package com.okn.dsp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.*
import androidx.compose.runtime.*

class MainActivity: ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){
  super.onCreate(savedInstanceState)
  setContent{
   OKNDSP()
  }
 }
}

@Composable
fun OKNDSP(){
 MaterialTheme {
  Surface {
   Column {
    Text("OKN_DSP", style=MaterialTheme.typography.headlineMedium)
    Text("BP1048P4 7CH DSP Controller")
    val channels=listOf(
     "CH1 Front L","CH2 Front R","CH3 SUB",
     "CH4 Rear L","CH5 Rear R","CH6 AUX L","CH7 AUX R")
    channels.forEach{
     Text(it)
     Slider(value=0.5f,onValueChange={})
    }
   }
  }
 }
}
