# OKN_DSP

DSP Controller for MVSilicon BP1048P4 7CH.

Build APK:
1. Upload to GitHub
2. Open Actions
3. Run Android Build APK
4. Download OKN_DSP-apk artifact
