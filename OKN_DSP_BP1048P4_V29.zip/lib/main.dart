import 'package:flutter/material.dart';

void main()=>runApp(const App());

class App extends StatelessWidget{
 const App({super.key});
 Widget build(BuildContext c)=>MaterialApp(
 debugShowCheckedModeBanner:false,
 theme:ThemeData.dark(),
 home:const Home());
}

class Home extends StatelessWidget{
 const Home({super.key});
 Widget build(BuildContext c)=>Scaffold(
 appBar:AppBar(title:const Text('OKN_DSP BP1048P4 V29')),
 body:ListView(padding:const EdgeInsets.all(18),children:const[
 Text('DSP Mixer Controller',
 style:TextStyle(color:Colors.cyan,fontSize:28)),
 SizedBox(height:20),
 Text('CH1 - CH7 Channel Select\n'
 'Volume Control\n'
 '15 Band EQ Per Channel\n'
 'Delay Time ms\n'
 'HPF / LPF Crossover\n'
 'DSP Command Builder\n'
 'Bluetooth TX Ready',
 style:TextStyle(fontSize:18))
 ]));
}
