// V29 15 Band EQ control
