// V29 CH1-CH7 channel model
