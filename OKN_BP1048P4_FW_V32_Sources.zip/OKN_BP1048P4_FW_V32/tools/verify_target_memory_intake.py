#!/usr/bin/env python3
import json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
m=json.loads((ROOT/'target_memory_report.json').read_text())
fw=json.loads((ROOT/'firmware_manifest.json').read_text())
rr=json.loads((ROOT/'resource_requirements.json').read_text())
errors=[]
if m.get('project_version')!=32: errors.append('target_memory_report project_version != 32')
if m.get('state')!='LOCKED_NO_EXACT_TARGET_LINKER_ARTIFACT': errors.append('shipped memory report must remain locked')
if m.get('artifact') is not None or m.get('parsed_regions')!=[]: errors.append('shipped memory report must contain no target values/artifact')
for k in ('exact_ram_capacity_verified','delay_arena_placement_verified','persistence_workspace_verified','authorizes_hardware','authorizes_mobile_flash','review_ready'):
    if m.get(k) is not False: errors.append(k+' must remain false')
if fw.get('resource_readiness',{}).get('target_memory_report')!='target_memory_report.json': errors.append('firmware manifest missing memory-report binding')
if rr.get('target_memory',{}).get('evidence_report')!='target_memory_report.json': errors.append('resource requirements missing memory-report binding')
if errors:
    print('ERROR: V32 target-memory intake policy violation')
    for e in errors: print(' - '+e)
    sys.exit(1)
print('PASS: V32 target linker/memory intake is content-bound-ready, value-empty, read-only, and non-authorizing')
