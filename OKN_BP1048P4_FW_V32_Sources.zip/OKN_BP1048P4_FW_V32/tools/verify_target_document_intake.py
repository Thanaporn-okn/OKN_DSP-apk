#!/usr/bin/env python3
import json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
m=json.loads((ROOT/'target_document_manifest.json').read_text(encoding='utf-8'))
fw=json.loads((ROOT/'firmware_manifest.json').read_text(encoding='utf-8'))
errors=[]
if m.get('schema')!=1 or m.get('project_version')!=32: errors.append('target document schema/version mismatch')
if m.get('state')!='LOCKED_NO_EXACT_TARGET_DOCUMENT': errors.append('shipped V32 target document intake must remain locked')
if m.get('documents')!=[] or m.get('promoted_claims')!=[]: errors.append('shipped V32 target document intake must contain no ingested/promoted evidence')
for k in ('exact_target_document_content_verified','reviewed_claim_mapping_complete','authorizes_hardware','authorizes_mobile_flash'):
    if m.get(k) is not False: errors.append(k+' must remain false')
for x in m.get('public_listings',[]):
    if x.get('content_bytes_ingested') is not False or x.get('reviewed') is not False or x.get('authorizes') not in ([],None):
        errors.append('public listing must remain non-authorizing/unreviewed without document bytes')
rh=fw.get('release_hardening',{})
if rh.get('exact_target_document_intake') is not True: errors.append('firmware manifest missing exact-target document intake flag')
if rh.get('document_filename_listing_auto_authorizes') is not False: errors.append('filename/listing auto-authorization must be false')
if rh.get('document_content_hash_required') is not True: errors.append('document content hash requirement missing')
if errors:
    print('ERROR: V32 target document intake policy violation')
    for e in errors: print(' - '+e)
    sys.exit(1)
print('PASS: V32 exact-target document intake requires content bytes + SHA256 + review and never authorizes from filenames/listings')
