#!/usr/bin/env python3
from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'evidence_manifest.json').read_text())
errors=[]
if m.get('schema')!=4: errors.append('evidence schema must be 4')
if m.get('project_version')!=32: errors.append('project_version must be 32')
if m.get('target')!='BP1048P4' or m.get('board')!='GoloPine 7CH': errors.append('target/board mismatch')
if m.get('policy')!='FAIL_CLOSED_NO_INFERENCE': errors.append('policy mismatch')
if m.get('hardware_authorized') is not False: errors.append('hardware_authorized must be false')
req=m.get('required_exact_evidence',{})
if any(bool(v) for v in req.values()): errors.append('V32 exact evidence flags must all remain false')
prov=m.get('provenance',{})
if prov.get('previous_source_sha256')!='0a75c9ee6d9c4d54d8bfc80af5c4efce8c525035ad4f12647457285a1798fe67': errors.append('V31 source provenance mismatch')
if prov.get('validation_zip_sha256')!='ddda2d55fd4fa3a8dd99269952f640f5047966d5aeaa3b4ff7208419d8a75b18': errors.append('V31 validation provenance mismatch')
if not any(o.get('id')=='v31-ci-validation' for o in m.get('observations',[])): errors.append('V31 CI observation missing')
for ob in m.get('observations',[]):
    if ob.get('authorizes') not in ([],None): errors.append('observations may not authorize hardware in V32')
if errors:
    [print('BLOCKED:',e) for e in errors]; sys.exit(1)
print('PASS: V32 evidence manifest is internally consistent and non-authorizing')
