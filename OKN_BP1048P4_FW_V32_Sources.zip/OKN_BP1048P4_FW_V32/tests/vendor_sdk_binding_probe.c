/*
 * V32 compile-only vendor SDK binding probe.
 * No main(), no link, no execution, no hardware I/O.
 */
#ifndef OKN_VENDOR_BINDING_HEADER
#error "OKN_VENDOR_BINDING_HEADER must name the reviewed shim header"
#endif

#include OKN_VENDOR_BINDING_HEADER
#include "portability/okn_vendor_sdk_binding_contract.h"
#include "hal/bp1048p4_sdk_adapter.h"

int okn_vendor_sdk_binding_compile_probe(void) {
    return (int)(
        OKN_VENDOR_BINDING_ABI +
        OKN_VENDOR_EVIDENCE_EXACT_BP1048P4 +
        OKN_VENDOR_EVIDENCE_EXACT_GOLOPINE_BOARD +
        OKN_VENDOR_BINDING_HAS_PLATFORM_INIT +
        OKN_VENDOR_BINDING_HAS_OUTPUT_SAFETY_MUTE +
        OKN_VENDOR_BINDING_HAS_AUDIO_START +
        OKN_VENDOR_BINDING_HAS_AUDIO_APPLY +
        OKN_VENDOR_BINDING_HAS_BLE_NOTIFY +
        OKN_VENDOR_BINDING_HAS_NVM +
        BP1048P4_SDK_ADAPTER_ABI);
}
