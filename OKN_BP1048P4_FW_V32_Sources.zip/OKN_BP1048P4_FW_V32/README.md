# OKN_BP1048P4_FW_V32

V32 is an exact-target document-intake hardening revision of the portable clean-room firmware foundation. Protocol V2 and persistence schema 2 remain unchanged.

## What V32 adds

- Content-bound `target_document_intake.py` for future exact BP1048P4 datasheets, SDK documentation, programmer manuals, and reviewed extracted-text companions.
- SHA-256 binding of the exact document bytes and optional extracted-text bytes before review.
- Filename/title/download-page matches are explicitly non-authorizing.
- An exact-target candidate becomes only `review_ready_for_claim_mapping` after content anchoring plus explicit review; it still cannot promote hardware claims by itself.
- Existing read-only target linker/memory intake from V31 is preserved.
- Public research records an exact-model `BP1048P4数据手册_V0.8.pdf` listing, but the shipped V32 package contains no vendor datasheet/programmer bytes.
- V31 Source ZIP and uploaded GitHub validation Artifact are bound as the immediate predecessor.

## Safety status

This package is **not** a BP1048P4/GoloPine flash image. It emits no programmer packet, does not invoke a target linker, and contains no guessed BP1048P4 address, pin, boot command, memory capacity, or image format. Hardware and mobile flashing remain locked.

Run:

```sh
make host-test
```
