OKN DSP Controller V5.1

Fixes:
- Correct APK upload path
- Android launcher fix
- Flutter build validation
- BLE permission support

Build:
flutter pub get
flutter build apk --release
