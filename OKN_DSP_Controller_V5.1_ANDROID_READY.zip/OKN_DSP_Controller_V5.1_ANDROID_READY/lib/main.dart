import 'package:flutter/material.dart';

void main(){
  runApp(const OKNApp());
}

class OKNApp extends StatelessWidget{
  const OKNApp({super.key});

  @override
  Widget build(BuildContext context){
    return MaterialApp(
      debugShowCheckedModeBanner:false,
      title:'OKN DSP Controller',
      theme:ThemeData.dark(),
      home:const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget{
  const HomePage({super.key});

  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar:AppBar(
        title:const Text('OKN DSP Controller V5.1'),
      ),
      body:const Center(
        child:Column(
          mainAxisAlignment:MainAxisAlignment.center,
          children:[
            Text('DSP Controller Ready'),
            SizedBox(height:20),
            Text('BP1048P4 / 7CH Framework'),
          ],
        ),
      ),
    );
  }
}
