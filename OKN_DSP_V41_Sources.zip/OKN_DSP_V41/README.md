# OKN DSP V41

Base: **V40 real-hardware stable**.

V41 adds **guarded manual SaveParams verification** without changing the proven V40 realtime writer/readback behavior. Saving is never automatic. A user tap starts an isolated transaction:

1. Require an idle realtime/GATT boundary.
2. Fetch a fresh authenticated Device Description (`SAVE_PRECHECK`).
3. Require the normal 7/7 scalar, 105/105 EQ, sensor and strict safe-PEQ 55/55 gates.
4. Capture the verified state that is intended to persist.
5. Send the already-proven SaveParams ID7 plaintext `570000000700000000` exactly once.
6. Require GATT success and wait 5 seconds.
7. Fetch a fresh `SAVE_POSTCHECK` descriptor.
8. Compare the tracked verified scalar/EQ state to the PRECHECK snapshot.
9. Report `V41 SAVE VERIFIED` only on a match. A mismatch reports `SAVE UNCONFIRMED • DO NOT RETRY automatically`.

During the save transaction realtime scalar/EQ writes, Reset EQ and manual refresh are blocked. GATT/cipher uncertainty fails closed and forces reconnect/re-auth. No non-safe/locked EQ row or unverified control is added.

“Restore verified state” in V41 is qualified by DSP persistence: after a successful guarded save, power-cycle the DSP and reconnect. V40/V41 readback must restore the app UI from the state returned by the DSP. V41 does **not** bulk-rewrite all bands as a restore operation.

Version: **41.0.0** (`versionCode 1041`)
