# OKN DSP V41

Base: **V40 real-hardware stable**.

V41 adds **guarded manual SaveParams plus read-only restore verification** without changing the V40 Frequency/Q/Gain writer, V39 Gain-only Safe Reset, V38 strict 55-row PEQ gate, BLE authentication, or UI lineage.

Manual **Save DSP** is allowed only from an idle transport. V41 then performs a fresh authenticated Device Description precheck, requires scalar 7/7, EQ 105/105, sensors >=4 and strict safe PEQ 55/55, fingerprints the verified actuator state, sends the verified ID7 Trigger exactly once using the existing UFE `0x57` zero-payload format, performs a fresh postcheck, and compares the verified state. A mismatch reports `SAVE UNCONFIRMED / DO NOT RETRY automatically`; no automatic retry or automatic SaveParams exists.

After a confirmed save, the verified fingerprint is retained locally. A later fresh INITIAL descriptor (for example after DSP power-cycle/reconnect) is compared read-only and reports `RESTORE VERIFIED` or `RESTORE DIFFERENT`; V41 never writes state during restore verification.

Version: **41.0.0** (`versionCode 1041`)
