# OKN DSP V41

Base: **V40 real-hardware stable**.

V41 adds **guarded manual SaveParams plus read-only Restore verified state** while preserving the V40 writer/readback behavior. Manual Save freezes normal polling, requires an idle realtime/TX boundary, performs a fresh authenticated Device Description precheck, requires S7/7 + EQ105/105 + sensors>=4 + strict-safe PEQ55/55, snapshots the complete verified descriptor state, sends the verified ID7 SaveParams trigger once using the existing UFE 0x57 format, performs a fresh postcheck, and compares the postcheck against the intended snapshot.

If the postcheck differs, the app reports `SAVE UNCONFIRMED / DO NOT RETRY automatically`. Any GATT rejection/error/timeout or uncertain TX ordering during the guarded transaction fails closed and forces reconnect/re-auth.

Restore remains deliberately **read-only**: it fetches a fresh authenticated descriptor and restores UI/local state from the DSP. It does not replay a local snapshot and does not use hardware preset recall/write, because those paths remain unverified/locked.

V38 safe-PEQ Frequency/Q semantics, V39 Gain-only Safe Reset, V40 authoritative readback, UI lineage/themes/presets/touch isolation/WindowInsets/icon, and the existing application/signing identity are retained.

Version: **41.0.0** (`versionCode 1041`)
