#!/usr/bin/env python3
from pathlib import Path
import re, sys

root=Path(__file__).resolve().parent.parent
ble=(root/'app/src/main/java/com/okn/dsp/BleManager.java').read_text()
proto=(root/'app/src/main/java/com/okn/dsp/DspProtocol.java').read_text()
view=(root/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
build=(root/'app/build.gradle').read_text()

checks={
 'version41': "versionCode 1041" in build and "versionName '41.0.0'" in build,
 'save_id7': 'static final int ID_SAVE_PARAMS = 7;' in proto,
 'save_exact_encoder': 'return encodeWrite(ID_SAVE_PARAMS, 0, new byte[0]);' in proto,
 'manual_entry': 'int requestGuardedSave()' in ble,
 'precheck_descriptor': 'startDescriptorRequest("SAVE_PRECHECK")' in ble,
 'postcheck_descriptor': 'startDescriptorRequest("SAVE_POSTCHECK")' in ble,
 'idle_gate': 'trebleTarget != null' in ble and '!pending.isEmpty()' in ble and
              '!eqRealtimePending.isEmpty()' in ble and '!eqShapePending.isEmpty()' in ble,
 'write_ticket_boundary': 'if (!writeTickets.isEmpty())' in ble,
 'safe_gate55': 'safePeakingRows != EXPECTED_SAFE_PEAKING_ROWS' in ble and 'EXPECTED_SAFE_PEAKING_ROWS = 55' in ble,
 'snapshot': 'VerifiedSnapshot.capture(scalarValues, eqBands)' in ble,
 'save_once_surface': ble.count('DspProtocol.encodeSaveParamsTrigger()') == 1,
 'save_ticket': '"SAVE_PARAMS_V41"' in ble,
 'status0_required': 'status != BluetoothGatt.GATT_SUCCESS' in ble,
 'settle_5s': 'SAVE_SETTLE_MS = 5000L' in ble,
 'post_compare': 'saveExpected.compare(scalarValues, eqBands)' in ble,
 'unconfirmed_no_retry': 'SAVE UNCONFIRMED • DO NOT RETRY automatically' in ble,
 'fail_closed_session': 'sessionFault("SAVE UNCONFIRMED' in ble,
 'ui_manual_button': 'SAVE VERIFIED STATE TO DSP' in view and 'id.equals("saveDsp")' in view,
 'reset_locked_while_save': 'if (saveInProgress) return -4;' in ble,
 'scalar_locked_while_save': 'txCipher == null || saveInProgress' in ble,
 'eq_locked_while_save': 'eqResetActive || saveInProgress' in ble,
 'shape_locked_while_save': 'eqResetActive || saveInProgress' in ble,
 'gain_gap_retained': 'EQ_REALTIME_MIN_GAP_MS = 45L' in ble,
 'shape_gap_retained': 'EQ_SHAPE_MIN_GAP_MS = 110L' in ble,
 'reset_gap_retained': 'EQ_RESET_MIN_GAP_MS = 110L' in ble,
}

# Manual-only proof: the one call from UI must be the only requestGuardedSave callsite outside its definition.
call_count = ble.count('requestGuardedSave()') + view.count('requestGuardedSave()')
checks['manual_only_call_surface'] = call_count == 2

# Save encoder must not appear in sync/readback setters or reset action.
for label, source, pattern in [
    ('sync_no_save_scalar', view, r'void setScalarFromDsp\(.*?\n    \}'),
    ('sync_no_save_eq', view, r'void setEqFromDsp\(.*?\n    \}'),
    ('sync_complete_no_save', view, r'void onDspSyncComplete\(.*?\n    \}'),
]:
    m=re.search(pattern, source, re.S)
    checks[label]=bool(m) and 'requestGuardedSave' not in m.group(0)

for k,v in checks.items(): print(f'{k}={"PASS" if v else "FAIL"}')
if not all(checks.values()):
    sys.exit(1)
print('V41_GUARDED_SAVE_STATIC_PASS')
