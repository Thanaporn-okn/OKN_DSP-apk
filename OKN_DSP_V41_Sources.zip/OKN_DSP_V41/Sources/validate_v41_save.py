#!/usr/bin/env python3
from pathlib import Path
import json, re, sys
root=Path(__file__).resolve().parent.parent
ble=(root/'app/src/main/java/com/okn/dsp/BleManager.java').read_text()
proto=(root/'app/src/main/java/com/okn/dsp/DspProtocol.java').read_text()
view=(root/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
main=(root/'app/src/main/java/com/okn/dsp/MainActivity.java').read_text()
build=(root/'app/build.gradle').read_text()
evidence=json.loads((root/'Sources/ProtocolEvidence/GoloPine_DeviceDescription_REAL_20260906_204555.json').read_text())
id7=next((a for a in evidence.get('actuators',[]) if a.get('ID')==7),None)
checks={
 'version41': "versionCode 1041" in build and "versionName '41.0.0'" in build,
 'id7_evidence': bool(id7) and id7.get('name')=='SaveParams' and id7.get('type')==2100 and id7.get('cpar')=='Trigger',
 'id7_no_data': bool(id7) and not any(k.startswith('UFE_TYPE_') for k in id7),
 'id7_constant': 'static final int ID_SAVE_PARAMS = 7;' in proto,
 'existing_ufe_writer_only': 'return encodeWrite(ID_SAVE_PARAMS, 0, new byte[0]);' in proto,
 'manual_entry': 'void requestManualSaveVerified()' in ble and 'homeSaveVerified' in view,
 'precheck': 'startDescriptorRequest("SAVE_PRECHECK")' in ble,
 'postcheck': 'startDescriptorRequest("SAVE_POSTCHECK")' in ble,
 'strict_scalar_7': 'scalarValues.size() != DspProtocol.VERIFIED_SCALARS.length' in ble,
 'strict_eq_105': 'descriptorEqCount != 105' in ble,
 'strict_sensors_4': 'descriptorSensorCount < 4' in ble,
 'strict_safe_55': 'safePeakingRows != EXPECTED_SAFE_PEAKING_ROWS' in ble and 'EXPECTED_SAFE_PEAKING_ROWS = 55' in ble,
 'idle_boundary': all(x in ble for x in ['!pending.isEmpty()', '!eqRealtimePending.isEmpty()', '!eqShapePending.isEmpty()', 'trebleTarget != null', 'writeTickets.isEmpty()']),
 'poll_freeze': 'stopOriginalCommandScheduler();' in re.search(r'private void beginManualSaveVerified\(\) \{(.*?)\n    \}',ble,re.S).group(1),
 'save_writer_lock_scalar': 'txCipher == null || saveStage != SAVE_IDLE' in ble,
 'save_writer_lock_gain': 'eqResetActive || saveStage != SAVE_IDLE' in ble,
 'save_writer_lock_shape': '!eqShapeHealthGate || eqResetActive || saveStage != SAVE_IDLE' in ble,
 'save_reset_lock': 'if (saveStage != SAVE_IDLE) return -4;' in ble,
 'snapshot_all_eq': 'new DspProtocol.EqBand[7][DspProtocol.EQ_BANDS]' in ble,
 'snapshot_compare': 'saveIntended.matches(scalarValues, eqBands)' in ble,
 'unconfirmed_exact': 'SAVE UNCONFIRMED / DO NOT RETRY automatically' in ble,
 'no_retry_loop': 'SAVE UNCONFIRMED / DO NOT RETRY automatically' in ble and 'postcheck differs from intended state' in ble,
 'descriptor_tx_confirm': 'saveDescriptorTxConfirmed' in ble and 'DESC_SAVE_PRECHECK' in ble and 'DESC_SAVE_POSTCHECK' in ble,
 'session_fault_reauth': 'txCipher = null;' in ble and 'rxCipher = null;' in ble and 'main.postDelayed(this::startScan, 900L)' in ble,
 'restore_read_only': 'requestVerifiedReadback("RESTORE_VERIFIED")' in ble,
 'restore_ui': 'read DSP → app' in view,
 'save_result_toast': 'onGuardedSaveResult' in main,
 'v38_gap': 'EQ_SHAPE_MIN_GAP_MS = 110L' in ble,
 'v39_reset': 'DspProtocol.peakingFromCurrent(current, 0f)' in ble and 'EQ_RESET_MIN_GAP_MS = 110L' in ble,
 'gain_gap': 'EQ_REALTIME_MIN_GAP_MS = 45L' in ble,
}
# Ensure readback callbacks still cannot write to DSP.
for name,pat in [('scalar_readback',r'void setScalarFromDsp\(.*?\n    \}'),('eq_readback',r'void setEqFromDsp\(.*?\n    \}')]:
    m=re.search(pat,view,re.S)
    checks[name+'_no_write']=bool(m) and all(x not in m.group(0) for x in ['requestManualSaveVerified','setScalarRealtime','setEqRealtime','setEqShapeRealtime','resetEqSafe'])
for k,v in checks.items():
    print(f'{k}={"PASS" if v else "FAIL"}')
if not all(checks.values()): sys.exit(1)
# Independent expected plaintext from verified UFE layout: 0x57 + BE32(7)+BE16(0)+BE16(0)
plain=bytes([0x57])+int(7).to_bytes(4,'big')+int(0).to_bytes(2,'big')+int(0).to_bytes(2,'big')
assert plain.hex().upper()=='570000000700000000'
print('SaveParams_plain='+plain.hex().upper())
print('V41_GUARDED_SAVE_STATIC_PASS')
