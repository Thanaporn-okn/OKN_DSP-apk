#!/usr/bin/env python3
from pathlib import Path
import sys
root=Path(__file__).resolve().parent.parent
ble=(root/'app/src/main/java/com/okn/dsp/BleManager.java').read_text()
proto=(root/'app/src/main/java/com/okn/dsp/DspProtocol.java').read_text()
view=(root/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
build=(root/'app/build.gradle').read_text()
checks={
 'version41': "versionCode 1041" in build and "versionName '41.0.0'" in build,
 'save_id7': 'ID_SAVE_PARAMS = 7' in proto,
 'verified_zero_payload_trigger': 'encodeTriggerWrite' in proto and 'return encodeWrite(id, 0, new byte[0]);' in proto,
 'manual_entry': 'int requestGuardedSave()' in ble and 'id.equals("saveDsp")' in view,
 'queue_idle_gate': '!pending.isEmpty()' in ble and '!eqRealtimePending.isEmpty()' in ble and '!eqShapePending.isEmpty()' in ble and 'hasWriteTickets()' in ble,
 'precheck_descriptor': 'startDescriptorRequest("SAVE_PRECHECK")' in ble,
 'postcheck_descriptor': 'startDescriptorRequest("SAVE_POSTCHECK")' in ble,
 'health_7_105_4': 'scalarValues.size() == DspProtocol.VERIFIED_SCALARS.length' in ble and 'eqCount == 105' in ble and 'sensorCount >= 4' in ble,
 'safe_55': 'safePeakingRows == EXPECTED_SAFE_PEAKING_ROWS' in ble and 'EXPECTED_SAFE_PEAKING_ROWS = 55' in ble,
 'single_save_send': 'sendScheduledControl(PendingCommand.saveParams())' in ble,
 'post_compare': 'saveExpectedFingerprint.equals(actual)' in ble,
 'no_auto_retry': 'SAVE UNCONFIRMED / DO NOT RETRY automatically' in ble,
 'restore_read_only': 'RESTORE VERIFIED' in ble and 'RESTORE DIFFERENT' in ble,
 'save_blocks_live_scalar': 'txCipher == null || saveTransactionActive' in ble,
 'save_blocks_reset': 'if (saveTransactionActive) return -4;' in ble,
 'v39_v40_files_retained': (root/'Sources/V39_SAFE_RESET_EQ.txt').exists() and (root/'Sources/V40_DSP_READBACK_SYNC.txt').exists(),
}
# Exact expected plaintext for zero-payload UFE write: 57 + ID7 BE32 + offset0 BE16 + len0 BE16
expected=bytes.fromhex('570000000700000000')
checks['trigger_vector']=len(expected)==9 and expected[0]==0x57 and int.from_bytes(expected[1:5],'big')==7 and expected[5:]==b'\0\0\0\0'
failed=[k for k,v in checks.items() if not v]
for k,v in checks.items(): print(f"{'PASS' if v else 'FAIL'} {k}")
if failed:
    print('FAILED:', ', '.join(failed)); sys.exit(1)
print('V41 GUARDED SAVE/RESTORE PREFLIGHT PASS')
