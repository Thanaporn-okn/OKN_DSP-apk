#!/usr/bin/env python3
from pathlib import Path
import re, sys, hashlib
root=Path(__file__).resolve().parent.parent
ble=(root/'app/src/main/java/com/okn/dsp/BleManager.java').read_text()
main=(root/'app/src/main/java/com/okn/dsp/MainActivity.java').read_text()
view=(root/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
state=(root/'app/src/main/java/com/okn/dsp/DspState.java').read_text()
build=(root/'app/build.gradle').read_text()
proto=(root/'app/src/main/java/com/okn/dsp/DspProtocol.java').read_bytes()
checks={
 'version40plus': ('versionCode 1040' in build or 'versionCode 1041' in build) and ("versionName '40.0.0'" in build or "versionName '41.0.0'" in build),
 'listener_sync_callback': 'void onDspSyncComplete(String source, int scalarCount, int eqCount, int safePeakingRows);' in ble,
 'initial_descriptor': 'startDescriptorRequest("INITIAL")' in ble,
 'manual_refresh_descriptor': 'startDescriptorRequest("REFRESH")' in ble,
 'refresh_blocks_reset': 'if (eqResetActive || liveWriteBusy' in ble,
 'reason_tracking': 'descriptorReason' in ble and 'publishDescriptorToUi(loadedReason, eqCount)' in ble,
 'health_scalar_7': 'scalarValues.size() == DspProtocol.VERIFIED_SCALARS.length' in ble,
 'health_eq_105': 'eqCount == 105' in ble,
 'safe_gate_55': 'safePeakingRows == EXPECTED_SAFE_PEAKING_ROWS' in ble and 'EXPECTED_SAFE_PEAKING_ROWS = 55' in ble,
 'sync_post_after_publish': 'listener.onDspSyncComplete(syncSource, scalarCount, publishedEqCount, safeCount)' in ble,
 'main_bridge': 'dspView.onDspSyncComplete(source, scalarCount, eqCount, safePeakingRows)' in main,
 'scalar_local_setters': 'state.setMasterVolume(value);' in view and 'state.setBassVolume(value);' in view and 'state.setBassCutoff(value);' in view,
 'eq_local_setters': 'state.setEqFreq(channel0, band0, frequency);' in view and 'state.setEqQ(channel0, band0, q);' in view and 'state.setEqGain(channel0, band0, gainDb);' in view,
 'sync_checkpoint': 'state.flushPending(false);' in view,
 'sync_diagnostic': ('V40 DSP SYNC' in view or 'V41 DSP SYNC' in view),
 'reset_v39_retained': 'int resetEqSafe(int channel0)' in ble and 'EQ_RESET_MIN_GAP_MS = 110L' in ble,
 'fq_v38_retained': 'EQ_SHAPE_MIN_GAP_MS = 110L' in ble and 'eqShapeHealthGate' in ble,
 'manual_only_saveparams': ble.count('sendScheduledControl(PendingCommand.saveParams())') == 1 and 'requestGuardedSave()' in ble,
}
# Sync methods themselves must not call hardware writers.
ms=re.search(r'void setScalarFromDsp\(.*?\n    \}', view, re.S)
me=re.search(r'void setEqFromDsp\(.*?\n    \}', view, re.S)
for label,m in [('scalar_readback_no_write',ms),('eq_readback_no_write',me)]:
    checks[label]=bool(m) and all(x not in m.group(0) for x in ['sendVerified','setScalarRealtime','setEqRealtime','setEqShapeRealtime'])
for k,v in checks.items(): print(f'{k}={"PASS" if v else "FAIL"}')
if not all(checks.values()): sys.exit(1)
print('DspProtocol_SHA256='+hashlib.sha256(proto).hexdigest())
print('V40_DSP_READBACK_SYNC_REGRESSION_PASS')
