#!/usr/bin/env python3
from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[1]
m=json.loads((root/"evidence_manifest.json").read_text())
errors=[]
if m.get("schema")!=4: errors.append("evidence schema must be 4")
if m.get("project_version")!=14: errors.append("project_version must be 14")
if m.get("target")!="BP1048P4" or m.get("board")!="GoloPine 7CH": errors.append("target/board mismatch")
if m.get("policy")!="FAIL_CLOSED_NO_INFERENCE": errors.append("policy mismatch")
if m.get("hardware_authorized") is not False: errors.append("hardware_authorized must be false")
req=m.get("required_exact_evidence",{})
if any(bool(v) for v in req.values()): errors.append("V14 exact evidence flags must all remain false")
prov=m.get("provenance",{})
if prov.get("previous_source_sha256")!="bb4e043d8eac4f5f83ea724a676edd84d5e59ef88b2fe3d3dbe247ebd00fe3c7": errors.append("V13 source provenance mismatch")
if prov.get("validation_zip_sha256")!="ac60ad17bcf97960adb2ae55da9bbaf9c2d6aa7a9bb5cb5099bbd428a44c3c6f": errors.append("V13 validation provenance mismatch")
for ob in m.get("observations",[]):
    if ob.get("authorizes") not in ([],None): errors.append("observations may not authorize hardware in V14")
if errors:
    [print("BLOCKED:",e) for e in errors]; sys.exit(1)
print("PASS: V14 evidence manifest is internally consistent and non-authorizing")
