# OKN_BP1048P4_FW_V14

V14 is a portable control-session integrity release built on the validated V13 baseline.

The wire protocol stays at version 2. V14 adds an exact-request retry cache for a
future serialized Android BLE/USB control adapter. Repeating the immediately previous
valid request replays its encoded response instead of evaluating the command again,
so a lost ACK/notification cannot cause a SET command to advance revision/dirty state
twice. A full internal response buffer also makes retry after a too-small caller buffer
idempotent. The cache is reset at a transport reconnect/session boundary.

This is not a cryptographic anti-replay feature and does not authorize hardware.
All BP1048P4/GoloPine target, flash, board, memory, BLE, NVM and programmer evidence
gates remain fail-closed. No target `.bin` is produced.

See `docs/CONTROL_SESSION_V14.md`.
