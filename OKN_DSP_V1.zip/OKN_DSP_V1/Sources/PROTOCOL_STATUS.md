# DSP Protocol Status — V1

Known from supplied project data:

- Target shown in UI: `DSP-7900`
- BLE characteristic UUID: `0000ab01-0000-1000-8000-00805f9b34fb`
- Captured events: RX_READ, `len=0`, mode=IDLE, status=0, empty hex payload.

What is not yet proven:

- GATT service UUID containing AB01.
- Whether AB01 is read-only, write, write-no-response, notify, or a combination on the real unit.
- Command/opcode packet format for master gain, EQ, crossover, delay and output controls.
- Scaling, byte order, checksum/CRC and acknowledgement behavior.

Implementation rule:

- Never invent hardware packet bytes.
- UI changes are applied immediately in local state.
- BLE scans for DSP-7900 / DSP-named devices and discovers services.
- AB01 is found dynamically across discovered services and read when readable.
- `writeConfirmedFrame()` is available only for a byte frame that has been confirmed from real protocol evidence and only when AB01 exposes a writable property.
