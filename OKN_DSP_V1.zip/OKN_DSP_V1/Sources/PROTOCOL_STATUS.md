# DSP protocol status — V1

Confirmed topology carried into the clean V1 architecture:

- BLE Service: `0000AB00-0000-1000-8000-00805F9B34FB`
- Write characteristic: `0000AB01-0000-1000-8000-00805F9B34FB`
- Primary notify: `0000AB02-0000-1000-8000-00805F9B34FB`
- Secondary notify: `0000AB03-0000-1000-8000-00805F9B34FB`
- One GATT write in flight, latest-target-wins queue, minimum 38 ms pacing, 2.5 s write callback timeout.
- Confirmed scalar actuator IDs from prior reverse engineering: 2, 3, 8, 9, 10, 13, 11.
- EQ actuator map CH1..CH7: 4, 5, 6, 14, 15, 16, 17.
- 15 EQ records per channel; verified writable EQ type boundary: PEAKING type=12; record size 48 bytes.

V1 does not invent the missing authenticated session frames, scalar byte layout, EQ record offsets/scaling, checksum, or ACK parser. The UI therefore updates immediately locally and BLE discovery/connection is real, while hardware-changing writes remain gated behind `enqueueVerifiedWrite()` until those bytes are confirmed from captures.
