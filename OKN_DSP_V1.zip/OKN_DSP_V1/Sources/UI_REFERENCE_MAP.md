# UI reference map — V1

All five supplied references are 864x1536 and are preserved in `Sources/reference/`.

- `Home.png` -> Home
- `EQ.png` -> EQ
- `Crossover.png` -> Crossover
- `Delay.png` -> Delay
- `Output.png` -> Output

The custom Android view uses 864x1536 as its design coordinate system and scales it to the actual full-screen surface. No unrelated screen or navigation structure is introduced.
