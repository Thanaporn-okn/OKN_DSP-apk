These five images are the exact UI references supplied for the OKN_DSP rebuild:
01_HOME.png
02_EQ.png
03_CROSSOVER.png
04_DELAY.png
05_OUTPUT.png
