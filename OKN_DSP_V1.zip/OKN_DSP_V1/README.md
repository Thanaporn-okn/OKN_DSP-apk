# OKN_DSP V1

Fresh V1 rebuild from the five uploaded 864x1536 UI references: Home, EQ, Crossover, Delay, Output.

- Native Android custom Canvas UI, designed on an 864x1536 coordinate system and scaled to the screen.
- Immediate local interaction for navigation, channel tabs, sliders, switches and selectors.
- BLE discovery/connection foundation uses confirmed topology: Service AB00, write AB01, notifications AB02/AB03.
- Hardware command encoding is intentionally not guessed. The exact authenticated session/write byte frames are still required before hardware-changing UI actions can safely be wired to AB01.
- Package: com.okn.dsp
- versionCode: 1
- versionName: 1.0.0
- compileSdk / targetSdk: 35
- minSdk: 23
