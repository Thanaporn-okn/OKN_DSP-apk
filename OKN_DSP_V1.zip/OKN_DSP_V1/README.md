# OKN_DSP V1

Android native (Kotlin + Jetpack Compose) rebuilt from step 1 using the five uploaded UI reference screens.

## Implemented in V1

- Full-screen responsive layout for phone and tablet.
- Five functional pages: Home, Parametric EQ, Crossover, Delay, Output.
- Seven channels (CH1..CH7) and channel selector.
- Immediate UI updates for sliders, switches, buttons and dropdowns (no debounce/relay delay in UI state).
- Parametric EQ graph, crossover graph, delay car visualization and output meters drawn natively with Compose Canvas.
- Local preset Save / Load / Delete using Android SharedPreferences.
- Real BLE scan/connect layer and discovery of known characteristic UUID `0000ab01-0000-1000-8000-00805f9b34fb`.
- Read/probe support for AB01 and a guarded raw-write method that only writes confirmed frames to a writable characteristic.

## Important hardware-control status

The available capture only confirms characteristic UUID AB01 and empty read events. It does **not** define the DSP command byte frames for gain/EQ/crossover/delay/output. V1 deliberately does not invent packet bytes. The UI is fully interactive and BLE connection is real; physical DSP parameter writes require confirmed protocol frames from traffic captures.

## Version policy

This package is V1. If a build/runtime error is found, the correction should be issued as a new version (V2, V3, ...), not overwritten in place.
