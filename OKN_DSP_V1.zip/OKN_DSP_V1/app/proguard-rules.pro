# OKN_DSP V1: no custom ProGuard rules yet.
