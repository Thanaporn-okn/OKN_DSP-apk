# OKN_DSP V1 - no shrinking rules required yet.
