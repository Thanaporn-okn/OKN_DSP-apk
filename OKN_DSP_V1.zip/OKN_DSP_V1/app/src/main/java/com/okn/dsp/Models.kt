package com.okn.dsp

enum class DspScreen { HOME, EQ, CROSSOVER, DELAY, OUTPUT }

data class EqBand(
    val type: String,
    val frequencyHz: Float,
    val gainDb: Float,
    val q: Float,
    val enabled: Boolean = true
)

data class FilterState(
    val type: String = "Linkwitz-Riley",
    val frequencyHz: Float,
    val slopeDbOct: Int = 24,
    val bypass: Boolean = false
)

data class ChannelState(
    val id: Int,
    val name: String,
    val shortName: String,
    val delayMs: Float = 0f,
    val outputDb: Float = -3f,
    val muted: Boolean = false,
    val solo: Boolean = false,
    val phaseInverted: Boolean = false,
    val linked: Boolean = false
)

data class DspUiState(
    val currentScreen: DspScreen = DspScreen.HOME,
    val selectedChannel: Int = 0,
    val masterVolumeDb: Float = -3f,
    val bassVolumeDb: Float = 4f,
    val bassCutoffHz: Float = 100f,
    val bassBoostDb: Float = 3f,
    val middleBoostDb: Float = -2f,
    val trebleBoostDb: Float = 1f,
    val audioSource: String = "High Level (Speaker)",
    val systemPreset: String = "Flat",
    val presetName: String = "Custom 1",
    val eqPage: Int = 0,
    val eqBands: List<EqBand> = defaultEqBands(),
    val hpf: FilterState = FilterState(frequencyHz = 100f),
    val lpf: FilterState = FilterState(frequencyHz = 1000f),
    val crossoverView: String = "Magnitude",
    val phaseDegrees: Int = 0,
    val polarity: String = "Normal",
    val linkLR: Boolean = true,
    val outputMode: String = "Stereo",
    val delayUnit: String = "ms",
    val seatPreset: String = "Driver (Left)",
    val masterOutputDb: Float = -1f,
    val channels: List<ChannelState> = defaultChannels()
)

fun defaultChannels(): List<ChannelState> = listOf(
    ChannelState(1, "Front L", "CH1", 0.00f, -3.0f, linked = true),
    ChannelState(2, "Front R", "CH2", 1.25f, -2.5f, linked = true),
    ChannelState(3, "Rear L", "CH3", 2.60f, -4.0f),
    ChannelState(4, "Rear R", "CH4", 2.30f, -1.0f),
    ChannelState(5, "Center", "CH5", 0.80f, -2.0f),
    ChannelState(6, "Sub L", "CH6", 3.10f, -3.5f),
    ChannelState(7, "Sub R", "CH7", 1.90f, -4.5f)
)

fun defaultEqBands(): List<EqBand> = listOf(
    EqBand("PEQ", 32f, -3f, 0.70f),
    EqBand("Low Shelf", 100f, 2.5f, 1.00f),
    EqBand("PEQ", 200f, 6f, 1.20f),
    EqBand("PEQ", 500f, -4f, 1.00f),
    EqBand("PEQ", 2000f, 3f, 1.00f),
    EqBand("High Shelf", 10000f, -2f, 0.70f),
    EqBand("PEQ", 63f, 0f, 1.00f),
    EqBand("PEQ", 125f, 0f, 1.00f),
    EqBand("PEQ", 250f, 0f, 1.00f),
    EqBand("PEQ", 1000f, 0f, 1.00f),
    EqBand("PEQ", 4000f, 0f, 1.00f),
    EqBand("PEQ", 8000f, 0f, 1.00f),
    EqBand("PEQ", 16000f, 0f, 1.00f),
    EqBand("PEQ", 18000f, 0f, 1.00f),
    EqBand("PEQ", 20000f, 0f, 1.00f)
)
