package com.okn.dsp

import android.annotation.SuppressLint
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.os.Build
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID


data class BleUiState(
    val status: String = "Disconnected",
    val deviceName: String = "DSP-7900",
    val connected: Boolean = false,
    val scanning: Boolean = false,
    val characteristicFound: Boolean = false,
    val characteristicWritable: Boolean = false,
    val lastRxHex: String = ""
)

class BleController(private val context: Context) {
    companion object {
        val KNOWN_CHARACTERISTIC_UUID: UUID = UUID.fromString("0000ab01-0000-1000-8000-00805f9b34fb")
        private const val TARGET_NAME = "DSP-7900"
    }

    private val bluetoothManager = context.getSystemService(BluetoothManager::class.java)
    private val adapter get() = bluetoothManager?.adapter
    private val scanner get() = adapter?.bluetoothLeScanner

    private val _state = MutableStateFlow(BleUiState())
    val state: StateFlow<BleUiState> = _state.asStateFlow()

    private var gatt: BluetoothGatt? = null
    private var knownCharacteristic: BluetoothGattCharacteristic? = null

    @SuppressLint("MissingPermission")
    fun toggleConnection() {
        if (_state.value.connected || gatt != null) disconnect() else startScan()
    }

    @SuppressLint("MissingPermission")
    fun startScan() {
        if (_state.value.scanning) return
        val s = scanner ?: run {
            _state.value = _state.value.copy(status = "Bluetooth unavailable")
            return
        }
        _state.value = _state.value.copy(status = "Scanning…", scanning = true)
        s.startScan(scanCallback)
    }

    @SuppressLint("MissingPermission")
    fun disconnect() {
        runCatching { scanner?.stopScan(scanCallback) }
        runCatching { gatt?.disconnect() }
        runCatching { gatt?.close() }
        gatt = null
        knownCharacteristic = null
        _state.value = BleUiState()
    }

    @SuppressLint("MissingPermission")
    fun close() = disconnect()

    @SuppressLint("MissingPermission")
    private fun connect(result: ScanResult) {
        runCatching { scanner?.stopScan(scanCallback) }
        _state.value = _state.value.copy(status = "Connecting…", scanning = false, deviceName = result.device.name ?: TARGET_NAME)
        gatt = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            result.device.connectGatt(context, false, gattCallback, android.bluetooth.BluetoothDevice.TRANSPORT_LE)
        } else {
            result.device.connectGatt(context, false, gattCallback)
        }
    }

    @SuppressLint("MissingPermission")
    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val name = result.device.name ?: result.scanRecord?.deviceName ?: ""
            if (name.contains(TARGET_NAME, ignoreCase = true) || name.contains("DSP", ignoreCase = true)) {
                connect(result)
            }
        }

        override fun onScanFailed(errorCode: Int) {
            _state.value = _state.value.copy(status = "Scan failed ($errorCode)", scanning = false)
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            when (newState) {
                BluetoothProfile.STATE_CONNECTED -> {
                    this@BleController.gatt = gatt
                    _state.value = _state.value.copy(status = "Connected", connected = true, scanning = false)
                    gatt.discoverServices()
                }
                BluetoothProfile.STATE_DISCONNECTED -> {
                    runCatching { gatt.close() }
                    this@BleController.gatt = null
                    knownCharacteristic = null
                    _state.value = BleUiState(status = if (status == BluetoothGatt.GATT_SUCCESS) "Disconnected" else "Disconnected ($status)")
                }
            }
        }

        @SuppressLint("MissingPermission")
        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) return
            val ch = findCharacteristic(gatt.services, KNOWN_CHARACTERISTIC_UUID)
            knownCharacteristic = ch
            val writable = ch?.let {
                (it.properties and BluetoothGattCharacteristic.PROPERTY_WRITE) != 0 ||
                    (it.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0
            } ?: false
            _state.value = _state.value.copy(characteristicFound = ch != null, characteristicWritable = writable)
            if (ch != null && (ch.properties and BluetoothGattCharacteristic.PROPERTY_READ) != 0) {
                runCatching { gatt.readCharacteristic(ch) }
            }
        }

        @Deprecated("Deprecated in API 33 but required for older Android versions")
        override fun onCharacteristicRead(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS && characteristic.uuid == KNOWN_CHARACTERISTIC_UUID) {
                _state.value = _state.value.copy(lastRxHex = characteristic.value?.toHex().orEmpty())
            }
        }

        @Deprecated("Deprecated in API 33 but required for older Android versions")
        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            if (characteristic.uuid == KNOWN_CHARACTERISTIC_UUID) {
                _state.value = _state.value.copy(lastRxHex = characteristic.value?.toHex().orEmpty())
            }
        }
    }

    private fun findCharacteristic(services: List<BluetoothGattService>, uuid: UUID): BluetoothGattCharacteristic? {
        services.forEach { service ->
            service.characteristics.firstOrNull { it.uuid == uuid }?.let { return it }
        }
        return null
    }

    /**
     * Raw BLE write is intentionally available only when the discovered AB01 characteristic is writable.
     * DSP parameter -> byte-frame mapping is NOT guessed. The UI therefore updates immediately, while
     * hardware writes must wait for confirmed protocol frames from the real DSP traffic capture.
     */
    @SuppressLint("MissingPermission")
    fun writeConfirmedFrame(frame: ByteArray): Boolean {
        val g = gatt ?: return false
        val ch = knownCharacteristic ?: return false
        val noResponse = (ch.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0
        val normalWrite = (ch.properties and BluetoothGattCharacteristic.PROPERTY_WRITE) != 0
        if (!noResponse && !normalWrite) return false
        val writeType = if (noResponse) BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE else BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            g.writeCharacteristic(ch, frame, writeType) == android.bluetooth.BluetoothStatusCodes.SUCCESS
        } else {
            @Suppress("DEPRECATION")
            run {
                ch.writeType = writeType
                ch.value = frame
                g.writeCharacteristic(ch)
            }
        }
    }
}

private fun ByteArray.toHex(): String = joinToString(separator = " ") { "%02X".format(it) }
