package com.okn.dsp;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int REQ_BT = 7001;
    private static final UUID UUID_AB00 = uuid16(0xAB00);
    private static final UUID UUID_AB01 = uuid16(0xAB01);
    private static final UUID UUID_AB02 = uuid16(0xAB02);
    private static final UUID UUID_AB03 = uuid16(0xAB03);
    private static final UUID UUID_CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

    private final Handler main = new Handler(Looper.getMainLooper());
    private DspControlView dspView;
    private BluetoothAdapter adapter;
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic writeChar;
    private boolean scanning;
    private byte[] latestPendingWrite;
    private boolean writeInFlight;
    private long lastWriteMs;
    private Runnable writeTimeout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        enterImmersive();
        BluetoothManager manager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = manager == null ? null : manager.getAdapter();
        scanner = adapter == null ? null : adapter.getBluetoothLeScanner();
        dspView = new DspControlView(this);
        dspView.setBleAction(this::toggleBleConnection);
        setContentView(dspView);
    }

    private void enterImmersive() {
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.systemBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) enterImmersive();
    }

    public void toggleBleConnection() {
        if (gatt != null) {
            disconnectGatt();
            return;
        }
        if (!hasBlePermissions()) {
            requestBlePermissions();
            return;
        }
        startScan();
    }

    private boolean hasBlePermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
                   checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestBlePermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}, REQ_BT);
        } else {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_BT);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_BT && hasBlePermissions()) startScan();
    }

    private void startScan() {
        if (adapter == null || !adapter.isEnabled()) {
            dspView.setConnectionState("Bluetooth Off", false);
            return;
        }
        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null || scanning) return;
        scanning = true;
        dspView.setConnectionState("Scanning", false);
        ScanSettings settings = new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build();
        try {
            scanner.startScan(null, settings, scanCallback);
            main.postDelayed(() -> {
                if (scanning) {
                    stopScan();
                    dspView.setConnectionState("Disconnected", false);
                }
            }, 8000);
        } catch (SecurityException ex) {
            scanning = false;
            dspView.setConnectionState("Permission", false);
        }
    }

    private void stopScan() {
        if (!scanning || scanner == null) return;
        scanning = false;
        try { scanner.stopScan(scanCallback); } catch (SecurityException ignored) { }
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            if (result == null || result.getDevice() == null) return;
            boolean serviceMatch = false;
            if (result.getScanRecord() != null && result.getScanRecord().getServiceUuids() != null) {
                for (ParcelUuid p : result.getScanRecord().getServiceUuids()) {
                    if (UUID_AB00.equals(p.getUuid())) { serviceMatch = true; break; }
                }
            }
            String name = null;
            try { name = result.getDevice().getName(); } catch (SecurityException ignored) { }
            boolean nameMatch = name != null && name.toUpperCase(Locale.US).contains("DSP");
            if (!serviceMatch && !nameMatch) return;
            stopScan();
            dspView.setConnectionState("Connecting", false);
            try {
                gatt = result.getDevice().connectGatt(MainActivity.this, false, gattCallback, BluetoothDeviceTransport.TRANSPORT_LE);
            } catch (Throwable first) {
                try {
                    gatt = result.getDevice().connectGatt(MainActivity.this, false, gattCallback);
                } catch (SecurityException denied) {
                    dspView.setConnectionState("Permission", false);
                }
            }
        }
    };

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
            if (newState == BluetoothProfile.STATE_CONNECTED && status == BluetoothGatt.GATT_SUCCESS) {
                runOnUiThread(() -> dspView.setConnectionState("Discovering", false));
                try { g.discoverServices(); } catch (SecurityException ignored) { }
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                runOnUiThread(() -> {
                    if (gatt == g) {
                        gatt = null;
                        writeChar = null;
                        writeInFlight = false;
                        latestPendingWrite = null;
                    }
                    dspView.setConnectionState("Disconnected", false);
                });
                try { g.close(); } catch (Throwable ignored) { }
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt g, int status) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                runOnUiThread(() -> dspView.setConnectionState("Service Error", false));
                return;
            }
            BluetoothGattService s = g.getService(UUID_AB00);
            if (s == null) {
                runOnUiThread(() -> dspView.setConnectionState("AB00 Missing", false));
                return;
            }
            writeChar = s.getCharacteristic(UUID_AB01);
            BluetoothGattCharacteristic n2 = s.getCharacteristic(UUID_AB02);
            BluetoothGattCharacteristic n3 = s.getCharacteristic(UUID_AB03);
            enableNotify(g, n2);
            enableNotify(g, n3);
            runOnUiThread(() -> dspView.setConnectionState(writeChar != null ? "Connected" : "AB01 Missing", writeChar != null));
        }

        @Override
        public void onCharacteristicWrite(BluetoothGatt g, BluetoothGattCharacteristic characteristic, int status) {
            if (characteristic == null || !UUID_AB01.equals(characteristic.getUuid())) return;
            main.post(() -> {
                writeInFlight = false;
                if (writeTimeout != null) main.removeCallbacks(writeTimeout);
                writeTimeout = null;
                if (status == BluetoothGatt.GATT_SUCCESS) pumpWriteQueue();
                else {
                    latestPendingWrite = null;
                    dspView.setConnectionState("Write Error", false);
                }
            });
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic characteristic, byte[] value) {
            if (characteristic != null && value != null) {
                runOnUiThread(() -> dspView.onBleNotify(characteristic.getUuid(), value));
            }
        }

        @Override
        @SuppressWarnings("deprecation")
        public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic characteristic) {
            byte[] v = characteristic == null ? null : characteristic.getValue();
            if (characteristic != null && v != null) {
                runOnUiThread(() -> dspView.onBleNotify(characteristic.getUuid(), v));
            }
        }
    };

    private void enableNotify(BluetoothGatt g, BluetoothGattCharacteristic c) {
        if (g == null || c == null) return;
        try {
            g.setCharacteristicNotification(c, true);
            BluetoothGattDescriptor d = c.getDescriptor(UUID_CCCD);
            if (d != null) {
                if (Build.VERSION.SDK_INT >= 33) g.writeDescriptor(d, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                else {
                    //noinspection deprecation
                    d.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                    //noinspection deprecation
                    g.writeDescriptor(d);
                }
            }
        } catch (SecurityException ignored) { }
    }

    /**
     * Transport primitive reserved for packets whose exact byte layout has been verified.
     * It intentionally is not called by UI controls until the authenticated DSP protocol encoder is confirmed.
     */
    public void enqueueVerifiedWrite(byte[] packet) {
        if (packet == null || packet.length == 0) return;
        latestPendingWrite = packet.clone();
        pumpWriteQueue();
    }

    private void pumpWriteQueue() {
        if (writeInFlight || latestPendingWrite == null || gatt == null || writeChar == null) return;
        long now = android.os.SystemClock.elapsedRealtime();
        long wait = Math.max(0, 38 - (now - lastWriteMs));
        if (wait > 0) {
            main.postDelayed(this::pumpWriteQueue, wait);
            return;
        }
        byte[] p = latestPendingWrite;
        latestPendingWrite = null;
        boolean started = false;
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                int r = gatt.writeCharacteristic(writeChar, p, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
                started = (r == 0);
            } else {
                //noinspection deprecation
                writeChar.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
                //noinspection deprecation
                writeChar.setValue(p);
                //noinspection deprecation
                started = gatt.writeCharacteristic(writeChar);
            }
        } catch (SecurityException ignored) { }
        if (!started) {
            dspView.setConnectionState("Write Blocked", false);
            return;
        }
        lastWriteMs = android.os.SystemClock.elapsedRealtime();
        writeInFlight = true;
        writeTimeout = () -> {
            if (writeInFlight) {
                writeInFlight = false;
                latestPendingWrite = null;
                dspView.setConnectionState("Write Timeout", false);
            }
        };
        main.postDelayed(writeTimeout, 2500);
    }

    private void disconnectGatt() {
        stopScan();
        BluetoothGatt g = gatt;
        gatt = null;
        writeChar = null;
        writeInFlight = false;
        latestPendingWrite = null;
        if (writeTimeout != null) main.removeCallbacks(writeTimeout);
        writeTimeout = null;
        if (g != null) {
            try { g.disconnect(); } catch (SecurityException ignored) { }
            try { g.close(); } catch (Throwable ignored) { }
        }
        dspView.setConnectionState("Disconnected", false);
    }

    @Override
    protected void onDestroy() {
        disconnectGatt();
        super.onDestroy();
    }

    private static UUID uuid16(int shortUuid) {
        return UUID.fromString(String.format(Locale.US, "0000%04x-0000-1000-8000-00805f9b34fb", shortUuid & 0xffff));
    }

    /** Keeps source compatible with older SDK method overload resolution. */
    private static final class BluetoothDeviceTransport {
        static final int TRANSPORT_LE = 2;
    }
}
