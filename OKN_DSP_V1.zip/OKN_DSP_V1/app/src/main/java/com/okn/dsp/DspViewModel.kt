package com.okn.dsp

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import org.json.JSONArray
import org.json.JSONObject

class DspViewModel(application: Application) : AndroidViewModel(application) {
    var state by mutableStateOf(DspUiState())
        private set

    private val prefs = application.getSharedPreferences("okn_dsp_presets", 0)

    fun setScreen(screen: DspScreen) { state = state.copy(currentScreen = screen) }
    fun selectChannel(index: Int) { state = state.copy(selectedChannel = index.coerceIn(0, 6)) }
    fun setMasterVolume(v: Float) { state = state.copy(masterVolumeDb = v) }
    fun setBassVolume(v: Float) { state = state.copy(bassVolumeDb = v) }
    fun setBassCutoff(v: Float) { state = state.copy(bassCutoffHz = v) }
    fun setBassBoost(v: Float) { state = state.copy(bassBoostDb = v) }
    fun setMiddleBoost(v: Float) { state = state.copy(middleBoostDb = v) }
    fun setTrebleBoost(v: Float) { state = state.copy(trebleBoostDb = v) }
    fun setAudioSource(v: String) { state = state.copy(audioSource = v) }
    fun setSystemPreset(v: String) { state = state.copy(systemPreset = v) }
    fun setPresetName(v: String) { state = state.copy(presetName = v) }
    fun setEqPage(v: Int) { state = state.copy(eqPage = v.coerceIn(0, 2)) }

    fun updateEqBand(index: Int, transform: (EqBand) -> EqBand) {
        if (index !in state.eqBands.indices) return
        state = state.copy(eqBands = state.eqBands.mapIndexed { i, b -> if (i == index) transform(b) else b })
    }

    fun resetEq() { state = state.copy(eqBands = defaultEqBands()) }
    fun setHpf(v: FilterState) { state = state.copy(hpf = v) }
    fun setLpf(v: FilterState) { state = state.copy(lpf = v) }
    fun setCrossoverView(v: String) { state = state.copy(crossoverView = v) }
    fun setPhase(v: Int) { state = state.copy(phaseDegrees = v) }
    fun setPolarity(v: String) { state = state.copy(polarity = v) }
    fun setLinkLR(v: Boolean) { state = state.copy(linkLR = v) }
    fun setOutputMode(v: String) { state = state.copy(outputMode = v) }
    fun resetCrossover() { state = state.copy(hpf = FilterState(frequencyHz = 100f), lpf = FilterState(frequencyHz = 1000f)) }
    fun setDelayUnit(v: String) { state = state.copy(delayUnit = v) }
    fun setSeatPreset(v: String) { state = state.copy(seatPreset = v) }

    fun setDelay(index: Int, ms: Float) {
        updateChannel(index) { it.copy(delayMs = ms.coerceIn(0f, 10f)) }
    }

    fun syncDelays() {
        val selected = state.channels[state.selectedChannel].delayMs
        state = state.copy(channels = state.channels.map { it.copy(delayMs = selected) })
    }

    fun setMasterOutput(v: Float) { state = state.copy(masterOutputDb = v) }
    fun setOutput(index: Int, db: Float) { updateChannel(index) { it.copy(outputDb = db) } }
    fun toggleMute(index: Int) { updateChannel(index) { it.copy(muted = !it.muted) } }
    fun toggleSolo(index: Int) { updateChannel(index) { it.copy(solo = !it.solo) } }
    fun togglePhase(index: Int) { updateChannel(index) { it.copy(phaseInverted = !it.phaseInverted) } }
    fun toggleLink(index: Int) { updateChannel(index) { it.copy(linked = !it.linked) } }
    fun allMuteOff() { state = state.copy(channels = state.channels.map { it.copy(muted = false) }) }
    fun resetLevels() { state = state.copy(masterOutputDb = -1f, channels = defaultChannels()) }

    private fun updateChannel(index: Int, transform: (ChannelState) -> ChannelState) {
        if (index !in state.channels.indices) return
        val updated = state.channels.mapIndexed { i, c -> if (i == index) transform(c) else c }
        val source = updated[index]
        val linked = source.linked
        val finalChannels = if (linked && index in 0..1) {
            val peer = if (index == 0) 1 else 0
            updated.mapIndexed { i, c ->
                if (i == peer && c.linked) c.copy(outputDb = source.outputDb, delayMs = source.delayMs) else c
            }
        } else updated
        state = state.copy(channels = finalChannels)
    }

    fun savePreset(): Boolean = runCatching {
        prefs.edit().putString("preset_${state.presetName}", encodeState(state).toString()).apply()
        true
    }.getOrDefault(false)

    fun loadPreset(name: String): Boolean = runCatching {
        val raw = prefs.getString("preset_$name", null) ?: return false
        state = decodeState(JSONObject(raw)).copy(currentScreen = state.currentScreen, presetName = name)
        true
    }.getOrDefault(false)

    fun savedPresetNames(): List<String> = prefs.all.keys
        .filter { it.startsWith("preset_") }
        .map { it.removePrefix("preset_") }
        .sorted()

    fun deletePreset(name: String) { prefs.edit().remove("preset_$name").apply() }

    private fun encodeState(s: DspUiState): JSONObject = JSONObject().apply {
        put("masterVolumeDb", s.masterVolumeDb)
        put("bassVolumeDb", s.bassVolumeDb)
        put("bassCutoffHz", s.bassCutoffHz)
        put("bassBoostDb", s.bassBoostDb)
        put("middleBoostDb", s.middleBoostDb)
        put("trebleBoostDb", s.trebleBoostDb)
        put("audioSource", s.audioSource)
        put("systemPreset", s.systemPreset)
        put("masterOutputDb", s.masterOutputDb)
        put("hpfFrequency", s.hpf.frequencyHz)
        put("hpfSlope", s.hpf.slopeDbOct)
        put("hpfType", s.hpf.type)
        put("hpfBypass", s.hpf.bypass)
        put("lpfFrequency", s.lpf.frequencyHz)
        put("lpfSlope", s.lpf.slopeDbOct)
        put("lpfType", s.lpf.type)
        put("lpfBypass", s.lpf.bypass)
        put("eq", JSONArray().apply {
            s.eqBands.forEach { b -> put(JSONObject().apply {
                put("type", b.type); put("frequencyHz", b.frequencyHz); put("gainDb", b.gainDb); put("q", b.q); put("enabled", b.enabled)
            }) }
        })
        put("channels", JSONArray().apply {
            s.channels.forEach { c -> put(JSONObject().apply {
                put("id", c.id); put("name", c.name); put("shortName", c.shortName); put("delayMs", c.delayMs); put("outputDb", c.outputDb)
                put("muted", c.muted); put("solo", c.solo); put("phase", c.phaseInverted); put("linked", c.linked)
            }) }
        })
    }

    private fun decodeState(j: JSONObject): DspUiState {
        val base = DspUiState()
        val eqArray = j.optJSONArray("eq")
        val eq = if (eqArray != null) (0 until eqArray.length()).map { i ->
            val b = eqArray.getJSONObject(i)
            EqBand(b.optString("type", "PEQ"), b.optDouble("frequencyHz", 1000.0).toFloat(), b.optDouble("gainDb", 0.0).toFloat(), b.optDouble("q", 1.0).toFloat(), b.optBoolean("enabled", true))
        } else base.eqBands
        val chArray = j.optJSONArray("channels")
        val channels = if (chArray != null) (0 until chArray.length()).map { i ->
            val c = chArray.getJSONObject(i)
            ChannelState(c.optInt("id", i + 1), c.optString("name", "CH${i + 1}"), c.optString("shortName", "CH${i + 1}"), c.optDouble("delayMs", 0.0).toFloat(), c.optDouble("outputDb", -3.0).toFloat(), c.optBoolean("muted"), c.optBoolean("solo"), c.optBoolean("phase"), c.optBoolean("linked"))
        } else base.channels
        return base.copy(
            masterVolumeDb = j.optDouble("masterVolumeDb", -3.0).toFloat(),
            bassVolumeDb = j.optDouble("bassVolumeDb", 4.0).toFloat(),
            bassCutoffHz = j.optDouble("bassCutoffHz", 100.0).toFloat(),
            bassBoostDb = j.optDouble("bassBoostDb", 3.0).toFloat(),
            middleBoostDb = j.optDouble("middleBoostDb", -2.0).toFloat(),
            trebleBoostDb = j.optDouble("trebleBoostDb", 1.0).toFloat(),
            audioSource = j.optString("audioSource", base.audioSource),
            systemPreset = j.optString("systemPreset", base.systemPreset),
            masterOutputDb = j.optDouble("masterOutputDb", -1.0).toFloat(),
            eqBands = eq,
            hpf = FilterState(j.optString("hpfType", "Linkwitz-Riley"), j.optDouble("hpfFrequency", 100.0).toFloat(), j.optInt("hpfSlope", 24), j.optBoolean("hpfBypass")),
            lpf = FilterState(j.optString("lpfType", "Linkwitz-Riley"), j.optDouble("lpfFrequency", 1000.0).toFloat(), j.optInt("lpfSlope", 24), j.optBoolean("lpfBypass")),
            channels = channels
        )
    }
}
