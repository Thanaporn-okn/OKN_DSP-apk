package com.okn.dsp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;

import java.util.Arrays;
import java.util.Locale;
import java.util.UUID;

public class DspControlView extends View {
    private static final float W = 864f;
    private static final float H = 1536f;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF r = new RectF();
    private final Typeface regular = Typeface.create("sans-serif", Typeface.NORMAL);
    private final Typeface medium = Typeface.create("sans-serif-medium", Typeface.NORMAL);
    private final Typeface bold = Typeface.create("sans-serif", Typeface.BOLD);

    private final int BG = Color.rgb(0, 12, 24);
    private final int PANEL = Color.rgb(2, 28, 50);
    private final int PANEL2 = Color.rgb(1, 22, 41);
    private final int LINE = Color.rgb(14, 82, 126);
    private final int TEXT = Color.rgb(242, 247, 255);
    private final int SUB = Color.rgb(139, 190, 231);
    private final int CYAN = Color.rgb(0, 220, 255);
    private final int BLUE = Color.rgb(0, 132, 255);
    private final int MAGENTA = Color.rgb(244, 45, 255);
    private final int ORANGE = Color.rgb(255, 148, 32);
    private final int GREEN = Color.rgb(0, 238, 120);
    private final int RED = Color.rgb(255, 49, 93);
    private final int YELLOW = Color.rgb(255, 227, 40);
    private final int PURPLE = Color.rgb(184, 50, 255);
    private final int WHITE = Color.WHITE;

    private Runnable bleAction;
    private String connectionText = "Disconnected";
    private boolean connected;
    private int page = 0;
    private int channel = 0;
    private boolean settingsOpen;

    // Home
    private float master = -3f, bass = 4f, cutoff = 100f, bassBoost = 3f, midBoost = -2f, trebleBoost = 1f;
    private int audioSource = 0, systemPreset = 0;

    // EQ
    private int eqBandPage = 0;
    private final float[] eqFreq = new float[15];
    private final float[] eqGain = new float[15];
    private final float[] eqQ = new float[15];
    private final boolean[] eqPower = new boolean[15];
    private final int[] eqType = new int[15];

    // Crossover
    private boolean hpfBypass, lpfBypass, lrLink = true;
    private int hpfType = 0, lpfType = 0, hpfSlope = 2, lpfSlope = 2;
    private float hpfFreq = 100f, lpfFreq = 1000f;
    private int phase = 0, polarity = 0, outputMode = 0;

    // Delay
    private boolean delayCm;
    private int seatPreset;
    private final float[] delayMs = {0f, 1.25f, 2.60f, 2.30f, 0.80f, 3.10f, 1.90f};

    // Output
    private float masterOutput = -1f;
    private final float[] outDb = {-3f, -2.5f, -4f, -1f, -2f, -3.5f, -4.5f};
    private final boolean[] mute = new boolean[7];
    private final boolean[] solo = new boolean[7];
    private final boolean[] phaseInvert = new boolean[7];
    private final boolean[] link = {true, true, false, false, false, false, false};

    private int dragKind = 0; // 1 home, 2 delay, 3 output, 4 master output
    private int dragIndex = -1;
    private long lastNotifyAt;
    private String lastNotify = "";

    private static final String[] CH_NAME = {"Front L","Front R","Rear L","Rear R","Center","Sub L","Sub R"};
    private static final int[] CH_COLOR = {
            Color.rgb(35, 195, 255), Color.rgb(255, 151, 35), Color.rgb(0, 229, 100),
            Color.rgb(255, 79, 195), Color.rgb(235, 239, 245), Color.rgb(182, 56, 255), Color.rgb(0, 218, 239)
    };

    public DspControlView(Context context) {
        super(context);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        setBackgroundColor(BG);
        initEq();
    }

    private void initEq() {
        float[] f = {32,100,200,500,2000,10000,63,125,250,1000,4000,8000,50,1600,12500};
        float[] g = {-3,2.5f,6,-4,3,-2,0,0,0,0,0,0,0,0,0};
        for (int i=0;i<15;i++) {
            eqFreq[i] = f[i]; eqGain[i] = g[i]; eqQ[i] = i==2?1.2f:(i==0||i==5?0.7f:1.0f); eqPower[i] = true;
            eqType[i] = i==1?1:(i==5?2:0);
        }
    }

    public void setBleAction(Runnable action) { this.bleAction = action; }

    public void setConnectionState(String text, boolean connected) {
        this.connectionText = text == null ? "Disconnected" : text;
        this.connected = connected;
        invalidate();
    }

    public void onBleNotify(UUID uuid, byte[] value) {
        lastNotifyAt = SystemClock.elapsedRealtime();
        StringBuilder sb = new StringBuilder();
        int n = Math.min(value.length, 8);
        for (int i=0;i<n;i++) sb.append(String.format(Locale.US, "%02X", value[i] & 0xff));
        lastNotify = sb.toString();
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        float sx = getWidth()/W, sy = getHeight()/H;
        c.save();
        c.scale(sx, sy);
        drawBackground(c);
        drawHeader(c);
        if (page == 0) drawHome(c);
        else {
            drawChannelTabs(c);
            if (page == 1) drawEq(c);
            else if (page == 2) drawCrossover(c);
            else if (page == 3) drawDelay(c);
            else drawOutput(c);
        }
        drawBottomNav(c);
        if (settingsOpen) drawSettingsOverlay(c);
        c.restore();
    }

    private void drawBackground(Canvas c) {
        p.setShader(new LinearGradient(0,0,0,H, Color.rgb(0,20,38), BG, Shader.TileMode.CLAMP));
        c.drawRect(0,0,W,H,p); p.setShader(null);
        p.setColor(Color.argb(60,0,130,255)); p.setStrokeWidth(1);
        for(int i=0;i<9;i++) c.drawLine(0, 120+i*170, W, 90+i*170,p);
    }

    private void drawHeader(Canvas c) {
        drawLogo(c, 56, 52, CYAN);
        if (page == 0) {
            text(c,"OKN_DSP", 137, 61, 45, TEXT, bold);
            text(c,"Professional Audio Processor", 137, 91, 21, SUB, regular);
        } else {
            text(c,"DSP Control", 115, 57, 41, TEXT, regular);
            text(c,"Professional Audio Processor", 115, 82, 20, SUB, regular);
        }
        roundRect(c, 520, 18, 763, 86, 14, PANEL2, LINE, 1.5f);
        glowDot(c, 550, 52, connected ? GREEN : Color.rgb(67,95,117), 10);
        text(c, connectionText, 575, 46, 18, connected?GREEN:SUB, medium);
        text(c,"DSP-7900", 575, 69, 17, SUB, regular);
        text(c,"›", 727, 62, 46, Color.rgb(183,220,255), regular);
        gear(c, 809, 53, 21, Color.rgb(190,226,255));
    }

    private void drawChannelTabs(Canvas c) {
        float x=18, y=105, gap=7, bw=112, bh=76;
        for(int i=0;i<7;i++) {
            float xx=x+i*(bw+gap);
            if(i==channel) {
                p.setShader(new LinearGradient(xx,y,xx,y+bh,BLUE,CYAN,Shader.TileMode.CLAMP));
                roundRectRaw(c,xx,y,xx+bw,y+bh,10,p);
                p.setShader(null);
                glowBorder(c,xx,y,xx+bw,y+bh,10,CYAN,8);
            } else roundRect(c,xx,y,xx+bw,y+bh,10,PANEL2,LINE,1);
            textCenter(c,"CH"+(i+1),xx+bw/2,y+31,21,TEXT,medium);
            textCenter(c,CH_NAME[i],xx+bw/2,y+58,18,TEXT,regular);
        }
    }

    private void drawHome(Canvas c) {
        homeSliderCard(c, 15,125,849,260, CYAN, "Master Volume","ปรับระดับเสียงรวม", master,-60,12,"dB",0);
        homeSliderCard(c, 15,273,849,408, CYAN, "Bass Volume","ปรับระดับเสียงเบส", bass,-12,12,"dB",1);
        homeSliderCard(c, 15,421,849,556, MAGENTA, "Bass Cutoff","ตั้งค่าความถี่ตัดเบส", cutoff,20,500,"Hz",2);
        homeSliderCard(c, 15,569,849,704, RED, "Bass Boost","เพิ่มความหนักแน่นของเบส", bassBoost,-10,12,"dB",3);
        homeSliderCard(c, 15,717,849,852, BLUE, "Middle Boost","เพิ่มความชัดเจนย่านกลาง", midBoost,-12,12,"dB",4);
        homeSliderCard(c, 15,865,849,1000, MAGENTA, "Treble Boost","เพิ่มความใสย่านแหลม", trebleBoost,-12,12,"dB",5);

        roundRect(c,15,1022,427,1180,16,PANEL,LINE,1.5f);
        iconTile(c,38,1042,116,1118, BLUE); musicIcon(c,77,1080,Color.rgb(171,232,255));
        text(c,"Audio Source",140,1068,24,TEXT,medium); text(c,"แหล่งสัญญาณเสียง",140,1100,18,SUB,regular);
        roundRect(c,140,1116,408,1166,9,PANEL2,Color.rgb(49,100,146),1);
        text(c,audioSource==0?"High Level (Speaker)":"Bluetooth / AUX",154,1149,18,TEXT,regular); text(c,"⌄",377,1149,24,SUB,regular);

        roundRect(c,15,1193,427,1360,16,PANEL,LINE,1.5f);
        iconTile(c,38,1215,116,1291, BLUE); menuIcon(c,77,1253,Color.rgb(145,226,255));
        text(c,"System Preset",140,1242,24,TEXT,medium); text(c,"พรีเซ็ตระบบ",140,1274,18,SUB,regular);
        roundRect(c,140,1290,408,1340,9,PANEL2,Color.rgb(49,100,146),1);
        String[] prs={"Flat","Sound Quality","Bass","Vocal"}; text(c,prs[systemPreset],154,1323,18,TEXT,regular); text(c,"⌄",377,1323,24,SUB,regular);

        roundRect(c,440,1022,849,1360,16,PANEL,LINE,1.5f);
        iconTile(c,466,1044,542,1120, BLUE); chipIcon(c,504,1082,Color.rgb(167,225,255));
        text(c,"Device Status",566,1068,24,TEXT,medium); text(c,"สถานะอุปกรณ์",566,1102,18,SUB,regular);
        p.setColor(Color.rgb(17,57,82)); c.drawRect(466,1127,826,1129,p);
        glowDot(c,480,1160,connected?GREEN:Color.rgb(67,95,117),9); text(c,connected?"Connected":"Disconnected",518,1167,18,TEXT,regular); text(c,"DSP-7900",765,1167,17,SUB,regular);
        battery(c,480,1212,GREEN); text(c,"Voltage",518,1218,18,SUB,regular); text(c,"13.6 V",765,1218,17,SUB,regular);
        thermometer(c,480,1264,CYAN); text(c,"Temperature",518,1270,18,SUB,regular); text(c,"42 °C",765,1270,17,SUB,regular);
        circleCheck(c,480,1315,CYAN); text(c,"System",518,1322,18,SUB,regular); text(c,connected?"Normal":"Standby",754,1322,17,connected?GREEN:SUB,regular);
        if (!lastNotify.isEmpty() && SystemClock.elapsedRealtime()-lastNotifyAt < 10000) text(c,"RX "+lastNotify,566,1345,12,SUB,regular);
    }

    private void homeSliderCard(Canvas c,float l,float t,float rr,float b,int color,String title,String th,float value,float min,float max,String unit,int idx) {
        roundRect(c,l,t,rr,b,18,PANEL,LINE,1.2f);
        glowCircle(c,84,t+67,45,color); drawHomeIcon(c,84,t+67,idx,color);
        text(c,title,166,t+57,27,TEXT,medium); text(c,th,166,t+94,18,SUB,regular);
        float sl=381,sr=667,sy=t+58;
        p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeWidth(15); p.setColor(Color.rgb(32,77,118)); c.drawLine(sl,sy,sr,sy,p);
        float norm = idx==2 ? logNorm(value,min,max) : clamp((value-min)/(max-min),0,1);
        p.setShader(new LinearGradient(sl,sy,sr,sy,color,CYAN,Shader.TileMode.CLAMP)); c.drawLine(sl,sy,sl+(sr-sl)*norm,sy,p); p.setShader(null);
        glowDot(c,sl+(sr-sl)*norm,sy,WHITE,19);
        drawTicks(c,sl,sr,t+81,idx==0?6:5,idx==0?new String[]{"-60","-40","-20","0","+12"}:idx==2?new String[]{"20","50","100","200","500"}:new String[]{idx==3?"-10":"-12","-6","0","+6","+12"});
        roundRect(c,698,t+27,824,t+90,11,PANEL2,Color.rgb(57,105,151),1.3f);
        String val = idx==2 ? String.format(Locale.US,"%.0f Hz",value) : String.format(Locale.US,"%.1f dB",value);
        textCenter(c,val,761,t+68,22,TEXT,medium);
    }

    private void drawEq(Canvas c) {
        roundRect(c,16,196,848,635,17,PANEL,LINE,1.4f);
        drawLogo(c,75,254,CYAN); text(c,"Parametric EQ",134,258,29,TEXT,bold); text(c,"ปรับแต่งความถี่เสียงอย่างละเอียด",134,292,20,SUB,regular);
        roundRect(c,485,218,666,291,10,PANEL2,Color.rgb(52,106,152),1); text(c,"ช่องสัญญาณ",507,246,16,TEXT,regular); text(c,"CH"+(channel+1)+" - "+CH_NAME[channel],507,276,18,TEXT,regular); text(c,"⌄",635,271,24,SUB,regular);
        roundRect(c,676,218,833,291,10,PANEL2,Color.rgb(52,106,152),1); resetIcon(c,713,254,SUB); text(c,"รีเซ็ต EQ",746,262,17,TEXT,regular);
        drawEqGraph(c,75,315,827,585);
        tabButton(c,18,651,239,708,"Bands 1 - 6",eqBandPage==0); tabButton(c,246,651,448,708,"Bands 7 - 12",eqBandPage==1); tabButton(c,455,651,655,708,"Bands 13 - 15",eqBandPage==2);
        drawEqTable(c);
        roundRect(c,16,1193,848,1360,16,PANEL,LINE,1.3f);
        folderIcon(c,80,1256,Color.rgb(130,211,255)); text(c,"Preset",142,1242,23,TEXT,medium); text(c,"ชุดค่าที่ใช้งานอยู่",142,1274,17,SUB,regular);
        roundRect(c,141,1282,327,1338,9,PANEL2,Color.rgb(50,99,145),1); text(c,"Custom 1",156,1318,17,TEXT,regular); text(c,"⌄",294,1316,24,SUB,regular);
        iconButton(c,340,1223,473,1340,"▣","Save"); iconButton(c,487,1223,638,1340,"□","Manage");
        text(c,"B E T T E R   S O U N D",690,1305,11,SUB,regular); text(c,"A   B R I G H T E R   D R I V E",664,1333,10,SUB,regular);
    }

    private void drawEqGraph(Canvas c,float l,float t,float rr,float b) {
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1); p.setColor(Color.rgb(13,55,82));
        for(int i=0;i<=10;i++){float x=l+(rr-l)*i/10f;c.drawLine(x,t,x,b,p);} for(int j=0;j<=6;j++){float y=t+(b-t)*j/6f;c.drawLine(l,y,rr,y,p);} p.setStyle(Paint.Style.FILL);
        text(c,"dB",31,t+17,16,SUB,regular); String[] yv={"+12","+6","0","-6","-12"}; for(int i=0;i<5;i++) text(c,yv[i],28,t+52+i*54,15,TEXT,regular);
        String[] xv={"20","50","100","200","500","1k","2k","5k","10k","20k","Hz"}; for(int i=0;i<xv.length;i++) textCenter(c,xv[i],l+(rr-l)*i/(xv.length-1),b+31,15,TEXT,regular);
        float[] ptsX={0.09f,0.22f,0.34f,0.48f,0.61f,0.74f,0.88f,1.0f}; float[] ptsY={0.65f,0.46f,0.21f,0.66f,0.50f,0.35f,0.64f,0.48f}; int[] cols={RED,ORANGE,YELLOW,GREEN,CYAN,BLUE,PURPLE,Color.rgb(255,73,168)};
        path.reset();
        for(int i=0;i<ptsX.length;i++){float x=l+(rr-l)*ptsX[i], y=t+(b-t)*ptsY[i]; if(i==0) path.moveTo(l,t+(b-t)*0.70f); path.quadTo(x-20,y,x,y);}
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(4); p.setShader(new LinearGradient(l,t,rr,b,cols,null,Shader.TileMode.CLAMP)); c.drawPath(path,p); p.setShader(null); p.setStyle(Paint.Style.FILL);
        for(int i=0;i<ptsX.length;i++){float x=l+(rr-l)*ptsX[i],y=t+(b-t)*ptsY[i];glowDot(c,x,y,cols[i],9);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);p.setColor(WHITE);c.drawCircle(x,y,9,p);p.setStyle(Paint.Style.FILL);}
    }

    private void drawEqTable(Canvas c) {
        float top=711; roundRect(c,16,top,848,1178,16,PANEL,LINE,1.2f);
        text(c,"#",44,760,17,TEXT,regular); text(c,"Type",112,760,17,TEXT,regular); text(c,"Frequency",311,760,17,TEXT,regular); text(c,"Gain",486,760,17,TEXT,regular); text(c,"Q",656,760,17,TEXT,regular); text(c,"Power",761,760,17,TEXT,regular);
        int start=eqBandPage==0?0:(eqBandPage==1?6:12); int count=eqBandPage==2?3:6; float rowY=785, rowH=62;
        for(int row=0;row<count;row++) {
            int i=start+row; float y=rowY+row*rowH;
            p.setColor(Color.rgb(14,59,84)); c.drawRect(31,y+rowH-1,826,y+rowH,p);
            glowDot(c,47,y+22,bandColor(i),10); text(c,String.valueOf(i+1),72,y+30,18,TEXT,regular);
            roundRect(c,102,y,276,y+47,7,PANEL2,Color.rgb(47,99,144),1); text(c,typeName(eqType[i]),152,y+31,16,TEXT,regular); text(c,"⌄",242,y+29,22,SUB,regular);
            stepBox(c,291,y,422,y+47,formatFreq(eqFreq[i])); stepBox(c,438,y,574,y+47,String.format(Locale.US,"%.1f dB",eqGain[i])); stepBox(c,593,y,736,y+47,String.format(Locale.US,"%.2f",eqQ[i]));
            toggle(c,758,y+4,828,y+43,eqPower[i],CYAN);
        }
    }

    private void drawCrossover(Canvas c) {
        roundRect(c,17,197,848,667,17,PANEL,LINE,1.3f);
        glowCircle(c,88,260,47,MAGENTA); crossoverIcon(c,88,260,MAGENTA); text(c,"Crossover",171,262,31,TEXT,bold); text(c,"ตั้งค่าการแบ่งความถี่",171,299,20,SUB,regular);
        roundRect(c,493,234,664,290,9,PANEL2,Color.rgb(50,99,145),1); text(c,"Magnitude",510,270,18,TEXT,regular); text(c,"⌄",632,268,23,SUB,regular);
        roundRect(c,680,234,828,290,9,PANEL2,Color.rgb(50,99,145),1); resetIcon(c,716,262,SUB); text(c,"Reset",751,269,17,TEXT,regular);
        roundRect(c,28,332,837,655,12,Color.rgb(1,20,35),Color.rgb(22,71,104),1); drawCrossoverGraph(c,82,371,819,613);
        filterCard(c,18,682,848,915,CYAN,true); filterCard(c,18,929,848,1160,MAGENTA,false);
        roundRect(c,18,1175,848,1380,16,PANEL,LINE,1.2f); gear(c,71,1216,18,Color.rgb(146,224,255)); text(c,"Advanced Settings",121,1214,20,TEXT,medium); text(c,"ตั้งค่าขั้นสูง",121,1242,16,SUB,regular);
        smallSelector(c,39,1254,240,1362,"Phase",phase+"°"); smallSelector(c,252,1254,444,1362,"Polarity",polarity==0?"Normal":"Invert");
        roundRect(c,456,1254,599,1362,10,PANEL2,Color.rgb(45,95,139),1); text(c,"↔  Link L/R",475,1290,16,TEXT,regular); toggle(c,504,1310,566,1348,lrLink,CYAN);
        smallSelector(c,612,1254,829,1362,"Output Mode",outputMode==0?"Stereo":"Mono");
    }

    private void drawCrossoverGraph(Canvas c,float l,float t,float rr,float b) {
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1);p.setColor(Color.rgb(11,55,82));for(int i=0;i<=11;i++){float x=l+(rr-l)*i/11f;c.drawLine(x,t,x,b,p);}for(int j=0;j<=5;j++){float y=t+(b-t)*j/5f;c.drawLine(l,y,rr,y,p);}p.setStyle(Paint.Style.FILL);
        String[] yv={"+12","+6","0","-6","-12","-24"};for(int i=0;i<yv.length;i++)text(c,yv[i],39,t+8+i*(b-t)/5f,15,TEXT,regular); String[] xv={"20","50","100","200","500","1k","2k","5k","10k","20k","Hz"};for(int i=0;i<xv.length;i++)textCenter(c,xv[i],l+(rr-l)*i/(xv.length-1),b+29,15,TEXT,regular);
        float hpX=l+(rr-l)*logNorm(hpfFreq,20,20000), lpX=l+(rr-l)*logNorm(lpfFreq,20,20000), y=t+85;
        path.reset();path.moveTo(l,b+20);path.cubicTo(hpX-130,b-30,hpX-65,y,hpX,y);path.lineTo(rr,y);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(5);p.setColor(CYAN);c.drawPath(path,p);
        path.reset();path.moveTo(l,y);path.lineTo(lpX,y);path.cubicTo(lpX+60,y,lpX+110,b-30,rr,b+20);p.setColor(MAGENTA);c.drawPath(path,p);p.setStyle(Paint.Style.FILL);glowDot(c,hpX,y,CYAN,10);glowDot(c,lpX,y,MAGENTA,10);
        text(c,"●  High Pass (HPF)",548,357,15,CYAN,regular);text(c,"●  Low Pass (LPF)",692,357,15,MAGENTA,regular);
    }

    private void filterCard(Canvas c,float l,float t,float rr,float b,int color,boolean high) {
        roundRect(c,l,t,rr,b,16,PANEL,LINE,1.2f); glowCircle(c,86,t+64,45,color); if(high) hpfIcon(c,86,t+64,color); else lpfIcon(c,86,t+64,color);
        text(c,high?"High Pass Filter (HPF)":"Low Pass Filter (LPF)",165,t+52,27,TEXT,medium); text(c,high?"กรองความถี่ต่ำออก":"กรองความถี่สูงออก",165,t+86,18,SUB,regular); text(c,"Bypass",667,t+63,18,TEXT,regular); toggle(c,748,t+34,823,t+75,high?hpfBypass:lpfBypass,BLUE);
        float y=t+111; selectorBox(c,39,y,295,y+95,"Type", high?typeFilter(hpfType):typeFilter(lpfType)); selectorBox(c,307,y,560,y+95,"Frequency",formatFreq(high?hpfFreq:lpfFreq)); selectorBox(c,572,y,827,y+95,"Slope",slopeName(high?hpfSlope:lpfSlope));
    }

    private void drawDelay(Canvas c) {
        roundRect(c,18,197,848,730,17,PANEL,LINE,1.3f); glowCircle(c,87,257,45,GREEN); clockIcon(c,87,257,GREEN); text(c,"Delay",154,247,29,TEXT,bold); text(c,"ตั้งค่าหน่วงเวลาเพื่อการจัดตำแหน่งเสียง",154,280,19,SUB,regular);
        roundRect(c,485,218,647,278,10,PANEL2,Color.rgb(52,106,152),1); tabButton(c,488,222,565,275,"ms",!delayCm); textCenter(c,"cm",607,259,18,TEXT,regular); roundRect(c,660,218,830,278,10,PANEL2,Color.rgb(52,106,152),1); resetIcon(c,701,248,SUB); text(c,"ซิงค์ทุกช่อง",741,257,16,TEXT,regular);
        drawCar(c,100,302,446,691);
        delayInfoCard(c,495,302,818,426,"Seat Preset","ตำแหน่งการฟัง",seatPreset==0?"Driver (Left)":seatPreset==1?"Center":"Passenger (Right)",0);
        delayInfoCard(c,495,438,818,575,"Distance Reference","อ้างอิงระยะทางเสียง","Speed of Sound (20°C)\n343 m/s (34.3 cm/ms)",1);
        delayInfoCard(c,495,587,818,714,"Total Delay Range","ช่วงหน่วงเวลาทั้งหมด","0.00 ms                3.10 ms\nน้อยที่สุด              มากที่สุด",2);
        float y=742; for(int i=0;i<7;i++){delayRow(c,i,y+i*88);}
    }

    private void drawCar(Canvas c,float l,float t,float rr,float b) {
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(Color.rgb(0,121,255));r.set(l+70,t+10,rr-45,b-5);c.drawRoundRect(r,110,110,p);p.setStrokeWidth(1);for(int i=0;i<5;i++){r.inset(7,8);p.setColor(Color.argb(70,0,175,255));c.drawRoundRect(r,100,100,p);}p.setStyle(Paint.Style.FILL);
        // seats
        seat(c,210,391); seat(c,310,391); seat(c,210,520); seat(c,310,520);
        float[][] pts={{153,411},{386,411},{147,576},{390,576},{271,351},{272,645}}; for(int i=0;i<6;i++){int color=i==0?CYAN:i==1?ORANGE:i==2?GREEN:i==3?Color.rgb(255,74,192):i==4?Color.LTGRAY:PURPLE; glowDot(c,pts[i][0],pts[i][1],color,14);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(color);c.drawCircle(pts[i][0],pts[i][1],18,p);p.setStyle(Paint.Style.FILL);}
        text(c,"0.00 ms",58,429,17,TEXT,regular);text(c,"1.25 ms",412,429,17,TEXT,regular);text(c,"2.60 ms",58,593,17,TEXT,regular);text(c,"2.30 ms",417,593,17,TEXT,regular);textCenter(c,"0.80 ms",271,321,17,TEXT,regular);textCenter(c,"3.10 ms",272,696,17,TEXT,regular);
    }

    private void delayInfoCard(Canvas c,float l,float t,float rr,float b,String title,String sub,String val,int icon) {
        roundRect(c,l,t,rr,b,12,PANEL2,Color.rgb(31,76,112),1); if(icon==0) chairIcon(c,l+42,t+42,CYAN); else if(icon==1) rulerIcon(c,l+42,t+42,CYAN); else barsIcon(c,l+42,t+42,CYAN);
        text(c,title,l+88,t+35,20,TEXT,medium);text(c,sub,l+88,t+62,16,SUB,regular);
        String[] parts=val.split("\\n"); if(icon==0){roundRect(c,l+88,t+70,rr-16,b-14,7,PANEL,Color.rgb(43,92,135),1);text(c,val,l+104,t+99,16,TEXT,regular);text(c,"⌄",rr-47,t+98,22,SUB,regular);} else {for(int i=0;i<parts.length;i++)text(c,parts[i],l+88,t+92+i*28,15,i==0?SUB:TEXT,regular);}
    }

    private void delayRow(Canvas c,int i,float y) {
        roundRect(c,18,y,848,y+80,13,PANEL,LINE,1); glowDot(c,48,y+36,CH_COLOR[i],14); text(c,"CH"+(i+1),84,y+32,20,TEXT,medium);text(c,CH_NAME[i],84,y+58,15,SUB,regular);
        float sl=200,sr=650,sy=y+35; p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeWidth(12);p.setColor(Color.rgb(40,82,119));c.drawLine(sl,sy,sr,sy,p);float n=clamp(delayMs[i]/10f,0,1);p.setColor(CH_COLOR[i]);c.drawLine(sl,sy,sl+(sr-sl)*n,sy,p);glowDot(c,sl+(sr-sl)*n,sy,WHITE,14);drawTicks(c,sl,sr,y+57,6,new String[]{"0","2","4","6","8","10"});
        roundRect(c,679,y+10,832,y+68,9,PANEL2,Color.rgb(47,98,143),1);textCenter(c,String.format(Locale.US,"%.2f ms",delayMs[i]),756,y+35,17,TEXT,medium);textCenter(c,String.format(Locale.US,"%.1f cm",delayMs[i]*34.3f),756,y+58,15,SUB,regular);
    }

    private void drawOutput(Canvas c) {
        roundRect(c,18,197,848,553,17,PANEL,LINE,1.3f);glowCircle(c,89,264,45,ORANGE);speakerIcon(c,89,264,ORANGE);text(c,"Output",174,267,31,TEXT,bold);text(c,"ปรับระดับเอาต์พุตแต่ละช่อง",174,302,19,SUB,regular);
        roundRect(c,478,234,647,296,10,PANEL2,Color.rgb(50,99,145),1); text(c,"♩",503,272,24,TEXT,regular);text(c,"All Mute Off",539,270,16,TEXT,regular);roundRect(c,659,234,831,296,10,PANEL2,Color.rgb(50,99,145),1);resetIcon(c,697,265,SUB);text(c,"Reset Levels",733,270,16,TEXT,regular);
        roundRect(c,30,336,560,541,11,PANEL2,Color.rgb(32,81,118),1);text(c,"Output Level Overview",49,369,19,TEXT,regular);drawMeters(c,91,390,532,490);
        roundRect(c,570,336,833,541,11,PANEL2,Color.rgb(32,81,118),1);text(c,"Master Output",586,389,18,TEXT,regular);roundRect(c,720,354,815,405,8,PANEL,Color.rgb(48,98,143),1);textCenter(c,String.format(Locale.US,"%.1f dB",masterOutput),768,388,18,TEXT,medium);drawOutputSlider(c,589,447,813,masterOutput,WHITE);
        float y=573;for(int i=0;i<7;i++)outputRow(c,i,y+i*109);
    }

    private void drawMeters(Canvas c,float l,float t,float rr,float b) {
        float bw=27,gap=23;for(int i=0;i<7;i++){float x=l+i*(bw+gap);for(int s=0;s<12;s++){float yy=b-s*8;p.setColor(s<8?CH_COLOR[i]:Color.rgb(18,47,67));c.drawRect(x,yy,x+bw,yy+5,p);}textCenter(c,"CH"+(i+1),x+bw/2,b+25,14,TEXT,regular);textCenter(c,CH_NAME[i],x+bw/2,b+47,12,SUB,regular);}text(c,"+12",42,t+9,13,SUB,regular);text(c,"0",54,t+36,13,SUB,regular);text(c,"-12",42,t+65,13,SUB,regular);text(c,"-24",42,t+93,13,SUB,regular);text(c,"-60",42,b+2,13,SUB,regular);
    }

    private void outputRow(Canvas c,int i,float y) {
        roundRect(c,18,y,848,y+98,13,PANEL,LINE,1);glowCircle(c,61,y+49,25,CH_COLOR[i]);textCenter(c,String.valueOf(i+1),61,y+57,20,TEXT,medium);text(c,"CH"+(i+1),107,y+39,22,TEXT,medium);text(c,CH_NAME[i],107,y+68,16,SUB,regular);
        drawOutputSlider(c,194,y+37,426,outDb[i],CH_COLOR[i]);roundRect(c,441,y+19,533,y+71,8,PANEL2,Color.rgb(46,95,139),1);textCenter(c,String.format(Locale.US,"%.1f dB",outDb[i]),487,y+53,17,TEXT,medium);
        outputAction(c,548,y+12,611,y+80,"♪","Mute",mute[i]);outputAction(c,622,y+12,686,y+80,"♬","Solo",solo[i]);outputAction(c,697,y+12,763,y+80,"Ø","Phase",phaseInvert[i]);if(i<2)outputAction(c,773,y+12,837,y+80,"↔","Link",link[i]);
    }

    private void drawOutputSlider(Canvas c,float sl,float sy,float sr,float val,int color) {
        p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeWidth(12);p.setColor(Color.rgb(39,83,119));c.drawLine(sl,sy,sr,sy,p);float n=clamp((val+60f)/72f,0,1);p.setShader(new LinearGradient(sl,sy,sr,sy,color,CYAN,Shader.TileMode.CLAMP));c.drawLine(sl,sy,sl+(sr-sl)*n,sy,p);p.setShader(null);glowDot(c,sl+(sr-sl)*n,sy,WHITE,14);drawTicks(c,sl,sr,sy+28,5,new String[]{"-60","-40","-20","0","+12"});
    }

    private void drawBottomNav(Canvas c) {
        float top = page==0?1381:1400; roundRect(c,16,top,848,1496,17,PANEL2,LINE,1.2f);String[] labels={"Home","EQ","Crossover","Delay","Output"};
        for(int i=0;i<5;i++){float l=18+i*166,r=l+164;if(page==i){p.setShader(new LinearGradient(l,top,l,1492,Color.rgb(0,70,190),Color.rgb(0,120,255),Shader.TileMode.CLAMP));roundRectRaw(c,l,top+3,r,1492,10,p);p.setShader(null);glowBorder(c,l,top+3,r,1492,10,BLUE,10);}float cx=(l+r)/2;navIcon(c,cx,top+42,i,page==i?CYAN:Color.rgb(183,219,255));textCenter(c,labels[i],cx,top+91,20,page==i?TEXT:Color.rgb(180,215,244),regular);}
    }

    private void drawSettingsOverlay(Canvas c) {
        p.setColor(Color.argb(185,0,8,15));c.drawRect(0,0,W,H,p);roundRect(c,104,430,760,1000,20,Color.rgb(2,24,43),Color.rgb(28,111,165),2);gear(c,432,500,30,CYAN);textCenter(c,"DSP Settings",432,570,29,TEXT,bold);textCenter(c,"OKN_DSP V1 • 1.0.0",432,615,18,SUB,regular);textCenter(c,"BLE Service AB00 • Write AB01 • Notify AB02 / AB03",432,655,15,SUB,regular);textCenter(c,"UI controls update immediately on-device.",432,716,17,TEXT,regular);textCenter(c,"Hardware write frames remain protected until byte protocol is verified.",432,750,15,SUB,regular);roundRect(c,248,835,616,905,12,PANEL,Color.rgb(60,121,170),1.5f);textCenter(c,"Close",432,879,22,TEXT,medium);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float x=e.getX()*W/getWidth(), y=e.getY()*H/getHeight();
        if(e.getAction()==MotionEvent.ACTION_DOWN){return handleDown(x,y);} else if(e.getAction()==MotionEvent.ACTION_MOVE){if(dragKind!=0){handleDrag(x,y);return true;}} else if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL){dragKind=0;dragIndex=-1;return true;}return true;
    }

    private boolean handleDown(float x,float y) {
        if(settingsOpen){if(x>200&&x<665&&y>810&&y<940){settingsOpen=false;invalidate();}return true;}
        if(x>780&&y<110){settingsOpen=true;invalidate();return true;}
        if(x>510&&x<770&&y<100){if(bleAction!=null)bleAction.run();return true;}
        float navTop=page==0?1370:1385;if(y>navTop){int n=(int)(x/172f);n=Math.max(0,Math.min(4,n));page=n;invalidate();return true;}
        if(page>0&&y>=100&&y<=190){int n=(int)((x-18)/119f);if(n>=0&&n<7){channel=n;invalidate();return true;}}
        if(page==0) return touchHome(x,y);
        if(page==1) return touchEq(x,y);
        if(page==2) return touchCross(x,y);
        if(page==3) return touchDelay(x,y);
        return touchOutput(x,y);
    }

    private boolean touchHome(float x,float y) {
        float[] tops={125,273,421,569,717,865}; for(int i=0;i<6;i++){if(y>=tops[i]&&y<=tops[i]+135&&x>=350&&x<=690){dragKind=1;dragIndex=i;handleDrag(x,y);return true;}}
        if(x>130&&x<420&&y>1100&&y<1185){audioSource=(audioSource+1)%2;invalidate();return true;}if(x>130&&x<420&&y>1280&&y<1360){systemPreset=(systemPreset+1)%4;invalidate();return true;}return true;
    }

    private boolean touchEq(float x,float y) {
        if(y>640&&y<715){eqBandPage=x<242?0:x<452?1:2;invalidate();return true;}if(x>670&&y>210&&y<300){initEq();invalidate();return true;}
        int start=eqBandPage==0?0:(eqBandPage==1?6:12),count=eqBandPage==2?3:6;for(int row=0;row<count;row++){float ry=785+row*62;if(y>=ry&&y<=ry+48){int i=start+row;if(x>=100&&x<=280){eqType[i]=(eqType[i]+1)%3;}else if(x>=290&&x<=425){eqFreq[i]=stepFreq(eqFreq[i],x>356?1:-1);}else if(x>=435&&x<=580){eqGain[i]=clamp(eqGain[i]+(x>508?0.5f:-0.5f),-12,12);}else if(x>=590&&x<=740){eqQ[i]=clamp(eqQ[i]+(x>665?0.1f:-0.1f),0.2f,10f);}else if(x>=750){eqPower[i]=!eqPower[i];}invalidate();return true;}}return true;
    }

    private boolean touchCross(float x,float y) {
        if(y>680&&y<915&&x>730){hpfBypass=!hpfBypass;invalidate();return true;}if(y>928&&y<1160&&x>730){lpfBypass=!lpfBypass;invalidate();return true;}if(y>790&&y<900){if(x<305)hpfType=(hpfType+1)%3;else if(x<565)hpfFreq=stepFreq(hpfFreq,1);else hpfSlope=(hpfSlope+1)%4;invalidate();return true;}if(y>1035&&y<1150){if(x<305)lpfType=(lpfType+1)%3;else if(x<565)lpfFreq=stepFreq(lpfFreq,1);else lpfSlope=(lpfSlope+1)%4;invalidate();return true;}if(y>1250&&y<1370){if(x<245)phase=(phase+45)%360;else if(x<450)polarity=1-polarity;else if(x<605)lrLink=!lrLink;else outputMode=1-outputMode;invalidate();return true;}if(x>675&&y>225&&y<305){hpfFreq=100;lpfFreq=1000;invalidate();return true;}return true;
    }

    private boolean touchDelay(float x,float y) {
        if(y>210&&y<290&&x>480&&x<650){delayCm=x>565;invalidate();return true;}if(y>210&&y<290&&x>650){float min=delayMs[0];for(float v:delayMs)if(v<min)min=v;for(int i=0;i<delayMs.length;i++)delayMs[i]=clamp(delayMs[i]-min,0,10);invalidate();return true;}if(x>490&&y>300&&y<430){seatPreset=(seatPreset+1)%3;invalidate();return true;}for(int i=0;i<7;i++){float ry=742+i*88;if(y>=ry&&y<=ry+80&&x>=180&&x<=665){dragKind=2;dragIndex=i;handleDrag(x,y);return true;}}return true;
    }

    private boolean touchOutput(float x,float y) {
        if(y>230&&y<305&&x>470&&x<650){Arrays.fill(mute,false);invalidate();return true;}if(y>230&&y<305&&x>650){for(int i=0;i<7;i++)outDb[i]=-3f;masterOutput=-1f;invalidate();return true;}if(y>420&&y<505&&x>570){dragKind=4;handleDrag(x,y);return true;}for(int i=0;i<7;i++){float ry=573+i*109;if(y>=ry&&y<=ry+98){if(x>=180&&x<=435){dragKind=3;dragIndex=i;handleDrag(x,y);}else if(x>=540&&x<618)mute[i]=!mute[i];else if(x>=618&&x<695){solo[i]=!solo[i];if(solo[i])for(int j=0;j<7;j++)if(j!=i)solo[j]=false;}else if(x>=695&&x<772)phaseInvert[i]=!phaseInvert[i];else if(x>=772&&i<2)link[i]=!link[i];invalidate();return true;}}return true;
    }

    private void handleDrag(float x,float y) {
        if(dragKind==1){float n=clamp((x-381)/(667-381),0,1);switch(dragIndex){case 0:master=-60+n*72;break;case 1:bass=-12+n*24;break;case 2:cutoff=(float)(20*Math.pow(25,n));break;case 3:bassBoost=-10+n*22;break;case 4:midBoost=-12+n*24;break;case 5:trebleBoost=-12+n*24;break;}}else if(dragKind==2&&dragIndex>=0){delayMs[dragIndex]=clamp((x-200)/(650-200)*10f,0,10);}else if(dragKind==3&&dragIndex>=0){outDb[dragIndex]=-60+clamp((x-194)/(426-194),0,1)*72;}else if(dragKind==4){masterOutput=-60+clamp((x-589)/(813-589),0,1)*72;}invalidate();
    }

    // -------- helpers --------
    private void roundRect(Canvas c,float l,float t,float rr,float b,float rad,int fill,int stroke,float sw){p.setShader(null);p.setStyle(Paint.Style.FILL);p.setColor(fill);r.set(l,t,rr,b);c.drawRoundRect(r,rad,rad,p);if(sw>0){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(sw);p.setColor(stroke);c.drawRoundRect(r,rad,rad,p);p.setStyle(Paint.Style.FILL);}}
    private void roundRectRaw(Canvas c,float l,float t,float rr,float b,float rad,Paint paint){r.set(l,t,rr,b);c.drawRoundRect(r,rad,rad,paint);}
    private void glowBorder(Canvas c,float l,float t,float rr,float b,float rad,int color,float blur){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(color);p.setShadowLayer(blur,0,0,color);r.set(l,t,rr,b);c.drawRoundRect(r,rad,rad,p);p.clearShadowLayer();p.setStyle(Paint.Style.FILL);}
    private void glowDot(Canvas c,float x,float y,int color,float rad){p.setStyle(Paint.Style.FILL);p.setColor(color);p.setShadowLayer(rad*1.4f,0,0,color);c.drawCircle(x,y,rad,p);p.clearShadowLayer();}
    private void glowCircle(Canvas c,float x,float y,float rad,int color){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);p.setColor(color);p.setShadowLayer(14,0,0,color);c.drawCircle(x,y,rad,p);p.clearShadowLayer();p.setStyle(Paint.Style.FILL);}
    private void text(Canvas c,String s,float x,float y,float size,int color,Typeface face){p.setShader(null);p.setStyle(Paint.Style.FILL);p.setTypeface(face);p.setTextSize(size);p.setColor(color);p.setTextAlign(Paint.Align.LEFT);c.drawText(s,x,y,p);}
    private void textCenter(Canvas c,String s,float x,float y,float size,int color,Typeface face){p.setShader(null);p.setStyle(Paint.Style.FILL);p.setTypeface(face);p.setTextSize(size);p.setColor(color);p.setTextAlign(Paint.Align.CENTER);c.drawText(s,x,y,p);p.setTextAlign(Paint.Align.LEFT);}
    private void drawLogo(Canvas c,float cx,float cy,int color){p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeWidth(7);p.setColor(color);p.setShadowLayer(10,0,0,color);float[] h={18,32,47,35,21};for(int i=0;i<5;i++){float x=cx-32+i*16;c.drawLine(x,cy-h[i]/2,x,cy+h[i]/2,p);}p.clearShadowLayer();}
    private void gear(Canvas c,float cx,float cy,float rad,int color){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);p.setColor(color);c.drawCircle(cx,cy,rad*.62f,p);c.drawCircle(cx,cy,rad*.22f,p);for(int i=0;i<8;i++){double a=i*Math.PI/4;float x1=cx+(float)Math.cos(a)*rad*.70f,y1=cy+(float)Math.sin(a)*rad*.70f,x2=cx+(float)Math.cos(a)*rad,y2=cy+(float)Math.sin(a)*rad;c.drawLine(x1,y1,x2,y2,p);}p.setStyle(Paint.Style.FILL);}
    private void iconTile(Canvas c,float l,float t,float rr,float b,int color){roundRect(c,l,t,rr,b,15,Color.rgb(3,43,78),color,1);p.setShadowLayer(10,0,0,color);p.setColor(Color.argb(40,0,180,255));c.drawRoundRect(new RectF(l,t,rr,b),15,15,p);p.clearShadowLayer();}
    private void drawHomeIcon(Canvas c,float x,float y,int idx,int color){p.setColor(color);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(5);if(idx==0)speakerIcon(c,x,y,color);else if(idx==1){c.drawCircle(x,y,22,p);c.drawCircle(x,y,9,p);}else if(idx==2)crossoverIcon(c,x,y,color);else if(idx==3)barsIcon(c,x,y,color);else if(idx==4){path.reset();path.moveTo(x-28,y+5);path.lineTo(x-19,y+5);path.lineTo(x-11,y-21);path.lineTo(x+1,y+24);path.lineTo(x+12,y-12);path.lineTo(x+20,y+8);path.lineTo(x+31,y+8);c.drawPath(path,p);}else{path.reset();path.moveTo(x,y-25);path.lineTo(x+8,y-7);path.lineTo(x+26,y);path.lineTo(x+8,y+8);path.lineTo(x,y+27);path.lineTo(x-8,y+8);path.lineTo(x-26,y);path.lineTo(x-8,y-7);path.close();p.setStyle(Paint.Style.FILL);c.drawPath(path,p);}p.setStyle(Paint.Style.FILL);}
    private void speakerIcon(Canvas c,float x,float y,int color){p.setColor(color);p.setStyle(Paint.Style.FILL);path.reset();path.moveTo(x-25,y-8);path.lineTo(x-12,y-8);path.lineTo(x+3,y-23);path.lineTo(x+3,y+23);path.lineTo(x-12,y+8);path.lineTo(x-25,y+8);path.close();c.drawPath(path,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);r.set(x-1,y-17,x+27,y+17);c.drawArc(r,-55,110,false,p);r.set(x+2,y-25,x+39,y+25);c.drawArc(r,-50,100,false,p);p.setStyle(Paint.Style.FILL);}
    private void musicIcon(Canvas c,float x,float y,int color){p.setColor(color);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(5);c.drawLine(x-4,y-20,x+18,y-25,p);c.drawLine(x-4,y-20,x-4,y+13,p);c.drawLine(x+18,y-25,x+18,y+8,p);p.setStyle(Paint.Style.FILL);c.drawCircle(x-10,y+16,8,p);c.drawCircle(x+12,y+12,8,p);}
    private void menuIcon(Canvas c,float x,float y,int color){p.setColor(color);p.setStrokeWidth(6);p.setStrokeCap(Paint.Cap.ROUND);for(int i=-1;i<=1;i++)c.drawLine(x-17,y+i*13,x+17,y+i*13,p);}
    private void chipIcon(Canvas c,float x,float y,int color){p.setColor(color);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);r.set(x-15,y-15,x+15,y+15);c.drawRoundRect(r,4,4,p);for(int i=-1;i<=1;i++){c.drawLine(x-23,y+i*9,x-15,y+i*9,p);c.drawLine(x+15,y+i*9,x+23,y+i*9,p);c.drawLine(x+i*9,y-23,x+i*9,y-15,p);c.drawLine(x+i*9,y+15,x+i*9,y+23,p);}p.setStyle(Paint.Style.FILL);}
    private void battery(Canvas c,float x,float y,int color){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(color);r.set(x-12,y-9,x+12,y+9);c.drawRect(r,p);c.drawLine(x+12,y-4,x+16,y-4,p);c.drawLine(x+16,y-4,x+16,y+4,p);c.drawLine(x+16,y+4,x+12,y+4,p);p.setStyle(Paint.Style.FILL);c.drawRect(x-8,y-5,x+7,y+5,p);}
    private void thermometer(Canvas c,float x,float y,int color){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(color);c.drawCircle(x,y+8,7,p);c.drawLine(x-3,y+2,x-3,y-14,p);c.drawLine(x+3,y+2,x+3,y-14,p);c.drawArc(new RectF(x-3,y-18,x+3,y-12),180,180,false,p);p.setStyle(Paint.Style.FILL);}
    private void circleCheck(Canvas c,float x,float y,int color){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(color);c.drawCircle(x,y,14,p);c.drawLine(x-7,y,x-1,y+6,p);c.drawLine(x-1,y+6,x+8,y-7,p);p.setStyle(Paint.Style.FILL);}
    private void resetIcon(Canvas c,float x,float y,int color){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(color);r.set(x-14,y-14,x+14,y+14);c.drawArc(r,-60,290,false,p);path.reset();path.moveTo(x+10,y-15);path.lineTo(x+18,y-7);path.lineTo(x+7,y-5);path.close();p.setStyle(Paint.Style.FILL);c.drawPath(path,p);}
    private void crossoverIcon(Canvas c,float x,float y,int color){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);p.setColor(color);path.reset();path.moveTo(x-28,y-15);path.cubicTo(x-8,y-15,x-15,y+15,x+28,y+15);c.drawPath(path,p);path.reset();path.moveTo(x-28,y+15);path.cubicTo(x-8,y+15,x-15,y-15,x+28,y-15);c.drawPath(path,p);p.setStyle(Paint.Style.FILL);}
    private void hpfIcon(Canvas c,float x,float y,int color){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);p.setColor(color);path.reset();path.moveTo(x-28,y+18);path.cubicTo(x-15,y+18,x-12,y-18,x+8,y-18);path.lineTo(x+28,y-18);c.drawPath(path,p);p.setStyle(Paint.Style.FILL);}
    private void lpfIcon(Canvas c,float x,float y,int color){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);p.setColor(color);path.reset();path.moveTo(x-28,y-18);path.lineTo(x-5,y-18);path.cubicTo(x+15,y-18,x+14,y+18,x+28,y+18);c.drawPath(path,p);p.setStyle(Paint.Style.FILL);}
    private void clockIcon(Canvas c,float x,float y,int color){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);p.setColor(color);c.drawCircle(x,y,24,p);c.drawLine(x,y,x,y-15,p);c.drawLine(x,y,x+13,y+8,p);p.setStyle(Paint.Style.FILL);}
    private void chairIcon(Canvas c,float x,float y,int color){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(color);r.set(x-10,y-16,x+10,y+5);c.drawRoundRect(r,5,5,p);r.set(x-14,y+3,x+14,y+15);c.drawRoundRect(r,4,4,p);c.drawLine(x-10,y+15,x-13,y+23,p);c.drawLine(x+10,y+15,x+13,y+23,p);p.setStyle(Paint.Style.FILL);}
    private void rulerIcon(Canvas c,float x,float y,int color){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(color);c.save();c.rotate(-38,x,y);r.set(x-18,y-7,x+18,y+7);c.drawRoundRect(r,2,2,p);for(int i=-12;i<=12;i+=6)c.drawLine(x+i,y-7,x+i,y-1,p);c.restore();p.setStyle(Paint.Style.FILL);}
    private void barsIcon(Canvas c,float x,float y,int color){p.setColor(color);p.setStrokeWidth(5);p.setStrokeCap(Paint.Cap.ROUND);for(int i=-2;i<=2;i++){float h=8+Math.abs(i-1)*5;c.drawLine(x+i*8,y+h/2,x+i*8,y-h,p);}}
    private void folderIcon(Canvas c,float x,float y,int color){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);p.setColor(color);path.reset();path.moveTo(x-23,y-16);path.lineTo(x-5,y-16);path.lineTo(x+2,y-8);path.lineTo(x+24,y-8);path.lineTo(x+24,y+18);path.lineTo(x-23,y+18);path.close();c.drawPath(path,p);p.setStyle(Paint.Style.FILL);}
    private void navIcon(Canvas c,float x,float y,int idx,int color){if(idx==0){p.setColor(color);path.reset();path.moveTo(x-23,y);path.lineTo(x,y-20);path.lineTo(x+23,y);path.lineTo(x+18,y);path.lineTo(x+18,y+24);path.lineTo(x-18,y+24);path.lineTo(x-18,y);path.close();p.setStyle(Paint.Style.FILL);c.drawPath(path,p);}else if(idx==1){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(color);path.reset();path.moveTo(x-24,y+3);path.lineTo(x-17,y+3);path.lineTo(x-10,y-16);path.lineTo(x-2,y+20);path.lineTo(x+6,y-10);path.lineTo(x+13,y+6);path.lineTo(x+24,y+6);c.drawPath(path,p);p.setStyle(Paint.Style.FILL);}else if(idx==2)crossoverIcon(c,x,y,color);else if(idx==3)clockIcon(c,x,y,color);else barsIcon(c,x,y,color);}
    private void drawTicks(Canvas c,float sl,float sr,float y,int count,String[] labels){p.setStrokeWidth(2);p.setColor(Color.rgb(72,141,197));for(int i=0;i<count;i++){float x=sl+(sr-sl)*i/(count-1);c.drawLine(x,y-8,x,y,p);}for(int i=0;i<labels.length;i++){float x=sl+(sr-sl)*i/(labels.length-1);textCenter(c,labels[i],x,y+23,14,SUB,regular);}}
    private void tabButton(Canvas c,float l,float t,float rr,float b,String label,boolean active){if(active){p.setShader(new LinearGradient(l,t,l,b,BLUE,CYAN,Shader.TileMode.CLAMP));roundRectRaw(c,l,t,rr,b,9,p);p.setShader(null);glowBorder(c,l,t,rr,b,9,CYAN,8);}else roundRect(c,l,t,rr,b,9,PANEL2,Color.rgb(45,96,140),1);textCenter(c,label,(l+rr)/2,t+37,19,TEXT,regular);}
    private void stepBox(Canvas c,float l,float t,float rr,float b,String val){roundRect(c,l,t,rr,b,7,PANEL2,Color.rgb(46,96,141),1);text(c,"‹",l+8,t+31,24,SUB,regular);textCenter(c,val,(l+rr)/2,t+30,15,TEXT,regular);text(c,"›",rr-18,t+31,24,SUB,regular);}
    private void toggle(Canvas c,float l,float t,float rr,float b,boolean on,int color){roundRect(c,l,t,rr,b,(b-t)/2,on?color:Color.rgb(30,59,90),on?color:Color.rgb(44,82,119),1);float rad=(b-t)/2-4;float cx=on?rr-rad-4:l+rad+4;glowDot(c,cx,(t+b)/2,WHITE,rad);}
    private void selectorBox(Canvas c,float l,float t,float rr,float b,String label,String value){roundRect(c,l,t,rr,b,10,PANEL2,Color.rgb(43,91,133),1);text(c,label,l+15,t+31,16,TEXT,regular);roundRect(c,l+14,t+45,rr-14,b-14,7,PANEL,Color.rgb(53,104,150),1);text(c,value,l+31,b-33,17,TEXT,regular);text(c,"⌄",rr-48,b-34,22,SUB,regular);}
    private void smallSelector(Canvas c,float l,float t,float rr,float b,String label,String value){roundRect(c,l,t,rr,b,10,PANEL2,Color.rgb(44,94,137),1);text(c,label,l+20,t+36,16,TEXT,regular);roundRect(c,l+14,t+51,rr-14,b-14,7,PANEL,Color.rgb(53,103,149),1);textCenter(c,value,(l+rr)/2,b-34,17,TEXT,regular);}
    private void iconButton(Canvas c,float l,float t,float rr,float b,String glyph,String label){roundRect(c,l,t,rr,b,10,PANEL2,Color.rgb(47,100,145),1);textCenter(c,glyph,(l+rr)/2,t+52,34,Color.rgb(187,230,255),medium);textCenter(c,label,(l+rr)/2,t+83,16,SUB,regular);}
    private void outputAction(Canvas c,float l,float t,float rr,float b,String glyph,String label,boolean on){roundRect(c,l,t,rr,b,9,on?Color.rgb(3,48,81):PANEL2,on?CYAN:Color.rgb(43,91,133),on?2:1);textCenter(c,glyph,(l+rr)/2,t+29,23,on?CYAN:Color.rgb(184,221,247),regular);textCenter(c,label,(l+rr)/2,t+56,14,on?CYAN:TEXT,regular);}
    private void seat(Canvas c,float x,float y){roundRect(c,x-24,y-28,x+24,y+24,12,Color.rgb(0,45,93),Color.rgb(0,103,190),2);roundRect(c,x-29,y+10,x+29,y+33,10,Color.rgb(0,51,103),Color.rgb(0,107,196),2);}
    private float clamp(float v,float a,float b){return Math.max(a,Math.min(b,v));}
    private float logNorm(float v,float min,float max){return clamp((float)(Math.log(v/min)/Math.log(max/min)),0,1);}
    private String formatFreq(float f){return f>=1000?String.format(Locale.US,"%.1f kHz",f/1000f):String.format(Locale.US,"%.0f Hz",f);}
    private float stepFreq(float f,int dir){float[] steps={20,25,32,40,50,63,80,100,125,160,200,250,315,400,500,630,800,1000,1250,1600,2000,2500,3150,4000,5000,6300,8000,10000,12500,16000,20000};int best=0;for(int i=0;i<steps.length;i++)if(Math.abs(steps[i]-f)<Math.abs(steps[best]-f))best=i;best=Math.max(0,Math.min(steps.length-1,best+dir));return steps[best];}
    private int bandColor(int i){int[] c={RED,ORANGE,YELLOW,GREEN,CYAN,PURPLE,Color.rgb(255,80,170),Color.rgb(48,165,255),Color.rgb(0,229,160),Color.rgb(255,196,0),Color.rgb(102,122,255),Color.rgb(255,90,90),Color.rgb(0,190,255),Color.rgb(220,70,255),Color.rgb(255,145,0)};return c[i%c.length];}
    private String typeName(int t){return t==1?"Low Shelf":t==2?"High Shelf":"PEQ";}
    private String typeFilter(int t){return t==0?"Linkwitz-Riley":t==1?"Butterworth":"Bessel";}
    private String slopeName(int i){int[] a={6,12,24,48};return a[i%4]+" dB/Oct";}
}
