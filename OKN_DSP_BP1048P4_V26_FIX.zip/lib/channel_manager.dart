// CH1-CH7 manager V26
