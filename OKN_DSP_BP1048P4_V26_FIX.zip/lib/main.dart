import 'package:flutter/material.dart';

void main() => runApp(const OKNDSP());

class OKNDSP extends StatelessWidget {
  const OKNDSP({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),
      home: const DSPHome(),
    );
  }
}

class DSPHome extends StatelessWidget {
  const DSPHome({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('OKN_DSP BP1048P4 V26')),
      backgroundColor: const Color(0xff101018),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: const [
          Text('DSP Controller',
              style: TextStyle(color: Colors.cyan, fontSize: 28)),
          SizedBox(height: 20),
          Text('Bluetooth Connect\n'
              'CH1 - CH7 Mixer\n'
              'Volume Control\n'
              '15 Band EQ\n'
              'HPF / LPF Crossover\n'
              'Delay\n'
              'TX RX Log\n'
              'Preset Save / Load',
              style: TextStyle(fontSize: 18)),
        ],
      ),
    );
  }
}
