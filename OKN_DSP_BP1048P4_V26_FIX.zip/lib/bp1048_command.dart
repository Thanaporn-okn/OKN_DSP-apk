// BP1048P4 command packet V26
