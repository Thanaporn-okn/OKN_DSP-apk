// Bluetooth manager V26
