#!/usr/bin/env python3
from pathlib import Path
import re, sys
root=Path(__file__).resolve().parent.parent
ble=(root/'app/src/main/java/com/okn/dsp/BleManager.java').read_text()
view=(root/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
state=(root/'app/src/main/java/com/okn/dsp/DspState.java').read_text()
build=(root/'app/build.gradle').read_text()
checks={
 'version39': "versionCode 1039" in build and "versionName '39.0.0'" in build,
 'reset_method': 'int resetEqSafe(int channel0)' in ble,
 'stale_gain_clear': 'stopEqRealtimePump();' in ble,
 'stale_shape_clear': 'stopEqShapePump();' in ble,
 'gain_only_peaking': 'DspProtocol.peakingFromCurrent(current, 0f)' in ble,
 'gain_only_band1': 'DspProtocol.firstBandGainFromCurrent(current, 0f)' in ble,
 'reset_gap_110': 'EQ_RESET_MIN_GAP_MS = 110L' in ble,
 'reset_blocks_touch_gain': 'txCipher == null || eqResetActive' in ble,
 'reset_blocks_touch_shape': '!eqShapeHealthGate || eqResetActive' in ble,
 'selective_ui_mirror': 'resetEqGainWritableOnly(resetCh, eqGainWritable[resetCh])' in view,
 'requires_ready': 'Connect DSP before Safe Reset EQ' in view,
 'refuse_inflight_snapshot': 'if (liveWriteBusy) return -3;' in ble,
 'selective_state': 'resetEqGainWritableOnly(int ch, boolean[] writable)' in state,
 'no_reset_channel_call': 'state.resetEqChannel(resetCh)' not in view,
}
# Inspect reset method body specifically: it must not call the shape writer or touch scalar Master.
m=re.search(r'int resetEqSafe\(int channel0\) \{(.*?)\n    \}\n\n    private void clearEqResetState', ble, re.S)
checks['reset_body_found']=m is not None
if m:
    body=m.group(1)
    checks['no_shape_target_in_reset']='peakingShapeFromCurrent' not in body and 'setEqShapeRealtime' not in body
    checks['no_master_in_reset']='ID_MASTER_VOLUME' not in body and 'setScalarRealtime' not in body
    checks['full_record_path']='PendingCommand.eq(' in body
for k,v in checks.items():
    print(f'{k}={"PASS" if v else "FAIL"}')
if not all(checks.values()): sys.exit(1)
print('V39_SAFE_RESET_STATIC_PASS')
