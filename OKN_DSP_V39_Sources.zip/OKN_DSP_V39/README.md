# OKN DSP V39 — Safe Hardware Reset EQ

**Base:** V38, confirmed normal on the real DSP by the user. V38 Master Volume, EQ Gain, and safe-row Frequency/Q behavior are preserved.

## V39 change

Reset EQ is enabled for hardware again, but only through the already-proven V38/V32 Gain writer.

- Reset affects **Gain only**.
- Frequency, Q, filter type, F2, G and R metadata are preserved exactly.
- Only rows marked Gain-writable by the fresh Device Description are touched.
- Locked/bypass/unsafe rows remain untouched in both hardware and UI.
- Reset refuses to snapshot targets while another live write is still in flight; the UI asks for one retry after that write finishes.
- All stale EQ touch targets are discarded before reset.
- User EQ writes are temporarily blocked while reset is running.
- Each reset record is a full **48-byte** verified EQ record.
- Reset uses one GATT write in flight and **110 ms minimum spacing** between rows.
- No bulk multi-band packet is used.
- No Master-volume mute/ramp is injected.
- No automatic SaveParams is sent.
- If the BLE/DSP session is not Ready, Reset EQ refuses to run rather than changing only the UI.

This avoids the V33-V36 failure mode where Frequency/Q were rewritten across many rows during reset.

## Version

- versionName: **39.0.0**
- versionCode: **1039**
- applicationId: `com.okn.dsp`

Build the APK with the supplied GitHub Actions workflow.
