# OKN DSP V36 — Phase 2 Hardware-safe EQ Reset

Base: **V35**. V31 authenticated BLE, V32 low-latency EQ, V33 Frequency/Q/Gain, and V35 Smooth-Q are retained.

## V36 critical fix
Real-hardware video `36225.mp4` shows that pressing **Reset EQ** can produce a very loud burst for about one second and then leave a sustained whistle. The previous reset wrote many Frequency/Q coefficient records in sequence. That reset path is removed.

V36 Reset EQ is now a **Safe Flat Reset**:

1. Cancel stale EQ/Q drag targets.
2. Require a valid current Master value; otherwise block Reset (fail closed).
3. Temporarily mute verified Master Volume to `-70 dB`.
4. Set every writable EQ band to `0 dB` using its **current** Frequency/Q and the already-proven Gain writer.
5. Do **not** sweep or rewrite Frequency/Q during Reset.
6. Restore Master in confirmed steps of at most `10 dB` until the user's previous Master level is reached.

Frequency and Q remain unchanged when Reset is pressed. Gain becomes 0 dB, so the EQ response is flat without the dangerous multi-band F/Q sweep.

## Retained
- Master Volume LIVE.
- Bass Volume / Bass Cutoff verified scalar control.
- Bands 2..15 Frequency + Smooth-Q + Gain LIVE.
- Band 1 Gain LIVE only.
- 45 ms serialized EQ lane and continuous AES-CFB8 state.

## Still deliberately locked
- Volume Ch1-Ch7 hardware mapping.
- Band 1 generic Frequency/Q writes.
- Automatic permanent SaveParams.

versionName: **36.0.0**
versionCode: **1036**
Phase: **2 — authenticated real-time DSP control**
