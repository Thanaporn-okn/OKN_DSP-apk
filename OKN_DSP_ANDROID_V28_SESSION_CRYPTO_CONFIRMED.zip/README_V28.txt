OKN DSP ANDROID V28 — VERIFIED UFE / SESSION CRYPTO MODEL

New confirmations from the clean official-app HCI + logcat session:
- UFE WRITE layout = 57 | actuatorId:uint32 BE | memoryOffset:uint16 BE | memoryLength:uint16 BE | data
- UFE READ layout  = 58 | actuatorId:uint32 BE | memoryOffset:uint16 BE | memoryLength:uint16 BE
- Scalar FLOAT32 actuator data = little-endian
- MasterVolume ID2 -13.76 dB plaintext = 570000000200000004F6285CC1
- AES-CFB8/NoPadding application TX is confirmed
- Session key = 16-byte RandKey from the current authentication session
- TX IV = 01 repeated 16 bytes
- TX CFB8 state is continuous across application packets
- Plain device-description request = 661C0624
- Verified vector A: key 81162308EBF817D62C083CD5250A2D4D -> AC6B6C12
- Verified vector B: key 2CDB9100B0162F6D82285C9706EFABB3 -> B596F744

EQ:
- CH1..CH7 actuator IDs = 4,5,6,14,15,16,17
- one band = 48 bytes = int32 LE type + 11 float32 LE fields
- band offset = (band-1)*48; captured cascade/Band7 uses offset 288
- PEAKING type = 12
- captured PEAKING coefficients match standard RBJ math at Fs=44100 Hz

CURRENT SINGLE MAJOR BLOCKER:
The app still cannot derive/extract the current 16-byte RandKey from the raw 32-byte authentication response by itself. Therefore LIVE DSP parameter writes remain locked. Known keys in self-tests are evidence vectors only and are never reused for live control.

V28 includes offline protocol self-tests and verified serializers, but WriteGate remains false.
