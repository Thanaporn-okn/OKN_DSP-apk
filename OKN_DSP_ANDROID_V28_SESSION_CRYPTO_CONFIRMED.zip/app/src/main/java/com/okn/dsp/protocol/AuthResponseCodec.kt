package com.okn.dsp.protocol

/** Header fields that are directly visible before the still-encrypted authentication payload. */
data class AuthResponseHeader(
    val typeId: Int,
    val versionId: Int,
    val encryptedTail: ByteArray,
)

object AuthResponseCodec {
    fun parse32(bytes: ByteArray): AuthResponseHeader {
        require(bytes.size == 32) { "authentication response must be 32 bytes" }
        return AuthResponseHeader(
            typeId = ByteCodec.readU16be(bytes, 0),
            versionId = ByteCodec.readU16be(bytes, 2),
            encryptedTail = bytes.copyOfRange(4, bytes.size),
        )
    }
}
