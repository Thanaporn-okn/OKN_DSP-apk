# BUILD NOTES R14

R14 เป็น research-hardening release ต่อจาก R13 ไม่ใช่ firmware image สำหรับแฟลช

การเปลี่ยนแปลง:
- ปิด task เดิมเรื่อง `SignalMerger.GainList` เพราะพิสูจน์แล้วว่าเป็น DTO/backing List<double> ไม่ใช่ hardware writer
- เพิ่มเอกสาร static evidence ของ generic BP10X USB PC-upgrade path
- เพิ่ม machine-readable flashboot research gate
- เพิ่ม offline MVA header inspector แบบ read-only
- เพิ่ม fail-closed safety checker สำหรับ Android + research-state flags
- แก้ SHA manifest ไม่ให้ self-reference และไม่ package binary ที่เกิดจาก host tests

R14 ไม่เพิ่ม:
- Feature SET_REPORT
- 0x55/0xAA upgrade latch
- erase/program/commit
- guessed flash address
- guessed MVA packer
