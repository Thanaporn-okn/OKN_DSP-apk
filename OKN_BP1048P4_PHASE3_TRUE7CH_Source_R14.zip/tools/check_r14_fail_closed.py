#!/usr/bin/env python3
from pathlib import Path
import json, re
root = Path(__file__).resolve().parents[1]
java = (root/'android-usb-probe/app/src/main/java/com/okn/dsp/usbprobe/MainActivity.java').read_text(encoding='utf-8')

# Every USB controlTransfer request type present in the Android probe must be IN (bit7 = 1).
for m in re.finditer(r'controlTransfer\(\s*(0x[0-9A-Fa-f]+|\d+)', java):
    v = int(m.group(1), 0)
    if (v & 0x80) == 0:
        raise SystemExit(f'R14 safety guard FAIL: USB control OUT request type {m.group(1)}')

for bad in ['bulkTransfer(', 'new UsbRequest(', 'claimInterface(x3,true)', 'claimInterface(x3, true)']:
    if bad in java:
        raise SystemExit(f'R14 safety guard FAIL: forbidden Android write token {bad!r}')

state = json.loads((root/'config/FLASHBOOT_RESEARCH_STATE_R14.json').read_text(encoding='utf-8'))
gate = state['production_gate']
for key in [
    'exact_golopine_post_jump_protocol', 'exact_golopine_image_format',
    'exact_golopine_flash_layout', 'exact_golopine_7bus_audio_hook',
    'stock_backup_available', 'recovery_verified', 'enable_feature_set_report',
    'enable_flash_write', 'enable_erase', 'enable_commit'
]:
    if gate.get(key) is not False:
        raise SystemExit(f'R14 safety guard FAIL: {key} must remain false')

port = (root/'firmware/port/bp1048p4_golopine_port_TEMPLATE.c').read_text(encoding='utf-8')
if '#error "Replace TEMPLATE with a reviewed exact board port before enabling."' not in port:
    raise SystemExit('R14 safety guard FAIL: exact-board port fail-closed #error missing')

print('R14 flash/USB fail-closed guard: PASS')
