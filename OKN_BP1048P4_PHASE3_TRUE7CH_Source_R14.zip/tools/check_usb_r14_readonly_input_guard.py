from pathlib import Path
root=Path(__file__).resolve().parents[1]
p=root/'android-usb-probe/app/src/main/java/com/okn/dsp/usbprobe/MainActivity.java'
s=p.read_text(encoding='utf-8')
for bad in [
    'claimInterface(x3,true)', 'claimInterface(x3, true)',
    'controlTransfer(0x21', 'controlTransfer(0x01',
    'bulkTransfer(', 'new UsbRequest(',
    'out[0]=(byte)0xA5', 'SET_REPORT result'
]:
    if bad in s:
        raise SystemExit(f'R14 Android guard FAIL: forbidden transport token {bad!r}')
for needed in ['InputDevice.getDeviceIds()', 'dispatchKeyEvent', 'dispatchGenericMotionEvent', 'keyActionToString', 'R14 READ-ONLY USB complete']:
    if needed not in s:
        raise SystemExit(f'R14 Android guard FAIL: missing {needed!r}')

if 'KeyEvent.actionToString' in s:
    raise SystemExit('R14 Android compile guard FAIL: KeyEvent.actionToString does not exist')
print('R14 Android InputDevice + USB read-only guard: PASS')
