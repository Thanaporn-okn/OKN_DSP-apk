#!/usr/bin/env python3
from pathlib import Path
import importlib.util, tempfile
p = Path(__file__).with_name('inspect_mva_readonly.py')
spec = importlib.util.spec_from_file_location('inspect_mva_readonly', p)
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
with tempfile.TemporaryDirectory() as td:
    f = Path(td)/'sample.mva'
    f.write_bytes(b'MV\xB1\x58\x04' + b'abcMVUBxyz')
    r = m.inspect(f)
    assert r['fingerprint_kind'] == 'MV-prefix'
    assert r['raw_chip_byte'] == 0xB1
    assert r['raw_generation_byte'] == 0x58
    assert r['raw_record_count_byte'] == 4
    assert r['contains_MVUB_ascii'] is True
    before = f.read_bytes()
    m.inspect(f)
    assert f.read_bytes() == before
print('R14 read-only MVA fingerprint tests: PASS')
