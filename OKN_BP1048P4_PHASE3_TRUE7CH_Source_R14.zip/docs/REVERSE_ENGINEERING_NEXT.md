# จุด reverse-engineering ต่อจาก R14

## A. Stock 7CH GainList path: CLOSED

จาก Windows 2026 protected runtime ที่ถอดได้แล้ว:
- `SignalMerger.get_GainList` / `set_GainList` เป็นเพียง backing `List<double>`
- legacy `DSTechAcutatorCommand` / SigmaDSP single-variable helpers ไม่มี direct managed caller ใน active 2026 runtime
- active writer ใช้ UFE actuator จาก Device Description
- stock Device Description ไม่มี `Channel1Volume..Channel7Volume`

ดังนั้น **หยุดค้นหา stock hidden CH1..CH7 volume ผ่าน GainList/legacy SigmaDSP path** และห้ามใช้ EQ/Band1/Tone Control มาปลอมเป็น channel gain

## B. Exact first-install path: PRIMARY TARGET

งานต่อคือ reconstruct post-jump flashboot transport ของ exact GoloPine board แบบ static/offline ก่อน:
1. packet framing / command IDs
2. ACK/NACK / retry semantics
3. CRC/checksum
4. image/container record rules และ target/chip validation
5. read-only identity/version/capability ถ้ามี
6. exact flash layout + protected/boot/app/config/calibration regions
7. backup/restore หรือ hardware recovery ที่พิสูจน์ได้

Public generic BP10X SDK ยืนยันเพียง family architecture: Feature 0x55/0xAA สามารถ arm PC-upgrade และ handoff ไป flashboot address 0 ได้ แต่ **ห้ามใช้เป็น production GoloPine command recipe** จน exact board evidence ครบ

## C. Exact 7-bus audio callback

TRUE7CH core พร้อมแล้ว แต่ board port ยัง lock. ต้องหา exact buffers/callback ของ:
- CH1/CH2 main L/R
- CH3 bass mono
- CH4/CH5 stereo pair
- CH6/CH7 stereo pair

จุด apply ต้องหลัง EQ/crossover และก่อน final DAC/I2S sink. ห้ามเดา MMIO/register/buffer pointer.

## D. Android writer

Samsung S25+ จะเปิด firmware-write path ได้ก็ต่อเมื่อ B+C ผ่าน gate ทั้งหมด. ก่อนหน้านั้น Android USB code ต้องเป็น read-only และปุ่ม CH1..CH7 จะเปิดเฉพาะเมื่อ firmware OKN advertise `OKN-DSP-P4-7CH` + IDs22..28 ครบเท่านั้น.
