# BP10X Flashboot static evidence — R14

วันที่ 2026-09-18

เอกสารนี้สรุป **static family evidence** เท่านั้น ไม่มีขั้นตอนส่งคำสั่งไปฮาร์ดแวร์

## 1. HID PC-upgrade arm ใน public BP10X SDK

ไฟล์ public SDK `otg_device_standard_request.c` แสดง logic บน HID data interface:
- Feature SET_REPORT ตั้ง `pc_upgrade=0` ก่อน
- ถ้า `Request[0] == 0x55` จะเปรียบเทียบ `Request[1..4]` กับ 4 bytes ที่ `(0x10000 + 0xB8)`; ถ้าต่างกันจึง arm `pc_upgrade`
- ถ้า `Request[0] == 0xAA` จะ arm `pc_upgrade` แบบ unconditional
- Feature GET_REPORT เมื่อ armed จะตอบ marker `0x55` แล้วเรียก `start_up_grate(AppResourceUsbDevice)` เมื่อ flashboot support เปิดอยู่

จุดสำคัญ: นี่อธิบายได้ว่าทำไม Feature report 8-byte ของตระกูลนี้เกี่ยวข้องกับ PC-upgrade แต่ **R14 ไม่ส่ง SET_REPORT ใด ๆ**

## 2. Generic family layout evidence

Public BP10X linker/source ชุดเดียวกันแสดงว่า:
- flashboot ถูก link ไว้ที่ address `0x000000`
- application start อยู่ที่ `0x00010000`
- `flash_boot.c` ฝัง `flash_data[65536]`

ดังนั้น offset `0xB8` ที่ใช้ compare ในข้อ 1 สอดคล้องกับ app header ที่ `0x10000 + 0xB8` ใน generic build นี้

**ห้ามยก layout นี้ไปเป็น exact GoloPine flash map** เพราะ production firmware อาจใช้ linker/config/package คนละ revision

## 3. MVA evidence

หลักฐานเดิมจาก embedded flashboot ระบุ package/type logic และ strings เกี่ยวกับ MVA/MVB1X แต่ exact production GoloPine container ยังไม่ถูก recover.

งานจาก sibling BP10xx device แสดงว่ามี MVA หลาย generation/layout และบางรุ่นมี Code/Flash Driver/Const records แต่ความแตกต่างข้าม chip/generation สูงพอที่ห้าม copy layout, CRC, encryption หรือ erase strategy มาใช้กับ GoloPine โดยตรง.

## 4. Gate ที่ยังล็อก

จนกว่าจะมีหลักฐาน exact GoloPine ครบ ค่าเหล่านี้ต้องเป็น false:
- `exact_golopine_post_jump_protocol`
- `exact_golopine_image_format`
- `stock_backup_available`
- `recovery_verified`
- `enable_feature_set_report`
- `enable_flash_write`

R14 จึงเป็น source/research package และไม่มี flashable target image.
