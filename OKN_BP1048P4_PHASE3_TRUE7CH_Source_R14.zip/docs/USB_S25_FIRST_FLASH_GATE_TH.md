# Samsung S25+ USB-C first-flash gate — R14

USB IF4 ของบอร์ดจริงตรงกับ generic BP10X vendor-HID shape มากพอให้ระบุว่าเป็น candidate PC-upgrade interface แต่ยัง **ไม่พอ** สำหรับ first flash.

Android R14 ทำได้เฉพาะ read-only:
- enumerate device/interface/endpoint
- ตรวจ expected VID/PID
- อ่าน HID report descriptor
- Feature GET_REPORT (IN)
- Input GET_REPORT (IN)
- passive Android InputDevice events

R14 ไม่มี control OUT, SET_REPORT, endpoint OUT, 0x55/0xAA latch, erase, program, commit หรือ reboot-to-bootloader.

ก่อนปลดล็อก writer ต้องมีหลักฐานครบทุกข้อ:
1. exact GoloPine post-jump packet framing + ACK/NACK + CRC
2. exact production image/container/chip validation
3. exact flash size/layout/protected boot/app/config/calibration regions
4. stock firmware backup หรือ recovery image/path ที่พิสูจน์ได้
5. non-destructive bootloader identity/version/read path ถ้ามี
6. exact 7-output audio hook ของ production project
7. image hash + board identity preflight + power-loss/recovery plan
8. ทดสอบกับ recovery-capable spare board ก่อนบอร์ดหลัก

Generic SDK address/handshake และ sibling BP10xx MVA layout เป็น research evidence เท่านั้น ห้ามยกมาเป็น write recipe ของบอร์ดนี้.
