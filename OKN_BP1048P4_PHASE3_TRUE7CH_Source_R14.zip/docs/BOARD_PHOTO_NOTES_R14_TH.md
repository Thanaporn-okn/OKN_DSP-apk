# Board photo notes — R14

จากรูปบอร์ดชุด 2026-09-18 และ silkscreen ที่อ่านได้:
- บอร์ดระบุ `3/5/7-channels DSP Wireless audio front stage`
- กลุ่ม output ด้านหลังระบุคู่ `1/2`, mono `Bass 3`, คู่ `4/5`, คู่ `6/7`
- มี USB-A, USB-C, SPDIF และไฟ `DC 5-30V`
- topology ทางกายภาพสอดคล้องกับ logical 7-channel core ที่ใช้ใน R14

รูปถ่ายยังไม่ให้หลักฐานพอสำหรับ:
- exact SPI-flash part/size
- protected boot region
- calibration/identity address
- exact DAC/I2S buffer callback

ดังนั้นไม่มีการเดา flash map หรือ hardware register จากรูป
