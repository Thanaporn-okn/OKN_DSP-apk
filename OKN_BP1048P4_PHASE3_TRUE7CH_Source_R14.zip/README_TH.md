# OKN BP1048P4 Phase3 TRUE7CH R14

R14 เดินหน้าจาก R13 โดยย้ายเป้าหมาย reverse-engineering ไปที่ **firmware/flashboot path ที่ใช้งานจริง** และปิดทางตันของ `SignalMerger.GainList` / legacy SigmaDSP helper ตามหลักฐาน Windows 2026 ที่ถอดได้แล้ว

## สิ่งที่ยังคงเดิม

- TRUE CH1..CH7 gain เป็น dedicated PCM gain stage หลัง EQ/crossover และก่อน physical sink
- **ไม่ใช้ EQ/Biquad gain ทำ Channel Volume**
- ช่วง -70..+6 dB, step 0.5 dB, linear amplitude Q2.14 + int16 saturation
- custom UFE IDs 22..28 สำหรับ `Channel1Volume..Channel7Volume` ใช้เฉพาะ firmware OKN ใหม่
- Android USB probe สำหรับ Samsung S25+ เป็น read-only เท่านั้น

## สิ่งใหม่ใน R14

- บันทึกหลักฐาน static จาก public BP10X SDK ว่า generic PC-upgrade handshake ใช้ HID Feature SET_REPORT `0x55`/`0xAA` และ handoff ไป flashboot ที่ address 0
- บันทึกว่าใน generic SDK, `0x55` เปรียบเทียบ 4 bytes หลัง command กับข้อมูลที่ app-header offset `0xB8` ของ app ซึ่ง generic linker วาง app ที่ `0x10000`
- บันทึกว่า generic SDK มี embedded flashboot 65,536 bytes และ linker วาง flashboot ที่ address 0
- หลักฐานด้านบนเป็น **family evidence เท่านั้น** ไม่ใช่ permission ให้ส่ง 55/AA ไปบอร์ด GoloPine
- เพิ่ม `FLASHBOOT_RESEARCH_STATE_R14.json` เพื่อบังคับ fail-closed จน exact production protocol/image/recovery ครบ
- เพิ่ม `inspect_mva_readonly.py` สำหรับวิเคราะห์ไฟล์ MVA แบบ offline/read-only เท่านั้น
- เพิ่ม R14 safety verifier ที่ตรวจว่า Android source ไม่มี USB control OUT / bulk write / SET_REPORT path
- แก้ packaging checksum: `SHA256SUMS.txt` ไม่ hash ตัวเอง และไม่นำ host-test binary เข้า ZIP
- ลบ safety guard รุ่นเก่าที่ stale ออกจาก release package เพื่อลด false failure

## สถานะสำคัญ

ยัง **ไม่มี** `.bin` / `.mva` ที่ปลอดภัยพอให้แฟลชบอร์ดจริง เพราะยังขาด exact GoloPine post-jump flashboot wire protocol, exact production image/container rules, stock backup/recovery และ exact final audio-buffer hook ของ 7 output buses
