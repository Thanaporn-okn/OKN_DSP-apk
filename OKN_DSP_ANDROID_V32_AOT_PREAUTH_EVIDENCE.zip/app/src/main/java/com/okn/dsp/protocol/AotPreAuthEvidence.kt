package com.okn.dsp.protocol

/**
 * V32 static evidence recovered directly from the user-provided GoloPine 250401 APK.
 * Offline only: this class never transmits BLE traffic and does not enable WriteGate.
 */
object AotPreAuthEvidence {
    private const val APK_LIBAPP_SIZE = 40436640
    private const val DIRECT_KEY_CANDIDATES = 1122
    private const val DIRECT_IV_CANDIDATES = 528
    private const val DIRECT_PAIRS_TESTED = 592416
    private const val HASH_STRING_COUNT = 176071

    fun report(): List<String> = buildList {
        add("AOT STATIC SOURCE: 1Android APP golopine tuning 250401.apk")
        add("lib/arm64-v8a/libapp.so size=$APK_LIBAPP_SIZE bytes • Flutter/Dart AOT")
        add("AUTH strings recovered: 'Error in authentication response data length, Exit' and ', RandKey='")
        add("CRYPTO strings recovered: AES/ • cfb8 • CFB-8 • CFB-128 • /CBC • /HKDF • /PBKDF2 • /CMAC • ECDH • secp256r1")
        add("CFB8 PROOF NOTE: with fixed AES key+IV, C[0] xor P[0] is constant because it uses AES(IV)[0]")
        add("For i>0 CFB8 feeds previous ciphertext bytes back into the shift register, so C[i] xor P[i] need NOT remain constant across sessions")
        add("Observed auth vectors: encRandKey[0] xor RandKey[0] = 0x5C for 4/4 sessions — this is CONSISTENT with one fixed pre-auth CFB8 initial state")
        add("Therefore V31 rejection applies only to a naive fixed 16-byte XOR mask; it does NOT reject fixed AES-CFB8 key/IV")
        add("APK literal/chunk sweep: keys=$DIRECT_KEY_CANDIDATES IVs=$DIRECT_IV_CANDIDATES directPairs=$DIRECT_PAIRS_TESTED • exact 16/16 decoder=NONE")
        add("Hash sweep: MD5/SHA-256/SHA-1 derived keys from $HASH_STRING_COUNT printable AOT strings against common IVs • exact decoder=NONE")
        add("Interpretation: pre-auth secret/IV is likely raw binary, assembled at runtime, or KDF/ECDH-derived rather than a simple printable/hex literal pair")
        add("NEXT STATIC TARGET: resolve the Dart AOT function that prints ', RandKey=' and trace the object-pool inputs passed into AES/CFB-8 init")
        add("LIVE WRITE LOCKED • no BLE packet is transmitted by this evidence lab")
    }
}
