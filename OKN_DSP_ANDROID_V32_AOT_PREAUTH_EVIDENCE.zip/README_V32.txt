OKN DSP Android V32 — AOT PRE-AUTH EVIDENCE

Changes from V31:
- Keeps all verified UFE/EQ48/post-auth AES-CFB8 self tests.
- Adds AotPreAuthEvidence and RUN AOT PRE-AUTH EVIDENCE.
- Corrects interpretation of the 0x5C first-byte invariant: it is expected for fixed-key/fixed-IV AES-CFB8 because feedback makes later keystream bytes session-dependent.
- Records direct static scan of the user-provided GoloPine 250401 APK/libapp.so.
- 592,416 direct printable/hex/chunk key-IV candidate pairs tested: no exact 16/16 RandKey decoder.
- MD5/SHA-derived keys from 176,071 AOT printable strings against common IVs: no exact decoder.
- LIVE WRITE remains locked.

Next reverse target: AOT function/object-pool path that logs ', RandKey=' and initializes AES/CFB-8.
