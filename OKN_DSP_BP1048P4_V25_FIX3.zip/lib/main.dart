import 'package:flutter/material.dart';
void main()=>runApp(const App());
class App extends StatelessWidget{
 const App({super.key});
 Widget build(BuildContext c)=>MaterialApp(
 home:Scaffold(
 backgroundColor:Color(0xff101018),
 body:Center(child:Text('OKN_DSP BP1048P4 V25 FIX3\nBUILD READY',
 style:TextStyle(color:Colors.cyan,fontSize:24)))
 ));
}
