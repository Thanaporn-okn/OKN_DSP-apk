# OKN DSP V9 Notify Diagnostic

V9 is a diagnostic build for the verified DSP BLE connection.

- Device: LE-GoIoPine_DSP_A
- Address: DC:E0:D9:88:C7:04
- Service: AB00
- Notify/Indicate targets: AB02 and AB03
- No DSP command payload is written to AB01.
- CCCD is configured sequentially, waiting for each descriptor-write callback before the next one.
- RX packets from AB02/AB03 are displayed.

The actual board-displayed Bluetooth name is shown in the app. This version uses the verified device only for this diagnostic stage.
