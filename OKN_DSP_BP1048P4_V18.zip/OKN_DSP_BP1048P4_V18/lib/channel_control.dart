// CH1-CH7 Volume EQ Delay HPF LPF control
