// V18 BP1048P4 TX RX Command Queue HEX Monitor
