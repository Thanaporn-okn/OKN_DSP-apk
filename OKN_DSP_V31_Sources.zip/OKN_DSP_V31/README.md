# OKN DSP V31 — Phase 2 live BLE/auth integration

Base UI: **V29/V30 accepted UI**. V31 keeps the current responsive Home / Mix / EQ design and imports only the verified real-device BLE/auth/session implementation recovered from the user-supplied V17 source set.

## What changed from V30

V30 intentionally stopped before live writes because the V35 proof did not independently describe how to recover the current-session RandKey from AUTH32. The supplied V17 source set contains that missing implementation and the original-app transport evidence.

Recovered V17 AUTH32 decoder:
- `typeId` = AUTH32 bytes 0..1, big-endian.
- `versionId` = AUTH32 bytes 2..3, big-endian.
- For type 53284, decrypt AUTH32 bytes 8..31 with AES/CFB8/NoPadding.
- Pre-auth key: `2AAF948632A59FF8F2B23E6E4193FD21`.
- IV: `01` repeated 16 bytes.
- Decrypted 24 bytes = 8-byte unique ID + 16-byte RandKey.
- Special type 53285 uses pre-auth key `10E7D2F443924938A28D759BAC0E9E22` exactly as recovered in V17.

The known V35 vector now passes end-to-end:
- AUTH32: `D024E38C00000000420DA6E8FDDF06895D514A274A2181DEB2F457CA70A60EC1`
- typeId: `53284`
- versionId: `58252`
- unique ID: `060708080D07405C`
- RandKey: `0168DEEB916838D752E0D696BB3655E6`
- first authenticated plaintext `661C0624` -> ciphertext `5DFCB7E5`

## Live functions enabled in V31

- BLE scan / auto-connect to matching GoloPine / DSP / OKN device names.
- AB00 service, AB01 WRITE WITHOUT RESPONSE, AB02 notifications.
- AUTH16 -> AUTH32 -> current-session RandKey -> independent continuous AES-CFB8 TX/RX streams.
- Real Device Description download and health gate before any audio-control write.
- Master Volume ID2 LIVE.
- Bass Volume ID8 LIVE.
- Bass Cutoff ID9 LIVE.
- 15-band EQ Gain LIVE only for hardware records qualified by the recovered V17 writer.
- Original-app style ~380 ms shared command scheduler with ID19/ID20/ID0/ID21 keepalive polling.
- Reset Global sends the three verified global controls when DSP is READY.
- Reset EQ sends qualified Gain resets only.

## Deliberately still locked

- `Volume Ch1-Ch7`: no verified standalone actuator mapping in the supplied Device Description/V17 source evidence.
- EQ Frequency/Q writes: the recovered V17 graphic-EQ writer preserves the live hardware Frequency/Q record and changes Gain only. V31 therefore does not claim Frequency/Q live control.
- Automatic permanent `SaveParams`: not introduced; the recovered source explicitly kept permanent save manual.

versionName: 31.0.0  
versionCode: 1031  
Phase: 2 — authenticated live-control integration
