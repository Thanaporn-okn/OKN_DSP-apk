package com.okn.dsp.protocol;

/** Offline vectors from the supplied V35 proof plus the recovered V17 pre-auth decoder. */
public final class ProtocolSelfTest {
    private ProtocolSelfTest() {}

    public static void runOrThrow() {
        String read19 = ByteCodec.toHex(UfeCodec.encodeRead(19, 0, 1));
        if (!"580000001300000001".equals(read19)) throw new IllegalStateException("read serializer mismatch: " + read19);

        byte[] auth32 = ByteCodec.hexToBytes("D024E38C00000000420DA6E8FDDF06895D514A274A2181DEB2F457CA70A60EC1");
        AuthResponseCodec.Decoded decoded = AuthResponseCodec.decode32(auth32);
        if (decoded.typeId != 53284) throw new IllegalStateException("AUTH type mismatch: " + decoded.typeId);
        if (decoded.versionId != 58252) throw new IllegalStateException("AUTH version mismatch: " + decoded.versionId);
        String uniqueId = ByteCodec.toHex(decoded.uniqueId);
        if (!"060708080D07405C".equals(uniqueId)) throw new IllegalStateException("UniqueId mismatch: " + uniqueId);
        String randHex = ByteCodec.toHex(decoded.randKey);
        if (!"0168DEEB916838D752E0D696BB3655E6".equals(randHex)) throw new IllegalStateException("RandKey mismatch: " + randHex);

        byte[] out = new SessionCrypto(decoded.randKey, true).update(ByteCodec.hexToBytes("661C0624"));
        String cipher = ByteCodec.toHex(out);
        if (!"5DFCB7E5".equals(cipher)) throw new IllegalStateException("AES/CFB8 vector mismatch: " + cipher);

        if (Phase2ProtocolBridge.eqBand(0, 0, 100f, 1f, 0f).length != 57)
            throw new IllegalStateException("EQ write packet length mismatch");

        if (!WriteGate.ENABLED) throw new IllegalStateException("V31 write gate unexpectedly disabled");
    }
}
