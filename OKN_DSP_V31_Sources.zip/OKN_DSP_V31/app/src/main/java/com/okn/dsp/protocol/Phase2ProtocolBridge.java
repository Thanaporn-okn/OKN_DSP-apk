package com.okn.dsp.protocol;

/**
 * V31 bridge from the accepted V29 UI values to verified UFE plaintext packets.
 * This class deliberately returns bytes only; it never sends BLE data unless the authenticated health-gated transport is ready.
 */
public final class Phase2ProtocolBridge {
    private Phase2ProtocolBridge() {}

    public static byte[] masterVolume(float db) { return UfeCodec.encodeFloat32Write(ProtocolProfile.MASTER_VOLUME, db); }
    public static byte[] bassVolume(float db) { return UfeCodec.encodeFloat32Write(ProtocolProfile.BASS_VOLUME, db); }
    public static byte[] bassCutoff(float hz) { return UfeCodec.encodeFloat32Write(ProtocolProfile.BASS_CUTOFF, hz); }

    public static byte[] eqBand(int channelIndex, int bandIndex, float frequencyHz, float q, float gainDb) {
        int actuator = ProtocolProfile.eqActuator(channelIndex);
        int offset = ProtocolProfile.eqBandOffset(bandIndex);
        return UfeCodec.encodeWrite(actuator, offset, EqBandCodec.encodePeaking(frequencyHz, q, gainDb));
    }

    public static byte[] readFloat32(int actuatorId) { return UfeCodec.encodeRead(actuatorId, 0, 4); }

    /** Not mapped by the supplied device descriptor; do not invent a standalone per-channel volume actuator. */
    public static byte[] channelVolumeNotYetMapped(int channelIndex, float db) {
        throw new UnsupportedOperationException("Per-channel Volume Ch1-Ch7 has no verified standalone actuator mapping in the supplied V35 descriptor");
    }

    public static boolean liveWriteReady() { return WriteGate.ENABLED; }
}
