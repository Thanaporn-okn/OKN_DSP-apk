package com.okn.dsp.protocol;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * V31 authentication decoder recovered from the verified V17 source set.
 * AUTH32 layout:
 *   typeId(BE16), versionId(BE16), reserved(4), encryptedPayload(24)
 * The encrypted payload decrypts to uniqueId(8) + RandKey(16).
 */
public final class AuthResponseCodec {
    private static final byte[] DEFAULT_PREAUTH_KEY = ByteCodec.hexToBytes("2AAF948632A59FF8F2B23E6E4193FD21");
    private static final byte[] TYPE_53285_PREAUTH_KEY = ByteCodec.hexToBytes("10E7D2F443924938A28D759BAC0E9E22");
    private static final byte[] IV = ByteCodec.hexToBytes("01010101010101010101010101010101");

    private AuthResponseCodec() {}

    public static Header parse32(byte[] bytes) {
        if (bytes == null || bytes.length != 32) throw new IllegalArgumentException("authentication response must be 32 bytes");
        byte[] f4 = new byte[4];
        byte[] encryptedPayload = new byte[24];
        System.arraycopy(bytes, 4, f4, 0, 4);
        System.arraycopy(bytes, 8, encryptedPayload, 0, 24);
        return new Header(ByteCodec.readU16be(bytes, 0), ByteCodec.readU16be(bytes, 2), f4, encryptedPayload);
    }

    public static Decoded decode32(byte[] bytes) {
        Header h = parse32(bytes);
        byte[] key = h.typeId == 53285 ? TYPE_53285_PREAUTH_KEY : DEFAULT_PREAUTH_KEY;
        try {
            Cipher cipher = Cipher.getInstance("AES/CFB8/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"), new IvParameterSpec(IV));
            byte[] plain = cipher.update(h.encryptedPayload);
            if (plain == null || plain.length != 24) throw new IllegalStateException("bad pre-auth plaintext");
            byte[] uniqueId = new byte[8];
            byte[] randKey = new byte[16];
            System.arraycopy(plain, 0, uniqueId, 0, 8);
            System.arraycopy(plain, 8, randKey, 0, 16);
            return new Decoded(h.typeId, h.versionId, uniqueId, randKey);
        } catch (Exception e) {
            throw new IllegalStateException("AUTH32 decode failed", e);
        }
    }

    public static final class Header {
        public final int typeId;
        public final int versionId;
        public final byte[] field4to7;
        public final byte[] encryptedPayload;

        Header(int typeId, int versionId, byte[] field4to7, byte[] encryptedPayload) {
            this.typeId = typeId;
            this.versionId = versionId;
            this.field4to7 = field4to7;
            this.encryptedPayload = encryptedPayload;
        }
    }

    public static final class Decoded {
        public final int typeId;
        public final int versionId;
        public final byte[] uniqueId;
        public final byte[] randKey;

        Decoded(int typeId, int versionId, byte[] uniqueId, byte[] randKey) {
            this.typeId = typeId;
            this.versionId = versionId;
            this.uniqueId = uniqueId;
            this.randKey = randKey;
        }
    }
}
