# OKN DSP V37 — Emergency Hardware-Safety Rollback

**Base:** exact V32 real-hardware-stable control implementation, not V33–V36.

V37 is an emergency rollback after real-device testing showed severe EQ pumping/warble and a DSP self-reboot while Frequency/Q were being changed by V33–V36. The original GoloPine application remains stable on the same hardware, so V37 stops the unsafe experimental F/Q paths instead of guessing another smoothing algorithm.

## Hardware control enabled

- Master Volume: LIVE (same verified path as V32)
- Bass Volume / Bass Cutoff: inherited verified scalar path
- EQ Gain Band: LIVE using the V32 one-write-at-a-time, latest-target-wins 45 ms lane
- EQ Frequency: **SAFE LOCK — UI/local state only, no DSP write**
- EQ Q: **SAFE LOCK — UI/local state only, no DSP write**
- Reset EQ: **SAFE LOCK — local reset only, no bulk DSP EQ writes**

The BLE/auth/session, protocol codec and EQ Gain transport are copied directly from V32. V37 intentionally does not contain the V33–V36 Frequency/Q smoothers or hardware reset sequence.

## Why this rollback is required

Real DSP testing established that V32 Master Volume and EQ Gain work correctly. Later experimental Frequency/Q/reset paths caused loud pumping/whistling and eventually a DSP reboot. Until the original-app behavior or the previously verified guarded 48-byte PEAKING procedure is migrated exactly, Frequency/Q and hardware Reset remain locked.

## Next engineering target

Reconstruct the original app's safe realtime F/Q behavior using the user's archived original app and the prior verified production EQ procedure: safe PEAKING type=12 only, full 48-byte record, controlled serialization, fresh descriptor verification, and exact rollback on verification failure. Do not re-enable F/Q from unverified interpolation logic.

## Version

- versionName: **37.0.0**
- versionCode: **1037**
- applicationId: `com.okn.dsp`

## Validation performed

- V32 BleManager byte-identical: PASS
- V32 DspProtocol byte-identical: PASS
- Protocol JVM self-test: PASS
- F/Q BLE calls absent from DspView: PASS
- Reset EQ bulk hardware send absent: PASS
- Internal SHA256 manifest: generated after final source freeze
- Full Android APK build: GitHub Actions authoritative path
