package com.okn.okn_dsp

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.app.ActivityCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val methods = "okn_dsp/methods"
    private val events = "okn_dsp/events"
    private var sink: EventChannel.EventSink? = null
    private var scanner: BluetoothLeScanner? = null
    private var gatt: BluetoothGatt? = null

    override fun configureFlutterEngine(engine: FlutterEngine) {
        super.configureFlutterEngine(engine)
        EventChannel(engine.dartExecutor.binaryMessenger, events).setStreamHandler(object : EventChannel.StreamHandler {
            override fun onListen(a: Any?, s: EventChannel.EventSink?) { sink = s }
            override fun onCancel(a: Any?) { sink = null }
        })
        MethodChannel(engine.dartExecutor.binaryMessenger, methods).setMethodCallHandler { call, result ->
            when (call.method) {
                "scan" -> {
                    if (!hasPermissions()) requestBlePermissions() else startScan()
                    result.success(null)
                }
                "connect" -> {
                    val address = call.argument<String>("address")
                    if (address == null) result.error("ADDRESS", "Missing Bluetooth address", null)
                    else { connect(address); result.success(null) }
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun hasPermissions() =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
        (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
         ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED)

    private fun requestBlePermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT), 2001)
    }

    private fun emit(m: Map<String, Any?>) = runOnUiThread { sink?.success(m) }

    @SuppressLint("MissingPermission")
    private fun startScan() {
        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val adapter = manager.adapter
        if (!adapter.isEnabled) {
            emit(mapOf("type" to "status", "message" to "กรุณาเปิด Bluetooth ของมือถือก่อน"))
            return
        }
        scanner = adapter.bluetoothLeScanner
        if (scanner == null) {
            emit(mapOf("type" to "status", "message" to "มือถือไม่รองรับ BLE Scanner"))
            return
        }
        emit(mapOf("type" to "status", "message" to "กำลังค้นหา BLE 10 วินาที..."))
        scanner?.startScan(null, ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build(), scanCallback)
        Handler(Looper.getMainLooper()).postDelayed({
            try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
            emit(mapOf("type" to "status", "message" to "ค้นหาเสร็จแล้ว — ถ้าไม่พบ ให้กดปุ่ม DSP ที่เคยพบ"))
        }, 10000)
    }

    private val scanCallback = object : ScanCallback() {
        @SuppressLint("MissingPermission")
        override fun onScanResult(type: Int, r: ScanResult) {
            val d = r.device
            val name = r.scanRecord?.deviceName ?: d.name ?: "ไม่ทราบชื่อ"
            emit(mapOf("type" to "device", "name" to name, "address" to d.address, "rssi" to r.rssi))
        }
        override fun onScanFailed(code: Int) =
            emit(mapOf("type" to "status", "message" to "BLE scan error: $code"))
    }

    @SuppressLint("MissingPermission")
    private fun connect(address: String) {
        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val device = manager.adapter.getRemoteDevice(address)
        gatt?.close()
        emit(mapOf("type" to "status", "message" to "กำลังเชื่อมต่อ $address ..."))
        gatt = device.connectGatt(this, false, callback, BluetoothDevice.TRANSPORT_LE)
    }

    private val callback = object : BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, state: Int) {
            if (state == BluetoothProfile.STATE_CONNECTED) {
                emit(mapOf("type" to "connected"))
                emit(mapOf("type" to "status", "message" to "เชื่อมต่อแล้ว กำลังอ่าน GATT..."))
                g.discoverServices()
            } else if (state == BluetoothProfile.STATE_DISCONNECTED) {
                emit(mapOf("type" to "disconnected"))
                emit(mapOf("type" to "status", "message" to "ตัดการเชื่อมต่อ (status=$status)"))
            }
        }

        @SuppressLint("MissingPermission")
        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            val out = StringBuilder("GATT STATUS: $status\nSERVICES: ${g.services.size}\n\n")
            for ((si, s) in g.services.withIndex()) {
                out.append("SERVICE ${si+1}: ${s.uuid}\n")
                for ((ci, c) in s.characteristics.withIndex()) {
                    val p = c.properties
                    val props = mutableListOf<String>()
                    if (p and BluetoothGattCharacteristic.PROPERTY_READ != 0) props.add("READ")
                    if (p and BluetoothGattCharacteristic.PROPERTY_WRITE != 0) props.add("WRITE")
                    if (p and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0) props.add("WRITE_NR")
                    if (p and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0) props.add("NOTIFY")
                    if (p and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0) props.add("INDICATE")
                    out.append("  CHAR ${ci+1}: ${c.uuid}\n")
                    out.append("    PROPERTIES: ${props.joinToString(", ")}\n")
                    for (d in c.descriptors) out.append("    DESC: ${d.uuid}\n")
                    if (p and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0 ||
                        p and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0) {
                        g.setCharacteristicNotification(c, true)
                        for (d in c.descriptors) {
                            if (d.uuid.toString().lowercase() == "00002902-0000-1000-8000-00805f9b34fb") {
                                d.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                                g.writeDescriptor(d)
                            }
                        }
                    }
                }
                out.append("\n")
            }
            emit(mapOf("type" to "gatt", "text" to out.toString()))
            emit(mapOf("type" to "status", "message" to "อ่าน GATT และเปิด Notify แล้ว — ไม่ได้ส่งคำสั่ง DSP"))
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            val hex = c.value.joinToString(" ") { "%02X".format(it) }
            emit(mapOf("type" to "rx", "characteristic" to c.uuid.toString(), "data" to hex))
        }
    }
}
