#include "../src/persist/okn_persistence.h"
#include "../src/runtime/okn_runtime.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

static uint8_t slots[OKN_PERSIST_SLOT_COUNT][OKN_PERSIST_IMAGE_SIZE];
static size_t slot_len[OKN_PERSIST_SLOT_COUNT];

static int ram_read(unsigned slot, uint8_t *out, size_t cap, size_t *out_len) {
    if (slot >= OKN_PERSIST_SLOT_COUNT || !out || !out_len) return OKN_ERR_ARG;
    if (slot_len[slot] == 0u) { *out_len=0u; return OKN_ERR_STORAGE; }
    if (cap < slot_len[slot]) return OKN_ERR_BUFFER;
    memcpy(out,slots[slot],slot_len[slot]);
    *out_len=slot_len[slot];
    return OKN_OK;
}
static int ram_write(unsigned slot, const uint8_t *data, size_t len) {
    if (slot >= OKN_PERSIST_SLOT_COUNT || !data || len > sizeof(slots[slot])) return OKN_ERR_ARG;
    memcpy(slots[slot],data,len); slot_len[slot]=len; return OKN_OK;
}
static const okn_storage_io_t RAM={ram_read,ram_write};

int main(void) {
    assert(okn_crc32_ieee((const uint8_t*)"123456789",9u)==0xCBF43926u);

    okn_controller_t ctl;
    okn_controller_init(&ctl);
    assert(okn_set_master_gain(&ctl.state,-4.0f)==OKN_OK);
    assert(okn_set_channel_gain(&ctl.state,6,-8.5f)==OKN_OK);
    assert(okn_set_channel_delay(&ctl.state,6,12.25f)==OKN_OK);
    assert(okn_set_channel_mute(&ctl.state,2,true)==OKN_OK);
    assert(okn_set_peq_band(&ctl.state,1,14,true,OKN_FILTER_NOTCH,3150.0f,0.0f,3.0f)==OKN_OK);

    uint8_t image[OKN_PERSIST_IMAGE_SIZE]; size_t n=0u;
    assert(okn_persist_encode(&ctl.state,42u,image,sizeof(image),&n)==OKN_OK);
    assert(n==OKN_PERSIST_IMAGE_SIZE);

    okn_dsp_state_t decoded; uint32_t gen=0u;
    assert(okn_persist_decode(image,n,&decoded,&gen)==OKN_OK);
    assert(gen==42u);
    assert(fabsf(decoded.master_gain_db+4.0f)<0.0001f);
    assert(fabsf(decoded.ch[6].gain_db+8.5f)<0.0001f);
    assert(fabsf(decoded.ch[6].delay_ms-12.25f)<0.0001f);
    assert(decoded.ch[2].mute);
    assert(decoded.ch[1].peq[14].type==OKN_FILTER_NOTCH);

    /* Corruption must be rejected. */
    image[OKN_PERSIST_HEADER_SIZE+20u]^=0x01u;
    assert(okn_persist_decode(image,n,&decoded,&gen)==OKN_ERR_STATE_CRC);

    memset(slots,0,sizeof(slots)); memset(slot_len,0,sizeof(slot_len));
    unsigned slot=99u;
    assert(okn_runtime_save_verified(&ctl,&RAM,&gen,&slot)==OKN_OK);
    assert(gen==1u && slot==0u);

    assert(okn_set_channel_gain(&ctl.state,0,-3.0f)==OKN_OK);
    assert(okn_runtime_save_verified(&ctl,&RAM,&gen,&slot)==OKN_OK);
    assert(gen==2u && slot==1u);

    okn_controller_t boot; int restored=0;
    assert(okn_runtime_restore_or_defaults(&boot,&RAM,&gen,&slot,&restored)==OKN_OK);
    assert(restored==1 && gen==2u && slot==1u);
    assert(fabsf(boot.state.ch[0].gain_db+3.0f)<0.0001f);
    assert(boot.master_dirty && boot.channel_dirty_mask==0x7Fu);

    /* Break newest slot: loader must roll back to older valid generation. */
    slots[1][OKN_PERSIST_HEADER_SIZE+3u]^=0x80u;
    assert(okn_runtime_restore_or_defaults(&boot,&RAM,&gen,&slot,&restored)==OKN_OK);
    assert(restored==1 && gen==1u && slot==0u);
    assert(fabsf(boot.state.ch[0].gain_db-0.0f)<0.0001f);

    /* Empty storage leaves initialized safe defaults; caller gets explicit failure. */
    memset(slot_len,0,sizeof(slot_len));
    boot.state.master_gain_db=9.0f;
    restored=1; gen=99u; slot=99u;
    assert(okn_runtime_restore_or_defaults(&boot,&RAM,&gen,&slot,&restored)==OKN_ERR_STORAGE);
    assert(restored==0 && gen==0u);
    assert(fabsf(boot.state.master_gain_db)<0.0001f);

    puts("ALL V24 PERSISTENCE TESTS PASS");
    return 0;
}
