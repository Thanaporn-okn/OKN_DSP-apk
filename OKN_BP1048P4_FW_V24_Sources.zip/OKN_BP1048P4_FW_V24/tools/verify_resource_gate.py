#!/usr/bin/env python3
from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[1]
m=json.loads((root/"resource_requirements.json").read_text())
errors=[]
if m.get("schema") != 1: errors.append("resource schema must be 1")
if m.get("project_version") != 24: errors.append("resource project_version must be 24")
if m.get("policy") != "NO_TARGET_RAM_CAPACITY_OR_PLACEMENT_INFERENCE": errors.append("resource policy mismatch")
d=m.get("delay",{})
if d.get("arena_samples") != 16807: errors.append("reference delay arena sample count mismatch")
if d.get("arena_bytes_reference") != 67228: errors.append("reference delay arena byte count mismatch")
if d.get("storage") != "caller-owned external arena": errors.append("delay arena must be caller-owned")
tm=m.get("target_memory",{})
if tm.get("bp1048p4_ram_capacity_bytes") is not None: errors.append("must not guess BP1048P4 RAM capacity")
for k in ("exact_ram_capacity_verified","delay_arena_placement_verified","persistence_workspace_verified"):
    if tm.get(k) is not False: errors.append(k+" must remain false until exact target proof")
if errors:
    [print("BLOCKED:",e) for e in errors]; sys.exit(1)
print("PASS: V24 resource gate is explicit and no BP1048P4 RAM capacity/placement is inferred")
