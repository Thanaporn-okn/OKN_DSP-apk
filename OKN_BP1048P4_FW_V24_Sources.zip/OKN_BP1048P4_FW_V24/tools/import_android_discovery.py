#!/usr/bin/env python3
"""Import one validated V24 Android discovery capture into the local evidence bundle.

This copies bytes and updates JSON metadata only. It never opens a USB/BLE/serial
transport and cannot authorize hardware or mobile flashing.
"""
from __future__ import annotations
from pathlib import Path
import argparse, hashlib, json, re, shutil
from android_discovery_capture import validate_capture_file

KIND={"usb_host":"android_usb_enumeration","ble":"android_ble_advertisement","serial_enumeration":"android_serial_enumeration"}
ID_RE=re.compile(r"^[A-Za-z0-9_.-]{1,64}$")

def sha256_file(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()

def import_capture(root: Path, capture_path: Path, capture_id: str|None=None) -> dict:
    root=Path(root).resolve(); capture_path=Path(capture_path)
    if capture_path.is_symlink(): raise ValueError('symlink input capture forbidden')
    vr=validate_capture_file(capture_path)
    if not vr.get('ok'): raise ValueError('capture invalid: '+'; '.join(vr.get('errors',[])))
    manifest_path=root/'hardware_discovery_manifest.json'
    m=json.loads(manifest_path.read_text())
    if m.get('project_version')!=24 or m.get('state') not in ('LOCKED_NO_CAPTURE','CAPTURE_READY_FOR_REVIEW_NOT_AUTHORIZED'):
        raise ValueError('hardware discovery manifest is not a V24 intake manifest')
    evidence_dir=root/m.get('bundle_root','hardware_probe_evidence'); evidence_dir.mkdir(parents=True,exist_ok=True)
    raw_sha=sha256_file(capture_path); canonical=vr['canonical_sha256']; transport=vr['transport']
    name=f"android-{transport}-{canonical[:16]}.json"; dest=evidence_dir/name
    existing=next((r for r in m.get('captures',[]) if r.get('sha256')==raw_sha and r.get('canonical_sha256')==canonical),None)
    if existing:
        return {'imported':False,'duplicate':True,'record':existing}
    cid=capture_id or f"android-{transport}-{canonical[:12]}"
    if not ID_RE.fullmatch(cid): raise ValueError('capture id must use A-Z a-z 0-9 _ . - and be <=64 chars')
    if any(r.get('id')==cid for r in m.get('captures',[])): raise ValueError('capture id already exists')
    if dest.exists() and sha256_file(dest)!=raw_sha: raise ValueError('destination collision')
    shutil.copyfile(capture_path,dest)
    rec={
      'id':cid,'kind':KIND[transport],'path':name,'sha256':raw_sha,
      'source':'android-discovery-capture-v1','reviewed':False,'read_only':True,
      'commands_sent':[],'write_attempted':False,
      'capture_format':'android_discovery_capture_v1','canonical_sha256':canonical,
    }
    m.setdefault('captures',[]).append(rec)
    m['state']='CAPTURE_READY_FOR_REVIEW_NOT_AUTHORIZED'
    # These authorization fields are deliberately never changed by import.
    m['automatic_authorization']=False; m['android_host_transport_verified']=False
    manifest_path.write_text(json.dumps(m,indent=2)+'\n')
    return {'imported':True,'duplicate':False,'record':rec}

def main()->int:
    ap=argparse.ArgumentParser(description='Import a validated Android read-only capture; no device I/O.')
    ap.add_argument('capture'); ap.add_argument('--root',default='.'); ap.add_argument('--id')
    a=ap.parse_args()
    try: r=import_capture(Path(a.root),Path(a.capture),a.id)
    except Exception as e:
        print('BLOCKED:'+str(e)); return 1
    print('ANDROID_DISCOVERY_IMPORT='+('DUPLICATE' if r['duplicate'] else 'IMPORTED_FOR_REVIEW'))
    print('HARDWARE_AUTHORIZATION=UNCHANGED_FALSE')
    return 0
if __name__=='__main__': raise SystemExit(main())
