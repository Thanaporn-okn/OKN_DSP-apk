#!/usr/bin/env python3
from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'evidence_manifest.json').read_text())
errors=[]
if m.get('schema')!=4: errors.append('evidence schema must be 4')
if m.get('project_version')!=24: errors.append('project_version must be 24')
if m.get('target')!='BP1048P4' or m.get('board')!='GoloPine 7CH': errors.append('target/board mismatch')
if m.get('policy')!='FAIL_CLOSED_NO_INFERENCE': errors.append('policy mismatch')
if m.get('hardware_authorized') is not False: errors.append('hardware_authorized must be false')
req=m.get('required_exact_evidence',{})
if any(bool(v) for v in req.values()): errors.append('V24 exact evidence flags must all remain false')
prov=m.get('provenance',{})
if prov.get('previous_source_sha256')!='24bea15f5552cab0e6fac591d0d194029bb843658f1be8220f10e1c29dcb21a5': errors.append('V23 source provenance mismatch')
if prov.get('validation_zip_sha256')!='edb5cefe26993deecb595effd5c9f63341dc6db423e026e44d32abe7a2319c31': errors.append('V23 validation provenance mismatch')
if not any(o.get('id')=='v23-ci-validation' for o in m.get('observations',[])): errors.append('V23 CI observation missing')
for ob in m.get('observations',[]):
    if ob.get('authorizes') not in ([],None): errors.append('observations may not authorize hardware in V24')
if errors:
    [print('BLOCKED:',e) for e in errors]; sys.exit(1)
print('PASS: V24 evidence manifest is internally consistent and non-authorizing')
