# OKN_BP1048P4_FW_V24

V24 preserves the V23 portable DSP/control, read-only Android discovery, fingerprint and human-review boundaries, and adds an **Immediate-Predecessor Provenance Chain**. The source revision must point to exactly V23, and the V23 source ZIP hash plus uploaded GitHub validation hash must agree across the firmware manifest, evidence manifest, CI observation and `provenance_chain_manifest.json`.

## What V24 adds

- `provenance_chain_manifest.json` with a strict `current -> current-1` rule.
- SHA-256 binding to the V23 source ZIP and the actual uploaded V23 validation ZIP.
- Cross-checking between firmware provenance, evidence provenance and the V23 CI observation.
- Regression tests that reject version skips, stale/tampered hashes and missing predecessor observations.
- Correction of the V23 manifest lineage bug where `previous_version` was incorrectly reported as 23 while the referenced source was V22. V24 records its own immediate predecessor correctly as V23.

The wire frame remains Protocol V2. Hardware authorization remains false. No programmer packet, address, pin sequence, boot command, `.bin` or `.img` is added.

See `docs/PROVENANCE_CHAIN_V24.md` for the lineage contract.

