package com.okn.dsp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Locale;

/**
 * V20 Phase 1 UI (reference-layout match + responsive full-screen).
 *
 * Four full-screen pages based on the uploaded reference: Home, Mix, EQ and
 * Crossover. Every visible control is interactive and updates the UI immediately.
 * This class intentionally performs no BLE/DSP transport in Phase 1.
 */
final class DspView extends View {
    private static final float W = 786f;
    private static final float H = 1340f;
    private static final float NAV_H = 116f;

    private static final int PAGE_HOME = 0;
    private static final int PAGE_MIX = 1;
    private static final int PAGE_EQ = 2;
    private static final int PAGE_XOVER = 3;

    private static final int DRAG_NONE = -1;
    private static final int DRAG_MIX_BASE = 0;      // 0..5
    private static final int DRAG_EQ_GRAPH = 20;
    private static final int DRAG_EQ_FREQ = 21;
    private static final int DRAG_EQ_GAIN = 22;
    private static final int DRAG_EQ_Q = 23;
    private static final int DRAG_EQ_OUTPUT = 24;
    private static final int DRAG_HP = 30;
    private static final int DRAG_LP = 31;
    private static final int DRAG_DELAY = 32;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final DspState state = new DspState();

    private int page = PAGE_HOME;
    private int dragMode = DRAG_NONE;
    private float scaleX = 1f;
    private float scaleY = 1f;
    private float viewportW = W;
    private float viewportH = H;
    private float contentLeft = 0f;
    private boolean renderFault = false;
    private String renderFaultName = "";

    private final int BG = Color.rgb(5, 14, 24);
    private final int BG2 = Color.rgb(8, 22, 35);
    private final int PANEL = Color.rgb(15, 30, 43);
    private final int PANEL_2 = Color.rgb(17, 35, 50);
    private final int BORDER = Color.rgb(31, 54, 70);
    private final int TRACK = Color.rgb(42, 61, 74);
    private final int CYAN = Color.rgb(38, 202, 232);
    private final int CYAN_2 = Color.rgb(0, 155, 205);
    private final int WHITE = Color.rgb(241, 246, 249);
    private final int SUB = Color.rgb(158, 173, 184);
    private final int GREEN = Color.rgb(43, 220, 106);
    private final int RED = Color.rgb(242, 69, 74);
    private final int BLUE = Color.rgb(39, 137, 232);

    DspView(Context context) {
        super(context);
        // Keep the platform default hardware renderer. A full-screen software layer
        // can consume a large bitmap on high-resolution phones/tablets.
        setLayerType(View.LAYER_TYPE_NONE, null);
        setFocusable(true);
        setClickable(true);
        setHapticFeedbackEnabled(false);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        if (renderFault) {
            drawRenderFault(canvas);
            return;
        }

        int checkpoint = canvas.save();
        try {
            calculateViewport();

            canvas.drawColor(BG);
            canvas.scale(scaleX, scaleY);
            drawBackdrop(canvas);

            canvas.save();
            canvas.translate(contentLeft, 0f);
            if (page == PAGE_HOME) drawHome(canvas);
            else if (page == PAGE_MIX) drawMix(canvas);
            else if (page == PAGE_EQ) drawEq(canvas);
            else drawCrossover(canvas);
            canvas.restore();

            drawBottomNav(canvas);
        } catch (RuntimeException e) {
            renderFault = true;
            renderFaultName = e.getClass().getSimpleName();
        } finally {
            canvas.restoreToCount(checkpoint);
        }

        if (renderFault) drawRenderFault(canvas);
    }

    private void drawRenderFault(Canvas canvas) {
        canvas.drawColor(BG);
        Paint safe = new Paint(Paint.ANTI_ALIAS_FLAG);
        safe.setColor(WHITE);
        safe.setTextAlign(Paint.Align.CENTER);
        safe.setTypeface(Typeface.DEFAULT_BOLD);
        safe.setTextSize(Math.max(34f, getWidth() * 0.055f));
        float cx = getWidth() * 0.5f;
        float cy = getHeight() * 0.46f;
        canvas.drawText("OKN_DSP V20", cx, cy, safe);
        safe.setTypeface(Typeface.DEFAULT);
        safe.setColor(SUB);
        safe.setTextSize(Math.max(22f, getWidth() * 0.035f));
        canvas.drawText("UI render protection active", cx, cy + 56f, safe);
        if (!renderFaultName.isEmpty()) {
            canvas.drawText(renderFaultName, cx, cy + 102f, safe);
        }
    }

    private void calculateViewport() {
        if (getWidth() <= 0 || getHeight() <= 0) return;
        // V20 deliberately maps the logical UI to the full physical display.
        // The previous uniform-width scaling left a large unused vertical area on
        // modern tall phones. Separate X/Y scales keep every page edge-to-edge
        // while retaining the same logical hit targets on phones and tablets.
        scaleX = getWidth() / W;
        scaleY = getHeight() / H;
        if (scaleX <= 0f || !Float.isFinite(scaleX)) scaleX = 1f;
        if (scaleY <= 0f || !Float.isFinite(scaleY)) scaleY = 1f;
        viewportW = W;
        viewportH = H;
        contentLeft = 0f;
    }

    private void drawBackdrop(Canvas c) {
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0, 0, viewportW, viewportH,
                Color.rgb(9, 23, 36), Color.rgb(3, 10, 18), Shader.TileMode.CLAMP));
        c.drawRect(0, 0, viewportW, viewportH, p);
        p.setShader(null);
    }

    private float navTop() {
        return viewportH - NAV_H;
    }

    // ---------------------------------------------------------------------
    // HOME
    // ---------------------------------------------------------------------

    private void drawHome(Canvas c) {
        text(c, "DSP 7 Ch", 40, 72, 37, WHITE, true, Paint.Align.LEFT);
        text(c, "Pure Sound. Total Control.", 40, 103, 18, SUB, false, Paint.Align.LEFT);
        drawGear(c, 724, 74, WHITE);

        // Device connection card.
        roundPanel(c, 26, 132, 734, 175, 20, PANEL, BORDER);
        drawBluetoothBadge(c, 101, 220, state.demoConnected);
        p.setColor(state.demoConnected ? GREEN : Color.rgb(128, 143, 153));
        c.drawCircle(190, 190, 10, p);
        text(c, state.demoConnected ? "Device Connected" : "Device Disconnected", 215, 198, 23, WHITE, true, Paint.Align.LEFT);
        text(c, "DSP 7 Ch", 215, 231, 18, SUB, false, Paint.Align.LEFT);
        text(c, state.demoConnected ? "Ready for audio processing" : "Tap to reconnect", 215, 263, 16, SUB, false, Paint.Align.LEFT);
        text(c, "›", 716, 232, 43, SUB, false, Paint.Align.CENTER);

        // DSP information card.
        roundPanel(c, 26, 327, 734, 270, 20, PANEL, BORDER);
        drawDspBox(c, 64, 405, 260, 130);
        text(c, "DSP 7 Ch", 404, 382, 26, WHITE, true, Paint.Align.LEFT);
        text(c, "7 Channel Digital Signal Processor", 404, 414, 17, SUB, false, Paint.Align.LEFT);
        infoPair(c, "Firmware", "v1.2.0", 404, 456);
        infoPair(c, "Input Source", "Bluetooth", 404, 489);
        infoPair(c, "Sample Rate", "48 kHz", 404, 522);
        infoPair(c, "Status", "Normal", 404, 555);

        // Feature cards.
        float featureY = 620f;
        float featureW = 226f;
        featureCard(c, 26, featureY, featureW, 178, "Mix", "Volume & Tone", 0);
        featureCard(c, 280, featureY, featureW, 178, "EQ", "7 Ch Equalizer", 1);
        featureCard(c, 534, featureY, featureW, 178, "Crossover", "Filter & Delay", 2);

        // Banner pinned near bottom navigation while staying below feature cards.
        float by = Math.max(825f, navTop() - 160f);
        roundPanel(c, 26, by, 734, 112, 17, Color.rgb(11, 26, 39), BORDER);
        text(c, "Better Sound", 52, by + 45, 24, WHITE, false, Paint.Align.LEFT);
        text(c, "A Brighter Drive", 52, by + 75, 20, SUB, false, Paint.Align.LEFT);
        drawWave(c, 330, by + 58, 300, 36, CYAN_2);
        text(c, "DSP 7 Ch", 716, by + 49, 16, SUB, true, Paint.Align.RIGHT);
        text(c, "FOR A BETTER TOMORROW", 716, by + 74, 10, SUB, false, Paint.Align.RIGHT);
    }

    private void featureCard(Canvas c, float x, float y, float w, float h, String title, String sub, int type) {
        roundPanel(c, x, y, w, h, 18, PANEL_2, BORDER);
        if (type == 0) drawMixIcon(c, x + w / 2f, y + 62, CYAN);
        else if (type == 1) drawEqIcon(c, x + w / 2f, y + 62, CYAN);
        else drawCrossoverIcon(c, x + w / 2f, y + 62, CYAN);
        text(c, title, x + w / 2f, y + 119, 22, WHITE, false, Paint.Align.CENTER);
        text(c, sub, x + w / 2f, y + 146, 14, SUB, false, Paint.Align.CENTER);
    }

    // ---------------------------------------------------------------------
    // MIX
    // ---------------------------------------------------------------------

    private void drawMix(Canvas c) {
        drawPageHeader(c, "Mix", false);
        String[] labels = {"Master Volume", "Bass Volume", "Bass Cutoff", "Bass Boost", "Middle Boost", "Treble Boost"};
        for (int i = 0; i < 6; i++) {
            float y = 126 + i * 174f;
            roundPanel(c, 26, y, 734, 150, 20, PANEL, BORDER);
            drawMixRowIcon(c, 70, y + 74, i, WHITE);
            text(c, labels[i], 122, y + 52, 21, WHITE, false, Paint.Align.LEFT);
            text(c, mixValueText(i), 718, y + 52, 21, WHITE, false, Paint.Align.RIGHT);
            drawMixSlider(c, i, 124, y + 87, 680);
            text(c, mixMinText(i), 124, y + 124, 13, SUB, false, Paint.Align.LEFT);
            text(c, mixMaxText(i), 680, y + 124, 13, SUB, false, Paint.Align.RIGHT);
        }
    }

    private void drawMixSlider(Canvas c, int index, float x0, float cy, float x1) {
        float frac = mixFraction(index);
        drawSlider(c, x0, cy, x1, frac, CYAN, true);
    }

    private float mixFraction(int index) {
        if (index == 0) return state.masterPercent / 100f;
        if (index == 1) return state.bassPercent / 100f;
        if (index == 2) return logFraction(state.bassCutoffHz, 20f, 300f);
        float v = index == 3 ? state.bassBoostDb : index == 4 ? state.middleBoostDb : state.trebleBoostDb;
        return (v + 12f) / 24f;
    }

    private String mixValueText(int index) {
        if (index == 0) return DspState.percent(state.masterPercent);
        if (index == 1) return DspState.percent(state.bassPercent);
        if (index == 2) return String.format(Locale.US, "%.0f Hz", state.bassCutoffHz);
        float v = index == 3 ? state.bassBoostDb : index == 4 ? state.middleBoostDb : state.trebleBoostDb;
        return String.format(Locale.US, "%+.0f dB", v);
    }

    private String mixMinText(int index) {
        if (index <= 1) return "0%";
        if (index == 2) return "20 Hz";
        return "-12 dB";
    }

    private String mixMaxText(int index) {
        if (index <= 1) return "100%";
        if (index == 2) return "300 Hz";
        return "+12 dB";
    }

    // ---------------------------------------------------------------------
    // EQ
    // ---------------------------------------------------------------------

    private void drawEq(Canvas c) {
        drawPageHeader(c, "EQ", true);
        drawChannelTabs(c, 24, 118, state.eqChannel, true);

        // Graph.
        float gx = 78, gy = 218, gw = 672, gh = 324;
        drawEqGrid(c, gx, gy, gw, gh);
        drawEqCurve(c, gx, gy, gw, gh);
        text(c, "Frequency (Hz)", gx + gw / 2f, gy + gh + 46, 15, SUB, false, Paint.Align.CENTER);

        // Band navigation and three editable parameters.
        roundPanel(c, 26, 602, 734, 300, 20, PANEL, BORDER);
        text(c, "‹", 206, 651, 36, SUB, false, Paint.Align.CENTER);
        text(c, "Band " + (state.selectedBand + 1) + " / 15", 393, 649, 19, WHITE, true, Paint.Align.CENTER);
        text(c, "›", 580, 651, 36, SUB, false, Paint.Align.CENTER);

        int ch = state.eqChannel;
        int b = state.selectedBand;
        drawEqParam(c, 50, 686, 213, "Frequency", DspState.hz(state.eqFreqHz[ch][b]), 20f, 20000f,
                logFraction(state.eqFreqHz[ch][b], 20f, 20000f), "20 Hz", "20 kHz");
        drawEqParam(c, 286, 686, 213, "Gain", DspState.db(state.eqGainDb[ch][b]), -12f, 12f,
                (state.eqGainDb[ch][b] + 12f) / 24f, "-12 dB", "+12 dB");
        drawEqParam(c, 522, 686, 213, "Q (Quality Factor)", String.format(Locale.US, "%.1f", state.eqQ[ch][b]), 0.1f, 10f,
                (state.eqQ[ch][b] - 0.1f) / 9.9f, "0.1", "10.0");

        // Output gain.
        roundPanel(c, 26, 928, 734, 126, 20, PANEL, BORDER);
        drawSpeaker(c, 64, 988, SUB);
        text(c, "Output Gain (" + DspState.CHANNELS_SHORT[ch] + ")", 108, 978, 18, WHITE, false, Paint.Align.LEFT);
        text(c, DspState.db(state.outputGainDb[ch]), 718, 978, 18, WHITE, false, Paint.Align.RIGHT);
        drawSlider(c, 312, 1013, 676, (state.outputGainDb[ch] + 12f) / 24f, CYAN, true);
        text(c, "-12 dB", 312, 1042, 12, SUB, false, Paint.Align.LEFT);
        text(c, "+12 dB", 676, 1042, 12, SUB, false, Paint.Align.RIGHT);

        // Preset buttons.
        button(c, 26, 1080, 354, 82, "▣   Save Preset", false);
        button(c, 406, 1080, 354, 82, "▱   Load Preset", false);
    }

    private void drawChannelTabs(Canvas c, float x, float y, int selected, boolean eq) {
        float gap = 7f;
        float w = (738f - gap * 6f) / 7f;
        for (int i = 0; i < 7; i++) {
            float xx = x + i * (w + gap);
            boolean sel = i == selected;
            roundPanel(c, xx, y, w, 62, 12, sel ? CYAN_2 : PANEL, sel ? CYAN : BORDER);
            text(c, DspState.CHANNELS_SHORT[i], xx + w / 2f, y + 39, 17, sel ? WHITE : SUB, true, Paint.Align.CENTER);
        }
    }

    private void drawEqGrid(Canvas c, float gx, float gy, float gw, float gh) {
        p.setColor(Color.rgb(7, 20, 30));
        c.drawRect(gx, gy, gx + gw, gy + gh, p);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(1f);
        stroke.setColor(Color.rgb(30, 50, 62));
        for (int i = 0; i <= 12; i++) {
            float x = gx + gw * i / 12f;
            c.drawLine(x, gy, x, gy + gh, stroke);
        }
        for (int i = 0; i <= 8; i++) {
            float y = gy + gh * i / 8f;
            c.drawLine(gx, y, gx + gw, y, stroke);
        }
        String[] ylabels = {"+12", "+6", "0", "-6", "-12"};
        for (int i = 0; i < 5; i++) {
            float y = gy + gh * i / 4f + 5;
            text(c, ylabels[i], gx - 16, y, 13, SUB, false, Paint.Align.RIGHT);
        }
        float[] ticks = {20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000};
        String[] tl = {"20", "50", "100", "200", "500", "1K", "2K", "5K", "10K", "20K"};
        for (int i = 0; i < ticks.length; i++) {
            float x = gx + logFraction(ticks[i], 20, 20000) * gw;
            text(c, tl[i], x, gy + gh + 24, 12, SUB, false, Paint.Align.CENTER);
        }
    }

    private void drawEqCurve(Canvas c, float gx, float gy, float gw, float gh) {
        int ch = state.eqChannel;
        Integer[] order = new Integer[DspState.BANDS];
        for (int i = 0; i < order.length; i++) order[i] = i;
        Arrays.sort(order, Comparator.comparingDouble(i -> state.eqFreqHz[ch][i]));

        Path fill = new Path();
        Path line = new Path();
        float firstX = 0f;
        float lastX = 0f;
        for (int n = 0; n < order.length; n++) {
            int b = order[n];
            float x = gx + logFraction(state.eqFreqHz[ch][b], 20f, 20000f) * gw;
            float y = gy + (12f - state.eqGainDb[ch][b]) / 24f * gh;
            if (n == 0) {
                line.moveTo(x, y);
                fill.moveTo(x, gy + gh);
                fill.lineTo(x, y);
                firstX = x;
            } else {
                line.lineTo(x, y);
                fill.lineTo(x, y);
            }
            lastX = x;
        }
        fill.lineTo(lastX, gy + gh);
        fill.lineTo(firstX, gy + gh);
        fill.close();
        p.setShader(new LinearGradient(0, gy, 0, gy + gh,
                Color.argb(115, 25, 203, 223), Color.argb(0, 25, 203, 223), Shader.TileMode.CLAMP));
        c.drawPath(fill, p);
        p.setShader(null);
        stroke.setColor(CYAN);
        stroke.setStrokeWidth(4f);
        stroke.setStyle(Paint.Style.STROKE);
        c.drawPath(line, stroke);

        for (int b = 0; b < DspState.BANDS; b++) {
            float x = gx + logFraction(state.eqFreqHz[ch][b], 20f, 20000f) * gw;
            float y = gy + (12f - state.eqGainDb[ch][b]) / 24f * gh;
            p.setColor(b == state.selectedBand ? CYAN : WHITE);
            c.drawCircle(x, y, b == state.selectedBand ? 9f : 6f, p);
        }
    }

    private void drawEqParam(Canvas c, float x, float y, float w, String title, String value,
                             float min, float max, float frac, String left, String right) {
        roundPanel(c, x, y, w, 185, 15, PANEL_2, BORDER);
        text(c, title, x + 17, y + 33, title.length() > 14 ? 14 : 16, WHITE, false, Paint.Align.LEFT);
        text(c, value, x + 17, y + 63, 18, WHITE, true, Paint.Align.LEFT);
        drawSlider(c, x + 18, y + 100, x + w - 18, frac, CYAN, true);
        text(c, left, x + 18, y + 137, 11, SUB, false, Paint.Align.LEFT);
        text(c, right, x + w - 18, y + 137, 11, SUB, false, Paint.Align.RIGHT);
    }

    // ---------------------------------------------------------------------
    // CROSSOVER
    // ---------------------------------------------------------------------

    private void drawCrossover(Canvas c) {
        drawPageHeader(c, "Crossover", false);
        int ch = state.crossoverChannel;
        roundPanel(c, 628, 42, 108, 56, 12, PANEL, BORDER);
        text(c, DspState.CHANNELS_SHORT[ch] + "  ▾", 682, 78, 17, WHITE, false, Paint.Align.CENTER);

        float gx = 76, gy = 158, gw = 674, gh = 326;
        drawCrossoverGraph(c, gx, gy, gw, gh, ch);
        text(c, "Frequency (Hz)", gx + gw / 2f, gy + gh + 42, 14, SUB, false, Paint.Align.CENTER);

        drawFilterCard(c, 26, 554, 734, 208, true, ch);
        drawFilterCard(c, 26, 786, 734, 208, false, ch);

        roundPanel(c, 26, 1018, 734, 146, 20, PANEL, BORDER);
        drawClock(c, 65, 1070, WHITE);
        text(c, "Delay", 105, 1060, 19, WHITE, false, Paint.Align.LEFT);
        text(c, String.format(Locale.US, "%.2f ms", state.delayMs[ch]), 718, 1060, 18, WHITE, false, Paint.Align.RIGHT);
        drawSlider(c, 160, 1098, 676, state.delayMs[ch] / 20f, CYAN, true);
        text(c, "0.00 ms", 160, 1132, 12, SUB, false, Paint.Align.LEFT);
        text(c, "20.00 ms", 676, 1132, 12, SUB, false, Paint.Align.RIGHT);
    }

    private void drawCrossoverGraph(Canvas c, float gx, float gy, float gw, float gh, int ch) {
        p.setColor(Color.rgb(7, 20, 30));
        c.drawRect(gx, gy, gx + gw, gy + gh, p);
        stroke.setStrokeWidth(1f);
        stroke.setColor(Color.rgb(30, 50, 62));
        for (int i = 0; i <= 12; i++) c.drawLine(gx + gw * i / 12f, gy, gx + gw * i / 12f, gy + gh, stroke);
        for (int i = 0; i <= 6; i++) c.drawLine(gx, gy + gh * i / 6f, gx + gw, gy + gh * i / 6f, stroke);

        String[] yl = {"0", "-6", "-12", "-18", "-24"};
        for (int i = 0; i < yl.length; i++) text(c, yl[i], gx - 15, gy + i * gh / 4f + 5, 12, SUB, false, Paint.Align.RIGHT);
        float[] ticks = {20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000};
        String[] tl = {"20", "50", "100", "200", "500", "1K", "2K", "5K", "10K", "20K"};
        for (int i = 0; i < ticks.length; i++) {
            float x = gx + logFraction(ticks[i], 20, 20000) * gw;
            text(c, tl[i], x, gy + gh + 22, 12, SUB, false, Paint.Align.CENTER);
        }

        float hpX = gx + logFraction(state.hpfHz[ch], 20, 20000) * gw;
        float lpX = gx + logFraction(state.lpfHz[ch], 20, 20000) * gw;
        hpX = clamp(hpX, gx, gx + gw);
        lpX = clamp(lpX, gx, gx + gw);

        // HPF fill and line.
        if (state.hpfEnabled[ch]) {
            Path hp = new Path();
            hp.moveTo(gx, gy + gh);
            hp.lineTo(hpX, gy + 24);
            hp.lineTo(Math.min(gx + gw, hpX + 80), gy + 24);
            hp.lineTo(gx + gw, gy + gh);
            hp.close();
            p.setShader(new LinearGradient(gx, gy, hpX, gy, Color.argb(100, 39, 137, 232), Color.argb(10, 39, 137, 232), Shader.TileMode.CLAMP));
            c.drawPath(hp, p);
            p.setShader(null);
            stroke.setColor(BLUE); stroke.setStrokeWidth(4); c.drawLine(gx + 28, gy + gh, hpX, gy + 24, stroke);
            p.setColor(BLUE); c.drawCircle(hpX, gy + 24, 9, p);
            text(c, "HPF", hpX - 12, gy + gh - 18, 17, SUB, true, Paint.Align.RIGHT);
        }

        // Pass band.
        p.setColor(Color.argb(35, 60, 220, 120));
        float passL = Math.min(hpX, lpX);
        float passR = Math.max(hpX, lpX);
        c.drawRect(passL, gy + 22, passR, gy + gh, p);
        stroke.setColor(GREEN); stroke.setStrokeWidth(3); c.drawLine(passL, gy + 24, passR, gy + 24, stroke);

        // LPF fill and line.
        if (state.lpfEnabled[ch]) {
            Path lp = new Path();
            lp.moveTo(Math.max(gx, lpX - 60), gy + 24);
            lp.lineTo(lpX, gy + 24);
            lp.lineTo(gx + gw, gy + gh);
            lp.lineTo(gx + gw, gy + 24);
            lp.close();
            p.setShader(new LinearGradient(lpX, gy, gx + gw, gy, Color.argb(15, 242, 69, 74), Color.argb(105, 242, 69, 74), Shader.TileMode.CLAMP));
            c.drawPath(lp, p);
            p.setShader(null);
            stroke.setColor(RED); stroke.setStrokeWidth(4); c.drawLine(lpX, gy + 24, gx + gw - 20, gy + gh, stroke);
            p.setColor(RED); c.drawCircle(lpX, gy + 24, 9, p);
            text(c, "LPF", lpX + 24, gy + gh - 18, 17, SUB, true, Paint.Align.LEFT);
        }
    }

    private void drawFilterCard(Canvas c, float x, float y, float w, float h, boolean hp, int ch) {
        roundPanel(c, x, y, w, h, 20, PANEL, BORDER);
        boolean enabled = hp ? state.hpfEnabled[ch] : state.lpfEnabled[ch];
        drawToggle(c, x + 23, y + 34, enabled);
        text(c, hp ? "High Pass Filter (HPF)" : "Low Pass Filter (LPF)", x + 76, y + 48, 18, WHITE, false, Paint.Align.LEFT);
        int type = hp ? state.hpfType[ch] : state.lpfType[ch];
        roundPanel(c, x + 435, y + 20, 276, 48, 10, PANEL_2, BORDER);
        text(c, DspState.FILTER_TYPES[type] + "  ▾", x + 573, y + 50, 11.5f, WHITE, false, Paint.Align.CENTER);

        float value = hp ? state.hpfHz[ch] : state.lpfHz[ch];
        float min = hp ? 20f : 100f;
        float max = hp ? 1000f : 20000f;
        float frac = logFraction(value, min, max);
        drawSlider(c, x + 80, y + 116, x + 610, frac, CYAN, enabled);
        text(c, hp ? "20 Hz" : "100 Hz", x + 80, y + 154, 12, SUB, false, Paint.Align.LEFT);
        text(c, hp ? "1 kHz" : "20 kHz", x + 610, y + 154, 12, SUB, false, Paint.Align.RIGHT);
        text(c, DspState.hz(value), x + 704, y + 124, 17, WHITE, false, Paint.Align.RIGHT);
    }

    // ---------------------------------------------------------------------
    // SHARED HEADER / NAV
    // ---------------------------------------------------------------------

    private void drawPageHeader(Canvas c, String title, boolean reset) {
        text(c, "‹", 42, 79, 43, WHITE, false, Paint.Align.CENTER);
        text(c, title, 88, 78, 31, WHITE, true, Paint.Align.LEFT);
        if (reset) text(c, "Reset", 675, 75, 14, Color.rgb(136, 185, 222), false, Paint.Align.CENTER);
        text(c, "⋮", 742, 78, 31, WHITE, false, Paint.Align.CENTER);
    }

    private void drawBottomNav(Canvas c) {
        float y = navTop();
        p.setColor(Color.rgb(6, 18, 28));
        c.drawRect(0, y, viewportW, viewportH, p);
        stroke.setColor(BORDER);
        stroke.setStrokeWidth(1f);
        c.drawLine(0, y, viewportW, y, stroke);
        String[] labels = {"Home", "Mix", "EQ", "Crossover"};
        for (int i = 0; i < 4; i++) {
            float cx = viewportW * (i + 0.5f) / 4f;
            boolean sel = page == i;
            int color = sel ? CYAN : SUB;
            if (i == 0) drawHomeIcon(c, cx, y + 39, color);
            else if (i == 1) drawMixIcon(c, cx, y + 38, color);
            else if (i == 2) drawEqIcon(c, cx, y + 38, color);
            else drawCrossoverIcon(c, cx, y + 38, color);
            text(c, labels[i], cx, y + 88, 14, color, sel, Paint.Align.CENTER);
        }
    }

    // ---------------------------------------------------------------------
    // TOUCH
    // ---------------------------------------------------------------------

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (scaleX <= 0f || scaleY <= 0f || !Float.isFinite(scaleX) || !Float.isFinite(scaleY)) return true;
        float gx = event.getX() / scaleX;
        float y = event.getY() / scaleY;

        int action = event.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN) {
            if (y >= navTop()) {
                int tab = Math.min(3, Math.max(0, (int) (gx / (viewportW / 4f))));
                page = tab;
                dragMode = DRAG_NONE;
                invalidate();
                return true;
            }
            float x = gx - contentLeft;
            if (x < 0 || x > W) return true;
            if (page == PAGE_HOME) handleHomeDown(x, y);
            else if (page == PAGE_MIX) handleMixDown(x, y);
            else if (page == PAGE_EQ) handleEqDown(x, y);
            else handleCrossoverDown(x, y);
            invalidate();
            return true;
        }

        if (action == MotionEvent.ACTION_MOVE) {
            float x = gx - contentLeft;
            if (x < -80 || x > W + 80) return true;
            handleDrag(x, y);
            invalidate();
            return true;
        }

        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            dragMode = DRAG_NONE;
            performClick();
            return true;
        }
        return true;
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    private void handleHomeDown(float x, float y) {
        if (x > 680 && y < 120) {
            toast("Phase 1: Settings UI will be connected to real DSP settings in Phase 2");
            return;
        }
        if (x >= 26 && x <= 760 && y >= 132 && y <= 307) {
            state.demoConnected = !state.demoConnected;
            return;
        }
        if (y >= 620 && y <= 798) {
            if (x >= 26 && x <= 252) page = PAGE_MIX;
            else if (x >= 280 && x <= 506) page = PAGE_EQ;
            else if (x >= 534 && x <= 760) page = PAGE_XOVER;
        }
    }

    private void handleMixDown(float x, float y) {
        if (handleBack(x, y)) return;
        if (x >= 710 && y <= 110) {
            toast("Phase 1: Mix menu preview");
            return;
        }
        for (int i = 0; i < 6; i++) {
            float rowY = 126 + i * 174f;
            if (x >= 106 && x <= 700 && y >= rowY + 62 && y <= rowY + 115) {
                dragMode = DRAG_MIX_BASE + i;
                updateMix(i, x);
                return;
            }
        }
    }

    private void handleEqDown(float x, float y) {
        if (handleBack(x, y)) return;
        if (x >= 718 && y <= 110) {
            toast("Phase 1: EQ menu preview");
            return;
        }
        if (x >= 625 && x <= 715 && y <= 100) {
            state.resetEqChannel(state.eqChannel);
            toast("EQ channel reset");
            return;
        }
        if (y >= 118 && y <= 180 && x >= 24 && x <= 762) {
            float gap = 7f;
            float w = (738f - gap * 6f) / 7f;
            int ch = (int) ((x - 24) / (w + gap));
            if (ch >= 0 && ch < 7) state.eqChannel = ch;
            return;
        }
        if (y >= 602 && y <= 675) {
            if (x >= 155 && x <= 260) state.selectedBand = (state.selectedBand + 14) % 15;
            else if (x >= 530 && x <= 635) state.selectedBand = (state.selectedBand + 1) % 15;
            return;
        }
        if (x >= 78 && x <= 750 && y >= 218 && y <= 542) {
            state.selectedBand = nearestEqBand(x, y, 78, 218, 672, 324);
            dragMode = DRAG_EQ_GRAPH;
            updateEqGraph(x, y);
            return;
        }
        if (y >= 770 && y <= 825) {
            if (x >= 50 && x <= 263) { dragMode = DRAG_EQ_FREQ; updateEqFreq(x); }
            else if (x >= 286 && x <= 499) { dragMode = DRAG_EQ_GAIN; updateEqGain(x); }
            else if (x >= 522 && x <= 735) { dragMode = DRAG_EQ_Q; updateEqQ(x); }
            return;
        }
        if (x >= 286 && x <= 700 && y >= 986 && y <= 1035) {
            dragMode = DRAG_EQ_OUTPUT;
            updateEqOutput(x);
            return;
        }
        if (x >= 26 && x <= 380 && y >= 1080 && y <= 1162) {
            state.saveEqPreset(getContext());
            toast("Saved EQ preset");
            return;
        }
        if (x >= 406 && x <= 760 && y >= 1080 && y <= 1162) {
            boolean ok = state.loadEqPreset(getContext());
            toast(ok ? "Loaded EQ preset" : "No saved EQ preset yet");
        }
    }

    private void handleCrossoverDown(float x, float y) {
        if (handleBack(x, y)) return;
        if (x >= 720 && y <= 110) {
            toast("Phase 1: Crossover menu preview");
            return;
        }
        if (x >= 610 && x < 720 && y >= 30 && y <= 110) {
            state.crossoverChannel = (state.crossoverChannel + 1) % DspState.CHANNELS;
            return;
        }
        int ch = state.crossoverChannel;
        // HPF card.
        if (y >= 554 && y <= 762) {
            if (x >= 35 && x <= 95 && y <= 635) {
                state.hpfEnabled[ch] = !state.hpfEnabled[ch];
            } else if (x >= 455 && x <= 745 && y <= 635) {
                state.hpfType[ch] = (state.hpfType[ch] + 1) % DspState.FILTER_TYPES.length;
            } else if (x >= 90 && x <= 650 && y >= 642 && y <= 706) {
                dragMode = DRAG_HP;
                updateHpf(x);
            }
            return;
        }
        // LPF card.
        if (y >= 786 && y <= 994) {
            if (x >= 35 && x <= 95 && y <= 867) {
                state.lpfEnabled[ch] = !state.lpfEnabled[ch];
            } else if (x >= 455 && x <= 745 && y <= 867) {
                state.lpfType[ch] = (state.lpfType[ch] + 1) % DspState.FILTER_TYPES.length;
            } else if (x >= 90 && x <= 650 && y >= 874 && y <= 938) {
                dragMode = DRAG_LP;
                updateLpf(x);
            }
            return;
        }
        if (x >= 145 && x <= 700 && y >= 1074 && y <= 1122) {
            dragMode = DRAG_DELAY;
            updateDelay(x);
        }
    }

    private boolean handleBack(float x, float y) {
        if (x <= 75 && y <= 110) {
            page = PAGE_HOME;
            dragMode = DRAG_NONE;
            return true;
        }
        return false;
    }

    private void handleDrag(float x, float y) {
        if (dragMode >= DRAG_MIX_BASE && dragMode < DRAG_MIX_BASE + 6) updateMix(dragMode - DRAG_MIX_BASE, x);
        else if (dragMode == DRAG_EQ_GRAPH) updateEqGraph(x, y);
        else if (dragMode == DRAG_EQ_FREQ) updateEqFreq(x);
        else if (dragMode == DRAG_EQ_GAIN) updateEqGain(x);
        else if (dragMode == DRAG_EQ_Q) updateEqQ(x);
        else if (dragMode == DRAG_EQ_OUTPUT) updateEqOutput(x);
        else if (dragMode == DRAG_HP) updateHpf(x);
        else if (dragMode == DRAG_LP) updateLpf(x);
        else if (dragMode == DRAG_DELAY) updateDelay(x);
    }

    private void updateMix(int index, float x) {
        float f = clamp((x - 124f) / (680f - 124f), 0f, 1f);
        if (index == 0) state.masterPercent = Math.round(f * 100f);
        else if (index == 1) state.bassPercent = Math.round(f * 100f);
        else if (index == 2) state.bassCutoffHz = Math.round(logValue(f, 20f, 300f));
        else if (index == 3) state.bassBoostDb = round1(-12f + f * 24f);
        else if (index == 4) state.middleBoostDb = round1(-12f + f * 24f);
        else state.trebleBoostDb = round1(-12f + f * 24f);
    }

    private int nearestEqBand(float x, float y, float gx, float gy, float gw, float gh) {
        int ch = state.eqChannel;
        int best = 0;
        float bestD = Float.MAX_VALUE;
        for (int b = 0; b < 15; b++) {
            float bx = gx + logFraction(state.eqFreqHz[ch][b], 20f, 20000f) * gw;
            float by = gy + (12f - state.eqGainDb[ch][b]) / 24f * gh;
            float dx = bx - x, dy = by - y;
            float d = dx * dx + dy * dy;
            if (d < bestD) { bestD = d; best = b; }
        }
        return best;
    }

    private void updateEqGraph(float x, float y) {
        int ch = state.eqChannel, b = state.selectedBand;
        float fx = clamp((x - 78f) / 672f, 0f, 1f);
        float fy = clamp((y - 218f) / 324f, 0f, 1f);
        state.eqFreqHz[ch][b] = roundFreq(logValue(fx, 20f, 20000f));
        state.eqGainDb[ch][b] = round1(12f - fy * 24f);
    }

    private void updateEqFreq(float x) {
        int ch = state.eqChannel, b = state.selectedBand;
        float f = clamp((x - 68f) / (245f - 68f), 0f, 1f);
        state.eqFreqHz[ch][b] = roundFreq(logValue(f, 20f, 20000f));
    }

    private void updateEqGain(float x) {
        int ch = state.eqChannel, b = state.selectedBand;
        float f = clamp((x - 304f) / (481f - 304f), 0f, 1f);
        state.eqGainDb[ch][b] = round1(-12f + f * 24f);
    }

    private void updateEqQ(float x) {
        int ch = state.eqChannel, b = state.selectedBand;
        float f = clamp((x - 540f) / (717f - 540f), 0f, 1f);
        state.eqQ[ch][b] = round1(0.1f + f * 9.9f);
    }

    private void updateEqOutput(float x) {
        float f = clamp((x - 312f) / (676f - 312f), 0f, 1f);
        state.outputGainDb[state.eqChannel] = round1(-12f + f * 24f);
    }

    private void updateHpf(float x) {
        int ch = state.crossoverChannel;
        float f = clamp((x - 106f) / (636f - 106f), 0f, 1f);
        state.hpfHz[ch] = roundFreq(logValue(f, 20f, 1000f));
        if (state.hpfHz[ch] > state.lpfHz[ch]) state.lpfHz[ch] = state.hpfHz[ch];
    }

    private void updateLpf(float x) {
        int ch = state.crossoverChannel;
        float f = clamp((x - 106f) / (636f - 106f), 0f, 1f);
        state.lpfHz[ch] = roundFreq(logValue(f, 100f, 20000f));
        if (state.lpfHz[ch] < state.hpfHz[ch]) state.hpfHz[ch] = state.lpfHz[ch];
    }

    private void updateDelay(float x) {
        float f = clamp((x - 160f) / (676f - 160f), 0f, 1f);
        state.delayMs[state.crossoverChannel] = Math.round(f * 2000f) / 100f;
    }

    // ---------------------------------------------------------------------
    // DRAWING HELPERS
    // ---------------------------------------------------------------------

    private void drawSlider(Canvas c, float x0, float y, float x1, float frac, int accent, boolean enabled) {
        frac = clamp(frac, 0f, 1f);
        float kx = x0 + (x1 - x0) * frac;
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(9f);
        p.setColor(TRACK);
        c.drawLine(x0, y, x1, y, p);
        p.setColor(enabled ? accent : Color.rgb(65, 79, 88));
        c.drawLine(x0, y, kx, y, p);
        p.setColor(enabled ? CYAN : Color.rgb(118, 128, 134));
        c.drawCircle(kx, y, 13f, p);
        p.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawToggle(Canvas c, float x, float y, boolean on) {
        float w = 48, h = 27;
        p.setColor(on ? CYAN : Color.rgb(62, 77, 88));
        c.drawRoundRect(new RectF(x, y, x + w, y + h), h / 2f, h / 2f, p);
        p.setColor(WHITE);
        c.drawCircle(on ? x + w - 14 : x + 14, y + h / 2f, 10, p);
    }

    private void button(Canvas c, float x, float y, float w, float h, String label, boolean selected) {
        roundPanel(c, x, y, w, h, 14, selected ? Color.rgb(17, 77, 106) : Color.rgb(19, 49, 68), selected ? CYAN : Color.rgb(25, 89, 120));
        text(c, label, x + w / 2f, y + h / 2f + 7, 18, WHITE, false, Paint.Align.CENTER);
    }

    private void roundPanel(Canvas c, float x, float y, float w, float h, float r, int fill, int border) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(fill);
        c.drawRoundRect(new RectF(x, y, x + w, y + h), r, r, p);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(1.2f);
        stroke.setColor(border);
        c.drawRoundRect(new RectF(x, y, x + w, y + h), r, r, stroke);
    }

    private void text(Canvas c, String s, float x, float y, float size, int color, boolean bold, Paint.Align align) {
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        p.setTextSize(size);
        p.setTextAlign(align);
        // Use Android's explicit sans-serif family rather than the user-selected
        // system display font so the UI stays visually consistent with the reference.
        p.setTypeface(Typeface.create(bold ? "sans-serif-medium" : "sans-serif", Typeface.NORMAL));
        c.drawText(s, x, y, p);
    }

    private void infoPair(Canvas c, String key, String value, float x, float y) {
        text(c, key, x, y, 15, SUB, false, Paint.Align.LEFT);
        text(c, value, x + 176, y, 15, WHITE, false, Paint.Align.LEFT);
    }

    private void drawBluetoothBadge(Canvas c, float cx, float cy, boolean on) {
        p.setColor(Color.rgb(13, 42, 59));
        c.drawCircle(cx, cy, 57, p);
        stroke.setColor(CYAN_2); stroke.setStrokeWidth(2.5f); stroke.setStyle(Paint.Style.STROKE); c.drawCircle(cx, cy, 57, stroke);
        stroke.setColor(on ? WHITE : SUB); stroke.setStrokeWidth(3.2f);
        Path b = new Path();
        b.moveTo(cx, cy - 25); b.lineTo(cx + 17, cy - 9); b.lineTo(cx - 18, cy + 19); b.lineTo(cx, cy + 32); b.lineTo(cx, cy - 25);
        b.moveTo(cx, cy); b.lineTo(cx + 18, cy + 18); b.moveTo(cx, cy); b.lineTo(cx - 18, cy - 16);
        c.drawPath(b, stroke);
    }

    private void drawDspBox(Canvas c, float x, float y, float w, float h) {
        p.setColor(Color.rgb(10, 13, 16));
        Path body = new Path();
        body.moveTo(x, y + 25); body.lineTo(x + w * .72f, y); body.lineTo(x + w, y + 34); body.lineTo(x + w, y + h - 18); body.lineTo(x + 48, y + h); body.lineTo(x, y + 92); body.close();
        c.drawPath(body, p);
        stroke.setColor(Color.rgb(63, 72, 78)); stroke.setStrokeWidth(2); c.drawPath(body, stroke);
        text(c, "DSP 7 Ch", x + w * .58f, y + 69, 14, WHITE, true, Paint.Align.CENTER);
    }

    private void drawWave(Canvas c, float x, float y, float w, float amp, int color) {
        for (int k = 0; k < 4; k++) {
            Path path = new Path();
            for (int i = 0; i <= 80; i++) {
                float xx = x + w * i / 80f;
                float yy = y + (float) Math.sin(i * .22 + k * .7) * (amp - k * 6);
                if (i == 0) path.moveTo(xx, yy); else path.lineTo(xx, yy);
            }
            stroke.setColor(Color.argb(140 - k * 25, Color.red(color), Color.green(color), Color.blue(color)));
            stroke.setStrokeWidth(1.2f); c.drawPath(path, stroke);
        }
    }

    private void drawGear(Canvas c, float cx, float cy, int color) {
        stroke.setStyle(Paint.Style.STROKE); stroke.setColor(color); stroke.setStrokeWidth(3);
        c.drawCircle(cx, cy, 17, stroke); c.drawCircle(cx, cy, 6, stroke);
        for (int i = 0; i < 8; i++) {
            double a = i * Math.PI / 4.0;
            c.drawLine(cx + (float) Math.cos(a) * 18, cy + (float) Math.sin(a) * 18,
                    cx + (float) Math.cos(a) * 24, cy + (float) Math.sin(a) * 24, stroke);
        }
    }

    private void drawSpeaker(Canvas c, float cx, float cy, int color) {
        p.setColor(color);
        Path s = new Path();
        s.moveTo(cx - 20, cy - 8); s.lineTo(cx - 8, cy - 8); s.lineTo(cx + 7, cy - 20); s.lineTo(cx + 7, cy + 20); s.lineTo(cx - 8, cy + 8); s.lineTo(cx - 20, cy + 8); s.close();
        c.drawPath(s, p);
        stroke.setColor(color); stroke.setStrokeWidth(2.2f); stroke.setStyle(Paint.Style.STROKE);
        c.drawArc(new RectF(cx, cy - 15, cx + 28, cy + 15), -55, 110, false, stroke);
        c.drawArc(new RectF(cx - 2, cy - 23, cx + 42, cy + 23), -50, 100, false, stroke);
    }

    private void drawMixRowIcon(Canvas c, float cx, float cy, int index, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(3); stroke.setStyle(Paint.Style.STROKE);
        if (index == 0) drawSpeaker(c, cx, cy, color);
        else if (index == 1) { c.drawCircle(cx, cy, 22, stroke); c.drawCircle(cx, cy, 10, stroke); }
        else if (index == 2) { Path q = new Path(); q.moveTo(cx - 25, cy + 18); q.cubicTo(cx - 15, cy - 25, cx + 10, cy - 28, cx + 25, cy + 18); c.drawPath(q, stroke); }
        else { Path q = new Path(); q.moveTo(cx - 28, cy); for (int i = 0; i < 8; i++) q.lineTo(cx - 21 + i * 7, cy + (i % 2 == 0 ? -17 : 17)); c.drawPath(q, stroke); }
    }

    private void drawHomeIcon(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(3); stroke.setStyle(Paint.Style.STROKE);
        Path h = new Path(); h.moveTo(cx - 18, cy); h.lineTo(cx, cy - 17); h.lineTo(cx + 18, cy); h.lineTo(cx + 14, cy); h.lineTo(cx + 14, cy + 18); h.lineTo(cx + 4, cy + 18); h.lineTo(cx + 4, cy + 6); h.lineTo(cx - 4, cy + 6); h.lineTo(cx - 4, cy + 18); h.lineTo(cx - 14, cy + 18); h.lineTo(cx - 14, cy); c.drawPath(h, stroke);
    }

    private void drawMixIcon(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(2.5f); stroke.setStyle(Paint.Style.STROKE);
        for (int i = -1; i <= 1; i++) {
            float x = cx + i * 15;
            c.drawLine(x, cy - 21, x, cy + 21, stroke);
            float yy = cy + (i == -1 ? -6 : i == 0 ? 7 : -1);
            c.drawCircle(x, yy, 4.5f, stroke);
        }
    }

    private void drawEqIcon(Canvas c, float cx, float cy, int color) {
        p.setColor(color);
        float[] h = {12, 25, 18, 32, 21};
        for (int i = 0; i < h.length; i++) c.drawRoundRect(new RectF(cx - 26 + i * 12, cy + 20 - h[i], cx - 21 + i * 12, cy + 20), 2, 2, p);
    }

    private void drawCrossoverIcon(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(2.4f); stroke.setStyle(Paint.Style.STROKE);
        Path a = new Path(); a.moveTo(cx - 24, cy + 18); a.cubicTo(cx - 10, cy + 17, cx - 7, cy - 17, cx + 24, cy - 18); c.drawPath(a, stroke);
        Path b = new Path(); b.moveTo(cx - 24, cy - 18); b.cubicTo(cx + 3, cy - 17, cx + 8, cy + 17, cx + 24, cy + 18); c.drawPath(b, stroke);
    }

    private void drawClock(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(2.5f); stroke.setStyle(Paint.Style.STROKE);
        c.drawCircle(cx, cy, 20, stroke); c.drawLine(cx, cy, cx, cy - 11, stroke); c.drawLine(cx, cy, cx + 9, cy + 7, stroke);
    }

    private float logFraction(float value, float min, float max) {
        value = clamp(value, min, max);
        return (float) ((Math.log(value) - Math.log(min)) / (Math.log(max) - Math.log(min)));
    }

    private float logValue(float frac, float min, float max) {
        frac = clamp(frac, 0f, 1f);
        return (float) Math.exp(Math.log(min) + frac * (Math.log(max) - Math.log(min)));
    }

    private float roundFreq(float v) {
        if (v < 100f) return Math.round(v);
        if (v < 1000f) return Math.round(v / 5f) * 5f;
        return Math.round(v / 10f) * 10f;
    }

    private float round1(float v) {
        return Math.round(v * 10f) / 10f;
    }

    private float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    private void toast(String message) {
        Toast.makeText(getContext(), message, Toast.LENGTH_SHORT).show();
    }
}
