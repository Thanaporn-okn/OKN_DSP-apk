package com.okn.dsp;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;

/**
 * OKN_DSP V19 - Phase 1 UI shell (startup crash hardening).
 *
 * Phase 1 deliberately does not start BLE or write to a DSP.  The entire UI is
 * interactive locally so every control can be visually verified first.  Phase 2
 * can attach the real transport/protocol after the user supplies the definitive
 * DSP control data.
 */
public class MainActivity extends Activity {
    private DspView dspView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        safeConfigureWindow();
        safeEnterImmersive();
        try {
            dspView = new DspView(this);
            setContentView(dspView);
        } catch (RuntimeException ex) {
            showStartupFallback(ex);
        } catch (LinkageError err) {
            showStartupFallback(err);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        safeConfigureWindow();
        safeEnterImmersive();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) safeEnterImmersive();
    }


    private void safeConfigureWindow() {
        try {
            configureWindow();
        } catch (RuntimeException ignored) {
            // Some OEM window implementations may reject optional flags.
        }
    }

    private void safeEnterImmersive() {
        try {
            enterImmersive();
        } catch (RuntimeException ignored) {
            // Keep the app running even if an OEM rejects immersive-window calls.
        }
    }

    private void showStartupFallback(Throwable error) {
        android.widget.TextView fallback = new android.widget.TextView(this);
        fallback.setBackgroundColor(android.graphics.Color.rgb(1, 8, 20));
        fallback.setTextColor(android.graphics.Color.WHITE);
        fallback.setGravity(android.view.Gravity.CENTER);
        fallback.setTextSize(20f);
        fallback.setPadding(40, 40, 40, 40);
        String name = error == null ? "Unknown" : error.getClass().getSimpleName();
        fallback.setText("OKN_DSP V19\nUI safe mode\nStartup renderer recovered (" + name + " )");
        setContentView(fallback);
    }

    private void configureWindow() {
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            WindowManager.LayoutParams lp = window.getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            window.setAttributes(lp);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.setStatusBarContrastEnforced(false);
            window.setNavigationBarContrastEnforced(false);
        }
    }

    private void enterImmersive() {
        Window window = getWindow();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false);
            WindowInsetsController controller = window.getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            window.getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }
}
