OKN_DSP V20 — Phase 1 real-device UI parity pass

Basis: review of the user-provided V19 screen recording on a 1080x2340 Android device.

Changes:
- Kept the UI 100% code-drawn; no uploaded screenshot is packaged or used as a background.
- Connection pill now matches the approved visual language: Connected / OKN-DSP-7CH.
- Rebalanced tall-screen vertical spacing so Home, Mix, EQ and Crossover occupy the usable screen more evenly.
- Improved the code-drawn DSP chassis with extra vector rails, connector details and light accents.
- Updated visible firmware/version labels to V20.
- Preserved immediate local slider/toggle/button response for Phase 1.
- Preserved V19 startup hardening and safe renderer fallback.

Phase 2 real DSP/BLE transport is intentionally not enabled yet.
