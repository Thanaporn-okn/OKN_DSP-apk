OKN_DSP V20 - Phase 1 UI Reference Match
=========================================

Base: V19 (startup-hardened build that opens successfully)
Reference: Sources/UI_REFERENCE_PHASE1_4PAGES.png
Observed comparison source: user-provided V19 screen recording 29941.mp4

V20 UI changes
--------------
1. Full-screen logical canvas changed from 786x1536 to 786x1340 so Home/Mix/EQ/Crossover occupy the physical screen instead of leaving a large unused vertical area on tall phones.
2. Separate X/Y display scaling maps the full logical UI edge-to-edge while preserving logical touch coordinates, so sliders and buttons remain immediate/real-time in Phase 1.
3. Text rendering now requests Android sans-serif / sans-serif-medium rather than a generic alias, improving visual consistency with the uploaded reference.
4. Home reference text now matches the supplied mockup: Ready for audio processing, Firmware v1.2.0, Input Source Bluetooth, Sample Rate 48 kHz, Status Normal.
5. Mix boost values display whole dB values (+4 dB, +2 dB, +3 dB) like the reference.
6. EQ opens on Band 8 / 15 with the reference starting point 1,000 Hz, +3.0 dB, Q 1.0.
7. Startup/runtime protection from V19 is retained.
8. Phase 1 remains UI-only: no BLE/DSP write is started by MainActivity.

Project rules retained
----------------------
- Home / Mix / EQ / Crossover bottom navigation on every page.
- Sliders and graph controls update immediately while dragging.
- EQ: 15 bands x 7 channels, editable Frequency / Gain / Q, Output Gain, Save/Load Preset.
- Crossover: HPF / LPF type, cutoff, channel selection and Delay.
- Build workflow remains OKN_DSP_AutoBuild.yml and auto-runs for OKN_DSP_V*_Sources.zip pushes.
- Sources/SHA256SUMS.txt is regenerated for this version.
- Any later build/runtime defect must become a new incremented version, not overwrite V20.
