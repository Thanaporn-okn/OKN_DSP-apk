OKN_DSP V15 — 15-BAND GRAPHIC EQ
================================

Version
- versionCode 15
- versionName 15.0.0
- applicationId com.okn.dsp

Stable base
- V14 real-hardware audio behavior preserved.
- Same signing keystore retained byte-for-byte.

What changed
1. EQ UI expanded from 6 bands to 15 bands.
2. All 15 records from each channel's live Device Description are displayed (7 x 15 = 105 records).
3. Removed the old 6-band nearest-frequency map.
4. UI Band 1..15 now maps directly to hardware record 1..15.
5. Graphic EQ interaction changes Gain only. Frequency/Q are kept from the live DSP record.
6. 15 narrow vertical sliders fit the portrait full-screen EQ page; graph also renders all 15 points.
7. READ ONLY marker is shown for a record outside the already-qualified PEAKING write boundary.

Inherited unchanged
- AB00 / AB01 / AB02 transport
- Auth + AES-CFB8 session
- 380 ms original-app scheduler
- V14 Treble ID11 <= 0.5 dB safe slew
- scalar IDs and their hardware paths
- stable package/signing identity
