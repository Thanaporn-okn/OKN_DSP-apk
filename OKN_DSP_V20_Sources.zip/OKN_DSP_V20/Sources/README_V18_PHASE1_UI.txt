OKN_DSP V18 - Phase 1 UI implementation
========================================

Scope
-----
This version intentionally implements UI behavior only. No real DSP/BLE write is
started by MainActivity. The previous verified BLE/protocol source files are kept
in the project so Phase 2 can integrate the real hardware control without losing
prior reverse-engineering work.

Implemented pages
-----------------
1. Home
   - DSP 7 Ch header, connection status card, DSP information card.
   - Mix / EQ / Crossover navigation cards.
   - Bottom navigation: Home > Mix > EQ > Crossover.

2. Mix
   - Master Volume 0..100%
   - Bass Volume 0..100%
   - Bass Cutoff 20..300 Hz (logarithmic slider)
   - Bass Boost -12..+12 dB
   - Middle Boost -12..+12 dB
   - Treble Boost -12..+12 dB
   - Values update immediately while the finger moves.

3. EQ
   - 7 channels.
   - 15 bands per channel.
   - Frequency 20 Hz..20 kHz, Gain -12..+12 dB, Q 0.1..10.
   - Output Gain -12..+12 dB per channel.
   - Curve point selection and direct drag.
   - Save/Load preset using SharedPreferences.

4. Crossover
   - 7 channels.
   - HPF enable, cutoff and filter type.
   - LPF enable, cutoff and filter type.
   - Delay 0..20 ms.
   - Crossover graph updates immediately.

Responsive behavior
-------------------
The app uses a 786x1536 design coordinate system and a single uniform scale.
Tall phones extend the vertical logical viewport so the bottom navigation remains
at the real screen bottom. Wider tablet screens extend the logical width and keep
the main content centered while the background and navigation remain full screen.
System status/navigation bars are hidden with immersive mode and display cutouts
are allowed on short edges.

Version rule
------------
If a build/runtime error is found after this package is delivered, the fix must be
released as the next version number rather than silently replacing V18.
