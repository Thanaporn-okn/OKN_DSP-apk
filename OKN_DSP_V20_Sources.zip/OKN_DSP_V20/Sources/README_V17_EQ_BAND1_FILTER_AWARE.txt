OKN_DSP V17 — FILTER-AWARE FIRST EQ BAND

Base: V16 stable runtime baseline.
Purpose: enable the only remaining RO EQ slider (Band 1) on CH1..CH7 without changing the filter family stored by the DSP.

What changed:
1. PEAKING type12 writer from V16 is unchanged for bands 2..15.
2. Band 1 now recognizes the real native filter type:
   - Tone Control type17 on CH1/CH2/CH4/CH5/CH6/CH7.
   - General Low-pass type3 on CH3.
3. Type17 target uses the captured field layout F/F2/Q/B/G/R and recomputes B0/B1/B2/A1/A2 with the SigmaStudio Tone Control equations.
4. Type3 target preserves cutoff/Q and changes only cell gain G with a normal second-order low-pass coefficient rebuild.
5. No type conversion to PEAKING is performed.
6. Original-style 380 ms scheduler, AES-CFB8 stream behavior, stable signing key and V14 Treble safe behavior remain unchanged.

Expected runtime result:
- All 15 sliders should show LIVE on CH1..CH7.
- The previously circled first slider should now move and affect the DSP.
- Existing stable controls should remain unchanged.

V17 must be tested on real hardware before promotion to stable baseline.
