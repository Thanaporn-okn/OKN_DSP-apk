OKN_DSP V14 — TrebleBoost ID11 acoustic isolation
=================================================
Base: V13 (Master/Bass Boost/Middle Boost real-DSP PASS).

Change scope only:
- TrebleBoost ID11 no longer writes during MotionEvent MOVE.
- Final ID11 target commits on finger release.
- Hardware value slews from last successful live value in max 0.5 dB steps.
- Each next step waits for the next existing 380 ms scheduler slot after the prior write succeeds.
- Latest target wins; no stale target queue.
- Shared 380 ms scheduler/poll cycle remains unchanged for other controls.
- SaveParams remains manual/not automatic.

Safety intent:
Avoid the V13 condition where rapidly moving UI target could become a large direct ID11 jump at a 380 ms slot.
Real acoustic qualification is still required; static validation does not claim the Treble incident is fully resolved.
