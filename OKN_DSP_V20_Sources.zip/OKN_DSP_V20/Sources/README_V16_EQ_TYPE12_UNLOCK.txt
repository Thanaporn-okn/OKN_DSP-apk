OKN_DSP V16 — COMPLETE PEAKING BAND ACCESS
==========================================
V16 is based on V15 and fixes the runtime-observed CH3..CH7 incomplete EQ access.

Important boundary:
- All 15 real records per channel are still displayed.
- All valid PEAKING (type=12) records can now be adjusted, even when auxiliary metadata fields such as R are non-zero.
- Non-PEAKING records remain READ ONLY because overwriting Tone Control / Low-pass / other filter types as PEAKING would change unrelated DSP behavior.
- Graphic EQ changes Gain only and preserves the live record Frequency, Q, F2, G and R metadata.

V14 audio-stable scalar behavior and V15 BLE scheduler are unchanged.
