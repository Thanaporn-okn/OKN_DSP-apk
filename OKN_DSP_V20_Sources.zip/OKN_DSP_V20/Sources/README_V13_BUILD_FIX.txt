OKN_DSP V13 — V12 Java Compile Fix
==================================
V13 is intentionally a minimal build-fix release.

Changed:
- Declare verified UFE read opcode CMD_READ_SENSOR_ACTUATOR = 0x58 in DspProtocol.java.
- Version bumped to 13.0.0 / versionCode 13.

Unchanged from V12:
- UI
- original-app 380 ms scheduler
- latest-target queue behavior
- sensor keepalive cycle ID19 -> ID20 -> ID0 -> ID21
- AB00 / AB01 / AB02 transport
- AES-CFB8 session handling
- verified scalar/EQ serializer
- SaveParams policy
- applicationId com.okn.dsp
- stable update signing key
