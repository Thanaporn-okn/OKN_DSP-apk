OKN_DSP V18 - Phase 1 UI Rebuild
=================================

Goal
----
Rebuild the four uploaded reference screens as a native interactive Android UI:
Home, Mix, Eq, and Crossover.

Critical implementation rule
----------------------------
The uploaded reference screenshots are NOT used as app backgrounds, bitmap layers,
textures, or runtime resources. V18 draws the interface from Java Canvas primitives:
gradients, panels, text, icons, neon waves, graphs, sliders, and a stylized DSP chassis.

Phase 1 behavior
----------------
- Full-screen immersive portrait UI.
- Responsive virtual viewport for phones and tablets.
- Bottom navigation on all pages: Home > Mix > Eq > Crossover.
- Sliders update values during ACTION_MOVE with no deliberate UI delay.
- Home/Mix values are linked locally.
- EQ has 7 channels x 15 bands, draggable graph gain points, Frequency/Gain/Q controls,
  channel output, quick presets, and local save/load.
- Crossover has 7 channels, HPF/LPF toggles and frequency sliders, slope buttons,
  delay/distance linkage, phase/polarity, and filter-link toggle.
- Settings overlay identifies this as Phase 1 UI Preview.

Phase 2
-------
The existing protocol/BLE source files are retained only as dormant project material.
MainActivity does not initialize Bluetooth in V18. Real DSP control must be wired only
after the user provides the definitive DSP control data for Phase 2.

Build
-----
Use OKN_DSP_AutoBuild.yml in .github/workflows once. Uploading any new
OKN_DSP_V*_Sources.zip at repository root automatically triggers a build of the newest
version ZIP. Sources/SHA256SUMS.txt is verified before Gradle builds the APK.
