OKN_DSP V12 — Original-App Scheduler Match
==========================================
1. UI remains immediate and follows the finger.
2. BLE application commands are not emitted directly from MotionEvent callbacks.
3. A single 380 ms scheduler owns all AB01 application traffic.
4. When a control target is pending, only the latest target is sent in the next scheduler slot.
5. When no control write is pending, V12 sends the same ID19/ID20/ID0/ID21 UFE read cycle observed in the official app.
6. Scalar/EQ writes still use verified AB00/AB01/AB02 + AES-CFB8 + UFE serializers.
7. SaveParams remains manual only; no automatic permanent save is introduced.
8. Stable signing key and package com.okn.dsp are unchanged.
