OKN_DSP V19 - Phase 1 startup hardening

Goal:
Keep the V18 four-page UI behavior while preventing the reported immediate-close failure from terminating the activity.

Changes:
1. MainActivity fullscreen/window calls are defensive again.
2. Immersive mode is entered after setContentView.
3. DspView no longer forces a full-screen software layer.
4. Software-only drawing shadows were removed from interactive/render-hot paths.
5. DspView catches RuntimeException during rendering and shows a visible fallback diagnostic.
6. MainActivity catches RuntimeException while creating DspView and shows a startup diagnostic fallback.
7. Version advanced to V19; V18 is not overwritten.

Phase 1 only: controls change local UI state immediately; no real DSP/BLE writes.
