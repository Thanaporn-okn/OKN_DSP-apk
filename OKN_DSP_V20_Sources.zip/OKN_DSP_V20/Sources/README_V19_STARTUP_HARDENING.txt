OKN_DSP V19 - Phase 1 Startup Hardening

Goal: preserve the V18 code-drawn Home / Mix / Eq / Crossover UI while preventing the reported immediate startup exit.

Important rendering rule:
- Reference screenshots are NOT bundled as backgrounds or UI bitmaps.
- The interface remains generated from Java Canvas primitives, gradients, paths, text and touch regions.

V19 changes:
- Hardware-accelerated default Canvas path; forced full-screen software layer removed.
- Runtime rendering guard with an in-app safe-mode fallback.
- Runtime window/immersive calls are guarded against OEM-specific exceptions.
- Version advanced to 19 as required after a runtime error.

The safe-mode screen is only a recovery path. Under normal rendering, the full interactive UI is shown.
