# OKN BP1048P4 Phase3 TRUE7CH Source R5

Firmware TRUE7CH core เดิมยังคงแยก Channel Gain ออกจาก EQ.
Android USB probe R5 ใช้สำหรับอ่านสถานะ USB/HID แบบ read-only จากบอร์ดที่สังเกตจริง 0x6324:0x1719.

จุดใหม่ R5 คืออ่าน HID GET_REPORT จาก IF4 ตาม report descriptor ที่บอร์ดส่งเอง:
- FEATURE ID0 = 8 bytes
- INPUT ID0 = 256 bytes

ไม่มี SET_REPORT, ไม่มี class/endpoint OUT, ไม่มี erase/program/flash.
ใช้ `.github/workflows/OKN_BP1048P4_AUTO.yml` เดิมได้ ไม่ต้องเปลี่ยน workflow ตาม revision.
