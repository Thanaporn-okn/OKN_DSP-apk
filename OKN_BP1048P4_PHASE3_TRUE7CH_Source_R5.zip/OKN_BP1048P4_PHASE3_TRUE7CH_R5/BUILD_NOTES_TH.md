# OKN BP1048P4 Phase3 TRUE7CH R5 — USB Read-Only GET_REPORT Probe

R5 ต่อจากผลจริงบน Samsung S25+:
- VID = 0x6324, PID = 0x1719
- Manufacturer = JMDSTECH
- Product = DSTech DSP ComboDigitalArchitect
- IF4 HID report descriptor ยืนยัน vendor-defined Usage Page 0xFF00
- IF4: INPUT 256 bytes, OUTPUT 256 bytes, FEATURE 8 bytes, ไม่มี REPORT_ID => ID 0

R5 เพิ่มเฉพาะการอ่านแบบ Device-to-Host:
- Standard GET_DESCRIPTOR (IN)
- HID GET_REPORT FEATURE, ID0, 8 bytes (IN)
- HID GET_REPORT INPUT, ID0, 256 bytes (IN)

R5 ไม่ส่ง:
- SET_REPORT
- HID/Class OUT
- endpoint OUT
- erase/program/flash
- reboot-to-bootloader

claimInterface ใช้ force=false เท่านั้น เพื่อไม่ detach kernel driver.
