import 'package:flutter/material.dart';

void main()=>runApp(const OKNDSP());

class OKNDSP extends StatelessWidget{
 const OKNDSP({super.key});
 @override
 Widget build(BuildContext c)=>MaterialApp(
  debugShowCheckedModeBanner:false,
  theme:ThemeData.dark(useMaterial3:true),
  home:const Home());
}

class Home extends StatefulWidget{
 const Home({super.key});
 State<Home> createState()=>_Home();
}

class _Home extends State<Home>{
 int page=0;
 final pages=['MAIN','EQ','CROSSOVER','DELAY','MIXER','PRESET','SETTINGS'];

 Widget build(BuildContext c){
 return Scaffold(
 backgroundColor:const Color(0xff0b1016),
 body:SafeArea(child:Column(children:[
 Expanded(child:page==0?mainUI():controlUI()),
 nav()
 ])));
 }

 Widget mainUI()=>Column(children:[
  Container(
   margin:const EdgeInsets.all(10),
   padding:const EdgeInsets.all(15),
   decoration:BoxDecoration(color:const Color(0xff202631),
   borderRadius:BorderRadius.circular(15)),
   child:const Text('🔵 Connected\nBP1048P4 7CH DSP\nFW:1.2.6')),
  const Text('Master Volume -12.5 dB',
  style:TextStyle(fontSize:22)),
  Expanded(child:Row(children:List.generate(7,(i)=>
   Expanded(child:Column(children:[
    Text('CH${i+1}'),
    Expanded(child:RotatedBox(
     quarterTurns:3,
     child:Slider(value:.7,onChanged:null))),
    ElevatedButton(onPressed:null,child:const Text('Mute'))
   ])))))
 ]);

 Widget controlUI()=>Center(
 child:Text(pages[page],
 style:const TextStyle(fontSize:35,color:Colors.cyan)));

 Widget nav()=>SizedBox(
 height:55,
 child:Row(mainAxisAlignment:MainAxisAlignment.spaceAround,
 children:List.generate(pages.length,(i)=>InkWell(
 onTap:(){setState(()=>page=i);},
 child:Text(pages[i],
 style:TextStyle(color:i==page?Colors.cyan:Colors.white))
 ))));
}
