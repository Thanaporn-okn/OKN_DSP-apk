// V33 Bluetooth monitor UI
