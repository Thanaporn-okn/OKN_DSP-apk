// V33 connection manager
