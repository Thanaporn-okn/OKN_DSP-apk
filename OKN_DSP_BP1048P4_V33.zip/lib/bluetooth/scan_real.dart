// V33 Android Bluetooth scan layer
