// V33 BP1048P4 packet format
