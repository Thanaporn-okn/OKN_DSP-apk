import 'package:flutter/material.dart';

void main()=>runApp(const OKN());

class OKN extends StatelessWidget{
 const OKN({super.key});
 @override
 Widget build(BuildContext c){
  return MaterialApp(
   debugShowCheckedModeBanner:false,
   theme:ThemeData.dark(),
   home:Scaffold(
    appBar:AppBar(title:const Text('OKN_DSP BP1048P4 V33')),
    body:const Padding(
     padding:EdgeInsets.all(20),
     child:Text(
      'Bluetooth DSP Real Controller\n\n'
      'Scan Bluetooth Device\n'
      'Connect Device\n'
      'Read MAC / Name\n'
      'TX BP1048P4 Packet\n'
      'RX Response Parser\n'
      'HEX Monitor\n'
      'Volume EQ Delay\n'
      'HPF LPF Control',
      style:TextStyle(fontSize:20),
     ),
    ),
   ),
  );
 }
}
