# OKN BP1048P4 Phase3 TRUE7CH — R8

R8 เป็น diagnostic probe สำหรับบอร์ดจริง JMDSTECH / DSTech DSP ComboDigitalArchitect VID:PID `6324:1719`.

## จุดประสงค์
พิสูจน์ว่า response ของ version/info query ที่ R6 ส่งสำเร็จ อาจกลับมาทาง HID IF3 interrupt IN endpoint `0x81` แทน IF4 control `GET_REPORT INPUT`.

## ขั้นตอน
1. ติดตั้ง APK ที่ build จาก source นี้
2. กด `READ-ONLY SCAN + QUALIFY IF4`
3. ต้องเห็น PASS ทั้ง IF4 descriptor / IF4 feature / IF3 EP81
4. กดปุ่ม query เพียงครั้งเดียว
5. ส่ง log ตั้งแต่ `IF3 claim(force=false)` จนถึง `R8 complete` กลับมาวิเคราะห์

## Safety boundary
R8 มี OUT transfer ได้มากที่สุดหนึ่งครั้งต่อการกดปุ่ม: `A5 5A 00 00 16` padded ถึง 256 bytes ผ่าน HID SET_REPORT IF4. หลังจากนั้นทุก transfer เป็น IN/read-only เท่านั้น. ไม่มี DSP parameter write, EQ-as-gain, SaveParams, erase, program หรือ reboot-to-bootloader.
