from pathlib import Path
p = Path(__file__).resolve().parents[1] / 'android-usb-probe/app/src/main/java/com/okn/dsp/usbprobe/MainActivity.java'
s = p.read_text(encoding='utf-8')
required = [
    'OBSERVED_VID = 0x6324',
    'OBSERVED_PID = 0x1719',
    'EXPECTED_IF4_REPORT',
    'EXPECTED_FEATURE',
    'findIf3InterruptIn',
    'ep.getAddress()==0x81',
    'USB_ENDPOINT_XFER_INT',
    'readIf3InputControlNoClaim',
    '0xA1,0x01,0x0100,x.getId()',
    'NO CLAIM / NO FORCE DETACH',
    'A5',
    '0x5A',
    'out[2]=0x00',
    'out[3]=0x00',
    'out[4]=0x16',
    '0x21',
    '0x09',
    '0x0200',
    'No IF3 control-IN response observed',
]
for x in required:
    assert x in s, f'missing R8 guard token: {x}'
# Exactly one host-to-device HID SET_REPORT remains.
assert s.count('c.controlTransfer(\n                        0x21') == 1, 'unexpected number of host-to-device class control transfers'
# IF3 must never be claimed, especially not force-detached.
for bad in ['claimInterface(x3,false)', 'claimInterface(x3,true)', 'bulkTransfer(ep81', 'UsbRequest']:
    assert bad not in s, f'R8 must not seize IF3: {bad}'
# No firmware/DSP write vocabulary/API paths.
for bad in ['eraseFlash(', 'programFlash(', 'rebootToBootloader(', 'SaveParams(', '0x57,']:
    assert bad not in s, f'forbidden token: {bad}'
print('R8 guarded IF3 control-IN version-query USB safety: PASS')
