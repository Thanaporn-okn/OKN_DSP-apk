# R7 build notes

R7 ต่อจากผลจริงของ R6 บนบอร์ด 6324:1719:
- IF4 report descriptor exact = PASS
- IF4 Feature 8 bytes exact = PASS
- SET_REPORT 256 bytes สำเร็จที่ USB transfer layer
- IF4 control GET_REPORT INPUT หลัง query = 0 bytes

R7 จึงไม่เพิ่มคำสั่ง DSP ใหม่ แต่เพิ่มการฟัง response แบบ read-only ทาง IF3 interrupt-IN endpoint 0x81 (64 bytes) หลังส่ง version/info query เดิมเพียงหนึ่งครั้ง

Safety:
- query เดิมเท่านั้น: A5 5A 00 00 16 + zero padding to 256
- ต้องผ่าน VID/PID + IF4 descriptor + Feature + IF3 EP81 gate
- claim IF3 แบบ force=false เท่านั้น; ถ้า claim ไม่ได้ จะ BLOCK และไม่ส่ง OUT
- หลัง query มีเฉพาะ IF4 GET_REPORT INPUT และ IF3 EP81 IN reads
- ไม่มี UFE 0x57 / EQ / SaveParams / erase / program / bootloader command
