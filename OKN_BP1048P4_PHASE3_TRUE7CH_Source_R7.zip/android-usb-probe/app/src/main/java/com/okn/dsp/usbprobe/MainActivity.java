package com.okn.dsp.usbprobe;

import android.app.*;
import android.os.*;
import android.content.*;
import android.hardware.usb.*;
import android.widget.*;
import java.util.*;

public final class MainActivity extends Activity {
    private static final int OBSERVED_VID = 0x6324;
    private static final int OBSERVED_PID = 0x1719;
    private static final String ACTION_USB_PERMISSION = "com.okn.dsp.usbprobe.USB_PERMISSION";

    private static final byte[] EXPECTED_IF4_REPORT = new byte[] {
        0x06,0x00,(byte)0xFF,0x0A,(byte)0xAA,0x55,(byte)0xA1,0x01,
        0x15,0x00,0x26,(byte)0xFF,0x00,0x75,0x08,(byte)0x96,0x00,0x01,
        0x09,0x01,(byte)0x81,0x02,(byte)0x96,0x00,0x01,0x09,0x01,(byte)0x91,0x02,
        (byte)0x95,0x08,0x09,0x01,(byte)0xB1,0x02,(byte)0xC0
    };
    private static final byte[] EXPECTED_FEATURE = new byte[] {0x00,0x01,0x00,0x03,0x04,0x00,0x08,0x00};

    private UsbManager usb;
    private TextView log;
    private Button query;
    private UsbDevice selected;
    private volatile boolean queryQualified = false;

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            if (!ACTION_USB_PERMISSION.equals(i.getAction())) return;
            UsbDevice d = i.getParcelableExtra(UsbManager.EXTRA_DEVICE);
            if (i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false) && d != null) {
                selected = d;
                probeReadOnly(d);
            } else add("USB permission denied");
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        usb = (UsbManager) getSystemService(USB_SERVICE);
        buildUi();
        IntentFilter f = new IntentFilter(ACTION_USB_PERMISSION);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, RECEIVER_NOT_EXPORTED);
        else registerReceiver(receiver, f);
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(receiver);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28,28,28,28);

        TextView title = new TextView(this);
        title.setText("OKN BP1048P4 USB-C Probe R7\nRead-only qualify + ONE guarded VERSION QUERY + IF3 IN listen\nNo DSP parameter write / no erase / no firmware write");
        title.setTextSize(18);

        Button scan = new Button(this);
        scan.setText("1) READ-ONLY SCAN + QUALIFY IF4");
        query = new Button(this);
        query.setText("2) SEND ONE VERSION QUERY + LISTEN IF3 EP81 (disabled until qualified)");
        query.setEnabled(false);

        log = new TextView(this);
        log.setTextIsSelectable(true);
        ScrollView sv = new ScrollView(this);
        sv.addView(log);

        root.addView(title);
        root.addView(scan);
        root.addView(query);
        root.addView(sv, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);

        scan.setOnClickListener(v -> scan());
        query.setOnClickListener(v -> sendOneVersionQuery());
    }

    private void scan() {
        log.setText("");
        queryQualified = false;
        query.setEnabled(false);
        selected = null;
        Map<String,UsbDevice> devices = usb.getDeviceList();
        add("USB devices: " + devices.size());
        for (UsbDevice d: devices.values()) {
            int vid=d.getVendorId(), pid=d.getProductId();
            add(String.format(Locale.US,"VID=0x%04X (%d) PID=0x%04X (%d) interfaces=%d",vid,vid,pid,pid,d.getInterfaceCount()));
            dumpInterfaces(d);
            if (vid==OBSERVED_VID && pid==OBSERVED_PID) {
                selected=d;
                add("*** EXACT TARGET MATCH: 6324:1719 ***");
            }
        }
        if (selected==null) { add("Exact target not found; query remains disabled"); return; }
        requestOrProbe(selected);
    }

    private void dumpInterfaces(UsbDevice d) {
        for (int i=0;i<d.getInterfaceCount();i++) {
            UsbInterface ui=d.getInterface(i);
            add("  IDX"+i+" IF"+ui.getId()+" alt="+ui.getAlternateSetting()+" class="+ui.getInterfaceClass()+" sub="+ui.getInterfaceSubclass()+" proto="+ui.getInterfaceProtocol()+" ep="+ui.getEndpointCount());
            for (int e=0;e<ui.getEndpointCount();e++) {
                UsbEndpoint ep=ui.getEndpoint(e);
                add("    EP addr=0x"+String.format(Locale.US,"%02X",ep.getAddress())+" dir="+(ep.getDirection()==UsbConstants.USB_DIR_IN?"IN":"OUT")+" type="+ep.getType()+" max="+ep.getMaxPacketSize()+" interval="+ep.getInterval());
            }
        }
    }

    private void requestOrProbe(UsbDevice d) {
        if (usb.hasPermission(d)) { probeReadOnly(d); return; }
        int flags=PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT>=31?PendingIntent.FLAG_MUTABLE:0);
        PendingIntent pi=PendingIntent.getBroadcast(this,0,new Intent(ACTION_USB_PERMISSION).setPackage(getPackageName()),flags);
        usb.requestPermission(d,pi);
    }

    private UsbInterface findIf3(UsbDevice d) {
        for (int i=0;i<d.getInterfaceCount();i++) {
            UsbInterface x=d.getInterface(i);
            if (x.getId()==3 && x.getInterfaceClass()==UsbConstants.USB_CLASS_HID) return x;
        }
        return null;
    }

    private UsbEndpoint findIf3InterruptIn(UsbInterface x) {
        if (x==null) return null;
        for (int i=0;i<x.getEndpointCount();i++) {
            UsbEndpoint ep=x.getEndpoint(i);
            if (ep.getAddress()==0x81
                    && ep.getDirection()==UsbConstants.USB_DIR_IN
                    && ep.getType()==UsbConstants.USB_ENDPOINT_XFER_INT
                    && ep.getMaxPacketSize()==64) return ep;
        }
        return null;
    }

    private UsbInterface findIf4(UsbDevice d) {
        for (int i=0;i<d.getInterfaceCount();i++) {
            UsbInterface x=d.getInterface(i);
            if (x.getId()==4 && x.getInterfaceClass()==UsbConstants.USB_CLASS_HID) return x;
        }
        return null;
    }

    private byte[] readIf4ReportDescriptor(UsbDeviceConnection c, UsbInterface x) {
        byte[] report=new byte[64];
        int n=c.controlTransfer(0x81,0x06,0x2200,x.getId(),report,report.length,1500);
        ui("IF4 HID REPORT => "+n+" bytes");
        if (n<=0) return null;
        byte[] exact=Arrays.copyOf(report,n);
        ui("  "+hex(exact,exact.length));
        return exact;
    }

    private byte[] readFeature(UsbDeviceConnection c, UsbInterface x) {
        byte[] feature=new byte[8];
        int n=c.controlTransfer(0xA1,0x01,0x0300,x.getId(),feature,feature.length,1500);
        ui("GET_REPORT FEATURE IF4 ID0 len8 => "+n+" bytes");
        if (n>0) ui("  FEATURE: "+hex(feature,n));
        return n==8 ? feature : null;
    }

    private void probeReadOnly(UsbDevice d) {
        new Thread(() -> {
            UsbDeviceConnection c=usb.openDevice(d);
            if (c==null) { ui("openDevice failed"); return; }
            try {
                ui("Permission/open: OK");
                try {
                    ui("Manufacturer: "+safe(d.getManufacturerName()));
                    ui("Product: "+safe(d.getProductName()));
                    ui("Serial: "+safe(d.getSerialNumber()));
                } catch(Throwable t) { ui("String descriptors unavailable: "+t.getClass().getSimpleName()); }

                UsbInterface x=findIf4(d);
                UsbInterface x3=findIf3(d);
                UsbEndpoint ep81=findIf3InterruptIn(x3);
                if (x==null) { ui("IF4 HID not found; query remains disabled"); return; }
                byte[] rd=readIf4ReportDescriptor(c,x);
                byte[] ft=readFeature(c,x);

                boolean exactReport=Arrays.equals(rd,EXPECTED_IF4_REPORT);
                boolean exactFeature=Arrays.equals(ft,EXPECTED_FEATURE);
                boolean exactIf3In=ep81!=null;
                ui("IF4 descriptor exact gate: "+(exactReport?"PASS":"FAIL"));
                ui("IF4 feature exact gate: "+(exactFeature?"PASS":"FAIL"));
                ui("IF3 EP81 interrupt-IN exact gate: "+(exactIf3In?"PASS":"FAIL"));

                byte[] input=new byte[256];
                int in=c.controlTransfer(0xA1,0x01,0x0100,x.getId(),input,input.length,1500);
                ui("GET_REPORT INPUT IF4 ID0 len256 => "+in+" bytes");
                if (in>0) ui("  INPUT: "+hex(input,in));

                queryQualified = exactReport && exactFeature && exactIf3In
                        && d.getVendorId()==OBSERVED_VID && d.getProductId()==OBSERVED_PID;
                ui(queryQualified
                        ? "QUALIFIED: one version-query button enabled. Nothing has been sent OUT yet."
                        : "NOT QUALIFIED: query stays disabled.");
                runOnUiThread(() -> query.setEnabled(queryQualified));
                ui("READ-ONLY qualification complete.");
            } finally { c.close(); }
        },"okn-r6-qualify").start();
    }

    private void sendOneVersionQuery() {
        query.setEnabled(false);
        if (!queryQualified || selected==null) { add("Query blocked: qualification missing"); return; }
        new Thread(() -> {
            UsbDevice d=selected;
            UsbDeviceConnection c=usb.openDevice(d);
            if (c==null) { ui("Query openDevice failed"); return; }
            boolean claimed4=false, claimed3=false;
            UsbInterface x4=null, x3=null;
            try {
                x4=findIf4(d);
                x3=findIf3(d);
                UsbEndpoint ep81=findIf3InterruptIn(x3);
                if (x4==null || x3==null || ep81==null) {
                    ui("Query blocked: exact IF3/IF4 topology missing");
                    return;
                }

                // Re-check immutable gates immediately before the only OUT transfer.
                byte[] rd=readIf4ReportDescriptor(c,x4);
                byte[] ft=readFeature(c,x4);
                if (d.getVendorId()!=OBSERVED_VID || d.getProductId()!=OBSERVED_PID
                        || !Arrays.equals(rd,EXPECTED_IF4_REPORT)
                        || !Arrays.equals(ft,EXPECTED_FEATURE)) {
                    ui("Query blocked: pre-send IF4 gate failed");
                    return;
                }

                // R7 only proceeds if the known IF3 interrupt-IN listener can be claimed
                // without force-detaching any kernel/OS driver.
                claimed3=c.claimInterface(x3,false);
                ui("IF3 claim(force=false): "+(claimed3?"OK":"FAILED"));
                if (!claimed3) {
                    ui("Query blocked: IF3 listener unavailable; no OUT report sent.");
                    return;
                }
                claimed4=c.claimInterface(x4,false);
                ui("IF4 claim(force=false): "+(claimed4?"OK":"not claimed"));

                byte[] out=new byte[256];
                out[0]=(byte)0xA5;
                out[1]=0x5A;
                out[2]=0x00; // public BP1048-family version/info query
                out[3]=0x00; // zero payload length
                out[4]=0x16; // frame terminator

                ui("ABOUT TO SEND exactly one guarded query: A5 5A 00 00 16 + zero padding to 256");
                int wn=c.controlTransfer(
                        0x21,       // host-to-device | class | interface
                        0x09,       // HID SET_REPORT
                        0x0200,     // OUTPUT report, report ID 0
                        x4.getId(),
                        out,out.length,1500);
                ui("ONE VERSION QUERY SET_REPORT result => "+wn+" bytes");

                // Read-only response path A: control GET_REPORT on IF4 (same as R6).
                SystemClock.sleep(30);
                byte[] ctrlIn=new byte[256];
                int ctrlN=c.controlTransfer(0xA1,0x01,0x0100,x4.getId(),ctrlIn,ctrlIn.length,350);
                ui("GET_REPORT INPUT IF4 after query => "+ctrlN+" bytes");
                if (ctrlN>0) {
                    ui("  IF4 CONTROL RESPONSE: "+hex(ctrlIn,ctrlN));
                    parseVersionResponse(ctrlIn,ctrlN);
                }

                // Read-only response path B: IF3 interrupt IN EP 0x81, max packet 64.
                // No endpoint OUT exists on IF3 and R7 never performs an OUT transfer here.
                byte[] assembled=new byte[256];
                int total=0;
                for (int attempt=1; attempt<=8 && total<assembled.length; attempt++) {
                    byte[] pkt=new byte[64];
                    int rn=c.bulkTransfer(ep81,pkt,pkt.length,250);
                    ui("IF3 EP81 interrupt-IN attempt "+attempt+" => "+rn+" bytes");
                    if (rn>0) {
                        ui("  EP81: "+hex(pkt,rn));
                        int copy=Math.min(rn,assembled.length-total);
                        System.arraycopy(pkt,0,assembled,total,copy);
                        total += copy;
                        if (rn < 64) break;
                    }
                }
                if (total>0) {
                    ui("IF3 EP81 assembled => "+total+" bytes");
                    ui("  ASSEMBLED: "+hex(assembled,total));
                    parseVersionResponse(assembled,total);
                } else {
                    ui("No IF3 EP81 interrupt response observed within R7 listen window.");
                }

                ui("R7 complete: exactly one OUT report maximum; all post-query probes were IN/read-only; no DSP parameter/erase/program command exists in this APK.");
            } finally {
                if (claimed4 && x4!=null) c.releaseInterface(x4);
                if (claimed3 && x3!=null) c.releaseInterface(x3);
                c.close();
            }
        },"okn-r7-version-query-if3-listen").start();
    }

    private void parseVersionResponse(byte[] b,int n) {
        if (n>=12 && (b[0]&0xFF)==0xA5 && (b[1]&0xFF)==0x5A && (b[2]&0xFF)==0x00
                && (b[3]&0xFF)==0x07 && (b[11]&0xFF)==0x16) {
            ui(String.format(Locale.US,
                    "VERSION FRAME MATCH: family=0x%02X effect=%d.%d.%d audioLib=%d.%d.%d",
                    b[4]&0xFF,b[5]&0xFF,b[6]&0xFF,b[7]&0xFF,b[8]&0xFF,b[9]&0xFF,b[10]&0xFF));
        } else {
            ui("Response does not match expected public-SDK version frame; do not interpret it as version.");
        }
    }

    private static String safe(String s){ return s==null?"<null>":s; }
    private static String hex(byte[] b,int n){
        if (b==null || n<=0) return "<none>";
        StringBuilder s=new StringBuilder();
        for(int i=0;i<n && i<b.length;i++){
            if(i>0)s.append(' ');
            s.append(String.format(Locale.US,"%02X",b[i]&0xFF));
        }
        return s.toString();
    }
    private void add(String s){ log.append(s+"\n"); }
    private void ui(String s){ runOnUiThread(() -> add(s)); }
}
