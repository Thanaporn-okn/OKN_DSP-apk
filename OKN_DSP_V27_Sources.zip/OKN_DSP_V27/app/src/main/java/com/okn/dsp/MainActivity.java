package com.okn.dsp;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public final class MainActivity extends Activity implements DspView.Host {
    private DspView dspView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dspView = new DspView(this);
        // targetSdk 35 is edge-to-edge on Android 15+. Do not guess a status-bar
        // height: consume the actual safe-area values reported by the device.
        dspView.setOnApplyWindowInsetsListener((view, insets) -> {
            dspView.setSystemInsets(
                    insets.getSystemWindowInsetLeft(),
                    insets.getSystemWindowInsetTop(),
                    insets.getSystemWindowInsetRight(),
                    insets.getSystemWindowInsetBottom());
            return insets;
        });
        setContentView(dspView);
        dspView.requestApplyInsets();
        applySystemBars(dspView.getThemeIndex());
    }

    @Override
    protected void onPause() {
        // V20: do not perform any storage work in the visible pause transition.
        // Interactive changes are already auto-saved by the 120 ms coalescer.
        super.onPause();
    }

    @Override
    protected void onStop() {
        if (dspView != null) dspView.flushState(true);
        super.onStop();
    }

    @Override
    public void requestThemePicker(int currentTheme) {
        final int themeAccent = 0xFF10B981;
        final int themeSoft = currentTheme == 0 ? 0xFFE8FAF4 : 0xFF12372F;
        final int card = dialogCard(currentTheme);
        final int text = dialogText(currentTheme);
        final int sub = dialogSub(currentTheme);
        final int row = dialogRow(currentTheme);

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(18), dp(20), dp(18));
        root.setBackground(roundRect(card, 28));

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView titleIcon = circleIcon("T", themeAccent,
                currentTheme == 0 ? 0xFFE1F8F0 : 0xFF164A3E, 48);
        titleRow.addView(titleIcon, fixed(dp(48), dp(48)));

        LinearLayout titleText = new LinearLayout(this);
        titleText.setOrientation(LinearLayout.VERTICAL);
        titleText.setPadding(dp(14), 0, 0, 0);
        TextView title = label("Theme", 22, text, AppFonts.BOLD);
        TextView subtitle = label("Choose how OKN DSP looks on your device.", 14, sub, AppFonts.REGULAR);
        titleText.addView(title);
        titleText.addView(subtitle);
        titleRow.addView(titleText, weighted());
        root.addView(titleRow);
        addSpacer(root, 18);

        String[] names = {"Light", "Dark", "Midnight"};
        String[] descriptions = {
                "Clean and bright interface",
                "Easy on the eyes",
                "Deep dark for low light"
        };
        String[] symbols = {"☀", "◐", "✦"};

        for (int i = 0; i < names.length; i++) {
            final int index = i;
            boolean selected = i == currentTheme;
            LinearLayout option = new LinearLayout(this);
            option.setOrientation(LinearLayout.HORIZONTAL);
            option.setGravity(Gravity.CENTER_VERTICAL);
            option.setPadding(dp(12), dp(10), dp(12), dp(10));
            option.setMinimumHeight(dp(72));
            option.setBackground(strokedRoundRect(
                    selected ? themeSoft : row,
                    selected ? themeAccent : Color.TRANSPARENT,
                    selected ? 1.2f : 0f,
                    18));

            int iconFill = selected
                    ? (currentTheme == 0 ? 0xFFD5F6EA : 0xFF175344)
                    : (currentTheme == 0 ? 0xFFEAF0F7 : 0xFF233148);
            TextView icon = circleIcon(symbols[i], selected ? themeAccent : sub, iconFill, 44);
            option.addView(icon, fixed(dp(44), dp(44)));

            LinearLayout copy = new LinearLayout(this);
            copy.setOrientation(LinearLayout.VERTICAL);
            copy.setPadding(dp(12), 0, dp(8), 0);
            copy.addView(label(names[i], 17, text, AppFonts.MEDIUM));
            copy.addView(label(descriptions[i], 13, sub, AppFonts.REGULAR));
            option.addView(copy, weighted());

            RadioButton radio = new RadioButton(this);
            radio.setChecked(selected);
            radio.setClickable(false);
            radio.setFocusable(false);
            radio.setButtonTintList(new ColorStateList(
                    new int[][] {
                            new int[] {android.R.attr.state_checked},
                            new int[] {}
                    },
                    new int[] {themeAccent, sub}
            ));
            option.addView(radio, fixed(dp(42), dp(42)));

            option.setOnClickListener(v -> {
                dspView.setThemeIndex(index);
                applySystemBars(index);
                dialog.dismiss();
            });
            root.addView(option);
            if (i < names.length - 1) addSpacer(root, 9);
        }

        addSpacer(root, 16);
        TextView cancel = actionButton("Cancel", dialogAccent(currentTheme), dialogButtonSoft(currentTheme), false);
        cancel.setOnClickListener(v -> dialog.dismiss());
        root.addView(cancel, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));

        dialog.setContentView(root);
        showStyledDialog(dialog);
    }


    @Override
    public void onThemeChanged(int themeIndex) {
        // V21: invoked one vsync after the in-Canvas picker changes palette,
        // keeping system-bar recomposition off the same frame as the UI switch.
        applySystemBars(themeIndex);
    }

    @Override
    public void requestPresetName(String currentName) {
        final int theme = dspView.getThemeIndex();
        final int card = dialogCard(theme);
        final int text = dialogText(theme);
        final int sub = dialogSub(theme);
        final int accent = 0xFFEC4899;
        final int accentSoft = theme == 0 ? 0xFFFFEDF5 : 0xFF3A1728;

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(18), dp(20), dp(18));
        root.setBackground(roundRect(card, 28));

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.addView(circleIcon("P", accent, accentSoft, 48), fixed(dp(48), dp(48)));

        LinearLayout titleCopy = new LinearLayout(this);
        titleCopy.setOrientation(LinearLayout.VERTICAL);
        titleCopy.setPadding(dp(14), 0, 0, 0);
        titleCopy.addView(label("Preset name", 22, text, AppFonts.BOLD));
        titleCopy.addView(label("Give your EQ preset a memorable name.", 14, sub, AppFonts.REGULAR));
        titleRow.addView(titleCopy, weighted());
        root.addView(titleRow);
        addSpacer(root, 18);

        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setImeOptions(EditorInfo.IME_ACTION_DONE);
        input.setText(currentName == null ? "" : currentName);
        input.setHint("My EQ Preset");
        input.setTextColor(text);
        input.setHintTextColor(sub);
        input.setTextSize(16);
        input.setTypeface(AppFonts.REGULAR);
        input.setPadding(dp(14), 0, dp(14), 0);
        input.setMinimumHeight(dp(58));
        input.setBackground(strokedRoundRect(dialogRow(theme), accent, 1.2f, 16));
        if (input.getText().length() > 0) input.selectAll();
        root.addView(input, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(58)));

        addSpacer(root, 8);
        TextView helper = label("Use a name that helps you remember this sound.", 12, sub, AppFonts.REGULAR);
        helper.setPadding(dp(2), 0, 0, 0);
        root.addView(helper);
        addSpacer(root, 18);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        TextView cancel = actionButton("Cancel", accent, dialogButtonSoft(theme), false);
        TextView save = actionButton("Save", 0xFFFFFFFF, accent, true);
        LinearLayout.LayoutParams actionParams = new LinearLayout.LayoutParams(0, dp(54), 1f);
        actions.addView(cancel, actionParams);
        addHorizontalSpacer(actions, 12);
        actions.addView(save, new LinearLayout.LayoutParams(0, dp(54), 1f));
        root.addView(actions);

        Runnable doSave = () -> {
            String name = input.getText().toString().trim();
            if (name.isEmpty()) name = "Preset";
            dspView.savePreset(name);
            dialog.dismiss();
        };
        cancel.setOnClickListener(v -> dialog.dismiss());
        save.setOnClickListener(v -> doSave.run());
        input.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                doSave.run();
                return true;
            }
            return false;
        });

        dialog.setContentView(root);
        dialog.setOnShowListener(ignored -> {
            styleDialogWindow(dialog.getWindow());
            input.requestFocus();
            Window w = dialog.getWindow();
            if (w != null) w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        });
        dialog.show();
    }

    @Override
    public void requestPresetPicker(String currentName) {
        String[] names = dspView.getPresetNames();
        if (names.length == 0) {
            showMessage("No saved presets");
            return;
        }

        final int theme = dspView.getThemeIndex();
        final int card = dialogCard(theme);
        final int text = dialogText(theme);
        final int sub = dialogSub(theme);
        final int accent = dialogAccent(theme);
        final int row = dialogRow(theme);
        final int selectedSoft = theme == 0 ? 0xFFE8FAF4 : 0xFF12372F;

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(18), dp(20), dp(18));
        root.setBackground(roundRect(card, 28));

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.addView(circleIcon("P", accent, dialogAccentSoft(theme), 48), fixed(dp(48), dp(48)));

        LinearLayout titleCopy = new LinearLayout(this);
        titleCopy.setOrientation(LinearLayout.VERTICAL);
        titleCopy.setPadding(dp(14), 0, 0, 0);
        titleCopy.addView(label("Saved Presets", 22, text, AppFonts.BOLD));
        titleCopy.addView(label("Tap a preset to load it instantly.", 14, sub, AppFonts.REGULAR));
        titleRow.addView(titleCopy, weighted());
        root.addView(titleRow);
        addSpacer(root, 18);

        for (int i = 0; i < names.length; i++) {
            final String preset = names[i];
            final boolean selected = preset.equals(currentName);

            LinearLayout option = new LinearLayout(this);
            option.setOrientation(LinearLayout.HORIZONTAL);
            option.setGravity(Gravity.CENTER_VERTICAL);
            option.setPadding(dp(14), dp(10), dp(14), dp(10));
            option.setMinimumHeight(dp(62));
            option.setBackground(strokedRoundRect(
                    selected ? selectedSoft : row,
                    selected ? accent : Color.TRANSPARENT,
                    selected ? 1.2f : 0f,
                    18));

            TextView initial = circleIcon(preset.substring(0, 1).toUpperCase(),
                    selected ? accent : sub,
                    selected ? dialogAccentSoft(theme) : (theme == 0 ? 0xFFEAF0F7 : 0xFF233148),
                    40);
            option.addView(initial, fixed(dp(40), dp(40)));

            LinearLayout copy = new LinearLayout(this);
            copy.setOrientation(LinearLayout.VERTICAL);
            copy.setPadding(dp(12), 0, dp(8), 0);
            copy.addView(label(preset, 17, text, AppFonts.MEDIUM));
            copy.addView(label(selected ? "Currently loaded" : "Load this preset", 12, sub, AppFonts.REGULAR));
            option.addView(copy, weighted());

            TextView marker = label(selected ? "✓" : "›", 24,
                    selected ? accent : sub, AppFonts.MEDIUM);
            marker.setGravity(Gravity.CENTER);
            option.addView(marker, fixed(dp(36), dp(36)));

            option.setOnClickListener(v -> {
                // V20: selection and loading remain one immediate operation.
                dspView.selectPreset(preset);
                dialog.dismiss();
            });
            root.addView(option);
            if (i < names.length - 1) addSpacer(root, 9);
        }

        addSpacer(root, 16);
        TextView cancel = actionButton("Cancel", accent, dialogButtonSoft(theme), false);
        cancel.setOnClickListener(v -> dialog.dismiss());
        root.addView(cancel, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));

        dialog.setContentView(root);
        showStyledDialog(dialog);
    }

    @Override
    public void requestDeletePreset(String currentName) {
        String[] names = dspView.getPresetNames();
        if (names.length == 0) {
            showMessage("No saved presets");
            return;
        }

        final int theme = dspView.getThemeIndex();
        final int card = dialogCard(theme);
        final int text = dialogText(theme);
        final int sub = dialogSub(theme);
        final int row = dialogRow(theme);
        final int danger = theme == 0 ? 0xFFE11D48 : 0xFFFF5A78;
        final int dangerSoft = theme == 0 ? 0xFFFFE8EF : 0xFF3A1824;
        final int dangerRow = theme == 0 ? 0xFFFFF5F7 : 0xFF2B1821;

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(18), dp(20), dp(18));
        root.setBackground(roundRect(card, 28));

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.addView(circleIcon("!", danger, dangerSoft, 48), fixed(dp(48), dp(48)));

        LinearLayout titleCopy = new LinearLayout(this);
        titleCopy.setOrientation(LinearLayout.VERTICAL);
        titleCopy.setPadding(dp(14), 0, 0, 0);
        titleCopy.addView(label("Delete preset", 22, text, AppFonts.BOLD));
        titleCopy.addView(label("Remove this EQ preset from your saved presets.", 14, sub, AppFonts.REGULAR));
        titleRow.addView(titleCopy, weighted());
        root.addView(titleRow);
        addSpacer(root, 18);

        LinearLayout presetCard = new LinearLayout(this);
        presetCard.setOrientation(LinearLayout.HORIZONTAL);
        presetCard.setGravity(Gravity.CENTER_VERTICAL);
        presetCard.setPadding(dp(14), dp(12), dp(14), dp(12));
        presetCard.setBackground(strokedRoundRect(dangerRow, danger, 1.0f, 18));

        String initialText = (currentName == null || currentName.isEmpty())
                ? "P" : currentName.substring(0, 1).toUpperCase();
        presetCard.addView(circleIcon(initialText, danger, dangerSoft, 42), fixed(dp(42), dp(42)));

        LinearLayout presetCopy = new LinearLayout(this);
        presetCopy.setOrientation(LinearLayout.VERTICAL);
        presetCopy.setPadding(dp(12), 0, 0, 0);
        presetCopy.addView(label(currentName == null ? "Preset" : currentName, 17, text, AppFonts.MEDIUM));
        presetCopy.addView(label("This action cannot be undone.", 12, sub, AppFonts.REGULAR));
        presetCard.addView(presetCopy, weighted());
        root.addView(presetCard);
        addSpacer(root, 18);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        TextView cancel = actionButton("Cancel", dialogAccent(theme), dialogButtonSoft(theme), false);
        TextView delete = actionButton("Delete", 0xFFFFFFFF, danger, true);
        actions.addView(cancel, new LinearLayout.LayoutParams(0, dp(54), 1f));
        addHorizontalSpacer(actions, 12);
        actions.addView(delete, new LinearLayout.LayoutParams(0, dp(54), 1f));
        root.addView(actions);

        cancel.setOnClickListener(v -> dialog.dismiss());
        delete.setOnClickListener(v -> {
            dspView.deletePreset(currentName);
            dialog.dismiss();
        });

        dialog.setContentView(root);
        showStyledDialog(dialog);
    }

    @Override
    public void showMessage(String message) {
        Toast toast = Toast.makeText(this, message, Toast.LENGTH_SHORT);
        toast.show();
    }

    private void showStyledDialog(Dialog dialog) {
        dialog.setCanceledOnTouchOutside(true);
        dialog.setOnShowListener(ignored -> styleDialogWindow(dialog.getWindow()));
        dialog.show();
    }

    private void styleDialogWindow(Window w) {
        if (w == null) return;
        w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        // V20: remove the platform dialog zoom/fade animation. On some Samsung
        // devices that animation competes with our full-screen custom Canvas and
        // produces visible hitching. The dialog now appears/dismisses instantly.
        w.setWindowAnimations(0);
        w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        WindowManager.LayoutParams attrs = w.getAttributes();
        attrs.dimAmount = 0.52f;
        w.setAttributes(attrs);
        int screen = getResources().getDisplayMetrics().widthPixels;
        int width = Math.min(screen - dp(32), dp(560));
        w.setLayout(Math.max(dp(280), width), WindowManager.LayoutParams.WRAP_CONTENT);
    }

    private TextView label(String value, float sp, int color, Typeface face) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setTypeface(face);
        v.setIncludeFontPadding(false);
        return v;
    }

    private TextView circleIcon(String value, int foreground, int fill, int sizeDp) {
        TextView v = label(value, 20, foreground, AppFonts.BOLD);
        v.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(fill);
        v.setBackground(bg);
        v.setMinWidth(dp(sizeDp));
        v.setMinHeight(dp(sizeDp));
        return v;
    }

    private TextView actionButton(String value, int foreground, int fill, boolean strong) {
        TextView v = label(value, 15, foreground, strong ? AppFonts.MEDIUM : AppFonts.REGULAR);
        v.setGravity(Gravity.CENTER);
        v.setBackground(roundRect(fill, 16));
        v.setClickable(true);
        v.setFocusable(true);
        return v;
    }

    private GradientDrawable roundRect(int color, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.RECTANGLE);
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private GradientDrawable strokedRoundRect(int fill, int strokeColor, float strokeDp, float radiusDp) {
        GradientDrawable d = roundRect(fill, radiusDp);
        if (strokeDp > 0f && strokeColor != Color.TRANSPARENT) {
            d.setStroke(Math.max(1, dp(strokeDp)), strokeColor);
        }
        return d;
    }

    private LinearLayout.LayoutParams weighted() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
    }

    private LinearLayout.LayoutParams fixed(int width, int height) {
        return new LinearLayout.LayoutParams(width, height);
    }

    private void addSpacer(LinearLayout root, int heightDp) {
        View spacer = new View(this);
        root.addView(spacer, new LinearLayout.LayoutParams(1, dp(heightDp)));
    }

    private void addHorizontalSpacer(LinearLayout root, int widthDp) {
        View spacer = new View(this);
        root.addView(spacer, new LinearLayout.LayoutParams(dp(widthDp), 1));
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private int dialogCard(int theme) {
        if (theme == 0) return 0xFFFDFEFF;
        if (theme == 1) return 0xFF151E2D;
        return 0xFF0C1421;
    }

    private int dialogRow(int theme) {
        if (theme == 0) return 0xFFF2F6FA;
        if (theme == 1) return 0xFF1C283A;
        return 0xFF111F31;
    }

    private int dialogText(int theme) {
        return theme == 0 ? 0xFF0C1220 : 0xFFF3F7FD;
    }

    private int dialogSub(int theme) {
        return theme == 0 ? 0xFF748399 : 0xFF9EABBE;
    }

    private int dialogAccent(int theme) {
        if (theme == 0) return 0xFF138CF5;
        if (theme == 1) return 0xFF2E9BFF;
        return 0xFF21B7FF;
    }

    private int dialogAccentSoft(int theme) {
        if (theme == 0) return 0xFFE7F2FF;
        if (theme == 1) return 0xFF142C45;
        return 0xFF09253A;
    }

    private int dialogButtonSoft(int theme) {
        if (theme == 0) return 0xFFEAF0F7;
        if (theme == 1) return 0xFF1D2A3D;
        return 0xFF122238;
    }

    private void lockDialogTypeface(AlertDialog dialog) {
        Window w = dialog.getWindow();
        if (w == null) return;
        applyTypefaceRecursive(w.getDecorView());
    }

    private void applyTypefaceRecursive(View view) {
        if (view instanceof TextView) {
            TextView tv = (TextView) view;
            int style = tv.getTypeface() == null ? 0 : tv.getTypeface().getStyle();
            tv.setTypeface((style & Typeface.BOLD) != 0 ? AppFonts.BOLD : AppFonts.REGULAR);
        }
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                applyTypefaceRecursive(group.getChildAt(i));
            }
        }
    }

    private void applySystemBars(int themeIndex) {
        boolean light = themeIndex == 0;
        int bg;
        if (themeIndex == 0) bg = 0xFFF4F7FB;
        else if (themeIndex == 1) bg = 0xFF0D1320;
        else bg = 0xFF050A13;

        Window window = getWindow();
        window.setStatusBarColor(bg);
        window.setNavigationBarColor(bg);

        if (android.os.Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = window.getInsetsController();
            if (c != null) {
                int mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                        | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                c.setSystemBarsAppearance(light ? mask : 0, mask);
            }
        } else {
            int flags = window.getDecorView().getSystemUiVisibility();
            if (light) {
                flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                if (android.os.Build.VERSION.SDK_INT >= 26) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            } else {
                flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                if (android.os.Build.VERSION.SDK_INT >= 26) flags &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            }
            window.getDecorView().setSystemUiVisibility(flags);
        }
    }
}
