# OKN DSP V27 — Phase 1

Base: V25. V27 keeps the V25 UI/touch/performance/preset fixes and keeps the V25/V26 behavior and redraws the circled Home status icons with a cleaner, more balanced style closer to the reference.

## V27 icon redesign

All Home icons are recreated from **Canvas/vector/shape code**. The uploaded reference is used only as a visual guide; it is **not copied into the app, embedded as a screenshot, or used as a background**.

- Bluetooth — clean blue badge, white Bluetooth glyph
- DSP Device — clean pink badge, white chip glyph
- Audio Input — clean red/rose badge, white waveform glyph
- Amplifier Link — clean pink/red badge, white speaker glyph
- Preset Sync — clean cyan/teal badge, white preset/document glyph
- Firmware Status — clean violet badge, white gear glyph
- Quick Control — soft pink rounded badge, pink EQ bars

versionName: 27.0.0
versionCode: 1027
Phase: 1 UI hardening

V27 specifically removes the heavy V26 glow, enlarges and refines the white glyphs, adds cleaner spacing, and uses a lighter pastel halo around each badge.
