OKN_DSP V27 — LONG-SESSION EQ ANTI-SURGE
========================================
Base: V26.
No BLE/auth/AES/UFE packet format change.
No new actuator IDs.
No Crossover hardware writes.

Acoustic safety change for PEAKING Bands 2-15:
1. Never release a negative cut to 0 dB merely to migrate its centre.
2. Positive boosts are still neutralized before centre migration.
3. Negative/zero bands migrate at a non-positive bridge gain.
4. Energy-increasing gain transitions are capped at +1.0 dB per official-style 380 ms scheduler slot.
5. Latest target wins during the slew.
6. V26 Safe Reset is retained unchanged.

Goal: eliminate the ~1 second loud surge that can appear after prolonged EQ tuning while preserving the V24/V26 no-whine/no-reset-spike behavior.
