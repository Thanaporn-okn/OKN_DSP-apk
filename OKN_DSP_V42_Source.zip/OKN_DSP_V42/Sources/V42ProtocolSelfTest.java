package com.okn.dsp;

public final class V42ProtocolSelfTest {
    private static void require(boolean ok, String what) {
        if (!ok) throw new AssertionError(what);
    }
    private static String hex(byte[] b) {
        StringBuilder s = new StringBuilder();
        for (byte v : b) s.append(String.format("%02X", v & 0xff));
        return s.toString();
    }
    public static void main(String[] args) {
        require(DspProtocol.OKN_CHANNEL_VOLUME_IDS.length == 7, "7 IDs");
        for (int i = 0; i < 7; i++) {
            require(DspProtocol.OKN_CHANNEL_VOLUME_IDS[i] == 22 + i, "ID sequence");
            require(DspProtocol.channelVolumeNameMatches(22 + i, "Channel" + (i + 1) + "Volume"), "name gate");
            require(DspProtocol.channelForVolumeActuator(22 + i) == i, "reverse map");
        }
        require(Float.isNaN(DspProtocol.sanitizeChannelVolume(-70.1f)), "low clamp fail-closed");
        require(Float.isNaN(DspProtocol.sanitizeChannelVolume(6.1f)), "high clamp fail-closed");
        require(DspProtocol.sanitizeChannelVolume(0.5f) == 0.5f, "valid volume");
        require("570000001600000004000040C0".equals(hex(DspProtocol.encodeFloatWrite(22, -3.0f))), "CH1 -3 dB bytes");
        require("570000001C000000040000003F".equals(hex(DspProtocol.encodeFloatWrite(28, 0.5f))), "CH7 +0.5 dB bytes");
        for (int ch = 0; ch < 7; ch++) {
            require(DspProtocol.eqActuatorForChannel0(ch) != DspProtocol.channelVolumeIdForChannel0(ch), "EQ and volume IDs separate");
        }
        System.out.println("V42 protocol self-test: PASS");
    }
}
