#!/usr/bin/env python3
from pathlib import Path
import re, subprocess, tempfile, shutil

ROOT = Path(__file__).resolve().parents[1]

def read(rel):
    return (ROOT / rel).read_text(encoding="utf-8")

def need(cond, msg):
    if not cond:
        raise SystemExit("FAIL: " + msg)

build = read("app/build.gradle")
proto = read("app/src/main/java/com/okn/dsp/DspProtocol.java")
ble = read("app/src/main/java/com/okn/dsp/BleManager.java")
view = read("app/src/main/java/com/okn/dsp/DspView.java")
bridge = read("app/src/main/java/com/okn/dsp/protocol/Phase2ProtocolBridge.java")

need("versionCode 1042" in build and "versionName '42.0.0'" in build, "V42 version")
need("{22, 23, 24, 25, 26, 27, 28}" in proto, "custom volume IDs")
for n in range(1, 8):
    need(f'"Channel" + (channel0 + 1) + "Volume"' in proto, "exact ChannelNVolume name generator")
    break
need("channelVolumeProfileReady = channelVolumeValues.size() == DspProtocol.OKN_CHANNEL_VOLUME_IDS.length" in ble,
     "all-seven descriptor gate")
need("DspProtocol.channelVolumeNameMatches" in ble and "TYPE_FLOAT32" in ble,
     "descriptor name/type gate")
need("ble.setChannelVolumeRealtime(ch, next)" in view, "+/- sends dedicated channel volume")
need("channelVolumeNotYetMapped" in bridge and "UnsupportedOperationException" in bridge,
     "stock mapping remains explicitly locked")

m = re.search(r"void setChannelVolumeRealtime\(.*?\n    \}", ble, flags=re.S)
need(m is not None, "channel-volume writer method")
block = m.group(0)
need("setScalarRealtimeOnMain" in block, "channel volume uses scalar UFE lane")
need("setEqRealtime" not in block and "encodeEqWrite" not in block, "channel volume never routes through EQ")

# No private signing material in deliverable source.
for ext in ("*.jks", "*.keystore", "*.p12", "*.pfx"):
    need(not list(ROOT.rglob(ext)), f"no signing material ({ext})")

# Compile and run the pure-Java protocol byte-vector test when javac is available.
if shutil.which("javac") and shutil.which("java"):
    with tempfile.TemporaryDirectory() as td:
        subprocess.run([
            "javac", "-d", td,
            str(ROOT / "app/src/main/java/com/okn/dsp/DspProtocol.java"),
            str(ROOT / "Sources/V42ProtocolSelfTest.java")
        ], check=True)
        subprocess.run(["java", "-cp", td, "com.okn.dsp.V42ProtocolSelfTest"], check=True)

print("V42 TRUE 7CH validation: PASS")
