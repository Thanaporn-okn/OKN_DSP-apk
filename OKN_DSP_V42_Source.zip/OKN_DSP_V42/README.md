# OKN DSP V42 — TRUE 7CH Volume Controller

V42 ต่อจาก V41 และแก้ข้อจำกัดสำคัญของแอปเดิม: **Volume/Gain แยก CH1–CH7 ต้องเป็น dedicated channel level จริง ห้ามใช้ EQ Gain แทน Volume**

## สิ่งที่พิสูจน์ได้จาก stock GoloPine firmware

- Device Description เดิมมี actuator 15 ตัว แต่ **ไม่มี standalone CH1–CH7 volume actuator ที่ยืนยันได้**
- CH1–CH7 EQ ใช้ actuator ID 4,5,6,14,15,16,17 และยังคงเป็น EQ เท่านั้น
- `channelVolume[]` ใน UI รุ่นก่อนเป็น local state; source เดิมมี guard ที่ระบุชัดว่า mapping ของ per-channel volume ยังไม่ถูกยืนยัน

ดังนั้น V42 **ไม่ส่งค่า Channel Volume ไปหา stock firmware แบบเดา ID** และไม่แอบเปลี่ยน EQ Gain เพื่อหลอกว่าเป็น Volume

## OKN custom-firmware contract

เมื่อเฟิร์มแวร์ OKN รุ่นใหม่ประกาศ Device Description ที่มี actuator ต่อไปนี้ครบ 7 ตัว:

| CH | ID | name | type | range |
|---|---:|---|---:|---:|
| 1 | 22 | Channel1Volume | FLOAT32 (2000) | -70..+6 dB |
| 2 | 23 | Channel2Volume | FLOAT32 (2000) | -70..+6 dB |
| 3 | 24 | Channel3Volume | FLOAT32 (2000) | -70..+6 dB |
| 4 | 25 | Channel4Volume | FLOAT32 (2000) | -70..+6 dB |
| 5 | 26 | Channel5Volume | FLOAT32 (2000) | -70..+6 dB |
| 6 | 27 | Channel6Volume | FLOAT32 (2000) | -70..+6 dB |
| 7 | 28 | Channel7Volume | FLOAT32 (2000) | -70..+6 dB |

แอปจึงปลดล็อกปุ่ม `− / +` ของ CH1–CH7 โดย step = 0.5 dB และใช้ UFE FLOAT32 writer เดิมผ่าน authenticated AES/CFB8 BLE session

Plaintext ก่อนเข้ารหัส:

`57 | actuatorId:u32 BE | 0000 | 0004 | float32_dB LE`

ตัวอย่าง CH1 = -3.0 dB:

`57 00 00 00 16 00 00 00 04 00 00 40 C0`

ตัวอย่าง CH7 = +0.5 dB:

`57 00 00 00 1C 00 00 00 04 00 00 00 3F`

Ciphertext ห้าม hard-code เพราะขึ้นกับ RandKey/session และสถานะต่อเนื่องของ AES-CFB8

## Safety gate

V42 จะเปิด 7CH Volume เฉพาะเมื่อ fresh Device Description หลัง AUTH มี ID22..28 ครบ, type FLOAT32, ชื่อ `Channel1Volume` … `Channel7Volume` ตรงทุกตัว และค่าปัจจุบันอยู่ในช่วงที่กำหนด ถ้าเป็น stock firmware ปุ่มจะถูกล็อกและจะไม่มี packet ID22..28 ถูกส่งออกไป

ฟังก์ชัน EQ เดิมยังทำงานตาม actuator ของ EQ เดิมเท่านั้น และไม่ได้ถูกเรียกจากทางเดิน Channel Volume

## Version

- `versionName = 42.0.0`
- `versionCode = 1042`
- `compileSdk/targetSdk = 35`
- Java 17

## Build

ใช้ `OKN_DSP_V42_AutoBuild.yml` ที่แนบมากับชุด release หรือ build ด้วย Android Gradle Plugin 8.7.3 + Gradle 8.9 + JDK 17

ก่อน build ให้รัน:

```bash
python3 Sources/validate_v42_true7ch.py
```

APK debug จาก CI ใช้ Android debug keystore ตามปกติ ชุด Source.zip ไม่มี private signing key
