# OKN_BP1048P4_FW_V22

V22 preserves the V21 read-only Android discovery capture/import path and adds a multi-capture transport fingerprint layer. The goal is to distinguish a one-off observation from a transport identity that repeats consistently across independent phone sessions, without turning observation into hardware authorization.

## What V22 adds

- `transport_fingerprint_manifest.json`
- `tools/discovery_fingerprint.py`
- `tools/verify_discovery_fingerprint.py`
- `tests/test_discovery_fingerprint.py`
- minimum two independent sessions before `OBSERVED_STABLE`
- USB serial numbers, BLE addresses, RSSI, timestamps, and opaque transcript payloads excluded from structural fingerprints
- `OBSERVED_STABLE` remains non-authorizing; `android_host_transport_verified` stays false
- disagreement between repeated captures produces `INCONSISTENT`

The wire frame remains Protocol V2. DSP/core behavior is unchanged. V22 intentionally contains no destructive executor, programmer packet, bootloader command, target address/pin sequence, or flash image.

Run:

```sh
make verify
make test
make demo
```

See `docs/DISCOVERY_FINGERPRINT_V22.md`, `docs/ANDROID_DISCOVERY_CAPTURE_V22.md`, `docs/HARDWARE_DISCOVERY_V22.md`, `docs/MOBILE_FLASH_TRANSACTION_V19.md`, and `docs/PORT_INTEGRATION_PLAN_V18.md`.
