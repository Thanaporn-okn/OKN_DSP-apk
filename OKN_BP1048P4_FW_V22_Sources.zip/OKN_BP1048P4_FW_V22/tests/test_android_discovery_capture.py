#!/usr/bin/env python3
from pathlib import Path
import copy, hashlib, json, sys, tempfile
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'tools'))
from android_discovery_capture import canonical_sha256, validate_capture, validate_capture_file
from import_android_discovery import import_capture
from hardware_discovery import load_and_verify

def make_capture(transport='usb_host'):
    kind={'usb_host':'usb_device','ble':'ble_advertisement','serial_enumeration':'serial_device'}[transport]
    op='enumerate'
    c={
      'schema':1,'project_version':22,'format':'OKN_ANDROID_DISCOVERY_CAPTURE','format_version':1,
      'target':'BP1048P4','board':'GoloPine 7CH',
      'policy':'READ_ONLY_ENUMERATION_CANONICAL_HASH_NO_COMMANDS_NO_AUTHORIZATION',
      'transport':transport,'read_only':True,'write_attempted':False,'commands_sent':[],
      'source':{'platform':'android','collector':'synthetic-v21-unit-test','permission_granted':True},
      'observations':[{'kind':kind,'operation':op,'metadata':{'synthetic':True,'value':123}}],
      'transcript':[{'operation':op,'direction':'metadata','note':'synthetic enumeration only'}],
    }
    c['canonical_sha256']=canonical_sha256(c)
    return c

for transport in ('usb_host','ble','serial_enumeration'):
    c=make_capture(transport); r=validate_capture(c)
    assert r['ok'] and r['transport']==transport and not r['programmer_io_available']

c=make_capture(); bad=copy.deepcopy(c); bad['write_attempted']=True; bad['canonical_sha256']=canonical_sha256(bad)
assert not validate_capture(bad)['ok']
bad=copy.deepcopy(c); bad['commands_sent']=['vendor-probe']; bad['canonical_sha256']=canonical_sha256(bad)
assert not validate_capture(bad)['ok']
bad=copy.deepcopy(c); bad['observations'][0]['operation']='program'; bad['canonical_sha256']=canonical_sha256(bad)
assert not validate_capture(bad)['ok']
bad=copy.deepcopy(c); bad['canonical_sha256']='0'*64
assert not validate_capture(bad)['ok']

with tempfile.TemporaryDirectory() as td:
    td=Path(td); (td/'hardware_probe_evidence').mkdir()
    # Minimal V22 discovery manifest copied from shipped source.
    (td/'hardware_discovery_manifest.json').write_text((root/'hardware_discovery_manifest.json').read_text())
    cp=td/'capture.json'; cp.write_text(json.dumps(c,indent=2)+'\n')
    assert validate_capture_file(cp)['ok']
    ir=import_capture(td,cp,'phone-usb-test')
    assert ir['imported'] and not ir['duplicate']
    rr=load_and_verify(td/'hardware_discovery_manifest.json',td)
    assert rr['ok'] and rr['review_ready'] and rr['valid_capture_count']==1
    assert not rr['hardware_authorized'] and not rr['mobile_flash_authorized'] and not rr['programmer_io_available']
    # Exact duplicate is idempotent and does not create a second capture.
    ir2=import_capture(td,cp,'another-id-not-used')
    assert ir2['duplicate']
    m=json.loads((td/'hardware_discovery_manifest.json').read_text()); assert len(m['captures'])==1
    # Tamper with the imported bytes: outer raw hash binding catches it.
    imported=td/'hardware_probe_evidence'/m['captures'][0]['path']; imported.write_text('{}\n')
    rr=load_and_verify(td/'hardware_discovery_manifest.json',td)
    assert not rr['ok'] and any('sha256 mismatch' in e for e in rr['errors'])

print('ALL V22 ANDROID DISCOVERY CAPTURE TESTS PASS')
