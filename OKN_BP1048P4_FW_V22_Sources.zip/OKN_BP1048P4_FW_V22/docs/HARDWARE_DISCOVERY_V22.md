# V22 Read-Only Hardware Discovery Contract

V22 adds a non-authorizing intake layer for observations that can be collected from an
Android phone or desktop without sending target-specific commands. Examples are OS-level
USB host enumeration, BLE advertisement metadata, serial-port enumeration, a vendor tool's
read-only log, or board-photo metadata.

Every capture is content-bound by SHA256 and must live under `hardware_probe_evidence/`.
The verifier rejects traversal, symlinks, duplicate IDs, hash mismatches, any non-empty
`commands_sent`, or `write_attempted=true`.

A valid discovery capture is only **ready for review**. It does not prove the BP1048P4
programmer protocol, does not set `android_host_transport` in target qualification, and
does not authorize hardware/mobile flashing. Promotion to an exact claim still requires
the V17 content-bound qualification process plus explicit authorization.

V22 contains no vendor USB request, BLE write, serial command, programmer packet, boot
sequence, erase/program operation, target address, pin value, or flash image.
