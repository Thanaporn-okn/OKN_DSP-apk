#!/usr/bin/env python3
from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'evidence_manifest.json').read_text())
errors=[]
if m.get('schema')!=4: errors.append('evidence schema must be 4')
if m.get('project_version')!=22: errors.append('project_version must be 22')
if m.get('target')!='BP1048P4' or m.get('board')!='GoloPine 7CH': errors.append('target/board mismatch')
if m.get('policy')!='FAIL_CLOSED_NO_INFERENCE': errors.append('policy mismatch')
if m.get('hardware_authorized') is not False: errors.append('hardware_authorized must be false')
req=m.get('required_exact_evidence',{})
if any(bool(v) for v in req.values()): errors.append('V22 exact evidence flags must all remain false')
prov=m.get('provenance',{})
if prov.get('previous_source_sha256')!='d6e1015f4a59585706e30cbf3694970a78e9e73768cfdefc7ee74f259d0153b5': errors.append('V21 source provenance mismatch')
if prov.get('validation_zip_sha256')!='976a18f30e015167b477c3bd03dd0bd9c631b9c43cbce14a7a97c520bbc5de4d': errors.append('V21 validation provenance mismatch')
if not any(o.get('id')=='v21-ci-validation' for o in m.get('observations',[])): errors.append('V21 CI observation missing')
for ob in m.get('observations',[]):
    if ob.get('authorizes') not in ([],None): errors.append('observations may not authorize hardware in V22')
if errors:
    [print('BLOCKED:',e) for e in errors]; sys.exit(1)
print('PASS: V22 evidence manifest is internally consistent and non-authorizing')
