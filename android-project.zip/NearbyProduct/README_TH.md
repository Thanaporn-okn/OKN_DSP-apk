# NearbyProduct v0.2.0

เวอร์ชันนี้เพิ่มจากชุดแรก:

- Bottom Navigation 5 หน้าใช้งานจริง
  - หน้าแรก
  - กลุ่ม
  - Marketplace
  - ค้นหา
  - รายการโปรด
- Favorite ทำงานข้ามทุกหน้าใน session เดียวกัน
- ขอสิทธิ์ Location runtime
- ใช้ FusedLocationProviderClient อ่านตำแหน่งจริง
- คำนวณระยะทางจริงจาก GPS ไปยังพิกัดสินค้า
- Search + Category filter
- Search radius 1 / 5 / 10 / 20 / 50 / 100 กม. / ไม่จำกัด
- แยกสินค้า Facebook Group และ Marketplace
- Search screen มีพื้นที่ Map placeholder เพื่อเตรียมเชื่อม Google Maps/OpenStreetMap ภายหลัง

## GitHub Actions

ใช้ `build-apk.yml` ตัวเดิมได้เลย

แทนที่ไฟล์ใน repository ด้วย:
`android-project.zip`

จากนั้น Commit/Push แล้ว GitHub Actions จะ build APK อัตโนมัติ

## ยังไม่เชื่อมในเวอร์ชันนี้

- Facebook/Meta API จริง
- Google Maps / OpenStreetMap tiles จริง
- Room persistence สำหรับ Favorite
- Product Detail
- Notification / Saved Search
- รูปสินค้าจริงจาก backend

สาเหตุที่ยังไม่เชื่อม Facebook จริง:
ต้องกำหนดช่องทาง API/สิทธิ์ที่บัญชี Meta Developer ได้รับก่อน
เพื่อไม่ให้ใช้ scraping หรือช่องทางที่ขัดกับข้อกำหนดของ Meta
