# NearbyProduct Android

Android Jetpack Compose starter project for the nearby-products UI.

## Local build
Requires JDK 17, Android SDK 35 and Gradle 8.9.

```bash
gradle clean assembleDebug
```

APK output:
`app/build/outputs/apk/debug/app-debug.apk`
