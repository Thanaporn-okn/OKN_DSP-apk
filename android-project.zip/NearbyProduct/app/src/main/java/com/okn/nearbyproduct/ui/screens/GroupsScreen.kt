package com.okn.nearbyproduct.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.okn.nearbyproduct.location.UserLocation
import com.okn.nearbyproduct.model.Product
import com.okn.nearbyproduct.model.ProductSource
import com.okn.nearbyproduct.ui.components.ProductListCard

@Composable
fun GroupsScreen(
    products: List<Product>,
    userLocation: UserLocation?,
    favoriteIds: Set<String>,
    onToggleFavorite: (String) -> Unit,
) {
    val groupProducts = products.filter { it.source == ProductSource.FACEBOOK_GROUP }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(top = 12.dp),
    ) {
        Text(
            text = "สินค้าในกลุ่ม",
            modifier = Modifier.padding(horizontal = 14.dp),
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
        )
        Text(
            text = "${groupProducts.size} รายการ · แสดงเฉพาะแหล่งข้อมูลที่ได้รับอนุญาต",
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        LazyColumn(
            contentPadding = PaddingValues(10.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp),
        ) {
            items(groupProducts, key = { it.id }) { product ->
                ProductListCard(
                    product = product,
                    userLocation = userLocation,
                    isFavorite = product.id in favoriteIds,
                    onFavorite = { onToggleFavorite(product.id) },
                )
            }
        }
    }
}
