package com.okn.nearbyproduct.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.okn.nearbyproduct.location.UserLocation
import com.okn.nearbyproduct.model.Product
import com.okn.nearbyproduct.ui.components.ProductGridCard

@Composable
fun HomeScreen(
    products: List<Product>,
    userLocation: UserLocation?,
    favoriteIds: Set<String>,
    onToggleFavorite: (String) -> Unit,
    onRequestLocation: () -> Unit,
) {
    val categories = listOf("ทั้งหมด", "รถยนต์", "มือถือ", "คอมพิวเตอร์", "บ้านและสวน", "อื่น ๆ")
    var selectedCategory by remember { mutableIntStateOf(0) }
    var search by remember { mutableStateOf("") }

    val filtered = products.filter { product ->
        val categoryOk = selectedCategory == 0 ||
            product.category == categories[selectedCategory]
        val searchOk = search.isBlank() ||
            product.title.contains(search, ignoreCase = true) ||
            product.locationName.contains(search, ignoreCase = true)
        categoryOk && searchOk
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(
                modifier = Modifier.weight(1f),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                    )
                    Text(
                        text = if (userLocation == null) {
                            " ใช้ตำแหน่งของฉัน"
                        } else {
                            " GPS พร้อมใช้งาน"
                        },
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
                Text(
                    text = userLocation?.let {
                        "%.5f, %.5f".format(it.latitude, it.longitude)
                    } ?: "แตะเพื่อขอสิทธิ์ตำแหน่ง",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            IconButton(onClick = onRequestLocation) {
                Icon(Icons.Default.LocationOn, contentDescription = "อัปเดตตำแหน่ง")
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                placeholder = { Text("ค้นหาสินค้า...") },
            )
            IconButton(onClick = {}) {
                Icon(Icons.Default.Tune, contentDescription = "ตัวกรอง")
            }
        }

        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(categories) { category ->
                val index = categories.indexOf(category)
                AssistChip(
                    onClick = { selectedCategory = index },
                    label = {
                        Text(
                            text = category,
                            fontWeight = if (selectedCategory == index) {
                                FontWeight.Bold
                            } else {
                                FontWeight.Normal
                            },
                        )
                    },
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 4.dp),
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    "สินค้าล่าสุด",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    "${filtered.size} รายการ",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Text(
                "ล่าสุด ▾",
                color = MaterialTheme.colorScheme.primary,
            )
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(filtered, key = { it.id }) { product ->
                ProductGridCard(
                    product = product,
                    userLocation = userLocation,
                    isFavorite = product.id in favoriteIds,
                    onFavorite = { onToggleFavorite(product.id) },
                )
            }
        }
    }
}
