package com.okn.nearbyproduct.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.okn.nearbyproduct.location.UserLocation
import com.okn.nearbyproduct.location.distanceKm
import com.okn.nearbyproduct.model.Product
import com.okn.nearbyproduct.ui.components.ProductGridCard

@Composable
fun SearchScreen(
    products: List<Product>,
    userLocation: UserLocation?,
    favoriteIds: Set<String>,
    onToggleFavorite: (String) -> Unit,
) {
    var query by remember { mutableStateOf("") }
    var radiusKm by remember { mutableDoubleStateOf(10.0) }
    val radii = listOf(1.0, 5.0, 10.0, 20.0, 50.0, 100.0, 99999.0)

    val filtered = products.filter { product ->
        val queryOk = query.isBlank() ||
            product.title.contains(query, ignoreCase = true) ||
            product.locationName.contains(query, ignoreCase = true)
        val d = distanceKm(userLocation, product.latitude, product.longitude)
        val radiusOk = userLocation == null || radiusKm >= 99999.0 || (d != null && d <= radiusKm)
        queryOk && radiusOk
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Text(
            text = "ค้นหาสินค้าใกล้คุณ",
            modifier = Modifier.padding(start = 14.dp, top = 12.dp),
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
        )

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            singleLine = true,
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            placeholder = { Text("ชื่อสินค้า พื้นที่ หรือหมวดหมู่") },
        )

        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
            shape = MaterialTheme.shapes.large,
            tonalElevation = 1.dp,
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .background(MaterialTheme.colorScheme.surfaceVariant),
            ) {
                Column(
                    modifier = Modifier.align(Alignment.Center),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primaryContainer,
                    ) {
                        Icon(
                            Icons.Default.LocationOn,
                            contentDescription = null,
                            modifier = Modifier.padding(14.dp),
                            tint = MaterialTheme.colorScheme.primary,
                        )
                    }
                    Text(
                        text = if (userLocation == null) {
                            "ยังไม่ได้รับตำแหน่ง GPS"
                        } else {
                            "ตำแหน่งปัจจุบันของคุณ"
                        },
                        modifier = Modifier.padding(top = 8.dp),
                        fontWeight = FontWeight.SemiBold,
                    )
                    Text(
                        text = "Map provider จะเชื่อมในขั้นถัดไป",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        Text(
            text = "รัศมีค้นหา",
            modifier = Modifier.padding(start = 14.dp, top = 10.dp),
            fontWeight = FontWeight.SemiBold,
        )

        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(7.dp),
        ) {
            items(radii) { radius ->
                AssistChip(
                    onClick = { radiusKm = radius },
                    label = {
                        Text(
                            if (radius >= 99999.0) "ไม่จำกัด"
                            else "${radius.toInt()} กม."
                        )
                    },
                    leadingIcon = if (radiusKm == radius) {
                        {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(
                                        MaterialTheme.colorScheme.primary,
                                        CircleShape,
                                    )
                            )
                        }
                    } else null,
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 8.dp),
        ) {
            Text(
                text = "สินค้าใกล้คุณ",
                modifier = Modifier.weight(1f),
                fontWeight = FontWeight.Bold,
            )
            Text("${filtered.size} รายการ")
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(filtered, key = { it.id }) { product ->
                ProductGridCard(
                    product = product,
                    userLocation = userLocation,
                    isFavorite = product.id in favoriteIds,
                    onFavorite = { onToggleFavorite(product.id) },
                )
            }
        }
    }
}
