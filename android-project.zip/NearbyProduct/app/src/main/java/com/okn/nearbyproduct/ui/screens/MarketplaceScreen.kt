package com.okn.nearbyproduct.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.okn.nearbyproduct.location.UserLocation
import com.okn.nearbyproduct.model.Product
import com.okn.nearbyproduct.model.ProductSource
import com.okn.nearbyproduct.ui.components.ProductGridCard

@Composable
fun MarketplaceScreen(
    products: List<Product>,
    userLocation: UserLocation?,
    favoriteIds: Set<String>,
    onToggleFavorite: (String) -> Unit,
) {
    val marketplace = products.filter { it.source == ProductSource.MARKETPLACE }

    Column(modifier = Modifier.fillMaxSize()) {
        Text(
            text = "Marketplace",
            modifier = Modifier.padding(start = 14.dp, end = 14.dp, top = 12.dp),
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
        )

        Surface(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            color = MaterialTheme.colorScheme.secondaryContainer,
            shape = MaterialTheme.shapes.medium,
        ) {
            Text(
                text = "หน้านี้เตรียม DataSource ไว้สำหรับข้อมูล Marketplace ที่ Meta อนุญาต ปัจจุบันใช้ข้อมูลตัวอย่างในแอป",
                modifier = Modifier.padding(10.dp),
                style = MaterialTheme.typography.bodySmall,
            )
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(marketplace, key = { it.id }) { product ->
                ProductGridCard(
                    product = product,
                    userLocation = userLocation,
                    isFavorite = product.id in favoriteIds,
                    onFavorite = { onToggleFavorite(product.id) },
                )
            }
        }
    }
}
