package com.okn.nearbyproduct.location

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority

data class UserLocation(
    val latitude: Double,
    val longitude: Double,
)

class LocationController(context: Context) {
    private val client: FusedLocationProviderClient =
        LocationServices.getFusedLocationProviderClient(context)

    @SuppressLint("MissingPermission")
    fun requestCurrentLocation(
        onSuccess: (UserLocation) -> Unit,
        onFailure: (Throwable?) -> Unit,
    ) {
        client
            .getCurrentLocation(Priority.PRIORITY_BALANCED_POWER_ACCURACY, null)
            .addOnSuccessListener { location ->
                if (location != null) {
                    onSuccess(UserLocation(location.latitude, location.longitude))
                } else {
                    client.lastLocation
                        .addOnSuccessListener { last ->
                            if (last != null) {
                                onSuccess(UserLocation(last.latitude, last.longitude))
                            } else {
                                onFailure(null)
                            }
                        }
                        .addOnFailureListener(onFailure)
                }
            }
            .addOnFailureListener(onFailure)
    }
}

fun distanceKm(
    from: UserLocation?,
    toLatitude: Double,
    toLongitude: Double,
): Double? {
    if (from == null) return null

    val results = FloatArray(1)
    Location.distanceBetween(
        from.latitude,
        from.longitude,
        toLatitude,
        toLongitude,
        results,
    )
    return results[0] / 1000.0
}
