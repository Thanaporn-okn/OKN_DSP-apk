package com.okn.nearbyproduct.ui.home

data class ProductUiModel(
    val id: String,
    val title: String,
    val priceText: String,
    val oldPriceText: String? = null,
    val locationText: String,
    val distanceText: String,
    val timeText: String,
    val sourceText: String,
    val isFavorite: Boolean = false,
)

val sampleProducts = listOf(
    ProductUiModel(
        id = "1",
        title = "iPhone 15 Pro 256GB มือสอง สภาพดี",
        priceText = "฿19,900",
        oldPriceText = "฿25,900",
        locationText = "เมืองมหาสารคาม",
        distanceText = "2.4 กม.",
        timeText = "12 นาทีที่แล้ว",
        sourceText = "Facebook Group",
    ),
    ProductUiModel(
        id = "2",
        title = "Honda PCX 160 ปี 2023",
        priceText = "฿68,000",
        locationText = "กันทรวิชัย",
        distanceText = "5.1 กม.",
        timeText = "1 ชั่วโมงที่แล้ว",
        sourceText = "Facebook Group",
        isFavorite = true,
    ),
    ProductUiModel(
        id = "3",
        title = "โซฟาเบด สภาพใหม่",
        priceText = "฿2,990",
        locationText = "เมืองมหาสารคาม",
        distanceText = "3.2 กม.",
        timeText = "3 ชั่วโมงที่แล้ว",
        sourceText = "Marketplace",
    ),
    ProductUiModel(
        id = "4",
        title = "MacBook Air M2",
        priceText = "฿27,500",
        oldPriceText = "฿32,900",
        locationText = "กันทรวิชัย",
        distanceText = "12 กม.",
        timeText = "5 ชั่วโมงที่แล้ว",
        sourceText = "Marketplace",
    ),
)
