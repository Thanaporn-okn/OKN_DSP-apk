package com.okn.nearbyproduct.model

data class Product(
    val id: String,
    val title: String,
    val priceBaht: Int,
    val oldPriceBaht: Int? = null,
    val category: String,
    val condition: String,
    val locationName: String,
    val latitude: Double,
    val longitude: Double,
    val minutesAgo: Int,
    val source: ProductSource,
    val groupName: String? = null,
)

enum class ProductSource(val label: String) {
    FACEBOOK_GROUP("Facebook Group"),
    MARKETPLACE("Marketplace")
}

val sampleProducts = listOf(
    Product(
        id = "p1",
        title = "iPhone 15 Pro 256GB มือสอง สภาพดี",
        priceBaht = 19900,
        oldPriceBaht = 25900,
        category = "มือถือ",
        condition = "มือสอง",
        locationName = "เมืองมหาสารคาม",
        latitude = 16.1851,
        longitude = 103.3007,
        minutesAgo = 12,
        source = ProductSource.FACEBOOK_GROUP,
        groupName = "ซื้อขายมหาสารคาม"
    ),
    Product(
        id = "p2",
        title = "Honda PCX 160 ปี 2023",
        priceBaht = 68000,
        category = "รถยนต์",
        condition = "มือสอง",
        locationName = "กันทรวิชัย",
        latitude = 16.3272,
        longitude = 103.2990,
        minutesAgo = 60,
        source = ProductSource.FACEBOOK_GROUP,
        groupName = "ตลาดรถมือสองอีสาน"
    ),
    Product(
        id = "p3",
        title = "โซฟาเบด สภาพใหม่",
        priceBaht = 2990,
        category = "บ้านและสวน",
        condition = "ใหม่",
        locationName = "เมืองมหาสารคาม",
        latitude = 16.1908,
        longitude = 103.2875,
        minutesAgo = 180,
        source = ProductSource.MARKETPLACE
    ),
    Product(
        id = "p4",
        title = "MacBook Air M2 13 นิ้ว",
        priceBaht = 27500,
        oldPriceBaht = 32900,
        category = "คอมพิวเตอร์",
        condition = "มือสอง",
        locationName = "บรบือ",
        latitude = 16.0418,
        longitude = 103.1197,
        minutesAgo = 300,
        source = ProductSource.MARKETPLACE
    ),
    Product(
        id = "p5",
        title = "จักรยานเสือภูเขา GIANT",
        priceBaht = 4500,
        oldPriceBaht = 6000,
        category = "อื่น ๆ",
        condition = "มือสอง",
        locationName = "โกสุมพิสัย",
        latitude = 16.2486,
        longitude = 103.0670,
        minutesAgo = 240,
        source = ProductSource.FACEBOOK_GROUP,
        groupName = "ซื้อขายของมือสอง"
    ),
    Product(
        id = "p6",
        title = "กล้อง Sony A6400 พร้อมเลนส์",
        priceBaht = 18900,
        category = "อื่น ๆ",
        condition = "มือสอง",
        locationName = "เมืองมหาสารคาม",
        latitude = 16.2033,
        longitude = 103.2841,
        minutesAgo = 360,
        source = ProductSource.MARKETPLACE
    ),
)
