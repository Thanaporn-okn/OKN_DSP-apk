package com.okn.nearbyproduct.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.okn.nearbyproduct.location.LocationController
import com.okn.nearbyproduct.location.UserLocation
import com.okn.nearbyproduct.model.sampleProducts
import com.okn.nearbyproduct.ui.screens.FavoritesScreen
import com.okn.nearbyproduct.ui.screens.GroupsScreen
import com.okn.nearbyproduct.ui.screens.HomeScreen
import com.okn.nearbyproduct.ui.screens.MarketplaceScreen
import com.okn.nearbyproduct.ui.screens.SearchScreen

private data class AppTab(
    val label: String,
    val icon: ImageVector,
)

private val tabs = listOf(
    AppTab("หน้าแรก", Icons.Default.Home),
    AppTab("กลุ่ม", Icons.Default.Groups),
    AppTab("Marketplace", Icons.Default.Storefront),
    AppTab("ค้นหา", Icons.Default.Search),
    AppTab("รายการโปรด", Icons.Default.Favorite),
)

@Composable
fun NearbyProductApp() {
    val context = LocalContext.current
    val locationController = remember { LocationController(context.applicationContext) }

    var selectedTab by remember { mutableIntStateOf(0) }
    var userLocation by remember { mutableStateOf<UserLocation?>(null) }
    var favoriteIds by remember { mutableStateOf(setOf<String>()) }

    fun hasLocationPermission(): Boolean {
        val fine = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION,
        ) == PackageManager.PERMISSION_GRANTED

        val coarse = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION,
        ) == PackageManager.PERMISSION_GRANTED

        return fine || coarse
    }

    fun loadLocation() {
        if (!hasLocationPermission()) return

        locationController.requestCurrentLocation(
            onSuccess = { userLocation = it },
            onFailure = { },
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions(),
    ) { result ->
        val granted = result[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            result[Manifest.permission.ACCESS_COARSE_LOCATION] == true

        if (granted) loadLocation()
    }

    fun requestLocation() {
        if (hasLocationPermission()) {
            loadLocation()
        } else {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                )
            )
        }
    }

    fun toggleFavorite(productId: String) {
        favoriteIds = if (productId in favoriteIds) {
            favoriteIds - productId
        } else {
            favoriteIds + productId
        }
    }

    LaunchedEffect(Unit) {
        if (hasLocationPermission()) {
            loadLocation()
        }
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { index, tab ->
                    NavigationBarItem(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                        ),
                    )
                }
            }
        },
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
        ) {
            when (selectedTab) {
                0 -> HomeScreen(
                    products = sampleProducts,
                    userLocation = userLocation,
                    favoriteIds = favoriteIds,
                    onToggleFavorite = ::toggleFavorite,
                    onRequestLocation = ::requestLocation,
                )
                1 -> GroupsScreen(
                    products = sampleProducts,
                    userLocation = userLocation,
                    favoriteIds = favoriteIds,
                    onToggleFavorite = ::toggleFavorite,
                )
                2 -> MarketplaceScreen(
                    products = sampleProducts,
                    userLocation = userLocation,
                    favoriteIds = favoriteIds,
                    onToggleFavorite = ::toggleFavorite,
                )
                3 -> SearchScreen(
                    products = sampleProducts,
                    userLocation = userLocation,
                    favoriteIds = favoriteIds,
                    onToggleFavorite = ::toggleFavorite,
                )
                4 -> FavoritesScreen(
                    products = sampleProducts,
                    userLocation = userLocation,
                    favoriteIds = favoriteIds,
                    onToggleFavorite = ::toggleFavorite,
                )
            }
        }
    }
}
