OKN_DSP V5 - Phase 1 UI

This version keeps the V4 UI/interaction baseline and fixes Android in-place update packaging.

Important:
- V1-V4 APKs were built as GitHub Actions debug APKs. A clean runner can generate a different debug signing key, so Android can reject an update even when applicationId and versionCode are correct.
- V5 introduces one fixed OKN_DSP project signing key bundled in this source package.
- V5 and every later version MUST keep exactly the same keystore and alias.
- Because the private key used to sign the already-installed V3/V4 APK is not available, the first migration to V5 requires uninstalling the old OKN_DSP once, then installing V5.
- From V5 onward, V6/V7/... can update over the installed app as long as applicationId stays com.okn.dsp, versionCode increases, and the same keystore is retained.

Phase 2 DSP transport is still pending uploaded control/protocol data.
