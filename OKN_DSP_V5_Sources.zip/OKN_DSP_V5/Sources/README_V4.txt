OKN_DSP V4

Goal for V4
- Improve only the UI structure shown in the supplied Home and EQ reference images.
- Use the full phone display cleanly, especially modern Samsung 19.5:9 and 20:9 portrait screens.
- Keep controls large, readable, and immediately responsive to touch.

UI changes
- Responsive full-height layout: the reference width stays 786 design units so icons/circles are not stretched.
- On tall displays the six Home control cards are spaced progressively down the screen.
- The Preset panel moves down naturally and the bottom navigation stays anchored to the physical bottom edge.
- EQ graph height expands on tall displays while preserving the frequency/gain mapping.
- EQ band cards, channel selector, fader/mute/phase row, and preset actions are re-spaced for full-screen use.
- Touch hit areas use the same responsive coordinates as drawing, so controls remain aligned on tall screens.
- Added tap haptic feedback for buttons, presets, tabs, channel selection, mute/phase, and drag start.
- Full-screen cutout support and KEEP_SCREEN_ON are enabled for real tuning sessions.
- OEM/window failures remain guarded so full-screen setup cannot crash startup.

Behavior retained
- Home sliders change their displayed values immediately while dragging.
- EQ points can be dragged and update frequency/gain immediately.
- Channel selection, Reset, fader, mute, phase, save/load preset, BLE retry, and device-read controls remain interactive.
- Home and EQ are the only implemented pages because they are the only pages with supplied UI references.
- Crossover / Delay / Settings tabs acknowledge taps but do not invent unknown UI.

DSP protocol note
The known characteristic 0000ab01-0000-1000-8000-00805f9b34fb is retained for READ/Notify discovery.
A verified WRITE packet format for the DSP parameters has not yet been captured, so V4 does not invent one.
UI values change locally without delay; confirmed live hardware writes require the real protocol bytes.

Version
versionCode 4
versionName 4.0.0

V5 UPDATE INSTALL FIX
---------------------
V5 adds a stable app signing key so GitHub Actions builds can update V5 -> V6 -> V7 without Android rejecting the update because of a changed debug certificate.
For devices with V1-V4 already installed, uninstall the old app once before installing V5 because the old certificate cannot be recovered from a GitHub-hosted runner.
