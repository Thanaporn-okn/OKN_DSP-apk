package com.okn.dsp.data

import android.content.Context
import com.okn.dsp.model.ChannelState
import com.okn.dsp.model.DspUiState
import com.okn.dsp.model.EqBand
import com.okn.dsp.model.ThemeMode
import com.okn.dsp.model.defaultChannels
import org.json.JSONArray
import org.json.JSONObject

class SettingsRepository(context: Context) {
    private val prefs = context.getSharedPreferences("okn_dsp_v1_phase1", Context.MODE_PRIVATE)

    fun load(): DspUiState {
        val defaults = DspUiState()
        val channels = defaultChannels().mapIndexed { c, channel ->
            channel.copy(
                volume = prefs.getFloat("ch_${c}_volume", channel.volume),
                bands = channel.bands.mapIndexed { b, band ->
                    band.copy(
                        gain = prefs.getFloat("ch_${c}_band_${b}_gain", band.gain),
                        frequency = prefs.getFloat("ch_${c}_band_${b}_freq", band.frequency),
                        q = prefs.getFloat("ch_${c}_band_${b}_q", band.q),
                    )
                }
            )
        }
        return defaults.copy(
            masterVolume = prefs.getFloat("master_volume", defaults.masterVolume),
            bassVolume = prefs.getFloat("bass_volume", defaults.bassVolume),
            bassCutoff = prefs.getFloat("bass_cutoff", defaults.bassCutoff),
            selectedChannel = prefs.getInt("selected_channel", defaults.selectedChannel).coerceIn(0, 6),
            selectedBand = prefs.getInt("selected_band", defaults.selectedBand).coerceIn(0, 14),
            themeMode = runCatching {
                ThemeMode.valueOf(prefs.getString("theme_mode", ThemeMode.SYSTEM.name) ?: ThemeMode.SYSTEM.name)
            }.getOrDefault(ThemeMode.SYSTEM),
            channels = channels,
        )
    }

    fun saveMaster(value: Float) = prefs.edit().putFloat("master_volume", value).apply()
    fun saveBass(value: Float) = prefs.edit().putFloat("bass_volume", value).apply()
    fun saveCutoff(value: Float) = prefs.edit().putFloat("bass_cutoff", value).apply()
    fun saveTheme(value: ThemeMode) = prefs.edit().putString("theme_mode", value.name).apply()
    fun saveSelectedChannel(value: Int) = prefs.edit().putInt("selected_channel", value).apply()
    fun saveSelectedBand(value: Int) = prefs.edit().putInt("selected_band", value).apply()
    fun saveChannelVolume(channel: Int, value: Float) = prefs.edit().putFloat("ch_${channel}_volume", value).apply()

    fun saveBand(channel: Int, band: Int, data: EqBand) {
        prefs.edit()
            .putFloat("ch_${channel}_band_${band}_gain", data.gain)
            .putFloat("ch_${channel}_band_${band}_freq", data.frequency)
            .putFloat("ch_${channel}_band_${band}_q", data.q)
            .apply()
    }

    fun saveAll(state: DspUiState) {
        val editor = prefs.edit()
            .putFloat("master_volume", state.masterVolume)
            .putFloat("bass_volume", state.bassVolume)
            .putFloat("bass_cutoff", state.bassCutoff)
            .putString("theme_mode", state.themeMode.name)
            .putInt("selected_channel", state.selectedChannel)
            .putInt("selected_band", state.selectedBand)
        state.channels.forEachIndexed { c, channel ->
            editor.putFloat("ch_${c}_volume", channel.volume)
            channel.bands.forEachIndexed { b, band ->
                editor.putFloat("ch_${c}_band_${b}_gain", band.gain)
                editor.putFloat("ch_${c}_band_${b}_freq", band.frequency)
                editor.putFloat("ch_${c}_band_${b}_q", band.q)
            }
        }
        editor.apply()
    }

    fun presetNames(): List<String> = prefs.getStringSet("preset_names", emptySet())
        .orEmpty().toList().sorted()

    fun savePreset(name: String, state: DspUiState) {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) return
        val names = prefs.getStringSet("preset_names", emptySet()).orEmpty().toMutableSet()
        names += trimmed
        prefs.edit()
            .putStringSet("preset_names", names)
            .putString("preset:$trimmed", encodePreset(state).toString())
            .apply()
    }

    fun loadPreset(name: String): DspUiState? {
        val raw = prefs.getString("preset:$name", null) ?: return null
        return runCatching { decodePreset(JSONObject(raw)) }.getOrNull()
    }

    fun deletePreset(name: String) {
        val names = prefs.getStringSet("preset_names", emptySet()).orEmpty().toMutableSet()
        names.remove(name)
        prefs.edit().putStringSet("preset_names", names).remove("preset:$name").apply()
    }

    private fun encodePreset(state: DspUiState): JSONObject = JSONObject().apply {
        put("master", state.masterVolume.toDouble())
        put("bass", state.bassVolume.toDouble())
        put("cutoff", state.bassCutoff.toDouble())
        put("channels", JSONArray().apply {
            state.channels.forEach { channel ->
                put(JSONObject().apply {
                    put("volume", channel.volume.toDouble())
                    put("bands", JSONArray().apply {
                        channel.bands.forEach { band ->
                            put(JSONObject().apply {
                                put("gain", band.gain.toDouble())
                                put("freq", band.frequency.toDouble())
                                put("q", band.q.toDouble())
                            })
                        }
                    })
                })
            }
        })
    }

    private fun decodePreset(json: JSONObject): DspUiState {
        val current = load()
        val channelsJson = json.getJSONArray("channels")
        val channels = List(minOf(channelsJson.length(), 7)) { c ->
            val ch = channelsJson.getJSONObject(c)
            val bandsJson = ch.getJSONArray("bands")
            val fallback = current.channels[c]
            val bands = List(minOf(bandsJson.length(), 15)) { b ->
                val item = bandsJson.getJSONObject(b)
                EqBand(
                    gain = item.optDouble("gain", fallback.bands[b].gain.toDouble()).toFloat(),
                    frequency = item.optDouble("freq", fallback.bands[b].frequency.toDouble()).toFloat(),
                    q = item.optDouble("q", fallback.bands[b].q.toDouble()).toFloat(),
                )
            }.let { loaded -> if (loaded.size == 15) loaded else fallback.bands }
            ChannelState(
                volume = ch.optDouble("volume", fallback.volume.toDouble()).toFloat(),
                bands = bands,
            )
        }.let { loaded -> if (loaded.size == 7) loaded else current.channels }
        return current.copy(
            masterVolume = json.optDouble("master", current.masterVolume.toDouble()).toFloat(),
            bassVolume = json.optDouble("bass", current.bassVolume.toDouble()).toFloat(),
            bassCutoff = json.optDouble("cutoff", current.bassCutoff.toDouble()).toFloat(),
            channels = channels,
        )
    }
}
