package com.okn.dsp.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.NavigateBefore
import androidx.compose.material.icons.filled.NavigateNext
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speaker
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.WbAuto
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.okn.dsp.model.DspUiState
import com.okn.dsp.model.EqBand
import com.okn.dsp.model.ThemeMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.sqrt

private enum class Screen(val label: String) { HOME("Home"), MIX("Mix"), EQ("EQ") }

@Composable
fun OKNDspRoot(vm: MainViewModel = viewModel()) {
    val state by vm.uiState.collectAsState()
    val presets by vm.presetNames.collectAsState()
    OKNDspTheme(state.themeMode) {
        OKNDspApp(state, presets, vm)
    }
}

@Composable
private fun OKNDspApp(state: DspUiState, presets: List<String>, vm: MainViewModel) {
    var screen by rememberSaveable { mutableStateOf(Screen.HOME) }
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide = maxWidth >= 720.dp
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            snackbarHost = { SnackbarHost(snackbar) },
            bottomBar = {
                if (!wide) {
                    AppNavigationBar(screen) { screen = it }
                }
            }
        ) { inner ->
            Row(
                Modifier
                    .fillMaxSize()
                    .padding(inner)
            ) {
                if (wide) {
                    AppNavigationRail(screen) { screen = it }
                }
                Column(
                    Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .imePadding()
                ) {
                    AppHeader(state.themeMode, vm::cycleTheme, vm::setTheme)
                    when (screen) {
                        Screen.HOME -> HomeScreen(scope, snackbar)
                        Screen.MIX -> MixScreen(state, vm)
                        Screen.EQ -> EqScreen(state, presets, vm)
                    }
                }
            }
        }
    }
}

@Composable
private fun AppHeader(themeMode: ThemeMode, onTheme: () -> Unit, onThemeMode: (ThemeMode) -> Unit) {
    var menuOpen by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        OknLogo(44.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("OKN DSP", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
            Text("V1 • Phase 1 UI", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        IconButton(onClick = onTheme) {
            Icon(
                when (themeMode) {
                    ThemeMode.SYSTEM -> Icons.Default.WbAuto
                    ThemeMode.LIGHT -> Icons.Default.LightMode
                    ThemeMode.DARK -> Icons.Default.DarkMode
                },
                contentDescription = "Change theme",
            )
        }
        Box {
            IconButton(onClick = { menuOpen = true }) {
                Icon(Icons.Default.Menu, contentDescription = "Menu")
            }
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                DropdownMenuItem(
                    text = { Text("System theme") },
                    onClick = { onThemeMode(ThemeMode.SYSTEM); menuOpen = false },
                    leadingIcon = { Icon(Icons.Default.WbAuto, null) },
                )
                DropdownMenuItem(
                    text = { Text("Light theme") },
                    onClick = { onThemeMode(ThemeMode.LIGHT); menuOpen = false },
                    leadingIcon = { Icon(Icons.Default.LightMode, null) },
                )
                DropdownMenuItem(
                    text = { Text("Dark theme") },
                    onClick = { onThemeMode(ThemeMode.DARK); menuOpen = false },
                    leadingIcon = { Icon(Icons.Default.DarkMode, null) },
                )
            }
        }
    }
}

@Composable
private fun OknLogo(size: androidx.compose.ui.unit.Dp) {
    val blue = MaterialTheme.colorScheme.tertiary
    val cyan = MaterialTheme.colorScheme.secondary
    Box(
        modifier = Modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.26f))
            .background(Color(0xFF0A1425)),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize().padding(size * 0.12f)) {
            val w = this.size.width
            val h = this.size.height
            drawRoundRect(cyan, topLeft = Offset(w * .29f, h * .15f), size = Size(w * .16f, h * .70f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * .08f))
            drawLine(cyan, Offset(w * .14f, h * .40f), Offset(w * .14f, h * .60f), strokeWidth = w * .07f, cap = StrokeCap.Round)
            drawLine(blue, Offset(w * .48f, h * .50f), Offset(w * .80f, h * .18f), strokeWidth = w * .16f, cap = StrokeCap.Round)
            drawLine(blue, Offset(w * .48f, h * .50f), Offset(w * .80f, h * .82f), strokeWidth = w * .16f, cap = StrokeCap.Round)
            drawLine(cyan, Offset(w * .90f, h * .40f), Offset(w * .90f, h * .60f), strokeWidth = w * .07f, cap = StrokeCap.Round)
        }
    }
}

@Composable
private fun AppNavigationBar(selected: Screen, onSelect: (Screen) -> Unit) {
    NavigationBar(modifier = Modifier.navigationBarsPadding()) {
        Screen.entries.forEach { item ->
            NavigationBarItem(
                selected = item == selected,
                onClick = { onSelect(item) },
                icon = { Icon(screenIcon(item), contentDescription = item.label) },
                label = { Text(item.label) },
            )
        }
    }
}

@Composable
private fun AppNavigationRail(selected: Screen, onSelect: (Screen) -> Unit) {
    NavigationRail(Modifier.fillMaxHeight()) {
        Spacer(Modifier.height(18.dp))
        Screen.entries.forEach { item ->
            NavigationRailItem(
                selected = item == selected,
                onClick = { onSelect(item) },
                icon = { Icon(screenIcon(item), contentDescription = item.label) },
                label = { Text(item.label) },
            )
        }
    }
}

private fun screenIcon(screen: Screen) = when (screen) {
    Screen.HOME -> Icons.Default.Home
    Screen.MIX -> Icons.Default.Tune
    Screen.EQ -> Icons.Default.Equalizer
}

@Composable
private fun HomeScreen(scope: CoroutineScope, snackbar: SnackbarHostState) {
    val items = listOf(
        Triple(Icons.Default.Bluetooth, "Bluetooth", "Transport will be connected in Phase 2"),
        Triple(Icons.Default.Devices, "DSP Device", "Hardware protocol will be connected in Phase 2"),
        Triple(Icons.Default.MusicNote, "Audio Input", "Input routing UI ready"),
        Triple(Icons.Default.Speaker, "Amplifier Link", "Output UI ready"),
        Triple(Icons.Default.Save, "Preset Sync", "Local preset storage active"),
        Triple(Icons.Default.Settings, "Firmware Status", "Device query will be added in Phase 2"),
    )
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFE9FAF0)),
                shape = RoundedCornerShape(22.dp),
            ) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(52.dp).clip(CircleShape).background(Color(0xFF21C66A)),
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color.White) }
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text("Interface Ready", fontWeight = FontWeight.Bold, color = Color(0xFF123E26))
                        Text("Phase 1 UI + local real-time persistence are active", color = Color(0xFF2E6040), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        item { Text("Connection & Status", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        itemsIndexed(items) { index, item ->
            val tint = listOf(Color(0xFF1587FF), Color(0xFFFF3E79), Color(0xFF18BED0), Color(0xFFFF507A), Color(0xFF20C4C8), Color(0xFF8158F5))[index]
            StatusRow(
                icon = item.first,
                title = item.second,
                subtitle = item.third,
                tint = tint,
                onClick = { scope.launch { snackbar.showSnackbar("${item.second}: ${item.third}") } },
            )
        }
        item {
            StatusRow(
                icon = Icons.Default.Tune,
                title = "Quick Control",
                subtitle = "Use the Mix and EQ tabs for live UI control",
                tint = Color(0xFFFF3E79),
                onClick = { scope.launch { snackbar.showSnackbar("Open Mix or EQ from the navigation bar") } },
            )
        }
        item { Spacer(Modifier.height(10.dp)) }
    }
}

@Composable
private fun StatusRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    tint: Color,
    onClick: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(CircleShape).background(tint.copy(alpha = .14f)), contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null, tint = tint)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text("›", fontSize = 28.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun MixScreen(state: DspUiState, vm: MainViewModel) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            SectionCard(title = "Global", subtitle = "Overall output and bass settings") {
                ControlSlider("Master Volume", state.masterVolume, -60f..12f, "${state.masterVolume.one()} dB", Color(0xFFFF3B6B), vm::setMaster)
                ControlSlider("Bass Volume", state.bassVolume, -12f..12f, "${state.bassVolume.one()} dB", Color(0xFF16C7B7), vm::setBass)
                ControlSlider("Bass Cutoff", state.bassCutoff, 20f..500f, "${state.bassCutoff.toInt()} Hz", Color(0xFFFF4A8C), vm::setCutoff)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = vm::resetGlobal) {
                        Icon(Icons.Default.RestartAlt, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("Reset Global")
                    }
                }
            }
        }
        item {
            SectionCard(title = "Channels", subtitle = "Individual channel levels") {
                state.channels.forEachIndexed { index, channel ->
                    val hue = listOf(Color(0xFFFF2D74), Color(0xFF11C2D4), Color(0xFF32C66B), Color(0xFFFF355D), Color(0xFF3AC46C), Color(0xFF10C5C9), Color(0xFFFF4E4E))[index]
                    ChannelSlider(index + 1, channel.volume, hue) { vm.setChannelVolume(index, it) }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = vm::resetChannels) {
                        Icon(Icons.Default.RestartAlt, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("Reset Channels")
                    }
                }
            }
        }
        item { Spacer(Modifier.height(12.dp)) }
    }
}

@Composable
private fun SectionCard(title: String, subtitle: String, content: @Composable () -> Unit) {
    Card(shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
}

@Composable
private fun ChannelSlider(number: Int, value: Float, color: Color, onChange: (Float) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(36.dp).clip(CircleShape).background(color), contentAlignment = Alignment.Center) {
            Text(number.toString(), color = Color.White, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("Volume Ch$number", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
            Slider(value = value, onValueChange = onChange, valueRange = -60f..12f)
        }
        ValuePill("${value.one()} dB")
    }
}

@Composable
private fun ControlSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, display: String, color: Color, onChange: (Float) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(38.dp).clip(CircleShape).background(color.copy(alpha = .16f)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Tune, contentDescription = null, tint = color)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
            Slider(value = value, onValueChange = onChange, valueRange = range)
        }
        ValuePill(display)
    }
}

@Composable
private fun EqScreen(state: DspUiState, presets: List<String>, vm: MainViewModel) {
    val channel = state.channels[state.selectedChannel]
    val band = channel.bands[state.selectedBand]
    var presetName by rememberSaveable { mutableStateOf("") }
    var selectedPreset by rememberSaveable { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                repeat(7) { index ->
                    AssistChip(
                        onClick = { vm.setSelectedChannel(index) },
                        label = { Text("Ch${index + 1}") },
                        leadingIcon = if (state.selectedChannel == index) ({ Text("●", color = MaterialTheme.colorScheme.primary) }) else null,
                    )
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Channel ${state.selectedChannel + 1}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Text("Front Left • 15-band EQ", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        }
                        TextButton(onClick = vm::resetSelectedEq) {
                            Icon(Icons.Default.RestartAlt, contentDescription = null)
                            Spacer(Modifier.width(4.dp))
                            Text("Reset EQ")
                        }
                    }
                    EqGraph(channel.bands, state.selectedBand, vm::setSelectedBand)
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(38.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary.copy(alpha = .13f)), contentAlignment = Alignment.Center) {
                            Text("${state.selectedBand + 1}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Band ${state.selectedBand + 1}", fontWeight = FontWeight.Bold)
                            Text("Adjust selected band parameters", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = { vm.setSelectedBand((state.selectedBand - 1 + 15) % 15) }) { Icon(Icons.Default.NavigateBefore, null) }
                        IconButton(onClick = { vm.setSelectedBand((state.selectedBand + 1) % 15) }) { Icon(Icons.Default.NavigateNext, null) }
                    }
                    Spacer(Modifier.height(8.dp))
                    FrequencyControl(band.frequency, vm::setBandFrequency)
                    ControlSlider("Q (Quality Factor)", band.q, 0.1f..10f, band.q.one(), MaterialTheme.colorScheme.secondary, vm::setBandQ)
                    ControlSlider("Gain Band", band.gain, -12f..12f, "${band.gain.one()} dB", Color(0xFF18C56E), vm::setBandGain)
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Text("Presets", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text("Save/load the current local UI values", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = presetName,
                        onValueChange = { presetName = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text("Preset name") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            if (presetName.isNotBlank()) {
                                vm.savePreset(presetName)
                                selectedPreset = presetName.trim()
                            }
                        }) {
                            Icon(Icons.Default.Save, null)
                            Spacer(Modifier.width(6.dp))
                            Text("Save Preset")
                        }
                    }
                    if (presets.isNotEmpty()) {
                        Spacer(Modifier.height(10.dp))
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            presets.forEach { name ->
                                AssistChip(onClick = { selectedPreset = name }, label = { Text(if (selectedPreset == name) "✓ $name" else name) })
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilledTonalButton(enabled = selectedPreset.isNotBlank(), onClick = { vm.loadPreset(selectedPreset) }) { Text("Load") }
                            OutlinedButton(enabled = selectedPreset.isNotBlank(), onClick = {
                                vm.deletePreset(selectedPreset)
                                selectedPreset = ""
                            }) {
                                Icon(Icons.Default.Delete, null)
                                Spacer(Modifier.width(4.dp))
                                Text("Delete")
                            }
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(14.dp)) }
    }
}

@Composable
private fun FrequencyControl(value: Float, onChange: (Float) -> Unit) {
    val normalized = freqToSlider(value)
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(38.dp).clip(CircleShape).background(MaterialTheme.colorScheme.tertiary.copy(alpha = .14f)), contentAlignment = Alignment.Center) {
            Text("ƒ", color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("Frequency", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
            Slider(value = normalized, onValueChange = { onChange(sliderToFreq(it)) }, valueRange = 0f..1f)
        }
        ValuePill(formatFrequency(value))
    }
}

private fun freqToSlider(freq: Float): Float {
    val min = 20.0
    val max = 20000.0
    return (ln(freq.coerceIn(20f, 20000f).toDouble() / min) / ln(max / min)).toFloat()
}

private fun sliderToFreq(value: Float): Float {
    val min = 20.0
    val max = 20000.0
    return (min * (max / min).pow(value.coerceIn(0f, 1f).toDouble())).toFloat()
}

@Composable
private fun EqGraph(bands: List<EqBand>, selected: Int, onSelect: (Int) -> Unit) {
    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary
    val tertiary = MaterialTheme.colorScheme.tertiary
    val grid = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .45f)
    val surface = MaterialTheme.colorScheme.surface
    val density = LocalDensity.current
    val pointRadius = with(density) { 5.dp.toPx() }
    val stroke = with(density) { 3.dp.toPx() }

    Box(Modifier.fillMaxWidth().height(250.dp)) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 10.dp, vertical = 14.dp)
                .pointerInput(bands) {
                    detectTapGestures { tap ->
                        val w = size.width.toFloat()
                        val h = size.height.toFloat()
                        var nearest = 0
                        var minDist = Float.MAX_VALUE
                        bands.forEachIndexed { index, band ->
                            val x = freqToSlider(band.frequency) * w
                            val y = ((12f - band.gain) / 24f) * h
                            val dx = tap.x - x
                            val dy = tap.y - y
                            val d = sqrt(dx * dx + dy * dy)
                            if (d < minDist) { minDist = d; nearest = index }
                        }
                        onSelect(nearest)
                    }
                }
        ) {
            val w = size.width
            val h = size.height
            repeat(5) { i ->
                val y = h * i / 4f
                drawLine(grid, Offset(0f, y), Offset(w, y), strokeWidth = 1f)
            }
            repeat(7) { i ->
                val x = w * i / 6f
                drawLine(grid, Offset(x, 0f), Offset(x, h), strokeWidth = 1f)
            }

            val points = bands.map { band ->
                Offset(
                    x = freqToSlider(band.frequency) * w,
                    y = ((12f - band.gain.coerceIn(-12f, 12f)) / 24f) * h,
                )
            }
            if (points.isNotEmpty()) {
                val path = Path().apply {
                    moveTo(points.first().x, points.first().y)
                    for (i in 1 until points.size) lineTo(points[i].x, points[i].y)
                }
                drawPath(path, Brush.horizontalGradient(listOf(tertiary, secondary, primary)), style = Stroke(stroke, cap = StrokeCap.Round))
                points.forEachIndexed { index, point ->
                    val color = when {
                        index == selected -> primary
                        index < 5 -> tertiary
                        index < 10 -> secondary
                        else -> primary
                    }
                    drawCircle(color = color, radius = if (index == selected) pointRadius * 1.35f else pointRadius, center = point)
                    drawCircle(color = surface, radius = if (index == selected) pointRadius * .55f else pointRadius * .35f, center = point)
                }
            }
        }
        Text("+12", style = MaterialTheme.typography.labelSmall, modifier = Modifier.align(Alignment.TopStart))
        Text("0", style = MaterialTheme.typography.labelSmall, modifier = Modifier.align(Alignment.CenterStart))
        Text("-12", style = MaterialTheme.typography.labelSmall, modifier = Modifier.align(Alignment.BottomStart))
        Text("20 Hz", style = MaterialTheme.typography.labelSmall, modifier = Modifier.align(Alignment.BottomStart).padding(start = 34.dp))
        Text("20 kHz", style = MaterialTheme.typography.labelSmall, modifier = Modifier.align(Alignment.BottomEnd))
    }
}

@Composable
private fun ValuePill(text: String) {
    Box(
        modifier = Modifier
            .padding(start = 8.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 10.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, style = MaterialTheme.typography.labelMedium, textAlign = TextAlign.Center)
    }
}

private fun Float.one(): String = String.format(java.util.Locale.US, "%.1f", this)

private fun formatFrequency(value: Float): String = when {
    value >= 1000f -> "${(value / 1000f).one()} kHz"
    else -> "${value.toInt()} Hz"
}
