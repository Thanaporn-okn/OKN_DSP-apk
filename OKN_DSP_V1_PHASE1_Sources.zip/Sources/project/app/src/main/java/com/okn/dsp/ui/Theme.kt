package com.okn.dsp.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.okn.dsp.model.ThemeMode

private val Pink = Color(0xFFFF1768)
private val Cyan = Color(0xFF13C9D8)
private val Blue = Color(0xFF1787FF)
private val Dark = Color(0xFF091321)
private val DarkCard = Color(0xFF121E2E)

private val LightScheme = lightColorScheme(
    primary = Pink,
    secondary = Cyan,
    tertiary = Blue,
    background = Color(0xFFF7F9FD),
    surface = Color.White,
    surfaceVariant = Color(0xFFF0F3F8),
    onBackground = Color(0xFF101722),
    onSurface = Color(0xFF101722),
)

private val DarkScheme = darkColorScheme(
    primary = Pink,
    secondary = Cyan,
    tertiary = Blue,
    background = Dark,
    surface = DarkCard,
    surfaceVariant = Color(0xFF1A2738),
    onBackground = Color(0xFFF7F9FC),
    onSurface = Color(0xFFF7F9FC),
)

@Composable
fun OKNDspTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    MaterialTheme(
        colorScheme = if (dark) DarkScheme else LightScheme,
        content = content,
    )
}
