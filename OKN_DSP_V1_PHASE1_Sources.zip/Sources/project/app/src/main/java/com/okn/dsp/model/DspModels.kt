package com.okn.dsp.model

enum class ThemeMode { SYSTEM, LIGHT, DARK }

data class EqBand(
    val gain: Float,
    val frequency: Float,
    val q: Float,
)

data class ChannelState(
    val volume: Float,
    val bands: List<EqBand>,
)

data class DspUiState(
    val masterVolume: Float = -6f,
    val bassVolume: Float = 2f,
    val bassCutoff: Float = 80f,
    val channels: List<ChannelState> = defaultChannels(),
    val selectedChannel: Int = 0,
    val selectedBand: Int = 4,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
)

val defaultFrequencies = listOf(
    20f, 31.5f, 50f, 80f, 125f,
    200f, 315f, 500f, 800f, 1250f,
    2000f, 3150f, 5000f, 10000f, 20000f,
)

private val defaultGains = listOf(
    -2f, -1f, 1f, 3f, 5f,
    3f, 1f, 0f, -1f, -2f,
    -2f, 0f, 2f, 4f, 2f,
)

private val defaultChannelVolumes = listOf(-3f, -6f, -2f, -8f, 0f, -4f, -10f)

fun defaultBands(): List<EqBand> = defaultFrequencies.mapIndexed { index, frequency ->
    EqBand(gain = defaultGains[index], frequency = frequency, q = 1f)
}

fun defaultChannels(): List<ChannelState> = List(7) { index ->
    ChannelState(
        volume = defaultChannelVolumes[index],
        bands = defaultBands(),
    )
}
