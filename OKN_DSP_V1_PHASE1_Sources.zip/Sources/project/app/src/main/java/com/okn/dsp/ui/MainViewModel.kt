package com.okn.dsp.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.okn.dsp.data.SettingsRepository
import com.okn.dsp.model.DspUiState
import com.okn.dsp.model.EqBand
import com.okn.dsp.model.ThemeMode
import com.okn.dsp.model.defaultChannels
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = SettingsRepository(application)
    private val _uiState = MutableStateFlow(repository.load())
    val uiState: StateFlow<DspUiState> = _uiState.asStateFlow()

    private val _presetNames = MutableStateFlow(repository.presetNames())
    val presetNames: StateFlow<List<String>> = _presetNames.asStateFlow()

    fun setTheme(mode: ThemeMode) {
        _uiState.value = _uiState.value.copy(themeMode = mode)
        repository.saveTheme(mode)
    }

    fun cycleTheme() {
        setTheme(
            when (_uiState.value.themeMode) {
                ThemeMode.SYSTEM -> ThemeMode.LIGHT
                ThemeMode.LIGHT -> ThemeMode.DARK
                ThemeMode.DARK -> ThemeMode.SYSTEM
            }
        )
    }

    fun setMaster(value: Float) {
        _uiState.value = _uiState.value.copy(masterVolume = value)
        repository.saveMaster(value)
    }

    fun setBass(value: Float) {
        _uiState.value = _uiState.value.copy(bassVolume = value)
        repository.saveBass(value)
    }

    fun setCutoff(value: Float) {
        _uiState.value = _uiState.value.copy(bassCutoff = value)
        repository.saveCutoff(value)
    }

    fun setSelectedChannel(index: Int) {
        val safe = index.coerceIn(0, 6)
        _uiState.value = _uiState.value.copy(selectedChannel = safe)
        repository.saveSelectedChannel(safe)
    }

    fun setSelectedBand(index: Int) {
        val safe = index.coerceIn(0, 14)
        _uiState.value = _uiState.value.copy(selectedBand = safe)
        repository.saveSelectedBand(safe)
    }

    fun setChannelVolume(channel: Int, value: Float) {
        updateChannel(channel) { it.copy(volume = value) }
        repository.saveChannelVolume(channel, value)
    }

    fun setBandGain(value: Float) = updateCurrentBand { it.copy(gain = value) }
    fun setBandFrequency(value: Float) = updateCurrentBand { it.copy(frequency = value.coerceIn(20f, 20000f)) }
    fun setBandQ(value: Float) = updateCurrentBand { it.copy(q = value.coerceIn(0.1f, 10f)) }

    private fun updateCurrentBand(transform: (EqBand) -> EqBand) {
        val channelIndex = _uiState.value.selectedChannel
        val bandIndex = _uiState.value.selectedBand
        var updatedBand: EqBand? = null
        updateChannel(channelIndex) { channel ->
            val bands = channel.bands.toMutableList()
            bands[bandIndex] = transform(bands[bandIndex]).also { updatedBand = it }
            channel.copy(bands = bands)
        }
        updatedBand?.let { repository.saveBand(channelIndex, bandIndex, it) }
    }

    private fun updateChannel(index: Int, transform: (com.okn.dsp.model.ChannelState) -> com.okn.dsp.model.ChannelState) {
        val channels = _uiState.value.channels.toMutableList()
        channels[index] = transform(channels[index])
        _uiState.value = _uiState.value.copy(channels = channels)
    }

    fun resetGlobal() {
        val defaults = DspUiState()
        val updated = _uiState.value.copy(
            masterVolume = defaults.masterVolume,
            bassVolume = defaults.bassVolume,
            bassCutoff = defaults.bassCutoff,
        )
        _uiState.value = updated
        repository.saveAll(updated)
    }

    fun resetChannels() {
        val updated = _uiState.value.copy(channels = defaultChannels())
        _uiState.value = updated
        repository.saveAll(updated)
    }

    fun resetSelectedEq() {
        val selected = _uiState.value.selectedChannel
        val defaults = defaultChannels()[selected]
        val channels = _uiState.value.channels.toMutableList()
        channels[selected] = channels[selected].copy(bands = defaults.bands)
        val updated = _uiState.value.copy(channels = channels)
        _uiState.value = updated
        repository.saveAll(updated)
    }

    fun savePreset(name: String) {
        repository.savePreset(name, _uiState.value)
        _presetNames.value = repository.presetNames()
    }

    fun loadPreset(name: String) {
        repository.loadPreset(name)?.let { loaded ->
            val updated = loaded.copy(
                themeMode = _uiState.value.themeMode,
                selectedChannel = _uiState.value.selectedChannel,
                selectedBand = _uiState.value.selectedBand,
            )
            _uiState.value = updated
            repository.saveAll(updated)
        }
    }

    fun deletePreset(name: String) {
        repository.deletePreset(name)
        _presetNames.value = repository.presetNames()
    }
}
