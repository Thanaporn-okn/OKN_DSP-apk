OKN DSP — Version 1 / Phase 1

Goal
- Rebuild the UI from code only; no uploaded reference image is used as a screen background.
- Adaptive full-screen layout for phones and tablets.
- Light / Dark / System theme switching.
- Local values update immediately in UI and are auto-saved using SharedPreferences.
- Values remain after closing and reopening the app.
- Home, Mix, and 15-band EQ screens are implemented.
- 7 channels, Master Volume, Bass Volume, Bass Cutoff, channel volumes, EQ Gain, Frequency, and Q controls are interactive.
- EQ graph moves immediately with the current band values.
- Presets are stored locally.

Phase boundary
- Phase 1 does NOT claim real DSP hardware communication.
- Phase 2 will connect these already-live UI state changes to the real DSP protocol once the protocol/config files are supplied.
- No BLE UUID, packet format, write characteristic, checksum, or command mapping is guessed in V1.

Build
- The separately delivered workflow automatically builds the newest OKN_DSP_V*_PHASE*_Sources.zip pushed to the repository.
