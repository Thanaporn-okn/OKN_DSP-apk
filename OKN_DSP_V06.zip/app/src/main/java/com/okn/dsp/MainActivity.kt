package com.okn.dsp

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.widget.TextView

class MainActivity: Activity(){
 override fun onCreate(savedInstanceState: Bundle?){
  super.onCreate(savedInstanceState)
  val t=TextView(this)
  t.text="OKN_DSP BP1048P4 7CH Controller\nV0.6"
  t.textSize=28f
  t.setTextColor(Color.WHITE)
  t.setBackgroundColor(Color.BLACK)
  setContentView(t)
 }
}
