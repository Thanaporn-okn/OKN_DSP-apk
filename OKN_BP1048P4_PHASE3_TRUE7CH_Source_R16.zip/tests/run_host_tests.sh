#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
BIN="${TMPDIR:-/tmp}/okn_r16_test_gain7_$$"
trap 'rm -f "$BIN"' EXIT
cc -std=c11 -Wall -Wextra -Werror -pedantic \
  -I"$ROOT/firmware/include" \
  "$ROOT/firmware/src/okn_gain7.c" \
  "$ROOT/firmware/src/okn_ufe_gain7.c" \
  "$ROOT/tests/test_gain7.c" -o "$BIN"
"$BIN"
python3 "$ROOT/tools/check_no_eq_gain.py"
python3 "$ROOT/tools/check_usb_r16_same_address_guard.py"
python3 "$ROOT/tools/test_mva_inspect.py"
python3 "$ROOT/tools/check_r16_fail_closed.py"
