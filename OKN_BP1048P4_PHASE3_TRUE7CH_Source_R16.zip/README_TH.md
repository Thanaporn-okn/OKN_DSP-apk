# OKN BP1048P4 Phase3 TRUE7CH R16 — Same-Address Flashboot Discriminator

R16 ต่อจากผลบอร์ดจริงบน Samsung S25+ ที่ R15 ยืนยันแล้วว่า:

- normal mode = VID:PID `6324:1719`
- Manufacturer `JMDSTECH`
- Product `DSTech DSP ComboDigitalArchitect`
- 7 interfaces
- IF4 vendor HID Usage Page `FF00`, Usage `55AA`, Input/Output 256, Feature 8
- Feature baseline `00 01 00 03 04 00 08 00`
- หลัง R15 ส่ง `AA` แล้ว GET_REPORT ตอบ `55 01 00 03 04 00 08 00` แต่ Android ไม่พบ detach/re-enumeration ภายใน 20 วินาที
- หลัง power-cycle บอร์ดกลับ normal baseline `00 ...` และ exact gate PASS

## สิ่งใหม่ใน R16

R16 เพิ่มตัวแยกกรณี **flashboot เปลี่ยนโหมดแต่ยังคง USB address/Android device object เดิม** โดยหลัง manual AA + GET_REPORT หนึ่งครั้ง จะส่งเฉพาะ standard control-IN `GET_DESCRIPTOR` ที่ T+150 ms, T+700 ms และ T+2500 ms เพื่ออ่าน raw device/report descriptor โดยไม่ claim interface และไม่ส่ง endpoint OUT

Public BP10X SDK embedded flashboot 64 KiB ที่ใช้เป็น cross-family reference เท่านั้น มี descriptor candidate:

- Device descriptor bytes: `12 01 10 01 00 00 00 40 00 00 44 22 00 01 00 00 00 01`
- ถ้าตีความตาม USB descriptor จะเป็น VID:PID `0000:2244`, 1 configuration
- HID report descriptor ใช้ Usage bytes `55 AA` (ต่างจาก normal app ที่เป็น `AA 55`)
- Feature report count = 1 byte ใน public flashboot reference (normal app ของบอร์ดจริง = 8 bytes)

ข้อมูลชุดนี้ **ไม่ถือว่าเป็น production bootloader identity** จนกว่าจะเห็นจากบอร์ดจริง

## Safety

R16 ยังไม่มี firmware payload, bulk/interrupt OUT, erase, program, verify, commit หรือ automatic boot entry ปุ่มเข้า flashbootทำงานได้เพียงครั้งเดียวต่อ app process หลัง exact normal gate PASS และ confirmation จากผู้ใช้

TRUE 7CH DSP core ยังคงเดิม: dedicated PCM gain CH1..CH7 หลัง EQ/crossover ก่อน output sink, IDs 22..28, ไม่ใช้ EQ/Biquad เป็น Channel Gain
