package com.okn.dsp

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/** V91 reference Real-time UI launcher over the verified BLE/protocol core. */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startActivity(Intent(this, UnifiedControlActivity::class.java))
        finish()
    }
}
