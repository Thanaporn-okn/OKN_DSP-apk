package com.okn.dsp.protocol

/**
 * V53 guarded persistence proof policy.
 *
 * Runtime evidence already proves CH1 / actuator 4 / Band4 / offset 144 writes.
 * The live Device Description identifies actuator ID7 as:
 *   type=2100, name=SaveParams, cpar=Trigger, desc="Save all the turning parameters".
 *
 * V53 tests the narrow UFE Trigger encoding only inside a two-reboot proof flow:
 * WRITE_ACTUATOR(0x57) + ID7(BE32) + offset0(BE16) + length0(BE16), no payload.
 * Plain bytes must therefore be exactly: 57 00000007 0000 0000.
 * This encoding is NOT treated as persistent-proof success until a real DSP power-cycle
 * demonstrates that the verified -0.1 dB test value survives reboot and the restored
 * 0.0 dB original also survives a second reboot.
 */
object SaveParamsPolicy {
    const val ACTUATOR_ID = 7
    const val TYPE_ID = 2100
    const val TEST_CHANNEL = 1
    const val TEST_BAND = 4
    const val TEST_ACTUATOR = 4
    const val TEST_OFFSET = 144
    const val ORIGINAL_BOOST_DB = 0.0f
    const val TEST_BOOST_DB = -0.1f
    const val V51_LIVE_BOOST_DB = -0.2f
    const val BOOST_TOL = 0.0065f

    fun encodeTrigger(): ByteArray = UfeCodec.encodeWrite(ACTUATOR_ID, 0, byteArrayOf())

    fun triggerIsExact(): Boolean = ByteCodec.run { encodeTrigger().toHex() } == "570000000700000000"

    fun safeBandShape(b: EqBand48): Boolean =
        LiveEqPolicy.isWritable(b) &&
            kotlin.math.abs(b.frequency - 100.0f) <= 0.15f &&
            kotlin.math.abs(b.q - 2.23f) <= 0.02f

    fun boostMatches(actual: Float, expected: Float): Boolean =
        kotlin.math.abs(actual - expected) <= BOOST_TOL

    fun exactOriginalFrom(current: EqBand48): EqBand48 {
        require(safeBandShape(current)) { "unexpected CH1 Band4 shape" }
        return LiveEqPolicy.targetFromCurrent(current, ORIGINAL_BOOST_DB)
    }

    fun testTargetFrom(original: EqBand48): EqBand48 {
        require(safeBandShape(original)) { "unexpected CH1 Band4 shape" }
        require(boostMatches(original.boostDb, ORIGINAL_BOOST_DB)) { "baseline must be 0.0 dB" }
        return LiveEqPolicy.targetFromCurrent(original, TEST_BOOST_DB)
    }
}
