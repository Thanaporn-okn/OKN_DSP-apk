OKN DSP V53 — SAVEPARAMS PERSISTENCE PROOF / PREPARE BUTTON STATE FIX

WHY V53 EXISTS
- V52 correctly detected the known V51 RAM-only CH1 Band4 value -0.2 dB and displayed "PREPARE REQUIRED".
- On the observed Samsung/Android UI, the PREPARE button could remain disabled even while that exact guarded condition was true.
- V53 fixes only that UI/action-state defect. The SaveParams protocol scope and safety gates are unchanged.

V53 PREPARE FIX
- When the fresh Device Description confirms CH1 / actuator4 / Band4 is the known V51 -0.2 dB value, V53 atomically arms PREPARE on the UI thread.
- It explicitly sets enabled=true, clickable=true, alpha=1.0 and logs V53_PREPARE_UI_ARMED.
- It re-asserts the same guarded state at 250 ms and 1000 ms only if the live value is still safe -0.2 dB, the session is ready, phase is IDLE/SAVE_NOT_PROVEN, and no operation/descriptor read is active.
- The click handler independently re-checks session, phase, band shape and exact known -0.2 dB precondition before any write.
- PREPARE still writes CH1 Band4 back to 0.0 dB with NO SaveParams.

PERSISTENCE PROOF REMAINS THE SAME
1) SCAN DSP -> connect LE-GoloPine_DSP_A.
2) START V53 PERSISTENCE SESSION -> START READ-ONLY PERSISTENCE CHECK.
3) If status is PREPARE REQUIRED, tap PREPARE ORIGINAL CH1 BAND4 = 0.0 dB (NO SAVE), then confirm PREPARE 0.0 • NO SAVE.
4) Wait for V53 PREPARED / READY.
5) WRITE TEST -0.1 dB + VERIFY + SAVEPARAMS.
6) Wait for NOW POWER-CYCLE DSP, then power-cycle and reconnect/start V53.
7) Verify -0.1 survived, then RESTORE ORIGINAL 0.0 dB + VERIFY + SAVEPARAMS.
8) Wait for second NOW POWER-CYCLE DSP, power-cycle, reconnect/start V53.
9) Final success: V53 COMPLETE • SaveParams persistence proven • original 0.0 dB persisted after second reboot.
10) SAVE V53 CAPTURE TO DOWNLOADS and send the TXT.

SAFETY
- SaveParams ID7 remains confined to the guarded persistence proof.
- Trigger under test remains exactly: 570000000700000000.
- Generic Save/Preset/unknown writes remain locked.
