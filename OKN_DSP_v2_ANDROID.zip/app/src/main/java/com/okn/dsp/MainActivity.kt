package com.okn.dsp

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.widget.*

class MainActivity: Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL
        layout.setPadding(30,30,30,30)
        layout.setBackgroundColor(Color.BLACK)

        val title = TextView(this)
        title.text = "OKN_DSP BP1048P4 7CH Controller"
        title.textSize = 22f
        title.setTextColor(Color.WHITE)

        layout.addView(title)

        for(i in 1..7){
            val eq = SeekBar(this)
            eq.max = 30
            eq.progress = 15
            layout.addView(TextView(this).apply {
                text="CH$i EQ"
                setTextColor(Color.WHITE)
            })
            layout.addView(eq)
        }

        setContentView(layout)
    }
}