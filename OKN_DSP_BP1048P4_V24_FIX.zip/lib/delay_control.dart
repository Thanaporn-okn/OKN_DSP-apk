// V24 delay per channel
