// V24 EQ per channel
