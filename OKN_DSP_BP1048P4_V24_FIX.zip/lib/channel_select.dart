// V24 channel selector
