import 'package:flutter/material.dart';

void main()=>runApp(const OKNDSP());

class OKNDSP extends StatelessWidget{
 const OKNDSP({super.key});
 @override
 Widget build(BuildContext context){
  return MaterialApp(
   debugShowCheckedModeBanner:false,
   theme:ThemeData.dark(),
   home:const Home(),
  );
 }
}

class Home extends StatelessWidget{
 const Home({super.key});
 @override
 Widget build(BuildContext context){
  return Scaffold(
   backgroundColor:const Color(0xff101018),
   appBar:AppBar(title:const Text('OKN_DSP BP1048P4 V24')),
   body:const Center(
    child:Text(
     'DSP Mixer CH1-CH7\n'
     'Channel Select\n'
     'Volume EQ Delay\n'
     'HPF LPF Crossover\n'
     'Bluetooth Control Ready',
     textAlign:TextAlign.center,
     style:TextStyle(color:Colors.cyan,fontSize:24),
    ),
   ),
  );
 }
}
