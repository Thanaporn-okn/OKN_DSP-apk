OKN DSP V32 - CAPTURE EXPORT FIX

Purpose:
- Fix V30 SAVE CAPTURE, which only opened ACTION_SEND and did not create a file.
- SAVE CAPTURE FILE now uses Android ACTION_CREATE_DOCUMENT and writes UTF-8 raw capture to a user-selected .txt file.
- SHARE CAPTURE remains available separately.
- COPY CAPTURE TO CLIPBOARD is a fallback.
- LIVE DSP WRITE remains locked.

Use:
1. Connect DSP and collect the auth/capture session.
2. Press ANALYZE CAPTURE to verify capture is in memory.
3. Press SAVE CAPTURE FILE.
4. Android Files save picker must appear. Keep the suggested filename and tap Save.
5. Upload the resulting OKN_DSP_V32_CAPTURE_*.txt file to ChatGPT.

Do not press CLEAR LOG before saving.
