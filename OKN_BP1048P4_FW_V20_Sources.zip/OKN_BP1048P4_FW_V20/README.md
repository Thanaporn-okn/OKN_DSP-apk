# OKN_BP1048P4_FW_V20

V20 is the read-only hardware-discovery release built on the V19 mobile-flash transaction
contract. Firmware version is 20 while the wire protocol remains Protocol V2. The wire frame remains Protocol V2.

## What V20 adds

V20 adds `hardware_discovery_manifest.json`, `hardware_probe_evidence/`, and a content-bound
read-only verifier. It is designed for the first safe step toward Android USB-OTG flashing:
prove what transport the phone can actually observe before any vendor-specific command is
implemented.

Allowed evidence includes OS-level USB enumeration, BLE advertisement metadata, serial
port enumeration, vendor-tool read-only logs, and board-photo metadata. Captures are SHA256
verified and cannot authorize hardware by themselves. The verifier rejects path traversal,
symlinks, hash mismatch, non-empty command lists, or any recorded write attempt.

V20 intentionally contains **no destructive executor**, no programmer packet, no bootloader
command, no erase/program operation, no guessed target address/pin, and no `.bin`/`.img`.
The existing V19 transaction contract remains locked and still requires backup/readback,
exact programmer/image evidence, and explicit authorization.

## Safety status

- Exact BP1048P4 + GoloPine hardware port: LOCKED
- Hardware flashable: NO
- Android/mobile flashable: NO
- Read-only discovery captures shipped: NONE
- Programmer IO implemented: NO
- Destructive executor implemented: NO
- Unknown BP1048P4/GoloPine writes: NONE
- Unknown programmer/bootloader packets: NONE
- Legacy GoloPine SaveParams: NOT USED

Run `make host-test` for the full fail-closed validation suite.

See `docs/HARDWARE_DISCOVERY_V20.md`, `docs/MOBILE_FLASH_TRANSACTION_V19.md`,
`docs/PORT_INTEGRATION_PLAN_V18.md`, and `docs/QUALIFICATION_BUNDLE_V17.md`.
