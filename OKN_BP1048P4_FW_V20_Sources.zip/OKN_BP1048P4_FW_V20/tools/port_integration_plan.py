#!/usr/bin/env python3
"""V20 derived port integration plan.

The plan contains readiness state only. It deliberately carries no target
addresses, register values, pin assignments, programmer packets, or image
layout values. It never authorizes hardware by itself.
"""
from __future__ import annotations
from pathlib import Path
import argparse, json
from target_qualification_policy import evaluate
from qualification_bundle import load_and_verify

SUBSYSTEMS = {
    'identity': ('hardware', ('exact_chip_identity','exact_golopine_board_identity')),
    'startup_linker': ('hardware', ('exact_chip_identity','startup','linker_memory_map')),
    'flash_programming': ('hardware', (
        'exact_chip_identity','exact_golopine_board_identity','flash_programmer',
        'programmer_transport','image_layout','image_format','recovery_path','power_safety',
        'original_firmware_backup_readback','post_flash_readback_verify')),
    'safe_boot': ('hardware', (
        'exact_chip_identity','exact_golopine_board_identity','power_safety',
        'output_safety_mute','platform_init_output_safe')),
    'audio': ('hardware', (
        'exact_chip_identity','exact_golopine_board_identity','audio_api','board_audio_route',
        'output_safety_mute','platform_init_output_safe')),
    'ble_runtime': ('hardware', (
        'exact_chip_identity','exact_golopine_board_identity','ble_api','board_ble_route')),
    'nvm': ('hardware', (
        'exact_chip_identity','exact_golopine_board_identity','nvm_api','board_nvm_layout',
        'persistence_workspace_strategy')),
    'memory': ('hardware', (
        'exact_chip_identity','linker_memory_map','exact_ram_capacity','delay_arena_placement',
        'persistence_workspace_strategy')),
    'mobile_flash': ('mobile', (
        'exact_chip_identity','exact_golopine_board_identity','flash_programmer',
        'programmer_transport','image_layout','image_format','recovery_path','power_safety',
        'original_firmware_backup_readback','post_flash_readback_verify','android_host_transport')),
}

def build_plan(qmanifest: dict, verified_artifacts: dict) -> dict:
    ev=evaluate(qmanifest,verified_artifacts)
    qualified=ev['qualified']
    hw_auth=qmanifest.get('hardware_authorized') is True
    mob_auth=qmanifest.get('mobile_flash_authorized') is True
    subs={}
    for name,(scope,claims) in SUBSYSTEMS.items():
        q=[c for c in claims if qualified.get(c,False)]
        missing=[c for c in claims if not qualified.get(c,False)]
        complete=not missing
        authorized=(hw_auth if scope=='hardware' else (hw_auth and mob_auth))
        subs[name]={
            'required_claims':list(claims),
            'qualified_claims':q,
            'missing_claims':missing,
            'evidence_complete':complete,
            'authorization_scope':scope,
            'authorized':authorized,
            'ready_for_integration':complete and authorized,
        }
    all_hw=all(v['ready_for_integration'] for k,v in subs.items() if v['authorization_scope']=='hardware')
    mobile=subs['mobile_flash']['ready_for_integration']
    return {
        'schema':1,
        'project_version':20,
        'target':'BP1048P4',
        'board':'GoloPine 7CH',
        'policy':'DERIVED_FROM_CONTENT_BOUND_QUALIFICATION_NO_HARDWARE_VALUES',
        'contains_target_addresses_or_packets':False,
        'hardware_authorized':hw_auth,
        'mobile_flash_authorized':mob_auth,
        'hardware_integration_ready':all_hw,
        'mobile_flash_integration_ready':mobile,
        'subsystems':subs,
    }

def derive_from_files(root: Path) -> dict:
    q=json.loads((root/'target_qualification_manifest.json').read_text())
    br=load_and_verify(root/'qualification_bundle_manifest.json',root)
    if not br['ok']:
        raise ValueError('qualification bundle invalid: '+'; '.join(br['errors']))
    return build_plan(q,br['verified_index'])

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--root',default='.')
    ap.add_argument('--write')
    a=ap.parse_args()
    root=Path(a.root).resolve(); plan=derive_from_files(root)
    text=json.dumps(plan,indent=2)+'\n'
    if a.write: (root/a.write).write_text(text)
    else: print(text,end='')
    return 0
if __name__=='__main__': raise SystemExit(main())
