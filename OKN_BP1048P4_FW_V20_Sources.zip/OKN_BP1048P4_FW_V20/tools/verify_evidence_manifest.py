#!/usr/bin/env python3
from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'evidence_manifest.json').read_text())
errors=[]
if m.get('schema')!=4: errors.append('evidence schema must be 4')
if m.get('project_version')!=20: errors.append('project_version must be 20')
if m.get('target')!='BP1048P4' or m.get('board')!='GoloPine 7CH': errors.append('target/board mismatch')
if m.get('policy')!='FAIL_CLOSED_NO_INFERENCE': errors.append('policy mismatch')
if m.get('hardware_authorized') is not False: errors.append('hardware_authorized must be false')
req=m.get('required_exact_evidence',{})
if any(bool(v) for v in req.values()): errors.append('V20 exact evidence flags must all remain false')
prov=m.get('provenance',{})
if prov.get('previous_source_sha256')!='cab8da4d4c790fdbbfd6ea6f03f2006e2e3faff62f4f71bf4065f5c8c03fae32': errors.append('V19 source provenance mismatch')
if prov.get('validation_zip_sha256')!='f4ad3056ba8cba4964a937de2e66f3ccd21aab5c0cdfbe2c769bdb2a45b69939': errors.append('V19 validation provenance mismatch')
if not any(o.get('id')=='v19-ci-validation' for o in m.get('observations',[])): errors.append('V19 CI observation missing')
for ob in m.get('observations',[]):
    if ob.get('authorizes') not in ([],None): errors.append('observations may not authorize hardware in V20')
if errors:
    [print('BLOCKED:',e) for e in errors]; sys.exit(1)
print('PASS: V20 evidence manifest is internally consistent and non-authorizing')
