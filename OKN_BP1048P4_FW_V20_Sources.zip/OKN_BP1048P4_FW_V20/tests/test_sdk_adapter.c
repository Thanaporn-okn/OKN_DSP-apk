#include "../src/hal/bp1048p4_sdk_adapter.h"
#include <assert.h>
#include <stdio.h>

static bp1048p4_sdk_capabilities_t fully_proven_board(void) {
    bp1048p4_sdk_capabilities_t c = {
        .abi_version = BP1048P4_SDK_ADAPTER_ABI,
        .evidence_level = BP1048P4_SDK_EVIDENCE_EXACT_BOARD,
        .exact_bp1048p4_identity_verified = true,
        .exact_golopine_board_verified = true,
        .startup_verified = true,
        .linker_verified = true,
        .flash_programmer_verified = true,
        .image_layout_verified = true,
        .image_format_verified = true,
        .programmer_transport_verified = true,
        .recovery_path_verified = true,
        .power_safety_verified = true,
        .original_firmware_backup_readback_verified = true,
        .post_flash_readback_verify_verified = true,
        .audio_api_verified = true,
        .board_audio_route_verified = true,
        .output_safety_mute_verified = true,
        .platform_init_output_safe_verified = true,
        .ble_api_verified = true,
        .board_ble_route_verified = true,
        .nvm_api_verified = true,
        .board_nvm_layout_verified = true
    };
    return c;
}

int main(void) {
    const bp1048p4_sdk_capabilities_t *locked = bp1048p4_sdk_capabilities_get();
    assert(bp1048p4_sdk_adapter_authorize(locked, BP1048P4_SDK_USE_RUNTIME_AUDIO) == OKN_ERR_HAL_LOCKED);
    assert(bp1048p4_sdk_adapter_authorize(locked, BP1048P4_SDK_USE_FLASH_IMAGE) == OKN_ERR_HAL_LOCKED);

    /* Family/B1 evidence must never authorize a P4/GoloPine operation. */
    bp1048p4_sdk_capabilities_t family = fully_proven_board();
    family.evidence_level = BP1048P4_SDK_EVIDENCE_FAMILY_ONLY;
    family.exact_bp1048p4_identity_verified = false;
    family.exact_golopine_board_verified = false;
    assert(bp1048p4_sdk_adapter_authorize(&family, BP1048P4_SDK_USE_RUNTIME_AUDIO) == OKN_ERR_HAL_LOCKED);
    assert(bp1048p4_sdk_adapter_authorize(&family, BP1048P4_SDK_USE_FLASH_IMAGE) == OKN_ERR_HAL_LOCKED);

    /* Exact BP1048P4 chip proof alone still cannot authorize the
     * GoloPine board. Board identity + routing/layout evidence is separate. */
    bp1048p4_sdk_capabilities_t chip = fully_proven_board();
    chip.evidence_level = BP1048P4_SDK_EVIDENCE_EXACT_CHIP;
    chip.exact_golopine_board_verified = false;
    assert(bp1048p4_sdk_adapter_authorize(&chip, BP1048P4_SDK_USE_RUNTIME_AUDIO) == OKN_ERR_HAL_LOCKED);
    assert(bp1048p4_sdk_adapter_authorize(&chip, BP1048P4_SDK_USE_RUNTIME_BLE) == OKN_ERR_HAL_LOCKED);
    assert(bp1048p4_sdk_adapter_authorize(&chip, BP1048P4_SDK_USE_RUNTIME_NVM) == OKN_ERR_HAL_LOCKED);
    assert(bp1048p4_sdk_adapter_authorize(&chip, BP1048P4_SDK_USE_FLASH_IMAGE) == OKN_ERR_HAL_LOCKED);

    /* Exact-board authorization remains subsystem-granular. */
    bp1048p4_sdk_capabilities_t board = fully_proven_board();
    board.board_audio_route_verified = false;
    assert(bp1048p4_sdk_adapter_authorize(&board, BP1048P4_SDK_USE_RUNTIME_AUDIO) == OKN_ERR_HAL_LOCKED);
    board.board_audio_route_verified = true;
    board.platform_init_output_safe_verified = false;
    assert(bp1048p4_sdk_adapter_authorize(&board, BP1048P4_SDK_USE_RUNTIME_AUDIO) == OKN_ERR_HAL_LOCKED);
    board.platform_init_output_safe_verified = true;
    assert(bp1048p4_sdk_adapter_authorize(&board, BP1048P4_SDK_USE_RUNTIME_AUDIO) == OKN_OK);

    board.board_ble_route_verified = false;
    assert(bp1048p4_sdk_adapter_authorize(&board, BP1048P4_SDK_USE_RUNTIME_BLE) == OKN_ERR_HAL_LOCKED);
    board.board_ble_route_verified = true;
    assert(bp1048p4_sdk_adapter_authorize(&board, BP1048P4_SDK_USE_RUNTIME_BLE) == OKN_OK);

    board.board_nvm_layout_verified = false;
    assert(bp1048p4_sdk_adapter_authorize(&board, BP1048P4_SDK_USE_RUNTIME_NVM) == OKN_ERR_HAL_LOCKED);
    board.board_nvm_layout_verified = true;
    assert(bp1048p4_sdk_adapter_authorize(&board, BP1048P4_SDK_USE_RUNTIME_NVM) == OKN_OK);

    board.image_layout_verified = false;
    assert(bp1048p4_sdk_adapter_authorize(&board, BP1048P4_SDK_USE_FLASH_IMAGE) == OKN_ERR_HAL_LOCKED);
    board.image_layout_verified = true;
    board.image_format_verified = false;
    assert(bp1048p4_sdk_adapter_authorize(&board, BP1048P4_SDK_USE_FLASH_IMAGE) == OKN_ERR_HAL_LOCKED);
    board.image_format_verified = true;
    board.programmer_transport_verified = false;
    assert(bp1048p4_sdk_adapter_authorize(&board, BP1048P4_SDK_USE_FLASH_IMAGE) == OKN_ERR_HAL_LOCKED);
    board.programmer_transport_verified = true;
    board.recovery_path_verified = false;
    assert(bp1048p4_sdk_adapter_authorize(&board, BP1048P4_SDK_USE_FLASH_IMAGE) == OKN_ERR_HAL_LOCKED);
    board.recovery_path_verified = true;
    board.power_safety_verified = false;
    assert(bp1048p4_sdk_adapter_authorize(&board, BP1048P4_SDK_USE_FLASH_IMAGE) == OKN_ERR_HAL_LOCKED);
    board.power_safety_verified = true;
    board.original_firmware_backup_readback_verified = false;
    assert(bp1048p4_sdk_adapter_authorize(&board, BP1048P4_SDK_USE_FLASH_IMAGE) == OKN_ERR_HAL_LOCKED);
    board.original_firmware_backup_readback_verified = true;
    board.post_flash_readback_verify_verified = false;
    assert(bp1048p4_sdk_adapter_authorize(&board, BP1048P4_SDK_USE_FLASH_IMAGE) == OKN_ERR_HAL_LOCKED);
    board.post_flash_readback_verify_verified = true;
    assert(bp1048p4_sdk_adapter_authorize(&board, BP1048P4_SDK_USE_FLASH_IMAGE) == OKN_OK);

    puts("ALL V20 SDK-ADAPTER GATE TESTS PASS");
    return 0;
}
