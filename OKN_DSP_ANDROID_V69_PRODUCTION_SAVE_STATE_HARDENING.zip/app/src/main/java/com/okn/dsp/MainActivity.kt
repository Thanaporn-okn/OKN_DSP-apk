package com.okn.dsp

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * V69 production hardening control hub.
 *
 * New in V69: keeps the fully runtime-qualified V68 Unified scalar + safe-PEAKING EQ scope and hardens permanent save with fresh PRE-SAVE and POST-SAVE full-descriptor state checks. No new write family is enabled; Sensors/non-standard EQ remain read-only and generic/preset/delay/unknown writes stay locked.
 */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
    }

    private fun buildUi(): ScrollView {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 32)
        }

        root.addView(TextView(this).apply {
            text = "OKN DSP V69 — PRODUCTION HARDENED CONTROL HUB"
            textSize = 22f
        })

        root.addView(TextView(this).apply {
            text = "REAL DSP CONTROLS ONLY • NO MOCK EQ • NO LOCAL PRESET WRITE • GENERIC WRITES LOCKED"
            textSize = 14f
            setPadding(0, 8, 0, 12)
        })

        root.addView(TextView(this).apply {
            text = "Verified coverage\n" +
                "• Global FLOAT32: IDs 2,3,8,9,10,13,11\n" +
                "• EQ 7CH: actuator IDs 4,5,6,14,15,16,17 • 15 bands/channel\n" +
                "• SaveParams: ID7 exact trigger 570000000700000000\n" +
                "• V69 unified dashboard: V68-qualified Global + safe-PEAKING EQ writes preserved; SaveParams now requires fresh PRE-SAVE and POST-SAVE descriptor checks.\n" +
                "• REFRESH ALL now visibly reports START/COMPLETE + time + changed counts even when values are unchanged.\n" +
                "• Preset, Delay and unknown writes remain locked."
            textSize = 13f
            setPadding(0, 0, 0, 16)
        })

        root.addView(Button(this).apply {
            text = "UNIFIED V69 • V68 VERIFIED WRITES + SAVE STATE HARDENING"
            setOnClickListener { startActivity(Intent(this@MainActivity, UnifiedControlActivity::class.java)) }
        })
        root.addView(TextView(this).apply {
            text = "V69 Phase 3: all V68 scalar/EQ verify + rollback behavior is preserved. Manual Permanent Save now performs fresh full-descriptor PRE-SAVE verification of every touched last-verified state, then exact SaveParams, GATT success + 5s settle, then fresh POST-SAVE verification before COMPLETE. No auto-retry on mismatch."
            textSize = 12f
            setPadding(0, 2, 0, 12)
        })

        root.addView(Button(this).apply {
            text = "GLOBAL CONTROLS • 7 VERIFIED REAL DSP CONTROLS • APPLY + VERIFY + PERMANENT SAVE"
            setOnClickListener { startActivity(Intent(this@MainActivity, ScalarControlActivity::class.java)) }
        })
        root.addView(TextView(this).apply {
            text = "Production Global Controls: every APPLY uses WRITE 0x57 → fresh Device Description verify → automatic rollback if verify fails. Permanent Save remains a separate guarded action."
            textSize = 12f
            setPadding(0, 2, 0, 12)
        })

        root.addView(Button(this).apply {
            text = "LIVE EQ 7CH • REAL DSP • APPLY + VERIFY + PERMANENT SAVE"
            setOnClickListener { startActivity(Intent(this@MainActivity, LiveEqActivity::class.java)) }
        })
        root.addView(TextView(this).apply {
            text = "7CH real EQ from live Device Description • 105 bands • writes only verified safe PEAKING bands • automatic rollback when readback does not match."
            textSize = 12f
            setPadding(0, 2, 0, 12)
        })

        root.addView(Button(this).apply {
            text = "ADVANCED • EVIDENCE / CAPTURE LAB (READ-ONLY / PROOF TOOLS)"
            setOnClickListener { startActivity(Intent(this@MainActivity, EvidenceLabActivity::class.java)) }
        })

        return ScrollView(this).apply { addView(root) }
    }
}
