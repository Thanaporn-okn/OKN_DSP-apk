OKN_DSP v1.0.0 — MASTER REFERENCE / VERIFIED REALTIME DSP CONTROLLER
=====================================================================

IDENTITY
- App Name: OKN_DSP
- applicationId: com.okn.dsp
- versionCode: 1
- versionName: 1.0.0
- UI master: evidence/OKN_DSP_V1_UI_MASTER_REFERENCE.png

IMPLEMENTED IN V1.0.0
- New V1 application/runtime/state architecture; UI never writes BluetoothGatt directly.
- Reference-style black/dark-blue/cyan UI: OKN_DSP header, DSP-7CH card, preset selector,
  Global / EQ / Channel / Crossover / Delay / Output tabs, and Home / Live / Settings navigation.
- Portrait + landscape via fullSensor; process-scoped DSP runtime keeps GATT/session outside Activity recreation.
- Real BLE scan, device list, connect, disconnect, remembered reconnect, and automatic reconnect recovery.
- Verified GATT profile: Service AB00, AB01 write, AB02 primary notifications, AB03 secondary notifications.
- Explicit connection/session flow:
  Scan -> Connect -> Discover Services -> Enable Notifications -> Authentication
  -> Establish Session -> Device Description -> Read DSP State -> READY.
- 15,000 ms connection/descriptor watchdog.
- Explicit connection epoch. Every queued command is stamped with the active epoch and stale commands are blocked.
- AES-CFB8/NoPadding current-session transport using the verified RandKey path and IV=01 x16.
- Single central realtime write engine: one GATT write in flight, latest-target-wins coalescing, callback validation,
  queue clearing on connection loss, and final-target ramping.
- UI responds on every slider/fader/knob movement. No Apply/Confirm/OK for normal sound adjustment.
- Automatic local state persistence with 60 ms latest-state debounce plus lifecycle flush.
- Safe state replay only after a fresh authenticated Device Description / Health Gate.

VERIFIED GLOBAL / SCALAR CONTROL SURFACE
- ID 2  Master Volume
- ID 3  Remind Sound Volume (Output/System page)
- ID 8  Bass Volume
- ID 9  Bass Cutoff
- ID 10 Bass Boost
- ID 13 Middle Boost
- ID 11 Treble Boost
- Global reference page exposes Master Volume, Bass Volume, Bass Cutoff, Bass Boost, Middle Boost, Treble Boost.
- Master speaker/mute button is functional without inventing a mute packet: it uses verified MasterVolume ID2,
  mutes to -70 dB and restores the remembered pre-mute value.
- Reset / Save Preset / Load Preset are functional.

TREBLE / REALTIME AUDIO SAFETY
- TrebleBoost ID11 uses ordered callback-gated <=0.5 dB steps.
- Older intermediate targets are replaced by the latest target; stale values are never re-applied after a newer target.
- UI remains instantaneous while DSP writes are deliberately paced to reduce pop/stutter risk.
- Current audio-safe transport pacing: 90 ms global queue; Treble nominal 96 ms between successful steps.
- The final target is retained until the ramp reaches it or the session is invalidated.

EQ
- 7 channels: CH1..CH7.
- 15 EQ/Biquad records per channel = 105 records total.
- Verified EQ actuator IDs: CH1=4, CH2=5, CH3=6, CH4=14, CH5=15, CH6=16, CH7=17.
- Real-time draggable graph, Graphic EQ mode, Parametric EQ mode.
- Frequency / Q / Gain control for records verified as PEAKING type=12.
- Full verified 48-byte EQ record writer retained.
- Flat / Reset / Copy / Paste work on verified writable EQ rows.
- Non-PEAKING rows remain read-only; no guessed packet is emitted.

PRESET / SAVE POLICY
- App-local Preset Save/Load is separate from hardware nonvolatile SaveParams.
- Local presets include every currently verified writable scalar and PEAKING EQ record.
- SaveParams ID7 exact verified trigger is manual-only and health-gated.
- SaveParams is never fired from slider movement or automatic local persistence.

LOCKED BY PROTOCOL SAFETY
The following UI areas exist but hardware writes stay LOCKED until their packet mapping is proven:
- Crossover HPF/LPF hardware writes
- Delay hardware writes
- hardware preset recall/write protocol
- unverified per-channel Gain/Mute/Phase/Routing
- unverified Output Gain/Mute/Phase/Routing
- generic unknown actuator writes
No mock/fake DSP packet is used to make these controls appear functional.

BUILD
- JDK 17
- compileSdk / targetSdk 35
- minSdk 26
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- GitHub workflow uses Gradle 8.9

VALIDATION
- preflight_v1.py validates identity, reference image hash, signing key hash, BLE profile,
  READY/session flow, connection epoch, 15 s watchdog, verified IDs, realtime queue, persistence and lock gates.
- tools/ProtocolJvmSmoke.kt validates verified UFE/scalar/EQ/SaveParams/CFB8 vectors without Android.

IMPORTANT
Static/source validation cannot prove acoustic behavior on the physical DSP/speakers. Treble no-pop/no-stutter
must still be qualified on the real hardware. The production safety rule remains: unknown DSP packets stay locked.
