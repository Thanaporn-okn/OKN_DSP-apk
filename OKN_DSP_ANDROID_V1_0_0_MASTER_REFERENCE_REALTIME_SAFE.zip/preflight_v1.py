#!/usr/bin/env python3
from pathlib import Path
import hashlib, re, xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
UI_HASH = 'f61679fcfe8316f2770aefe88bfc5428f428f06201228724e6964bde12358cd3'
KEYSTORE_HASH = 'ba1c52f2607c09953c52fdd79c5f72026aaf0adb8aa44bcba277f7d9b49d9511'

def die(msg):
    print('ERROR:', msg)
    raise SystemExit(1)

def ok(msg): print('OK:', msg)

def text(rel):
    p=ROOT/rel
    if not p.is_file(): die(f'missing {rel}')
    return p.read_text(encoding='utf-8')

def sha(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()

def must(s, marker, where):
    if marker not in s: die(f'missing marker {marker!r} in {where}')

required = [
    'app/build.gradle.kts','app/src/main/AndroidManifest.xml','app/okn_dsp_stable_debug.keystore',
    'app/src/main/java/com/okn/dsp/MainActivity.kt','app/src/main/java/com/okn/dsp/OknDspApplication.kt',
    'app/src/main/java/com/okn/dsp/state/DspModels.kt','app/src/main/java/com/okn/dsp/state/DspStateStore.kt',
    'app/src/main/java/com/okn/dsp/ble/BleDspManager.kt','app/src/main/java/com/okn/dsp/ble/BleProfile.kt',
    'app/src/main/java/com/okn/dsp/repository/DspRepository.kt','app/src/main/java/com/okn/dsp/persistence/DspPreferences.kt',
    'app/src/main/java/com/okn/dsp/queue/RealtimeCommandQueue.kt','app/src/main/java/com/okn/dsp/smoothing/ScalarRampController.kt',
    'app/src/main/java/com/okn/dsp/smoothing/EqSlewController.kt','app/src/main/java/com/okn/dsp/ui/ReferenceDspUi.kt',
    'app/src/main/java/com/okn/dsp/protocol/VerifiedScalarControls.kt','app/src/main/java/com/okn/dsp/protocol/LiveEqPolicy.kt',
    'app/src/main/java/com/okn/dsp/protocol/WriteGate.kt','app/src/main/java/com/okn/dsp/protocol/SaveParamsPolicy.kt',
    'evidence/OKN_DSP_V1_UI_MASTER_REFERENCE.png','README_V1.txt','tools/ProtocolJvmSmoke.kt'
]
for f in required:
    if not (ROOT/f).is_file(): die(f'missing {f}')
ok(f'{len(required)} required files exist')

gradle=text('app/build.gradle.kts')
for m in ['applicationId = "com.okn.dsp"','versionCode = 1','versionName = "1.0.0"','compileSdk = 35','targetSdk = 35','minSdk = 26']:
    must(gradle,m,'app/build.gradle.kts')
ok('V1.0.0 identity')

manifest_path=ROOT/'app/src/main/AndroidManifest.xml'
try: ET.parse(manifest_path)
except Exception as e: die(f'AndroidManifest invalid: {e}')
manifest=manifest_path.read_text()
for m in ['android:name=".OknDspApplication"','android:screenOrientation="fullSensor"','android:configChanges="orientation|screenSize|smallestScreenSize|keyboardHidden"','android:label="OKN_DSP"']:
    must(manifest,m,'AndroidManifest.xml')
ok('process-scoped orientation/lifecycle contract')

if sha(ROOT/'evidence/OKN_DSP_V1_UI_MASTER_REFERENCE.png') != UI_HASH: die('UI reference hash mismatch')
if sha(ROOT/'app/okn_dsp_stable_debug.keystore') != KEYSTORE_HASH: die('stable debug keystore hash changed')
ok('reference image + stable debug signing identity')

profile=text('app/src/main/java/com/okn/dsp/ble/BleProfile.kt')
for m in ['0000ab00-0000-1000-8000-00805f9b34fb','0000ab01-0000-1000-8000-00805f9b34fb','0000ab02-0000-1000-8000-00805f9b34fb','0000ab03-0000-1000-8000-00805f9b34fb']:
    must(profile,m,'BleProfile.kt')
ble=text('app/src/main/java/com/okn/dsp/ble/BleDspManager.kt')
for m in [
    '631C062443FD3844558001F3EDA0CCF8','ConnectionState.ENABLING_NOTIFICATIONS',
    'ConnectionState.ESTABLISHING_SESSION','ConnectionState.READING_DEVICE_DESCRIPTION',
    'notifyChSecondary','subscribe(g, secondary, "AB03")','connectionEpoch',
    'command.epoch != connectionEpoch','main.postDelayed(it, 15_000L)','refreshDescriptor(DescriptorMode.INITIAL)'
]: must(ble,m,'BleDspManager.kt')
ok('BLE AB00/01/02/03 + explicit session flow + epoch + 15s watchdog')

models=text('app/src/main/java/com/okn/dsp/state/DspModels.kt')
for m in ['ENABLING_NOTIFICATIONS','ESTABLISHING_SESSION','READING_DEVICE_DESCRIPTION','READING_DSP_STATE','READY','val connectionEpoch: Long = 0L']:
    must(models,m,'DspModels.kt')
ok('READY state machine')

scalar=text('app/src/main/java/com/okn/dsp/protocol/VerifiedScalarControls.kt')
ids=[int(x) for x in re.findall(r'VerifiedScalarControl\((\d+),',scalar)]
if ids != [2,3,8,9,10,13,11]: die(f'scalar allow-list changed: {ids}')
ui=text('app/src/main/java/com/okn/dsp/ui/ReferenceDspUi.kt')
for m in ['private val visibleIds=listOf(2,8,9,10,13,11)','Remind Sound Volume','toggleMasterMute()','Graphic EQ','Parametric EQ','"Crossover"','"Delay"','"Output"']:
    must(ui,m,'ReferenceDspUi.kt')
ok('all 7 verified scalars reachable; six reference Global controls preserved')

queue=text('app/src/main/java/com/okn/dsp/queue/RealtimeCommandQueue.kt')
for m in ['private var inflight: Command? = null','realtime[command.key] = command','val epoch: Long']:
    must(queue,m,'RealtimeCommandQueue.kt')
ramp=text('app/src/main/java/com/okn/dsp/smoothing/ScalarRampController.kt')
for m in ['id == 11 -> 0.5f','if (id == 11) 96L else 90L','target[id] = v']:
    must(ramp,m,'ScalarRampController.kt')
eq=text('app/src/main/java/com/okn/dsp/smoothing/EqSlewController.kt')
must(eq,'moveLinear(c.boostDb, t.boostDb, 0.5f)','EqSlewController.kt')
ok('one-inflight latest-target realtime + ordered Treble/EQ slew')

prefs=text('app/src/main/java/com/okn/dsp/persistence/DspPreferences.kt')
for m in ['debounceMs: Long = 60L','Local auto-save only. This class never emits SaveParams or any BLE command.']:
    must(prefs,m,'DspPreferences.kt')
repo=text('app/src/main/java/com/okn/dsp/repository/DspRepository.kt')
for m in ['restoreLocalAfterHealthGate(parsed)','ConnectionState.READY','scheduleReconnect()','connectionEpoch = ble.currentEpoch()','fun saveParamsManual(): Boolean']:
    must(repo,m,'DspRepository.kt')
ok('local persistence + safe replay + automatic reconnect recovery')

gate=text('app/src/main/java/com/okn/dsp/protocol/WriteGate.kt')
for m in ['const val enabled: Boolean = false','const val presetHardwareWritesEnabled: Boolean = false','const val crossoverWritesEnabled: Boolean = false','const val delayWritesEnabled: Boolean = false','const val unknownOutputWritesEnabled: Boolean = false']:
    must(gate,m,'WriteGate.kt')
ok('unverified hardware write surfaces remain fail-closed')

all_kt='\n'.join(p.read_text(errors='ignore') for p in (ROOT/'app/src/main/java').rglob('*.kt'))
if all_kt.count('saveParamsManual()') != 2: die('SaveParams manual trigger call/definition count changed')
if 'AA 55' in all_kt or '0xAA, 0x55' in all_kt: die('conceptual AA55 packet leaked into production source')
ok('no fake AA55 protocol; SaveParams remains manual-only')

print('PREFLIGHT_V1_0_0_PASS')
