# OKN_DSP V1

โปรเจกต์ Android ใหม่ที่เริ่มนับ Version จาก V1 ตามภาพ UI อ้างอิง 5 หน้า: Home, EQ, Crossover, Delay และ Output

- UI เป็น Jetpack Compose และคอนโทรลเปลี่ยนค่าทันทีใน `onValueChange` / `onClick` ไม่มีการหน่วงค่าในชั้น UI
- รองรับ 7 ช่อง CH1–CH7
- มี BLE scan / connect จริง และใช้ UUID ที่ยืนยันแล้ว `0000ab01-0000-1000-8000-00805f9b34fb`
- ไม่ส่ง command bytes ที่เดาเองไปยัง DSP; จุดเข้ารหัสคำสั่งอยู่ใน `DspProtocol.encodeVerified()`
- ภาพต้นฉบับทั้ง 5 หน้าเก็บใน `Sources/UI_REFERENCE/`
- SHA256 manifest เก็บใน `Sources/`

Build สำหรับ GitHub Actions ใช้ไฟล์ workflow ที่ส่งแยกจาก ZIP เพื่อให้มือถืออัปโหลดไฟล์ ZIP ได้โดยไม่ต้องอัปโหลดโฟลเดอร์ Android ทั้งหมด
