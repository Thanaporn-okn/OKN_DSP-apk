# OKN DSP HCI Analyzer V1

วิเคราะห์ไฟล์ Android Bluetooth HCI Snoop/BTSnoop เพื่อแกะ protocol ของ OKN DSP โดย **ไม่ส่งคำสั่งควบคุม DSP**

## เป้าหมาย
- แยก ATT traffic
- หา AB01 write ที่ handle `0x0006`
- หา notification จาก AB02/AB03
- สรุปความยาว packet และ timeline
- เก็บ raw bytes สำหรับทำ packet-diff รอบถัดไป

## วิธีใช้บน GitHub (เหมาะกับมือถือ)
1. อัปโหลด ZIP นี้ไว้ใน repo
2. อัปโหลดไฟล์ `.cfa` หรือ `.log` ไว้ที่ root ของ repo
3. อัปโหลด workflow ที่มากับแพ็กนี้ไปที่ `.github/workflows/`
4. กด GitHub Actions → `OKN DSP HCI Analyzer V1` → Run workflow
5. ดาวน์โหลด artifact `OKN_DSP_HCI_ANALYSIS`

> ไม่ต้องแก้ source code ของแอป DSP และไม่ต้องส่ง payload ใด ๆ ไปยังบอร์ด
