#!/usr/bin/env python3
import argparse, csv, json, math, struct
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

TARGET_TX = 0x0006
TARGET_RX = {0x0008, 0x000B}
ATT_WRITE_CMD = 0x52
ATT_NOTIFY = 0x1B
ATT_WRITE_REQ = 0x12
ATT_READ_REQ = 0x0A
ATT_READ_RSP = 0x0B
ATT_ERROR = 0x01


def ts_to_iso(ts):
    # BTSnoop timestamp is microseconds since 0 AD (not Unix). Bluetooth btsnoop epoch offset.
    unix_us = ts - 0x00E03AB44A676000
    if unix_us < 0:
        return str(ts)
    return datetime.fromtimestamp(unix_us / 1_000_000, tz=timezone.utc).isoformat()


def parse(path):
    data = Path(path).read_bytes()
    if len(data) < 16 or data[:8] != b'btsnoop\x00':
        raise ValueError('Not a BTSnoop file')
    version, datalink = struct.unpack('>II', data[8:16])
    if version != 1:
        raise ValueError(f'Unsupported BTSnoop version: {version}')
    off = 16
    recs = []
    while off + 24 <= len(data):
        orig_len, incl_len, flags, drops, ts = struct.unpack('>IIIIQ', data[off:off+24])
        off += 24
        pkt = data[off:off+incl_len]
        off += incl_len
        if len(pkt) != incl_len or not pkt:
            continue
        recs.append((ts, flags, pkt))
    return version, datalink, recs


def att_records(recs):
    out=[]
    for ts, flags, pkt in recs:
        if pkt[0] != 0x02 or len(pkt) < 9: # HCI ACL data
            continue
        acl_len = struct.unpack('<H', pkt[3:5])[0]
        acl = pkt[5:5+acl_len]
        if len(acl) < 4:
            continue
        l2cap_len, cid = struct.unpack('<HH', acl[:4])
        if cid != 0x0004:
            continue
        payload = acl[4:4+l2cap_len]
        if not payload:
            continue
        op = payload[0]
        direction = 'TX' if flags == 0 else ('RX' if flags == 1 else f'FLAG_{flags}')
        handle = None
        value = b''
        if op in (ATT_WRITE_CMD, ATT_WRITE_REQ, ATT_READ_REQ):
            if len(payload) >= 3:
                handle = struct.unpack('<H', payload[1:3])[0]
                value = payload[3:]
        elif op == ATT_NOTIFY:
            if len(payload) >= 3:
                handle = struct.unpack('<H', payload[1:3])[0]
                value = payload[3:]
        elif op == ATT_READ_RSP:
            value = payload[1:]
        elif op == ATT_ERROR:
            value = payload[1:]
        out.append({
            'ts': ts, 'iso': ts_to_iso(ts), 'direction': direction,
            'opcode': op, 'handle': handle, 'value': value,
            'packet': payload,
        })
    return out


def entropy(b):
    if not b: return 0.0
    c=Counter(b); n=len(b)
    return -sum((v/n)*math.log2(v/n) for v in c.values())


def hexs(b): return b.hex()


def write_csv(rows, path):
    with open(path,'w',newline='',encoding='utf-8') as f:
        w=csv.writer(f)
        w.writerow(['index','timestamp_utc','direction','opcode','handle','value_len','value_hex','entropy_bits_byte'])
        for i,r in enumerate(rows):
            w.writerow([i,r['iso'],r['direction'],f"0x{r['opcode']:02X}", '' if r['handle'] is None else f"0x{r['handle']:04X}",len(r['value']),hexs(r['value']),f"{entropy(r['value']):.4f}"])


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('input')
    ap.add_argument('--out',default='okn_hci_analysis')
    args=ap.parse_args()
    out=Path(args.out); out.mkdir(parents=True,exist_ok=True)
    version,datalink,recs=parse(args.input)
    rows=att_records(recs)
    target_tx=[r for r in rows if r['direction']=='TX' and r['handle']==TARGET_TX and r['opcode'] in (ATT_WRITE_CMD,ATT_WRITE_REQ)]
    target_rx=[r for r in rows if r['direction']=='RX' and r['handle'] in TARGET_RX and r['opcode']==ATT_NOTIFY]
    all_notifies=[r for r in rows if r['direction']=='RX' and r['opcode']==ATT_NOTIFY]
    # pair each TX with first RX after it within 3 seconds
    pairs=[]
    for i,tx in enumerate(target_tx):
        nxt=None
        for rx in target_rx:
            if rx['ts']>=tx['ts']:
                dt=(rx['ts']-tx['ts'])/1e6
                if dt<=3:
                    nxt=(rx,dt)
                break
        pairs.append((i,tx,nxt))
    tx_lengths=Counter(len(r['value']) for r in target_tx)
    rx_lengths=Counter(len(r['value']) for r in target_rx)
    rx_handles=Counter(r['handle'] for r in all_notifies)
    opcode_counts=Counter((r['direction'],r['opcode']) for r in rows)
    # recurring prefixes for 9-byte TX values
    prefix=Counter(r['value'][:1].hex() for r in target_tx if len(r['value'])==9)
    summary={
      'input':str(Path(args.input).name), 'btsnoop_version':version, 'datalink':datalink,
      'records':len(recs), 'att_records':len(rows),
      'target_tx_ab01':len(target_tx), 'target_rx_notifications':len(target_rx),
      'target_rx_handles':{f'0x{k:04X}':v for k,v in rx_handles.items()},
      'tx_value_lengths':dict(sorted(tx_lengths.items())),
      'rx_value_lengths':dict(sorted(rx_lengths.items())),
      'opcode_counts':{f'{d}_0x{o:02X}':v for (d,o),v in sorted(opcode_counts.items())},
      'tx_9byte_first_byte_top':prefix.most_common(20),
      'large_rx_235_count':rx_lengths.get(235,0),
      'note':'No DSP command bytes are invented or emitted by this analyzer.'
    }
    (out/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False),encoding='utf-8')
    write_csv(rows,out/'att_all.csv')
    write_csv(target_tx,out/'ab01_tx.csv')
    write_csv(target_rx,out/'ab02_ab03_rx.csv')
    with open(out/'ab01_tx.bin','wb') as f:
        for r in target_tx: f.write(bytes([len(r['value']) & 255])+r['value'])
    with open(out/'notifications.bin','wb') as f:
        for r in target_rx: f.write(struct.pack('<H',len(r['value']))+r['value'])

    md=[]
    md.append('# OKN DSP — HCI/BTSnoop Packet Analysis V1')
    md.append('')
    md.append(f"Input: `{Path(args.input).name}`")
    md.append('')
    md.append('## Evidence extracted')
    md.append(f'- BTSnoop records: **{len(recs)}**')
    md.append(f'- ATT records: **{len(rows)}**')
    md.append(f'- AB01 writes (handle `0x0006`): **{len(target_tx)}**')
    md.append(f'- Notifications from AB02/AB03 handles: **{len(target_rx)}**')
    md.append('')
    md.append('## AB01 TX lengths')
    for k,v in sorted(tx_lengths.items()): md.append(f'- {k} bytes: {v}')
    md.append('')
    md.append('## AB02/AB03 notification lengths')
    for k,v in sorted(rx_lengths.items()): md.append(f'- {k} bytes: {v}')
    md.append('')
    md.append('## Important observation')
    md.append(f"- The 235-byte notification payload occurs **{rx_lengths.get(235,0)} times**.")
    md.append('- This is evidence from the HCI capture; it is not assumed to be a DSP application packet.')
    md.append('- The analyzer preserves raw bytes and does not attempt to guess encryption, checksum, EQ fields, channel mapping, or coefficient format.')
    md.append('')
    md.append('## Next reverse-engineering operation')
    md.append('1. Use the TX/RX timeline in `att_all.csv` and `ab01_tx.csv`.')
    md.append('2. Group traffic around one deliberate UI action at a time (for example one EQ slider change).')
    md.append('3. Compare the exact AB01 write before/after the action and the first related notification(s).')
    md.append('4. Only promote a byte/field to a protocol hypothesis when the same relationship repeats across controlled captures.')
    md.append('')
    md.append('## Safety')
    md.append('This package is analysis-only. It sends no BLE/DSP payloads and contains no guessed control command.')
    (out/'REPORT.md').write_text('\n'.join(md)+'\n',encoding='utf-8')
    print(json.dumps(summary,indent=2,ensure_ascii=False))

if __name__=='__main__': main()
