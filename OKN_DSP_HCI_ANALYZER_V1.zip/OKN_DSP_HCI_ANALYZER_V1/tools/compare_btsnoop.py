#!/usr/bin/env python3
import argparse, csv, difflib, json
from pathlib import Path
from analyze_btsnoop import parse, att_records, TARGET_TX

def extract(path):
    _,_,recs=parse(path)
    rows=att_records(recs)
    return [r for r in rows if r['direction']=='TX' and r['handle']==TARGET_TX and r['opcode'] in (0x52,0x12)]

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('baseline')
    ap.add_argument('action')
    ap.add_argument('--out',default='compare')
    a=ap.parse_args(); out=Path(a.out); out.mkdir(parents=True,exist_ok=True)
    b=extract(a.baseline); c=extract(a.action)
    def hx(rows): return [r['value'].hex() for r in rows]
    bs,cs=hx(b),hx(c)
    sm=difflib.SequenceMatcher(a=bs,b=cs,autojunk=False)
    lines=[]
    lines.append('# OKN DSP Controlled Capture Diff')
    lines.append('')
    lines.append(f'- Baseline: `{Path(a.baseline).name}` — {len(b)} AB01 writes')
    lines.append(f'- Action: `{Path(a.action).name}` — {len(c)} AB01 writes')
    lines.append('')
    lines.append('## Sequence diff')
    for tag,i1,i2,j1,j2 in sm.get_opcodes():
        if tag=='equal':
            continue
        lines.append(f'### {tag}: baseline[{i1}:{i2}] vs action[{j1}:{j2}]')
        for x in bs[i1:i2]: lines.append(f'- BASE  `{x}`')
        for x in cs[j1:j2]: lines.append(f'+ ACT   `{x}`')
    (out/'DIFF.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    with open(out/'aligned_diff.csv','w',newline='',encoding='utf-8') as f:
        w=csv.writer(f);w.writerow(['tag','baseline_index','action_index','baseline_hex','action_hex'])
        for tag,i1,i2,j1,j2 in sm.get_opcodes():
            n=max(i2-i1,j2-j1)
            for k in range(n):
                w.writerow([tag,i1+k if i1+k<i2 else '',j1+k if j1+k<j2 else '',bs[i1+k] if i1+k<i2 else '',cs[j1+k] if j1+k<j2 else ''])
    print(json.dumps({'baseline_writes':len(b),'action_writes':len(c),'opcodes':sm.get_opcodes()},indent=2))
if __name__=='__main__': main()
