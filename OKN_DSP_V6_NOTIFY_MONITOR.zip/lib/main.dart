import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() => runApp(const OknDspApp());

class OknDspApp extends StatelessWidget {
  const OknDspApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'OKN DSP',
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.blue),
    home: const HomePage(),
  );
}

class DeviceInfo {
  final String name, address;
  final int rssi;
  const DeviceInfo(this.name, this.address, this.rssi);
}

class _HomePageState extends State<HomePage> {
  static const methods = MethodChannel('okn_dsp/methods');
  static const events = EventChannel('okn_dsp/events');
  StreamSubscription? sub;
  final devices = <DeviceInfo>[];
  final rxLines = <String>[];
  String status = 'พร้อมค้นหา Bluetooth';
  String gatt = '';
  bool scanning = false;

  @override
  void initState() {
    super.initState();
    sub = events.receiveBroadcastStream().listen((e) {
      if (!mounted || e is! Map) return;
      final type = e['type']?.toString() ?? '';
      if (type == 'device') {
        final d = DeviceInfo(e['name']?.toString() ?? 'ไม่ทราบชื่อ',
            e['address']?.toString() ?? '', int.tryParse(e['rssi']?.toString() ?? '') ?? 0);
        setState(() { if (!devices.any((x) => x.address == d.address)) devices.add(d); });
      } else if (type == 'status') {
        setState(() => status = e['message']?.toString() ?? '');
      } else if (type == 'gatt') {
        setState(() => gatt = e['text']?.toString() ?? '');
      } else if (type == 'rx') {
        setState(() {
          rxLines.insert(0, '${e['characteristic']}: ${e['data']}');
          if (rxLines.length > 30) rxLines.removeLast();
        });
      }
    });
  }

  @override
  void dispose() { sub?.cancel(); super.dispose(); }

  Future<void> scan() async {
    setState(() { devices.clear(); gatt = ''; rxLines.clear(); status = 'กำลังค้นหา BLE...'; scanning = true; });
    try { await methods.invokeMethod('scan'); } catch (e) { setState(() => status = '$e'); }
    await Future<void>.delayed(const Duration(seconds: 8));
    if (mounted) setState(() => scanning = false);
  }

  Future<void> connect(DeviceInfo d) async {
    setState(() { status = 'กำลังเชื่อมต่อ ${d.name}...'; gatt = ''; rxLines.clear(); });
    try { await methods.invokeMethod('connect', {'address': d.address}); }
    catch (e) { setState(() => status = 'เชื่อมต่อไม่ได้: $e'); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('OKN DSP Controller V6'),
      actions: [IconButton(onPressed: scanning ? null : scan, icon: const Icon(Icons.bluetooth_searching))],
    ),
    body: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Card(child: Padding(
          padding: const EdgeInsets.all(14),
          child: Text(
            'Bluetooth ของบอร์ด\n'
            'ชื่อที่บอร์ดแสดง > ใช้สำหรับ Media / เล่นเพลง\n'
            'ชื่อที่บอร์ดแสดง > ใช้สำหรับ ควบคุม DSP\n\n$status',
            style: const TextStyle(fontSize: 16),
          ),
        )),
        if (gatt.isNotEmpty) ...[
          const SizedBox(height: 8),
          Card(child: Padding(
            padding: const EdgeInsets.all(10),
            child: SizedBox(height: 280, child: SingleChildScrollView(child: Text(gatt, style: const TextStyle(fontSize: 12)))),
          )),
        ],
        const SizedBox(height: 8),
        const Text('RX จาก Notify (อ่านอย่างเดียว)', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        Expanded(
          child: rxLines.isEmpty
            ? const Center(child: Text('ยังไม่มีข้อมูล Notify\nV6 จะรอข้อมูลจาก AB02 และ AB03'))
            : ListView(children: rxLines.map((x) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 3),
                child: SelectableText(x, style: const TextStyle(fontFamily: 'monospace')),
              )).toList()),
        ),
        const Text('🛑 V6 ไม่ส่งคำสั่งเขียนไปยัง DSP', textAlign: TextAlign.center),
      ]),
    ),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}
