# OKN Control Protocol V2

Replacement-firmware protocol. It is intentionally independent of GoloPine UFE.

Frame:
- byte 0 = 0x4F ('O')
- byte 1 = 0x4B ('K')
- byte 2 = protocol version 0x02
- byte 3 = command
- bytes 4..5 = payload length, uint16 little-endian
- payload
- final 2 bytes = CRC-16/CCITT-FALSE, little-endian

Channel index on wire: 0..6 = CH1..CH7. PEQ band index: 0..14.

Commands:
- 0x01 PING
- 0x02 GET_INFO
- 0x10 SET_MASTER_GAIN
- 0x11 SET_CH_GAIN
- 0x12 SET_CH_MUTE
- 0x13 SET_CH_PHASE
- 0x14 SET_CH_DELAY
- 0x20 SET_PEQ
- 0x21 SET_HPF
- 0x22 SET_LPF
- 0x7E ACK response
- 0x7F INFO response

V2 validates CRC and all ranges before mutating state. Bad CRC/format does not bump revision.
GET_INFO reports hardware_ready=0 until the authentic BP1048P4 hardware port is integrated.
