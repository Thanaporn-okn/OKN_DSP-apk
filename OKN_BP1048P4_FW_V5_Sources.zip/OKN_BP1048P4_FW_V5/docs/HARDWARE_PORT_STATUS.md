# BP1048P4 hardware port status — V4

V4 deliberately remains non-flashable.

Completed before hardware port:
- 7 independent output-channel control model
- 15 PEQ bands per channel
- HPF / LPF
- gain / mute / phase / delay
- portable reference DSP implementation
- versioned CRC-framed control protocol
- revision + dirty tracking
- transactional dirty apply
- deterministic persistent-state schema
- CRC32 corruption detection
- A/B storage generations + rollback
- fail-closed audio HAL
- fail-closed storage HAL

Hard gate:
Do not add startup code, linker script, memory map, debug pins, flash algorithm,
NVM page addresses, BLE stack calls, DSP effect IDs, pin mux, codec route or
clock configuration from guesses.

The hardware port opens only when authentic BP1048P4 SDK/example headers,
flash/debug tooling, or equivalent board evidence is available.
