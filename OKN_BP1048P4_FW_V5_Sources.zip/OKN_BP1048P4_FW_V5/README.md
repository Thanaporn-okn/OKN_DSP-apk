# OKN_BP1048P4_FW_V5

Clean-room replacement firmware foundation for GoloPine / BP1048P4 7CH.

V5 preserves the V4 DSP and persistence core and adds a transport-safe stream
reassembler plus explicit state readback commands for future OKN app sync.

## V5 additions
- byte-stream frame reassembly for BLE-like fragmentation
- concatenated-frame handling
- noise/corruption resynchronization
- CRC check before command dispatch
- GET_MASTER_STATE readback
- GET_CHANNEL_STATE readback
- GET_PEQ_STATE readback
- host stream-fragmentation and recovery tests

## Existing core
- 7 independent channels
- gain / mute / phase / 0-50 ms delay
- 15-band PEQ per channel
- notch / low shelf / high shelf
- HPF / LPF
- CRC-framed OKN Protocol V2
- dirty transactional apply
- portable 48 kHz reference audio engine
- deterministic state serialization
- CRC32 persistence
- A/B generation rollback
- read-after-write verification
- safe-default persistence fallback

## Hardware safety
This source is intentionally **not hardware-flashable**. No BP1048P4 MMIO,
flash page, boot packet, GPIO number, clock register, codec route, BLE SDK call,
GATT table or undocumented vendor call is guessed. Audio and storage HALs remain
fail-closed until verified BP1048P4 SDK / board evidence is available.

The stream layer is transport-independent and does not claim the GoloPine BLE
implementation.

Validation:
```sh
make verify
make test
make demo
```
