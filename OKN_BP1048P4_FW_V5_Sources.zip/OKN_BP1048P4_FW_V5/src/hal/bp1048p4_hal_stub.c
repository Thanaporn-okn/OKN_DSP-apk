#include "bp1048p4_hal.h"

static int locked_init(void) { return OKN_ERR_HAL_LOCKED; }
static int locked_audio(void) { return OKN_ERR_HAL_LOCKED; }
static int locked_master(float db) { (void)db; return OKN_ERR_HAL_LOCKED; }
static int locked_channel(unsigned channel, const okn_channel_state_t *state) {
    (void)channel; (void)state; return OKN_ERR_HAL_LOCKED;
}
static int locked_notify(const uint8_t *data, size_t len) {
    (void)data; (void)len; return OKN_ERR_HAL_LOCKED;
}

static const bp1048p4_hal_t HAL = {
    .platform_init = locked_init,
    .audio_start = locked_audio,
    .apply_master_gain = locked_master,
    .apply_channel_state = locked_channel,
    .ble_notify = locked_notify,
};

const bp1048p4_hal_t *bp1048p4_hal_get(void) { return &HAL; }
