#ifndef BP1048P4_HAL_H
#define BP1048P4_HAL_H

#include "../core/okn_dsp.h"
#include <stddef.h>
#include <stdint.h>

/* HARD SAFETY RULE:
 * No register addresses, boot packets, GPIO numbers or undocumented vendor calls
 * belong here until supported by authentic BP1048P4 SDK / board evidence. */
typedef struct {
    int (*platform_init)(void);
    int (*audio_start)(void);
    int (*apply_master_gain)(float db);
    int (*apply_channel_state)(unsigned channel, const okn_channel_state_t *state);
    int (*ble_notify)(const uint8_t *data, size_t len);
} bp1048p4_hal_t;

const bp1048p4_hal_t *bp1048p4_hal_get(void);

#endif
