#include "okn_controller.h"
#include <string.h>

void okn_controller_init(okn_controller_t *ctl) {
    if (!ctl) return;
    memset(ctl, 0, sizeof(*ctl));
    okn_dsp_init(&ctl->state);
}

void okn_controller_mark_all_dirty(okn_controller_t *ctl) {
    if (!ctl) return;
    ctl->master_dirty = true;
    ctl->channel_dirty_mask = (uint8_t)((1u << OKN_CHANNELS) - 1u);
}

void okn_controller_clear_dirty(okn_controller_t *ctl) {
    if (!ctl) return;
    ctl->master_dirty = false;
    ctl->channel_dirty_mask = 0u;
}

void okn_controller_touch_master(okn_controller_t *ctl) {
    if (!ctl) return;
    ctl->master_dirty = true;
    ++ctl->revision;
}

void okn_controller_touch_channel(okn_controller_t *ctl, unsigned channel) {
    if (!ctl || channel >= OKN_CHANNELS) return;
    ctl->channel_dirty_mask |= (uint8_t)(1u << channel);
    ++ctl->revision;
}
