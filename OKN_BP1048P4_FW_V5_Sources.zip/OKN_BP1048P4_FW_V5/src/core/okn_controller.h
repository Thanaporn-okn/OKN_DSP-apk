#ifndef OKN_CONTROLLER_H
#define OKN_CONTROLLER_H

#include "okn_dsp.h"
#include <stdbool.h>
#include <stdint.h>

typedef struct {
    okn_dsp_state_t state;
    uint32_t revision;
    bool master_dirty;
    uint8_t channel_dirty_mask;
} okn_controller_t;

void okn_controller_init(okn_controller_t *ctl);
void okn_controller_mark_all_dirty(okn_controller_t *ctl);
void okn_controller_clear_dirty(okn_controller_t *ctl);
void okn_controller_touch_master(okn_controller_t *ctl);
void okn_controller_touch_channel(okn_controller_t *ctl, unsigned channel);

#endif
