#ifndef OKN_STREAM_H
#define OKN_STREAM_H

#include "../core/okn_protocol.h"
#include <stddef.h>
#include <stdint.h>

#define OKN_PROTO_MAX_PACKET (8u + OKN_PROTO_MAX_PAYLOAD)
#define OKN_STREAM_BUFFER_CAP (OKN_PROTO_MAX_PACKET * 2u)

typedef okn_status_t (*okn_stream_frame_cb)(void *user, const uint8_t *frame, size_t len);

typedef struct {
    uint8_t buf[OKN_STREAM_BUFFER_CAP];
    size_t len;
    uint32_t frames_ok;
    uint32_t dropped_bytes;
    uint32_t crc_errors;
    uint32_t format_errors;
} okn_stream_t;

void okn_stream_init(okn_stream_t *s);
okn_status_t okn_stream_feed(okn_stream_t *s,
                             const uint8_t *data, size_t len,
                             okn_stream_frame_cb cb, void *user);

#endif
