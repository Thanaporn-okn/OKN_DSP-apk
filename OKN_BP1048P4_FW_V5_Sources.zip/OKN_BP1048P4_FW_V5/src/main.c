#include "core/okn_controller.h"
#include "runtime/okn_runtime.h"
#include "dsp/okn_audio_engine.h"
#include "hal/bp1048p4_storage.h"
#include <stdio.h>

int main(void) {
    okn_controller_t ctl;
    okn_audio_engine_t engine;
    okn_controller_init(&ctl);
    (void)okn_set_channel_gain(&ctl.state, 0, -3.0f);
    okn_controller_touch_channel(&ctl, 0);
    (void)okn_set_peq_band(&ctl.state, 0, 0, true, OKN_FILTER_PEQ, 1000.0f, 2.0f, 1.0f);
    okn_controller_touch_channel(&ctl, 0);

    printf("OKN_BP1048P4_FW_V5 host demo\n");
    printf("CH1 effective gain = %.6f\n", okn_effective_channel_linear_gain(&ctl.state, 0));
    printf("revision=%u dirtyMask=0x%02X\n", (unsigned)ctl.revision, ctl.channel_dirty_mask);
    if (okn_audio_engine_init(&engine, 48000u) == OKN_OK &&
        okn_audio_engine_prepare(&engine, &ctl.state, ctl.revision) == OKN_OK) {
        float in[OKN_CHANNELS] = {0}, out[OKN_CHANNELS] = {0};
        in[0] = 0.25f;
        okn_audio_engine_process_frame(&engine, in, out);
        printf("reference audio engine CH1 frame = %.6f\n", out[0]);
    }
    printf("HAL apply status = %d (expected locked until authentic BP1048P4 SDK port)\n",
           okn_runtime_apply_dirty(&ctl, bp1048p4_hal_get()));
    {
        uint32_t generation=0u; unsigned slot=0u;
        printf("storage save status = %d (expected locked until verified NVM API)\n",
               okn_runtime_save_verified(&ctl,bp1048p4_storage_get(),&generation,&slot));
    }
    return 0;
}
