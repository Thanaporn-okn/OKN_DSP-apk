#ifndef OKN_RUNTIME_H
#define OKN_RUNTIME_H

#include "../core/okn_controller.h"
#include "../hal/bp1048p4_hal.h"
#include "../persist/okn_persistence.h"

/* Apply only dirty state. A failed write remains dirty so callers can fail closed
 * or retry only after transport/platform health is re-established. */
okn_status_t okn_runtime_apply_dirty(okn_controller_t *ctl, const bp1048p4_hal_t *hal);

/* Boot starts from safe defaults. A valid persisted image may replace defaults.
 * Invalid/corrupt/absent storage never mutates the controller away from defaults. */
okn_status_t okn_runtime_restore_or_defaults(okn_controller_t *ctl,
                                             const okn_storage_io_t *storage,
                                             uint32_t *generation,
                                             unsigned *slot,
                                             int *restored);
okn_status_t okn_runtime_save_verified(const okn_controller_t *ctl,
                                       const okn_storage_io_t *storage,
                                       uint32_t *generation,
                                       unsigned *slot);

#endif
