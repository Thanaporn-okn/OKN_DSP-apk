#include "okn_runtime.h"

okn_status_t okn_runtime_apply_dirty(okn_controller_t *ctl, const bp1048p4_hal_t *hal) {
    if (!ctl || !hal || !hal->apply_master_gain || !hal->apply_channel_state) return OKN_ERR_ARG;
    if (okn_validate_state(&ctl->state) != OKN_OK) return OKN_ERR_RANGE;

    if (ctl->master_dirty) {
        const int rc = hal->apply_master_gain(ctl->state.master_gain_db);
        if (rc != OKN_OK) return rc == OKN_ERR_HAL_LOCKED ? OKN_ERR_HAL_LOCKED : OKN_ERR_HAL;
        ctl->master_dirty = false;
    }

    for (unsigned c = 0; c < OKN_CHANNELS; ++c) {
        const uint8_t bit = (uint8_t)(1u << c);
        if ((ctl->channel_dirty_mask & bit) == 0u) continue;
        const int rc = hal->apply_channel_state(c, &ctl->state.ch[c]);
        if (rc != OKN_OK) return rc == OKN_ERR_HAL_LOCKED ? OKN_ERR_HAL_LOCKED : OKN_ERR_HAL;
        ctl->channel_dirty_mask &= (uint8_t)~bit;
    }
    return OKN_OK;
}


okn_status_t okn_runtime_restore_or_defaults(okn_controller_t *ctl,
                                             const okn_storage_io_t *storage,
                                             uint32_t *generation,
                                             unsigned *slot,
                                             int *restored) {
    if (!ctl || !storage || !generation || !slot || !restored) return OKN_ERR_ARG;
    okn_controller_init(ctl);
    *generation=0u; *slot=0u; *restored=0;

    okn_dsp_state_t loaded;
    uint32_t g=0u; unsigned s=0u;
    const okn_status_t rc=okn_persist_load_latest(storage,&loaded,&g,&s);
    if (rc != OKN_OK) return rc;

    ctl->state=loaded;
    ctl->revision=g;
    okn_controller_mark_all_dirty(ctl);
    *generation=g; *slot=s; *restored=1;
    return OKN_OK;
}

okn_status_t okn_runtime_save_verified(const okn_controller_t *ctl,
                                       const okn_storage_io_t *storage,
                                       uint32_t *generation,
                                       unsigned *slot) {
    if (!ctl || !storage || !generation || !slot) return OKN_ERR_ARG;
    if (okn_validate_state(&ctl->state) != OKN_OK) return OKN_ERR_RANGE;
    return okn_persist_save_next(storage,&ctl->state,generation,slot);
}
