OKN_DSP V3 — DIRECT WRITE RELEASE
=================================
App: OKN_DSP
Package: com.okn.dsp
versionCode: 3
versionName: 1.0.2-v3

UI MASTER
- Home UI: exact uploaded reference image only.
- EQ UI: exact uploaded reference image only.
- No invented third visual design is added.

V3 CHANGE REQUEST APPLIED
The following V2 realtime restrictions are removed from DSP control writes:
- no app-level one-command-in-flight RealtimeCommandQueue
- no latest-target-wins DSP command coalescing
- no fixed 38 ms DSP write pacing
- no TrebleBoost <=0.5 dB / 48 ms slew limiter
- no EQ slew controller

V3 TRANSPORT BEHAVIOR
- Each verified scalar/EQ user change is submitted immediately to AB01 using WRITE_TYPE_NO_RESPONSE.
- AES-CFB8 TX state remains continuous and synchronized inside the direct write function.
- If Android rejects a write after encryption has advanced, the session fails closed and reconnect/auth is required; the app never guesses or reuses a potentially invalid cipher stream.
- Fresh device descriptor remains authoritative after reconnect. V3 does not automatically burst-replay remembered parameters after Health Gate.

VERIFIED HARDWARE SCOPE
- BLE service AB00, write AB01, notify AB02, secondary notify AB03.
- Verified Auth16 / RandKey / AES-CFB8 continuous session.
- Scalar IDs: 2,3,8,9,10,13,11.
- EQ actuators CH1..CH7: 4,5,6,14,15,16,17.
- EQ: 15 records per channel; only PEAKING type=12 is writable; each verified EQ write remains a complete 48-byte band record.
- SaveParams ID7 remains manual-only and guarded by a fresh descriptor Health Gate.

LOCKED / NOT GUESSED
- hardware Crossover writes
- hardware Delay writes
- hardware Preset recall/write protocol
- per-channel Output/Mute/Phase/routing packets
- generic/unknown actuator writes

BUILD
Use the separately delivered build-okn-dsp-v3.yml. It runs automatically when the V3 Source ZIP or V3 workflow is pushed to GitHub and also supports workflow_dispatch.
