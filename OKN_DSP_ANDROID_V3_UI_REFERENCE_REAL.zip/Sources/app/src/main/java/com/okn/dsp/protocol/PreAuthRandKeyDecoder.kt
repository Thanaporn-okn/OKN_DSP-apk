package com.okn.dsp.protocol

import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * OKN_DSP V3 pre-auth decoder using the verified target-device auth-response format.
 *
 * Auth response layout used by the reference app:
 *   0..1  TypeID (BE16)
 *   2..3  VersionID (BE16)
 *   4..7  auxiliary field (not part of the encrypted payload)
 *   8..31 24-byte AES-CFB8 ciphertext
 *
 * The 24-byte plaintext is:
 *   0..7  device unique ID
 *   8..23 RandKey (16 bytes)
 *
 * IV is 0x01 repeated 16 bytes. TypeID 53285 uses the alternate fixed key;
 * all other types follow the default branch seen in the recovered call site.
 */
data class PreAuthDecoded(
    val typeId: Int,
    val versionId: Int,
    val field4to7: ByteArray,
    val uniqueId: ByteArray,
    val randKey: ByteArray,
)

object PreAuthRandKeyDecoder {
    private val DEFAULT_KEY = ByteCodec.hexToBytes("2AAF948632A59FF8F2B23E6E4193FD21")
    private val TYPE_53285_KEY = ByteCodec.hexToBytes("10E7D2F443924938A28D759BAC0E9E22")
    private val IV = ByteArray(16) { 0x01 }

    fun decode(response32: ByteArray): PreAuthDecoded {
        require(response32.size == 32) { "authentication response must be 32 bytes" }
        val typeId = ByteCodec.readU16be(response32, 0)
        val versionId = ByteCodec.readU16be(response32, 2)
        val fixedKey = if (typeId == 53285) TYPE_53285_KEY else DEFAULT_KEY
        val cipher = Cipher.getInstance("AES/CFB8/NoPadding").apply {
            init(Cipher.DECRYPT_MODE, SecretKeySpec(fixedKey, "AES"), IvParameterSpec(IV))
        }
        val plain24 = cipher.update(response32.copyOfRange(8, 32)) ?: byteArrayOf()
        require(plain24.size == 24) { "pre-auth plaintext must be 24 bytes" }
        return PreAuthDecoded(
            typeId = typeId,
            versionId = versionId,
            field4to7 = response32.copyOfRange(4, 8),
            uniqueId = plain24.copyOfRange(0, 8),
            randKey = plain24.copyOfRange(8, 24),
        )
    }
}
