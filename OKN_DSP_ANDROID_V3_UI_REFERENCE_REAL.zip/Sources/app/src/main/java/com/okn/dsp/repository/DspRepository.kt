package com.okn.dsp.repository

import android.bluetooth.BluetoothDevice
import android.content.Context
import android.os.Handler
import android.os.Looper
import com.okn.dsp.ble.BleDspManager
import com.okn.dsp.logging.DspLogger
import com.okn.dsp.error.DspErrorHandler
import com.okn.dsp.persistence.DspPreferences
import com.okn.dsp.protocol.EqBand48
import com.okn.dsp.protocol.LiveEqPolicy
import com.okn.dsp.protocol.SaveParamsPolicy
import com.okn.dsp.protocol.UfeCodec
import com.okn.dsp.protocol.VerifiedScalarControls
import com.okn.dsp.state.ConnectionState
import com.okn.dsp.state.DeviceInfo
import com.okn.dsp.state.DspState
import com.okn.dsp.state.DspStateStore
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Repository boundary between UI state and verified hardware I/O.
 * Generic/unknown writes are impossible here: only verified scalar IDs, safe PEAKING records,
 * and the exact manual SaveParams trigger have public write paths.
 */
class DspRepository(
    private val context: Context,
    val store: DspStateStore,
    val logger: DspLogger,
    private val prefs: DspPreferences,
) : BleDspManager.Listener {

    var onDeviceFound: ((BluetoothDevice, String, Int) -> Unit)? = null
    var onToast: ((String) -> Unit)? = null
    var onSaveFinished: ((Boolean, String) -> Unit)? = null

    private val main = Handler(Looper.getMainLooper())
    private val ble = BleDspManager(context, logger, this)
    private val restoring = AtomicBoolean(false)
    private var local = prefs.load()
    private var manualDisconnectRequested = false
    private var reconnectAttempt = 0
    private var reconnectRunnable: Runnable? = null


    init {
        store.update { s ->
            var next = s.copy(
                selectedChannel = local.selectedChannel,
                selectedEqBand = local.selectedBand,
                linkAllEq = local.linkAll,
            )
            if (local.scalars.isNotEmpty()) next = next.copy(scalars = local.scalars)
            if (local.eq.isNotEmpty()) {
                val rows = next.eq.map { it.toMutableList() }.toMutableList()
                local.eq.forEach { (k, v) -> rows[k.first - 1][k.second - 1] = v }
                next = next.copy(eq = rows.map { it.toList() })
            }
            next
        }
    }

    fun startScan() = ble.startScan()
    fun stopScan() = ble.stopScan()

    fun connect(device: BluetoothDevice, name: String) {
        manualDisconnectRequested = false
        reconnectAttempt = 0
        cancelReconnect()
        prefs.saveLastDevice(device.address, name)
        store.update { it.copy(device = it.device.copy(bluetoothName = name, address = device.address), lastError = null) }
        ble.connect(device, reconnect = false)
    }

    fun reconnectLast(): Boolean {
        manualDisconnectRequested = false
        val address = prefs.load().lastAddress ?: return false
        val adapter = context.getSystemService(android.bluetooth.BluetoothManager::class.java)?.adapter ?: return false
        return runCatching {
            val d = adapter.getRemoteDevice(address)
            store.update { it.copy(device = it.device.copy(bluetoothName = prefs.load().lastName, address = address)) }
            ble.connect(d, reconnect = true)
            true
        }.getOrDefault(false)
    }

    fun disconnect() {
        manualDisconnectRequested = true
        reconnectAttempt = 0
        cancelReconnect()
        ble.disconnect()
    }

    fun refresh(): Boolean = ble.refreshDescriptor(BleDspManager.DescriptorMode.REFRESH)

    fun setScalar(id: Int, requested: Float, source: String = "ui") {
        val value = VerifiedScalarControls.sanitize(id, requested) ?: return
        store.setScalar(id, value, dirty = true)
        prefs.schedule(store.value())
        local = local.copy(scalars = local.scalars.toMutableMap().apply { put(id, value) })
        logger.log("PARAMETER", "local scalar id=$id value=$value source=$source")
        if (!store.value().healthGatePass || store.value().saveInFlight) return
        val plain = UfeCodec.encodeFloat32Write(id, value)
        ble.sendRealtime("S:$id", plain, "SCALAR id=$id value=$value")
    }

    fun setEq(channel1: Int, band1: Int, frequency: Float, q: Float, boostDb: Float, source: String = "ui") {
        val state = store.value()
        val current = state.eq.getOrNull(channel1 - 1)?.getOrNull(band1 - 1) ?: return
        if (!LiveEqPolicy.isWritable(current)) return
        val target = runCatching { LiveEqPolicy.targetFromParameters(current, frequency, q, boostDb) }.getOrNull() ?: return
        applyLocalEq(channel1, band1, target)
        local = local.copy(eq = local.eq.toMutableMap().apply { put(channel1 to band1, target) })
        logger.log("PARAMETER", "local EQ ch=$channel1 band=$band1 F=${target.frequency} Q=${target.q} B=${target.boostDb} source=$source")
        if (store.value().healthGatePass && !store.value().saveInFlight) {
            val plain = LiveEqPolicy.encodeWrite(channel1, band1, target)
            ble.sendRealtime("E:$channel1:$band1", plain, "EQ ch=$channel1 band=$band1 F=${target.frequency} Q=${target.q} B=${target.boostDb}")
        }

        if (state.linkAllEq) {
            for (ch in 1..7) {
                if (ch == channel1) continue
                val other = store.value().eq[ch - 1][band1 - 1] ?: continue
                if (!LiveEqPolicy.isWritable(other)) continue
                val mirrored = runCatching { LiveEqPolicy.targetFromParameters(other, target.frequency, target.q, target.boostDb) }.getOrNull() ?: continue
                applyLocalEq(ch, band1, mirrored)
                local = local.copy(eq = local.eq.toMutableMap().apply { put(ch to band1, mirrored) })
                if (store.value().healthGatePass && !store.value().saveInFlight) {
                    val plain = LiveEqPolicy.encodeWrite(ch, band1, mirrored)
                    ble.sendRealtime("E:$ch:$band1", plain, "EQ ch=$ch band=$band1 F=${mirrored.frequency} Q=${mirrored.q} B=${mirrored.boostDb}")
                }
            }
        }
        prefs.schedule(store.value())
    }

    fun selectChannel(ch: Int) { store.selectChannel(ch); local = local.copy(selectedChannel = ch.coerceIn(1,7)); prefs.schedule(store.value()) }
    fun selectBand(band: Int) { store.selectBand(band); local = local.copy(selectedBand = band.coerceIn(1,15)); prefs.schedule(store.value()) }
    fun setLinkAll(enabled: Boolean) { store.setLinkAll(enabled); local = local.copy(linkAll = enabled); prefs.schedule(store.value()) }

    /** Manual-only guarded persistent save. Never called from sliders, reconnect, background, or persistence. */
    fun saveParamsManual(): Boolean {
        val s = store.value()
        if (!s.healthGatePass || s.saveInFlight || ble.isDescriptorBusy()) return false
        store.update { it.copy(saveInFlight = true) }
        logger.log("PARAMETER", "SaveParams manual requested exact=${com.okn.dsp.protocol.ByteCodec.run { SaveParamsPolicy.encodeTrigger().toHex() }}")
        // Re-read immediately before permanent save. The user action remains the only trigger.
        val ok = ble.refreshDescriptor(BleDspManager.DescriptorMode.SAVE_PRECHECK)
        if (!ok) store.update { it.copy(saveInFlight = false) }
        return ok
    }

    fun flushLocal() = prefs.flush()
    fun logSnapshot(): String = logger.snapshot(500)

    override fun onConnection(state: ConnectionState, message: String) {
        store.update { s ->
            s.copy(
                connection = state,
                connectionMessage = message,
                connectionEpoch = ble.currentEpoch(),
                healthGatePass = if (state == ConnectionState.READY) s.healthGatePass else false,
                protocolIdle = if (state == ConnectionState.READY) s.protocolIdle else false,
                lastError = if (state == ConnectionState.FAILED) message else s.lastError,
            )
        }
        if (state == ConnectionState.READY) {
            reconnectAttempt = 0
            cancelReconnect()
        }
        if (state == ConnectionState.DISCONNECTED || state == ConnectionState.FAILED) {
            restoring.set(false)
            if (!manualDisconnectRequested) scheduleReconnect()
        }
    }

    override fun onDeviceFound(device: BluetoothDevice, name: String, rssi: Int) = onDeviceFound?.invoke(device, name, rssi) ?: Unit

    override fun onAuthInfo(typeId: Int, versionId: Int) {
        store.update { s -> s.copy(device = s.device.copy(typeId = typeId, versionId = versionId)) }
    }

    override fun onDeviceDescription(mode: BleDspManager.DescriptorMode, json: JSONObject) {
        store.update { it.copy(connection = ConnectionState.READING_DSP_STATE, connectionMessage = "Reading DSP State", connectionEpoch = ble.currentEpoch()) }
        val parsed = DeviceDescriptionParser.parse(json)
        val scalarOk = parsed.scalars.size == 7 && parsed.scalars.keys == setOf(2, 3, 8, 9, 10, 13, 11)
        val eqCount = parsed.eq.sumOf { row -> row.count { it != null } }
        val sensorOk = parsed.sensors.size == 4
        val pass = scalarOk && eqCount == 105 && sensorOk
        logger.log("PARAMETER", "descriptor mode=$mode scalars=${parsed.scalars.size}/7 eq=$eqCount/105 writablePeak=${parsed.writablePeakingCount} sensors=${parsed.sensors.size}/4 health=$pass")

        store.update { s ->
            s.copy(
                scalars = parsed.scalars,
                eq = parsed.eq,
                sensors = parsed.sensors,
                healthGatePass = pass,
                connection = if (pass) ConnectionState.READY else ConnectionState.FAILED,
                connectionMessage = if (pass) "READY" else "Health Gate Blocked",
                connectionEpoch = ble.currentEpoch(),
                device = s.device.copy(firmwareText = parsed.firmwareText),
                protocolIdle = true,
                lastError = if (pass) null else "Descriptor incomplete",
            )
        }

        when (mode) {
            BleDspManager.DescriptorMode.INITIAL -> if (pass) restoreLocalAfterHealthGate(parsed)
            BleDspManager.DescriptorMode.REFRESH -> Unit
            BleDspManager.DescriptorMode.SAVE_PRECHECK -> {
                if (!pass) finishSave(false, "Save blocked: fresh Health Gate failed")
                else sendManualSaveTrigger()
            }
            BleDspManager.DescriptorMode.SAVE_POSTCHECK -> finishSave(pass, if (pass) "SaveParams completed" else "Save post-check failed")
        }
    }

    override fun onWriteSent(total: Long) {
        // V3 has no app-level command queue; this compatibility flag only reflects descriptor activity.
        store.update { it.copy(writesSent = total, protocolIdle = !ble.isDescriptorBusy()) }
    }

    override fun onFatalError(message: String) {
        val display = DspErrorHandler.classify(message)
        store.update { it.copy(lastError = "${display.title}: ${display.recovery}", healthGatePass = false, saveInFlight = false) }
        onToast?.invoke(display.title)
    }

    private fun cancelReconnect() {
        reconnectRunnable?.let(main::removeCallbacks)
        reconnectRunnable = null
    }

    private fun scheduleReconnect() {
        if (manualDisconnectRequested || reconnectRunnable != null || prefs.load().lastAddress == null) return
        val delayMs = (1_000L * (reconnectAttempt + 1)).coerceAtMost(5_000L)
        reconnectRunnable = Runnable {
            reconnectRunnable = null
            if (manualDisconnectRequested) return@Runnable
            reconnectAttempt += 1
            logger.log("CONNECT", "automatic reconnect attempt=$reconnectAttempt delayMs=$delayMs")
            if (!reconnectLast()) scheduleReconnect()
        }.also { main.postDelayed(it, delayMs) }
    }

    private fun applyLocalEq(ch: Int, band: Int, target: EqBand48) {
        store.setEqBand(ch, band, target, dirty = true)
    }

    private fun restoreLocalAfterHealthGate(parsed: ParsedDescriptor) {
        if (!restoring.compareAndSet(false, true)) return
        // V3 deliberately does not auto-replay remembered values after reconnect.
        // The fresh DSP descriptor is authoritative until the user changes a control or explicitly loads a preset.
        val remembered = local
        local = DspPreferences.Snapshot(
            parsed.scalars,
            buildMap {
                for (ch in 1..7) for (band in 1..15) {
                    parsed.eq[ch - 1][band - 1]?.let { if (LiveEqPolicy.isWritable(it)) put(ch to band, it) }
                }
            },
            store.value().selectedChannel,
            store.value().selectedEqBand,
            store.value().linkAllEq,
            remembered.lastAddress,
            remembered.lastName,
        )
        prefs.schedule(store.value(), 0L)
        restoring.set(false)
    }

    private fun sendManualSaveTrigger() {
        val plain = SaveParamsPolicy.encodeTrigger()
        if (!SaveParamsPolicy.triggerIsExact()) { finishSave(false, "Save trigger self-check failed"); return }
        val accepted = ble.sendCritical("SAVE:ID7", plain, "SaveParams ID7 MANUAL") { ok ->
            main.post {
                if (!ok) finishSave(false, "SaveParams GATT failed")
                else {
                    // Give nonvolatile commit time before the post-check descriptor read.
                    main.postDelayed({
                        if (!ble.refreshDescriptor(BleDspManager.DescriptorMode.SAVE_POSTCHECK)) finishSave(false, "Save post-check could not start")
                    }, 5000L)
                }
            }
        }
        if (!accepted) finishSave(false, "Save blocked: protocol busy")
    }

    private fun finishSave(ok: Boolean, message: String) {
        store.update { it.copy(saveInFlight = false, dirtyLocal = if (ok) false else it.dirtyLocal) }
        logger.log("PARAMETER", "SaveParams result ok=$ok message=$message")
        onSaveFinished?.invoke(ok, message)
    }
}
