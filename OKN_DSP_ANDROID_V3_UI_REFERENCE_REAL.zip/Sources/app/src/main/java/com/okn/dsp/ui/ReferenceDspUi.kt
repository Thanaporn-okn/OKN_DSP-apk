package com.okn.dsp.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import com.okn.dsp.R
import com.okn.dsp.protocol.EqBand48
import com.okn.dsp.protocol.EqBandCodec
import com.okn.dsp.protocol.LiveEqPolicy
import com.okn.dsp.protocol.VerifiedScalarControls
import com.okn.dsp.state.ConnectionState
import com.okn.dsp.state.DspState
import com.okn.dsp.state.DspStateStore
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin

interface DspUiActions {
    fun scanConnect()
    fun showMainMenu()
    fun scalarChanged(id: Int, value: Float)
    fun toggleMasterMute()
    fun channelSelected(channel: Int)
    fun bandSelected(band: Int)
    fun eqChanged(channel: Int, band: Int, frequency: Float, q: Float, gain: Float)
    fun resetGlobal()
    fun savePreset()
    fun loadPreset()
    fun flatEq()
    fun copyEq()
    fun pasteEq()
    fun reconnect()
    fun disconnect()
    fun refresh()
    fun saveParams()
    fun showLogs()
    fun showUnavailable(label: String)
}

data class UiSnapshot(val tab: Int = 0, val parametricMode: Boolean = false)

/**
 * OKN_DSP V3 user-reference UI.
 *
 * Important: the two user supplied PNGs are the only visual master references.
 * They are rendered directly as the screen background. Dynamic, verified controls
 * are then redrawn only where state must be live (BLE status, scalar sliders,
 * EQ graph/values/channel selection). No third screen is invented.
 */
class ReferenceDspUi(
    private val context: Context,
    private val store: DspStateStore,
    private val actions: DspUiActions,
    initial: UiSnapshot = UiSnapshot(),
) {
    val view: View
    private val host = FrameLayout(context).apply { setBackgroundColor(Color.rgb(1, 10, 17)) }
    private var tab = initial.tab.coerceIn(0, 1)
    private var state = store.value()
    private var unsubscribe: (() -> Unit)? = null
    private var screen: ReferenceCanvasView? = null

    init {
        view = host
        show(tab)
        unsubscribe = store.subscribe { s ->
            state = s
            screen?.bind(s)
        }
    }

    fun dispose() { unsubscribe?.invoke(); unsubscribe = null }
    fun snapshot(): UiSnapshot = UiSnapshot(tab = tab, parametricMode = false)
    fun setPresetLabel(name: String) = Unit

    private fun show(index: Int) {
        tab = index.coerceIn(0, 1)
        val next = if (tab == 0) {
            HomeReferenceView(context, actions, ::navigate)
        } else {
            EqReferenceView(context, actions, ::navigate)
        }
        screen = next
        host.removeAllViews()
        host.addView(next, FrameLayout.LayoutParams(-1, -1))
        next.bind(state)
    }

    private fun navigate(target: Int) {
        when (target) {
            0, 1 -> if (target != tab) show(target)
            2 -> actions.showUnavailable("Crossover: ยังไม่มีหน้า UI อ้างอิงและคำสั่งเขียนฮาร์ดแวร์ยังไม่ยืนยัน")
            3 -> actions.showUnavailable("Delay: ยังไม่มีหน้า UI อ้างอิงและคำสั่งเขียนฮาร์ดแวร์ยังไม่ยืนยัน")
            4 -> actions.showMainMenu()
        }
    }
}

private abstract class ReferenceCanvasView(
    context: Context,
    drawableId: Int,
) : View(context) {
    protected var state: DspState = DspState()
    private val bitmap: Bitmap = BitmapFactory.decodeResource(resources, drawableId)
    protected val p = Paint(Paint.ANTI_ALIAS_FLAG)
    protected val path = Path()
    protected val designW = bitmap.width.toFloat()
    protected val designH = bitmap.height.toFloat()

    init {
        isSoundEffectsEnabled = false
        isHapticFeedbackEnabled = false
        setBackgroundColor(Color.rgb(1, 10, 17))
    }

    fun bind(s: DspState) {
        state = s
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawBitmap(bitmap, null, RectF(0f, 0f, width.toFloat(), height.toFloat()), p)
        if (width <= 0 || height <= 0) return
        canvas.save()
        canvas.scale(width / designW, height / designH)
        drawDynamic(canvas)
        canvas.restore()
    }

    protected abstract fun drawDynamic(c: Canvas)

    protected fun dx(x: Float) = x * designW / width.coerceAtLeast(1)
    protected fun dy(y: Float) = y * designH / height.coerceAtLeast(1)

    protected fun roundRect(c: Canvas, rect: RectF, radius: Float, fill: Int, stroke: Int? = null, strokeWidth: Float = 1f) {
        p.style = Paint.Style.FILL
        p.color = fill
        p.shader = null
        c.drawRoundRect(rect, radius, radius, p)
        if (stroke != null) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = strokeWidth
            p.color = stroke
            c.drawRoundRect(rect, radius, radius, p)
            p.style = Paint.Style.FILL
        }
    }

    protected fun text(
        c: Canvas,
        value: String,
        x: Float,
        y: Float,
        size: Float,
        color: Int = Color.WHITE,
        align: Paint.Align = Paint.Align.LEFT,
        bold: Boolean = false,
    ) {
        p.shader = null
        p.style = Paint.Style.FILL
        p.color = color
        p.textSize = size
        p.textAlign = align
        p.typeface = if (bold) android.graphics.Typeface.create("sans", android.graphics.Typeface.BOLD) else android.graphics.Typeface.create("sans", android.graphics.Typeface.NORMAL)
        c.drawText(value, x, y, p)
    }

    protected fun drawConnection(c: Canvas) {
        // Cover the reference placeholder connection block and redraw real BLE state.
        p.style = Paint.Style.FILL
        p.color = Color.rgb(1, 15, 25)
        c.drawRect(15f, 18f, 242f, 105f, p)
        val connected = state.connection == ConnectionState.READY && state.healthGatePass
        val dot = when {
            connected -> Color.rgb(27, 240, 120)
            state.connection == ConnectionState.FAILED -> Color.rgb(255, 82, 103)
            state.connection == ConnectionState.DISCONNECTED -> Color.rgb(90, 116, 140)
            else -> Color.rgb(0, 195, 255)
        }
        p.color = dot
        c.drawCircle(35f, 54f, 12f, p)
        val title = when (state.connection) {
            ConnectionState.SCANNING -> "กำลังค้นหา"
            ConnectionState.CONNECTING, ConnectionState.RECONNECTING -> "กำลังเชื่อมต่อ"
            ConnectionState.DISCOVERING, ConnectionState.ENABLING_NOTIFICATIONS -> "กำลังตั้งค่า"
            ConnectionState.AUTHENTICATING, ConnectionState.ESTABLISHING_SESSION -> "กำลังยืนยัน"
            ConnectionState.READING_DEVICE_DESCRIPTION, ConnectionState.READING_DSP_STATE -> "กำลังอ่าน DSP"
            ConnectionState.READY -> if (state.healthGatePass) "เชื่อมต่อแล้ว" else "กำลังตรวจสอบ"
            ConnectionState.FAILED -> "เชื่อมต่อล้มเหลว"
            else -> "ยังไม่เชื่อมต่อ"
        }
        text(c, title, 67f, 56f, 23f, if (connected) Color.rgb(34, 238, 128) else Color.rgb(150, 190, 218), bold = true)
        val name = state.device.bluetoothName?.takeIf { it.isNotBlank() } ?: "OKN-DSP_7CH"
        text(c, name, 67f, 88f, 18f, Color.rgb(149, 182, 213))
        text(c, "›", 214f, 86f, 34f, Color.rgb(153, 190, 222), bold = true)
    }
}

private class HomeReferenceView(
    context: Context,
    private val actions: DspUiActions,
    private val navigate: (Int) -> Unit,
) : ReferenceCanvasView(context, R.drawable.okn_home_reference) {
    private val ids = intArrayOf(2, 8, 9, 10, 13, 11)
    private val yCenters = floatArrayOf(190f, 335f, 479f, 627f, 774f, 919f)
    private val fills = intArrayOf(
        Color.rgb(16, 153, 255),
        Color.rgb(0, 211, 238),
        Color.rgb(220, 36, 243),
        Color.rgb(255, 42, 119),
        Color.rgb(0, 173, 255),
        Color.rgb(207, 48, 245),
    )
    private var draggingId = -1

    override fun drawDynamic(c: Canvas) {
        drawConnection(c)
        ids.forEachIndexed { i, id -> drawScalar(c, id, yCenters[i], fills[i]) }
    }

    private fun drawScalar(c: Canvas, id: Int, cy: Float, fill: Int) {
        val ctrl = VerifiedScalarControls.byId(id) ?: return
        val value = state.scalars[id]
        // Cover only the live track/thumb/value areas; titles/icons stay 100% from the reference PNG.
        p.style = Paint.Style.FILL
        p.color = Color.rgb(5, 28, 43)
        c.drawRoundRect(RectF(335f, cy - 17f, 618f, cy + 18f), 15f, 15f, p)
        val left = 346f
        val right = 610f
        val t = if (value == null) 0f else ((value - ctrl.min) / (ctrl.max - ctrl.min)).coerceIn(0f, 1f)
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 14f
        p.color = Color.rgb(48, 80, 111)
        c.drawLine(left, cy, right, cy, p)
        if (value != null) {
            p.shader = LinearGradient(left, cy, right, cy, fill, Color.rgb(93, 225, 255), Shader.TileMode.CLAMP)
            c.drawLine(left, cy, left + (right - left) * t, cy, p)
            p.shader = null
            p.style = Paint.Style.FILL
            p.color = Color.WHITE
            p.setShadowLayer(12f, 0f, 0f, Color.argb(180, 80, 210, 255))
            c.drawCircle(left + (right - left) * t, cy, 18f, p)
            p.clearShadowLayer()
        }
        p.strokeCap = Paint.Cap.BUTT

        // Keep the value frame from the supplied UI, but replace the placeholder value with live DSP data.
        p.style = Paint.Style.FILL
        p.color = Color.rgb(5, 24, 39)
        c.drawRoundRect(RectF(650f, cy - 27f, 739f, cy + 27f), 10f, 10f, p)
        val label = when {
            value == null -> "--"
            id == 9 -> String.format(Locale.US, "%.0f Hz", value)
            else -> String.format(Locale.US, "%.1f dB", value)
        }
        text(c, label, 694f, cy + 8f, 22f, Color.rgb(238, 246, 255), Paint.Align.CENTER)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = dx(event.x)
        val y = dy(event.y)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                // Real scalar sliders.
                val hit = yCenters.indices.firstOrNull { abs(y - yCenters[it]) <= 38f && x in 322f..632f }
                if (hit != null) {
                    draggingId = ids[hit]
                    parent?.requestDisallowInterceptTouchEvent(true)
                    updateSlider(draggingId, x)
                    return true
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (draggingId > 0) {
                    updateSlider(draggingId, x)
                    return true
                }
            }
            MotionEvent.ACTION_UP -> {
                if (draggingId > 0) {
                    draggingId = -1
                    parent?.requestDisallowInterceptTouchEvent(false)
                    performClick()
                    return true
                }
                when {
                    x in 10f..245f && y in 10f..115f -> actions.scanConnect()
                    x in 670f..786f && y in 15f..115f -> actions.showMainMenu()
                    x in 20f..200f && y in 1120f..1235f -> actions.flatEq()
                    x in 200f..390f && y in 1120f..1235f -> actions.showUnavailable("Pop: ยังไม่มีค่าพรีเซ็ตฮาร์ดแวร์ที่ยืนยัน")
                    x in 390f..580f && y in 1120f..1235f -> actions.showUnavailable("Rock: ยังไม่มีค่าพรีเซ็ตฮาร์ดแวร์ที่ยืนยัน")
                    x in 580f..780f && y in 1120f..1235f -> actions.showUnavailable("Jazz: ยังไม่มีค่าพรีเซ็ตฮาร์ดแวร์ที่ยืนยัน")
                    x in 20f..390f && y in 1235f..1360f -> actions.savePreset()
                    x in 390f..780f && y in 1235f..1360f -> actions.loadPreset()
                    y >= 1380f && x < designW * .20f -> navigate(0)
                    y >= 1380f && x < designW * .40f -> navigate(1)
                    y >= 1380f && x < designW * .60f -> navigate(2)
                    y >= 1380f && x < designW * .80f -> navigate(3)
                    y >= 1380f -> navigate(4)
                }
                performClick()
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                draggingId = -1
                parent?.requestDisallowInterceptTouchEvent(false)
                return true
            }
        }
        return true
    }

    private fun updateSlider(id: Int, x: Float) {
        val ctrl = VerifiedScalarControls.byId(id) ?: return
        val t = ((x - 346f) / (610f - 346f)).coerceIn(0f, 1f)
        var v = ctrl.min + (ctrl.max - ctrl.min) * t
        v = if (id == 9) v.roundToInt().toFloat() else (v * 10f).roundToInt() / 10f
        actions.scalarChanged(id, v)
    }

    override fun performClick(): Boolean = super.performClick()
}

private class EqReferenceView(
    context: Context,
    private val actions: DspUiActions,
    private val navigate: (Int) -> Unit,
) : ReferenceCanvasView(context, R.drawable.okn_eq_reference) {
    private val pointColors = intArrayOf(
        Color.rgb(255, 70, 76),
        Color.rgb(255, 194, 63),
        Color.rgb(55, 227, 89),
        Color.rgb(35, 193, 230),
        Color.rgb(160, 70, 239),
        Color.rgb(247, 104, 184),
    )
    private var draggingBand = -1

    override fun drawDynamic(c: Canvas) {
        drawConnection(c)
        drawChannelSelector(c)
        drawGraph(c)
        drawBandCards(c)
        drawChannelButtons(c)
    }

    private fun visibleBands(): List<Pair<Int, EqBand48>> {
        val rows = state.eq.getOrNull(state.selectedChannel - 1) ?: return emptyList()
        return rows.mapIndexedNotNull { i, b -> if (b != null && LiveEqPolicy.isWritable(b)) (i + 1) to b else null }.take(6)
    }

    private fun channelLabel(ch: Int): String = when (ch) {
        1 -> "CH 1 : Front Left"
        2 -> "CH 2 : Front Right"
        3 -> "CH 3 : Rear Left"
        4 -> "CH 4 : Rear Right"
        5 -> "CH 5 : Center"
        6 -> "CH 6 : Subwoofer"
        else -> "CH 7 : AUX"
    }

    private fun drawChannelSelector(c: Canvas) {
        roundRect(c, RectF(317f, 138f, 620f, 195f), 12f, Color.rgb(5, 22, 36), Color.rgb(31, 63, 96), 2f)
        text(c, channelLabel(state.selectedChannel), 335f, 177f, 22f, Color.rgb(238, 246, 255))
        p.color = Color.rgb(37, 64, 94)
        p.strokeWidth = 2f
        c.drawLine(528f, 139f, 528f, 194f, p)
        c.drawLine(575f, 139f, 575f, 194f, p)
        text(c, "‹", 551f, 180f, 37f, Color.rgb(177, 205, 244), Paint.Align.CENTER)
        text(c, "›", 598f, 180f, 37f, Color.rgb(177, 205, 244), Paint.Align.CENTER)
    }

    private fun drawGraph(c: Canvas) {
        val left = 80f
        val top = 226f
        val right = 770f
        val bottom = 541f
        roundRect(c, RectF(left, top, right, bottom), 10f, Color.rgb(3, 21, 31), Color.rgb(42, 83, 116), 2f)

        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f
        p.color = Color.rgb(17, 48, 67)
        val gains = floatArrayOf(12f, 6f, 0f, -6f, -12f)
        gains.forEach { g ->
            val y = gainToY(g, top, bottom)
            c.drawLine(left, y, right, y, p)
        }
        val freqs = floatArrayOf(20f, 50f, 100f, 200f, 500f, 1000f, 2000f, 5000f, 10000f, 20000f)
        freqs.forEach { f ->
            val x = freqToX(f, left, right)
            c.drawLine(x, top, x, bottom, p)
            val next = f * 2f
            if (next < 20000f) {
                val mx = freqToX(next.coerceAtMost(20000f), left, right)
                p.color = Color.rgb(11, 37, 54)
                c.drawLine(mx, top, mx, bottom, p)
                p.color = Color.rgb(17, 48, 67)
            }
        }

        val all = state.eq.getOrNull(state.selectedChannel - 1)?.filterNotNull().orEmpty()
        if (all.isNotEmpty()) {
            path.reset()
            val fillPath = Path()
            val samples = 220
            for (i in 0 until samples) {
                val t = i / (samples - 1f)
                val f = 20.0 * 1000.0.pow(t.toDouble())
                val db = all.sumOf { biquadDb(it, f) }.coerceIn(-12.0, 12.0).toFloat()
                val x = left + (right - left) * t
                val y = gainToY(db, top, bottom)
                if (i == 0) {
                    path.moveTo(x, y)
                    fillPath.moveTo(x, bottom)
                    fillPath.lineTo(x, y)
                } else {
                    path.lineTo(x, y)
                    fillPath.lineTo(x, y)
                }
            }
            fillPath.lineTo(right, bottom)
            fillPath.close()
            p.style = Paint.Style.FILL
            p.shader = LinearGradient(0f, top, 0f, bottom, Color.argb(115, 0, 126, 255), Color.argb(8, 0, 126, 255), Shader.TileMode.CLAMP)
            c.drawPath(fillPath, p)
            p.shader = null
            p.style = Paint.Style.STROKE
            p.strokeWidth = 4f
            p.color = Color.rgb(0, 137, 255)
            p.setShadowLayer(9f, 0f, 0f, Color.argb(190, 0, 125, 255))
            c.drawPath(path, p)
            p.clearShadowLayer()
        }

        val visible = visibleBands()
        visible.forEachIndexed { slot, (_, b) ->
            val x = freqToX(b.frequency.coerceIn(20f, 20000f), left, right)
            val y = gainToY(b.boostDb.coerceIn(-12f, 12f), top, bottom)
            p.style = Paint.Style.FILL
            p.color = pointColors[slot]
            p.setShadowLayer(12f, 0f, 0f, pointColors[slot])
            c.drawCircle(x, y, 11f, p)
            p.clearShadowLayer()
            p.style = Paint.Style.STROKE
            p.strokeWidth = 3f
            p.color = Color.WHITE
            c.drawCircle(x, y, 12f, p)
        }
        p.style = Paint.Style.FILL
    }

    private fun drawBandCards(c: Canvas) {
        roundRect(c, RectF(17f, 620f, 782f, 892f), 16f, Color.rgb(4, 23, 34), Color.rgb(21, 52, 75), 2f)
        text(c, "Freq", 29f, 722f, 20f, Color.rgb(199, 221, 242))
        text(c, "Gain", 29f, 770f, 20f, Color.rgb(199, 221, 242))
        text(c, "Q", 29f, 817f, 20f, Color.rgb(199, 221, 242))

        val visible = visibleBands()
        val start = 77f
        val step = 116.5f
        val width = 108f
        for (slot in 0 until 6) {
            val x0 = start + slot * step
            val activeBand = visible.getOrNull(slot)?.first
            val selected = activeBand != null && activeBand == state.selectedEqBand
            val border = if (selected) Color.rgb(0, 190, 255) else Color.rgb(30, 60, 83)
            roundRect(c, RectF(x0, 628f, x0 + width, 880f), 12f, Color.rgb(4, 20, 31), border, if (selected) 3f else 1.5f)
            if (selected) {
                p.style = Paint.Style.STROKE
                p.strokeWidth = 5f
                p.color = Color.argb(100, 0, 195, 255)
                c.drawRoundRect(RectF(x0 - 2f, 626f, x0 + width + 2f, 882f), 14f, 14f, p)
                p.style = Paint.Style.FILL
            }
            p.color = pointColors[slot]
            c.drawCircle(x0 + 27f, 659f, 12f, p)
            text(c, (slot + 1).toString(), x0 + 59f, 667f, 19f, Color.rgb(229, 239, 249), Paint.Align.CENTER)
            val entry = visible.getOrNull(slot)?.second
            if (entry != null) {
                text(c, freqLabel(entry.frequency), x0 + width / 2f, 727f, 18f, Color.rgb(234, 242, 251), Paint.Align.CENTER)
                text(c, String.format(Locale.US, "%.1f dB", entry.boostDb), x0 + width / 2f, 774f, 18f, Color.rgb(234, 242, 251), Paint.Align.CENTER)
                text(c, String.format(Locale.US, "%.1f", entry.q), x0 + width / 2f, 821f, 18f, Color.rgb(234, 242, 251), Paint.Align.CENTER)
            } else {
                text(c, "--", x0 + width / 2f, 727f, 18f, Color.rgb(120, 146, 171), Paint.Align.CENTER)
                text(c, "--", x0 + width / 2f, 774f, 18f, Color.rgb(120, 146, 171), Paint.Align.CENTER)
                text(c, "--", x0 + width / 2f, 821f, 18f, Color.rgb(120, 146, 171), Paint.Align.CENTER)
            }
            drawBell(c, x0 + width / 2f, 853f, Color.rgb(239, 246, 253))
        }
    }

    private fun drawBell(c: Canvas, cx: Float, cy: Float, color: Int) {
        p.style = Paint.Style.STROKE
        p.strokeWidth = 3f
        p.color = color
        path.reset()
        path.moveTo(cx - 24f, cy + 5f)
        path.cubicTo(cx - 13f, cy + 4f, cx - 14f, cy - 16f, cx, cy - 16f)
        path.cubicTo(cx + 14f, cy - 16f, cx + 13f, cy + 4f, cx + 24f, cy + 5f)
        c.drawPath(path, p)
        p.style = Paint.Style.FILL
    }

    private fun drawChannelButtons(c: Canvas) {
        val labels = arrayOf("CH1\nFL", "CH2\nFR", "CH3\nRL", "CH4\nRR", "CH5\nCEN", "CH6\nSUB", "CH7\nAUX")
        val x0 = 25f
        val gap = 9f
        val w = 98f
        for (i in 0 until 7) {
            val left = x0 + i * (w + gap)
            val active = state.selectedChannel == i + 1
            val fill = if (active) Color.rgb(0, 132, 255) else Color.rgb(4, 22, 35)
            val border = if (active) Color.rgb(0, 205, 255) else Color.rgb(33, 66, 92)
            roundRect(c, RectF(left, 965f, left + w, 1047f), 12f, fill, border, if (active) 2.5f else 1.5f)
            val parts = labels[i].split("\n")
            text(c, parts[0], left + w / 2f, 999f, 17f, Color.rgb(237, 245, 255), Paint.Align.CENTER, active)
            text(c, parts[1], left + w / 2f, 1027f, 16f, Color.rgb(220, 234, 248), Paint.Align.CENTER, active)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = dx(event.x)
        val y = dy(event.y)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (x in 78f..772f && y in 220f..550f) {
                    val hit = nearestVisiblePoint(x, y)
                    if (hit != null) {
                        draggingBand = hit
                        actions.bandSelected(hit)
                        parent?.requestDisallowInterceptTouchEvent(true)
                        return true
                    }
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (draggingBand > 0) {
                    val row = state.eq.getOrNull(state.selectedChannel - 1)?.getOrNull(draggingBand - 1)
                    if (row != null && LiveEqPolicy.isWritable(row)) {
                        val f = xToFreq(x, 80f, 770f)
                        val g = yToGain(y, 226f, 541f)
                        actions.eqChanged(state.selectedChannel, draggingBand, f, row.q, (g * 10f).roundToInt() / 10f)
                    }
                    return true
                }
            }
            MotionEvent.ACTION_UP -> {
                if (draggingBand > 0) {
                    draggingBand = -1
                    parent?.requestDisallowInterceptTouchEvent(false)
                    performClick()
                    return true
                }
                when {
                    x in 10f..245f && y in 10f..112f -> actions.scanConnect()
                    x in 680f..798f && y in 10f..112f -> actions.showMainMenu()
                    x in 528f..575f && y in 135f..202f -> selectAdjacentChannel(-1)
                    x in 575f..625f && y in 135f..202f -> selectAdjacentChannel(+1)
                    x in 628f..785f && y in 135f..205f -> actions.flatEq()
                    y in 620f..895f && x >= 72f -> {
                        val slot = (((x - 77f) / 116.5f).toInt()).coerceIn(0, 5)
                        visibleBands().getOrNull(slot)?.first?.let(actions::bandSelected)
                    }
                    y in 950f..1060f -> {
                        val idx = ((x - 18f) / 107f).toInt().coerceIn(0, 6)
                        actions.channelSelected(idx + 1)
                    }
                    y in 1065f..1238f -> actions.showUnavailable("Fader / Mute / Phase ต่อช่อง: คำสั่งฮาร์ดแวร์ยังไม่ยืนยัน จึงล็อกการเขียนไว้")
                    x in 8f..275f && y in 1240f..1362f -> actions.refresh()
                    x in 275f..535f && y in 1240f..1362f -> actions.loadPreset()
                    x in 535f..795f && y in 1240f..1362f -> actions.savePreset()
                    y >= 1382f && x < designW * .20f -> navigate(0)
                    y >= 1382f && x < designW * .40f -> navigate(1)
                    y >= 1382f && x < designW * .60f -> navigate(2)
                    y >= 1382f && x < designW * .80f -> navigate(3)
                    y >= 1382f -> navigate(4)
                }
                performClick()
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                draggingBand = -1
                parent?.requestDisallowInterceptTouchEvent(false)
                return true
            }
        }
        return true
    }

    private fun nearestVisiblePoint(x: Float, y: Float): Int? {
        val visible = visibleBands()
        var bestBand: Int? = null
        var best = Float.MAX_VALUE
        visible.forEach { (band, b) ->
            val px = freqToX(b.frequency.coerceIn(20f, 20000f), 80f, 770f)
            val py = gainToY(b.boostDb.coerceIn(-12f, 12f), 226f, 541f)
            val d = hypot(x - px, y - py)
            if (d < best) { best = d; bestBand = band }
        }
        return if (best <= 40f) bestBand else null
    }

    private fun selectAdjacentChannel(delta: Int) {
        val next = ((state.selectedChannel - 1 + delta + 7) % 7) + 1
        actions.channelSelected(next)
    }

    private fun freqToX(freq: Float, left: Float, right: Float): Float {
        val t = (ln(freq / 20f) / ln(1000f)).coerceIn(0f, 1f)
        return left + (right - left) * t
    }

    private fun xToFreq(x: Float, left: Float, right: Float): Float {
        val t = ((x - left) / (right - left)).coerceIn(0f, 1f)
        return (20.0 * 1000.0.pow(t.toDouble())).toFloat().coerceIn(20f, 20000f)
    }

    private fun gainToY(db: Float, top: Float, bottom: Float): Float {
        val t = ((12f - db) / 24f).coerceIn(0f, 1f)
        return top + (bottom - top) * t
    }

    private fun yToGain(y: Float, top: Float, bottom: Float): Float {
        val t = ((y - top) / (bottom - top)).coerceIn(0f, 1f)
        return (12f - 24f * t).coerceIn(-12f, 12f)
    }

    private fun freqLabel(f: Float): String = when {
        f >= 1000f -> {
            val k = f / 1000f
            if (abs(k - k.roundToInt()) < .05f) "${k.roundToInt()}.0 kHz" else String.format(Locale.US, "%.1f kHz", k)
        }
        else -> String.format(Locale.US, "%.0f Hz", f)
    }

    private fun biquadDb(b: EqBand48, freq: Double): Double {
        if (!listOf(b.b0, b.b1, b.b2, b.a1, b.a2).all { it.isFinite() }) return 0.0
        val w = 2.0 * Math.PI * freq / EqBandCodec.SAMPLE_RATE_HZ
        val c1 = cos(w); val s1 = sin(w); val c2 = cos(2 * w); val s2 = sin(2 * w)
        val nr = b.b0 + b.b1 * c1 + b.b2 * c2
        val ni = -b.b1 * s1 - b.b2 * s2
        val dr = 1.0 + b.a1 * c1 + b.a2 * c2
        val di = -b.a1 * s1 - b.a2 * s2
        val n2 = nr * nr + ni * ni
        val d2 = dr * dr + di * di
        return if (n2 <= 1e-18 || d2 <= 1e-18) 0.0 else 10.0 * log10(n2 / d2)
    }

    override fun performClick(): Boolean = super.performClick()
}
