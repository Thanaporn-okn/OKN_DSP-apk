package com.okn.dsp

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.database.ContentObserver
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.KeyEvent
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.okn.dsp.core.DspRuntime
import com.okn.dsp.preset.AppPresetStore
import com.okn.dsp.protocol.EqBand48
import com.okn.dsp.protocol.LiveEqPolicy
import com.okn.dsp.smoothing.PhoneVolumeBridge
import com.okn.dsp.state.ConnectionState
import com.okn.dsp.ui.DspUiActions
import com.okn.dsp.ui.OknColors
import com.okn.dsp.ui.ReferenceDspUi
import com.okn.dsp.ui.UiSnapshot
import com.okn.dsp.ui.dp
import com.okn.dsp.ui.rounded
import com.okn.dsp.ui.txt
import kotlin.math.abs

class MainActivity : Activity(), DspUiActions {
    private lateinit var runtime: DspRuntime
    private lateinit var ui: ReferenceDspUi
    private lateinit var phoneVolume: PhoneVolumeBridge
    private lateinit var presets: AppPresetStore
    private lateinit var uiPrefs: android.content.SharedPreferences
    private val main = Handler(Looper.getMainLooper())
    private val scanDevices = linkedMapOf<String, Triple<BluetoothDevice, String, Int>>()
    private var scanDialog: AlertDialog? = null
    private var scanList: LinearLayout? = null
    private var autoReconnectAttempted = false
    private var ignorePhoneVolumeUntil = 0L
    private var lastMasterSeen: Float? = null
    private var lastMasterBeforeMuteDb: Float = -12f
    private var copiedEq: Map<Int, EqBand48> = emptyMap()
    private var stateUnsubscribe: (() -> Unit)? = null

    private val volumeObserver = object : ContentObserver(main) {
        override fun onChange(selfChange: Boolean) {
            super.onChange(selfChange)
            if (!::phoneVolume.isInitialized || System.currentTimeMillis() < ignorePhoneVolumeUntil || phoneVolume.shouldIgnoreObserver()) return
            val db = phoneVolume.masterDbFromPhone()
            val existing = runtime.store.value().scalars[2]
            if (existing != null && abs(existing-db) > .06f) runtime.dsp.setScalar(2,db,"phone-volume-observer")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = OknColors.BG
        window.navigationBarColor = OknColors.BG
        applyReferenceFullscreen()
        runtime = (application as OknDspApplication).runtime
        phoneVolume = PhoneVolumeBridge(this)
        presets = AppPresetStore(applicationContext)
        uiPrefs = getSharedPreferences("okn_dsp_v1_ui_state", MODE_PRIVATE)
        lastMasterBeforeMuteDb = uiPrefs.getFloat("preMuteMasterDb", -12f).coerceIn(-70f, 6f)
        val initialUi = UiSnapshot(uiPrefs.getInt("tab",0).coerceIn(0,1), false)
        ui = ReferenceDspUi(this,runtime.store,this,initialUi)
        ui.setPresetLabel(presets.currentName())
        setContentView(ui.view)
        bindRuntimeCallbacks()

        stateUnsubscribe = runtime.store.subscribe { s ->
            val master=s.scalars[2]
            if(master!=null&&master.isFinite()&&lastMasterSeen?.let{abs(it-master)>.03f}!=false){
                lastMasterSeen=master
                ignorePhoneVolumeUntil=System.currentTimeMillis()+300L
                phoneVolume.syncPhoneFromMaster(master)
            }
        }
        contentResolver.registerContentObserver(Settings.System.CONTENT_URI,true,volumeObserver)
        main.postDelayed({tryAutoReconnect()},500L)
    }

    private fun bindRuntimeCallbacks() {
        runtime.dsp.onDeviceFound={device,name,rssi->main.post{onScanDevice(device,name,rssi)}}
        runtime.dsp.onToast={msg->main.post{toast(msg)}}
        runtime.dsp.onSaveFinished={ok,msg->main.post{toast(if(ok)"✓ $msg" else "⚠ $msg")}}
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val snap=ui.snapshot()
        saveUiSnapshot(snap)
        ui.dispose()
        ui=ReferenceDspUi(this,runtime.store,this,snap)
        ui.setPresetLabel(presets.currentName())
        setContentView(ui.view)
    }

    override fun onStop() {
        saveUiSnapshot(ui.snapshot())
        runtime.dsp.flushLocal()
        super.onStop()
    }

    override fun onDestroy() {
        runCatching { contentResolver.unregisterContentObserver(volumeObserver) }
        saveUiSnapshot(ui.snapshot())
        runtime.dsp.flushLocal()
        scanDialog?.dismiss()
        ui.dispose()
        stateUnsubscribe?.invoke(); stateUnsubscribe=null
        if (::phoneVolume.isInitialized) phoneVolume.cancelPendingSync()
        // V3 rule: Activity destruction never owns/disconnects the process-scoped DSP session.
        runtime.dsp.onDeviceFound=null
        runtime.dsp.onToast=null
        runtime.dsp.onSaveFinished=null
        super.onDestroy()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val isVolume=event.keyCode==KeyEvent.KEYCODE_VOLUME_UP||event.keyCode==KeyEvent.KEYCODE_VOLUME_DOWN
        if(isVolume&&event.action==KeyEvent.ACTION_DOWN&&::phoneVolume.isInitialized&&!phoneVolume.isProgrammatic()) {
            phoneVolume.cancelPendingSync()
            ignorePhoneVolumeUntil = 0L
        }
        val result=super.dispatchKeyEvent(event)
        if(isVolume&&event.action==KeyEvent.ACTION_DOWN&&!phoneVolume.isProgrammatic()){
            main.postDelayed({
                if(System.currentTimeMillis()<ignorePhoneVolumeUntil)return@postDelayed
                runtime.dsp.setScalar(2,phoneVolume.masterDbFromPhone(),"phone-volume-key")
            },28L)
        }
        return result
    }

    // ---------------- Reference UI actions ----------------
    override fun scanConnect() {
        val s=runtime.store.value()
        if(s.connection==ConnectionState.READY){
            AlertDialog.Builder(this).setTitle("OKN_DSP")
                .setItems(arrayOf("Scan / Connect another DSP","Disconnect")){_,which->if(which==0)startScanDialog() else runtime.devices.disconnect()}
                .show()
        } else startScanDialog()
    }

    override fun showMainMenu() {
        AlertDialog.Builder(this).setTitle("OKN_DSP V3 · 1.0.2")
            .setItems(arrayOf("Scan / Connect","Reconnect last DSP","Refresh verified state","Save to DSP (manual)","Debug log","Disconnect")){_,which->
                when(which){0->startScanDialog();1->reconnect();2->refresh();3->saveParams();4->showLogs();5->disconnect()}
            }.show()
    }

    override fun scalarChanged(id:Int,value:Float) {
        if(id==2) ignorePhoneVolumeUntil=System.currentTimeMillis()+300L
        runtime.dsp.setScalar(id,value,"v3-reference-ui")
    }

    override fun toggleMasterMute() {
        val current = runtime.store.value().scalars[2] ?: -12f
        ignorePhoneVolumeUntil = System.currentTimeMillis() + 350L
        if (current <= -69.5f) {
            runtime.dsp.setScalar(2, lastMasterBeforeMuteDb.coerceIn(-70f, 6f), "master-unmute")
        } else {
            lastMasterBeforeMuteDb = current.coerceIn(-70f, 6f)
            uiPrefs.edit().putFloat("preMuteMasterDb", lastMasterBeforeMuteDb).apply()
            runtime.dsp.setScalar(2, -70f, "master-mute")
        }
    }

    override fun channelSelected(channel:Int)=runtime.dsp.selectChannel(channel)
    override fun bandSelected(band:Int)=runtime.dsp.selectBand(band)
    override fun eqChanged(channel:Int,band:Int,frequency:Float,q:Float,gain:Float)=runtime.dsp.setEq(channel,band,frequency,q,gain,"v3-reference-ui")

    override fun resetGlobal() {
        val referenceDefaults=linkedMapOf(2 to -12f,8 to 0f,9 to 80f,10 to 0f,13 to 0f,11 to 0f)
        referenceDefaults.forEach{(id,v)->runtime.dsp.setScalar(id,v,"global-reset")}
    }

    override fun savePreset() {
        // One-tap local preset save: no confirmation dialog and no hardware SaveParams write.
        val name = presets.currentName().ifBlank { "Preset 1" }
        presets.save(name, runtime.store.value())
        ui.setPresetLabel(name)
        toast("Saved $name")
    }

    override fun loadPreset() {
        val names = presets.names()
        if (names.isEmpty()) { toast("No saved preset yet"); return }
        if (names.size == 1) { applyPreset(names.first()); return }
        // Choosing a preset is the action itself; there is no extra confirmation step.
        AlertDialog.Builder(this).setTitle("Load Preset").setItems(names.toTypedArray()) { _, which ->
            applyPreset(names[which])
        }.show()
    }

    private fun applyPreset(name: String) {
        val p = presets.load(name) ?: return
        presets.setCurrentName(p.name)
        ui.setPresetLabel(p.name)
        p.scalars.forEach { (id, v) -> runtime.dsp.setScalar(id, v, "preset:${p.name}") }
        p.eq.forEach { (k, b) ->
            val current = runtime.store.value().eq.getOrNull(k.first - 1)?.getOrNull(k.second - 1)
            if (current != null && LiveEqPolicy.isWritable(current)) {
                runtime.dsp.setEq(k.first, k.second, b.frequency, b.q, b.boostDb, "preset:${p.name}")
            }
        }
        toast("Loaded ${p.name}")
    }

    override fun flatEq() {
        val s=runtime.store.value();val ch=s.selectedChannel
        s.eq.getOrNull(ch-1)?.forEachIndexed{i,b->if(b!=null&&LiveEqPolicy.isWritable(b))runtime.dsp.setEq(ch,i+1,b.frequency,b.q,0f,"eq-flat")}
    }

    override fun copyEq() {
        val s=runtime.store.value();val ch=s.selectedChannel
        copiedEq=buildMap{s.eq.getOrNull(ch-1)?.forEachIndexed{i,b->if(b!=null&&LiveEqPolicy.isWritable(b))put(i+1,b)}}
        toast("Copied ${copiedEq.size} verified EQ bands")
    }

    override fun pasteEq() {
        if(copiedEq.isEmpty()){toast("Copy EQ first");return}
        val s=runtime.store.value();val ch=s.selectedChannel
        var count=0
        copiedEq.forEach{(band,src)->
            val current=s.eq.getOrNull(ch-1)?.getOrNull(band-1)
            if(current!=null&&LiveEqPolicy.isWritable(current)){runtime.dsp.setEq(ch,band,src.frequency,src.q,src.boostDb,"eq-paste");count++}
        }
        toast("Pasted $count verified EQ bands")
    }

    override fun reconnect(){if(!ensurePermissions())return;if(!runtime.devices.reconnectLast())toast("No remembered DSP device")}
    override fun disconnect()=runtime.devices.disconnect()
    override fun refresh(){if(!runtime.devices.refresh())toast("Refresh unavailable until authenticated")}

    override fun saveParams() {
        val s=runtime.store.value()
        if(!s.healthGatePass||s.saveInFlight){toast("Save blocked: DSP must be connected and verified");return}
        AlertDialog.Builder(this).setTitle("Save to DSP")
            .setMessage("บันทึกค่าปัจจุบันลง DSP แบบถาวร?\n\nSaveParams is manual only. Keep the DSP powered during the write.")
            .setNegativeButton("Cancel",null).setPositiveButton("Save"){_,_->if(!runtime.dsp.saveParamsManual())toast("Save could not start")}.show()
    }

    override fun showUnavailable(label: String) {
        toast(label)
    }

    override fun showLogs() {
        val tv=TextView(this).apply{text=runtime.dsp.logSnapshot().ifBlank{"No debug log yet."};setTextColor(OknColors.TEXT);setTextIsSelectable(true);textSize=10f;setPadding(dp(12),dp(10),dp(12),dp(10));setBackgroundColor(OknColors.BG);typeface=android.graphics.Typeface.MONOSPACE}
        val sc=ScrollView(this).apply{addView(tv,ViewGroup.LayoutParams(-1,-2))}
        AlertDialog.Builder(this).setTitle("OKN_DSP Debug Log").setView(sc).setPositiveButton("Close",null).show()
    }

    // ---------------- BLE scan / permissions ----------------
    private fun startScanDialog() {
        if(!ensurePermissions())return
        val manager=getSystemService(android.bluetooth.BluetoothManager::class.java)
        if(manager?.adapter?.isEnabled!=true){runCatching{startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))};toast("Enable Bluetooth, then tap connect again");return}
        scanDevices.clear()
        scanList=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(8),dp(8),dp(8),dp(8))}
        val scroll=ScrollView(this).apply{addView(scanList,ViewGroup.LayoutParams(-1,-2))}
        scanList?.addView(txt("Scanning for DSP…",12,OknColors.MUTED,false,Gravity.CENTER).apply{setPadding(0,dp(18),0,dp(18))},LinearLayout.LayoutParams(-1,-2))
        scanDialog?.dismiss()
        scanDialog=AlertDialog.Builder(this).setTitle("Bluetooth DSP").setView(scroll).setNegativeButton("Cancel"){_,_->runtime.devices.stopScan()}.create().also{d->d.setOnDismissListener{runtime.devices.stopScan();scanList=null};d.show()}
        runtime.devices.scan()
    }

    private fun onScanDevice(device:BluetoothDevice,name:String,rssi:Int) {
        scanDevices[device.address]=Triple(device,name,rssi)
        val list=scanList?:return
        list.removeAllViews()
        scanDevices.values.sortedByDescending{it.third}.forEach{(d,n,signal)->
            val b=txt("$n\n${d.address}    RSSI $signal dBm",13,OknColors.TEXT,true).apply{background=rounded(OknColors.CARD,dp(10).toFloat(),OknColors.BORDER,dp(1));setPadding(dp(12),dp(10),dp(12),dp(10));setOnClickListener{runtime.devices.stopScan();scanDialog?.dismiss();runtime.devices.connect(d,n)}}
            list.addView(b,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(7)})
        }
    }

    private fun ensurePermissions():Boolean {
        val needed=if(Build.VERSION.SDK_INT>=31)listOf(Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT) else listOf(Manifest.permission.ACCESS_FINE_LOCATION)
        val missing=needed.filter{checkSelfPermission(it)!=PackageManager.PERMISSION_GRANTED}
        if(missing.isEmpty())return true
        requestPermissions(missing.toTypedArray(),REQ_BLE);return false
    }

    override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults)
        if(requestCode==REQ_BLE){if(grantResults.isNotEmpty()&&grantResults.all{it==PackageManager.PERMISSION_GRANTED})startScanDialog() else toast("Bluetooth permission denied")}
    }


    private fun applyReferenceFullscreen() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let { controller ->
                controller.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                controller.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or
                    android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                    android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                    android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                )
        }
    }

    private fun saveUiSnapshot(s:UiSnapshot){uiPrefs.edit().putInt("tab",s.tab).putBoolean("parametric",false).apply()}
    private fun tryAutoReconnect(){if(autoReconnectAttempted||!ensurePermissions())return;autoReconnectAttempted=true;runCatching{runtime.devices.reconnectLast()}}
    private fun toast(msg:String)=Toast.makeText(this,msg,Toast.LENGTH_SHORT).show()

    companion object{private const val REQ_BLE=1001}
}
