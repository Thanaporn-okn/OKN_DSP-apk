-keepattributes Signature,*Annotation*
-dontwarn javax.annotation.**
# Retrofit service interfaces are reflected at runtime.
-keep,allowoptimization,allowshrinking interface com.okn.heavymarket.data.remote.**
