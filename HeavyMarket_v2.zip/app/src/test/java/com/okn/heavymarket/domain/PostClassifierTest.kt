package com.okn.heavymarket.domain

import org.junit.Assert.*
import org.junit.Test

class PostClassifierTest {
    private val classifier = RuleBasedPostClassifier()

    @Test fun saleThaiWithPrice() {
        val r = classifier.classify("ขายด่วน Hino 6 ล้อ ราคา 650,000 บาท พร้อมใช้")
        assertEquals(PostType.SALE, r.type)
        assertEquals(650000L, r.detectedPrice)
    }

    @Test fun wantedIsNotSale() {
        val r = classifier.classify("ตามหา Komatsu PC200 ต้องการซื้อ งบ 650000")
        assertEquals(PostType.WANTED, r.type)
    }

    @Test fun parsesThaiUnits() {
        assertEquals(650000L, PriceParser.parseFirst("ราคา 6.5 แสน"))
        assertEquals(1200000L, PriceParser.parseFirst("1.2 ล้าน"))
        assertEquals(650000L, PriceParser.parseFirst("650k"))
    }

    @Test fun duplicateHashStable() {
        val a = Deduplicator.normalizedHash("Hino 6 ล้อ", "ขาย ราคา 500000", 500000, "https://x.test/post?ref=a")
        val b = Deduplicator.normalizedHash("Hino 6 ล้อ", "ขาย ราคา 500000", 500000, "https://x.test/post?ref=b")
        assertEquals(a, b)
    }
    @Test fun parsesNaturalLanguageMaxPriceQuery() {
        val parsed = SearchQueryParser.parse("รถไถไม่เกิน 300000")
        assertEquals(300000L, parsed.maxPrice)
        assertEquals(listOf("รถไถ"), parsed.terms)
    }

    @Test fun similarityDetectsNearDuplicate() {
        val score = Deduplicator.similarity("ขาย Hino 6 ล้อ ราคา 650000 ขอนแก่น", "Hino 6 ล้อ ขอนแก่น ขายราคา 650000")
        assertTrue(score > 0.5)
    }

}
