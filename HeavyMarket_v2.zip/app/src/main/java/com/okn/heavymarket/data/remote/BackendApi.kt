package com.okn.heavymarket.data.remote

import retrofit2.http.GET
import retrofit2.http.Query

data class BackendProductPage(val items: List<BackendProductDto> = emptyList(), val nextCursor: String? = null)
data class BackendProductDto(
    val id: String,
    val title: String,
    val description: String = "",
    val price: Long? = null,
    val category: String = "อื่นๆ",
    val province: String = "",
    val sourceName: String = "Backend",
    val originalUrl: String = ""
)

interface BackendApi {
    @GET("api/products")
    suspend fun products(
        @Query("q") query: String? = null,
        @Query("cursor") cursor: String? = null,
        @Query("limit") limit: Int = 30
    ): BackendProductPage
}
