package com.okn.heavymarket.data.source

import com.okn.heavymarket.data.local.ProductEntity

interface ProductDataSource {
    val id: String
    val displayName: String
    suspend fun fetch(cursor: String? = null): DataSourcePage
    fun availability(): SourceAvailability = SourceAvailability.Available
}

interface FacebookPageDataSource : ProductDataSource
interface FacebookGroupDataSource : ProductDataSource
interface MarketplaceDataSource : ProductDataSource
interface ImportedPostDataSource : ProductDataSource
interface SharedPostDataSource : ProductDataSource
interface MockDataSource : ProductDataSource

data class DataSourcePage(val items: List<ProductEntity>, val nextCursor: String? = null)
sealed interface SourceAvailability {
    data object Available : SourceAvailability
    data class Unavailable(val reason: String) : SourceAvailability
}

class UnavailableFacebookGroupDataSource : FacebookGroupDataSource {
    override val id = "facebook-groups"
    override val displayName = "Facebook Groups"
    override suspend fun fetch(cursor: String?) = DataSourcePage(emptyList())
    override fun availability() = SourceAvailability.Unavailable(
        "Meta ยกเลิก Groups API แล้ว จึงใช้ Import URL / Share-to-App / provider ที่ได้รับอนุญาตแทน"
    )
}

class UnavailableMarketplaceDataSource : MarketplaceDataSource {
    override val id = "facebook-marketplace"
    override val displayName = "Facebook Marketplace"
    override suspend fun fetch(cursor: String?) = DataSourcePage(emptyList())
    override fun availability() = SourceAvailability.Unavailable(
        "ไม่มี public API ของ Meta สำหรับอ่าน Marketplace listings ทั่วไป"
    )
}
