package com.okn.heavymarket.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore by preferencesDataStore("settings")

@Singleton
class SettingsRepository @Inject constructor(@ApplicationContext private val context: Context) {
    private val darkModeKey = booleanPreferencesKey("dark_mode")
    private val notificationsKey = booleanPreferencesKey("notifications_enabled")

    val darkMode: Flow<Boolean> = context.dataStore.data.map { it[darkModeKey] ?: false }
    val notificationsEnabled: Flow<Boolean> = context.dataStore.data.map { it[notificationsKey] ?: true }

    suspend fun setDarkMode(value: Boolean) { context.dataStore.edit { it[darkModeKey] = value } }
    suspend fun setNotificationsEnabled(value: Boolean) { context.dataStore.edit { it[notificationsKey] = value } }
    suspend fun notificationsEnabledNow(): Boolean = notificationsEnabled.first()
}
