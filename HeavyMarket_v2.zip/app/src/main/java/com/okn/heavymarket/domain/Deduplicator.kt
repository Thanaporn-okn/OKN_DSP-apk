package com.okn.heavymarket.domain

import java.security.MessageDigest

object Deduplicator {
    fun normalizedHash(title: String, description: String, price: Long?, originalUrl: String?): String {
        val canonical = listOf(
            originalUrl?.substringBefore('?').orEmpty().trim().lowercase(),
            normalize(title),
            normalize(description).take(240),
            price?.toString().orEmpty()
        ).joinToString("|")
        return MessageDigest.getInstance("SHA-256")
            .digest(canonical.toByteArray())
            .joinToString("") { "%02x".format(it) }
    }

    private fun normalize(value: String) = value.lowercase().replace(Regex("[^a-z0-9ก-๙]+"), " ").trim()

    fun similarity(a: String, b: String): Double {
        val left = normalize(a).split(" ").filter { it.length > 1 }.toSet()
        val right = normalize(b).split(" ").filter { it.length > 1 }.toSet()
        if (left.isEmpty() || right.isEmpty()) return 0.0
        return left.intersect(right).size.toDouble() / left.union(right).size
    }
}
