package com.okn.heavymarket.domain

data class ParsedSearchQuery(
    val terms: List<String>,
    val minPrice: Long? = null,
    val maxPrice: Long? = null
)

object SearchQueryParser {
    private val maxPatterns = listOf(
        Regex("(?:ไม่เกิน|ราคาไม่เกิน|ต่ำกว่า|<=?)\\s*([0-9][0-9,]*)", RegexOption.IGNORE_CASE),
        Regex("(?:under|max)\\s*([0-9][0-9,]*)", RegexOption.IGNORE_CASE)
    )
    private val minPatterns = listOf(
        Regex("(?:ตั้งแต่|ไม่น้อยกว่า|มากกว่า|>=?)\\s*([0-9][0-9,]*)", RegexOption.IGNORE_CASE),
        Regex("(?:over|min)\\s*([0-9][0-9,]*)", RegexOption.IGNORE_CASE)
    )

    fun parse(raw: String): ParsedSearchQuery {
        var text = raw.trim()
        var maxPrice: Long? = null
        var minPrice: Long? = null
        maxPatterns.forEach { pattern ->
            pattern.find(text)?.let { m ->
                maxPrice = m.groupValues[1].replace(",", "").toLongOrNull()
                text = text.replace(m.value, " ")
            }
        }
        minPatterns.forEach { pattern ->
            pattern.find(text)?.let { m ->
                minPrice = m.groupValues[1].replace(",", "").toLongOrNull()
                text = text.replace(m.value, " ")
            }
        }
        val terms = text.lowercase().split(Regex("\\s+")).filter { it.isNotBlank() }
        return ParsedSearchQuery(terms, minPrice, maxPrice)
    }
}
