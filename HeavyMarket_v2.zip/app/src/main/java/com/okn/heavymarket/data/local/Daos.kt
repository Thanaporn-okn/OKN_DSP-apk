package com.okn.heavymarket.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {
    @Query("SELECT * FROM products WHERE classification = 'SALE' ORDER BY postedAt DESC")
    fun observeSales(): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products ORDER BY postedAt DESC")
    fun observeAll(): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE id = :id LIMIT 1")
    fun observeById(id: String): Flow<ProductEntity?>

    @Query("SELECT * FROM products WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): ProductEntity?

    @Query("SELECT * FROM products")
    suspend fun getAllOnce(): List<ProductEntity>

    @Query("SELECT COUNT(*) FROM products")
    suspend fun count(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(items: List<ProductEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: ProductEntity)
}

@Dao
interface FavoriteDao {
    @Query("SELECT * FROM favorites ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<FavoriteEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE type=:type AND targetId=:targetId)")
    fun observeIsFavorite(type: String, targetId: String): Flow<Boolean>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: FavoriteEntity)

    @Query("DELETE FROM favorites WHERE type=:type AND targetId=:targetId")
    suspend fun delete(type: String, targetId: String)
}

@Dao
interface GroupDao {
    @Query("SELECT * FROM group_sources ORDER BY favorite DESC, name")
    fun observeAll(): Flow<List<GroupSourceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: GroupSourceEntity)

    @Query("UPDATE group_sources SET favorite=:favorite WHERE id=:id")
    suspend fun setFavorite(id: String, favorite: Boolean)

    @Query("UPDATE group_sources SET syncEnabled=:enabled WHERE id=:id")
    suspend fun setSyncEnabled(id: String, enabled: Boolean)
}

@Dao
interface CategoryDao {
    @Query("SELECT * FROM categories WHERE enabled=1 ORDER BY name")
    fun observeEnabled(): Flow<List<CategoryEntity>>

    @Query("SELECT COUNT(*) FROM categories")
    suspend fun count(): Int

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(items: List<CategoryEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: CategoryEntity)
}

@Dao
interface KeywordRuleDao {
    @Query("SELECT * FROM keyword_rules WHERE enabled=1 ORDER BY include DESC, keyword")
    fun observeEnabled(): Flow<List<KeywordRuleEntity>>

    @Query("SELECT * FROM keyword_rules WHERE enabled=1")
    suspend fun enabledOnce(): List<KeywordRuleEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: KeywordRuleEntity)
}

@Dao
interface SavedSearchDao {
    @Query("SELECT * FROM saved_searches ORDER BY id DESC")
    fun observeAll(): Flow<List<SavedSearchEntity>>

    @Query("SELECT * FROM saved_searches WHERE notificationsEnabled=1")
    suspend fun enabledOnce(): List<SavedSearchEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: SavedSearchEntity): Long

    @Query("UPDATE saved_searches SET lastNotifiedAt=:timestamp WHERE id=:id")
    suspend fun markNotified(id: Long, timestamp: Long)
}

@Dao
interface SearchHistoryDao {
    @Query("SELECT * FROM search_history ORDER BY searchedAt DESC LIMIT 20")
    fun observeRecent(): Flow<List<SearchHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: SearchHistoryEntity)

    @Query("DELETE FROM search_history")
    suspend fun clear()
}

@Dao
interface RecentlyViewedDao {
    @Query("SELECT * FROM recently_viewed ORDER BY viewedAt DESC LIMIT 20")
    fun observeRecent(): Flow<List<RecentlyViewedEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: RecentlyViewedEntity)
}
