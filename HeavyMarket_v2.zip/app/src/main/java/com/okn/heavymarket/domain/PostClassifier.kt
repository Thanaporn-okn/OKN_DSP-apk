package com.okn.heavymarket.domain

import javax.inject.Inject
import javax.inject.Singleton

interface PostClassifier {
    fun classify(text: String): ClassificationResult
}

enum class PostType { SALE, RENTAL, WANTED, SERVICE, OTHER }

data class ClassificationResult(
    val type: PostType,
    val score: Double,
    val reasons: List<String>,
    val detectedPrice: Long? = null
)

@Singleton
class RuleBasedPostClassifier @Inject constructor() : PostClassifier {
    private val saleWords = listOf("ขาย", "ขายด่วน", "ราคา", "บาท", "ลดราคา", "มือสอง", "พร้อมใช้", "เจ้าของขายเอง", "สนใจ", "โทร", "inbox", "ทักแชท")
    private val wantedWords = listOf("รับซื้อ", "ตามหา", "ต้องการซื้อ", "หาซื้อ")
    private val rentalWords = listOf("ให้เช่า", "ปล่อยเช่า", "เช่ารายวัน", "เช่ารายเดือน")
    private val serviceWords = listOf("รับซ่อม", "บริการซ่อม", "รับสมัครงาน", "บริการขนส่ง")

    override fun classify(text: String): ClassificationResult {
        val normalized = text.lowercase().replace("฿", " ฿")
        val reasons = mutableListOf<String>()
        var saleScore = 0.0
        saleWords.forEach { if (normalized.contains(it)) { saleScore += if (it == "ขาย" || it == "ราคา") 1.5 else 0.7; reasons += "+$it" } }
        val price = PriceParser.parseFirst(text)
        if (price != null) { saleScore += 2.2; reasons += "+price" }

        val rental = rentalWords.count { normalized.contains(it) }
        val wanted = wantedWords.count { normalized.contains(it) }
        val service = serviceWords.count { normalized.contains(it) }

        return when {
            wanted > 0 -> ClassificationResult(PostType.WANTED, wanted * 2.5, reasons + "wanted", price)
            rental > 0 && saleScore < 4.0 -> ClassificationResult(PostType.RENTAL, rental * 2.5, reasons + "rental", price)
            service > 0 -> ClassificationResult(PostType.SERVICE, service * 2.5, reasons + "service", price)
            saleScore >= 2.2 -> ClassificationResult(PostType.SALE, saleScore, reasons, price)
            else -> ClassificationResult(PostType.OTHER, saleScore, reasons, price)
        }
    }
}

object PriceParser {
    private val bahtPattern = Regex("(?:฿\\s*)?([0-9]{1,3}(?:,[0-9]{3})+|[0-9]{4,9})(?:\\s*บาท)?", RegexOption.IGNORE_CASE)
    private val kPattern = Regex("([0-9]+(?:\\.[0-9]+)?)\\s*[kK]\\b")
    private val hundredKPattern = Regex("([0-9]+(?:\\.[0-9]+)?)\\s*แสน")
    private val millionPattern = Regex("([0-9]+(?:\\.[0-9]+)?)\\s*ล้าน")

    fun parseFirst(text: String): Long? {
        millionPattern.find(text)?.groupValues?.get(1)?.toDoubleOrNull()?.let { return (it * 1_000_000).toLong() }
        hundredKPattern.find(text)?.groupValues?.get(1)?.toDoubleOrNull()?.let { return (it * 100_000).toLong() }
        kPattern.find(text)?.groupValues?.get(1)?.toDoubleOrNull()?.let { return (it * 1_000).toLong() }
        return bahtPattern.find(text)?.groupValues?.get(1)?.replace(",", "")?.toLongOrNull()
    }
}
