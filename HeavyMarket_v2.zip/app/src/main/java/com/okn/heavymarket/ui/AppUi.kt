package com.okn.heavymarket.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import coil3.compose.AsyncImage
import com.okn.heavymarket.data.local.ProductEntity
import kotlinx.coroutines.flow.distinctUntilChanged
import java.text.NumberFormat
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

private data class Tab(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

private val tabs = listOf(
    Tab("latest", "ล่าสุด", Icons.Default.DynamicFeed),
    Tab("groups", "กลุ่ม", Icons.Default.Groups),
    Tab("market", "Marketplace", Icons.Default.Storefront),
    Tab("saved", "บันทึก", Icons.Default.Favorite),
    Tab("settings", "ตั้งค่า", Icons.Default.Settings)
)

@Composable
fun HeavyMarketAppUi(vm: MainViewModel) {
    val nav = rememberNavController()
    Scaffold(
        bottomBar = {
            NavigationBar {
                val current = nav.currentBackStackEntryFlow.collectAsState(initial = null).value?.destination?.route
                tabs.forEach { tab ->
                    NavigationBarItem(
                        selected = current == tab.route,
                        onClick = { nav.navigate(tab.route) { launchSingleTop = true; restoreState = true } },
                        icon = { Icon(tab.icon, null) },
                        label = { Text(tab.label, maxLines = 1) }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(navController = nav, startDestination = "latest", modifier = Modifier.padding(padding)) {
            composable("latest") { LatestScreen(vm, nav) }
            composable("groups") { GroupsScreen(vm, nav) }
            composable("market") { MarketplaceScreen(vm, nav) }
            composable("saved") { SavedScreen(vm, nav) }
            composable("settings") { SettingsScreen(vm) }
            composable("detail/{id}") { DetailScreen(nav) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LatestScreen(vm: MainViewModel, nav: NavHostController) {
    val products by vm.filtered.collectAsState()
    val visible by vm.visibleCount.collectAsState()
    val refreshing by vm.refreshing.collectAsState()
    val listState = rememberLazyListState()

    LaunchedEffect(listState, products.size, visible) {
        snapshotFlow { listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0 }
            .distinctUntilChanged()
            .collect { index ->
                if (products.isNotEmpty() && index >= minOf(products.size, visible) - 4) vm.loadMore()
            }
    }

    PullToRefreshBox(isRefreshing = refreshing, onRefresh = vm::refresh) {
        LazyColumn(
            state = listState,
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item { Text("ล่าสุด", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
            item { DemoBanner() }
            item { SearchBar(vm) }
            item { QuickFilters(vm) }
            if (products.isEmpty()) item { EmptyState("ยังไม่พบประกาศขายที่ตรงตัวกรอง") }
            items(products.take(visible), key = { it.id }) { product ->
                ProductCard(product) { nav.navigate("detail/${product.id}") }
            }
        }
    }
}

@Composable
private fun SearchBar(vm: MainViewModel) {
    val query by vm.query.collectAsState()
    OutlinedTextField(
        value = query,
        onValueChange = vm::search,
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        leadingIcon = { Icon(Icons.Default.Search, null) },
        placeholder = { Text("ค้นหา เช่น Hino 6 ล้อ, PC200, รถไถไม่เกิน 300000") },
        trailingIcon = if (query.isNotBlank()) {
            { IconButton(onClick = { vm.search("") }) { Icon(Icons.Default.Close, null) } }
        } else null
    )
}

@Composable
private fun QuickFilters(vm: MainViewModel) {
    val categories by vm.categories.collectAsState()
    val selected by vm.category.collectAsState()
    var filterOpen by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item { FilterChip(selected = selected == null, onClick = { vm.category.value = null }, label = { Text("ทั้งหมด") }) }
            items(categories.take(12), key = { it.name }) { category ->
                FilterChip(
                    selected = selected == category.name,
                    onClick = { vm.category.value = category.name },
                    label = { Text(category.name) }
                )
            }
            item { AssistChip(onClick = { filterOpen = true }, label = { Text("ตัวกรอง") }, leadingIcon = { Icon(Icons.Default.Tune, null) }) }
        }
        if (filterOpen) FilterSheet(vm) { filterOpen = false }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FilterSheet(vm: MainViewModel, close: () -> Unit) {
    val sheet = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var province by remember { mutableStateOf(vm.province.value) }
    var minPrice by remember { mutableStateOf(vm.minPrice.value?.toString().orEmpty()) }
    var maxPrice by remember { mutableStateOf(vm.maxPrice.value?.toString().orEmpty()) }
    val sort by vm.sort.collectAsState()
    val source by vm.sourceType.collectAsState()

    ModalBottomSheet(onDismissRequest = close, sheetState = sheet) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("ตัวกรอง", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            OutlinedTextField(province, { province = it }, label = { Text("จังหวัด/พื้นที่") }, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(minPrice, { minPrice = it.filter(Char::isDigit) }, label = { Text("ราคาต่ำสุด") }, modifier = Modifier.weight(1f))
                OutlinedTextField(maxPrice, { maxPrice = it.filter(Char::isDigit) }, label = { Text("ราคาสูงสุด") }, modifier = Modifier.weight(1f))
            }
            Text("แหล่งข้อมูล", fontWeight = FontWeight.SemiBold)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                item { FilterChip(selected = source == null, onClick = { vm.sourceType.value = null }, label = { Text("ทั้งหมด") }) }
                items(listOf("DEMO", "IMPORTED", "BACKEND", "FACEBOOK_PAGE")) { type ->
                    FilterChip(selected = source == type, onClick = { vm.sourceType.value = type }, label = { Text(type) })
                }
            }
            Text("ระยะทางจะใช้ได้เมื่อ Provider ส่งพิกัดรายการและผู้ใช้อนุญาตตำแหน่ง แอปไม่สร้างพิกัดปลอม", style = MaterialTheme.typography.bodySmall)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                item { FilterChip(selected = sort == Sort.NEWEST, onClick = { vm.sort.value = Sort.NEWEST }, label = { Text("ล่าสุด") }) }
                item { FilterChip(selected = sort == Sort.PRICE_LOW, onClick = { vm.sort.value = Sort.PRICE_LOW }, label = { Text("ราคาต่ำ-สูง") }) }
                item { FilterChip(selected = sort == Sort.PRICE_HIGH, onClick = { vm.sort.value = Sort.PRICE_HIGH }, label = { Text("ราคาสูง-ต่ำ") }) }
            }
            Button(
                onClick = {
                    vm.province.value = province
                    vm.minPrice.value = minPrice.toLongOrNull()
                    vm.maxPrice.value = maxPrice.toLongOrNull()
                    close()
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("ใช้ตัวกรอง") }
            TextButton(onClick = { vm.clearFilters(); close() }, modifier = Modifier.fillMaxWidth()) { Text("ล้างตัวกรอง") }
        }
    }
}

@Composable
private fun GroupsScreen(vm: MainViewModel, nav: NavHostController) {
    val groups by vm.groups.collectAsState()
    val products by vm.filtered.collectAsState()
    var url by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var groupQuery by remember { mutableStateOf("") }
    var importText by remember { mutableStateOf("") }
    val visibleGroups = groups.filter { groupQuery.isBlank() || it.name.contains(groupQuery, true) || it.url.contains(groupQuery, true) }

    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("กลุ่ม", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
        item {
            InfoCard(
                "Facebook Groups API ไม่เปิดให้ดึงโพสต์สมาชิกทั่วไปแล้ว",
                "รองรับบันทึก URL กลุ่ม, Favorite, เปิด/ปิด sync ต่อกลุ่มสำหรับ provider ในอนาคต, Share-to-App และ Import URL/ข้อความ โดยไม่แกล้งทำว่า sync Facebook สำเร็จ"
            )
        }
        item {
            OutlinedTextField(groupQuery, { groupQuery = it }, label = { Text("ค้นหากลุ่ม") }, leadingIcon = { Icon(Icons.Default.Search, null) }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(name, { name = it }, label = { Text("ชื่อกลุ่ม") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(url, { url = it }, label = { Text("Facebook Group URL") }, modifier = Modifier.fillMaxWidth())
            Button(
                onClick = { vm.addGroup(name, url); name = ""; url = "" },
                enabled = url.isNotBlank(),
                modifier = Modifier.fillMaxWidth()
            ) { Text("เพิ่มกลุ่ม") }
        }
        if (visibleGroups.isNotEmpty()) {
            item { Text("กลุ่มที่บันทึก", fontWeight = FontWeight.Bold) }
            items(visibleGroups, key = { it.id }) { group ->
                ListItem(
                    headlineContent = { Text(group.name) },
                    supportingContent = {
                        Column {
                            Text(group.url, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(if (group.syncEnabled) "Sync เปิด — จะทำงานเมื่อมี authorized provider" else "Sync ปิด", style = MaterialTheme.typography.labelSmall)
                        }
                    },
                    leadingContent = { Icon(Icons.Default.Groups, null) },
                    trailingContent = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { vm.setGroupFavorite(group.id, !group.favorite) }) {
                                Icon(if (group.favorite) Icons.Default.Star else Icons.Default.StarBorder, "Favorite group")
                            }
                            Switch(checked = group.syncEnabled, onCheckedChange = { vm.setGroupSync(group.id, it) })
                        }
                    }
                )
            }
        }
        item {
            HorizontalDivider()
            Text("Import Post", fontWeight = FontWeight.Bold)
            OutlinedTextField(importText, { importText = it }, label = { Text("วาง URL หรือข้อความโพสต์") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
            Button(
                onClick = { vm.importText(importText); importText = "" },
                enabled = importText.isNotBlank(),
                modifier = Modifier.fillMaxWidth()
            ) { Text("นำเข้า + classify + deduplicate") }
        }
        item { QuickFilters(vm) }
        item { Text("ประกาศขายที่มีในแอป", fontWeight = FontWeight.Bold) }
        items(products.take(20), key = { it.id }) { product -> ProductCard(product) { nav.navigate("detail/${product.id}") } }
    }
}

@Composable
private fun MarketplaceScreen(vm: MainViewModel, nav: NavHostController) {
    val products by vm.filtered.collectAsState()
    val history by vm.history.collectAsState()
    val recentlyViewed by vm.recentlyViewed.collectAsState()
    var grid by remember { mutableStateOf(true) }

    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Marketplace", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconButton(onClick = { grid = !grid }) { Icon(if (grid) Icons.Default.ViewList else Icons.Default.GridView, null) }
            }
        }
        item {
            InfoCard(
                "Provider-ready Marketplace",
                "Meta ไม่ได้เปิด public API สำหรับอ่าน listings ทั่วไป แอปจึงใช้ MarketplaceDataSource และทำงานกับ Demo/Imported/authorized provider โดยไม่สร้าง endpoint ปลอม"
            )
        }
        item { SearchBar(vm) }
        if (history.isNotEmpty()) {
            item {
                Column {
                    Text("ประวัติการค้นหา", fontWeight = FontWeight.SemiBold)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(history.take(8), key = { it.query }) { item -> AssistChip(onClick = { vm.search(item.query) }, label = { Text(item.query) }) }
                    }
                }
            }
        }
        if (recentlyViewed.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("ดูล่าสุด", fontWeight = FontWeight.SemiBold)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(recentlyViewed.take(8), key = { it.id }) { product ->
                            CompactProductCard(product, Modifier.width(210.dp)) { nav.navigate("detail/${product.id}") }
                        }
                    }
                }
            }
        }
        item { QuickFilters(vm) }
        if (grid) {
            items(products.chunked(2)) { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { product -> Box(Modifier.weight(1f)) { CompactProductCard(product) { nav.navigate("detail/${product.id}") } } }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        } else {
            items(products, key = { it.id }) { product -> ProductCard(product) { nav.navigate("detail/${product.id}") } }
        }
        item {
            OutlinedButton(onClick = vm::saveCurrentSearch, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Notifications, null)
                Spacer(Modifier.width(8.dp))
                Text("บันทึกการค้นหานี้และแจ้งเตือน")
            }
        }
    }
}

@Composable
private fun SavedScreen(vm: MainViewModel, nav: NavHostController) {
    val products by vm.favoriteProducts.collectAsState()
    val searches by vm.savedSearches.collectAsState()
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("บันทึก", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
        item { Text("Saved Searches", fontWeight = FontWeight.Bold) }
        if (searches.isEmpty()) item { Text("ยังไม่มี Saved Search") }
        items(searches, key = { it.id }) { search ->
            ListItem(
                headlineContent = { Text(search.name) },
                supportingContent = {
                    Text(
                        listOfNotNull(
                            search.keyword.takeIf { it.isNotBlank() },
                            search.category,
                            search.province,
                            search.minPrice?.let { "ตั้งแต่ ${formatPrice(it)}" },
                            search.maxPrice?.let { "ไม่เกิน ${formatPrice(it)}" },
                            search.sourceType
                        ).joinToString(" • ")
                    )
                },
                leadingContent = { Icon(Icons.Default.NotificationsActive, null) }
            )
        }
        item { HorizontalDivider(); Text("Favorite Products", fontWeight = FontWeight.Bold) }
        if (products.isEmpty()) item { EmptyState("ยังไม่มีสินค้าที่บันทึก") }
        items(products, key = { it.id }) { product -> ProductCard(product) { nav.navigate("detail/${product.id}") } }
    }
}

@Composable
private fun SettingsScreen(vm: MainViewModel) {
    val categories by vm.categories.collectAsState()
    val keywordRules by vm.keywordRules.collectAsState()
    val dark by vm.darkMode.collectAsState()
    val notifications by vm.notificationsEnabled.collectAsState()
    var categoryName by remember { mutableStateOf("") }
    var rule by remember { mutableStateOf("") }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("ตั้งค่า", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
        item {
            ListItem(
                headlineContent = { Text("Dark Mode") },
                trailingContent = { Switch(checked = dark, onCheckedChange = vm::setDarkMode) },
                leadingContent = { Icon(Icons.Default.DarkMode, null) }
            )
        }
        item {
            ListItem(
                headlineContent = { Text("แจ้งเตือน Saved Search") },
                supportingContent = { Text("ตรวจผ่าน WorkManager ตามข้อจำกัด Android") },
                trailingContent = { Switch(checked = notifications, onCheckedChange = vm::setNotificationsEnabled) },
                leadingContent = { Icon(Icons.Default.Notifications, null) }
            )
        }
        item { InfoCard("โหมดข้อมูล", "Demo ติดป้าย “ข้อมูลตัวอย่าง” ชัดเจน Live data ต้องมาจาก provider/API ที่ได้รับอนุญาตหรือข้อมูลที่ผู้ใช้นำเข้า") }
        item {
            Text("เพิ่มหมวดหมู่", fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(categoryName, { categoryName = it }, modifier = Modifier.weight(1f), label = { Text("ชื่อหมวดหมู่") })
                IconButton(onClick = { vm.addCategory(categoryName); categoryName = "" }, enabled = categoryName.isNotBlank()) { Icon(Icons.Default.AddCircle, null) }
            }
            Text(categories.joinToString(" • ") { it.name }, style = MaterialTheme.typography.bodySmall)
        }
        item {
            Text("Keyword Include / Exclude", fontWeight = FontWeight.Bold)
            OutlinedTextField(rule, { rule = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Keyword") })
            Row {
                Button(onClick = { vm.addKeywordRule(rule, true); rule = "" }, enabled = rule.isNotBlank()) { Text("Include") }
                Spacer(Modifier.width(8.dp))
                OutlinedButton(onClick = { vm.addKeywordRule(rule, false); rule = "" }, enabled = rule.isNotBlank()) { Text("Exclude") }
            }
            if (keywordRules.isNotEmpty()) {
                Text(keywordRules.joinToString(" • ") { (if (it.include) "+" else "−") + it.keyword }, style = MaterialTheme.typography.bodySmall)
            }
        }
        item { InfoCard("ความปลอดภัย", "App Secret, server token, password และ keystore ต้องอยู่ฝั่ง backend/GitHub Secrets เท่านั้น ไม่ฝังใน APK") }
    }
}

@Composable
private fun DetailScreen(nav: NavHostController, vm: DetailViewModel = hiltViewModel()) {
    val productState by vm.product.collectAsState()
    val favorite by vm.favorite.collectAsState()
    val related by vm.related.collectAsState()
    val context = LocalContext.current
    val product = productState
    if (product == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        return
    }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = nav::popBackStack) { Icon(Icons.Default.ArrowBack, null) }
                Text("รายละเอียดสินค้า", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }
        }
        item {
            AsyncImage(
                model = firstImage(product),
                contentDescription = product.title,
                modifier = Modifier.fillMaxWidth().height(260.dp),
                contentScale = ContentScale.Crop
            )
        }
        item {
            if (product.isDemo) DemoBadge()
            Text(product.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(product.price?.let(::formatPrice) ?: "ไม่ระบุราคา", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
            product.originalPrice?.let { Text("ราคาเดิม ${formatPrice(it)}", style = MaterialTheme.typography.bodyMedium) }
        }
        item {
            Text(product.description)
            HorizontalDivider()
            KeyValue("หมวดหมู่", product.category)
            KeyValue("ยี่ห้อ/รุ่น", listOfNotNull(product.brand, product.model).joinToString(" ").ifBlank { "ไม่ระบุ" })
            KeyValue("ปี", product.year?.toString() ?: "ไม่ระบุ")
            KeyValue("เลขไมล์/ชั่วโมง", product.mileageOrHours ?: "ไม่ระบุ")
            KeyValue("สถานะ", product.conditionText)
            KeyValue("พื้นที่", product.location)
            KeyValue("จังหวัด", product.province)
            KeyValue("วันที่โพสต์", formatDate(product.postedAt))
            KeyValue("แหล่งข้อมูล", product.sourceName)
            product.groupOrPageName?.let { KeyValue("กลุ่ม/เพจ", it) }
            product.sellerName?.let { KeyValue("ผู้ขาย", it) }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = vm::toggleFavorite, modifier = Modifier.weight(1f)) {
                    Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null)
                    Spacer(Modifier.width(6.dp))
                    Text(if (favorite) "บันทึกแล้ว" else "Favorite")
                }
                OutlinedButton(
                    onClick = {
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, "${product.title}\n${product.originalUrl}")
                        }
                        context.startActivity(Intent.createChooser(intent, "แชร์ประกาศ"))
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Share, null)
                    Spacer(Modifier.width(6.dp))
                    Text("แชร์")
                }
            }
        }
        item {
            OutlinedButton(
                onClick = { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(product.originalUrl))) } },
                enabled = product.originalUrl.startsWith("http"),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.OpenInNew, null)
                Spacer(Modifier.width(6.dp))
                Text("เปิดโพสต์ต้นฉบับ")
            }
        }
        item {
            TextButton(
                onClick = {
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, "Report Incorrect Data\nProduct: ${product.id}\n${product.originalUrl}")
                    }
                    context.startActivity(Intent.createChooser(intent, "รายงานข้อมูลไม่ถูกต้อง"))
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Report, null)
                Spacer(Modifier.width(6.dp))
                Text("Report Incorrect Data")
            }
        }
        if (related.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("สินค้าที่เกี่ยวข้อง", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(related, key = { it.id }) { relatedProduct ->
                            CompactProductCard(relatedProduct, Modifier.width(220.dp)) { nav.navigate("detail/${relatedProduct.id}") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProductCard(product: ProductEntity, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row {
            AsyncImage(
                model = firstImage(product),
                contentDescription = product.title,
                modifier = Modifier.width(130.dp).height(120.dp),
                contentScale = ContentScale.Crop
            )
            Column(Modifier.padding(12.dp).weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                if (product.isDemo) DemoBadge()
                Text(product.title, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(product.price?.let(::formatPrice) ?: "ไม่ระบุราคา", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                Text("${product.province} • ${product.category}", style = MaterialTheme.typography.bodySmall)
                Text("${product.sourceName} • ${formatDate(product.postedAt)}", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun CompactProductCard(product: ProductEntity, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Column {
            AsyncImage(
                model = firstImage(product),
                contentDescription = product.title,
                modifier = Modifier.fillMaxWidth().height(120.dp),
                contentScale = ContentScale.Crop
            )
            Column(Modifier.padding(10.dp)) {
                if (product.isDemo) DemoBadge()
                Text(product.title, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(product.price?.let(::formatPrice) ?: "ไม่ระบุราคา", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                Text(product.province, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun DemoBanner() = InfoCard("ข้อมูลตัวอย่าง", "รายการ Demo มีไว้ให้แอปใช้งานได้ทันทีโดยยังไม่มี Facebook/Meta token และไม่ใช่ข้อมูล Facebook จริง")

@Composable
private fun DemoBadge() {
    Surface(color = MaterialTheme.colorScheme.tertiaryContainer, shape = MaterialTheme.shapes.small) {
        Text("ข้อมูลตัวอย่าง", Modifier.padding(horizontal = 6.dp, vertical = 2.dp), style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun InfoCard(title: String, body: String) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
        Column(Modifier.padding(12.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(body, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun EmptyState(text: String) {
    Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) { Text(text) }
}

@Composable
private fun KeyValue(key: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(key, modifier = Modifier.width(130.dp), fontWeight = FontWeight.SemiBold)
        Text(value, modifier = Modifier.weight(1f))
    }
}

private fun firstImage(product: ProductEntity): String? = product.imageUrls.split('|').firstOrNull()?.trim()?.takeIf { it.isNotBlank() }
private fun formatPrice(value: Long) = NumberFormat.getCurrencyInstance(Locale("th", "TH")).format(value)
private fun formatDate(ms: Long) = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm").withZone(ZoneId.systemDefault()).format(Instant.ofEpochMilli(ms))
