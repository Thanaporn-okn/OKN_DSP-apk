package com.okn.heavymarket.data.local

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [
        ProductEntity::class,
        SourceEntity::class,
        GroupSourceEntity::class,
        SellerEntity::class,
        FavoriteEntity::class,
        SavedSearchEntity::class,
        SearchHistoryEntity::class,
        RecentlyViewedEntity::class,
        SyncStateEntity::class,
        CategoryEntity::class,
        KeywordRuleEntity::class,
        PostClassificationEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class HeavyMarketDatabase : RoomDatabase() {
    abstract fun productDao(): ProductDao
    abstract fun favoriteDao(): FavoriteDao
    abstract fun groupDao(): GroupDao
    abstract fun categoryDao(): CategoryDao
    abstract fun keywordRuleDao(): KeywordRuleDao
    abstract fun savedSearchDao(): SavedSearchDao
    abstract fun searchHistoryDao(): SearchHistoryDao
    abstract fun recentlyViewedDao(): RecentlyViewedDao
}
