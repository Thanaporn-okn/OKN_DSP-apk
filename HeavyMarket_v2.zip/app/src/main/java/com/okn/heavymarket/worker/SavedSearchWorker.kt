package com.okn.heavymarket.worker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import androidx.core.app.NotificationCompat
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.okn.heavymarket.R
import com.okn.heavymarket.data.HeavyMarketRepository
import com.okn.heavymarket.data.SettingsRepository
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject

@HiltWorker
class SavedSearchWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val repository: HeavyMarketRepository,
    private val settingsRepository: SettingsRepository
) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = runCatching {
        if (!settingsRepository.notificationsEnabledNow()) return@runCatching Result.success()
        val searches = repository.enabledSavedSearches()
        val products = repository.allProductsOnce()
        searches.forEach { s ->
            val hit = products
                .asSequence()
                .filter { it.classification == "SALE" }
                .filter { p ->
                    (s.keyword.isBlank() || (p.title + " " + p.description).contains(s.keyword, true)) &&
                        (s.category == null || p.category.equals(s.category, true)) &&
                        (s.province == null || p.province.contains(s.province, true)) &&
                        (s.minPrice == null || (p.price ?: Long.MIN_VALUE) >= s.minPrice) &&
                        (s.maxPrice == null || (p.price ?: Long.MAX_VALUE) <= s.maxPrice) &&
                        (s.sourceType == null || p.sourceType.equals(s.sourceType, true)) &&
                        p.createdAt > s.lastNotifiedAt
                }
                .maxByOrNull { it.createdAt }
            if (hit != null) {
                notify(s.id.toInt(), "พบรายการใหม่: ${s.name}", hit.title)
                repository.markSearchNotified(s.id, hit.createdAt)
            }
        }
        Result.success()
    }.getOrElse { Result.retry() }

    private fun notify(id: Int, title: String, body: String) {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "saved_search"
        manager.createNotificationChannel(NotificationChannel(channelId, "Saved Search", NotificationManager.IMPORTANCE_DEFAULT))
        val notification = NotificationCompat.Builder(applicationContext, channelId)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(body)
            .setAutoCancel(true)
            .build()
        manager.notify(1000 + id, notification)
    }
}
