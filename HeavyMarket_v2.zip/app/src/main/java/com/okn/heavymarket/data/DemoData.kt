package com.okn.heavymarket.data

import com.okn.heavymarket.data.local.ProductEntity
import com.okn.heavymarket.domain.Deduplicator

object DemoData {
    private val now = System.currentTimeMillis()
    fun products(): List<ProductEntity> = listOf(
        item("demo-hino", "Hino 6 ล้อ FC ปี 2018", "ขาย Hino 6 ล้อ มือสอง พร้อมใช้ ราคา 650,000 บาท เจ้าของขายเอง", 650_000, "รถหกล้อ", "ขอนแก่น", "Hino", "FC", 2018, 25, "https://images.unsplash.com/photo-1519003722824-194d4455a60c?auto=format&fit=crop&w=1200&q=80"),
        item("demo-komatsu", "Komatsu PC200-8 รถขุด", "ขายด่วน Komatsu PC200-8 ชั่วโมงทำงาน 8,900 ชม. ราคา 1.2 ล้าน", 1_200_000, "รถขุด", "นครราชสีมา", "Komatsu", "PC200-8", 2015, 80, "https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=1200&q=80", "8,900 ชม."),
        item("demo-kubota", "Kubota M7040 รถไถ", "รถไถ Kubota M7040 มือสอง พร้อมใช้งาน 295000 บาท", 295_000, "รถไถ", "อุดรธานี", "Kubota", "M7040", 2017, 130, "https://images.unsplash.com/photo-1592982537447-7440770cbfc9?auto=format&fit=crop&w=1200&q=80"),
        item("demo-isuzu", "Isuzu NPR 6 ล้อ ตู้แห้ง", "ขาย Isuzu NPR ปี 2020 ราคา 790,000 บาท สภาพพร้อมวิ่ง", 790_000, "รถหกล้อ", "กรุงเทพมหานคร", "Isuzu", "NPR", 2020, 190, "https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?auto=format&fit=crop&w=1200&q=80"),
        item("demo-cat", "CAT 320D Excavator", "CAT 320D รถแม็คโคร/รถขุดมือสอง ราคา 1.65 ล้าน สนใจโทร", 1_650_000, "รถขุด", "ชลบุรี", "CAT", "320D", 2014, 245, "https://images.unsplash.com/photo-1573170167633-5f2e56d6e92f?auto=format&fit=crop&w=1200&q=80"),
        item("demo-dump", "รถดั้ม 10 ล้อ", "ขายรถดั้ม 10 ล้อ พร้อมใช้งาน ราคา 980000 บาท", 980_000, "รถดั้ม", "สระบุรี", "Isuzu", "FXZ", 2016, 320, "https://images.unsplash.com/photo-1625047509248-ec889cbff17f?auto=format&fit=crop&w=1200&q=80")
    )

    private fun item(id: String, title: String, desc: String, price: Long, category: String, province: String, brand: String, model: String, year: Int, minutesAgo: Int, image: String, hours: String? = null): ProductEntity {
        val url = "https://example.com/demo/$id"
        return ProductEntity(
            id=id, title=title, description=desc, price=price, category=category, location=province,
            province=province, postedAt=now-minutesAgo*60_000L, sourceId="demo", sourceName="ข้อมูลตัวอย่าง",
            sourceType="DEMO", groupOrPageName="Demo Mode", brand=brand, model=model, year=year,
            mileageOrHours=hours, imageUrls=image, originalUrl=url, classification="SALE", classificationScore=5.0,
            normalizedHash=Deduplicator.normalizedHash(title, desc, price, url), isDemo=true
        )
    }
}
