package com.okn.heavymarket.data.remote

import java.io.IOException
import java.net.SocketTimeoutException
import retrofit2.HttpException

object ApiErrorMapper {
    fun thaiMessage(error: Throwable): String = when (error) {
        is SocketTimeoutException -> "การเชื่อมต่อใช้เวลานานเกินไป กรุณาลองใหม่"
        is HttpException -> when (error.code()) {
            401 -> "สิทธิ์เข้าสู่ระบบหมดอายุหรือไม่ถูกต้อง"
            403 -> "บัญชีหรือแอปไม่มีสิทธิ์อ่านข้อมูลนี้"
            429 -> "เรียกข้อมูลถี่เกินไป ระบบจะลองใหม่ตาม Rate Limit"
            in 500..599 -> "ผู้ให้บริการมีปัญหาชั่วคราว กรุณาลองใหม่ภายหลัง"
            else -> "เรียก API ไม่สำเร็จ (HTTP ${error.code()})"
        }
        is IOException -> "ไม่มีอินเทอร์เน็ตหรือเชื่อมต่อเซิร์ฟเวอร์ไม่ได้"
        else -> "เกิดข้อผิดพลาดในการโหลดข้อมูล"
    }
}
