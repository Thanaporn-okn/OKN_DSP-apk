package com.okn.heavymarket.ui

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.okn.heavymarket.data.HeavyMarketRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DetailViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val repository: HeavyMarketRepository
) : ViewModel() {
    private val id: String = checkNotNull(savedStateHandle["id"])
    val product = repository.product(id).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
    val favorite = repository.isFavorite(id).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)
    val related = repository.relatedProducts(id).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init { viewModelScope.launch { repository.markViewed(id) } }

    fun toggleFavorite() = viewModelScope.launch { repository.toggleFavorite(id, favorite.value) }
}
