package com.okn.heavymarket.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "products", indices = [Index(value = ["originalUrl"], unique = true), Index(value = ["normalizedHash"])])
data class ProductEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val price: Long?,
    val originalPrice: Long? = null,
    val currency: String = "THB",
    val category: String,
    val location: String,
    val province: String,
    val postedAt: Long,
    val sourceId: String,
    val sourceName: String,
    val sourceType: String,
    val groupOrPageName: String? = null,
    val sellerId: String? = null,
    val sellerName: String? = null,
    val brand: String? = null,
    val model: String? = null,
    val year: Int? = null,
    val mileageOrHours: String? = null,
    val conditionText: String = "มือสอง",
    val imageUrls: String = "",
    val originalUrl: String,
    val classification: String = "SALE",
    val classificationScore: Double = 0.0,
    val normalizedHash: String = "",
    val latitude: Double? = null,
    val longitude: Double? = null,
    val isDemo: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "sources")
data class SourceEntity(
    @PrimaryKey val id: String,
    val name: String,
    val type: String,
    val enabled: Boolean = true,
    val syncSupported: Boolean = false,
    val statusMessage: String = ""
)

@Entity(tableName = "group_sources")
data class GroupSourceEntity(
    @PrimaryKey val id: String,
    val name: String,
    val url: String,
    val favorite: Boolean = false,
    val syncEnabled: Boolean = false,
    val providerId: String = "manual"
)

@Entity(tableName = "sellers")
data class SellerEntity(
    @PrimaryKey val id: String,
    val name: String,
    val sourceId: String,
    val profileUrl: String? = null
)

@Entity(tableName = "favorites", primaryKeys = ["type", "targetId"])
data class FavoriteEntity(
    val type: String,
    val targetId: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "saved_searches")
data class SavedSearchEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val keyword: String = "",
    val category: String? = null,
    val province: String? = null,
    val minPrice: Long? = null,
    val maxPrice: Long? = null,
    val sourceType: String? = null,
    val notificationsEnabled: Boolean = true,
    val lastNotifiedAt: Long = 0
)

@Entity(tableName = "search_history")
data class SearchHistoryEntity(
    @PrimaryKey val query: String,
    val searchedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "recently_viewed")
data class RecentlyViewedEntity(
    @PrimaryKey val productId: String,
    val viewedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "sync_state")
data class SyncStateEntity(
    @PrimaryKey val sourceId: String,
    val lastSyncAt: Long = 0,
    val cursor: String? = null,
    val lastError: String? = null
)

@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey val name: String,
    val enabled: Boolean = true,
    val builtIn: Boolean = false
)

@Entity(tableName = "keyword_rules")
data class KeywordRuleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val keyword: String,
    val include: Boolean,
    val weight: Int = 1,
    val enabled: Boolean = true
)

@Entity(tableName = "post_classification")
data class PostClassificationEntity(
    @PrimaryKey val productId: String,
    val label: String,
    val score: Double,
    val reasons: String,
    val classifiedAt: Long = System.currentTimeMillis()
)
