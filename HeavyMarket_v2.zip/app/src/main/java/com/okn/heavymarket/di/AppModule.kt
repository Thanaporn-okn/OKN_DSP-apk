package com.okn.heavymarket.di

import android.content.Context
import androidx.room.Room
import com.okn.heavymarket.BuildConfig
import com.okn.heavymarket.data.local.*
import com.okn.heavymarket.data.remote.BackendApi
import com.okn.heavymarket.domain.PostClassifier
import com.okn.heavymarket.domain.RuleBasedPostClassifier
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class BindingModule {
    @Binds @Singleton abstract fun bindClassifier(impl: RuleBasedPostClassifier): PostClassifier
}

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Provides @Singleton
    fun database(@ApplicationContext context: Context): HeavyMarketDatabase =
        Room.databaseBuilder(context, HeavyMarketDatabase::class.java, "heavy-market.db")
            .build()

    @Provides fun productDao(db: HeavyMarketDatabase) = db.productDao()
    @Provides fun favoriteDao(db: HeavyMarketDatabase) = db.favoriteDao()
    @Provides fun groupDao(db: HeavyMarketDatabase) = db.groupDao()
    @Provides fun categoryDao(db: HeavyMarketDatabase) = db.categoryDao()
    @Provides fun keywordRuleDao(db: HeavyMarketDatabase) = db.keywordRuleDao()
    @Provides fun savedSearchDao(db: HeavyMarketDatabase) = db.savedSearchDao()
    @Provides fun searchHistoryDao(db: HeavyMarketDatabase) = db.searchHistoryDao()
    @Provides fun recentlyViewedDao(db: HeavyMarketDatabase) = db.recentlyViewedDao()

    @Provides @Singleton
    fun okHttp(): OkHttpClient = OkHttpClient.Builder()
        .addInterceptor(HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BASIC })
        .build()

    @Provides @Singleton
    fun retrofit(client: OkHttpClient): Retrofit = Retrofit.Builder()
        .baseUrl(BuildConfig.BACKEND_BASE_URL)
        .client(client)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    @Provides @Singleton
    fun backendApi(retrofit: Retrofit): BackendApi = retrofit.create(BackendApi::class.java)
}
