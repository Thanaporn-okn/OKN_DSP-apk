package com.okn.heavymarket.data.remote

import com.okn.heavymarket.BuildConfig
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import javax.inject.Inject
import javax.inject.Singleton

interface RealtimeEventClient {
    fun events(): Flow<String>
}

@Singleton
class BackendRealtimeClient @Inject constructor(private val client: OkHttpClient) : RealtimeEventClient {
    override fun events(): Flow<String> = callbackFlow {
        val wsUrl = BuildConfig.BACKEND_BASE_URL
            .replaceFirst("https://", "wss://")
            .replaceFirst("http://", "ws://") + "api/ws"
        val request = Request.Builder().url(wsUrl).build()
        val listener = object : WebSocketListener() {
            override fun onMessage(webSocket: WebSocket, text: String) { trySend(text) }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) { close(t) }
        }
        val socket = client.newWebSocket(request, listener)
        awaitClose { socket.close(1000, "app closed") }
    }
}
