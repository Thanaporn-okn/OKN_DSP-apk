import type {DataSource, Product, ProductPage} from './types.js';

export class FacebookGroupsDataSource implements DataSource {
  id = 'facebook-groups';
  name = 'Facebook Groups';
  async available() { return {available: false, reason: 'Meta removed the Groups API; use import/share or an authorized provider.'}; }
  async fetch(): Promise<ProductPage> { return {items: []}; }
}

export class MarketplaceDataSource implements DataSource {
  id = 'facebook-marketplace';
  name = 'Facebook Marketplace';
  async available() { return {available: false, reason: 'No general public Meta API for reading Marketplace listings.'}; }
  async fetch(): Promise<ProductPage> { return {items: []}; }
}

export class FacebookPageDataSource implements DataSource {
  id = 'facebook-pages';
  name = 'Facebook Pages';
  async available() {
    const configured = Boolean(process.env.META_APP_ID && process.env.META_SYSTEM_USER_TOKEN);
    return configured
      ? {available: false, reason: 'Credentials are present, but a Page adapter must only be enabled after the required Meta permissions/features are approved.'}
      : {available: false, reason: 'Page provider is not configured. Requires approved Meta Page permissions/features.'};
  }
  async fetch(): Promise<ProductPage> { return {items: []}; }
}

export class ImportedDataSource implements DataSource {
  id = 'imported';
  name = 'Imported';
  async available() { return {available: true}; }
  async fetch(): Promise<ProductPage> { return {items: [] as Product[]}; }
}

export const dataSources: DataSource[] = [
  new FacebookGroupsDataSource(),
  new MarketplaceDataSource(),
  new FacebookPageDataSource(),
  new ImportedDataSource()
];
