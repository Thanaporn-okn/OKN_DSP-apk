export type PostType = 'SALE' | 'RENTAL' | 'WANTED' | 'SERVICE' | 'OTHER';

export interface Product {
  id: string;
  title: string;
  description: string;
  price?: number;
  category: string;
  province: string;
  sourceName: string;
  sourceType: string;
  originalUrl: string;
  postedAt: number;
  classification: PostType;
  isDemo: boolean;
}

export interface ProductPage {
  items: Product[];
  nextCursor?: string;
}

export interface DataSourceAvailability {
  available: boolean;
  reason?: string;
}

export interface DataSource {
  id: string;
  name: string;
  available(): Promise<DataSourceAvailability>;
  fetch(cursor?: string): Promise<ProductPage>;
}

export interface SavedSearch {
  id: string;
  name: string;
  keyword: string;
  category?: string;
  province?: string;
  minPrice?: number;
  maxPrice?: number;
  sourceType?: string;
  notificationsEnabled: boolean;
  createdAt: number;
}
