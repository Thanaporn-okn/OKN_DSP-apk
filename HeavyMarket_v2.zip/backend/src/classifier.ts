import type {PostType} from './types.js';

export function classify(text: string): {type: PostType; score: number; price?: number} {
  const t = text.toLowerCase();
  const wanted = ['รับซื้อ', 'ตามหา', 'ต้องการซื้อ', 'หาซื้อ'].some(k => t.includes(k));
  const rental = ['ให้เช่า', 'ปล่อยเช่า', 'เช่ารายวัน', 'เช่ารายเดือน'].some(k => t.includes(k));
  const service = ['รับซ่อม', 'บริการซ่อม', 'รับสมัครงาน', 'บริการขนส่ง'].some(k => t.includes(k));
  const price = parsePrice(text);
  const saleWords = ['ขาย', 'ขายด่วน', 'ราคา', 'บาท', 'ลดราคา', 'มือสอง', 'พร้อมใช้', 'เจ้าของขายเอง', 'สนใจ', 'โทร', 'inbox', 'ทักแชท'];
  const score = saleWords.reduce((sum, keyword) => sum + (t.includes(keyword) ? (keyword === 'ขาย' || keyword === 'ราคา' ? 1.5 : 0.7) : 0), 0) + (price ? 2.2 : 0);
  if (wanted) return {type: 'WANTED', score, price};
  if (rental && score < 4) return {type: 'RENTAL', score, price};
  if (service) return {type: 'SERVICE', score, price};
  return {type: score >= 2.2 ? 'SALE' : 'OTHER', score, price};
}

function parsePrice(text: string): number | undefined {
  const million = text.match(/([0-9]+(?:\.[0-9]+)?)\s*ล้าน/i);
  if (million) return Math.round(Number(million[1]) * 1_000_000);
  const hundredK = text.match(/([0-9]+(?:\.[0-9]+)?)\s*แสน/i);
  if (hundredK) return Math.round(Number(hundredK[1]) * 100_000);
  const k = text.match(/([0-9]+(?:\.[0-9]+)?)\s*k\b/i);
  if (k) return Math.round(Number(k[1]) * 1_000);
  const standard = text.match(/(?:฿\s*)?([0-9]{1,3}(?:,[0-9]{3})+|[0-9]{4,9})(?:\s*บาท)?/i);
  return standard ? Number(standard[1].replaceAll(',', '')) : undefined;
}
