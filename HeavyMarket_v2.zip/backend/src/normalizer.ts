import {createHash} from 'node:crypto';
import type {Product} from './types.js';

export function normalizeText(value: string): string {
  return value.toLowerCase().replace(/[^a-z0-9ก-๙]+/g, ' ').trim().replace(/\s+/g, ' ');
}

export function canonicalUrl(value: string): string {
  return value.trim().split('?')[0] ?? '';
}

export function normalizedHash(product: Pick<Product, 'title'|'description'|'price'|'originalUrl'>): string {
  const canonical = [canonicalUrl(product.originalUrl), normalizeText(product.title), normalizeText(product.description).slice(0, 240), product.price ?? ''].join('|');
  return createHash('sha256').update(canonical).digest('hex');
}

export function similarity(a: string, b: string): number {
  const left = new Set(normalizeText(a).split(' ').filter(v => v.length > 1));
  const right = new Set(normalizeText(b).split(' ').filter(v => v.length > 1));
  if (!left.size || !right.size) return 0;
  let intersection = 0;
  for (const token of left) if (right.has(token)) intersection += 1;
  const union = new Set([...left, ...right]).size;
  return intersection / union;
}

export function isDuplicate(candidate: Product, existing: Product[]): boolean {
  const hash = normalizedHash(candidate);
  return existing.some(old =>
    normalizedHash(old) === hash ||
    (!!candidate.originalUrl && canonicalUrl(old.originalUrl) === canonicalUrl(candidate.originalUrl)) ||
    (old.price === candidate.price && similarity(`${old.title} ${old.description}`, `${candidate.title} ${candidate.description}`) >= 0.86)
  );
}
