import 'dotenv/config';
import cors from 'cors';
import express from 'express';
import {createServer} from 'node:http';
import {randomUUID} from 'node:crypto';
import {WebSocket, WebSocketServer} from 'ws';
import {classify} from './classifier.js';
import {dataSources} from './providers.js';
import {isDuplicate} from './normalizer.js';
import type {Product, SavedSearch} from './types.js';

const app = express();
app.disable('x-powered-by');
app.use(cors({origin: process.env.CORS_ORIGIN || '*'}));
app.use(express.json({limit: '1mb'}));

const token = process.env.API_BEARER_TOKEN;
app.use('/api', (req, res, next) => {
  if (!token || req.headers.authorization === `Bearer ${token}`) return next();
  return res.status(401).json({error: 'unauthorized'});
});

const now = Date.now();
const products: Product[] = [{
  id: 'server-demo-1',
  title: 'Hino 6 ล้อ Demo',
  description: 'ข้อมูลตัวอย่างจาก backend',
  price: 650000,
  category: 'รถหกล้อ',
  province: 'ขอนแก่น',
  sourceName: 'Backend Demo',
  sourceType: 'DEMO',
  originalUrl: 'https://example.com/demo/server-demo-1',
  postedAt: now,
  classification: 'SALE',
  isDemo: true
}];
const savedSearches: SavedSearch[] = [];

app.get('/health', (_req, res) => res.json({ok: true, service: 'heavy-market-backend'}));

app.get('/api/products', (req, res) => {
  const q = String(req.query.q || '').trim().toLowerCase();
  const category = String(req.query.category || '').trim();
  const province = String(req.query.province || '').trim();
  const sourceType = String(req.query.sourceType || '').trim();
  const minPrice = Number(req.query.minPrice || 0) || undefined;
  const maxPrice = Number(req.query.maxPrice || 0) || undefined;
  const limit = Math.max(1, Math.min(Number(req.query.limit || 30), 100));
  const offset = Math.max(0, Number(Buffer.from(String(req.query.cursor || ''), 'base64url').toString('utf8')) || 0);

  const matched = products
    .filter(p => p.classification === 'SALE')
    .filter(p => !q || `${p.title} ${p.description} ${p.category} ${p.province} ${p.sourceName}`.toLowerCase().includes(q))
    .filter(p => !category || p.category.toLowerCase() === category.toLowerCase())
    .filter(p => !province || p.province.toLowerCase().includes(province.toLowerCase()))
    .filter(p => !sourceType || p.sourceType.toLowerCase() === sourceType.toLowerCase())
    .filter(p => minPrice === undefined || (p.price ?? Number.NEGATIVE_INFINITY) >= minPrice)
    .filter(p => maxPrice === undefined || (p.price ?? Number.POSITIVE_INFINITY) <= maxPrice)
    .sort((a, b) => b.postedAt - a.postedAt);

  const items = matched.slice(offset, offset + limit);
  const nextOffset = offset + items.length;
  const nextCursor = nextOffset < matched.length ? Buffer.from(String(nextOffset)).toString('base64url') : undefined;
  res.json({items, nextCursor});
});

app.post('/api/import', (req, res) => {
  const text = String(req.body?.text || '').trim();
  if (!text) return res.status(400).json({error: 'text_required'});
  const c = classify(text);
  const url = text.match(/https?:\/\/\S+/)?.[0]?.replace(/[.,)]$/, '') || `import://${randomUUID()}`;
  const p: Product = {
    id: `import-${randomUUID()}`,
    title: text.split(/\r?\n/)[0]?.slice(0, 100) || 'Imported post',
    description: text,
    price: c.price,
    category: inferCategory(text),
    province: inferProvince(text),
    sourceName: 'User import',
    sourceType: 'IMPORTED',
    originalUrl: url,
    postedAt: Date.now(),
    classification: c.type,
    isDemo: false
  };
  if (isDuplicate(p, products)) return res.status(409).json({error: 'duplicate'});
  products.unshift(p);
  broadcast({type: 'product.created', product: p});
  return res.status(201).json(p);
});

app.get('/api/sources', async (_req, res) => {
  const items = await Promise.all(dataSources.map(async source => ({id: source.id, name: source.name, ...(await source.available())})));
  res.json(items);
});

app.post('/api/sources/:id/sync', async (req, res) => {
  const source = dataSources.find(item => item.id === req.params.id);
  if (!source) return res.status(404).json({error: 'source_not_found'});
  const availability = await source.available();
  if (!availability.available) return res.status(409).json({error: 'source_unavailable', reason: availability.reason});
  const page = await source.fetch(typeof req.body?.cursor === 'string' ? req.body.cursor : undefined);
  let inserted = 0;
  for (const product of page.items) {
    if (!isDuplicate(product, products)) { products.unshift(product); inserted += 1; }
  }
  if (inserted) broadcast({type: 'sync.completed', sourceId: source.id, inserted});
  return res.json({inserted, nextCursor: page.nextCursor});
});

app.get('/api/saved-searches', (_req, res) => res.json(savedSearches));
app.post('/api/saved-searches', (req, res) => {
  const item: SavedSearch = {
    id: randomUUID(),
    name: String(req.body?.name || 'Saved Search'),
    keyword: String(req.body?.keyword || ''),
    category: optionalString(req.body?.category),
    province: optionalString(req.body?.province),
    minPrice: optionalNumber(req.body?.minPrice),
    maxPrice: optionalNumber(req.body?.maxPrice),
    sourceType: optionalString(req.body?.sourceType),
    notificationsEnabled: req.body?.notificationsEnabled !== false,
    createdAt: Date.now()
  };
  savedSearches.unshift(item);
  res.status(201).json(item);
});
app.delete('/api/saved-searches/:id', (req, res) => {
  const index = savedSearches.findIndex(item => item.id === req.params.id);
  if (index < 0) return res.status(404).json({error: 'saved_search_not_found'});
  savedSearches.splice(index, 1);
  return res.status(204).end();
});

const server = createServer(app);
const wss = new WebSocketServer({server, path: '/api/ws'});
function broadcast(data: unknown) {
  const msg = JSON.stringify(data);
  for (const client of wss.clients) if (client.readyState === WebSocket.OPEN) client.send(msg);
}

server.listen(Number(process.env.PORT || 8080), () => console.log('Heavy Market backend listening'));

function optionalString(value: unknown): string | undefined {
  const text = typeof value === 'string' ? value.trim() : '';
  return text || undefined;
}
function optionalNumber(value: unknown): number | undefined {
  const n = Number(value);
  return Number.isFinite(n) ? n : undefined;
}
function inferCategory(text: string): string {
  const lower = text.toLowerCase();
  const map: Array<[string, string]> = [
    ['รถหกล้อ', 'รถหกล้อ'], ['6 ล้อ', 'รถหกล้อ'], ['รถสิบล้อ', 'รถสิบล้อ'], ['10 ล้อ', 'รถสิบล้อ'],
    ['รถดั้ม', 'รถดั้ม'], ['รถดั๊ม', 'รถดั้ม'], ['pc200', 'รถขุด'], ['excavator', 'รถขุด'], ['รถขุด', 'รถขุด'],
    ['รถแม็คโคร', 'รถแม็คโคร'], ['kubota', 'รถไถ'], ['รถไถ', 'รถไถ'], ['wheel loader', 'Wheel Loader'], ['รถเครน', 'รถเครน']
  ];
  return map.find(([needle]) => lower.includes(needle))?.[1] || 'อื่นๆ';
}
function inferProvince(text: string): string {
  const provinces = ['ขอนแก่น', 'นครราชสีมา', 'อุดรธานี', 'อุบลราชธานี', 'เชียงใหม่', 'เชียงราย', 'พิษณุโลก', 'กรุงเทพ', 'ชลบุรี', 'ระยอง', 'สระบุรี', 'สุราษฎร์ธานี', 'สงขลา'];
  return provinces.find(value => text.includes(value)) || 'ไม่ระบุ';
}
