# Heavy Market Backend

Reference backend (Node.js + TypeScript) สำหรับเก็บ secret/token ที่ห้ามอยู่ใน APK และเป็นจุดเชื่อม provider ที่ได้รับอนุญาตในอนาคต

## Run

```bash
cp .env.example .env
npm install
npm run dev
```

ตั้ง `API_BEARER_TOKEN` เป็นค่าสุ่มยาว ๆ ใน production และส่ง `Authorization: Bearer <token>` จาก client ที่ได้รับอนุญาต ห้าม commit `.env` จริง

## API

- `GET /health`
- `GET /api/products` — search/filter/pagination
- `POST /api/import` — normalize/classify/deduplicate imported text
- `GET /api/sources`
- `POST /api/sources/:id/sync` — sync เฉพาะ source ที่ `available=true`
- `GET/POST/DELETE /api/saved-searches`
- WebSocket `/api/ws` — realtime events เช่น `product.created`

Facebook Groups/Marketplace adapters จะตอบว่า unavailable ตามข้อจำกัดจริง ไม่สร้าง endpoint Facebook ปลอม ส่วน Facebook Pages ถูก disable จนกว่าจะมี permissions/features ที่ Meta อนุมัติจริง
