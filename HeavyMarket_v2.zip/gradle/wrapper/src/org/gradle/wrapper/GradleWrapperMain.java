package org.gradle.wrapper;

import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.nio.file.attribute.PosixFilePermission;
import java.security.MessageDigest;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Small repository-local Gradle bootstrapper.
 * It reads gradle-wrapper.properties, downloads the pinned distribution,
 * verifies distributionSha256Sum, extracts it under GRADLE_USER_HOME,
 * then delegates all arguments to the real Gradle executable.
 *
 * This class intentionally contains no project secret or credential.
 */
public final class GradleWrapperMain {
    private static final int CONNECT_TIMEOUT_MS = 30_000;
    private static final int READ_TIMEOUT_MS = 120_000;

    public static void main(String[] args) throws Exception {
        Path jar = Paths.get(GradleWrapperMain.class.getProtectionDomain()
                .getCodeSource().getLocation().toURI()).toAbsolutePath().normalize();
        Path wrapperDir = jar.getParent();
        Path projectDir = wrapperDir.getParent().getParent();
        Path propsFile = wrapperDir.resolve("gradle-wrapper.properties");

        Properties props = new Properties();
        try (InputStream in = Files.newInputStream(propsFile)) {
            props.load(in);
        }

        String distributionUrl = require(props, "distributionUrl").replace("\\:", ":");
        String expectedSha256 = require(props, "distributionSha256Sum").trim().toLowerCase(Locale.ROOT);
        if (!distributionUrl.startsWith("https://")) {
            throw new SecurityException("Only HTTPS Gradle distributions are allowed: " + distributionUrl);
        }

        String zipName = distributionUrl.substring(distributionUrl.lastIndexOf('/') + 1);
        String distName = zipName.endsWith(".zip") ? zipName.substring(0, zipName.length() - 4) : zipName;
        String gradleHomeEnv = System.getenv("GRADLE_USER_HOME");
        Path gradleUserHome = (gradleHomeEnv == null || gradleHomeEnv.isBlank())
                ? Paths.get(System.getProperty("user.home"), ".gradle")
                : Paths.get(gradleHomeEnv);
        String urlHash = sha256Hex(distributionUrl.getBytes(java.nio.charset.StandardCharsets.UTF_8)).substring(0, 16);
        Path installRoot = gradleUserHome.resolve("wrapper/dists").resolve(distName).resolve(urlHash);
        Path marker = installRoot.resolve(".ok");
        Path gradleExe = locateGradleExecutable(installRoot);

        if (!Files.exists(marker) || gradleExe == null) {
            Files.createDirectories(installRoot);
            Path tmpZip = Files.createTempFile(installRoot, "gradle-", ".zip.part");
            try {
                System.out.println("Downloading " + distributionUrl);
                download(distributionUrl, tmpZip);
                String actual = sha256Hex(tmpZip);
                if (!actual.equalsIgnoreCase(expectedSha256)) {
                    throw new SecurityException("Gradle distribution SHA-256 mismatch. Expected "
                            + expectedSha256 + " but got " + actual);
                }
                deleteChildrenExcept(installRoot, tmpZip);
                unzip(tmpZip, installRoot);
                Files.deleteIfExists(tmpZip);
                gradleExe = locateGradleExecutable(installRoot);
                if (gradleExe == null) {
                    throw new IOException("Gradle executable not found after extraction in " + installRoot);
                }
                makeExecutable(gradleExe);
                Files.writeString(marker, expectedSha256 + System.lineSeparator());
            } finally {
                Files.deleteIfExists(tmpZip);
            }
        }

        List<String> command = new ArrayList<>();
        if (isWindows()) {
            command.add("cmd");
            command.add("/c");
        }
        command.add(gradleExe.toString());
        command.addAll(Arrays.asList(args));
        Process process = new ProcessBuilder(command)
                .directory(projectDir.toFile())
                .inheritIO()
                .start();
        System.exit(process.waitFor());
    }

    private static String require(Properties p, String key) {
        String value = p.getProperty(key);
        if (value == null || value.isBlank()) throw new IllegalStateException("Missing " + key);
        return value;
    }

    private static void download(String url, Path target) throws Exception {
        URL current = URI.create(url).toURL();
        for (int redirects = 0; redirects < 10; redirects++) {
            URLConnection raw = current.openConnection();
            raw.setConnectTimeout(CONNECT_TIMEOUT_MS);
            raw.setReadTimeout(READ_TIMEOUT_MS);
            raw.setRequestProperty("User-Agent", "HeavyMarket-Gradle-Bootstrap/1");
            if (raw instanceof HttpURLConnection http) {
                http.setInstanceFollowRedirects(false);
                int code = http.getResponseCode();
                if (code >= 300 && code < 400) {
                    String location = http.getHeaderField("Location");
                    if (location == null) throw new IOException("Redirect without Location from " + current);
                    current = current.toURI().resolve(location).toURL();
                    continue;
                }
                if (code < 200 || code >= 300) throw new IOException("HTTP " + code + " from " + current);
            }
            try (InputStream in = raw.getInputStream(); OutputStream out = Files.newOutputStream(target,
                    StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE)) {
                in.transferTo(out);
            }
            return;
        }
        throw new IOException("Too many redirects downloading Gradle");
    }

    private static void unzip(Path zip, Path destination) throws IOException {
        Path normalizedDest = destination.toAbsolutePath().normalize();
        try (ZipInputStream zin = new ZipInputStream(Files.newInputStream(zip))) {
            ZipEntry entry;
            while ((entry = zin.getNextEntry()) != null) {
                Path out = normalizedDest.resolve(entry.getName()).normalize();
                if (!out.startsWith(normalizedDest)) throw new SecurityException("Unsafe ZIP entry: " + entry.getName());
                if (entry.isDirectory()) {
                    Files.createDirectories(out);
                } else {
                    Files.createDirectories(out.getParent());
                    Files.copy(zin, out, StandardCopyOption.REPLACE_EXISTING);
                }
                zin.closeEntry();
            }
        }
    }

    private static Path locateGradleExecutable(Path root) throws IOException {
        if (!Files.exists(root)) return null;
        String name = isWindows() ? "gradle.bat" : "gradle";
        try (var walk = Files.walk(root, 4)) {
            return walk.filter(p -> p.getFileName().toString().equals(name))
                    .filter(p -> p.getParent() != null && p.getParent().getFileName().toString().equals("bin"))
                    .findFirst().orElse(null);
        }
    }

    private static void deleteChildrenExcept(Path root, Path keep) throws IOException {
        if (!Files.exists(root)) return;
        try (var walk = Files.walk(root)) {
            walk.sorted(Comparator.reverseOrder()).forEach(p -> {
                if (p.equals(root) || p.equals(keep)) return;
                try { Files.deleteIfExists(p); } catch (IOException e) { throw new UncheckedIOException(e); }
            });
        } catch (UncheckedIOException e) {
            throw e.getCause();
        }
    }

    private static void makeExecutable(Path file) {
        if (isWindows()) return;
        try {
            Set<PosixFilePermission> perms = Files.getPosixFilePermissions(file);
            perms.add(PosixFilePermission.OWNER_EXECUTE);
            perms.add(PosixFilePermission.GROUP_EXECUTE);
            perms.add(PosixFilePermission.OTHERS_EXECUTE);
            Files.setPosixFilePermissions(file, perms);
        } catch (Exception ignored) {
            file.toFile().setExecutable(true, false);
        }
    }

    private static boolean isWindows() {
        return System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
    }

    private static String sha256Hex(Path path) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        try (InputStream in = Files.newInputStream(path)) {
            byte[] buffer = new byte[64 * 1024];
            for (int n; (n = in.read(buffer)) >= 0;) if (n > 0) md.update(buffer, 0, n);
        }
        return hex(md.digest());
    }

    private static String sha256Hex(byte[] data) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        return hex(md.digest(data));
    }

    private static String hex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) sb.append(String.format("%02x", b));
        return sb.toString();
    }
}
