# Changelog

## v2 — 2026-09-20

- แก้ GitHub Actions ล้มที่ `platforms;android-37` โดยย้ายแอปไปใช้ Android 16 stable (`compileSdk = 36`, `targetSdk = 36`).
- Workflow ไม่ hard-code platform API อีกต่อไป แต่ตรวจ `compileSdk` จาก `app/build.gradle(.kts)` แล้วติดตั้ง SDK ที่ตรงกับโปรเจกต์อัตโนมัติ.
- ตรึง Android Command-line Tools revision 15859902 เพื่อหลีกเลี่ยง `sdkmanager` รุ่นเก่าที่ preinstalled บน runner.
- คงระบบเลือก ZIP เวอร์ชันใหม่สุด, auto version จาก GitHub Run Number, Unit Test, Debug APK และ optional signed Release APK.

## v1 — 2026-09-20

- สร้าง Native Android app ด้วย Kotlin, Jetpack Compose, Material 3, MVVM, Repository, Coroutines/Flow และ Hilt
- เพิ่ม Room database พร้อม Product, Source, GroupSource, Seller, Favorite, SavedSearch, SearchHistory, RecentlyViewed, SyncState, Category, KeywordRule และ PostClassification
- เพิ่ม Unified SALE Feed, Pull-to-refresh, incremental/infinite display, search/filter/sort และ offline cache
- เพิ่ม Groups fallback: Group URL list, search, Favorite, sync flag, Android Share-to-App และ Import URL/text
- เพิ่ม Marketplace-style screen: grid/list, search history, recently viewed, saved items/search, filters และ related products
- เพิ่ม Product Detail พร้อม seller/source/group fields, Favorite, Share, Open Original และ Report Incorrect Data
- เพิ่ม Rule-based `PostClassifier` สำหรับ SALE/RENTAL/WANTED/SERVICE/OTHER
- เพิ่ม `PriceParser` รองรับ 650,000 / 650000 / 650k / 6.5 แสน / 1.2 ล้าน / ฿
- เพิ่ม Include/Exclude keyword rules ที่ถูกนำไปใช้ตอน import/classify
- เพิ่ม normalized SHA-256 dedup + URL canonicalization + similarity scoring
- เพิ่ม natural-language price search เช่น `รถไถไม่เกิน 300000`
- เพิ่ม Saved Search notification ผ่าน WorkManager และ `lastNotifiedAt` ป้องกันแจ้งซ้ำ
- เพิ่ม DataStore สำหรับ Dark Mode / Notification settings
- เพิ่ม Retrofit/OkHttp API contract, Thai API error mapper และ WebSocket realtime client
- เพิ่ม Node.js + TypeScript backend reference พร้อม auth hook, normalization, classification, deduplication, pagination, saved searches, source adapters และ realtime events
- เพิ่ม Facebook Groups/Marketplace unavailable adapters โดยไม่สร้าง fake endpoint; Page provider ปิดไว้จนได้รับ Meta permissions/features จริง
- เพิ่ม GitHub Actions สำหรับ test + Debug APK, non-interactive SDK install, automatic versioning, artifact verification/upload และ optional signed Release
- ใช้ AGP 9.4.0 built-in Kotlin + Compose compiler plugin, KSP 2.3.10, Room 2.8.5, AndroidX Hilt 1.4.0
- เพิ่ม repository-local Gradle bootstrap สำหรับ Gradle 9.6.1 พร้อมตรวจ official distribution SHA-256
- เพิ่ม `BUILD_VALIDATION.md` ระบุผลตรวจจริงและข้อจำกัด environment โดยไม่อ้าง APK build สำเร็จเกินจริง
