#!/usr/bin/env python3
from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[1]
m=json.loads((root/"evidence_manifest.json").read_text())
errors=[]
if m.get("schema")!=4: errors.append("evidence schema must be 4")
if m.get("project_version")!=16: errors.append("project_version must be 16")
if m.get("target")!="BP1048P4" or m.get("board")!="GoloPine 7CH": errors.append("target/board mismatch")
if m.get("policy")!="FAIL_CLOSED_NO_INFERENCE": errors.append("policy mismatch")
if m.get("hardware_authorized") is not False: errors.append("hardware_authorized must be false")
req=m.get("required_exact_evidence",{})
if any(bool(v) for v in req.values()): errors.append("V16 exact evidence flags must all remain false")
prov=m.get("provenance",{})
if prov.get("previous_source_sha256")!="8af8bf041528403c46b9cb0c439bffe490891f893ae3c4b3a8dda366e0a5d46c": errors.append("V15 source provenance mismatch")
if prov.get("validation_zip_sha256")!="e3742b9a6c540c08c95bfa492a0132b9ef7859f71fde43d30b329c0064ba45c3": errors.append("V15 validation provenance mismatch")
for ob in m.get("observations",[]):
    if ob.get("authorizes") not in ([],None): errors.append("observations may not authorize hardware in V16")
if errors:
    [print("BLOCKED:",e) for e in errors]; sys.exit(1)
print("PASS: V16 evidence manifest is internally consistent and non-authorizing")
