#!/usr/bin/env python3
"""Create a non-authorizing evidence intake record for a supplied artifact.

The output is intentionally UNREVIEWED_INPUT and authorizes nothing. A human
review must later map exact evidence to a claim in target_qualification_manifest.json.
"""
from pathlib import Path
import argparse, hashlib, json, sys

p=argparse.ArgumentParser()
p.add_argument('artifact')
p.add_argument('--source', required=True, help='provenance, e.g. vendor URL/email/package label')
a=p.parse_args()
path=Path(a.artifact)
if not path.is_file():
    print('not a regular file: '+str(path), file=sys.stderr); sys.exit(2)
h=hashlib.sha256()
with path.open('rb') as f:
    for b in iter(lambda:f.read(1024*1024), b''): h.update(b)
print(json.dumps({
    'schema':1,
    'classification':'UNREVIEWED_INPUT',
    'file_name':path.name,
    'size':path.stat().st_size,
    'sha256':h.hexdigest(),
    'source':a.source,
    'reviewed':False,
    'verified_claims':[],
    'authorizes':[]
}, indent=2))
