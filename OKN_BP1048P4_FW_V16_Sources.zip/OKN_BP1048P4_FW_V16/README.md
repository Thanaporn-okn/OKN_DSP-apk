# OKN_BP1048P4_FW_V16

V16 is a portable capability-negotiation release built on the GitHub-validated
V14 baseline.

The wire frame remains Protocol V2. V16 adds `GET_CAPABILITIES (0x06)` with a
fixed, little-endian capability payload returned as `CAPABILITIES (0x76)`.
The Android client can query this before enabling controls and can verify
firmware/protocol version, channel count, PEQ band count, portable max delay,
maximum frame size, supported control-plane features, retry/session policy,
and the fail-closed hardware/mobile-flash flags.

This is a read-only query. It does not authorize hardware, does not emit any
vendor programmer command, and does not change DSP state or revision.

The BP1048P4/GoloPine hardware port remains locked pending exact target and
board evidence. No `.bin` or other flashable image is shipped.

See `docs/CAPABILITY_HANDSHAKE_V16.md`.

## V16 target qualification

V16 adds a machine-verifiable target qualification bundle for the exact BP1048P4/GoloPine evidence that is still missing. Incoming vendor SDK/programmer/board artifacts can now be hashed with `tools/qualification_intake.py`, but no filename or text match can authorize a hardware claim. Every exact claim needs reviewed provenance and a SHA256-backed evidence locator. Hardware and mobile-flash authorization remain explicitly false.
