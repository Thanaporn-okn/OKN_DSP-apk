#!/usr/bin/env python3
from pathlib import Path
import copy, json, sys
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'tools'))
from target_qualification_policy import CLAIM_CLASSES, HARDWARE_CLAIMS, evaluate, record_is_qualified
m=json.loads((root/'target_qualification_manifest.json').read_text())
r=evaluate(m)
assert not r['hardware_ready'] and not r['mobile_ready']
assert all(v is False for v in r['qualified'].values())
# Filename/string hints never qualify anything.
fake={'verified':True,'reviewed':True,'classification':'FAMILY_ONLY','artifact_sha256':'a'*64,'source':'BP1048P4_SDK.zip','evidence_locator':'filename says BP1048P4'}
assert not record_is_qualified('exact_chip_identity',fake)
# Missing provenance/hash/review blocks an otherwise exact classification.
fake['classification']='EXACT_TARGET'; fake['reviewed']=False
assert not record_is_qualified('exact_chip_identity',fake)
fake['reviewed']=True; fake['artifact_sha256']='not-a-hash'
assert not record_is_qualified('exact_chip_identity',fake)
# Synthetic policy-only complete evidence can qualify, but authorization remains explicit.
m2=copy.deepcopy(m)
for name, classes in CLAIM_CLASSES.items():
    cls=sorted(classes)[0]
    m2['claims'][name]={'verified':True,'reviewed':True,'classification':cls,'artifact_sha256':'b'*64,'source':'synthetic unit-test evidence','evidence_locator':'unit-test:claim/'+name}
r2=evaluate(m2)
assert r2['hardware_complete'] and r2['mobile_complete']
assert not r2['hardware_ready'] and not r2['mobile_ready']
m2['hardware_authorized']=True
assert evaluate(m2)['hardware_ready'] and not evaluate(m2)['mobile_ready']
m2['mobile_flash_authorized']=True
assert evaluate(m2)['mobile_ready']
m2['claims']['programmer_transport']['reviewed']=False
assert not evaluate(m2)['hardware_ready']
print('ALL V16 TARGET QUALIFICATION TESTS PASS')
