@echo off
setlocal
set GRADLE_VERSION=9.6
if "%GRADLE_USER_HOME%"=="" set GRADLE_USER_HOME=%USERPROFILE%\.gradle
set BASE_DIR=%GRADLE_USER_HOME%\generated-wrapper\gradle-%GRADLE_VERSION%
set GRADLE_BIN=%BASE_DIR%\gradle-%GRADLE_VERSION%\bin\gradle.bat
if not exist "%GRADLE_BIN%" (
  if not exist "%BASE_DIR%" mkdir "%BASE_DIR%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$u='https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip'; $z='%BASE_DIR%\gradle-%GRADLE_VERSION%-bin.zip'; Invoke-WebRequest -UseBasicParsing $u -OutFile $z; Expand-Archive -Force $z '%BASE_DIR%'"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_BIN%" %*
