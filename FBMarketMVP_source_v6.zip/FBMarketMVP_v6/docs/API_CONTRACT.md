# Backend contract (next integration step)

The Android UI deliberately does not scrape Facebook directly. It expects normalized products from a backend/source adapter.

## Suggested endpoints

### `GET /v1/products`
Query parameters:
- `source=all|group|marketplace`
- `category`
- `q`
- `lat`
- `lng`
- `radiusKm`
- `cursor`

Response item shape:
```json
{
  "id": "source-stable-id",
  "source": "MARKETPLACE",
  "title": "Example product",
  "priceBaht": 19900,
  "category": "มือถือ",
  "sourceUrl": "https://...",
  "locationLabel": "มหาสารคาม",
  "latitude": 16.18,
  "longitude": 103.30,
  "createdAt": "2026-09-19T00:00:00+07:00"
}
```

### `GET /v1/groups`
Returns user-configured/authorized product sources.

### `POST /v1/alerts`
Creates a saved search using keywords, category, price and radius.

### `GET /v1/stream`
Use Server-Sent Events or WebSocket for normalized newly-arrived products. The backend, not the UI, owns source-specific collection logic.

## Deduplication
Prefer a stable `(source, sourceId)` key. Add fuzzy title/image/price matching only as a secondary layer.
