package com.okn.fbmarket.data

import com.okn.fbmarket.model.Product
import com.okn.fbmarket.model.ProductSource

private val demoProducts = listOf(
    Product(
        id = "m1",
        title = "iPhone 17 Pro 256GB",
        priceBaht = 31_900,
        category = "มือถือ",
        source = ProductSource.MARKETPLACE,
        locationLabel = "มหาสารคาม",
        latitude = 16.1850,
        longitude = 103.3008,
        postedMinutesAgo = 4,
        condition = "มือสอง - สภาพดีมาก",
        description = "เครื่องสภาพดี อุปกรณ์ครบ ใช้งานปกติ นัดรับและตรวจเครื่องก่อนซื้อได้"
    ),
    Product(
        id = "g1",
        title = "Samsung Galaxy S24",
        priceBaht = 18_500,
        category = "มือถือ",
        source = ProductSource.GROUP,
        groupName = "ซื้อขายมือถือ มหาสารคาม",
        locationLabel = "ตลาด มมส.",
        latitude = 16.2466,
        longitude = 103.2521,
        postedMinutesAgo = 8,
        condition = "มือสอง",
        description = "เครื่องไทย ใช้งานครบทุกฟังก์ชัน มีเคสและกล่อง"
    ),
    Product(
        id = "g2",
        title = "Yamaha NMAX 2024",
        priceBaht = 68_000,
        category = "มอเตอร์ไซค์",
        source = ProductSource.GROUP,
        groupName = "รถมือสอง มหาสารคาม",
        locationLabel = "กันทรวิชัย",
        latitude = 16.3272,
        longitude = 103.2982,
        postedMinutesAgo = 12,
        condition = "มือสอง",
        description = "รถเดิม เครื่องแน่น เอกสารครบ พร้อมโอน"
    ),
    Product(
        id = "m2",
        title = "MacBook Air M2",
        priceBaht = 28_500,
        category = "คอมพิวเตอร์",
        source = ProductSource.MARKETPLACE,
        locationLabel = "เมืองมหาสารคาม",
        latitude = 16.1764,
        longitude = 103.3030,
        postedMinutesAgo = 36,
        condition = "มือสอง",
        description = "RAM 8GB SSD 256GB แบตปกติ พร้อมที่ชาร์จ"
    ),
    Product(
        id = "m3",
        title = "โซฟา 3 ที่นั่ง สภาพดี",
        priceBaht = 4_900,
        category = "บ้านและสวน",
        source = ProductSource.MARKETPLACE,
        locationLabel = "แกดำ",
        latitude = 16.0208,
        longitude = 103.3845,
        postedMinutesAgo = 25,
        condition = "มือสอง",
        description = "โซฟาผ้าสภาพดี ไม่มีขาด นัดรับสินค้าได้"
    ),
    Product(
        id = "g3",
        title = "ทีวี LG 55 นิ้ว 4K",
        priceBaht = 12_500,
        category = "อิเล็กทรอนิกส์",
        source = ProductSource.GROUP,
        groupName = "ของมือสองสภาพดี มหาสารคาม",
        locationLabel = "บรบือ",
        latitude = 16.0437,
        longitude = 103.1191,
        postedMinutesAgo = 49,
        condition = "มือสอง",
        description = "จอปกติ รีโมตครบ ทดสอบก่อนรับได้"
    ),
    Product(
        id = "m4",
        title = "Toyota Corolla Altis",
        priceBaht = 359_000,
        category = "รถยนต์",
        source = ProductSource.MARKETPLACE,
        locationLabel = "โกสุมพิสัย",
        latitude = 16.2472,
        longitude = 103.0676,
        postedMinutesAgo = 67,
        condition = "มือสอง",
        description = "รถบ้าน เจ้าของขายเอง เอกสารพร้อมโอน"
    ),
    Product(
        id = "g4",
        title = "จักรยานไฟฟ้า",
        priceBaht = 8_900,
        category = "อื่น ๆ",
        source = ProductSource.GROUP,
        groupName = "ซื้อขายของใช้ มหาสารคาม",
        locationLabel = "วาปีปทุม",
        latitude = 15.8457,
        longitude = 103.3767,
        postedMinutesAgo = 90,
        condition = "มือสอง",
        description = "แบตยังดี มีที่ชาร์จ ทดลองขี่ได้"
    )
)

class MockMarketplaceAdapter : ProductSourceAdapter {
    override val source = ProductSource.MARKETPLACE
    override fun latest(): List<Product> = demoProducts.filter { it.source == source }
}

class MockGroupAdapter : ProductSourceAdapter {
    override val source = ProductSource.GROUP
    override fun latest(): List<Product> = demoProducts.filter { it.source == source }
}

object DemoData {
    val registry = SourceRegistry(listOf(MockMarketplaceAdapter(), MockGroupAdapter()))
    val groups = listOf(
        "ซื้อขายมือถือ มหาสารคาม",
        "รถมือสอง มหาสารคาม",
        "ของมือสองสภาพดี มหาสารคาม",
        "ซื้อขายของใช้ มหาสารคาม"
    )
}
