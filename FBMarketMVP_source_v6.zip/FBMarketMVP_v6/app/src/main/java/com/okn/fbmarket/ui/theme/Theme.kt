package com.okn.fbmarket.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val BrandBlue = Color(0xFF0B63CE)
private val BrandBlueDark = Color(0xFF084A9B)
private val Accent = Color(0xFF1677FF)

private val LightColors = lightColorScheme(
    primary = BrandBlue,
    secondary = Accent,
    tertiary = BrandBlueDark,
    surface = Color(0xFFFFFFFF),
    background = Color(0xFFF5F7FB)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF8AB9FF),
    secondary = Color(0xFFADC8FF)
)

@Composable
fun FBMarketTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content
    )
}
