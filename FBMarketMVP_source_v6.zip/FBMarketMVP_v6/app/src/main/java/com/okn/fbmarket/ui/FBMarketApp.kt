package com.okn.fbmarket.ui

import android.Manifest
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Chair
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Laptop
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.TwoWheeler
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.okn.fbmarket.data.DemoData
import com.okn.fbmarket.location.LocationController
import com.okn.fbmarket.location.UserLocation
import com.okn.fbmarket.location.distanceKm
import com.okn.fbmarket.model.Product
import com.okn.fbmarket.model.ProductSource
import kotlinx.coroutines.delay
import java.text.NumberFormat
import java.util.Locale

private enum class MainTab(val label: String, val icon: ImageVector) {
    HOME("หน้าแรก", Icons.Default.Home),
    GROUPS("กลุ่ม", Icons.Default.Groups),
    MARKETPLACE("Marketplace", Icons.Default.Storefront),
    SAVED("รายการโปรด", Icons.Default.Favorite),
    SETTINGS("ตั้งค่า", Icons.Default.Settings)
}

private val categories = listOf(
    "ทั้งหมด", "รถยนต์", "มอเตอร์ไซค์", "มือถือ", "คอมพิวเตอร์", "อิเล็กทรอนิกส์", "บ้านและสวน", "อื่น ๆ"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FBMarketApp() {
    val context = LocalContext.current
    val locationController = remember { LocationController(context) }
    val allProducts = remember { DemoData.registry.latestAll() }
    val savedIds = remember { mutableStateListOf<String>() }

    var tab by remember { mutableStateOf(MainTab.HOME) }
    var selectedProduct by remember { mutableStateOf<Product?>(null) }
    var showNotifications by remember { mutableStateOf(false) }
    var showFilter by remember { mutableStateOf(false) }
    var selectedCategory by remember { mutableStateOf("ทั้งหมด") }
    var query by remember { mutableStateOf("") }
    var radiusKm by remember { mutableStateOf(25f) }
    var radiusFilterEnabled by remember { mutableStateOf(false) }
    var userLocation by remember { mutableStateOf<UserLocation?>(null) }
    var locationAttempted by remember { mutableStateOf(false) }
    var refreshPulse by remember { mutableStateOf(0) }

    fun fetchLocation() {
        locationAttempted = true
        locationController.fetchCurrentLocation { userLocation = it }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        val granted = grants[Manifest.permission.ACCESS_COARSE_LOCATION] == true ||
            grants[Manifest.permission.ACCESS_FINE_LOCATION] == true
        if (granted) fetchLocation() else locationAttempted = true
    }

    LaunchedEffect(Unit) {
        if (locationController.hasCoarsePermission() || locationController.hasFinePermission()) {
            fetchLocation()
        }
        while (true) {
            delay(15_000)
            refreshPulse++
        }
    }

    if (selectedProduct != null) {
        ProductDetailScreen(
            product = selectedProduct!!,
            userLocation = userLocation,
            isSaved = selectedProduct!!.id in savedIds,
            onBack = { selectedProduct = null },
            onToggleSaved = {
                val id = selectedProduct!!.id
                if (id in savedIds) savedIds.remove(id) else savedIds.add(id)
            }
        )
        return
    }

    if (showNotifications) {
        NotificationsScreen(onBack = { showNotifications = false })
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            when (tab) {
                                MainTab.HOME -> "FB Market"
                                MainTab.GROUPS -> "สินค้าในกลุ่ม"
                                MainTab.MARKETPLACE -> "Marketplace"
                                MainTab.SAVED -> "รายการโปรด"
                                MainTab.SETTINGS -> "ตั้งค่า"
                            },
                            fontWeight = FontWeight.Bold
                        )
                        if (tab == MainTab.HOME) {
                            Text("สินค้าล่าสุดใกล้คุณ", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                },
                actions = {
                    if (tab != MainTab.SETTINGS) {
                        IconButton(onClick = { showNotifications = true }) {
                            Icon(Icons.Default.Notifications, contentDescription = "การแจ้งเตือน")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        },
        bottomBar = {
            NavigationBar {
                MainTab.entries.forEach { item ->
                    NavigationBarItem(
                        selected = tab == item,
                        onClick = { tab = item },
                        icon = { Icon(item.icon, contentDescription = item.label) },
                        label = { Text(item.label, maxLines = 1) }
                    )
                }
            }
        }
    ) { padding ->
        when (tab) {
            MainTab.HOME -> HomeScreen(
                modifier = Modifier.padding(padding),
                products = allProducts,
                userLocation = userLocation,
                query = query,
                selectedCategory = selectedCategory,
                radiusKm = radiusKm,
                radiusFilterEnabled = radiusFilterEnabled,
                refreshPulse = refreshPulse,
                onQueryChange = { query = it },
                onCategoryChange = { selectedCategory = it },
                onOpenFilter = { showFilter = true },
                onProductClick = { selectedProduct = it },
                isSaved = { it.id in savedIds },
                onToggleSaved = { p -> if (p.id in savedIds) savedIds.remove(p.id) else savedIds.add(p.id) },
                onRequestLocation = {
                    permissionLauncher.launch(
                        arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)
                    )
                },
                locationAttempted = locationAttempted
            )
            MainTab.GROUPS -> GroupsScreen(
                modifier = Modifier.padding(padding),
                products = DemoData.registry.latest(ProductSource.GROUP),
                userLocation = userLocation,
                onProductClick = { selectedProduct = it },
                isSaved = { it.id in savedIds },
                onToggleSaved = { p -> if (p.id in savedIds) savedIds.remove(p.id) else savedIds.add(p.id) }
            )
            MainTab.MARKETPLACE -> MarketplaceScreen(
                modifier = Modifier.padding(padding),
                products = DemoData.registry.latest(ProductSource.MARKETPLACE),
                userLocation = userLocation,
                onProductClick = { selectedProduct = it },
                isSaved = { it.id in savedIds },
                onToggleSaved = { p -> if (p.id in savedIds) savedIds.remove(p.id) else savedIds.add(p.id) }
            )
            MainTab.SAVED -> SavedScreen(
                modifier = Modifier.padding(padding),
                products = allProducts.filter { it.id in savedIds },
                userLocation = userLocation,
                onProductClick = { selectedProduct = it },
                onToggleSaved = { p -> savedIds.remove(p.id) }
            )
            MainTab.SETTINGS -> SettingsScreen(
                modifier = Modifier.padding(padding),
                userLocation = userLocation,
                radiusKm = radiusKm,
                onRadiusChange = { radiusKm = it },
                onRequestLocation = {
                    permissionLauncher.launch(
                        arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)
                    )
                }
            )
        }
    }

    if (showFilter) {
        FilterSheet(
            category = selectedCategory,
            radiusKm = radiusKm,
            radiusFilterEnabled = radiusFilterEnabled,
            onCategoryChange = { selectedCategory = it },
            onRadiusChange = { radiusKm = it },
            onRadiusFilterEnabledChange = { radiusFilterEnabled = it },
            onDismiss = { showFilter = false }
        )
    }
}

@Composable
private fun HomeScreen(
    modifier: Modifier,
    products: List<Product>,
    userLocation: UserLocation?,
    query: String,
    selectedCategory: String,
    radiusKm: Float,
    radiusFilterEnabled: Boolean,
    refreshPulse: Int,
    onQueryChange: (String) -> Unit,
    onCategoryChange: (String) -> Unit,
    onOpenFilter: () -> Unit,
    onProductClick: (Product) -> Unit,
    isSaved: (Product) -> Boolean,
    onToggleSaved: (Product) -> Unit,
    onRequestLocation: () -> Unit,
    locationAttempted: Boolean
) {
    val filtered = products.filter { product ->
        val matchesQuery = query.isBlank() || product.title.contains(query, ignoreCase = true) ||
            product.locationLabel.contains(query, ignoreCase = true)
        val matchesCategory = selectedCategory == "ทั้งหมด" || product.category == selectedCategory
        val distance = distanceKm(userLocation, product.latitude, product.longitude)
        val matchesRadius = !radiusFilterEnabled || distance == null || distance <= radiusKm
        matchesQuery && matchesCategory && matchesRadius
    }.sortedWith(
        compareBy<Product> { it.postedMinutesAgo }
            .thenBy { distanceKm(userLocation, it.latitude, it.longitude) ?: Double.MAX_VALUE }
    )

    Column(modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            OutlinedTextField(
                value = query,
                onValueChange = onQueryChange,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    IconButton(onClick = onOpenFilter) {
                        Icon(Icons.Default.Tune, contentDescription = "ตัวกรอง")
                    }
                },
                placeholder = { Text("ค้นหาสินค้า...") },
                shape = RoundedCornerShape(18.dp)
            )
            Spacer(Modifier.height(10.dp))
            LocationCard(
                userLocation = userLocation,
                radiusKm = radiusKm,
                radiusFilterEnabled = radiusFilterEnabled,
                locationAttempted = locationAttempted,
                onRequestLocation = onRequestLocation
            )
            Spacer(Modifier.height(10.dp))
            DemoNoticeCard(refreshPulse)
        }

        CategoryRow(selectedCategory, onCategoryChange)

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("สินค้าล่าสุด", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("${filtered.size} รายการ", color = MaterialTheme.colorScheme.primary)
        }

        if (filtered.isEmpty()) {
            EmptyState("ไม่พบสินค้าตามตัวกรองนี้")
        } else {
            ProductGrid(
                modifier = Modifier.fillMaxSize(),
                products = filtered,
                userLocation = userLocation,
                onProductClick = onProductClick,
                isSaved = isSaved,
                onToggleSaved = onToggleSaved
            )
        }
    }
}

@Composable
private fun DemoNoticeCard(refreshPulse: Int) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .55f)),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Outlined.Refresh, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(8.dp))
            Column {
                Text("DEMO DATA • โครงสร้างพร้อมต่อ Real-time API", fontWeight = FontWeight.SemiBold)
                Text(
                    "รีเฟรชสถานะทุก 15 วินาที • รอบ ${refreshPulse + 1}",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
private fun LocationCard(
    userLocation: UserLocation?,
    radiusKm: Float,
    radiusFilterEnabled: Boolean,
    locationAttempted: Boolean,
    onRequestLocation: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .55f)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.LocationOn, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    when {
                        userLocation != null && userLocation.isPrecise -> "ตำแหน่งปัจจุบัน • แม่นยำ"
                        userLocation != null -> "ตำแหน่งปัจจุบัน • โดยประมาณ"
                        locationAttempted -> "ยังไม่สามารถอ่านตำแหน่งได้"
                        else -> "ใช้ตำแหน่งเพื่อคำนวณระยะทาง"
                    },
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    if (radiusFilterEnabled) "กรองในรัศมี ${radiusKm.toInt()} กม."
                    else "แสดงสินค้าทุกระยะ • กรองระยะได้จากปุ่มตัวกรอง",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            if (userLocation == null) {
                OutlinedButton(onClick = onRequestLocation) { Text("เปิด") }
            }
        }
    }
}

@Composable
private fun CategoryRow(selected: String, onSelected: (String) -> Unit) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(categories) { category ->
            FilterChip(
                selected = selected == category,
                onClick = { onSelected(category) },
                label = { Text(category) }
            )
        }
    }
}

@Composable
private fun ProductGrid(
    modifier: Modifier,
    products: List<Product>,
    userLocation: UserLocation?,
    onProductClick: (Product) -> Unit,
    isSaved: (Product) -> Boolean,
    onToggleSaved: (Product) -> Unit
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = modifier,
        contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 18.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(products, key = { it.id }) { product ->
            ProductCard(
                product = product,
                userLocation = userLocation,
                isSaved = isSaved(product),
                onClick = { onProductClick(product) },
                onToggleSaved = { onToggleSaved(product) }
            )
        }
    }
}

@Composable
private fun ProductCard(
    product: Product,
    userLocation: UserLocation?,
    isSaved: Boolean,
    onClick: () -> Unit,
    onToggleSaved: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column {
            ProductArtwork(product)
            Column(Modifier.padding(10.dp)) {
                Row(verticalAlignment = Alignment.Top) {
                    Text(
                        product.title,
                        modifier = Modifier.weight(1f),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        fontWeight = FontWeight.SemiBold
                    )
                    IconButton(onClick = onToggleSaved, modifier = Modifier.size(30.dp)) {
                        Icon(
                            if (isSaved) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "บันทึก",
                            tint = if (isSaved) Color(0xFFE53935) else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Text(
                    "฿${formatNumber(product.priceBaht)}",
                    style = MaterialTheme.typography.titleMedium,
                    color = Color(0xFFE53935),
                    fontWeight = FontWeight.Bold
                )
                val km = distanceKm(userLocation, product.latitude, product.longitude)
                Text(
                    buildString {
                        append(if (km != null) "${formatDistance(km)} • " else "")
                        append(product.locationLabel)
                    },
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    "${product.source.label} • ${relativeTime(product.postedMinutesAgo)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun ProductArtwork(product: Product) {
    val colors = when (product.category) {
        "มือถือ" -> listOf(Color(0xFF102A43), Color(0xFF2F80ED))
        "คอมพิวเตอร์" -> listOf(Color(0xFF3D3D3D), Color(0xFF828282))
        "มอเตอร์ไซค์" -> listOf(Color(0xFF1D3557), Color(0xFFE63946))
        "รถยนต์" -> listOf(Color(0xFF33415C), Color(0xFF7D8597))
        "บ้านและสวน" -> listOf(Color(0xFF8D6E63), Color(0xFFD7CCC8))
        "อิเล็กทรอนิกส์" -> listOf(Color(0xFF512DA8), Color(0xFF0097A7))
        else -> listOf(Color(0xFF455A64), Color(0xFF90A4AE))
    }
    Box(
        modifier = Modifier.fillMaxWidth().aspectRatio(1.25f).background(Brush.linearGradient(colors)),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            categoryIcon(product.category),
            contentDescription = null,
            modifier = Modifier.size(54.dp),
            tint = Color.White.copy(alpha = .95f)
        )
        Surface(
            modifier = Modifier.align(Alignment.BottomStart).padding(8.dp),
            shape = RoundedCornerShape(50),
            color = Color.Black.copy(alpha = .45f)
        ) {
            Text(
                if (product.source == ProductSource.GROUP) "กลุ่ม" else "Marketplace",
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                color = Color.White,
                style = MaterialTheme.typography.labelSmall
            )
        }
    }
}

private fun categoryIcon(category: String): ImageVector = when (category) {
    "มือถือ" -> Icons.Default.PhoneAndroid
    "คอมพิวเตอร์" -> Icons.Default.Laptop
    "มอเตอร์ไซค์" -> Icons.Default.TwoWheeler
    "รถยนต์" -> Icons.Default.DirectionsCar
    "บ้านและสวน" -> Icons.Default.Chair
    "อิเล็กทรอนิกส์" -> Icons.Default.Tv
    else -> Icons.Default.Inventory2
}

@Composable
private fun GroupsScreen(
    modifier: Modifier,
    products: List<Product>,
    userLocation: UserLocation?,
    onProductClick: (Product) -> Unit,
    isSaved: (Product) -> Boolean,
    onToggleSaved: (Product) -> Unit
) {
    var selectedGroup by remember { mutableStateOf<String?>(null) }
    val visible = if (selectedGroup == null) products else products.filter { it.groupName == selectedGroup }

    Column(modifier.fillMaxSize()) {
        Text(
            "กลุ่มที่ติดตาม",
            modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 6.dp),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                FilterChip(
                    selected = selectedGroup == null,
                    onClick = { selectedGroup = null },
                    label = { Text("ทั้งหมด") }
                )
            }
            items(DemoData.groups) { group ->
                FilterChip(
                    selected = selectedGroup == group,
                    onClick = { selectedGroup = if (selectedGroup == group) null else group },
                    label = { Text(group, maxLines = 1) }
                )
            }
        }
        Text(
            "สินค้าล่าสุดจากกลุ่ม",
            modifier = Modifier.padding(16.dp, 12.dp, 16.dp, 8.dp),
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
        ProductGrid(
            modifier = Modifier.fillMaxSize(),
            products = visible,
            userLocation = userLocation,
            onProductClick = onProductClick,
            isSaved = isSaved,
            onToggleSaved = onToggleSaved
        )
    }
}

@Composable
private fun MarketplaceScreen(
    modifier: Modifier,
    products: List<Product>,
    userLocation: UserLocation?,
    onProductClick: (Product) -> Unit,
    isSaved: (Product) -> Boolean,
    onToggleSaved: (Product) -> Unit
) {
    var sortMode by remember { mutableStateOf("ใกล้ฉัน") }
    val visible = when (sortMode) {
        "ล่าสุด" -> products.sortedBy { it.postedMinutesAgo }
        "ราคา" -> products.sortedBy { it.priceBaht }
        else -> products.sortedBy { distanceKm(userLocation, it.latitude, it.longitude) ?: Double.MAX_VALUE }
    }

    Column(modifier.fillMaxSize()) {
        LazyRow(
            modifier = Modifier.padding(top = 12.dp),
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(listOf("ใกล้ฉัน", "ล่าสุด", "ราคา")) { sort ->
                FilterChip(
                    selected = sortMode == sort,
                    onClick = { sortMode = sort },
                    label = { Text(sort) }
                )
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(16.dp, 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.LocationOn, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(6.dp))
            Text(if (userLocation == null) "เปิดตำแหน่งเพื่อเรียงใกล้ฉัน" else "เรียงสินค้าโดยใช้ตำแหน่งอุปกรณ์")
        }
        ProductGrid(
            modifier = Modifier.fillMaxSize(),
            products = visible,
            userLocation = userLocation,
            onProductClick = onProductClick,
            isSaved = isSaved,
            onToggleSaved = onToggleSaved
        )
    }
}

@Composable
private fun SavedScreen(
    modifier: Modifier,
    products: List<Product>,
    userLocation: UserLocation?,
    onProductClick: (Product) -> Unit,
    onToggleSaved: (Product) -> Unit
) {
    if (products.isEmpty()) {
        Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.FavoriteBorder, contentDescription = null, modifier = Modifier.size(54.dp))
                Spacer(Modifier.height(10.dp))
                Text("ยังไม่มีรายการโปรด", style = MaterialTheme.typography.titleMedium)
                Text("กดรูปหัวใจที่สินค้าเพื่อบันทึกไว้")
            }
        }
    } else {
        ProductGrid(
            modifier = modifier.fillMaxSize(),
            products = products,
            userLocation = userLocation,
            onProductClick = onProductClick,
            isSaved = { true },
            onToggleSaved = onToggleSaved
        )
    }
}

@Composable
private fun SettingsScreen(
    modifier: Modifier,
    userLocation: UserLocation?,
    radiusKm: Float,
    onRadiusChange: (Float) -> Unit,
    onRequestLocation: () -> Unit
) {
    var darkModePreview by remember { mutableStateOf(false) }
    var notifyNew by remember { mutableStateOf(true) }

    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SectionCard("ตำแหน่ง") {
                SettingRow(
                    icon = Icons.Default.LocationOn,
                    title = if (userLocation == null) "ยังไม่ได้เปิดตำแหน่ง" else "ตำแหน่งพร้อมใช้งาน",
                    subtitle = if (userLocation?.isPrecise == true) "โหมดแม่นยำ" else "รองรับโหมดโดยประมาณ"
                )
                Spacer(Modifier.height(8.dp))
                Button(onClick = onRequestLocation, modifier = Modifier.fillMaxWidth()) {
                    Text(if (userLocation == null) "อนุญาตตำแหน่ง" else "อัปเดตสิทธิ์ตำแหน่ง")
                }
                Spacer(Modifier.height(12.dp))
                Text("รัศมีเริ่มต้น ${radiusKm.toInt()} กม.")
                Slider(value = radiusKm, onValueChange = onRadiusChange, valueRange = 5f..100f, steps = 18)
            }
        }
        item {
            SectionCard("การแจ้งเตือน") {
                ToggleSetting(
                    title = "สินค้าใหม่ตามเงื่อนไข",
                    subtitle = "เตรียมไว้สำหรับ FCM + Saved Search",
                    checked = notifyNew,
                    onCheckedChange = { notifyNew = it }
                )
            }
        }
        item {
            SectionCard("การแสดงผล") {
                ToggleSetting(
                    title = "โหมดมืด (ตัวอย่างสวิตช์)",
                    subtitle = "Theme จริงใช้ค่าระบบใน MVP นี้",
                    checked = darkModePreview,
                    onCheckedChange = { darkModePreview = it }
                )
            }
        }
        item {
            SectionCard("แหล่งข้อมูล") {
                Text("• Group adapter: DEMO")
                Text("• Marketplace adapter: DEMO")
                Spacer(Modifier.height(6.dp))
                Text(
                    "หน้าจอไม่ผูกกับ Facebook โดยตรง เพื่อให้เปลี่ยนไปใช้ backend/ผู้ให้บริการที่ได้รับอนุญาตได้",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable () -> Unit) {
    Card(shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun SettingRow(icon: ImageVector, title: String, subtitle: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(10.dp))
        Column {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun ToggleSetting(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FilterSheet(
    category: String,
    radiusKm: Float,
    radiusFilterEnabled: Boolean,
    onCategoryChange: (String) -> Unit,
    onRadiusChange: (Float) -> Unit,
    onRadiusFilterEnabledChange: (Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().padding(20.dp)) {
            Text("ตัวกรองสินค้า", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(16.dp))
            Text("หมวดหมู่", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(categories) { item ->
                    FilterChip(
                        selected = category == item,
                        onClick = { onCategoryChange(item) },
                        label = { Text(item) }
                    )
                }
            }
            Spacer(Modifier.height(20.dp))
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(Modifier.weight(1f)) {
                    Text("จำกัดระยะทาง", fontWeight = FontWeight.SemiBold)
                    Text(
                        if (radiusFilterEnabled) "ไม่เกิน ${radiusKm.toInt()} กม." else "ทุกระยะ",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Switch(checked = radiusFilterEnabled, onCheckedChange = onRadiusFilterEnabledChange)
            }
            Slider(
                value = radiusKm,
                onValueChange = onRadiusChange,
                valueRange = 5f..100f,
                steps = 18,
                enabled = radiusFilterEnabled
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("5 กม.", style = MaterialTheme.typography.labelSmall)
                Text("100 กม.", style = MaterialTheme.typography.labelSmall)
            }
            Spacer(Modifier.height(16.dp))
            Button(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text("ใช้ตัวกรอง") }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProductDetailScreen(
    product: Product,
    userLocation: UserLocation?,
    isSaved: Boolean,
    onBack: () -> Unit,
    onToggleSaved: () -> Unit
) {
    val context = LocalContext.current
    val distance = distanceKm(userLocation, product.latitude, product.longitude)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("รายละเอียดสินค้า") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "กลับ") }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            item { ProductArtwork(product) }
            item {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.Top) {
                        Column(Modifier.weight(1f)) {
                            Text(product.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                            Text(
                                "฿${formatNumber(product.priceBaht)}",
                                style = MaterialTheme.typography.headlineMedium,
                                color = Color(0xFFE53935),
                                fontWeight = FontWeight.Bold
                            )
                        }
                        IconButton(onClick = onToggleSaved) {
                            Icon(
                                if (isSaved) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                contentDescription = "บันทึก",
                                tint = if (isSaved) Color(0xFFE53935) else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    AssistChip(
                        onClick = {},
                        label = { Text(product.source.label) }
                    )
                    Spacer(Modifier.height(16.dp))
                    InfoLine(Icons.Default.LocationOn, "${product.locationLabel}${if (distance != null) " • ${formatDistance(distance)} จากคุณ" else ""}")
                    InfoLine(Icons.Default.Inventory2, "${product.condition} • ${relativeTime(product.postedMinutesAgo)}")
                    product.groupName?.let { InfoLine(Icons.Default.Groups, it) }
                    Spacer(Modifier.height(16.dp))
                    HorizontalDivider()
                    Spacer(Modifier.height(16.dp))
                    Text("รายละเอียด", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(product.description)
                    Spacer(Modifier.height(20.dp))
                    Button(
                        onClick = {
                            val uri = Uri.parse("geo:${product.latitude},${product.longitude}?q=${product.latitude},${product.longitude}(${Uri.encode(product.title)})")
                            context.startActivity(Intent(Intent.ACTION_VIEW, uri))
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Map, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("ดูตำแหน่งบนแผนที่")
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(
                        onClick = {
                            val url = if (product.source == ProductSource.MARKETPLACE) {
                                "https://www.facebook.com/marketplace/"
                            } else {
                                "https://www.facebook.com/groups/"
                            }
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.OpenInNew, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("เปิด Facebook (DEMO link)")
                    }
                }
            }
        }
    }
}

@Composable
private fun InfoLine(icon: ImageVector, text: String) {
    Row(Modifier.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(8.dp))
        Text(text)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NotificationsScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("การแจ้งเตือน") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "กลับ") }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Text("Saved Search (ตัวอย่าง)", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }
            items(
                listOf(
                    Triple("มือถือราคาไม่เกิน ฿20,000", "ภายใน 25 กม.", "พร้อมต่อ FCM"),
                    Triple("รถมือสอง", "ภายใน 50 กม.", "ยังไม่ได้เชื่อม backend"),
                    Triple("สินค้าจากกลุ่มที่ติดตาม", "ทันทีเมื่อมีรายการใหม่", "DEMO")
                )
            ) { item ->
                Card {
                    Column(Modifier.fillMaxWidth().padding(14.dp)) {
                        Text(item.first, fontWeight = FontWeight.SemiBold)
                        Text(item.second, style = MaterialTheme.typography.bodySmall)
                        Text(item.third, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyState(text: String) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

private fun formatNumber(value: Int): String = NumberFormat.getIntegerInstance(Locale("th", "TH")).format(value)

private fun formatDistance(km: Double): String = when {
    km < 1 -> "${(km * 1000).toInt()} ม."
    km < 10 -> String.format(Locale.US, "%.1f กม.", km)
    else -> "${km.toInt()} กม."
}

private fun relativeTime(minutes: Int): String = when {
    minutes < 60 -> "$minutes นาทีที่แล้ว"
    minutes < 24 * 60 -> "${minutes / 60} ชั่วโมงที่แล้ว"
    else -> "${minutes / (24 * 60)} วันที่แล้ว"
}
