package com.okn.fbmarket.model

enum class ProductSource(val label: String) {
    GROUP("กลุ่ม"),
    MARKETPLACE("Marketplace")
}

data class Product(
    val id: String,
    val title: String,
    val priceBaht: Int,
    val category: String,
    val source: ProductSource,
    val groupName: String? = null,
    val locationLabel: String,
    val latitude: Double,
    val longitude: Double,
    val postedMinutesAgo: Int,
    val condition: String,
    val description: String
)
