package com.okn.fbmarket

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.okn.fbmarket.ui.FBMarketApp
import com.okn.fbmarket.ui.theme.FBMarketTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FBMarketTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    FBMarketApp()
                }
            }
        }
    }
}
