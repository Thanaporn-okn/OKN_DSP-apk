package com.okn.fbmarket.data

import com.okn.fbmarket.model.Product
import com.okn.fbmarket.model.ProductSource

/**
 * UI depends on this boundary instead of Facebook directly.
 * A backend/approved provider can replace the mock adapters later without rewriting screens.
 */
interface ProductSourceAdapter {
    val source: ProductSource
    fun latest(): List<Product>
}

class SourceRegistry(adapters: List<ProductSourceAdapter>) {
    private val adaptersBySource = adapters.associateBy { it.source }

    fun latestAll(): List<Product> = adaptersBySource.values
        .flatMap { it.latest() }
        .sortedBy { it.postedMinutesAgo }

    fun latest(source: ProductSource): List<Product> =
        adaptersBySource[source]?.latest().orEmpty().sortedBy { it.postedMinutesAgo }
}
