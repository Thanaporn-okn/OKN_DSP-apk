package com.okn.fbmarket.location

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource

data class UserLocation(
    val latitude: Double,
    val longitude: Double,
    val isPrecise: Boolean
)

class LocationController(private val context: Context) {
    private val client = LocationServices.getFusedLocationProviderClient(context)

    fun hasCoarsePermission(): Boolean =
        context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun hasFinePermission(): Boolean =
        context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    fun fetchCurrentLocation(onResult: (UserLocation?) -> Unit) {
        if (!hasCoarsePermission() && !hasFinePermission()) {
            onResult(null)
            return
        }
        val priority = if (hasFinePermission()) {
            Priority.PRIORITY_HIGH_ACCURACY
        } else {
            Priority.PRIORITY_BALANCED_POWER_ACCURACY
        }
        val cancellation = CancellationTokenSource()
        client.getCurrentLocation(priority, cancellation.token)
            .addOnSuccessListener { location ->
                onResult(
                    location?.let {
                        UserLocation(
                            latitude = it.latitude,
                            longitude = it.longitude,
                            isPrecise = hasFinePermission()
                        )
                    }
                )
            }
            .addOnFailureListener { onResult(null) }
    }
}

fun distanceKm(user: UserLocation?, latitude: Double, longitude: Double): Double? {
    if (user == null) return null
    val result = FloatArray(1)
    Location.distanceBetween(user.latitude, user.longitude, latitude, longitude, result)
    return result[0] / 1000.0
}
