# OKN DSP V17 — Phase 1

V17 is built directly from **V16**, which itself keeps the requested V14 UI base. The discarded V15 redesign is not used.

## V17 UI refinement

- Replaced the plain Android **Theme** popup with a custom rounded OKN DSP dialog that matches the app UI.
- Theme choices now include title/subtitle copy, clear Light/Dark/Midnight rows, selected-state styling, and responsive width for phones/tablets.
- Replaced the plain Android **Preset name** popup with a custom rounded OKN DSP dialog.
- Preset dialog includes a styled name field, helper text, Cancel/Save actions, IME Done-to-save, and Light/Dark/Midnight-aware colors.
- No screenshot is used as a screen background; dialogs are native Android views drawn by code.

## Preserved from V16

- Bottom navigation has first priority for touch input over sliders.
- Tapping **Home / Mix / Eq** cannot adjust a hidden EQ Gain Band slider.
- Slider hit testing is limited to the visible content viewport above the navigation bar.
- V14 palette and behavior remain unchanged outside the two refined dialogs.
- Real-time persistence, presets, safe-area WindowInsets, EQ controls and graph behavior are preserved.

Version: **17.0.0** (`versionCode 1017`)
