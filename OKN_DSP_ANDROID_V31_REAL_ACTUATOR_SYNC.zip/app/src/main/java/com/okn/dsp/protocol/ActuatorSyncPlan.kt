package com.okn.dsp.protocol

data class SyncReadItem(
    val label: String,
    val actuatorId: Int,
    val offset: Int,
    val length: Int,
)

object ActuatorSyncPlan {
    val globalReads = listOf(
        SyncReadItem("MasterVolume", ConfirmedDspMap.MASTER_VOLUME, 0, 4),
        SyncReadItem("RemindSoundVolume", ConfirmedDspMap.REMIND_SOUND_VOLUME, 0, 4),
        SyncReadItem("BassVolume", ConfirmedDspMap.BASS_VOLUME, 0, 4),
        SyncReadItem("BassCutoff", ConfirmedDspMap.BASS_CUTOFF, 0, 4),
        SyncReadItem("BassBoost", ConfirmedDspMap.BASS_BOOST, 0, 4),
        SyncReadItem("MiddleBoost", ConfirmedDspMap.MIDDLE_BOOST, 0, 4),
        SyncReadItem("TrebleBoost", ConfirmedDspMap.TREBLE_BOOST, 0, 4),
    )

    val channelReads = ConfirmedDspMap.EQ_ACTUATOR_BY_CHANNEL.mapIndexed { i, id ->
        SyncReadItem("CH${i + 1} Biquad15", id, 0, ConfirmedDspMap.EQ_BAND_COUNT * ConfirmedDspMap.EQ_BAND_BYTES)
    }

    val allReads: List<SyncReadItem> = globalReads + channelReads

    fun encodedRequests(): List<ByteArray> = allReads.map { UfeCodec.encodeRead(it.actuatorId, it.offset, it.length) }

    /** CH3 reserves band 1 for BassCutoff/LPF. Other channels reserve band 1 ToneControl + band 2 MiddleBoost. */
    fun firstUserEqBand(channelIndex: Int): Int = if (channelIndex == 2) 2 else 3
    fun firstUserEqOffset(channelIndex: Int): Int = ConfirmedDspMap.eqBandOffset(firstUserEqBand(channelIndex))
}
