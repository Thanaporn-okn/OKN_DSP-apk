package com.okn.dsp.protocol

import org.json.JSONArray
import org.json.JSONObject

data class DspActuatorDescriptor(
    val id: Int,
    val type: Int,
    val name: String,
    val path: String,
    val description: String,
    val floatValue: Float? = null,
    val biquads: List<EqBand48> = emptyList(),
)

data class DspDeviceDescription(
    val name: String,
    val typeId: Int,
    val softwareRevision: Int,
    val hardwareRevision: Int,
    val sensorsCount: Int,
    val actuators: List<DspActuatorDescriptor>,
) {
    val actuatorById: Map<Int, DspActuatorDescriptor> = actuators.associateBy { it.id }

    fun globalFloat(id: Int): Float? = actuatorById[id]?.floatValue
    fun channelActuator(channelIndex: Int): DspActuatorDescriptor? = actuatorById[ConfirmedDspMap.eqActuator(channelIndex)]
}

object DeviceDescriptionCodec {
    const val BIQUAD_KEY = "UFE_TYPE_BIQUAD_CASCADE15_F"
    const val FLOAT_KEY = "UFE_TYPE_FLOAT32"

    fun parse(jsonText: String): DspDeviceDescription {
        val root = JSONObject(jsonText)
        val actuatorsArray = root.getJSONArray("actuators")
        val actuators = ArrayList<DspActuatorDescriptor>(actuatorsArray.length())

        for (i in 0 until actuatorsArray.length()) {
            val a = actuatorsArray.getJSONObject(i)
            val type = a.getInt("type")
            val floatValue = if (a.has(FLOAT_KEY)) a.optDouble(FLOAT_KEY).toFloat() else null
            val biquads = if (a.has(BIQUAD_KEY)) parseBiquads(a.getJSONArray(BIQUAD_KEY)) else emptyList()
            actuators += DspActuatorDescriptor(
                id = a.getInt("ID"),
                type = type,
                name = a.optString("name"),
                path = a.optString("path"),
                description = a.optString("desc"),
                floatValue = floatValue,
                biquads = biquads,
            )
        }

        return DspDeviceDescription(
            name = root.optString("name"),
            typeId = root.optInt("TypID"),
            softwareRevision = root.optInt("SRev"),
            hardwareRevision = root.optInt("HRev"),
            sensorsCount = root.optJSONArray("sensors")?.length() ?: 0,
            actuators = actuators,
        )
    }

    private fun parseBiquads(array: JSONArray): List<EqBand48> = buildList {
        for (i in 0 until array.length()) {
            val b = array.getJSONObject(i)
            add(
                EqBand48(
                    type = b.getInt("typ"),
                    frequency = b.optDouble("F").toFloat(),
                    frequency2 = b.optDouble("F2").toFloat(),
                    q = b.optDouble("Q").toFloat(),
                    boostDb = b.optDouble("B").toFloat(),
                    gain = b.optDouble("G").toFloat(),
                    r = b.optDouble("R").toFloat(),
                    b0 = b.optDouble("B0").toFloat(),
                    b1 = b.optDouble("B1").toFloat(),
                    b2 = b.optDouble("B2").toFloat(),
                    a1 = b.optDouble("A1").toFloat(),
                    a2 = b.optDouble("A2").toFloat(),
                )
            )
        }
    }
}

/**
 * Reassembles the decrypted UFE bulk response used for the JSON descriptor.
 * First chunk: 86 + length(3 bytes) + JSON. Continuations: 82 + JSON.
 */
class DeviceDescriptionAssembler {
    private val out = java.io.ByteArrayOutputStream()
    private var expectedLength: Int? = null
    var complete: Boolean = false
        private set

    fun reset() {
        out.reset()
        expectedLength = null
        complete = false
    }

    fun feedPlainPacket(packet: ByteArray): Boolean {
        if (packet.isEmpty()) return false
        when (packet[0].toInt() and 0xff) {
            0x86 -> {
                require(packet.size >= 4) { "descriptor first packet too short" }
                // Captured header is 86 E6 46 00 for 18150 bytes => little-endian 24-bit length.
                expectedLength = (packet[1].toInt() and 0xff) or
                    ((packet[2].toInt() and 0xff) shl 8) or
                    ((packet[3].toInt() and 0xff) shl 16)
                out.write(packet, 4, packet.size - 4)
            }
            UfeConstants.CONTINUE_BULK_SEND -> out.write(packet, 1, packet.size - 1)
            else -> return false
        }
        val need = expectedLength
        complete = need != null && out.size() >= need
        return complete
    }

    fun jsonBytes(): ByteArray {
        val need = expectedLength ?: error("descriptor length unknown")
        require(out.size() >= need) { "descriptor incomplete: ${out.size()}/$need" }
        return out.toByteArray().copyOf(need)
    }

    fun jsonText(): String = jsonBytes().toString(Charsets.UTF_8)
}
