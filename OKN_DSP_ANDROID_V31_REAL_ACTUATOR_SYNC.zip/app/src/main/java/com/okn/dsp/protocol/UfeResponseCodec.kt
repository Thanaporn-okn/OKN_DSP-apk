package com.okn.dsp.protocol

data class UfeReadResponse(
    val command: Int,
    val id: Int,
    val offset: Int,
    val length: Int,
    val data: ByteArray,
)

object UfeResponseCodec {
    fun decode(bytes: ByteArray): UfeReadResponse {
        require(bytes.size >= 9) { "UFE response must be at least 9 bytes" }
        val command = bytes[0].toInt() and 0xff
        require(command == UfeConstants.RESPONSE_READ_SENSOR_ACTUATOR_COMMAND) {
            "expected response 0x60, got 0x%02X".format(command)
        }
        val id = ByteCodec.readU32be(bytes, 1)
        val offset = ByteCodec.readU16be(bytes, 5)
        val length = ByteCodec.readU16be(bytes, 7)
        require(bytes.size >= 9 + length) { "response length=$length but bytes=${bytes.size - 9}" }
        return UfeReadResponse(command, id, offset, length, bytes.copyOfRange(9, 9 + length))
    }

    fun decodeFloat32(bytes: ByteArray): Pair<Int, Float> {
        val r = decode(bytes)
        require(r.length == 4) { "FLOAT32 response length must be 4" }
        return r.id to ByteCodec.readF32le(r.data, 0)
    }

    fun decodeBiquad15(bytes: ByteArray): Pair<Int, List<EqBand48>> {
        val r = decode(bytes)
        val expected = ConfirmedDspMap.EQ_BAND_COUNT * EqBandCodec.BYTES
        require(r.length == expected) { "Biquad15 response must be $expected bytes" }
        val bands = (0 until ConfirmedDspMap.EQ_BAND_COUNT).map { i ->
            val start = i * EqBandCodec.BYTES
            EqBandCodec.decode(r.data.copyOfRange(start, start + EqBandCodec.BYTES))
        }
        return r.id to bands
    }
}
