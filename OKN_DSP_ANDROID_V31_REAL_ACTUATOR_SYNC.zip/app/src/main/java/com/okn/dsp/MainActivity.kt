package com.okn.dsp

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import com.okn.dsp.protocol.WriteGate
import com.okn.dsp.protocol.ConfirmedDspMap
import com.okn.dsp.transport.BleProfile

class MainActivity : Activity() {
    private enum class Page { REAL_CONTROLS, EQ, SYNC, PRESET }

    private data class ChannelEq(
        val gainTenths: IntArray = IntArray(15)
    )

    private val channels = Array(7) { ChannelEq() }
    private val eqFreqs = intArrayOf(25, 40, 63, 100, 160, 250, 400, 630, 1000, 1600, 2500, 4000, 6300, 10000, 16000)
    private var selectedChannel = 0
    private var page = Page.REAL_CONTROLS
    private var pendingChanges = 0

    private lateinit var root: LinearLayout
    private lateinit var body: LinearLayout
    private lateinit var status: TextView
    private lateinit var channelSpinner: Spinner
    private lateinit var deviceList: LinearLayout

    private val handler = Handler(Looper.getMainLooper())
    private val found = LinkedHashMap<String, BluetoothDevice>()
    private var scanner: android.bluetooth.le.BluetoothLeScanner? = null
    private var gatt: BluetoothGatt? = null
    private var rxPackets = 0
    private var connectedName: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadLastState()
        buildUi()
        requestBlePermissions()
    }

    override fun onDestroy() {
        super.onDestroy()
        try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
        try { gatt?.close() } catch (_: Exception) {}
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 20, 22, 28)
        }

        root.addView(TextView(this).apply {
            text = "OKN DSP 7CH — V31 REAL ACTUATOR SYNC"
            textSize = 22f
        })

        status = TextView(this).apply {
            text = safeStatusText("DISCONNECTED")
            textSize = 14f
            setPadding(0, 8, 0, 10)
        }
        root.addView(status)

        val connectRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        connectRow.addView(Button(this).apply {
            text = "SCAN / CONNECT DSP"
            setOnClickListener { startScan() }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        connectRow.addView(Button(this).apply {
            text = "EVIDENCE LAB"
            setOnClickListener { startActivity(Intent(this@MainActivity, EvidenceLabActivity::class.java)) }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(connectRow)

        deviceList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(deviceList)

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(
            "REAL CONTROLS" to Page.REAL_CONTROLS,
            "EQ 7CH" to Page.EQ,
            "SYNC" to Page.SYNC,
            "PRESET" to Page.PRESET
        ).forEach { (label, target) ->
            tabs.addView(Button(this).apply {
                text = label
                setOnClickListener { page = target; renderPage() }
            })
        }
        root.addView(HorizontalScrollView(this).apply { addView(tabs) })

        val channelRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        channelRow.addView(TextView(this).apply {
            text = "EQ CHANNEL  "
            textSize = 16f
        })
        channelSpinner = Spinner(this)
        channelSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, (1..7).map { "CH$it" })
        channelSpinner.setSelection(selectedChannel)
        channelSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedChannel = position
                if (page == Page.EQ) renderPage()
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
        }
        channelRow.addView(channelSpinner, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(channelRow)

        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 12, 0, 12)
        }
        root.addView(body)

        root.addView(TextView(this).apply {
            text = "SAFE MODE: V31 เพิ่ม descriptor parser + actuator sync plan + RX decrypt engine แล้ว • response32↔RandKey จับคู่จริง 4 sessions • 20:45:55 request 5DFCB7E5 ถอดได้เป็น 661C0624 • เหลือ pre-auth RandKey transform/key/IV ก่อนปลด LIVE WRITE"
            textSize = 12f
        })

        setContentView(ScrollView(this).apply { addView(root) })
        renderPage()
    }

    private fun renderPage() {
        if (!::body.isInitialized) return
        body.removeAllViews()
        when (page) {
            Page.REAL_CONTROLS -> renderRealControls()
            Page.EQ -> renderEq(channels[selectedChannel])
            Page.SYNC -> renderSync()
            Page.PRESET -> renderPresets()
        }
    }

    private fun section(title: String, detail: String, confirmed: String = "CONFIRMED") {
        body.addView(TextView(this).apply {
            text = title
            textSize = 18f
            setPadding(0, 10, 0, 2)
        })
        body.addView(TextView(this).apply {
            text = "$detail\n[$confirmed]"
            textSize = 13f
            setPadding(0, 0, 0, 6)
        })
    }

    private fun renderRealControls() {
        body.addView(TextView(this).apply {
            text = "V31 • REAL ACTUATOR SYNC MODEL จาก descriptor + HCI + runtime log"
            textSize = 20f
            setPadding(0, 4, 0, 8)
        })
        section("1. ระดับเสียงหลัก", "Global ทุกช่อง • Actuator ID ${ConfirmedDspMap.MASTER_VOLUME}", "CONFIRMED ID=2")
        section("2. ระดับเสียงเตือนการเชื่อมต่อ", "Actuator ID ${ConfirmedDspMap.REMIND_SOUND_VOLUME} • OKN_DSP จะไม่ใช้", "OPTIONAL / OMIT")
        section("3. ระดับเสียงเบส", "Bass block อิสระ • Actuator ID ${ConfirmedDspMap.BASS_VOLUME}", "CONFIRMED ID=8")
        section("4. จุดตัดเสียงเบส", "Bass cutoff frequency • Actuator ID ${ConfirmedDspMap.BASS_CUTOFF}", "CONFIRMED ID=9")
        section("5. การเพิ่มเสียงเบส", "Bass Boost • Global • Actuator ID ${ConfirmedDspMap.BASS_BOOST}", "CONFIRMED ID=10")
        section("6. MiddleBoost", "Global • Actuator ID ${ConfirmedDspMap.MIDDLE_BOOST}", "CONFIRMED ID=13")
        section("7. การเพิ่มเสียงทรีเบิล", "Treble Boost • Global • Actuator ID ${ConfirmedDspMap.TREBLE_BOOST}", "CONFIRMED ID=11")
        section("8. Biquad15 / User PEQ", "CH1–CH7 แยกอิสระ • IDs 4,5,6,14,15,16,17 • 48 bytes/band • CH1/2/4/5/6/7 reserve Band1–2 • CH3 reserve Band1", "DESCRIPTOR VERIFIED")

        body.addView(TextView(this).apply {
            text = "PROTOCOL VERIFIED: WRITE=57 + ID(BE32)+offset(BE16)+len(BE16)+data • FLOAT32=LE • AES-CFB8 key=RandKey • TX IV=01×16 • stream ต่อเนื่อง\nSAME-SESSION VERIFIED: 20:45:55 response32 + RandKey + request4B อยู่ session เดียวกัน\nBLOCKER: ยังถอด RandKey จาก auth response 32B ด้วยอัลกอริทึมอิสระไม่ได้ → LIVE WRITE LOCKED"
            textSize = 13f
            setPadding(0, 10, 0, 10)
        })

        body.addView(Button(this).apply {
            text = "เปิด EQ 15-BAND แยก CH1–CH7"
            setOnClickListener { page = Page.EQ; renderPage() }
        })
        body.addView(Button(this).apply {
            text = "เปิด EVIDENCE LAB / CAPTURE"
            setOnClickListener { startActivity(Intent(this@MainActivity, EvidenceLabActivity::class.java)) }
        })
    }

    private fun renderEq(ch: ChannelEq) {
        body.addView(TextView(this).apply {
            text = "CH${selectedChannel + 1} • EQ 15-BAND • ACTUATOR ID ${ConfirmedDspMap.eqActuator(selectedChannel)}"
            textSize = 20f
            setPadding(0, 4, 0, 6)
        })
        val firstUserBand = com.okn.dsp.protocol.ActuatorSyncPlan.firstUserEqBand(selectedChannel)
        body.addView(TextView(this).apply {
            text = "48 bytes/band = type INT32 LE + 11×FLOAT32 LE • offset=(Band-1)×48 • Fs=44.1kHz • USER EQ starts Band$firstUserBand • reserved bands are locked"
            textSize = 13f
            setPadding(0, 0, 0, 8)
        })
        body.addView(Button(this).apply {
            text = "FLAT USER EQ CH${selectedChannel + 1} (LOCAL ONLY)"
            setOnClickListener {
                for (i in (firstUserBand - 1) until 15) ch.gainTenths[i] = 0
                changed()
                renderPage()
            }
        })
        val descriptorBands = try {
            val json = assets.open("device_description_204555.json").bufferedReader().use { it.readText() }
            com.okn.dsp.protocol.DeviceDescriptionCodec.parse(json).channelActuator(selectedChannel)?.biquads
        } catch (_: Exception) { null }
        (0 until 15).forEach { i ->
            val bandNo = i + 1
            val reserved = bandNo < firstUserBand
            val f = descriptorBands?.getOrNull(i)?.frequency ?: eqFreqs[i].toFloat()
            val typ = descriptorBands?.getOrNull(i)?.type
            val role = when {
                selectedChannel == 2 && bandNo == 1 -> "RESERVED • BASS LPF / BassCutoff"
                selectedChannel != 2 && bandNo == 1 -> "RESERVED • TONE CONTROL (Bass/Treble)"
                selectedChannel != 2 && bandNo == 2 -> "RESERVED • MiddleBoost"
                else -> "USER PEQ"
            }
            val label = TextView(this).apply {
                text = "BAND $bandNo • offset=${ConfirmedDspMap.eqBandOffset(bandNo)} • ${fmt(f.toDouble())} Hz • type=${typ ?: "?"} • $role   ${fmt(ch.gainTenths[i] / 10.0)} dB"
                textSize = 14f
            }
            body.addView(label)
            body.addView(SeekBar(this).apply {
                max = 240
                progress = ch.gainTenths[i] + 120
                isEnabled = !reserved
                setOnSeekBarChangeListener(simpleSeek { p ->
                    if (!reserved) {
                        ch.gainTenths[i] = p - 120
                        label.text = "BAND $bandNo • offset=${ConfirmedDspMap.eqBandOffset(bandNo)} • ${fmt(f.toDouble())} Hz • type=${typ ?: "?"} • $role   ${fmt(ch.gainTenths[i] / 10.0)} dB"
                        changed()
                    }
                })
            })
        }
    }

    private fun renderSync() {
        body.addView(TextView(this).apply {
            text = "V31 • REAL ACTUATOR SYNC / DIAGNOSTIC"
            textSize = 20f
            setPadding(0, 4, 0, 8)
        })
        body.addView(TextView(this).apply {
            text = "SYNC ENGINE READY หลังมี current-session RandKey • ตอนนี้ Live Sync ยัง LOCKED เพราะ RandKey derivation จาก auth response ยังไม่ verified"
            textSize = 13f
        })
        val run = Button(this).apply {
            text = "RUN CAPTURED SESSION SYNC SELF-TEST"
            setOnClickListener {
                try {
                    val json = assets.open("device_description_204555.json").bufferedReader().use { it.readText() }
                    val d = com.okn.dsp.protocol.DeviceDescriptionCodec.parse(json)
                    val lines = mutableListOf<String>()
                    lines += "DESCRIPTOR ${d.name} • type=${d.typeId} • sensors=${d.sensorsCount} • actuators=${d.actuators.size}"
                    val globals = listOf(2,3,8,9,10,13,11)
                    globals.forEach { id ->
                        val a = d.actuatorById[id]
                        lines += "ID$id ${a?.name} = ${a?.floatValue}"
                    }
                    for (ch in 0..6) {
                        val a = d.channelActuator(ch)
                        val first = com.okn.dsp.protocol.ActuatorSyncPlan.firstUserEqBand(ch)
                        val offset = com.okn.dsp.protocol.ActuatorSyncPlan.firstUserEqOffset(ch)
                        lines += "CH${ch+1} ID${a?.id} ${a?.biquads?.size ?: 0}/15 • USER EQ starts Band$first offset=$offset"
                    }
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("V31 SYNC SELF-TEST PASS")
                        .setMessage(lines.joinToString("\n"))
                        .setPositiveButton("OK", null)
                        .show()
                } catch (e: Exception) {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("SYNC SELF-TEST FAIL")
                        .setMessage(e.toString())
                        .setPositiveButton("OK", null)
                        .show()
                }
            }
        }
        body.addView(run)
        body.addView(TextView(this).apply {
            text = com.okn.dsp.protocol.ActuatorSyncPlan.allReads.joinToString("\n") {
                "READ ID${it.actuatorId} ${it.label} offset=${it.offset} len=${it.length}"
            }
            textSize = 12f
            setPadding(0, 10, 0, 0)
        })
    }

    private fun renderPresets() {
        body.addView(TextView(this).apply {
            text = "LOCAL EQ PRESETS"
            textSize = 18f
        })
        body.addView(TextView(this).apply {
            text = "เก็บ EQ 7CH บนมือถือเท่านั้น ยังไม่เขียนไป DSP"
            textSize = 13f
        })
        for (slot in 1..6) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(Button(this).apply {
                text = "LOAD P$slot"
                setOnClickListener {
                    if (loadPreset(slot)) {
                        Toast.makeText(this@MainActivity, "Loaded local P$slot", Toast.LENGTH_SHORT).show()
                        renderPage()
                    } else Toast.makeText(this@MainActivity, "P$slot is empty", Toast.LENGTH_SHORT).show()
                }
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(Button(this).apply {
                text = "SAVE P$slot"
                setOnClickListener {
                    savePreset(slot)
                    Toast.makeText(this@MainActivity, "Saved local P$slot", Toast.LENGTH_SHORT).show()
                }
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            body.addView(row)
        }
    }

    private fun changed() {
        pendingChanges++
        saveLastState()
        status.text = safeStatusText(connectedName?.let { "CONNECTED $it" } ?: "DISCONNECTED")
    }

    private fun safeStatusText(connection: String): String {
        val mode = if (WriteGate.enabled) "WRITE ENABLED" else "SAFE MODE • DSP PARAM WRITE LOCKED"
        return "$connection • RX=$rxPackets • local=$pendingChanges\n$mode"
    }

    private fun simpleSeek(block: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { if (fromUser) block(progress) }
        override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
        override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
    }

    private fun fmt(v: Double) = String.format(java.util.Locale.US, "%.2f", v)
    private fun formatFreq(v: Int) = if (v >= 1000) "${fmt(v / 1000.0)} kHz" else "$v Hz"

    private fun serialize(): String = channels.joinToString(";") { it.gainTenths.joinToString(":") }

    private fun deserialize(s: String) {
        val parts = s.split(";")
        for (i in 0 until minOf(7, parts.size)) {
            parts[i].split(":").take(15).forEachIndexed { j, v ->
                channels[i].gainTenths[j] = v.toIntOrNull()?.coerceIn(-120, 120) ?: channels[i].gainTenths[j]
            }
        }
    }

    private fun saveLastState() {
        getSharedPreferences("okn_dsp_v28", MODE_PRIVATE).edit().putString("last", serialize()).apply()
    }

    private fun loadLastState() {
        val s = getSharedPreferences("okn_dsp_v28", MODE_PRIVATE).getString("last", null) ?: return
        deserialize(s)
    }

    private fun savePreset(slot: Int) {
        getSharedPreferences("okn_dsp_v28", MODE_PRIVATE).edit().putString("preset_$slot", serialize()).apply()
    }

    private fun loadPreset(slot: Int): Boolean {
        val s = getSharedPreferences("okn_dsp_v28", MODE_PRIVATE).getString("preset_$slot", null) ?: return false
        deserialize(s)
        saveLastState()
        return true
    }

    private fun requestBlePermissions() {
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT), 100)
        }
    }

    private fun hasBlePermission(): Boolean =
        android.os.Build.VERSION.SDK_INT < 31 ||
            (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
             checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED)

    private fun startScan() {
        if (!hasBlePermission()) {
            requestBlePermissions()
            Toast.makeText(this, "อนุญาต Bluetooth แล้วกด Scan อีกครั้ง", Toast.LENGTH_SHORT).show()
            return
        }
        val adapter = getSystemService(BluetoothManager::class.java)?.adapter
        if (adapter == null || !adapter.isEnabled) {
            Toast.makeText(this, "กรุณาเปิด Bluetooth", Toast.LENGTH_SHORT).show()
            return
        }
        found.clear()
        deviceList.removeAllViews()
        status.text = safeStatusText("SCANNING")
        scanner = adapter.bluetoothLeScanner
        try { scanner?.startScan(scanCallback) } catch (_: SecurityException) { return }
        handler.postDelayed({
            try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
            status.text = safeStatusText(if (connectedName != null) "CONNECTED $connectedName" else "SCAN FINISHED")
        }, 10000)
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            val name = result.scanRecord?.deviceName ?: try { device.name } catch (_: SecurityException) { null }
            val relevant = name?.contains("GOLOPINE", true) == true || name?.contains("DSP", true) == true
            if (!relevant || found.containsKey(device.address)) return
            found[device.address] = device
            runOnUiThread {
                deviceList.addView(Button(this@MainActivity).apply {
                    text = "${name ?: "DSP"} • ${device.address}\nแตะเพื่อเชื่อมต่อ"
                    setOnClickListener { connect(device, name ?: "DSP") }
                })
            }
        }

        override fun onScanFailed(errorCode: Int) {
            runOnUiThread { status.text = safeStatusText("SCAN ERROR $errorCode") }
        }
    }

    private fun connect(device: BluetoothDevice, name: String) {
        if (!hasBlePermission()) return
        try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
        try { gatt?.close() } catch (_: Exception) {}
        status.text = safeStatusText("CONNECTING $name")
        try {
            gatt = device.connectGatt(this, false, object : BluetoothGattCallback() {
                override fun onConnectionStateChange(g: BluetoothGatt, statusCode: Int, newState: Int) {
                    if (newState == BluetoothProfile.STATE_CONNECTED) {
                        connectedName = name
                        runOnUiThread { status.text = safeStatusText("CONNECTED $name • DISCOVERING") }
                        try { g.discoverServices() } catch (_: SecurityException) {}
                    } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                        connectedName = null
                        runOnUiThread { status.text = safeStatusText("DISCONNECTED") }
                    }
                }

                override fun onServicesDiscovered(g: BluetoothGatt, statusCode: Int) {
                    if (statusCode != BluetoothGatt.GATT_SUCCESS) return
                    val service = g.getService(BleProfile.AB00_SERVICE)
                    val profile = if (service != null) "AB00/AB01/AB02/AB03" else "GENERIC"
                    val notifyChars = service?.let {
                        listOfNotNull(it.getCharacteristic(BleProfile.AB02_NOTIFY), it.getCharacteristic(BleProfile.AB03_NOTIFY))
                    } ?: emptyList()
                    runOnUiThread { status.text = safeStatusText("CONNECTED $name • PROFILE=$profile") }
                    notifyChars.forEachIndexed { index, ch -> handler.postDelayed({ subscribe(g, ch) }, (index * 700).toLong()) }
                }

                override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
                    rxPackets++
                    runOnUiThread { status.text = safeStatusText(connectedName?.let { "CONNECTED $it" } ?: "CONNECTED") }
                }
            }, BluetoothDevice.TRANSPORT_LE)
        } catch (_: SecurityException) {
            status.text = safeStatusText("CONNECT PERMISSION ERROR")
        }
    }

    private fun subscribe(g: BluetoothGatt, ch: BluetoothGattCharacteristic) {
        if (!hasBlePermission()) return
        try {
            g.setCharacteristicNotification(ch, true)
            val cccd = ch.getDescriptor(java.util.UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")) ?: return
            val v = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            if (android.os.Build.VERSION.SDK_INT >= 33) g.writeDescriptor(cccd, v)
            else {
                @Suppress("DEPRECATION") cccd.value = v
                @Suppress("DEPRECATION") g.writeDescriptor(cccd)
            }
        } catch (_: Exception) {}
    }
}
