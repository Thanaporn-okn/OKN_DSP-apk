OKN DSP ANDROID V31 — REAL ACTUATOR SYNC

What is new
- Parses the full 18,150-byte captured Device Description JSON.
- Confirms 15 actuators / 4 sensors and dynamic actuator values.
- Adds continuous SessionRxCipher (AES-CFB8, key=RandKey, IV=01 x16).
- Adds DeviceDescriptionAssembler for plaintext 0x86 + 0x82 bulk chunks.
- Adds UFE 0x60 response decoder for FLOAT32 and Biquad15.
- Adds ActuatorSyncPlan for IDs 2,3,8,9,10,13,11 and CH IDs 4,5,6,14,15,16,17.
- Adds SYNC tab with captured-session ground-truth self-test.
- Corrects user-EQ reserved bands:
  CH1/2/4/5/6/7: Band1 ToneControl, Band2 MiddleBoost, user EQ starts Band3 (offset 96).
  CH3: Band1 Bass LPF/BassCutoff, user EQ starts Band2 (offset 48).

Captured ground truth (20:45:55)
MasterVolume=1.840005
RemindSoundVolume=-70.0
BassVolume=-31.64001
BassCutoff=117.300003
BassBoost=7.8
MiddleBoost=12.000015
TrebleBoost=11.520011

Safety state
LIVE PARAMETER WRITE remains locked.
Reason: the current-session RandKey derivation from the 32-byte pre-auth response is not independently verified yet.
V31 has the read/sync layers after RandKey ready, and validates them against the real captured session.
