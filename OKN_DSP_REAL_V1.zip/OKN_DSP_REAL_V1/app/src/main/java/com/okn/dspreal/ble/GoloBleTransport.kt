package com.okn.dspreal.ble

import android.annotation.SuppressLint
import android.bluetooth.*
import android.content.Context
import android.os.Build

@SuppressLint("MissingPermission")
class GoloBleTransport(
    private val context: Context,
    private val listener: Listener,
) {
    interface Listener {
        fun onState(text: String)
        fun onReady()
        fun onNotify(bytes: ByteArray)
    }

    private var gatt: BluetoothGatt? = null
    private var writeChar: BluetoothGattCharacteristic? = null
    private var notifyChar: BluetoothGattCharacteristic? = null

    fun connect(device: BluetoothDevice) {
        close()
        listener.onState("CONNECTING ${device.address}")
        gatt = device.connectGatt(context, false, callback, BluetoothDevice.TRANSPORT_LE)
    }

    fun close() {
        try { gatt?.disconnect() } catch (_: Exception) {}
        try { gatt?.close() } catch (_: Exception) {}
        gatt = null
        writeChar = null
        notifyChar = null
    }

    fun writeNoResponse(bytes: ByteArray): Boolean {
        val g = gatt ?: return false
        val ch = writeChar ?: return false
        return if (Build.VERSION.SDK_INT >= 33) {
            g.writeCharacteristic(ch, bytes, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE) == BluetoothStatusCodes.SUCCESS
        } else {
            @Suppress("DEPRECATION") ch.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
            @Suppress("DEPRECATION") ch.value = bytes
            @Suppress("DEPRECATION") g.writeCharacteristic(ch)
        }
    }

    private val callback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                listener.onState("GATT ERROR status=$status")
                return
            }
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                listener.onState("CONNECTED • DISCOVERING AB00")
                g.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                listener.onState("DISCONNECTED")
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                listener.onState("DISCOVERY ERROR $status")
                return
            }
            val s = g.getService(BleProfile.SERVICE)
            if (s == null) {
                listener.onState("AB00 SERVICE NOT FOUND")
                return
            }
            writeChar = s.getCharacteristic(BleProfile.WRITE)
            notifyChar = s.getCharacteristic(BleProfile.NOTIFY)
            if (writeChar == null || notifyChar == null) {
                listener.onState("AB01/AB02 NOT FOUND")
                return
            }
            val ch = notifyChar!!
            g.setCharacteristicNotification(ch, true)
            val cccd = ch.getDescriptor(BleProfile.CCCD)
            if (cccd == null) {
                listener.onState("AB02 CCCD NOT FOUND")
                return
            }
            val ok = if (Build.VERSION.SDK_INT >= 33) {
                g.writeDescriptor(cccd, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE) == BluetoothStatusCodes.SUCCESS
            } else {
                @Suppress("DEPRECATION") cccd.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                @Suppress("DEPRECATION") g.writeDescriptor(cccd)
            }
            if (!ok) listener.onState("FAILED TO ENABLE AB02 NOTIFY")
        }

        override fun onDescriptorWrite(g: BluetoothGatt, descriptor: BluetoothGattDescriptor, status: Int) {
            if (descriptor.uuid == BleProfile.CCCD && status == BluetoothGatt.GATT_SUCCESS) {
                listener.onState("READY • AB01 WRITE / AB02 NOTIFY")
                listener.onReady()
            }
        }

        @Deprecated("Deprecated in API 33")
        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            @Suppress("DEPRECATION") val value = characteristic.value ?: return
            listener.onNotify(value.copyOf())
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            listener.onNotify(value.copyOf())
        }
    }
}
