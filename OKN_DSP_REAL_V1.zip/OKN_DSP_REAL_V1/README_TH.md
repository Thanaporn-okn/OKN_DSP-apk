# OKN DSP REAL V1 — เริ่มนับ 1 ใหม่

โครงการ Android/Kotlin ใหม่ที่ตัดโค้ดทดลองเก่าออก และเก็บเฉพาะส่วนที่มีหลักฐานจาก HCI + runtime log + descriptor/protocol mapping

## สิ่งที่แอป V1 ทำจริง

- Scan/Connect BLE DSP
- ใช้ Service `0000AB00-0000-1000-8000-00805F9B34FB`
- Write ที่ `AB01` ด้วย WRITE_NO_RESPONSE (ตรงกับ ATT Write Command `0x52` ที่จับได้)
- Notify จาก `AB02`
- ส่ง auth request จริง `631C062443FD3844558001F3EDA0CCF8`
- รับ auth response 32 bytes และแสดง TypeID/VersionID
- รับ RandKey 16 bytes ของ session ปัจจุบัน แล้วสร้าง AES/CFB8/NoPadding
- Key = RandKey, IV = `01` x16, TX cipher state ต่อเนื่องทั้ง session
- ส่ง device-description request plaintext `661C0624` หลังเข้ารหัส
- ส่ง UFE READ `0x58` และ WRITE `0x57` จริง
- เขียน Master Volume ID 2
- เขียน scalar IDs ที่ map แล้ว: 8/9/10/11/13
- เขียน EQ CH1..CH7 IDs 4,5,6,14,15,16,17 แบบ 48 bytes/band
- สร้าง Peaking EQ ด้วย Fs=44.1 kHz และโครงสร้าง coefficient ที่ตรง capture
- มีปุ่ม replay plaintext ที่ถอดมาจาก capture จริง 4 ชุด

## ข้อจำกัดเดียวที่ยังไม่ปิด

การแปลง auth response 32 bytes -> RandKey 16 bytes โดยอัตโนมัติยังไม่ได้ยืนยันสูตรจาก binary ดังนั้น V1 **ไม่เดา key** และให้กรอก RandKey ของ session ปัจจุบันก่อนเปิด encrypted TX.

นี่เป็นข้อจำกัดของ authentication bootstrap ไม่ใช่ UFE/DSP serializer: หลังมี RandKey แล้ว packet path ที่ใช้ใน V1 คือเส้นทางจริงที่ยืนยันจาก traffic แอปทางการ.

## คำสั่ง plaintext ที่ยืนยัน

```text
AUTH raw (unencrypted)
631C062443FD3844558001F3EDA0CCF8

Device Description plaintext (first encrypted TX)
661C0624

READ master volume ID=2, offset=0, len=4
580000000200000004

WRITE master -13.76 (captured)
570000000200000004F6285CC1

WRITE format
57 + actuatorId(u32 BE) + offset(u16 BE) + length(u16 BE) + payload

READ format
58 + actuatorId(u32 BE) + offset(u16 BE) + length(u16 BE)
```

## EQ map

```text
CH1 ID=4
CH2 ID=5
CH3 ID=6
CH4 ID=14
CH5 ID=15
CH6 ID=16
CH7 ID=17
Band offset = (band - 1) * 48
15 bands/channel
```

## Build

ใช้ไฟล์ workflow ที่ส่งแยก: `build-okn-dsp-real-v1.yml`
