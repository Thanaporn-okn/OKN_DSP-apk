# OKN_DSP BP1048P4 V13

Next step:
- CH1-CH7 channel structure
- Separate channel values
- Volume/EQ/Delay/HPF/LPF command framework
- Preset structure preparation

This package is prepared for GitHub Actions upload.
