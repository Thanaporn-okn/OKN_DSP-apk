#!/usr/bin/env python3
import argparse, csv, io, json, math, statistics, zipfile
from collections import Counter, defaultdict
from datetime import datetime

def read_member(z, name):
    return io.TextIOWrapper(z.open(name), encoding="utf-8")

def load_artifact(path):
    with zipfile.ZipFile(path) as z:
        names=set(z.namelist())
        base="analysis/"
        tx=[]
        rx=[]
        att=[]
        if base+"ab01_tx.csv" in names:
            tx=list(csv.DictReader(read_member(z, base+"ab01_tx.csv")))
        if base+"ab02_ab03_rx.csv" in names:
            rx=list(csv.DictReader(read_member(z, base+"ab02_ab03_rx.csv")))
        if base+"att_all.csv" in names:
            att=list(csv.DictReader(read_member(z, base+"att_all.csv")))
    return tx,rx,att

def parse_ts(s):
    return datetime.fromisoformat(s.replace("Z","+00:00"))

def bhex(s):
    return bytes.fromhex(s)

def entropy(bs):
    if not bs: return 0.0
    c=Counter(bs); n=len(bs)
    return -sum((v/n)*math.log2(v/n) for v in c.values())

def hamming(a,b):
    n=min(len(a),len(b))
    bits=sum((x^y).bit_count() for x,y in zip(a[:n],b[:n]))
    return bits, len(a), len(b)

def pair_tx_rx(att, window=0.20):
    rows=[]
    for r in att:
        if not r.get("value_hex"): continue
        if r.get("direction")!="TX" or r.get("handle")!="0x0006": continue
        t=parse_ts(r["timestamp_utc"])
        best=None
        for q in att:
            if not q.get("value_hex") or q.get("direction")!="RX" or q.get("handle")!="0x0008": continue
            tq=parse_ts(q["timestamp_utc"])
            d=(tq-t).total_seconds()
            if 0 <= d <= window:
                best=q; break
        if best:
            rows.append((r,best,(parse_ts(best["timestamp_utc"])-t).total_seconds()))
    return rows

def analyze(tx, rx, att, label):
    out=[]
    out.append(f"# OKN DSP HCI Analyzer V2 — {label}\n")
    out.append("## Safety\nAnalysis-only. No BLE/DSP payloads are generated or sent.\n")
    out.append(f"- AB01 writes: {len(tx)}")
    out.append(f"- AB02/AB03 notifications: {len(rx)}")
    if tx:
        out.append("- TX lengths: " + ", ".join(f"{k}:{v}" for k,v in sorted(Counter(int(x['value_len']) for x in tx).items())))
    if rx:
        out.append("- RX lengths: " + ", ".join(f"{k}:{v}" for k,v in sorted(Counter(int(x['value_len']) for x in rx).items())))
    # intervals
    tx9=sorted([parse_ts(x["timestamp_utc"]) for x in tx if int(x["value_len"])==9])
    if len(tx9)>2:
        ints=[(b-a).total_seconds() for a,b in zip(tx9,tx9[1:])]
        out.append(f"- 9-byte TX interval median: {statistics.median(ints):.4f}s")
        out.append(f"- 9-byte TX interval min/max: {min(ints):.4f}s / {max(ints):.4f}s")
    # entropy and uniqueness
    for L in sorted(set(int(x["value_len"]) for x in tx)):
        vals=[bhex(x["value_hex"]) for x in tx if int(x["value_len"])==L]
        if vals:
            out.append(f"- TX {L}-byte mean byte-entropy: {statistics.mean(entropy(v) for v in vals):.3f} bits/byte; unique {len(set(vals))}/{len(vals)}")
    pairs=pair_tx_rx(att)
    out.append(f"- TX→RX pairs within 200 ms: {len(pairs)}")
    if pairs:
        delays=[d for _,_,d in pairs]
        out.append(f"- Pair delay median: {statistics.median(delays)*1000:.1f} ms")
        out.append("\n## First 25 paired records\n")
        out.append("|#|TX|RX|delay ms|")
        out.append("|---:|---|---|---:|")
        for i,(a,b,d) in enumerate(pairs[:25]):
            out.append(f"|{i}|`{a['value_hex']}`|`{b['value_hex'][:80]}{'…' if len(b['value_hex'])>80 else ''}`|{d*1000:.1f}|")
    return "\n".join(out), pairs

def write_csv(path, pairs):
    with open(path,"w",newline="",encoding="utf-8") as f:
        w=csv.writer(f)
        w.writerow(["pair_index","tx_timestamp","tx_len","tx_hex","rx_timestamp","rx_len","rx_hex","delay_ms"])
        for i,(a,b,d) in enumerate(pairs):
            w.writerow([i,a["timestamp_utc"],a["value_len"],a["value_hex"],b["timestamp_utc"],b["value_len"],b["value_hex"],f"{d*1000:.3f}"])

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--input",required=True)
    ap.add_argument("--output",required=True)
    args=ap.parse_args()
    tx,rx,att=load_artifact(args.input)
    report,pairs=analyze(tx,rx,att,args.input)
    import os
    os.makedirs(args.output,exist_ok=True)
    open(os.path.join(args.output,"REPORT_V2.md"),"w",encoding="utf-8").write(report+"\n")
    write_csv(os.path.join(args.output,"tx_rx_pairs_200ms.csv"),pairs)
    json.dump({"ab01_writes":len(tx),"notifications":len(rx),"pairs_200ms":len(pairs)},
              open(os.path.join(args.output,"summary_v2.json"),"w",encoding="utf-8"),indent=2)
if __name__=="__main__": main()
