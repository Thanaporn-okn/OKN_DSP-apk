# OKN DSP HCI Analyzer V2

## เป้าหมาย
วิเคราะห์ traffic จาก BTSnoop/HCI ที่แยกด้วย V1 โดยเน้นความสัมพันธ์ `AB01 TX -> AB02 RX`
โดยไม่เดา command และไม่ส่ง packet ใด ๆ ไปยัง DSP

## ผลจาก capture ปัจจุบัน
V1 พบ:
- AB01 writes: 124
- AB02/AB03 notifications: 196
- TX 9-byte: 117
- RX 235-byte: 77
- RX 10-byte: 58
- RX 13-byte: 58

V2 จะสร้าง:
- `REPORT_V2.md`
- `tx_rx_pairs_200ms.csv`
- `summary_v2.json`

## ขั้นต่อไปของ reverse engineering
ต้องทำ capture แบบควบคุม โดยใช้แอป DSP เดิม:
1. เปิด HCI Snoop
2. เริ่ม capture ใหม่ก่อนเปิด/เชื่อมต่อ DSP
3. เปลี่ยนค่าเพียง 1 ค่า เช่น EQ band เดียว 0 -> +1 dB
4. รอ 2-3 วินาที
5. เปลี่ยนกลับ 0 dB
6. หยุด capture
7. ส่งไฟล์ capture ใหม่มา

ห้ามเปลี่ยนหลายค่าใน capture เดียว เพราะจะทำให้ระบุ field ไม่ได้

## หลักฐานที่ยังไม่ถือเป็นข้อสรุป
ข้อมูล 9-byte TX ที่ดูสุ่มและ notification 235-byte ที่ดูสุ่ม ยังไม่พอที่จะสรุปว่าเป็น encryption/checksum หรือรูปแบบ coefficient ใด ๆ
