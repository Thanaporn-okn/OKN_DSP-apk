package com.okn.dsp
import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.widget.*

class MainActivity: Activity(){
 override fun onCreate(b:Bundle?){
  super.onCreate(b)
  val root=LinearLayout(this)
  root.orientation=LinearLayout.VERTICAL
  root.setBackgroundColor(Color.BLACK)
  val title=TextView(this)
  title.text="Connected\nBP1048P4 7CH DSP   FW:1.2.6\n\nMaster Volume"
  title.textSize=22f
  title.setTextColor(Color.WHITE)
  root.addView(title)
  for(i in 1..7){
   val t=TextView(this)
   t.text="CH$i  ${arrayOf("Front L","Front R","SUB","Rear L","Rear R","AUX L","AUX R")[i-1]}"
   t.setTextColor(Color.WHITE)
   t.textSize=20f
   root.addView(t)
   val s=SeekBar(this)
   root.addView(s)
   val m=Button(this)
   m.text="MUTE"
   root.addView(m)
  }
  val menu=TextView(this)
  menu.text="MAIN   EQ   CROSSOVER   DELAY   MIXER   PRESET   SETTINGS"
  menu.setTextColor(Color.WHITE)
  menu.textSize=18f
  root.addView(menu)
  setContentView(root)
 }
}