package com.okn.dsp

import android.Manifest
import android.app.Activity
import android.bluetooth.*
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import com.okn.dsp.transport.BleProfile
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private val ts = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    private val prefs by lazy { getSharedPreferences("okn_dsp_v15", MODE_PRIVATE) }

    private lateinit var status: TextView
    private lateinit var deviceList: LinearLayout
    private lateinit var logView: TextView

    private var scanner: BluetoothLeScanner? = null
    private var gatt: BluetoothGatt? = null
    private val found = LinkedHashMap<String, BluetoothDevice>()
    private val notifyQueue = ArrayDeque<BluetoothGattCharacteristic>()
    private val readableQueue = ArrayDeque<BluetoothGattCharacteristic>()
    private var descriptorWriteInProgress = false

    private val captureLines = mutableListOf<String>()
    private val logLines = StringBuilder()
    private var packetNo = 0
    private var sessionNo = 0

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        buildUi()
        requestBlePermissions()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(28))
        }

        root.addView(TextView(this).apply {
            text = "OKN DSP Controller"
            textSize = 26f
            setTypeface(typeface, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "V15 • VERIFIED UFE MAP + AES-CFB8 TRANSPORT LAB"
            textSize = 13f
        })

        status = TextView(this).apply {
            text = "READY — CONTROL MAP VERIFIED • SESSION AUTH KEY STILL LOCKED"
            textSize = 14f
            setPadding(0, dp(10), 0, dp(10))
            setTypeface(typeface, Typeface.BOLD)
        }
        root.addView(status)

        root.addView(sectionTitle("ควบคุม DSP — ค่าจริงจาก Device Descriptor"))
        root.addView(rangeSlider(DspParameter.MASTER_VOLUME, -70, 6, -40, "dB"))
        root.addView(rangeSlider(DspParameter.BASS_LEVEL, -70, 6, -40, "dB"))
        root.addView(rangeSlider(DspParameter.BASS_CROSSOVER, 20, 250, 100, "Hz", "Actuator ID 9 • scale=log ตาม descriptor"))

        root.addView(sectionTitle("Boost รวมทุก CH"))
        root.addView(rangeSlider(DspParameter.BASS_BOOST, -12, 12, 0, "dB"))
        root.addView(rangeSlider(DspParameter.MIDDLE_BOOST, -12, 12, -1, "dB"))
        root.addView(rangeSlider(DspParameter.TREBLE_BOOST, -12, 12, 0, "dB"))

        root.addView(sectionTitle("Gain แยก 7 CH — UI พร้อม / mapping gain ยังไม่ยืนยัน"))
        root.addView(TextView(this).apply {
            text = "Device Descriptor ไม่มี actuator Gain แยกแบบ float32 โดยตรง แต่พบ BiquadCascade CH1–CH7 ที่ ID 4,5,6,14,15,16,17 ดังนั้น V15 ยังไม่ส่ง Gain CH เพื่อไม่เดาค่า DSP"
            textSize = 12f
            setPadding(0, 0, 0, dp(8))
        })
        listOf(
            DspParameter.CH1_GAIN, DspParameter.CH2_GAIN, DspParameter.CH3_GAIN,
            DspParameter.CH4_GAIN, DspParameter.CH5_GAIN, DspParameter.CH6_GAIN,
            DspParameter.CH7_GAIN
        ).forEach { root.addView(rangeSlider(it, -70, 6, 0, "dB", "LOCAL UI ONLY")) }

        root.addView(sectionTitle("Protocol verification"))
        root.addView(TextView(this).apply {
            text = "VERIFIED: AB01=TX Write Command • AB02=RX Notify • UFE 0x57 float write • UFE 0x58 read • 0x60 response • AES-128 CFB8 • IV=01×16 • MTU≈517. เหลือการถอด session RandKey จาก authentication response ก่อนเปิด DSP WRITE จริง"
            textSize = 12f
            setPadding(0, 0, 0, dp(8))
        })

        val reset = Button(this).apply {
            text = "RESET UI VALUES"
            isAllCaps = false
            setOnClickListener {
                prefs.edit().clear().apply()
                toast("รีเซ็ตค่า UI แล้ว — เปิดหน้าใหม่เพื่อโหลดค่าเริ่มต้น")
            }
        }
        root.addView(reset)

        root.addView(sectionTitle("Bluetooth / Capture Lab"))
        root.addView(TextView(this).apply {
            text = "ข้อมูลจาก bugreport ยืนยันแล้ว: AB01=TX, AB02=RX, UFE 0x57/0x58/0x60, AES-CFB8 IV=01×16 และ actuator IDs จริง. V15 ยังไม่ส่ง parameter เพราะ RandKey เป็น session key ใหม่ทุก connection"
            textSize = 12f
            setPadding(0, 0, 0, dp(8))
        })

        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(actionButton("SCAN DSP") { startScan() })
        row1.addView(actionButton("DISCONNECT") { disconnectGatt() })
        root.addView(row1)

        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(actionButton("SAVE CAPTURE") { shareCapture() })
        row2.addView(actionButton("ANALYZE") { analyzeCapture() })
        root.addView(row2)

        val row3 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row3.addView(actionButton("CLEAR LOG") {
            synchronized(captureLines) { captureLines.clear() }
            logLines.clear()
            logView.text = "Log:\n"
        })
        row3.addView(actionButton("APP SETTINGS") { openAppSettings() })
        root.addView(row3)

        deviceList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(6), 0, dp(8))
        }
        root.addView(deviceList)

        logView = TextView(this).apply {
            text = "Log:\n"
            textSize = 11f
            setTextIsSelectable(true)
            setPadding(0, dp(8), 0, 0)
        }
        root.addView(logView)

        setContentView(ScrollView(this).apply {
            isFillViewport = true
            addView(root)
        })
    }

    private fun sectionTitle(textValue: String): TextView = TextView(this).apply {
        text = textValue
        textSize = 18f
        setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(18), 0, dp(8))
    }

    private fun actionButton(label: String, click: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginEnd = dp(4)
        }
        setOnClickListener { click() }
    }

    private fun rangeSlider(
        parameter: DspParameter,
        minValue: Int,
        maxValue: Int,
        defaultValue: Int,
        unit: String,
        note: String? = null
    ): View {
        val saved = prefs.getInt(parameter.name, defaultValue).coerceIn(minValue, maxValue)
        val span = maxValue - minValue
        return sliderBlock(parameter, span, saved - minValue, { progress ->
            val value = minValue + progress
            "$value $unit"
        }, note) { progress ->
            onUiParameterChanged(DspUiValue(parameter, minValue + progress))
        }
    }

    private fun sliderBlock(
        parameter: DspParameter,
        maxProgress: Int,
        initialProgress: Int,
        valueFormatter: (Int) -> String,
        note: String?,
        changed: (Int) -> Unit
    ): View {
        val block = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(5), 0, dp(7))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val label = TextView(this).apply {
            text = parameter.displayName
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val valueText = TextView(this).apply {
            text = valueFormatter(initialProgress)
            textSize = 15f
            setPadding(dp(10), 0, 0, 0)
        }
        header.addView(label)
        header.addView(valueText)
        block.addView(header)

        val seek = SeekBar(this).apply {
            max = maxProgress
            progress = initialProgress
            isEnabled = true
            isClickable = true
            isFocusable = true
            minHeight = dp(44)
            setPadding(dp(4), 0, dp(4), 0)
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                valueText.text = valueFormatter(progress)
                if (fromUser) changed(progress)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
        block.addView(seek)

        if (!note.isNullOrBlank()) {
            block.addView(TextView(this).apply {
                text = note
                textSize = 11f
            })
        }
        return block
    }

    private fun onUiParameterChanged(value: DspUiValue) {
        prefs.edit().putInt(value.parameter.name, value.value).apply()
        val id = value.parameter.actuatorId
        val codec = if (id != null && value.parameter.simpleFloatWriteVerified) {
            val packet = com.okn.dsp.protocol.UfeCodec.encodeFloatWrite(id, value.value.toFloat())
            " plain57=${packet.joinToString("") { "%02X".format(it.toInt() and 0xFF) }}"
        } else ""
        append("UI ${value.parameter.name}=${value.value} scope=${value.parameter.scope}$codec TX=AUTH_LOCKED")
        // Serializer + actuator mapping are now verified from official-app HCI traffic.
        // Actual BLE parameter TX remains locked until the per-session RandKey can be
        // derived from the authentication response; do not reuse captured session keys.
    }

    private fun requestBlePermissions() {
        val missing = mutableListOf<String>()
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED)
                missing += Manifest.permission.BLUETOOTH_SCAN
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED)
                missing += Manifest.permission.BLUETOOTH_CONNECT
        } else {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
                missing += Manifest.permission.ACCESS_FINE_LOCATION
        }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 100)
    }

    private fun hasBlePermission(): Boolean {
        return if (android.os.Build.VERSION.SDK_INT >= 31) {
            checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        } else {
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun startScan() {
        if (!hasBlePermission()) {
            requestBlePermissions()
            append("Bluetooth permission not granted")
            return
        }
        val manager = getSystemService(BluetoothManager::class.java)
        val adapter = manager?.adapter
        if (adapter == null) {
            append("Bluetooth adapter not available")
            return
        }
        if (!adapter.isEnabled) {
            append("Bluetooth is OFF")
            return
        }
        scanner = adapter.bluetoothLeScanner
        if (scanner == null) {
            append("BLE scanner not available")
            return
        }

        found.clear()
        deviceList.removeAllViews()
        setStatus("SCANNING — looking for GOLOPINE / DSP / LE-DSTe")
        append("Scanning BLE devices for 10 seconds")
        try {
            scanner?.startScan(scanCallback)
        } catch (_: SecurityException) {
            append("BLE scan permission denied")
            return
        }
        handler.postDelayed({
            try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
            setStatus("SCAN FINISHED — select DSP device if shown")
            append("Scan finished; candidates=${found.size}")
        }, 10_000)
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            val name = result.scanRecord?.deviceName ?: try { device.name } catch (_: SecurityException) { null }
            val serviceMatch = result.scanRecord?.serviceUuids?.any { parcel ->
                parcel.uuid == BleProfile.AB00_SERVICE || parcel.uuid == BleProfile.UUID_0001
            } == true
            val nameMatch = name?.contains("GOLOPINE", true) == true ||
                name?.contains("DSP", true) == true ||
                name?.contains("LE-DSTe", true) == true

            if (serviceMatch || nameMatch) {
                if (!found.containsKey(device.address)) {
                    found[device.address] = device
                    runOnUiThread {
                        deviceList.addView(Button(this@MainActivity).apply {
                            text = "${name ?: "DSP candidate"}\n${device.address}\nแตะเพื่อเชื่อมต่อ"
                            isAllCaps = false
                            setOnClickListener { connect(device, name ?: "DSP") }
                        })
                    }
                }
            }
        }

        override fun onScanFailed(errorCode: Int) {
            append("BLE scan failed code=$errorCode")
        }
    }

    private fun connect(device: BluetoothDevice, name: String) {
        if (!hasBlePermission()) {
            append("Bluetooth permission not granted")
            return
        }
        sessionNo += 1
        packetNo = 0
        synchronized(captureLines) {
            captureLines.add("=== SESSION #$sessionNo START ${ts.format(Date())} ===")
        }
        try {
            scanner?.stopScan(scanCallback)
            gatt?.close()
            notifyQueue.clear()
            readableQueue.clear()
            descriptorWriteInProgress = false
            setStatus("CONNECTING — $name")
            append("Connecting $name ${device.address}")
            gatt = device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
        } catch (e: Exception) {
            append("Connect error=${e.message}")
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, statusCode: Int, newState: Int) {
            append("GATT state=$newState status=$statusCode")
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                setStatus("CONNECTED — capture lab (parameter TX auth-locked)")
                try {
                    if (android.os.Build.VERSION.SDK_INT >= 21) g.requestMtu(517)
                    g.discoverServices()
                } catch (e: Exception) {
                    append("Service discovery error=${e.message}")
                }
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                setStatus("DISCONNECTED")
            }
        }

        override fun onMtuChanged(g: BluetoothGatt, mtu: Int, statusCode: Int) {
            append("MTU=$mtu status=$statusCode")
        }

        override fun onServicesDiscovered(g: BluetoothGatt, statusCode: Int) {
            append("Services discovered status=$statusCode")
            if (statusCode != BluetoothGatt.GATT_SUCCESS) return

            notifyQueue.clear()
            readableQueue.clear()
            val preferredNotify = g.services.flatMap { it.characteristics }
                .filter { it.uuid == BleProfile.AB02_NOTIFY || it.uuid == BleProfile.AB03_NOTIFY }

            g.services.forEachIndexed { si, service ->
                append("SERVICE[$si] ${service.uuid}")
                service.characteristics.forEachIndexed { ci, ch ->
                    append("  CHAR[$ci] ${ch.uuid} [${properties(ch)}]")
                    if ((ch.properties and BluetoothGattCharacteristic.PROPERTY_READ) != 0) {
                        readableQueue.addLast(ch)
                    }
                    if (preferredNotify.isNotEmpty()) {
                        if (preferredNotify.any { it.uuid == ch.uuid }) notifyQueue.addLast(ch)
                    } else if ((ch.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0 ||
                        (ch.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) {
                        notifyQueue.addLast(ch)
                    }
                }
            }
            append("READABLE=${readableQueue.size} NOTIFY_TARGETS=${notifyQueue.size}")
            processNextNotificationSubscription(g)
            handler.postDelayed({ readNextReadable(g) }, 450)
        }

        override fun onDescriptorWrite(g: BluetoothGatt, descriptor: BluetoothGattDescriptor, statusCode: Int) {
            append("CCCD WRITE ${descriptor.uuid} status=$statusCode")
            descriptorWriteInProgress = false
            handler.postDelayed({ processNextNotificationSubscription(g) }, 250)
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            capture("RX_NOTIFY", characteristic.uuid.toString(), value)
        }

        @Suppress("DEPRECATION")
        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            capture("RX_NOTIFY", characteristic.uuid.toString(), characteristic.value ?: byteArrayOf())
        }

        override fun onCharacteristicRead(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            value: ByteArray,
            statusCode: Int
        ) {
            capture("RX_READ", characteristic.uuid.toString(), value, "status=$statusCode")
            handler.postDelayed({ readNextReadable(g) }, 250)
        }

        @Suppress("DEPRECATION")
        override fun onCharacteristicRead(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, statusCode: Int) {
            capture("RX_READ", characteristic.uuid.toString(), characteristic.value ?: byteArrayOf(), "status=$statusCode")
            handler.postDelayed({ readNextReadable(g) }, 250)
        }
    }

    private fun processNextNotificationSubscription(g: BluetoothGatt) {
        if (descriptorWriteInProgress) return
        val ch = notifyQueue.removeFirstOrNull() ?: return
        subscribeToNotifications(g, ch)
    }

    private fun subscribeToNotifications(g: BluetoothGatt, ch: BluetoothGattCharacteristic) {
        if (!hasBlePermission()) return
        try {
            val localOk = g.setCharacteristicNotification(ch, true)
            append("SUBSCRIBE ${ch.uuid} local=$localOk")
            val cccd = ch.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"))
            if (cccd == null) {
                append("CCCD not found for ${ch.uuid}")
                handler.postDelayed({ processNextNotificationSubscription(g) }, 250)
                return
            }
            val enable = if ((ch.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0)
                BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
            else BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE

            descriptorWriteInProgress = true
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                val rc = g.writeDescriptor(cccd, enable)
                append("CCCD request rc=$rc")
                if (rc != BluetoothGatt.GATT_SUCCESS) {
                    descriptorWriteInProgress = false
                    handler.postDelayed({ processNextNotificationSubscription(g) }, 400)
                }
            } else {
                @Suppress("DEPRECATION")
                cccd.value = enable
                @Suppress("DEPRECATION")
                val ok = g.writeDescriptor(cccd)
                append("CCCD request ok=$ok")
                if (!ok) {
                    descriptorWriteInProgress = false
                    handler.postDelayed({ processNextNotificationSubscription(g) }, 400)
                }
            }
        } catch (e: Exception) {
            descriptorWriteInProgress = false
            append("Subscribe error=${e.message}")
        }
    }

    private fun readNextReadable(g: BluetoothGatt) {
        if (!hasBlePermission()) return
        val ch = readableQueue.removeFirstOrNull() ?: return
        append("READ REQUEST ${ch.uuid}")
        try {
            val ok = g.readCharacteristic(ch)
            if (!ok) handler.postDelayed({ readNextReadable(g) }, 250)
        } catch (e: Exception) {
            append("READ error=${e.message}")
            handler.postDelayed({ readNextReadable(g) }, 250)
        }
    }

    private fun properties(ch: BluetoothGattCharacteristic): String {
        val p = mutableListOf<String>()
        if ((ch.properties and BluetoothGattCharacteristic.PROPERTY_READ) != 0) p += "READ"
        if ((ch.properties and BluetoothGattCharacteristic.PROPERTY_WRITE) != 0) p += "WRITE"
        if ((ch.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0) p += "WRITE_NR"
        if ((ch.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0) p += "NOTIFY"
        if ((ch.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) p += "INDICATE"
        return p.joinToString(",")
    }

    private fun capture(kind: String, uuid: String, bytes: ByteArray, extra: String = "") {
        val n = synchronized(captureLines) { packetNo += 1; packetNo }
        val line = "${ts.format(Date())}\t#$n\t$kind\t$uuid\tlen=${bytes.size}\t$extra\thex=${bytes.joinToString("") { "%02X".format(it.toInt() and 0xFF) }}"
        synchronized(captureLines) { captureLines.add(line) }
        append(line)
    }

    private fun analyzeCapture() {
        val lines = synchronized(captureLines) { captureLines.toList() }
        if (lines.isEmpty()) {
            append("ANALYSIS: capture empty")
            return
        }
        val histogram = linkedMapOf<Int, Int>()
        var rx = 0
        lines.forEach { line ->
            Regex("\\blen=(\\d+)").find(line)?.groupValues?.get(1)?.toIntOrNull()?.let { len ->
                histogram[len] = (histogram[len] ?: 0) + 1
            }
            if ("\tRX_" in line) rx++
        }
        val bulk235 = histogram[235] ?: 0
        val bulk157 = histogram[157] ?: 0
        append("=== V15 CAPTURE ANALYSIS ===")
        append("records=${lines.size} RX=$rx sessions=$sessionNo")
        append("lengths=${histogram.entries.sortedBy { it.key }.joinToString { "${it.key}B:${it.value}" }}")
        if (bulk235 > 0 || bulk157 > 0) append("bulk candidates 235B=$bulk235 157B=$bulk157 total=${bulk235 * 235 + bulk157 * 157}B")
        append("Verified codec: 0x57/0x58/0x60 + AES-CFB8 IV=01x16; session-key derivation not guessed")
    }

    private fun shareCapture() {
        val body = synchronized(captureLines) { captureLines.joinToString("\n") }
        if (body.isBlank()) {
            append("CAPTURE EMPTY")
            return
        }
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "OKN DSP V15 BLE capture")
            putExtra(Intent.EXTRA_TEXT, body)
        }, "Export DSP capture"))
    }

    private fun disconnectGatt() {
        try {
            gatt?.disconnect()
            gatt?.close()
        } catch (_: Exception) {}
        gatt = null
        setStatus("DISCONNECTED")
        append("Disconnected by user")
    }

    private fun openAppSettings() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.parse("package:$packageName")
        })
    }

    private fun setStatus(value: String) {
        runOnUiThread { status.text = value }
    }

    private fun append(message: String) {
        runOnUiThread {
            logLines.append(message).append('\n')
            if (logLines.length > 80_000) logLines.delete(0, 20_000)
            logView.text = "Log:\n$logLines"
        }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
        try { gatt?.close() } catch (_: Exception) {}
        gatt = null
        super.onDestroy()
    }
}
