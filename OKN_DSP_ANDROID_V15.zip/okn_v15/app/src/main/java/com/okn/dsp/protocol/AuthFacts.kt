package com.okn.dsp.protocol

/** Authentication facts proven from official-app captures. */
object AuthFacts {
    // Constant official-client authentication request seen across multiple sessions.
    val OFFICIAL_AUTH_REQUEST = hex("631C062443FD3844558001F3EDA0CCF8")
    val TRANSPORT_IV = ByteArray(16) { 0x01 }

    // A response is 32 bytes in the captured sessions. The final session RandKey changes
    // between connections and its derivation/decryption is intentionally NOT guessed here.
    const val AUTH_RESPONSE_LENGTH = 32

    private fun hex(s: String): ByteArray = s.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
}
