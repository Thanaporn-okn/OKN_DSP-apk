package com.okn.dsp.protocol

import java.nio.ByteBuffer
import java.nio.ByteOrder

data class UfeReadResponse(
    val id: Int,
    val offset: Int,
    val length: Int,
    val data: ByteArray
) {
    fun float32OrNull(): Float? =
        if (length == 4 && data.size >= 4)
            ByteBuffer.wrap(data, 0, 4).order(ByteOrder.LITTLE_ENDIAN).float
        else null
}

object UfeCodec {
    /**
     * VERIFIED from official-app HCI traffic:
     * 57 + id(u32 BE) + offset(u16 BE) + length(u16 BE) + float32(LE)
     */
    fun encodeFloatWrite(actuatorId: Int, value: Float, offset: Int = 0): ByteArray {
        val out = ByteBuffer.allocate(13).order(ByteOrder.BIG_ENDIAN)
        out.put(UfeConstants.WRITE_ACTUATOR_COMMAND.toByte())
        out.putInt(actuatorId)
        out.putShort(offset.toShort())
        out.putShort(4)
        val f = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putFloat(value).array()
        out.put(f)
        return out.array()
    }

    /** VERIFIED: 58 + id(u32 BE) + offset(u16 BE) + length(u16 BE). */
    fun encodeRead(id: Int, offset: Int = 0, length: Int = 4): ByteArray {
        val out = ByteBuffer.allocate(9).order(ByteOrder.BIG_ENDIAN)
        out.put(UfeConstants.READ_SENSOR_ACTUATOR_COMMAND.toByte())
        out.putInt(id)
        out.putShort(offset.toShort())
        out.putShort(length.toShort())
        return out.array()
    }

    /** VERIFIED response: 60 + id(u32 BE) + offset(u16 BE) + length(u16 BE) + data. */
    fun decodeReadResponse(bytes: ByteArray): UfeReadResponse? {
        if (bytes.size < 9 || (bytes[0].toInt() and 0xFF) != UfeConstants.RESPONSE_READ_SENSOR_ACTUATOR_COMMAND) return null
        val b = ByteBuffer.wrap(bytes).order(ByteOrder.BIG_ENDIAN)
        b.get()
        val id = b.int
        val offset = b.short.toInt() and 0xFFFF
        val length = b.short.toInt() and 0xFFFF
        if (bytes.size < 9 + length) return null
        return UfeReadResponse(id, offset, length, bytes.copyOfRange(9, 9 + length))
    }
}
