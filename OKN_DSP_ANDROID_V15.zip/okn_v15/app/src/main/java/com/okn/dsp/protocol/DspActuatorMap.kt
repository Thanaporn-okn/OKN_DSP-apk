package com.okn.dsp.protocol

data class FloatActuator(
    val id: Int,
    val name: String,
    val min: Float,
    val max: Float,
    val unit: String,
    val scale: String = "linear"
)

object DspActuatorMap {
    val MASTER = FloatActuator(2, "MasterVolume", -70f, 6f, "dB")
    val REMIND = FloatActuator(3, "RemindSoundVolume", -70f, 6f, "dB")
    val BASS_VOLUME = FloatActuator(8, "BassVolume", -70f, 6f, "dB")
    val BASS_CUTOFF = FloatActuator(9, "BassCutoff", 20f, 250f, "Hz", "log")
    val BASS_BOOST = FloatActuator(10, "BassBoost", -12f, 12f, "dB")
    val MIDDLE_BOOST = FloatActuator(13, "MiddleBoost", -12f, 12f, "dB")
    val TREBLE_BOOST = FloatActuator(11, "TrebleBoost", -12f, 12f, "dB")

    // BiquadCascade31F/Biquad31 processing channels, not direct gain controls.
    val BIQUAD_CHANNEL_IDS = intArrayOf(4, 5, 6, 14, 15, 16, 17)
}
