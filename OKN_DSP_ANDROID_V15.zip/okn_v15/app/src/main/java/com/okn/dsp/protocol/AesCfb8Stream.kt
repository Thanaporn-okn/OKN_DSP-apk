package com.okn.dsp.protocol

import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * VERIFIED from the 2026-09-06 official-app HCI session.
 * Transport after authentication is stateful AES-128/CFB8/NoPadding.
 * IV is sixteen 0x01 bytes. Do NOT reset Cipher between BLE chunks in one direction.
 */
class AesCfb8Stream(sessionKey: ByteArray, encrypt: Boolean) {
    private val cipher = Cipher.getInstance("AES/CFB8/NoPadding").apply {
        require(sessionKey.size == 16) { "RandKey must be 16 bytes" }
        val mode = if (encrypt) Cipher.ENCRYPT_MODE else Cipher.DECRYPT_MODE
        init(mode, SecretKeySpec(sessionKey, "AES"), IvParameterSpec(ByteArray(16) { 0x01 }))
    }

    fun update(bytes: ByteArray): ByteArray = cipher.update(bytes) ?: byteArrayOf()
}
