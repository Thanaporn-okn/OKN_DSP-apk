package com.okn.dsp

enum class DspParameter(
    val displayName: String,
    val scope: String,
    val actuatorId: Int?,
    val simpleFloatWriteVerified: Boolean
) {
    MASTER_VOLUME("ระดับเสียงหลัก", "ALL", 2, true),
    BASS_LEVEL("ระดับเสียงเบส", "BASS", 8, true),
    BASS_CROSSOVER("จุดตัดเสียงเบส", "BASS", 9, true),
    BASS_BOOST("Bass Boost", "ALL", 10, true),
    MIDDLE_BOOST("MiddleBoost", "ALL", 13, true),
    TREBLE_BOOST("Treble Boost", "ALL", 11, true),

    // No direct simple-float Gain actuator exists in the captured device descriptor.
    // Channel processing is through BiquadCascade actuators below, so these stay UI-only.
    CH1_GAIN("Gain CH1", "CH1 / Biquad ID4", 4, false),
    CH2_GAIN("Gain CH2", "CH2 / Biquad ID5", 5, false),
    CH3_GAIN("Gain CH3 (Bass CH)", "CH3 / Biquad ID6", 6, false),
    CH4_GAIN("Gain CH4", "CH4 / Biquad ID14", 14, false),
    CH5_GAIN("Gain CH5", "CH5 / Biquad ID15", 15, false),
    CH6_GAIN("Gain CH6", "CH6 / Biquad ID16", 16, false),
    CH7_GAIN("Gain CH7", "CH7 / Biquad ID17", 17, false)
}

data class DspUiValue(
    val parameter: DspParameter,
    val value: Int
)
