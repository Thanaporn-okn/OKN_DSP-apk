# OKN DSP Controller V15

ฐาน: OKN_DSP_ANDROID_V14 + bugreport `DOC-20260906-WA0002.zip` + official GoloPine Flutter client traffic

## V15 เปลี่ยนจาก normalized เป็นค่าจริงแล้ว
ข้อมูล Device Descriptor ถูกถอดออกจาก AB02 ได้ครบ 18,141 bytes และยืนยัน actuator ของเครื่องนี้โดยตรง:

- MasterVolume: ID 2, -70..+6 dB
- RemindSoundVolume: ID 3, -70..+6 dB
- BassVolume: ID 8, -70..+6 dB
- BassCutoff: ID 9, 20..250 Hz, log scale
- BassBoost: ID 10, -12..+12 dB
- MiddleBoost: ID 13, -12..+12 dB
- TrebleBoost: ID 11, -12..+12 dB
- SaveParams: ID 7

## 7-channel DSP actuators
Device Descriptor ไม่มี simple float actuator ชื่อ Gain CH1..CH7 โดยตรง แต่พบ BiquadCascade สำหรับ 7 ช่อง:

- ID 4: Left Channel
- ID 5: Right Channel
- ID 6: Bass Channel
- ID 14: 4th Channel
- ID 15: 5th Channel
- ID 16: 6th Channel
- ID 17: 7th Channel

V15 จึงยังคง Gain CH1..CH7 เป็น UI ที่กด/ลากได้ แต่ไม่ส่งค่าเข้าตัว DSP จนกว่าจะพิสูจน์ว่า field ใดใน Biquad cascade เป็น output/channel gain จริง

## BLE ที่ยืนยันจาก HCI จริง
- Service: `0000ab00-0000-1000-8000-00805f9b34fb`
- Host -> DSP write: `AB01`, ATT Write Command `0x52`
- DSP -> Host notify: `AB02`
- Secondary notify: `AB03`
- MTU ที่ official app ใช้: ประมาณ 517
- Device name: `GoloPine_DSP_Amplifier`

## UFE serializer ที่ยืนยันแล้ว
Float32 write plaintext:

`57 + actuatorId:u32BE + offset:u16BE + length:u16BE + float32:LE`

ตัวอย่าง MasterVolume -40.36 dB:

`570000000200000004A47021C2`

Read plaintext:

`58 + id:u32BE + offset:u16BE + length:u16BE`

Read response:

`60 + id:u32BE + offset:u16BE + length:u16BE + data`

## Encryption ที่ยืนยันแล้ว
หลัง authentication traffic เป็น stateful:

- AES-128
- CFB8
- NoPadding
- IV = `01010101010101010101010101010101`
- cipher state ต่อเนื่องข้าม BLE chunks แยกตามแต่ละทิศทาง

Device Description request หลัง auth decrypt ได้เป็น `661C0624`.
Device Description response เริ่มด้วย `86 + length:u16LE + 00`, ตามด้วย JSON; packet ต่อใช้ `82`.

## สิ่งที่ยังล็อกอยู่
เหลือจุดเดียวที่สำคัญก่อนเปิด parameter WRITE จริง: ต้องถอดวิธีสร้าง/ถอด `RandKey` 16-byte จาก authentication response ให้ได้ทุก connection

Official authentication request ที่ยืนยันซ้ำหลาย session:

`631C062443FD3844558001F3EDA0CCF8`

แต่ RandKey เปลี่ยนใหม่ทุก session ดังนั้น V15 **ไม่ hardcode key จาก bugreport** และยังไม่ส่ง slider parameters จริง เพื่อป้องกันการใช้ session key ผิดหรือทำให้ stream cipher state ผิด

## ไฟล์หลักใน source
- `protocol/UfeCodec.kt` — serializer 0x57 / 0x58 / 0x60 ที่ยืนยันแล้ว
- `protocol/AesCfb8Stream.kt` — AES-CFB8 IV 01x16 ที่ยืนยันแล้ว
- `protocol/DspActuatorMap.kt` — actuator IDs/ranges จาก Device Descriptor จริง
- `protocol/AuthFacts.kt` — authentication facts ที่ยืนยันแล้ว โดยยังไม่เดา RandKey derivation
- `docs/GoloPine_device_descriptor_20260906.json` — descriptor ที่ถอดครบ
- `docs/GoloPine_DSP_protocol_V15.json` — protocol checkpoint V15

## Build
ใช้ workflow `build-okn-dsp.yml` ตัวเดิมได้ ไม่ต้องอัป workflow ใหม่ วาง `OKN_DSP_ANDROID_V15.zip` ที่ root ของ repository แล้ว push เข้า main; workflow จะเลือก V ล่าสุดอัตโนมัติ
