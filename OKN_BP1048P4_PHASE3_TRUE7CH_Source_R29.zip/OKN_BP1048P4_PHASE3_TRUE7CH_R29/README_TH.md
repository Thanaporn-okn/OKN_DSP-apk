# OKN BP1048P4 Phase3 TRUE7CH — R29

R29 เป็นรอบ **offline package03/helper/readback reverse** ต่อจาก R28 ไม่มี hardware command ใหม่.

ไฟล์หลัก:
- `docs/R29_PACKAGE03_READBACK_OFFLINE_REVERSE_TH.md`
- `docs/R29_PACKAGE03_PARSER_EVIDENCE.txt`
- `config/R29_HELPER_READBACK_STATE.json`
- `config/R29_HELPER_READBACK_RISK.json`
- `tools/r29_helper_readback_offline.py`
- `sdk_evidence/r29_helper_readback/`

ผลใหม่สำคัญ:
1. helper 1,520 bytes ของ package03 เป็น opaque/high-entropy payload; exact codec ยังไม่พิสูจน์.
2. MVA parser ID3 handler @0x41D8 log length แล้ว skip record (`payload_length + 5`) โดยไม่พบ direct copy/execute/CRC ของ helper payload.
3. SDK มี `SpiFlashRead` internal primitive จริง แต่หลักฐานที่มีใช้เพื่อ staging CRC และ read-after-write verification; ยังไม่มี host-exposed arbitrary readback command.
4. stock backup/full flash readback/production layout ยังไม่พิสูจน์ — flash gate ยังคงปิด.

Android module relabel เป็น R29 เพื่อ continuity/stable signing เท่านั้น ไม่มี USB updater/readback path ใหม่ และ **ไม่จำเป็นต้องติดตั้ง R29 APK**.

ข้อห้ามเดิมยังคง: ไม่ส่ง `.mva`, ไม่ OBEX PUT, ไม่ Feature 0x55/0xAA, ไม่ USB flashboot command, ไม่ erase/program/commit/apply/reset.
