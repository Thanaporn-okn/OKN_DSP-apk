// V22 TX RX Log Monitor
