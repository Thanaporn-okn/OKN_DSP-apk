// V22 BP1048P4 HEX command packet
