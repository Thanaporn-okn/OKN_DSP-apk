// V22 Bluetooth Connect / Disconnect layer
