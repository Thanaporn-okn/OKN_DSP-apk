// V22 BP1048P4 protocol packet
