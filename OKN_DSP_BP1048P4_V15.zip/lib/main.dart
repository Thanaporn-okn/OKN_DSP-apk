import 'package:flutter/material.dart';

void main() => runApp(const OKNDSPV15());

class OKNDSPV15 extends StatelessWidget {
  const OKNDSPV15({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner:false,
      home: Scaffold(
        backgroundColor: const Color(0xff121018),
        body: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: const [
              Text('OKN_DSP BP1048P4 V15',
                style: TextStyle(color: Colors.cyan,fontSize:28)),
              SizedBox(height:20),
              Text(
                'CH1-CH7 Channel Select\n'
                '15 Band EQ Per Channel\n'
                'HPF / LPF Crossover\n'
                'Delay Time ms\n'
                'Bluetooth Command Packet\n'
                'TX RX Log Monitor',
                style: TextStyle(color: Colors.white,fontSize:18),
              )
            ],
          ),
        ),
      ),
    );
  }
}
