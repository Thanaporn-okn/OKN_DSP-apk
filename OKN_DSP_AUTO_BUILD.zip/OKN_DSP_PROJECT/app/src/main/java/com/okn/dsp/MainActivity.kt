package com.okn.dsp

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class MainActivity: Activity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  setContentView(TextView(this).apply {
   text="OKN_DSP BP1048P4 7CH Controller"
   textSize=24f
  })
 }
}
