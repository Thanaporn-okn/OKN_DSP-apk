# OKN BP1048P4 TRUE7CH — R19 Direct USB-C Flashboot Probe

R19 เริ่มเส้นทางเป้าหมายใหม่: **Samsung S25+ ต่อ USB-C เข้าบอร์ด GoloPine/JMDSTECH โดยตรง**

รุ่นนี้ยังเป็น read-only descriptor/fingerprint probe เท่านั้น เพื่อแยก normal application จาก MVSilicon BP10X flashboot family fingerprint โดยไม่ส่ง AA, SET_REPORT, ACP หรือคำสั่ง flash ใด ๆ

ใช้ `OKN_BP1048P4_AUTO.yml` ตัวเดิมได้ วาง ZIP R19 ใน repo แล้ว workflow จะเลือก source รุ่นล่าสุดและ build APK

หลังติดตั้งให้ต่อ S25+ ↔ USB-C ของบอร์ด, กด 2 → 3 → 5 แล้วส่ง whole log จากปุ่ม 7 กลับมา

รายละเอียด: `docs/DIRECT_USB_C_FLASHBOOT_PROBE_R19_TH.md`
