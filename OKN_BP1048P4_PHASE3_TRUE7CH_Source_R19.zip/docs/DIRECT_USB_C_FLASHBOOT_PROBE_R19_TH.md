# R19 — Samsung S25+ ↔ GoloPine Direct USB-C Flashboot Fingerprint Probe

## เป้าหมาย
R19 เปลี่ยนจากการหา AICE มาเป็นเส้นทางปลายทางที่ผู้ใช้ต้องการจริง: **Samsung S25+ ต่อ USB-C เข้าบอร์ด DSP โดยตรง** แต่รอบนี้ยังเป็น read-only เพื่อพิสูจน์ว่า USB ที่เห็นเป็น normal application หรือ flashboot ก่อนทำ protocol writer ใด ๆ

## หลักฐานจาก public BP10X SDK
ไฟล์สาธารณะ `Mv_BP10X/BT_Audio_APP/bt_audio_app_src/device/flash_boot.c` ใน `ZhiqingLi/Sdk_Refresh` มี flashboot image 64 KiB และมี USB descriptor ฝังอยู่ดังนี้:

- Device descriptor: `12 01 10 01 00 00 00 40 00 00 44 22 00 01 00 00 00 01`
  - VID `0000`, PID `2244`, 1 configuration
- Configuration: 27 bytes, 1 HID interface, **0 endpoints**
- HID report descriptor 36 bytes:
  `06 00 FF 0A 55 AA A1 01 15 00 26 FF 00 75 08 96 00 01 09 01 81 02 96 00 01 09 01 91 02 95 01 09 01 B1 02 C0`
  - vendor page FF00, usage bytes 55 AA
  - Input 256 bytes, Output 256 bytes, Feature 1 byte

สิ่งนี้เป็น **family reference** ไม่ใช่ข้อสรุปว่า bootloader ของ BP1048P4 บอร์ด GoloPine ต้องใช้ VID/PID เดียวกัน

Public app-side source `otg_device_standard_request.c` แสดงว่า Feature SET_REPORT `0xAA` เพียงตั้ง `pc_upgrade=1`; การ GET_REPORT หลังจากนั้นจะเรียก `start_up_grate(AppResourceUsbDevice)` เฉพาะเมื่อ `FLASH_BOOT_EN` ถูก compile เข้า firmware. `upgrade.c` จะกระโดด address 0 ก็ต่อเมื่อ `ResourceValue(AppResourceUsbDevice)` เป็นจริง. R15/R16 ของบอร์ดจริงเคยยืนยันแล้วว่า AA ถูกตอบรับแต่ยังไม่เกิด observable handoff จึง **R19 ไม่ส่ง AA ซ้ำ**

## R19 ทำอะไร
- สแกน Android USB devices แบบ passive
- อ่าน Device / Configuration / String / HID Report descriptors ด้วย standard `GET_DESCRIPTOR` control-IN เท่านั้น
- เปรียบเทียบกับ normal target fingerprint ที่วัดจริงก่อนหน้า (`6324:1719`) และ public BP10X flashboot fingerprint
- มี passive enumeration watch 30 วินาที เพื่อดู detach/attach/VID-PID/interface-shape ขณะผู้ใช้ power-cycle หรือเปลี่ยนโหมดด้วยปุ่มบนบอร์ด

## R19 ไม่ทำอะไร
ไม่มี Feature GET/SET report, ไม่มี `AA`, ไม่มี ACP, ไม่มี endpoint OUT, ไม่มี `claimInterface`, ไม่มี `bulkTransfer`, ไม่มี read/write memory, ไม่มี erase/program/commit

## วิธีทดสอบ
1. Build ด้วย `OKN_BP1048P4_AUTO.yml` เดิม
2. ติดตั้ง APK R19 บน S25+
3. ต่อ S25+ ↔ USB-C ของบอร์ด DSP โดยตรง และจ่ายไฟบอร์ดตามปกติ
4. กด `2) SCAN USB + CLASSIFY (PASSIVE)`
5. กด `3) INSPECT GOLOPINE/FLASHBOOT CANDIDATE (READ-ONLY)` และอนุญาต USB
6. รอ `R19 FINGERPRINT RESULT`
7. กด `5) WATCH ENUMERATION 30s (PASSIVE)` แล้วระหว่างนั้นลอง **power-cycle ด้วยมือ** หรือเปลี่ยน physical input/mode ของบอร์ดตามปกติเท่านั้น; แอปจะไม่ส่งคำสั่ง USB
8. ถ้าเห็น VID/PID หรือ interface shape ใหม่ ให้กดปุ่ม 3 หรือ 4 เพื่อ inspect descriptor แบบ read-only
9. กด `7) COPY WHOLE LOG` แล้วส่ง log ทั้งหมดกลับมา

## Gate ถัดไป
- ถ้าเจอ exact/public-like flashboot fingerprint: R20 จะโฟกัส **read-only protocol identify** ของ flashboot นั้นก่อน
- ถ้ายังเห็นแต่ exact normal app ทุกสถานะ: ต้อง reverse host protocol/entry condition ต่อจาก PC Tools/flashboot image โดยไม่ยิงคำสั่งเดาสุ่มใส่บอร์ด
