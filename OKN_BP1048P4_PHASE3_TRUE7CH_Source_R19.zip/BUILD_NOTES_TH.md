R19 build target: Android direct USB-C read-only flashboot fingerprint probe for GoloPine BP1048P4.
- Android package: com.okn.dsp.usbprobe
- versionCode: 19
- versionName: 0.19-r19-direct-usbc-flashboot-readonly
- compileSdk/targetSdk: 35
- minSdk: 26
- Java 17
- Stable workflow: OKN_BP1048P4_AUTO.yml unchanged
- No AA / SET_REPORT / ACP / endpoint OUT / flash executor in this release
- Public BP10X flashboot fingerprint included only as a comparison reference
