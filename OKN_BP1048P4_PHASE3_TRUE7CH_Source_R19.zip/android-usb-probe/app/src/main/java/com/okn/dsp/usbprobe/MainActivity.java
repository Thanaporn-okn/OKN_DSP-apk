package com.okn.dsp.usbprobe;

import android.app.*;
import android.os.*;
import android.content.*;
import android.hardware.usb.*;
import android.widget.*;
import java.util.*;
import java.text.SimpleDateFormat;

/**
 * R19 is deliberately fail-closed.  It never sends a host-to-device USB request.
 * It only enumerates Android's UsbDevice objects and performs standard descriptor
 * GET_DESCRIPTOR control-IN reads (0x80/0x81).  There is no SET_REPORT, endpoint
 * OUT, claimInterface, bulkTransfer, flash command, erase or program path here.
 */
public final class MainActivity extends Activity {
    private static final String ACTION_USB_PERMISSION = "com.okn.dsp.usbprobe.USB_PERMISSION";

    // User's confirmed GoloPine/JMDSTECH normal application identity.
    private static final int TARGET_NORMAL_VID = 0x6324;
    private static final int TARGET_NORMAL_PID = 0x1719;

    // Public BP10X flash_boot.c reference fingerprint.  This is a FAMILY reference,
    // not an assumption that the user's BP1048P4 must enumerate identically.
    private static final int PUBLIC_FLASHBOOT_VID = 0x0000;
    private static final int PUBLIC_FLASHBOOT_PID = 0x2244;

    private static final byte[] TARGET_NORMAL_DEVICE = hx(
            "12 01 10 01 00 00 00 40 24 63 19 17 00 01 01 02 03 01");
    private static final byte[] TARGET_NORMAL_IF4_REPORT = hx(
            "06 00 FF 0A AA 55 A1 01 15 00 26 FF 00 75 08 96 00 01 09 01 81 02 " +
            "96 00 01 09 01 91 02 95 08 09 01 B1 02 C0");

    // Extracted from public Mv_BP10X/.../device/flash_boot.c (build 2019-06-25).
    private static final byte[] PUBLIC_FLASHBOOT_DEVICE = hx(
            "12 01 10 01 00 00 00 40 00 00 44 22 00 01 00 00 00 01");
    private static final byte[] PUBLIC_FLASHBOOT_CONFIG = hx(
            "09 02 1B 00 01 01 00 80 32 " +
            "09 04 00 00 00 03 00 00 00 " +
            "09 21 00 01 00 01 22 24 00");
    private static final byte[] PUBLIC_FLASHBOOT_REPORT = hx(
            "06 00 FF 0A 55 AA A1 01 15 00 26 FF 00 75 08 96 00 01 09 01 81 02 " +
            "96 00 01 09 01 91 02 95 01 09 01 B1 02 C0");

    private UsbManager usb;
    private TextView log;
    private UsbDevice selected;
    private volatile boolean watchStop;
    private Capture lastCapture;

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            String a = i.getAction();
            if (ACTION_USB_PERMISSION.equals(a)) {
                UsbDevice d = i.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                if (!i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false) || d == null) {
                    add("USB permission denied");
                    return;
                }
                selected = d;
                add("USB permission granted: " + sig(d));
                inspectReadOnly(d);
                return;
            }
            if (UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(a)) {
                UsbDevice d = i.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                add("USB ATTACHED: " + (d == null ? "<unknown>" : sig(d) + " class=" + shallowClass(d)));
                return;
            }
            if (UsbManager.ACTION_USB_DEVICE_DETACHED.equals(a)) {
                UsbDevice d = i.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                add("USB DETACHED: " + (d == null ? "<unknown>" : sig(d)));
                if (selected != null && d != null && selected.getDeviceId() == d.getDeviceId()) selected = null;
            }
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        usb = (UsbManager)getSystemService(USB_SERVICE);
        buildUi();
        IntentFilter f = new IntentFilter(ACTION_USB_PERMISSION);
        f.addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED);
        f.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, RECEIVER_NOT_EXPORTED);
        else registerReceiver(receiver, f);
        readExitHistory();
    }

    @Override protected void onDestroy() {
        watchStop = true;
        super.onDestroy();
        try { unregisterReceiver(receiver); } catch (Exception ignored) {}
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24,24,24,24);

        TextView title = new TextView(this);
        title.setText("OKN MVSilicon Direct USB-C Probe R19\n" +
                "S25+ ↔ GoloPine BP1048P4\n" +
                "READ-ONLY flashboot fingerprinting — NO AA / NO SET_REPORT / NO FLASH WRITE");
        title.setTextSize(18);

        Button exits = new Button(this); exits.setText("1) READ APP EXIT HISTORY");
        Button scan = new Button(this); scan.setText("2) SCAN USB + CLASSIFY (PASSIVE)");
        Button inspect = new Button(this); inspect.setText("3) INSPECT GOLOPINE/FLASHBOOT CANDIDATE (READ-ONLY)");
        Button sole = new Button(this); sole.setText("4) INSPECT SOLE USB DEVICE (READ-ONLY)");
        Button watch = new Button(this); watch.setText("5) WATCH ENUMERATION 30s (PASSIVE)");
        Button compare = new Button(this); compare.setText("6) SHOW LAST FINGERPRINT RESULT");
        Button copy = new Button(this); copy.setText("7) COPY WHOLE LOG");
        Button clear = new Button(this); clear.setText("CLEAR LOG");

        log = new TextView(this);
        log.setTextIsSelectable(true);
        ScrollView sv = new ScrollView(this);
        sv.addView(log);

        root.addView(title); root.addView(exits); root.addView(scan); root.addView(inspect);
        root.addView(sole); root.addView(watch); root.addView(compare); root.addView(copy); root.addView(clear);
        root.addView(sv, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);

        exits.setOnClickListener(v -> readExitHistory());
        scan.setOnClickListener(v -> scanPassive());
        inspect.setOnClickListener(v -> selectAndInspect(true));
        sole.setOnClickListener(v -> selectAndInspect(false));
        watch.setOnClickListener(v -> watchEnumeration30s());
        compare.setOnClickListener(v -> showLastResult());
        copy.setOnClickListener(v -> copyLog());
        clear.setOnClickListener(v -> log.setText(""));
    }

    private void readExitHistory() {
        add("=== ANDROID APP EXIT HISTORY ===");
        add("Model: " + Build.MANUFACTURER + " " + Build.MODEL + " SDK=" + Build.VERSION.SDK_INT);
        if (Build.VERSION.SDK_INT < 30) { add("ApplicationExitInfo unavailable below API 30."); return; }
        try {
            ActivityManager am = (ActivityManager)getSystemService(ACTIVITY_SERVICE);
            List<ApplicationExitInfo> infos = am.getHistoricalProcessExitReasons(getPackageName(), 0, 8);
            add("Historical exits: " + infos.size());
            SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS Z", Locale.US);
            int idx = 0;
            for (ApplicationExitInfo info : infos) {
                idx++;
                add("EXIT #" + idx + ": time=" + fmt.format(new Date(info.getTimestamp())) +
                        " reason=" + info.getReason() + " status=" + info.getStatus());
                String desc = info.getDescription();
                if (desc != null && !desc.isEmpty()) add("  description=" + desc);
            }
        } catch (Throwable t) {
            add("Exit-history read failed: " + t.getClass().getSimpleName() + ": " + safe(t.getMessage()));
        }
        add("=== END EXIT HISTORY ===");
    }

    private void scanPassive() {
        add("=== R19 PASSIVE USB SCAN ===");
        Map<String,UsbDevice> devices = usb.getDeviceList();
        add("USB devices: " + devices.size());
        selected = null;
        for (UsbDevice d : devices.values()) {
            addDeviceSummary(d);
            if (selected == null && isInteresting(d)) selected = d;
        }
        if (selected != null) add("Selected candidate: " + sig(selected) + " class=" + shallowClass(selected));
        else add("No exact GoloPine/public-flashboot candidate. If exactly one USB device is attached, button 4 can inspect it read-only.");
        add("PASSIVE means Android enumeration only; no UsbDeviceConnection opened.");
        add("=== END R19 PASSIVE USB SCAN ===");
    }

    private void selectAndInspect(boolean interestingOnly) {
        Map<String,UsbDevice> devices = usb.getDeviceList();
        UsbDevice d = null;
        if (interestingOnly) {
            for (UsbDevice x : devices.values()) if (isInteresting(x)) { d = x; break; }
            if (d == null) {
                add("No exact 6324:1719 or public 0000:2244 candidate found. Run button 2 first; use button 4 only if the board is the sole attached USB device.");
                return;
            }
        } else {
            if (devices.size() != 1) {
                add("BLOCKED: button 4 requires exactly one attached USB device; found " + devices.size() + ".");
                return;
            }
            d = devices.values().iterator().next();
        }
        selected = d;
        if (usb.hasPermission(d)) inspectReadOnly(d); else requestPermission(d);
    }

    private void requestPermission(UsbDevice d) {
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0);
        PendingIntent pi = PendingIntent.getBroadcast(this, 0,
                new Intent(ACTION_USB_PERMISSION).setPackage(getPackageName()), flags);
        add("Requesting Android USB permission for " + sig(d));
        usb.requestPermission(d, pi);
    }

    private boolean isInteresting(UsbDevice d) {
        if (d == null) return false;
        return (d.getVendorId()==TARGET_NORMAL_VID && d.getProductId()==TARGET_NORMAL_PID) ||
                (d.getVendorId()==PUBLIC_FLASHBOOT_VID && d.getProductId()==PUBLIC_FLASHBOOT_PID);
    }

    private String shallowClass(UsbDevice d) {
        if (d.getVendorId()==TARGET_NORMAL_VID && d.getProductId()==TARGET_NORMAL_PID)
            return "KNOWN GOLOPINE NORMAL-APP VID:PID";
        if (d.getVendorId()==PUBLIC_FLASHBOOT_VID && d.getProductId()==PUBLIC_FLASHBOOT_PID)
            return "PUBLIC BP10X FLASHBOOT REFERENCE VID:PID";
        if (d.getInterfaceCount()==1 && d.getInterface(0).getInterfaceClass()==UsbConstants.USB_CLASS_HID)
            return "UNKNOWN SINGLE-HID / FLASHBOOT-LIKE CANDIDATE";
        return "UNKNOWN/NON-TARGET";
    }

    private void addDeviceSummary(UsbDevice d) {
        add(sig(d) + " shallow=" + shallowClass(d));
        add("  devClass=" + d.getDeviceClass() + " sub=" + d.getDeviceSubclass() + " proto=" + d.getDeviceProtocol());
        for (int i=0; i<d.getInterfaceCount(); i++) {
            UsbInterface x = d.getInterface(i);
            add("  IDX" + i + " IF" + x.getId() + " alt=" + x.getAlternateSetting() +
                    " class=" + x.getInterfaceClass() + " sub=" + x.getInterfaceSubclass() +
                    " proto=" + x.getInterfaceProtocol() + " ep=" + x.getEndpointCount() +
                    " name=" + safe(x.getName()));
            for (int e=0; e<x.getEndpointCount(); e++) {
                UsbEndpoint ep = x.getEndpoint(e);
                add("    EP addr=0x" + String.format(Locale.US,"%02X",ep.getAddress()) +
                        " dir=" + (ep.getDirection()==UsbConstants.USB_DIR_IN?"IN":"OUT") +
                        " type=" + ep.getType() + " max=" + ep.getMaxPacketSize() +
                        " interval=" + ep.getInterval());
            }
        }
    }

    private void inspectReadOnly(UsbDevice d) {
        new Thread(() -> {
            ui("=== R19 DIRECT USB-C READ-ONLY INSPECTION ===");
            ui("Target: " + sig(d));
            ui("Shallow class: " + shallowClass(d));
            UsbDeviceConnection c = usb.openDevice(d);
            if (c == null) { ui("openDevice: FAILED"); return; }
            try {
                Capture cap = new Capture();
                cap.androidSig = sig(d);
                cap.vid = d.getVendorId(); cap.pid = d.getProductId(); cap.interfaces = d.getInterfaceCount();
                ui("openDevice: OK");
                ui("Android strings: manufacturer=" + safe(d.getManufacturerName()) +
                        " product=" + safe(d.getProductName()) + " serial=" + safe(d.getSerialNumber()) +
                        " version=" + safe(d.getVersion()));

                byte[] dd = new byte[18];
                int dn = c.controlTransfer(0x80, 0x06, 0x0100, 0, dd, dd.length, 1500);
                ui("GET_DESCRIPTOR DEVICE => " + dn + " bytes");
                if (dn > 0) {
                    cap.device = Arrays.copyOf(dd,dn);
                    ui("  DEVICE: " + hex(dd,dn));
                    decodeDeviceDescriptor(dd,dn);
                }

                int lang = readLanguageId(c);
                if (dn >= 18) {
                    int iMan=dd[14]&0xFF, iProd=dd[15]&0xFF, iSer=dd[16]&0xFF;
                    ui(String.format(Locale.US,"String indices: manufacturer=%d product=%d serial=%d lang=0x%04X",iMan,iProd,iSer,lang));
                    if (iMan != 0) ui("  RAW manufacturer: " + readUsbString(c,iMan,lang));
                    if (iProd != 0) ui("  RAW product: " + readUsbString(c,iProd,lang));
                    if (iSer != 0) ui("  RAW serial: " + readUsbString(c,iSer,lang));
                }

                byte[] cfg9 = new byte[9];
                int c9 = c.controlTransfer(0x80,0x06,0x0200,0,cfg9,cfg9.length,1500);
                ui("GET_DESCRIPTOR CONFIG header => " + c9 + " bytes" + (c9>0?"\n  "+hex(cfg9,c9):""));
                if (c9 >= 4) {
                    int total=(cfg9[2]&0xFF)|((cfg9[3]&0xFF)<<8);
                    int capLen=Math.max(9,Math.min(total,4096));
                    byte[] cfg=new byte[capLen];
                    int cn=c.controlTransfer(0x80,0x06,0x0200,0,cfg,cfg.length,1500);
                    ui("GET_DESCRIPTOR CONFIG full requested=" + capLen + " => " + cn + " bytes");
                    if (cn > 0) {
                        cap.config=Arrays.copyOf(cfg,cn);
                        ui("  CONFIG: " + hex(cfg,cn));
                    }
                }

                for (int i=0; i<d.getInterfaceCount(); i++) {
                    UsbInterface x=d.getInterface(i);
                    if (x.getInterfaceClass()==UsbConstants.USB_CLASS_HID) {
                        byte[] rd=new byte[512];
                        int rn=c.controlTransfer(0x81,0x06,0x2200,x.getId(),rd,rd.length,1500);
                        ui("IF"+x.getId()+" HID GET_DESCRIPTOR REPORT => "+rn+" bytes" + (rn>0?"\n  REPORT: "+hex(rd,rn):""));
                        if (rn > 0) cap.hidReports.put(x.getId(),Arrays.copyOf(rd,rn));
                    }
                }

                cap.result = classifyDeep(cap);
                lastCapture = cap;
                ui("R19 FINGERPRINT RESULT: " + cap.result);
                ui("R19 SAFETY RESULT: descriptor-only inspection complete.");
                ui("NO AA, NO Feature SET_REPORT, NO endpoint OUT, NO claimInterface, NO bulkTransfer, NO flash command, NO erase/program.");
            } catch (Throwable t) {
                ui("R19 inspection exception: " + t.getClass().getSimpleName() + ": " + safe(t.getMessage()));
            } finally {
                c.close();
                ui("=== END R19 READ-ONLY INSPECTION ===");
            }
        }, "okn-r19-direct-usb-readonly").start();
    }

    private String classifyDeep(Capture c) {
        boolean normalDev = eq(c.device,TARGET_NORMAL_DEVICE);
        boolean normalReport = false;
        for (byte[] r : c.hidReports.values()) if (eq(r,TARGET_NORMAL_IF4_REPORT)) normalReport = true;
        if (c.vid==TARGET_NORMAL_VID && c.pid==TARGET_NORMAL_PID && normalDev && normalReport)
            return "EXACT-KNOWN-NORMAL-APP (6324:1719 + known HID report)";

        boolean bootDev = eq(c.device,PUBLIC_FLASHBOOT_DEVICE);
        boolean bootCfg = eq(c.config,PUBLIC_FLASHBOOT_CONFIG);
        boolean bootReport = false;
        for (byte[] r : c.hidReports.values()) if (eq(r,PUBLIC_FLASHBOOT_REPORT)) bootReport = true;
        if (bootDev && bootCfg && bootReport)
            return "EXACT-PUBLIC-BP10X-FLASHBOOT-REFERENCE (0000:2244 / one HID / control-only)";
        if (bootReport)
            return "FLASHBOOT-REPORT-FINGERPRINT-MATCH (VID/PID/config differs from public reference)";
        if (c.interfaces==1 && !c.hidReports.isEmpty())
            return "SINGLE-HID-UNKNOWN — preserve log for comparison; do not send commands";
        if (c.vid==TARGET_NORMAL_VID && c.pid==TARGET_NORMAL_PID)
            return "GOLOPINE-NORMAL-ID-BUT-DESCRIPTORS-DIFFER — preserve log";
        return "UNKNOWN/NON-MATCH";
    }

    private void watchEnumeration30s() {
        watchStop = false;
        add("=== R19 30s PASSIVE ENUMERATION WATCH ===");
        add("During this watch you may ONLY manually power-cycle the board or change its physical input/mode. R19 sends nothing to USB.");
        new Thread(() -> {
            long end=SystemClock.elapsedRealtime()+30000;
            String prev="";
            int change=0;
            while (!watchStop && SystemClock.elapsedRealtime()<end) {
                String now=snapshotShallow();
                if (!now.equals(prev)) {
                    change++;
                    ui("WATCH CHANGE #"+change+" t="+SystemClock.elapsedRealtime()+"ms\n"+now);
                    prev=now;
                }
                SystemClock.sleep(250);
            }
            ui("R19 WATCH DONE. changes="+change);
            ui("If a new VID:PID/interface shape appeared, run button 3 or 4 to capture its descriptors read-only.");
            ui("=== END R19 WATCH ===");
        },"okn-r19-passive-watch").start();
    }

    private String snapshotShallow() {
        List<UsbDevice> ds=new ArrayList<>(usb.getDeviceList().values());
        ds.sort(Comparator.comparingInt(UsbDevice::getVendorId).thenComparingInt(UsbDevice::getProductId).thenComparingInt(UsbDevice::getDeviceId));
        StringBuilder s=new StringBuilder();
        s.append("devices=").append(ds.size());
        for (UsbDevice d:ds) s.append("\n  ").append(sig(d)).append(" shallow=").append(shallowClass(d));
        return s.toString();
    }

    private void showLastResult() {
        Capture c=lastCapture;
        if (c==null) { add("No deep capture yet. Run button 3 or 4 first."); return; }
        add("=== LAST R19 FINGERPRINT ===");
        add("Android: " + c.androidSig);
        add("Result: " + c.result);
        add("Device: " + hex(c.device,c.device==null?0:c.device.length));
        add("Config: " + hex(c.config,c.config==null?0:c.config.length));
        for (Map.Entry<Integer,byte[]> e:c.hidReports.entrySet()) add("IF"+e.getKey()+" report: "+hex(e.getValue(),e.getValue().length));
        add("Public flashboot reference device: " + hex(PUBLIC_FLASHBOOT_DEVICE,PUBLIC_FLASHBOOT_DEVICE.length));
        add("Public flashboot reference config: " + hex(PUBLIC_FLASHBOOT_CONFIG,PUBLIC_FLASHBOOT_CONFIG.length));
        add("Public flashboot reference report: " + hex(PUBLIC_FLASHBOOT_REPORT,PUBLIC_FLASHBOOT_REPORT.length));
        add("=== END LAST FINGERPRINT ===");
    }

    private int readLanguageId(UsbDeviceConnection c) {
        byte[] b=new byte[255];
        int n=c.controlTransfer(0x80,0x06,0x0300,0,b,b.length,1500);
        if (n>=4 && (b[1]&0xFF)==0x03) {
            int lang=(b[2]&0xFF)|((b[3]&0xFF)<<8);
            ui("STRING0 LANGID descriptor => "+n+" bytes: "+hex(b,n));
            return lang;
        }
        ui("STRING0 LANGID descriptor => "+n+" bytes");
        return 0x0409;
    }

    private String readUsbString(UsbDeviceConnection c,int index,int lang) {
        byte[] b=new byte[255];
        int n=c.controlTransfer(0x80,0x06,0x0300|(index&0xFF),lang,b,b.length,1500);
        if (n<2 || (b[1]&0xFF)!=0x03) return "<read failed n="+n+">";
        int end=Math.min(n,b[0]&0xFF);
        StringBuilder s=new StringBuilder();
        for(int i=2;i+1<end;i+=2) s.append((char)((b[i]&0xFF)|((b[i+1]&0xFF)<<8)));
        return s+" [raw "+hex(b,n)+"]";
    }

    private void decodeDeviceDescriptor(byte[] b,int n) {
        if (n<18) return;
        int usbBcd=(b[2]&0xFF)|((b[3]&0xFF)<<8);
        int vid=(b[8]&0xFF)|((b[9]&0xFF)<<8);
        int pid=(b[10]&0xFF)|((b[11]&0xFF)<<8);
        int devBcd=(b[12]&0xFF)|((b[13]&0xFF)<<8);
        ui(String.format(Locale.US,"  decoded: bcdUSB=%04X class=%d sub=%d proto=%d ep0Max=%d VID:PID=%04X:%04X bcdDevice=%04X configs=%d",
                usbBcd,b[4]&0xFF,b[5]&0xFF,b[6]&0xFF,b[7]&0xFF,vid,pid,devBcd,b[17]&0xFF));
    }

    private void copyLog() {
        ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("OKN direct USB-C R19 log",log.getText()));
        Toast.makeText(this,"Log copied",Toast.LENGTH_SHORT).show();
    }

    private static String sig(UsbDevice d) {
        return String.format(Locale.US,"VID:PID=%04X:%04X interfaces=%d deviceId=%d name=%s",
                d.getVendorId(),d.getProductId(),d.getInterfaceCount(),d.getDeviceId(),safe(d.getDeviceName()));
    }

    private static boolean eq(byte[] a,byte[] b) { return a!=null && b!=null && Arrays.equals(a,b); }
    private static String safe(String s) { return s==null?"<null>":s; }
    private static String hex(byte[] b,int n) {
        if (b==null || n<=0) return "<none>";
        StringBuilder s=new StringBuilder();
        for(int i=0;i<n && i<b.length;i++) { if(i>0)s.append(' '); s.append(String.format(Locale.US,"%02X",b[i]&0xFF)); }
        return s.toString();
    }
    private static byte[] hx(String s) {
        String[] p=s.trim().split("\\s+"); byte[] out=new byte[p.length];
        for(int i=0;i<p.length;i++) out[i]=(byte)Integer.parseInt(p[i],16);
        return out;
    }
    private void add(String s) { runOnUiThread(() -> log.append(s+"\n")); }
    private void ui(String s) { runOnUiThread(() -> log.append(s+"\n")); }

    private static final class Capture {
        String androidSig;
        int vid,pid,interfaces;
        byte[] device,config;
        final Map<Integer,byte[]> hidReports=new LinkedHashMap<>();
        String result="<not classified>";
    }
}
