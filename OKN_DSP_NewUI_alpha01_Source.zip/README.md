# OKN DSP New UI

Fresh Android UI project built from the V55 control concepts, with a separate package so it can coexist with the old app.

## App ID
`com.okn.dspnewui`

## Current alpha scope
- HOME: master volume, status cards, quick access.
- PEQ: 10 channel groups and 15 bands per group.
- Every PEQ editor value has minus / slider / plus controls.
- OUTPUT: CH1–CH7, each with minus / slider / plus controls.
- Local persistence with SharedPreferences.
- SET: app info, local data reset, explicit safe/offline state.
- No INTERNET / USB / Bluetooth permissions.
- No device-write transport yet.

## Build
- Java 17
- Android Gradle Plugin 8.7.3
- compileSdk / targetSdk 35
- minSdk 26

Open in Android Studio and run `assembleDebug`.
