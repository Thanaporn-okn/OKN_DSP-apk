package com.okn.dspnewui;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public final class MainActivity extends Activity {
    private static final int WHITE = Color.rgb(245, 250, 255);
    private static final int MUTED = Color.rgb(158, 181, 201);
    private static final int AQUA = Color.rgb(78, 215, 200);
    private static final int BLUE = Color.rgb(90, 184, 255);
    private static final int PANEL = Color.argb(224, 8, 19, 29);
    private static final int PANEL_SOFT = Color.argb(214, 15, 32, 46);
    private static final int PANEL_HI = Color.argb(235, 22, 48, 62);
    private static final int BORDER = Color.argb(70, 220, 242, 255);

    private static final String[] EQ_CHANNELS = {
            "L", "R", "BASS", "CH1", "CH2", "CH3", "CH4", "CH5", "CH6", "CH7"
    };

    private DspStore store;
    private FrameLayout content;
    private LinearLayout nav;
    private int page;
    private int eqChannel;
    private int eqBand;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window w = getWindow();
        w.setStatusBarColor(Color.TRANSPARENT);
        w.setNavigationBarColor(Color.rgb(5, 12, 18));
        store = new DspStore(this);
        page = clamp(store.page(), 0, 3);
        eqChannel = clamp(store.eqChannel(), 0, EQ_CHANNELS.length - 1);
        eqBand = clamp(store.eqBand(), 0, 14);
        setContentView(buildRoot());
        showPage(page);
    }

    private View buildRoot() {
        FrameLayout root = new FrameLayout(this);
        ImageView background = new ImageView(this);
        background.setImageResource(R.drawable.background);
        background.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(background, match());

        View tint = new View(this);
        tint.setBackgroundColor(Color.argb(158, 0, 8, 14));
        root.addView(tint, match());

        LinearLayout shell = vbox();
        shell.setPadding(dp(14), dp(14), dp(14), dp(14));
        root.addView(shell, match());
        shell.addView(buildHeader(), lp(-1, dp(82)));
        shell.addView(space(10));
        content = new FrameLayout(this);
        shell.addView(content, new LinearLayout.LayoutParams(-1, 0, 1f));
        shell.addView(space(10));
        nav = buildBottomNav();
        shell.addView(nav, lp(-1, dp(66)));
        return root;
    }

    private View buildHeader() {
        LinearLayout row = hbox();
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(10), dp(12), dp(10));
        row.setBackground(card(PANEL, 24, BORDER));

        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.app_icon);
        row.addView(icon, lp(dp(54), dp(54)));

        LinearLayout copy = vbox();
        copy.setPadding(dp(12), 0, dp(8), 0);
        copy.addView(label("OKN DSP", 18, WHITE, true));
        copy.addView(label("NEW CONTROL UI  •  LOCAL MODE", 10, MUTED, true));
        row.addView(copy, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView chip = label("OFFLINE", 10, Color.rgb(255, 219, 130), true);
        chip.setGravity(Gravity.CENTER);
        chip.setBackground(card(Color.argb(220, 89, 61, 19), 16, Color.TRANSPARENT));
        row.addView(chip, lp(dp(76), dp(34)));
        return row;
    }

    private LinearLayout buildBottomNav() {
        LinearLayout row = hbox();
        row.setPadding(dp(5), dp(5), dp(5), dp(5));
        row.setBackground(card(Color.argb(238, 5, 15, 23), 22, BORDER));
        String[] labels = {"HOME", "PEQ", "OUTPUT", "SET"};
        for (int i = 0; i < labels.length; i++) {
            final int index = i;
            Button b = actionButton(labels[i]);
            b.setTag(index);
            b.setOnClickListener(v -> showPage(index));
            row.addView(b, new LinearLayout.LayoutParams(0, -1, 1f));
        }
        return row;
    }

    private void showPage(int index) {
        page = clamp(index, 0, 3);
        store.page(page);
        content.removeAllViews();
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout body = vbox();
        body.setPadding(0, 0, 0, dp(8));
        scroll.addView(body, new ScrollView.LayoutParams(-1, -2));
        content.addView(scroll, match());
        if (page == 0) buildHome(body);
        else if (page == 1) buildPeq(body);
        else if (page == 2) buildOutput(body);
        else buildSettings(body);
        refreshNav();
    }

    private void refreshNav() {
        for (int i = 0; i < nav.getChildCount(); i++) {
            Button b = (Button) nav.getChildAt(i);
            boolean active = ((Integer) b.getTag()) == page;
            b.setTextColor(active ? Color.rgb(4, 28, 31) : WHITE);
            b.setBackground(card(active ? AQUA : Color.TRANSPARENT, 17, Color.TRANSPARENT));
        }
    }

    private void buildHome(LinearLayout body) {
        body.addView(titleBlock("CONTROL CENTER", "New layout based on V55 controls"));
        body.addView(space(10));

        LinearLayout master = panel();
        LinearLayout top = hbox();
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(section("MASTER OUTPUT"), new LinearLayout.LayoutParams(0, -2, 1f));
        TextView local = pill("LOCAL DATA", Color.rgb(104, 234, 197), Color.argb(120, 15, 100, 76));
        top.addView(local);
        master.addView(top);
        master.addView(space(8));
        master.addView(valueControl("Master Volume", -70f, 6f, 0.5f, store.master(), "dB", store::master, null));
        body.addView(master);
        body.addView(space(10));

        GridLayout quick = new GridLayout(this);
        quick.setColumnCount(2);
        addQuickCard(quick, "DSP", "READY", "15-band PEQ");
        addQuickCard(quick, "OUTPUT", "7 CH", "0.5 dB step");
        addQuickCard(quick, "DEVICE", "OFFLINE", "safe local mode");
        addQuickCard(quick, "PROFILE", "DEFAULT", "stored on device");
        body.addView(quick);
        body.addView(space(10));

        LinearLayout shortcuts = panel();
        shortcuts.addView(section("QUICK ACCESS"));
        shortcuts.addView(space(8));
        Button peq = primaryButton("Open Parametric EQ");
        peq.setOnClickListener(v -> showPage(1));
        shortcuts.addView(peq, lp(-1, dp(52)));
        shortcuts.addView(space(8));
        Button out = secondaryButton("Open CH1–CH7 Output Trim");
        out.setOnClickListener(v -> showPage(2));
        shortcuts.addView(out, lp(-1, dp(50)));
        body.addView(shortcuts);
    }

    private void buildPeq(LinearLayout body) {
        body.addView(titleBlock("PARAMETRIC EQ", "10 channel groups • 15 bands • direct +/- control"));
        body.addView(space(10));

        LinearLayout channels = panel();
        channels.addView(section("CHANNEL GROUP"));
        channels.addView(space(8));
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout chipRow = hbox();
        hsv.addView(chipRow, new HorizontalScrollView.LayoutParams(-2, -2));
        channels.addView(hsv, lp(-1, dp(48)));
        body.addView(channels);
        body.addView(space(10));

        LinearLayout bands = panel();
        bands.addView(section("15 BANDS"));
        TextView help = label("Select a band, then use the controls below.", 11, MUTED, false);
        help.setPadding(0, dp(3), 0, dp(7));
        bands.addView(help);
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(3);
        bands.addView(grid);
        body.addView(bands);
        body.addView(space(10));

        LinearLayout editor = panel();
        body.addView(editor);

        Runnable rebuild = () -> {
            rebuildEqChannels(chipRow, grid, editor);
            rebuildEqGrid(grid, editor);
        };
        rebuild.run();
    }

    private void rebuildEqChannels(LinearLayout chipRow, GridLayout grid, LinearLayout editor) {
        chipRow.removeAllViews();
        for (int i = 0; i < EQ_CHANNELS.length; i++) {
            final int ch = i;
            Button chip = actionButton(EQ_CHANNELS[i]);
            boolean active = ch == eqChannel;
            chip.setTextColor(active ? Color.rgb(6, 29, 32) : WHITE);
            chip.setBackground(card(active ? AQUA : PANEL_HI, 16, active ? Color.TRANSPARENT : BORDER));
            chip.setOnClickListener(v -> {
                eqChannel = ch;
                store.eqChannel(ch);
                rebuildEqChannels(chipRow, grid, editor);
                rebuildEqGrid(grid, editor);
            });
            LinearLayout.LayoutParams p = lp(dp(ch >= 3 ? 62 : 68), dp(42));
            p.setMargins(0, 0, dp(7), 0);
            chipRow.addView(chip, p);
        }
    }

    private void rebuildEqGrid(GridLayout grid, LinearLayout editor) {
        grid.removeAllViews();
        for (int i = 0; i < 15; i++) {
            final int band = i;
            float f = store.eqFreq(eqChannel, band);
            float g = store.eqGain(eqChannel, band);
            Button card = actionButton("B" + (i + 1) + "\n" + compactHz(f) + "  " + signed(g) + "dB");
            card.setTextSize(10);
            boolean active = i == eqBand;
            card.setTextColor(active ? Color.rgb(5, 26, 30) : WHITE);
            card.setBackground(card(active ? AQUA : PANEL_HI, 16, active ? Color.TRANSPARENT : BORDER));
            card.setOnClickListener(v -> {
                eqBand = band;
                store.eqBand(band);
                rebuildEqGrid(grid, editor);
            });
            GridLayout.LayoutParams p = new GridLayout.LayoutParams();
            p.width = 0;
            p.height = dp(68);
            p.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            p.setMargins(dp(3), dp(3), dp(3), dp(3));
            grid.addView(card, p);
        }
        rebuildEqEditor(editor, grid);
    }

    private void rebuildEqEditor(LinearLayout editor, GridLayout grid) {
        editor.removeAllViews();
        editor.addView(section("BAND " + (eqBand + 1) + " EDITOR  •  " + EQ_CHANNELS[eqChannel]));
        editor.addView(space(5));
        Runnable cards = () -> refreshBandLabels(grid);
        editor.addView(valueControl("Frequency", 20f, 20000f, 10f,
                store.eqFreq(eqChannel, eqBand), "Hz",
                v -> store.eqFreq(eqChannel, eqBand, v), cards));
        editor.addView(divider());
        editor.addView(valueControl("Gain", -12f, 12f, 0.5f,
                store.eqGain(eqChannel, eqBand), "dB",
                v -> store.eqGain(eqChannel, eqBand, v), cards));
        editor.addView(divider());
        editor.addView(valueControl("Q", 0.1f, 10f, 0.1f,
                store.eqQ(eqChannel, eqBand), "",
                v -> store.eqQ(eqChannel, eqBand, v), null));
    }

    private void refreshBandLabels(GridLayout grid) {
        for (int i = 0; i < grid.getChildCount(); i++) {
            Button card = (Button) grid.getChildAt(i);
            card.setText("B" + (i + 1) + "\n" + compactHz(store.eqFreq(eqChannel, i)) +
                    "  " + signed(store.eqGain(eqChannel, i)) + "dB");
        }
    }

    private void buildOutput(LinearLayout body) {
        body.addView(titleBlock("OUTPUT TRIM", "CH1–CH7 • each channel has – / slider / +"));
        body.addView(space(10));
        LinearLayout box = panel();
        for (int i = 0; i < 7; i++) {
            final int ch = i;
            if (i > 0) box.addView(divider());
            LinearLayout top = hbox();
            top.setGravity(Gravity.CENTER_VERTICAL);
            top.addView(label("CH" + (i + 1), 16, WHITE, true), new LinearLayout.LayoutParams(0, -2, 1f));
            top.addView(pill("OUTPUT", BLUE, Color.argb(95, 29, 78, 112)));
            box.addView(top);
            box.addView(valueControl("Level", -70f, 6f, 0.5f, store.outputTrim(ch), "dB",
                    v -> store.outputTrim(ch, v), null));
        }
        body.addView(box);
    }

    private void buildSettings(LinearLayout body) {
        body.addView(titleBlock("SETTINGS", "New UI configuration and local safety"));
        body.addView(space(10));

        LinearLayout app = panel();
        app.addView(section("APP"));
        app.addView(infoLine("Name", "OKN DSP New UI"));
        app.addView(infoLine("Package", "com.okn.dspnewui"));
        app.addView(infoLine("Version", "1.0.0-alpha01"));
        body.addView(app);
        body.addView(space(10));

        LinearLayout safety = panel();
        safety.addView(section("SAFE LOCAL MODE"));
        safety.addView(infoLine("USB write", "DISABLED"));
        safety.addView(infoLine("Bluetooth control", "DISABLED"));
        safety.addView(infoLine("Network", "NO PERMISSION"));
        safety.addView(infoLine("Flash write", "DISABLED"));
        body.addView(safety);
        body.addView(space(10));

        LinearLayout data = panel();
        data.addView(section("LOCAL PARAMETERS"));
        data.addView(space(8));
        Button save = primaryButton("Save current values");
        save.setOnClickListener(v -> Toast.makeText(this, "Values are already stored locally ✓", Toast.LENGTH_SHORT).show());
        data.addView(save, lp(-1, dp(52)));
        data.addView(space(8));
        Button reset = secondaryButton("Reset to defaults");
        reset.setOnClickListener(v -> {
            store.reset();
            eqChannel = 0;
            eqBand = 0;
            Toast.makeText(this, "Reset complete", Toast.LENGTH_SHORT).show();
            showPage(0);
        });
        data.addView(reset, lp(-1, dp(50)));
        body.addView(data);
    }

    private View valueControl(String name, float min, float max, float step, float initial,
                              String unit, ValueSetter setter, Runnable changed) {
        LinearLayout wrapper = vbox();
        wrapper.setPadding(0, dp(9), 0, dp(9));
        LinearLayout head = hbox();
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = label(name, 12, WHITE, false);
        TextView value = label("", 13, BLUE, true);
        value.setGravity(Gravity.END);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        head.addView(value, lp(dp(112), -2));
        wrapper.addView(head);
        wrapper.addView(space(5));

        LinearLayout controls = hbox();
        controls.setGravity(Gravity.CENTER_VERTICAL);
        Button minus = squareButton("−");
        Button plus = squareButton("+");
        SeekBar seek = new SeekBar(this);
        int maxSteps = Math.max(1, Math.round((max - min) / step));
        seek.setMax(maxSteps);
        seek.setProgress(clamp(Math.round((initial - min) / step), 0, maxSteps));

        Runnable render = () -> {
            float current = min + seek.getProgress() * step;
            value.setText(format(current, step) + (unit.isEmpty() ? "" : " " + unit));
        };
        Runnable persist = () -> {
            float current = min + seek.getProgress() * step;
            setter.set(current);
            render.run();
            if (changed != null) changed.run();
        };
        render.run();

        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                render.run();
                if (fromUser) persist.run();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { persist.run(); }
        });
        minus.setOnClickListener(v -> {
            seek.setProgress(Math.max(0, seek.getProgress() - 1));
            persist.run();
        });
        plus.setOnClickListener(v -> {
            seek.setProgress(Math.min(seek.getMax(), seek.getProgress() + 1));
            persist.run();
        });

        controls.addView(minus, lp(dp(46), dp(44)));
        controls.addView(seek, new LinearLayout.LayoutParams(0, dp(44), 1f));
        controls.addView(plus, lp(dp(46), dp(44)));
        wrapper.addView(controls);
        return wrapper;
    }

    private void addQuickCard(GridLayout grid, String title, String value, String caption) {
        LinearLayout card = vbox();
        card.setPadding(dp(12), dp(12), dp(12), dp(12));
        card.setBackground(card(PANEL_SOFT, 18, BORDER));
        card.addView(label(title, 10, MUTED, true));
        card.addView(label(value, 18, WHITE, true));
        card.addView(label(caption, 10, MUTED, false));
        GridLayout.LayoutParams p = new GridLayout.LayoutParams();
        p.width = 0;
        p.height = dp(92);
        p.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        p.setMargins(dp(3), dp(3), dp(3), dp(3));
        grid.addView(card, p);
    }

    private LinearLayout panel() {
        LinearLayout box = vbox();
        box.setPadding(dp(13), dp(12), dp(13), dp(12));
        box.setBackground(card(PANEL, 22, BORDER));
        return box;
    }

    private View titleBlock(String title, String subtitle) {
        LinearLayout box = vbox();
        box.setPadding(dp(4), dp(4), dp(4), 0);
        box.addView(label(title, 16, Color.rgb(214, 239, 255), true));
        box.addView(label(subtitle, 11, MUTED, false));
        return box;
    }

    private TextView section(String value) {
        TextView t = label(value, 12, Color.rgb(207, 234, 250), true);
        t.setLetterSpacing(0.05f);
        return t;
    }

    private View infoLine(String left, String right) {
        LinearLayout row = hbox();
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(8), 0, dp(8));
        row.addView(label(left, 12, MUTED, false), new LinearLayout.LayoutParams(0, -2, 1f));
        TextView r = label(right, 12, WHITE, true);
        r.setGravity(Gravity.END);
        row.addView(r, lp(dp(190), -2));
        return row;
    }

    private TextView pill(String text, int fg, int bg) {
        TextView v = label(text, 10, fg, true);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(9), dp(5), dp(9), dp(5));
        v.setBackground(card(bg, 14, Color.TRANSPARENT));
        return v;
    }

    private Button actionButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(WHITE);
        b.setTextSize(11);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        b.setAllCaps(false);
        b.setMinHeight(0);
        b.setMinWidth(0);
        b.setPadding(dp(6), 0, dp(6), 0);
        b.setBackground(card(PANEL_HI, 15, Color.TRANSPARENT));
        return b;
    }

    private Button squareButton(String text) {
        Button b = actionButton(text);
        b.setTextSize(20);
        b.setBackground(card(PANEL_HI, 15, BORDER));
        return b;
    }

    private Button primaryButton(String text) {
        Button b = actionButton(text);
        b.setTextSize(13);
        b.setTextColor(Color.rgb(5, 30, 31));
        b.setBackground(card(AQUA, 16, Color.TRANSPARENT));
        return b;
    }

    private Button secondaryButton(String text) {
        Button b = actionButton(text);
        b.setTextSize(13);
        b.setBackground(card(PANEL_HI, 16, BORDER));
        return b;
    }

    private TextView label(String text, int sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setTypeface(Typeface.create(bold ? "sans-serif-medium" : "sans-serif", Typeface.NORMAL));
        v.setIncludeFontPadding(false);
        return v;
    }

    private View divider() {
        View v = new View(this);
        v.setBackgroundColor(Color.argb(50, 230, 244, 255));
        v.setLayoutParams(lp(-1, dp(1)));
        return v;
    }

    private LinearLayout vbox() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        return v;
    }

    private LinearLayout hbox() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.HORIZONTAL);
        return v;
    }

    private View space(int dp) {
        View v = new View(this);
        v.setLayoutParams(lp(1, this.dp(dp)));
        return v;
    }

    private FrameLayout.LayoutParams match() { return new FrameLayout.LayoutParams(-1, -1); }
    private LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w, h); }

    private GradientDrawable card(int fill, int radiusDp, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radiusDp));
        if (stroke != Color.TRANSPARENT) d.setStroke(dp(1), stroke);
        return d;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private static String signed(float value) {
        return String.format(Locale.US, value >= 0 ? "+%.1f" : "%.1f", value);
    }

    private static String compactHz(float value) {
        if (value >= 1000f) {
            float k = value / 1000f;
            if (Math.abs(k - Math.round(k)) < 0.001f) return Math.round(k) + "k";
            return String.format(Locale.US, "%.1fk", k);
        }
        return Math.round(value) + "Hz";
    }

    private static String format(float value, float step) {
        if (step >= 1f && Math.abs(value - Math.round(value)) < 0.001f) {
            return Integer.toString(Math.round(value));
        }
        return String.format(Locale.US, "%.1f", value);
    }

    @FunctionalInterface private interface ValueSetter { void set(float value); }
}
