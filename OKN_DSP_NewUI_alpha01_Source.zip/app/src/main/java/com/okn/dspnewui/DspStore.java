package com.okn.dspnewui;

import android.content.Context;
import android.content.SharedPreferences;

public final class DspStore {
    public static final float[] DEFAULT_FREQ = {
            31f, 45f, 63f, 90f, 125f, 180f, 250f, 355f, 500f, 710f,
            1000f, 2000f, 4000f, 8000f, 16000f
    };

    private final SharedPreferences prefs;

    public DspStore(Context context) {
        prefs = context.getSharedPreferences("okn_dsp_new_ui", Context.MODE_PRIVATE);
    }

    public int page() { return prefs.getInt("page", 0); }
    public void page(int value) { prefs.edit().putInt("page", value).apply(); }

    public int eqChannel() { return prefs.getInt("eq_channel", 0); }
    public void eqChannel(int value) { prefs.edit().putInt("eq_channel", value).apply(); }

    public int eqBand() { return prefs.getInt("eq_band", 0); }
    public void eqBand(int value) { prefs.edit().putInt("eq_band", value).apply(); }

    public float master() { return prefs.getFloat("master", -12f); }
    public void master(float value) { prefs.edit().putFloat("master", value).apply(); }

    public float eqFreq(int ch, int band) {
        return prefs.getFloat(eqKey(ch, band, "freq"), DEFAULT_FREQ[band]);
    }
    public void eqFreq(int ch, int band, float value) {
        prefs.edit().putFloat(eqKey(ch, band, "freq"), value).apply();
    }
    public float eqGain(int ch, int band) {
        return prefs.getFloat(eqKey(ch, band, "gain"), 0f);
    }
    public void eqGain(int ch, int band, float value) {
        prefs.edit().putFloat(eqKey(ch, band, "gain"), value).apply();
    }
    public float eqQ(int ch, int band) {
        return prefs.getFloat(eqKey(ch, band, "q"), 1f);
    }
    public void eqQ(int ch, int band, float value) {
        prefs.edit().putFloat(eqKey(ch, band, "q"), value).apply();
    }

    public float outputTrim(int ch) {
        return prefs.getFloat("output_" + ch, 0f);
    }
    public void outputTrim(int ch, float value) {
        prefs.edit().putFloat("output_" + ch, value).apply();
    }

    public void reset() { prefs.edit().clear().apply(); }

    private static String eqKey(int ch, int band, String suffix) {
        return "eq_" + ch + "_" + band + "_" + suffix;
    }
}
