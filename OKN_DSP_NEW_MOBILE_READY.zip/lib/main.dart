import 'package:flutter/material.dart';

void main() {
  runApp(const OKNDSP());
}

class OKNDSP extends StatelessWidget {
  const OKNDSP({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: const Color(0xff10151c),
        body: Center(
          child: Text(
            'OKN_DSP BP1048P4 V4',
            style: TextStyle(
              color: Colors.cyan,
              fontSize: 32,
            ),
          ),
        ),
      ),
    );
  }
}
