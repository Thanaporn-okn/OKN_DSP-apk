import 'package:flutter/material.dart';

void main()=>runApp(const OKNV16());

class OKNV16 extends StatelessWidget{
 const OKNV16({super.key});

 @override
 Widget build(BuildContext context){
  return MaterialApp(
   debugShowCheckedModeBanner:false,
   home: Scaffold(
    backgroundColor: const Color(0xff121018),
    body: SafeArea(
     child: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
       crossAxisAlignment: CrossAxisAlignment.start,
       children:[
        const Text('OKN_DSP BP1048P4 V16',
        style:TextStyle(color:Colors.cyan,fontSize:28)),
        const SizedBox(height:25),
        const Text(
        'Bluetooth Connect\n'
        'Device Scan Ready\n'
        'DSP Read / Write Command\n'
        'HEX TX RX Log\n'
        'Save / Load Preset',
        style:TextStyle(color:Colors.white,fontSize:18)),
       ],
      ),
     ),
    ),
   ),
  );
 }
}
