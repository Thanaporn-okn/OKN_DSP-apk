import 'package:flutter/material.dart';

void main()=>runApp(const OKNDSP());

class OKNDSP extends StatelessWidget{
 const OKNDSP({super.key});
 Widget build(BuildContext c)=>MaterialApp(
 debugShowCheckedModeBanner:false,
 theme:ThemeData.dark(useMaterial3:true),
 home:const DSP());
}

class DSP extends StatefulWidget{
 const DSP({super.key});
 State<DSP> createState()=>_DSP();
}

class _DSP extends State<DSP>{
 int tab=0;
 final tabs=['MAIN','EQ','XOVER','DELAY','MIXER','PRESET','BT'];

 Widget build(BuildContext c)=>Scaffold(
 backgroundColor:const Color(0xff090d12),
 body:SafeArea(child:Column(children:[
 Expanded(child:view()),
 nav()
 ])));

 Widget view(){
 if(tab==1)return eq();
 if(tab==2)return xover();
 return main();
 }

 Widget box(String t,Widget w)=>Container(
 margin:const EdgeInsets.all(10),
 padding:const EdgeInsets.all(12),
 decoration:BoxDecoration(
 color:const Color(0xff18202a),
 borderRadius:BorderRadius.circular(14)),
 child:Column(children:[
 Text(t,style:const TextStyle(color:Colors.cyan,fontSize:22)),
 w]));

 Widget main()=>box('BP1048P4 7CH DSP',
 Expanded(child:Row(children:List.generate(7,(i)=>
 Expanded(child:Column(children:[
 Text('CH${i+1}'),
 Expanded(child:RotatedBox(quarterTurns:3,
 child:Slider(value:.6,onChanged:null))),
 Text('-12 dB')
 ]))))));

 Widget eq()=>box('EQ 15 BAND',
 Expanded(child:ListView(children:List.generate(15,(i)=>
 Column(children:[
 Text('${[20,31,63,125,250,500,1000,2000,4000,8000,16000][i%11]} Hz'),
 Slider(value:.5,onChanged:null)
 ])))));

 Widget xover()=>box('CROSSOVER',
 const Column(children:[
 Text('HPF Butterworth 24dB'),
 Slider(value:.5,onChanged:null),
 Text('LPF Linkwitz-Riley 48dB'),
 Slider(value:.5,onChanged:null)
 ]));

 Widget nav()=>SizedBox(height:55,child:Row(
 mainAxisAlignment:MainAxisAlignment.spaceAround,
 children:List.generate(tabs.length,(i)=>GestureDetector(
 onTap:()=>setState(()=>tab=i),
 child:Text(tabs[i],
 style:TextStyle(color:i==tab?Colors.cyan:Colors.white))))));
}
