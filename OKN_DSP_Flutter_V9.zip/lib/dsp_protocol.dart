class DSPProtocol{
 List<int> setVolume(int ch,int value){
  return [0xAA, ch, value, 0x55];
 }
 List<int> setEQ(int band,int gain){
  return [0xBB, band, gain, 0x55];
 }
}
