# OKN BP1048P4 USB Diagnostic R11

R11 ใช้ตรวจว่า R9 ปิด/ล้มด้วยเหตุผลใดจาก Android `ApplicationExitInfo` และยืนยัน USB descriptor แบบ read-only เท่านั้น

## วิธีใช้
1. อย่า uninstall R9 ก่อน
2. ติดตั้ง R11 ทับ package เดิม
3. เปิดแอป; exit history จะอ่านให้อัตโนมัติ
4. กด `1) READ R9 / APP EXIT HISTORY` อีกครั้งเพื่อคัดลอกผล
5. กด `2) READ-ONLY USB SCAN + QUALIFY` เพื่อยืนยันบอร์ดยัง enumerate ปกติ
6. ส่ง log ทั้งหมดกลับมาวิเคราะห์

R11 ไม่มี USB OUT และไม่ force-detach IF3


## R11 build fix
- แก้ host safety guard ให้หา source ด้วย path จากไฟล์ guard เอง ไม่อิง current working directory
- `tests/run_host_tests.sh` จะ `cd` ไป project root ก่อนรัน guard
- Android diagnostic behavior ยังคง read-only เหมือน R10
