# OKN DSP Android V19 — Event Fingerprint

V19 advances the passive evidence workflow using the real captures observed from the device.

## Grounded observations used
- BLE notify source observed on AB02.
- Notification payloads observed at 10 and 13 bytes in the supplied sessions.
- AB01 read returned `len=0`, so an empty read is treated as read evidence, not a protocol frame.
- CCCD subscription to AB02/AB03 succeeded with status 0.
- The app still performs no DSP WRITE.

## V19 change
Adds an **EVENT FINGERPRINT** analysis that compares captured BASELINE and EVENT notification bytes by:
- length bucket
- exact payload overlap
- nearest-baseline byte-position differences
- observed byte SUM overlap
- observed byte XOR overlap

These are capture-derived statistical observations only. V19 does not assign protocol field meanings, encryption, checksum semantics, or DSP parameter meanings.

## Use
1. Connect to the DSP.
2. Capture a baseline.
3. Perform exactly one controlled parameter change using the original controller while this app remains passive.
4. Capture the event window.
5. Press **EVENT FINGERPRINT**.
6. Repeat the same controlled change in multiple independent sessions and use **CORRELATE SESSIONS**.

WRITE remains disabled.
