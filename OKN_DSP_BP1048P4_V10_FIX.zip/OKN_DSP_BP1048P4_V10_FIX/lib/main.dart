
import 'package:flutter/material.dart';

void main() {
  runApp(const OKNDSP());
}

class OKNDSP extends StatelessWidget {
  const OKNDSP({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: const Color(0xff111017),
        body: Center(
          child: Text(
            'OKN_DSP BP1048P4 V10 FIX',
            style: TextStyle(color: Colors.cyan, fontSize: 28),
          ),
        ),
      ),
    );
  }
}
