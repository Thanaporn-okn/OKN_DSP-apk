
OKN DSP BP1048P4 V10 FIX

Flutter project structure fixed:
- pubspec.yaml
- android folder
- lib folder

Ready for GitHub Actions build.
