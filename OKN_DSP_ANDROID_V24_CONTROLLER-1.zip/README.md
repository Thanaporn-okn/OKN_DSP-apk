# OKN DSP Android V24 — 7CH Controller + Evidence Lab

Android app project for the GoloPine / BP1048P4 7-channel DSP work.

## Controller UI
- CH1..CH7 selection
- Gain -60.0 .. +12.0 dB
- Mute and Phase 0/180
- 15-band EQ per channel
- HPF / LPF crossover targets
- Delay 0..20 ms
- 7-channel mixer
- 6 local presets stored on the phone
- BLE scan/connect to GoloPine/DSP devices
- AB00 discovery with AB02/AB03 notification subscription

## Evidence Lab
The previous capture/differential/correlation/stability lab is retained as a separate screen.

## Critical write gate
DSP actuator writes are deliberately disabled in `protocol/WriteGate.kt`.
The current evidence confirms the BLE transport profile, but exact application framing,
authentication/encryption, integrity checks, actuator mapping and SigmaDSP coefficient
serialization still need independent verification before safe writes can be enabled.

The controller therefore acts as a complete UI/state shell now. Values are saved locally,
not transmitted as guessed DSP commands.

## Build
GitHub Actions workflow: `.github/workflows/build-android.yml`

Upload the project files to a GitHub repository, open **Actions > Build Android APK > Run workflow**,
then download the `OKN-DSP-V24.1-FIX1-controller-debug-apk` artifact.


## V24.1 FIX1
- Fixed missing `com.okn.dsp.transport.BleProfile` import in `EvidenceLabActivity.kt`.
- Replaced unsupported `IntArray.mapIndexedNotNull` usage with an explicit loop.
- No DSP/UFE write behavior was enabled; evidence/read/notify safety policy is unchanged.
