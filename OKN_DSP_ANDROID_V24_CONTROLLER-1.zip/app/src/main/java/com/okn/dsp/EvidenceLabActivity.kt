package com.okn.dsp

import android.Manifest
import android.app.Activity
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.*
import android.content.Intent
import android.content.ActivityNotFoundException
import android.net.Uri
import android.provider.OpenableColumns
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.core.app.ActivityCompat
import com.okn.dsp.transport.BleProfile
import java.util.UUID

class EvidenceLabActivity : Activity() {
    private lateinit var log: TextView
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val found = LinkedHashMap<String, BluetoothDevice>()
    private var scanner: BluetoothLeScanner? = null
    private var gatt: BluetoothGatt? = null
    private val notifyQueue = ArrayDeque<BluetoothGattCharacteristic>()
    private var descriptorWriteInProgress = false
    private val logLines = StringBuilder()
    private val captureLines = mutableListOf<String>()
    private var packetNo = 0
    private var sessionNo = 0
    private val ts = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    private val OPEN_CAPTURE = 200
    private var importedA: List<String>? = null
    private var importedB: List<String>? = null

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        buildUi()
        requestBlePermissions()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }

        val title = TextView(this).apply {
            text = "OKN DSP Controller\nV24 EVIDENCE LAB"
            textSize = 22f
        }

        status = TextView(this).apply {
            text = "WRITE DISABLED — capture/read/notify only"
            textSize = 15f
        }

        val scan = Button(this).apply {
            text = "SCAN DSP"
            setOnClickListener { startScan() }
        }

        val save = Button(this).apply {
            text = "SAVE CAPTURE"
            setOnClickListener { shareCapture() }
        }

        val analyze = Button(this).apply {
            text = "ANALYZE CAPTURE"
            setOnClickListener { analyzeCapture() }
        }

        val importBtn = Button(this).apply {
            text = "IMPORT CAPTURE"
            setOnClickListener { openCaptureFile() }
        }

        val correlate = Button(this).apply {
            text = "CORRELATE TX/RX"
            setOnClickListener { analyzeTemporalCorrelation() }
        }

        val diff = Button(this).apply {
            text = "DIFF A/B BYTES"
            setOnClickListener { analyzeControlledByteDiff() }
        }

        val stability = Button(this).apply {
            text = "STABILITY REPORT"
            setOnClickListener { analyzeControlledStability() }
        }

        val clear = Button(this).apply {
            text = "CLEAR LOG"
            setOnClickListener {
                logLines.clear()
                captureLines.clear()
                importedA = null
                importedB = null
                log.text = "Log:\n"
            }
        }

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        log = TextView(this).apply {
            text = "Log:\n"
            textSize = 13f
        }

        root.addView(title)
        root.addView(status)
        root.addView(scan)
        root.addView(save)
        root.addView(analyze)
        root.addView(importBtn)
        root.addView(correlate)
        root.addView(diff)
        root.addView(stability)
        root.addView(clear)
        root.addView(list)
        root.addView(log)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun requestBlePermissions() {
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT
                ),
                100
            )
        }
    }

    private fun startScan() {
        if (!hasBlePermission()) {
            append("Bluetooth permission not granted")
            return
        }

        val manager = getSystemService(BluetoothManager::class.java)
        val adapter = manager?.adapter
        if (adapter == null) {
            append("Bluetooth adapter not available")
            return
        }
        if (!adapter.isEnabled) {
            append("Bluetooth is OFF — turn Bluetooth ON and scan again")
            return
        }

        scanner = adapter.bluetoothLeScanner
        if (scanner == null) {
            append("BLE scanner not available")
            return
        }

        found.clear()
        list.removeAllViews()
        append("Scanning for LE-GOLOPINE DSP ...")

        try {
            scanner?.startScan(callback)
        } catch (_: SecurityException) {
            append("Bluetooth permission denied")
            return
        }

        handler.postDelayed({
            try { scanner?.stopScan(callback) } catch (_: Exception) {}
            append("Scan finished")
        }, 10000)
    }

    private fun hasBlePermission(): Boolean =
        android.os.Build.VERSION.SDK_INT < 31 ||
        (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
         checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED)

    private val callback = object : ScanCallback() {
        override fun onScanResult(type: Int, result: ScanResult) {
            val device = result.device
            val name = result.scanRecord?.deviceName
                ?: try { device.name } catch (_: SecurityException) { null }

            if (name?.contains("GOLOPINE", true) == true ||
                name?.contains("DSP", true) == true) {
                if (!found.containsKey(device.address)) {
                    found[device.address] = device
                    runOnUiThread {
                        val b = Button(this@EvidenceLabActivity).apply {
                            text = "${name ?: "DSP"}\n${device.address}\nTAP TO CONNECT"
                            setOnClickListener { connect(device, name ?: "DSP") }
                        }
                        list.addView(b)
                    }
                }
            }
        }

        override fun onScanFailed(errorCode: Int) {
            append("BLE scan failed: $errorCode")
        }
    }

    private fun connect(device: BluetoothDevice, name: String) {
        sessionNo += 1
        packetNo = 0
        synchronized(captureLines) { captureLines.add("=== SESSION #$sessionNo START ${ts.format(Date())} ===") }
        if (!hasBlePermission()) {
            append("Bluetooth permission not granted")
            return
        }

        try {
            gatt?.close()
            gatt = null
            notifyQueue.clear()
            descriptorWriteInProgress = false
            status.text = "CONNECTING — $name"
            append("Connecting to $name ${device.address} ...")
            gatt = device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
        } catch (_: SecurityException) {
            append("Bluetooth permission denied")
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, statusCode: Int, newState: Int) {
            append("GATT state=$newState status=$statusCode")
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                status.text = "CONNECTED — discovery/read/notify only"
                append("Connected — discovering services")
                try { g.discoverServices() }
                catch (_: SecurityException) { append("Service discovery permission denied") }
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                status.text = "DISCONNECTED"
                append("Disconnected")
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, statusCode: Int) {
            append("Services discovered: status=$statusCode")
            if (statusCode != BluetoothGatt.GATT_SUCCESS) return

            notifyQueue.clear()

            val abService = g.services.firstOrNull { it.uuid == BleProfile.AB00_SERVICE }
            val preferredNotify = abService?.characteristics?.filter { it.uuid == BleProfile.AB02_NOTIFY || it.uuid == BleProfile.AB03_NOTIFY } ?: emptyList()

            g.services.forEachIndexed { si, service ->
                append("SERVICE[$si] ${service.uuid}")
                service.characteristics.forEachIndexed { ci, ch ->
                    val props = properties(ch)
                    append("  CHAR[$ci] ${ch.uuid} [$props]")
                    ch.descriptors.forEach { d ->
                        append("    DESC ${d.uuid}")
                    }

                    if (preferredNotify.isNotEmpty()) {
                        if (preferredNotify.any { it.uuid == ch.uuid }) notifyQueue.addLast(ch)
                    } else if ((ch.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0 ||
                        (ch.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) {
                        notifyQueue.addLast(ch)
                    }
                }
            }

            append("NOTIFY TARGETS=${notifyQueue.size} (AB02/AB03 preferred when present)")
            processNextNotificationSubscription(g)

            // Read one characteristic at a time to avoid GATT_BUSY.
            handler.postDelayed({ readNextReadable(g) }, 500)
        }

        override fun onDescriptorWrite(
            g: BluetoothGatt,
            descriptor: BluetoothGattDescriptor,
            statusCode: Int
        ) {
            append("CCCD WRITE ${descriptor.uuid} status=$statusCode")
            descriptorWriteInProgress = false
            handler.postDelayed({ processNextNotificationSubscription(g) }, 250)
        }

        override fun onCharacteristicChanged(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            value: ByteArray
        ) {
            capture("RX_NOTIFY", characteristic.uuid.toString(), value)
        }

        override fun onCharacteristicRead(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            value: ByteArray,
            statusCode: Int
        ) {
            capture("RX_READ", characteristic.uuid.toString(), value, "status=$statusCode")
            handler.postDelayed({ readNextReadable(g) }, 250)
        }

        @Suppress("DEPRECATION")
        override fun onCharacteristicRead(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            statusCode: Int
        ) {
            capture("RX_READ", characteristic.uuid.toString(), characteristic.value ?: byteArrayOf(), "status=$statusCode")
            handler.postDelayed({ readNextReadable(g) }, 250)
        }
    }

    private var readableQueue = ArrayDeque<BluetoothGattCharacteristic>()

    private fun readNextReadable(g: BluetoothGatt) {
        if (!hasBlePermission()) return
        if (readableQueue.isEmpty()) {
            readableQueue.addAll(
                g.services.flatMap { it.characteristics }
                    .filter { it.properties and BluetoothGattCharacteristic.PROPERTY_READ != 0 }
            )
        }
        val ch = readableQueue.removeFirstOrNull() ?: return
        append("READ REQUEST ${shortUuid(ch.uuid)}")
        try {
            g.readCharacteristic(ch)
        } catch (_: Exception) {
            handler.postDelayed({ readNextReadable(g) }, 300)
        }
    }

    private fun processNextNotificationSubscription(g: BluetoothGatt) {
        if (descriptorWriteInProgress) return
        val ch = notifyQueue.removeFirstOrNull() ?: return
        subscribeToNotifications(g, ch)
    }

    private fun subscribeToNotifications(g: BluetoothGatt, ch: BluetoothGattCharacteristic) {
        if (!hasBlePermission()) return

        try {
            val localOk = g.setCharacteristicNotification(ch, true)
            append("SUBSCRIBE ${shortUuid(ch.uuid)} local=$localOk")

            val cccd = ch.getDescriptor(
                UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
            )

            if (cccd == null) {
                append("  CCCD NOT FOUND")
                handler.postDelayed({ processNextNotificationSubscription(g) }, 250)
                return
            }

            val value =
                if ((ch.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0)
                    BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
                else
                    BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE

            descriptorWriteInProgress = true

            if (android.os.Build.VERSION.SDK_INT >= 33) {
                val rc = g.writeDescriptor(cccd, value)
                append("  CCCD REQUEST rc=$rc")
                if (rc != BluetoothGatt.GATT_SUCCESS) {
                    descriptorWriteInProgress = false
                    handler.postDelayed({ processNextNotificationSubscription(g) }, 500)
                }
            } else {
                @Suppress("DEPRECATION")
                cccd.value = value
                @Suppress("DEPRECATION")
                val ok = g.writeDescriptor(cccd)
                append("  CCCD REQUEST ok=$ok")
                if (!ok) {
                    descriptorWriteInProgress = false
                    handler.postDelayed({ processNextNotificationSubscription(g) }, 500)
                }
            }
        } catch (_: SecurityException) {
            append("  CCCD permission denied")
            descriptorWriteInProgress = false
        } catch (e: Exception) {
            append("  CCCD error=${e.message}")
            descriptorWriteInProgress = false
        }
    }

    private fun properties(ch: BluetoothGattCharacteristic): String {
        val p = mutableListOf<String>()
        if (ch.properties and BluetoothGattCharacteristic.PROPERTY_READ != 0) p.add("READ")
        if (ch.properties and BluetoothGattCharacteristic.PROPERTY_WRITE != 0) p.add("WRITE")
        if (ch.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0) p.add("WRITE_NR")
        if (ch.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0) p.add("NOTIFY")
        if (ch.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0) p.add("INDICATE")
        return p.joinToString(",")
    }

    private fun shortUuid(uuid: UUID): String = uuid.toString()

    private fun ByteArray.toHex(): String =
        take(128).joinToString(" ") { "%02X".format(it.toInt() and 0xFF) }

    private fun captureMeta(kind: String, uuid: String) {
        val n = synchronized(captureLines) { packetNo += 1; packetNo }
        val line = "${ts.format(Date())}\t#$n\t$kind\t$uuid"
        synchronized(captureLines) { captureLines.add(line) }
        append(line)
    }

    private fun capture(kind: String, uuid: String, bytes: ByteArray, extra: String = "") {
        val n = synchronized(captureLines) { packetNo += 1; packetNo }
        val line = "${ts.format(Date())}\t#$n\t$kind\t$uuid\tlen=${bytes.size}\t$extra\thex=${bytes.joinToString("") { "%02X".format(it.toInt() and 0xFF) }}"
        synchronized(captureLines) { captureLines.add(line) }
        append(line)
    }


    private fun openCaptureFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "text/plain"
            addCategory(Intent.CATEGORY_OPENABLE)
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        try { startActivityForResult(intent, OPEN_CAPTURE) }
        catch (e: Exception) { append("IMPORT ERROR=${e.message}") }
    }

    @Deprecated("Activity result API retained for phone-only compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != OPEN_CAPTURE || resultCode != RESULT_OK || data == null) return
        try {
            val uris = mutableListOf<Uri>()
            data.data?.let { uris.add(it) }
            data.clipData?.let { clip -> for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri) }
            val unique = uris.distinct().take(2)
            if (unique.isEmpty()) return
            val imported = unique.map { uri ->
                contentResolver.openInputStream(uri)?.use { input -> BufferedReader(InputStreamReader(input)).readLines() } ?: emptyList()
            }
            if (imported.size == 1) {
                importedA = imported[0]
                append("IMPORTED SESSION A: ${imported[0].size} lines")
            } else {
                importedA = imported[0]
                importedB = imported[1]
                append("IMPORTED A=${imported[0].size} lines, B=${imported[1].size} lines")
                analyzeDifferential(imported[0], imported[1])
            }
        } catch (e: Exception) { append("IMPORT ERROR=${e.message}") }
    }

    private fun payload(line: String): ByteArray? {
        val h = line.substringAfter("hex=", "").trim().takeIf { it.isNotBlank() } ?: return null
        if (h.length % 2 != 0 || !h.all { it in "0123456789abcdefABCDEF" }) return null
        return ByteArray(h.length / 2) { i -> h.substring(i * 2, i * 2 + 2).toInt(16).toByte() }
    }

    private fun captureRecords(lines: List<String>, len: Int? = null, kindPrefix: String? = null): List<ByteArray> =
        lines.filter { line ->
            (len == null || Regex("\\blen=$len\\b").containsMatchIn(line)) &&
            (kindPrefix == null || line.contains("\t$kindPrefix\t"))
        }.mapNotNull { payload(it) }

    private fun sha256Hex(bytes: ByteArray): String {
        val md = java.security.MessageDigest.getInstance("SHA-256")
        return md.digest(bytes).joinToString("") { "%02X".format(it.toInt() and 0xFF) }
    }

    private fun evidenceQuality(lines: List<String>, label: String) {
        val valid = lines.mapNotNull { line ->
            val len = Regex("\\blen=(\\d+)").find(line)?.groupValues?.get(1)?.toIntOrNull()
            val hex = line.substringAfter("hex=", "").trim()
            if (len != null && hex.length == len * 2 && hex.all { it in "0123456789abcdefABCDEF" }) Pair(len, hex) else null
        }
        append("[$label] validHexRecords=${valid.size}/${lines.size}")
        val byLen = valid.groupingBy { it.first }.eachCount()
        append("[$label] validatedLengths=" + byLen.entries.sortedBy { it.key }.joinToString { "${it.key}B:${it.value}" })
        val bad = lines.size - valid.size
        if (bad > 0) append("[$label] WARNING malformed/incomplete records=$bad")
    }

    private fun analyzeDifferential(a: List<String>, b: List<String>) {
        append("=== V17 CROSS-SESSION EVIDENCE DIFFERENTIAL ===")
        evidenceQuality(a, "A")
        evidenceQuality(b, "B")
        compareClass("9B", captureRecords(a, 9), captureRecords(b, 9))
        compareClass("13B", captureRecords(a, 13), captureRecords(b, 13))
        compareClass("16B", captureRecords(a, 16), captureRecords(b, 16))
        compareClass("32B", captureRecords(a, 32), captureRecords(b, 32))
        val aBulk = captureRecords(a, 235) + captureRecords(a, 157)
        val bBulk = captureRecords(b, 235) + captureRecords(b, 157)
        append("BULK A=${aBulk.sumOf { it.size }}B B=${bBulk.sumOf { it.size }}B")
        if (aBulk.isNotEmpty()) bulkStructure("A", aBulk)
        if (bBulk.isNotEmpty()) bulkStructure("B", bBulk)
        if (aBulk.isNotEmpty() && bBulk.isNotEmpty()) {
            append("BULK SHA256 A=${sha256Hex(aBulk.fold(ByteArray(0)) { acc, x -> acc + x })}")
            append("BULK SHA256 B=${sha256Hex(bBulk.fold(ByteArray(0)) { acc, x -> acc + x })}")
        }
        append("RULE: differing bytes are candidates only; no field meaning/key/checksum is claimed")
        append("EVIDENCE CLASSIFICATION: stable/session-varying/parameter-varying separation requires controlled captures")
    }

    private fun compareClass(label: String, a: List<ByteArray>, b: List<ByteArray>) {
        append("[$label] A=${a.size} B=${b.size}")
        if (a.isEmpty() || b.isEmpty()) return
        val n = minOf(a.size, b.size)
        val diffCounts = IntArray(label.removeSuffix("B").toInt())
        var exact = 0
        for (i in 0 until n) {
            if (a[i].contentEquals(b[i])) exact++
            for (j in diffCounts.indices) if (a[i][j] != b[i][j]) diffCounts[j]++
        }
        append("[$label] aligned=$n exact=$exact/${n} differing-per-position=" + diffCounts.mapIndexed { i,c -> "$i:$c" }.joinToString(","))
        append("[$label] NOTE alignment is capture-order only; position != field until independently proven")
        append("[$label] Aunique=${a.map { it.toHexFull() }.toSet().size} Bunique=${b.map { it.toHexFull() }.toSet().size}")
    }

    private fun bulkStructure(label: String, chunks: List<ByteArray>) {
        val stream = chunks.fold(ByteArray(0)) { acc, x -> acc + x }
        append("BULK $label chunks=${chunks.size} reassembled=${stream.size}B")
        if (stream.isNotEmpty()) {
            append("BULK $label first64=${stream.take(64).joinToString("") { "%02X".format(it.toInt() and 0xFF) }}")
            val zeros = stream.count { it.toInt() == 0 }
            append("BULK $label zeroBytes=$zeros/${stream.size}")
        }
    }

    private fun ByteArray.toHexFull(): String = joinToString("") { "%02X".format(it.toInt() and 0xFF) }

    private data class TimedRecord(
        val index: Int,
        val timeMs: Long,
        val kind: String,
        val uuid: String,
        val len: Int,
        val bytes: ByteArray
    )

    private fun parseTimedRecord(line: String, index: Int): TimedRecord? {
        val time = Regex("^(\\d{2}):(\\d{2}):(\\d{2})\\.(\\d{3})\\t").find(line) ?: return null
        val h = time.groupValues[1].toLong()
        val m = time.groupValues[2].toLong()
        val sec = time.groupValues[3].toLong()
        val ms = time.groupValues[4].toLong()
        val t = (((h * 60 + m) * 60 + sec) * 1000 + ms)
        val parts = line.split('\t')
        if (parts.size < 4) return null
        val kind = parts.getOrNull(2) ?: return null
        val uuid = parts.getOrNull(3) ?: return null
        val len = Regex("\\blen=(\\d+)\\b").find(line)?.groupValues?.get(1)?.toIntOrNull() ?: return null
        val bytes = payload(line) ?: return null
        if (bytes.size != len) return null
        return TimedRecord(index, t, kind, uuid, len, bytes)
    }

    private fun analyzeTemporalCorrelation() {
        val lines = synchronized(captureLines) { captureLines.toList() }
        if (lines.isEmpty()) { append("CORRELATION: CAPTURE EMPTY"); return }
        val records = lines.mapIndexedNotNull { i, line -> parseTimedRecord(line, i) }
        append("=== V21 TX/RX TEMPORAL CORRELATION ===")
        append("validTimedRecords=${records.size}/${lines.size}")
        if (records.isEmpty()) return

        val tx = records.filter { it.kind.startsWith("TX_") }
        val rx = records.filter { it.kind.startsWith("RX_") }
        append("TX=${tx.size} RX=${rx.size}")

        fun hexPrefix(b: ByteArray, n: Int = 8): String = b.take(n).joinToString("") { "%02X".format(it.toInt() and 0xFF) }
        val windows = listOf(10L, 50L, 200L, 1000L)
        for (w in windows) {
            var matched = 0
            for (t in tx) if (rx.any { it.timeMs >= t.timeMs && it.timeMs - t.timeMs <= w }) matched++
            append("TX->RX within ${w}ms: $matched/${tx.size}")
        }

        for (t in tx.take(40)) {
            val r = rx.firstOrNull { it.timeMs >= t.timeMs }
            if (r != null) {
                append("TX#${t.index} ${t.kind} ${t.len}B -> RX#${r.index} ${r.kind} ${r.len}B dt=${r.timeMs-t.timeMs}ms tx=${hexPrefix(t.bytes)} rx=${hexPrefix(r.bytes)}")
            }
        }

        val txByLen = tx.groupingBy { it.len }.eachCount().toSortedMap()
        val rxByLen = rx.groupingBy { it.len }.eachCount().toSortedMap()
        append("TX length histogram=" + txByLen.entries.joinToString { "${it.key}B:${it.value}" })
        append("RX length histogram=" + rxByLen.entries.joinToString { "${it.key}B:${it.value}" })
        append("RULE: temporal proximity is correlation evidence only; it does not assign protocol fields or meanings")
        append("RULE: first RX after TX is not assumed to be the semantic response")
    }

    private fun analyzeControlledByteDiff() {
        val a = importedA
        val b = importedB
        if (a == null || b == null) {
            append("DIFF A/B: requires two imported captures (A and B)")
            return
        }
        val ra = a.mapIndexedNotNull { i, line -> parseTimedRecord(line, i) }
            .filter { it.kind.startsWith("TX_") }
        val rb = b.mapIndexedNotNull { i, line -> parseTimedRecord(line, i) }
            .filter { it.kind.startsWith("TX_") }
        append("=== V22 CONTROLLED BYTE DIFFERENTIAL ===")
        append("A valid TX=${ra.size}; B valid TX=${rb.size}")
        val groupsA = ra.groupBy { it.kind to it.len }
        val groupsB = rb.groupBy { it.kind to it.len }
        val keys = (groupsA.keys + groupsB.keys).toSortedSet(compareBy<Pair<String,Int>>({it.first},{it.second}))
        var comparable = 0
        var totalDiff = 0
        for (key in keys) {
            val ga = groupsA[key].orEmpty()
            val gb = groupsB[key].orEmpty()
            val n = minOf(ga.size, gb.size)
            if (n == 0) continue
            var same = 0
            val posDiff = IntArray(key.second)
            var byteComparisons = 0L
            for (i in 0 until n) {
                val x = ga[i].bytes
                val y = gb[i].bytes
                if (x.contentEquals(y)) same++
                for (j in 0 until minOf(x.size, y.size)) {
                    byteComparisons++
                    if (x[j] != y[j]) { posDiff[j]++; totalDiff++ }
                }
            }
            comparable += n
            append("GROUP ${key.first}/${key.second}B pairs=$n identical=$same/${n} byteComparisons=$byteComparisons")
            val active = mutableListOf<String>()
            for (idx in posDiff.indices) {
                val c = posDiff[idx]
                if (c > 0) active.add("${idx}:${c}")
            }
            if (active.isNotEmpty()) append("  differing byte positions=count: " + active.joinToString(" "))
        }
        append("COMPARABLE TX RECORD PAIRS=$comparable totalByteDifferences=$totalDiff")
        append("RULE: ordinal pairing within same kind+length is only a controlled alignment heuristic; it does NOT prove field semantics")
        append("RULE: a parameter meaning is accepted only when repeated controlled captures reproduce the same localized change")
        append("RULE: no decrypt, checksum inference, actuator mapping, or DSP write is performed")
    }

    private fun analyzeControlledStability() {
        val a = importedA
        val b = importedB
        if (a == null || b == null) {
            append("STABILITY: requires two imported captures (A and B)")
            return
        }
        val ra = a.mapIndexedNotNull { i, line -> parseTimedRecord(line, i) }.filter { it.kind.startsWith("TX_") }
        val rb = b.mapIndexedNotNull { i, line -> parseTimedRecord(line, i) }.filter { it.kind.startsWith("TX_") }
        append("=== V23 CONTROLLED STABILITY REPORT ===")
        append("A valid TX=${ra.size}; B valid TX=${rb.size}")
        val groupsA = ra.groupBy { it.kind to it.len }
        val groupsB = rb.groupBy { it.kind to it.len }
        val keys = (groupsA.keys + groupsB.keys).toSortedSet(compareBy<Pair<String,Int>>({it.first},{it.second}))
        for (key in keys) {
            val ga = groupsA[key].orEmpty()
            val gb = groupsB[key].orEmpty()
            val n = minOf(ga.size, gb.size)
            if (n == 0) continue
            val changed = IntArray(key.second)
            var identical = 0
            for (i in 0 until n) {
                val x = ga[i].bytes
                val y = gb[i].bytes
                if (x.contentEquals(y)) identical++
                for (j in 0 until key.second) if (x[j] != y[j]) changed[j]++
            }
            val active = changed.withIndex().filter { it.value > 0 }
            val always = active.filter { it.value == n }.map { it.index }
            append("GROUP ${key.first}/${key.second}B pairs=$n identical=$identical")
            append("  changedPositions=" + active.joinToString(" ") { "${it.index}:${it.value}/$n" }.ifBlank { "none" })
            append("  alwaysChangedPositions=" + always.joinToString(",").ifBlank { "none" })
            append("  RULE: repeated localized change is controlled-difference evidence only; it is NOT a field/command assignment")
        }
        append("STABILITY RULE: promote parameter-varying evidence only after the same controlled UI change repeats in independent sessions")
        append("STABILITY RULE: session-wide/randomized changes are not promoted to DSP fields")
        append("STABILITY RULE: no decrypt, checksum inference, actuator mapping, or DSP write")
    }

    private fun shareCapture() {
        val body = synchronized(captureLines) { captureLines.joinToString("\n") }
        if (body.isBlank()) { append("CAPTURE EMPTY"); return }
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "OKN DSP V22 BLE evidence capture")
            putExtra(Intent.EXTRA_TEXT, body)
        }
        startActivity(Intent.createChooser(intent, "Export DSP capture"))
    }


    private fun analyzeCapture() {
        val lines = synchronized(captureLines) { captureLines.toList() }
        if (lines.isEmpty()) { append("ANALYSIS: CAPTURE EMPTY"); return }
        val lens = linkedMapOf<Int, Int>()
        val tx = mutableListOf<String>()
        val rx = mutableListOf<String>()
        for (line in lines) {
            val len = Regex("\\blen=(\\d+)").find(line)?.groupValues?.get(1)?.toIntOrNull()
            if (len != null) lens[len] = (lens[len] ?: 0) + 1
            when {
                "\tTX_" in line -> tx.add(line)
                "\tRX_" in line -> rx.add(line)
            }
        }
        append("=== CAPTURE ANALYSIS V22 ===")
        append("records=${lines.size} sessions=$sessionNo")
        append("length histogram=${lens.entries.sortedBy { it.key }.joinToString { "${it.key}B:${it.value}" }}")
        append("TX records=${tx.size} RX records=${rx.size}")
        val repeated9 = lines.filter { Regex("\\blen=9\\b").containsMatchIn(it) }
        val repeated13 = lines.filter { Regex("\\blen=13\\b").containsMatchIn(it) }
        append("9B records=${repeated9.size}; 13B records=${repeated13.size}")
        if (repeated9.isNotEmpty()) append("9B unique=${uniquePayloads(repeated9)}")
        if (repeated13.isNotEmpty()) append("13B unique=${uniquePayloads(repeated13)}")
        val bulk235 = lines.count { Regex("\\blen=235\\b").containsMatchIn(it) }
        val bulk157 = lines.count { Regex("\\blen=157\\b").containsMatchIn(it) }
        if (bulk235 > 0 || bulk157 > 0) append("bulk candidates: 235B=$bulk235 157B=$bulk157 total=${bulk235*235 + bulk157*157}B")
        append("NOTE: statistical analysis only; no guessed decrypt/write performed")
    }

    private fun uniquePayloads(lines: List<String>): Int {
        return lines.mapNotNull { line ->
            line.substringAfter("hex=", "").takeIf { it.isNotBlank() }
        }.toSet().size
    }

    private fun append(message: String) {
        runOnUiThread {
            logLines.append(message).append('\n')
            log.text = "Log:\n$logLines"
        }
    }

    override fun onDestroy() {
        try { scanner?.stopScan(callback) } catch (_: Exception) {}
        try { gatt?.close() } catch (_: Exception) {}
        gatt = null
        super.onDestroy()
    }
}
