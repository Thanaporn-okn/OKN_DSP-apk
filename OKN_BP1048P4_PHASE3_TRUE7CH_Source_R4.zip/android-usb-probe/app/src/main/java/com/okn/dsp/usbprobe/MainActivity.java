package com.okn.dsp.usbprobe;

import android.app.*;
import android.os.*;
import android.content.*;
import android.hardware.usb.*;
import android.widget.*;
import java.util.*;

public final class MainActivity extends Activity {
    private static final int OBSERVED_VID = 0x6324; // observed on Samsung S25+ / Android USB host
    private static final int OBSERVED_PID = 0x1719; // observed on Samsung S25+ / Android USB host
    private static final int LEGACY_CANDIDATE_VID = 0x18B4; // retained as read-only fallback evidence only
    private static final int LEGACY_CANDIDATE_PID = 0x06B7;
    private static final String ACTION_USB_PERMISSION = "com.okn.dsp.usbprobe.USB_PERMISSION";

    private UsbManager usb;
    private TextView log;
    private UsbDevice selected;

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            if (!ACTION_USB_PERMISSION.equals(i.getAction())) return;
            UsbDevice d = i.getParcelableExtra(UsbManager.EXTRA_DEVICE);
            if (i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false) && d != null) {
                selected = d;
                probeDescriptorsReadOnly(d);
            } else {
                add("USB permission denied");
            }
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        usb = (UsbManager) getSystemService(USB_SERVICE);
        buildUi();
        IntentFilter f = new IntentFilter(ACTION_USB_PERMISSION);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, RECEIVER_NOT_EXPORTED);
        else registerReceiver(receiver, f);
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(receiver);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 28, 28, 28);

        TextView title = new TextView(this);
        title.setText("OKN BP1048P4 USB-C Descriptor Probe R4\nREAD ONLY: no SET_REPORT / no erase / no firmware write");
        title.setTextSize(18);

        Button scan = new Button(this);
        scan.setText("SCAN + READ USB/HID DESCRIPTORS");

        log = new TextView(this);
        log.setTextIsSelectable(true);
        ScrollView sv = new ScrollView(this);
        sv.addView(log);

        root.addView(title);
        root.addView(scan);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        scan.setOnClickListener(v -> scan());
    }

    private void scan() {
        log.setText("");
        Map<String, UsbDevice> devices = usb.getDeviceList();
        add("USB devices: " + devices.size());
        selected = null;

        for (UsbDevice d : devices.values()) {
            int vid = d.getVendorId();
            int pid = d.getProductId();
            add(String.format(Locale.US,
                    "VID=0x%04X (%d) PID=0x%04X (%d) interfaces=%d",
                    vid, vid, pid, pid, d.getInterfaceCount()));
            dumpInterfaces(d);

            if (vid == OBSERVED_VID && pid == OBSERVED_PID) {
                selected = d;
                add("*** OBSERVED BOARD MATCH: 6324:1719 ***");
            } else if (vid == LEGACY_CANDIDATE_VID && pid == LEGACY_CANDIDATE_PID) {
                selected = d;
                add("*** LEGACY CANDIDATE MATCH: 18B4:06B7 ***");
            } else if (selected == null && devices.size() == 1 && hasAudioAndHid(d)) {
                selected = d;
                add("*** SINGLE COMPOSITE AUDIO+HID CANDIDATE ***");
            }
        }

        if (selected == null) {
            add("No safe read-only candidate selected");
            return;
        }
        requestOrProbe(selected);
    }


    private boolean hasAudioAndHid(UsbDevice d) {
        boolean audio = false;
        boolean hid = false;
        for (int i = 0; i < d.getInterfaceCount(); i++) {
            UsbInterface ui = d.getInterface(i);
            if (ui.getInterfaceClass() == UsbConstants.USB_CLASS_AUDIO) audio = true;
            if (ui.getInterfaceClass() == UsbConstants.USB_CLASS_HID) hid = true;
        }
        return audio && hid;
    }

    private void dumpInterfaces(UsbDevice d) {
        for (int i = 0; i < d.getInterfaceCount(); i++) {
            UsbInterface ui = d.getInterface(i);
            add("  IDX" + i + " IF" + ui.getId()
                    + " alt=" + ui.getAlternateSetting()
                    + " class=" + ui.getInterfaceClass()
                    + " sub=" + ui.getInterfaceSubclass()
                    + " proto=" + ui.getInterfaceProtocol()
                    + " ep=" + ui.getEndpointCount());
            for (int e = 0; e < ui.getEndpointCount(); e++) {
                UsbEndpoint ep = ui.getEndpoint(e);
                add("    EP addr=0x" + String.format(Locale.US, "%02X", ep.getAddress())
                        + " dir=" + (ep.getDirection() == UsbConstants.USB_DIR_IN ? "IN" : "OUT")
                        + " type=" + ep.getType()
                        + " max=" + ep.getMaxPacketSize()
                        + " interval=" + ep.getInterval());
            }
        }
    }

    private void requestOrProbe(UsbDevice d) {
        if (usb.hasPermission(d)) {
            probeDescriptorsReadOnly(d);
            return;
        }
        int flags = PendingIntent.FLAG_UPDATE_CURRENT
                | (Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0);
        PendingIntent pi = PendingIntent.getBroadcast(
                this, 0,
                new Intent(ACTION_USB_PERMISSION).setPackage(getPackageName()),
                flags);
        usb.requestPermission(d, pi);
    }

    private void probeDescriptorsReadOnly(UsbDevice d) {
        new Thread(() -> {
            UsbDeviceConnection c = usb.openDevice(d);
            if (c == null) {
                ui("openDevice failed");
                return;
            }
            try {
                ui("Permission/open: OK");
                try {
                    ui("Manufacturer: " + safe(d.getManufacturerName()));
                    ui("Product: " + safe(d.getProductName()));
                    ui("Serial: " + safe(d.getSerialNumber()));
                } catch (Throwable t) {
                    ui("String descriptors unavailable: " + t.getClass().getSimpleName());
                }

                byte[] raw = c.getRawDescriptors();
                ui("Raw descriptors: " + (raw == null ? 0 : raw.length) + " bytes");
                if (raw != null) ui("RAW: " + hex(raw, Math.min(raw.length, 512)));

                // READ-ONLY standard GET_DESCRIPTOR for HID report descriptors.
                // bmRequestType 0x81 = Device-to-host | Standard | Interface
                // bRequest 0x06 = GET_DESCRIPTOR
                // wValue 0x2200 = HID Report Descriptor, index 0
                for (int i = 0; i < d.getInterfaceCount(); i++) {
                    UsbInterface x = d.getInterface(i);
                    if (x.getInterfaceClass() != UsbConstants.USB_CLASS_HID) continue;
                    byte[] report = new byte[512];
                    int n = c.controlTransfer(0x81, 0x06, 0x2200, x.getId(), report, report.length, 1500);
                    ui("HID REPORT IDX" + i + " IF" + x.getId() + " alt=" + x.getAlternateSetting()
                            + " => " + n + " bytes");
                    if (n > 0) ui("  " + hex(report, n));
                }

                ui("READ-ONLY complete.");
                ui("Sent: standard IN GET_DESCRIPTOR only.");
                ui("NOT sent: SET_REPORT / class OUT / erase / program / reboot-to-bootloader.");
            } finally {
                c.close();
            }
        }, "okn-usb-descriptor-r4").start();
    }

    private static String safe(String s) { return s == null ? "<null>" : s; }

    private static String hex(byte[] b, int n) {
        if (b == null || n <= 0) return "<none>";
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < n && i < b.length; i++) {
            if (i > 0) s.append(' ');
            s.append(String.format(Locale.US, "%02X", b[i] & 0xFF));
        }
        return s.toString();
    }

    private void add(String s) { log.append(s + "\n"); }
    private void ui(String s) { runOnUiThread(() -> add(s)); }
}
