# Build notes

Host test:
```bash
bash tests/run_host_tests.sh
```

Android read-only USB probe:
```bash
gradle -p android-usb-probe :app:assembleDebug
```

ไม่มี target BP1048P4 `.bin` build command ใน Phase3 เพราะ exact board toolchain/linker/startup/image packaging ยังไม่ถูกยืนยัน. การใส่ generic linker เพื่อให้ได้ `.bin` หลอก ๆ จะขัดกับ safety gate ของโครงการ.


R4: แก้ USB identity จากการวัดจริงบน Samsung S25+: VID=0x6324 PID=0x1719 และเพิ่ม safe single-device Audio+HID fallback สำหรับอ่าน descriptor เท่านั้น
