package com.okn.dsp.preset

import android.content.Context
import com.okn.dsp.protocol.EqBand48
import com.okn.dsp.protocol.LiveEqPolicy
import com.okn.dsp.protocol.VerifiedScalarControls
import com.okn.dsp.state.DspState
import org.json.JSONArray
import org.json.JSONObject

/** App-local presets. Never emits a DSP packet by itself. */
class AppPresetStore(context: Context) {
    private val prefs = context.getSharedPreferences("okn_dsp_fresh_v1_presets", Context.MODE_PRIVATE)

    data class Snapshot(
        val name: String,
        val scalars: Map<Int, Float>,
        val eq: Map<Pair<Int, Int>, EqBand48>,
    )

    fun currentName(): String = prefs.getString("current", "Preset 1") ?: "Preset 1"

    fun setCurrentName(name: String) { prefs.edit().putString("current", name).apply() }

    fun names(): List<String> {
        val raw = prefs.getString("index", null) ?: return emptyList()
        return runCatching {
            val a = JSONArray(raw)
            buildList { for (i in 0 until a.length()) add(a.optString(i)) }
        }.getOrDefault(emptyList()).filter { it.isNotBlank() }
    }

    fun save(nameInput: String, state: DspState) {
        val name = nameInput.trim().ifBlank { "Preset 1" }
        val root = JSONObject()
        val scalars = JSONObject()
        VerifiedScalarControls.controls.forEach { c ->
            state.scalars[c.id]?.let { scalars.put(c.id.toString(), it.toDouble()) }
        }
        root.put("scalars", scalars)
        val eq = JSONObject()
        for (ch in 1..7) for (band in 1..15) {
            val b = state.eq[ch - 1][band - 1] ?: continue
            if (!LiveEqPolicy.isWritable(b)) continue
            eq.put("$ch:$band", bandToJson(b))
        }
        root.put("eq", eq)
        prefs.edit().putString("preset:$name", root.toString()).putString("current", name).apply()
        val list = names().toMutableList().apply { remove(name); add(0, name) }.take(20)
        prefs.edit().putString("index", JSONArray(list).toString()).apply()
    }

    fun load(name: String): Snapshot? {
        val raw = prefs.getString("preset:$name", null) ?: return null
        return runCatching {
            val root = JSONObject(raw)
            val scalars = linkedMapOf<Int, Float>()
            root.optJSONObject("scalars")?.let { so ->
                val keys = so.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val id = k.toIntOrNull() ?: continue
                    val value = so.optDouble(k, Double.NaN).toFloat()
                    if (VerifiedScalarControls.sanitize(id, value) != null) scalars[id] = value
                }
            }
            val eq = linkedMapOf<Pair<Int, Int>, EqBand48>()
            root.optJSONObject("eq")?.let { eo ->
                val keys = eo.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    val p = key.split(":")
                    if (p.size != 2) continue
                    val ch = p[0].toIntOrNull() ?: continue
                    val band = p[1].toIntOrNull() ?: continue
                    val b = jsonToBand(eo.optJSONObject(key) ?: continue)
                    if (ch in 1..7 && band in 1..15 && LiveEqPolicy.isWritable(b)) eq[ch to band] = b
                }
            }
            Snapshot(name, scalars, eq)
        }.getOrNull()
    }

    private fun bandToJson(b: EqBand48) = JSONObject().apply {
        put("typ", b.type); put("F", b.frequency); put("F2", b.frequency2); put("Q", b.q)
        put("B", b.boostDb); put("G", b.gain); put("R", b.r)
        put("B0", b.b0); put("B1", b.b1); put("B2", b.b2); put("A1", b.a1); put("A2", b.a2)
    }

    private fun jsonToBand(o: JSONObject) = EqBand48(
        type = o.optInt("typ", -1),
        frequency = o.optDouble("F", Double.NaN).toFloat(),
        frequency2 = o.optDouble("F2", Double.NaN).toFloat(),
        q = o.optDouble("Q", Double.NaN).toFloat(),
        boostDb = o.optDouble("B", Double.NaN).toFloat(),
        gain = o.optDouble("G", Double.NaN).toFloat(),
        r = o.optDouble("R", Double.NaN).toFloat(),
        b0 = o.optDouble("B0", Double.NaN).toFloat(),
        b1 = o.optDouble("B1", Double.NaN).toFloat(),
        b2 = o.optDouble("B2", Double.NaN).toFloat(),
        a1 = o.optDouble("A1", Double.NaN).toFloat(),
        a2 = o.optDouble("A2", Double.NaN).toFloat(),
    )
}
