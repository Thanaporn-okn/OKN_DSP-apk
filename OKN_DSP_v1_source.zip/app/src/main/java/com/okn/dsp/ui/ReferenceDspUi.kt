package com.okn.dsp.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import android.widget.ScrollView
import com.okn.dsp.protocol.EqBand48
import com.okn.dsp.protocol.LiveEqPolicy
import com.okn.dsp.state.ConnectionState
import com.okn.dsp.state.DspState
import com.okn.dsp.state.DspStateStore
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Actions exposed by the reference-only UI to the verified DSP runtime. */
interface DspUiActions {
    fun scanConnect()
    fun showMainMenu()
    fun scalarChanged(id: Int, value: Float)
    fun toggleMasterMute()
    fun channelSelected(channel: Int)
    fun bandSelected(band: Int)
    fun eqChanged(channel: Int, band: Int, frequency: Float, q: Float, gain: Float)
    fun resetGlobal()
    fun savePreset()
    fun loadPreset()
    fun flatEq()
    fun copyEq()
    fun pasteEq()
    fun reconnect()
    fun disconnect()
    fun refresh()
    fun saveParams()
    fun showLogs()
}

data class UiSnapshot(val tab: Int = 0, val parametricMode: Boolean = false)

/**
 * OKN_DSP V1 UI reconstructed from the supplied 1024x1536 two-screen reference.
 * The logical canvas for one phone screen is exactly 512x1536.  It scales uniformly
 * to device width so the relative geometry remains the same on every Android phone.
 *
 * Hardware writes remain routed only through the already-verified DspUiActions/runtime
 * boundary; this view never writes raw BLE packets itself.
 */
class ReferenceDspUi(
    context: Context,
    private val store: DspStateStore,
    private val actions: DspUiActions,
    initial: UiSnapshot = UiSnapshot(),
) {
    private val canvasView = DspReferenceCanvas(context, actions, initial.tab.coerceIn(0, 1))
    private val scroller = ScrollView(context).apply {
        isFillViewport = false
        overScrollMode = View.OVER_SCROLL_NEVER
        setBackgroundColor(Color.rgb(1, 12, 21))
        addView(canvasView, ScrollView.LayoutParams(-1, -2))
    }
    val view: View = scroller
    private var unsubscribe: (() -> Unit)? = null

    init {
        unsubscribe = store.subscribe { canvasView.bind(it) }
    }

    fun dispose() {
        unsubscribe?.invoke()
        unsubscribe = null
    }

    fun snapshot(): UiSnapshot = UiSnapshot(canvasView.page, false)

    fun setPresetLabel(name: String) {
        canvasView.presetName = name
        canvasView.invalidate()
    }
}

private class DspReferenceCanvas(
    context: Context,
    private val actions: DspUiActions,
    startPage: Int,
) : View(context) {
    companion object {
        private const val W = 512f
        private const val H = 1536f
        private val EQ_REF_FREQS = floatArrayOf(50f, 100f, 500f, 1000f, 2000f, 5000f, 10000f)
        private val EQ_FALLBACK_GAIN = floatArrayOf(-3f, 0f, 4f, -2f, -4f, 2f, 0f)
        private val BAND_COLORS = intArrayOf(
            Color.rgb(255, 65, 65),
            Color.rgb(255, 162, 28),
            Color.rgb(255, 202, 46),
            Color.rgb(86, 232, 55),
            Color.rgb(25, 198, 232),
            Color.rgb(144, 78, 236),
            Color.rgb(245, 91, 166),
        )
    }

    var page: Int = startPage
        private set
    var presetName: String = "Flat"

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val path = Path()
    private var state: DspState = DspState()
    private var activeHit: Hit? = null
    private var eqVisibleBands: IntArray = IntArray(7) { it + 1 }

    private sealed class Hit {
        data class Slider(val id: Int, val rect: RectF, val min: Float, val max: Float, val cutoff: Boolean = false) : Hit()
        data class EqFader(val slot: Int, val rect: RectF) : Hit()
        data class Button(val action: String, val rect: RectF) : Hit()
    }

    init {
        setBackgroundColor(Color.rgb(1, 12, 21))
        isSoundEffectsEnabled = false
        isHapticFeedbackEnabled = false
        isFocusable = true
    }

    fun bind(s: DspState) {
        state = s
        eqVisibleBands = chooseVisibleEqBands(s)
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val width = MeasureSpec.getSize(widthMeasureSpec).coerceAtLeast(1)
        val height = (width * (H / W)).roundToInt()
        setMeasuredDimension(width, height)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val scale = width / W
        canvas.save()
        canvas.scale(scale, scale)
        drawBackground(canvas)
        if (page == 0) drawHome(canvas) else drawEq(canvas)
        canvas.restore()
    }

    private fun drawBackground(c: Canvas) {
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, W, H, intArrayOf(Color.rgb(2, 22, 36), Color.rgb(0, 12, 21), Color.rgb(1, 18, 30)), null, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, W, H, p)
        p.shader = null
        p.color = Color.argb(45, 0, 157, 255)
        c.drawCircle(57f, 70f, 115f, p)
        p.color = Color.argb(18, 0, 184, 255)
        c.drawCircle(425f, 1380f, 190f, p)
    }

    private fun drawHome(c: Canvas) {
        drawHeader(c)
        drawDeviceCard(c)

        drawHomeControl(c, 215f, 157f, 2, "Master Volume", "ระดับเสียงรวม", -70f, 6f, "dB", icon = "speaker", accent = Color.rgb(24, 147, 255), ticks = listOf("-60", "-40", "-20", "0", "+20"))
        drawHomeControl(c, 382f, 156f, 8, "Bass Volume", "ระดับเสียงเบส", -70f, 6f, "dB", icon = "bass", accent = Color.rgb(29, 157, 255), ticks = listOf("-60", "-40", "-20", "0", "+20"))
        drawHomeControl(c, 550f, 155f, 9, "Bass Cutoff", "ความถี่ตัดเบส (Low Pass)", 20f, 250f, "Hz", icon = "wave", accent = Color.rgb(27, 221, 196), ticks = listOf("20", "50", "100", "200", "500"), cutoff = true)
        drawHomeControl(c, 717f, 157f, 10, "Bass Boost", "เพิ่มเสียงเบส", -12f, 12f, "dB", icon = "bars", accent = Color.rgb(255, 174, 28), ticks = listOf("-12", "-6", "0", "+6", "+12"))
        drawHomeControl(c, 887f, 157f, 13, "Middle Boost", "เพิ่มเสียงกลาง", -12f, 12f, "dB", icon = "bars", accent = Color.rgb(142, 72, 238), ticks = listOf("-12", "-6", "0", "+6", "+12"))
        drawHomeControl(c, 1054f, 157f, 11, "Treble Boost", "เพิ่มเสียงแหลม", -12f, 12f, "dB", icon = "bars", accent = Color.rgb(239, 85, 157), ticks = listOf("-12", "-6", "0", "+6", "+12"))

        // Quick presets
        panel(c, 14f, 1223f, 484f, 99f, 15f)
        text(c, "พรีเซ็ตด่วน", 29f, 1255f, 16f, C_TEXT, true)
        val names = listOf("Flat", "Pop", "Rock", "Jazz", "Vocal")
        val xs = floatArrayOf(29f, 123f, 216f, 309f, 402f)
        names.forEachIndexed { i, name ->
            val selected = name.equals(presetName, true)
            button(c, xs[i], 1264f, 84f, 46f, name, selected)
        }

        // Save / load
        actionButton(c, 23f, 1337f, 225f, 65f, "save", "บันทึกพรีเซ็ต")
        actionButton(c, 264f, 1337f, 225f, 65f, "folder", "โหลดพรีเซ็ต")
        drawBottomNav(c, active = 0)
    }

    private fun drawHeader(c: Canvas) {
        drawWaveLogo(c, 34f, 23f)
        text(c, "OKN_", 108f, 54f, 34f, Color.WHITE, true, italic = true)
        text(c, "DSP", 208f, 54f, 34f, C_BLUE, true, italic = true)
        text(c, "DIGITAL SIGNAL PROCESSOR", 109f, 77f, 11f, Color.rgb(167, 172, 221), false, letterSpacing = 1.5f)

        val connected = state.connection == ConnectionState.READY
        roundRect(c, 316f, 25f, 128f, 62f, 15f, Color.argb(155, 4, 31, 48), C_BORDER, 1f)
        drawBluetooth(c, 330f, 42f, if (connected) C_GREEN else C_MUTED)
        text(c, if (connected) "เชื่อมต่อแล้ว" else "ยังไม่เชื่อมต่อ", 359f, 53f, 14f, Color.WHITE, true)
        text(c, state.device.bluetoothName ?: "OKN-DSP", 359f, 76f, 11f, Color.rgb(180, 190, 219))
        if (connected) {
            p.color = Color.argb(65, 64, 255, 105)
            p.style = Paint.Style.FILL
            c.drawCircle(338f, 62f, 19f, p)
        }
        drawGear(c, 474f, 52f, C_TEXT)
    }

    private fun drawDeviceCard(c: Canvas) {
        panel(c, 14f, 106f, 484f, 94f, 15f)
        roundRect(c, 28f, 119f, 70f, 68f, 12f, Color.argb(180, 9, 43, 65), Color.rgb(17, 72, 102), 1f)
        drawDevice(c, 50f, 132f, Color.rgb(130, 155, 255))
        text(c, "DSP 7 Channel", 113f, 151f, 19f, C_TEXT, true)
        text(c, "Professional Audio Processing", 113f, 176f, 13f, C_MUTED)

        val connected = state.connection == ConnectionState.READY
        roundRect(c, 316f, 125f, 171f, 57f, 12f, Color.argb(120, 2, 24, 39), Color.rgb(18, 83, 129), 1.2f)
        drawLink(c, 330f, 145f, C_BLUE)
        text(c, if (connected) "ยกเลิกการเชื่อมต่อ" else "เชื่อมต่อ DSP", 358f, 160f, 13f, if (connected) Color.rgb(214, 221, 239) else C_BLUE, true)
    }

    private fun drawHomeControl(
        c: Canvas,
        y: Float,
        h: Float,
        id: Int,
        title: String,
        subtitle: String,
        minV: Float,
        maxV: Float,
        unit: String,
        icon: String,
        accent: Int,
        ticks: List<String>,
        cutoff: Boolean = false,
    ) {
        panel(c, 14f, y, 484f, h, 16f)
        when (icon) {
            "speaker" -> drawSpeaker(c, 39f, y + 39f, accent)
            "bass" -> drawBass(c, 38f, y + 37f, accent)
            "wave" -> drawWave(c, 40f, y + 41f, accent)
            else -> drawBars(c, 40f, y + 34f, accent)
        }
        text(c, title, 119f, y + 37f, 19f, C_TEXT, true)
        text(c, subtitle, 119f, y + 66f, 14f, C_MUTED)

        val fallback = when (id) { 2 -> -6f; 8 -> 0f; 9 -> 80f; 10 -> 4f; 13 -> 2f; 11 -> 3f; else -> 0f }
        val value = state.scalars[id] ?: fallback
        val valueText = if (unit == "Hz") String.format(Locale.US, "%.0f Hz", value) else String.format(Locale.US, "%.1f dB", value)
        roundRect(c, 381f, y + 44f, 101f, 42f, 13f, Color.argb(150, 4, 25, 39), Color.rgb(50, 81, 105), 1f)
        text(c, valueText, 431f, y + 71f, 17f, Color.WHITE, true, align = Paint.Align.CENTER)

        val sx = 120f
        val sy = y + 94f
        val ex = 454f
        p.strokeCap = Paint.Cap.ROUND
        p.style = Paint.Style.STROKE
        p.strokeWidth = 13f
        p.color = C_TRACK
        c.drawLine(sx, sy, ex, sy, p)
        val t = if (cutoff) cutoffPos(value) else ((value - minV) / (maxV - minV)).coerceIn(0f, 1f)
        p.color = accent
        if (t > 0.001f) {
            p.shader = LinearGradient(sx, sy, sx + (ex - sx) * t, sy, accent, Color.rgb(25, 157, 255), Shader.TileMode.CLAMP)
            c.drawLine(sx, sy, sx + (ex - sx) * t, sy, p)
            p.shader = null
        }
        p.style = Paint.Style.FILL
        p.color = Color.rgb(239, 245, 251)
        c.drawCircle(sx + (ex - sx) * t, sy, 14f, p)
        p.color = Color.argb(65, 255, 255, 255)
        c.drawCircle(sx + (ex - sx) * t, sy, 16f, p)

        val tx = floatArrayOf(sx, 204f, 283f, 360f, 445f)
        ticks.forEachIndexed { i, tick ->
            p.strokeWidth = 1f
            p.color = Color.rgb(78, 107, 129)
            c.drawLine(tx[i], sy + 18f, tx[i], sy + 25f, p)
            text(c, tick, tx[i], sy + 43f, 13f, C_MUTED, align = Paint.Align.CENTER)
        }
    }

    private fun drawEq(c: Canvas) {
        drawHeader(c)
        drawEqTabs(c)

        // EQ graph panel
        panel(c, 526f - 512f, 214f, 484f, 355f, 15f)
        text(c, "กราฟ EQ", 28f, 258f, 21f, C_TEXT, true)
        roundRect(c, 131f, 229f, 194f, 42f, 12f, Color.argb(120, 2, 22, 35), Color.rgb(54, 84, 105), 1f)
        val ch = state.selectedChannel.coerceIn(1, 7)
        val chNames = listOf("Front Left", "Front Right", "Rear Left", "Rear Right", "Center", "Subwoofer", "AUX")
        text(c, "(CH$ch : ${chNames[ch - 1]})", 144f, 257f, 14f, C_TEXT)
        drawChevron(c, 307f, 245f, C_MUTED)
        roundRect(c, 405f, 229f, 92f, 44f, 12f, Color.argb(120, 2, 22, 35), Color.rgb(54, 84, 105), 1f)
        text(c, "Reset", 451f, 258f, 15f, C_TEXT, true, align = Paint.Align.CENTER)
        drawEqGraph(c)
        drawEqFaders(c)
        drawChannelSelector(c)
        drawEqActions(c)
        drawBottomNav(c, active = 1)
    }

    private fun drawEqTabs(c: Canvas) {
        panel(c, 14f, 106f, 484f, 94f, 15f)
        val labels = listOf("หน้าหลัก", "EQ", "Delay", "Crossover", "Output")
        val icons = listOf("home", "eq", "delay", "cross", "speaker")
        val widths = floatArrayOf(91f, 93f, 101f, 112f, 88f)
        var x = 14f
        labels.forEachIndexed { i, label ->
            val active = i == 1
            if (active) roundRect(c, x + 3f, 110f, widths[i] - 6f, 90f, 13f, C_BLUE, C_BLUE, 1f)
            val cx = x + widths[i] / 2f
            when (icons[i]) {
                "home" -> drawHomeIcon(c, cx - 12f, 127f, if (active) Color.WHITE else Color.rgb(192, 201, 244))
                "eq" -> drawMiniEq(c, cx - 12f, 129f, if (active) Color.WHITE else Color.rgb(192, 201, 244))
                "delay" -> drawClock(c, cx - 12f, 128f, if (active) Color.WHITE else Color.rgb(192, 201, 244))
                "cross" -> drawCross(c, cx - 13f, 132f, if (active) Color.WHITE else Color.rgb(192, 201, 244))
                else -> drawSpeakerSmall(c, cx - 12f, 129f, if (active) Color.WHITE else Color.rgb(192, 201, 244))
            }
            text(c, label, cx, 183f, 14f, if (active) Color.WHITE else Color.rgb(197, 204, 231), align = Paint.Align.CENTER)
            if (i < labels.lastIndex) {
                p.style = Paint.Style.STROKE; p.strokeWidth = 1f; p.color = Color.rgb(16, 50, 68)
                c.drawLine(x + widths[i], 124f, x + widths[i], 184f, p)
            }
            x += widths[i]
        }
    }

    private fun drawEqGraph(c: Canvas) {
        val left = 57f
        val top = 286f
        val right = 498f
        val bottom = 526f
        roundRect(c, left, top, right - left, bottom - top, 4f, Color.rgb(2, 21, 31), Color.rgb(49, 75, 94), 1f)

        p.style = Paint.Style.STROKE
        p.strokeWidth = 0.7f
        for (i in 0..12) {
            val x = left + (right - left) * i / 12f
            p.color = if (i % 2 == 0) Color.argb(50, 83, 119, 143) else Color.argb(26, 83, 119, 143)
            c.drawLine(x, top, x, bottom, p)
        }
        for (i in 0..8) {
            val y = top + (bottom - top) * i / 8f
            p.color = if (i == 4) Color.argb(85, 79, 124, 150) else Color.argb(40, 83, 119, 143)
            c.drawLine(left, y, right, y, p)
        }
        text(c, "+12", 51f, 310f, 12f, C_MUTED, align = Paint.Align.RIGHT)
        text(c, "+6", 51f, 364f, 12f, C_MUTED, align = Paint.Align.RIGHT)
        text(c, "0", 51f, 418f, 12f, C_MUTED, align = Paint.Align.RIGHT)
        text(c, "-6", 51f, 472f, 12f, C_MUTED, align = Paint.Align.RIGHT)
        text(c, "-12", 51f, 528f, 12f, C_MUTED, align = Paint.Align.RIGHT)

        val axis = listOf("20", "50", "100", "200", "500", "1K", "2K", "5K", "10K", "20K")
        axis.forEachIndexed { i, s ->
            text(c, s, left + (right - left) * i / (axis.size - 1f), 554f, 12f, C_MUTED, align = Paint.Align.CENTER)
        }

        val gains = visibleGains()
        val freqs = visibleFreqs()
        val points = Array(7) { i ->
            val x = logX(freqs[i], left, right)
            val y = bottom - ((gains[i] + 12f) / 24f).coerceIn(0f, 1f) * (bottom - top)
            Pair(x, y)
        }
        // Fill area under curve.
        path.reset()
        path.moveTo(left, zeroY(top, bottom))
        path.lineTo(points[0].first, points[0].second)
        for (i in 1 until points.size) path.lineTo(points[i].first, points[i].second)
        path.lineTo(right, zeroY(top, bottom))
        path.close()
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, top, 0f, bottom, Color.argb(105, 0, 145, 255), Color.argb(4, 0, 145, 255), Shader.TileMode.CLAMP)
        c.drawPath(path, p)
        p.shader = null

        path.reset()
        path.moveTo(left, zeroY(top, bottom) + 20f)
        path.lineTo(points[0].first, points[0].second)
        for (i in 1 until points.size) path.lineTo(points[i].first, points[i].second)
        path.lineTo(right, points.last().second - 4f)
        line.color = C_BLUE
        line.strokeWidth = 3.2f
        line.strokeCap = Paint.Cap.ROUND
        line.strokeJoin = Paint.Join.ROUND
        c.drawPath(path, line)

        points.forEachIndexed { i, pt ->
            p.style = Paint.Style.FILL
            p.color = BAND_COLORS[i]
            c.drawCircle(pt.first, pt.second, 8.6f, p)
            line.color = Color.WHITE
            line.strokeWidth = 1.5f
            c.drawCircle(pt.first, pt.second, 8.6f, line)
        }
    }

    private fun drawEqFaders(c: Canvas) {
        val panelY = 582f
        val panelH = 497f
        val x0 = 8f
        val gap = 5f
        val cardW = 65.8f
        val gains = visibleGains()
        val freqs = visibleFreqs()
        for (i in 0 until 7) {
            val x = x0 + i * (cardW + gap)
            roundRect(c, x, panelY, cardW, panelH, 12f, Color.argb(168, 3, 25, 38), Color.rgb(41, 72, 91), 1f)
            p.style = Paint.Style.FILL; p.color = BAND_COLORS[i]; c.drawCircle(x + cardW / 2f, panelY + 29f, 8f, p)
            text(c, "${i + 1}", x + cardW / 2f, panelY + 61f, 13f, C_TEXT, align = Paint.Align.CENTER)

            roundRect(c, x + 6f, panelY + 74f, cardW - 12f, 35f, 7f, Color.rgb(3, 17, 27), Color.rgb(35, 68, 88), 1f)
            text(c, freqShort(freqs[i]), x + cardW / 2f, panelY + 98f, 12f, C_TEXT, true, align = Paint.Align.CENTER)
            roundRect(c, x + 8f, panelY + 119f, cardW - 16f, 34f, 7f, Color.rgb(3, 17, 27), Color.rgb(35, 68, 88), 1f)
            text(c, String.format(Locale.US, "%.1f", gains[i]), x + cardW / 2f, panelY + 142f, 12f, C_TEXT, true, align = Paint.Align.CENTER)
            text(c, "dB", x + cardW / 2f, panelY + 174f, 12f, Color.rgb(206, 213, 235), align = Paint.Align.CENTER)
            roundRect(c, x + 9f, panelY + 193f, cardW - 18f, 34f, 7f, Color.rgb(3, 17, 27), Color.rgb(35, 68, 88), 1f)
            text(c, String.format(Locale.US, "%.1f", visibleQ(i)), x + cardW / 2f, panelY + 216f, 12f, C_TEXT, true, align = Paint.Align.CENTER)

            val fx = x + 16f
            val fyTop = panelY + 263f
            val fyBottom = panelY + 423f
            roundRect(c, fx, fyTop, 8f, fyBottom - fyTop, 4f, Color.rgb(29, 60, 79), null, 0f)
            val y = gainY(gains[i], fyTop, fyBottom)
            p.style = Paint.Style.STROKE; p.strokeWidth = 8f; p.strokeCap = Paint.Cap.ROUND; p.color = BAND_COLORS[i]
            c.drawLine(fx + 4f, y, fx + 4f, fyBottom, p)
            p.style = Paint.Style.FILL; p.color = Color.rgb(244, 247, 250); c.drawCircle(fx + 4f, y, 10.5f, p)
            text(c, "+12", x + 37f, fyTop + 11f, 10f, C_MUTED)
            text(c, "0", x + 37f, gainY(0f, fyTop, fyBottom) + 4f, 10f, C_MUTED)
            text(c, "-12", x + 37f, fyBottom + 4f, 10f, C_MUTED)

            // tiny bell-filter icon box
            roundRect(c, x + 9f, panelY + 449f, cardW - 18f, 37f, 8f, Color.rgb(4, 21, 32), Color.rgb(36, 67, 87), 1f)
            drawBell(c, x + 21f, panelY + 459f, C_TEXT)
        }
    }

    private fun drawChannelSelector(c: Canvas) {
        panel(c, 14f, 1102f, 484f, 143f, 15f)
        text(c, "เลือกช่องสัญญาณ", 29f, 1134f, 16f, C_TEXT, true)
        val labels = listOf("CH1\nFL", "CH2\nFR", "CH3\nRL", "CH4\nRR", "CH5\nCEN", "CH6\nSUB", "CH7\nAUX")
        val gap = 6f
        val bw = 59f
        labels.forEachIndexed { i, label ->
            val x = 29f + i * (bw + gap)
            val active = state.selectedChannel == i + 1
            roundRect(c, x, 1153f, bw, 77f, 10f, if (active) C_BLUE else Color.rgb(4, 24, 38), if (active) Color.rgb(37, 176, 255) else Color.rgb(45, 76, 98), 1f)
            val parts = label.split("\n")
            text(c, parts[0], x + bw / 2f, 1183f, 13f, Color.WHITE, true, align = Paint.Align.CENTER)
            text(c, parts[1], x + bw / 2f, 1209f, 13f, Color.WHITE, align = Paint.Align.CENTER)
        }
    }

    private fun drawEqActions(c: Canvas) {
        panel(c, 14f, 1260f, 484f, 105f, 14f)
        actionButton(c, 23f, 1270f, 145f, 78f, "copy", "คัดลอก EQ")
        actionButton(c, 183f, 1270f, 145f, 78f, "paste", "วาง EQ")
        actionButton(c, 343f, 1270f, 145f, 78f, "save", "บันทึกเป็นพรีเซ็ต")
    }

    private fun drawBottomNav(c: Canvas, active: Int) {
        p.style = Paint.Style.FILL
        p.color = Color.rgb(2, 14, 23)
        c.drawRect(0f, 1425f, W, H, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 1f; p.color = Color.rgb(24, 50, 65)
        c.drawLine(0f, 1425f, W, 1425f, p)
        val centers = floatArrayOf(89f, 256f, 423f)
        val labels = listOf("หน้าหลัก", "EQ", "เพิ่มเติม")
        val iconNames = listOf("home", "eq", "more")
        centers.forEachIndexed { i, cx ->
            val color = if (i == active) Color.rgb(0, 163, 255) else Color.rgb(177, 186, 226)
            when (iconNames[i]) {
                "home" -> drawHomeIcon(c, cx - 18f, 1441f, color, 1.4f)
                "eq" -> drawMiniEq(c, cx - 16f, 1446f, color, 1.25f)
                else -> drawMore(c, cx - 18f, 1460f, color)
            }
            text(c, labels[i], cx, 1511f, 16f, color, align = Paint.Align.CENTER)
        }
    }

    private fun actionButton(c: Canvas, x: Float, y: Float, w: Float, h: Float, icon: String, label: String) {
        roundRect(c, x, y, w, h, 11f, Color.argb(150, 3, 22, 35), Color.rgb(48, 81, 103), 1f)
        when (icon) {
            "save" -> drawSave(c, x + 52f, y + 20f, Color.rgb(211, 220, 242))
            "folder" -> drawFolder(c, x + 54f, y + 20f, Color.rgb(211, 220, 242))
            "copy" -> drawCopy(c, x + 25f, y + 25f, Color.rgb(211, 220, 242))
            "paste" -> drawPaste(c, x + 25f, y + 25f, Color.rgb(211, 220, 242))
        }
        val tx = if (w > 180f) x + w / 2f + 20f else x + w / 2f + 10f
        text(c, label, tx, y + h / 2f + 6f, if (w > 180f) 14f else 12.3f, C_TEXT, true, align = Paint.Align.CENTER)
    }

    // ---------- Touch ----------
    override fun onTouchEvent(event: MotionEvent): Boolean {
        val scale = width / W
        val x = event.x / scale
        val y = event.y / scale
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val hit = hitTest(x, y)
                activeHit = hit
                if (hit != null) {
                    parent?.requestDisallowInterceptTouchEvent(hit is Hit.Slider || hit is Hit.EqFader)
                    if (hit is Hit.Slider) updateSlider(hit, x)
                    if (hit is Hit.EqFader) updateEqFader(hit, y)
                    return true
                }
                return false
            }
            MotionEvent.ACTION_MOVE -> {
                when (val hit = activeHit) {
                    is Hit.Slider -> { updateSlider(hit, x); return true }
                    is Hit.EqFader -> { updateEqFader(hit, y); return true }
                    else -> return activeHit != null
                }
            }
            MotionEvent.ACTION_UP -> {
                val hit = activeHit
                activeHit = null
                parent?.requestDisallowInterceptTouchEvent(false)
                when (hit) {
                    is Hit.Button -> if (hit.rect.contains(x, y)) performAction(hit.action)
                    is Hit.Slider -> updateSlider(hit, x)
                    is Hit.EqFader -> updateEqFader(hit, y)
                    else -> Unit
                }
                performClick()
                return hit != null
            }
            MotionEvent.ACTION_CANCEL -> {
                activeHit = null
                parent?.requestDisallowInterceptTouchEvent(false)
                return false
            }
        }
        return super.onTouchEvent(event)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private fun hitTest(x: Float, y: Float): Hit? {
        if (y in 24f..88f && x in 310f..448f) return Hit.Button("connect", RectF(310f, 24f, 448f, 88f))
        if (y in 22f..90f && x in 452f..510f) return Hit.Button("menu", RectF(452f, 22f, 510f, 90f))
        if (y in 125f..186f && x in 312f..494f) return Hit.Button("device", RectF(312f, 125f, 494f, 186f))
        if (page == 0) {
            val defs = listOf(
                Triple(2, 215f, Pair(-70f, 6f)),
                Triple(8, 382f, Pair(-70f, 6f)),
                Triple(9, 550f, Pair(20f, 250f)),
                Triple(10, 717f, Pair(-12f, 12f)),
                Triple(13, 887f, Pair(-12f, 12f)),
                Triple(11, 1054f, Pair(-12f, 12f)),
            )
            defs.forEach { (id, yy, range) ->
                val r = RectF(106f, yy + 76f, 468f, yy + 116f)
                if (r.contains(x, y)) return Hit.Slider(id, r, range.first, range.second, id == 9)
            }
            val presetXs = floatArrayOf(29f, 123f, 216f, 309f, 402f)
            val presetNames = listOf("Flat", "Pop", "Rock", "Jazz", "Vocal")
            presetXs.forEachIndexed { i, xx ->
                val r = RectF(xx, 1262f, xx + 84f, 1312f)
                if (r.contains(x, y)) return Hit.Button("preset:${presetNames[i]}", r)
            }
            RectF(23f, 1333f, 248f, 1407f).let { if (it.contains(x, y)) return Hit.Button("savePreset", it) }
            RectF(264f, 1333f, 489f, 1407f).let { if (it.contains(x, y)) return Hit.Button("loadPreset", it) }
        } else {
            // top tabs
            RectF(14f, 106f, 105f, 200f).let { if (it.contains(x, y)) return Hit.Button("home", it) }
            RectF(105f, 106f, 200f, 200f).let { if (it.contains(x, y)) return Hit.Button("eq", it) }
            RectF(405f, 225f, 500f, 280f).let { if (it.contains(x, y)) return Hit.Button("resetEq", it) }
            // faders
            val cardW = 65.8f; val gap = 5f; val x0 = 8f
            for (i in 0 until 7) {
                val fx = x0 + i * (cardW + gap)
                val r = RectF(fx + 3f, 831f, fx + 48f, 1018f)
                if (r.contains(x, y)) return Hit.EqFader(i, r)
            }
            // channels
            val bw = 59f; val cg = 6f
            for (i in 0 until 7) {
                val xx = 29f + i * (bw + cg)
                val r = RectF(xx, 1150f, xx + bw, 1234f)
                if (r.contains(x, y)) return Hit.Button("channel:${i + 1}", r)
            }
            RectF(23f, 1267f, 168f, 1352f).let { if (it.contains(x, y)) return Hit.Button("copyEq", it) }
            RectF(183f, 1267f, 328f, 1352f).let { if (it.contains(x, y)) return Hit.Button("pasteEq", it) }
            RectF(343f, 1267f, 488f, 1352f).let { if (it.contains(x, y)) return Hit.Button("savePreset", it) }
        }
        // bottom nav shared
        RectF(0f, 1424f, 170f, 1536f).let { if (it.contains(x, y)) return Hit.Button("home", it) }
        RectF(170f, 1424f, 342f, 1536f).let { if (it.contains(x, y)) return Hit.Button("eq", it) }
        RectF(342f, 1424f, 512f, 1536f).let { if (it.contains(x, y)) return Hit.Button("menu", it) }
        return null
    }

    private fun updateSlider(hit: Hit.Slider, x: Float) {
        val t = ((x - 120f) / (454f - 120f)).coerceIn(0f, 1f)
        val raw = if (hit.cutoff) cutoffValue(t) else hit.min + (hit.max - hit.min) * t
        val v = when (hit.id) {
            2, 8 -> (raw * 10f).roundToInt() / 10f
            9 -> raw.roundToInt().toFloat().coerceIn(20f, 250f)
            else -> (raw * 2f).roundToInt() / 2f
        }
        actions.scalarChanged(hit.id, v)
    }

    private fun updateEqFader(hit: Hit.EqFader, y: Float) {
        val top = 845f
        val bottom = 1005f
        val t = ((y - top) / (bottom - top)).coerceIn(0f, 1f)
        val gain = (((12f - 24f * t) * 2f).roundToInt() / 2f).coerceIn(-12f, 12f)
        val ch = state.selectedChannel.coerceIn(1, 7)
        val band = eqVisibleBands.getOrNull(hit.slot) ?: return
        val b = state.eq.getOrNull(ch - 1)?.getOrNull(band - 1) ?: return
        if (!LiveEqPolicy.isWritable(b)) return
        actions.bandSelected(band)
        actions.eqChanged(ch, band, b.frequency, b.q, gain)
    }

    private fun performAction(action: String) {
        when {
            action == "connect" -> actions.scanConnect()
            action == "menu" -> actions.showMainMenu()
            action == "device" -> if (state.connection == ConnectionState.READY) actions.disconnect() else actions.scanConnect()
            action == "home" -> { page = 0; invalidate() }
            action == "eq" -> { page = 1; invalidate() }
            action == "savePreset" -> actions.savePreset()
            action == "loadPreset" -> actions.loadPreset()
            action == "copyEq" -> actions.copyEq()
            action == "pasteEq" -> actions.pasteEq()
            action == "resetEq" -> actions.flatEq()
            action.startsWith("channel:") -> action.substringAfter(':').toIntOrNull()?.let { actions.channelSelected(it) }
            action.startsWith("preset:") -> applyQuickPreset(action.substringAfter(':'))
        }
    }

    private fun applyQuickPreset(name: String) {
        presetName = name
        val values = when (name) {
            "Flat" -> floatArrayOf(0f, 0f, 0f)
            "Pop" -> floatArrayOf(2f, 1f, 2f)
            "Rock" -> floatArrayOf(4f, 2f, 3f)
            "Jazz" -> floatArrayOf(1f, 2f, 2f)
            "Vocal" -> floatArrayOf(-1f, 4f, 2f)
            else -> floatArrayOf(0f, 0f, 0f)
        }
        actions.scalarChanged(10, values[0])
        actions.scalarChanged(13, values[1])
        actions.scalarChanged(11, values[2])
        invalidate()
    }

    // ---------- State mapping ----------
    private fun chooseVisibleEqBands(s: DspState): IntArray {
        val rows = s.eq.getOrNull(s.selectedChannel.coerceIn(1, 7) - 1) ?: return IntArray(7) { it + 1 }
        val candidates = rows.mapIndexedNotNull { i, b -> if (b != null && LiveEqPolicy.isWritable(b)) i + 1 else null }.toMutableSet()
        if (candidates.isEmpty()) return IntArray(7) { it + 1 }
        val out = IntArray(7)
        EQ_REF_FREQS.forEachIndexed { i, ref ->
            val best = candidates.minByOrNull { band ->
                val f = rows[band - 1]?.frequency ?: ref
                abs(ln((f / ref).coerceAtLeast(0.0001f)))
            }
            out[i] = best ?: (i + 1)
            if (best != null) candidates.remove(best)
        }
        return out
    }

    private fun visibleBands(): Array<EqBand48?> {
        val rows = state.eq.getOrNull(state.selectedChannel.coerceIn(1, 7) - 1)
        return Array(7) { i -> rows?.getOrNull((eqVisibleBands.getOrNull(i) ?: (i + 1)) - 1) }
    }

    private fun visibleGains(): FloatArray {
        val bands = visibleBands()
        return FloatArray(7) { i -> bands[i]?.boostDb?.takeIf { it.isFinite() } ?: EQ_FALLBACK_GAIN[i] }
    }

    private fun visibleFreqs(): FloatArray {
        val bands = visibleBands()
        return FloatArray(7) { i -> bands[i]?.frequency?.takeIf { it.isFinite() && it > 0f } ?: EQ_REF_FREQS[i] }
    }

    private fun visibleQ(slot: Int): Float = visibleBands().getOrNull(slot)?.q?.takeIf { it.isFinite() } ?: 1f

    // ---------- Drawing helpers ----------
    private fun panel(c: Canvas, x: Float, y: Float, w: Float, h: Float, r: Float) {
        roundRect(c, x, y, w, h, r, Color.argb(185, 5, 31, 45), Color.rgb(21, 68, 91), 1f)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(x, y, x + w, y + h, Color.argb(20, 0, 141, 255), Color.argb(5, 0, 141, 255), Shader.TileMode.CLAMP)
        c.drawRoundRect(RectF(x + 1f, y + 1f, x + w - 1f, y + h - 1f), r, r, p)
        p.shader = null
    }

    private fun button(c: Canvas, x: Float, y: Float, w: Float, h: Float, label: String, active: Boolean) {
        roundRect(c, x, y, w, h, 9f, if (active) C_BLUE else Color.rgb(3, 24, 38), if (active) Color.rgb(31, 188, 255) else Color.rgb(48, 80, 101), 1f)
        text(c, label, x + w / 2f, y + 29f, 14f, Color.WHITE, active, align = Paint.Align.CENTER)
    }

    private fun roundRect(c: Canvas, x: Float, y: Float, w: Float, h: Float, r: Float, fill: Int, stroke: Int?, sw: Float) {
        p.style = Paint.Style.FILL
        p.color = fill
        c.drawRoundRect(RectF(x, y, x + w, y + h), r, r, p)
        if (stroke != null) {
            line.color = stroke
            line.strokeWidth = sw
            line.style = Paint.Style.STROKE
            c.drawRoundRect(RectF(x + sw / 2f, y + sw / 2f, x + w - sw / 2f, y + h - sw / 2f), r, r, line)
        }
    }

    private fun text(
        c: Canvas,
        s: String,
        x: Float,
        y: Float,
        size: Float,
        color: Int,
        bold: Boolean = false,
        italic: Boolean = false,
        align: Paint.Align = Paint.Align.LEFT,
        letterSpacing: Float = 0f,
    ) {
        p.shader = null
        p.style = Paint.Style.FILL
        p.color = color
        p.textSize = size
        p.textAlign = align
        p.typeface = when {
            bold && italic -> Typeface.create("sans-serif", Typeface.BOLD_ITALIC)
            bold -> Typeface.create("sans-serif", Typeface.BOLD)
            italic -> Typeface.create("sans-serif", Typeface.ITALIC)
            else -> Typeface.create("sans-serif", Typeface.NORMAL)
        }
        if (letterSpacing == 0f) c.drawText(s, x, y, p)
        else {
            var xx = x
            s.forEach { ch ->
                val t = ch.toString(); c.drawText(t, xx, y, p); xx += p.measureText(t) + letterSpacing
            }
        }
    }

    private fun zeroY(top: Float, bottom: Float): Float = bottom - 0.5f * (bottom - top)
    private fun gainY(gain: Float, top: Float, bottom: Float): Float = bottom - ((gain + 12f) / 24f).coerceIn(0f, 1f) * (bottom - top)
    private fun logX(freq: Float, left: Float, right: Float): Float {
        val f = freq.coerceIn(20f, 20000f)
        val t = ln(f / 20f) / ln(1000f)
        return left + (right - left) * t
    }

    private fun cutoffPos(v: Float): Float {
        val f = v.coerceIn(20f, 500f)
        return (ln(f / 20f) / ln(25f)).coerceIn(0f, 1f)
    }

    private fun cutoffValue(t: Float): Float = (20.0 * Math.pow(25.0, t.toDouble())).toFloat().coerceAtMost(250f)

    private fun freqShort(f: Float): String = when {
        f >= 10000f -> String.format(Locale.US, "%.1f kHz", f / 1000f)
        f >= 1000f -> String.format(Locale.US, "%.1f kHz", f / 1000f)
        else -> String.format(Locale.US, "%.0f Hz", f)
    }

    // ---------- Vector-like icons ----------
    private fun drawWaveLogo(c: Canvas, x: Float, y: Float) {
        line.color = C_BLUE; line.strokeWidth = 5.5f; line.strokeCap = Paint.Cap.ROUND
        val xs = floatArrayOf(3f, 14f, 25f, 36f, 47f)
        val hs = floatArrayOf(22f, 45f, 64f, 45f, 22f)
        xs.forEachIndexed { i, dx -> c.drawLine(x + dx, y + 33f - hs[i] / 2f, x + dx, y + 33f + hs[i] / 2f, line) }
    }

    private fun drawBluetooth(c: Canvas, x: Float, y: Float, color: Int) {
        line.color = color; line.strokeWidth = 1.8f; line.strokeCap = Paint.Cap.ROUND; line.strokeJoin = Paint.Join.ROUND
        path.reset(); path.moveTo(x + 8f, y); path.lineTo(x + 17f, y + 8f); path.lineTo(x + 8f, y + 16f); path.lineTo(x + 8f, y); path.lineTo(x + 17f, y - 8f); path.lineTo(x + 8f, y - 16f); path.lineTo(x + 8f, y + 16f)
        c.drawPath(path, line); c.drawLine(x, y - 9f, x + 16f, y + 8f, line); c.drawLine(x, y + 9f, x + 16f, y - 8f, line)
    }

    private fun drawGear(c: Canvas, cx: Float, cy: Float, color: Int) {
        line.color = color; line.strokeWidth = 5f
        c.drawCircle(cx, cy, 12f, line)
        line.strokeWidth = 4f
        for (i in 0 until 8) {
            val a = i * Math.PI / 4
            val x1 = cx + (16f * kotlin.math.cos(a)).toFloat(); val y1 = cy + (16f * kotlin.math.sin(a)).toFloat()
            val x2 = cx + (21f * kotlin.math.cos(a)).toFloat(); val y2 = cy + (21f * kotlin.math.sin(a)).toFloat()
            c.drawLine(x1, y1, x2, y2, line)
        }
        p.style = Paint.Style.FILL; p.color = color; c.drawCircle(cx, cy, 4f, p)
    }

    private fun drawDevice(c: Canvas, x: Float, y: Float, color: Int) {
        line.color = color; line.strokeWidth = 2f
        c.drawRoundRect(RectF(x, y, x + 29f, y + 40f), 3f, 3f, line)
        c.drawCircle(x + 15f, y + 20f, 8f, line)
        p.style = Paint.Style.FILL; p.color = color; c.drawCircle(x + 24f, y + 7f, 2f, p)
        c.drawLine(x + 5f, y - 3f, x + 24f, y, line)
    }

    private fun drawLink(c: Canvas, x: Float, y: Float, color: Int) {
        line.color = color; line.strokeWidth = 2.5f; line.strokeCap = Paint.Cap.ROUND
        c.drawArc(RectF(x, y, x + 18f, y + 15f), 120f, 220f, false, line)
        c.drawArc(RectF(x + 10f, y + 6f, x + 28f, y + 21f), -60f, 220f, false, line)
        c.drawLine(x + 9f, y + 12f, x + 19f, y + 8f, line)
    }

    private fun drawSpeaker(c: Canvas, x: Float, y: Float, color: Int) {
        line.color = color; line.strokeWidth = 5f; line.strokeCap = Paint.Cap.ROUND; line.strokeJoin = Paint.Join.ROUND
        path.reset(); path.moveTo(x, y + 10f); path.lineTo(x + 12f, y + 10f); path.lineTo(x + 25f, y); path.lineTo(x + 25f, y + 43f); path.lineTo(x + 12f, y + 31f); path.lineTo(x, y + 31f); path.close(); c.drawPath(path, line)
        c.drawArc(RectF(x + 24f, y + 4f, x + 50f, y + 38f), -55f, 110f, false, line)
        c.drawArc(RectF(x + 21f, y - 4f, x + 63f, y + 47f), -52f, 104f, false, line)
    }

    private fun drawBass(c: Canvas, x: Float, y: Float, color: Int) {
        line.color = color; line.strokeWidth = 4f; line.strokeCap = Paint.Cap.ROUND
        c.drawArc(RectF(x, y, x + 56f, y + 56f), 210f, 120f, false, line)
        c.drawArc(RectF(x + 7f, y + 7f, x + 49f, y + 49f), 30f, 120f, false, line)
        c.drawCircle(x + 28f, y + 28f, 9f, line)
        c.drawLine(x + 1f, y + 24f, x + 9f, y + 24f, line); c.drawLine(x + 47f, y + 32f, x + 55f, y + 32f, line)
    }

    private fun drawWave(c: Canvas, x: Float, y: Float, color: Int) {
        line.color = color; line.strokeWidth = 3.5f; line.strokeCap = Paint.Cap.ROUND; line.strokeJoin = Paint.Join.ROUND
        path.reset(); path.moveTo(x, y + 15f); path.lineTo(x + 8f, y + 15f); path.lineTo(x + 14f, y - 3f); path.lineTo(x + 21f, y + 28f); path.lineTo(x + 29f, y - 16f); path.lineTo(x + 37f, y + 29f); path.lineTo(x + 44f, y + 2f); path.lineTo(x + 50f, y + 16f); path.lineTo(x + 58f, y + 16f); c.drawPath(path, line)
    }

    private fun drawBars(c: Canvas, x: Float, y: Float, color: Int) {
        line.color = color; line.strokeWidth = 5f; line.strokeCap = Paint.Cap.ROUND
        val heights = floatArrayOf(17f, 40f, 55f, 32f, 22f)
        for (i in heights.indices) c.drawLine(x + i * 11f, y + 28f - heights[i] / 2f, x + i * 11f, y + 28f + heights[i] / 2f, line)
    }

    private fun drawHomeIcon(c: Canvas, x: Float, y: Float, color: Int, scale: Float = 1f) {
        line.color = color; line.strokeWidth = 3f * scale; line.strokeJoin = Paint.Join.ROUND
        path.reset(); path.moveTo(x, y + 14f * scale); path.lineTo(x + 12f * scale, y); path.lineTo(x + 24f * scale, y + 14f * scale); c.drawPath(path, line)
        c.drawRect(RectF(x + 4f * scale, y + 13f * scale, x + 20f * scale, y + 27f * scale), line)
    }

    private fun drawMiniEq(c: Canvas, x: Float, y: Float, color: Int, scale: Float = 1f) {
        line.color = color; line.strokeWidth = 2.3f * scale; line.strokeCap = Paint.Cap.ROUND
        val hs = floatArrayOf(10f, 20f, 29f, 18f, 12f)
        for (i in hs.indices) c.drawLine(x + i * 5.5f * scale, y + 15f * scale - hs[i] / 2f * scale, x + i * 5.5f * scale, y + 15f * scale + hs[i] / 2f * scale, line)
    }

    private fun drawClock(c: Canvas, x: Float, y: Float, color: Int) {
        line.color = color; line.strokeWidth = 2.6f
        c.drawCircle(x + 12f, y + 12f, 12f, line); c.drawLine(x + 12f, y + 12f, x + 12f, y + 4f, line); c.drawLine(x + 12f, y + 12f, x + 18f, y + 16f, line)
    }

    private fun drawCross(c: Canvas, x: Float, y: Float, color: Int) {
        line.color = color; line.strokeWidth = 2.7f; line.strokeCap = Paint.Cap.ROUND
        path.reset(); path.moveTo(x, y); path.cubicTo(x + 8f, y, x + 10f, y + 17f, x + 25f, y + 17f); c.drawPath(path, line)
        path.reset(); path.moveTo(x, y + 17f); path.cubicTo(x + 8f, y + 17f, x + 10f, y, x + 25f, y); c.drawPath(path, line)
    }

    private fun drawSpeakerSmall(c: Canvas, x: Float, y: Float, color: Int) {
        line.color = color; line.strokeWidth = 2.6f; line.strokeJoin = Paint.Join.ROUND
        path.reset(); path.moveTo(x, y + 7f); path.lineTo(x + 6f, y + 7f); path.lineTo(x + 13f, y + 1f); path.lineTo(x + 13f, y + 22f); path.lineTo(x + 6f, y + 16f); path.lineTo(x, y + 16f); path.close(); c.drawPath(path, line)
        c.drawArc(RectF(x + 11f, y + 2f, x + 28f, y + 21f), -55f, 110f, false, line)
    }

    private fun drawChevron(c: Canvas, x: Float, y: Float, color: Int) {
        line.color = color; line.strokeWidth = 2f; line.strokeCap = Paint.Cap.ROUND
        c.drawLine(x, y, x + 5f, y + 5f, line); c.drawLine(x + 5f, y + 5f, x + 10f, y, line)
    }

    private fun drawBell(c: Canvas, x: Float, y: Float, color: Int) {
        line.color = color; line.strokeWidth = 2.2f; line.strokeCap = Paint.Cap.ROUND
        path.reset(); path.moveTo(x, y + 18f); path.cubicTo(x + 7f, y + 18f, x + 7f, y, x + 14f, y); path.cubicTo(x + 21f, y, x + 21f, y + 18f, x + 28f, y + 18f); c.drawPath(path, line)
    }

    private fun drawSave(c: Canvas, x: Float, y: Float, color: Int) {
        line.color = color; line.strokeWidth = 2.5f; line.strokeJoin = Paint.Join.ROUND
        c.drawRoundRect(RectF(x, y, x + 24f, y + 27f), 2f, 2f, line); c.drawRect(RectF(x + 5f, y, x + 18f, y + 9f), line); c.drawCircle(x + 12f, y + 20f, 4f, line)
    }

    private fun drawFolder(c: Canvas, x: Float, y: Float, color: Int) {
        line.color = color; line.strokeWidth = 2.5f; line.strokeJoin = Paint.Join.ROUND
        path.reset(); path.moveTo(x, y + 5f); path.lineTo(x + 10f, y + 5f); path.lineTo(x + 14f, y + 9f); path.lineTo(x + 30f, y + 9f); path.lineTo(x + 30f, y + 26f); path.lineTo(x, y + 26f); path.close(); c.drawPath(path, line)
    }

    private fun drawCopy(c: Canvas, x: Float, y: Float, color: Int) {
        line.color = color; line.strokeWidth = 2f
        c.drawRoundRect(RectF(x + 7f, y + 2f, x + 23f, y + 20f), 2f, 2f, line); c.drawRoundRect(RectF(x + 2f, y + 7f, x + 18f, y + 25f), 2f, 2f, line)
    }

    private fun drawPaste(c: Canvas, x: Float, y: Float, color: Int) {
        line.color = color; line.strokeWidth = 2f
        c.drawRoundRect(RectF(x + 3f, y + 5f, x + 24f, y + 26f), 2f, 2f, line); c.drawRoundRect(RectF(x + 8f, y + 1f, x + 19f, y + 8f), 2f, 2f, line)
    }

    private fun drawMore(c: Canvas, x: Float, y: Float, color: Int) {
        p.style = Paint.Style.FILL; p.color = color
        c.drawCircle(x, y, 3f, p); c.drawCircle(x + 12f, y, 3f, p); c.drawCircle(x + 24f, y, 3f, p)
    }

    private val C_TEXT = Color.rgb(241, 246, 250)
    private val C_MUTED = Color.rgb(171, 184, 212)
    private val C_BLUE = Color.rgb(8, 145, 255)
    private val C_GREEN = Color.rgb(81, 238, 94)
    private val C_BORDER = Color.rgb(34, 75, 102)
    private val C_TRACK = Color.rgb(40, 67, 84)
}
