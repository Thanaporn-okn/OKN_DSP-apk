from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
checks = {
    "app/build.gradle.kts": [
        'applicationId = "com.okn.dsp"',
        'versionCode = 1',
        'versionName = "1.0.0"',
    ],
    "app/src/main/AndroidManifest.xml": [
        'android:screenOrientation="portrait"',
        'android.permission.BLUETOOTH_SCAN',
        'android.permission.BLUETOOTH_CONNECT',
    ],
    "app/src/main/java/com/okn/dsp/ui/ReferenceDspUi.kt": [
        'Master Volume', 'Bass Volume', 'Bass Cutoff', 'Bass Boost',
        'Middle Boost', 'Treble Boost', 'กราฟ EQ', 'เลือกช่องสัญญาณ',
        'บันทึกพรีเซ็ต', 'โหลดพรีเซ็ต', 'คัดลอก EQ', 'วาง EQ',
    ],
    "app/src/main/java/com/okn/dsp/ble/BleProfile.kt": [
        '0000ab00-0000-1000-8000-00805f9b34fb',
        '0000ab01-0000-1000-8000-00805f9b34fb',
        '0000ab02-0000-1000-8000-00805f9b34fb',
        '0000ab03-0000-1000-8000-00805f9b34fb',
    ],
    "app/src/main/java/com/okn/dsp/protocol/ConfirmedDspMap.kt": [
        'MASTER_VOLUME = 2', 'BASS_VOLUME = 8', 'BASS_CUTOFF = 9',
        'BASS_BOOST = 10', 'MIDDLE_BOOST = 13', 'TREBLE_BOOST = 11',
        'intArrayOf(4, 5, 6, 14, 15, 16, 17)',
    ],
    "app/src/main/java/com/okn/dsp/protocol/LiveEqPolicy.kt": [
        'PEAKING', 'EqBandCodec.encode', 'offsetForBand',
    ],
}

failed = False
for rel, needles in checks.items():
    path = ROOT / rel
    if not path.exists():
        print(f"ERROR missing: {rel}")
        failed = True
        continue
    text = path.read_text(encoding="utf-8", errors="replace")
    for needle in needles:
        if needle not in text:
            print(f"ERROR {rel}: missing {needle!r}")
            failed = True

ui_source = (ROOT / "app/src/main/java/com/okn/dsp/ui/ReferenceDspUi.kt").read_text(encoding="utf-8", errors="replace")
if "ScrollView.LayoutParams" in ui_source:
    print("ERROR ReferenceDspUi.kt: invalid ScrollView.LayoutParams regression")
    failed = True
if "ViewGroup.LayoutParams" not in ui_source:
    print("ERROR ReferenceDspUi.kt: expected ViewGroup.LayoutParams")
    failed = True

ref = ROOT / "reference/OKN_DSP_v1_UI_REFERENCE.png"
if not ref.exists() or ref.stat().st_size < 100_000:
    print("ERROR UI reference image missing/invalid")
    failed = True

if failed:
    sys.exit(1)
print("OKN_DSP v1 preflight PASS")
print("UI reference + Android manifest + verified BLE/protocol boundary found.")
