OKN_DSP v1 — NEW CLEAN PROJECT
===============================

UI source of truth
- reference/OKN_DSP_v1_UI_REFERENCE.png
- Home page follows the supplied left screen: Master Volume, Bass Volume, Bass Cutoff,
  Bass Boost, Middle Boost, Treble Boost, quick presets, Save Preset, Load Preset.
- EQ page follows the supplied right screen: top Home/EQ/Delay/Crossover/Output tabs,
  EQ graph, seven visible colored EQ strips, CH1..CH7 selector, Copy/Paste/Save Preset,
  and the three-item bottom navigation.

Real DSP transport retained behind the new UI
- BLE service AB00
- AB01 write
- AB02 notify
- AB03 secondary notify
- Auth16 + RandKey AES-CFB8 session
- verified global scalar IDs: 2, 8, 9, 10, 13, 11
- verified 7-channel EQ actuator map: 4,5,6,14,15,16,17
- PEAKING type=12 full 48-byte EQ records only
- manual SaveParams ID7 only
- unknown/unguarded raw DSP writes are not exposed

Build
- Android applicationId: com.okn.dsp
- versionCode: 1
- versionName: 1.0.0
- minSdk: 26
- targetSdk / compileSdk: 35
- Java 17 / Kotlin 2.0.21 / AGP 8.7.3

The project ZIP intentionally contains no .github workflow folder. Use the separately
provided build-OKN_DSP.yml so a phone only needs to upload individual files.
