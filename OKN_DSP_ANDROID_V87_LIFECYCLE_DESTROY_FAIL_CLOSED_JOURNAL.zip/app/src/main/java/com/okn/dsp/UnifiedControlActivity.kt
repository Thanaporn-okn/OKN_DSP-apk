package com.okn.dsp

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.graphics.Typeface
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import com.okn.dsp.protocol.*
import com.okn.dsp.transport.BleProfile
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * V87 lifecycle-destroy fail-closed journal on top of the runtime-qualified V86 production baseline.
 *
 * V87 preserves the V74/V86-qualified writer surface and ordering: 7 verified scalar controls,
 * safe-PEAKING EQ, guarded SaveParams PRE/POST checks, persistent diagnostics, power-cycle proof,
 * stale-GATT isolation, per-session READ-ONLY health gate, connection/session/GATT epoch binding,
 * direct/persistent reconnect, stable upgrade signing, the 15 s connection-readiness watchdog,
 * and V86 all-status DISCONNECTED fail-closed handling.
 *
 * New V87 behavior: Activity destruction/recreation is also a fail-closed connection transition.
 * Any active scalar/EQ/Save pipeline is journaled as UNCONFIRMED and persisted before timers/state are cleared;
 * the active GATT is detached, connection/session state is invalidated, live cache is cleared, and old GATT is closed.
 * No automatic reconnect/START/Auth/DSP write/Save is sent from onDestroy().
 */
class UnifiedControlActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private val ts = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    private val startupProbe16 = ByteCodec.hexToBytes("631C062443FD3844558001F3EDA0CCF8")

    private lateinit var status: TextView
    private lateinit var deviceList: LinearLayout
    private lateinit var reconnectButton: Button
    private lateinit var startSessionButton: Button
    private lateinit var refreshButton: Button
    private lateinit var refreshInfo: TextView
    private lateinit var scalarHost: LinearLayout
    private lateinit var sensorHost: LinearLayout
    private lateinit var channelSpinner: Spinner
    private lateinit var eqHost: LinearLayout
    private lateinit var logView: TextView
    private lateinit var globalSection: LinearLayout
    private lateinit var eqSection: LinearLayout
    private lateinit var systemSection: LinearLayout
    private lateinit var globalTabButton: Button
    private lateinit var eqTabButton: Button
    private lateinit var systemTabButton: Button
    private lateinit var mainScroll: ScrollView
    private var productionTab = 0

    private var scanner: android.bluetooth.le.BluetoothLeScanner? = null
    private val found = LinkedHashMap<String, BluetoothDevice>()
    private var gatt: BluetoothGatt? = null
    private var ab01: BluetoothGattCharacteristic? = null
    private var ab02: BluetoothGattCharacteristic? = null
    private var connectedName: String? = null
    private var selectedDevice: BluetoothDevice? = null
    private var selectedDeviceName: String? = null
    private var pendingConnectRunnable: Runnable? = null
    private val lastDspPrefsName = "okn_dsp_last_device"
    private val lastDspAddressKey = "last_dsp_address"
    private val lastDspNameKey = "last_dsp_name"
    private val connectionReadyTimeoutMs = 15000L
    private var connectionWatchdog: Runnable? = null
    private var connectionWatchdogEpoch = -1L

    private var waitingAuth = false
    private var sessionReady = false
    private var txCipher: SessionTxCipher? = null
    private var rxCipher: SessionRxCipher? = null

    private enum class DescMode { INITIAL, REFRESH, WRITE_PREFLIGHT, VERIFY_TARGET, VERIFY_RESTORE, EQ_WRITE_PREFLIGHT, EQ_VERIFY_TARGET, EQ_VERIFY_RESTORE, SAVE_PRECHECK, SAVE_POSTCHECK }
    private enum class PendingGattPurpose { SCALAR_TARGET, SCALAR_RESTORE, EQ_TARGET, EQ_RESTORE, SAVE_PARAMS }
    private enum class GattWriteKind { OTHER, SCALAR_TARGET, SCALAR_RESTORE, EQ_TARGET, EQ_RESTORE, SAVE_PARAMS }
    private val gattWriteTickets = java.util.ArrayDeque<GattWriteKind>()
    private var descMode: DescMode? = null
    private var descExpected = -1
    private val descBytes = ByteArrayOutputStream()
    private var descriptorTimeout: Runnable? = null

    private var pendingId: Int? = null
    private var pendingTarget: Float? = null
    private var pendingOriginal: Float? = null
    private var pendingGattPurpose: PendingGattPurpose? = null
    private var gattActionTimeout: Runnable? = null

    private var pendingEqChannel = 0
    private var pendingEqBand = 0
    private var pendingEqRequestedBoost: Float? = null
    private var pendingEqOriginal: EqBand48? = null
    private var pendingEqTarget: EqBand48? = null
    private val eqTargetVerifyDelayMs = 3000L
    private val eqRestoreVerifyDelayMs = 3000L

    private val saveCommitSettleMs = 5000L
    private var unsavedVerifiedChanges = false
    private var verifiedChangeCount = 0
    private var verifiedScalarChangeCount = 0
    private var verifiedEqChangeCount = 0
    private var saveInFlight = false
    private var saveGattOk = false
    private var saveSettleRunnable: Runnable? = null
    private val verifiedScalarExpected = LinkedHashMap<Int, Float>()
    private val verifiedEqExpected = LinkedHashMap<String, EqBand48>()
    private lateinit var permanentSaveButton: Button
    private lateinit var dirtyInfo: TextView
    private lateinit var persistenceProofInfo: TextView
    private lateinit var diagnosticInfo: TextView
    private lateinit var armPowerCycleProofButton: Button
    private lateinit var fieldSelfCheckInfo: TextView
    private lateinit var fieldSelfCheckButton: Button
    private var sessionHealthGatePassed = false
    private var connectionEpoch = 0L
    private var controlSessionEpoch = 0L
    private var healthGateBoundConnectionEpoch = -1L
    private var healthGateBoundSessionEpoch = -1L
    private var healthGateBoundGattIdentity = 0

    private val scalarValues = LinkedHashMap<Int, Float>()
    private val bands = Array(7) { arrayOfNulls<EqBand48>(15) }
    private val sensors = mutableListOf<SensorSnapshot>()
    private var selectedChannel = 1

    private var refreshCount = 0
    private var refreshStartedElapsedMs = 0L
    private var refreshBeforeScalars: Map<Int, Float> = emptyMap()
    private var refreshBeforeSensors: Map<Int, String> = emptyMap()
    private var refreshBeforeEq: Map<String, String> = emptyMap()

    private data class SensorSnapshot(val id: Int, val name: String, val valueText: String)
    private data class PersistenceSnapshot(
        val savedAtMs: Long,
        val scalarExpected: LinkedHashMap<Int, Float>,
        val eqExpected: LinkedHashMap<String, EqBand48>,
    )

    private val proofPrefsName = "okn_dsp_v72_persistence_proof"
    private val proofSnapshotKey = "post_save_snapshot_json"
    private val proofArmedKey = "power_cycle_proof_armed"
    private val proofDisconnectSeenKey = "power_cycle_disconnect_seen"
    private val proofArmedAtKey = "power_cycle_proof_armed_at"
    private val proofLastResultKey = "power_cycle_last_result"

    private val captureLines = mutableListOf<String>()
    private var packetNo = 0
    private val criticalCaptureFileName = "okn_dsp_v87_last_critical_capture.txt"
    private val legacyCriticalCaptureFileNameV86 = "okn_dsp_v86_last_critical_capture.txt"
    private val legacyCriticalCaptureFileNameV85 = "okn_dsp_v85_last_critical_capture.txt"
    private val legacyCriticalCaptureFileNameV84 = "okn_dsp_v84_last_critical_capture.txt"
    private val legacyCriticalCaptureFileNameV83 = "okn_dsp_v83_last_critical_capture.txt"
    private val legacyCriticalCaptureFileName = "okn_dsp_v82_last_critical_capture.txt"
    private val legacyCriticalCaptureFileNameV81 = "okn_dsp_v81_last_critical_capture.txt"
    private val legacyCriticalCaptureFileNameV80 = "okn_dsp_v80_last_critical_capture.txt"
    private val legacyCriticalCaptureFileNameV79 = "okn_dsp_v79_last_critical_capture.txt"
    private val legacyCriticalCaptureFileNameV78 = "okn_dsp_v78_last_critical_capture.txt"
    private val legacyCriticalCaptureFileNameV77 = "okn_dsp_v77_last_critical_capture.txt"
    private val legacyCriticalCaptureFileNameV76 = "okn_dsp_v76_last_critical_capture.txt"
    private val legacyCriticalCaptureFileNameV75 = "okn_dsp_v75_last_critical_capture.txt"
    private val legacyCriticalCaptureFileNameV74 = "okn_dsp_v74_last_critical_capture.txt"
    private var recoveredCriticalCaptureText: String? = null
    private var gattActionArmedAtElapsedMs = 0L
    private var gattActionArmedGattIdentity = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        recoveredCriticalCaptureText = loadCriticalCapture()
        buildUi()
        record("META", "V87_UNIFIED_ACTIVITY_START")
        restoreLastDspReconnectUi()
        recordUpgradeContinuityProbe()
        requestBlePermissions()
        record("META", "V87_UNIFIED_POLICY scalarWrites=true scalarIds=2,3,8,9,10,13,11 eqWrites=safePeakingOnly eqIds=4,5,6,14,15,16,17 sensorReadOnly=true genericWrites=false saveParams=manualGuarded savePrecheck=true savePostcheck=true sessionHealthGate=requiredPerSession connectionEpochBinding=required persistentLastDspReconnect=localPrefsOnly lastDspCacheUi=explicit stableUpgradeSigning=projectStableDebugKey stableUpgradeContinuity=V83_PASSED connectionReadyWatchdog=failClosed15s passiveDisconnectEpochDetach=V84_CARRIED allStatusDisconnectFailClosed=V86_PASSED lifecycleDestroyFailClosed=required artifactDeliveryFix=V86_PASSED powerCycleReconnectProof=userArmedDisconnectRequired staleGattIsolation=activeGattIdentityRequired expectedScalars=7 expectedEqBands=105 expectedSensors=4")
        record("META", "V87_UNIFIED_RUNTIME_EVIDENCE unifiedScalarMigration=V67_PASSED unifiedLiveEqMigration=V68_PASSED saveStateHardening=V69_PASSED powerCycleReconnectPersistence=V70_PASSED staleGattIsolation=V71_PASSED staleGattBasis=V56_PROVEN uiMigration=V72_PRODUCTION diagnosticHardening=V73_PASSED gattArmBeforeWrite=V74_PASSED releaseBaselineFreeze=V75_PASSED sessionHealthGate=V76_PASSED connectionEpochHealthGate=V78_PASSED iconRefresh=V79_PASSED persistentLastDspReconnect=V80_PASSED connectionReadyWatchdog=V81_CARRIED stableUpgradeSigning=V82_CARRIED stableUpgradeContinuity=V83_PASSED passiveDisconnectEpochDetach=V84_STATUS8_FAIL_CLOSED_PROVEN allStatusDisconnectFailClosed=V86_PASSED lifecycleDestroyFailClosed=V87_PENDING_RUNTIME_PROOF artifactDeliveryFix=V86_PASSED lastDspCacheUi=V82_PASSED fieldSelfCheck=READ_ONLY eqProduction=V62/V64 liveEq=V51/V62 saveParamsPersistence=V57")
        if (recoveredCriticalCaptureText != null) {
            record("META", "V87_UNIFIED_RECOVERED_CRITICAL_CAPTURE available=true bytes=${recoveredCriticalCaptureText?.toByteArray()?.size ?: 0}")
        }
        refreshPersistenceProofUi()
        updateDiagnosticInfo()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (hasPendingControlWrite() || descMode != null || pendingGattPurpose != null || saveInFlight) {
            Toast.makeText(this, "V87 กำลัง write/verify/rollback/save • รอให้ pipeline จบก่อนออกจาก Unified", Toast.LENGTH_LONG).show()
            record("META", "V87_UNIFIED_BACK_BLOCKED pendingScalar=${pendingId ?: -1} eqCh=$pendingEqChannel eqBand=$pendingEqBand descMode=${descMode ?: "NONE"} gattPurpose=${pendingGattPurpose ?: "NONE"} saveInFlight=$saveInFlight")
            return
        }
        super.onBackPressed()
    }

    override fun onDestroy() {
        // V87 lifecycle invariant: Android may destroy/recreate this Activity without
        // going through onBackPressed() (for example configuration/activity recreation).
        // Capture control-write uncertainty BEFORE timers/pending state are cleared.
        val closingGatt = gatt
        val closingGattIdentity = closingGatt?.let { System.identityHashCode(it) } ?: 0
        val purposeAtDestroy = pendingGattPurpose
        val pendingScalarAtDestroy = pendingId ?: -1
        val pendingEqChannelAtDestroy = pendingEqChannel
        val pendingEqBandAtDestroy = pendingEqBand
        val hadSavePipeline = saveInFlight || purposeAtDestroy == PendingGattPurpose.SAVE_PARAMS
        val hadScalarPipeline = pendingId != null ||
            purposeAtDestroy == PendingGattPurpose.SCALAR_TARGET ||
            purposeAtDestroy == PendingGattPurpose.SCALAR_RESTORE
        val hadEqPipeline = pendingEqChannel != 0 ||
            purposeAtDestroy == PendingGattPurpose.EQ_TARGET ||
            purposeAtDestroy == PendingGattPurpose.EQ_RESTORE
        val hadControlPipeline = hadSavePipeline || hadScalarPipeline || hadEqPipeline

        if (hadSavePipeline) {
            record("META", "V87_UNIFIED_PERSISTENT_SAVE_UNCONFIRMED reason=activity-destroy-during-save changesRemainUnsaved=true")
        }
        if (hadScalarPipeline) {
            record("META", "V87_UNIFIED_WRITE_STATE_UNCONFIRMED reason=activity-destroy-during-scalar-pipeline id=$pendingScalarAtDestroy purpose=${purposeAtDestroy ?: "NONE"}")
        }
        if (hadEqPipeline) {
            record("META", "V87_UNIFIED_EQ_WRITE_STATE_UNCONFIRMED reason=activity-destroy-during-eq-pipeline ch=$pendingEqChannelAtDestroy band=$pendingEqBandAtDestroy purpose=${purposeAtDestroy ?: "NONE"}")
        }
        if (hadControlPipeline) {
            persistCriticalCapture(
                "activity-destroy-active-pipeline-save=$hadSavePipeline-scalar=$hadScalarPipeline-eq=$hadEqPipeline-purpose=${purposeAtDestroy ?: "NONE"}"
            )
        }

        cancelDescriptorTimeout()
        cancelGattActionTimeout()
        cancelConnectionWatchdog("activity-destroy")
        cancelSaveTimers()
        saveInFlight = false
        saveGattOk = false
        pendingConnectRunnable?.let { handler.removeCallbacks(it) }
        pendingConnectRunnable = null
        try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}

        // Detach first; any late callback from the old GATT is stale immediately.
        gatt = null
        invalidateForConnectionTransition("activity-destroy")
        try { closingGatt?.close() } catch (_: Exception) {}
        record(
            "META",
            "V87_LIFECYCLE_DESTROY_FAIL_CLOSED oldGattIdentity=$closingGattIdentity activeGattDetached=true controlPipelineUnconfirmed=$hadControlPipeline save=$hadSavePipeline scalar=$hadScalarPipeline eq=$hadEqPipeline connectionEpoch=$connectionEpoch sessionReady=$sessionReady healthGateValid=${sessionHealthGateValid()} staleSessionObjectsCleared=true"
        )
        super.onDestroy()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun productionSectionTitle(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 19f
        setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        setPadding(0, dp(10), 0, dp(6))
    }

    private fun selectProductionTab(tab: Int) {
        productionTab = tab
        if (!::globalSection.isInitialized) return
        globalSection.visibility = if (tab == 0) View.VISIBLE else View.GONE
        eqSection.visibility = if (tab == 1) View.VISIBLE else View.GONE
        systemSection.visibility = if (tab == 2) View.VISIBLE else View.GONE
        globalTabButton.text = if (tab == 0) "● GLOBAL" else "GLOBAL"
        eqTabButton.text = if (tab == 1) "● EQ 7CH" else "EQ 7CH"
        systemTabButton.text = if (tab == 2) "● STATUS" else "STATUS"
        mainScroll.post { mainScroll.smoothScrollTo(0, 0) }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(28))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(TextView(this).apply {
            text = "OKN DSP"
            textSize = 26f
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(TextView(this).apply {
            text = "V87 • PRODUCTION SAFE"
            textSize = 13f
        })
        root.addView(header)

        root.addView(TextView(this).apply {
            text = "Real DSP Control • Verified Global + 7CH EQ"
            textSize = 13f
            setPadding(0, 0, 0, dp(8))
        })

        status = TextView(this).apply {
            text = "DISCONNECTED • Connect to DSP to load live values"
            textSize = 15f
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        root.addView(status)

        val connection = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(6))
        }
        connection.addView(productionSectionTitle("DSP CONNECTION"))
        connection.addView(Button(this).apply {
            text = "SCAN DSP"
            setOnClickListener { startScan() }
        })
        deviceList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        connection.addView(deviceList)
        reconnectButton = Button(this).apply {
            text = "RECONNECT LAST DSP • NO SCAN"
            isEnabled = false
            setOnClickListener { reconnectCurrentDevice() }
        }
        connection.addView(reconnectButton)
        startSessionButton = Button(this).apply {
            text = "START CONTROL SESSION"
            isEnabled = false
            setOnClickListener { confirmStartSession() }
        }
        connection.addView(startSessionButton)
        refreshButton = Button(this).apply {
            text = "SYNC LIVE VALUES"
            isEnabled = false
            setOnClickListener { beginRefresh() }
        }
        connection.addView(refreshButton)
        refreshInfo = TextView(this).apply {
            text = "Live values are loaded from the DSP. Sync re-reads Global + EQ + Sensors in the same authenticated session."
            textSize = 12f
            setPadding(0, dp(2), 0, dp(8))
        }
        connection.addView(refreshInfo)
        root.addView(connection)

        dirtyInfo = TextView(this).apply {
            text = "No verified changes waiting to save"
            textSize = 13f
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            setPadding(0, dp(6), 0, dp(3))
        }
        root.addView(dirtyInfo)
        permanentSaveButton = Button(this).apply {
            text = "SAVE TO DSP • LOCKED"
            isEnabled = false
            setOnClickListener { confirmPermanentSave() }
        }
        root.addView(permanentSaveButton)
        root.addView(TextView(this).apply {
            text = "Manual save only • final DSP state is verified before and after SaveParams"
            textSize = 11f
            setPadding(0, 0, 0, dp(6))
        })

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        globalTabButton = Button(this).apply {
            text = "● GLOBAL"
            setOnClickListener { selectProductionTab(0) }
        }
        eqTabButton = Button(this).apply {
            text = "EQ 7CH"
            setOnClickListener { selectProductionTab(1) }
        }
        systemTabButton = Button(this).apply {
            text = "STATUS"
            setOnClickListener { selectProductionTab(2) }
        }
        tabs.addView(globalTabButton, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        tabs.addView(eqTabButton, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        tabs.addView(systemTabButton, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(tabs)

        globalSection = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        globalSection.addView(productionSectionTitle("GLOBAL CONTROLS"))
        globalSection.addView(TextView(this).apply {
            text = "7 verified controls • every Apply is followed by fresh DSP readback verification"
            textSize = 12f
        })
        scalarHost = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        globalSection.addView(scalarHost)
        root.addView(globalSection)

        eqSection = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        eqSection.addView(productionSectionTitle("7-CHANNEL EQ"))
        eqSection.addView(TextView(this).apply {
            text = "15 bands per channel • writable only when the live DSP band is verified safe PEAKING"
            textSize = 12f
            setPadding(0, 0, 0, dp(4))
        })
        channelSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@UnifiedControlActivity, android.R.layout.simple_spinner_dropdown_item,
                (1..7).map { "CH$it / ID${LiveEqPolicy.actuatorForChannel(it)}" })
            onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                    selectedChannel = position + 1
                    renderEq()
                }
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
            }
        }
        eqSection.addView(channelSpinner)
        eqHost = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        eqSection.addView(eqHost)
        root.addView(eqSection)

        systemSection = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        systemSection.addView(productionSectionTitle("DSP STATUS"))
        sensorHost = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        systemSection.addView(sensorHost)
        persistenceProofInfo = TextView(this).apply {
            text = "Persistence proof: no current snapshot"
            textSize = 13f
            setPadding(0, dp(12), 0, dp(4))
        }
        systemSection.addView(persistenceProofInfo)
        armPowerCycleProofButton = Button(this).apply {
            text = "ADVANCED • ARM POWER-CYCLE PROOF"
            isEnabled = false
            setOnClickListener { confirmArmPowerCycleProof() }
        }
        systemSection.addView(armPowerCycleProofButton)
        fieldSelfCheckInfo = TextView(this).apply {
            text = "V87 SESSION HEALTH GATE • LOCKED • run READ-ONLY check before APPLY/SAVE"
            textSize = 13f
            setPadding(0, dp(12), 0, dp(4))
        }
        systemSection.addView(fieldSelfCheckInfo)
        fieldSelfCheckButton = Button(this).apply {
            text = "RUN V87 SESSION HEALTH GATE • READ ONLY"
            setOnClickListener { runFieldSelfCheck() }
        }
        systemSection.addView(fieldSelfCheckButton)
        diagnosticInfo = TextView(this).apply {
            text = "Diagnostics: current session only"
            textSize = 12f
            setPadding(0, dp(12), 0, dp(4))
        }
        systemSection.addView(diagnosticInfo)
        systemSection.addView(Button(this).apply {
            text = "EXPORT DIAGNOSTIC CAPTURE • CURRENT + LAST FAILURE"
            setOnClickListener { saveCapture() }
        })
        systemSection.addView(Button(this).apply {
            text = "ADVANCED / EVIDENCE LAB"
            setOnClickListener { startActivity(Intent(this@UnifiedControlActivity, EvidenceLabActivity::class.java)) }
        })
        val logToggle = Button(this).apply { text = "SHOW SESSION LOG" }
        logView = TextView(this).apply {
            textSize = 11f
            visibility = View.GONE
            setPadding(0, dp(10), 0, 0)
        }
        logToggle.setOnClickListener {
            val show = logView.visibility != View.VISIBLE
            logView.visibility = if (show) View.VISIBLE else View.GONE
            logToggle.text = if (show) "HIDE SESSION LOG" else "SHOW SESSION LOG"
        }
        systemSection.addView(logToggle)
        systemSection.addView(logView)
        root.addView(systemSection)

        root.addView(TextView(this).apply {
            text = "Verified write scope: Global IDs 2,3,8,9,10,13,11 + safe PEAKING EQ only. Preset / Delay / unknown writes remain locked."
            textSize = 11f
            setPadding(0, dp(16), 0, 0)
        })

        mainScroll = ScrollView(this).apply { addView(root) }
        setContentView(mainScroll)
        renderAll()
        refreshPersistenceProofUi()
        selectProductionTab(0)
    }

    private fun beginRefresh() {
        if (!sessionReady || descMode != null || waitingAuth || txCipher == null || gatt == null || ab01 == null || hasPendingControlWrite() || saveInFlight || pendingGattPurpose != null) {
            Toast.makeText(this, "V87 session busy/not ready", Toast.LENGTH_SHORT).show()
            record("META", "V87_UNIFIED_REFRESH_BLOCKED sessionReady=$sessionReady descMode=$descMode waitingAuth=$waitingAuth txReady=${txCipher != null} gattReady=${gatt != null} ab01Ready=${ab01 != null}")
            return
        }
        refreshCount += 1
        refreshStartedElapsedMs = android.os.SystemClock.elapsedRealtime()
        refreshBeforeScalars = LinkedHashMap(scalarValues)
        refreshBeforeSensors = sensors.associate { it.id to it.valueText }
        refreshBeforeEq = snapshotEqSignatures()
        refreshButton.isEnabled = false
        refreshButton.text = "SYNCING #$refreshCount • PLEASE WAIT"
        status.text = "V87 REFRESHING #$refreshCount • SAME SESSION • re-reading 7 scalars + 105 EQ + 4 sensors"
        refreshInfo.text = "REFRESH #$refreshCount STARTED • ${ts.format(Date())} • กำลังอ่าน Device Description ใหม่ทั้งชุด"
        record("META", "V87_UNIFIED_REFRESH_TAP refresh=$refreshCount sameSession=true scalarWrites=true eqWrites=safePeakingOnly sensorReadOnly=true beforeScalars=${refreshBeforeScalars.size} beforeEq=${refreshBeforeEq.size} beforeSensors=${refreshBeforeSensors.size}")
        if (!requestDescriptor(DescMode.REFRESH)) {
            refreshButton.text = "SYNC LIVE VALUES"
            refreshButton.isEnabled = sessionReady
            refreshInfo.text = "REFRESH #$refreshCount FAILED TO QUEUE • ${ts.format(Date())} • descriptor refresh queue failed; no REFRESH write exists"
            record("META", "V87_UNIFIED_REFRESH_QUEUE_FAILED refresh=$refreshCount")
        }
    }

    private fun confirmStartSession() {
        if (saveInFlight || hasPendingControlWrite() || descMode != null || pendingGattPurpose != null || waitingAuth) {
            Toast.makeText(this, "V87 protocol busy • รอ pipeline ปัจจุบันให้จบก่อน START ใหม่", Toast.LENGTH_LONG).show(); return
        }
        if (gatt == null || ab01 == null || ab02 == null) {
            Toast.makeText(this, "เชื่อม DSP และรอ AB02 READY ก่อน", Toast.LENGTH_LONG).show(); return
        }
        AlertDialog.Builder(this)
            .setTitle("Start V87 unified verified-control session")
            .setMessage("AUTH16 → derive RandKey → อ่าน Device Description สด → โหลด Global 7 + EQ 105 bands + 4 sensors ใน session เดียว\n\nV87 อนุญาต WRITE 0x57 เฉพาะ scalar IDs 2,3,8,9,10,13,11 และ EQ safe PEAKING type=12 เท่านั้น. ทั้งสอง path ใช้ fresh-preflight + matching GATT success + fresh verify + exact rollback. Sensors/non-standard EQ READ ONLY. SaveParams manual guarded เท่านั้น. V87 จะ invalidate session/gate ทันทีเมื่อเริ่ม connect/reconnect และจะยังล็อก APPLY/SAVE จนกว่า current connection+session epoch จะผ่าน SESSION HEALTH GATE แบบ READ ONLY")
            .setNegativeButton("ยกเลิก", null)
            .setPositiveButton("START V87") { _, _ -> startSession() }
            .show()
    }

    private fun startSession() {
        val g = gatt ?: return
        val w = ab01 ?: return
        waitingAuth = true
        sessionReady = false
        controlSessionEpoch += 1L
        resetSessionHealthGate("new-session")
        txCipher = null
        rxCipher = null
        descMode = null
        descExpected = -1
        descBytes.reset()
        scalarValues.clear()
        sensors.clear()
        for (c in bands.indices) for (b in bands[c].indices) bands[c][b] = null
        clearPending("new-session", recordEvent = false)
        clearPendingEq("new-session", recordEvent = false)
        pendingGattPurpose = null
        synchronized(gattWriteTickets) { gattWriteTickets.clear() }
        cancelDescriptorTimeout()
        cancelGattActionTimeout()
        cancelSaveTimers()
        unsavedVerifiedChanges = false
        verifiedChangeCount = 0
        verifiedScalarChangeCount = 0
        verifiedEqChangeCount = 0
        verifiedScalarExpected.clear()
        verifiedEqExpected.clear()
        saveInFlight = false
        saveGattOk = false
        refreshButton.isEnabled = false
        refreshButton.text = "SYNC LIVE VALUES"
        refreshCount = 0
        refreshStartedElapsedMs = 0L
        refreshBeforeScalars = emptyMap()
        refreshBeforeSensors = emptyMap()
        refreshBeforeEq = emptyMap()
        if (::refreshInfo.isInitialized) refreshInfo.text = "REFRESH STATUS • session ใหม่กำลังเริ่ม • รอ V87 UNIFIED READY"
        renderAll()
        record("META", "V87_UNIFIED_SESSION_START")
        if (!writeNoResponse(g, w, startupProbe16, "TX_AUTH16_V87_UNIFIED")) {
            waitingAuth = false
            status.text = "AUTH16 queue failed"
        } else status.text = "AUTH16 sent • waiting 32B auth response"
    }

    private fun requestDescriptor(mode: DescMode): Boolean {
        val g = gatt
        val w = ab01
        val tx = txCipher
        if (g == null || w == null || tx == null) {
            record("META", "V87_UNIFIED_DESC_BLOCKED mode=$mode reason=session-object-missing")
            onDescriptorFailure(mode, "session-object-missing")
            return false
        }
        if (descMode != null) {
            record("META", "V87_UNIFIED_DESC_BLOCKED mode=$mode reason=descriptor-busy current=$descMode")
            onDescriptorFailure(mode, "descriptor-busy")
            return false
        }
        descMode = mode
        descExpected = -1
        descBytes.reset()
        val plain = SessionCryptoFacts.DEVICE_DESCRIPTION_REQUEST
        val enc = tx.encryptNext(plain)
        record("META", "V87_UNIFIED_DESC_REQUEST mode=$mode plain=${ByteCodec.run { plain.toHex() }} sameSession=true")
        if (!writeNoResponse(g, w, enc, "TX_DESC_V87_UNIFIED_${mode.name}")) {
            descMode = null
            sessionReady = false
            record("META", "V87_UNIFIED_TX_STREAM_UNCERTAIN reason=descriptor-queue-failed mode=$mode action=STOP_REAUTH")
            when (mode) {
                DescMode.WRITE_PREFLIGHT -> {
                    status.text = "V87 WRITE BLOCKED • descriptor queue failed • STOP/START new session"
                    clearPending("preflight-descriptor-queue-failed")
                }
                DescMode.VERIFY_TARGET -> {
                    status.text = "TARGET VERIFY UNCONFIRMED • TX stream uncertain • STOP • DO NOT SAVE"
                    clearPending("target-verify-descriptor-queue-failed")
                }
                DescMode.VERIFY_RESTORE -> {
                    status.text = "SCALAR RESTORE VERIFY UNCONFIRMED • TX stream uncertain • STOP • DO NOT SAVE"
                    clearPending("restore-verify-descriptor-queue-failed")
                }
                DescMode.EQ_WRITE_PREFLIGHT -> {
                    status.text = "V87 EQ WRITE BLOCKED • descriptor queue failed • STOP/START new session"
                    clearPendingEq("preflight-descriptor-queue-failed")
                }
                DescMode.EQ_VERIFY_TARGET -> {
                    status.text = "EQ TARGET VERIFY UNCONFIRMED • TX stream uncertain • STOP • DO NOT SAVE"
                    clearPendingEq("target-verify-descriptor-queue-failed")
                }
                DescMode.EQ_VERIFY_RESTORE -> {
                    status.text = "EQ RESTORE VERIFY UNCONFIRMED • TX stream uncertain • STOP • DO NOT SAVE"
                    clearPendingEq("restore-verify-descriptor-queue-failed")
                }
                DescMode.SAVE_PRECHECK -> markSaveUnconfirmed("pre-save-descriptor-queue-failed")
                DescMode.SAVE_POSTCHECK -> markSaveUnconfirmed("post-save-descriptor-queue-failed")
                DescMode.INITIAL, DescMode.REFRESH -> {
                    status.text = "V87 descriptor queue failed • TX stream uncertain • START new session"
                    updateActionButtons()
                }
            }
            return false
        }
        cancelDescriptorTimeout()
        descriptorTimeout = Runnable {
            if (descMode != mode) return@Runnable
            record("META", "V87_UNIFIED_DESC_TIMEOUT mode=$mode id=${pendingId ?: -1} eqCh=$pendingEqChannel eqBand=$pendingEqBand")
            descMode = null
            descExpected = -1
            descBytes.reset()
            onDescriptorFailure(mode, "timeout")
        }.also { handler.postDelayed(it, 15000L) }
        return true
    }

    private fun onDescriptorFailure(mode: DescMode, reason: String) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            handler.post { onDescriptorFailure(mode, reason) }
            return
        }
        when (mode) {
            DescMode.WRITE_PREFLIGHT -> {
                status.text = "V87 WRITE BLOCKED • fresh preflight descriptor failed ($reason)"
                clearPending("preflight-$reason")
            }
            DescMode.VERIFY_TARGET -> restorePending("target-verify-$reason")
            DescMode.VERIFY_RESTORE -> {
                sessionReady = false
                status.text = "SCALAR RESTORE VERIFY FAILED/UNCONFIRMED — STOP • export capture"
                record("META", "V87_UNIFIED_RESTORE_VERIFY_FATAL reason=$reason id=${pendingId ?: -1}")
                clearPending("restore-verify-$reason")
            }
            DescMode.EQ_WRITE_PREFLIGHT -> {
                status.text = "V87 EQ WRITE BLOCKED • fresh preflight descriptor failed ($reason)"
                clearPendingEq("preflight-$reason")
            }
            DescMode.EQ_VERIFY_TARGET -> restorePendingEq("target-verify-$reason")
            DescMode.EQ_VERIFY_RESTORE -> {
                sessionReady = false
                status.text = "EQ RESTORE VERIFY FAILED/UNCONFIRMED — STOP • DO NOT SAVE • export capture"
                record("META", "V87_UNIFIED_EQ_RESTORE_VERIFY_FATAL reason=$reason ch=$pendingEqChannel band=$pendingEqBand")
                clearPendingEq("restore-verify-$reason")
            }
            DescMode.SAVE_PRECHECK -> markSaveUnconfirmed("pre-save-descriptor-$reason")
            DescMode.SAVE_POSTCHECK -> markSaveUnconfirmed("post-save-descriptor-$reason")
            DescMode.INITIAL, DescMode.REFRESH -> {
                sessionReady = false
                status.text = "V87 descriptor read failed ($mode/$reason)"
                updateActionButtons()
            }
        }
    }

    private fun cancelDescriptorTimeout() {
        descriptorTimeout?.let { handler.removeCallbacks(it) }
        descriptorTimeout = null
    }

    private fun handleAb02(value: ByteArray) {
        record("RX_NOTIFY", "len=${value.size} hex=${ByteCodec.run { value.toHex() }}")
        if (waitingAuth) {
            if (value.size != 32) return
            try {
                val d = PreAuthRandKeyDecoder.decode(value)
                txCipher = SessionTxCipher(d.randKey)
                rxCipher = SessionRxCipher(d.randKey)
                waitingAuth = false
                record("META", "V87_UNIFIED_RANDKEY_DERIVED type=${d.typeId} ver=${d.versionId} rand=${ByteCodec.run { d.randKey.toHex() }}")
                requestDescriptor(DescMode.INITIAL)
            } catch (e: Exception) {
                waitingAuth = false
                record("META", "V87_UNIFIED_AUTH_DECODE_ERROR ${e.javaClass.simpleName}:${e.message}")
                runOnUiThread { status.text = "Auth decode failed" }
            }
            return
        }
        val rx = rxCipher ?: return
        val plain = try { rx.decryptNext(value) } catch (e: Exception) {
            val activeMode = descMode
            record("META", "V87_UNIFIED_RX_DECRYPT_ERROR ${e.javaClass.simpleName}:${e.message} mode=${activeMode ?: "NONE"}")
            sessionReady = false
            if (activeMode != null) {
                descMode = null
                descExpected = -1
                descBytes.reset()
                cancelDescriptorTimeout()
                onDescriptorFailure(activeMode, "rx-decrypt-error")
            }
            return
        }
        record("RX_PLAIN", "len=${plain.size} hex=${ByteCodec.run { plain.toHex() }}")
        if (descMode != null) collectDescriptor(plain)
    }

    private fun collectDescriptor(plain: ByteArray) {
        val mode = descMode ?: return
        if (descExpected < 0) {
            if (plain.size < 4 || (plain[0].toInt() and 0xff) != 0x86) {
                record("META", "V87_UNIFIED_DESC_NONHEADER mode=$mode marker=${plain.firstOrNull()?.toInt()?.and(0xff)} len=${plain.size}")
                return
            }
            descExpected = (plain[1].toInt() and 0xff) or
                ((plain[2].toInt() and 0xff) shl 8) or
                ((plain[3].toInt() and 0xff) shl 16)
            descBytes.reset()
            descBytes.write(plain, 4, plain.size - 4)
            record("META", "V87_UNIFIED_DESC_HEADER mode=$mode jsonLen=$descExpected")
        } else {
            if (plain.isEmpty() || (plain[0].toInt() and 0xff) != 0x82) {
                record("META", "V87_UNIFIED_DESC_NONCONT mode=$mode marker=${plain.firstOrNull()?.toInt()?.and(0xff)} len=${plain.size}")
                return
            }
            descBytes.write(plain, 1, plain.size - 1)
        }
        if (descExpected > 0 && descBytes.size() >= descExpected) {
            val bytes = descBytes.toByteArray().copyOf(descExpected)
            val obj = try { JSONObject(bytes.toString(Charsets.UTF_8)) } catch (e: Exception) {
                record("META", "V87_UNIFIED_DESC_JSON_ERROR mode=$mode ${e.javaClass.simpleName}:${e.message}")
                cancelDescriptorTimeout()
                descMode = null
                descExpected = -1
                descBytes.reset()
                sessionReady = false
                onDescriptorFailure(mode, "json-error")
                return
            }
            record("META", "V87_UNIFIED_DESC_COMPLETE mode=$mode bytes=${bytes.size}")
            cancelDescriptorTimeout()
            descMode = null
            descExpected = -1
            descBytes.reset()
            handler.post { loadUnified(mode, obj) }
        }
    }

    private fun loadUnified(mode: DescMode, obj: JSONObject) {
        scalarValues.clear()
        val acts = obj.optJSONArray("actuators")
        if (acts != null) {
            for (i in 0 until acts.length()) {
                val a = acts.optJSONObject(i) ?: continue
                val id = a.optInt("ID", -1)
                if (VerifiedScalarControls.allowed(id) && a.optInt("type", -1) == 2000 && a.has("UFE_TYPE_FLOAT32")) {
                    val v = a.optDouble("UFE_TYPE_FLOAT32", Double.NaN).toFloat()
                    if (v.isFinite()) scalarValues[id] = v
                }
            }
        }

        var eqCount = 0
        var writableCount = 0
        for (ch in 1..7) {
            val actuator = LiveEqPolicy.actuatorForChannel(ch)
            for (band1 in 1..15) {
                val band = extractBand(obj, actuator, band1)
                bands[ch - 1][band1 - 1] = band
                if (band != null) {
                    eqCount++
                    if (LiveEqPolicy.isWritable(band)) writableCount++
                }
            }
        }

        sensors.clear()
        val sArr = obj.optJSONArray("sensors")
        if (sArr != null) {
            for (i in 0 until sArr.length()) {
                val s = sArr.optJSONObject(i) ?: continue
                val id = s.optInt("ID", -999)
                val name = s.optString("name", "Sensor$id")
                val valueText = when {
                    s.has("UFE_TYPE_FLOAT32") -> {
                        val v = s.optDouble("UFE_TYPE_FLOAT32", Double.NaN)
                        if (v.isFinite()) String.format(Locale.US, "%.3f", v) else "NaN"
                    }
                    s.has("UFE_TYPE_BOOLEAN_INDICATE") -> s.optBoolean("UFE_TYPE_BOOLEAN_INDICATE").toString()
                    else -> "unknown"
                }
                sensors.add(SensorSnapshot(id, name, valueText))
            }
        }

        val scalarOk = scalarValues.size == VerifiedScalarControls.controls.size
        val eqOk = eqCount == 105
        val sensorOk = sensors.size == 4
        sessionReady = scalarOk && eqOk && sensorOk
        record("META", "V87_UNIFIED_LOAD mode=$mode scalarCount=${scalarValues.size} expectedScalars=7 eqBands=$eqCount expectedEqBands=105 writablePeakingBands=$writableCount sensors=${sensors.size} expectedSensors=4 ready=$sessionReady scalarWrites=true eqWrites=safePeakingOnly sensorReadOnly=true genericWrites=false saveParamsManual=true")
        renderAll()

        when (mode) {
            DescMode.INITIAL -> {
                status.text = if (sessionReady) {
                    "V87 UNIFIED READY • 7 verified scalars + 105 EQ (safe PEAKING writable) + 4 sensors READ ONLY"
                } else {
                    "V87 UNIFIED BLOCKED • scalar=${scalarValues.size}/7 EQ=$eqCount/105 sensors=${sensors.size}/4"
                }
                refreshInfo.text = if (sessionReady) {
                    "REFRESH STATUS • READY • REFRESH ALL re-reads 7 + 105 + 4 in this same authenticated session"
                } else "REFRESH STATUS • BLOCKED • initial load incomplete"
                maybeVerifyArmedPersistenceProof(eqCount)
            }
            DescMode.REFRESH -> finishRefresh(eqCount)
            DescMode.WRITE_PREFLIGHT -> handleWritePreflight(eqCount)
            DescMode.VERIFY_TARGET -> handleTargetVerify(eqCount)
            DescMode.VERIFY_RESTORE -> handleRestoreVerify(eqCount)
            DescMode.EQ_WRITE_PREFLIGHT -> handleEqWritePreflight(eqCount)
            DescMode.EQ_VERIFY_TARGET -> handleEqTargetVerify(eqCount)
            DescMode.EQ_VERIFY_RESTORE -> handleEqRestoreVerify(eqCount)
            DescMode.SAVE_PRECHECK -> handleSaveStateCheck(eqCount, preSave = true)
            DescMode.SAVE_POSTCHECK -> handleSaveStateCheck(eqCount, preSave = false)
        }
        updateActionButtons()
        record("META", "V87_UNIFIED_RENDER_COMPLETE mode=$mode scalarRows=${scalarValues.size} eqRows=${bands[selectedChannel - 1].count { it != null }} sensorRows=${sensors.size} mainThread=${Looper.myLooper() == Looper.getMainLooper()}")
    }

    private fun finishRefresh(eqCount: Int) {
        val afterEq = snapshotEqSignatures()
        val scalarChanged = VerifiedScalarControls.controls.count { c ->
            val before = refreshBeforeScalars[c.id]
            val after = scalarValues[c.id]
            before == null || after == null || kotlin.math.abs(before - after) > 0.0001f
        }
        val afterSensors = sensors.associate { it.id to it.valueText }
        val sensorKeys = refreshBeforeSensors.keys + afterSensors.keys
        val sensorChanged = sensorKeys.count { refreshBeforeSensors[it] != afterSensors[it] }
        val eqKeys = refreshBeforeEq.keys + afterEq.keys
        val eqChanged = eqKeys.count { refreshBeforeEq[it] != afterEq[it] }
        val elapsed = if (refreshStartedElapsedMs > 0L) android.os.SystemClock.elapsedRealtime() - refreshStartedElapsedMs else -1L
        val unchanged = scalarChanged == 0 && sensorChanged == 0 && eqChanged == 0
        val summary = if (unchanged) "NO VALUE CHANGES • refresh สำเร็จ แต่ DSP ส่งค่าชุดเดิม" else "CHANGED • scalars=$scalarChanged • EQ=$eqChanged • sensors=$sensorChanged"
        refreshInfo.text = "REFRESH #$refreshCount COMPLETE • ${ts.format(Date())} • ${elapsed}ms • $summary"
        status.text = if (sessionReady) "V87 UNIFIED READY • REFRESH #$refreshCount COMPLETE • same session" else "V87 REFRESH #$refreshCount BLOCKED • scalar=${scalarValues.size}/7 EQ=$eqCount/105 sensors=${sensors.size}/4"
        record("META", "V87_UNIFIED_REFRESH_COMPLETE refresh=$refreshCount elapsedMs=$elapsed scalarChanged=$scalarChanged eqChanged=$eqChanged sensorChanged=$sensorChanged unchanged=$unchanged scalarCount=${scalarValues.size} eqBands=$eqCount sensors=${sensors.size} ready=$sessionReady sameSession=true")
        Toast.makeText(this, "REFRESH #$refreshCount COMPLETE • ${if (unchanged) "values unchanged" else "values updated"}", Toast.LENGTH_LONG).show()
    }

    private fun handleWritePreflight(eqCount: Int) {
        val id = pendingId ?: return
        val target = pendingTarget ?: return
        if (!sessionReady || eqCount != 105 || !VerifiedScalarControls.allowed(id)) {
            record("META", "V87_UNIFIED_SCALAR_PREFLIGHT_BLOCKED id=$id ready=$sessionReady scalarCount=${scalarValues.size} eqBands=$eqCount sensors=${sensors.size}")
            status.text = "V87 WRITE BLOCKED • fresh descriptor/count/allow-list preflight failed"
            clearPending("preflight-invariants-failed")
            return
        }
        val original = scalarValues[id]
        if (original == null) {
            status.text = "V87 WRITE BLOCKED • fresh baseline missing for ID$id"
            clearPending("preflight-baseline-missing")
            return
        }
        pendingOriginal = original
        record("META", "V87_UNIFIED_SCALAR_PREFLIGHT_OK id=$id freshBaseline=$original target=$target scalarCount=7 eqBands=105 sensors=4 sameSession=true")
        if (VerifiedScalarControls.matches(id, original, target)) {
            status.text = "V87 NO WRITE • target already equals fresh baseline for ID$id"
            record("META", "V87_UNIFIED_SCALAR_NOOP id=$id baseline=$original target=$target")
            clearPending("target-equals-baseline", recordEvent = false)
            return
        }
        sendScalarTargetAfterPreflight()
    }

    private fun handleTargetVerify(eqCount: Int) {
        val id = pendingId ?: return
        val expected = pendingTarget ?: return
        val actual = scalarValues[id]
        val ok = sessionReady && eqCount == 105 && actual != null && VerifiedScalarControls.matches(id, actual, expected)
        record("META", "V87_UNIFIED_TARGET_DESCRIPTOR_VERIFY id=$id expected=$expected actual=${actual ?: "MISSING"} verified=$ok fullDescriptorReady=$sessionReady")
        if (ok) {
            unsavedVerifiedChanges = true
            verifiedChangeCount += 1
            verifiedScalarChangeCount += 1
            verifiedScalarExpected[id] = actual!!
            status.text = "V87 VERIFIED • ID$id=${fmt(actual)} • RAM DIRTY • Permanent Save remains manual"
            record("META", "V87_UNIFIED_SCALAR_WRITE_COMPLETE id=$id verified=true persistence=RAM_DIRTY verifiedChangeCount=$verifiedChangeCount scalarVerified=$verifiedScalarChangeCount eqVerified=$verifiedEqChangeCount saveParamsSent=false")
            clearPending("target-verified", recordEvent = false)
        } else {
            restorePending("target-verify-failed")
        }
    }

    private fun handleRestoreVerify(eqCount: Int) {
        val id = pendingId ?: return
        val expected = pendingOriginal ?: return
        val actual = scalarValues[id]
        val ok = sessionReady && eqCount == 105 && actual != null && VerifiedScalarControls.matches(id, actual, expected)
        record("META", "V87_UNIFIED_RESTORE_DESCRIPTOR_VERIFY id=$id expected=$expected actual=${actual ?: "MISSING"} verified=$ok fullDescriptorReady=$sessionReady")
        if (ok) {
            status.text = "V87 TARGET VERIFY FAILED • exact fresh baseline restored safely • no SaveParams"
        } else {
            sessionReady = false
            status.text = "RESTORE VERIFY FAILED — STOP CONTROL • DO NOT SAVE • export capture"
            record("META", "V87_UNIFIED_RESTORE_VERIFY_FATAL id=$id expected=$expected actual=${actual ?: "MISSING"}")
        }
        clearPending(if (ok) "restore-verified" else "restore-verify-failed", recordEvent = false)
    }

    private fun handleEqWritePreflight(eqCount: Int) {
        val ch = pendingEqChannel
        val band1 = pendingEqBand
        val requested = pendingEqRequestedBoost ?: return
        if (!sessionReady || eqCount != 105 || ch !in 1..7 || band1 !in 1..15) {
            record("META", "V87_UNIFIED_EQ_PREFLIGHT_BLOCKED ch=$ch band=$band1 ready=$sessionReady scalarCount=${scalarValues.size} eqBands=$eqCount sensors=${sensors.size}")
            status.text = "V87 EQ WRITE BLOCKED • fresh descriptor/count preflight failed"
            clearPendingEq("preflight-invariants-failed")
            return
        }
        val original = bands[ch - 1][band1 - 1]
        if (original == null || !LiveEqPolicy.isWritable(original)) {
            record("META", "V87_UNIFIED_EQ_PREFLIGHT_BLOCKED ch=$ch band=$band1 reason=missing-or-non-safe-peaking")
            status.text = "V87 EQ WRITE BLOCKED • fresh band is not safe PEAKING"
            clearPendingEq("preflight-band-not-writable")
            return
        }
        val target = try { LiveEqPolicy.targetFromCurrent(original, requested) } catch (e: Exception) {
            record("META", "V87_UNIFIED_EQ_PREFLIGHT_BLOCKED ch=$ch band=$band1 reason=target-invalid ${e.javaClass.simpleName}:${e.message}")
            status.text = "V87 EQ WRITE BLOCKED • target invalid"
            clearPendingEq("target-invalid")
            return
        }
        pendingEqOriginal = original
        pendingEqTarget = target
        record("META", "V87_UNIFIED_EQ_PREFLIGHT_OK ch=$ch actuator=${LiveEqPolicy.actuatorForChannel(ch)} band=$band1 offset=${LiveEqPolicy.offsetForBand(band1)} freshBoost=${original.boostDb} targetBoost=${target.boostDb} fullRecordBytes=48 scalarCount=7 eqBands=105 sensors=4 sameSession=true")
        if (LiveEqPolicy.semanticMatches(original, target)) {
            status.text = "V87 EQ NO WRITE • target already equals fresh baseline CH$ch Band$band1"
            record("META", "V87_UNIFIED_EQ_NOOP ch=$ch band=$band1 baselineBoost=${original.boostDb} targetBoost=${target.boostDb}")
            clearPendingEq("target-equals-baseline", recordEvent = false)
            return
        }
        sendEqTargetAfterPreflight()
    }

    private fun handleEqTargetVerify(eqCount: Int) {
        val ch = pendingEqChannel
        val band1 = pendingEqBand
        val expected = pendingEqTarget ?: return
        val actual = if (ch in 1..7 && band1 in 1..15) bands[ch - 1][band1 - 1] else null
        val ok = sessionReady && eqCount == 105 && actual != null && LiveEqPolicy.semanticMatches(actual, expected)
        record("META", "V87_UNIFIED_EQ_TARGET_DESCRIPTOR_VERIFY ch=$ch actuator=${if (ch in 1..7) LiveEqPolicy.actuatorForChannel(ch) else -1} band=$band1 expectedBoost=${expected.boostDb} actualBoost=${actual?.boostDb ?: Float.NaN} verified=$ok fullDescriptorReady=$sessionReady")
        if (ok) {
            unsavedVerifiedChanges = true
            verifiedChangeCount += 1
            verifiedEqChangeCount += 1
            verifiedEqExpected["$ch:$band1"] = actual!!
            status.text = "V87 EQ VERIFIED • CH$ch Band$band1=${fmt(actual.boostDb)}dB • RAM DIRTY • Permanent Save remains manual"
            record("META", "V87_UNIFIED_EQ_WRITE_COMPLETE ch=$ch actuator=${LiveEqPolicy.actuatorForChannel(ch)} band=$band1 appliedBoost=${actual.boostDb} verified=true persistence=RAM_DIRTY verifiedChangeCount=$verifiedChangeCount scalarVerified=$verifiedScalarChangeCount eqVerified=$verifiedEqChangeCount saveParamsSent=false")
            clearPendingEq("target-verified", recordEvent = false)
        } else {
            restorePendingEq("target-verify-failed")
        }
    }

    private fun handleEqRestoreVerify(eqCount: Int) {
        val ch = pendingEqChannel
        val band1 = pendingEqBand
        val expected = pendingEqOriginal ?: return
        val actual = if (ch in 1..7 && band1 in 1..15) bands[ch - 1][band1 - 1] else null
        val ok = sessionReady && eqCount == 105 && actual != null && LiveEqPolicy.semanticMatches(actual, expected)
        record("META", "V87_UNIFIED_EQ_RESTORE_DESCRIPTOR_VERIFY ch=$ch actuator=${if (ch in 1..7) LiveEqPolicy.actuatorForChannel(ch) else -1} band=$band1 expectedBoost=${expected.boostDb} actualBoost=${actual?.boostDb ?: Float.NaN} verified=$ok fullDescriptorReady=$sessionReady")
        if (ok) {
            status.text = "V87 EQ TARGET VERIFY FAILED • exact 48-byte fresh baseline restored safely • no SaveParams"
            record("META", "V87_UNIFIED_EQ_WRITE_ABORTED_AND_ROLLED_BACK ch=$ch band=$band1 restored=true saveParamsSent=false")
        } else {
            sessionReady = false
            status.text = "EQ RESTORE VERIFY FAILED — STOP CONTROL • DO NOT SAVE • export capture"
            record("META", "V87_UNIFIED_EQ_RESTORE_VERIFY_FATAL ch=$ch band=$band1 expectedBoost=${expected.boostDb} actualBoost=${actual?.boostDb ?: Float.NaN}")
        }
        clearPendingEq(if (ok) "restore-verified" else "restore-verify-failed", recordEvent = false)
    }

    private fun snapshotEqSignatures(): Map<String, String> {
        val out = LinkedHashMap<String, String>(105)
        for (ch in 1..7) {
            for (band1 in 1..15) {
                val b = bands[ch - 1][band1 - 1]
                out["$ch:$band1"] = if (b == null) {
                    "MISSING"
                } else {
                    listOf(
                        b.type.toString(), b.frequency.toString(), b.frequency2.toString(), b.q.toString(),
                        b.boostDb.toString(), b.gain.toString(), b.r.toString(), b.b0.toString(), b.b1.toString(),
                        b.b2.toString(), b.a1.toString(), b.a2.toString()
                    ).joinToString("|")
                }
            }
        }
        return out
    }

    private fun currentGattIdentity(): Int = gatt?.let { System.identityHashCode(it) } ?: 0

    private fun sessionHealthGateValid(): Boolean {
        val activeIdentity = currentGattIdentity()
        return sessionReady && sessionHealthGatePassed &&
            healthGateBoundConnectionEpoch == connectionEpoch &&
            healthGateBoundSessionEpoch == controlSessionEpoch &&
            healthGateBoundGattIdentity != 0 &&
            healthGateBoundGattIdentity == activeIdentity
    }

    private fun resetSessionHealthGate(reason: String, recordEvent: Boolean = true) {
        sessionHealthGatePassed = false
        healthGateBoundConnectionEpoch = -1L
        healthGateBoundSessionEpoch = -1L
        healthGateBoundGattIdentity = 0
        if (::fieldSelfCheckInfo.isInitialized) {
            fieldSelfCheckInfo.text = "V87 SESSION HEALTH GATE • LOCKED • $reason"
        }
        if (recordEvent) {
            record("META", "V87_SESSION_HEALTH_GATE_RESET reason=$reason connectionEpoch=$connectionEpoch sessionEpoch=$controlSessionEpoch activeGattIdentity=${currentGattIdentity()}")
        }
    }

    private fun invalidateForConnectionTransition(reason: String) {
        connectionEpoch += 1L
        sessionReady = false
        waitingAuth = false
        resetSessionHealthGate(reason, recordEvent = true)
        txCipher = null
        rxCipher = null
        ab01 = null
        ab02 = null
        descMode = null
        descExpected = -1
        descBytes.reset()
        scalarValues.clear()
        sensors.clear()
        for (c in bands.indices) for (b in bands[c].indices) bands[c][b] = null
        clearPending("connection-transition", recordEvent = false)
        clearPendingEq("connection-transition", recordEvent = false)
        pendingGattPurpose = null
        synchronized(gattWriteTickets) { gattWriteTickets.clear() }
        cancelDescriptorTimeout()
        cancelGattActionTimeout()
        cancelConnectionWatchdog("connection-transition-$reason")
        pendingConnectRunnable?.let { handler.removeCallbacks(it) }
        pendingConnectRunnable = null
        refreshCount = 0
        if (::startSessionButton.isInitialized) startSessionButton.isEnabled = false
        if (::refreshButton.isInitialized) {
            refreshButton.isEnabled = false
            refreshButton.text = "SYNC LIVE VALUES"
        }
        record("META", "V87_CONNECTION_EPOCH_INVALIDATE reason=$reason connectionEpoch=$connectionEpoch sessionEpoch=$controlSessionEpoch sessionReady=$sessionReady healthGateValid=${sessionHealthGateValid()} staleSessionObjectsCleared=true")
        if (::refreshInfo.isInitialized) refreshInfo.text = "REFRESH STATUS • reconnect + START required"
        renderAll()
    }

    private fun renderAll() {
        renderScalars()
        renderSensors()
        renderEq()
    }

    private fun renderScalars() {
        if (!::scalarHost.isInitialized) return
        scalarHost.removeAllViews()
        if (!sessionReady && scalarValues.isEmpty()) {
            scalarHost.addView(TextView(this).apply { text = "Connect + START CONTROL SESSION เพื่อโหลดค่าจริงจาก DSP"; textSize = 14f })
            updateDirtyUi()
            return
        }
        for (c in VerifiedScalarControls.controls) {
            val current = scalarValues[c.id]
            val block = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, 10, 0, 10)
            }
            block.addView(TextView(this).apply {
                text = "${c.name}  •  ${current?.let { fmt(it) } ?: "MISSING"} ${c.unit}\nID ${c.id} • range ${fmt(c.min)} .. ${fmt(c.max)}"
                textSize = 15f
            })
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val edit = EditText(this).apply {
                inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED
                setText(current?.let { fmt(it) } ?: "")
                hint = c.unit
                isEnabled = current != null && sessionHealthGateValid()
            }
            row.addView(edit, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(Button(this).apply {
                text = "APPLY ✓ VERIFY"
                isEnabled = current != null && sessionHealthGateValid() && !hasPendingControlWrite() && descMode == null && pendingGattPurpose == null && !saveInFlight
                setOnClickListener {
                    val requested = edit.text.toString().toFloatOrNull()
                    if (requested == null) Toast.makeText(this@UnifiedControlActivity, "กรอกตัวเลขก่อน", Toast.LENGTH_SHORT).show()
                    else confirmScalarWrite(c, requested)
                }
            })
            block.addView(row)
            scalarHost.addView(block)
        }
        updateDirtyUi()
    }

    private fun updateDirtyUi() {
        if (::dirtyInfo.isInitialized) {
            dirtyInfo.text = if (unsavedVerifiedChanges) {
                "RAM DIRTY • $verifiedChangeCount verified change(s): scalar=$verifiedScalarChangeCount EQ=$verifiedEqChangeCount • Permanent Save available when protocol idle"
            } else {
                "RAM CLEAN/UNARMED • 0 verified V87 scalar/EQ changes • Session gate ${if (sessionHealthGateValid()) "PASS" else "LOCKED"} • Permanent Save locked"
            }
        }
        if (::permanentSaveButton.isInitialized) {
            val enabled = sessionHealthGateValid() && unsavedVerifiedChanges && verifiedChangeCount > 0 && !saveInFlight && !hasPendingControlWrite() && descMode == null && pendingGattPurpose == null && !waitingAuth
            permanentSaveButton.isEnabled = enabled
            permanentSaveButton.text = if (enabled) "SAVE TO DSP • $verifiedChangeCount VERIFIED CHANGE(S)" else "SAVE TO DSP • LOCKED"
        }
    }

    private fun updateActionButtons() {
        if (::refreshButton.isInitialized) {
            refreshButton.text = if (descMode == DescMode.REFRESH) "SYNCING #$refreshCount • PLEASE WAIT" else "SYNC LIVE VALUES"
            refreshButton.isEnabled = sessionReady && descMode == null && !hasPendingControlWrite() && pendingGattPurpose == null && !saveInFlight && !waitingAuth
        }
        updateDirtyUi()
        refreshPersistenceProofUi()
        if (::scalarHost.isInitialized && Looper.myLooper() == Looper.getMainLooper()) {
            // Re-rendering refreshes APPLY button guards and displayed fresh values.
            if (scalarHost.childCount > 0 || scalarValues.isNotEmpty()) {
                // Avoid recursive render: updateActionButtons is also called from renderScalars.
            }
        }
    }

    private fun confirmScalarWrite(c: VerifiedScalarControl, requested: Float) {
        if (!WriteGate.unifiedVerifiedScalarWritesEnabled || WriteGate.enabled) {
            Toast.makeText(this, "V87 unified scalar write gate blocked", Toast.LENGTH_LONG).show()
            record("META", "V87_UNIFIED_SCALAR_WRITE_BLOCKED reason=write-gate id=${c.id} genericWrites=${WriteGate.enabled}")
            return
        }
        if (!sessionHealthGateValid()) {
            Toast.makeText(this, "V87 SESSION HEALTH GATE locked/stale • run READ-ONLY check for current connection", Toast.LENGTH_LONG).show()
            record("META", "V87_UNIFIED_SCALAR_WRITE_BLOCKED reason=session-health-gate-not-current id=${c.id}")
            return
        }
        val target = VerifiedScalarControls.sanitize(c.id, requested)
        if (target == null || !VerifiedScalarControls.allowed(c.id)) {
            Toast.makeText(this, "ค่านอกช่วง/ID ไม่อยู่ใน verified allow-list", Toast.LENGTH_LONG).show()
            return
        }
        if (!sessionReady || descMode != null || hasPendingControlWrite() || pendingGattPurpose != null || saveInFlight || waitingAuth) {
            Toast.makeText(this, "V87 session busy/not ready", Toast.LENGTH_LONG).show()
            return
        }
        val displayed = scalarValues[c.id]
        AlertDialog.Builder(this)
            .setTitle("V87 VERIFIED UNIFIED SCALAR WRITE")
            .setMessage("${c.name} • ID=${c.id}\nDisplayed=${displayed?.let { fmt(it) } ?: "?"} → requested=${fmt(target)} ${c.unit}\n\nก่อนเขียน V87 จะอ่าน fresh Device Description ทั้งชุดใน session เดิม แล้วใช้ค่าจริงสดเป็น exact rollback baseline. จากนั้น WRITE 0x57 → require GATT success → fresh full-descriptor verify. ถ้า verify ไม่ผ่านจะคืน exact baseline และ fresh-verify การคืนค่า.\n\nไม่มี auto-save; Permanent Save ต้องกดแยกหลัง verify ผ่านเท่านั้น.")
            .setNegativeButton("ยกเลิก", null)
            .setPositiveButton("FRESH PREFLIGHT + APPLY") { _, _ -> beginScalarPreflight(c, target) }
            .show()
    }

    private fun beginScalarPreflight(c: VerifiedScalarControl, target: Float) {
        if (!sessionHealthGateValid() || hasPendingControlWrite() || descMode != null || pendingGattPurpose != null || saveInFlight) return
        pendingId = c.id
        pendingTarget = target
        pendingOriginal = null
        status.text = "V87 FRESH PREFLIGHT • ${c.name} ID${c.id} • reading 7 + 105 + 4 before write"
        record("META", "V87_UNIFIED_SCALAR_PREFLIGHT_START id=${c.id} name=${c.name} requestedTarget=$target sameSession=true genericWrites=false")
        renderAll()
        requestDescriptor(DescMode.WRITE_PREFLIGHT)
    }

    private fun sendScalarTargetAfterPreflight() {
        val id = pendingId ?: return
        val target = pendingTarget ?: return
        val original = pendingOriginal ?: return
        val c = VerifiedScalarControls.byId(id) ?: run { clearPending("id-not-allowed"); return }
        val g = gatt ?: return
        val w = ab01 ?: return
        val tx = txCipher ?: return
        if (!sessionHealthGateValid() || !VerifiedScalarControls.allowed(id) || pendingGattPurpose != null || descMode != null) {
            clearPending("target-send-guard-failed")
            return
        }
        val plain = UfeCodec.encodeFloat32Write(id, target)
        val enc = tx.encryptNext(plain)
        pendingGattPurpose = PendingGattPurpose.SCALAR_TARGET
        record("META", "V87_UNIFIED_SCALAR_WRITE_PLAIN=${ByteCodec.run { plain.toHex() }} id=$id name=${c.name} freshOriginal=$original target=$target saveParams=false genericWrites=false")
        if (!writeNoResponse(g, w, enc, "TX_SCALAR_WRITE_V87_UNIFIED_ID$id", PendingGattPurpose.SCALAR_TARGET)) {
            pendingGattPurpose = null
            sessionReady = false
            record("META", "V87_UNIFIED_TX_STREAM_UNCERTAIN reason=scalar-target-queue-failed id=$id action=STOP_REAUTH")
            status.text = "V87 target write queue failed/unconfirmed • STOP • DO NOT SAVE • START new session"
            persistCriticalCapture("scalar-target-write-queue-failed")
            clearPending("target-write-queue-failed")
            return
        }
        status.text = "V87 WRITE queued • waiting required GATT success before fresh verify"
    }

    private fun restorePending(reason: String) {
        val id = pendingId ?: return
        val original = pendingOriginal ?: run {
            status.text = "V87 rollback impossible • fresh baseline missing • STOP"
            sessionReady = false
            clearPending("rollback-baseline-missing")
            return
        }
        val g = gatt ?: return
        val w = ab01 ?: return
        val tx = txCipher ?: return
        if (!VerifiedScalarControls.allowed(id)) { clearPending("restore-id-not-allowed"); return }
        if (descMode != null) {
            record("META", "V87_UNIFIED_RESTORE_DEFER_BLOCKED reason=descriptor-busy mode=$descMode")
            sessionReady = false
            clearPending("restore-descriptor-busy")
            return
        }
        val plain = UfeCodec.encodeFloat32Write(id, original)
        val enc = tx.encryptNext(plain)
        pendingGattPurpose = PendingGattPurpose.SCALAR_RESTORE
        record("META", "V87_UNIFIED_FAILSAFE_RESTORE_PLAIN=${ByteCodec.run { plain.toHex() }} id=$id exactFreshBaseline=$original reason=$reason saveParams=false")
        if (!writeNoResponse(g, w, enc, "TX_SCALAR_RESTORE_V87_UNIFIED_ID$id", PendingGattPurpose.SCALAR_RESTORE)) {
            pendingGattPurpose = null
            sessionReady = false
            status.text = "RESTORE WRITE QUEUE FAILED — STOP • DO NOT SAVE • diagnostic persisted"
            persistCriticalCapture("scalar-restore-write-queue-failed")
            clearPending("restore-queue-failed")
            return
        }
        status.text = "V87 FAILSAFE RESTORE queued • waiting required GATT success"
    }

    private fun armGattActionTimeout(purpose: PendingGattPurpose) {
        cancelGattActionTimeout()
        gattActionArmedAtElapsedMs = android.os.SystemClock.elapsedRealtime()
        gattActionArmedGattIdentity = gatt?.let { System.identityHashCode(it) } ?: 0
        val depth = synchronized(gattWriteTickets) { gattWriteTickets.size }
        record("META", "V87_UNIFIED_GATT_ACTION_ARM purpose=$purpose timeoutMs=3000 ticketDepth=$depth activeGattIdentity=$gattActionArmedGattIdentity sdk=${android.os.Build.VERSION.SDK_INT}")
        gattActionTimeout = Runnable {
            if (pendingGattPurpose != purpose) return@Runnable
            val ageMs = if (gattActionArmedAtElapsedMs > 0L) android.os.SystemClock.elapsedRealtime() - gattActionArmedAtElapsedMs else -1L
            val timeoutDepth = synchronized(gattWriteTickets) { gattWriteTickets.size }
            pendingGattPurpose = null
            record("META", "V87_UNIFIED_GATT_RESULT_TIMEOUT purpose=$purpose ageMs=$ageMs id=${pendingId ?: -1} eqCh=$pendingEqChannel eqBand=$pendingEqBand ticketDepth=$timeoutDepth activeGattIdentity=${gatt?.let { System.identityHashCode(it) } ?: 0} armedGattIdentity=$gattActionArmedGattIdentity")
            when (purpose) {
                PendingGattPurpose.SCALAR_TARGET -> {
                    sessionReady = false
                    status.text = "SCALAR TARGET GATT UNCONFIRMED — STOP • NO AUTO-RESTORE • reconnect + fresh read"
                    record("META", "V87_UNIFIED_UNCONFIRMED_TARGET_POLICY action=STOP_NO_SECOND_WRITE family=SCALAR reason=gatt-timeout")
                    persistCriticalCapture("scalar-target-gatt-unconfirmed")
                    clearPending("target-gatt-unconfirmed-stop")
                }
                PendingGattPurpose.SCALAR_RESTORE -> {
                    sessionReady = false
                    status.text = "SCALAR RESTORE GATT UNCONFIRMED — STOP • DO NOT SAVE • diagnostic persisted"
                    persistCriticalCapture("scalar-restore-gatt-unconfirmed")
                    clearPending("restore-gatt-unconfirmed")
                }
                PendingGattPurpose.EQ_TARGET -> {
                    sessionReady = false
                    status.text = "EQ TARGET GATT UNCONFIRMED — STOP • NO AUTO-RESTORE • reconnect + fresh read"
                    record("META", "V87_UNIFIED_UNCONFIRMED_TARGET_POLICY action=STOP_NO_SECOND_WRITE family=EQ reason=gatt-timeout")
                    persistCriticalCapture("eq-target-gatt-unconfirmed")
                    clearPendingEq("target-gatt-unconfirmed-stop")
                }
                PendingGattPurpose.EQ_RESTORE -> {
                    sessionReady = false
                    status.text = "EQ RESTORE GATT UNCONFIRMED — STOP • DO NOT SAVE • diagnostic persisted"
                    persistCriticalCapture("eq-restore-gatt-unconfirmed")
                    clearPendingEq("restore-gatt-unconfirmed")
                }
                PendingGattPurpose.SAVE_PARAMS -> {
                    persistCriticalCapture("save-gatt-timeout")
                    markSaveUnconfirmed("save-gatt-timeout")
                }
            }
        }.also { handler.postDelayed(it, 3000L) }
    }

    private fun cancelGattActionTimeout() {
        gattActionTimeout?.let { handler.removeCallbacks(it) }
        gattActionTimeout = null
        gattActionArmedAtElapsedMs = 0L
        gattActionArmedGattIdentity = 0
    }

    private fun clearPending(reason: String, recordEvent: Boolean = true) {
        if (recordEvent) record("META", "V87_UNIFIED_PENDING_CLEAR reason=$reason id=${pendingId ?: -1}")
        pendingId = null
        pendingTarget = null
        pendingOriginal = null
        cancelGattActionTimeout()
        pendingGattPurpose = null
        if (Looper.myLooper() == Looper.getMainLooper()) renderAll() else handler.post { renderAll() }
    }

    private fun confirmEqWrite(channel1: Int, band1: Int, requested: Float) {
        if (!WriteGate.unifiedVerifiedEqWritesEnabled || WriteGate.enabled) {
            Toast.makeText(this, "V87 unified EQ write gate blocked", Toast.LENGTH_LONG).show()
            record("META", "V87_UNIFIED_EQ_WRITE_BLOCKED reason=write-gate ch=$channel1 band=$band1 genericWrites=${WriteGate.enabled}")
            return
        }
        if (!sessionHealthGateValid()) {
            Toast.makeText(this, "V87 SESSION HEALTH GATE locked/stale • run READ-ONLY check for current connection", Toast.LENGTH_LONG).show()
            record("META", "V87_UNIFIED_EQ_WRITE_BLOCKED reason=session-health-gate-not-current ch=$channel1 band=$band1")
            return
        }
        val targetDb = LiveEqPolicy.sanitizeBoost(requested)
        if (targetDb == null) {
            Toast.makeText(this, "ช่วง EQ ที่อนุญาต ${LiveEqPolicy.MIN_BOOST_DB}..${LiveEqPolicy.MAX_BOOST_DB} dB", Toast.LENGTH_LONG).show()
            return
        }
        if (!sessionReady || descMode != null || hasPendingControlWrite() || pendingGattPurpose != null || saveInFlight || waitingAuth) {
            Toast.makeText(this, "V87 session busy/not ready", Toast.LENGTH_LONG).show()
            return
        }
        val displayed = bands.getOrNull(channel1 - 1)?.getOrNull(band1 - 1)
        if (displayed == null || !LiveEqPolicy.isWritable(displayed)) {
            Toast.makeText(this, "Band นี้ไม่ใช่ verified safe PEAKING • READ ONLY", Toast.LENGTH_LONG).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("V87 VERIFIED UNIFIED LIVE EQ WRITE")
            .setMessage("CH$channel1 / ID${LiveEqPolicy.actuatorForChannel(channel1)} / Band$band1\nDisplayed=${fmt(displayed.boostDb)} → requested=${fmt(targetDb)} dB\n\nก่อนเขียน V87 จะอ่าน fresh Device Description ทั้งชุดใน session เดิม แล้วเก็บ 48-byte band record จริงสดเป็น exact rollback baseline. จากนั้นเขียน full 48-byte PEAKING record → require matching GATT success → fresh full-descriptor verify. ถ้า verify ไม่ผ่านจะคืน exact 48-byte baseline และ fresh-verify การคืนค่า.\n\nไม่มี auto-save; Permanent Save ต้องกดแยกหลัง verify ผ่านเท่านั้น.")
            .setNegativeButton("ยกเลิก", null)
            .setPositiveButton("FRESH PREFLIGHT + APPLY") { _, _ -> beginEqPreflight(channel1, band1, targetDb) }
            .show()
    }

    private fun beginEqPreflight(channel1: Int, band1: Int, targetDb: Float) {
        if (!sessionHealthGateValid() || hasPendingControlWrite() || descMode != null || pendingGattPurpose != null || saveInFlight) return
        pendingEqChannel = channel1
        pendingEqBand = band1
        pendingEqRequestedBoost = targetDb
        pendingEqOriginal = null
        pendingEqTarget = null
        status.text = "V87 EQ FRESH PREFLIGHT • CH$channel1 Band$band1 • reading 7 + 105 + 4 before write"
        record("META", "V87_UNIFIED_EQ_PREFLIGHT_START ch=$channel1 actuator=${LiveEqPolicy.actuatorForChannel(channel1)} band=$band1 requestedBoost=$targetDb sameSession=true genericWrites=false fullRecordBytes=48")
        renderAll()
        requestDescriptor(DescMode.EQ_WRITE_PREFLIGHT)
    }

    private fun sendEqTargetAfterPreflight() {
        val ch = pendingEqChannel
        val band1 = pendingEqBand
        val target = pendingEqTarget ?: return
        val original = pendingEqOriginal ?: return
        val g = gatt ?: return
        val w = ab01 ?: return
        val tx = txCipher ?: return
        if (!sessionHealthGateValid() || ch !in 1..7 || band1 !in 1..15 || pendingGattPurpose != null || descMode != null || !LiveEqPolicy.isWritable(original)) {
            clearPendingEq("target-send-guard-failed")
            return
        }
        val plain = LiveEqPolicy.encodeWrite(ch, band1, target)
        val enc = tx.encryptNext(plain)
        pendingGattPurpose = PendingGattPurpose.EQ_TARGET
        record("META", "V87_UNIFIED_EQ_WRITE_PLAIN=${ByteCodec.run { plain.toHex() }} ch=$ch actuator=${LiveEqPolicy.actuatorForChannel(ch)} band=$band1 offset=${LiveEqPolicy.offsetForBand(band1)} payloadBytes=48 freshOriginalBoost=${original.boostDb} targetBoost=${target.boostDb} saveParams=false genericWrites=false")
        if (!writeNoResponse(g, w, enc, "TX_EQ_CH${ch}_B${band1}_V87_UNIFIED", PendingGattPurpose.EQ_TARGET)) {
            pendingGattPurpose = null
            sessionReady = false
            status.text = "V87 EQ target write queue failed/unconfirmed • STOP session • export capture"
            persistCriticalCapture("eq-target-write-queue-failed")
            clearPendingEq("target-write-queue-failed")
            return
        }
        status.text = "V87 EQ WRITE queued • waiting required GATT success before fresh verify"
    }

    private fun restorePendingEq(reason: String) {
        val ch = pendingEqChannel
        val band1 = pendingEqBand
        val original = pendingEqOriginal ?: run {
            status.text = "V87 EQ rollback impossible • fresh 48-byte baseline missing • STOP"
            sessionReady = false
            clearPendingEq("rollback-baseline-missing")
            return
        }
        val g = gatt ?: run { sessionReady = false; clearPendingEq("rollback-no-gatt"); return }
        val w = ab01 ?: run { sessionReady = false; clearPendingEq("rollback-no-ab01"); return }
        val tx = txCipher ?: run { sessionReady = false; clearPendingEq("rollback-no-cipher"); return }
        if (ch !in 1..7 || band1 !in 1..15 || descMode != null) {
            record("META", "V87_UNIFIED_EQ_RESTORE_BLOCKED ch=$ch band=$band1 reason=guard descMode=$descMode")
            sessionReady = false
            clearPendingEq("restore-guard-failed")
            return
        }
        val plain = LiveEqPolicy.encodeRestore(ch, band1, original)
        val enc = tx.encryptNext(plain)
        pendingGattPurpose = PendingGattPurpose.EQ_RESTORE
        record("META", "V87_UNIFIED_EQ_FAILSAFE_RESTORE_PLAIN=${ByteCodec.run { plain.toHex() }} ch=$ch actuator=${LiveEqPolicy.actuatorForChannel(ch)} band=$band1 offset=${LiveEqPolicy.offsetForBand(band1)} payloadBytes=48 exactFreshBaselineBoost=${original.boostDb} reason=$reason saveParams=false")
        if (!writeNoResponse(g, w, enc, "TX_EQ_CH${ch}_B${band1}_RESTORE_V87_UNIFIED", PendingGattPurpose.EQ_RESTORE)) {
            pendingGattPurpose = null
            sessionReady = false
            status.text = "EQ RESTORE WRITE QUEUE FAILED — STOP • DO NOT SAVE • diagnostic persisted"
            persistCriticalCapture("eq-restore-write-queue-failed")
            clearPendingEq("restore-queue-failed")
            return
        }
        status.text = "V87 EQ FAILSAFE RESTORE queued • waiting required GATT success"
    }

    private fun clearPendingEq(reason: String, recordEvent: Boolean = true) {
        if (recordEvent) record("META", "V87_UNIFIED_EQ_PENDING_CLEAR reason=$reason ch=$pendingEqChannel band=$pendingEqBand")
        pendingEqChannel = 0
        pendingEqBand = 0
        pendingEqRequestedBoost = null
        pendingEqOriginal = null
        pendingEqTarget = null
        cancelGattActionTimeout()
        pendingGattPurpose = null
        if (Looper.myLooper() == Looper.getMainLooper()) {
            renderEq(); renderScalars(); updateDirtyUi()
        } else handler.post { renderEq(); renderScalars(); updateDirtyUi() }
    }

    private fun hasPendingControlWrite(): Boolean = pendingId != null || pendingEqChannel != 0

    private fun confirmPermanentSave() {
        if (!sessionHealthGateValid()) {
            Toast.makeText(this, "V87 SESSION HEALTH GATE locked • SaveParams blocked", Toast.LENGTH_LONG).show()
            record("META", "V87_UNIFIED_SAVEPARAMS_BLOCKED reason=session-health-gate-not-current")
            return
        }
        if (!WriteGate.verifiedScalarPersistentSaveEnabled || !WriteGate.liveEqPersistentSaveEnabled || !WriteGate.unifiedVerifiedScalarWritesEnabled || !WriteGate.unifiedVerifiedEqWritesEnabled) {
            Toast.makeText(this, "V87 permanent-save gate disabled", Toast.LENGTH_LONG).show(); return
        }
        if (!sessionReady || gatt == null || ab01 == null || txCipher == null || waitingAuth) {
            Toast.makeText(this, "เชื่อม DSP และ START V87 session ก่อน", Toast.LENGTH_LONG).show(); return
        }
        if (saveInFlight || hasPendingControlWrite() || descMode != null || pendingGattPurpose != null) {
            Toast.makeText(this, "Protocol busy • รอ write/verify/refresh ให้จบก่อน SAVE", Toast.LENGTH_LONG).show(); return
        }
        if (!unsavedVerifiedChanges || verifiedChangeCount <= 0) {
            Toast.makeText(this, "ยังไม่มี verified scalar/EQ change ใน V87 session นี้ • SaveParams locked", Toast.LENGTH_LONG).show(); return
        }
        if (!SaveParamsPolicy.triggerIsExact()) {
            record("META", "V87_UNIFIED_SAVEPARAMS_BLOCKED reason=trigger-not-exact")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("V87 PERMANENT SAVE • FINAL-STATE GUARDED")
            .setMessage("Verified changes in this session = $verifiedChangeCount (scalar=$verifiedScalarChangeCount, EQ=$verifiedEqChangeCount)\n\nจะส่ง SaveParams ID7 exact plaintext 570000000700000000 ซึ่ง V57 พิสูจน์ persistence ผ่าน power-cycle แล้ว. SaveParams บันทึก turning parameters ปัจจุบันทั้งชุด รวม EQ ปัจจุบันด้วย.\n\nV87 SESSION HEALTH GATE ผ่านแล้ว. V87 จะตรวจ fresh final state อัตโนมัติก่อนส่ง SaveParams และตรวจอีกครั้งหลัง settle 5 วินาที. ห้ามปิด DSP ระหว่างขั้นตอนนี้.")
            .setNegativeButton("ยกเลิก", null)
            .setPositiveButton("VERIFY FINAL STATE + SAVE") { _, _ -> beginPermanentSavePrecheck() }
            .show()
    }

    private fun beginPermanentSavePrecheck() {
        if (!sessionHealthGateValid() || saveInFlight || hasPendingControlWrite() || descMode != null || pendingGattPurpose != null || waitingAuth || !unsavedVerifiedChanges || verifiedChangeCount <= 0) {
            record("META", "V87_UNIFIED_SAVEPARAMS_BLOCKED reason=guard-race-before-precheck")
            return
        }
        if (verifiedScalarExpected.isEmpty() && verifiedEqExpected.isEmpty()) {
            record("META", "V87_UNIFIED_SAVEPARAMS_BLOCKED reason=no-verified-state-snapshot")
            return
        }
        saveInFlight = true
        saveGattOk = false
        record("META", "V87_UNIFIED_SAVE_PRECHECK_START verifiedChanges=$verifiedChangeCount scalarExpected=${verifiedScalarExpected.size} eqExpected=${verifiedEqExpected.size} sameSession=true")
        status.text = "V87 FINAL-STATE PRECHECK • reading fresh descriptor before SaveParams"
        updateDirtyUi()
        requestDescriptor(DescMode.SAVE_PRECHECK)
    }

    private fun handleSaveStateCheck(eqCount: Int, preSave: Boolean) {
        if (!saveInFlight) {
            record("META", "V87_UNIFIED_SAVE_STATE_CHECK_IGNORED phase=${if (preSave) "PRE" else "POST"} reason=save-not-in-flight")
            return
        }
        var scalarMismatch = 0
        for ((id, expected) in verifiedScalarExpected) {
            val actual = scalarValues[id]
            if (actual == null || !VerifiedScalarControls.matches(id, actual, expected)) scalarMismatch++
        }
        var eqMismatch = 0
        for ((key, expected) in verifiedEqExpected) {
            val parts = key.split(':')
            val ch = parts.getOrNull(0)?.toIntOrNull() ?: -1
            val band1 = parts.getOrNull(1)?.toIntOrNull() ?: -1
            val actual = if (ch in 1..7 && band1 in 1..15) bands[ch - 1][band1 - 1] else null
            if (actual == null || !LiveEqPolicy.semanticMatches(actual, expected)) eqMismatch++
        }
        val countsOk = sessionReady && scalarValues.size == 7 && eqCount == 105 && sensors.size == 4
        val ok = countsOk && scalarMismatch == 0 && eqMismatch == 0
        val resultMarker = if (preSave) "V87_UNIFIED_SAVE_PRECHECK_RESULT" else "V87_UNIFIED_SAVE_POSTCHECK_RESULT"
        record("META", "$resultMarker verified=$ok countsOk=$countsOk scalarMismatch=$scalarMismatch eqMismatch=$eqMismatch scalarExpected=${verifiedScalarExpected.size} eqExpected=${verifiedEqExpected.size} fullDescriptorReady=$sessionReady")
        if (!ok) {
            markSaveUnconfirmed("${if (preSave) "pre" else "post"}-save-state-mismatch-scalar${scalarMismatch}-eq${eqMismatch}")
            return
        }
        if (preSave) {
            status.text = "V87 FINAL-STATE PRECHECK PASSED • sending exact SaveParams"
            sendPermanentSaveAfterPrecheck()
        } else {
            completePersistentSaveAfterPostcheck()
        }
    }

    private fun sendPermanentSaveAfterPrecheck() {
        val g = gatt ?: return markSaveUnconfirmed("save-gatt-missing-after-precheck")
        val w = ab01 ?: return markSaveUnconfirmed("save-ab01-missing-after-precheck")
        val tx = txCipher ?: return markSaveUnconfirmed("save-tx-missing-after-precheck")
        if (!sessionHealthGateValid() || !saveInFlight || hasPendingControlWrite() || descMode != null || pendingGattPurpose != null || waitingAuth || !unsavedVerifiedChanges || verifiedChangeCount <= 0) {
            markSaveUnconfirmed("guard-race-after-precheck")
            return
        }
        val plain = SaveParamsPolicy.encodeTrigger()
        if (ByteCodec.run { plain.toHex() } != "570000000700000000") {
            markSaveUnconfirmed("unexpected-trigger")
            return
        }
        pendingGattPurpose = PendingGattPurpose.SAVE_PARAMS
        val enc = tx.encryptNext(plain)
        record("META", "V87_UNIFIED_SAVEPARAMS_TRIGGER_PLAIN=${ByteCodec.run { plain.toHex() }} actuator=7 offset=0 length=0 verifiedChanges=$verifiedChangeCount scalarVerified=$verifiedScalarChangeCount eqVerified=$verifiedEqChangeCount manualGuarded=true precheckPassed=true")
        if (!writeNoResponse(g, w, enc, "TX_SAVEPARAMS_ID7_V87_UNIFIED", PendingGattPurpose.SAVE_PARAMS)) {
            pendingGattPurpose = null
            sessionReady = false
            record("META", "V87_UNIFIED_TX_STREAM_UNCERTAIN reason=saveparams-queue-failed action=STOP_NO_RETRY")
            markSaveUnconfirmed("saveparams-queue-failed")
            return
        }
        status.text = "V87 SaveParams queued • waiting required GATT success"
        updateDirtyUi()
    }

    private fun beginSaveSettle() {
        cancelSaveSettle()
        saveSettleRunnable = Runnable {
            if (!saveInFlight || !saveGattOk) return@Runnable
            record("META", "V87_UNIFIED_SAVE_POSTCHECK_START settleMs=$saveCommitSettleMs sameSession=true")
            status.text = "V87 SaveParams settled • reading fresh POST-SAVE descriptor before COMPLETE"
            requestDescriptor(DescMode.SAVE_POSTCHECK)
        }.also { handler.postDelayed(it, saveCommitSettleMs) }
    }

    private fun completePersistentSaveAfterPostcheck() {
        val savedCount = verifiedChangeCount
        val savedScalar = verifiedScalarChangeCount
        val savedEq = verifiedEqChangeCount
        storePostSavePersistenceSnapshot()
        unsavedVerifiedChanges = false
        verifiedChangeCount = 0
        verifiedScalarChangeCount = 0
        verifiedEqChangeCount = 0
        verifiedScalarExpected.clear()
        verifiedEqExpected.clear()
        saveInFlight = false
        saveGattOk = false
        record("META", "V87_UNIFIED_PERSISTENT_SAVE_COMPLETE savedVerifiedChanges=$savedCount savedScalar=$savedScalar savedEq=$savedEq trigger=570000000700000000 gattStatus=0 settleMs=$saveCommitSettleMs precheck=true postcheck=true persistenceSnapshot=7scalars+105eq persistenceBasis=V57_TWO_POWER_CYCLE_PROOF")
        status.text = "V87 PERMANENT SAVE COMPLETE • PRE/POST verified • persistence snapshot ready"
        renderAll()
        refreshPersistenceProofUi()
    }

    private fun proofPrefs() = getSharedPreferences(proofPrefsName, MODE_PRIVATE)

    private fun eqBandToJson(b: EqBand48): JSONObject = JSONObject().apply {
        put("type", b.type)
        put("frequency", b.frequency.toDouble())
        put("frequency2", b.frequency2.toDouble())
        put("q", b.q.toDouble())
        put("boostDb", b.boostDb.toDouble())
        put("gain", b.gain.toDouble())
        put("r", b.r.toDouble())
        put("b0", b.b0.toDouble())
        put("b1", b.b1.toDouble())
        put("b2", b.b2.toDouble())
        put("a1", b.a1.toDouble())
        put("a2", b.a2.toDouble())
    }

    private fun eqBandFromJson(o: JSONObject): EqBand48 = EqBand48(
        type = o.getInt("type"),
        frequency = o.getDouble("frequency").toFloat(),
        frequency2 = o.getDouble("frequency2").toFloat(),
        q = o.getDouble("q").toFloat(),
        boostDb = o.getDouble("boostDb").toFloat(),
        gain = o.getDouble("gain").toFloat(),
        r = o.getDouble("r").toFloat(),
        b0 = o.getDouble("b0").toFloat(),
        b1 = o.getDouble("b1").toFloat(),
        b2 = o.getDouble("b2").toFloat(),
        a1 = o.getDouble("a1").toFloat(),
        a2 = o.getDouble("a2").toFloat(),
    )

    private fun storePostSavePersistenceSnapshot() {
        if (!sessionReady || scalarValues.size != 7 || bands.sumOf { row -> row.count { it != null } } != 105) {
            record("META", "V87_UNIFIED_PERSISTENCE_SNAPSHOT_NOT_STORED reason=incomplete-post-save-state scalars=${scalarValues.size} eq=${bands.sumOf { row -> row.count { it != null } }}")
            return
        }
        val root = JSONObject()
        root.put("version", 70)
        root.put("savedAtMs", System.currentTimeMillis())
        val scalarObj = JSONObject()
        for ((id, v) in scalarValues) scalarObj.put(id.toString(), v.toDouble())
        val eqObj = JSONObject()
        var eqCount = 0
        for (ch in 1..7) {
            for (band1 in 1..15) {
                val b = bands[ch - 1][band1 - 1] ?: continue
                eqObj.put("$ch:$band1", eqBandToJson(b))
                eqCount++
            }
        }
        root.put("scalars", scalarObj)
        root.put("eq", eqObj)
        proofPrefs().edit()
            .putString(proofSnapshotKey, root.toString())
            .putBoolean(proofArmedKey, false)
            .putBoolean(proofDisconnectSeenKey, false)
            .putLong(proofArmedAtKey, 0L)
            .putString(proofLastResultKey, "SNAPSHOT_READY")
            .apply()
        record("META", "V87_UNIFIED_PERSISTENCE_SNAPSHOT_STORED scalarSnapshot=${scalarValues.size} eqSnapshot=$eqCount source=SAVE_POSTCHECK sensorSnapshot=excluded_dynamic")
    }

    private fun loadPersistenceSnapshot(): PersistenceSnapshot? {
        val raw = proofPrefs().getString(proofSnapshotKey, null) ?: return null
        return try {
            val root = JSONObject(raw)
            val scalars = LinkedHashMap<Int, Float>()
            val so = root.getJSONObject("scalars")
            val sk = so.keys()
            while (sk.hasNext()) {
                val k = sk.next()
                scalars[k.toInt()] = so.getDouble(k).toFloat()
            }
            val eq = LinkedHashMap<String, EqBand48>()
            val eo = root.getJSONObject("eq")
            val ek = eo.keys()
            while (ek.hasNext()) {
                val k = ek.next()
                eq[k] = eqBandFromJson(eo.getJSONObject(k))
            }
            PersistenceSnapshot(root.getLong("savedAtMs"), scalars, eq)
        } catch (_: Exception) {
            null
        }
    }

    private fun refreshPersistenceProofUi() {
        if (!::persistenceProofInfo.isInitialized || !::armPowerCycleProofButton.isInitialized) return
        val prefs = proofPrefs()
        val snapshot = loadPersistenceSnapshot()
        val armed = prefs.getBoolean(proofArmedKey, false)
        val disconnectSeen = prefs.getBoolean(proofDisconnectSeenKey, false)
        val lastResult = prefs.getString(proofLastResultKey, "NONE") ?: "NONE"
        persistenceProofInfo.text = when {
            snapshot == null -> "POWER-CYCLE PERSISTENCE PROOF • no V87 POST-SAVE snapshot yet"
            armed && !disconnectSeen -> "POWER-CYCLE PERSISTENCE PROOF • ARMED • waiting for DSP power-off/disconnect"
            armed && disconnectSeen -> "POWER-CYCLE PERSISTENCE PROOF • DISCONNECT OBSERVED • power DSP ON, reconnect + START V87 to compare 7 + 105"
            lastResult.startsWith("PASS") -> "POWER-CYCLE PERSISTENCE PROOF • PASS • 7 scalars + 105 EQ matched saved POST-SAVE snapshot"
            lastResult.startsWith("FAIL") -> "POWER-CYCLE PERSISTENCE PROOF • FAIL/BLOCKED • export capture; do not save blindly"
            else -> "POWER-CYCLE PERSISTENCE PROOF • snapshot ready: scalars=${snapshot.scalarExpected.size} EQ=${snapshot.eqExpected.size} • ARM when protocol idle and RAM clean"
        }
        val busy = saveInFlight || hasPendingControlWrite() || descMode != null || pendingGattPurpose != null || waitingAuth
        armPowerCycleProofButton.isEnabled = snapshot != null && !armed && sessionReady && !unsavedVerifiedChanges && !busy
        armPowerCycleProofButton.text = if (armPowerCycleProofButton.isEnabled) {
            "ARM POWER-CYCLE / RECONNECT PROOF • 7 + 105 SNAPSHOT"
        } else if (armed) {
            "POWER-CYCLE / RECONNECT PROOF • ARMED"
        } else {
            "ARM POWER-CYCLE / RECONNECT PROOF • LOCKED"
        }
    }

    private fun runFieldSelfCheck() {
        val exactScalarIds = VerifiedScalarControls.controls.map { it.id } == listOf(2, 3, 8, 9, 10, 13, 11)
        val scalarCountOk = scalarValues.size == 7
        val eqCount = bands.sumOf { row -> row.count { it != null } }
        val eqCountOk = eqCount == 105
        val sensorCountOk = sensors.size == 4
        val sessionObjectsOk = gatt != null && ab01 != null && ab02 != null && txCipher != null && rxCipher != null
        val writerLocksOk = !WriteGate.enabled && WriteGate.unifiedVerifiedScalarWritesEnabled && WriteGate.unifiedVerifiedEqWritesEnabled
        val protocolIdle = !waitingAuth && descMode == null && pendingGattPurpose == null && !hasPendingControlWrite() && !saveInFlight && synchronized(gattWriteTickets) { gattWriteTickets.isEmpty() }
        val ramClean = !unsavedVerifiedChanges && verifiedChangeCount == 0
        val activeGattIdentity = gatt?.let { System.identityHashCode(it) } ?: 0
        val gattIdentityOk = activeGattIdentity != 0
        val pass = sessionReady && scalarCountOk && eqCountOk && sensorCountOk && sessionObjectsOk && exactScalarIds && writerLocksOk && protocolIdle && ramClean && gattIdentityOk
        if (pass) {
            sessionHealthGatePassed = true
            healthGateBoundConnectionEpoch = connectionEpoch
            healthGateBoundSessionEpoch = controlSessionEpoch
            healthGateBoundGattIdentity = activeGattIdentity
        } else {
            resetSessionHealthGate("health-check-blocked", recordEvent = false)
        }
        val snapshot = loadPersistenceSnapshot()
        val summary = if (pass) {
            "PASS • 7+105+4 • session/auth ready • protocol idle • RAM clean • writer locks intact • APPLY/SAVE unlocked"
        } else {
            "BLOCKED • APPLY/SAVE remain locked • inspect/export diagnostic"
        }
        fieldSelfCheckInfo.text = "V87 SESSION HEALTH GATE • $summary"
        status.text = if (pass) "V87 SESSION HEALTH GATE PASS • production controls unlocked • READ ONLY check" else "V87 SESSION HEALTH GATE BLOCKED • no write sent • controls remain locked"
        record("META", "V87_SESSION_HEALTH_GATE_RESULT pass=$pass writesSent=0 healthGatePassed=$sessionHealthGatePassed healthGateValid=${sessionHealthGateValid()} sessionReady=$sessionReady scalarCount=${scalarValues.size} eqBands=$eqCount sensors=${sensors.size} sessionObjectsOk=$sessionObjectsOk exactScalarIds=$exactScalarIds genericWrites=${WriteGate.enabled} scalarGate=${WriteGate.unifiedVerifiedScalarWritesEnabled} eqGate=${WriteGate.unifiedVerifiedEqWritesEnabled} protocolIdle=$protocolIdle ramClean=$ramClean verifiedChangeCount=$verifiedChangeCount connectionEpoch=$connectionEpoch sessionEpoch=$controlSessionEpoch boundConnectionEpoch=$healthGateBoundConnectionEpoch boundSessionEpoch=$healthGateBoundSessionEpoch activeGattIdentity=$activeGattIdentity boundGattIdentity=$healthGateBoundGattIdentity persistenceSnapshot=${snapshot != null} recoveredCritical=${recoveredCriticalCaptureText != null}")
        renderAll()
        Toast.makeText(this, "V87 SESSION HEALTH GATE ${if (pass) "PASS • CONTROLS UNLOCKED" else "BLOCKED"} • READ ONLY", Toast.LENGTH_LONG).show()
    }

    private fun confirmArmPowerCycleProof() {
        val snapshot = loadPersistenceSnapshot()
        if (snapshot == null || !sessionReady || unsavedVerifiedChanges || saveInFlight || hasPendingControlWrite() || descMode != null || pendingGattPurpose != null || waitingAuth) {
            Toast.makeText(this, "V87 proof ARM blocked • need successful save snapshot + RAM clean + idle session", Toast.LENGTH_LONG).show()
            record("META", "V87_UNIFIED_POWER_CYCLE_PROOF_ARM_BLOCKED snapshot=${snapshot != null} sessionReady=$sessionReady ramDirty=$unsavedVerifiedChanges")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("V87 ARM POWER-CYCLE / RECONNECT PERSISTENCE PROOF")
            .setMessage("Snapshot = ${snapshot.scalarExpected.size} verified scalars + ${snapshot.eqExpected.size} EQ bands from the last successful POST-SAVE descriptor.\n\nAfter ARM: power the DSP OFF for about 10 seconds, then ON. V87 must observe the BLE disconnect. Reconnect and START V87 again; the first fresh descriptor will be compared read-only against this snapshot. Sensors are excluded because they are dynamic. No write is sent by this proof.")
            .setNegativeButton("ยกเลิก", null)
            .setPositiveButton("ARM PROOF") { _, _ ->
                proofPrefs().edit()
                    .putBoolean(proofArmedKey, true)
                    .putBoolean(proofDisconnectSeenKey, false)
                    .putLong(proofArmedAtKey, System.currentTimeMillis())
                    .putString(proofLastResultKey, "ARMED")
                    .apply()
                record("META", "V87_UNIFIED_POWER_CYCLE_PROOF_ARMED userAction=true scalarExpected=${snapshot.scalarExpected.size} eqExpected=${snapshot.eqExpected.size} disconnectRequired=true writesSent=0")
                status.text = "V87 POWER-CYCLE PROOF ARMED • now power DSP OFF ~10s, then ON • reconnect + START"
                refreshPersistenceProofUi()
            }
            .show()
    }

    private fun noteProofDisconnectObserved() {
        val prefs = proofPrefs()
        if (!prefs.getBoolean(proofArmedKey, false)) return
        prefs.edit().putBoolean(proofDisconnectSeenKey, true).putString(proofLastResultKey, "DISCONNECT_OBSERVED").apply()
        record("META", "V87_UNIFIED_POWER_CYCLE_PROOF_DISCONNECT_OBSERVED armed=true disconnectObserved=true writesSent=0")
        handler.post { refreshPersistenceProofUi() }
    }

    private fun maybeVerifyArmedPersistenceProof(eqCount: Int) {
        val prefs = proofPrefs()
        if (!prefs.getBoolean(proofArmedKey, false)) {
            refreshPersistenceProofUi()
            return
        }
        val disconnectSeen = prefs.getBoolean(proofDisconnectSeenKey, false)
        val snapshot = loadPersistenceSnapshot()
        if (!disconnectSeen) {
            record("META", "V87_UNIFIED_POWER_CYCLE_PROOF_PENDING reason=disconnect-not-observed writesSent=0")
            refreshPersistenceProofUi()
            return
        }
        if (snapshot == null) {
            prefs.edit().putBoolean(proofArmedKey, false).putString(proofLastResultKey, "FAIL_NO_SNAPSHOT").apply()
            record("META", "V87_UNIFIED_POWER_CYCLE_PERSISTENCE_PROOF_RESULT verified=false reason=snapshot-missing disconnectObserved=true writesSent=0")
            sessionReady = false
            status.text = "V87 PERSISTENCE PROOF FAILED • snapshot missing • STOP"
            refreshPersistenceProofUi()
            return
        }
        var scalarMismatch = 0
        for ((id, expected) in snapshot.scalarExpected) {
            val actual = scalarValues[id]
            if (actual == null || !VerifiedScalarControls.matches(id, actual, expected)) scalarMismatch++
        }
        var eqMismatch = 0
        for ((key, expected) in snapshot.eqExpected) {
            val parts = key.split(':')
            val ch = parts.getOrNull(0)?.toIntOrNull() ?: -1
            val band1 = parts.getOrNull(1)?.toIntOrNull() ?: -1
            val actual = if (ch in 1..7 && band1 in 1..15) bands[ch - 1][band1 - 1] else null
            if (actual == null || !LiveEqPolicy.semanticMatches(actual, expected)) eqMismatch++
        }
        val countsOk = sessionReady && scalarValues.size == 7 && eqCount == 105 && snapshot.scalarExpected.size == 7 && snapshot.eqExpected.size == 105
        val ok = countsOk && scalarMismatch == 0 && eqMismatch == 0
        val ageMs = System.currentTimeMillis() - snapshot.savedAtMs
        record("META", "V87_UNIFIED_POWER_CYCLE_PERSISTENCE_PROOF_RESULT verified=$ok countsOk=$countsOk scalarMismatch=$scalarMismatch eqMismatch=$eqMismatch scalarExpected=${snapshot.scalarExpected.size} eqExpected=${snapshot.eqExpected.size} disconnectObserved=true userArmed=true snapshotAgeMs=$ageMs freshAuthSession=true writesSent=0 sensorsCompared=false")
        prefs.edit()
            .putBoolean(proofArmedKey, false)
            .putBoolean(proofDisconnectSeenKey, false)
            .putString(proofLastResultKey, if (ok) "PASS_${System.currentTimeMillis()}" else "FAIL_${System.currentTimeMillis()}")
            .apply()
        if (ok) {
            status.text = "V87 POWER-CYCLE / RECONNECT PERSISTENCE PROOF PASS • 7 scalars + 105 EQ match saved state"
            Toast.makeText(this, "V87 PERSISTENCE PROOF PASS • 7 + 105 matched", Toast.LENGTH_LONG).show()
        } else {
            sessionReady = false
            status.text = "V87 PERSISTENCE PROOF FAILED/BLOCKED • scalarMismatch=$scalarMismatch EQMismatch=$eqMismatch • DO NOT SAVE"
            Toast.makeText(this, "PERSISTENCE PROOF FAILED • STOP and export capture", Toast.LENGTH_LONG).show()
        }
        refreshPersistenceProofUi()
    }

    private fun markSaveUnconfirmed(reason: String) {
        persistCriticalCapture("save-unconfirmed-$reason")
        cancelSaveTimers()
        pendingGattPurpose = null
        saveInFlight = false
        saveGattOk = false
        record("META", "V87_UNIFIED_PERSISTENT_SAVE_UNCONFIRMED reason=$reason changesRemainUnsaved=true scalarExpected=${verifiedScalarExpected.size} eqExpected=${verifiedEqExpected.size}")
        status.text = "V87 SAVE UNCONFIRMED/BLOCKED • DO NOT RETRY BLINDLY • export capture • RAM DIRTY retained"
        updateDirtyUi()
    }

    private fun cancelSaveSettle() {
        saveSettleRunnable?.let { handler.removeCallbacks(it) }
        saveSettleRunnable = null
    }

    private fun cancelSaveTimers() {
        cancelSaveSettle()
    }

    private fun renderSensors() {
        if (!::sensorHost.isInitialized) return
        sensorHost.removeAllViews()
        if (sensors.isEmpty()) {
            sensorHost.addView(TextView(this).apply { text = "ยังไม่ได้โหลด sensor จาก Device Description"; textSize = 14f })
            return
        }
        sensors.forEach { s ->
            sensorHost.addView(TextView(this).apply {
                text = "${s.name} • ID ${s.id} • ${s.valueText} • READ ONLY"
                textSize = 15f
                setPadding(0, 4, 0, 4)
            })
        }
    }

    private fun renderEq() {
        if (!::eqHost.isInitialized) return
        eqHost.removeAllViews()
        val ch = selectedChannel
        eqHost.addView(TextView(this).apply {
            text = "CH$ch • Actuator ID ${LiveEqPolicy.actuatorForChannel(ch)} • safe PEAKING only"
            textSize = 17f
            setPadding(0, 8, 0, 6)
        })
        if (!sessionReady && bands[ch - 1].all { it == null }) {
            eqHost.addView(TextView(this).apply { text = "Connect + START CONTROL SESSION เพื่อโหลด EQ จริงจาก DSP"; textSize = 14f })
            return
        }
        for (band1 in 1..15) {
            val b = bands[ch - 1][band1 - 1]
            val block = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, 7, 0, 9)
            }
            if (b == null) {
                block.addView(TextView(this).apply { text = "Band $band1 • MISSING • READ ONLY"; textSize = 13f })
                eqHost.addView(block)
                continue
            }
            val writable = LiveEqPolicy.isWritable(b)
            block.addView(TextView(this).apply {
                text = if (writable) {
                    "Band $band1  •  ${fmt(b.frequency)} Hz  •  Q ${fmt(b.q)}  •  ${fmt(b.boostDb)} dB  •  VERIFIED"
                } else {
                    "Band $band1  •  ${fmt(b.frequency)} Hz  •  type ${b.type}  •  READ ONLY"
                }
                textSize = 13f
            })
            if (writable) {
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                val edit = EditText(this).apply {
                    inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED
                    setText(String.format(Locale.US, "%.1f", b.boostDb))
                    hint = "-12.0 .. +12.0 dB"
                    isEnabled = sessionHealthGateValid() && !hasPendingControlWrite() && descMode == null && pendingGattPurpose == null && !saveInFlight
                }
                row.addView(edit, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                row.addView(Button(this).apply {
                    text = "APPLY ✓ VERIFY"
                    isEnabled = sessionHealthGateValid() && !hasPendingControlWrite() && descMode == null && pendingGattPurpose == null && !saveInFlight
                    setOnClickListener {
                        val requested = edit.text.toString().toFloatOrNull()
                        if (requested == null) Toast.makeText(this@UnifiedControlActivity, "กรอกค่า dB ก่อน", Toast.LENGTH_SHORT).show()
                        else confirmEqWrite(ch, band1, requested)
                    }
                })
                block.addView(row)
            } else {
                block.addView(TextView(this).apply {
                    text = "LOCKED • non-standard/unsafe EQ shape • V87 ไม่ส่ง write"
                    textSize = 12f
                })
            }
            eqHost.addView(block)
        }
    }

    private fun extractBand(obj: JSONObject, actuatorId: Int, bandIndex1: Int): EqBand48? {
        val arr = obj.optJSONArray("actuators") ?: return null
        for (i in 0 until arr.length()) {
            val a = arr.optJSONObject(i) ?: continue
            if (a.optInt("ID", -1) != actuatorId || a.optInt("type", -1) != 4084) continue
            val bandArr = a.optJSONArray("UFE_TYPE_BIQUAD_CASCADE15_F") ?: return null
            val b = bandArr.optJSONObject(bandIndex1 - 1) ?: return null
            fun f(key: String): Float = b.optDouble(key, Double.NaN).toFloat()
            val out = EqBand48(
                type = b.optInt("typ", -1),
                frequency = f("F"), frequency2 = f("F2"), q = f("Q"), boostDb = f("B"),
                gain = f("G"), r = f("R"), b0 = f("B0"), b1 = f("B1"), b2 = f("B2"),
                a1 = f("A1"), a2 = f("A2")
            )
            if (listOf(out.frequency, out.frequency2, out.q, out.boostDb, out.gain, out.r, out.b0, out.b1, out.b2, out.a1, out.a2).any { !it.isFinite() }) return null
            return out
        }
        return null
    }

    private fun isCurrentGatt(callbackGatt: BluetoothGatt, callback: String): Boolean {
        val active = gatt
        val current = active != null && callbackGatt === active
        if (!current) {
            record("META", "V87_UNIFIED_STALE_GATT_CALLBACK_IGNORED callback=$callback activeGattPresent=${active != null} callbackIsActive=false")
        }
        return current
    }

    private fun cancelConnectionWatchdog(reason: String) {
        val active = connectionWatchdog ?: return
        handler.removeCallbacks(active)
        connectionWatchdog = null
        val oldEpoch = connectionWatchdogEpoch
        connectionWatchdogEpoch = -1L
        record("META", "V87_CONNECTION_WATCHDOG_CANCEL reason=$reason armedEpoch=$oldEpoch currentEpoch=$connectionEpoch")
    }

    private fun armConnectionWatchdog(epoch: Long, transitionReason: String) {
        cancelConnectionWatchdog("re-arm")
        connectionWatchdogEpoch = epoch
        val task = Runnable {
            connectionWatchdog = null
            connectionWatchdogEpoch = -1L
            if (connectionEpoch != epoch) {
                record("META", "V87_CONNECTION_WATCHDOG_STALE requestedEpoch=$epoch currentEpoch=$connectionEpoch action=IGNORE")
                return@Runnable
            }
            val timedOutGatt = gatt
            val timedOutIdentity = timedOutGatt?.let { System.identityHashCode(it) } ?: 0
            record("META", "V87_CONNECTION_WATCHDOG_TIMEOUT timeoutMs=$connectionReadyTimeoutMs transitionReason=$transitionReason connectionEpoch=$connectionEpoch sessionEpoch=$controlSessionEpoch activeGattIdentity=$timedOutIdentity action=FAIL_CLOSED writesSent=0")
            gatt = null
            invalidateForConnectionTransition("connection-watchdog-timeout")
            try { timedOutGatt?.disconnect() } catch (_: Exception) {}
            try { timedOutGatt?.close() } catch (_: Exception) {}
            status.text = "CONNECTION TIMEOUT • fail-closed • RECONNECT LAST DSP or SCAN"
            if (::reconnectButton.isInitialized) reconnectButton.isEnabled = resolveCachedAddressExists()
            if (::startSessionButton.isInitialized) startSessionButton.isEnabled = false
            if (::refreshButton.isInitialized) refreshButton.isEnabled = false
            record("META", "V87_CONNECTION_WATCHDOG_RECOVERY_COMPLETE oldGattIdentity=$timedOutIdentity newConnectionEpoch=$connectionEpoch sessionReady=$sessionReady healthGateValid=${sessionHealthGateValid()} writesSent=0")
        }
        connectionWatchdog = task
        handler.postDelayed(task, connectionReadyTimeoutMs)
        record("META", "V87_CONNECTION_WATCHDOG_ARM timeoutMs=$connectionReadyTimeoutMs transitionReason=$transitionReason connectionEpoch=$epoch writesSent=0")
    }

    private fun resolveCachedAddressExists(): Boolean =
        !getSharedPreferences(lastDspPrefsName, MODE_PRIVATE).getString(lastDspAddressKey, null).isNullOrBlank()

    private fun failConnectionReady(reason: String, callbackGatt: BluetoothGatt?) {
        val active = gatt
        if (callbackGatt != null && active != null && callbackGatt !== active) {
            record("META", "V87_CONNECTION_READY_FAILURE_STALE reason=$reason action=IGNORE")
            return
        }
        cancelConnectionWatchdog("fail-$reason")
        val failedGatt = active
        val failedIdentity = failedGatt?.let { System.identityHashCode(it) } ?: 0
        gatt = null
        invalidateForConnectionTransition("connection-ready-failed-$reason")
        try { failedGatt?.disconnect() } catch (_: Exception) {}
        try { failedGatt?.close() } catch (_: Exception) {}
        status.text = "CONNECTION FAILED • $reason • fail-closed • retry"
        if (::reconnectButton.isInitialized) reconnectButton.isEnabled = resolveCachedAddressExists()
        if (::startSessionButton.isInitialized) startSessionButton.isEnabled = false
        if (::refreshButton.isInitialized) refreshButton.isEnabled = false
        record("META", "V87_CONNECTION_READY_FAIL_CLOSED reason=$reason oldGattIdentity=$failedIdentity connectionEpoch=$connectionEpoch sessionReady=$sessionReady healthGateValid=${sessionHealthGateValid()} writesSent=0")
    }

    private fun restoreLastDspReconnectUi() {
        if (!::reconnectButton.isInitialized) return
        val prefs = getSharedPreferences(lastDspPrefsName, MODE_PRIVATE)
        val address = prefs.getString(lastDspAddressKey, null)
        val name = prefs.getString(lastDspNameKey, null)
        val available = !address.isNullOrBlank()
        reconnectButton.isEnabled = available
        reconnectButton.text = if (available) "RECONNECT LAST DSP • NO SCAN" else "NO SAVED DSP • SCAN ONCE"
        if (available) {
            record("META", "V87_LAST_DSP_CACHE_AVAILABLE address=$address name=${name ?: "DSP"} writesSent=0")
        } else {
            record("META", "V87_LAST_DSP_CACHE_MISSING action=SCAN_ONCE writesSent=0")
        }
    }

    private fun persistLastDsp(device: BluetoothDevice, name: String) {
        getSharedPreferences(lastDspPrefsName, MODE_PRIVATE).edit()
            .putString(lastDspAddressKey, device.address)
            .putString(lastDspNameKey, name)
            .apply()
        if (::reconnectButton.isInitialized) {
            reconnectButton.text = "RECONNECT LAST DSP • NO SCAN"
            reconnectButton.isEnabled = true
        }
        record("META", "V87_LAST_DSP_CACHE_UPDATED address=${device.address} name=$name writesSent=0")
    }

    private fun resolveLastDsp(): Pair<BluetoothDevice, String>? {
        val inMemory = selectedDevice
        val inMemoryName = selectedDeviceName
        if (inMemory != null && !inMemoryName.isNullOrBlank()) return inMemory to inMemoryName
        if (!hasBlePermission()) { requestBlePermissions(); return null }
        val prefs = getSharedPreferences(lastDspPrefsName, MODE_PRIVATE)
        val address = prefs.getString(lastDspAddressKey, null) ?: return null
        val name = prefs.getString(lastDspNameKey, null)?.takeIf { it.isNotBlank() } ?: "DSP"
        val adapter = getSystemService(BluetoothManager::class.java)?.adapter ?: return null
        return try {
            adapter.getRemoteDevice(address) to name
        } catch (e: IllegalArgumentException) {
            prefs.edit().remove(lastDspAddressKey).remove(lastDspNameKey).apply()
            reconnectButton.isEnabled = false
            reconnectButton.text = "NO SAVED DSP • SCAN ONCE"
            record("META", "V87_LAST_DSP_CACHE_INVALID address=$address cleared=true writesSent=0")
            null
        }
    }

    private fun reconnectCurrentDevice() {
        if (saveInFlight || hasPendingControlWrite() || descMode != null || pendingGattPurpose != null) {
            Toast.makeText(this, "V87 protocol busy • ห้ามเปลี่ยน connection", Toast.LENGTH_LONG).show(); return
        }
        val resolved = resolveLastDsp()
        if (resolved == null) {
            Toast.makeText(this, "ยังไม่มี DSP ล่าสุด • SCAN DSP ก่อนหนึ่งครั้ง", Toast.LENGTH_LONG).show()
            record("META", "V87_RECONNECT_LAST_BLOCKED reason=no-valid-last-device")
            return
        }
        val (device, name) = resolved
        val source = if (selectedDevice != null) "current-memory" else "persisted-address"
        selectedDevice = device
        selectedDeviceName = name
        record("META", "V87_RECONNECT_LAST_REQUEST source=$source name=$name address=${device.address} connectionEpoch=$connectionEpoch sessionEpoch=$controlSessionEpoch healthGateValidBefore=${sessionHealthGateValid()}")
        connect(device, name, transitionReason = "reconnect-last", directReconnect = true)
    }

    private fun recordUpgradeContinuityProbe() {
        val prefs = getSharedPreferences(lastDspPrefsName, MODE_PRIVATE)
        val address = prefs.getString(lastDspAddressKey, null)?.trim().orEmpty()
        val name = prefs.getString(lastDspNameKey, null)?.trim().orEmpty()
        val cachePresent = address.isNotEmpty()
        val pkg = try { packageManager.getPackageInfo(packageName, 0) } catch (_: Exception) { null }
        val firstInstallTime = pkg?.firstInstallTime ?: 0L
        val lastUpdateTime = pkg?.lastUpdateTime ?: 0L
        val updatedInPlace = firstInstallTime > 0L && lastUpdateTime > firstInstallTime
        record(
            "META",
            "V87_STABLE_UPGRADE_CONTINUITY_PROBE updatedInPlace=$updatedInPlace cachePresent=$cachePresent firstInstallTime=$firstInstallTime lastUpdateTime=$lastUpdateTime address=${if (cachePresent) address else "NONE"} name=${if (name.isNotEmpty()) name else "NONE"} stableSigning=projectStableDebugKey priorContinuity=V83_PASSED writesSent=0"
        )
    }

    private fun startScan() {
        if (saveInFlight || hasPendingControlWrite() || descMode != null || pendingGattPurpose != null) {
            Toast.makeText(this, "V87 protocol busy • ห้ามเปลี่ยน connection", Toast.LENGTH_LONG).show(); return
        }
        if (!hasBlePermission()) { requestBlePermissions(); return }
        val adapter = getSystemService(BluetoothManager::class.java)?.adapter ?: return
        if (!adapter.isEnabled) { Toast.makeText(this, "เปิด Bluetooth ก่อน", Toast.LENGTH_SHORT).show(); return }
        found.clear(); deviceList.removeAllViews()
        scanner = adapter.bluetoothLeScanner
        status.text = "SCANNING"
        try { scanner?.startScan(scanCallback) } catch (_: SecurityException) { return }
        handler.postDelayed({ try { scanner?.stopScan(scanCallback) } catch (_: Exception) {} }, 10000L)
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val d = result.device
            val name = result.scanRecord?.deviceName ?: try { d.name } catch (_: SecurityException) { null }
            if (name?.contains("GOLOPINE", true) != true && name?.contains("DSP", true) != true) return
            if (found.putIfAbsent(d.address, d) != null) return
            runOnUiThread {
                deviceList.addView(Button(this@UnifiedControlActivity).apply {
                    text = "${name ?: "DSP"} • ${d.address}\nแตะเพื่อเชื่อมต่อ"
                    setOnClickListener { connect(d, name ?: "DSP", transitionReason = "scan-select", directReconnect = false) }
                })
            }
        }
    }

    private fun connect(device: BluetoothDevice, name: String, transitionReason: String, directReconnect: Boolean) {
        if (saveInFlight || hasPendingControlWrite() || descMode != null || pendingGattPurpose != null) {
            Toast.makeText(this, "V87 protocol busy • ห้ามเปลี่ยน connection", Toast.LENGTH_LONG).show(); return
        }
        if (!hasBlePermission()) return
        try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
        val oldGatt = gatt
        selectedDevice = device
        selectedDeviceName = name
        persistLastDsp(device, name)
        if (::reconnectButton.isInitialized) reconnectButton.isEnabled = true
        invalidateForConnectionTransition(transitionReason)
        gatt = null
        try { oldGatt?.disconnect() } catch (_: Exception) {}
        try { oldGatt?.close() } catch (_: Exception) {}
        connectedName = name
        status.text = "CONNECTING $name • session/gate invalidated"
        record("META", "V87_UNIFIED_CONNECT_START name=$name address=${device.address} oldGattDetached=${oldGatt != null} directReconnect=$directReconnect transitionReason=$transitionReason connectionEpoch=$connectionEpoch sessionEpoch=$controlSessionEpoch healthGateValid=${sessionHealthGateValid()}")
        pendingConnectRunnable?.let { handler.removeCallbacks(it) }
        val requestedEpoch = connectionEpoch
        armConnectionWatchdog(requestedEpoch, transitionReason)
        val openNewGatt = Runnable {
            pendingConnectRunnable = null
            if (connectionEpoch != requestedEpoch) {
                record("META", "V87_CONNECT_OPEN_CANCELLED reason=stale-connection-epoch requestedEpoch=$requestedEpoch currentEpoch=$connectionEpoch")
                return@Runnable
            }
            try {
                val newGatt = device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
                gatt = newGatt
                record("META", "V87_UNIFIED_ACTIVE_GATT_ASSIGNED callbackIdentityGuard=true directReconnect=$directReconnect connectionEpoch=$connectionEpoch sessionEpoch=$controlSessionEpoch activeGattIdentity=${currentGattIdentity()} healthGateValid=${sessionHealthGateValid()}")
            } catch (_: SecurityException) {
                handler.post { failConnectionReady("permission-error", null) }
            }
        }
        pendingConnectRunnable = openNewGatt
        if (oldGatt != null) {
            record("META", "V87_RECONNECT_SETTLE_WAIT ms=600 directReconnect=$directReconnect oldGattDetached=true")
            handler.postDelayed(openNewGatt, 600L)
        } else {
            openNewGatt.run()
        }
    }

    private fun failClosedDisconnectedAllStatus(callbackGatt: BluetoothGatt, statusCode: Int) {
        val active = gatt
        if (active == null || callbackGatt !== active) {
            record("META", "V87_ALL_STATUS_DISCONNECT_STALE status=$statusCode action=IGNORE activeGattPresent=${active != null}")
            return
        }

        val disconnectedIdentity = System.identityHashCode(callbackGatt)
        val hadSaveInFlight = saveInFlight
        val hadScalarPipeline = pendingId != null
        val hadEqPipeline = pendingEqChannel != 0

        noteProofDisconnectObserved()
        if (hadSaveInFlight) {
            record("META", "V87_UNIFIED_PERSISTENT_SAVE_UNCONFIRMED reason=disconnect-during-save changesRemainUnsaved=true")
        }
        if (hadScalarPipeline) {
            record("META", "V87_UNIFIED_WRITE_STATE_UNCONFIRMED reason=disconnect-during-scalar-pipeline id=${pendingId ?: -1}")
        }
        if (hadEqPipeline) {
            record("META", "V87_UNIFIED_EQ_WRITE_STATE_UNCONFIRMED reason=disconnect-during-eq-pipeline ch=$pendingEqChannel band=$pendingEqBand")
        }

        cancelSaveTimers()
        saveInFlight = false
        saveGattOk = false

        // Detach first so any callback arriving after this point fails isCurrentGatt().
        gatt = null
        invalidateForConnectionTransition("gatt-disconnected-status-$statusCode")
        try { callbackGatt.close() } catch (_: Exception) {}

        val liveCacheCleared = scalarValues.isEmpty() && sensors.isEmpty() &&
            bands.all { channel -> channel.all { it == null } }
        record(
            "META",
            "V87_ALL_STATUS_DISCONNECT_FAIL_CLOSED status=$statusCode oldGattIdentity=$disconnectedIdentity activeGattDetached=true connectionEpoch=$connectionEpoch sessionEpoch=$controlSessionEpoch sessionReady=$sessionReady healthGateValid=${sessionHealthGateValid()} staleSessionObjectsCleared=true liveCacheCleared=$liveCacheCleared writesSent=0"
        )

        if (hadSaveInFlight || hadScalarPipeline || hadEqPipeline) {
            persistCriticalCapture(
                "all-status-disconnect-status=$statusCode-active-pipeline-save=$hadSaveInFlight-scalar=$hadScalarPipeline-eq=$hadEqPipeline"
            )
        }

        status.text = "DISCONNECTED • status=$statusCode • fail-closed • RECONNECT LAST DSP + START"
        if (::reconnectButton.isInitialized) reconnectButton.isEnabled = resolveCachedAddressExists()
        if (::startSessionButton.isInitialized) startSessionButton.isEnabled = false
        if (::refreshButton.isInitialized) {
            refreshButton.isEnabled = false
            refreshButton.text = "SYNC LIVE VALUES"
        }
        if (::refreshInfo.isInitialized) refreshInfo.text = "REFRESH STATUS • DISCONNECTED • reconnect + START"
        if (::fieldSelfCheckInfo.isInitialized) fieldSelfCheckInfo.text = "V87 SESSION HEALTH GATE • LOCKED • disconnected status=$statusCode"
        renderAll()
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, statusCode: Int, newState: Int) {
            if (!isCurrentGatt(g, "onConnectionStateChange")) return
            record("META", "GATT_STATE status=$statusCode newState=$newState")
            // V87 invariant: every terminal DISCONNECTED callback, regardless of status code,
            // uses the same detach/epoch/live-cache/uncertainty-journal path. This branch
            // must run before generic status handling because real DSP power loss was
            // observed as status=8 + STATE_DISCONNECTED on V84.
            if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                cancelConnectionWatchdog("gatt-disconnected-status-$statusCode")
                handler.post { failClosedDisconnectedAllStatus(g, statusCode) }
                return
            }
            if (statusCode != BluetoothGatt.GATT_SUCCESS) {
                handler.post { failConnectionReady("gatt-state-status-$statusCode", g) }
                return
            }
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                runOnUiThread { status.text = "CONNECTED ${connectedName ?: "DSP"} • discovering" }
                try {
                    g.requestMtu(517)
                    handler.postDelayed({ try { g.discoverServices() } catch (_: SecurityException) {} }, 250L)
                } catch (_: SecurityException) {}
            }
        }

        override fun onMtuChanged(g: BluetoothGatt, mtu: Int, statusCode: Int) {
            if (!isCurrentGatt(g, "onMtuChanged")) return
            record("META", "MTU_CHANGED mtu=$mtu status=$statusCode")
        }

        override fun onServicesDiscovered(g: BluetoothGatt, statusCode: Int) {
            if (!isCurrentGatt(g, "onServicesDiscovered")) return
            val service = g.getService(BleProfile.AB00_SERVICE)
            ab01 = service?.getCharacteristic(BleProfile.AB01_WRITE)
            ab02 = service?.getCharacteristic(BleProfile.AB02_NOTIFY)
            val ok = statusCode == BluetoothGatt.GATT_SUCCESS && ab01 != null && ab02 != null
            record("META", "SERVICES_DISCOVERED status=$statusCode AB01=${ab01 != null} AB02=${ab02 != null}")
            if (!ok) {
                handler.post { failConnectionReady("services-or-profile-status-$statusCode", g) }
                return
            }
            subscribeAb02(g, ab02!!)
            runOnUiThread { status.text = "CONNECTED • enabling AB02 notifications"; startSessionButton.isEnabled = false }
        }

        override fun onDescriptorWrite(g: BluetoothGatt, descriptor: BluetoothGattDescriptor, statusCode: Int) {
            if (!isCurrentGatt(g, "onDescriptorWrite")) return
            record("META", "CCCD_WRITE status=$statusCode")
            if (statusCode == BluetoothGatt.GATT_SUCCESS) {
                cancelConnectionWatchdog("cccd-ready")
                record("META", "V87_CONNECTION_READY connectionEpoch=$connectionEpoch activeGattIdentity=${System.identityHashCode(g)} writesSent=0")
                runOnUiThread {
                    status.text = "CONNECTED • AB02 notifications READY"
                    startSessionButton.isEnabled = true
                }
            } else {
                handler.post { failConnectionReady("cccd-status-$statusCode", g) }
            }
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, statusCode: Int) {
            if (!isCurrentGatt(g, "onCharacteristicWrite")) return
            val ticket = synchronized(gattWriteTickets) { if (gattWriteTickets.isEmpty()) null else gattWriteTickets.removeFirst() }
            record("META", "TX_WRITE_RESULT status=$statusCode uuid=${characteristic.uuid} ticket=${ticket ?: "NONE"}")
            if (characteristic.uuid != BleProfile.AB01_WRITE || ticket == null || ticket == GattWriteKind.OTHER) return
            val purpose = when (ticket) {
                GattWriteKind.SCALAR_TARGET -> PendingGattPurpose.SCALAR_TARGET
                GattWriteKind.SCALAR_RESTORE -> PendingGattPurpose.SCALAR_RESTORE
                GattWriteKind.EQ_TARGET -> PendingGattPurpose.EQ_TARGET
                GattWriteKind.EQ_RESTORE -> PendingGattPurpose.EQ_RESTORE
                GattWriteKind.SAVE_PARAMS -> PendingGattPurpose.SAVE_PARAMS
                GattWriteKind.OTHER -> return
            }
            if (pendingGattPurpose != purpose) {
                record("META", "V87_UNIFIED_GATT_TICKET_MISMATCH ticket=$ticket pending=${pendingGattPurpose ?: "NONE"} status=$statusCode ticketDepth=${synchronized(gattWriteTickets) { gattWriteTickets.size }} activeGattIdentity=${System.identityHashCode(g)}")
                persistCriticalCapture("gatt-ticket-mismatch-$ticket-pending-${pendingGattPurpose ?: "NONE"}")
                return
            }
            val callbackAgeMs = if (gattActionArmedAtElapsedMs > 0L) android.os.SystemClock.elapsedRealtime() - gattActionArmedAtElapsedMs else -1L
            val armedGattIdentity = gattActionArmedGattIdentity
            cancelGattActionTimeout()
            pendingGattPurpose = null
            val ok = statusCode == BluetoothGatt.GATT_SUCCESS
            record("META", "V87_UNIFIED_GATT_RESULT purpose=$purpose ticket=$ticket status=$statusCode ok=$ok callbackAgeMs=$callbackAgeMs id=${pendingId ?: -1} eqCh=$pendingEqChannel eqBand=$pendingEqBand activeGattIdentity=${System.identityHashCode(g)} armedGattIdentity=$armedGattIdentity ticketDepth=${synchronized(gattWriteTickets) { gattWriteTickets.size }}")
            handler.post {
                when (purpose) {
                    PendingGattPurpose.SCALAR_TARGET -> {
                        if (ok) {
                            status.text = "V87 target GATT success • requesting fresh full descriptor verify"
                            handler.postDelayed({ requestDescriptor(DescMode.VERIFY_TARGET) }, 350L)
                        } else {
                            sessionReady = false
                            status.text = "SCALAR TARGET GATT FAILED $statusCode — STOP • NO AUTO-RESTORE • reconnect + fresh read"
                            record("META", "V87_UNIFIED_UNCONFIRMED_TARGET_POLICY action=STOP_NO_SECOND_WRITE family=SCALAR reason=gatt-status-$statusCode")
                            persistCriticalCapture("scalar-target-gatt-failed-$statusCode")
                            clearPending("target-gatt-failed-stop-$statusCode")
                        }
                    }
                    PendingGattPurpose.SCALAR_RESTORE -> {
                        if (ok) {
                            status.text = "V87 restore GATT success • requesting fresh restore verify"
                            handler.postDelayed({ requestDescriptor(DescMode.VERIFY_RESTORE) }, 350L)
                        } else {
                            sessionReady = false
                            status.text = "RESTORE GATT FAILED — STOP • DO NOT SAVE • diagnostic persisted"
                            persistCriticalCapture("scalar-restore-gatt-failed-$statusCode")
                            clearPending("restore-gatt-failed-$statusCode")
                        }
                    }
                    PendingGattPurpose.EQ_TARGET -> {
                        if (ok) {
                            status.text = "V87 EQ target GATT success • waiting proven settle before fresh full descriptor verify"
                            handler.postDelayed({ requestDescriptor(DescMode.EQ_VERIFY_TARGET) }, eqTargetVerifyDelayMs)
                        } else {
                            sessionReady = false
                            status.text = "EQ TARGET GATT FAILED $statusCode — STOP • NO AUTO-RESTORE • reconnect + fresh read"
                            record("META", "V87_UNIFIED_UNCONFIRMED_TARGET_POLICY action=STOP_NO_SECOND_WRITE family=EQ reason=gatt-status-$statusCode")
                            persistCriticalCapture("eq-target-gatt-failed-$statusCode")
                            clearPendingEq("target-gatt-failed-stop-$statusCode")
                        }
                    }
                    PendingGattPurpose.EQ_RESTORE -> {
                        if (ok) {
                            status.text = "V87 EQ restore GATT success • waiting proven settle before fresh restore verify"
                            handler.postDelayed({ requestDescriptor(DescMode.EQ_VERIFY_RESTORE) }, eqRestoreVerifyDelayMs)
                        } else {
                            sessionReady = false
                            status.text = "EQ RESTORE GATT FAILED — STOP • DO NOT SAVE • diagnostic persisted"
                            persistCriticalCapture("eq-restore-gatt-failed-$statusCode")
                            clearPendingEq("restore-gatt-failed-$statusCode")
                        }
                    }
                    PendingGattPurpose.SAVE_PARAMS -> {
                        if (ok) {
                            saveGattOk = true
                            record("META", "V87_UNIFIED_SAVEPARAMS_GATT_SUCCESS settleMs=$saveCommitSettleMs")
                            status.text = "V87 SaveParams GATT success • DO NOT POWER OFF • settling 5s"
                            beginSaveSettle()
                        } else markSaveUnconfirmed("save-gatt-failed-$statusCode")
                    }
                }
                renderAll()
            }
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            if (!isCurrentGatt(g, "onCharacteristicChanged33")) return
            if (characteristic.uuid == BleProfile.AB02_NOTIFY) handleAb02(value)
        }

        @Suppress("DEPRECATION")
        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            if (!isCurrentGatt(g, "onCharacteristicChangedLegacy")) return
            if (android.os.Build.VERSION.SDK_INT < 33 && characteristic.uuid == BleProfile.AB02_NOTIFY) handleAb02(characteristic.value ?: byteArrayOf())
        }
    }

    private fun subscribeAb02(g: BluetoothGatt, ch: BluetoothGattCharacteristic) {
        if (!hasBlePermission()) return
        try {
            g.setCharacteristicNotification(ch, true)
            val cccd = ch.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")) ?: return
            val v = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            if (android.os.Build.VERSION.SDK_INT >= 33) g.writeDescriptor(cccd, v)
            else {
                @Suppress("DEPRECATION") cccd.value = v
                @Suppress("DEPRECATION") g.writeDescriptor(cccd)
            }
        } catch (e: Exception) {
            record("META", "V87_UNIFIED_SUBSCRIBE_ERROR ${e.javaClass.simpleName}:${e.message}")
        }
    }

    private fun writeNoResponse(
        g: BluetoothGatt,
        ch: BluetoothGattCharacteristic,
        bytes: ByteArray,
        label: String,
        purpose: PendingGattPurpose? = null,
    ): Boolean {
        if (!hasBlePermission()) return false
        record("TX", "$label len=${bytes.size} hex=${ByteCodec.run { bytes.toHex() }}")

        // V87 ordering invariant: prepare the callback ticket and, for control writes,
        // arm the timeout/GATT identity BEFORE calling Android writeCharacteristic().
        // Android may deliver onCharacteristicWrite almost immediately; the callback
        // must never observe ticket/purpose state that has not been armed yet.
        val kind = when (purpose) {
            PendingGattPurpose.SCALAR_TARGET -> GattWriteKind.SCALAR_TARGET
            PendingGattPurpose.SCALAR_RESTORE -> GattWriteKind.SCALAR_RESTORE
            PendingGattPurpose.EQ_TARGET -> GattWriteKind.EQ_TARGET
            PendingGattPurpose.EQ_RESTORE -> GattWriteKind.EQ_RESTORE
            PendingGattPurpose.SAVE_PARAMS -> GattWriteKind.SAVE_PARAMS
            null -> GattWriteKind.OTHER
        }
        synchronized(gattWriteTickets) { gattWriteTickets.addLast(kind) }
        record("META", "V87_UNIFIED_GATT_TICKET_PREPARED label=$label kind=$kind depth=${synchronized(gattWriteTickets) { gattWriteTickets.size }} beforeWriteCharacteristic=true")
        if (purpose != null) armGattActionTimeout(purpose)

        val queued = try {
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                g.writeCharacteristic(ch, bytes, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE) == BluetoothStatusCodes.SUCCESS
            } else {
                @Suppress("DEPRECATION") ch.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                @Suppress("DEPRECATION") ch.value = bytes
                @Suppress("DEPRECATION") g.writeCharacteristic(ch)
            }
        } catch (e: Exception) {
            record("META", "$label ERROR ${e.javaClass.simpleName}:${e.message}")
            false
        }

        if (!queued) {
            val ticketRolledBack = synchronized(gattWriteTickets) {
                if (gattWriteTickets.isNotEmpty() && gattWriteTickets.last() == kind) {
                    gattWriteTickets.removeLast()
                    true
                } else false
            }
            if (purpose != null && pendingGattPurpose == purpose) cancelGattActionTimeout()
            record("META", "V87_UNIFIED_GATT_PREARM_ROLLBACK label=$label kind=$kind ticketRolledBack=$ticketRolledBack purpose=${purpose ?: "OTHER"} reason=writeCharacteristic-not-accepted depth=${synchronized(gattWriteTickets) { gattWriteTickets.size }}")
            return false
        }

        record("META", "V87_UNIFIED_GATT_WRITE_ACCEPTED label=$label kind=$kind purpose=${purpose ?: "OTHER"} ticketDepth=${synchronized(gattWriteTickets) { gattWriteTickets.size }} armedGattIdentity=$gattActionArmedGattIdentity")
        return true
    }

    private fun record(kind: String, text: String) {
        val line = "${ts.format(Date())}\t#${++packetNo}\t$kind\t$text"
        synchronized(captureLines) { captureLines.add(line) }
        if (::logView.isInitialized) runOnUiThread { logView.text = (logView.text.toString() + line + "\n").takeLast(16000) }
    }

    private fun loadCriticalCapture(): String? = try {
        val current = java.io.File(filesDir, criticalCaptureFileName)
        val legacyV86 = java.io.File(filesDir, legacyCriticalCaptureFileNameV86)
        val legacyV85 = java.io.File(filesDir, legacyCriticalCaptureFileNameV85)
        val legacyV84 = java.io.File(filesDir, legacyCriticalCaptureFileNameV84)
        val legacyV83 = java.io.File(filesDir, legacyCriticalCaptureFileNameV83)
        val legacyV82 = java.io.File(filesDir, legacyCriticalCaptureFileName)
        val legacyV81 = java.io.File(filesDir, legacyCriticalCaptureFileNameV81)
        val legacyV80 = java.io.File(filesDir, legacyCriticalCaptureFileNameV80)
        val legacyV79 = java.io.File(filesDir, legacyCriticalCaptureFileNameV79)
        val legacyV78 = java.io.File(filesDir, legacyCriticalCaptureFileNameV78)
        val legacyV77 = java.io.File(filesDir, legacyCriticalCaptureFileNameV77)
        val legacyV76 = java.io.File(filesDir, legacyCriticalCaptureFileNameV76)
        val legacyV75 = java.io.File(filesDir, legacyCriticalCaptureFileNameV75)
        val legacyV74 = java.io.File(filesDir, legacyCriticalCaptureFileNameV74)
        when {
            current.isFile && current.length() > 0L -> current.readText()
            legacyV86.isFile && legacyV86.length() > 0L -> legacyV86.readText()
            legacyV85.isFile && legacyV85.length() > 0L -> legacyV85.readText()
            legacyV84.isFile && legacyV84.length() > 0L -> legacyV84.readText()
            legacyV83.isFile && legacyV83.length() > 0L -> legacyV83.readText()
            legacyV82.isFile && legacyV82.length() > 0L -> legacyV82.readText()
            legacyV81.isFile && legacyV81.length() > 0L -> legacyV81.readText()
            legacyV80.isFile && legacyV80.length() > 0L -> legacyV80.readText()
            legacyV79.isFile && legacyV79.length() > 0L -> legacyV79.readText()
            legacyV78.isFile && legacyV78.length() > 0L -> legacyV78.readText()
            legacyV77.isFile && legacyV77.length() > 0L -> legacyV77.readText()
            legacyV76.isFile && legacyV76.length() > 0L -> legacyV76.readText()
            legacyV75.isFile && legacyV75.length() > 0L -> legacyV75.readText()
            legacyV74.isFile && legacyV74.length() > 0L -> legacyV74.readText()
            else -> null
        }
    } catch (_: Exception) { null }

    private fun persistCriticalCapture(reason: String) {
        val snapshot = buildString {
            append("=== OKN DSP V87 PERSISTED CRITICAL DIAGNOSTIC ===\n")
            append("reason=").append(reason).append('\n')
            append("savedAt=").append(SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date())).append('\n')
            append("policy=NO_AUTO_SECOND_WRITE_WHEN_TARGET_GATT_UNCONFIRMED\n")
            synchronized(captureLines) { captureLines.forEach { append(it).append('\n') } }
        }
        try {
            java.io.File(filesDir, criticalCaptureFileName).writeText(snapshot)
            recoveredCriticalCaptureText = snapshot
            updateDiagnosticInfo()
        } catch (e: Exception) {
            if (::logView.isInitialized) runOnUiThread {
                logView.text = (logView.text.toString() + "DIAGNOSTIC_PERSIST_ERROR ${e.javaClass.simpleName}:${e.message}\n").takeLast(16000)
            }
        }
    }

    private fun updateDiagnosticInfo() {
        if (!::diagnosticInfo.isInitialized) return
        runOnUiThread {
            val bytes = recoveredCriticalCaptureText?.toByteArray()?.size ?: 0
            diagnosticInfo.text = if (bytes > 0) {
                "Diagnostics: LAST FAILURE PERSISTED • $bytes bytes • survives app restart • Export includes it"
            } else {
                "Diagnostics: armed • critical GATT failure will be persisted automatically and survive app restart"
            }
        }
    }

    private fun saveCapture() {
        val text = buildString {
            append("=== OKN DSP V87 PRODUCTION SAFE DIAGNOSTIC CAPTURE ===\n")
            append("exportIncludesRecoveredCritical=").append(recoveredCriticalCaptureText != null).append('\n')
            recoveredCriticalCaptureText?.let { recovered ->
                append("\n=== RECOVERED/PERSISTED LAST CRITICAL FAILURE ===\n")
                append(recovered.trimEnd()).append('\n')
                append("=== END RECOVERED CRITICAL FAILURE ===\n\n")
            }
            append("=== CURRENT V87 SESSION ===\n")
            synchronized(captureLines) { captureLines.forEach { append(it).append('\n') } }
        }
        val name = "OKN_DSP_V87_PRODUCTION_SAFE_DIAGNOSTIC_CAPTURE_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.txt"
        try {
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: error("insert failed")
                contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) }
                Toast.makeText(this, "Saved Downloads/$name", Toast.LENGTH_LONG).show()
            } else {
                val f = java.io.File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), name)
                f.writeText(text)
                Toast.makeText(this, "Saved ${f.absolutePath}", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Save failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun requestBlePermissions() {
        val perms = if (android.os.Build.VERSION.SDK_INT >= 31) {
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        } else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (perms.any { ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }) {
            ActivityCompat.requestPermissions(this, perms, 1065)
        }
    }

    private fun hasBlePermission(): Boolean = if (android.os.Build.VERSION.SDK_INT >= 31) {
        ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
    } else ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun fmt(v: Float): String = String.format(Locale.US, "%.3f", v)
}
