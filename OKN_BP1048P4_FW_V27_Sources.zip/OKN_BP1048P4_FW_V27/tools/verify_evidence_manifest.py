#!/usr/bin/env python3
from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'evidence_manifest.json').read_text())
errors=[]
if m.get('schema')!=4: errors.append('evidence schema must be 4')
if m.get('project_version')!=27: errors.append('project_version must be 27')
if m.get('target')!='BP1048P4' or m.get('board')!='GoloPine 7CH': errors.append('target/board mismatch')
if m.get('policy')!='FAIL_CLOSED_NO_INFERENCE': errors.append('policy mismatch')
if m.get('hardware_authorized') is not False: errors.append('hardware_authorized must be false')
req=m.get('required_exact_evidence',{})
if any(bool(v) for v in req.values()): errors.append('V27 exact evidence flags must all remain false')
prov=m.get('provenance',{})
if prov.get('previous_source_sha256')!='f52fd3bef50f13e2f82f6653bcb8e73c3ed10978796531f978c467e1f1b4feb4': errors.append('V26 source provenance mismatch')
if prov.get('validation_zip_sha256')!='aeed6ae397fc1257bde9129b2432b646f5d17ee19c7771b111171f54f609fb3e': errors.append('V26 validation provenance mismatch')
if not any(o.get('id')=='v26-ci-validation' for o in m.get('observations',[])): errors.append('V26 CI observation missing')
for ob in m.get('observations',[]):
    if ob.get('authorizes') not in ([],None): errors.append('observations may not authorize hardware in V27')
if errors:
    [print('BLOCKED:',e) for e in errors]; sys.exit(1)
print('PASS: V27 evidence manifest is internally consistent and non-authorizing')
