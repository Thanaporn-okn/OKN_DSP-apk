#!/usr/bin/env python3
from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'tools'))
from port_integration_plan import derive_from_files
errors=[]
try: expected=derive_from_files(root)
except Exception as e:
    print('BLOCKED: cannot derive port integration plan:',e); raise SystemExit(1)
actual=json.loads((root/'port_integration_plan.json').read_text())
if actual != expected: errors.append('port_integration_plan.json is stale or not derived from current qualification inputs')
if actual.get('schema')!=1 or actual.get('project_version')!=27: errors.append('plan schema/version mismatch')
if actual.get('contains_target_addresses_or_packets') is not False: errors.append('plan must not contain target values')
if actual.get('hardware_integration_ready') is not False: errors.append('shipped V27 hardware integration must remain locked')
if actual.get('mobile_flash_integration_ready') is not False: errors.append('shipped V27 mobile flash integration must remain locked')
for name,s in actual.get('subsystems',{}).items():
    if s.get('ready_for_integration') is not False: errors.append(name+': shipped subsystem unexpectedly ready')
forbidden={'address','register','register_value','packet','opcode','boot_pin','gpio','memory_base','load_address','flash_offset','pin_value'}
def walk(x,path='root'):
    if isinstance(x,dict):
        for k,v in x.items():
            if k.lower() in forbidden: errors.append(path+'.'+k+': forbidden hardware-value key in readiness plan')
            walk(v,path+'.'+k)
    elif isinstance(x,list):
        for i,v in enumerate(x): walk(v,f'{path}[{i}]')
walk(actual)
if errors:
    [print('BLOCKED:',e) for e in errors]; raise SystemExit(1)
print('PASS: V27 port integration plan is derived, stale-resistant, value-free, and fail-closed')
