#!/usr/bin/env python3
from pathlib import Path
import json,re,sys

ROOT=Path(__file__).resolve().parents[1]
HEX64=re.compile(r'^[0-9a-f]{64}$')

def load(name):
    return json.loads((ROOT/name).read_text())

def verify(chain, fw, evidence):
    errors=[]
    if chain.get('schema') != 1:
        errors.append('provenance schema must be 1')
    if chain.get('policy') != 'LINEAR_IMMEDIATE_PREDECESSOR_SHA256':
        errors.append('provenance policy mismatch')
    current=chain.get('current',{})
    prev=chain.get('previous',{})
    cv=current.get('version')
    pv=prev.get('version')
    if chain.get('project_version') != cv:
        errors.append('project_version/current.version mismatch')
    if cv != 27:
        errors.append('current version must be 27')
    if not isinstance(pv,int) or pv != cv-1:
        errors.append('previous version must equal current version - 1')
    for key in ('source_sha256','validation_sha256'):
        if not isinstance(prev.get(key),str) or not HEX64.fullmatch(prev[key]):
            errors.append(key+' must be lowercase SHA-256 hex')
    if prev.get('source_file') != f'OKN_BP1048P4_FW_V{pv}_Sources.zip':
        errors.append('previous source filename/version mismatch')
    if prev.get('validation_file') != f'OKN-BP1048P4-FW-V{pv}-validation.zip':
        errors.append('previous validation filename/version mismatch')
    if chain.get('authorizes_hardware') is not False or chain.get('authorizes_mobile_flash') is not False:
        errors.append('provenance chain must be non-authorizing')

    fp=fw.get('provenance',{})
    if fp.get('previous_version') != pv:
        errors.append('firmware_manifest previous_version mismatch')
    if fp.get('previous_source_sha256') != prev.get('source_sha256'):
        errors.append('firmware_manifest previous source hash mismatch')
    if fp.get('previous_validation_sha256') != prev.get('validation_sha256'):
        errors.append('firmware_manifest previous validation hash mismatch')

    ep=evidence.get('provenance',{})
    if ep.get('previous_source') != prev.get('source_file'):
        errors.append('evidence_manifest previous source filename mismatch')
    if ep.get('previous_source_sha256') != prev.get('source_sha256'):
        errors.append('evidence_manifest previous source hash mismatch')
    if ep.get('validation_zip_sha256') != prev.get('validation_sha256'):
        errors.append('evidence_manifest previous validation hash mismatch')
    if ep.get('validated_by_uploaded_artifact') is not True:
        errors.append('predecessor must be backed by uploaded validation artifact')

    obsid=f'v{pv}-ci-validation'
    matches=[o for o in evidence.get('observations',[]) if o.get('id')==obsid]
    if len(matches)!=1:
        errors.append('exactly one immediate predecessor CI observation required')
    else:
        o=matches[0]
        if o.get('source_zip_sha256') != prev.get('source_sha256'):
            errors.append('CI observation previous source hash mismatch')
        if o.get('validation_zip_sha256') != prev.get('validation_sha256'):
            errors.append('CI observation previous validation hash mismatch')
        if o.get('authorizes') not in ([],None):
            errors.append('CI observation must not authorize hardware')
    return errors

def main():
    chain=load('provenance_chain_manifest.json')
    fw=load('firmware_manifest.json')
    evidence=load('evidence_manifest.json')
    errors=verify(chain,fw,evidence)
    if errors:
        for e in errors: print('BLOCKED:',e)
        return 1
    print('PASS: V27 provenance chain binds the immediate V26 source + GitHub validation hashes and remains non-authorizing')
    return 0

if __name__=='__main__':
    sys.exit(main())
