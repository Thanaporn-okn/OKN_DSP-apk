#!/usr/bin/env python3
from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[1]
fm=json.loads((root/'firmware_manifest.json').read_text())
tm=json.loads((root/'target_port_manifest.json').read_text())
errors=[]
ts=fm.get('transport_safety',{})
sb=fm.get('safe_boot',{})
if ts.get('partial_frame_idle_reset') is not True: errors.append('partial-frame idle reset must be declared')
if ts.get('transport_supplies_elapsed_time') is not True: errors.append('portable parser must not own/guess a target clock')
if ts.get('timeout_value_target_specific') is not True: errors.append('timeout value must remain transport/target policy')
if sb.get('platform_init_output_safe_evidence_required') is not True: errors.append('safe boot must require platform_init output-safe evidence')
if tm.get('evidence',{}).get('platform_init_output_safe') is not False: errors.append('platform_init_output_safe target evidence must remain locked')
h=(root/'src/hal/bp1048p4_port_contract.h').read_text()
if 'BP1048P4_PORT_ABI_VERSION 2u' not in h: errors.append('port ABI must be V16 preserves ABI 2')
if 'platform_init_output_safe_verified' not in h: errors.append('port contract missing safe-init evidence')
sh=(root/'src/transport/okn_stream.h').read_text()
for sym in ('okn_stream_note_idle','okn_stream_reset_partial','timeout_resets'):
    if sym not in sh: errors.append('stream safety symbol missing: '+sym)
if errors:
    [print('BLOCKED:',e) for e in errors]; sys.exit(1)
print('PASS: V27 stream idle recovery + platform-init output-safe evidence gate are explicit and fail-closed')
