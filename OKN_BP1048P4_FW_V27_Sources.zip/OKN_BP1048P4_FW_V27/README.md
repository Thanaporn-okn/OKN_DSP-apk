# OKN_BP1048P4_FW_V27

V27 is a wire/persistence portability hardening revision of the portable clean-room firmware foundation. It preserves the V26 numeric/state hardening, fuzzing, provenance chain, source inventory, and every fail-closed hardware/mobile-flash gate.

## What V27 adds

- Freezes byte-for-byte golden vectors for Protocol V2 `GET_INFO`, `GET_CAPABILITIES`, one floating-point channel-gain mutation/ACK, and a full 1,690-byte persistence image.
- Runs the same golden-vector test with GCC and Clang when both are available, catching compiler/ABI drift before any BP1048P4 toolchain port.
- Verifies persistence and protocol formats use explicit little-endian byte helpers instead of packed C structs or raw state-struct serialization.
- Independently checks the persistence schema-2 CRC over header fields + payload while skipping only the stored CRC word.
- Keeps Protocol V2 and persistence schema 2 unchanged; V27 is a compatibility hardening revision, not a wire-format redesign.
- Binds the immediate predecessor to the uploaded V26 GitHub validation artifact.

The golden vectors are regression fixtures, not BP1048P4 hardware packets. They describe only the clean-room OKN protocol and portable persistence format.

## Safety status

- Exact BP1048P4/GoloPine hardware integration: LOCKED.
- Hardware flashable: NO.
- Mobile flashable: NO.
- Programmer I/O: NOT IMPLEMENTED.
- Destructive executor: NOT IMPLEMENTED.
- Target `.bin/.img`: NONE.
- No guessed register/address/pin/programmer packet is introduced by V27.
