# OKN_DSP V2

Android DSP controller rebuilt from the five supplied UI reference screens.

Version: V2 (versionCode 2 / versionName 2.0.0)

V2 startup fix:
- BLE scanner creation is no longer performed in `Activity.onCreate()`.
- On Android 12+ the app first checks `BLUETOOTH_SCAN` and `BLUETOOTH_CONNECT` runtime permissions.
- `getBluetoothLeScanner()` is now called only after permission validation and is guarded against `SecurityException`.
- This removes the identified first-launch crash path present in V1.

UI pages: Home, EQ, Crossover, Delay, Output.
Reference images are stored under `Sources/reference/`.

Protocol safety: UI interaction remains local/immediate. DSP writes are sent only through the verified-write transport once an exact command packet format is confirmed.
