# OKN_DSP V2 Startup Fix

## Identified V1 fault
`MainActivity.onCreate()` obtained `BluetoothLeScanner` before Android 12+ runtime Bluetooth permissions had been granted. Access to the BLE scanner can require `BLUETOOTH_SCAN`, so this startup path could throw `SecurityException` immediately when the app was opened.

## V2 correction
1. `onCreate()` initializes the Bluetooth adapter only and leaves `scanner = null`.
2. The scanner is created inside `startScan()` only after `hasBlePermissions()` has passed.
3. Scanner creation is wrapped in `try/catch (SecurityException)`.
4. App version advanced to V2 rather than overwriting V1.
