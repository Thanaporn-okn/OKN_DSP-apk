import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() => runApp(const OknDspApp());

class OknDspApp extends StatelessWidget {
  const OknDspApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'OKN DSP',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.blue),
      home: const HomePage(),
    );
  }
}

class DeviceInfo {
  final String name;
  final String address;
  final int rssi;
  const DeviceInfo(this.name, this.address, this.rssi);
}

class Packet {
  final String characteristic;
  final String hex;
  final String time;
  final int length;
  const Packet(this.characteristic, this.hex, this.time, this.length);
}

class ReadResult {
  final String stage;
  final String hex;
  final int length;
  final int status;
  const ReadResult(this.stage, this.hex, this.length, this.status);
}

class _HomePageState extends State<HomePage> {
  static const methods = MethodChannel('okn_dsp/methods');
  static const events = EventChannel('okn_dsp/events');

  StreamSubscription? sub;
  final devices = <String, DeviceInfo>{};
  final packets = <Packet>[];
  final reads = <ReadResult>[];

  DeviceInfo? selected;
  String status = 'กด Bluetooth ด้านบนเพื่อค้นหา';
  String notifyStatus = 'ยังไม่ได้เปิด Notify';
  String gatt = '';
  String testStage = 'ยังไม่ได้เริ่ม';
  bool scanning = false;
  bool connected = false;
  bool testing = false;

  @override
  void initState() {
    super.initState();
    sub = events.receiveBroadcastStream().listen(_onEvent);
  }

  void _onEvent(dynamic event) {
    if (!mounted || event is! Map) return;
    final type = event['type']?.toString() ?? '';

    if (type == 'scan') {
      final name = event['name']?.toString() ?? '';
      final address = event['address']?.toString() ?? '';
      final rssi = int.tryParse(event['rssi']?.toString() ?? '') ?? 0;
      if (address.isNotEmpty) {
        setState(() {
          devices[address] = DeviceInfo(
            name.isEmpty ? '(บอร์ดไม่ส่งชื่อ)' : name,
            address,
            rssi,
          );
        });
      }
    } else if (type == 'scan_done') {
      setState(() {
        scanning = false;
        status = 'ค้นหาเสร็จแล้ว — พบ ${devices.length} อุปกรณ์';
      });
    } else if (type == 'status') {
      setState(() => status = event['message']?.toString() ?? '');
    } else if (type == 'connected') {
      setState(() {
        connected = true;
        status = 'เชื่อมต่อ DSP แล้ว';
      });
    } else if (type == 'disconnected') {
      setState(() {
        connected = false;
        testing = false;
        testStage = 'หลุดการเชื่อมต่อ';
      });
    } else if (type == 'gatt') {
      setState(() => gatt = event['text']?.toString() ?? '');
    } else if (type == 'notify') {
      setState(() => notifyStatus = event['message']?.toString() ?? '');
    } else if (type == 'rx') {
      final ch = event['characteristic']?.toString() ?? '';
      final hex = event['data']?.toString() ?? '';
      final len = int.tryParse(event['length']?.toString() ?? '') ?? 0;
      final time = event['time']?.toString() ?? '';
      setState(() {
        packets.insert(0, Packet(ch, hex, time, len));
        if (packets.length > 100) packets.removeLast();
      });
    } else if (type == 'read') {
      final stage = event['stage']?.toString() ?? 'READ';
      final hex = event['data']?.toString() ?? '';
      final len = int.tryParse(event['length']?.toString() ?? '') ?? 0;
      final st = int.tryParse(event['status']?.toString() ?? '') ?? -1;
      setState(() {
        reads.insert(0, ReadResult(stage, hex, len, st));
      });
    } else if (type == 'test') {
      setState(() => testStage = event['message']?.toString() ?? '');
    }
  }

  Future<void> scan() async {
    setState(() {
      scanning = true;
      devices.clear();
      status = 'กำลังค้นหา Bluetooth...';
    });
    try {
      await methods.invokeMethod('scan');
    } catch (e) {
      if (mounted) setState(() {
        scanning = false;
        status = 'สแกนไม่ได้: $e';
      });
    }
  }

  Future<void> connect(DeviceInfo d) async {
    setState(() {
      selected = d;
      connected = false;
      testing = false;
      packets.clear();
      reads.clear();
      gatt = '';
      testStage = 'กำลังเชื่อมต่อ...';
      notifyStatus = 'กำลังเชื่อมต่อ';
      status = 'กำลังเชื่อมต่อ ${d.name}...';
    });
    try {
      await methods.invokeMethod('connect', {'address': d.address});
    } catch (e) {
      if (mounted) setState(() => status = 'เชื่อมต่อไม่ได้: $e');
    }
  }

  Future<void> startFullTest() async {
    if (!connected || testing) return;
    setState(() {
      testing = true;
      packets.clear();
      reads.clear();
      testStage = 'เริ่มทดสอบ AB01 → AB02 → AB03';
    });
    try {
      await methods.invokeMethod('startFullTest');
    } catch (e) {
      if (mounted) setState(() {
        testing = false;
        testStage = 'ทดสอบไม่สำเร็จ: $e';
      });
    }
  }

  Future<void> readAb01() async {
    if (!connected) return;
    setState(() => testStage = 'READ AB01 แบบ READ เท่านั้น');
    try {
      await methods.invokeMethod('readAb01');
    } catch (e) {
      if (mounted) setState(() => testStage = 'READ AB01 ไม่สำเร็จ: $e');
    }
  }

  Future<void> copyAll() async {
    final out = <String>[
      'OKN DSP V11 AB01 → AB02 → AB03 DIAGNOSTIC',
      if (selected != null)
        'DEVICE: ${selected!.name} | ${selected!.address} | RSSI=${selected!.rssi}',
      'TEST: $testStage',
      '',
      'READ RESULTS:',
      ...reads.reversed.map((r) =>
          '${r.stage} | STATUS=${r.status} | LEN=${r.length} | ${r.hex}'),
      '',
      'NOTIFY PACKETS:',
      ...packets.reversed.map((p) =>
          '${p.time} | ${p.characteristic} | LEN=${p.length} | ${p.hex}'),
    ];
    await Clipboard.setData(ClipboardData(text: out.join('\n')));
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('คัดลอกผลทดสอบทั้งหมดแล้ว')),
      );
    }
  }

  @override
  void dispose() {
    sub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('OKN DSP Controller V11'),
        actions: [
          IconButton(
            tooltip: 'ค้นหา Bluetooth',
            onPressed: scanning ? null : scan,
            icon: const Icon(Icons.bluetooth_searching),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('ตัวทดสอบ AB01 → AB02 → AB03',
                      style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  const Text(
                    'AB01 = READ เท่านั้น\n'
                    'AB02 = เปิด Notify และรอข้อมูล\n'
                    'AB03 = เปิด Notify และรอข้อมูล\n'
                    'ไม่มีการส่ง payload ควบคุม DSP',
                    style: TextStyle(fontSize: 16),
                  ),
                  const SizedBox(height: 12),
                  Text(status),
                  const SizedBox(height: 8),
                  Text('ขั้นตอน: $testStage'),
                ],
              ),
            ),
          ),

          if (selected != null)
            Card(
              child: ListTile(
                leading: const Icon(Icons.developer_board),
                title: Text(selected!.name),
                subtitle: Text('${selected!.address}\nRSSI ${selected!.rssi} dBm'),
                trailing: connected
                    ? const Icon(Icons.bluetooth_connected)
                    : FilledButton(
                        onPressed: () => connect(selected!),
                        child: const Text('เชื่อมต่อ'),
                      ),
              ),
            ),

          if (!connected)
            Card(
              child: Column(
                children: [
                  ListTile(
                    title: const Text('อุปกรณ์ Bluetooth ที่พบ'),
                    subtitle: Text(scanning
                        ? 'กำลังค้นหา...'
                        : 'เลือกอุปกรณ์ที่เป็นช่องควบคุม DSP'),
                  ),
                  ...devices.values.map((d) => ListTile(
                        leading: const Icon(Icons.bluetooth),
                        title: Text(d.name),
                        subtitle: Text('${d.address}  RSSI ${d.rssi}'),
                        trailing: OutlinedButton(
                          onPressed: () => connect(d),
                          child: const Text('ใช้เป็น DSP'),
                        ),
                      )),
                  if (!scanning && devices.isEmpty)
                    const Padding(
                      padding: EdgeInsets.all(16),
                      child: Text('ยังไม่พบอุปกรณ์ กด Bluetooth ด้านบน'),
                    ),
                ],
              ),
            ),

          if (connected) ...[
            Card(
              child: Column(
                children: [
                  ListTile(
                    leading: const Icon(Icons.notifications_active),
                    title: const Text('Notify'),
                    subtitle: Text(notifyStatus),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(12),
                    child: SizedBox(
                      width: double.infinity,
                      child: FilledButton.icon(
                        onPressed: testing ? null : startFullTest,
                        icon: const Icon(Icons.science),
                        label: Text(testing
                            ? 'กำลังทดสอบ AB01 → AB02 → AB03...'
                            : 'เริ่มทดสอบ AB01 → AB02 → AB03'),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                    child: OutlinedButton.icon(
                      onPressed: readAb01,
                      icon: const Icon(Icons.download),
                      label: const Text('อ่าน AB01 เดี่ยว (READ เท่านั้น)'),
                    ),
                  ),
                ],
              ),
            ),

            if (gatt.isNotEmpty)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: SelectableText(
                      gatt,
                      style: const TextStyle(fontFamily: 'monospace', fontSize: 11),
                    ),
                  ),
                ),
              ),

            Row(
              children: [
                const Expanded(
                  child: Text('AB01 READ RESPONSE',
                      style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
                ),
                IconButton(
                  onPressed: copyAll,
                  icon: const Icon(Icons.copy),
                  tooltip: 'คัดลอกทั้งหมด',
                ),
              ],
            ),
            if (reads.isEmpty)
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text('ยังไม่มีผล AB01 READ'),
              )
            else
              ...reads.map((r) => Card(
                    child: Padding(
                      padding: const EdgeInsets.all(10),
                      child: SelectableText(
                        '${r.stage}\nSTATUS=${r.status}  LEN=${r.length}\n${r.hex}',
                        style: const TextStyle(fontFamily: 'monospace'),
                      ),
                    ),
                  )),

            const SizedBox(height: 8),
            Row(
              children: [
                const Expanded(
                  child: Text('RX จาก AB02 / AB03 Notify',
                      style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
                ),
                Text('${packets.length} packets'),
              ],
            ),
            if (packets.isEmpty)
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                  'ยังไม่มี packet\nหลังเริ่มทดสอบ ให้รอข้อมูลจาก AB02 / AB03',
                  textAlign: TextAlign.center,
                ),
              )
            else
              ...packets.map((p) => Card(
                    child: Padding(
                      padding: const EdgeInsets.all(10),
                      child: SelectableText(
                        '${p.time}\nCHAR=${p.characteristic}\nLEN=${p.length}\n${p.hex}',
                        style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
                      ),
                    ),
                  )),

            const SizedBox(height: 12),
            const Text(
              '🛑 V11: ทดสอบ READ/Notify เท่านั้น ไม่ส่งคำสั่งควบคุม DSP',
              textAlign: TextAlign.center,
            ),
          ],
        ],
      ),
    );
  }
}
