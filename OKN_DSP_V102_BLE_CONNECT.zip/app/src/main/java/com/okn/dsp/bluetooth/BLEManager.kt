package com.okn.dsp.bluetooth

class BLEManager {

    var connected:Boolean = false

    fun scanDevices() {
        // BLE scan implementation
    }

    fun connect(device:String) {
        connected = true
    }

    fun disconnect() {
        connected = false
    }

    fun write(data:ByteArray) {
        // Send BLE packet
    }

    fun enableNotify() {
        // Enable notification
    }
}