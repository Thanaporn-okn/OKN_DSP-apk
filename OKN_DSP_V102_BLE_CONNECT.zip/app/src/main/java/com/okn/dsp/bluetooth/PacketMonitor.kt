package com.okn.dsp.bluetooth

object PacketMonitor {

    fun tx(data:ByteArray):String {
        return data.joinToString(" ") {
            "%02X".format(it)
        }
    }

    fun rx(data:ByteArray):String {
        return data.joinToString(" ") {
            "%02X".format(it)
        }
    }
}