package com.okn.dsp.ui

class BLEConnectScreen {
    // Device List
    // Scan Button
    // Connect Button
    // TX/RX Monitor
}