OKN_DSP V1.0.2 BLE CONNECT

Added:
- BLE Manager base
- Device connection flow
- TX/RX packet monitor
- BLE test screen base

Next:
- Real packet capture
- BP1048P4 command map