OKN DSP V37 — PRE-AUTH RANDKEY AOT TRACE + VERIFIED READBACK BASE

STATUS
- Project readiness: ~97% (unchanged until standalone current-session RandKey is proven).
- BLE AB00/AB01/AB02/AB03: verified.
- AUTH16 -> RESPONSE32: verified on repeated live sessions.
- Post-auth AES-CFB8: verified from official same-session evidence.
- Device Description: 18,150-byte JSON recovered and parsed.
- Readback: READ 0x58 / RESPONSE 0x60 verified with 83 paired records.
- 15 actuators + 4 sensors mapped from the real descriptor.
- DSP WRITE 0x57 remains LOCKED.

WHAT V37 ADDS
1. RandKeyPreAuthLab.kt
   - compares every response32 tail with its same-session official RandKey.
   - computes C[i] XOR K[i] across paired vectors.
   - rejects a simple fixed 16-byte XOR transform unless all positions are invariant.
   - never invents a key/IV/KDF.

2. Evidence Lab button:
   PRE-AUTH RANDKEY TRACE REPORT (READ-ONLY)

3. GitHub Actions AOT trace job
   - extracts libapp.so/libflutter.so from the included 250401 reference APK.
   - runs Blutter on ARM64 runner.
   - collects RandKey/auth/AES-CFB8 object and assembly context.
   - packages a separate analysis artifact for the next decode step.

4. Existing V35 device-description/readback proof is preserved.

BUILD / MOBILE FLOW
- Upload OKN_DSP_ANDROID_V37_PREAUTH_RANDKEY_TRACE.zip to repository root.
- Upload build-okn-dsp-v37.yml to .github/workflows/.
- Push triggers build automatically; workflow_dispatch is also supported.
- Download APK artifact: OKN-DSP-V37-PREAUTH-RANDKEY-TRACE-debug-apk
- Download analysis artifact: OKN-DSP-V37-AOT-RANDKEY-TRACE

SAFETY
- No guessed DSP actuator writes.
- No automatic LIVE WRITE.
- Auth16 capture probe remains the only BLE startup replay in the Evidence Lab.
- AOT analysis is static/read-only.
