package com.okn.dsp.protocol

import com.okn.dsp.protocol.ByteCodec.toHex

/**
 * V37 read-only pre-auth analysis.
 * Uses only already captured paired vectors. It does not transmit BLE packets and
 * deliberately refuses to claim a RandKey transform until one rule explains all pairs.
 */
object RandKeyPreAuthLab {
    data class PairStats(
        val label: String,
        val encryptedTailHex: String,
        val randKeyHex: String,
        val xorHex: String,
    )

    val stats: List<PairStats> = AuthVectorLab.pairedVectors.map { v ->
        val response = ByteCodec.hexToBytes(v.response32Hex)
        val encryptedTail = response.copyOfRange(16, 32)
        val key = ByteCodec.hexToBytes(v.randKeyHex)
        val xor = ByteArray(16) { i -> (encryptedTail[i].toInt() xor key[i].toInt()).toByte() }
        PairStats(v.label, encryptedTail.toHex(), key.toHex(), xor.toHex())
    }

    /** Byte positions whose C[i] XOR K[i] value is identical across all paired sessions. */
    val invariantXorPositions: List<Pair<Int, Int>> = (0 until 16).mapNotNull { i ->
        val values = stats.map { ByteCodec.hexToBytes(it.xorHex)[i].toInt() and 0xff }.distinct()
        if (values.size == 1) i to values.first() else null
    }

    val fixedXorTransformVerified: Boolean = invariantXorPositions.size == 16
    val automaticRandKeyVerified: Boolean = false

    fun report(): List<String> = buildList {
        add("V37 PRE-AUTH RANDKEY LAB • paired vectors=${stats.size}")
        stats.forEach { s ->
            add("${s.label} • encTail=${s.encryptedTailHex}")
            add("${s.label} • RandKey=${s.randKeyHex}")
            add("${s.label} • CxorK=${s.xorHex}")
        }
        val invariantText = invariantXorPositions.joinToString { pair ->
            "${pair.first}:0x%02X".format(pair.second)
        }
        add("Invariant XOR positions=$invariantText")
        add("Fixed bytewise XOR transform=${if (fixedXorTransformVerified) "SUPPORTED" else "REJECTED by paired vectors"}")
        add("Observed invariant at byte0 (0x5C) is evidence only; it is not sufficient to derive 16-byte RandKey.")
        add("AUTO RANDKEY=${if (automaticRandKeyVerified) "VERIFIED" else "LOCKED"}")
        add("Next evidence target: recover the libapp.so auth-response -> RandKey call site / transform without guessing.")
        add("DSP WRITE 0x57 remains disabled. READ-ONLY evidence path only.")
    }
}
