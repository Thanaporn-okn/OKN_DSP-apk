#!/usr/bin/env python3
"""V30 compile-only portable-core toolchain acceptance probe.

This tool NEVER links, executes target code, emits firmware images, or performs
hardware/programmer I/O. A PASS means only that the compiler accepts the C11
ABI/numeric assumptions required by the portable core.
"""
from pathlib import Path
import argparse, json, shutil, subprocess, tempfile, sys

ROOT = Path(__file__).resolve().parents[1]

def main() -> int:
    ap = argparse.ArgumentParser(description="Compile-only OKN V30 toolchain contract probe; non-authorizing.")
    ap.add_argument("--cc", required=True, help="compiler executable/path")
    ap.add_argument("--flag", action="append", default=[], help="extra compiler flag (repeatable)")
    args = ap.parse_args()
    cc = shutil.which(args.cc) if "/" not in args.cc else args.cc
    result = {
        "schema": 1,
        "project_version": 30,
        "compiler": args.cc,
        "compiler_resolved": cc,
        "compile_contract_pass": False,
        "compile_only": True,
        "linker_invoked": False,
        "target_code_executed": False,
        "firmware_image_emitted": False,
        "hardware_io_performed": False,
        "authorizes_hardware": False,
        "authorizes_mobile_flash": False,
        "required_assumptions": [
            "CHAR_BIT=8", "uint8_t=8", "uint16_t=16", "uint32_t=32",
            "int32_t=32", "float=IEEE754-binary32-compatible"
        ],
    }
    if not cc:
        result["error"] = "compiler not found"
        print(json.dumps(result, sort_keys=True))
        return 2
    try:
        ver = subprocess.run([cc, "--version"], text=True, capture_output=True, timeout=10)
        result["compiler_version_first_line"] = (ver.stdout or ver.stderr).splitlines()[0] if (ver.stdout or ver.stderr) else "unknown"
        with tempfile.TemporaryDirectory(prefix="okn-v30-toolchain-") as td:
            out = Path(td) / "probe.o"
            cmd = [cc, "-std=c11", "-Wall", "-Wextra", "-Werror", "-pedantic", "-Isrc", *args.flag,
                   "-c", "tests/toolchain_compile_probe.c", "-o", str(out)]
            cp = subprocess.run(cmd, cwd=ROOT, text=True, capture_output=True, timeout=30)
            result["compiler_returncode"] = cp.returncode
            if cp.stdout: result["stdout"] = cp.stdout[-4000:]
            if cp.stderr: result["stderr"] = cp.stderr[-4000:]
            result["compile_contract_pass"] = (cp.returncode == 0 and out.exists())
    except Exception as e:
        result["error"] = f"{type(e).__name__}: {e}"
    print(json.dumps(result, sort_keys=True))
    return 0 if result["compile_contract_pass"] else 1

if __name__ == "__main__":
    raise SystemExit(main())
