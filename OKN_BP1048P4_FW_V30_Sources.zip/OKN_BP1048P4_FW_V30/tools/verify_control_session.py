#!/usr/bin/env python3
from pathlib import Path
import sys
root=Path(__file__).resolve().parents[1]
h=(root/'src/transport/okn_control_session.h').read_text()
c=(root/'src/transport/okn_control_session.c').read_text()
fm=(root/'firmware_manifest.json').read_text()
errors=[]
for sym in ('okn_control_session_execute','okn_control_session_reset','duplicate_replays','cached_request'):
    if sym not in h+c: errors.append('missing control-session symbol: '+sym)
if 'memcmp(session->cached_request, request, request_len)' not in c:
    errors.append('duplicate detection must compare exact request bytes')
if 'okn_protocol_execute_ex' not in c:
    errors.append('session must use separated protocol execution result')
if 'uint8_t encoded[OKN_CONTROL_MAX_FRAME]' not in c:
    errors.append('session must execute into full internal response buffer')
if '"single_outstanding_request": true' not in fm:
    errors.append('firmware manifest must declare serialized request contract')
if '"exact_duplicate_response_cache": true' not in fm:
    errors.append('firmware manifest must declare duplicate response cache')
if errors:
    [print('BLOCKED:',e) for e in errors]; sys.exit(1)
print('PASS: V30 control-session retry idempotence is explicit and portable')
