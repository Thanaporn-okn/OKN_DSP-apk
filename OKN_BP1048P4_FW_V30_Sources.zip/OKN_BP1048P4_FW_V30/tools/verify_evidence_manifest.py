#!/usr/bin/env python3
from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'evidence_manifest.json').read_text())
errors=[]
if m.get('schema')!=4: errors.append('evidence schema must be 4')
if m.get('project_version')!=30: errors.append('project_version must be 30')
if m.get('target')!='BP1048P4' or m.get('board')!='GoloPine 7CH': errors.append('target/board mismatch')
if m.get('policy')!='FAIL_CLOSED_NO_INFERENCE': errors.append('policy mismatch')
if m.get('hardware_authorized') is not False: errors.append('hardware_authorized must be false')
req=m.get('required_exact_evidence',{})
if any(bool(v) for v in req.values()): errors.append('V30 exact evidence flags must all remain false')
prov=m.get('provenance',{})
if prov.get('previous_source_sha256')!='ebd7d5f17669390398cb091792f85e9bb0731c9616aa764ff646c300b6f5a8b7': errors.append('V29 source provenance mismatch')
if prov.get('validation_zip_sha256')!='f778e7b3dd301c79afbb5ea8c9dd080387e3f25b1cc78bc743393a9c9e08530e': errors.append('V29 validation provenance mismatch')
if not any(o.get('id')=='v29-ci-validation' for o in m.get('observations',[])): errors.append('V29 CI observation missing')
for ob in m.get('observations',[]):
    if ob.get('authorizes') not in ([],None): errors.append('observations may not authorize hardware in V30')
if errors:
    [print('BLOCKED:',e) for e in errors]; sys.exit(1)
print('PASS: V30 evidence manifest is internally consistent and non-authorizing')
