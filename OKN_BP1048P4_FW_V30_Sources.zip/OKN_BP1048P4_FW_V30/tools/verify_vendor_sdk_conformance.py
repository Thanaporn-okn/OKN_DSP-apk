#!/usr/bin/env python3
from pathlib import Path
import json, sys
ROOT=Path(__file__).resolve().parents[1]
errors=[]
m=json.loads((ROOT/"vendor_sdk_binding_manifest.json").read_text())
h=(ROOT/"src/portability/okn_vendor_sdk_binding_contract.h").read_text()
t=(ROOT/"tools/vendor_sdk_conformance.py").read_text()
p=(ROOT/"tests/vendor_sdk_binding_probe.c").read_text()
if m.get("project_version")!=30 or m.get("schema")!=1: errors.append("binding manifest version/schema mismatch")
if m.get("state")!="LOCKED_NO_EXACT_VENDOR_BINDING": errors.append("binding manifest must remain locked")
if m.get("authorizes_hardware") is not False or m.get("authorizes_mobile_flash") is not False: errors.append("binding manifest must remain non-authorizing")
for token in ["OKN_VENDOR_BINDING_ABI","OKN_VENDOR_EVIDENCE_EXACT_BP1048P4","OKN_VENDOR_EVIDENCE_EXACT_GOLOPINE_BOARD"]:
    if token not in h or token not in p: errors.append("missing contract token: "+token)
if '"-c"' not in t: errors.append("SDK conformance tool must compile-only with -c")
for forbidden in ["objcopy", "openocd", "flashrom"]:
    if forbidden in t.lower(): errors.append("unexpected programmer/build-image token: "+forbidden)
if errors:
    for e in errors: print("BLOCKED:",e)
    sys.exit(1)
print("PASS: V30 vendor SDK adapter conformance is compile-only, exact-target-gated, and non-authorizing")
