# OKN_BP1048P4_FW_V30

V30 is a vendor-SDK adapter conformance hardening revision of the portable clean-room
firmware foundation. Protocol V2 and persistence schema 2 remain unchanged.

## What V30 adds

- Compile-only vendor SDK binding contract and probe.
- Locked `vendor_sdk_binding_manifest.json` with no exact-target binding shipped.
- Family/B1 ABI-shape test that is explicitly rejected as exact BP1048P4/GoloPine evidence.
- Synthetic exact-target fixture only for gate regression testing; it never authorizes hardware.
- GCC/Clang conformance self-test.
- V29 GitHub validation bound as the immediate predecessor.

## Safety status

This package is **not** a BP1048P4/GoloPine flash image. It adds no target register
address, board pin, programmer packet, boot command, linker map, or image format.
Hardware and mobile flashing remain locked until reviewed exact-target evidence is
integrated in a later version.

Run:

```sh
make host-test
```
