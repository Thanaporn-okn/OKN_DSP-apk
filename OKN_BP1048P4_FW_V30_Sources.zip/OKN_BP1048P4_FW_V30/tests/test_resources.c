#include "../src/dsp/okn_audio_engine.h"
#include "../src/core/okn_controller.h"
#include "../src/persist/okn_persistence.h"
#include "../src/transport/okn_control_session.h"
#include <assert.h>
#include <stdio.h>

int main(void) {
    assert(sizeof(float) == 4u);
    assert(okn_audio_engine_required_delay_arena_samples() == OKN_AUDIO_REF_DELAY_ARENA_SAMPLES);

    /* The engine object must no longer embed the 7CH x 50 ms delay arena. */
    assert(sizeof(okn_audio_engine_t) < OKN_AUDIO_REF_DELAY_ARENA_BYTES);
    assert(OKN_AUDIO_REF_DELAY_ARENA_SAMPLES ==
           (size_t)OKN_CHANNELS * (size_t)(OKN_AUDIO_REF_MAX_DELAY_SAMPLES + 1u));

    printf("V30 RESOURCE REPORT\n");
    printf("sizeof(okn_audio_engine_t)=%zu\n", sizeof(okn_audio_engine_t));
    printf("sizeof(okn_audio_lane_t)=%zu\n", sizeof(okn_audio_lane_t));
    printf("sizeof(okn_controller_t)=%zu\n", sizeof(okn_controller_t));
    printf("sizeof(okn_dsp_state_t)=%zu\n", sizeof(okn_dsp_state_t));
    printf("delay_arena_samples=%zu\n", OKN_AUDIO_REF_DELAY_ARENA_SAMPLES);
    printf("delay_arena_bytes=%zu\n", OKN_AUDIO_REF_DELAY_ARENA_BYTES);
    printf("persistence_image_bytes=%u\n", (unsigned)OKN_PERSIST_IMAGE_SIZE);
    printf("sizeof(okn_control_session_t)=%zu\n", sizeof(okn_control_session_t));
    printf("control_session_cached_frame_bytes=%u\n", (unsigned)(OKN_CONTROL_MAX_FRAME * 2u));
    printf("NOTE=host ABI sizes only; no BP1048P4 RAM capacity is inferred\n");
    puts("ALL V30 RESOURCE TESTS PASS");
    return 0;
}
