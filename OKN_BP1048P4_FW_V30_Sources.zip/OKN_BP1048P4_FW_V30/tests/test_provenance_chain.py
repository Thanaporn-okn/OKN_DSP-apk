#!/usr/bin/env python3
from pathlib import Path
import copy,json,sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from verify_provenance_chain import verify

chain=json.loads((ROOT/'provenance_chain_manifest.json').read_text())
fw=json.loads((ROOT/'firmware_manifest.json').read_text())
ev=json.loads((ROOT/'evidence_manifest.json').read_text())
assert verify(chain,fw,ev)==[]

x=copy.deepcopy(chain); x['previous']['version']=24
assert any('current version - 1' in e for e in verify(x,fw,ev))

x=copy.deepcopy(chain); x['previous']['source_sha256']='0'*64
assert any('source hash mismatch' in e for e in verify(x,fw,ev))

x=copy.deepcopy(chain); x['previous']['validation_sha256']='f'*64
assert any('validation hash mismatch' in e for e in verify(x,fw,ev))

x=copy.deepcopy(ev); x['observations']=[o for o in x['observations'] if o.get('id')!='v29-ci-validation']
assert any('immediate predecessor CI observation' in e for e in verify(chain,fw,x))

x=copy.deepcopy(fw); x['provenance']['previous_version']=24
assert any('firmware_manifest previous_version mismatch' in e for e in verify(chain,x,ev))

print('ALL V30 PROVENANCE CHAIN TESTS PASS')
