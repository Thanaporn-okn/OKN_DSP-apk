# OKN DSP V33 — Phase 2 real-time Frequency / Q / Gain

Base: **V32**, which the user confirmed on real hardware for Master Volume and low-latency EQ Gain. V33 keeps the accepted V29/V30 UI and the V31/V32 authenticated BLE transport unchanged, then extends the proven EQ fast lane to Frequency and Q for the hardware records that are independently identifiable as type-12 PEAKING filters.

## V33 change

The supplied Device Description contains type-12 PEAKING records with complete `F / Q / B / B0 / B1 / B2 / A1 / A2` data. A captured record at `650 Hz / Q 0.3 / +12 dB` is reproduced by the V33 44.1 kHz coefficient calculation to float precision. V33 therefore rebuilds the complete 48-byte record when Frequency, Q, or Gain moves.

### Real-time policy
- **Bands 2..15**: Frequency + Q + Gain LIVE.
- **Band 1**: Gain LIVE only. The real DSP uses a special native filter there (type17 Tone Control on CH1/2/4/5/6/7 and type3 General Low-pass on CH3), so V33 does not pretend that the generic Frequency/Q sliders have verified semantics for that record.
- EQ writes keep the **V32 45 ms latest-value lane**, one GATT write in flight at a time, with continuous AES-CFB8 packet ordering.
- Reset EQ preserves Band 1 live Frequency/Q, resets Band 1 Gain, and sends Bands 2..15 Frequency/Q/Gain.

## Existing verified live functions retained
- AB00 service / AB01 TX / AB02 notify.
- AUTH16 → AUTH32 → per-session RandKey → AES/CFB8 authenticated stream.
- Device Description health gate before audio writes.
- Master Volume ID2 LIVE.
- Bass Volume ID8 LIVE.
- Bass Cutoff ID9 LIVE.
- EQ Gain LIVE on all V17-qualified records.

## Still deliberately locked
- `Volume Ch1-Ch7`: no verified standalone actuator mapping.
- Band 1 Frequency/Q: native special-filter semantics are not mapped to the generic UI controls.
- Automatic permanent `SaveParams`: not enabled.

## Offline verification
- Recovered runtime `DspProtocol.java`: compiles with Java 17.
- Captured type-12 PEAKING coefficient vector: PASS.
- Modular `ProtocolSelfTest`: PASS.
- EQ UFE packet size: 57 bytes.

versionName: **33.0.0**  
versionCode: **1033**  
Phase: **2 — authenticated real-time DSP control**
