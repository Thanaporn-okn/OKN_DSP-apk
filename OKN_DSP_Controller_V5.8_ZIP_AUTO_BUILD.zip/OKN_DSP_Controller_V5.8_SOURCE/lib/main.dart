import 'package:flutter/material.dart';

void main(){
  runApp(const OKNDSP());
}

class OKNDSP extends StatelessWidget{
  const OKNDSP({super.key});

  @override
  Widget build(BuildContext context){
    return MaterialApp(
      debugShowCheckedModeBanner:false,
      theme:ThemeData.dark(),
      home:const Scaffold(
        body:Center(
          child:Text('OKN DSP Controller V5.8\nZIP AUTO BUILD'),
        ),
      ),
    );
  }
}
