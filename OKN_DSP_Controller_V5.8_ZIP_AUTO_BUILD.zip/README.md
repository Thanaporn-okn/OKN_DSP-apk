OKN DSP Controller V5.8 ZIP AUTO BUILD

วิธีใช้มือถือ:
1. Upload ZIP ไฟล์นี้เข้า GitHub
2. Run Actions
3. ระบบจะแตก ZIP และ Build APK อัตโนมัติ
