# OKN DSP V6 — Phase 1 EQ color refresh

V6 is a new version created from V5 to add richer visual color to the EQ page. It does not overwrite V5.

## V6 EQ changes
- Ch1–Ch7 tabs now use distinct channel colors; the active channel is solid and inactive channels use a soft tint.
- EQ graph line follows the active channel color.
- All 15 EQ band points use a spectrum palette so each band is easier to identify.
- The selected band highlight and band badge use that band's color.
- Frequency, Q and Gain Band controls have separate Cyan / Purple / Orange colors, including icons, value pills, slider fills and knobs.
- Reset EQ uses a soft red warning treatment; Preset controls retain their existing function and persistence behavior.
- Light, Dark and Midnight themes remain supported and the new colors adapt through alpha/tint changes.
- All controls remain code-rendered; no screenshot/image is used as a background.
- Phase 2 DSP hardware transport remains intentionally unimplemented until real protocol/control data is supplied.

Build input: `OKN_DSP_V6_Sources.zip` using the existing `OKN_DSP_AutoBuild.yml`.
