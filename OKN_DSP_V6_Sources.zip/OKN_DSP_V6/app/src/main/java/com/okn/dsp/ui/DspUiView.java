package com.okn.dsp.ui;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Build;
import android.view.DisplayCutout;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowInsets;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Entire Phase-1 UI is rendered from Canvas primitives.
 * The uploaded design image is NOT bundled or painted as a background.
 */
public final class DspUiView extends View {
    private static final int WHITE = Color.rgb(245, 249, 255);
    private static final int MUTED = Color.rgb(169, 188, 216);
    private static final int BLUE = Color.rgb(30, 167, 255);
    private static final int CYAN = Color.rgb(0, 218, 255);
    private static final int GREEN = Color.rgb(0, 222, 157);
    private static final int PURPLE = Color.rgb(172, 72, 255);
    private static final int ORANGE = Color.rgb(255, 177, 65);
    private static final int CARD = Color.rgb(6, 40, 75);
    private static final int CARD_2 = Color.rgb(9, 48, 87);
    private static final int BORDER = Color.rgb(21, 89, 139);
    private static final int GRID = Color.rgb(23, 69, 105);

    private static final int C_NAV = 1;
    private static final int C_HEADER_SETTINGS = 2;
    private static final int C_HOME_INPUT = 3;
    private static final int C_HOME_QUICK = 4;
    private static final int C_MIX = 10;
    private static final int C_EQ_CHANNEL = 20;
    private static final int C_EQ_GRAPH = 21;
    private static final int C_EQ_SLIDER = 22;
    private static final int C_EQ_NUDGE = 23;
    private static final int C_EQ_SAVE = 24;
    private static final int C_EQ_LOAD = 25;
    private static final int C_EQ_MORE = 26;
    private static final int C_XO_CUTOFF = 30;
    private static final int C_XO_TYPE = 31;
    private static final int C_XO_SLOPE = 32;
    private static final int C_XO_DELAY = 33;
    private static final int C_XO_LINK = 34;
    private static final int C_XO_VIEW = 35;
    private static final int C_XO_RESET = 36;
    private static final int C_XO_AUTO = 37;
    private static final int C_XO_PRESET = 38;
    private static final int C_MODAL_CLOSE = 50;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final List<Control> controls = new ArrayList<>();
    private final DspUiState s = new DspUiState();
    private final SharedPreferences prefs;

    private Control active;
    private float downX;
    private float downY;
    private float startValue;
    private int safeTop;
    private int safeBottom;
    private int safeLeft;
    private int safeRight;
    private long messageUntil;
    private String message = "";
    private String modal = null;
    private boolean hostActive = true;
    private boolean renderSafeMode = false;
    private String lastUiError = "";

    public DspUiView(Context context) {
        super(context);
        setFocusable(true);
        setClickable(true);
        prefs = context.getSharedPreferences("okn_dsp_phase1", Context.MODE_PRIVATE);
        migrateLegacyPreferences(context);
        String session = prefs.getString("session", null);
        if (session != null) s.restoreSession(session);
        stroke.setStyle(Paint.Style.STROKE);
        p.setDither(true);
        p.setSubpixelText(true);
        stroke.setDither(true);
        setBackgroundColor(Color.BLACK);
    }

    @Override
    public WindowInsets onApplyWindowInsets(WindowInsets insets) {
        safeTop = safeBottom = safeLeft = safeRight = 0;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            DisplayCutout cutout = insets.getDisplayCutout();
            if (cutout != null) {
                safeTop = cutout.getSafeInsetTop();
                safeBottom = cutout.getSafeInsetBottom();
                safeLeft = cutout.getSafeInsetLeft();
                safeRight = cutout.getSafeInsetRight();
            }
        }
        invalidate();
        return insets;
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        if (renderSafeMode) {
            drawSafeFallback(c);
            return;
        }
        try {
            controls.clear();
            drawBackground(c);
            drawHeader(c);
            switch (s.page) {
                case DspUiState.PAGE_MIX -> drawMix(c);
                case DspUiState.PAGE_EQ -> drawEq(c);
                case DspUiState.PAGE_CROSSOVER -> drawCrossover(c);
                default -> drawHome(c);
            }
            drawBottomNav(c);
            if (modal != null) drawModal(c);
            if (System.currentTimeMillis() < messageUntil) drawMessage(c);

            // V2 deliberately avoids a permanent animation loop. UI redraws are event-driven.
            if (hostActive && messageUntil > System.currentTimeMillis()) postInvalidateDelayed(100L);
        } catch (Throwable error) {
            renderSafeMode = true;
            controls.clear();
            lastUiError = error.getClass().getSimpleName();
            drawSafeFallback(c);
        }
    }

    public void setHostActive(boolean active) {
        hostActive = active;
        if (active) invalidate();
    }

    public void showStartupDiagnostic(String diagnostic) {
        if (diagnostic == null || diagnostic.isEmpty()) return;
        message = diagnostic.length() > 88 ? diagnostic.substring(0, 88) + "…" : diagnostic;
        messageUntil = System.currentTimeMillis() + 5000L;
        invalidate();
    }

    private void drawSafeFallback(Canvas c) {
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.rgb(2, 14, 29));
        c.drawRect(0, 0, Math.max(1f, W()), Math.max(1f, H()), p);
        text(c, "OKN_DSP", Math.max(1f, W()) * .5f, Math.max(1f, H()) * .42f, Math.max(18f, ts(.055f)), WHITE, Paint.Align.CENTER, true);
        text(c, "UI recovery mode", Math.max(1f, W()) * .5f, Math.max(1f, H()) * .49f, Math.max(14f, ts(.026f)), ORANGE, Paint.Align.CENTER, true);
        String detail = lastUiError.isEmpty() ? "Rendering recovered safely." : "Recovered from: " + lastUiError;
        text(c, detail, Math.max(1f, W()) * .5f, Math.max(1f, H()) * .55f, Math.max(11f, ts(.018f)), MUTED, Paint.Align.CENTER, false);
    }

    private float W() { return getWidth(); }
    private float H() { return getHeight(); }
    private float base() { return Math.min(W(), H()); }
    private float pad() { return Math.max(12f, base() * 0.025f); }
    private float navH() { return Math.max(base() * 0.135f, H() * 0.078f); }
    private float headerH() { return Math.max(base() * 0.145f, H() * 0.092f); }
    private float contentTop() { return safeTop + headerH(); }
    private float contentBottom() { return H() - safeBottom - navH(); }
    private float contentH() { return Math.max(1f, contentBottom() - contentTop()); }
    private float cx(float f) { return safeLeft + (W() - safeLeft - safeRight) * f; }
    private float cy(float f) { return contentTop() + contentH() * f; }
    private float ts(float f) { return Math.max(10f, base() * f); }

    private void drawBackground(Canvas c) {
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0, 0, 0, H(), Color.rgb(7, 28, 61), Color.rgb(1, 9, 22), Shader.TileMode.CLAMP));
        c.drawRect(0, 0, W(), H(), p);
        p.setShader(null);

        // Procedural mountain silhouettes: vector-only, not an image background.
        float horizon = safeTop + headerH() * 0.80f;
        path.reset();
        path.moveTo(0, horizon + base() * 0.05f);
        path.lineTo(W() * .08f, horizon - base() * .015f);
        path.lineTo(W() * .16f, horizon + base() * .02f);
        path.lineTo(W() * .28f, horizon - base() * .055f);
        path.lineTo(W() * .38f, horizon + base() * .01f);
        path.lineTo(W() * .52f, horizon - base() * .07f);
        path.lineTo(W() * .66f, horizon + base() * .012f);
        path.lineTo(W() * .80f, horizon - base() * .05f);
        path.lineTo(W(), horizon + base() * .02f);
        path.lineTo(W(), horizon + base() * .16f);
        path.lineTo(0, horizon + base() * .16f);
        path.close();
        p.setColor(Color.rgb(5, 27, 55));
        c.drawPath(path, p);

        // Gentle blue halo.
        p.setShader(new RadialGradient(W() * .52f, H() * .25f, W() * .55f,
                Color.argb(80, 0, 115, 255), Color.TRANSPARENT, Shader.TileMode.CLAMP));
        c.drawCircle(W() * .52f, H() * .25f, W() * .55f, p);
        p.setShader(null);
    }

    private void drawHeader(Canvas c) {
        float left = pad() + safeLeft;
        float top = safeTop + Math.max(7f, headerH() * .10f);
        text(c, "OKN_", left, top + headerH() * .32f, ts(.068f), WHITE, Paint.Align.LEFT, true);
        float logoOffset = measure("OKN_", ts(.068f), true);
        text(c, "DSP", left + logoOffset, top + headerH() * .32f, ts(.068f), BLUE, Paint.Align.LEFT, true);
        text(c, "S O U N D   I N   H I G H E R   D E F I N I T I O N", left, top + headerH() * .55f,
                ts(.020f), MUTED, Paint.Align.LEFT, false);

        float gearR = base() * .022f;
        float gx = W() - safeRight - pad() - gearR;
        float gy = top + gearR;
        drawGear(c, gx, gy, gearR, WHITE);
        addControl(C_HEADER_SETTINGS, 0, 0, new RectF(gx - gearR * 1.8f, gy - gearR * 1.8f, gx + gearR * 1.8f, gy + gearR * 1.8f), 0, 1, false, false);

        float chipW = base() * .23f;
        float chipH = base() * .068f;
        float chipR = chipH * .5f;
        float right = W() - safeRight - pad();
        float chipTop = top + headerH() * .39f;
        round(c, right - chipW, chipTop, right, chipTop + chipH, chipR, Color.argb(135, 2, 30, 58), Color.argb(180, 15, 83, 126), 1.2f);
        p.setColor(GREEN);
        c.drawCircle(right - chipW + chipH * .33f, chipTop + chipH * .5f, chipH * .12f, p);
        text(c, "V6 UI", right - chipH * .25f, chipTop + chipH * .64f, ts(.024f), GREEN, Paint.Align.RIGHT, true);
    }

    private void drawHome(Canvas c) {
        RectF device = rect(.035f, .025f, .965f, .525f);
        panel(c, device, 18f);
        text(c, "DSP DEVICE", device.left + pad() * .55f, device.top + ts(.040f), ts(.020f), MUTED, Paint.Align.LEFT, true);
        text(c, "OKN DSP-8 Pro", device.left + pad() * .55f, device.top + ts(.095f), ts(.050f), WHITE, Paint.Align.LEFT, true);
        text(c, "8-Channel Digital Signal Processor", device.left + pad() * .55f, device.top + ts(.132f), ts(.025f), MUTED, Paint.Align.LEFT, false);

        drawDspBox(c, device.left + device.width() * .05f, device.top + device.height() * .35f,
                device.width() * .52f, device.height() * .43f);
        float sx = device.left + device.width() * .65f;
        float sy = device.top + device.height() * .27f;
        float row = device.height() * .17f;
        statusLine(c, sx, sy, BLUE, "Bluetooth", "Phase 2 transport pending", 0);
        statusLine(c, sx, sy + row, GREEN, "Excellent", "UI response", 1);
        statusLine(c, sx, sy + row * 2, GREEN, "100%", "Interface ready", 2);
        statusLine(c, sx, sy + row * 3, CYAN, "v6.0.0", "Phase 1 Final", 3);

        RectF input = rect(.035f, .545f, .965f, .705f);
        panel(c, input, 16f);
        text(c, "INPUT SOURCE", input.left + pad() * .5f, input.top + ts(.032f), ts(.018f), MUTED, Paint.Align.LEFT, true);
        String[] names = {"Bluetooth", "AUX", "Optical", "USB"};
        for (int i = 0; i < 4; i++) {
            float gap = input.width() * .018f;
            float bw = (input.width() - gap * 5) / 4f;
            float l = input.left + gap + i * (bw + gap);
            RectF b = new RectF(l, input.top + input.height() * .28f, l + bw, input.bottom - input.height() * .10f);
            int col = s.inputSource == i ? BLUE : Color.argb(150, 12, 48, 82);
            round(c, b.left, b.top, b.right, b.bottom, b.height() * .18f, col, s.inputSource == i ? CYAN : BORDER, 1.2f);
            drawSourceIcon(c, i, b.centerX(), b.top + b.height() * .31f, b.height() * .19f, s.inputSource == i ? WHITE : MUTED);
            text(c, names[i], b.centerX(), b.bottom - b.height() * .16f, ts(.021f), WHITE, Paint.Align.CENTER, true);
            addControl(C_HOME_INPUT, i, 0, b, 0, 1, false, false);
        }

        RectF quick = rect(.035f, .725f, .965f, .94f);
        panel(c, quick, 16f);
        text(c, "QUICK ACTIONS", quick.left + pad() * .5f, quick.top + ts(.030f), ts(.018f), MUTED, Paint.Align.LEFT, true);
        String[] q = {"Load Preset", "Save Preset", "Device Settings", "About Device"};
        String[] sub = {"Recall saved setup", "Save current setup", "Advanced options", "Info & support"};
        int[] cols = {PURPLE, BLUE, GREEN, ORANGE};
        for (int i = 0; i < 4; i++) {
            int r = i / 2, col = i % 2;
            float gap = quick.width() * .02f;
            float bw = (quick.width() - gap * 3) / 2f;
            float bh = quick.height() * .31f;
            float l = quick.left + gap + col * (bw + gap);
            float t = quick.top + quick.height() * .22f + r * (bh + quick.height() * .06f);
            RectF b = new RectF(l, t, l + bw, t + bh);
            round(c, b.left, b.top, b.right, b.bottom, b.height() * .18f, Color.argb(160, 8, 48, 84), blend(cols[i], Color.BLACK, .42f), 1.2f);
            c.drawCircle(b.left + b.height() * .28f, b.centerY(), b.height() * .19f, solid(Color.argb(130, Color.red(cols[i]), Color.green(cols[i]), Color.blue(cols[i]))));
            drawQuickIcon(c, i, b.left + b.height() * .28f, b.centerY(), b.height() * .12f, WHITE);
            text(c, q[i], b.left + b.height() * .55f, b.top + b.height() * .42f, ts(.021f), WHITE, Paint.Align.LEFT, true);
            text(c, sub[i], b.left + b.height() * .55f, b.top + b.height() * .70f, ts(.016f), MUTED, Paint.Align.LEFT, false);
            text(c, "›", b.right - b.height() * .18f, b.centerY() + ts(.012f), ts(.040f), MUTED, Paint.Align.CENTER, false);
            addControl(C_HOME_QUICK, i, 0, b, 0, 1, false, false);
        }

        RectF premium = rect(.035f, .952f, .965f, .995f);
        round(c, premium.left, premium.top, premium.right, premium.bottom, premium.height() * .32f,
                Color.argb(120, 10, 36, 74), Color.argb(130, 20, 85, 180), 1f);
        drawWaveform(c, premium, BLUE, 0f);
        text(c, "Premium Sound Experience", premium.centerX(), premium.centerY() - ts(.002f), ts(.017f), WHITE, Paint.Align.CENTER, true);
        text(c, "Precision Audio. In Your Hands.", premium.centerX(), premium.centerY() + ts(.018f), ts(.014f), MUTED, Paint.Align.CENTER, false);
    }

    private void drawMix(Canvas c) {
        text(c, "Mix", cx(.045f), cy(.065f), ts(.055f), WHITE, Paint.Align.LEFT, true);
        text(c, "Real-time mixing and tone control", cx(.045f), cy(.102f), ts(.024f), MUTED, Paint.Align.LEFT, false);
        RectF wave = new RectF(cx(.66f), cy(.035f), cx(.95f), cy(.11f));
        drawWaveform(c, wave, BLUE, 0.18f);
        text(c, "LIVE AUDIO CONTROL", wave.centerX(), wave.bottom + ts(.022f), ts(.014f), MUTED, Paint.Align.CENTER, true);

        drawMixSliderCard(c, rect(.035f, .14f, .965f, .275f), 0, PURPLE, "Master Volume", "Control overall output level", s.masterVolume, -60f, 0f, "dB");
        drawMixSliderCard(c, rect(.035f, .295f, .965f, .43f), 1, CYAN, "Bass Volume", "Adjust bass channel level", s.bassVolume, -20f, 20f, "dB");

        drawKnobCard(c, rect(.035f, .455f, .492f, .695f), 2, GREEN, "Bass Cutoff", "Low-pass filter cutoff", s.bassCutoff, 20f, 300f, "Hz");
        drawKnobCard(c, rect(.508f, .455f, .965f, .695f), 3, PURPLE, "Bass Boost", "Boost low frequencies", s.bassBoost, -12f, 12f, "dB");
        drawKnobCard(c, rect(.035f, .715f, .492f, .955f), 4, BLUE, "Middle Boost", "Boost mid frequencies", s.middleBoost, -12f, 12f, "dB");
        drawKnobCard(c, rect(.508f, .715f, .965f, .955f), 5, ORANGE, "Treble Boost", "Boost high frequencies", s.trebleBoost, -12f, 12f, "dB");
    }

    private void drawMixSliderCard(Canvas c, RectF r, int index, int accent, String title, String sub, float value, float min, float max, String unit) {
        panel(c, r, 16f);
        float iconR = r.height() * .22f;
        c.drawCircle(r.left + r.height() * .28f, r.top + r.height() * .34f, iconR, solid(Color.argb(150, Color.red(accent), Color.green(accent), Color.blue(accent))));
        drawSpeaker(c, r.left + r.height() * .28f, r.top + r.height() * .34f, iconR * .75f, WHITE);
        text(c, title, r.left + r.height() * .56f, r.top + r.height() * .28f, ts(.028f), WHITE, Paint.Align.LEFT, true);
        text(c, sub, r.left + r.height() * .56f, r.top + r.height() * .48f, ts(.019f), MUTED, Paint.Align.LEFT, false);
        valueChip(c, r.right - r.width() * .19f, r.top + r.height() * .16f, r.width() * .16f, r.height() * .31f,
                formatValue(value, unit), accent);
        RectF tr = new RectF(r.left + r.width() * .055f, r.top + r.height() * .70f, r.right - r.width() * .055f, r.top + r.height() * .82f);
        slider(c, tr, value, min, max, accent, false);
        text(c, formatValue(min, unit), tr.left, r.bottom - r.height() * .07f, ts(.016f), MUTED, Paint.Align.LEFT, false);
        text(c, formatValue(max, unit), tr.right, r.bottom - r.height() * .07f, ts(.016f), MUTED, Paint.Align.RIGHT, false);
        addControl(C_MIX, index, 0, expand(tr, r.height() * .14f), min, max, false, false);
    }

    private void drawKnobCard(Canvas c, RectF r, int index, int accent, String title, String sub, float value, float min, float max, String unit) {
        panel(c, r, 16f);
        float smallR = r.height() * .105f;
        c.drawCircle(r.left + r.width() * .12f, r.top + r.height() * .17f, smallR, solid(Color.argb(150, Color.red(accent), Color.green(accent), Color.blue(accent))));
        drawBars(c, r.left + r.width() * .12f, r.top + r.height() * .17f, smallR * .95f, WHITE);
        text(c, title, r.left + r.width() * .22f, r.top + r.height() * .16f, ts(.022f), WHITE, Paint.Align.LEFT, true);
        text(c, sub, r.left + r.width() * .22f, r.top + r.height() * .26f, ts(.016f), MUTED, Paint.Align.LEFT, false);
        valueChip(c, r.right - r.width() * .22f, r.top + r.height() * .07f, r.width() * .19f, r.height() * .17f, formatValue(value, unit), accent);

        float kr = Math.min(r.width(), r.height()) * .24f;
        float kx = r.centerX();
        float ky = r.top + r.height() * .64f;
        drawKnob(c, kx, ky, kr, value, min, max, accent);
        text(c, formatValue(min, unit), r.left + r.width() * .08f, r.bottom - r.height() * .07f, ts(.015f), MUTED, Paint.Align.LEFT, false);
        text(c, formatValue(max, unit), r.right - r.width() * .08f, r.bottom - r.height() * .07f, ts(.015f), MUTED, Paint.Align.RIGHT, false);
        addControl(C_MIX, index, 0, new RectF(kx - kr * 1.35f, ky - kr * 1.35f, kx + kr * 1.35f, ky + kr * 1.35f), min, max, false, true);
    }

    private void drawEq(Canvas c) {
        text(c, "Eq", cx(.045f), cy(.055f), ts(.055f), WHITE, Paint.Align.LEFT, true);
        text(c, "S H A P E   Y O U R   S O U N D", cx(.045f), cy(.09f), ts(.018f), MUTED, Paint.Align.LEFT, true);
        RectF save = rect(.48f, .025f, .68f, .09f);
        RectF load = rect(.695f, .025f, .89f, .09f);
        RectF more = rect(.905f, .025f, .965f, .09f);
        smallButton(c, save, "Save Preset", GREEN, false); addControl(C_EQ_SAVE,0,0,save,0,1,false,false);
        smallButton(c, load, "Load Preset", PURPLE, false); addControl(C_EQ_LOAD,0,0,load,0,1,false,false);
        smallButton(c, more, "⋮", BLUE, false); addControl(C_EQ_MORE,0,0,more,0,1,false,false);

        String[] chTop = {"Ch 1", "Ch 2", "Ch 3", "Ch 4", "Ch 5", "Ch 6", "Ch 7"};
        String[] chBot = {"FL", "FR", "C", "RL", "RR", "SUB", "AUX"};
        float gap = (cx(.965f) - cx(.035f)) * .009f;
        float total = cx(.965f) - cx(.035f);
        float bw = (total - gap * 6) / 7f;
        for (int i = 0; i < 7; i++) {
            float l = cx(.035f) + i * (bw + gap);
            RectF b = new RectF(l, cy(.115f), l + bw, cy(.205f));
            int fill = s.eqChannel == i ? Color.argb(210, 0, 101, 175) : Color.argb(140, 8, 41, 73);
            round(c, b.left, b.top, b.right, b.bottom, b.height() * .15f, fill, s.eqChannel == i ? BLUE : BORDER, 1.2f);
            text(c, chTop[i], b.centerX(), b.top + b.height() * .38f, ts(.016f), s.eqChannel == i ? WHITE : MUTED, Paint.Align.CENTER, true);
            text(c, chBot[i], b.centerX(), b.top + b.height() * .72f, ts(.020f), WHITE, Paint.Align.CENTER, true);
            addControl(C_EQ_CHANNEL, i, 0, b, 0, 1, false, false);
        }

        RectF graphCard = rect(.035f, .225f, .965f, .55f);
        panel(c, graphCard, 16f);
        text(c, "15 Band Equalizer", graphCard.left + pad() * .45f, graphCard.top + ts(.036f), ts(.023f), WHITE, Paint.Align.LEFT, true);
        RectF plot = new RectF(graphCard.left + graphCard.width() * .075f, graphCard.top + graphCard.height() * .22f,
                graphCard.right - graphCard.width() * .035f, graphCard.bottom - graphCard.height() * .15f);
        drawEqGraph(c, plot);
        addControl(C_EQ_GRAPH,0,0,plot,0,1,false,false);

        RectF band = rect(.035f, .57f, .965f, .815f);
        panel(c, band, 16f);
        text(c, "Band Controls", band.left + pad() * .45f, band.top + ts(.033f), ts(.022f), WHITE, Paint.Align.LEFT, true);
        text(c, "Band " + (s.eqBand + 1) + " of 15", band.right - pad() * .8f, band.top + ts(.033f), ts(.016f), MUTED, Paint.Align.RIGHT, false);
        drawBandControl(c, band, 0, "Frequency", s.eqFreq[s.eqChannel][s.eqBand], 20f, 20000f, "Hz", BLUE, true);
        drawBandControl(c, band, 1, "Gain", s.eqGain[s.eqChannel][s.eqBand], -12f, 12f, "dB", GREEN, false);
        drawBandControl(c, band, 2, "Q (Quality Factor)", s.eqQ[s.eqChannel][s.eqBand], .1f, 10f, "", PURPLE, false);

        RectF out = rect(.035f, .835f, .965f, .955f);
        panel(c, out, 16f);
        c.drawCircle(out.left + out.height() * .31f, out.centerY(), out.height() * .22f, solid(Color.argb(120, 30, 167, 255)));
        drawSpeaker(c, out.left + out.height() * .31f, out.centerY(), out.height() * .17f, WHITE);
        text(c, "Output Level - Ch " + (s.eqChannel + 1) + " (" + channelName(s.eqChannel) + ")", out.left + out.height() * .60f, out.top + out.height() * .32f, ts(.020f), WHITE, Paint.Align.LEFT, true);
        valueChip(c, out.right - out.width() * .15f, out.top + out.height() * .16f, out.width() * .12f, out.height() * .30f, formatValue(s.output[s.eqChannel], "dB"), BLUE);
        RectF tr = new RectF(out.left + out.width() * .14f, out.top + out.height() * .60f, out.right - out.width() * .07f, out.top + out.height() * .76f);
        slider(c, tr, s.output[s.eqChannel], -60f, 12f, BLUE, false);
        addControl(C_EQ_SLIDER, 3, 0, expand(tr, out.height() * .12f), -60, 12, false, false);
        text(c, "-60 dB", tr.left, out.bottom - out.height() * .06f, ts(.014f), MUTED, Paint.Align.LEFT, false);
        text(c, "+12 dB", tr.right, out.bottom - out.height() * .06f, ts(.014f), MUTED, Paint.Align.RIGHT, false);
    }

    private void drawBandControl(Canvas c, RectF parent, int property, String title, float value, float min, float max, String unit, int accent, boolean log) {
        float gap = parent.width() * .012f;
        float innerL = parent.left + parent.width() * .025f;
        float innerW = parent.width() * .95f;
        float bw = (innerW - gap * 2) / 3f;
        float l = innerL + property * (bw + gap);
        RectF r = new RectF(l, parent.top + parent.height() * .20f, l + bw, parent.bottom - parent.height() * .07f);
        round(c, r.left, r.top, r.right, r.bottom, r.height() * .06f, Color.argb(110, 7, 45, 80), Color.argb(160, 17, 83, 128), 1f);
        c.drawCircle(r.left + r.width() * .10f, r.top + r.height() * .25f, r.height() * .12f, solid(Color.argb(130, Color.red(accent), Color.green(accent), Color.blue(accent))));
        if (property == 0) drawSine(c, r.left + r.width() * .10f, r.top + r.height() * .25f, r.height() * .085f, WHITE);
        else if (property == 1) drawBars(c, r.left + r.width() * .10f, r.top + r.height() * .25f, r.height() * .085f, WHITE);
        else text(c, "Q", r.left + r.width() * .10f, r.top + r.height() * .29f, ts(.020f), WHITE, Paint.Align.CENTER, true);
        text(c, title, r.left + r.width() * .20f, r.top + r.height() * .19f, ts(.015f), MUTED, Paint.Align.LEFT, false);
        text(c, formatValue(value, unit), r.left + r.width() * .20f, r.top + r.height() * .36f, ts(.026f), WHITE, Paint.Align.LEFT, true);
        RectF tr = new RectF(r.left + r.width() * .13f, r.top + r.height() * .53f, r.right - r.width() * .13f, r.top + r.height() * .64f);
        slider(c, tr, value, min, max, accent, log);
        addControl(C_EQ_SLIDER, property, 0, expand(tr, r.height() * .13f), min, max, log, false);
        RectF minus = new RectF(r.left + r.width() * .04f, r.top + r.height() * .72f, r.left + r.width() * .20f, r.bottom - r.height() * .04f);
        RectF plus = new RectF(r.right - r.width() * .20f, r.top + r.height() * .72f, r.right - r.width() * .04f, r.bottom - r.height() * .04f);
        circleButton(c, minus, "−", accent); circleButton(c, plus, "+", accent);
        addControl(C_EQ_NUDGE, property, -1, minus, min, max, log, false);
        addControl(C_EQ_NUDGE, property, +1, plus, min, max, log, false);
        String range;
        if (property == 0) range = "20 Hz – 20 kHz";
        else if (property == 1) range = "-12 dB – +12 dB";
        else range = "0.1 – 10.0";
        text(c, range, r.centerX(), r.bottom - r.height() * .07f, ts(.014f), MUTED, Paint.Align.CENTER, false);
    }

    private void drawEqGraph(Canvas c, RectF plot) {
        stroke.setStrokeWidth(Math.max(1f, base() * .002f));
        stroke.setColor(Color.argb(120, 34, 91, 130));
        for (int i = 0; i <= 6; i++) {
            float y = plot.top + plot.height() * i / 6f;
            c.drawLine(plot.left, y, plot.right, y, stroke);
        }
        for (int i = 0; i <= 10; i++) {
            float x = plot.left + plot.width() * i / 10f;
            c.drawLine(x, plot.top, x, plot.bottom, stroke);
        }
        text(c, "+12", plot.left - ts(.008f), plot.top + ts(.012f), ts(.013f), MUTED, Paint.Align.RIGHT, false);
        text(c, "0", plot.left - ts(.008f), plot.centerY() + ts(.006f), ts(.013f), MUTED, Paint.Align.RIGHT, false);
        text(c, "-12", plot.left - ts(.008f), plot.bottom, ts(.013f), MUTED, Paint.Align.RIGHT, false);
        String[] labels = {"20", "80", "315", "1.25k", "5k", "20k"};
        float[] hz = {20f, 80f, 315f, 1250f, 5000f, 20000f};
        for (int i = 0; i < labels.length; i++) {
            float x = logX(plot, hz[i]);
            text(c, labels[i], x, plot.bottom + ts(.026f), ts(.012f), MUTED, Paint.Align.CENTER, false);
        }
        text(c, "Frequency (Hz)", plot.centerX(), plot.bottom + ts(.048f), ts(.013f), MUTED, Paint.Align.CENTER, false);
        text(c, "dB", plot.left - ts(.035f), plot.centerY(), ts(.012f), MUTED, Paint.Align.CENTER, false);

        // Smooth parametric-EQ preview. Frequency, gain and Q all affect this curve immediately.
        path.reset();
        final int samples = 160;
        for (int i = 0; i <= samples; i++) {
            float t = i / (float) samples;
            float f = 20f * (float) Math.pow(1000f, t);
            float response = eqResponseAt(s.eqChannel, f);
            float x = plot.left + plot.width() * t;
            float y = plot.centerY() - (response / 12f) * plot.height() * .48f;
            y = DspUiState.clamp(y, plot.top, plot.bottom);
            if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
        }
        stroke.setStrokeWidth(Math.max(2f, base() * .005f));
        stroke.setColor(BLUE);
        c.drawPath(path, stroke);

        for (int b = 0; b < 15; b++) {
            float x = logX(plot, s.eqFreq[s.eqChannel][b]);
            float y = plot.centerY() - (s.eqGain[s.eqChannel][b] / 12f) * plot.height() * .48f;
            int col = rainbowBand(b);
            float rr = b == s.eqBand ? base() * .014f : base() * .009f;
            p.setColor(col); p.setStyle(Paint.Style.FILL); c.drawCircle(x, y, rr, p);
            if (b == s.eqBand) {
                stroke.setColor(WHITE); stroke.setStrokeWidth(base() * .003f); c.drawCircle(x, y, rr * 1.45f, stroke);
            }
        }
    }

    private float eqResponseAt(int channel, float frequency) {
        float sum = 0f;
        for (int b = 0; b < 15; b++) {
            float center = Math.max(20f, s.eqFreq[channel][b]);
            float q = DspUiState.clamp(s.eqQ[channel][b], .1f, 10f);
            double octaves = Math.log(frequency / center) / Math.log(2.0);
            // Higher Q means a narrower bell. Clamp keeps the preview stable at extreme Q.
            double sigma = 1.05 / Math.sqrt(Math.max(.18, q));
            double bell = Math.exp(-0.5 * (octaves / sigma) * (octaves / sigma));
            sum += s.eqGain[channel][b] * (float) bell * .62f;
        }
        return DspUiState.clamp(sum, -12f, 12f);
    }

    private void drawCrossover(Canvas c) {
        text(c, "Crossover", cx(.045f), cy(.052f), ts(.047f), WHITE, Paint.Align.LEFT, true);
        text(c, "Configure crossover filters and time alignment for each channel.", cx(.045f), cy(.086f), ts(.018f), MUTED, Paint.Align.LEFT, false);
        RectF preset = rect(.70f, .02f, .965f, .085f);
        smallButton(c, preset, "▱  Crossover Preset  ›", BLUE, false);
        addControl(C_XO_PRESET,0,0,preset,0,1,false,false);

        RectF graph = rect(.035f, .11f, .965f, .37f);
        panel(c, graph, 16f);
        text(c, "C R O S S O V E R   R E S P O N S E", graph.left + pad() * .5f, graph.top + ts(.032f), ts(.015f), MUTED, Paint.Align.LEFT, true);
        RectF mag = new RectF(graph.right - graph.width() * .34f, graph.top + graph.height() * .04f, graph.right - graph.width() * .18f, graph.top + graph.height() * .18f);
        RectF phase = new RectF(graph.right - graph.width() * .17f, graph.top + graph.height() * .04f, graph.right - graph.width() * .03f, graph.top + graph.height() * .18f);
        smallButton(c, mag, "Magnitude", BLUE, !s.phaseView); addControl(C_XO_VIEW,0,0,mag,0,1,false,false);
        smallButton(c, phase, "Phase", BLUE, s.phaseView); addControl(C_XO_VIEW,0,1,phase,0,1,false,false);
        RectF plot = new RectF(graph.left + graph.width() * .08f, graph.top + graph.height() * .24f, graph.right - graph.width() * .03f, graph.bottom - graph.height() * .12f);
        drawXoGraph(c, plot);

        RectF settings = rect(.035f, .39f, .965f, .72f);
        panel(c, settings, 16f);
        text(c, "C R O S S O V E R   S E T T I N G S", settings.left + pad() * .5f, settings.top + ts(.030f), ts(.015f), MUTED, Paint.Align.LEFT, true);
        text(c, "Link L/R", settings.right - settings.width() * .15f, settings.top + ts(.030f), ts(.016f), MUTED, Paint.Align.RIGHT, false);
        RectF toggle = new RectF(settings.right - settings.width() * .12f, settings.top + settings.height() * .035f, settings.right - settings.width() * .03f, settings.top + settings.height() * .13f);
        drawToggle(c, toggle, s.linkLR); addControl(C_XO_LINK,0,0,toggle,0,1,false,false);
        drawXoColumns(c, settings);

        RectF delays = rect(.035f, .745f, .965f, .955f);
        panel(c, delays, 16f);
        text(c, "C H A N N E L   D E L A Y / T I M E   A L I G N M E N T", delays.left + pad() * .5f, delays.top + ts(.030f), ts(.014f), MUTED, Paint.Align.LEFT, true);
        drawDelayColumns(c, delays);
        RectF reset = new RectF(delays.left + delays.width() * .03f, delays.bottom - delays.height() * .22f, delays.left + delays.width() * .28f, delays.bottom - delays.height() * .06f);
        RectF auto = new RectF(delays.right - delays.width() * .30f, delays.bottom - delays.height() * .22f, delays.right - delays.width() * .03f, delays.bottom - delays.height() * .06f);
        smallButton(c, reset, "↻  Reset Delays", BLUE, false); addControl(C_XO_RESET,0,0,reset,0,1,false,false);
        smallButton(c, auto, "⚙  Auto Align", CYAN, false); addControl(C_XO_AUTO,0,0,auto,0,1,false,false);
    }

    private void drawXoGraph(Canvas c, RectF plot) {
        stroke.setStrokeWidth(Math.max(1f, base() * .002f));
        stroke.setColor(Color.argb(120, 34, 91, 130));
        for (int i = 0; i <= 5; i++) {
            float y = plot.top + plot.height() * i / 5f;
            c.drawLine(plot.left, y, plot.right, y, stroke);
        }
        float[] hz = {20f, 100f, 500f, 1000f, 5000f, 10000f, 20000f};
        for (float f : hz) {
            float x = logX(plot, f);
            c.drawLine(x, plot.top, x, plot.bottom, stroke);
            text(c, shortHz(f), x, plot.bottom + ts(.019f), ts(.011f), MUTED, Paint.Align.CENTER, false);
        }
        text(c, "+12", plot.left - ts(.008f), plot.top + ts(.010f), ts(.011f), MUTED, Paint.Align.RIGHT, false);
        text(c, "0", plot.left - ts(.008f), plot.top + plot.height() * .22f, ts(.011f), MUTED, Paint.Align.RIGHT, false);
        text(c, "-24", plot.left - ts(.008f), plot.bottom, ts(.011f), MUTED, Paint.Align.RIGHT, false);
        int[] cols = {PURPLE, BLUE, GREEN, ORANGE};
        for (int ch = 0; ch < 4; ch++) {
            path.reset();
            for (int i = 0; i <= 100; i++) {
                float f = 20f * (float)Math.pow(1000f, i / 100f);
                float norm = crossoverMagnitude(ch, f);
                float x = logX(plot, f);
                float y;
                if (s.phaseView) {
                    float phase = crossoverPhase(ch, f);
                    y = plot.centerY() - phase * plot.height() * .42f;
                } else {
                    y = plot.bottom - norm * plot.height() * .82f;
                }
                if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
            }
            stroke.setColor(cols[ch]); stroke.setStrokeWidth(Math.max(2f, base() * .005f)); c.drawPath(path, stroke);
        }
        String[] names = {"SUB", "MID", "HIGH", "FULL"};
        float lx = plot.left;
        for (int i = 0; i < 4; i++) {
            p.setColor(cols[i]); c.drawCircle(lx + base() * .011f, plot.bottom + ts(.046f), base() * .008f, p);
            text(c, names[i], lx + base() * .025f, plot.bottom + ts(.051f), ts(.012f), MUTED, Paint.Align.LEFT, true);
            lx += plot.width() * .22f;
        }
    }

    private void drawXoColumns(Canvas c, RectF parent) {
        String[] names = {"SUB", "MID", "HIGH", "FULL"};
        int[] cols = {PURPLE, BLUE, GREEN, ORANGE};
        String[] types = {"Low Pass", "Band Pass", "High Pass", "Bypass"};
        float gap = parent.width() * .012f;
        float l0 = parent.left + parent.width() * .02f;
        float usable = parent.width() * .96f;
        float cw = (usable - gap * 3) / 4f;
        for (int i = 0; i < 4; i++) {
            float l = l0 + i * (cw + gap);
            RectF card = new RectF(l, parent.top + parent.height() * .16f, l + cw, parent.bottom - parent.height() * .05f);
            round(c, card.left, card.top, card.right, card.bottom, card.height() * .035f, Color.argb(90, 6, 42, 75), Color.argb(130, 18, 82, 126), 1f);
            p.setColor(cols[i]); c.drawCircle(card.left + card.width() * .08f, card.top + card.height() * .09f, card.width() * .03f, p);
            text(c, names[i], card.left + card.width() * .15f, card.top + card.height() * .115f, ts(.014f), cols[i], Paint.Align.LEFT, true);
            RectF type = new RectF(card.left + card.width() * .04f, card.top + card.height() * .17f, card.right - card.width() * .04f, card.top + card.height() * .34f);
            smallButton(c, type, types[s.xoType[i]], cols[i], false); addControl(C_XO_TYPE,i,0,type,0,1,false,false);
            float lowVal = s.xoLow[i];
            float highVal = s.xoHigh[i];
            String display = s.xoType[i] == 1 ? shortHz(lowVal) + " - " + shortHz(highVal) : (s.xoType[i] == 2 ? shortHz(lowVal) : shortHz(highVal));
            text(c, display, card.centerX(), card.top + card.height() * .42f, ts(.016f), WHITE, Paint.Align.CENTER, true);
            RectF low = new RectF(card.left + card.width() * .08f, card.top + card.height() * .50f, card.right - card.width() * .08f, card.top + card.height() * .58f);
            RectF high = new RectF(card.left + card.width() * .08f, card.top + card.height() * .62f, card.right - card.width() * .08f, card.top + card.height() * .70f);
            if (s.xoType[i] == 0) {
                slider(c, low, highVal, 20f, 20000f, cols[i], true);
                addControl(C_XO_CUTOFF,i,1,expand(low, card.height() * .04f),20,20000,true,false);
            } else if (s.xoType[i] == 2) {
                slider(c, low, lowVal, 20f, 20000f, cols[i], true);
                addControl(C_XO_CUTOFF,i,0,expand(low, card.height() * .04f),20,20000,true,false);
            } else if (s.xoType[i] == 1) {
                slider(c, low, lowVal, 20f, 20000f, cols[i], true);
                slider(c, high, highVal, 20f, 20000f, cols[i], true);
                addControl(C_XO_CUTOFF,i,0,expand(low, card.height() * .04f),20,20000,true,false);
                addControl(C_XO_CUTOFF,i,1,expand(high, card.height() * .04f),20,20000,true,false);
            } else {
                stroke.setColor(Color.argb(100, 150, 170, 190)); stroke.setStrokeWidth(base() * .002f);
                c.drawLine(low.left, low.centerY(), low.right, low.centerY(), stroke);
            }
            text(c, "Slope", card.left + card.width() * .05f, card.top + card.height() * .78f, ts(.012f), MUTED, Paint.Align.LEFT, false);
            int[] slope = {12,24,36};
            for (int j = 0; j < 3; j++) {
                float bw = card.width() * .27f;
                float bl = card.left + card.width() * .05f + j * card.width() * .30f;
                RectF b = new RectF(bl, card.top + card.height() * .83f, bl + bw, card.bottom - card.height() * .04f);
                smallButton(c, b, slope[j] + " dB", cols[i], s.xoSlope[i] == slope[j]);
                addControl(C_XO_SLOPE,i,slope[j],b,0,1,false,false);
            }
        }
    }

    private void drawDelayColumns(Canvas c, RectF parent) {
        String[] names = {"SUB", "MID", "HIGH", "FULL"};
        int[] cols = {PURPLE, BLUE, GREEN, ORANGE};
        float gap = parent.width() * .012f;
        float l0 = parent.left + parent.width() * .02f;
        float usable = parent.width() * .96f;
        float cw = (usable - gap * 3) / 4f;
        for (int i = 0; i < 4; i++) {
            float l = l0 + i * (cw + gap);
            RectF card = new RectF(l, parent.top + parent.height() * .20f, l + cw, parent.bottom - parent.height() * .29f);
            p.setColor(cols[i]); c.drawCircle(card.left + card.width() * .06f, card.top + card.height() * .08f, card.width() * .026f, p);
            text(c, names[i], card.left + card.width() * .13f, card.top + card.height() * .12f, ts(.013f), cols[i], Paint.Align.LEFT, true);
            text(c, String.format(Locale.US, "%.2f ms", s.delayMs[i]), card.left + card.width() * .13f, card.top + card.height() * .32f, ts(.018f), WHITE, Paint.Align.LEFT, true);
            RectF tr = new RectF(card.left + card.width() * .04f, card.top + card.height() * .52f, card.right - card.width() * .04f, card.top + card.height() * .62f);
            slider(c, tr, s.delayMs[i], 0f, 20f, cols[i], false);
            addControl(C_XO_DELAY,i,0,expand(tr,card.height()*.12f),0,20,false,false);
            float cm = s.delayMs[i] * 34.3f;
            text(c, String.format(Locale.US, "%.1f cm", cm), card.centerX(), card.bottom, ts(.012f), MUTED, Paint.Align.CENTER, false);
        }
    }

    private void drawBottomNav(Canvas c) {
        float top = H() - safeBottom - navH();
        RectF r = new RectF(safeLeft, top, W() - safeRight, H());
        p.setShader(new LinearGradient(0, top, 0, H(), Color.argb(245, 4, 25, 49), Color.argb(255, 2, 14, 29), Shader.TileMode.CLAMP));
        c.drawRect(r, p); p.setShader(null);
        stroke.setColor(Color.argb(120, 31, 91, 138)); stroke.setStrokeWidth(Math.max(1f, base()*.002f)); c.drawLine(r.left, r.top, r.right, r.top, stroke);
        String[] names = {"Home", "Mix", "Eq", "Crossover"};
        float each = r.width() / 4f;
        for (int i = 0; i < 4; i++) {
            RectF hit = new RectF(r.left + i * each, r.top, r.left + (i+1) * each, r.bottom);
            float x = hit.centerX();
            float iy = r.top + r.height() * .35f;
            int col = s.page == i ? BLUE : Color.rgb(157, 183, 223);
            drawNavIcon(c, i, x, iy, r.height() * .18f, col);
            text(c, names[i], x, r.top + r.height() * .76f, ts(.020f), col, Paint.Align.CENTER, s.page == i);
            if (s.page == i) {
                p.setColor(BLUE);
                c.drawRoundRect(new RectF(x-each*.20f,r.bottom-r.height()*.035f,x+each*.20f,r.bottom-r.height()*.015f),r.height()*.02f,r.height()*.02f,p);
            }
            addControl(C_NAV,i,0,hit,0,1,false,false);
        }
    }

    private void drawModal(Canvas c) {
        p.setColor(Color.argb(190, 0, 5, 14)); p.setStyle(Paint.Style.FILL); c.drawRect(0,0,W(),H(),p);
        RectF box = new RectF(cx(.115f), H()*.335f, cx(.885f), H()*.665f);
        round(c,box.left,box.top,box.right,box.bottom,base()*.035f,Color.rgb(6,35,66),BLUE,1.5f);
        String title = "Device Settings";
        String body = "Phase 1 Final UI.\nControls and graphs react immediately.\nSession + preset values persist locally.\nReal BLE/DSP transport starts in Phase 2.";
        if ("about".equals(modal)) {
            title = "About OKN_DSP";
            body = "OKN_DSP Version 6.0.0\nPhase 1 Final: responsive DSP interface\nCanvas-rendered UI — no screenshot background.";
        }
        text(c,title,box.left+box.width()*.07f,box.top+box.height()*.17f,ts(.032f),WHITE,Paint.Align.LEFT,true);
        float y = box.top+box.height()*.32f;
        for (String line: body.split("\\n")) {
            text(c,line,box.left+box.width()*.07f,y,ts(.022f),MUTED,Paint.Align.LEFT,false); y += ts(.040f);
        }
        RectF close = new RectF(box.centerX()-box.width()*.22f,box.bottom-box.height()*.20f,box.centerX()+box.width()*.22f,box.bottom-box.height()*.08f);
        smallButton(c,close,"Close",BLUE,true); addControl(C_MODAL_CLOSE,0,0,close,0,1,false,false);
    }

    private void drawMessage(Canvas c) {
        RectF r = new RectF(cx(.20f), H()*.16f, cx(.80f), H()*.16f + base()*.10f);
        round(c,r.left,r.top,r.right,r.bottom,r.height()*.30f,Color.argb(235,5,34,61),Color.argb(220,25,144,220),1.2f);
        text(c,message,r.centerX(),r.centerY()+ts(.008f),ts(.021f),WHITE,Paint.Align.CENTER,true);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        try {
            float x = e.getX(), y = e.getY();
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN -> {
                    downX = x; downY = y;
                    active = findControl(x,y);
                    if (active == null) return true;
                    if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                    startValue = currentValue(active);
                    if (!active.drag) { applyButton(active, x, y); persistSession(); }
                    else applyDrag(active, x, y, true);
                    invalidate();
                    return true;
                }
                case MotionEvent.ACTION_MOVE -> {
                    if (active != null && active.drag) {
                        applyDrag(active, x, y, false);
                        invalidate();
                    }
                    return true;
                }
                case MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (active != null && active.drag) {
                        applyDrag(active, x, y, false);
                        invalidate();
                    }
                    persistSession();
                    if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
                    active = null;
                    return true;
                }
                default -> { return true; }
            }
        } catch (Throwable error) {
            active = null;
            lastUiError = error.getClass().getSimpleName();
            show("Control recovered safely");
            invalidate();
            return true;
        }
    }

    private Control findControl(float x, float y) {
        for (int i = controls.size() - 1; i >= 0; i--) if (controls.get(i).r.contains(x,y)) return controls.get(i);
        return null;
    }

    private void applyButton(Control c, float x, float y) {
        switch (c.type) {
            case C_NAV -> { s.page = c.a; modal = null; }
            case C_HEADER_SETTINGS -> modal = "settings";
            case C_HOME_INPUT -> { s.inputSource = c.a; show("Input source: " + new String[]{"Bluetooth","AUX","Optical","USB"}[c.a]); }
            case C_HOME_QUICK -> {
                if (c.a == 0) loadPreset();
                else if (c.a == 1) savePreset();
                else if (c.a == 2) modal = "settings";
                else modal = "about";
            }
            case C_EQ_CHANNEL -> s.eqChannel = c.a;
            case C_EQ_GRAPH -> {
                float t = DspUiState.clamp((x-c.r.left)/c.r.width(),0,1);
                float hz = 20f * (float)Math.pow(1000f,t);
                int best = 0; float dist = Float.MAX_VALUE;
                for (int i=0;i<15;i++) { float d=Math.abs((float)Math.log(s.eqFreq[s.eqChannel][i]/hz)); if(d<dist){dist=d;best=i;} }
                s.eqBand = best;
            }
            case C_EQ_NUDGE -> nudgeEq(c.a, c.b);
            case C_EQ_SAVE -> savePreset();
            case C_EQ_LOAD -> loadPreset();
            case C_EQ_MORE -> modal = "settings";
            case C_XO_TYPE -> { s.xoType[c.a] = (s.xoType[c.a] + 1) % 4; }
            case C_XO_SLOPE -> s.xoSlope[c.a] = c.b;
            case C_XO_LINK -> s.linkLR = !s.linkLR;
            case C_XO_VIEW -> s.phaseView = c.b == 1;
            case C_XO_RESET -> { s.resetDelays(); show("Delays reset to 0.00 ms"); }
            case C_XO_AUTO -> { autoAlign(); show("Auto Align preview applied"); }
            case C_XO_PRESET -> loadPreset();
            case C_MODAL_CLOSE -> modal = null;
        }
    }

    private void applyDrag(Control c, float x, float y, boolean first) {
        if (c.type == C_EQ_GRAPH) {
            float tx = DspUiState.clamp((x - c.r.left) / c.r.width(), 0f, 1f);
            float hz = 20f * (float) Math.pow(1000f, tx);
            if (first) {
                int best = 0; float dist = Float.MAX_VALUE;
                for (int i = 0; i < 15; i++) {
                    float d = Math.abs((float) Math.log(s.eqFreq[s.eqChannel][i] / hz));
                    if (d < dist) { dist = d; best = i; }
                }
                s.eqBand = best;
            }
            int band = s.eqBand;
            float minHz = band == 0 ? 20f : s.eqFreq[s.eqChannel][band - 1] * 1.015f;
            float maxHz = band == 14 ? 20000f : s.eqFreq[s.eqChannel][band + 1] / 1.015f;
            s.eqFreq[s.eqChannel][band] = DspUiState.clamp(hz, minHz, maxHz);
            float ty = DspUiState.clamp((y - c.r.top) / c.r.height(), 0f, 1f);
            s.eqGain[s.eqChannel][band] = DspUiState.clamp(12f - ty * 24f, -12f, 12f);
            return;
        }
        float value;
        if (c.knob) {
            float dy = downY - y;
            float dx = x - downX;
            float delta = (dy + dx * .35f) / Math.max(1f, base() * .34f);
            value = startValue + delta * (c.max - c.min);
        } else {
            float t = DspUiState.clamp((x - c.r.left) / c.r.width(), 0f, 1f);
            if (c.log) value = c.min * (float)Math.pow(c.max / c.min, t);
            else value = c.min + (c.max - c.min) * t;
        }
        value = DspUiState.clamp(value, c.min, c.max);
        switch (c.type) {
            case C_MIX -> setMixValue(c.a, value);
            case C_EQ_SLIDER -> setEqValue(c.a, value);
            case C_XO_CUTOFF -> {
                if (c.b == 0) s.xoLow[c.a] = Math.min(value, s.xoHigh[c.a] * .98f);
                else s.xoHigh[c.a] = Math.max(value, s.xoLow[c.a] * 1.02f);
            }
            case C_XO_DELAY -> {
                s.delayMs[c.a] = value;
                if (s.linkLR && c.a < 2) s.delayMs[1-c.a] = value;
            }
        }
    }

    private float currentValue(Control c) {
        if (c.type == C_MIX) return mixValue(c.a);
        if (c.type == C_EQ_SLIDER) return eqValue(c.a);
        if (c.type == C_XO_CUTOFF) return c.b == 0 ? s.xoLow[c.a] : s.xoHigh[c.a];
        if (c.type == C_XO_DELAY) return s.delayMs[c.a];
        return 0f;
    }

    private float mixValue(int i) {
        return switch (i) {
            case 0 -> s.masterVolume; case 1 -> s.bassVolume; case 2 -> s.bassCutoff;
            case 3 -> s.bassBoost; case 4 -> s.middleBoost; default -> s.trebleBoost;
        };
    }

    private void setMixValue(int i, float v) {
        switch (i) {
            case 0 -> s.masterVolume=v; case 1 -> s.bassVolume=v; case 2 -> s.bassCutoff=v;
            case 3 -> s.bassBoost=v; case 4 -> s.middleBoost=v; case 5 -> s.trebleBoost=v;
        }
    }

    private float eqValue(int property) {
        return switch (property) {
            case 0 -> s.eqFreq[s.eqChannel][s.eqBand];
            case 1 -> s.eqGain[s.eqChannel][s.eqBand];
            case 2 -> s.eqQ[s.eqChannel][s.eqBand];
            default -> s.output[s.eqChannel];
        };
    }

    private void setEqValue(int property, float v) {
        if (property == 0) s.eqFreq[s.eqChannel][s.eqBand] = v;
        else if (property == 1) s.eqGain[s.eqChannel][s.eqBand] = v;
        else if (property == 2) s.eqQ[s.eqChannel][s.eqBand] = v;
        else s.output[s.eqChannel] = v;
    }

    private void nudgeEq(int property, int dir) {
        float v = eqValue(property);
        if (property == 0) v *= dir > 0 ? 1.08f : .925f;
        else if (property == 1) v += dir * .5f;
        else if (property == 2) v += dir * .1f;
        setEqValue(property, DspUiState.clamp(v, property==0?20f:property==1?-12f:.1f, property==0?20000f:property==1?12f:10f));
    }

    private void migrateLegacyPreferences(Context context) {
        if (prefs.contains("migration_v6_done")) return;
        SharedPreferences legacy = context.getSharedPreferences("okn_dsp_phase1_v4", Context.MODE_PRIVATE);
        SharedPreferences.Editor e = prefs.edit();
        String oldPreset = legacy.getString("preset_1", null);
        if (oldPreset != null && !prefs.contains("preset_1")) e.putString("preset_1", oldPreset);
        e.putBoolean("migration_v6_done", true).apply();
    }

    public void persistSession() {
        try {
            prefs.edit().putString("session", s.serializeSession()).apply();
        } catch (RuntimeException ignored) {
            // UI state persistence must never be allowed to crash the app.
        }
    }

    private void savePreset() {
        prefs.edit().putString("preset_1", s.serialize()).putString("session", s.serializeSession()).apply();
        show("Preset saved locally");
    }

    private void loadPreset() {
        String raw = prefs.getString("preset_1", null);
        if (raw != null && s.restore(raw)) { persistSession(); show("Preset loaded"); }
        else show("No saved preset yet");
    }

    private void autoAlign() {
        float max = 2.5f;
        for (int i=0;i<4;i++) s.delayMs[i] = Math.max(0f, max - i * .55f);
    }

    private void show(String m) { message = m; messageUntil = System.currentTimeMillis() + 1600L; }

    private RectF rect(float l, float t, float r, float b) { return new RectF(cx(l), cy(t), cx(r), cy(b)); }
    private RectF expand(RectF r, float v) { return new RectF(r.left-v,r.top-v,r.right+v,r.bottom+v); }

    private void panel(Canvas c, RectF r, float radiusDpLike) {
        float rr = Math.min(r.width(), r.height()) * .045f;
        round(c,r.left,r.top,r.right,r.bottom,rr,Color.argb(205,7,40,74),Color.argb(155,18,86,132),1.2f);
    }

    private void round(Canvas c, float l, float t, float r, float b, float rad, int fill, int border, float sw) {
        p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(fill); c.drawRoundRect(new RectF(l,t,r,b),rad,rad,p);
        stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(Math.max(1f,base()*.0015f*sw)); stroke.setColor(border); c.drawRoundRect(new RectF(l,t,r,b),rad,rad,stroke);
    }

    private Paint solid(int color) { p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(color); return p; }

    private void text(Canvas c, String text, float x, float y, float size, int color, Paint.Align align, boolean bold) {
        p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(color); p.setTextSize(size); p.setTextAlign(align);
        p.setTypeface(android.graphics.Typeface.create(
                bold ? "sans-serif-medium" : "sans-serif",
                android.graphics.Typeface.NORMAL));
        c.drawText(text,x,y,p);
    }

    private float measure(String text, float size, boolean bold) {
        p.setTextSize(size); p.setTypeface(android.graphics.Typeface.create(
                bold ? "sans-serif-medium" : "sans-serif",
                android.graphics.Typeface.NORMAL));
        return p.measureText(text);
    }

    private void slider(Canvas c, RectF tr, float value, float min, float max, int accent, boolean log) {
        float cy = tr.centerY();
        float t;
        if (log) t = (float)(Math.log(value/min)/Math.log(max/min)); else t = (value-min)/(max-min);
        t = DspUiState.clamp(t,0,1);
        stroke.setStrokeWidth(Math.max(3f, tr.height()*.22f)); stroke.setStrokeCap(Paint.Cap.ROUND); stroke.setColor(Color.rgb(31,62,91)); c.drawLine(tr.left,cy,tr.right,cy,stroke);
        stroke.setColor(accent); c.drawLine(tr.left,cy,tr.left+tr.width()*t,cy,stroke);
        p.setShader(new RadialGradient(tr.left+tr.width()*t,cy,tr.height()*1.6f,Color.argb(140,Color.red(accent),Color.green(accent),Color.blue(accent)),Color.TRANSPARENT,Shader.TileMode.CLAMP));
        c.drawCircle(tr.left+tr.width()*t,cy,tr.height()*1.6f,p); p.setShader(null);
        p.setColor(WHITE); c.drawCircle(tr.left+tr.width()*t,cy,Math.max(tr.height()*.55f,base()*.008f),p);
        stroke.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawKnob(Canvas c, float x, float y, float r, float value, float min, float max, int accent) {
        p.setShader(new RadialGradient(x-r*.25f,y-r*.30f,r*1.2f,Color.rgb(19,55,86),Color.rgb(1,13,27),Shader.TileMode.CLAMP));
        c.drawCircle(x,y,r,p); p.setShader(null);
        stroke.setStrokeWidth(Math.max(2f,r*.08f)); stroke.setStrokeCap(Paint.Cap.ROUND); stroke.setColor(Color.rgb(40,69,96));
        RectF arc = new RectF(x-r*1.03f,y-r*1.03f,x+r*1.03f,y+r*1.03f); c.drawArc(arc,135,270,false,stroke);
        float t = DspUiState.clamp((value-min)/(max-min),0,1);
        stroke.setColor(accent); c.drawArc(arc,135,270*t,false,stroke);
        float ang = (float)Math.toRadians(135+270*t);
        float px = x+(float)Math.cos(ang)*r*.78f, py = y+(float)Math.sin(ang)*r*.78f;
        p.setColor(WHITE); c.drawCircle(px,py,r*.10f,p);
        stroke.setStrokeCap(Paint.Cap.BUTT);
    }

    private void valueChip(Canvas c, float l, float t, float w, float h, String value, int accent) {
        round(c,l,t,l+w,t+h,h*.20f,Color.argb(120,8,30,58),Color.argb(180,Color.red(accent),Color.green(accent),Color.blue(accent)),1f);
        text(c,value,l+w*.5f,t+h*.68f,ts(.018f),accent,Paint.Align.CENTER,true);
    }

    private void smallButton(Canvas c, RectF r, String label, int accent, boolean selected) {
        int fill = selected ? Color.argb(170,Color.red(accent)/3,Color.green(accent)/3,Color.blue(accent)/3) : Color.argb(125,6,35,65);
        round(c,r.left,r.top,r.right,r.bottom,r.height()*.25f,fill,selected?accent:Color.argb(160,18,79,120),1f);
        text(c,label,r.centerX(),r.centerY()+ts(.006f),Math.min(ts(.016f),r.height()*.34f),selected?WHITE:MUTED,Paint.Align.CENTER,true);
    }

    private void circleButton(Canvas c, RectF r, String label, int accent) {
        float rr = Math.min(r.width(),r.height())*.48f; p.setColor(Color.argb(120,7,34,62)); c.drawCircle(r.centerX(),r.centerY(),rr,p);
        stroke.setColor(Color.argb(170,28,93,138)); stroke.setStrokeWidth(base()*.002f); c.drawCircle(r.centerX(),r.centerY(),rr,stroke);
        text(c,label,r.centerX(),r.centerY()+ts(.009f),ts(.027f),accent,Paint.Align.CENTER,true);
    }

    private void drawDspBox(Canvas c, float x, float y, float w, float h) {
        // Vector approximation of a black DSP enclosure.
        path.reset(); path.moveTo(x,y+h*.25f); path.lineTo(x+w*.12f,y); path.lineTo(x+w,y+h*.12f); path.lineTo(x+w*.86f,y+h*.38f); path.close();
        p.setShader(new LinearGradient(x,y,x+w,y+h*.4f,Color.rgb(38,46,59),Color.rgb(6,9,15),Shader.TileMode.CLAMP)); c.drawPath(path,p); p.setShader(null);
        path.reset(); path.moveTo(x,y+h*.25f); path.lineTo(x+w*.86f,y+h*.38f); path.lineTo(x+w*.86f,y+h); path.lineTo(x,y+h*.82f); path.close();
        p.setColor(Color.rgb(5,8,13)); c.drawPath(path,p);
        path.reset(); path.moveTo(x+w*.86f,y+h*.38f); path.lineTo(x+w,y+h*.12f); path.lineTo(x+w,y+h*.74f); path.lineTo(x+w*.86f,y+h); path.close(); p.setColor(Color.rgb(17,20,26)); c.drawPath(path,p);
        stroke.setStrokeWidth(h*.035f); stroke.setColor(Color.rgb(0,72,255)); c.drawLine(x+w*.46f,y+h*.62f,x+w*.75f,y+h*.67f,stroke);
        text(c,"OKN_DSP",x+w*.52f,y+h*.20f,Math.min(ts(.018f),h*.11f),Color.rgb(190,199,213),Paint.Align.CENTER,true);
    }

    private void statusLine(Canvas c, float x, float y, int accent, String title, String sub, int icon) {
        float r = base()*.035f; c.drawCircle(x,y,r,solid(Color.argb(120,Color.red(accent),Color.green(accent),Color.blue(accent))));
        if(icon==0) drawBluetooth(c,x,y,r*.60f,WHITE); else if(icon==1) drawBars(c,x,y,r*.70f,WHITE); else if(icon==2) drawBattery(c,x,y,r*.65f,WHITE); else drawChip(c,x,y,r*.62f,WHITE);
        text(c,title,x+r*1.45f,y-ts(.003f),ts(.022f),accent,Paint.Align.LEFT,true);
        text(c,sub,x+r*1.45f,y+ts(.027f),ts(.015f),MUTED,Paint.Align.LEFT,false);
    }

    private void drawSourceIcon(Canvas c, int i, float x, float y, float r, int color) {
        if(i==0) drawBluetooth(c,x,y,r,color); else if(i==1) { stroke.setColor(color);stroke.setStrokeWidth(r*.14f);c.drawLine(x,y-r*.6f,x,y+r*.4f,stroke);c.drawCircle(x,y+r*.62f,r*.16f,solid(color)); }
        else if(i==2) { stroke.setColor(color);stroke.setStrokeWidth(r*.12f);c.drawRect(x-r*.5f,y-r*.5f,x+r*.5f,y+r*.5f,stroke);c.drawCircle(x,y,r*.18f,stroke); }
        else { stroke.setColor(color);stroke.setStrokeWidth(r*.12f);c.drawLine(x,y+r*.65f,x,y-r*.65f,stroke);c.drawLine(x,y-r*.65f,x-r*.28f,y-r*.28f,stroke);c.drawLine(x,y-r*.65f,x+r*.28f,y-r*.28f,stroke);c.drawLine(x,y-r*.15f,x-r*.42f,y-r*.42f,stroke);c.drawCircle(x-r*.42f,y-r*.42f,r*.10f,solid(color)); }
    }

    private void drawQuickIcon(Canvas c, int i, float x, float y, float r, int color) {
        if(i==0) drawGear(c,x,y,r,color); else if(i==1) { stroke.setColor(color);stroke.setStrokeWidth(r*.12f);c.drawRect(x-r*.58f,y-r*.52f,x+r*.58f,y+r*.52f,stroke);c.drawLine(x-r*.32f,y-r*.52f,x-r*.32f,y-r*.80f,stroke);c.drawLine(x-r*.32f,y-r*.80f,x+r*.20f,y-r*.80f,stroke); }
        else if(i==2) drawBars(c,x,y,r,color); else { text(c,"i",x,y+r*.35f,r*1.45f,color,Paint.Align.CENTER,true); }
    }

    private void drawWaveform(Canvas c, RectF r, int accent, float phase) {
        float mid = r.centerY(); int n=34; float bw=r.width()/n;
        p.setColor(Color.argb(170,Color.red(accent),Color.green(accent),Color.blue(accent)));
        for(int i=0;i<n;i++) { float v=(float)(.18+.72*Math.abs(Math.sin(i*.72+phase*6.28))*Math.abs(Math.sin(i*.19+1.2))); float h=r.height()*v*.44f; c.drawRoundRect(new RectF(r.left+i*bw+bw*.27f,mid-h,r.left+i*bw+bw*.65f,mid+h),bw*.18f,bw*.18f,p); }
    }

    private void drawSpeaker(Canvas c, float x, float y, float r, int color) {
        p.setColor(color); path.reset();path.moveTo(x-r*.65f,y-r*.25f);path.lineTo(x-r*.25f,y-r*.25f);path.lineTo(x+r*.10f,y-r*.60f);path.lineTo(x+r*.10f,y+r*.60f);path.lineTo(x-r*.25f,y+r*.25f);path.lineTo(x-r*.65f,y+r*.25f);path.close();c.drawPath(path,p);
        stroke.setColor(color);stroke.setStrokeWidth(r*.11f);stroke.setStrokeCap(Paint.Cap.ROUND);c.drawArc(new RectF(x-r*.05f,y-r*.52f,x+r*.72f,y+r*.52f),-55,110,false,stroke);stroke.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawBars(Canvas c, float x, float y, float r, int color) {
        p.setColor(color); float bw=r*.16f; float[] h={.45f,.75f,1f,.63f}; for(int i=0;i<4;i++){float xx=x-r*.48f+i*r*.32f;c.drawRoundRect(new RectF(xx-bw*.5f,y-r*h[i]*.5f,xx+bw*.5f,y+r*h[i]*.5f),bw*.4f,bw*.4f,p);} }
    private void drawSine(Canvas c,float x,float y,float r,int color){ stroke.setColor(color);stroke.setStrokeWidth(r*.13f);path.reset();for(int i=0;i<=20;i++){float xx=x-r+i*(2*r/20f);float yy=y+(float)Math.sin(i/20f*Math.PI*2)*r*.45f;if(i==0)path.moveTo(xx,yy);else path.lineTo(xx,yy);}c.drawPath(path,stroke); }
    private void drawBluetooth(Canvas c,float x,float y,float r,int color){ stroke.setColor(color);stroke.setStrokeWidth(r*.13f);path.reset();path.moveTo(x,y-r);path.lineTo(x+r*.58f,y-r*.40f);path.lineTo(x-r*.58f,y+r*.55f);path.moveTo(x,y+r);path.lineTo(x+r*.58f,y+r*.40f);path.lineTo(x-r*.58f,y-r*.55f);path.moveTo(x,y-r);path.lineTo(x,y+r);c.drawPath(path,stroke); }
    private void drawBattery(Canvas c,float x,float y,float r,int color){ stroke.setColor(color);stroke.setStrokeWidth(r*.10f);c.drawRoundRect(new RectF(x-r*.70f,y-r*.42f,x+r*.55f,y+r*.42f),r*.08f,r*.08f,stroke);p.setColor(color);c.drawRect(x+r*.57f,y-r*.18f,x+r*.73f,y+r*.18f,p);c.drawRect(x-r*.52f,y-r*.25f,x+r*.32f,y+r*.25f,p); }
    private void drawChip(Canvas c,float x,float y,float r,int color){ stroke.setColor(color);stroke.setStrokeWidth(r*.10f);c.drawRect(x-r*.48f,y-r*.48f,x+r*.48f,y+r*.48f,stroke);c.drawRect(x-r*.22f,y-r*.22f,x+r*.22f,y+r*.22f,stroke);for(int i=-1;i<=1;i+=2){c.drawLine(x-r*.72f,y+i*r*.22f,x-r*.48f,y+i*r*.22f,stroke);c.drawLine(x+r*.48f,y+i*r*.22f,x+r*.72f,y+i*r*.22f,stroke);c.drawLine(x+i*r*.22f,y-r*.72f,x+i*r*.22f,y-r*.48f,stroke);c.drawLine(x+i*r*.22f,y+r*.48f,x+i*r*.22f,y+r*.72f,stroke);} }

    private void drawGear(Canvas c,float x,float y,float r,int color){ stroke.setColor(color);stroke.setStrokeWidth(r*.14f);c.drawCircle(x,y,r*.52f,stroke);c.drawCircle(x,y,r*.18f,stroke);for(int i=0;i<8;i++){double a=i*Math.PI/4;float x1=x+(float)Math.cos(a)*r*.60f,y1=y+(float)Math.sin(a)*r*.60f,x2=x+(float)Math.cos(a)*r*.92f,y2=y+(float)Math.sin(a)*r*.92f;c.drawLine(x1,y1,x2,y2,stroke);} }

    private void drawNavIcon(Canvas c,int i,float x,float y,float r,int color){
        stroke.setColor(color);stroke.setStrokeWidth(r*.16f);stroke.setStrokeCap(Paint.Cap.ROUND);p.setColor(color);
        if(i==0){path.reset();path.moveTo(x-r*.8f,y);path.lineTo(x,y-r*.70f);path.lineTo(x+r*.8f,y);path.lineTo(x+r*.62f,y);path.lineTo(x+r*.62f,y+r*.72f);path.lineTo(x-r*.62f,y+r*.72f);path.lineTo(x-r*.62f,y);path.close();c.drawPath(path,p);}
        else if(i==1){for(int k=-1;k<=1;k++){float xx=x+k*r*.62f;c.drawLine(xx,y-r*.78f,xx,y+r*.78f,stroke);float yy=y+(k==0?-r*.18f:k<0?r*.28f:-r*.35f);c.drawCircle(xx,yy,r*.18f,p);}}
        else if(i==2){for(int k=-1;k<=1;k++){float xx=x+k*r*.58f;float h=(k==0?1f:.65f)*r*.72f;c.drawRoundRect(new RectF(xx-r*.13f,y-h,xx+r*.13f,y+h),r*.12f,r*.12f,p);}}
        else {path.reset();path.moveTo(x-r*.8f,y-r*.65f);path.cubicTo(x-r*.2f,y-r*.65f,x-r*.2f,y+r*.65f,x+r*.8f,y+r*.65f);path.moveTo(x-r*.8f,y+r*.65f);path.cubicTo(x-r*.2f,y+r*.65f,x-r*.2f,y-r*.65f,x+r*.8f,y-r*.65f);c.drawPath(path,stroke);} stroke.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawToggle(Canvas c, RectF r, boolean on) {
        round(c,r.left,r.top,r.right,r.bottom,r.height()*.5f,on?Color.argb(160,0,100,165):Color.argb(140,40,54,72),on?BLUE:BORDER,1f);
        float rr=r.height()*.38f; float x=on?r.right-r.height()*.5f:r.left+r.height()*.5f; p.setColor(WHITE);c.drawCircle(x,r.centerY(),rr,p);
    }

    private float logX(RectF plot, float hz) { float t=(float)(Math.log(hz/20f)/Math.log(1000f)); return plot.left+plot.width()*DspUiState.clamp(t,0,1); }

    private float crossoverMagnitude(int ch, float f) {
        int type=s.xoType[ch]; if(type==3) return .82f;
        float slope=Math.max(1f,s.xoSlope[ch]/12f);
        if(type==0){float x=f/Math.max(20f,s.xoHigh[ch]);return (float)(.84/Math.sqrt(1+Math.pow(x,2*slope)));}
        if(type==2){float x=Math.max(20f,s.xoLow[ch])/f;return (float)(.84/Math.sqrt(1+Math.pow(x,2*slope)));}
        float hp=(float)(1/Math.sqrt(1+Math.pow(Math.max(20f,s.xoLow[ch])/f,2*slope)));
        float lp=(float)(1/Math.sqrt(1+Math.pow(f/Math.max(25f,s.xoHigh[ch]),2*slope)));
        return .9f*hp*lp;
    }

    private float crossoverPhase(int ch,float f){ int type=s.xoType[ch]; if(type==3)return 0f;float center=type==0?s.xoHigh[ch]:type==2?s.xoLow[ch]:(float)Math.sqrt(s.xoLow[ch]*s.xoHigh[ch]);float x=(float)Math.log(f/center);return (float)Math.tanh(x)*.75f*(type==0?-1:1); }

    private int rainbowBand(int b) {
        float t=b/14f; float hue=210f+t*145f; if(hue>360)hue-=360; return Color.HSVToColor(new float[]{hue,0.88f,1f});
    }

    private String channelName(int ch){return new String[]{"Front Left","Front Right","Center","Rear Left","Rear Right","Sub","Aux"}[ch];}
    private String shortHz(float hz){if(hz>=1000f){float k=hz/1000f;return (Math.abs(k-Math.round(k))<.05f?String.valueOf(Math.round(k)):String.format(Locale.US,"%.1f",k))+" kHz";}return String.format(Locale.US,"%.0f Hz",hz);}

    private String formatValue(float v,String unit){
        if("Hz".equals(unit)){return v>=1000?String.format(Locale.US,"%.2f kHz",v/1000f):String.format(Locale.US,"%.0f Hz",v);} 
        if("dB".equals(unit)) return String.format(Locale.US,"%+.1f dB",v);
        if(unit==null||unit.isEmpty()) return String.format(Locale.US,"%.1f",v);
        return String.format(Locale.US,"%.1f %s",v,unit);
    }

    private int blend(int a,int b,float t){int r=(int)(Color.red(a)*(1-t)+Color.red(b)*t);int g=(int)(Color.green(a)*(1-t)+Color.green(b)*t);int bl=(int)(Color.blue(a)*(1-t)+Color.blue(b)*t);return Color.rgb(r,g,bl);}

    private void addControl(int type,int a,int b,RectF r,float min,float max,boolean log,boolean knob){
        boolean drag = type==C_MIX || type==C_EQ_GRAPH || type==C_EQ_SLIDER || type==C_XO_CUTOFF || type==C_XO_DELAY;
        controls.add(new Control(type,a,b,new RectF(r),min,max,log,knob,drag));
    }

    private static final class Control {
        final int type,a,b; final RectF r; final float min,max; final boolean log,knob,drag;
        Control(int type,int a,int b,RectF r,float min,float max,boolean log,boolean knob,boolean drag){this.type=type;this.a=a;this.b=b;this.r=r;this.min=min;this.max=max;this.log=log;this.knob=knob;this.drag=drag;}
    }
}
