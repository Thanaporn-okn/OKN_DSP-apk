package com.okn.dsp;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.okn.dsp.ui.DspUiView;

/**
 * OKN_DSP Version 6 / Phase 1 Final UI.
 * Safe-start activity: a native root is attached first so the app can always open,
 * then the DSP UI is mounted inside it. Real DSP transport is Phase 2.
 */
public class MainActivity extends Activity {
    private FrameLayout root;
    private DspUiView uiView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureWindowCompat();

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(2, 14, 29));
        setContentView(root);

        // Attach the complex UI only after a native root is already visible.
        root.post(this::mountDspUiSafely);
    }

    @Override
    protected void onResume() {
        super.onResume();
        configureWindowCompat();
        if (uiView != null) uiView.setHostActive(true);
    }

    @Override
    protected void onPause() {
        if (uiView != null) {
            uiView.persistSession();
            uiView.setHostActive(false);
        }
        super.onPause();
    }

    private void configureWindowCompat() {
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        // Conservative immersive flags supported across our full minSdk range.
        window.getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    private void mountDspUiSafely() {
        try {
            if (isFinishing() || root == null) return;
            uiView = new DspUiView(this);
            root.removeAllViews();
            root.addView(uiView, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT));
        } catch (Throwable error) {
            uiView = null;
            showStartupFallback(error);
        }
    }

    private void showStartupFallback(Throwable error) {
        if (root == null) return;
        root.removeAllViews();

        TextView fallback = new TextView(this);
        fallback.setTextColor(Color.WHITE);
        fallback.setTextSize(18f);
        fallback.setGravity(Gravity.CENTER);
        fallback.setPadding(32, 32, 32, 32);
        String type = error == null ? "unknown" : error.getClass().getSimpleName();
        fallback.setText("OKN_DSP V6\n\nSafe startup mode\nUI could not be mounted: " + type
                + "\n\nThe app process is still running.");
        root.addView(fallback, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
    }
}
