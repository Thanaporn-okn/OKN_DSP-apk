package com.okn.dsp;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsetsController;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public final class MainActivity extends Activity implements DspView.Host {
    private DspView dspView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dspView = new DspView(this);
        setContentView(dspView);
        applySystemBars(dspView.getThemeIndex());
    }

    @Override
    protected void onPause() {
        // Synchronous lifecycle checkpoint so an app swipe-away/relaunch restores
        // the last visible values instead of an earlier asynchronous snapshot.
        if (dspView != null) dspView.flushState();
        super.onPause();
    }

    @Override
    protected void onStop() {
        if (dspView != null) dspView.flushState();
        super.onStop();
    }

    @Override
    public void requestThemePicker(int currentTheme) {
        String[] items = {"Light", "Dark", "Midnight"};
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Theme")
                .setSingleChoiceItems(items, currentTheme, null)
                .setNegativeButton("Cancel", null)
                .create();

        dialog.setOnShowListener(ignored -> {
            lockDialogTypeface(dialog);
            dialog.getListView().setOnItemClickListener((parent, view, position, id) -> {
                dspView.setThemeIndex(position);
                dspView.flushState();
                applySystemBars(position);
                dialog.dismiss();
            });
        });
        dialog.show();
    }

    @Override
    public void requestPresetName(String currentName) {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setText(currentName == null ? "" : currentName);
        if (input.getText().length() > 0) input.selectAll();
        input.setTypeface(AppFonts.REGULAR);
        int pad = (int) (20f * getResources().getDisplayMetrics().density);
        input.setPadding(pad, pad / 2, pad, pad / 2);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Preset name")
                .setView(input)
                .setPositiveButton("Save", (d, which) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) name = "Preset";
                    dspView.savePreset(name);
                    dspView.flushState();
                })
                .setNegativeButton("Cancel", null)
                .create();
        dialog.setOnShowListener(ignored -> lockDialogTypeface(dialog));
        dialog.show();
    }


    @Override
    public void requestPresetPicker(String currentName) {
        String[] names = dspView.getPresetNames();
        if (names.length == 0) {
            showMessage("No saved presets");
            return;
        }
        int checked = -1;
        for (int i = 0; i < names.length; i++) {
            if (names[i].equals(currentName)) {
                checked = i;
                break;
            }
        }
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Saved Presets")
                .setSingleChoiceItems(names, checked, null)
                .setNegativeButton("Cancel", null)
                .create();
        dialog.setOnShowListener(ignored -> {
            lockDialogTypeface(dialog);
            dialog.getListView().setOnItemClickListener((parent, view, position, id) -> {
                dspView.selectPreset(names[position]);
                dspView.flushState();
                dialog.dismiss();
            });
        });
        dialog.show();
    }

    @Override
    public void requestDeletePreset(String currentName) {
        String[] names = dspView.getPresetNames();
        if (names.length == 0) {
            showMessage("No saved presets");
            return;
        }
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Delete preset")
                .setMessage("Delete preset ‘" + currentName + "’?")
                .setPositiveButton("Delete", (d, which) -> {
                    dspView.deletePreset(currentName);
                    dspView.flushState();
                })
                .setNegativeButton("Cancel", null)
                .create();
        dialog.setOnShowListener(ignored -> lockDialogTypeface(dialog));
        dialog.show();
    }

    @Override
    public void showMessage(String message) {
        Toast toast = Toast.makeText(this, message, Toast.LENGTH_SHORT);
        toast.show();
    }

    private void lockDialogTypeface(AlertDialog dialog) {
        Window w = dialog.getWindow();
        if (w == null) return;
        applyTypefaceRecursive(w.getDecorView());
    }

    private void applyTypefaceRecursive(View view) {
        if (view instanceof TextView) {
            TextView tv = (TextView) view;
            int style = tv.getTypeface() == null ? 0 : tv.getTypeface().getStyle();
            tv.setTypeface((style & android.graphics.Typeface.BOLD) != 0 ? AppFonts.BOLD : AppFonts.REGULAR);
        }
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                applyTypefaceRecursive(group.getChildAt(i));
            }
        }
    }

    private void applySystemBars(int themeIndex) {
        boolean light = themeIndex == 0;
        int bg;
        if (themeIndex == 0) bg = 0xFFF4F7FB;
        else if (themeIndex == 1) bg = 0xFF0D1320;
        else bg = 0xFF050A13;

        Window window = getWindow();
        window.setStatusBarColor(bg);
        window.setNavigationBarColor(bg);

        if (android.os.Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = window.getInsetsController();
            if (c != null) {
                int mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                        | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                c.setSystemBarsAppearance(light ? mask : 0, mask);
            }
        } else {
            int flags = window.getDecorView().getSystemUiVisibility();
            if (light) {
                flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                if (android.os.Build.VERSION.SDK_INT >= 26) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            } else {
                flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                if (android.os.Build.VERSION.SDK_INT >= 26) flags &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            }
            window.getDecorView().setSystemUiVisibility(flags);
        }
    }
}
