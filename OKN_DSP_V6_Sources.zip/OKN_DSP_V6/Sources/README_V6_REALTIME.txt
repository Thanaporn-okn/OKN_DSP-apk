OKN_DSP V6 — REALTIME HARDWARE CONTROL
======================================

WHY V6 EXISTS
V5 connected over BLE but changed only the local UI state. It did not implement the authenticated GoloPine application session or UFE writes, so the physical DSP sound did not change.

V6 VERIFIED CONTROL PATH
BLE scan/connect
  -> service AB00
  -> AB02 notification enable
  -> AUTH16 631C062443FD3844558001F3EDA0CCF8 on AB01
  -> decode 32-byte auth response
  -> derive current 16-byte RandKey
  -> independent continuous AES/CFB8/NoPadding TX/RX streams, IV=01 x 16
  -> encrypted Device Description request plaintext 661C0624
  -> collect/decrypt 0x86 header + 0x82 continuation JSON
  -> Health Gate: 7 known scalars + 105 EQ records + >=4 sensors
  -> READY
  -> encrypted UFE WRITE_ACTUATOR (0x57) real-time writes on AB01

VERIFIED HOME HARDWARE ACTUATORS
ID 2  MasterVolume       -70 .. +6 dB
ID 8  BassVolume         -70 .. +6 dB
ID 9  BassCutoff          20 .. 250 Hz
ID 10 BassBoost          -12 .. +12 dB
ID 13 MiddleBoost        -12 .. +12 dB
ID 11 TrebleBoost        -12 .. +12 dB
(ID 3 RemindSoundVolume is verified in protocol but is not exposed by the supplied Home screenshot.)

VERIFIED EQ HARDWARE
CH1..CH7 actuator IDs = 4,5,6,14,15,16,17
15 records per channel, 48 bytes per record.
Only live Device Description records that are PEAKING type=12 with the verified field shape are writable.
The six UI points are mapped dynamically to the nearest six verified PEAKING records for each channel. A drag writes a complete 48-byte peaking record (F/Q/Gain and RBJ coefficients) to the mapped hardware band.

REALTIME ORDERING
- UI changes immediately under the finger.
- One BLE write is allowed in flight.
- Pending values are coalesced per parameter (latest-target-wins).
- Minimum normal pacing: 38 ms after successful GATT callback.
- TrebleBoost ID11: callback-gated <=0.5 dB steps, >=48 ms between steps.
- Encryption occurs only when a command is actually sent. Replaced pending commands do not consume AES-CFB8 stream state.
- If write ordering/cipher state becomes uncertain, V6 fails closed and reconnects/authenticates from a fresh session.

LOCKED BECAUSE NOT VERIFIED ON THIS DSP
- per-channel Fader / Mute / Phase hardware packets
- Crossover hardware packets
- Delay hardware packets
- hardware Preset recall/write packet
- generic/unknown actuator writes
Those visible controls can still change local UI state, but V6 does not invent unsafe DSP packets for them.

UPDATE SIGNING
V6 keeps the exact V5 signing keystore and applicationId com.okn.dsp.
Do not regenerate the keystore in future versions.
