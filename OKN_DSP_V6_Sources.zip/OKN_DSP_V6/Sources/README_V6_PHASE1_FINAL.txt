OKN_DSP V6 - Phase 1 Final UI

Purpose
- Finalize the UI-only phase before real DSP transport is introduced in Phase 2.
- UI is drawn from Android Canvas/vector primitives. The uploaded reference screenshot is not bundled or used as a background.

V6 changes
- versionCode 6 / versionName 6.0.0.
- Keeps applicationId com.okn.dsp and the exact V5 signing keystore so V6 is an in-place update over V5.
- Corrects stale V4 labels left in earlier source and shows V6 consistently in the app.
- Uses a stable SharedPreferences namespace and migrates the V4/V5 local preset on first V6 launch.
- Saves current UI/DSP-control state when controls are released and when the Activity pauses, then restores it at startup.
- EQ graph is directly draggable: horizontal movement adjusts selected-band frequency and vertical movement adjusts gain.
- EQ response preview now reacts to Frequency, Gain and Q in real time.
- Touch targets retain immediate event-driven rendering; no permanent redraw loop is used.
- Crossover and delay graphs/controls remain real-time UI simulations only.

Phase boundary
V6 still sends no packets to DSP hardware. BLE/transport/protocol work starts only in Phase 2 after protocol source data is supplied.
