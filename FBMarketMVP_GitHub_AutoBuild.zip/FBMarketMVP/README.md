# FB Market MVP

Android/Jetpack Compose starter for a location-aware product feed with separate `GROUP` and `MARKETPLACE` source adapters.

## Included now
- Home: latest products, search, category chips and distance filter.
- Groups: followed groups + group-only products.
- Marketplace: marketplace-only product grid.
- Saved: local in-memory favorites for the MVP.
- Settings: location status and app architecture notes.
- Product detail screen.
- Foreground coarse/fine location permission handling.
- Real distance calculation from the current device location to demo product coordinates.
- Source adapter boundary so UI does not depend on Facebook-specific collection code.

## Important data-source note
The included feed is DEMO DATA. Do not treat it as a live Facebook feed. The next integration step is to connect an approved/authorized backend source through `ProductSourceAdapter` or replace the repository with an HTTP API implementation.

## Build stack
- Android Gradle Plugin 9.4.0
- Gradle 9.6
- Kotlin 2.2.10
- Jetpack Compose BOM 2026.09.00
- Activity Compose 1.13.0
- Lifecycle 2.11.0
- Google Play services Location 21.4.0
- minSdk 24, target/compileSdk 37

## Open and run
1. Open this folder in a current Android Studio.
2. Install Android SDK Platform 37 if prompted.
3. Use JDK 17 (Android Studio's compatible embedded JDK is fine).
4. Sync Gradle.
5. Run on a physical Android device or Google APIs emulator.
6. Grant approximate or precise location when you want distance sorting/filtering.

The included `gradlew`/`gradlew.bat` are lightweight bootstrap scripts that download Gradle 9.6 on first use. They are used because this generated archive does not embed the binary Gradle wrapper JAR.

## Privacy choice
No background location permission is declared. The MVP asks only for foreground location and continues working without location permission; distance filtering is simply unavailable.

## Next implementation milestone
Replace demo adapters with a backend API, add Room cache + pagination + deduplication, then add FCM notifications/saved-search alerts.

## Automatic APK build (GitHub Actions)

The workflow `.github/workflows/build-apk.yml` builds the Android debug APK automatically on code pushes and can also be started manually from **Actions → Build Android APK → Run workflow**.

Successful runs publish a directly downloadable artifact named `build.apk` plus `build.apk.sha256`.

The CI intentionally installs Gradle 9.6 itself, so the build does not depend on a checked-in `gradle-wrapper.jar`.
