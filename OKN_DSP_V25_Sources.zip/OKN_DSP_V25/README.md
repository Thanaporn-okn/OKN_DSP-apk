# OKN DSP V25 — Phase 1

Base: V24. V25 keeps all V24 touch-isolation, smooth modal, preset, persistence, and safe-area fixes.

## V25 color update

- Added **pink** and **red/rose** accents across the app.
- Home: DSP Device, Audio Input and Quick Control now add pink/red accents.
- Mix: Bass Volume = pink, Bass Cutoff = red/rose; Ch1–Ch7 use mint/teal/green plus pink/red.
- EQ: Ch1–Ch7 and the 15-band graph include pink/red points while Frequency remains blue, Q remains cyan/teal, and Gain Band remains mint green.
- Preset name / Save Preset uses pink; Reset EQ and Delete remain red.
- Bottom navigation: Home selected = pink, Mix selected = mint, EQ selected = red/rose.
- Orange and amber are still excluded.

versionName: 25.0.0
versionCode: 1025
Phase: 1 UI hardening
