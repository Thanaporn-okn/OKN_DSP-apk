package com.okn.dsp

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/** V85 all-status disconnect fail-closed unification launcher; V84 writer/protocol behavior carried unchanged. */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startActivity(Intent(this, UnifiedControlActivity::class.java))
        finish()
    }
}
