OKN_DSP V18 — NEW UI / REALTIME INTERACTION ARCHITECTURE
=========================================================

Goal
----
Rebuild the app UI from scratch to match the approved four-screen design:
1. Home — connection status, DSP device card, Master Volume, quick presets.
2. Mix — Output Volume 7 Channels with per-channel vertical fader, mute and link groups.
3. EQ — Parametric/Graphic EQ, 15 real bands x 7 channels.
4. Crossover — HPF, LPF and Delay controls per channel.

Realtime behavior
-----------------
- Every visible control updates the UI immediately while the finger moves.
- UI drawing and touch handling are never blocked by sleeps or by a BLE round trip.
- Verified hardware targets use latest-value coalescing: stale intermediate touch values are discarded.
- BLE connection priority is HIGH after connection, while the application command cadence remains the verified safe cadence.

Verified hardware path from uploaded V17 evidence
--------------------------------------------------
- AB00 service / AB01 TX / AB02 RX.
- WRITE WITHOUT RESPONSE on AB01.
- 16-byte authentication request + AES-CFB8 stream.
- UFE 0x57 actuator writes / 0x58 reads.
- Master Volume ID2.
- 15-band EQ actuators: CH1=4, CH2=5, CH3=6, CH4=14, CH5=15, CH6=16, CH7=17.
- V17 filter-aware first-band behavior is preserved.

Important transport boundary
----------------------------
The uploaded hardware evidence proves that the official app serializes application commands at about 380 ms.
Earlier high-rate callback-driven writes caused audible stutter/pumping on the real DSP. Therefore V18 makes the UI
feel realtime but does NOT bypass the verified DSP scheduler. The newest requested value replaces older queued values.

Output / Crossover / Delay boundary
-----------------------------------
The uploaded V17 evidence explicitly states that Output Fader / Mute / Phase, Crossover and Delay hardware writes were
not yet packet-qualified. V18 therefore implements their complete realtime UI interaction but does not invent actuator
IDs or packet layouts. Unknown controls are visibly marked HW MAP PENDING and call the diagnostic hook instead of sending
a guessed DSP packet. This is intentional: no fake or unsafe hardware write is claimed.

Next hardware qualification input needed to unlock those blocks
----------------------------------------------------------------
A real-device packet/descriptor capture while changing each of these controls in the original app:
- Output gain CH1..CH7
- Output mute CH1..CH7
- HPF frequency + slope
- LPF frequency + slope
- Delay CH1..CH7

Once those packet mappings are captured, the UI and state model are already prepared for direct binding.
