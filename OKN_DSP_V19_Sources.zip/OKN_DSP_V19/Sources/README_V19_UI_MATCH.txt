OKN_DSP V19 UI MATCH

- Reworked custom Canvas geometry to 786x1702 (9:19.5) for modern Samsung portrait displays.
- Home/Mix/EQ/Crossover composition now follows UI_REFERENCE_V18_4PAGES.png much more closely.
- Preserved verified V18 BLE scalar realtime writes and EQ realtime writes.
- Preserved safe/coalesced BLE scheduler; visual changes do not bypass BleManager.
- Crossover/Delay/Output Gain remain UI-interactive only until verified hardware mapping exists.
- Crossover channel picker is the CHx pill in the top-right; tap to cycle CH1..CH7.
