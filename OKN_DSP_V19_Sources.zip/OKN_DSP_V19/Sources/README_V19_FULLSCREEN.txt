OKN_DSP V19 - RESPONSIVE FULL-SCREEN
====================================
This version fixes the V18 16:9 letterbox behavior seen on the supplied 1080x2340 Samsung-class portrait screen recording.

Rendering strategy
- Base UI geometry remains 864x1536 to preserve the supplied reference design.
- On tall portrait screens, width is the master scale so the app fills left/right exactly.
- Extra screen height is converted to logical UI space and distributed across Home/EQ/Crossover/Delay/Output section gaps.
- Text, circles, icons and controls are NOT non-uniformly stretched.
- The bottom navigation bar follows the actual bottom of the screen.
- On shorter displays the previous aspect-fit fallback remains available.

Interaction
- Touch coordinates are inverse-mapped using the same full-screen scale.
- Every moved section has matching V19 hit-box offsets.
- Real-time BLE paths from V18 are unchanged.

Android immersive mode
- Edge-to-edge layout remains enabled.
- Status and navigation bars are transparent/hidden.
- Immersive mode is re-applied whenever the Activity regains window focus, including after permission dialogs.
