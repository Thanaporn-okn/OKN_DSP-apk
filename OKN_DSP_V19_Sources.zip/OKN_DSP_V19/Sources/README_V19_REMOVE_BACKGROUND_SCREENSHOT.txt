OKN_DSP V19 - Phase 1 UI correction

Reason for new version:
- V18 rendered the supplied UI reference PNG as a full-screen background and then drew live controls over it.
- On-device testing showed duplicated/ghost knobs and values because the original controls were still visible in that background image.

V19 correction:
- Runtime no longer decodes or draws ui_home.png / ui_mix.png / ui_eq.png / ui_crossover.png.
- Runtime screenshot drawable files were removed from app/src/main/res/drawable-nodpi.
- Header, panels, neon waves, DSP device illustration, cards, labels, graphs, controls and bottom navigation are drawn natively with Android Canvas.
- Live sliders/buttons keep immediate local updates on ACTION_DOWN/ACTION_MOVE; no BLE/DSP round trip is used in Phase 1.
- Reference images remain only under Sources/ for design comparison and are not packaged as runtime page backgrounds.

Phase 2 DSP binding remains disabled until the real DSP control data/protocol is supplied.
