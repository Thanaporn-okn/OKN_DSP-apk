OKN_DSP V18 — PHASE 1 UI

Status
- Phase 1 UI: implemented.
- Phase 2 real DSP control: intentionally not enabled in this version.

Reference screens
- UI_REFERENCE_HOME_V18.png
- UI_REFERENCE_MIX_V18.png
- UI_REFERENCE_EQ_V18.png
- UI_REFERENCE_CROSSOVER_V18.png

Implemented interactions
1. Home
   - Master Volume slider updates immediately while dragging.
   - Mix / EQ / Crossover cards navigate to their screens.
   - Quick Preset buttons update local tone/EQ state.
   - Preset card saves the local Phase 1 tone state.
2. Mix
   - Master Volume, Bass Volume, Bass Cutoff, Bass Boost, Middle Boost, Treble Boost.
   - Values redraw on every MotionEvent move; no BLE round-trip is required.
3. EQ
   - 7 channels.
   - 15 bands per channel.
   - Band Frequency can move freely from 20 Hz to 20 kHz.
   - Gain range -12 dB to +12 dB.
   - Q range 0.1 to 10.0.
   - Graph points and curve redraw immediately.
   - Channel Output slider.
   - Local Save/Load Preset and Quick Presets.
4. Crossover
   - 7 channels.
   - HPF/LPF on/off, frequency and 6/12/18/24 dB slope selection.
   - Delay time and derived distance display.
   - 0/180 degree phase/polarity.
   - Link Filters toggle.
   - Crossover curve redraws immediately.
5. Navigation
   - Bottom navigation on all screens: Home / Mix / Eq / Crossover.

Display behavior
- Uses the supplied 864x1536 reference artwork as the visual base.
- Draws edge-to-edge under immersive full-screen mode.
- Touch coordinates and live overlays scale to the actual device width/height, covering phones and tablets in portrait orientation.

Phase 2 note
- Existing V17 BLE/protocol classes are retained in the source tree for later hardware binding.
- MainActivity intentionally does not start BLE or send DSP writes in V18 Phase 1.
- When the real DSP control files/protocol data are supplied, bind Phase1UiView state changes to the verified protocol in a new version.
