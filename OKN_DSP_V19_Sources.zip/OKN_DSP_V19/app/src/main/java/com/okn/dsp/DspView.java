package com.okn.dsp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import java.util.Locale;

/**
 * OKN_DSP V19 visual-match UI.
 *
 * Geometry is authored for a 9:19.5 phone canvas (786 x 1702) so modern Samsung
 * displays fill naturally. UI tracking is immediate; verified DSP writes still go
 * through the existing BleManager coalescing/safe scheduler.
 */
final class DspView extends View {
    private static final float W = 786f;
    private static final float H = 1702f;
    private static final float NAV_H = 120f;

    private static final int PAGE_HOME = 0;
    private static final int PAGE_MIX = 1;
    private static final int PAGE_EQ = 2;
    private static final int PAGE_XOVER = 3;

    private static final int DRAG_NONE = 0;
    private static final int DRAG_MIX = 1;
    private static final int DRAG_EQ_FREQ = 2;
    private static final int DRAG_EQ_GAIN = 3;
    private static final int DRAG_EQ_Q = 4;
    private static final int DRAG_OUTPUT = 5;
    private static final int DRAG_HPF = 6;
    private static final int DRAG_LPF = 7;
    private static final int DRAG_DELAY = 8;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final DspState state = new DspState();

    private BleManager ble;
    private int page = PAGE_HOME;
    private int dragKind = DRAG_NONE;
    private int dragIndex = -1;
    private float scale = 1f;
    private float offsetX = 0f;
    private float offsetY = 0f;

    private String bleStatus = "กำลังค้นหา DSP";
    private String bleDevice = "OKN-DSP_7CH";
    private boolean bleConnected = false;
    private String diagnostic = "";

    private final int BG_TOP = Color.rgb(7, 18, 28);
    private final int BG_BOTTOM = Color.rgb(2, 8, 14);
    private final int PANEL = Color.rgb(15, 29, 42);
    private final int PANEL_2 = Color.rgb(19, 36, 50);
    private final int PANEL_3 = Color.rgb(10, 23, 34);
    private final int BORDER = Color.rgb(42, 64, 80);
    private final int TRACK = Color.rgb(44, 59, 71);
    private final int WHITE = Color.rgb(244, 248, 251);
    private final int SUB = Color.rgb(150, 166, 179);
    private final int CYAN = Color.rgb(25, 203, 232);
    private final int BLUE = Color.rgb(28, 132, 239);
    private final int GREEN = Color.rgb(53, 219, 112);
    private final int ORANGE = Color.rgb(255, 174, 65);
    private final int RED = Color.rgb(255, 77, 91);

    DspView(Context context, BleManager ble) {
        super(context);
        this.ble = ble;
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        setFocusable(true);
        setClickable(true);
        setHapticFeedbackEnabled(false);
    }

    void setBleManager(BleManager ble) { this.ble = ble; }

    void setBleStatus(String status, String deviceName, boolean connected) {
        bleStatus = status == null ? "" : status;
        if (deviceName != null && !deviceName.isEmpty()) bleDevice = deviceName;
        bleConnected = connected;
        invalidate();
    }

    void setDiagnostic(String message) {
        diagnostic = message == null ? "" : message;
        invalidate();
    }

    void setScalarFromDsp(int actuatorId, float value) {
        switch (actuatorId) {
            case DspProtocol.ID_MASTER_VOLUME: state.masterVolume = value; break;
            case DspProtocol.ID_BASS_VOLUME: state.bassVolume = value; break;
            case DspProtocol.ID_BASS_CUTOFF: state.bassCutoff = value; break;
            case DspProtocol.ID_BASS_BOOST: state.bassBoost = value; break;
            case DspProtocol.ID_MIDDLE_BOOST: state.middleBoost = value; break;
            case DspProtocol.ID_TREBLE_BOOST: state.trebleBoost = value; break;
            default: return;
        }
        invalidate();
    }

    void setEqFromDsp(int channel0, int band0, float frequency, float gainDb, float q,
                      boolean writable, boolean shapeWritable) {
        if (channel0 < 0 || channel0 >= DspState.CHANNELS || band0 < 0 || band0 >= DspState.BANDS) return;
        state.freq[channel0][band0] = frequency;
        state.gain[channel0][band0] = gainDb;
        state.q[channel0][band0] = q;
        state.eqWritable[channel0][band0] = writable;
        state.eqShapeWritable[channel0][band0] = shapeWritable;
        invalidate();
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        scale = Math.min(getWidth() / W, getHeight() / H);
        offsetX = (getWidth() - W * scale) * 0.5f;
        offsetY = (getHeight() - H * scale) * 0.5f;

        c.drawColor(BG_BOTTOM);
        c.save();
        c.translate(offsetX, offsetY);
        c.scale(scale, scale);
        drawBackground(c);
        if (page == PAGE_HOME) drawHome(c);
        else if (page == PAGE_MIX) drawMix(c);
        else if (page == PAGE_EQ) drawEq(c);
        else drawCrossover(c);
        drawBottomNav(c);
        c.restore();
    }

    private void drawBackground(Canvas c) {
        p.setShader(new LinearGradient(0, 0, 0, H, BG_TOP, BG_BOTTOM, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, W, H, p);
        p.setShader(null);
    }

    private float navTop() { return H - NAV_H; }

    // ------------------------------------------------------------
    // HOME
    // ------------------------------------------------------------
    private void drawHome(Canvas c) {
        text(c, "DSP 7 Ch", 34, 72, 38, WHITE, true, Paint.Align.LEFT);
        text(c, "Pure Sound. Total Control.", 34, 101, 17, SUB, false, Paint.Align.LEFT);
        drawGear(c, 730, 70, 18, WHITE);

        // Connection card
        card(c, 24, 132, 738, 184, 22, PANEL, BORDER);
        p.setColor(Color.rgb(7, 72, 102));
        p.setShadowLayer(18, 0, 0, Color.argb(180, 0, 185, 255));
        c.drawCircle(94, 224, 48, p);
        p.clearShadowLayer();
        drawBluetooth(c, 94, 224, 26, WHITE);
        p.setColor(bleConnected ? GREEN : ORANGE);
        c.drawCircle(181, 186, 10, p);
        text(c, bleConnected ? "Device Connected" : "กำลังค้นหา DSP...", 207, 193, 24, WHITE, true, Paint.Align.LEFT);
        text(c, bleDevice, 207, 226, 16, SUB, false, Paint.Align.LEFT);
        text(c, bleConnected ? "Ready for audio processing" : "แตะเพื่อค้นหาอุปกรณ์อีกครั้ง", 207, 255, 15, SUB, false, Paint.Align.LEFT);
        drawChevron(c, 725, 224, SUB);

        // DSP information card
        card(c, 24, 338, 738, 330, 22, PANEL, BORDER);
        drawDspBox(c, 55, 416, 265, 154);
        text(c, "DSP 7 Ch", 394, 398, 27, WHITE, true, Paint.Align.LEFT);
        text(c, "7 Channel Digital Signal Processor", 394, 429, 16, SUB, false, Paint.Align.LEFT);
        infoPair(c, 394, 473, "Firmware", "v19.0.0");
        infoPair(c, 394, 510, "Input Source", "Bluetooth");
        infoPair(c, 394, 547, "Sample Rate", "48 kHz");
        infoPair(c, 394, 584, "Status", bleConnected ? "Normal" : "Searching");

        // Main navigation shortcuts
        homeTile(c, 24, 694, 230, 226, "Mix", "Volume & Tone", PAGE_MIX, 0);
        homeTile(c, 278, 694, 230, 226, "EQ", "7 Ch Equalizer", PAGE_EQ, 1);
        homeTile(c, 532, 694, 230, 226, "Crossover", "Filter & Delay", PAGE_XOVER, 2);

        // Banner
        card(c, 24, 946, 738, 154, 20, PANEL_3, BORDER);
        text(c, "Better Sound", 48, 995, 24, WHITE, true, Paint.Align.LEFT);
        text(c, "A Brighter Drive", 48, 1027, 20, SUB, false, Paint.Align.LEFT);
        drawWave(c, 250, 986, 460, 62, CYAN);
        text(c, "DSP 7 Ch", 718, 1029, 16, SUB, true, Paint.Align.RIGHT);

        // Small state summary, visually quiet like the reference bottom area.
        if (!diagnostic.isEmpty()) {
            String d = diagnostic.length() > 74 ? diagnostic.substring(0, 74) + "…" : diagnostic;
            text(c, d, 34, 1152, 13, Color.rgb(99, 121, 136), false, Paint.Align.LEFT);
        }
    }

    private void drawDspBox(Canvas c, float x, float y, float w, float h) {
        p.setColor(Color.rgb(4, 8, 13));
        Path body = new Path();
        body.moveTo(x + 10, y + 45);
        body.lineTo(x + w * .66f, y);
        body.lineTo(x + w, y + 50);
        body.lineTo(x + w - 10, y + h);
        body.lineTo(x + 6, y + h - 32);
        body.close();
        c.drawPath(body, p);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(2);
        stroke.setColor(Color.rgb(54, 67, 78));
        c.drawPath(body, stroke);
        text(c, "DSP 7 Ch", x + w * .63f, y + h * .67f, 18, WHITE, true, Paint.Align.CENTER);
    }

    private void homeTile(Canvas c, float x, float y, float w, float h, String title, String sub, int target, int icon) {
        card(c, x, y, w, h, 20, PANEL, BORDER);
        p.setColor(Color.argb(42, 26, 203, 232));
        c.drawRoundRect(new RectF(x + 24, y + 28, x + 84, y + 88), 16, 16, p);
        if (icon == 0) drawMixIcon(c, x + 54, y + 58, CYAN);
        else if (icon == 1) drawEqIcon(c, x + 54, y + 58, CYAN);
        else drawXoverIcon(c, x + 54, y + 58, CYAN);
        text(c, title, x + 24, y + 137, 25, WHITE, true, Paint.Align.LEFT);
        text(c, sub, x + 24, y + 169, 14, SUB, false, Paint.Align.LEFT);
        drawChevron(c, x + w - 22, y + 125, SUB);
    }

    // ------------------------------------------------------------
    // MIX
    // ------------------------------------------------------------
    private void drawMix(Canvas c) {
        drawPageHeader(c, "Mix", true, false);
        String[] names = {"Master Volume", "Bass Volume", "Bass Cutoff", "Bass Boost", "Middle Boost", "Treble Boost"};
        for (int i = 0; i < 6; i++) {
            float y = mixRowY(i);
            card(c, 24, y, 738, 190, 20, PANEL, BORDER);
            drawMixRowIcon(c, 70, y + 61, i);
            text(c, names[i], 116, y + 56, 22, WHITE, true, Paint.Align.LEFT);
            text(c, mixValueTextTarget(i, mixValue(i)), 732, y + 57, 21, WHITE, true, Paint.Align.RIGHT);
            float min = mixMin(i), max = mixMax(i);
            drawHorizontalSlider(c, 116, y + 102, 690, mixValue(i), min, max, i == 2, true, 9, 13);
            text(c, mixLeftLabel(i), 116, y + 145, 12, SUB, false, Paint.Align.LEFT);
            text(c, mixRightLabel(i), 690, y + 145, 12, SUB, false, Paint.Align.RIGHT);
        }
    }

    private float mixRowY(int i) { return 128f + i * 220f; }

    private float mixValue(int i) {
        if (i == 0) return state.masterVolume;
        if (i == 1) return state.bassVolume;
        if (i == 2) return state.bassCutoff;
        if (i == 3) return state.bassBoost;
        if (i == 4) return state.middleBoost;
        return state.trebleBoost;
    }

    private float mixMin(int i) { return i <= 1 ? -70f : i == 2 ? 20f : -12f; }
    private float mixMax(int i) { return i <= 1 ? 6f : i == 2 ? 250f : 12f; }

    private String mixValueTextTarget(int i, float v) {
        if (i <= 1) {
            int pct = Math.round(clamp((v + 70f) / 76f, 0f, 1f) * 100f);
            return pct + "%";
        }
        if (i == 2) return String.format(Locale.US, "%.0f Hz", v);
        return String.format(Locale.US, "%+.1f dB", v);
    }

    private String mixLeftLabel(int i) {
        if (i <= 1) return "0%";
        if (i == 2) return "20 Hz";
        return "-12 dB";
    }

    private String mixRightLabel(int i) {
        if (i <= 1) return "100%";
        if (i == 2) return "250 Hz";
        return "+12 dB";
    }

    // ------------------------------------------------------------
    // EQ
    // ------------------------------------------------------------
    private void drawEq(Canvas c) {
        drawPageHeader(c, "EQ", true, true);
        drawChannelTabs(c, 112);
        drawEqGraph(c);
        drawEqBands(c);

        int ch = state.channel;
        int b = state.selectedBand;
        text(c, "‹", 302, 866, 36, SUB, false, Paint.Align.CENTER);
        text(c, "Band " + (b + 1) + " / 15", 393, 860, 18, WHITE, true, Paint.Align.CENTER);
        text(c, "›", 484, 866, 36, SUB, false, Paint.Align.CENTER);

        drawParamCard(c, 24, 895, 230, 190, "Frequency", DspState.hz(state.freq[ch][b]),
                state.freq[ch][b], 20f, 20000f, true, state.eqShapeWritable[ch][b]);
        drawParamCard(c, 278, 895, 230, 190, "Gain", DspState.db(state.gain[ch][b]),
                state.gain[ch][b], -12f, 12f, false, state.eqWritable[ch][b]);
        drawParamCard(c, 532, 895, 230, 190, "Q (Quality Factor)", String.format(Locale.US, "%.2f", state.q[ch][b]),
                state.q[ch][b], 0.05f, 20f, true, state.eqShapeWritable[ch][b]);

        card(c, 24, 1113, 738, 132, 18, PANEL, BORDER);
        drawSpeaker(c, 58, 1170, 18, WHITE);
        text(c, "Output Gain (" + DspState.CHANNEL_SHORT[ch] + ")", 92, 1160, 18, WHITE, true, Paint.Align.LEFT);
        drawHorizontalSlider(c, 330, 1168, 640, state.fader[ch], -60f, 12f, false, true, 8, 11);
        text(c, DspState.db(state.fader[ch]), 730, 1198, 13, SUB, false, Paint.Align.RIGHT);

        filledButton(c, 24, 1270, 355, 92, "▣  Save Preset");
        filledButton(c, 407, 1270, 355, 92, "▱  Load Preset");
        text(c, "EQ changes track your finger immediately", 393, 1410, 13, Color.rgb(87, 116, 132), false, Paint.Align.CENTER);
    }

    private void drawEqGraph(Canvas c) {
        float gx = 70, gy = 222, gw = 646, gh = 300;
        card(c, 24, 198, 738, 356, 18, PANEL_3, BORDER);
        stroke.setStrokeWidth(1);
        stroke.setColor(Color.rgb(34, 55, 69));
        for (int i = 0; i <= 10; i++) {
            float x = gx + gw * i / 10f;
            c.drawLine(x, gy, x, gy + gh, stroke);
        }
        for (int i = 0; i <= 4; i++) {
            float y = gy + gh * i / 4f;
            c.drawLine(gx, y, gx + gw, y, stroke);
        }
        int ch = state.channel;
        Path line = new Path();
        Path fill = new Path();
        for (int b = 0; b < DspState.BANDS; b++) {
            float x = freqX(state.freq[ch][b], gx, gw);
            float y = gainY(state.gain[ch][b], gy, gh);
            if (b == 0) { line.moveTo(x, y); fill.moveTo(x, gy + gh / 2f); fill.lineTo(x, y); }
            else { line.lineTo(x, y); fill.lineTo(x, y); }
        }
        float lastX = freqX(state.freq[ch][DspState.BANDS - 1], gx, gw);
        fill.lineTo(lastX, gy + gh / 2f);
        fill.close();
        p.setColor(Color.argb(40, 23, 202, 232));
        c.drawPath(fill, p);
        stroke.setStrokeWidth(4);
        stroke.setColor(CYAN);
        c.drawPath(line, stroke);
        for (int b = 0; b < DspState.BANDS; b++) {
            float x = freqX(state.freq[ch][b], gx, gw);
            float y = gainY(state.gain[ch][b], gy, gh);
            p.setColor(b == state.selectedBand ? WHITE : CYAN);
            c.drawCircle(x, y, b == state.selectedBand ? 8 : 5, p);
        }
        text(c, "+12", 58, gy + 9, 11, SUB, false, Paint.Align.RIGHT);
        text(c, "0", 58, gy + gh / 2f + 5, 11, SUB, false, Paint.Align.RIGHT);
        text(c, "-12", 58, gy + gh, 11, SUB, false, Paint.Align.RIGHT);
        String[] labels = {"20", "50", "100", "200", "500", "1K", "2K", "5K", "10K", "20K"};
        for (int i = 0; i < labels.length; i++) {
            text(c, labels[i], gx + gw * i / (labels.length - 1f), gy + gh + 24, 10, SUB, false, Paint.Align.CENTER);
        }
    }

    private void drawEqBands(Canvas c) {
        card(c, 24, 580, 738, 244, 18, PANEL, BORDER);
        text(c, "15 Band", 44, 617, 17, WHITE, true, Paint.Align.LEFT);
        text(c, "แตะ band เพื่อเลือก", 133, 617, 12, SUB, false, Paint.Align.LEFT);
        float start = 48f, usable = 690f, col = usable / DspState.BANDS;
        float top = 651, bottom = 757;
        int ch = state.channel;
        for (int b = 0; b < DspState.BANDS; b++) {
            float cx = start + col * (b + .5f);
            boolean sel = b == state.selectedBand;
            p.setStrokeWidth(sel ? 5 : 3);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(Color.rgb(52, 71, 85));
            c.drawLine(cx, top, cx, bottom, p);
            float ky = top + (12f - clamp(state.gain[ch][b], -12f, 12f)) / 24f * (bottom - top);
            p.setColor(sel ? CYAN : ORANGE);
            c.drawCircle(cx, ky, sel ? 8 : 6, p);
            text(c, Integer.toString(b + 1), cx, 789, 9, sel ? WHITE : SUB, sel, Paint.Align.CENTER);
        }
        p.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawParamCard(Canvas c, float x, float y, float w, float h, String label, String valueText,
                               float value, float min, float max, boolean log, boolean hwLive) {
        card(c, x, y, w, h, 18, PANEL, BORDER);
        text(c, label, x + 18, y + 35, 14, SUB, false, Paint.Align.LEFT);
        text(c, valueText, x + 18, y + 72, 22, WHITE, true, Paint.Align.LEFT);
        drawHorizontalSlider(c, x + 18, y + 118, x + w - 18, value, min, max, log, true, 7, 10);
        text(c, hwLive ? "DSP LIVE" : "UI LIVE", x + 18, y + 158, 10, hwLive ? GREEN : ORANGE, true, Paint.Align.LEFT);
    }

    // ------------------------------------------------------------
    // CROSSOVER
    // ------------------------------------------------------------
    private void drawCrossover(Canvas c) {
        drawPageHeader(c, "Crossover", true, false);
        channelPill(c, 634, 32, 104, 52);
        drawCrossoverGraph(c);
        int ch = state.channel;
        drawCrossoverCard(c, 24, 590, "High Pass Filter (HPF)", state.hpfEnabled[ch], state.hpfHz[ch], true);
        drawCrossoverCard(c, 24, 842, "Low Pass Filter (LPF)", state.lpfEnabled[ch], state.lpfHz[ch], false);

        card(c, 24, 1094, 738, 172, 20, PANEL, BORDER);
        drawClock(c, 63, 1144, 18, WHITE);
        text(c, "Delay", 102, 1150, 21, WHITE, true, Paint.Align.LEFT);
        text(c, String.format(Locale.US, "%.2f ms", state.delayMs[ch]), 730, 1150, 17, WHITE, true, Paint.Align.RIGHT);
        drawHorizontalSlider(c, 102, 1200, 682, state.delayMs[ch], 0f, 20f, false, true, 8, 11);
        text(c, "0.00 ms", 102, 1235, 11, SUB, false, Paint.Align.LEFT);
        text(c, "20.00 ms", 682, 1235, 11, SUB, false, Paint.Align.RIGHT);

        filledButton(c, 24, 1302, 355, 92, "▣  Save Preset");
        filledButton(c, 407, 1302, 355, 92, "▱  Load Preset");
        text(c, "Crossover / Delay are UI-ready; hardware mapping stays locked until verified", 393, 1432, 12,
                Color.rgb(91, 116, 131), false, Paint.Align.CENTER);
    }

    private void drawCrossoverGraph(Canvas c) {
        float gx = 68, gy = 154, gw = 648, gh = 352;
        card(c, 24, 126, 738, 428, 18, PANEL_3, BORDER);
        stroke.setStrokeWidth(1);
        stroke.setColor(Color.rgb(34, 55, 69));
        for (int i = 0; i <= 10; i++) c.drawLine(gx + gw * i / 10f, gy, gx + gw * i / 10f, gy + gh, stroke);
        for (int i = 0; i <= 5; i++) c.drawLine(gx, gy + gh * i / 5f, gx + gw, gy + gh * i / 5f, stroke);
        int ch = state.channel;
        float hx = freqX(state.hpfHz[ch], gx, gw);
        float lx = freqX(state.lpfHz[ch], gx, gw);
        float top = gy + 42;
        Path hp = new Path();
        hp.moveTo(gx, gy + gh);
        hp.lineTo(Math.max(gx, hx - 62), gy + gh);
        hp.lineTo(hx, top);
        hp.lineTo(gx + gw, top);
        stroke.setStrokeWidth(4); stroke.setColor(BLUE); c.drawPath(hp, stroke);
        Path lp = new Path();
        lp.moveTo(gx, top); lp.lineTo(lx, top); lp.lineTo(Math.min(gx + gw, lx + 70), gy + gh); lp.lineTo(gx + gw, gy + gh);
        stroke.setColor(RED); c.drawPath(lp, stroke);
        p.setColor(BLUE); c.drawCircle(hx, top, 8, p);
        p.setColor(RED); c.drawCircle(lx, top, 8, p);
        text(c, "HPF", hx - 6, top + 62, 12, BLUE, true, Paint.Align.CENTER);
        text(c, "LPF", lx + 4, top + 62, 12, RED, true, Paint.Align.CENTER);
        String[] labels = {"20", "50", "100", "200", "500", "1K", "2K", "5K", "10K", "20K"};
        for (int i = 0; i < labels.length; i++) text(c, labels[i], gx + gw * i / 9f, gy + gh + 25, 10, SUB, false, Paint.Align.CENTER);
    }

    private void drawCrossoverCard(Canvas c, float x, float y, String title, boolean enabled, float value, boolean hp) {
        card(c, x, y, 738, 220, 20, PANEL, BORDER);
        drawToggle(c, 46, y + 50, enabled);
        text(c, title, 118, y + 56, 20, WHITE, true, Paint.Align.LEFT);
        pill(c, 492, y + 26, 242, 50, "Linkwitz-Riley (24 dB/Oct)", SUB, PANEL_2);
        drawHorizontalSlider(c, 118, y + 127, 682, value, 20f, 20000f, true, enabled, 8, 11);
        text(c, hp ? "20 Hz" : "100 Hz", 118, y + 168, 11, SUB, false, Paint.Align.LEFT);
        text(c, hp ? "300 Hz" : "20 kHz", 682, y + 168, 11, SUB, false, Paint.Align.RIGHT);
        text(c, DspState.hz(value), 730, y + 127, 14, WHITE, true, Paint.Align.RIGHT);
        text(c, "HW mapping locked", 118, y + 198, 10, ORANGE, true, Paint.Align.LEFT);
    }

    // ------------------------------------------------------------
    // SHARED UI
    // ------------------------------------------------------------
    private void drawPageHeader(Canvas c, String title, boolean back, boolean reset) {
        if (back) drawBack(c, 36, 62, WHITE);
        text(c, title, 88, 72, 31, WHITE, true, Paint.Align.LEFT);
        if (reset) text(c, "Reset", 687, 69, 15, Color.rgb(139, 204, 225), false, Paint.Align.RIGHT);
        if (!reset && page == PAGE_MIX) drawMenuDots(c, 735, 61, WHITE);
    }

    private void drawChannelTabs(Canvas c, float y) {
        float gap = 9, left = 24, w = (738f - gap * 6f) / 7f;
        for (int ch = 0; ch < DspState.CHANNELS; ch++) {
            float x = left + ch * (w + gap);
            boolean sel = ch == state.channel;
            card(c, x, y, w, 58, 12, sel ? Color.rgb(24, 171, 198) : PANEL_2, sel ? CYAN : BORDER);
            text(c, DspState.CHANNEL_SHORT[ch], x + w / 2f, y + 37, 14, sel ? Color.rgb(1, 22, 28) : SUB, true, Paint.Align.CENTER);
        }
    }

    private void channelPill(Canvas c, float x, float y, float w, float h) {
        card(c, x, y, w, h, 12, PANEL_2, BORDER);
        text(c, DspState.CHANNEL_SHORT[state.channel], x + 42, y + 34, 15, WHITE, true, Paint.Align.CENTER);
        Path t = new Path();
        t.moveTo(x + 75, y + 21); t.lineTo(x + 88, y + 21); t.lineTo(x + 81.5f, y + 29); t.close();
        p.setColor(SUB); c.drawPath(t, p);
    }

    private void drawBottomNav(Canvas c) {
        float y = navTop();
        p.setColor(Color.rgb(5, 14, 22));
        c.drawRect(0, y, W, H, p);
        stroke.setStrokeWidth(1); stroke.setColor(Color.rgb(32, 52, 66)); c.drawLine(0, y, W, y, stroke);
        String[] labels = {"Home", "Mix", "EQ", "Crossover"};
        for (int i = 0; i < 4; i++) {
            float cx = W / 8f + i * W / 4f;
            boolean sel = i == page;
            int col = sel ? CYAN : Color.rgb(122, 143, 157);
            if (sel) {
                p.setColor(Color.argb(35, 25, 203, 232));
                c.drawCircle(cx, y + 34, 25, p);
            }
            if (i == 0) drawHomeIcon(c, cx, y + 34, col);
            else if (i == 1) drawMixIcon(c, cx, y + 34, col);
            else if (i == 2) drawEqIcon(c, cx, y + 34, col);
            else drawXoverIcon(c, cx, y + 34, col);
            text(c, labels[i], cx, y + 88, 12, col, sel, Paint.Align.CENTER);
        }
    }

    private void card(Canvas c, float x, float y, float w, float h, float r, int fill, int border) {
        p.setStyle(Paint.Style.FILL); p.setColor(fill);
        c.drawRoundRect(new RectF(x, y, x + w, y + h), r, r, p);
        stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(1.2f); stroke.setColor(border);
        c.drawRoundRect(new RectF(x, y, x + w, y + h), r, r, stroke);
    }

    private void pill(Canvas c, float x, float y, float w, float h, String label, int fg, int fill) {
        card(c, x, y, w, h, h / 2f, fill, BORDER);
        text(c, label, x + w / 2f, y + h / 2f + 5, 11, fg, false, Paint.Align.CENTER);
    }

    private void filledButton(Canvas c, float x, float y, float w, float h, String label) {
        int fill = Color.rgb(17, 67, 92);
        card(c, x, y, w, h, 15, fill, Color.rgb(38, 111, 143));
        text(c, label, x + w / 2f, y + h / 2f + 7, 17, WHITE, true, Paint.Align.CENTER);
    }

    private void infoPair(Canvas c, float x, float y, String a, String b) {
        text(c, a, x, y, 15, SUB, false, Paint.Align.LEFT);
        text(c, b, 710, y, 15, WHITE, false, Paint.Align.RIGHT);
    }

    private void drawHorizontalSlider(Canvas c, float x0, float cy, float x1, float value,
                                      float min, float max, boolean log, boolean enabled,
                                      float trackWidth, float knobRadius) {
        float frac;
        if (log) {
            float v = clamp(value, min, max);
            frac = (float) ((Math.log(v) - Math.log(min)) / (Math.log(max) - Math.log(min)));
        } else frac = (value - min) / (max - min);
        frac = clamp(frac, 0f, 1f);
        float k = x0 + frac * (x1 - x0);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(trackWidth);
        p.setColor(TRACK); c.drawLine(x0, cy, x1, cy, p);
        p.setColor(enabled ? CYAN : Color.rgb(94, 109, 121)); c.drawLine(x0, cy, k, cy, p);
        p.setColor(enabled ? Color.rgb(199, 245, 252) : Color.rgb(184, 192, 198)); c.drawCircle(k, cy, knobRadius, p);
        p.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawToggle(Canvas c, float x, float cy, boolean on) {
        float w = 54, h = 30;
        card(c, x, cy - h / 2f, w, h, 15, on ? Color.rgb(16, 156, 181) : Color.rgb(52, 65, 76), on ? CYAN : BORDER);
        p.setColor(WHITE); c.drawCircle(on ? x + 39 : x + 15, cy, 10, p);
    }

    private void text(Canvas c, String s, float x, float y, float size, int color, boolean bold, Paint.Align align) {
        p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(color); p.setTextSize(size); p.setTextAlign(align);
        p.setTypeface(Typeface.create("sans", bold ? Typeface.BOLD : Typeface.NORMAL));
        c.drawText(s, x, y, p);
    }

    private void drawWave(Canvas c, float x, float y, float w, float h, int color) {
        stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(2); stroke.setColor(Color.argb(165, Color.red(color), Color.green(color), Color.blue(color)));
        for (int k = 0; k < 4; k++) {
            Path path = new Path();
            for (int i = 0; i <= 100; i++) {
                float xx = x + w * i / 100f;
                float yy = y + h / 2f + (float) Math.sin(i * (.18 + k * .012) + k) * (7 + k * 3);
                if (i == 0) path.moveTo(xx, yy); else path.lineTo(xx, yy);
            }
            c.drawPath(path, stroke);
        }
    }

    // ------------------------------------------------------------
    // ICONS
    // ------------------------------------------------------------
    private void drawBack(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(3); stroke.setStrokeCap(Paint.Cap.ROUND);
        c.drawLine(cx + 10, cy - 12, cx - 4, cy, stroke); c.drawLine(cx - 4, cy, cx + 10, cy + 12, stroke);
        c.drawLine(cx - 3, cy, cx + 18, cy, stroke); stroke.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawChevron(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(3); stroke.setStrokeCap(Paint.Cap.ROUND);
        c.drawLine(cx - 6, cy - 9, cx + 3, cy, stroke); c.drawLine(cx + 3, cy, cx - 6, cy + 9, stroke);
        stroke.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawMenuDots(Canvas c, float cx, float cy, int color) {
        p.setColor(color); c.drawCircle(cx, cy - 10, 2.4f, p); c.drawCircle(cx, cy, 2.4f, p); c.drawCircle(cx, cy + 10, 2.4f, p);
    }

    private void drawGear(Canvas c, float cx, float cy, float r, int color) {
        stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(3); stroke.setColor(color);
        c.drawCircle(cx, cy, r * .66f, stroke); c.drawCircle(cx, cy, r * .23f, stroke);
        for (int i = 0; i < 8; i++) {
            double a = Math.PI * i / 4.0;
            c.drawLine(cx + (float)Math.cos(a) * r * .72f, cy + (float)Math.sin(a) * r * .72f,
                    cx + (float)Math.cos(a) * r, cy + (float)Math.sin(a) * r, stroke);
        }
    }

    private void drawBluetooth(Canvas c, float cx, float cy, float r, int color) {
        stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(3); stroke.setStrokeCap(Paint.Cap.ROUND); stroke.setColor(color);
        Path path = new Path();
        path.moveTo(cx, cy - r); path.lineTo(cx + r * .45f, cy - r * .55f); path.lineTo(cx - r * .2f, cy); path.lineTo(cx + r * .45f, cy + r * .55f); path.lineTo(cx, cy + r); path.close();
        c.drawPath(path, stroke); c.drawLine(cx - r * .45f, cy - r * .45f, cx + r * .34f, cy + r * .34f, stroke); c.drawLine(cx - r * .45f, cy + r * .45f, cx + r * .34f, cy - r * .34f, stroke);
        stroke.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawHomeIcon(Canvas c, float cx, float cy, int color) {
        stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(2.5f); stroke.setColor(color);
        Path h = new Path(); h.moveTo(cx - 12, cy); h.lineTo(cx, cy - 10); h.lineTo(cx + 12, cy); h.lineTo(cx + 9, cy + 12); h.lineTo(cx - 9, cy + 12); h.close(); c.drawPath(h, stroke);
    }

    private void drawMixIcon(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(2.5f); p.setColor(color);
        for (int i = -1; i <= 1; i++) {
            float x = cx + i * 9; c.drawLine(x, cy - 14, x, cy + 14, stroke);
            float yy = cy + (i == -1 ? -5 : i == 0 ? 7 : -1); c.drawCircle(x, yy, 3.5f, p);
        }
    }

    private void drawEqIcon(Canvas c, float cx, float cy, int color) {
        p.setColor(color);
        float[] hs = {9, 18, 27, 14, 22};
        for (int i = 0; i < hs.length; i++) c.drawRoundRect(new RectF(cx - 17 + i * 8, cy + 14 - hs[i], cx - 13 + i * 8, cy + 14), 2, 2, p);
    }

    private void drawXoverIcon(Canvas c, float cx, float cy, int color) {
        stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(2.5f); stroke.setColor(color);
        Path a = new Path(); a.moveTo(cx - 15, cy - 12); a.cubicTo(cx - 2, cy - 12, cx - 5, cy + 12, cx + 15, cy + 12); c.drawPath(a, stroke);
        Path b = new Path(); b.moveTo(cx - 15, cy + 12); b.cubicTo(cx - 2, cy + 12, cx - 5, cy - 12, cx + 15, cy - 12); c.drawPath(b, stroke);
    }

    private void drawSpeaker(Canvas c, float cx, float cy, float r, int color) {
        p.setColor(color); Path sp = new Path(); sp.moveTo(cx-r,cy-r*.35f); sp.lineTo(cx-r*.35f,cy-r*.35f); sp.lineTo(cx+r*.35f,cy-r); sp.lineTo(cx+r*.35f,cy+r); sp.lineTo(cx-r*.35f,cy+r*.35f); sp.lineTo(cx-r,cy+r*.35f); sp.close(); c.drawPath(sp,p);
        stroke.setColor(color); stroke.setStrokeWidth(2); Path w = new Path(); w.moveTo(cx+r*.55f,cy-r*.55f); w.quadTo(cx+r*1.1f,cy,cx+r*.55f,cy+r*.55f); c.drawPath(w,stroke);
    }

    private void drawClock(Canvas c, float cx, float cy, float r, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(2.5f); c.drawCircle(cx,cy,r,stroke); c.drawLine(cx,cy,cx,cy-r*.55f,stroke); c.drawLine(cx,cy,cx+r*.45f,cy+r*.2f,stroke);
    }

    private void drawMixRowIcon(Canvas c, float cx, float cy, int i) {
        if (i == 0) drawSpeaker(c, cx, cy, 16, WHITE);
        else if (i == 1) {
            stroke.setColor(WHITE); stroke.setStrokeWidth(2.5f); c.drawCircle(cx, cy, 17, stroke); c.drawCircle(cx, cy, 7, stroke);
        } else if (i == 2) {
            stroke.setColor(WHITE); stroke.setStrokeWidth(2.5f); Path a = new Path(); a.moveTo(cx-18,cy+12); a.cubicTo(cx-13,cy-15,cx+1,cy-18,cx+18,cy+12); c.drawPath(a,stroke);
        } else {
            stroke.setColor(WHITE); stroke.setStrokeWidth(2.2f); Path w = new Path();
            w.moveTo(cx-18,cy); w.lineTo(cx-13,cy); w.lineTo(cx-9,cy-12); w.lineTo(cx-4,cy+13); w.lineTo(cx+1,cy-8); w.lineTo(cx+6,cy+8); w.lineTo(cx+11,cy-4); w.lineTo(cx+18,cy); c.drawPath(w,stroke);
        }
    }

    // ------------------------------------------------------------
    // TOUCH
    // ------------------------------------------------------------
    @Override public boolean onTouchEvent(MotionEvent event) {
        if (scale <= 0f || Float.isNaN(scale) || Float.isInfinite(scale)) return true;
        float x = (event.getX() - offsetX) / scale;
        float y = (event.getY() - offsetY) / scale;
        if (x < 0 || x > W || y < 0 || y > H) return true;
        int action = event.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN) {
            if (y >= navTop()) {
                page = Math.min(3, Math.max(0, (int)(x / (W / 4f)))); clearDrag(); invalidate(); return true;
            }
            if (page != PAGE_HOME && x <= 76 && y <= 105) { page = PAGE_HOME; clearDrag(); invalidate(); return true; }
            if (page == PAGE_HOME) return handleHomeDown(x, y);
            if (page == PAGE_MIX) return handleMixDown(x, y);
            if (page == PAGE_EQ) return handleEqDown(x, y);
            return handleCrossoverDown(x, y);
        }
        if (action == MotionEvent.ACTION_MOVE) { updateDrag(x); return true; }
        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            finishDrag(); clearDrag(); performClick(); return true;
        }
        return true;
    }

    @Override public boolean performClick() { super.performClick(); return true; }

    private boolean handleHomeDown(float x, float y) {
        if (y >= 132 && y <= 316) { if (ble != null) ble.startScan(); return true; }
        if (y >= 694 && y <= 920) {
            if (x < 266) page = PAGE_MIX; else if (x < 520) page = PAGE_EQ; else page = PAGE_XOVER;
            invalidate(); return true;
        }
        return true;
    }

    private boolean handleMixDown(float x, float y) {
        for (int i = 0; i < 6; i++) {
            float sy = mixRowY(i) + 102;
            if (x >= 96 && x <= 714 && Math.abs(y - sy) <= 54) {
                dragKind = DRAG_MIX; dragIndex = i; updateMix(i, x); invalidate(); return true;
            }
        }
        return true;
    }

    private boolean handleEqDown(float x, float y) {
        if (handleChannelTap(x, y, 112)) return true;
        if (y >= 580 && y <= 824 && x >= 40 && x <= 748) {
            float col = 690f / DspState.BANDS;
            int b = Math.min(DspState.BANDS - 1, Math.max(0, (int)((x - 48f) / col)));
            state.selectedBand = b; invalidate(); return true;
        }
        if (y >= 895 && y <= 1085) {
            if (x >= 24 && x <= 254) { dragKind = DRAG_EQ_FREQ; updateEqParam(x); invalidate(); return true; }
            if (x >= 278 && x <= 508) { dragKind = DRAG_EQ_GAIN; updateEqParam(x); invalidate(); return true; }
            if (x >= 532 && x <= 762) { dragKind = DRAG_EQ_Q; updateEqParam(x); invalidate(); return true; }
        }
        if (y >= 1113 && y <= 1245 && x >= 300) { dragKind = DRAG_OUTPUT; updateOutput(x); invalidate(); return true; }
        if (y >= 1270 && y <= 1362) {
            if (x < 393) { state.saveEq(getContext()); toast("บันทึก EQ preset แล้ว"); }
            else { boolean ok = state.loadEq(getContext()); if (ok) sendEqChannel(state.channel); toast(ok ? "โหลด EQ preset แล้ว" : "ยังไม่มี EQ preset"); invalidate(); }
            return true;
        }
        if (y <= 95 && x >= 640) { state.flattenEq(state.channel); sendEqChannel(state.channel); invalidate(); return true; }
        return true;
    }

    private boolean handleCrossoverDown(float x, float y) {
        int ch = state.channel;
        if (x >= 620 && y <= 100) { state.channel = (state.channel + 1) % DspState.CHANNELS; invalidate(); return true; }
        if (x >= 30 && x <= 110 && y >= 600 && y <= 680) { state.hpfEnabled[ch] = !state.hpfEnabled[ch]; reportUnverified("HPF enable"); invalidate(); return true; }
        if (x >= 30 && x <= 110 && y >= 852 && y <= 932) { state.lpfEnabled[ch] = !state.lpfEnabled[ch]; reportUnverified("LPF enable"); invalidate(); return true; }
        if (y >= 680 && y <= 790 && x >= 100 && x <= 706) { dragKind = DRAG_HPF; updateCrossover(x); invalidate(); return true; }
        if (y >= 932 && y <= 1042 && x >= 100 && x <= 706) { dragKind = DRAG_LPF; updateCrossover(x); invalidate(); return true; }
        if (y >= 1160 && y <= 1245 && x >= 90 && x <= 706) { dragKind = DRAG_DELAY; updateCrossover(x); invalidate(); return true; }
        if (y >= 1302 && y <= 1394) {
            if (x < 393) { state.saveCrossover(getContext()); toast("บันทึก Crossover preset แล้ว"); }
            else { boolean ok = state.loadCrossover(getContext()); toast(ok ? "โหลด Crossover preset แล้ว" : "ยังไม่มี Crossover preset"); invalidate(); }
            return true;
        }
        return true;
    }

    private boolean handleChannelTap(float x, float y, float tabY) {
        if (y < tabY || y > tabY + 64 || x < 24 || x > 762) return false;
        float gap = 9, w = (738f - gap * 6f) / 7f;
        int ch = (int)((x - 24) / (w + gap));
        if (ch >= 0 && ch < DspState.CHANNELS) { state.channel = ch; invalidate(); return true; }
        return false;
    }

    private void updateDrag(float x) {
        if (dragKind == DRAG_MIX) updateMix(dragIndex, x);
        else if (dragKind == DRAG_EQ_FREQ || dragKind == DRAG_EQ_GAIN || dragKind == DRAG_EQ_Q) updateEqParam(x);
        else if (dragKind == DRAG_OUTPUT) updateOutput(x);
        else if (dragKind == DRAG_HPF || dragKind == DRAG_LPF || dragKind == DRAG_DELAY) updateCrossover(x);
        else return;
        invalidate();
    }

    private void updateMix(int idx, float x) {
        float frac = clamp((x - 116f) / (690f - 116f), 0f, 1f);
        if (idx == 0) state.masterVolume = round1(-70f + frac * 76f);
        else if (idx == 1) state.bassVolume = round1(-70f + frac * 76f);
        else if (idx == 2) state.bassCutoff = Math.round(logValue(frac, 20f, 250f));
        else if (idx == 3) state.bassBoost = round1(-12f + frac * 24f);
        else if (idx == 4) state.middleBoost = round1(-12f + frac * 24f);
        else state.trebleBoost = round1(-12f + frac * 24f);
        sendMix(idx);
    }

    private void sendMix(int idx) {
        if (ble == null) return;
        if (idx == 0) ble.setScalarRealtime(DspProtocol.ID_MASTER_VOLUME, state.masterVolume);
        else if (idx == 1) ble.setScalarRealtime(DspProtocol.ID_BASS_VOLUME, state.bassVolume);
        else if (idx == 2) ble.setScalarRealtime(DspProtocol.ID_BASS_CUTOFF, state.bassCutoff);
        else if (idx == 3) ble.setScalarRealtime(DspProtocol.ID_BASS_BOOST, state.bassBoost);
        else if (idx == 4) ble.setScalarRealtime(DspProtocol.ID_MIDDLE_BOOST, state.middleBoost);
        else ble.setScalarRealtime(DspProtocol.ID_TREBLE_BOOST, state.trebleBoost);
    }

    private void updateEqParam(float x) {
        int ch = state.channel, b = state.selectedBand;
        float frac;
        if (dragKind == DRAG_EQ_FREQ) frac = clamp((x - 42f) / (236f - 42f), 0f, 1f);
        else if (dragKind == DRAG_EQ_GAIN) frac = clamp((x - 296f) / (490f - 296f), 0f, 1f);
        else frac = clamp((x - 550f) / (744f - 550f), 0f, 1f);
        if (dragKind == DRAG_EQ_FREQ) state.freq[ch][b] = logValue(frac, 20f, 20000f);
        else if (dragKind == DRAG_EQ_GAIN) state.gain[ch][b] = round1(-12f + frac * 24f);
        else state.q[ch][b] = round2(logValue(frac, 0.05f, 20f));
        boolean canSend = dragKind == DRAG_EQ_GAIN ? state.eqWritable[ch][b] : state.eqShapeWritable[ch][b];
        if (canSend && ble != null) ble.setEqRealtime(ch, b, state.freq[ch][b], state.gain[ch][b], state.q[ch][b]);
    }

    private void sendEqChannel(int ch) {
        if (ble == null) return;
        for (int b = 0; b < DspState.BANDS; b++) if (state.eqWritable[ch][b]) ble.setEqRealtime(ch, b, state.freq[ch][b], state.gain[ch][b], state.q[ch][b]);
    }

    private void updateOutput(float x) {
        float frac = clamp((x - 330f) / (640f - 330f), 0f, 1f);
        state.fader[state.channel] = round1(-60f + frac * 72f);
    }

    private void updateCrossover(float x) {
        int ch = state.channel;
        if (dragKind == DRAG_HPF) {
            float frac = clamp((x - 118f) / (682f - 118f), 0f, 1f); state.hpfHz[ch] = Math.round(logValue(frac, 20f, 20000f));
        } else if (dragKind == DRAG_LPF) {
            float frac = clamp((x - 118f) / (682f - 118f), 0f, 1f); state.lpfHz[ch] = Math.round(logValue(frac, 20f, 20000f));
        } else if (dragKind == DRAG_DELAY) {
            float frac = clamp((x - 102f) / (682f - 102f), 0f, 1f); state.delayMs[ch] = round2(frac * 20f);
        }
    }

    private void finishDrag() {
        if (dragKind == DRAG_EQ_FREQ || dragKind == DRAG_EQ_Q) {
            if (!state.eqShapeWritable[state.channel][state.selectedBand]) reportUnverified("EQ Frequency/Q");
        } else if (dragKind == DRAG_EQ_GAIN) {
            if (!state.eqWritable[state.channel][state.selectedBand]) reportUnverified("EQ Gain");
        } else if (dragKind == DRAG_OUTPUT) reportUnverified("Output Gain");
        else if (dragKind == DRAG_HPF) reportUnverified("HPF frequency");
        else if (dragKind == DRAG_LPF) reportUnverified("LPF frequency");
        else if (dragKind == DRAG_DELAY) reportUnverified("Delay");
    }

    private void reportUnverified(String name) { if (ble != null) ble.reportUnverifiedControl(name); }
    private void clearDrag() { dragKind = DRAG_NONE; dragIndex = -1; }

    private float freqX(float freq, float gx, float gw) {
        double frac = (Math.log(clamp(freq, 20f, 20000f)) - Math.log(20)) / (Math.log(20000) - Math.log(20));
        return gx + (float)frac * gw;
    }
    private float gainY(float gain, float gy, float gh) { return gy + (12f - clamp(gain, -12f, 12f)) / 24f * gh; }
    private float logValue(float frac, float min, float max) { return (float)Math.exp(Math.log(min) + frac * (Math.log(max) - Math.log(min))); }
    private float clamp(float v, float lo, float hi) { return Math.max(lo, Math.min(hi, v)); }
    private float round1(float v) { return Math.round(v * 10f) / 10f; }
    private float round2(float v) { return Math.round(v * 100f) / 100f; }
    private void toast(String s) { Toast.makeText(getContext(), s, Toast.LENGTH_SHORT).show(); }
}
