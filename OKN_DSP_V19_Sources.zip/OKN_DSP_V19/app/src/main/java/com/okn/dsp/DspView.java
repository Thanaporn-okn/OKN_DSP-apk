package com.okn.dsp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import java.util.Locale;

/**
 * OKN_DSP V18 UI rebuilt from scratch from the approved 4-screen mockup.
 *
 * Rendering/touch are immediate on the UI thread. Verified hardware writes are delegated to
 * BleManager, which intentionally keeps the official-app latest-value 380 ms transport cadence
 * recovered from the uploaded BTSnoop evidence. Unsupported DSP blocks never emit guessed writes.
 */
final class DspView extends View {
    private static final float W = 1080f, H = 2400f;
    private static final int HOME = 0, MIX = 1, EQ = 2, CROSS = 3;
    private static final int DRAG_NONE = 0, DRAG_MASTER = 1, DRAG_OUTPUT = 2,
            DRAG_EQ = 3, DRAG_HPF = 4, DRAG_LPF = 5, DRAG_DELAY = 6;

    private static final int BG = Color.rgb(2, 10, 18);
    private static final int PANEL = Color.rgb(5, 20, 34);
    private static final int PANEL2 = Color.rgb(7, 28, 46);
    private static final int BORDER = Color.rgb(18, 70, 108);
    private static final int WHITE = Color.rgb(240, 247, 255);
    private static final int SUB = Color.rgb(154, 181, 207);
    private static final int CYAN = Color.rgb(0, 207, 255);
    private static final int GREEN = Color.rgb(18, 232, 112);
    private static final int ORANGE = Color.rgb(255, 158, 27);
    private static final int RED = Color.rgb(255, 55, 72);
    private static final int PURPLE = Color.rgb(178, 48, 255);
    private static final int MAGENTA = Color.rgb(255, 47, 208);
    private static final int YELLOW = Color.rgb(255, 216, 32);
    private static final int[] CH_COLORS = {CYAN, GREEN, YELLOW, ORANGE, RED, MAGENTA, PURPLE};
    private static final android.graphics.Typeface FONT = android.graphics.Typeface.create("sans", android.graphics.Typeface.NORMAL);
    private static final android.graphics.Typeface FONT_BOLD = android.graphics.Typeface.create("sans", android.graphics.Typeface.BOLD);
    private static final String[] FILTER_TYPES = {"Linkwitz-Riley", "Butterworth", "Bessel"};
    private static final int[] SLOPES = {12, 18, 24, 36, 48};

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final DspState state = new DspState();

    private BleManager ble;
    private String bleStatus = "Disconnected";
    private String deviceName = "OKN-DSP_7CH";
    private boolean dspReady;
    private String diagnostic = "";
    private int drag = DRAG_NONE;
    private int dragIndex = -1;
    private long lastUnverifiedNotice;

    DspView(Context context) {
        super(context);
        setBackgroundColor(BG);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        stroke.setStyle(Paint.Style.STROKE);
    }

    void setBleManager(BleManager ble) { this.ble = ble; }

    void setBleStatus(String status, String name, boolean ready) {
        bleStatus = status == null ? "" : status;
        if (name != null && !name.isEmpty()) deviceName = name;
        dspReady = ready;
        invalidate();
    }

    void setDiagnostic(String message) {
        diagnostic = message == null ? "" : message;
        invalidate();
    }

    void setScalarFromDsp(int actuatorId, float value) {
        if (actuatorId == DspProtocol.ID_MASTER_VOLUME) state.masterVolume = value;
        invalidate();
    }

    void setEqFromDsp(int channel0, int band0, float frequency, float gainDb, float q, boolean writable) {
        if (channel0 < 0 || channel0 >= 7 || band0 < 0 || band0 >= 15) return;
        state.eqFreq[channel0][band0] = frequency;
        state.eqGain[channel0][band0] = gainDb;
        state.eqQ[channel0][band0] = q;
        state.eqWritable[channel0][band0] = writable;
        invalidate();
    }

    @Override protected void onDraw(Canvas actual) {
        super.onDraw(actual);
        float sx = getWidth() / W, sy = getHeight() / H;
        actual.save();
        actual.scale(sx, sy);
        actual.drawColor(BG);
        drawHeader(actual);
        if (state.page == HOME) drawHome(actual);
        else if (state.page == MIX) drawMix(actual);
        else if (state.page == EQ) drawEq(actual);
        else drawCrossover(actual);
        drawBottomNav(actual);
        actual.restore();
    }

    private void drawHeader(Canvas c) {
        p.setColor(Color.rgb(1, 14, 25));
        c.drawRect(0, 0, W, 170, p);
        drawWaveLogo(c, 62, 78, 1f);
        text(c, "OKN_DSP", 140, 70, 43, WHITE, true, Paint.Align.LEFT);
        text(c, "PROFESSIONAL AUDIO CONTROL", 142, 105, 16, Color.rgb(105, 176, 224), false, Paint.Align.LEFT);
        roundPanel(c, 668, 29, 283, 105, 17, PANEL2, BORDER);
        p.setColor(dspReady ? GREEN : Color.rgb(110, 124, 140));
        p.setShadowLayer(dspReady ? 14 : 0, 0, 0, p.getColor());
        c.drawCircle(698, 64, 11, p); p.clearShadowLayer();
        text(c, dspReady ? "Connected" : "Connecting", 725, 66, 22, dspReady ? GREEN : WHITE, true, Paint.Align.LEFT);
        text(c, deviceName, 725, 99, 18, SUB, false, Paint.Align.LEFT);
        drawGear(c, 1010, 79, WHITE);
    }

    private void drawHome(Canvas c) {
        text(c, "Home", 70, 232, 38, WHITE, true, Paint.Align.LEFT);
        text(c, "Device status & quick control", 70, 267, 19, SUB, false, Paint.Align.LEFT);

        roundPanel(c, 65, 315, 950, 175, 24, PANEL, BORDER);
        p.setColor(dspReady ? GREEN : ORANGE);
        p.setShadowLayer(18, 0, 0, p.getColor()); c.drawCircle(128, 380, 22, p); p.clearShadowLayer();
        text(c, dspReady ? "Connected" : bleStatus, 175, 373, 31, dspReady ? GREEN : WHITE, true, Paint.Align.LEFT);
        text(c, deviceName, 175, 410, 21, SUB, false, Paint.Align.LEFT);
        text(c, dspReady ? "DSP READY" : "Tap card to scan", 175, 448, 18, dspReady ? CYAN : ORANGE, false, Paint.Align.LEFT);
        drawSignalBars(c, 930, 395, dspReady ? GREEN : SUB);

        drawDspBox(c, 165, 565, 750, 320);

        float cy = 1040;
        roundPanel(c, 70, 935, 940, 250, 24, PANEL, BORDER);
        drawSpeaker(c, 125, 1000, WHITE);
        text(c, "Master Volume", 170, 1008, 29, WHITE, true, Paint.Align.LEFT);
        text(c, db(state.masterVolume), 930, 1008, 34, CYAN, true, Paint.Align.RIGHT);
        drawHorizontalSlider(c, 130, cy, 830, -70, 6, state.masterVolume, CYAN);
        text(c, "-70", 130, 1107, 16, SUB, false, Paint.Align.CENTER);
        text(c, "0", 865, 1107, 16, SUB, false, Paint.Align.CENTER);

        text(c, "Quick Preset", 72, 1285, 28, WHITE, true, Paint.Align.LEFT);
        String[] presets = {"Flat", "Vocal", "Rock", "Custom"};
        for (int i = 0; i < 4; i++) {
            float x = 70 + i * 237f;
            boolean sel = i == state.homePreset;
            roundPanel(c, x, 1320, 215, 96, 18, sel ? Color.rgb(0, 142, 224) : PANEL2, sel ? CYAN : BORDER);
            text(c, presets[i], x + 107, 1380, 23, WHITE, true, Paint.Align.CENTER);
        }

        roundPanel(c, 70, 1490, 940, 430, 24, PANEL, BORDER);
        text(c, "Realtime Engine", 105, 1550, 27, WHITE, true, Paint.Align.LEFT);
        statusRow(c, 106, 1610, "UI touch response", "Immediate / 60 fps", GREEN);
        statusRow(c, 106, 1685, "Verified DSP controls", "Master + 15-band EQ x 7", CYAN);
        statusRow(c, 106, 1760, "BLE transport", "Latest value wins • safe serialized stream", CYAN);
        statusRow(c, 106, 1835, "Output / Crossover / Delay", "UI LIVE • hardware map pending", ORANGE);
        if (!diagnostic.isEmpty()) text(c, ellipsize(diagnostic, 58), 105, 1885, 17, SUB, false, Paint.Align.LEFT);
    }

    private void drawMix(Canvas c) {
        text(c, "Output Volume (7 Channels)", 70, 235, 36, WHITE, true, Paint.Align.LEFT);
        outlineButton(c, 848, 188, 165, 70, "↻ Reset", false);
        text(c, "Seven-channel output mixer", 70, 272, 18, SUB, false, Paint.Align.LEFT);
        badge(c, 70, 298, "UI REAL-TIME", GREEN);
        badge(c, 260, 298, "HW MAP PENDING", ORANGE);

        roundPanel(c, 60, 360, 960, 1370, 28, PANEL, BORDER);
        float top = 570, bottom = 1455;
        for (int ch = 0; ch < 7; ch++) {
            float cx = 125 + ch * 137f;
            int color = CH_COLORS[ch];
            roundPanel(c, cx - 54, 405, 108, 70, 14, Color.argb(60, Color.red(color), Color.green(color), Color.blue(color)), color);
            text(c, "CH" + (ch + 1), cx, 450, 21, WHITE, true, Paint.Align.CENTER);
            text(c, db(state.outputGain[ch]), cx, 520, 21, WHITE, true, Paint.Align.CENTER);
            drawVerticalSlider(c, cx, top, bottom, -60, 12, state.outputGain[ch], color);
            roundPanel(c, cx - 44, 1505, 88, 86, 44, state.outputMute[ch] ? Color.rgb(95, 28, 36) : PANEL2, state.outputMute[ch] ? RED : BORDER);
            drawSpeaker(c, cx, 1548, state.outputMute[ch] ? RED : WHITE);
        }
        text(c, "Link", 90, 1659, 22, WHITE, true, Paint.Align.LEFT);
        String[] links = {"Off", "1-2", "3-4", "5-6", "All"};
        for (int i = 0; i < links.length; i++) {
            float x = 180 + i * 157f;
            boolean sel = state.linkMode == i;
            roundPanel(c, x, 1618, 135, 76, 16, sel ? Color.rgb(0, 131, 218) : PANEL2, sel ? CYAN : BORDER);
            text(c, links[i], x + 67, 1667, 20, WHITE, true, Paint.Align.CENTER);
        }
        roundPanel(c, 70, 1770, 940, 250, 22, PANEL, BORDER);
        text(c, "Hardware boundary", 102, 1825, 24, WHITE, true, Paint.Align.LEFT);
        text(c, "V17 data does not contain verified output-gain actuator IDs.", 102, 1880, 19, SUB, false, Paint.Align.LEFT);
        text(c, "Controls move instantly; no guessed packet is transmitted.", 102, 1925, 19, ORANGE, false, Paint.Align.LEFT);
    }

    private void drawEq(Canvas c) {
        text(c, "Parametric EQ", 70, 230, 38, WHITE, true, Paint.Align.LEFT);
        text(c, "15-band Graphic EQ • 7 channels", 70, 270, 19, SUB, false, Paint.Align.LEFT);
        channelTabs(c, 70, 305);
        outlineButton(c, 830, 305, 180, 66, "↻ Reset EQ", false);

        drawEqGraph(c, 75, 420, 930, 550);

        roundPanel(c, 70, 1015, 940, 760, 24, PANEL, BORDER);
        text(c, "15 Bands", 98, 1062, 25, WHITE, true, Paint.Align.LEFT);
        float top = 1160, bottom = 1575;
        for (int b = 0; b < 15; b++) {
            float cx = 115 + b * 61.5f;
            int color = rainbowBand(b);
            drawThinVerticalSlider(c, cx, top, bottom, -12, 12, state.eqGain[state.channel][b], color,
                    state.eqWritable[state.channel][b]);
            text(c, String.valueOf(b + 1), cx, 1633, 13, state.eqWritable[state.channel][b] ? WHITE : SUB, false, Paint.Align.CENTER);
        }
        int b = state.selectedBand;
        float y = 1685;
        text(c, "Selected band " + (b + 1), 100, y, 22, WHITE, true, Paint.Align.LEFT);
        text(c, hz(state.eqFreq[state.channel][b]), 365, y, 21, CYAN, true, Paint.Align.CENTER);
        text(c, db(state.eqGain[state.channel][b]), 610, y, 21, CH_COLORS[state.channel], true, Paint.Align.CENTER);
        text(c, "Q " + String.format(Locale.US, "%.2f", state.eqQ[state.channel][b]), 855, y, 21, WHITE, true, Paint.Align.CENTER);
        text(c, state.eqWritable[state.channel][b] ? "LIVE" : "READ ONLY", 855, 1735, 16,
                state.eqWritable[state.channel][b] ? GREEN : ORANGE, true, Paint.Align.CENTER);

        roundPanel(c, 70, 1815, 940, 190, 22, PANEL, BORDER);
        text(c, "Gain writes preserve live Frequency / Q / filter type", 100, 1870, 20, SUB, false, Paint.Align.LEFT);
        text(c, "Verified V17 path: 105 real filter records", 100, 1920, 20, GREEN, true, Paint.Align.LEFT);
        if (!diagnostic.isEmpty()) text(c, ellipsize(diagnostic, 62), 100, 1970, 16, SUB, false, Paint.Align.LEFT);
    }

    private void drawCrossover(Canvas c) {
        text(c, "Crossover & Delay", 70, 230, 38, WHITE, true, Paint.Align.LEFT);
        channelTabs(c, 70, 305);
        outlineButton(c, 830, 305, 180, 66, "↻ Reset", false);
        badge(c, 70, 390, "UI REAL-TIME", GREEN);
        badge(c, 260, 390, "HW MAP PENDING", ORANGE);

        drawCrossoverGraph(c, 75, 470, 930, 520);

        roundPanel(c, 70, 1040, 940, 590, 24, PANEL, BORDER);
        text(c, "Crossover", 100, 1095, 27, WHITE, true, Paint.Align.LEFT);
        toggle(c, 873, 1070, state.crossoverEnabled[state.channel], CYAN);
        text(c, "High Pass", 105, 1190, 21, WHITE, true, Paint.Align.LEFT);
        text(c, hz(state.hpfHz[state.channel]) + " Hz", 925, 1190, 21, CYAN, true, Paint.Align.RIGHT);
        drawLogSlider(c, 210, 1218, 680, 20, 20000, state.hpfHz[state.channel], CYAN);
        pill(c, 105, 1285, 300, 65, FILTER_TYPES[state.hpfType[state.channel]], WHITE);
        pill(c, 430, 1285, 260, 65, state.hpfSlope[state.channel] + " dB/oct", WHITE);
        text(c, "Low Pass", 105, 1418, 21, WHITE, true, Paint.Align.LEFT);
        text(c, hz(state.lpfHz[state.channel]) + " Hz", 925, 1418, 21, RED, true, Paint.Align.RIGHT);
        drawLogSlider(c, 210, 1446, 680, 20, 20000, state.lpfHz[state.channel], RED);
        pill(c, 105, 1515, 300, 65, FILTER_TYPES[state.lpfType[state.channel]], WHITE);
        pill(c, 430, 1515, 260, 65, state.lpfSlope[state.channel] + " dB/oct", WHITE);

        roundPanel(c, 70, 1680, 940, 325, 24, PANEL, BORDER);
        text(c, "Delay", 100, 1735, 27, WHITE, true, Paint.Align.LEFT);
        pill(c, 660, 1705, 105, 62, "ms", state.delayUnit == 0 ? CYAN : SUB);
        pill(c, 775, 1705, 105, 62, "cm", state.delayUnit == 1 ? CYAN : SUB);
        pill(c, 890, 1705, 105, 62, "inch", state.delayUnit == 2 ? CYAN : SUB);
        drawHorizontalSlider(c, 120, 1850, 760, 0, 20, state.delayMs[state.channel], CYAN);
        text(c, delayDisplay(state.delayMs[state.channel]), 930, 1860, 23, WHITE, true, Paint.Align.RIGHT);
        text(c, "Crossover/Delay packet layout is not present in the uploaded V17 evidence.", 100, 1950, 17, ORANGE, false, Paint.Align.LEFT);
    }

    private void drawBottomNav(Canvas c) {
        p.setColor(Color.rgb(2, 16, 28)); c.drawRect(0, 2190, W, H, p);
        stroke.setColor(BORDER); stroke.setStrokeWidth(2); c.drawLine(0, 2190, W, 2190, stroke);
        String[] names = {"Home", "Mix", "EQ", "Crossover"};
        for (int i = 0; i < 4; i++) {
            float cx = 135 + i * 270f;
            boolean sel = state.page == i;
            if (sel) {
                p.setShader(new LinearGradient(cx - 90, 2190, cx + 90, 2380,
                        Color.argb(70, 0, 185, 255), Color.TRANSPARENT, Shader.TileMode.CLAMP));
                c.drawRoundRect(new RectF(cx - 100, 2210, cx + 100, 2380), 28, 28, p); p.setShader(null);
            }
            drawNavIcon(c, cx, 2268, i, sel ? CYAN : SUB);
            text(c, names[i], cx, 2340, 19, sel ? CYAN : SUB, sel, Paint.Align.CENTER);
        }
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX() * W / Math.max(1, getWidth());
        float y = e.getY() * H / Math.max(1, getHeight());
        int a = e.getActionMasked();

        if (a == MotionEvent.ACTION_DOWN) {
            if (x >= 955 && y <= 155) {
                if (ble != null) ble.requestDspRefresh(); else toast("Bluetooth ยังไม่พร้อม");
                performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP);
                return true;
            }
            if (y >= 2180) {
                int page = Math.max(0, Math.min(3, (int) (x / 270f)));
                state.page = page; drag = DRAG_NONE; invalidate(); performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP); return true;
            }
            if (state.page == HOME) handleHomeDown(x, y);
            else if (state.page == MIX) handleMixDown(x, y);
            else if (state.page == EQ) handleEqDown(x, y);
            else handleCrossDown(x, y);
            invalidate(); return true;
        }
        if (a == MotionEvent.ACTION_MOVE) {
            handleDrag(x, y); invalidate(); return true;
        }
        if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
            if (drag == DRAG_OUTPUT) noticeUnverified("Output Volume CH" + (dragIndex + 1));
            else if (drag == DRAG_HPF || drag == DRAG_LPF) noticeUnverified("Crossover");
            else if (drag == DRAG_DELAY) noticeUnverified("Delay");
            drag = DRAG_NONE; dragIndex = -1; invalidate(); return true;
        }
        return true;
    }

    private void handleHomeDown(float x, float y) {
        if (y >= 315 && y <= 490) { if (ble != null) ble.startScan(); return; }
        if (y >= 985 && y <= 1100 && x >= 100 && x <= 930) { drag = DRAG_MASTER; updateMaster(x); return; }
        if (y >= 1320 && y <= 1425) {
            int idx = (int) ((x - 70) / 237f);
            if (idx >= 0 && idx < 4) {
                state.homePreset = idx;
                if (idx == 0) state.masterVolume = -20f;
                else if (idx == 1) state.masterVolume = -16f;
                else if (idx == 2) state.masterVolume = -12f;
                else state.masterVolume = -20f;
                sendMaster();
            }
        }
    }

    private void handleMixDown(float x, float y) {
        if (y >= 405 && y <= 1595) {
            int ch = Math.max(0, Math.min(6, Math.round((x - 125f) / 137f)));
            float cx = 125 + ch * 137f;
            if (Math.abs(x - cx) <= 58) {
                if (y >= 1495) { state.outputMute[ch] = !state.outputMute[ch]; noticeUnverified("Output Mute CH" + (ch + 1)); return; }
                drag = DRAG_OUTPUT; dragIndex = ch; updateOutput(y); return;
            }
        }
        if (y >= 1610 && y <= 1705) {
            int idx = Math.round((x - 180) / 157f); if (idx >= 0 && idx < 5) state.linkMode = idx;
        }
        if (x >= 848 && y >= 180 && y <= 270) {
            for (int ch = 0; ch < 7; ch++) { state.outputGain[ch] = (ch == 5) ? -8f : -3f; state.outputMute[ch] = false; }
            noticeUnverified("Output reset");
        }
    }

    private void handleEqDown(float x, float y) {
        if (handleChannelTab(x, y)) return;
        if (x >= 830 && y >= 295 && y <= 385) {
            state.flattenCurrentEq();
            for (int b = 0; b < 15; b++) sendEqBand(b);
            return;
        }
        if (y >= 1110 && y <= 1650) {
            int b = Math.max(0, Math.min(14, Math.round((x - 115f) / 61.5f)));
            state.selectedBand = b;
            if (state.eqWritable[state.channel][b]) { drag = DRAG_EQ; dragIndex = b; updateEq(y); }
            else toast("Band " + (b + 1) + " ยังไม่ LIVE จาก Device Description");
            return;
        }
        if (x >= 75 && x <= 1005 && y >= 420 && y <= 970) {
            int nearest = nearestEqBand(x, y); state.selectedBand = nearest;
            if (state.eqWritable[state.channel][nearest]) { drag = DRAG_EQ; dragIndex = nearest; updateEqFromGraph(y); }
        }
    }

    private void handleCrossDown(float x, float y) {
        if (handleChannelTab(x, y)) return;
        if (x >= 850 && y >= 1050 && y <= 1150) { state.crossoverEnabled[state.channel] = !state.crossoverEnabled[state.channel]; noticeUnverified("Crossover enable"); return; }
        if (y >= 1275 && y <= 1360) {
            if (x >= 95 && x <= 420) { state.hpfType[state.channel] = (state.hpfType[state.channel] + 1) % FILTER_TYPES.length; noticeUnverified("HPF type"); return; }
            if (x >= 420 && x <= 710) { state.hpfSlope[state.channel] = nextSlope(state.hpfSlope[state.channel]); noticeUnverified("HPF slope"); return; }
        }
        if (y >= 1505 && y <= 1595) {
            if (x >= 95 && x <= 420) { state.lpfType[state.channel] = (state.lpfType[state.channel] + 1) % FILTER_TYPES.length; noticeUnverified("LPF type"); return; }
            if (x >= 420 && x <= 710) { state.lpfSlope[state.channel] = nextSlope(state.lpfSlope[state.channel]); noticeUnverified("LPF slope"); return; }
        }
        if (y >= 1695 && y <= 1780) {
            if (x >= 650 && x < 775) { state.delayUnit = 0; return; }
            if (x >= 775 && x < 890) { state.delayUnit = 1; return; }
            if (x >= 890) { state.delayUnit = 2; return; }
        }
        if (y >= 1180 && y <= 1275 && x >= 180 && x <= 930) { drag = DRAG_HPF; updateCross(x); return; }
        if (y >= 1405 && y <= 1505 && x >= 180 && x <= 930) { drag = DRAG_LPF; updateCross(x); return; }
        if (y >= 1800 && y <= 1905 && x >= 90 && x <= 930) { drag = DRAG_DELAY; updateDelay(x); return; }
        if (x >= 830 && y >= 295 && y <= 385) {
            int ch = state.channel; state.hpfHz[ch] = ch == 5 ? 20f : 80f; state.lpfHz[ch] = ch == 5 ? 120f : 3000f; state.delayMs[ch] = 0f; state.hpfSlope[ch] = 24; state.lpfSlope[ch] = 24; state.hpfType[ch] = 0; state.lpfType[ch] = 0;
            noticeUnverified("Crossover reset");
        }
    }

    private boolean handleChannelTab(float x, float y) {
        if (y < 300 || y > 385) return false;
        int ch = (int) ((x - 70) / 105f);
        if (ch >= 0 && ch < 7) { state.channel = ch; return true; }
        return false;
    }

    private void handleDrag(float x, float y) {
        if (drag == DRAG_MASTER) updateMaster(x);
        else if (drag == DRAG_OUTPUT) updateOutput(y);
        else if (drag == DRAG_EQ) updateEq(y);
        else if (drag == DRAG_HPF || drag == DRAG_LPF) updateCross(x);
        else if (drag == DRAG_DELAY) updateDelay(x);
    }

    private void updateMaster(float x) {
        float f = clamp((x - 130) / 830f, 0, 1); state.masterVolume = round1(-70 + f * 76); sendMaster();
    }
    private void sendMaster() { if (ble != null) ble.setScalarRealtime(DspProtocol.ID_MASTER_VOLUME, state.masterVolume); }

    private void updateOutput(float y) {
        if (dragIndex < 0) return;
        float f = 1f - clamp((y - 570) / (1455 - 570f), 0, 1); float value = round1(-60 + f * 72);
        applyLinkedOutput(dragIndex, value);
    }

    private void applyLinkedOutput(int ch, float value) {
        state.outputGain[ch] = value;
        if (state.linkMode == 4) for (int i = 0; i < 7; i++) state.outputGain[i] = value;
        else if (state.linkMode == 1 && ch <= 1) { state.outputGain[0] = value; state.outputGain[1] = value; }
        else if (state.linkMode == 2 && ch >= 2 && ch <= 3) { state.outputGain[2] = value; state.outputGain[3] = value; }
        else if (state.linkMode == 3 && ch >= 4 && ch <= 5) { state.outputGain[4] = value; state.outputGain[5] = value; }
    }

    private void updateEq(float y) {
        int b = dragIndex; if (b < 0) return;
        float f = 1f - clamp((y - 1160) / (1575 - 1160f), 0, 1);
        state.eqGain[state.channel][b] = round1(-12 + f * 24); sendEqBand(b);
    }

    private void updateEqFromGraph(float y) {
        int b = dragIndex; if (b < 0) return;
        float f = 1f - clamp((y - 445) / 480f, 0, 1);
        state.eqGain[state.channel][b] = round1(-12 + f * 24); sendEqBand(b);
    }

    private void sendEqBand(int b) {
        if (ble == null || !state.eqWritable[state.channel][b]) return;
        ble.setEqRealtime(state.channel, b, state.eqFreq[state.channel][b], state.eqGain[state.channel][b], state.eqQ[state.channel][b]);
    }

    private void updateCross(float x) {
        float f = clamp((x - 210) / 680f, 0, 1);
        float hz = (float) (20.0 * Math.pow(1000.0, f));
        hz = Math.max(20, Math.min(20000, Math.round(hz)));
        if (drag == DRAG_HPF) state.hpfHz[state.channel] = hz; else state.lpfHz[state.channel] = hz;
        if (state.hpfHz[state.channel] > state.lpfHz[state.channel]) {
            if (drag == DRAG_HPF) state.lpfHz[state.channel] = state.hpfHz[state.channel]; else state.hpfHz[state.channel] = state.lpfHz[state.channel];
        }
    }

    private void updateDelay(float x) { state.delayMs[state.channel] = Math.round(clamp((x - 120) / 760f, 0, 1) * 2000f) / 100f; }

    private void noticeUnverified(String name) {
        long now = SystemClock.uptimeMillis();
        if (now - lastUnverifiedNotice < 900) return;
        lastUnverifiedNotice = now;
        if (ble != null) ble.reportUnverifiedControl(name);
        else toast(name + " • UI LIVE • hardware mapping pending");
    }

    private void drawEqGraph(Canvas c, float x, float y, float w, float h) {
        roundPanel(c, x, y, w, h, 16, Color.rgb(1, 15, 27), BORDER);
        for (int i = 1; i < 10; i++) { stroke.setColor(Color.rgb(9, 51, 80)); stroke.setStrokeWidth(1); float gx=x+w*i/10f; c.drawLine(gx,y,gx,y+h,stroke); }
        for (int i = 1; i < 6; i++) { stroke.setColor(Color.rgb(9, 51, 80)); float gy=y+h*i/6f; c.drawLine(x,gy,x+w,gy,stroke); }
        int ch = state.channel;
        Path path = new Path();
        for (int b = 0; b < 15; b++) {
            float px = x + logFreqFrac(state.eqFreq[ch][b]) * w;
            float py = y + (12f - state.eqGain[ch][b]) / 24f * h;
            if (b == 0) path.moveTo(px, py); else path.lineTo(px, py);
        }
        stroke.setStrokeWidth(6); stroke.setColor(CYAN); stroke.setShadowLayer(14,0,0,CYAN); c.drawPath(path, stroke); stroke.clearShadowLayer();
        for (int b = 0; b < 15; b++) {
            float px = x + logFreqFrac(state.eqFreq[ch][b]) * w;
            float py = y + (12f - state.eqGain[ch][b]) / 24f * h;
            int color = rainbowBand(b); p.setColor(color); p.setShadowLayer(12,0,0,color); c.drawCircle(px, py, b==state.selectedBand?13:9,p); p.clearShadowLayer();
        }
        text(c, "+12", x-12,y+15,15,SUB,false,Paint.Align.RIGHT); text(c,"0",x-12,y+h/2+5,15,SUB,false,Paint.Align.RIGHT); text(c,"-12",x-12,y+h,15,SUB,false,Paint.Align.RIGHT);
        String[] ft={"20","50","100","200","500","1k","2k","5k","10k","20k"}; float[] fv={20,50,100,200,500,1000,2000,5000,10000,20000};
        for(int i=0;i<fv.length;i++) text(c,ft[i],x+logFreqFrac(fv[i])*w,y+h+30,13,SUB,false,Paint.Align.CENTER);
    }

    private void drawCrossoverGraph(Canvas c, float x, float y, float w, float h) {
        roundPanel(c, x, y, w, h, 16, Color.rgb(1,15,27), BORDER);
        for(int i=1;i<10;i++){stroke.setColor(Color.rgb(9,51,80));stroke.setStrokeWidth(1);float gx=x+w*i/10f;c.drawLine(gx,y,gx,y+h,stroke);} for(int i=1;i<5;i++){float gy=y+h*i/5f;c.drawLine(x,gy,x+w,gy,stroke);}
        int ch=state.channel; float hpf=logFreqFrac(state.hpfHz[ch]), lpf=logFreqFrac(state.lpfHz[ch]);
        Path hp=new Path(); hp.moveTo(x,y+h); hp.cubicTo(x+w*hpf*.5f,y+h,x+w*hpf*.75f,y+55,x+w*Math.min(1,hpf+.12f),y+55); hp.lineTo(x+w,y+55);
        stroke.setStrokeWidth(6); stroke.setColor(Color.rgb(0,145,255)); stroke.setShadowLayer(12,0,0,stroke.getColor()); c.drawPath(hp,stroke); stroke.clearShadowLayer();
        Path lp=new Path(); lp.moveTo(x,y+55); lp.lineTo(x+w*Math.max(0,lpf-.12f),y+55); lp.cubicTo(x+w*lpf,y+55,x+w*Math.min(1,lpf+.08f),y+h,x+w,y+h);
        stroke.setColor(Color.rgb(255,58,95)); stroke.setShadowLayer(12,0,0,stroke.getColor()); c.drawPath(lp,stroke); stroke.clearShadowLayer();
        text(c,"HPF",x+120,y+40,17,Color.rgb(0,145,255),true,Paint.Align.CENTER); text(c,"LPF",x+240,y+40,17,RED,true,Paint.Align.CENTER);
    }

    private void channelTabs(Canvas c, float x, float y) {
        for(int ch=0;ch<7;ch++){float xx=x+ch*105f;boolean sel=state.channel==ch;int color=CH_COLORS[ch];roundPanel(c,xx,y,90,66,14,sel?Color.argb(100,Color.red(color),Color.green(color),Color.blue(color)):PANEL2,sel?color:BORDER);text(c,"CH"+(ch+1),xx+45,y+42,18,WHITE,true,Paint.Align.CENTER);} }

    private void drawHorizontalSlider(Canvas c,float x,float y,float width,float min,float max,float value,int color){float f=clamp((value-min)/(max-min),0,1);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeWidth(16);p.setColor(Color.rgb(27,58,82));c.drawLine(x,y,x+width,y,p);p.setColor(color);p.setShadowLayer(10,0,0,color);c.drawLine(x,y,x+width*f,y,p);p.clearShadowLayer();p.setColor(WHITE);c.drawCircle(x+width*f,y,19,p);p.setStrokeCap(Paint.Cap.BUTT);}
    private void drawLogSlider(Canvas c,float x,float y,float width,float min,float max,float value,int color){float f=(float)((Math.log(value)-Math.log(min))/(Math.log(max)-Math.log(min)));drawHorizontalSlider(c,x,y,width,0,1,f,color);}
    private void drawVerticalSlider(Canvas c,float x,float top,float bottom,float min,float max,float value,int color){float f=clamp((value-min)/(max-min),0,1);float yy=bottom-f*(bottom-top);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeWidth(17);p.setColor(Color.rgb(31,59,77));c.drawLine(x,top,x,bottom,p);p.setColor(color);p.setShadowLayer(12,0,0,color);c.drawLine(x,bottom,x,yy,p);p.clearShadowLayer();p.setColor(WHITE);c.drawCircle(x,yy,19,p);p.setStrokeCap(Paint.Cap.BUTT);}
    private void drawThinVerticalSlider(Canvas c,float x,float top,float bottom,float min,float max,float value,int color,boolean live){float f=clamp((value-min)/(max-min),0,1);float yy=bottom-f*(bottom-top);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeWidth(8);p.setColor(Color.rgb(29,55,72));c.drawLine(x,top,x,bottom,p);p.setColor(live?color:Color.rgb(87,100,112));if(live)p.setShadowLayer(8,0,0,color);c.drawLine(x,bottom,x,yy,p);p.clearShadowLayer();p.setColor(live?WHITE:SUB);c.drawCircle(x,yy,11,p);p.setStrokeCap(Paint.Cap.BUTT);}

    private void roundPanel(Canvas c,float x,float y,float w,float h,float rad,int fill,int border){p.setColor(fill);p.setStyle(Paint.Style.FILL);c.drawRoundRect(new RectF(x,y,x+w,y+h),rad,rad,p);stroke.setColor(border);stroke.setStyle(Paint.Style.STROKE);stroke.setStrokeWidth(2);c.drawRoundRect(new RectF(x,y,x+w,y+h),rad,rad,stroke);}
    private void outlineButton(Canvas c,float x,float y,float w,float h,String label,boolean active){roundPanel(c,x,y,w,h,15,active?Color.rgb(0,100,170):PANEL2,active?CYAN:BORDER);text(c,label,x+w/2,y+h/2+8,20,WHITE,true,Paint.Align.CENTER);}
    private void pill(Canvas c,float x,float y,float w,float h,String label,int color){roundPanel(c,x,y,w,h,16,PANEL2,BORDER);text(c,label,x+w/2,y+h/2+7,18,color,true,Paint.Align.CENTER);}
    private void badge(Canvas c,float x,float y,String label,int color){float w=label.length()*12+40;roundPanel(c,x,y,w,50,25,Color.argb(32,Color.red(color),Color.green(color),Color.blue(color)),color);text(c,label,x+w/2,y+32,15,color,true,Paint.Align.CENTER);}
    private void toggle(Canvas c,float x,float y,boolean on,int color){float w=112,h=54;roundPanel(c,x,y,w,h,27,on?Color.argb(120,Color.red(color),Color.green(color),Color.blue(color)):PANEL2,on?color:BORDER);p.setColor(WHITE);c.drawCircle(on?x+84:x+28,y+27,20,p);}
    private void statusRow(Canvas c,float x,float y,String label,String value,int color){p.setColor(color);c.drawCircle(x,y-7,8,p);text(c,label,x+28,y,20,WHITE,true,Paint.Align.LEFT);text(c,value,930,y,19,color,true,Paint.Align.RIGHT);}

    private void drawWaveLogo(Canvas c,float x,float y,float scale){int[] hs={32,58,85,58,32};for(int i=0;i<5;i++){float xx=x+i*15*scale;p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeWidth(8*scale);p.setColor(CYAN);p.setShadowLayer(14,0,0,CYAN);c.drawLine(xx,y-hs[i]*.5f*scale,xx,y+hs[i]*.5f*scale,p);p.clearShadowLayer();p.setStrokeCap(Paint.Cap.BUTT);}}
    private void drawDspBox(Canvas c,float x,float y,float w,float h){p.setShader(new LinearGradient(x,y,x+w,y+h,Color.rgb(38,48,58),Color.rgb(5,9,13),Shader.TileMode.CLAMP));Path top=new Path();top.moveTo(x+50,y);top.lineTo(x+w-110,y+35);top.lineTo(x+w-210,y+95);top.lineTo(x,y+55);top.close();c.drawPath(top,p);p.setShader(null);p.setColor(Color.rgb(7,12,17));c.drawRoundRect(new RectF(x,y+55,x+w-210,y+h),16,16,p);p.setColor(Color.rgb(11,16,22));Path side=new Path();side.moveTo(x+w-210,y+95);side.lineTo(x+w-110,y+35);side.lineTo(x+w-110,y+h-50);side.lineTo(x+w-210,y+h);side.close();c.drawPath(side,p);p.setColor(CYAN);p.setShadowLayer(16,0,0,CYAN);c.drawCircle(x+170,y+210,10,p);p.clearShadowLayer();text(c,"OKN_DSP",x+w-340,y+220,24,WHITE,true,Paint.Align.CENTER);text(c,"7 CHANNEL DSP",x+w-340,y+250,14,SUB,false,Paint.Align.CENTER);}
    private void drawSignalBars(Canvas c,float x,float y,int color){p.setColor(color);for(int i=0;i<5;i++){float h=18+i*14;c.drawRoundRect(new RectF(x+i*15,y-h,x+i*15+8,y),4,4,p);}}
    private void drawGear(Canvas c,float cx,float cy,int color){stroke.setColor(color);stroke.setStrokeWidth(7);c.drawCircle(cx,cy,22,stroke);c.drawCircle(cx,cy,7,stroke);for(int i=0;i<8;i++){double a=i*Math.PI/4;float x1=cx+(float)Math.cos(a)*27,y1=cy+(float)Math.sin(a)*27,x2=cx+(float)Math.cos(a)*35,y2=cy+(float)Math.sin(a)*35;c.drawLine(x1,y1,x2,y2,stroke);}}
    private void drawSpeaker(Canvas c,float cx,float cy,int color){p.setColor(color);Path q=new Path();q.moveTo(cx-24,cy-10);q.lineTo(cx-9,cy-10);q.lineTo(cx+7,cy-24);q.lineTo(cx+7,cy+24);q.lineTo(cx-9,cy+10);q.lineTo(cx-24,cy+10);q.close();c.drawPath(q,p);stroke.setColor(color);stroke.setStrokeWidth(3);c.drawArc(new RectF(cx-2,cy-17,cx+30,cy+17),-55,110,false,stroke);}
    private void drawNavIcon(Canvas c,float cx,float cy,int type,int color){stroke.setColor(color);stroke.setStrokeWidth(5);if(type==0){Path h=new Path();h.moveTo(cx-25,cy);h.lineTo(cx,cy-22);h.lineTo(cx+25,cy);h.lineTo(cx+18,cy);h.lineTo(cx+18,cy+22);h.lineTo(cx-18,cy+22);h.lineTo(cx-18,cy);h.close();c.drawPath(h,stroke);}else if(type==1){for(int i=-1;i<=1;i++){float xx=cx+i*22;c.drawLine(xx,cy-27,xx,cy+27,stroke);p.setColor(color);c.drawCircle(xx,cy+(i==0?-10:10),7,p);}}else if(type==2){for(int i=-1;i<=1;i++){float xx=cx+i*22;c.drawLine(xx,cy-27,xx,cy+27,stroke);p.setColor(color);c.drawCircle(xx,cy+(i==0?10:-10),7,p);}}else{c.drawCircle(cx,cy-22,6,stroke);c.drawCircle(cx-25,cy+22,6,stroke);c.drawCircle(cx+25,cy+22,6,stroke);c.drawLine(cx,cy-16,cx,cy,stroke);c.drawLine(cx,cy,cx-25,cy+16,stroke);c.drawLine(cx,cy,cx+25,cy+16,stroke);}}

    private int nearestEqBand(float x,float y){int ch=state.channel,best=0;float bd=Float.MAX_VALUE;for(int b=0;b<15;b++){float px=75+logFreqFrac(state.eqFreq[ch][b])*930;float py=420+(12-state.eqGain[ch][b])/24f*550;float dx=px-x,dy=py-y,d=dx*dx+dy*dy;if(d<bd){bd=d;best=b;}}return best;}
    private float logFreqFrac(float hz){return clamp((float)((Math.log(Math.max(20,hz))-Math.log(20))/(Math.log(20000)-Math.log(20))),0,1);}
    private int rainbowBand(int b){float hue=(b/14f)*300f;return Color.HSVToColor(new float[]{hue,0.90f,1f});}
    private int nextSlope(int current){for(int i=0;i<SLOPES.length;i++)if(SLOPES[i]==current)return SLOPES[(i+1)%SLOPES.length];return 24;}
    private String delayDisplay(float ms){if(state.delayUnit==1)return String.format(Locale.US,"%.1f cm",ms*34.3f);if(state.delayUnit==2)return String.format(Locale.US,"%.1f inch",ms*13.5039f);return String.format(Locale.US,"%.2f ms",ms);}
    private void text(Canvas c,String s,float x,float y,float size,int color,boolean bold,Paint.Align align){p.setShader(null);p.setStyle(Paint.Style.FILL);p.setColor(color);p.setTextSize(size);p.setTextAlign(align);p.setTypeface(bold?FONT_BOLD:FONT);c.drawText(s,x,y,p);}
    private String db(float v){return String.format(Locale.US,"%.1f dB",v);}
    private String hz(float v){if(v>=1000)return String.format(Locale.US,v>=10000?"%.0fk":"%.1fk",v/1000f);return String.format(Locale.US,"%.0f",v);}
    private float clamp(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}
    private float round1(float v){return Math.round(v*10f)/10f;}
    private String ellipsize(String s,int n){return s.length()<=n?s:s.substring(0,n-1)+"…";}
    private void toast(String s){Toast.makeText(getContext(),s,Toast.LENGTH_SHORT).show();}
}
