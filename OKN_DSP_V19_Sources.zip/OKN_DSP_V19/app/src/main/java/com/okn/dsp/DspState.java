package com.okn.dsp;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Locale;

/**
 * Phase 1 UI-only state model.
 *
 * All controls update this in-memory model immediately. No DSP/BLE write is
 * performed in Phase 1. The verified BLE/protocol sources are intentionally
 * retained in the project for Phase 2 integration.
 */
final class DspState {
    static final int CHANNELS = 7;
    static final int BANDS = 15;

    // Mix page, matching the uploaded UI reference ranges.
    float masterPercent = 75f;
    float bassPercent = 60f;
    float bassCutoffHz = 80f;
    float bassBoostDb = 4f;
    float middleBoostDb = 2f;
    float trebleBoostDb = 3f;

    // EQ page.
    final float[][] eqFreqHz = new float[CHANNELS][BANDS];
    final float[][] eqGainDb = new float[CHANNELS][BANDS];
    final float[][] eqQ = new float[CHANNELS][BANDS];
    final float[] outputGainDb = new float[CHANNELS];
    int eqChannel = 0;
    int selectedBand = 7;

    // Crossover page.
    final boolean[] hpfEnabled = new boolean[CHANNELS];
    final boolean[] lpfEnabled = new boolean[CHANNELS];
    final float[] hpfHz = new float[CHANNELS];
    final float[] lpfHz = new float[CHANNELS];
    final float[] delayMs = new float[CHANNELS];
    final int[] hpfType = new int[CHANNELS];
    final int[] lpfType = new int[CHANNELS];
    int crossoverChannel = 0;

    boolean demoConnected = true;

    static final String[] CHANNELS_SHORT = {"CH1", "CH2", "CH3", "CH4", "CH5", "CH6", "CH7"};
    static final String[] FILTER_TYPES = {
            "Linkwitz-Riley (24 dB/Oct)",
            "Linkwitz-Riley (12 dB/Oct)",
            "Butterworth (24 dB/Oct)",
            "Butterworth (12 dB/Oct)",
            "Bessel (12 dB/Oct)"
    };

    private static final float[] DEFAULT_EQ_FREQ = {
            20f, 31.5f, 50f, 80f, 125f,
            200f, 315f, 500f, 800f, 1250f,
            2000f, 3150f, 5000f, 8000f, 16000f
    };

    DspState() {
        for (int ch = 0; ch < CHANNELS; ch++) {
            for (int b = 0; b < BANDS; b++) {
                eqFreqHz[ch][b] = DEFAULT_EQ_FREQ[b];
                eqGainDb[ch][b] = 0f;
                eqQ[ch][b] = 1.0f;
            }
            outputGainDb[ch] = 0f;
            hpfEnabled[ch] = true;
            lpfEnabled[ch] = true;
            hpfHz[ch] = 80f;
            lpfHz[ch] = 3500f;
            delayMs[ch] = 0f;
            hpfType[ch] = 0;
            lpfType[ch] = 0;
        }

        // Give the initial EQ curve a gentle shape like the reference image.
        float[] shape = {-3f, -2f, 1f, 3f, 1f, 0f, 2f, 5f, 2f, 1f, 1f, 0f, -2f, -3f, -3f};
        for (int ch = 0; ch < CHANNELS; ch++) {
            System.arraycopy(shape, 0, eqGainDb[ch], 0, BANDS);
        }
    }

    void resetEqChannel(int ch) {
        if (ch < 0 || ch >= CHANNELS) return;
        for (int b = 0; b < BANDS; b++) {
            eqFreqHz[ch][b] = DEFAULT_EQ_FREQ[b];
            eqGainDb[ch][b] = 0f;
            eqQ[ch][b] = 1.0f;
        }
        outputGainDb[ch] = 0f;
    }

    void saveEqPreset(Context context) {
        SharedPreferences.Editor e = context.getSharedPreferences("okn_phase1_eq", Context.MODE_PRIVATE).edit();
        for (int ch = 0; ch < CHANNELS; ch++) {
            e.putFloat("out_" + ch, outputGainDb[ch]);
            for (int b = 0; b < BANDS; b++) {
                e.putFloat("f_" + ch + "_" + b, eqFreqHz[ch][b]);
                e.putFloat("g_" + ch + "_" + b, eqGainDb[ch][b]);
                e.putFloat("q_" + ch + "_" + b, eqQ[ch][b]);
            }
        }
        e.putBoolean("saved", true).apply();
    }

    boolean loadEqPreset(Context context) {
        SharedPreferences p = context.getSharedPreferences("okn_phase1_eq", Context.MODE_PRIVATE);
        if (!p.getBoolean("saved", false)) return false;
        for (int ch = 0; ch < CHANNELS; ch++) {
            outputGainDb[ch] = p.getFloat("out_" + ch, outputGainDb[ch]);
            for (int b = 0; b < BANDS; b++) {
                eqFreqHz[ch][b] = p.getFloat("f_" + ch + "_" + b, eqFreqHz[ch][b]);
                eqGainDb[ch][b] = p.getFloat("g_" + ch + "_" + b, eqGainDb[ch][b]);
                eqQ[ch][b] = p.getFloat("q_" + ch + "_" + b, eqQ[ch][b]);
            }
        }
        return true;
    }

    static String percent(float v) {
        return String.format(Locale.US, "%.0f%%", v);
    }

    static String db(float v) {
        if (Math.abs(v) < 0.05f) return "0.0 dB";
        return String.format(Locale.US, "%+.1f dB", v);
    }

    static String hz(float v) {
        if (v >= 1000f) {
            float k = v / 1000f;
            if (Math.abs(k - Math.round(k)) < 0.02f) return String.format(Locale.US, "%.0f kHz", k);
            return String.format(Locale.US, "%.2f kHz", k);
        }
        return String.format(Locale.US, "%.0f Hz", v);
    }
}
