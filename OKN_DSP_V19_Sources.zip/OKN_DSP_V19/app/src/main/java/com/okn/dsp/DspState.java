package com.okn.dsp;

import java.util.Arrays;

final class DspState {
    static final int CHANNELS = 7;
    static final int BANDS = 15;

    static final String[] CHANNEL_SHORT = {"CH1", "CH2", "CH3", "CH4", "CH5", "CH6", "CH7"};
    static final String[] CHANNEL_LONG = {
            "CH1 - Front L", "CH2 - Front R", "CH3 - Rear L", "CH4 - Rear R",
            "CH5 - Center", "CH6 - Sub", "CH7 - AUX"
    };

    float masterVolume = -20f;
    int page = 0;
    int channel = 0;
    int selectedBand = 0;
    int homePreset = 0;
    int delayUnit = 0; // 0 ms, 1 cm, 2 inch

    final float[] outputGain = new float[CHANNELS];
    final boolean[] outputMute = new boolean[CHANNELS];

    final float[][] eqFreq = new float[CHANNELS][BANDS];
    final float[][] eqGain = new float[CHANNELS][BANDS];
    final float[][] eqQ = new float[CHANNELS][BANDS];
    final boolean[][] eqWritable = new boolean[CHANNELS][BANDS];

    final boolean[] crossoverEnabled = new boolean[CHANNELS];
    final float[] hpfHz = new float[CHANNELS];
    final float[] lpfHz = new float[CHANNELS];
    final int[] hpfSlope = new int[CHANNELS];
    final int[] lpfSlope = new int[CHANNELS];
    final int[] hpfType = new int[CHANNELS];
    final int[] lpfType = new int[CHANNELS];
    final float[] delayMs = new float[CHANNELS];

    int linkMode = 0; // 0 off, 1 pair 1-2, 2 pair 3-4, 3 pair 5-6, 4 all

    DspState() {
        float[] defaultFreq = {20, 31.5f, 50, 80, 125, 200, 315, 500, 800, 1250, 2000, 3150, 5000, 8000, 16000};
        for (int ch = 0; ch < CHANNELS; ch++) {
            outputGain[ch] = (ch == 5) ? -8f : -3f;
            outputMute[ch] = false;
            crossoverEnabled[ch] = true;
            hpfHz[ch] = (ch == 5) ? 20f : 80f;
            lpfHz[ch] = (ch == 5) ? 120f : 3000f;
            hpfSlope[ch] = 24;
            lpfSlope[ch] = 24;
            hpfType[ch] = 0;
            lpfType[ch] = 0;
            delayMs[ch] = 0f;
            for (int b = 0; b < BANDS; b++) {
                eqFreq[ch][b] = defaultFreq[b];
                eqGain[ch][b] = 0f;
                eqQ[ch][b] = 1f;
                eqWritable[ch][b] = false;
            }
        }
    }

    void flattenCurrentEq() {
        Arrays.fill(eqGain[channel], 0f);
    }
}
