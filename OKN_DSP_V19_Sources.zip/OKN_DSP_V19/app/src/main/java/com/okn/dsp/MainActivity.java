package com.okn.dsp;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;

/**
 * OKN_DSP V19 - Phase 1 native UI shell.
 *
 * No DSP writer is started in this version. Controls update locally on every
 * touch/move event so UI behavior can be validated before Phase 2 hardware
 * protocol binding is enabled.
 */
public class MainActivity extends Activity {
    private Phase1UiView uiView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureWindowSafely();
        enterImmersiveSafely();
        uiView = new Phase1UiView(this);
        setContentView(uiView);
    }

    @Override
    protected void onResume() {
        super.onResume();
        configureWindowSafely();
        enterImmersiveSafely();
    }

    private void configureWindowSafely() {
        try {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                WindowManager.LayoutParams lp = window.getAttributes();
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
                window.setAttributes(lp);
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                window.setStatusBarContrastEnforced(false);
                window.setNavigationBarContrastEnforced(false);
            }
        } catch (RuntimeException ignored) {
            // OEM window customizations must never prevent the UI from opening.
        }
    }

    private void enterImmersiveSafely() {
        try {
            Window window = getWindow();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                window.setDecorFitsSystemWindows(false);
                WindowInsetsController controller = window.getInsetsController();
                if (controller != null) {
                    controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                    controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                }
            } else {
                window.getDecorView().setSystemUiVisibility(
                        android.view.View.SYSTEM_UI_FLAG_FULLSCREEN |
                                android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                                android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                                android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                                android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                                android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            }
        } catch (RuntimeException ignored) {
            // Full-screen failure must never prevent the app from opening.
        }
    }
}
