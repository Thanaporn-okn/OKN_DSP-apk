package com.okn.dsp;

import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.widget.TextView;

/**
 * V19 / Phase 1 startup-hardened UI build.
 *
 * BLE/DSP transport is deliberately not started in Phase 1. V19 restores the
 * defensive window handling that was present before V18 and adds a simple
 * fallback view so an OEM fullscreen/window exception cannot terminate startup.
 */
public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureWindowSafely();

        try {
            setContentView(new DspView(this));
        } catch (RuntimeException e) {
            setContentView(createStartupFallback(e));
        }

        enterImmersiveSafely();
    }

    @Override
    protected void onResume() {
        super.onResume();
        configureWindowSafely();
        enterImmersiveSafely();
    }

    private void configureWindowSafely() {
        try {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                WindowManager.LayoutParams lp = window.getAttributes();
                lp.layoutInDisplayCutoutMode =
                        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
                window.setAttributes(lp);
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                window.setStatusBarContrastEnforced(false);
                window.setNavigationBarContrastEnforced(false);
            }
        } catch (RuntimeException ignored) {
            // OEM-specific window behavior must never prevent the app from opening.
        }
    }

    private void enterImmersiveSafely() {
        try {
            Window window = getWindow();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                window.setDecorFitsSystemWindows(false);
                WindowInsetsController controller = window.getInsetsController();
                if (controller != null) {
                    controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                    controller.setSystemBarsBehavior(
                            WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                }
            } else {
                window.getDecorView().setSystemUiVisibility(
                        android.view.View.SYSTEM_UI_FLAG_FULLSCREEN |
                                android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                                android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                                android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                                android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                                android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            }
        } catch (RuntimeException ignored) {
            // Fullscreen failure must never terminate the activity.
        }
    }

    private TextView createStartupFallback(RuntimeException error) {
        TextView view = new TextView(this);
        view.setBackgroundColor(Color.rgb(5, 14, 24));
        view.setTextColor(Color.WHITE);
        view.setTextSize(18f);
        view.setGravity(Gravity.CENTER);
        view.setPadding(48, 48, 48, 48);
        view.setText("OKN_DSP V19\nUI startup protection active\n" +
                error.getClass().getSimpleName());
        return view;
    }
}
