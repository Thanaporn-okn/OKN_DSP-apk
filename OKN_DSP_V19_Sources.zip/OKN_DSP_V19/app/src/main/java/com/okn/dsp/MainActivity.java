package com.okn.dsp;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.widget.Toast;

public class MainActivity extends Activity implements BleManager.Listener {
    private static final int REQ_BLE = 1801;
    private final Handler main = new Handler(Looper.getMainLooper());
    private DspView dspView;
    private BleManager ble;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureWindow();
        enterImmersive();
        dspView = new DspView(this);
        setContentView(dspView);
        dspView.setBleStatus("กำลังเตรียม Bluetooth", "OKN-DSP_7CH", false);
        main.postDelayed(this::initBle, 250L);
    }

    private void initBle() {
        if (isFinishing() || isDestroyed()) return;
        try {
            ble = new BleManager(this, this);
            dspView.setBleManager(ble);
            requestBlePermissions();
        } catch (RuntimeException e) {
            showBleUnavailable("Bluetooth เริ่มไม่ได้: " + e.getClass().getSimpleName());
        }
    }

    @Override protected void onResume() {
        super.onResume();
        configureWindow();
        enterImmersive();
    }

    @Override protected void onDestroy() {
        main.removeCallbacksAndMessages(null);
        if (ble != null) ble.close();
        super.onDestroy();
    }

    @Override public void onBleStatus(String status, String deviceName, boolean ready) {
        if (dspView != null) dspView.setBleStatus(status, deviceName, ready);
    }

    @Override public void onBleMessage(String message) {
        if (dspView != null) dspView.setDiagnostic(message);
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override public void onScalarValue(int actuatorId, float value) {
        if (dspView != null) dspView.setScalarFromDsp(actuatorId, value);
    }

    @Override public void onEqValue(int channel0, int uiBand0, float frequency, float gainDb, float q, boolean writable) {
        if (dspView != null) dspView.setEqFromDsp(channel0, uiBand0, frequency, gainDb, q, writable);
    }

    private void requestBlePermissions() {
        if (ble == null) return;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                boolean scan = checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED;
                boolean connect = checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
                if (!scan || !connect) {
                    dspView.setBleStatus("รออนุญาต Bluetooth", "OKN-DSP_7CH", false);
                    requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}, REQ_BLE);
                } else ble.startScan();
            } else if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_BLE);
            } else ble.startScan();
        } catch (RuntimeException e) {
            showBleUnavailable("ขอสิทธิ์ Bluetooth ไม่สำเร็จ");
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_BLE) return;
        boolean ok = grantResults.length > 0;
        for (int result : grantResults) ok &= result == PackageManager.PERMISSION_GRANTED;
        if (ok && ble != null) ble.startScan();
        else showBleUnavailable("ต้องอนุญาต Bluetooth ก่อนเชื่อมต่อ DSP");
    }

    private void showBleUnavailable(String message) {
        if (dspView != null) {
            dspView.setBleStatus("Bluetooth ยังไม่พร้อม", "OKN-DSP_7CH", false);
            dspView.setDiagnostic(message);
        }
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private void configureWindow() {
        try {
            Window w = getWindow();
            w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                WindowManager.LayoutParams lp = w.getAttributes();
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
                w.setAttributes(lp);
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                w.setStatusBarContrastEnforced(false);
                w.setNavigationBarContrastEnforced(false);
            }
        } catch (RuntimeException ignored) {}
    }

    private void enterImmersive() {
        try {
            Window w = getWindow();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                w.setDecorFitsSystemWindows(false);
                WindowInsetsController c = w.getInsetsController();
                if (c != null) {
                    c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                    c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                }
            } else {
                w.getDecorView().setSystemUiVisibility(
                        android.view.View.SYSTEM_UI_FLAG_FULLSCREEN |
                        android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                        android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                        android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                        android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                        android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            }
        } catch (RuntimeException ignored) {}
    }
}
