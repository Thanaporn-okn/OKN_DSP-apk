# OKN_DSP V18 - no custom rules required.
