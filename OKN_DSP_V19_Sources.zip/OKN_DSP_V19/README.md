# OKN DSP V19 — Phase 1

V19 is built directly from V18 and keeps the V14/V16 visual base, the V16 bottom-navigation touch fix, V17 custom dialogs and V18 immediate preset loading.

## V19 smoothness fixes

- Synchronize interactive redraws with display vsync using `postInvalidateOnAnimation()` so rapid touch events are coalesced into one frame.
- Skip duplicate slider updates when the rounded value has not changed.
- Coalesce real-time state persistence for rapid slider events into one SharedPreferences apply every ~120 ms instead of one write request per MotionEvent.
- Preserve instant in-memory control/graph response while keeping automatic persistence and a durable lifecycle checkpoint.
- Reuse frame-local `RectF` objects to reduce garbage collection during scrolling and slider dragging.
- Keep hit-test geometry instead of rebuilding touch target objects on every drag frame.
- Remove the platform Dialog zoom/fade animation, which can hitch on some Samsung devices.
- Explicitly keep Android hardware acceleration enabled.
- Preset selection still loads the chosen preset immediately and the custom Saved Presets dialog remains enabled.
- V16 Home / Mix / Eq touch ownership fix remains intact.

## Version

- versionName: 19.0.0
- versionCode: 1019
