import 'package:flutter/material.dart';

void main() => runApp(const OKNDSP());

class OKNDSP extends StatelessWidget {
  const OKNDSP({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner:false,
      theme: ThemeData.dark(useMaterial3:true),
      home: const Home()
    );
  }
}

class Home extends StatelessWidget {
  const Home({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff0b1016),
      body: SafeArea(
        child: Column(
          children:[
            const SizedBox(height:30),
            const Text(
              "OKN_DSP V21 BETA2",
              style:TextStyle(fontSize:30,color:Colors.cyan)
            ),
            const Text("BP1048P4 7CH DSP"),
            Expanded(
              child: Row(
                children: List.generate(7,(i)=>
                  Expanded(
                    child: Column(
                      children:[
                        Text("CH${i+1}"),
                        Expanded(
                          child: RotatedBox(
                            quarterTurns:3,
                            child: Slider(
                              value:.5,
                              onChanged:null
                            )
                          )
                        ),
                        const Text("-12 dB")
                      ]
                    )
                  )
                )
              )
            )
          ]
        )
      )
    );
  }
}
