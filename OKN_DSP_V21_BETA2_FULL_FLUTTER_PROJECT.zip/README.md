# OKN_DSP V21 BETA2 FULL FLUTTER PROJECT

Flutter project ready for GitHub Actions build.
