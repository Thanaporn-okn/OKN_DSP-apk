package com.okn.dsp.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun MainScreen() {
    val channels = listOf(
        "CH1 FRONT L",
        "CH2 FRONT R",
        "CH3 SUB",
        "CH4 REAR L",
        "CH5 REAR R",
        "CH6 AUX",
        "CH7 CENTER"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF101010))
            .padding(12.dp)
    ) {
        Text(
            "OKN_DSP BP1048P4 7CH DSP",
            color = Color.White,
            style = MaterialTheme.typography.headlineSmall
        )

        Text("● Connected   Bluetooth   TOSLINK",
            color = Color(0xFF00E5FF))

        Spacer(Modifier.height(12.dp))

        Card {
            Column(Modifier.padding(12.dp)) {
                Text("MASTER VOLUME")
                Slider(value = 0.75f, onValueChange = {})
                Text("-12.5 dB")
            }
        }

        Spacer(Modifier.height(10.dp))

        channels.forEachIndexed { index, ch ->
            Text(
                ch,
                color = when(index){
                    2 -> Color(0xFFB000FF)
                    5 -> Color(0xFF00FF66)
                    6 -> Color(0xFFFFD000)
                    else -> Color(0xFF00E5FF)
                }
            )
            Slider(value = 0.5f, onValueChange = {})
        }

        Spacer(Modifier.height(8.dp))

        Row {
            listOf("MAIN","EQ","XOVER","DELAY","MIX").forEach {
                Button(
                    onClick = {},
                    modifier = Modifier.padding(2.dp)
                ){
                    Text(it)
                }
            }
        }
    }
}