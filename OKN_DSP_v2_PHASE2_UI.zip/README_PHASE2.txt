OKN_DSP v2 Phase 2 UI

Added:
- Dark DSP Dashboard
- Master Volume
- 7 Channel Fader
- Channel Color Coding
- Navigation Base

Next:
Phase 3 EQ / Crossover / Delay