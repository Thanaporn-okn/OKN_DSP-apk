package com.okn.dsp
import android.app.Activity
import android.os.Bundle

class MainActivity: Activity(){
 override fun onCreate(b:Bundle?){
  super.onCreate(b)
  setContentView(R.layout.activity_main)
 }
}
