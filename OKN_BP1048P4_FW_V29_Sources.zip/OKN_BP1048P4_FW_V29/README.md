# OKN_BP1048P4_FW_V29

V29 is a reproducible-release hardening revision of the portable clean-room
firmware foundation. It preserves the V28 toolchain contract; Protocol V2 remains unchanged,
Persistence Schema 2, golden vectors, sanitizer fuzzing, evidence gates,
mobile-flash safety boundaries, and all fail-closed hardware locks.

## What V29 adds

- Deterministic source ZIP builder (`tools/reproducible_package.py`).
- Fixed ZIP timestamps: 1980-01-01 00:00:00.
- Lexicographically sorted POSIX entry paths.
- Normalized regular-file mode 0644.
- Symlink rejection and path-safety checks.
- Double-build byte-for-byte identity verification.
- Extract/readback verification against every source file.
- Reproducibility tests proving source mtimes do not affect package bytes.
- `release_repro_manifest.json` and static non-authorizing policy guard.
- V28 GitHub validation bound as the immediate predecessor.

## Safety state

This is still a portable host-validated firmware foundation, **not** a
BP1048P4/GoloPine flash image. V29 adds no register address, board pin,
programmer packet, boot command, target linker script, or hardware write.

- Hardware flashable: NO
- Mobile flashable: NO
- Programmer I/O: NOT IMPLEMENTED
- Destructive executor: NOT IMPLEMENTED
- Target `.bin/.img`: NONE
- Exact BP1048P4/GoloPine port: LOCKED

Passing the reproducibility contract only proves deterministic source packaging.
It does not prove target compatibility or authorize hardware.

## Validation

Run:

```sh
make host-test
```

This performs all existing core/audio/persistence/transport/safe-boot tests,
ASan/UBSan fuzzing, wire/persistence golden vectors, GCC/Clang portability,
target-toolchain compile-only checks, provenance/evidence safety gates, and the
V29 reproducible-release tests.
