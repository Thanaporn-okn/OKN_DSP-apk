#!/usr/bin/env python3
from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'evidence_manifest.json').read_text())
errors=[]
if m.get('schema')!=4: errors.append('evidence schema must be 4')
if m.get('project_version')!=29: errors.append('project_version must be 29')
if m.get('target')!='BP1048P4' or m.get('board')!='GoloPine 7CH': errors.append('target/board mismatch')
if m.get('policy')!='FAIL_CLOSED_NO_INFERENCE': errors.append('policy mismatch')
if m.get('hardware_authorized') is not False: errors.append('hardware_authorized must be false')
req=m.get('required_exact_evidence',{})
if any(bool(v) for v in req.values()): errors.append('V29 exact evidence flags must all remain false')
prov=m.get('provenance',{})
if prov.get('previous_source_sha256')!='9acb0d62f7faf64912648d0f8b1ab8da78ca6fa1bf00a748f3ca921e1b1385f8': errors.append('V28 source provenance mismatch')
if prov.get('validation_zip_sha256')!='857710fe05326085b90e11207b4a89ad404ee4766a646697ebd35f16acf3cd26': errors.append('V28 validation provenance mismatch')
if not any(o.get('id')=='v28-ci-validation' for o in m.get('observations',[])): errors.append('V28 CI observation missing')
for ob in m.get('observations',[]):
    if ob.get('authorizes') not in ([],None): errors.append('observations may not authorize hardware in V29')
if errors:
    [print('BLOCKED:',e) for e in errors]; sys.exit(1)
print('PASS: V29 evidence manifest is internally consistent and non-authorizing')
