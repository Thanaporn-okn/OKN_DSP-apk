#!/usr/bin/env python3
from pathlib import Path
import json, sys
root=Path(__file__).resolve().parents[1]
s=json.loads((root/'android_discovery_capture_schema.json').read_text())
h=json.loads((root/'hardware_discovery_manifest.json').read_text())
errors=[]
if s.get('schema')!=1 or s.get('project_version')!=29: errors.append('capture schema/version mismatch')
if s.get('format')!='OKN_ANDROID_DISCOVERY_CAPTURE' or s.get('format_version')!=1: errors.append('capture format mismatch')
if s.get('policy')!='READ_ONLY_ENUMERATION_CANONICAL_HASH_NO_COMMANDS_NO_AUTHORIZATION': errors.append('capture policy mismatch')
if s.get('allowed_transports')!=['usb_host','ble','serial_enumeration']: errors.append('allowed transports changed')
ss=s.get('safety',{})
for k in ('read_only_only','commands_sent_must_be_empty','write_attempted_must_be_false','raw_capture_file_hash_reverified_by_outer_manifest'):
    if ss.get(k) is not True: errors.append('capture safety flag missing: '+k)
for k in ('automatic_authorization','programmer_io_available','destructive_executor_available'):
    if ss.get(k) is not False: errors.append('forbidden capture capability enabled: '+k)
if h.get('android_capture_schema')!='android_discovery_capture_schema.json': errors.append('hardware discovery schema link missing')
if h.get('android_capture_importer')!='tools/import_android_discovery.py': errors.append('hardware discovery importer link missing')
if h.get('android_host_transport_verified') is not False or h.get('automatic_authorization') is not False: errors.append('capture intake may not authorize hardware')
if errors:
    [print('BLOCKED:',e) for e in errors]; sys.exit(1)
print('PASS: V29 Android discovery capture contract is canonical-hash-bound, read-only, and non-authorizing')
