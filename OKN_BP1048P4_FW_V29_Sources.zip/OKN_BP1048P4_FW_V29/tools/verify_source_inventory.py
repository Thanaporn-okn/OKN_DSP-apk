#!/usr/bin/env python3
from pathlib import Path
import json, subprocess, sys

root=Path(__file__).resolve().parents[1]
inv=json.loads((root/'source_inventory.json').read_text())
errors=[]
if inv.get('schema') != 1: errors.append('inventory schema must be 1')
if inv.get('project_version') != 29: errors.append('inventory project_version must be 29')
if inv.get('algorithm') != 'SHA-256': errors.append('inventory algorithm must be SHA-256')
if inv.get('authorizes_hardware') is not False: errors.append('inventory may not authorize hardware')
if inv.get('authorizes_mobile_flash') is not False: errors.append('inventory may not authorize mobile flash')
if errors:
    [print('BLOCKED:',e) for e in errors]
    raise SystemExit(1)
r=subprocess.run([sys.executable,str(root/'tools/source_inventory.py'),'--root',str(root)])
raise SystemExit(r.returncode)
