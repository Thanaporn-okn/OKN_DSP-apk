package com.okn.dsp.protocol

/**
 * V42 gate: normal UI writes remain locked.
 * Only the Evidence Lab controlled MasterVolume proof may issue WRITE 0x57,
 * with a read-current -> -1 dB -> readback -> automatic restore -> readback sequence.
 * SaveParams (ID 7), EQ, presets, delay and persistent writes remain blocked.
 */
object WriteGate {
    const val enabled: Boolean = false
    const val controlledMasterVolumeProofEnabled: Boolean = true
}
