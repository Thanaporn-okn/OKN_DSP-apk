class BluetoothManager{

 List<String> devices=[];

 Future<void> scan()async{
  devices=[
   "BP1048P4 DSP",
   "OKN_DSP Module"
  ];
 }

 Future<void> connect()async{
  // Connect Bluetooth characteristic
 }

 Future<void> disconnect()async{
  // Disconnect
 }

 Future<void> write(List<int> data)async{
  // BLE write characteristic
 }

}
