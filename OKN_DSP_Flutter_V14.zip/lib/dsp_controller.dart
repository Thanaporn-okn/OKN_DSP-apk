import 'bluetooth_manager.dart';

class DSPController{
 bool connected=false;
 final bt=BluetoothManager();

 void sendVolume(int ch,double value){
  int db=((value*60)-60).round();
  List<int> packet=[
   0xAA,
   ch,
   db & 0xff,
   0x55
  ];
  bt.write(packet);
 }

 void receive(List<int> data){
  // Decode DSP notify packet
 }

}
