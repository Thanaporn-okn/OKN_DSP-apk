import 'package:flutter/material.dart';
import 'bluetooth_manager.dart';
import 'dsp_controller.dart';

void main()=>runApp(const OKNDSP());

class OKNDSP extends StatelessWidget{
 const OKNDSP({super.key});
 @override
 Widget build(BuildContext c)=>MaterialApp(
 debugShowCheckedModeBanner:false,
 theme:ThemeData.dark(useMaterial3:true),
 home:const Home());
}

class Home extends StatefulWidget{
 const Home({super.key});
 State<Home> createState()=>_Home();
}

class _Home extends State<Home>{
 final bt=BluetoothManager();
 final dsp=DSPController();
 String state="Disconnected";

 Widget build(BuildContext c)=>Scaffold(
 backgroundColor:const Color(0xff0b1016),
 body:SafeArea(child:Column(children:[
 const Text("OKN_DSP",
 style:TextStyle(fontSize:32,color:Colors.cyan)),
 Text(state),
 Row(mainAxisAlignment:MainAxisAlignment.center,children:[
 ElevatedButton(
 onPressed:()async{
 await bt.scan();
 setState(()=>state="Device Found");
 },
 child:const Text("SCAN")),
 ElevatedButton(
 onPressed:()async{
 await bt.connect();
 dsp.connected=true;
 setState(()=>state="Connected BP1048P4");
 },
 child:const Text("CONNECT"))
 ]),
 Expanded(child:Row(
 children:List.generate(7,(i)=>Expanded(
 child:Column(children:[
 Text("CH${i+1}"),
 Expanded(child:RotatedBox(
 quarterTurns:3,
 child:Slider(
 value:.5,
 onChanged:(v)=>dsp.sendVolume(i,v)))),
 const Text("-30 dB")
 ]))))),
 ])));
}
