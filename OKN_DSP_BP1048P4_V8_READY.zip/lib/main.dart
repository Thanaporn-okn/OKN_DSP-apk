
import 'package:flutter/material.dart';

void main()=>runApp(const App());

class App extends StatelessWidget{
 const App({super.key});
 Widget build(BuildContext c)=>MaterialApp(
  theme:ThemeData.dark(),
  home:const DSPPage());
}

class DSPPage extends StatefulWidget{
 const DSPPage({super.key});
 State<DSPPage> createState()=>_DSPPageState();
}

class _DSPPageState extends State<DSPPage>{
 int ch=1;
 double vol=50;
 bool connected=false;
 final cmd=['Volume','EQ','Delay','HPF','LPF','Preset'];

 Widget build(BuildContext c)=>Scaffold(
 appBar:AppBar(title:const Text('OKN_DSP BP1048P4 V8')),
 body:ListView(
 padding:const EdgeInsets.all(16),
 children:[
 Text('BP1048P4 Communication'),
 SwitchListTile(
 title:const Text('Device Connected'),
 value:connected,
 onChanged:(v)=>setState(()=>connected=v)),
 DropdownButton<int>(
 value:ch,
 items:List.generate(7,(i)=>DropdownMenuItem(
 value:i+1,child:Text('Channel CH${i+1}'))),
 onChanged:(v)=>setState(()=>ch=v!)),
 Text('Volume ${vol.toInt()}'),
 Slider(value:vol,min:0,max:100,
 onChanged:(v)=>setState(()=>vol=v)),
 const Text('Command Queue'),
 ...cmd.map((e)=>ListTile(
 title:Text(e),
 trailing:ElevatedButton(
 child:const Text('SEND'),
 onPressed:(){},
 ))),
 ]));
}
