import 'package:flutter/material.dart';

void main()=>runApp(const OKNApp());

class OKNApp extends StatelessWidget{
 const OKNApp({super.key});

 @override
 Widget build(BuildContext context){
  return MaterialApp(
   debugShowCheckedModeBanner:false,
   theme:ThemeData.dark(),
   home:const DSPHome()
  );
 }
}

class DSPHome extends StatelessWidget{
 const DSPHome({super.key});

 @override
 Widget build(BuildContext context){
  return Scaffold(
   appBar:AppBar(title:const Text('OKN_DSP BP1048P4 V40.2')),
   body:ListView(
    padding:const EdgeInsets.all(20),
    children:const [
     Text('Bluetooth DSP Controller',
       style:TextStyle(fontSize:28,color:Colors.cyan)),
     SizedBox(height:20),
     Text('Scan Device'),
     Text('Connect / Disconnect'),
     Text('CH1 - CH7 Mixer'),
     Text('Volume Control'),
     Text('15 Band EQ'),
     Text('Delay ms'),
     Text('HPF / LPF Crossover'),
     Text('BP1048P4 Command Builder'),
     Text('TX / RX HEX Monitor'),
    ],
   ),
  );
 }
}
