Android V2 embedding ready
