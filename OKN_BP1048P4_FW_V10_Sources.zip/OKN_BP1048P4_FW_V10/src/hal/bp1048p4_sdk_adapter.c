#include "bp1048p4_sdk_adapter.h"

static const bp1048p4_sdk_capabilities_t LOCKED_CAPS = {
    .abi_version = BP1048P4_SDK_ADAPTER_ABI,
    .evidence_level = BP1048P4_SDK_EVIDENCE_FAMILY_ONLY,
    .exact_bp1048p4_identity_verified = false,
    .exact_golopine_board_verified = false,
    .startup_verified = false,
    .linker_verified = false,
    .flash_programmer_verified = false,
    .image_layout_verified = false,
    .image_format_verified = false,
    .programmer_transport_verified = false,
    .recovery_path_verified = false,
    .power_safety_verified = false,
    .original_firmware_backup_readback_verified = false,
    .post_flash_readback_verify_verified = false,
    .audio_api_verified = false,
    .board_audio_route_verified = false,
    .output_safety_mute_verified = false,
    .ble_api_verified = false,
    .board_ble_route_verified = false,
    .nvm_api_verified = false,
    .board_nvm_layout_verified = false
};

static bool exact_board_base(const bp1048p4_sdk_capabilities_t *caps) {
    return caps->evidence_level == BP1048P4_SDK_EVIDENCE_EXACT_BOARD &&
           caps->exact_bp1048p4_identity_verified &&
           caps->exact_golopine_board_verified &&
           caps->startup_verified &&
           caps->linker_verified;
}

okn_status_t bp1048p4_sdk_adapter_authorize(const bp1048p4_sdk_capabilities_t *caps,
                                             bp1048p4_sdk_use_t use) {
    if (!caps) return OKN_ERR_ARG;
    if (caps->abi_version != BP1048P4_SDK_ADAPTER_ABI) return OKN_ERR_FORMAT;

    /* Family SDK evidence and even an exact-chip SDK are not enough to prove
     * the GoloPine board wiring/routing. Real-target operations require both. */
    if (!exact_board_base(caps)) return OKN_ERR_HAL_LOCKED;

    switch (use) {
        case BP1048P4_SDK_USE_RUNTIME_AUDIO:
            if (!caps->audio_api_verified || !caps->board_audio_route_verified ||
                !caps->output_safety_mute_verified) return OKN_ERR_HAL_LOCKED;
            return OKN_OK;
        case BP1048P4_SDK_USE_RUNTIME_BLE:
            if (!caps->ble_api_verified || !caps->board_ble_route_verified)
                return OKN_ERR_HAL_LOCKED;
            return OKN_OK;
        case BP1048P4_SDK_USE_RUNTIME_NVM:
            if (!caps->nvm_api_verified || !caps->board_nvm_layout_verified)
                return OKN_ERR_HAL_LOCKED;
            return OKN_OK;
        case BP1048P4_SDK_USE_FLASH_IMAGE:
            if (!caps->flash_programmer_verified || !caps->image_layout_verified ||
                !caps->image_format_verified || !caps->programmer_transport_verified ||
                !caps->recovery_path_verified || !caps->power_safety_verified ||
                !caps->original_firmware_backup_readback_verified ||
                !caps->post_flash_readback_verify_verified)
                return OKN_ERR_HAL_LOCKED;
            return OKN_OK;
        default:
            return OKN_ERR_ARG;
    }
}

const bp1048p4_sdk_capabilities_t *bp1048p4_sdk_capabilities_get(void) {
    return &LOCKED_CAPS;
}
