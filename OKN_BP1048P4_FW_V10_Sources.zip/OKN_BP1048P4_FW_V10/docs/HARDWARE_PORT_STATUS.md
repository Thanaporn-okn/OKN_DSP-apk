# Hardware port status — V10

| Port area | V10 state |
|---|---|
| Portable DSP/control core | PASS |
| BLE-like framing/model | PASS |
| Persistence model | PASS |
| Exact BP1048P4 SDK/startup/linker | LOCKED |
| Exact GoloPine board routing/pin map | LOCKED |
| Programmer transport + image format/layout | LOCKED |
| Recovery + power-safety procedure | LOCKED |
| Original firmware readback/backup verification | LOCKED |
| Post-flash readback verification | LOCKED |
| Android USB-OTG / verified OTA host path | LOCKED |
| Hardware flashable | NO |
| Mobile flashable | NO |

V10 does not infer any P4 register, memory address, boot pin, or programmer packet from B1/B2 family material.
