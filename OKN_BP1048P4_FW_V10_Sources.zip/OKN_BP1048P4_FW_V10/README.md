# OKN_BP1048P4_FW_V10

Portable clean-room control/DSP firmware architecture for the GoloPine 7CH target using BP1048P4 as the intended chip. Hardware access remains fail-closed.

V10 keeps the V1-V9 portable core and fixes two control-plane issues before hardware integration: `GET_INFO` now reports firmware version 10 from a single version header, and application-level command rejection is returned inside an ACK without aborting the transport loop. Protocol wire version remains V2.

V10 also strengthens flash safety. A flash image is not authorizable until exact target/board evidence, programmer transport, image layout/format, recovery and power safety are verified **and** the original firmware can be read back/hashed and the programmed image can be read back/verified. Android flashing has an additional verified-host-transport gate.

`flash_session_manifest.json` and `tools/flash_session_guard.py` are non-executing preflight controls. They contain no programmer command, boot address, register, pin guess, or vendor flash packet.

Run `make verify`, `make test`, and `make demo`. This release intentionally remains `hardware_flashable=false` and `mobile_flashable=false` and ships no target firmware image.
