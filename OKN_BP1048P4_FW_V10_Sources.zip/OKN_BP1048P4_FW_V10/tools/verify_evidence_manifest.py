#!/usr/bin/env python3
from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[1]
m=json.loads((root/"evidence_manifest.json").read_text())
errors=[]
if m.get("schema")!=3: errors.append("evidence schema must be 3")
if m.get("project_version")!=10: errors.append("project_version must be 10")
if m.get("target")!="BP1048P4" or m.get("board")!="GoloPine 7CH": errors.append("target/board mismatch")
if m.get("policy")!="FAIL_CLOSED_NO_INFERENCE": errors.append("policy mismatch")
if m.get("hardware_authorized") is not False: errors.append("hardware_authorized must be false")
req=m.get("required_exact_evidence",{})
if any(bool(v) for v in req.values()): errors.append("V10 exact evidence flags must all remain false")
prov=m.get("provenance",{})
if prov.get("previous_source_sha256")!="1832445b66920c88890b0142e7599c72be827cd303b592dbd82d7e6d799cae46": errors.append("V9 source provenance mismatch")
if prov.get("validation_zip_sha256")!="9b0112916c71aeedbe7fa7b8a39b8ef750d463f09b606d74627fc28a220c703a": errors.append("V9 validation provenance mismatch")
for ob in m.get("observations",[]):
    if ob.get("authorizes") not in ([],None): errors.append("observations may not authorize hardware in V10")
if errors:
    [print("BLOCKED:",e) for e in errors]; sys.exit(1)
print("PASS: V10 evidence manifest is internally consistent and non-authorizing")
