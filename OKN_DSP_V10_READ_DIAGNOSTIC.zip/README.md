# OKN DSP V10 Read Diagnostic

V10 is the next protocol-discovery stage after verified AB02/AB03 Notify.

Verified:
- Device: LE-GoIoPine_DSP_A
- Address: DC:E0:D9:88:C7:04
- Service: 0000ab00-0000-1000-8000-00805f9b34fb
- AB01: READ, WRITE, WRITE_NR
- AB02: NOTIFY
- AB03: NOTIFY
- CCCD for AB02/AB03 succeeds with status 0.

V10:
- Enables AB02 and AB03 Notify sequentially.
- Automatically performs a Bluetooth GATT READ of AB01 after Notify is enabled.
- Shows the AB01 read response as hex.
- Also continues listening for AB02/AB03 notifications.
- Does NOT write a DSP payload to AB01.
- Does NOT invent or send any BP1048P4 command bytes.
