package com.okn.dsp.protocol

/**
 * V48 gate.
 * Generic writes remain disabled. V45 scalar controls stay enabled because they
 * are runtime verified. V48 additionally enables one constrained recovery-only
 * CH1 Band4 EQ proof only. SaveParams ID=7, normal EQ writes, presets, delay and
 * unknown actuator writes remain blocked.
 */
object WriteGate {
    const val enabled: Boolean = false
    const val controlledMasterVolumeProofEnabled: Boolean = true
    const val verifiedScalarControlsEnabled: Boolean = true
    const val controlledEqBandProofEnabled: Boolean = false
    const val eqBandRecoveryEnabled: Boolean = true
}
