# Architecture

## Components

```mermaid
flowchart LR
  P[Permitted Data Provider] --> W[BullMQ Worker]
  M[Mock Providers] --> W
  W --> N[Normalizer]
  N --> D[Duplicate Detector]
  D --> DB[(PostgreSQL + PostGIS)]
  DB --> E[Event Publisher]
  E --> R[(Redis Pub/Sub)]
  R --> A[NestJS API / SSE]
  A --> B[Next.js BFF]
  B --> UI[Responsive Browser UI]
```

## Trust Boundaries

Browser never receives provider access tokens or `INTERNAL_API_KEY`. The API is private in Docker Compose and Next.js proxies REST/SSE requests with the internal key. In non-demo mode, the BFF verifies an HttpOnly JWT session before proxying.

## Ingestion Transaction Model

1. Provider returns external shape.
2. Zod validation/normalization.
3. URL normalization and SHA-256 identity.
4. Lookup `(source, externalId)` or URL hash.
5. Optional high-confidence secondary match using seller + price ±1% + pg_trgm title similarity.
6. Insert/update using Prisma.
7. DB unique constraints protect races.
8. Price changes append `ProductPriceHistory`.
9. Commit.
10. Publish Redis event and evaluate notification rules.

## Scaling

- Feed indexes begin with `discoveredAt DESC` and use stable keyset cursors.
- Price/nearest cursors use their actual sort key plus `id`.
- Geo queries use `ST_DWithin` with GiST geography index.
- API replicas are stateless; realtime fanout uses Redis Pub/Sub.
- BullMQ supports multiple workers; DB unique constraints preserve idempotency.
