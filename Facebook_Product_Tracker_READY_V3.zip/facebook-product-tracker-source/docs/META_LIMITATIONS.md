# Meta / Facebook Integration Limits

Last reviewed for this scaffold: 2026-09-17.

## Facebook Groups

Meta deprecated the Facebook Groups API with Graph API v19 and documented removal from all versions on 2024-04-22. Do not implement the old `publish_to_groups` / `groups_access_member_info` flow as if it were still generally available.

Official references:
- https://developers.facebook.com/docs/graph-api/changelog/version19.0/
- https://developers.facebook.com/blog/post/2024/01/23/introducing-facebook-graph-and-marketing-api-v19/

`AuthorizedGroupProvider` therefore fails closed. Replace it only with a current data source for which the app/account has explicit authorization.

## Marketplace

Do not assume a general-purpose public API for all consumer Marketplace listings. Meta exposes separate products/programs for particular approved use cases, such as Marketplace partner integrations and Meta Content Library access. Their scope is not equivalent to unrestricted consumer Marketplace search.

Official references:
- https://developers.facebook.com/docs/marketplace/partnerships/itemAPI/
- https://developers.facebook.com/docs/content-library-and-api/content-library-api/guides/fb-marketplace/

## Provider Contract

Core code must depend only on `ProductProvider` / `GroupProvider`. A real connector is responsible for:

- validating its own authorization/scope
- respecting rate limits and retention rules
- returning `AUTH_REQUIRED`, `LIMITED`, `UNAVAILABLE`, etc.
- using webhooks over polling when officially available
- never passing raw access tokens to the browser
