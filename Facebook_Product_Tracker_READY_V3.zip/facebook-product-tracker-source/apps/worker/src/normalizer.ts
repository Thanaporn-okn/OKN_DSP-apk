import { createHash } from 'node:crypto';
import { ProductResultSchema, type ProductResult } from '@tracker/shared';

export function normalizeUrl(input: string): string {
  const url = new URL(input);
  const strip = ['fbclid', 'ref', 'refsrc', '__tn__', 'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content'];
  strip.forEach((key) => url.searchParams.delete(key));
  url.hash = '';
  url.pathname = url.pathname.replace(/\/+$/, '') || '/';
  url.searchParams.sort();
  return url.toString();
}

export function sha256(value: string): string {
  return createHash('sha256').update(value).digest('hex');
}

export function normalizeProduct(input: unknown): ProductResult & { normalizedUrl: string; normalizedUrlHash: string; contentHash: string } {
  const p = ProductResultSchema.parse(input);
  const normalizedUrl = normalizeUrl(p.sourceUrl);
  const content = JSON.stringify({
    title: p.title.trim().replace(/\s+/g, ' '),
    description: p.description?.trim() ?? null,
    price: p.price ?? null,
    sellerName: p.sellerName?.trim() ?? null,
    status: p.status
  });
  return {
    ...p,
    title: p.title.trim().replace(/\s+/g, ' '),
    description: p.description?.trim() || null,
    sellerName: p.sellerName?.trim() || null,
    normalizedUrl,
    normalizedUrlHash: sha256(normalizedUrl),
    contentHash: sha256(content)
  };
}
