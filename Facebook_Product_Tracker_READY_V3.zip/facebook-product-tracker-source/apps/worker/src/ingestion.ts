import { Prisma, prisma } from '@tracker/database';
import type { ProductResult } from '@tracker/shared';
import { normalizeProduct } from './normalizer';
import { EventPublisher } from './event-publisher';
import { evaluateNotificationRules } from './rule-engine';

function toPublicProduct(product: any) {
  return {
    ...product,
    price: product.price == null ? null : Number(product.price),
    originalPrice: product.originalPrice == null ? null : Number(product.originalPrice),
    latitude: product.latitude == null ? null : Number(product.latitude),
    longitude: product.longitude == null ? null : Number(product.longitude)
  };
}

export class IngestionService {
  constructor(private readonly events: EventPublisher) {}

  async ingest(input: ProductResult) {
    const p = normalizeProduct(input);
    const primary = await prisma.product.findFirst({
      where: { OR: [{ source: p.source, externalId: p.externalId }, { normalizedUrlHash: p.normalizedUrlHash }] },
      include: { images: true, priceHistory: { orderBy: { observedAt: 'desc' }, take: 5 } }
    });
    const existing = primary ?? await this.findSecondaryDuplicate(p);
    if (existing) return this.updateExisting(existing.id, p);

    try {
      const created = await prisma.product.create({
        data: {
          externalId: p.externalId,
          source: p.source,
          sourceUrl: p.normalizedUrl,
          normalizedUrlHash: p.normalizedUrlHash,
          title: p.title,
          description: p.description ?? null,
          price: p.price ?? null,
          currency: p.currency,
          originalPrice: p.originalPrice ?? null,
          sellerName: p.sellerName ?? null,
          groupId: p.groupId ?? null,
          groupName: p.groupName ?? null,
          latitude: p.latitude ?? null,
          longitude: p.longitude ?? null,
          locationName: p.locationName ?? null,
          createdAt: p.createdAt ?? null,
          status: p.status,
          rawData: p.rawData as Prisma.InputJsonValue,
          contentHash: p.contentHash,
          images: { create: p.images.map((url, position) => ({ url, position })) },
          ...(p.price != null ? { priceHistory: { create: { price: p.price, currency: p.currency } } } : {})
        },
        include: { images: true, priceHistory: true }
      });
      await this.events.publish('product.created', created.id, { product: toPublicProduct(created) });
      await evaluateNotificationRules(created.id);
      return { action: 'created' as const, product: created };
    } catch (error) {
      if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2002') {
        const raced = await prisma.product.findFirst({ where: { OR: [{ source: p.source, externalId: p.externalId }, { normalizedUrlHash: p.normalizedUrlHash }] } });
        if (raced) return this.updateExisting(raced.id, p);
      }
      throw error;
    }
  }

  private async findSecondaryDuplicate(p: ReturnType<typeof normalizeProduct>) {
    if (!p.sellerName || p.price == null) return null;
    const rows = await prisma.$queryRaw<Array<{ id: string }>>(Prisma.sql`
      SELECT "id"
      FROM "Product"
      WHERE "source" = ${p.source}::"ProductSource"
        AND "sellerName" = ${p.sellerName}
        AND "price" BETWEEN ${p.price * 0.99} AND ${p.price * 1.01}
        AND similarity("title", ${p.title}) >= 0.94
        AND "discoveredAt" > NOW() - INTERVAL '30 days'
      ORDER BY similarity("title", ${p.title}) DESC
      LIMIT 1
    `);
    return rows[0] ?? null;
  }

  private async updateExisting(id: string, p: ReturnType<typeof normalizeProduct>) {
    const previous = await prisma.product.findUniqueOrThrow({ where: { id }, include: { images: true, priceHistory: { orderBy: { observedAt: 'desc' }, take: 5 } } });
    const priceChanged = p.price != null && (previous.price == null || !previous.price.equals(p.price));
    const statusChanged = previous.status !== p.status;
    const contentChanged = previous.contentHash !== p.contentHash;
    if (!priceChanged && !statusChanged && !contentChanged) return { action: 'unchanged' as const, product: previous };

    const updated = await prisma.$transaction(async (tx) => {
      const row = await tx.product.update({
        where: { id },
        data: {
          title: p.title,
          description: p.description ?? null,
          price: p.price ?? null,
          originalPrice: p.originalPrice ?? previous.originalPrice,
          sellerName: p.sellerName ?? null,
          groupId: p.groupId ?? null,
          groupName: p.groupName ?? null,
          latitude: p.latitude ?? null,
          longitude: p.longitude ?? null,
          locationName: p.locationName ?? null,
          createdAt: p.createdAt ?? previous.createdAt,
          status: p.status,
          rawData: p.rawData as Prisma.InputJsonValue,
          contentHash: p.contentHash
        },
        include: { images: true, priceHistory: { orderBy: { observedAt: 'desc' }, take: 5 } }
      });
      if (priceChanged && p.price != null) await tx.productPriceHistory.create({ data: { productId: id, price: p.price, currency: p.currency } });
      for (const [position, url] of p.images.entries()) {
        await tx.productImage.upsert({ where: { productId_url: { productId: id, url } }, update: { position }, create: { productId: id, url, position } });
      }
      return row;
    });

    const publicProduct = toPublicProduct(updated);
    if (priceChanged) await this.events.publish('product.price_changed', id, { product: publicProduct, previousPrice: previous.price == null ? null : Number(previous.price), newPrice: p.price });
    else if (p.status === 'REMOVED' || p.status === 'SOLD') await this.events.publish('product.removed', id, { product: publicProduct });
    else await this.events.publish('product.updated', id, { product: publicProduct });
    await evaluateNotificationRules(id);
    return { action: priceChanged ? 'price_changed' as const : 'updated' as const, product: updated };
  }
}
