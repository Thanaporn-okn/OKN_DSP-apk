import { Prisma, prisma } from '@tracker/database';

export async function evaluateNotificationRules(productId: string) {
  const product = await prisma.product.findUnique({ where: { id: productId } });
  if (!product) return 0;
  const rules = await prisma.notificationRule.findMany({ where: { enabled: true, ...(product.source ? { OR: [{ source: null }, { source: product.source }] } : {}) } });
  let created = 0;
  for (const rule of rules) {
    if (rule.keyword && !`${product.title} ${product.description ?? ''}`.toLowerCase().includes(rule.keyword.toLowerCase())) continue;
    if (rule.maxPrice && (!product.price || product.price.greaterThan(rule.maxPrice))) continue;
    if (rule.latitude && rule.longitude && rule.radiusKm && product.latitude && product.longitude) {
      const rows = await prisma.$queryRaw<Array<{ ok: boolean }>>(Prisma.sql`
        SELECT ST_DWithin(
          ST_SetSRID(ST_MakePoint(${Number(product.longitude)}, ${Number(product.latitude)}),4326)::geography,
          ST_SetSRID(ST_MakePoint(${Number(rule.longitude)}, ${Number(rule.latitude)}),4326)::geography,
          ${Number(rule.radiusKm) * 1000}
        ) AS ok
      `);
      if (!rows[0]?.ok) continue;
    }
    const result = await prisma.notification.createMany({
      data: [{ userId: rule.userId, ruleId: rule.id, productId, channel: rule.channel, status: rule.channel === 'BROWSER' ? 'SENT' : 'PENDING', sentAt: rule.channel === 'BROWSER' ? new Date() : null }],
      skipDuplicates: true
    });
    created += result.count;
  }
  return created;
}
