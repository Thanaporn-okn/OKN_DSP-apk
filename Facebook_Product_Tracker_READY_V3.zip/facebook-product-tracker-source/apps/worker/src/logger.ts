import pino from 'pino';
export const logger = pino({
  base: { service: 'worker' },
  redact: ['*.accessToken', '*.token', '*.password', '*.secret', '*.cookie', '*.authorization']
});
