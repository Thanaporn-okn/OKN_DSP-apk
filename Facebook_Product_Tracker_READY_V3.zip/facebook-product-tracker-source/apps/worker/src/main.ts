import { Queue, Worker, type Job } from 'bullmq';
import IORedis from 'ioredis';
import { prisma } from '@tracker/database';
import { createGroupProvider, createProductProvider } from '@tracker/providers';
import { EventPublisher } from './event-publisher';
import { IngestionService } from './ingestion';
import { logger } from './logger';

const redisUrl = process.env.REDIS_URL ?? 'redis://localhost:6379';
const makeConnection = () => new IORedis(redisUrl, { maxRetriesPerRequest: null });
const queueConnection = makeConnection();

const searchQueue = new Queue('search-watcher', { connection: queueConnection });
const groupQueue = new Queue('group-watcher', { connection: queueConnection });
const updateQueue = new Queue('product-update', { connection: queueConnection });
const cleanupQueue = new Queue('cleanup', { connection: queueConnection });
const retryQueue = new Queue('retry', { connection: queueConnection });

const events = new EventPublisher();
const ingestion = new IngestionService(events);

const rateMax = Number(process.env.COLLECTOR_RATE_LIMIT_MAX ?? 10);
const rateDuration = Number(process.env.COLLECTOR_RATE_LIMIT_DURATION_MS ?? 60_000);

async function runRecorded<T>(job: Job, providerKey: string, refs: { searchPresetId?: string; trackedGroupId?: string }, task: () => Promise<T>): Promise<T> {
  const record = await prisma.collectorJob.create({
    data: {
      queueName: job.queueName,
      providerKey,
      bullJobId: String(job.id ?? ''),
      searchPresetId: refs.searchPresetId,
      trackedGroupId: refs.trackedGroupId,
      status: 'RUNNING',
      attempts: job.attemptsMade + 1,
      payload: (job.data ?? {}) as any,
      startedAt: new Date()
    }
  });
  const start = Date.now();
  try {
    const value = await task();
    await prisma.collectorJob.update({ where: { id: record.id }, data: { status: 'SUCCEEDED', durationMs: Date.now() - start, finishedAt: new Date() } });
    return value;
  } catch (error) {
    const maxAttempts = typeof job.opts.attempts === 'number' ? job.opts.attempts : 1;
    const finalAttempt = job.attemptsMade + 1 >= maxAttempts;
    await prisma.collectorJob.update({
      where: { id: record.id },
      data: {
        status: finalAttempt ? 'DEAD_LETTER' : 'FAILED',
        durationMs: Date.now() - start,
        errorMessage: error instanceof Error ? error.message.slice(0, 2000) : String(error).slice(0, 2000),
        finishedAt: new Date()
      }
    });
    throw error;
  }
}

const searchWorker = new Worker('search-watcher', async (job) => {
  if (job.name === 'schedule-enabled-presets') {
    const presets = await prisma.searchPreset.findMany({ where: { enabled: true }, select: { id: true } });
    const bucket = Math.floor(Date.now() / Number(process.env.SEARCH_WATCH_INTERVAL_MS ?? 300_000));
    for (const preset of presets) {
      await searchQueue.add('collect-search-preset', { searchPresetId: preset.id }, {
        jobId: `search-${preset.id}-${bucket}`,
        attempts: 5,
        backoff: { type: 'exponential', delay: 2000 },
        removeOnComplete: 1000,
        removeOnFail: 5000
      });
    }
    return { enqueued: presets.length };
  }

  const searchPresetId = String(job.data.searchPresetId ?? '');
  const preset = await prisma.searchPreset.findUnique({ where: { id: searchPresetId }, include: { keywords: true } });
  if (!preset || !preset.enabled) return { skipped: true };
  const provider = createProductProvider(preset.providerKey);
  return runRecorded(job, preset.providerKey, { searchPresetId }, async () => {
    const health = await provider.health();
    await prisma.dataSource.updateMany({ where: { key: provider.key }, data: { connectionStatus: health, lastCheckedAt: new Date() } });
    if (health !== 'CONNECTED' && health !== 'LIMITED') throw new Error(`Provider ${provider.key} is ${health}`);
    const found = await provider.search({
      keywords: preset.keywords.map((k) => k.value),
      latitude: Number(preset.latitude),
      longitude: Number(preset.longitude),
      radiusKm: Number(preset.radiusKm),
      minPrice: preset.minPrice == null ? null : Number(preset.minPrice),
      maxPrice: preset.maxPrice == null ? null : Number(preset.maxPrice)
    });
    let created = 0;
    for (const product of found) {
      const result = await ingestion.ingest(product);
      if (result.action === 'created') created++;
    }
    await prisma.searchPreset.update({ where: { id: preset.id }, data: { lastRunAt: new Date() } });
    await events.publish('collector.status', preset.id, { collector: 'marketplace', provider: provider.key, status: health, found: found.length, created });
    return { found: found.length, created };
  });
}, { connection: makeConnection(), concurrency: 3, limiter: { max: rateMax, duration: rateDuration } });

const groupWorker = new Worker('group-watcher', async (job) => {
  if (job.name === 'schedule-enabled-groups') {
    const groups = await prisma.trackedGroup.findMany({ where: { enabled: true }, select: { id: true } });
    const bucket = Math.floor(Date.now() / Number(process.env.GROUP_WATCH_INTERVAL_MS ?? 600_000));
    for (const group of groups) {
      await groupQueue.add('sync-group', { trackedGroupId: group.id }, {
        jobId: `group-${group.id}-${bucket}`,
        attempts: 5,
        backoff: { type: 'exponential', delay: 3000 },
        removeOnComplete: 1000,
        removeOnFail: 5000
      });
    }
    return { enqueued: groups.length };
  }

  const trackedGroupId = String(job.data.trackedGroupId ?? '');
  const group = await prisma.trackedGroup.findUnique({ where: { id: trackedGroupId } });
  if (!group || !group.enabled) return { skipped: true };
  const provider = createGroupProvider(group.providerKey);
  return runRecorded(job, group.providerKey, { trackedGroupId }, async () => {
    const health = await provider.health();
    await prisma.dataSource.updateMany({ where: { key: provider.key }, data: { connectionStatus: health, lastCheckedAt: new Date() } });
    await prisma.trackedGroup.update({ where: { id: group.id }, data: { connectionStatus: health } });
    if (health !== 'CONNECTED' && health !== 'LIMITED') throw new Error(`Group provider ${provider.key} is ${health}`);
    const page = await provider.getPosts(group.externalGroupId, group.lastCursor ?? undefined);
    let created = 0;
    for (const product of page.items) {
      const result = await ingestion.ingest(product);
      if (result.action === 'created') created++;
    }
    await prisma.trackedGroup.update({
      where: { id: group.id },
      data: {
        lastSyncAt: new Date(),
        lastCursor: page.nextCursor,
        postsCount: { increment: page.items.length },
        newPostsCount: { increment: created },
        connectionStatus: health
      }
    });
    await events.publish('group.synced', group.id, { groupId: group.externalGroupId, groupName: group.name, found: page.items.length, created, status: health });
    return { found: page.items.length, created };
  });
}, { connection: makeConnection(), concurrency: 2, limiter: { max: rateMax, duration: rateDuration } });

const updateWorker = new Worker('product-update', async (job) => {
  if (job.name !== 'refresh-active-products') return { skipped: true };
  const rows = await prisma.product.findMany({ where: { source: 'MARKETPLACE', status: 'ACTIVE', externalId: { not: null } }, orderBy: { updatedAt: 'asc' }, take: 100 });
  let updated = 0;
  for (const row of rows) {
    const raw = (row.rawData ?? {}) as Record<string, unknown>;
    const providerKey = typeof raw.provider === 'string' ? raw.provider : null;
    if (!providerKey) continue;
    try {
      const provider = createProductProvider(providerKey);
      const fresh = await provider.getItem(row.externalId!);
      if (!fresh) continue;
      const result = await ingestion.ingest(fresh);
      if (result.action !== 'unchanged') updated++;
    } catch (error) {
      logger.warn({ productId: row.id, error: error instanceof Error ? error.message : String(error) }, 'product refresh skipped');
    }
  }
  return { checked: rows.length, updated };
}, { connection: makeConnection(), concurrency: 1, limiter: { max: Math.max(1, Math.floor(rateMax / 2)), duration: rateDuration } });

const cleanupWorker = new Worker('cleanup', async (job) => {
  if (job.name !== 'cleanup-old-operational-data') return { skipped: true };
  const eventCutoff = new Date(Date.now() - 30 * 86_400_000);
  const jobCutoff = new Date(Date.now() - 30 * 86_400_000);
  const [eventsDeleted, jobsDeleted] = await prisma.$transaction([
    prisma.eventLog.deleteMany({ where: { createdAt: { lt: eventCutoff } } }),
    prisma.collectorJob.deleteMany({ where: { createdAt: { lt: jobCutoff }, status: { in: ['SUCCEEDED', 'FAILED'] } } })
  ]);
  return { eventsDeleted: eventsDeleted.count, jobsDeleted: jobsDeleted.count };
}, { connection: makeConnection(), concurrency: 1 });

const retryWorker = new Worker('retry', async (job) => {
  if (job.name !== 'requeue-dead-letter') return { skipped: true };
  const recordId = String(job.data.collectorJobId ?? '');
  const record = await prisma.collectorJob.findUnique({ where: { id: recordId } });
  if (!record || record.status !== 'DEAD_LETTER') return { skipped: true };
  if (record.searchPresetId) await searchQueue.add('collect-search-preset', { searchPresetId: record.searchPresetId }, { attempts: 5, backoff: { type: 'exponential', delay: 5000 } });
  else if (record.trackedGroupId) await groupQueue.add('sync-group', { trackedGroupId: record.trackedGroupId }, { attempts: 5, backoff: { type: 'exponential', delay: 5000 } });
  return { requeued: true };
}, { connection: makeConnection(), concurrency: 1 });

async function schedule() {
  const searchEvery = Number(process.env.SEARCH_WATCH_INTERVAL_MS ?? 300_000);
  const groupEvery = Number(process.env.GROUP_WATCH_INTERVAL_MS ?? 600_000);
  const updateEvery = Number(process.env.PRODUCT_UPDATE_INTERVAL_MS ?? 1_800_000);
  await searchQueue.add('schedule-enabled-presets', {}, { repeat: { every: searchEvery }, jobId: 'scheduler-search', removeOnComplete: true });
  await groupQueue.add('schedule-enabled-groups', {}, { repeat: { every: groupEvery }, jobId: 'scheduler-groups', removeOnComplete: true });
  await updateQueue.add('refresh-active-products', {}, { repeat: { every: updateEvery }, jobId: 'scheduler-update', removeOnComplete: true });
  await cleanupQueue.add('cleanup-old-operational-data', {}, { repeat: { pattern: '15 3 * * *' }, jobId: 'scheduler-cleanup', removeOnComplete: true });
  await searchQueue.add('schedule-enabled-presets', {}, { jobId: `bootstrap-search-${Date.now()}`, removeOnComplete: true });
  await groupQueue.add('schedule-enabled-groups', {}, { jobId: `bootstrap-groups-${Date.now()}`, removeOnComplete: true });
}

async function shutdown() {
  logger.info('Shutting down worker');
  await Promise.all([searchWorker.close(), groupWorker.close(), updateWorker.close(), cleanupWorker.close(), retryWorker.close()]);
  await Promise.all([searchQueue.close(), groupQueue.close(), updateQueue.close(), cleanupQueue.close(), retryQueue.close()]);
  await events.close();
  await queueConnection.quit();
  await prisma.$disconnect();
}

process.on('SIGTERM', () => void shutdown().finally(() => process.exit(0)));
process.on('SIGINT', () => void shutdown().finally(() => process.exit(0)));

schedule().then(() => logger.info('Worker queues scheduled')).catch((error) => {
  logger.error({ error: error instanceof Error ? error.message : String(error) }, 'Worker bootstrap failed');
  process.exit(1);
});
