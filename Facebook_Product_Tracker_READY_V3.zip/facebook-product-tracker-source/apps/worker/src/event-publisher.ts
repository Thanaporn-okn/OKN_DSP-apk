import { randomUUID } from 'node:crypto';
import IORedis from 'ioredis';
import { prisma } from '@tracker/database';
import type { RealtimeEvent } from '@tracker/shared';

export class EventPublisher {
  private readonly redis = new IORedis(process.env.REDIS_URL ?? 'redis://localhost:6379', { maxRetriesPerRequest: null });

  async publish(type: RealtimeEvent['type'], aggregateId: string | null, payload: Record<string, unknown>) {
    const event: RealtimeEvent = { id: randomUUID(), type, occurredAt: new Date().toISOString(), payload };
    await prisma.eventLog.create({ data: { type, aggregateId, payload: event as any } });
    await this.redis.publish('tracker:events', JSON.stringify(event));
    return event;
  }

  async close() { await this.redis.quit(); }
}
