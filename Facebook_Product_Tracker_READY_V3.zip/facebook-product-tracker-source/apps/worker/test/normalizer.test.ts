import { describe, expect, it } from 'vitest';
import { normalizeProduct, normalizeUrl } from '../src/normalizer';

describe('normalizer', () => {
  it('removes tracking parameters and normalizes trailing slash', () => {
    expect(normalizeUrl('https://example.com/item/123/?fbclid=x&utm_source=y')).toBe('https://example.com/item/123');
  });

  it('normalizes a provider product into a stable URL hash', () => {
    const a = normalizeProduct({ externalId: '1', source: 'MARKETPLACE', sourceUrl: 'https://example.com/a?fbclid=1', title: '  iPhone   16 ', currency: 'THB', images: [], status: 'ACTIVE', rawData: {} });
    const b = normalizeProduct({ externalId: '1', source: 'MARKETPLACE', sourceUrl: 'https://example.com/a?fbclid=2', title: 'iPhone 16', currency: 'THB', images: [], status: 'ACTIVE', rawData: {} });
    expect(a.normalizedUrlHash).toBe(b.normalizedUrlHash);
    expect(a.title).toBe('iPhone 16');
  });
});
