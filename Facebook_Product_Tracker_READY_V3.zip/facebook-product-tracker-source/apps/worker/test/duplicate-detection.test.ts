import { describe, expect, it } from 'vitest';
import { normalizeProduct } from '../src/normalizer';

describe('duplicate identity', () => {
  it('produces the same URL hash after removing Facebook/tracking parameters', () => {
    const base = { externalId: 'x', source: 'MARKETPLACE' as const, title: 'iPhone', currency: 'THB', images: [], status: 'ACTIVE' as const, rawData: {} };
    const a = normalizeProduct({ ...base, sourceUrl: 'https://example.com/item/1?fbclid=abc&utm_source=test' });
    const b = normalizeProduct({ ...base, sourceUrl: 'https://example.com/item/1' });
    expect(a.normalizedUrlHash).toBe(b.normalizedUrlHash);
  });
});
