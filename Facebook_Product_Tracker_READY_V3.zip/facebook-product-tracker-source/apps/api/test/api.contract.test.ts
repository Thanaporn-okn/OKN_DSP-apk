import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { Test } from '@nestjs/testing';
import type { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { AppModule } from '../src/app.module';

let app: INestApplication;

describe('API contract', () => {
  beforeAll(async () => {
    process.env.INTERNAL_API_KEY ||= 'test-internal-key-1234567890';
    process.env.REDIS_URL ||= 'redis://localhost:6379';
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();
    app = moduleRef.createNestApplication();
    await app.init();
  });

  afterAll(async () => { await app.close(); });

  it('exposes health without internal credentials', async () => {
    const response = await request(app.getHttpServer()).get('/health');
    expect(response.status).toBe(200);
    expect(response.body.ok).toBe(true);
  });

  it('protects internal API routes', async () => {
    const response = await request(app.getHttpServer()).get('/api/stats');
    expect(response.status).toBe(401);
  });

  it('returns feed stats with internal key', async () => {
    const response = await request(app.getHttpServer()).get('/api/stats').set('x-internal-key', process.env.INTERNAL_API_KEY!);
    expect(response.status).toBe(200);
    expect(response.body.total).toBeGreaterThanOrEqual(20);
  });
});
