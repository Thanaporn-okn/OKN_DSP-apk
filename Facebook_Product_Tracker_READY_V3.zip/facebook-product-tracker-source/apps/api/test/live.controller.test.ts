import { describe, expect, it } from 'vitest';
import { Subject, firstValueFrom, filter } from 'rxjs';
import type { RealtimeEvent } from '@tracker/shared';
import { LiveController } from '../src/live/live.controller';

class FakeHub {
  stream = new Subject<RealtimeEvent>();
}

describe('realtime SSE controller', () => {
  it('forwards product.created events to the SSE observable', async () => {
    const hub = new FakeHub();
    const controller = new LiveController(hub as any);
    const promise = firstValueFrom(controller.live().pipe(filter((event) => event.type === 'product.created')));
    hub.stream.next({ id: 'e1', type: 'product.created', occurredAt: new Date().toISOString(), payload: { product: { id: 'p1' } } });
    const event = await promise;
    expect(event.type).toBe('product.created');
    expect((event.data as RealtimeEvent).payload).toEqual({ product: { id: 'p1' } });
  });
});
