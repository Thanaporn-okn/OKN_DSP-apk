import { Controller, Get } from '@nestjs/common';
import { prisma } from '@tracker/database';
import IORedis from 'ioredis';

@Controller()
export class SystemController {
  @Get('health')
  health() { return { ok: true, service: 'api', at: new Date().toISOString() }; }

  @Get('api/system/status')
  async status() {
    let database: 'ONLINE' | 'ERROR' = 'ONLINE';
    let queue: 'RUNNING' | 'ERROR' = 'RUNNING';
    try { await prisma.$queryRaw`SELECT 1`; } catch { database = 'ERROR'; }
    const redis = new IORedis(process.env.REDIS_URL ?? 'redis://localhost:6379', { lazyConnect: true, maxRetriesPerRequest: 1 });
    try { await redis.connect(); await redis.ping(); } catch { queue = 'ERROR'; } finally { redis.disconnect(); }
    const sources = await prisma.dataSource.findMany({ select: { key: true, name: true, enabled: true, connectionStatus: true, lastCheckedAt: true } });
    return { live: database === 'ONLINE' && queue === 'RUNNING', database, queue, sources };
  }
}
