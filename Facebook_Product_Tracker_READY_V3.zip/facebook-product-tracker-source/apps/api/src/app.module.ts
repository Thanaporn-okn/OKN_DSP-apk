import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { APP_GUARD } from '@nestjs/core';
import { ThrottlerGuard, ThrottlerModule } from '@nestjs/throttler';
import { InternalKeyMiddleware } from './common/internal-key.middleware';
import { ProductsModule } from './products/products.module';
import { PresetsModule } from './presets/presets.module';
import { GroupsModule } from './groups/groups.module';
import { SystemModule } from './system/system.module';
import { LiveModule } from './live/live.module';
import { AuthModule } from './auth/auth.module';
import { QueueModule } from './queue/queue.module';

@Module({
  imports: [ThrottlerModule.forRoot([{ ttl: 60_000, limit: 120 }]), QueueModule, ProductsModule, PresetsModule, GroupsModule, SystemModule, LiveModule, AuthModule],
  providers: [{ provide: APP_GUARD, useClass: ThrottlerGuard }]
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer.apply(InternalKeyMiddleware).forRoutes('*');
  }
}
