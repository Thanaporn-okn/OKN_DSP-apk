import { Body, Controller, Delete, Get, Headers, NotFoundException, Param, Patch, Post, Query } from '@nestjs/common';
import { GroupsService } from './groups.service';
import { ProductsService } from '../products/products.service';
import { requireUserId } from '../common/user';

@Controller('api/groups')
export class GroupsController {
  constructor(private readonly groups: GroupsService, private readonly products: ProductsService) {}
  @Get() list(@Headers('x-user-id') user?: string) { return this.groups.list(requireUserId(user)); }
  @Post() create(@Headers('x-user-id') user: string | undefined, @Body() body: unknown) { return this.groups.create(requireUserId(user), body); }
  @Patch(':id') update(@Headers('x-user-id') user: string | undefined, @Param('id') id: string, @Body() body: unknown) { return this.groups.update(requireUserId(user), id, body); }
  @Delete(':id') remove(@Headers('x-user-id') user: string | undefined, @Param('id') id: string) { return this.groups.remove(requireUserId(user), id); }
  @Post(':id/sync') sync(@Headers('x-user-id') user: string | undefined, @Param('id') id: string) { return this.groups.sync(requireUserId(user), id); }
  @Get(':id/posts') async posts(@Headers('x-user-id') user: string | undefined, @Param('id') id: string, @Query() query: Record<string, unknown>) {
    const group = (await this.groups.list(requireUserId(user))).find((g) => g.id === id);
    if (!group) throw new NotFoundException('Tracked group not found');
    return this.products.list({ ...query, source: 'FACEBOOK_GROUP', groupId: group.externalGroupId });
  }
}
