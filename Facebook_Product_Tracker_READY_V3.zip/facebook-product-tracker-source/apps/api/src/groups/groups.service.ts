import { Injectable, NotFoundException } from '@nestjs/common';
import { prisma } from '@tracker/database';
import { TrackedGroupInputSchema } from '@tracker/shared';
import { QueueService } from '../queue/queue.service';

@Injectable()
export class GroupsService {
  constructor(private readonly queue: QueueService) {}

  list(userId: string) {
    return prisma.trackedGroup.findMany({ where: { userId }, orderBy: { createdAt: 'desc' } });
  }

  async create(userId: string, body: unknown) {
    const input = TrackedGroupInputSchema.parse(body);
    return prisma.trackedGroup.create({
      data: {
        userId,
        externalGroupId: input.externalGroupId,
        name: input.name,
        providerKey: input.providerKey,
        enabled: input.enabled,
        connectionStatus: input.providerKey === 'mock-group' ? 'CONNECTED' : 'UNAVAILABLE'
      }
    });
  }

  async update(userId: string, id: string, body: unknown) {
    const existing = await prisma.trackedGroup.findFirst({ where: { id, userId } });
    if (!existing) throw new NotFoundException('Tracked group not found');
    const input = TrackedGroupInputSchema.partial().parse(body);
    return prisma.trackedGroup.update({ where: { id }, data: input });
  }

  async remove(userId: string, id: string) {
    const result = await prisma.trackedGroup.deleteMany({ where: { id, userId } });
    if (!result.count) throw new NotFoundException('Tracked group not found');
    return { ok: true };
  }

  async sync(userId: string, id: string) {
    const group = await prisma.trackedGroup.findFirst({ where: { id, userId } });
    if (!group) throw new NotFoundException('Tracked group not found');
    const job = await this.queue.enqueueGroupSync(id);
    return { queued: true, jobId: job.id };
  }
}
