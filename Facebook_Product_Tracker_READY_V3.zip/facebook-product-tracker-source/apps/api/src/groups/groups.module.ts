import { Module } from '@nestjs/common';
import { ProductsModule } from '../products/products.module';
import { GroupsController } from './groups.controller';
import { GroupsService } from './groups.service';
@Module({ imports: [ProductsModule], controllers: [GroupsController], providers: [GroupsService] })
export class GroupsModule {}
