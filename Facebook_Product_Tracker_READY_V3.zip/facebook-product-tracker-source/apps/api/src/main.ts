import 'reflect-metadata';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { Logger } from './common/logger';
import { z } from 'zod';

const EnvSchema = z.object({
  API_PORT: z.coerce.number().default(4000),
  DATABASE_URL: z.string().min(1),
  REDIS_URL: z.string().min(1),
  INTERNAL_API_KEY: z.string().min(16)
});

async function bootstrap() {
  const env = EnvSchema.parse(process.env);
  const app = await NestFactory.create(AppModule, { bufferLogs: true });
  app.useLogger(new Logger('api'));
  app.enableShutdownHooks();
  app.enableCors({ origin: false });
  await app.listen(env.API_PORT, '0.0.0.0');
  console.log(JSON.stringify({ timestamp: new Date().toISOString(), level: 'INFO', service: 'api', message: `Listening on ${env.API_PORT}` }));
}

bootstrap().catch((error) => {
  console.error(JSON.stringify({ timestamp: new Date().toISOString(), level: 'ERROR', service: 'api', message: 'Bootstrap failed', error: error instanceof Error ? error.message : String(error) }));
  process.exit(1);
});
