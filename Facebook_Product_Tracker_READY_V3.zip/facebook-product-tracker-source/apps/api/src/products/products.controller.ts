import { Controller, Get, Param, Query } from '@nestjs/common';
import { ProductsService } from './products.service';

@Controller('api')
export class ProductsController {
  constructor(private readonly products: ProductsService) {}

  @Get('products')
  list(@Query() query: Record<string, unknown>) { return this.products.list(query); }

  @Get('products/:id')
  get(@Param('id') id: string) { return this.products.getById(id); }

  @Get('marketplace')
  marketplace(@Query() query: Record<string, unknown>) { return this.products.list({ ...query, source: 'MARKETPLACE' }); }

  @Get('stats')
  stats() { return this.products.stats(); }
}
