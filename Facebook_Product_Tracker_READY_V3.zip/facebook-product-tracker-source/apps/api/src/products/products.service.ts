import { Injectable, NotFoundException } from '@nestjs/common';
import { Prisma, prisma } from '@tracker/database';
import { ProductSearchSchema, decodeCursor, encodeCursor, type ProductSearch } from '@tracker/shared';

function serializeProduct(product: any, distanceKm?: number | null) {
  return {
    ...product,
    price: product.price == null ? null : Number(product.price),
    originalPrice: product.originalPrice == null ? null : Number(product.originalPrice),
    latitude: product.latitude == null ? null : Number(product.latitude),
    longitude: product.longitude == null ? null : Number(product.longitude),
    distanceKm: distanceKm == null ? null : Number(distanceKm),
    priceHistory: product.priceHistory?.map((h: any) => ({ ...h, price: Number(h.price) })) ?? []
  };
}

@Injectable()
export class ProductsService {
  async list(raw: Record<string, unknown>) {
    const q = ProductSearchSchema.parse(raw) as ProductSearch;
    if (q.latitude != null && q.longitude != null && q.radiusKm != null) return this.listGeo(q);

    const cursor = decodeCursor(q.cursor);
    const and: Prisma.ProductWhereInput[] = [];
    if (q.keyword) and.push({ OR: [{ title: { contains: q.keyword, mode: 'insensitive' } }, { description: { contains: q.keyword, mode: 'insensitive' } }] });
    if (q.createdAfter) and.push({ createdAt: { gte: q.createdAfter } });
    if (q.sort === 'price_asc' || q.sort === 'price_desc') and.push({ price: { not: null } });
    if (cursor?.sort === q.sort) {
      if (q.sort === 'newest' && typeof cursor.value === 'string') {
        const date = new Date(cursor.value);
        and.push({ OR: [{ discoveredAt: { lt: date } }, { discoveredAt: date, id: { lt: cursor.id } }] });
      } else if (q.sort === 'price_asc' && typeof cursor.value === 'number') {
        and.push({ OR: [{ price: { gt: cursor.value } }, { price: cursor.value, id: { lt: cursor.id } }] });
      } else if (q.sort === 'price_desc' && typeof cursor.value === 'number') {
        and.push({ OR: [{ price: { lt: cursor.value } }, { price: cursor.value, id: { lt: cursor.id } }] });
      }
    }
    const where: Prisma.ProductWhereInput = {
      ...(q.source ? { source: q.source } : {}),
      ...(q.groupId ? { groupId: q.groupId } : {}),
      ...(q.province ? { locationName: { contains: q.province, mode: 'insensitive' } } : {}),
      ...(q.minPrice != null || q.maxPrice != null ? { price: { ...(q.minPrice != null ? { gte: q.minPrice } : {}), ...(q.maxPrice != null ? { lte: q.maxPrice } : {}) } } : {}),
      ...(and.length ? { AND: and } : {})
    };
    const orderBy = q.sort === 'price_asc' ? [{ price: 'asc' as const }, { id: 'desc' as const }]
      : q.sort === 'price_desc' ? [{ price: 'desc' as const }, { id: 'desc' as const }]
      : [{ discoveredAt: 'desc' as const }, { id: 'desc' as const }];
    const rows = await prisma.product.findMany({
      where,
      take: q.limit + 1,
      orderBy,
      include: { images: { orderBy: { position: 'asc' } }, priceHistory: { take: 5, orderBy: { observedAt: 'desc' } } }
    });
    const hasMore = rows.length > q.limit;
    const pageRows = rows.slice(0, q.limit);
    const items = pageRows.map((p) => serializeProduct(p));
    const last = pageRows.at(-1);
    const nextCursor = hasMore && last ? encodeCursor({
      sort: q.sort === 'nearest' ? 'newest' : q.sort,
      id: last.id,
      value: q.sort === 'price_asc' || q.sort === 'price_desc' ? Number(last.price) : last.discoveredAt.toISOString()
    }) : null;
    return { items, nextCursor };
  }

  private async listGeo(q: ProductSearch) {
    const point = Prisma.sql`ST_SetSRID(ST_MakePoint(${q.longitude!}, ${q.latitude!}), 4326)::geography`;
    const distance = Prisma.sql`ST_Distance("location", ${point}) / 1000.0`;
    const conditions: Prisma.Sql[] = [Prisma.sql`"location" IS NOT NULL`, Prisma.sql`ST_DWithin("location", ${point}, ${q.radiusKm! * 1000})`];
    if (q.source) conditions.push(Prisma.sql`"source" = ${q.source}::"ProductSource"`);
    if (q.groupId) conditions.push(Prisma.sql`"groupId" = ${q.groupId}`);
    if (q.keyword) conditions.push(Prisma.sql`("title" ILIKE ${'%' + q.keyword + '%'} OR "description" ILIKE ${'%' + q.keyword + '%'})`);
    if (q.province) conditions.push(Prisma.sql`"locationName" ILIKE ${'%' + q.province + '%'}`);
    if (q.minPrice != null) conditions.push(Prisma.sql`"price" >= ${q.minPrice}`);
    if (q.maxPrice != null) conditions.push(Prisma.sql`"price" <= ${q.maxPrice}`);
    if (q.createdAfter) conditions.push(Prisma.sql`"createdAt" >= ${q.createdAfter}`);
    if (q.sort === 'price_asc' || q.sort === 'price_desc') conditions.push(Prisma.sql`"price" IS NOT NULL`);
    const cursor = decodeCursor(q.cursor);
    if (cursor?.sort === q.sort) {
      if (q.sort === 'newest' && typeof cursor.value === 'string') {
        const date = new Date(cursor.value);
        conditions.push(Prisma.sql`("discoveredAt" < ${date} OR ("discoveredAt" = ${date} AND "id" < ${cursor.id}))`);
      } else if (q.sort === 'price_asc' && typeof cursor.value === 'number') {
        conditions.push(Prisma.sql`("price" > ${cursor.value} OR ("price" = ${cursor.value} AND "id" < ${cursor.id}))`);
      } else if (q.sort === 'price_desc' && typeof cursor.value === 'number') {
        conditions.push(Prisma.sql`("price" < ${cursor.value} OR ("price" = ${cursor.value} AND "id" < ${cursor.id}))`);
      } else if (q.sort === 'nearest' && typeof cursor.value === 'number') {
        conditions.push(Prisma.sql`(${distance} > ${cursor.value} OR (${distance} = ${cursor.value} AND "id" < ${cursor.id}))`);
      }
    }
    const order = q.sort === 'nearest' ? Prisma.sql`${distance} ASC, "id" DESC`
      : q.sort === 'price_asc' ? Prisma.sql`"price" ASC, "id" DESC`
      : q.sort === 'price_desc' ? Prisma.sql`"price" DESC, "id" DESC`
      : Prisma.sql`"discoveredAt" DESC, "id" DESC`;
    const ids = await prisma.$queryRaw<Array<{ id: string; distance_km: number; price: Prisma.Decimal | null; discoveredAt: Date }>>(Prisma.sql`
      SELECT "id", ${distance} AS distance_km, "price", "discoveredAt"
      FROM "Product"
      WHERE ${Prisma.join(conditions, ' AND ')}
      ORDER BY ${order}
      LIMIT ${q.limit + 1}
    `);
    const selected = ids.slice(0, q.limit);
    const products = await prisma.product.findMany({
      where: { id: { in: selected.map((x) => x.id) } },
      include: { images: { orderBy: { position: 'asc' } }, priceHistory: { take: 5, orderBy: { observedAt: 'desc' } } }
    });
    const byId = new Map(products.map((p) => [p.id, p]));
    const items = selected.flatMap((r) => { const product = byId.get(r.id); return product ? [serializeProduct(product, r.distance_km)] : []; });
    const last = selected.at(-1);
    const nextCursor = ids.length > q.limit && last ? encodeCursor({
      sort: q.sort,
      id: last.id,
      value: q.sort === 'nearest' ? Number(last.distance_km) : q.sort === 'price_asc' || q.sort === 'price_desc' ? Number(last.price) : last.discoveredAt.toISOString()
    }) : null;
    return { items, nextCursor };
  }

  async getById(id: string) {
    const product = await prisma.product.findUnique({ where: { id }, include: { images: { orderBy: { position: 'asc' } }, priceHistory: { orderBy: { observedAt: 'desc' } } } });
    if (!product) throw new NotFoundException('Product not found');
    return serializeProduct(product);
  }

  async stats() {
    const start = new Date(); start.setHours(0, 0, 0, 0);
    const hourAgo = new Date(Date.now() - 3600_000);
    const [today, lastHour, total, marketplace, groups] = await Promise.all([
      prisma.product.count({ where: { discoveredAt: { gte: start } } }),
      prisma.product.count({ where: { discoveredAt: { gte: hourAgo } } }),
      prisma.product.count(),
      prisma.product.count({ where: { source: 'MARKETPLACE' } }),
      prisma.product.count({ where: { source: 'FACEBOOK_GROUP' } })
    ]);
    return { today, lastHour, total, marketplace, groups };
  }
}
