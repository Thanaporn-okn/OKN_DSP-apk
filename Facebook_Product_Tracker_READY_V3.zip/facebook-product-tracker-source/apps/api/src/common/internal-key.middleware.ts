import { Injectable, NestMiddleware, UnauthorizedException } from '@nestjs/common';
import type { NextFunction, Request, Response } from 'express';
import { timingSafeEqual } from 'node:crypto';

@Injectable()
export class InternalKeyMiddleware implements NestMiddleware {
  use(req: Request, _res: Response, next: NextFunction) {
    if (req.path === '/health') return next();
    const provided = req.header('x-internal-key') ?? '';
    const expected = process.env.INTERNAL_API_KEY ?? '';
    const a = Buffer.from(provided);
    const b = Buffer.from(expected);
    if (!expected || a.length !== b.length || !timingSafeEqual(a, b)) throw new UnauthorizedException('Invalid internal API key');
    next();
  }
}
