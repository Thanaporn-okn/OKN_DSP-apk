import { BadRequestException } from '@nestjs/common';

export function requireUserId(value?: string): string {
  if (!value) throw new BadRequestException('x-user-id is required');
  return value;
}
