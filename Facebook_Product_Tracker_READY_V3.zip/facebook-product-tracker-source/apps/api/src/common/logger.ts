import { LoggerService } from '@nestjs/common';
import pino from 'pino';

export class Logger implements LoggerService {
  private readonly logger = pino({ base: { service: this.service }, redact: ['req.headers.authorization', '*.accessToken', '*.password', '*.secret', '*.cookie'] });
  constructor(private readonly service: string) {}
  log(message: unknown, context?: string) { this.logger.info({ context }, String(message)); }
  error(message: unknown, trace?: string, context?: string) { this.logger.error({ context, trace }, String(message)); }
  warn(message: unknown, context?: string) { this.logger.warn({ context }, String(message)); }
  debug(message: unknown, context?: string) { this.logger.debug({ context }, String(message)); }
  verbose(message: unknown, context?: string) { this.logger.trace({ context }, String(message)); }
}
