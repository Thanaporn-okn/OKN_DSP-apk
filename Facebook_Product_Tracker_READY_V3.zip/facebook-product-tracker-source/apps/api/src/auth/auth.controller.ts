import { Body, Controller, UnauthorizedException } from '@nestjs/common';
import { Post } from '@nestjs/common';
import { prisma } from '@tracker/database';
import bcrypt from 'bcryptjs';
import { z } from 'zod';

const LoginSchema = z.object({ email: z.string().email(), password: z.string().min(8).max(200) });

@Controller('api/auth')
export class AuthController {
  @Post('login')
  async login(@Body() body: unknown) {
    const input = LoginSchema.parse(body);
    const user = await prisma.user.findUnique({ where: { email: input.email } });
    if (!user?.passwordHash || !(await bcrypt.compare(input.password, user.passwordHash))) throw new UnauthorizedException('Invalid credentials');
    return { id: user.id, email: user.email, name: user.name, role: user.role };
  }
}
