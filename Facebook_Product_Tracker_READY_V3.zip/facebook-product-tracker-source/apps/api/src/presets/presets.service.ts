import { Injectable, NotFoundException } from '@nestjs/common';
import { prisma } from '@tracker/database';
import { SearchPresetInputSchema } from '@tracker/shared';
import { QueueService } from '../queue/queue.service';

@Injectable()
export class PresetsService {
  constructor(private readonly queue: QueueService) {}

  list(userId: string) {
    return prisma.searchPreset.findMany({ where: { userId }, include: { keywords: true }, orderBy: { createdAt: 'desc' } });
  }

  async create(userId: string, body: unknown) {
    const input = SearchPresetInputSchema.parse(body);
    const preset = await prisma.searchPreset.create({
      data: {
        userId,
        name: input.name,
        locationName: input.locationName ?? null,
        latitude: input.latitude,
        longitude: input.longitude,
        radiusKm: input.radiusKm,
        minPrice: input.minPrice ?? null,
        maxPrice: input.maxPrice ?? null,
        enabled: input.enabled,
        providerKey: 'mock-marketplace',
        keywords: { create: input.keywords.map((value) => ({ value, normalized: value.trim().toLowerCase() })) }
      },
      include: { keywords: true }
    });
    if (preset.enabled) await this.queue.enqueueSearchPreset(preset.id);
    return preset;
  }

  async update(userId: string, id: string, body: unknown) {
    const existing = await prisma.searchPreset.findFirst({ where: { id, userId } });
    if (!existing) throw new NotFoundException('Search preset not found');
    const input = SearchPresetInputSchema.partial().parse(body);
    const preset = await prisma.$transaction(async (tx) => {
      if (input.keywords) {
        await tx.searchKeyword.deleteMany({ where: { searchPresetId: id } });
        await tx.searchKeyword.createMany({ data: input.keywords.map((value) => ({ searchPresetId: id, value, normalized: value.trim().toLowerCase() })) });
      }
      return tx.searchPreset.update({
        where: { id },
        data: {
          ...(input.name !== undefined ? { name: input.name } : {}),
          ...(input.locationName !== undefined ? { locationName: input.locationName } : {}),
          ...(input.latitude !== undefined ? { latitude: input.latitude } : {}),
          ...(input.longitude !== undefined ? { longitude: input.longitude } : {}),
          ...(input.radiusKm !== undefined ? { radiusKm: input.radiusKm } : {}),
          ...(input.minPrice !== undefined ? { minPrice: input.minPrice } : {}),
          ...(input.maxPrice !== undefined ? { maxPrice: input.maxPrice } : {}),
          ...(input.enabled !== undefined ? { enabled: input.enabled } : {})
        },
        include: { keywords: true }
      });
    });
    if (preset.enabled) await this.queue.enqueueSearchPreset(preset.id);
    return preset;
  }

  async remove(userId: string, id: string) {
    const result = await prisma.searchPreset.deleteMany({ where: { id, userId } });
    if (!result.count) throw new NotFoundException('Search preset not found');
    return { ok: true };
  }

  async sync(userId: string, id: string) {
    const preset = await prisma.searchPreset.findFirst({ where: { id, userId } });
    if (!preset) throw new NotFoundException('Search preset not found');
    const job = await this.queue.enqueueSearchPreset(id);
    return { queued: true, jobId: job.id };
  }
}
