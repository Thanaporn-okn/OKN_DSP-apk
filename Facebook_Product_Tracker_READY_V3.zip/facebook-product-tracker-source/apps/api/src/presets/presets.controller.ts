import { Body, Controller, Delete, Get, Headers, Param, Patch, Post } from '@nestjs/common';
import { PresetsService } from './presets.service';
import { requireUserId } from '../common/user';

@Controller('api/search-presets')
export class PresetsController {
  constructor(private readonly presets: PresetsService) {}
  @Get() list(@Headers('x-user-id') user?: string) { return this.presets.list(requireUserId(user)); }
  @Post() create(@Headers('x-user-id') user: string | undefined, @Body() body: unknown) { return this.presets.create(requireUserId(user), body); }
  @Patch(':id') update(@Headers('x-user-id') user: string | undefined, @Param('id') id: string, @Body() body: unknown) { return this.presets.update(requireUserId(user), id, body); }
  @Delete(':id') remove(@Headers('x-user-id') user: string | undefined, @Param('id') id: string) { return this.presets.remove(requireUserId(user), id); }
  @Post(':id/sync') sync(@Headers('x-user-id') user: string | undefined, @Param('id') id: string) { return this.presets.sync(requireUserId(user), id); }
}
