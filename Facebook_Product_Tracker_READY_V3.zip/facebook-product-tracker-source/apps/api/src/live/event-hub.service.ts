import { Injectable, OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import IORedis from 'ioredis';
import { Subject } from 'rxjs';
import type { RealtimeEvent } from '@tracker/shared';

@Injectable()
export class EventHubService implements OnModuleInit, OnModuleDestroy {
  readonly stream = new Subject<RealtimeEvent>();
  private readonly redis = new IORedis(process.env.REDIS_URL ?? 'redis://localhost:6379', { maxRetriesPerRequest: null });

  async onModuleInit() {
    await this.redis.subscribe('tracker:events');
    this.redis.on('message', (_channel, payload) => {
      try { this.stream.next(JSON.parse(payload) as RealtimeEvent); } catch { /* ignore malformed events */ }
    });
  }

  async onModuleDestroy() {
    this.stream.complete();
    await this.redis.quit();
  }
}
