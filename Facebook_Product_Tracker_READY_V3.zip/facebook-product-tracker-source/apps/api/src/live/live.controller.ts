import { Controller, MessageEvent, Sse } from '@nestjs/common';
import { Observable, map, merge, interval } from 'rxjs';
import { EventHubService } from './event-hub.service';

@Controller('api/live')
export class LiveController {
  constructor(private readonly hub: EventHubService) {}

  @Sse()
  live(): Observable<MessageEvent> {
    const events$ = this.hub.stream.pipe(map((event) => ({ type: event.type, data: event }) as MessageEvent));
    const heartbeat$ = interval(20_000).pipe(map(() => ({ type: 'heartbeat', data: { ts: new Date().toISOString() } }) as MessageEvent));
    return merge(events$, heartbeat$);
  }
}
