import { Module } from '@nestjs/common';
import { EventHubService } from './event-hub.service';
import { LiveController } from './live.controller';
@Module({ controllers: [LiveController], providers: [EventHubService] })
export class LiveModule {}
