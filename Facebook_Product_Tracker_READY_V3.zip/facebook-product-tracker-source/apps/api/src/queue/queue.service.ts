import { Injectable, OnModuleDestroy } from '@nestjs/common';
import { Queue } from 'bullmq';
import IORedis from 'ioredis';

@Injectable()
export class QueueService implements OnModuleDestroy {
  private readonly connection = new IORedis(process.env.REDIS_URL ?? 'redis://localhost:6379', { maxRetriesPerRequest: null });
  private readonly searchQueue = new Queue('search-watcher', { connection: this.connection });
  private readonly groupQueue = new Queue('group-watcher', { connection: this.connection });

  async enqueueSearchPreset(searchPresetId: string) {
    return this.searchQueue.add('collect-search-preset', { searchPresetId }, { attempts: 5, backoff: { type: 'exponential', delay: 2000 }, removeOnComplete: 1000, removeOnFail: 5000 });
  }

  async enqueueGroupSync(trackedGroupId: string) {
    return this.groupQueue.add('sync-group', { trackedGroupId }, { attempts: 5, backoff: { type: 'exponential', delay: 3000 }, removeOnComplete: 1000, removeOnFail: 5000 });
  }

  async onModuleDestroy() {
    await Promise.all([this.searchQueue.close(), this.groupQueue.close(), this.connection.quit()]);
  }
}
