import { NextRequest, NextResponse } from 'next/server';

export function middleware(request: NextRequest) {
  if (process.env.APP_DEMO_MODE === 'true') return NextResponse.next();
  const path = request.nextUrl.pathname;
  if (path.startsWith('/login') || path.startsWith('/api/auth')) return NextResponse.next();
  if (!request.cookies.get('tracker_session')) return NextResponse.redirect(new URL('/login', request.url));
  return NextResponse.next();
}

export const config = { matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'] };
