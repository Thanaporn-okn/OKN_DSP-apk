import type maplibregl from 'maplibre-gl';

export interface MapProviderAdapter {
  style(): maplibregl.StyleSpecification;
  attribution: string;
}

export class OpenStreetMapRasterAdapter implements MapProviderAdapter {
  attribution = '© OpenStreetMap contributors';
  style(): maplibregl.StyleSpecification {
    return {
      version: 8,
      sources: { osm: { type: 'raster', tiles: ['https://tile.openstreetmap.org/{z}/{x}/{y}.png'], tileSize: 256, attribution: this.attribution } },
      layers: [{ id: 'osm', type: 'raster', source: 'osm' }]
    };
  }
}

export const mapProvider: MapProviderAdapter = new OpenStreetMapRasterAdapter();
