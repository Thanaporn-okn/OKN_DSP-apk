import { SignJWT, jwtVerify } from 'jose';

export type SessionUser = { id: string; email: string; name?: string | null; role: string };

function key() {
  const secret = process.env.AUTH_SECRET;
  if (!secret || secret.length < 32) throw new Error('AUTH_SECRET must be at least 32 characters');
  return new TextEncoder().encode(secret);
}

export async function signSession(user: SessionUser) {
  return new SignJWT({ email: user.email, name: user.name ?? null, role: user.role })
    .setProtectedHeader({ alg: 'HS256' })
    .setSubject(user.id)
    .setIssuedAt()
    .setExpirationTime('12h')
    .sign(key());
}

export async function verifySession(token?: string | null): Promise<SessionUser | null> {
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, key());
    if (!payload.sub || typeof payload.email !== 'string' || typeof payload.role !== 'string') return null;
    return { id: payload.sub, email: payload.email, name: typeof payload.name === 'string' ? payload.name : null, role: payload.role };
  } catch {
    return null;
  }
}
