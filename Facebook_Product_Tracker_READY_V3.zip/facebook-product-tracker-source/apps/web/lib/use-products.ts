'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { api } from './api';
import type { ProductPage, ProductView } from './types';

function distanceKm(lat1: number, lng1: number, lat2: number, lng2: number) {
  const r = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLng / 2) ** 2;
  return 2 * r * Math.asin(Math.sqrt(a));
}

function matches(product: ProductView, endpoint: 'products' | 'marketplace', key: string) {
  const q = new URLSearchParams(key);
  if (endpoint === 'marketplace' && product.source !== 'MARKETPLACE') return false;
  const source = q.get('source');
  if (source && product.source !== source) return false;
  const groupId = q.get('groupId');
  if (groupId && product.groupId !== groupId) return false;
  const keyword = q.get('keyword')?.toLowerCase();
  if (keyword && !`${product.title} ${product.description ?? ''}`.toLowerCase().includes(keyword)) return false;
  const province = q.get('province')?.toLowerCase();
  if (province && !(product.locationName ?? '').toLowerCase().includes(province)) return false;
  const min = q.get('minPrice'); if (min && (product.price == null || product.price < Number(min))) return false;
  const max = q.get('maxPrice'); if (max && (product.price == null || product.price > Number(max))) return false;
  const createdAfter = q.get('createdAfter'); if (createdAfter && (!product.createdAt || new Date(product.createdAt) < new Date(createdAfter))) return false;
  const lat = q.get('latitude'), lng = q.get('longitude'), radius = q.get('radiusKm');
  if (lat && lng && radius) {
    if (product.latitude == null || product.longitude == null) return false;
    if (distanceKm(Number(lat), Number(lng), product.latitude, product.longitude) > Number(radius)) return false;
  }
  return true;
}

export function useProducts(endpoint: 'products' | 'marketplace', params: URLSearchParams, realtime = false) {
  const [items, setItems] = useState<ProductView[]>([]);
  const [cursor, setCursor] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const key = params.toString();
  const eventSourceRef = useRef<EventSource | null>(null);

  const load = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const result = await api<ProductPage>(`${endpoint}?${key}`);
      setItems(result.items); setCursor(result.nextCursor);
    } catch (e) { setError(e instanceof Error ? e.message : String(e)); }
    finally { setLoading(false); }
  }, [endpoint, key]);

  const loadMore = useCallback(async () => {
    if (!cursor || loadingMore) return;
    setLoadingMore(true);
    try {
      const q = new URLSearchParams(key); q.set('cursor', cursor);
      const result = await api<ProductPage>(`${endpoint}?${q.toString()}`);
      setItems((prev) => [...prev, ...result.items.filter((p) => !prev.some((x) => x.id === p.id))]);
      setCursor(result.nextCursor);
    } finally { setLoadingMore(false); }
  }, [cursor, endpoint, key, loadingMore]);

  useEffect(() => { void load(); }, [load]);

  useEffect(() => {
    if (!realtime) return;
    const source = new EventSource('/api/live');
    eventSourceRef.current = source;
    const types = ['product.created', 'product.updated', 'product.price_changed', 'product.removed'];
    const handler = (event: MessageEvent) => {
      try {
        const envelope = JSON.parse(event.data) as { payload?: { product?: ProductView } };
        const product = envelope.payload?.product;
        if (!product) return;
        const keep = matches(product, endpoint, key);
        setItems((prev) => {
          const exists = prev.some((x) => x.id === product.id);
          if (!keep) return exists ? prev.filter((x) => x.id !== product.id) : prev;
          if (exists) return prev.map((x) => x.id === product.id ? { ...x, ...product } : x);
          return [product, ...prev].slice(0, 300);
        });
      } catch { /* ignore malformed event */ }
    };
    types.forEach((type) => source.addEventListener(type, handler as EventListener));
    return () => { types.forEach((type) => source.removeEventListener(type, handler as EventListener)); source.close(); };
  }, [endpoint, key, realtime]);

  return { items, cursor, loading, loadingMore, error, reload: load, loadMore };
}
