import type { NextRequest } from 'next/server';
import { verifySession, type SessionUser } from './session';

export async function currentUserFromRequest(request: NextRequest): Promise<SessionUser | null> {
  if (process.env.APP_DEMO_MODE === 'true') {
    return { id: process.env.DEMO_USER_ID ?? 'demo_user', email: process.env.DEMO_ADMIN_EMAIL ?? 'demo@example.com', name: 'Demo Admin', role: 'ADMIN' };
  }
  return verifySession(request.cookies.get('tracker_session')?.value);
}

export function internalHeaders(userId?: string) {
  return {
    'x-internal-key': process.env.INTERNAL_API_KEY ?? '',
    ...(userId ? { 'x-user-id': userId } : {})
  };
}
