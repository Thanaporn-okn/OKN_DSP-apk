export type ProductView = {
  id: string;
  externalId?: string | null;
  source: 'MARKETPLACE' | 'FACEBOOK_GROUP';
  sourceUrl: string;
  title: string;
  description?: string | null;
  price?: number | null;
  originalPrice?: number | null;
  currency: string;
  sellerName?: string | null;
  groupId?: string | null;
  groupName?: string | null;
  latitude?: number | null;
  longitude?: number | null;
  locationName?: string | null;
  createdAt?: string | null;
  discoveredAt: string;
  updatedAt: string;
  status: string;
  distanceKm?: number | null;
  images: Array<{ id: string; url: string; position: number }>;
  priceHistory?: Array<{ id: string; price: number; observedAt: string }>;
};

export type ProductPage = { items: ProductView[]; nextCursor: string | null };
export type Stats = { today: number; lastHour: number; total: number; marketplace: number; groups: number };
export type SystemStatus = {
  live: boolean;
  database: 'ONLINE' | 'ERROR';
  queue: 'RUNNING' | 'ERROR';
  sources: Array<{ key: string; name: string; enabled: boolean; connectionStatus: string; lastCheckedAt?: string | null }>;
};
