'use client';

import Image from 'next/image';
import { ExternalLink, MapPin, Tag, UserRound } from 'lucide-react';
import { formatTHB, timeAgo } from '../lib/api';
import type { ProductView } from '../lib/types';

export function ProductCard({ product, view = 'grid' }: { product: ProductView; view?: 'grid' | 'list' }) {
  const priceDrop = product.originalPrice != null && product.price != null && product.originalPrice > product.price;
  const image = product.images?.[0]?.url ?? 'https://picsum.photos/seed/fallback/900/700';
  const isList = view === 'list';
  return (
    <article className={`group overflow-hidden rounded-2xl border border-slate-800 bg-slate-900/70 transition hover:border-slate-700 hover:bg-slate-900 ${isList ? 'sm:flex' : ''}`}>
      <div className={`relative bg-slate-950 ${isList ? 'sm:w-64 sm:flex-none' : 'aspect-[4/3]'}`}>
        <Image src={image} alt={product.title} fill className="object-cover transition duration-300 group-hover:scale-[1.02]" sizes={isList ? '256px' : '(max-width:768px) 100vw, 33vw'} />
        <div className="absolute left-2 top-2 flex flex-wrap gap-1.5">
          <span className={`rounded-full px-2 py-1 text-[10px] font-bold ${product.source === 'MARKETPLACE' ? 'bg-blue-600/90 text-white' : 'bg-violet-600/90 text-white'}`}>{product.source === 'MARKETPLACE' ? 'MARKETPLACE' : 'GROUP'}</span>
          {Date.now() - new Date(product.discoveredAt).getTime() < 60 * 60_000 && <span className="rounded-full bg-emerald-500 px-2 py-1 text-[10px] font-bold text-slate-950">NEW</span>}
          {priceDrop && <span className="rounded-full bg-rose-500 px-2 py-1 text-[10px] font-bold text-white">PRICE DROP</span>}
        </div>
      </div>
      <div className="flex min-w-0 flex-1 flex-col p-4">
        <h3 className="line-clamp-2 min-h-[2.7rem] text-sm font-semibold leading-5 text-slate-100">{product.title}</h3>
        <div className="mt-2 flex flex-wrap items-baseline gap-2">
          <span className="text-xl font-bold text-white">{formatTHB(product.price)}</span>
          {priceDrop && <span className="text-sm text-slate-500 line-through">{formatTHB(product.originalPrice)}</span>}
        </div>
        <div className="mt-3 space-y-1.5 text-xs text-slate-400">
          <div className="flex items-center gap-2"><MapPin className="h-3.5 w-3.5" /><span className="truncate">{product.locationName ?? 'ไม่ระบุตำแหน่ง'}{product.distanceKm != null ? ` · ${product.distanceKm.toFixed(1)} km` : ''}</span></div>
          {product.sellerName && <div className="flex items-center gap-2"><UserRound className="h-3.5 w-3.5" /><span className="truncate">{product.sellerName}</span></div>}
          {product.groupName && <div className="flex items-center gap-2"><Tag className="h-3.5 w-3.5" /><span className="truncate">{product.groupName}</span></div>}
        </div>
        <div className="mt-4 flex items-end justify-between gap-3 border-t border-slate-800 pt-3 text-[11px] text-slate-500">
          <div><div>โพสต์ {timeAgo(product.createdAt)}</div><div>พบ {timeAgo(product.discoveredAt)}</div></div>
          <a href={product.sourceUrl} target="_blank" rel="noreferrer noopener" className="inline-flex items-center gap-1.5 rounded-xl bg-slate-800 px-3 py-2 text-xs font-medium text-slate-200 hover:bg-slate-700">{product.sourceUrl.includes('facebook.com') ? 'Open Facebook' : 'เปิด Mock Source'}<ExternalLink className="h-3.5 w-3.5" /></a>
        </div>
      </div>
    </article>
  );
}
