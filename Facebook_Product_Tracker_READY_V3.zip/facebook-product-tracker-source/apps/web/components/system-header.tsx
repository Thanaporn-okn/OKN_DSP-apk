'use client';

import { useEffect, useState } from 'react';
import { Bell, Search, Settings } from 'lucide-react';
import { api } from '../lib/api';
import type { SystemStatus } from '../lib/types';

export function SystemHeader() {
  const [status, setStatus] = useState<SystemStatus | null>(null);
  useEffect(() => {
    let mounted = true;
    const load = () => api<SystemStatus>('system/status').then((value) => mounted && setStatus(value)).catch(() => mounted && setStatus(null));
    load();
    const id = setInterval(load, 30_000);
    return () => { mounted = false; clearInterval(id); };
  }, []);
  const marketplace = status?.sources.find((s) => s.key === 'mock-marketplace' && s.enabled) ?? status?.sources.find((s) => s.key.includes('marketplace'));
  const groups = status?.sources.find((s) => s.key === 'mock-group' && s.enabled) ?? status?.sources.find((s) => s.key.includes('group'));
  return (
    <header className="sticky top-0 z-40 border-b border-slate-800/80 bg-[#070b12]/90 backdrop-blur-xl">
      <div className="flex h-16 items-center gap-3 px-4 sm:px-6 lg:px-8">
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2"><h1 className="truncate text-sm font-semibold text-white sm:text-base">Facebook Marketplace & Groups Product Tracker</h1><span className={`inline-flex items-center gap-1 rounded-full px-2 py-1 text-[10px] font-semibold ${status?.live ? 'bg-emerald-500/10 text-emerald-300' : 'bg-rose-500/10 text-rose-300'}`}><span className={`h-1.5 w-1.5 rounded-full ${status?.live ? 'bg-emerald-400 animate-pulse' : 'bg-rose-400'}`} />{status?.live ? 'LIVE' : 'OFFLINE'}</span></div>
          <p className="mt-0.5 hidden text-xs text-slate-500 sm:block">Marketplace {marketplace?.connectionStatus ?? '...'} · Groups {groups?.connectionStatus ?? '...'} · DB {status?.database ?? '...'} · Queue {status?.queue ?? '...'}</p>
        </div>
        <button className="rounded-xl border border-slate-800 bg-slate-900 p-2.5 text-slate-400 hover:text-white" aria-label="Search"><Search className="h-4 w-4" /></button>
        <button className="rounded-xl border border-slate-800 bg-slate-900 p-2.5 text-slate-400 hover:text-white" aria-label="Notifications"><Bell className="h-4 w-4" /></button>
        <button className="rounded-xl border border-slate-800 bg-slate-900 p-2.5 text-slate-400 hover:text-white" aria-label="Settings"><Settings className="h-4 w-4" /></button>
      </div>
    </header>
  );
}
