'use client';

import { MapPin, Save, Search } from 'lucide-react';
import { useState } from 'react';
import { LocationMap } from './location-map';

export type MarketplaceSearchState = {
  keyword: string; locationName: string; latitude: number; longitude: number; radiusKm: number; minPrice: string; maxPrice: string; sort: string;
};

export function MarketplaceSearchPanel({ value, onChange, onSearch, onSave }: { value: MarketplaceSearchState; onChange: (value: MarketplaceSearchState) => void; onSearch: () => void; onSave: () => void }) {
  const [showMap, setShowMap] = useState(false);
  const set = <K extends keyof MarketplaceSearchState>(key: K, v: MarketplaceSearchState[K]) => onChange({ ...value, [key]: v });
  return <section className="rounded-2xl border border-slate-800 bg-slate-900/70 p-4">
    <div className="mb-4 flex flex-wrap items-center justify-between gap-3"><div><h3 className="font-semibold text-white">Search Control Panel</h3><p className="text-xs text-slate-500">ค้นหาจาก Provider ที่รองรับตำแหน่งและ radius</p></div><button onClick={() => setShowMap((v) => !v)} className="inline-flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-slate-300"><MapPin className="h-4 w-4" />{showMap ? 'ซ่อนแผนที่' : 'เลือกบนแผนที่'}</button></div>
    <div className="grid gap-2 md:grid-cols-2 xl:grid-cols-4">
      <input value={value.keyword} onChange={(e) => set('keyword', e.target.value)} placeholder="Keyword เช่น iPhone, MacBook" className="rounded-xl border border-slate-800 bg-slate-950 px-3 py-2.5 text-sm outline-none focus:border-blue-500" />
      <input value={value.locationName} onChange={(e) => set('locationName', e.target.value)} placeholder="จังหวัด / เมือง" className="rounded-xl border border-slate-800 bg-slate-950 px-3 py-2.5 text-sm outline-none focus:border-blue-500" />
      <div className="grid grid-cols-2 gap-2"><input type="number" step="0.000001" value={value.latitude} onChange={(e) => set('latitude', Number(e.target.value))} placeholder="Latitude" className="rounded-xl border border-slate-800 bg-slate-950 px-3 py-2.5 text-sm" /><input type="number" step="0.000001" value={value.longitude} onChange={(e) => set('longitude', Number(e.target.value))} placeholder="Longitude" className="rounded-xl border border-slate-800 bg-slate-950 px-3 py-2.5 text-sm" /></div>
      <select value={value.radiusKm} onChange={(e) => set('radiusKm', Number(e.target.value))} className="rounded-xl border border-slate-800 bg-slate-950 px-3 py-2.5 text-sm"><option value={5}>5 km</option><option value={10}>10 km</option><option value={20}>20 km</option><option value={50}>50 km</option><option value={100}>100 km</option><option value={200}>200 km</option></select>
      <input value={value.minPrice} onChange={(e) => set('minPrice', e.target.value)} inputMode="numeric" placeholder="ราคาต่ำสุด" className="rounded-xl border border-slate-800 bg-slate-950 px-3 py-2.5 text-sm" />
      <input value={value.maxPrice} onChange={(e) => set('maxPrice', e.target.value)} inputMode="numeric" placeholder="ราคาสูงสุด" className="rounded-xl border border-slate-800 bg-slate-950 px-3 py-2.5 text-sm" />
      <select value={value.sort} onChange={(e) => set('sort', e.target.value)} className="rounded-xl border border-slate-800 bg-slate-950 px-3 py-2.5 text-sm"><option value="newest">Newest</option><option value="price_asc">Price Low → High</option><option value="price_desc">Price High → Low</option><option value="nearest">Nearest</option></select>
      <div className="flex gap-2"><button onClick={onSearch} className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-blue-500"><Search className="h-4 w-4" />ค้นหา</button><button onClick={onSave} className="inline-flex items-center gap-2 rounded-xl border border-slate-700 px-4 py-2.5 text-sm text-slate-200 hover:bg-slate-800"><Save className="h-4 w-4" />Save</button></div>
    </div>
    {showMap && <div className="mt-4"><LocationMap latitude={value.latitude} longitude={value.longitude} onChange={(latitude, longitude) => onChange({ ...value, latitude, longitude })} /><p className="mt-2 text-xs text-slate-500">คลิกบนแผนที่เพื่อเปลี่ยน Latitude / Longitude</p></div>}
  </section>;
}
