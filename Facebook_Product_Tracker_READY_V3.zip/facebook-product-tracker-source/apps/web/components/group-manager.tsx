'use client';

import { Eye, Plus, RefreshCcw, Trash2, ToggleLeft, ToggleRight } from 'lucide-react';
import { useEffect, useState } from 'react';
import { api } from '../lib/api';

type Group = {
  id: string; externalGroupId: string; name: string; providerKey: string; enabled: boolean; connectionStatus: string;
  lastSyncAt?: string | null; postsCount: number; newPostsCount: number;
};

export function GroupManager({ onSelect }: { onSelect: (externalGroupId: string | null) => void }) {
  const [groups, setGroups] = useState<Group[]>([]);
  const [name, setName] = useState('กลุ่มซื้อขายใหม่');
  const [externalGroupId, setExternalGroupId] = useState('demo-group-3');
  const [providerKey, setProviderKey] = useState('mock-group');
  const [message, setMessage] = useState<string | null>(null);

  const load = () => api<Group[]>('groups').then(setGroups).catch((e) => setMessage(e instanceof Error ? e.message : String(e)));
  useEffect(() => { void load(); }, []);

  async function addGroup() {
    await api('groups', { method: 'POST', body: JSON.stringify({ name, externalGroupId, providerKey, enabled: true }) });
    setMessage('เพิ่ม Group แล้ว'); await load();
  }

  async function patch(group: Group, enabled: boolean) {
    await api(`groups/${group.id}`, { method: 'PATCH', body: JSON.stringify({ enabled }) });
    await load();
  }

  async function sync(group: Group) {
    await api(`groups/${group.id}/sync`, { method: 'POST' });
    setMessage(`ส่ง ${group.name} เข้า Queue แล้ว`);
  }

  async function remove(group: Group) {
    await api(`groups/${group.id}`, { method: 'DELETE' });
    setMessage(`ลบ ${group.name} แล้ว`); onSelect(null); await load();
  }

  return <section className="space-y-3 rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
    <div className="flex flex-wrap items-end gap-2">
      <div className="min-w-[180px] flex-1"><label className="mb-1 block text-xs text-slate-500">Group Name</label><input value={name} onChange={(e) => setName(e.target.value)} className="w-full rounded-xl border border-slate-800 bg-slate-950 px-3 py-2.5 text-sm" /></div>
      <div className="min-w-[160px] flex-1"><label className="mb-1 block text-xs text-slate-500">Group ID / provider identifier</label><input value={externalGroupId} onChange={(e) => setExternalGroupId(e.target.value)} className="w-full rounded-xl border border-slate-800 bg-slate-950 px-3 py-2.5 text-sm" /></div>
      <div><label className="mb-1 block text-xs text-slate-500">Provider</label><select value={providerKey} onChange={(e) => setProviderKey(e.target.value)} className="rounded-xl border border-slate-800 bg-slate-950 px-3 py-2.5 text-sm"><option value="mock-group">Mock Group</option><option value="authorized-group">Authorized source</option></select></div>
      <button onClick={addGroup} className="inline-flex items-center gap-2 rounded-xl bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white"><Plus className="h-4 w-4" />Add Group</button>
    </div>
    <p className="text-xs text-amber-300/80">Legacy Facebook Groups API ถูกยกเลิกแล้ว; `authorized-group` จะรายงาน Unavailable จนกว่าจะเสียบ Data Source ที่ได้รับอนุญาตจริง</p>
    {message && <div className="rounded-xl border border-slate-800 bg-slate-950/70 p-2 text-xs text-slate-300">{message}</div>}
    <div className="overflow-x-auto"><table className="w-full min-w-[860px] text-left text-sm"><thead className="text-xs uppercase text-slate-600"><tr><th className="p-2">Group</th><th className="p-2">ID</th><th className="p-2">Status</th><th className="p-2">Last Sync</th><th className="p-2">Posts</th><th className="p-2">New</th><th className="p-2">Actions</th></tr></thead><tbody>{groups.map((group) => <tr key={group.id} className="border-t border-slate-800"><td className="p-2 font-medium text-slate-200"><button onClick={() => onSelect(group.externalGroupId)} className="hover:text-blue-300">{group.name}</button></td><td className="p-2 font-mono text-xs text-slate-500">{group.externalGroupId}</td><td className="p-2"><span className={`rounded-full px-2 py-1 text-[10px] font-semibold ${group.connectionStatus === 'CONNECTED' ? 'bg-emerald-500/10 text-emerald-300' : 'bg-amber-500/10 text-amber-300'}`}>{group.connectionStatus}</span></td><td className="p-2 text-xs text-slate-500">{group.lastSyncAt ? new Date(group.lastSyncAt).toLocaleString('th-TH') : '-'}</td><td className="p-2 text-slate-300">{group.postsCount}</td><td className="p-2 text-emerald-300">{group.newPostsCount}</td><td className="p-2"><div className="flex gap-1"><button onClick={() => patch(group, !group.enabled)} className="rounded-lg border border-slate-800 p-2 text-slate-400" title={group.enabled ? 'Disable' : 'Enable'}>{group.enabled ? <ToggleRight className="h-4 w-4 text-emerald-400" /> : <ToggleLeft className="h-4 w-4" />}</button><button onClick={() => onSelect(group.externalGroupId)} className="rounded-lg border border-slate-800 p-2 text-slate-400" title="View Posts"><Eye className="h-4 w-4" /></button><button onClick={() => sync(group)} className="rounded-lg border border-slate-800 p-2 text-slate-400" title="Sync"><RefreshCcw className="h-4 w-4" /></button><button onClick={() => remove(group)} className="rounded-lg border border-slate-800 p-2 text-rose-400" title="Delete"><Trash2 className="h-4 w-4" /></button></div></td></tr>)}</tbody></table></div>
  </section>;
}
