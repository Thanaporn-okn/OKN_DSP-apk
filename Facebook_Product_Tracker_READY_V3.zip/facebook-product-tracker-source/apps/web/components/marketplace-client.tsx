'use client';

import { Grid2X2, List, RefreshCcw } from 'lucide-react';
import { useEffect, useMemo, useRef, useState } from 'react';
import { api } from '../lib/api';
import { useProducts } from '../lib/use-products';
import { LoadingGrid } from './loading-grid';
import { MarketplaceSearchPanel, type MarketplaceSearchState } from './marketplace-search-panel';
import { ProductCard } from './product-card';

type Preset = { id: string; name: string; enabled: boolean; keywords: Array<{ value: string }>; locationName?: string | null; radiusKm: string; lastRunAt?: string | null };

const initial: MarketplaceSearchState = {
  keyword: 'iPhone', locationName: 'กรุงเทพมหานคร', latitude: Number(process.env.NEXT_PUBLIC_DEFAULT_LAT ?? 13.7563), longitude: Number(process.env.NEXT_PUBLIC_DEFAULT_LNG ?? 100.5018), radiusKm: 50, minPrice: '', maxPrice: '', sort: 'newest'
};

export function MarketplaceClient() {
  const [draft, setDraft] = useState(initial);
  const [applied, setApplied] = useState(initial);
  const [view, setView] = useState<'grid' | 'list'>('grid');
  const [presets, setPresets] = useState<Preset[]>([]);
  const [notice, setNotice] = useState<string | null>(null);
  const sentinel = useRef<HTMLDivElement | null>(null);
  const params = useMemo(() => {
    const q = new URLSearchParams({ keyword: applied.keyword, latitude: String(applied.latitude), longitude: String(applied.longitude), radiusKm: String(applied.radiusKm), sort: applied.sort, limit: '30' });
    if (applied.minPrice) q.set('minPrice', applied.minPrice);
    if (applied.maxPrice) q.set('maxPrice', applied.maxPrice);
    if (applied.locationName) q.set('province', applied.locationName);
    return q;
  }, [applied]);
  const feed = useProducts('marketplace', params, true);

  const loadPresets = () => api<Preset[]>('search-presets').then(setPresets).catch(() => undefined);
  useEffect(() => { void loadPresets(); }, []);
  useEffect(() => {
    if (!sentinel.current) return;
    const observer = new IntersectionObserver((entries) => { if (entries[0]?.isIntersecting) void feed.loadMore(); }, { rootMargin: '300px' });
    observer.observe(sentinel.current); return () => observer.disconnect();
  }, [feed.loadMore]);

  async function savePreset() {
    try {
      await api('search-presets', { method: 'POST', body: JSON.stringify({ name: `${draft.keyword} ${draft.locationName} ${draft.radiusKm}km`, keywords: draft.keyword.split(',').map((x) => x.trim()).filter(Boolean), locationName: draft.locationName, latitude: draft.latitude, longitude: draft.longitude, radiusKm: draft.radiusKm, minPrice: draft.minPrice ? Number(draft.minPrice) : null, maxPrice: draft.maxPrice ? Number(draft.maxPrice) : null, enabled: true }) });
      setNotice('บันทึก Search Preset แล้วและส่งเข้า Queue สำหรับรอบตรวจถัดไป'); void loadPresets();
    } catch (e) { setNotice(e instanceof Error ? e.message : String(e)); }
  }

  return <div className="space-y-4">
    <div><p className="text-xs font-semibold uppercase tracking-[.2em] text-blue-400">Marketplace</p><h2 className="mt-1 text-2xl font-bold text-white sm:text-3xl">ค้นหาและติดตามสินค้า</h2><p className="mt-1 text-sm text-slate-500">Demo ใช้ Mock Provider; Provider จริงต้องเป็นแหล่งข้อมูลที่ Meta อนุญาตให้แอปเข้าถึง</p></div>
    <MarketplaceSearchPanel value={draft} onChange={setDraft} onSearch={() => setApplied(draft)} onSave={savePreset} />
    {notice && <div className="rounded-xl border border-blue-900 bg-blue-950/30 p-3 text-sm text-blue-200">{notice}</div>}
    {presets.length > 0 && <div className="flex gap-2 overflow-x-auto pb-1">{presets.map((preset) => <button key={preset.id} onClick={() => api(`search-presets/${preset.id}/sync`, { method: 'POST' }).then(() => setNotice(`ส่ง ${preset.name} เข้า Queue แล้ว`))} className="whitespace-nowrap rounded-full border border-slate-800 bg-slate-900 px-3 py-1.5 text-xs text-slate-300 hover:border-blue-700"><RefreshCcw className="mr-1.5 inline h-3 w-3" />{preset.name}</button>)}</div>}
    <div className="flex justify-end gap-1"><button onClick={() => setView('grid')} className={`rounded-lg p-2 ${view === 'grid' ? 'bg-blue-600 text-white' : 'bg-slate-900 text-slate-500'}`}><Grid2X2 className="h-4 w-4" /></button><button onClick={() => setView('list')} className={`rounded-lg p-2 ${view === 'list' ? 'bg-blue-600 text-white' : 'bg-slate-900 text-slate-500'}`}><List className="h-4 w-4" /></button></div>
    {feed.loading ? <LoadingGrid /> : <div className={view === 'grid' ? 'grid gap-3 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4' : 'space-y-3'}>{feed.items.map((product) => <ProductCard key={product.id} product={product} view={view} />)}</div>}
    <div ref={sentinel} className="h-10 text-center text-xs text-slate-600">{feed.loadingMore ? 'กำลังโหลดเพิ่ม…' : feed.cursor ? 'เลื่อนเพื่อโหลดเพิ่ม' : 'ครบแล้ว'}</div>
  </div>;
}
