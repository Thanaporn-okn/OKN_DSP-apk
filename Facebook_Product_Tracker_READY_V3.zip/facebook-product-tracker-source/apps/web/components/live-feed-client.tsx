'use client';
import { useEffect, useMemo, useRef, useState } from 'react';
import { Radio } from 'lucide-react';
import { FilterBar, type FeedFilters } from './filter-bar';
import { ProductCard } from './product-card';
import { LoadingGrid } from './loading-grid';
import { StatsStrip } from './stats-strip';
import { useProducts } from '../lib/use-products';

export function LiveFeedClient() {
  const [filters, setFilters] = useState<FeedFilters>({ source: '', keyword: '', minPrice: '', maxPrice: '', province: '', sort: 'newest', radiusKm: '', postedWithin: '' });
  const params = useMemo(() => {
    const q = new URLSearchParams({ limit: '30', sort: filters.sort });
    if (filters.source) q.set('source', filters.source);
    if (filters.keyword) q.set('keyword', filters.keyword);
    if (filters.minPrice) q.set('minPrice', filters.minPrice);
    if (filters.maxPrice) q.set('maxPrice', filters.maxPrice);
    if (filters.province) q.set('province', filters.province);
    if (filters.radiusKm) { q.set('latitude', String(Number(process.env.NEXT_PUBLIC_DEFAULT_LAT ?? 13.7563))); q.set('longitude', String(Number(process.env.NEXT_PUBLIC_DEFAULT_LNG ?? 100.5018))); q.set('radiusKm', filters.radiusKm); }
    if (filters.postedWithin) q.set('createdAfter', new Date(Date.now() - Number(filters.postedWithin) * 3600_000).toISOString());
    if (filters.sort === 'nearest' && !filters.radiusKm) { q.set('latitude', String(Number(process.env.NEXT_PUBLIC_DEFAULT_LAT ?? 13.7563))); q.set('longitude', String(Number(process.env.NEXT_PUBLIC_DEFAULT_LNG ?? 100.5018))); q.set('radiusKm', '200'); }
    return q;
  }, [filters]);
  const feed = useProducts('products', params, true);
  const sentinel = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    if (!sentinel.current) return;
    const observer = new IntersectionObserver((entries) => { if (entries[0]?.isIntersecting) void feed.loadMore(); }, { rootMargin: '300px' });
    observer.observe(sentinel.current); return () => observer.disconnect();
  }, [feed.loadMore]);

  return <div className="space-y-4">
    <div className="flex items-end justify-between gap-3"><div><div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[.2em] text-emerald-400"><Radio className="h-4 w-4 animate-pulse" />Live feed</div><h2 className="mt-1 text-2xl font-bold tracking-tight text-white sm:text-3xl">สินค้าล่าสุด</h2><p className="mt-1 text-sm text-slate-500">รายการใหม่จะถูกแทรกด้านบนผ่าน Server-Sent Events โดยไม่ reload</p></div></div>
    <StatsStrip />
    <FilterBar value={filters} onChange={setFilters} />
    {feed.error && <div className="rounded-xl border border-rose-900 bg-rose-950/30 p-3 text-sm text-rose-300">{feed.error}</div>}
    {feed.loading ? <LoadingGrid /> : <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4">{feed.items.map((product) => <ProductCard key={product.id} product={product} />)}</div>}
    <div ref={sentinel} className="h-10 text-center text-xs text-slate-600">{feed.loadingMore ? 'กำลังโหลดเพิ่ม…' : feed.cursor ? 'เลื่อนเพื่อโหลดเพิ่ม' : 'ครบแล้ว'}</div>
  </div>;
}
