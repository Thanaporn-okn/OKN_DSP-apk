'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Activity, LayoutGrid, MapPinned, Search, Settings, UsersRound } from 'lucide-react';
import { SystemHeader } from './system-header';

const nav = [
  { href: '/', label: 'Live Feed', icon: Activity },
  { href: '/marketplace', label: 'Marketplace', icon: MapPinned },
  { href: '/groups', label: 'Groups', icon: UsersRound }
];

export function DashboardShell({ children }: { children: React.ReactNode }) {
  const path = usePathname();
  if (path === '/login') return <>{children}</>;
  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[240px_1fr]">
      <aside className="hidden border-r border-slate-800/80 bg-slate-950/80 p-4 backdrop-blur lg:sticky lg:top-0 lg:block lg:h-screen">
        <div className="mb-7 flex items-center gap-3 px-2 pt-2">
          <div className="grid h-10 w-10 place-items-center rounded-2xl bg-blue-600 shadow-glow"><LayoutGrid className="h-5 w-5" /></div>
          <div><p className="font-semibold text-white">FB Product Tracker</p><p className="text-xs text-slate-500">Permitted sources only</p></div>
        </div>
        <nav className="space-y-1">
          {nav.map(({ href, label, icon: Icon }) => {
            const active = href === '/' ? path === '/' : path.startsWith(href);
            return <Link key={href} href={href} className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition ${active ? 'bg-blue-600/15 text-blue-300 ring-1 ring-blue-500/20' : 'text-slate-400 hover:bg-slate-900 hover:text-white'}`}><Icon className="h-4 w-4" />{label}</Link>;
          })}
        </nav>
        <div className="absolute bottom-5 left-4 right-4 rounded-2xl border border-slate-800 bg-slate-900/70 p-3 text-xs text-slate-500">
          <p className="mb-1 font-medium text-slate-300">Connector policy</p>
          Core app ไม่ใช้ scraping bypass, session theft หรือ CAPTCHA bypass
        </div>
      </aside>
      <div className="min-w-0">
        <SystemHeader />
        <main className="mx-auto max-w-[1600px] px-3 pb-24 pt-4 sm:px-5 lg:px-7 lg:pb-8">{children}</main>
      </div>
      <nav className="fixed bottom-0 left-0 right-0 z-50 grid grid-cols-3 border-t border-slate-800 bg-slate-950/95 px-2 py-2 backdrop-blur lg:hidden">
        {nav.map(({ href, label, icon: Icon }) => {
          const active = href === '/' ? path === '/' : path.startsWith(href);
          return <Link key={href} href={href} className={`flex flex-col items-center gap-1 rounded-xl py-2 text-[11px] ${active ? 'text-blue-300' : 'text-slate-500'}`}><Icon className="h-5 w-5" />{label}</Link>;
        })}
      </nav>
    </div>
  );
}
