'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { GroupManager } from './group-manager';
import { ProductCard } from './product-card';
import { LoadingGrid } from './loading-grid';
import { useProducts } from '../lib/use-products';

export function GroupsClient() {
  const [groupId, setGroupId] = useState<string | null>(null);
  const [keyword, setKeyword] = useState('');
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');
  const [sort, setSort] = useState('newest');
  const [postedWithin, setPostedWithin] = useState('');
  const sentinel = useRef<HTMLDivElement | null>(null);
  const params = useMemo(() => {
    const q = new URLSearchParams({ source: 'FACEBOOK_GROUP', limit: '30', sort });
    if (groupId) q.set('groupId', groupId);
    if (keyword) q.set('keyword', keyword);
    if (minPrice) q.set('minPrice', minPrice);
    if (maxPrice) q.set('maxPrice', maxPrice);
    if (postedWithin) q.set('createdAfter', new Date(Date.now() - Number(postedWithin) * 3600_000).toISOString());
    return q;
  }, [groupId, keyword, minPrice, maxPrice, sort, postedWithin]);
  const feed = useProducts('products', params, true);
  useEffect(() => {
    if (!sentinel.current) return;
    const observer = new IntersectionObserver((entries) => { if (entries[0]?.isIntersecting) void feed.loadMore(); }, { rootMargin: '300px' });
    observer.observe(sentinel.current); return () => observer.disconnect();
  }, [feed.loadMore]);

  return <div className="space-y-4">
    <div><p className="text-xs font-semibold uppercase tracking-[.2em] text-violet-400">Facebook Groups</p><h2 className="mt-1 text-2xl font-bold text-white sm:text-3xl">Group Tracking</h2><p className="mt-1 text-sm text-slate-500">จัดการเฉพาะ Group/Data Source ที่บัญชีและแอปได้รับอนุญาต</p></div>
    <GroupManager onSelect={setGroupId} />
    <section className="rounded-2xl border border-slate-800 bg-slate-900/60 p-3"><div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-6"><button onClick={() => setGroupId(null)} className={`rounded-xl border px-3 py-2.5 text-sm ${groupId ? 'border-slate-800 bg-slate-950 text-slate-400' : 'border-violet-700 bg-violet-600/10 text-violet-300'}`}>ทุก Group</button><input value={keyword} onChange={(e) => setKeyword(e.target.value)} placeholder="Keyword" className="rounded-xl border border-slate-800 bg-slate-950 px-3 py-2.5 text-sm" /><input value={minPrice} onChange={(e) => setMinPrice(e.target.value)} placeholder="ราคาต่ำสุด" className="rounded-xl border border-slate-800 bg-slate-950 px-3 py-2.5 text-sm" /><input value={maxPrice} onChange={(e) => setMaxPrice(e.target.value)} placeholder="ราคาสูงสุด" className="rounded-xl border border-slate-800 bg-slate-950 px-3 py-2.5 text-sm" /><select value={postedWithin} onChange={(e) => setPostedWithin(e.target.value)} className="rounded-xl border border-slate-800 bg-slate-950 px-3 py-2.5 text-sm"><option value="">ทุกวันที่</option><option value="24">24 ชั่วโมง</option><option value="168">7 วัน</option></select><select value={sort} onChange={(e) => setSort(e.target.value)} className="rounded-xl border border-slate-800 bg-slate-950 px-3 py-2.5 text-sm"><option value="newest">Newest First</option><option value="price_asc">Price Low → High</option><option value="price_desc">Price High → Low</option></select></div></section>
    {feed.loading ? <LoadingGrid /> : <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4">{feed.items.map((product) => <ProductCard key={product.id} product={product} />)}</div>}
    <div ref={sentinel} className="h-10 text-center text-xs text-slate-600">{feed.loadingMore ? 'กำลังโหลดเพิ่ม…' : feed.cursor ? 'เลื่อนเพื่อโหลดเพิ่ม' : 'ครบแล้ว'}</div>
  </div>;
}
