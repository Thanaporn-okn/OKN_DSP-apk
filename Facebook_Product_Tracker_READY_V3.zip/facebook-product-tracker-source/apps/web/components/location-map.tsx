'use client';

import { useEffect, useRef } from 'react';
import maplibregl from 'maplibre-gl';
import { mapProvider } from '../lib/map-provider';

export function LocationMap({ latitude, longitude, onChange }: { latitude: number; longitude: number; onChange: (lat: number, lng: number) => void }) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<maplibregl.Map | null>(null);
  const markerRef = useRef<maplibregl.Marker | null>(null);

  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;
    const map = new maplibregl.Map({ container: containerRef.current, style: mapProvider.style(), center: [longitude, latitude], zoom: Number(process.env.NEXT_PUBLIC_DEFAULT_ZOOM ?? 10) });
    map.addControl(new maplibregl.NavigationControl(), 'top-right');
    const marker = new maplibregl.Marker({ color: '#3b82f6' }).setLngLat([longitude, latitude]).addTo(map);
    map.on('click', (event) => onChange(Number(event.lngLat.lat.toFixed(6)), Number(event.lngLat.lng.toFixed(6))));
    mapRef.current = map; markerRef.current = marker;
    return () => { marker.remove(); map.remove(); mapRef.current = null; markerRef.current = null; };
  }, []);

  useEffect(() => {
    markerRef.current?.setLngLat([longitude, latitude]);
  }, [latitude, longitude]);

  return <div ref={containerRef} className="h-72 w-full overflow-hidden rounded-2xl border border-slate-700" />;
}
