export function LoadingGrid() {
  return <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4">{Array.from({ length: 8 }).map((_, i) => <div key={i} className="overflow-hidden rounded-2xl border border-slate-800 bg-slate-900/50"><div className="skeleton aspect-[4/3]" /><div className="space-y-3 p-4"><div className="skeleton h-4 rounded" /><div className="skeleton h-7 w-2/3 rounded" /><div className="skeleton h-3 w-1/2 rounded" /></div></div>)}</div>;
}
