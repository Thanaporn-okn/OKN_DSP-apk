'use client';
import { SlidersHorizontal } from 'lucide-react';

export type FeedFilters = { source: string; keyword: string; minPrice: string; maxPrice: string; province: string; sort: string; radiusKm: string; postedWithin: string };

export function FilterBar({ value, onChange, showSource = true }: { value: FeedFilters; onChange: (next: FeedFilters) => void; showSource?: boolean }) {
  const set = (key: keyof FeedFilters, v: string) => onChange({ ...value, [key]: v });
  return <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-3">
    <div className="mb-3 flex items-center gap-2 text-sm font-medium text-slate-200"><SlidersHorizontal className="h-4 w-4" />Filter & Sort</div>
    <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4 2xl:grid-cols-8">
      {showSource && <select value={value.source} onChange={(e) => set('source', e.target.value)} className="rounded-xl border border-slate-800 bg-slate-950 px-3 py-2.5 text-sm"><option value="">All sources</option><option value="MARKETPLACE">Marketplace</option><option value="FACEBOOK_GROUP">Groups</option></select>}
      <input value={value.keyword} onChange={(e) => set('keyword', e.target.value)} placeholder="Keyword" className="rounded-xl border border-slate-800 bg-slate-950 px-3 py-2.5 text-sm outline-none focus:border-blue-500" />
      <input value={value.minPrice} onChange={(e) => set('minPrice', e.target.value)} inputMode="numeric" placeholder="ราคาต่ำสุด" className="rounded-xl border border-slate-800 bg-slate-950 px-3 py-2.5 text-sm outline-none focus:border-blue-500" />
      <input value={value.maxPrice} onChange={(e) => set('maxPrice', e.target.value)} inputMode="numeric" placeholder="ราคาสูงสุด" className="rounded-xl border border-slate-800 bg-slate-950 px-3 py-2.5 text-sm outline-none focus:border-blue-500" />
      <input value={value.province} onChange={(e) => set('province', e.target.value)} placeholder="จังหวัด/เมือง" className="rounded-xl border border-slate-800 bg-slate-950 px-3 py-2.5 text-sm outline-none focus:border-blue-500" />
      <select value={value.radiusKm} onChange={(e) => set('radiusKm', e.target.value)} className="rounded-xl border border-slate-800 bg-slate-950 px-3 py-2.5 text-sm"><option value="">ทุกระยะ</option><option value="5">5 km</option><option value="10">10 km</option><option value="20">20 km</option><option value="50">50 km</option><option value="100">100 km</option><option value="200">200 km</option></select>
      <select value={value.postedWithin} onChange={(e) => set('postedWithin', e.target.value)} className="rounded-xl border border-slate-800 bg-slate-950 px-3 py-2.5 text-sm"><option value="">ทุกเวลาโพสต์</option><option value="1">1 ชั่วโมง</option><option value="6">6 ชั่วโมง</option><option value="24">24 ชั่วโมง</option><option value="168">7 วัน</option></select>
      <select value={value.sort} onChange={(e) => set('sort', e.target.value)} className="rounded-xl border border-slate-800 bg-slate-950 px-3 py-2.5 text-sm"><option value="newest">ใหม่ → เก่า</option><option value="price_asc">ราคาต่ำ → สูง</option><option value="price_desc">ราคาสูง → ต่ำ</option><option value="nearest">ใกล้ที่สุด</option></select>
    </div>
  </div>;
}
