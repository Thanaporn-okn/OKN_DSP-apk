'use client';
import { useEffect, useState } from 'react';
import { Activity, Clock3, Layers3, MapPinned, UsersRound } from 'lucide-react';
import { api } from '../lib/api';
import type { Stats } from '../lib/types';

export function StatsStrip() {
  const [stats, setStats] = useState<Stats | null>(null);
  useEffect(() => {
    const load = () => api<Stats>('stats').then(setStats).catch(() => undefined);
    load(); const id = setInterval(load, 20_000); return () => clearInterval(id);
  }, []);
  const cards = [
    ['สินค้าใหม่วันนี้', stats?.today, Activity],
    ['1 ชั่วโมงล่าสุด', stats?.lastHour, Clock3],
    ['ทั้งหมด', stats?.total, Layers3],
    ['Marketplace', stats?.marketplace, MapPinned],
    ['Group Posts', stats?.groups, UsersRound]
  ] as const;
  return <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 xl:grid-cols-5">{cards.map(([label, value, Icon]) => <div key={label} className="rounded-2xl border border-slate-800 bg-slate-900/60 p-3.5"><div className="flex items-center justify-between text-xs text-slate-500"><span>{label}</span><Icon className="h-4 w-4" /></div><div className="mt-2 text-2xl font-semibold tracking-tight text-white">{value ?? '—'}</div></div>)}</div>;
}
