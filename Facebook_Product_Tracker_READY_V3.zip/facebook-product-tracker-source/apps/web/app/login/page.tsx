'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { LockKeyhole } from 'lucide-react';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('demo@example.com');
  const [password, setPassword] = useState('ChangeMe123!');
  const [error, setError] = useState<string | null>(null);
  async function submit(event: React.FormEvent) {
    event.preventDefault(); setError(null);
    const response = await fetch('/api/auth/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email, password }) });
    if (!response.ok) return setError('อีเมลหรือรหัสผ่านไม่ถูกต้อง');
    router.replace('/'); router.refresh();
  }
  return <main className="grid min-h-screen place-items-center px-4"><form onSubmit={submit} className="w-full max-w-md rounded-3xl border border-slate-800 bg-slate-900/80 p-6 shadow-2xl"><div className="mb-5 grid h-12 w-12 place-items-center rounded-2xl bg-blue-600"><LockKeyhole className="h-5 w-5" /></div><h1 className="text-2xl font-bold text-white">เข้าสู่ระบบ</h1><p className="mt-1 text-sm text-slate-500">JWT เก็บใน HttpOnly cookie; API ภายในใช้ server-only key</p><div className="mt-5 space-y-3"><input value={email} onChange={(e) => setEmail(e.target.value)} type="email" className="w-full rounded-xl border border-slate-800 bg-slate-950 px-3 py-3" placeholder="Email" /><input value={password} onChange={(e) => setPassword(e.target.value)} type="password" className="w-full rounded-xl border border-slate-800 bg-slate-950 px-3 py-3" placeholder="Password" />{error && <p className="text-sm text-rose-400">{error}</p>}<button className="w-full rounded-xl bg-blue-600 px-4 py-3 font-semibold text-white hover:bg-blue-500">Login</button></div></form></main>;
}
