import type { Metadata } from 'next';
import 'maplibre-gl/dist/maplibre-gl.css';
import './globals.css';
import { DashboardShell } from '../components/dashboard-shell';

export const metadata: Metadata = {
  title: 'Facebook Product Tracker',
  description: 'Permitted-source Facebook Marketplace & Groups product tracking dashboard'
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="th"><body><DashboardShell>{children}</DashboardShell></body></html>;
}
