import { LiveFeedClient } from '../components/live-feed-client';
export default function HomePage() { return <LiveFeedClient />; }
