import { NextRequest, NextResponse } from 'next/server';
import { currentUserFromRequest, internalHeaders } from '../../../lib/server-user';

export async function GET(request: NextRequest) {
  const user = await currentUserFromRequest(request);
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const base = process.env.API_INTERNAL_URL ?? 'http://localhost:4000';
  const upstream = await fetch(new URL('/api/live', base), { headers: internalHeaders(user.id), cache: 'no-store', signal: request.signal });
  return new NextResponse(upstream.body, {
    status: upstream.status,
    headers: {
      'content-type': 'text/event-stream',
      'cache-control': 'no-cache, no-transform',
      connection: 'keep-alive',
      'x-accel-buffering': 'no'
    }
  });
}
