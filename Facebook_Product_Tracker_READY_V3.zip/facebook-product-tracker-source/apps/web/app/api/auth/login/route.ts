import { NextRequest, NextResponse } from 'next/server';
import { internalHeaders } from '../../../../lib/server-user';
import { signSession, type SessionUser } from '../../../../lib/session';

export async function POST(request: NextRequest) {
  const origin = request.headers.get('origin');
  if (origin && origin !== request.nextUrl.origin) return NextResponse.json({ error: 'Cross-site login blocked' }, { status: 403 });
  const base = process.env.API_INTERNAL_URL ?? 'http://localhost:4000';
  const upstream = await fetch(new URL('/api/auth/login', base), {
    method: 'POST',
    headers: { ...internalHeaders(), 'content-type': 'application/json' },
    body: await request.text(),
    cache: 'no-store'
  });
  if (!upstream.ok) return NextResponse.json({ error: 'Invalid credentials' }, { status: 401 });
  const user = await upstream.json() as SessionUser;
  const token = await signSession(user);
  const response = NextResponse.json({ ok: true, user });
  response.cookies.set('tracker_session', token, { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'lax', path: '/', maxAge: 60 * 60 * 12 });
  return response;
}
