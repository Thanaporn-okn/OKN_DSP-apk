import { NextRequest, NextResponse } from 'next/server';
import { currentUserFromRequest, internalHeaders } from '../../../../lib/server-user';

function safeMutation(request: NextRequest) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(request.method)) return true;
  const origin = request.headers.get('origin');
  return !origin || origin === request.nextUrl.origin;
}

async function forward(request: NextRequest, context: { params: Promise<{ path: string[] }> }) {
  if (!safeMutation(request)) return NextResponse.json({ error: 'Cross-site mutation blocked' }, { status: 403 });
  const user = await currentUserFromRequest(request);
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const { path } = await context.params;
  const base = process.env.API_INTERNAL_URL ?? 'http://localhost:4000';
  const target = new URL(`/api/${path.map(encodeURIComponent).join('/')}`, base);
  target.search = request.nextUrl.search;
  const body = ['GET', 'HEAD'].includes(request.method) ? undefined : await request.text();
  const upstream = await fetch(target, {
    method: request.method,
    headers: { ...internalHeaders(user.id), 'content-type': request.headers.get('content-type') ?? 'application/json' },
    body,
    cache: 'no-store',
    signal: request.signal
  });
  return new NextResponse(upstream.body, {
    status: upstream.status,
    headers: { 'content-type': upstream.headers.get('content-type') ?? 'application/json', 'cache-control': 'no-store' }
  });
}

export const GET = forward;
export const POST = forward;
export const PATCH = forward;
export const DELETE = forward;
