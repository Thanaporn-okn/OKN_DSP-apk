# Facebook Product Tracker Android

Android WebView shell แบบ production-safe สำหรับ Facebook Marketplace & Groups Product Tracker

## เปิดใช้ทันที

หากไม่ได้ตั้ง `TRACKER_WEB_URL` แอปจะเปิด `android/app/src/main/assets/index.html` เป็น **LOCAL DEMO** ทันที โดยมี:

- Live Feed และการจำลองสินค้าใหม่แบบ real-time
- Marketplace search / keyword / price / sort
- Latitude / Longitude / Radius และแผนที่เลือกตำแหน่งแบบ offline
- Search Preset บันทึกในเครื่อง
- Facebook Groups: add / enable / disable / sync / delete / view
- Price drop badge, source badge, stats และ responsive UI
- ข้อมูล Mock มากกว่า 20 รายการ

ข้อมูล LOCAL DEMO เก็บใน WebView `localStorage` และไม่ใช้ Facebook credential จริง

## เชื่อม Backend จริง

กดปุ่ม **Server** บนแถบ Android แล้วใส่ HTTPS URL ของระบบ Tracker ที่ deploy แล้ว หรือ build ด้วย Gradle property:

```bash
gradle -p android :app:assembleDebug -PTRACKER_WEB_URL=https://tracker.example.com
```

เว้น URL ว่างเพื่อกลับ LOCAL DEMO

## Security

- ไม่เก็บ Facebook token ใน APK
- อนุญาต remote tracker ผ่าน HTTPS เท่านั้น
- localhost/10.0.2.2 HTTP ใช้ได้เฉพาะ development
- ลิงก์ Facebook เปิดผ่าน external browser/app
