# No custom ProGuard rules are required for the lightweight WebView shell.
