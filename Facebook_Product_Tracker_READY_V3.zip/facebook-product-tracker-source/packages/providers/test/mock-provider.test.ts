import { describe, expect, it } from 'vitest';
import { MockMarketplaceProvider, MockGroupProvider } from '../src';

describe('mock providers', () => {
  it('returns normalized marketplace-shaped data', async () => {
    const provider = new MockMarketplaceProvider();
    const items = await provider.search({ keywords: ['iPhone'], latitude: 13.7563, longitude: 100.5018, radiusKm: 50 });
    expect(items.length).toBeGreaterThan(0);
    expect(items[0]?.source).toBe('MARKETPLACE');
  });

  it('returns group posts', async () => {
    const provider = new MockGroupProvider();
    const page = await provider.getPosts('demo-group-1');
    expect(page.items[0]?.source).toBe('FACEBOOK_GROUP');
  });
});
