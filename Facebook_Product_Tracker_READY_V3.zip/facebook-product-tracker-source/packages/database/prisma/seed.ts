import { PrismaClient, ProductSource } from '@prisma/client';
import bcrypt from 'bcryptjs';
import { createHash } from 'node:crypto';

const prisma = new PrismaClient();
const userId = process.env.DEMO_USER_ID ?? 'demo_user';

const locations = [
  ['กรุงเทพมหานคร', 13.7563, 100.5018],
  ['นนทบุรี', 13.8591, 100.5217],
  ['ปทุมธานี', 14.0208, 100.5250],
  ['สมุทรปราการ', 13.5991, 100.5998],
  ['ชลบุรี', 13.3611, 100.9847],
  ['เชียงใหม่', 18.7883, 98.9853]
] as const;

const demoProducts = [
  ['iPhone 16 Pro Max 256GB Titanium', 32900, 35900],
  ['iPhone 15 Pro 256GB', 24900, null],
  ['MacBook Air M3 15 นิ้ว', 34900, 38900],
  ['MacBook Pro M3 Pro 14 นิ้ว', 52900, null],
  ['Sony A7 IV Body สภาพสวย', 48900, 52900],
  ['Fujifilm X-T5 + 18-55', 45900, null],
  ['Canon EOS R6 Mark II', 49900, 53900],
  ['JBL PartyBox 310', 14900, 16900],
  ['Marantz PM6007 Integrated Amp', 16500, null],
  ['ลำโพง KEF Q350 คู่', 13900, 15900],
  ['RTX 4070 Super 12GB', 18500, null],
  ['Gaming PC Ryzen 7 + RTX 4070', 36900, 39900],
  ['iPad Pro M4 11 นิ้ว 256GB', 29900, 32900],
  ['Apple Watch Ultra 2', 18900, null],
  ['Toyota Yaris Ativ 2023', 489000, 519000],
  ['Honda City Hatchback RS 2022', 479000, null],
  ['DJI Mini 4 Pro Fly More', 22900, 24900],
  ['GoPro HERO13 Black', 11900, null],
  ['Nintendo Switch OLED', 7900, 8900],
  ['PlayStation 5 Slim Disc', 13900, null]
] as const;

function hashUrl(url: string) {
  return createHash('sha256').update(url).digest('hex');
}

async function main() {
  const passwordHash = await bcrypt.hash(process.env.DEMO_ADMIN_PASSWORD ?? 'ChangeMe123!', 12);
  await prisma.user.upsert({
    where: { id: userId },
    update: { email: process.env.DEMO_ADMIN_EMAIL ?? 'demo@example.com', passwordHash },
    create: {
      id: userId,
      email: process.env.DEMO_ADMIN_EMAIL ?? 'demo@example.com',
      name: 'Demo Admin',
      role: 'ADMIN',
      passwordHash
    }
  });

  const sources = [
    ['mock-marketplace', 'Mock Marketplace', 'MOCK_MARKETPLACE', 'CONNECTED'],
    ['mock-group', 'Mock Groups', 'MOCK_GROUP', 'CONNECTED'],
    ['meta-marketplace', 'Meta Marketplace (approved access only)', 'META_MARKETPLACE', 'UNAVAILABLE'],
    ['authorized-group', 'Authorized Group Source', 'AUTHORIZED_GROUP', 'UNAVAILABLE']
  ] as const;
  for (const [key, name, kind, status] of sources) {
    await prisma.dataSource.upsert({
      where: { key },
      update: { name, kind, connectionStatus: status, enabled: key.startsWith('mock') },
      create: { key, name, kind, connectionStatus: status, enabled: key.startsWith('mock'), config: {} }
    });
  }

  for (let i = 0; i < demoProducts.length; i++) {
    const [title, price, originalPrice] = demoProducts[i]!;
    const source: ProductSource = i % 3 === 0 ? 'FACEBOOK_GROUP' : 'MARKETPLACE';
    const externalId = `seed-${i + 1}`;
    const sourceUrl = `https://example.com/demo/${source.toLowerCase()}/${externalId}`;
    const loc = locations[i % locations.length]!;
    const product = await prisma.product.upsert({
      where: { normalizedUrlHash: hashUrl(sourceUrl) },
      update: {
        title,
        price,
        originalPrice,
        status: 'ACTIVE'
      },
      create: {
        externalId,
        source,
        sourceUrl,
        normalizedUrlHash: hashUrl(sourceUrl),
        title,
        description: 'ข้อมูลสาธิตสำหรับเปิดระบบครั้งแรก สามารถลบออกได้เมื่อเชื่อม Provider จริง',
        price,
        currency: 'THB',
        originalPrice,
        sellerName: `ผู้ขายตัวอย่าง ${i + 1}`,
        groupId: source === 'FACEBOOK_GROUP' ? `demo-group-${(i % 2) + 1}` : null,
        groupName: source === 'FACEBOOK_GROUP' ? `กลุ่มซื้อขายตัวอย่าง ${(i % 2) + 1}` : null,
        latitude: loc[1] + (i % 5) * 0.005,
        longitude: loc[2] + (i % 5) * 0.005,
        locationName: loc[0],
        createdAt: new Date(Date.now() - i * 22 * 60_000),
        discoveredAt: new Date(Date.now() - i * 17 * 60_000),
        status: 'ACTIVE',
        rawData: { seed: true, version: 1 }
      }
    });
    await prisma.productImage.upsert({
      where: { productId_url: { productId: product.id, url: `https://picsum.photos/seed/tracker-${i + 1}/900/700` } },
      update: {},
      create: { productId: product.id, url: `https://picsum.photos/seed/tracker-${i + 1}/900/700`, position: 0 }
    });
    if (originalPrice) {
      const historyCount = await prisma.productPriceHistory.count({ where: { productId: product.id } });
      if (historyCount === 0) {
        await prisma.productPriceHistory.createMany({
          data: [
            { productId: product.id, price: originalPrice, currency: 'THB', observedAt: new Date(Date.now() - 86_400_000) },
            { productId: product.id, price, currency: 'THB', observedAt: new Date() }
          ]
        });
      }
    }
  }

  const preset = await prisma.searchPreset.findFirst({ where: { userId, name: 'iPhone กรุงเทพ 50km' } });
  if (!preset) {
    await prisma.searchPreset.create({
      data: {
        userId,
        name: 'iPhone กรุงเทพ 50km',
        locationName: 'กรุงเทพมหานคร',
        latitude: 13.7563,
        longitude: 100.5018,
        radiusKm: 50,
        minPrice: 20000,
        maxPrice: 45000,
        enabled: true,
        providerKey: 'mock-marketplace',
        keywords: { create: [{ value: 'iPhone 16 Pro', normalized: 'iphone 16 pro' }, { value: 'iPhone', normalized: 'iphone' }] }
      }
    });
  }

  for (let i = 1; i <= 2; i++) {
    await prisma.trackedGroup.upsert({
      where: { userId_externalGroupId_providerKey: { userId, externalGroupId: `demo-group-${i}`, providerKey: 'mock-group' } },
      update: { enabled: true, connectionStatus: 'CONNECTED' },
      create: {
        userId,
        externalGroupId: `demo-group-${i}`,
        name: `กลุ่มซื้อขายตัวอย่าง ${i}`,
        providerKey: 'mock-group',
        enabled: true,
        connectionStatus: 'CONNECTED'
      }
    });
  }

  const existingRule = await prisma.notificationRule.findFirst({ where: { userId, name: 'iPhone <= 30,000' } });
  if (!existingRule) {
    await prisma.notificationRule.create({
      data: { userId, name: 'iPhone <= 30,000', keyword: 'iPhone', maxPrice: 30000, radiusKm: 50, latitude: 13.7563, longitude: 100.5018, channel: 'BROWSER', enabled: true }
    });
  }
}

main()
  .then(() => console.log('Seed completed: 20 demo products, presets, groups and data sources.'))
  .finally(() => prisma.$disconnect());
