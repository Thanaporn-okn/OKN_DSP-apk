CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS pg_trgm;

CREATE TYPE "UserRole" AS ENUM ('ADMIN','USER');
CREATE TYPE "ProductSource" AS ENUM ('MARKETPLACE','FACEBOOK_GROUP');
CREATE TYPE "ProductStatus" AS ENUM ('ACTIVE','SOLD','REMOVED','UNKNOWN');
CREATE TYPE "DataSourceKind" AS ENUM ('MOCK_MARKETPLACE','MOCK_GROUP','META_MARKETPLACE','AUTHORIZED_GROUP');
CREATE TYPE "ConnectionStatus" AS ENUM ('CONNECTED','LIMITED','AUTH_REQUIRED','UNAVAILABLE','ERROR','DISABLED');
CREATE TYPE "CollectorJobStatus" AS ENUM ('QUEUED','RUNNING','SUCCEEDED','FAILED','DEAD_LETTER');
CREATE TYPE "NotificationChannel" AS ENUM ('BROWSER','LINE','TELEGRAM','EMAIL','DISCORD');
CREATE TYPE "NotificationStatus" AS ENUM ('PENDING','SENT','FAILED','SKIPPED');

CREATE TABLE "User" (
  "id" TEXT PRIMARY KEY,
  "email" TEXT NOT NULL UNIQUE,
  "name" TEXT,
  "passwordHash" TEXT,
  "role" "UserRole" NOT NULL DEFAULT 'USER',
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL
);

CREATE TABLE "Product" (
  "id" TEXT PRIMARY KEY,
  "externalId" TEXT,
  "source" "ProductSource" NOT NULL,
  "sourceUrl" TEXT NOT NULL,
  "normalizedUrlHash" TEXT NOT NULL UNIQUE,
  "title" TEXT NOT NULL,
  "description" TEXT,
  "price" DECIMAL(14,2),
  "currency" VARCHAR(8) NOT NULL DEFAULT 'THB',
  "originalPrice" DECIMAL(14,2),
  "sellerName" TEXT,
  "groupId" TEXT,
  "groupName" TEXT,
  "latitude" DECIMAL(9,6),
  "longitude" DECIMAL(9,6),
  "locationName" TEXT,
  "createdAt" TIMESTAMP(3),
  "discoveredAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  "status" "ProductStatus" NOT NULL DEFAULT 'ACTIVE',
  "rawData" JSONB NOT NULL,
  "contentHash" TEXT,
  "location" geography(Point,4326) GENERATED ALWAYS AS (
    CASE WHEN "latitude" IS NULL OR "longitude" IS NULL THEN NULL
      ELSE ST_SetSRID(ST_MakePoint("longitude"::double precision, "latitude"::double precision),4326)::geography
    END
  ) STORED,
  CONSTRAINT "Product_source_externalId_key" UNIQUE ("source","externalId")
);

CREATE TABLE "ProductImage" (
  "id" TEXT PRIMARY KEY,
  "productId" TEXT NOT NULL,
  "url" TEXT NOT NULL,
  "position" INTEGER NOT NULL DEFAULT 0,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "ProductImage_productId_fkey" FOREIGN KEY ("productId") REFERENCES "Product"("id") ON DELETE CASCADE,
  CONSTRAINT "ProductImage_productId_url_key" UNIQUE ("productId","url")
);

CREATE TABLE "ProductPriceHistory" (
  "id" TEXT PRIMARY KEY,
  "productId" TEXT NOT NULL,
  "price" DECIMAL(14,2) NOT NULL,
  "currency" VARCHAR(8) NOT NULL,
  "observedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "ProductPriceHistory_productId_fkey" FOREIGN KEY ("productId") REFERENCES "Product"("id") ON DELETE CASCADE
);

CREATE TABLE "SearchPreset" (
  "id" TEXT PRIMARY KEY,
  "userId" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "locationName" TEXT,
  "latitude" DECIMAL(9,6) NOT NULL,
  "longitude" DECIMAL(9,6) NOT NULL,
  "radiusKm" DECIMAL(8,2) NOT NULL,
  "minPrice" DECIMAL(14,2),
  "maxPrice" DECIMAL(14,2),
  "enabled" BOOLEAN NOT NULL DEFAULT true,
  "providerKey" TEXT NOT NULL DEFAULT 'mock-marketplace',
  "lastRunAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "SearchPreset_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE
);

CREATE TABLE "SearchKeyword" (
  "id" TEXT PRIMARY KEY,
  "searchPresetId" TEXT NOT NULL,
  "value" TEXT NOT NULL,
  "normalized" TEXT NOT NULL,
  CONSTRAINT "SearchKeyword_searchPresetId_fkey" FOREIGN KEY ("searchPresetId") REFERENCES "SearchPreset"("id") ON DELETE CASCADE,
  CONSTRAINT "SearchKeyword_searchPresetId_normalized_key" UNIQUE ("searchPresetId","normalized")
);

CREATE TABLE "TrackedGroup" (
  "id" TEXT PRIMARY KEY,
  "userId" TEXT NOT NULL,
  "externalGroupId" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "providerKey" TEXT NOT NULL DEFAULT 'authorized-group',
  "enabled" BOOLEAN NOT NULL DEFAULT true,
  "connectionStatus" "ConnectionStatus" NOT NULL DEFAULT 'UNAVAILABLE',
  "lastSyncAt" TIMESTAMP(3),
  "lastCursor" TEXT,
  "postsCount" INTEGER NOT NULL DEFAULT 0,
  "newPostsCount" INTEGER NOT NULL DEFAULT 0,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "TrackedGroup_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE,
  CONSTRAINT "TrackedGroup_userId_externalGroupId_providerKey_key" UNIQUE ("userId","externalGroupId","providerKey")
);

CREATE TABLE "DataSource" (
  "id" TEXT PRIMARY KEY,
  "key" TEXT NOT NULL UNIQUE,
  "name" TEXT NOT NULL,
  "kind" "DataSourceKind" NOT NULL,
  "enabled" BOOLEAN NOT NULL DEFAULT true,
  "connectionStatus" "ConnectionStatus" NOT NULL DEFAULT 'UNAVAILABLE',
  "encryptedCredentials" TEXT,
  "config" JSONB NOT NULL DEFAULT '{}'::jsonb,
  "lastCheckedAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL
);

CREATE TABLE "CollectorJob" (
  "id" TEXT PRIMARY KEY,
  "queueName" TEXT NOT NULL,
  "providerKey" TEXT NOT NULL,
  "bullJobId" TEXT,
  "searchPresetId" TEXT,
  "trackedGroupId" TEXT,
  "status" "CollectorJobStatus" NOT NULL DEFAULT 'QUEUED',
  "attempts" INTEGER NOT NULL DEFAULT 0,
  "durationMs" INTEGER,
  "errorMessage" TEXT,
  "payload" JSONB NOT NULL,
  "startedAt" TIMESTAMP(3),
  "finishedAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "CollectorJob_searchPresetId_fkey" FOREIGN KEY ("searchPresetId") REFERENCES "SearchPreset"("id") ON DELETE SET NULL,
  CONSTRAINT "CollectorJob_trackedGroupId_fkey" FOREIGN KEY ("trackedGroupId") REFERENCES "TrackedGroup"("id") ON DELETE SET NULL
);

CREATE TABLE "EventLog" (
  "id" TEXT PRIMARY KEY,
  "type" TEXT NOT NULL,
  "aggregateId" TEXT,
  "payload" JSONB NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE "NotificationRule" (
  "id" TEXT PRIMARY KEY,
  "userId" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "enabled" BOOLEAN NOT NULL DEFAULT true,
  "keyword" TEXT,
  "maxPrice" DECIMAL(14,2),
  "latitude" DECIMAL(9,6),
  "longitude" DECIMAL(9,6),
  "radiusKm" DECIMAL(8,2),
  "source" "ProductSource",
  "channel" "NotificationChannel" NOT NULL DEFAULT 'BROWSER',
  "target" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "NotificationRule_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE
);

CREATE TABLE "Notification" (
  "id" TEXT PRIMARY KEY,
  "userId" TEXT NOT NULL,
  "ruleId" TEXT NOT NULL,
  "productId" TEXT NOT NULL,
  "channel" "NotificationChannel" NOT NULL,
  "status" "NotificationStatus" NOT NULL DEFAULT 'PENDING',
  "errorMessage" TEXT,
  "sentAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "Notification_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE,
  CONSTRAINT "Notification_ruleId_fkey" FOREIGN KEY ("ruleId") REFERENCES "NotificationRule"("id") ON DELETE CASCADE,
  CONSTRAINT "Notification_productId_fkey" FOREIGN KEY ("productId") REFERENCES "Product"("id") ON DELETE CASCADE,
  CONSTRAINT "Notification_ruleId_productId_channel_key" UNIQUE ("ruleId","productId","channel")
);

CREATE INDEX "Product_discoveredAt_id_idx" ON "Product" ("discoveredAt" DESC, "id" DESC);
CREATE INDEX "Product_createdAt_idx" ON "Product" ("createdAt" DESC);
CREATE INDEX "Product_source_discoveredAt_idx" ON "Product" ("source", "discoveredAt" DESC);
CREATE INDEX "Product_price_idx" ON "Product" ("price");
CREATE INDEX "Product_groupId_discoveredAt_idx" ON "Product" ("groupId", "discoveredAt" DESC);
CREATE INDEX "Product_latitude_longitude_idx" ON "Product" ("latitude", "longitude");
CREATE INDEX "Product_status_idx" ON "Product" ("status");
CREATE INDEX "Product_location_gist_idx" ON "Product" USING GIST ("location");
CREATE INDEX "Product_title_trgm_idx" ON "Product" USING GIN ("title" gin_trgm_ops);
CREATE INDEX "Product_description_trgm_idx" ON "Product" USING GIN ("description" gin_trgm_ops);
CREATE INDEX "ProductImage_productId_position_idx" ON "ProductImage" ("productId", "position");
CREATE INDEX "ProductPriceHistory_productId_observedAt_idx" ON "ProductPriceHistory" ("productId", "observedAt" DESC);
CREATE INDEX "SearchPreset_userId_enabled_idx" ON "SearchPreset" ("userId", "enabled");
CREATE INDEX "SearchPreset_enabled_lastRunAt_idx" ON "SearchPreset" ("enabled", "lastRunAt");
CREATE INDEX "SearchKeyword_normalized_idx" ON "SearchKeyword" ("normalized");
CREATE INDEX "TrackedGroup_userId_enabled_idx" ON "TrackedGroup" ("userId", "enabled");
CREATE INDEX "CollectorJob_status_createdAt_idx" ON "CollectorJob" ("status", "createdAt" DESC);
CREATE INDEX "CollectorJob_providerKey_createdAt_idx" ON "CollectorJob" ("providerKey", "createdAt" DESC);
CREATE INDEX "EventLog_type_createdAt_idx" ON "EventLog" ("type", "createdAt" DESC);
CREATE INDEX "EventLog_aggregateId_createdAt_idx" ON "EventLog" ("aggregateId", "createdAt" DESC);
CREATE INDEX "NotificationRule_userId_enabled_idx" ON "NotificationRule" ("userId", "enabled");
CREATE INDEX "Notification_userId_createdAt_idx" ON "Notification" ("userId", "createdAt" DESC);
CREATE INDEX "Notification_status_createdAt_idx" ON "Notification" ("status", "createdAt");
