import { describe, expect, it } from 'vitest';
import { ProductSearchSchema, RealtimeEventSchema } from '../src';

describe('search validation', () => {
  it('requires complete geo triplet', () => {
    expect(ProductSearchSchema.safeParse({ latitude: 13.7 }).success).toBe(false);
    expect(ProductSearchSchema.safeParse({ latitude: 13.7, longitude: 100.5, radiusKm: 50 }).success).toBe(true);
  });

  it('caps page size at 100', () => {
    expect(ProductSearchSchema.safeParse({ limit: 101 }).success).toBe(false);
  });
});

describe('realtime event contract', () => {
  it('accepts product.created envelope', () => {
    expect(RealtimeEventSchema.safeParse({ id: '1', type: 'product.created', occurredAt: new Date().toISOString(), payload: { product: { id: 'p1' } } }).success).toBe(true);
  });
});
