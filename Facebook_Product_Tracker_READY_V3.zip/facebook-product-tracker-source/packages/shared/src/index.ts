import { z } from 'zod';

export const ProductSourceSchema = z.enum(['MARKETPLACE', 'FACEBOOK_GROUP']);
export type ProductSource = z.infer<typeof ProductSourceSchema>;

export const ProductStatusSchema = z.enum(['ACTIVE', 'SOLD', 'REMOVED', 'UNKNOWN']);
export type ProductStatus = z.infer<typeof ProductStatusSchema>;

export const ProductResultSchema = z.object({
  externalId: z.string().min(1),
  source: ProductSourceSchema,
  sourceUrl: z.string().url(),
  title: z.string().min(1),
  description: z.string().nullable().optional(),
  price: z.number().nonnegative().nullable().optional(),
  currency: z.string().default('THB'),
  originalPrice: z.number().nonnegative().nullable().optional(),
  images: z.array(z.string().url()).default([]),
  sellerName: z.string().nullable().optional(),
  groupId: z.string().nullable().optional(),
  groupName: z.string().nullable().optional(),
  latitude: z.number().min(-90).max(90).nullable().optional(),
  longitude: z.number().min(-180).max(180).nullable().optional(),
  locationName: z.string().nullable().optional(),
  createdAt: z.coerce.date().nullable().optional(),
  updatedAt: z.coerce.date().nullable().optional(),
  status: ProductStatusSchema.default('ACTIVE'),
  rawData: z.record(z.unknown()).default({})
});
export type ProductResult = z.infer<typeof ProductResultSchema>;

export const ProductSearchSchema = z.object({
  keyword: z.string().trim().optional(),
  source: ProductSourceSchema.optional(),
  groupId: z.string().optional(),
  province: z.string().optional(),
  minPrice: z.coerce.number().nonnegative().optional(),
  maxPrice: z.coerce.number().nonnegative().optional(),
  latitude: z.coerce.number().min(-90).max(90).optional(),
  longitude: z.coerce.number().min(-180).max(180).optional(),
  radiusKm: z.coerce.number().positive().max(1000).optional(),
  createdAfter: z.coerce.date().optional(),
  sort: z.enum(['newest', 'price_asc', 'price_desc', 'nearest']).default('newest'),
  cursor: z.string().optional(),
  limit: z.coerce.number().int().min(1).max(100).default(30)
}).refine((v) => {
  const geo = [v.latitude, v.longitude, v.radiusKm].filter((x) => x !== undefined).length;
  return geo === 0 || geo === 3;
}, 'latitude, longitude and radiusKm must be supplied together').refine((v) => {
  const geo = [v.latitude, v.longitude, v.radiusKm].filter((x) => x !== undefined).length;
  return v.sort !== 'nearest' || geo === 3;
}, 'nearest sort requires latitude, longitude and radiusKm');
export type ProductSearch = z.infer<typeof ProductSearchSchema>;

export const SearchPresetInputSchema = z.object({
  name: z.string().min(2).max(100),
  keywords: z.array(z.string().trim().min(1)).min(1).max(20),
  locationName: z.string().max(200).nullable().optional(),
  latitude: z.number().min(-90).max(90),
  longitude: z.number().min(-180).max(180),
  radiusKm: z.number().positive().max(1000),
  minPrice: z.number().nonnegative().nullable().optional(),
  maxPrice: z.number().nonnegative().nullable().optional(),
  enabled: z.boolean().default(true)
});
export type SearchPresetInput = z.infer<typeof SearchPresetInputSchema>;

export const TrackedGroupInputSchema = z.object({
  externalGroupId: z.string().min(1),
  name: z.string().min(1).max(200),
  providerKey: z.string().min(1).default('authorized-group'),
  enabled: z.boolean().default(true)
});
export type TrackedGroupInput = z.infer<typeof TrackedGroupInputSchema>;

export const RealtimeEventSchema = z.object({
  id: z.string(),
  type: z.enum([
    'product.created',
    'product.updated',
    'product.price_changed',
    'product.removed',
    'collector.status',
    'group.synced'
  ]),
  occurredAt: z.string(),
  payload: z.record(z.unknown())
});
export type RealtimeEvent = z.infer<typeof RealtimeEventSchema>;

export type CursorPayload = { sort: 'newest' | 'price_asc' | 'price_desc' | 'nearest'; id: string; value: string | number };

export function encodeCursor(value: CursorPayload): string {
  return Buffer.from(JSON.stringify(value)).toString('base64url');
}

export function decodeCursor(cursor?: string): CursorPayload | null {
  if (!cursor) return null;
  try {
    const value = JSON.parse(Buffer.from(cursor, 'base64url').toString('utf8')) as CursorPayload;
    if (!value?.id || !['newest','price_asc','price_desc','nearest'].includes(value.sort) || !['string','number'].includes(typeof value.value)) return null;
    return value;
  } catch {
    return null;
  }
}
