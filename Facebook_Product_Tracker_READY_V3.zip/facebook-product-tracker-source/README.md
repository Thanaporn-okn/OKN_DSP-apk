# Facebook Marketplace & Groups Product Tracker

เว็บแอปแบบ Production-oriented สำหรับรวบรวม ค้นหา จัดเก็บ ติดตาม และแจ้งเหตุการณ์ของประกาศสินค้าจาก **Data Provider ที่ได้รับอนุญาต** โดย Core Application ไม่ผูกกับ scraping implementation และสามารถรันด้วย Mock Provider ได้ทันที

> จุดยืนด้านการเข้าถึงข้อมูล: โปรเจกต์นี้ไม่ข้าม Login/CAPTCHA, ไม่ขโมย Cookie/Session/Token, ไม่หลบ Bot Protection และไม่เข้าถึง Group ที่บัญชี/แอปไม่มีสิทธิ์

## STEP 1 — ข้อจำกัด Facebook / Meta ที่ต้องรู้

- Meta ประกาศ deprecate Facebook Groups API ใน Graph API v19 และระบุว่าจะถูกนำออกจากทุกเวอร์ชันในวันที่ 22 เมษายน 2024 ดังนั้น `AuthorizedGroupProvider` ในโปรเจกต์นี้ **ไม่แกล้งทำเป็น Graph API ที่ยังใช้งานได้** และจะรายงาน `UNAVAILABLE` จนกว่าจะเสียบแหล่งข้อมูลที่ Meta/เจ้าของข้อมูลอนุญาตจริง
- Facebook Marketplace ไม่มี public Graph API ทั่วไปที่ให้แอปดึง “Marketplace ทั้งหมด” ของผู้ใช้ทุกคนได้ตามใจ แอปจึงแยก `ProductProvider` ออกจาก Core
- Meta มีผลิตภัณฑ์/โปรแกรมเฉพาะบางแบบ เช่น Marketplace Partner APIs และ Meta Content Library API แต่สิทธิ์, วัตถุประสงค์, ประเทศ, ประเภทข้อมูล และการอนุมัติขึ้นกับโปรแกรมนั้น ๆ ต้องตรวจสิทธิ์ของแอปก่อน implement connector จริง

เอกสารอ้างอิง Meta:
- https://developers.facebook.com/docs/graph-api/changelog/version19.0/
- https://developers.facebook.com/blog/post/2024/01/23/introducing-facebook-graph-and-marketing-api-v19/
- https://developers.facebook.com/docs/marketplace/partnerships/itemAPI/
- https://developers.facebook.com/docs/content-library-and-api/content-library-api/guides/fb-marketplace/

## STEP 2 — Architecture

```text
Permitted Provider / Mock Provider
              |
              v
      BullMQ Collector Worker
              |
     Normalizer + Dedupe
              |
        PostgreSQL/PostGIS
              |
       EventLog + Redis Pub/Sub
              |
          NestJS SSE API
              |
       Next.js BFF (secret boundary)
              |
      Browser / Responsive UI
```

- **Web:** Next.js + React + TypeScript + Tailwind CSS + MapLibre
- **API:** NestJS, REST, Zod validation, rate limiting
- **Worker:** BullMQ + Redis, exponential backoff, rate limiting, dead-letter state
- **Database:** PostgreSQL + PostGIS + Prisma
- **Realtime:** Redis Pub/Sub → NestJS SSE → Browser `EventSource`
- **Geo:** generated `geography(Point,4326)` + GiST index + `ST_DWithin` / `ST_Distance`
- **Keyword:** `pg_trgm` GIN index สำหรับ title/description
- **Auth:** JWT session ใน HttpOnly cookie เมื่อปิด demo mode; Browser ไม่เห็น `INTERNAL_API_KEY`

รายละเอียดเพิ่ม: `docs/ARCHITECTURE.md`

## STEP 3 — Folder Structure

```text
apps/
  web/                    # Next.js UI + BFF + SSE proxy
  api/                    # NestJS REST API + system status + SSE
  worker/                 # BullMQ collectors, ingestion, rule engine
packages/
  database/               # Prisma schema, migrations, seed
  providers/              # Provider interfaces + mock/safe Meta stubs + credential crypto
  shared/                 # Shared Zod contracts/types/cursor helpers
docker/
  Dockerfile.web
  Dockerfile.api
  Dockerfile.worker
docs/
  ARCHITECTURE.md
  META_LIMITATIONS.md
.github/workflows/ci.yml
```

## STEP 4 — Database

Prisma models:

- `User`
- `Product`
- `ProductImage`
- `ProductPriceHistory`
- `SearchPreset`
- `SearchKeyword`
- `TrackedGroup`
- `DataSource`
- `CollectorJob`
- `EventLog`
- `NotificationRule`
- `Notification`

Duplicate protection ใช้ `@@unique([source, externalId])` + unique `normalizedUrlHash` และ Worker จับ Prisma `P2002` เพื่อป้องกัน race condition จาก worker หลายตัว

Spatial migration เปิด `postgis` และสร้าง generated geography column + GiST index ส่วน keyword เปิด `pg_trgm` + GIN index

## STEP 5 — Backend API

หลัก ๆ มี:

```text
GET    /api/products
GET    /api/products/:id
GET    /api/marketplace
GET    /api/live                    # SSE
GET    /api/groups
POST   /api/groups
PATCH  /api/groups/:id
DELETE /api/groups/:id
POST   /api/groups/:id/sync
GET    /api/groups/:id/posts
GET    /api/search-presets
POST   /api/search-presets
PATCH  /api/search-presets/:id
DELETE /api/search-presets/:id
POST   /api/search-presets/:id/sync
GET    /api/system/status
GET    /api/stats
POST   /api/auth/login
```

Feed รองรับ keyword/source/group/province/price/date/geo radius/sort และใช้ cursor ที่ผูกกับ sort key เพื่อป้องกัน duplicate/skip ระหว่างหน้า

## STEP 6 — Provider Layer

```ts
interface ProductProvider {
  readonly key: string;
  health(): Promise<ProviderHealth>;
  search(params: MarketplaceSearchParams): Promise<ProductResult[]>;
  getItem(externalId: string): Promise<ProductResult | null>;
}

interface GroupProvider {
  readonly key: string;
  health(): Promise<ProviderHealth>;
  getPosts(groupId: string, cursor?: string): Promise<GroupPostPage>;
}
```

มี provider เริ่มต้น:

- `MockMarketplaceProvider` — ใช้ได้ทันที
- `MockGroupProvider` — ใช้ได้ทันที
- `MetaMarketplaceProvider` — safe stub; ไม่ทำ scraping และไม่อ้างสิทธิ์ที่ไม่มี
- `AuthorizedGroupProvider` — safe stub หลังการยกเลิก legacy Groups API

Credential ที่ต้อง persist สามารถใช้ AES-256-GCM helpers `encryptCredential()` / `decryptCredential()` และเก็บเฉพาะ ciphertext ใน `DataSource.encryptedCredentials`

## STEP 7 — Queue / Worker

Queue:

- `search-watcher`
- `group-watcher`
- `product-update`
- `cleanup`
- `retry`

ทุก collector ใช้ exponential backoff + rate limiter และเขียน `CollectorJob` เพื่อดูสถานะ `RUNNING / SUCCEEDED / FAILED / DEAD_LETTER`

หาก Provider มี webhook จริง ควร implement connector ให้ webhook enqueue งานแทนการลด polling interval

## STEP 8 — Realtime

Event หลัก:

- `product.created`
- `product.updated`
- `product.price_changed`
- `product.removed`
- `collector.status`
- `group.synced`

Worker เขียน DB ก่อน แล้ว publish event ผ่าน Redis หลัง transaction สำเร็จ หน้า Live Feed รับผ่าน SSE และ insert/update card โดยไม่ reload

## STEP 9 — Frontend

มี 3 หน้าหลัก:

1. `/` Live Feed — stats, filter, time/radius, realtime insert, infinite scroll
2. `/marketplace` — keyword/location/lat/lng/radius/price/sort, Map click, save preset, grid/list
3. `/groups` — Add/Enable/Disable/Sync/Delete/View feed + group/date/keyword/price filter

UI เป็น responsive dark dashboard มี desktop sidebar และ mobile bottom navigation

## STEP 10 — Location / Radius

Marketplace ใช้ MapLibre โดย map tile ถูกห่อผ่าน `MapProviderAdapter` เพื่อเปลี่ยน provider ได้ภายหลัง

Backend ใช้ PostGIS:

```sql
ST_DWithin(product.location, search_point, radius_meters)
ST_Distance(product.location, search_point)
```

จึงไม่ส่งสินค้าหลายหมื่นรายการเข้า Browser เพื่อคำนวณระยะเอง

## STEP 11 — Groups Tracking

ใน Demo ให้เลือก `mock-group`

`authorized-group` เป็น placeholder ที่ตั้งใจ fail-safe เพราะ legacy Facebook Groups API ใช้งานไม่ได้แล้ว หากองค์กรของคุณมี permitted source ใหม่ ให้ implement `GroupProvider` ตัวใหม่และลงทะเบียนใน `createGroupProvider()` โดยไม่แก้ Product Service/UI

## STEP 12 — Run with Docker

ต้องมี Docker + Docker Compose เท่านั้น สำหรับ demo ไม่จำเป็นต้องสร้าง `.env` ก่อน:

```bash
docker compose up --build
```

เปิด:

```text
http://localhost:3000
```

Compose มี local-only default secrets เพื่อให้ demo ขึ้นทันที และ `APP_DEMO_MODE=true` โดยค่าเริ่มต้น **ห้ามใช้ค่า default เหล่านี้ใน Production**

หยุดระบบ:

```bash
docker compose down
```

ล้าง demo database:

```bash
docker compose down -v
```

## Development แบบไม่ใช้ Docker สำหรับ Node services

Requirements:

- Node.js >= 20.18 (แนะนำ 22)
- PostgreSQL 16 + PostGIS
- Redis 7+

```bash
cp .env.example .env
npm install
npm run prisma:generate
npm run prisma:deploy -w @tracker/database
npm run prisma:seed -w @tracker/database
npm run dev
```

## Environment Variables

สำคัญ:

```text
DATABASE_URL
REDIS_URL
INTERNAL_API_KEY
AUTH_SECRET
APP_DEMO_MODE
DEMO_USER_ID
DEMO_ADMIN_EMAIL
DEMO_ADMIN_PASSWORD
CREDENTIAL_ENCRYPTION_KEY
FACEBOOK_APP_ID
FACEBOOK_APP_SECRET
FACEBOOK_ACCESS_TOKEN
META_CONTENT_LIBRARY_TOKEN
META_MARKETPLACE_PROVIDER_MODE
META_GROUP_PROVIDER_MODE
```

`FACEBOOK_*` และ token ทั้งหมดเป็น server-side เท่านั้น ห้าม prefix ด้วย `NEXT_PUBLIC_`

## Authentication

Demo Compose ตั้ง `APP_DEMO_MODE=true` เพื่อเปิด Dashboard ทันทีตาม requirement

Production:

1. ตั้ง `APP_DEMO_MODE=false`
2. เปลี่ยน `AUTH_SECRET`, `INTERNAL_API_KEY`, DB/Redis credentials
3. เปลี่ยน demo admin password หรือแทน login layer ด้วย OIDC/OAuth provider ขององค์กร
4. ใช้ HTTPS เท่านั้น

เมื่อ demo mode ปิด Login จะใช้ password hash ใน DB และออก JWT 12 ชั่วโมงใน `HttpOnly + SameSite=Lax` cookie

## Security Notes

- Provider secret ไม่ส่งไป Frontend
- API ไม่ publish port ออก host ใน Compose; Browser เข้า API ผ่าน Next.js BFF
- BFF ตรวจ same-origin สำหรับ mutation เพื่อช่วยป้องกัน CSRF
- NestJS throttling ป้องกัน request burst
- Prisma parameterization ลด SQL injection; raw PostGIS query ใช้ tagged `Prisma.sql`
- Next secure headers + CSP + frame deny + MIME sniff protection
- Pino logger redact token/password/cookie/authorization
- persisted provider credentials มี AES-256-GCM helper
- ห้าม log raw Facebook access token หรือ session cookie

## Notification Architecture

Schema รองรับ `BROWSER / LINE / TELEGRAM / EMAIL / DISCORD`

V1 จะสร้าง Browser notification record เมื่อ rule match ส่วนช่องทางอื่นคง `PENDING` เพื่อให้เพิ่ม sender adapter ต่อได้โดยไม่แก้ rule matching/database schema

ตัวอย่าง rule seed:

```text
Keyword = iPhone
Price <= 30000
Radius <= 50 km จากกรุงเทพฯ
Channel = BROWSER
```

## STEP 13 — Tests

มี automated tests สำหรับ:

- Normalizer
- URL/duplicate identity
- Mock Provider
- Search validation
- Realtime event contract
- API protection + stats integration

รัน:

```bash
npm test
```

Integration/API test ต้องมี PostgreSQL + Redis และ migration/seed แล้ว

## STEP 14 — GitHub Actions

`.github/workflows/ci.yml` ทำ:

1. install
2. Prisma generate/migrate/seed
3. lint/typecheck
4. tests
5. build
6. Docker build validation ทั้ง web/api/worker

## STEP 15 — Production Deployment

แนะนำ:

- Managed PostgreSQL ที่เปิด PostGIS
- Managed Redis พร้อม auth/TLS
- แยก Web/API/Worker replicas
- API/Redis/DB อยู่ private network
- HTTPS ที่ reverse proxy/load balancer
- Secret Manager แทน `.env` file
- จำกัด Worker concurrency ตาม provider rate limit จริง
- ใส่ metrics/alerting (Prometheus/OpenTelemetry/Sentry) ก่อนรับโหลดจริง
- backup DB + retention policy

หาก scale API หลาย replica SSE ยังทำงานได้เพราะทุก API subscribe Redis Pub/Sub เดียวกัน

## STEP 16 — Validation / Troubleshooting

### `Provider ... is UNAVAILABLE`
ปกติสำหรับ safe Meta/Group stubs จนกว่าจะ configure approved connector จริง ให้ใช้ Mock Provider เพื่อตรวจระบบ Core

### Map ไม่ขึ้น
ตรวจ internet access ไป `https://tile.openstreetmap.org` และข้อกำหนด tile usage หาก production traffic สูง ควรใช้ commercial/self-hosted tile provider ผ่าน `MapProviderAdapter`

### PostGIS migration error
ต้องใช้ PostgreSQL image/instance ที่ติดตั้ง PostGIS ได้ Compose ใช้ `postgis/postgis:16-3.4`

### Queue ไม่วิ่ง
ตรวจ `REDIS_URL`, Redis health และหน้า System Status

### Facebook token expired/rate limited
Provider จริงต้องแปลงสถานะเป็น `AUTH_REQUIRED` / `LIMITED`, ใช้ refresh flow เฉพาะที่ Meta รองรับ และไม่ polling ถี่เพื่อหลบข้อจำกัด

## สิ่งที่ควรเพิ่มก่อน Production จริงกับ Meta

1. ผ่าน Meta App Review / program approval ที่เกี่ยวข้องกับ data product จริง
2. Implement provider ตาม endpoint/scope ที่ได้รับอนุญาตเท่านั้น
3. Token lifecycle + encrypted credential storage/rotation
4. Provider-specific rate-limit headers and adaptive scheduler
5. Data retention/deletion flow ตาม Meta Platform Terms และกฎหมายที่เกี่ยวข้อง
6. Monitoring, audit trail, SLO, backup/restore drill

## Android APK shell / GitHub ZIP build

โฟลเดอร์ `android/` เป็น Android WebView shell สำหรับเปิด Dashboard ที่ Deploy แล้ว โดย Backend, PostgreSQL, Redis และ Facebook/Meta credentials ยังคงอยู่ฝั่ง Server เท่านั้น

เมื่อนำ `facebook-product-tracker-source.zip` และ workflow `Build_APK_From_ZIP.yml` ไปไว้ที่ root ของ GitHub repository ระบบ Actions จะ unzip source ก่อน setup Gradle และ build `FacebookProductTracker-debug.apk` อัตโนมัติ

แนะนำให้ตั้ง Repository Variable `TRACKER_WEB_URL` เป็น HTTPS URL ของ Web App ที่ Deploy แล้ว เช่น `https://tracker.example.com` หากไม่ตั้ง สามารถเปิด APK แล้วกด “ตั้งค่า URL” ภายในแอปได้
