import 'package:flutter/material.dart';

class CrossoverPage extends StatelessWidget{
 const CrossoverPage({super.key});

 Widget build(BuildContext c)=>Column(children:[
 const Text('CROSSOVER',
 style:TextStyle(fontSize:25,color:Colors.cyan)),
 const Text('HPF Frequency'),
 Slider(value:.3,onChanged:null),
 const Text('LPF Frequency'),
 Slider(value:.7,onChanged:null),
 const Text('Slope 12 / 24 / 48 dB')
 ]);
}
