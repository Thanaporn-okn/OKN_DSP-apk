import 'package:flutter/material.dart';

class BluetoothPage extends StatelessWidget{
 const BluetoothPage({super.key});

 Widget build(BuildContext c)=>Column(children:[
 const Text('BLUETOOTH DSP',
 style:TextStyle(fontSize:25,color:Colors.cyan)),
 ElevatedButton(
 onPressed:null,
 child:const Text('SCAN BP1048P4')),
 ElevatedButton(
 onPressed:null,
 child:const Text('CONNECT'))
 ]);
}
