import 'package:flutter/material.dart';

class EQPage extends StatelessWidget{
 const EQPage({super.key});

 Widget build(BuildContext c)=>Column(children:[
 const Text('EQ 15 BAND GRAPH',
 style:TextStyle(fontSize:25,color:Colors.cyan)),
 Expanded(child:ListView.builder(
 itemCount:15,
 itemBuilder:(c,i)=>Column(children:[
 Text('Band ${i+1}'),
 Slider(
 min:-12,max:12,value:0,
 onChanged:null)
 ])))
 ]);
}
