import 'package:flutter/material.dart';
import 'eq_page.dart';
import 'crossover_page.dart';
import 'bluetooth_page.dart';

void main()=>runApp(const OKNDSP());

class OKNDSP extends StatelessWidget{
 const OKNDSP({super.key});
 Widget build(BuildContext c)=>MaterialApp(
 debugShowCheckedModeBanner:false,
 theme:ThemeData.dark(useMaterial3:true),
 home:const Home());
}

class Home extends StatefulWidget{
 const Home({super.key});
 State<Home> createState()=>_Home();
}

class _Home extends State<Home>{
 int tab=0;

 final pages=[
 const MainPage(),
 const EQPage(),
 const CrossoverPage(),
 const BluetoothPage()
 ];

 Widget build(BuildContext c)=>Scaffold(
 backgroundColor:const Color(0xff090d12),
 body:SafeArea(child:pages[tab]),
 bottomNavigationBar:NavigationBar(
 selectedIndex:tab,
 onDestinationSelected:(v)=>setState(()=>tab=v),
 destinations:const[
 NavigationDestination(icon:Icon(Icons.tune),label:'MAIN'),
 NavigationDestination(icon:Icon(Icons.graphic_eq),label:'EQ'),
 NavigationDestination(icon:Icon(Icons.filter_alt),label:'XOVER'),
 NavigationDestination(icon:Icon(Icons.bluetooth),label:'BT')
 ]));
}

class MainPage extends StatelessWidget{
 const MainPage({super.key});
 Widget build(BuildContext c)=>Column(children:[
 const Text('OKN_DSP V21 BETA2',
 style:TextStyle(fontSize:30,color:Colors.cyan)),
 const Text('BP1048P4 7CH DSP'),
 Expanded(child:Row(children:List.generate(7,(i)=>
 Expanded(child:Column(children:[
 Text('CH${i+1}'),
 Expanded(child:RotatedBox(
 quarterTurns:3,
 child:Slider(value:.5,onChanged:null))),
 Text('-12 dB')
 ]))))),
 ]);
}
