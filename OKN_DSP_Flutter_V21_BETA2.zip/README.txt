OKN_DSP Flutter V21 BETA2

Added:
- Improved navigation
- EQ gain -12 to +12 dB
- Crossover control page
- Bluetooth manager UI

Target:
BP1048P4 7CH DSP
