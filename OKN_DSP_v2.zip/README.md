# OKN_DSP v2

Launch-stability repair of the clean OKN_DSP restart.

## v2 scope
- Keeps the UI structure from the supplied reference image.
- Home: Master Volume, Bass Volume, Bass Cutoff, Bass Boost, Middle Boost, Treble Boost, presets, save/load.
- EQ: graph, 7 bands, 7-channel selector, copy/paste/save controls.
- Home/EQ navigation and touch sliders.
- Fixes risky launch/render paths from v1: no forced software layer, guarded canvas sizing, safe shader drawing, and a render-fallback guard.
- DSP/BLE commands are still intentionally not connected in this UI-stage build.

## Android build
- Package: `com.okn.dsp`
- Min SDK: 26
- Target/Compile SDK: 35
- Java: 17
- Android Gradle Plugin: 8.6.1
- Version code: 2
- Version name: `1.0-v2`
