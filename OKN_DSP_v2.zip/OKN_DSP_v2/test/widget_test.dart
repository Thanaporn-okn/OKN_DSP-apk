import 'package:flutter_test/flutter_test.dart';
import 'package:okn_dsp/main.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  testWidgets('OKN_DSP app starts', (tester) async {
    SharedPreferences.setMockInitialValues({});
    await tester.pumpWidget(const OknDspApp());
    await tester.pumpAndSettle();
    expect(find.text('OKN_DSP'), findsOneWidget);
  });
}
