# OKN_DSP v2

Flutter implementation rebuilt from step 1 using only the five supplied DSP Control UI reference screens.

## Included
- Home, Parametric EQ, Crossover, Delay, and Output screens.
- 7 channels: Front L, Front R, Rear L, Rear R, Center, Sub L, Sub R.
- Responsive full-screen layout with SafeArea, scroll/compact layouts for narrow phones, and centered wide layout for tablets.
- Interactive sliders, switches, dropdowns, presets, EQ band controls, crossover values, delays, mute/solo/phase/link controls.
- Controls update local UI state immediately; main/output/delay values and EQ presets are persisted.
- BLE scan/connect/disconnect support using `flutter_blue_plus`.
- Known observed BLE UUID: `0000ab01-0000-1000-8000-00805f9b34fb`.
- `Sources/` contains the protocol notes, control map, UI-reference hashes, and source-file SHA-256 manifest.

## Important protocol boundary
The supplied/captured data does not yet contain a verified DSP write-command packet format. This project deliberately does **not** guess or transmit fabricated DSP parameter bytes. BLE discovery and connection are implemented, but hardware parameter transmission remains gated until real write frames are captured and verified. The packet encoder methods in `lib/main.dart` are the intended integration points.

## Mobile-friendly GitHub build
Use the separate `build_android_v2.yml` once as `.github/workflows/build_android.yml` in the repository.

After that, each new version can be uploaded as a single ZIP named `OKN_DSP_vN.zip` at the repository root. The workflow automatically detects the highest version ZIP, extracts it, generates the Android platform project, installs dependencies, generates the launcher icon, runs analyze/tests, builds the release APK, creates the APK SHA-256 file, and uploads both as the Actions artifact.

The workflow runs automatically on every push and also keeps `workflow_dispatch`, so the **Run workflow** button remains available when the workflow file is on the repository default branch.


## v2 build correction
Version 2 was created from the reported v1 Android release-build failure. The UI/controls are intentionally unchanged.

- `flutter_blue_plus` is pinned to `1.36.8`; the 1.35.10+ line includes the Android change to use the user/project compile SDK instead of the older hard-coded API 33 behavior.
- GitHub Actions pins Flutter `3.44.8` for deterministic builds. This Flutter line uses Android compile/target API 36.
- The workflow explicitly locks app `compileSdk`/`targetSdk` to API 36 after `flutter create`.
- Gradle VFS watching is disabled in CI to suppress the non-fatal `Already watching path` watcher exception seen on some Flutter/Gradle Linux builds.
- Every release artifact still includes an APK SHA-256 file.
