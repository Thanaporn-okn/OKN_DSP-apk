# OKN_DSP v2 Android build correction

## Failure received from v1
The release build failed in `:flutter_blue_plus_android:checkReleaseAarMetadata` because the plugin module was compiled against Android API 33 while resolved AndroidX libraries required compile API 34 or later.

The `Caught exception: Already watching path: .../android` line is a Gradle filesystem-watcher message and was not the AAR-metadata failure that stopped this build. v2 disables Gradle VFS watching in CI so this message should not distract from real build errors.

## v2 correction
1. `flutter_blue_plus` is updated from `1.35.5` to pinned `1.36.8`. The upstream 1.35.10 change made Android use the project/user-provided compile SDK, removing the older API-33 limitation.
2. CI is pinned to Flutter `3.44.8` instead of a moving `stable` toolchain.
3. The generated Android app is explicitly patched to `compileSdk = 36` and `targetSdk = 36` before dependency resolution/build.
4. The workflow verifies the patched Android build file and records Flutter/Java information in the build log before compiling.

No UI layout, DSP controls, BLE UUID, or no-guess protocol boundary was changed in this build-fix version.
