OKN_DSP v2 - Sources integrity folder

This folder is intentionally included inside the source ZIP.
- PROTOCOL_NOTES.md: verified BLE facts and the no-guess packet boundary.
- UI_CONTROL_MAP.csv: controls represented by the five supplied UI screens.
- UI_REFERENCE_SHA256.txt: SHA-256 hashes of the five supplied reference images.
- WORKFLOW_SHA256.txt: SHA-256 of the separately delivered GitHub Actions workflow.
- BUILD_FIX_V2.md: exact build failure cause and v2 correction.
- SHA256SUMS.txt: SHA-256 manifest for all files in this source package except the manifest itself.

During a successful GitHub Actions release build, the workflow also creates:
- Sources/APK_SHA256.txt
and uploads the release APK together with its APK_SHA256.txt artifact.
