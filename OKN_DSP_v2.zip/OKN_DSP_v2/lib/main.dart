import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  runApp(const OknDspApp());
}

class OknDspApp extends StatefulWidget {
  const OknDspApp({super.key});

  @override
  State<OknDspApp> createState() => _OknDspAppState();
}

class _OknDspAppState extends State<OknDspApp> {
  late final DspController controller;

  @override
  void initState() {
    super.initState();
    controller = DspController()..initialize();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'OKN_DSP',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: AppColors.bg,
        colorScheme: const ColorScheme.dark(
          primary: AppColors.cyan,
          secondary: AppColors.blue,
          surface: AppColors.panel,
        ),
        useMaterial3: true,
      ),
      home: AnimatedBuilder(
        animation: controller,
        builder: (context, _) => DspShell(controller: controller),
      ),
    );
  }
}

class AppColors {
  static const bg = Color(0xFF00111F);
  static const bg2 = Color(0xFF001A2D);
  static const panel = Color(0xFF062540);
  static const panel2 = Color(0xFF041C32);
  static const border = Color(0xFF0B5A92);
  static const blue = Color(0xFF0B78FF);
  static const cyan = Color(0xFF00E8FF);
  static const green = Color(0xFF00F47A);
  static const orange = Color(0xFFFF9D25);
  static const yellow = Color(0xFFFFDF2C);
  static const pink = Color(0xFFFF3B6D);
  static const magenta = Color(0xFFE93DFF);
  static const purple = Color(0xFFAF40FF);
  static const white = Color(0xFFF7FAFF);
  static const muted = Color(0xFF9BC3E5);
  static const track = Color(0xFF244E70);
}

const channelNames = <String>[
  'Front L',
  'Front R',
  'Rear L',
  'Rear R',
  'Center',
  'Sub L',
  'Sub R',
];

const channelColors = <Color>[
  Color(0xFF19C9FF),
  Color(0xFFFF9D25),
  Color(0xFF00F47A),
  Color(0xFFFF4FD5),
  Color(0xFFECEFF4),
  Color(0xFFB13DFF),
  Color(0xFF18D6F5),
];

enum DspPage { home, eq, crossover, delay, output }

class EqBand {
  EqBand({
    required this.type,
    required this.frequency,
    required this.gain,
    required this.q,
    this.enabled = true,
  });

  String type;
  double frequency;
  double gain;
  double q;
  bool enabled;
}

class DspController extends ChangeNotifier {
  static final Guid knownUuid = Guid('0000ab01-0000-1000-8000-00805f9b34fb');

  DspPage page = DspPage.home;
  int selectedChannel = 0;
  bool initialized = false;

  double masterVolume = -3.0;
  double bassVolume = 4.0;
  double bassCutoff = 100.0;
  double bassBoost = 3.0;
  double middleBoost = -2.0;
  double trebleBoost = 1.0;
  String audioSource = 'High Level (Speaker)';
  String systemPreset = 'Flat';

  final List<List<EqBand>> eqByChannel = List.generate(
    7,
    (_) => <EqBand>[
      EqBand(type: 'PEQ', frequency: 32, gain: -3, q: .70),
      EqBand(type: 'Low Shelf', frequency: 100, gain: 2.5, q: 1.00),
      EqBand(type: 'PEQ', frequency: 200, gain: 6, q: 1.20),
      EqBand(type: 'PEQ', frequency: 500, gain: -4, q: 1.00),
      EqBand(type: 'PEQ', frequency: 2000, gain: 3, q: 1.00),
      EqBand(type: 'High Shelf', frequency: 10000, gain: -2, q: .70),
      EqBand(type: 'PEQ', frequency: 12500, gain: 0, q: 1.00),
      EqBand(type: 'PEQ', frequency: 16000, gain: 0, q: 1.00),
      EqBand(type: 'PEQ', frequency: 63, gain: 0, q: 1.00),
      EqBand(type: 'PEQ', frequency: 125, gain: 0, q: 1.00),
      EqBand(type: 'PEQ', frequency: 250, gain: 0, q: 1.00),
      EqBand(type: 'PEQ', frequency: 1000, gain: 0, q: 1.00),
      EqBand(type: 'PEQ', frequency: 4000, gain: 0, q: 1.00),
      EqBand(type: 'PEQ', frequency: 8000, gain: 0, q: 1.00),
      EqBand(type: 'PEQ', frequency: 18000, gain: 0, q: 1.00),
    ],
  );
  int eqGroup = 0;
  String eqPreset = 'Custom 1';
  String crossoverDisplay = 'Magnitude';

  final List<double> hpfFrequency = List.filled(7, 100.0);
  final List<double> lpfFrequency = List.filled(7, 1000.0);
  final List<bool> hpfBypass = List.filled(7, false);
  final List<bool> lpfBypass = List.filled(7, false);
  final List<String> hpfType = List.filled(7, 'Linkwitz-Riley');
  final List<String> lpfType = List.filled(7, 'Linkwitz-Riley');
  final List<String> hpfSlope = List.filled(7, '24 dB/Oct');
  final List<String> lpfSlope = List.filled(7, '24 dB/Oct');
  int phase = 0;
  bool polarityNormal = true;
  bool linkLr = true;
  String outputMode = 'Stereo';

  final List<double> delaysMs = <double>[0.0, 1.25, 2.60, 2.30, 0.80, 3.10, 1.90];
  bool delayUnitMs = true;
  String seatPreset = 'Driver (Left)';

  double masterOutput = -1.0;
  final List<double> outputLevels = <double>[-3.0, -2.5, -4.0, -1.0, -2.0, -3.5, -4.5];
  final List<bool> muted = List.filled(7, false);
  final List<bool> solo = List.filled(7, false);
  final List<bool> phaseInvert = List.filled(7, false);
  final List<bool> linked = <bool>[true, true, false, false, false, false, false];

  final List<ScanResult> scanResults = <ScanResult>[];
  BluetoothDevice? connectedDevice;
  BluetoothCharacteristic? writableCharacteristic;
  bool scanning = false;
  bool connecting = false;
  String bleStatus = 'Disconnected';
  String deviceName = 'DSP-7900';
  StreamSubscription<List<ScanResult>>? _scanSub;
  StreamSubscription<BluetoothConnectionState>? _connectionSub;
  SharedPreferences? _prefs;

  Future<void> initialize() async {
    await _load();
    initialized = true;
    notifyListeners();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    _prefs = prefs;
    masterVolume = prefs.getDouble('masterVolume') ?? masterVolume;
    bassVolume = prefs.getDouble('bassVolume') ?? bassVolume;
    bassCutoff = prefs.getDouble('bassCutoff') ?? bassCutoff;
    bassBoost = prefs.getDouble('bassBoost') ?? bassBoost;
    middleBoost = prefs.getDouble('middleBoost') ?? middleBoost;
    trebleBoost = prefs.getDouble('trebleBoost') ?? trebleBoost;
    masterOutput = prefs.getDouble('masterOutput') ?? masterOutput;
    for (var i = 0; i < 7; i++) {
      outputLevels[i] = prefs.getDouble('output_$i') ?? outputLevels[i];
      delaysMs[i] = prefs.getDouble('delay_$i') ?? delaysMs[i];
    }
  }

  Future<void> _saveDouble(String key, double value) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    _prefs = prefs;
    await prefs.setDouble(key, value);
  }

  void setPage(DspPage value) {
    page = value;
    notifyListeners();
  }

  void refresh() => notifyListeners();

  void selectChannel(int index) {
    selectedChannel = index.clamp(0, 6).toInt();
    notifyListeners();
  }

  void setMasterVolume(double value) {
    masterVolume = value;
    notifyListeners();
    _saveDouble('masterVolume', value);
    _sendParameter('MASTER_VOLUME', value);
  }

  void setBassVolume(double value) {
    bassVolume = value;
    notifyListeners();
    _saveDouble('bassVolume', value);
    _sendParameter('BASS_VOLUME', value);
  }

  void setBassCutoff(double value) {
    bassCutoff = value;
    notifyListeners();
    _saveDouble('bassCutoff', value);
    _sendParameter('BASS_CUTOFF', value);
  }

  void setBassBoost(double value) {
    bassBoost = value;
    notifyListeners();
    _saveDouble('bassBoost', value);
    _sendParameter('BASS_BOOST', value);
  }

  void setMiddleBoost(double value) {
    middleBoost = value;
    notifyListeners();
    _saveDouble('middleBoost', value);
    _sendParameter('MIDDLE_BOOST', value);
  }

  void setTrebleBoost(double value) {
    trebleBoost = value;
    notifyListeners();
    _saveDouble('trebleBoost', value);
    _sendParameter('TREBLE_BOOST', value);
  }

  void setEqGroup(int value) {
    eqGroup = value;
    notifyListeners();
  }

  void updateEqBand(int index, {String? type, double? frequency, double? gain, double? q, bool? enabled}) {
    final band = eqByChannel[selectedChannel][index];
    if (type != null) band.type = type;
    if (frequency != null) band.frequency = frequency;
    if (gain != null) band.gain = gain;
    if (q != null) band.q = q;
    if (enabled != null) band.enabled = enabled;
    notifyListeners();
    _sendEq(index, band);
  }

  void resetEq() {
    final defaults = <EqBand>[
      EqBand(type: 'PEQ', frequency: 32, gain: -3, q: .70),
      EqBand(type: 'Low Shelf', frequency: 100, gain: 2.5, q: 1.00),
      EqBand(type: 'PEQ', frequency: 200, gain: 6, q: 1.20),
      EqBand(type: 'PEQ', frequency: 500, gain: -4, q: 1.00),
      EqBand(type: 'PEQ', frequency: 2000, gain: 3, q: 1.00),
      EqBand(type: 'High Shelf', frequency: 10000, gain: -2, q: .70),
    ];
    for (var i = 0; i < defaults.length; i++) {
      eqByChannel[selectedChannel][i] = defaults[i];
    }
    notifyListeners();
  }


  Future<void> saveEqPreset() async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    _prefs = prefs;
    final payload = eqByChannel[selectedChannel]
        .map((b) => <String, dynamic>{
              'type': b.type,
              'frequency': b.frequency,
              'gain': b.gain,
              'q': b.q,
              'enabled': b.enabled,
            })
        .toList();
    await prefs.setString('eqPreset_${eqPreset}_$selectedChannel', jsonEncode(payload));
  }

  Future<void> selectEqPreset(String name) async {
    eqPreset = name;
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    _prefs = prefs;
    final raw = prefs.getString('eqPreset_${name}_$selectedChannel');
    if (raw != null) {
      try {
        final decoded = jsonDecode(raw) as List<dynamic>;
        for (var i = 0; i < decoded.length && i < eqByChannel[selectedChannel].length; i++) {
          final item = decoded[i] as Map<String, dynamic>;
          eqByChannel[selectedChannel][i] = EqBand(
            type: item['type'] as String? ?? 'PEQ',
            frequency: (item['frequency'] as num? ?? 100).toDouble(),
            gain: (item['gain'] as num? ?? 0).toDouble(),
            q: (item['q'] as num? ?? 1).toDouble(),
            enabled: item['enabled'] as bool? ?? true,
          );
        }
      } catch (_) {}
    }
    notifyListeners();
  }

  void resetCrossover() {
    final ch = selectedChannel;
    hpfFrequency[ch] = 100.0;
    lpfFrequency[ch] = 1000.0;
    hpfBypass[ch] = false;
    lpfBypass[ch] = false;
    hpfType[ch] = 'Linkwitz-Riley';
    lpfType[ch] = 'Linkwitz-Riley';
    hpfSlope[ch] = '24 dB/Oct';
    lpfSlope[ch] = '24 dB/Oct';
    notifyListeners();
  }

  void setHpfFrequency(double value) {
    hpfFrequency[selectedChannel] = value;
    notifyListeners();
    _sendParameter('HPF_FREQ_CH${selectedChannel + 1}', value);
  }

  void setLpfFrequency(double value) {
    lpfFrequency[selectedChannel] = value;
    notifyListeners();
    _sendParameter('LPF_FREQ_CH${selectedChannel + 1}', value);
  }

  void setDelay(int channel, double value) {
    delaysMs[channel] = value;
    notifyListeners();
    _saveDouble('delay_$channel', value);
    _sendParameter('DELAY_CH${channel + 1}', value);
  }

  void syncDelayChannels() {
    final value = delaysMs[selectedChannel];
    for (var i = 0; i < delaysMs.length; i++) {
      delaysMs[i] = value;
    }
    notifyListeners();
  }

  void setMasterOutput(double value) {
    masterOutput = value;
    notifyListeners();
    _saveDouble('masterOutput', value);
    _sendParameter('MASTER_OUTPUT', value);
  }

  void setOutputLevel(int channel, double value) {
    outputLevels[channel] = value;
    notifyListeners();
    _saveDouble('output_$channel', value);
    _sendParameter('OUTPUT_CH${channel + 1}', value);
  }

  void resetOutputLevels() {
    masterOutput = -1.0;
    const defaults = <double>[-3.0, -2.5, -4.0, -1.0, -2.0, -3.5, -4.5];
    for (var i = 0; i < 7; i++) {
      outputLevels[i] = defaults[i];
      muted[i] = false;
      solo[i] = false;
      phaseInvert[i] = false;
    }
    notifyListeners();
  }

  void allMuteOff() {
    for (var i = 0; i < muted.length; i++) {
      muted[i] = false;
    }
    notifyListeners();
  }

  Future<void> requestBlePermissions() async {
    await <Permission>[
      Permission.bluetoothScan,
      Permission.bluetoothConnect,
      Permission.locationWhenInUse,
    ].request();
  }

  Future<void> scan() async {
    if (scanning) return;
    await requestBlePermissions();
    scanResults.clear();
    scanning = true;
    bleStatus = 'Scanning...';
    notifyListeners();

    await _scanSub?.cancel();
    _scanSub = FlutterBluePlus.scanResults.listen((results) {
      scanResults
        ..clear()
        ..addAll(results.where((r) {
          final name = r.device.platformName.toLowerCase();
          return name.contains('dsp') || r.advertisementData.advName.toLowerCase().contains('dsp') || r.advertisementData.serviceUuids.any((u) => u.toString().toLowerCase() == knownUuid.toString().toLowerCase());
        }));
      if (scanResults.isEmpty) {
        scanResults.addAll(results);
      }
      notifyListeners();
    });

    try {
      await FlutterBluePlus.startScan(timeout: const Duration(seconds: 7));
      await FlutterBluePlus.isScanning.where((value) => value == false).first;
    } catch (e) {
      bleStatus = 'Scan error';
    } finally {
      scanning = false;
      if (connectedDevice == null && bleStatus != 'Scan error') bleStatus = 'Disconnected';
      notifyListeners();
    }
  }

  Future<void> connect(BluetoothDevice device) async {
    if (connecting) return;
    connecting = true;
    bleStatus = 'Connecting...';
    notifyListeners();
    try {
      await FlutterBluePlus.stopScan();
      await connectedDevice?.disconnect();
      await device.connect(timeout: const Duration(seconds: 12), autoConnect: false);
      connectedDevice = device;
      deviceName = device.platformName.isNotEmpty ? device.platformName : 'DSP-7900';
      writableCharacteristic = await _findWritableCharacteristic(device);
      bleStatus = 'Connected';
      await _connectionSub?.cancel();
      _connectionSub = device.connectionState.listen((state) {
        if (state == BluetoothConnectionState.disconnected) {
          connectedDevice = null;
          writableCharacteristic = null;
          bleStatus = 'Disconnected';
          notifyListeners();
        }
      });
    } catch (e) {
      connectedDevice = null;
      writableCharacteristic = null;
      bleStatus = 'Connect error';
    } finally {
      connecting = false;
      notifyListeners();
    }
  }

  Future<BluetoothCharacteristic?> _findWritableCharacteristic(BluetoothDevice device) async {
    final services = await device.discoverServices();
    BluetoothCharacteristic? fallback;
    for (final service in services) {
      for (final c in service.characteristics) {
        final writable = c.properties.write || c.properties.writeWithoutResponse;
        if (!writable) continue;
        fallback ??= c;
        if (c.uuid == knownUuid || service.uuid == knownUuid) return c;
      }
    }
    return fallback;
  }

  Future<void> disconnect() async {
    await connectedDevice?.disconnect();
    connectedDevice = null;
    writableCharacteristic = null;
    bleStatus = 'Disconnected';
    notifyListeners();
  }

  Future<void> _sendParameter(String key, double value) async {
    // Immediate UI state is always applied. The target DSP packet protocol is
    // still unknown from the available captures, so no guessed payload is sent.
    // Once real command bytes are identified, replace _encodeVerifiedPacket.
    final characteristic = writableCharacteristic;
    final packet = _encodeVerifiedPacket(key, value);
    if (characteristic == null || packet == null) return;
    try {
      await characteristic.write(
        packet,
        withoutResponse: characteristic.properties.writeWithoutResponse,
      );
    } catch (_) {
      // Keep UI responsive; connection state will surface transport problems.
    }
  }

  Future<void> _sendEq(int index, EqBand band) async {
    final characteristic = writableCharacteristic;
    final packet = _encodeVerifiedEqPacket(index, band);
    if (characteristic == null || packet == null) return;
    try {
      await characteristic.write(
        packet,
        withoutResponse: characteristic.properties.writeWithoutResponse,
      );
    } catch (_) {}
  }

  Uint8List? _encodeVerifiedPacket(String key, double value) => null;

  Uint8List? _encodeVerifiedEqPacket(int index, EqBand band) => null;

  @override
  void dispose() {
    _scanSub?.cancel();
    _connectionSub?.cancel();
    super.dispose();
  }
}

class DspShell extends StatelessWidget {
  const DspShell({super.key, required this.controller});
  final DspController controller;

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.sizeOf(context);
    final maxWidth = size.width >= 900 ? 960.0 : size.width;
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SizedBox(
            width: maxWidth,
            child: Column(
              children: [
                _Header(controller: controller),
                if (controller.page != DspPage.home) _ChannelTabs(controller: controller),
                Expanded(child: _buildPage()),
                _BottomNav(controller: controller),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPage() {
    switch (controller.page) {
      case DspPage.home:
        return HomePage(controller: controller);
      case DspPage.eq:
        return EqPage(controller: controller);
      case DspPage.crossover:
        return CrossoverPage(controller: controller);
      case DspPage.delay:
        return DelayPage(controller: controller);
      case DspPage.output:
        return OutputPage(controller: controller);
    }
  }
}

class _Header extends StatelessWidget {
  const _Header({required this.controller});
  final DspController controller;

  @override
  Widget build(BuildContext context) {
    final isHome = controller.page == DspPage.home;
    final compact = MediaQuery.sizeOf(context).width < 600;
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 14, 16, 10),
      child: Row(
        children: [
          _WaveLogo(size: compact ? 46 : 58),
          SizedBox(width: compact ? 8 : 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  isHome ? 'OKN_DSP' : 'DSP Control',
                  style: TextStyle(fontSize: compact ? 22 : 30, fontWeight: FontWeight.w700, letterSpacing: .2),
                ),
                const Text(
                  'Professional Audio Processor',
                  style: TextStyle(color: AppColors.muted, fontSize: 14),
                ),
              ],
            ),
          ),
          InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: () => _showBleSheet(context),
            child: Container(
              width: compact ? 126 : 150,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: AppColors.panel2,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: AppColors.border),
                boxShadow: const [BoxShadow(color: Color(0x330078FF), blurRadius: 16)],
              ),
              child: Row(
                children: [
                  Container(
                    width: 13,
                    height: 13,
                    decoration: BoxDecoration(
                      color: controller.connectedDevice != null ? AppColors.green : const Color(0xFF607D8B),
                      shape: BoxShape.circle,
                      boxShadow: controller.connectedDevice != null
                          ? const [BoxShadow(color: AppColors.green, blurRadius: 10)]
                          : null,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          controller.connectedDevice != null ? 'Connected' : controller.bleStatus,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: controller.connectedDevice != null ? AppColors.green : AppColors.muted,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        Text(controller.deviceName, style: const TextStyle(color: AppColors.muted, fontSize: 12)),
                      ],
                    ),
                  ),
                  const Icon(Icons.chevron_right, color: AppColors.muted),
                ],
              ),
            ),
          ),
          const SizedBox(width: 10),
          IconButton(
            onPressed: () => _showBleSheet(context),
            icon: Icon(Icons.settings_outlined, size: compact ? 27 : 32, color: const Color(0xFFC8E5FF)),
          ),
        ],
      ),
    );
  }

  void _showBleSheet(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppColors.panel2,
      isScrollControlled: true,
      builder: (context) => AnimatedBuilder(
        animation: controller,
        builder: (context, _) {
          return SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      const Expanded(
                        child: Text('DSP Bluetooth', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
                      ),
                      if (controller.connectedDevice != null)
                        TextButton(onPressed: controller.disconnect, child: const Text('Disconnect')),
                    ],
                  ),
                  const SizedBox(height: 8),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: controller.scanning ? null : controller.scan,
                      icon: controller.scanning
                          ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                          : const Icon(Icons.bluetooth_searching),
                      label: Text(controller.scanning ? 'Scanning...' : 'Scan for DSP'),
                    ),
                  ),
                  const SizedBox(height: 12),
                  ConstrainedBox(
                    constraints: const BoxConstraints(maxHeight: 360),
                    child: ListView.separated(
                      shrinkWrap: true,
                      itemCount: controller.scanResults.length,
                      separatorBuilder: (_, __) => const Divider(height: 1, color: Color(0x223FA9FF)),
                      itemBuilder: (context, index) {
                        final result = controller.scanResults[index];
                        final name = result.device.platformName.isNotEmpty
                            ? result.device.platformName
                            : (result.advertisementData.advName.isNotEmpty ? result.advertisementData.advName : 'BLE Device');
                        return ListTile(
                          leading: const Icon(Icons.memory, color: AppColors.cyan),
                          title: Text(name),
                          subtitle: Text('${result.device.remoteId}   RSSI ${result.rssi} dBm'),
                          trailing: const Icon(Icons.chevron_right),
                          onTap: () async {
                            await controller.connect(result.device);
                            if (context.mounted && controller.connectedDevice != null) Navigator.pop(context);
                          },
                        );
                      },
                    ),
                  ),
                  if (controller.scanResults.isEmpty)
                    const Padding(
                      padding: EdgeInsets.only(top: 12),
                      child: Text('Tap Scan for DSP to find nearby devices.', style: TextStyle(color: AppColors.muted)),
                    ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class _ChannelTabs extends StatelessWidget {
  const _ChannelTabs({required this.controller});
  final DspController controller;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 72,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 7),
        scrollDirection: Axis.horizontal,
        itemCount: 7,
        separatorBuilder: (_, __) => const SizedBox(width: 7),
        itemBuilder: (context, index) {
          final selected = controller.selectedChannel == index;
          return InkWell(
            onTap: () => controller.selectChannel(index),
            borderRadius: BorderRadius.circular(9),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 110),
              width: 104,
              decoration: BoxDecoration(
                gradient: selected
                    ? const LinearGradient(colors: [Color(0xFF0B4FFF), Color(0xFF00DAFF)], begin: Alignment.topLeft, end: Alignment.bottomRight)
                    : const LinearGradient(colors: [Color(0xFF08233B), Color(0xFF072036)]),
                borderRadius: BorderRadius.circular(9),
                border: Border.all(color: selected ? AppColors.cyan : AppColors.border),
                boxShadow: selected ? const [BoxShadow(color: Color(0x6600BFFF), blurRadius: 16)] : null,
              ),
              alignment: Alignment.center,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('CH${index + 1}', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
                  Text(channelNames[index], style: const TextStyle(fontSize: 12, color: Color(0xFFDCEEFF))),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class _BottomNav extends StatelessWidget {
  const _BottomNav({required this.controller});
  final DspController controller;

  static const items = <(DspPage, IconData, String)>[
    (DspPage.home, Icons.home_rounded, 'Home'),
    (DspPage.eq, Icons.graphic_eq_rounded, 'EQ'),
    (DspPage.crossover, Icons.multiline_chart_rounded, 'Crossover'),
    (DspPage.delay, Icons.schedule_rounded, 'Delay'),
    (DspPage.output, Icons.bar_chart_rounded, 'Output'),
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(18, 8, 18, 10),
      height: 78,
      decoration: BoxDecoration(
        color: AppColors.panel2,
        border: Border.all(color: AppColors.border),
        borderRadius: BorderRadius.circular(15),
      ),
      child: Row(
        children: [
          for (final item in items)
            Expanded(
              child: InkWell(
                onTap: () => controller.setPage(item.$1),
                borderRadius: BorderRadius.circular(12),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 120),
                  margin: const EdgeInsets.all(5),
                  decoration: BoxDecoration(
                    gradient: controller.page == item.$1
                        ? const LinearGradient(colors: [Color(0xFF093D9B), Color(0xFF066BFF)], begin: Alignment.topCenter, end: Alignment.bottomCenter)
                        : null,
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: controller.page == item.$1 ? const [BoxShadow(color: Color(0x66006EFF), blurRadius: 15)] : null,
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(item.$2, color: controller.page == item.$1 ? AppColors.cyan : const Color(0xFFC7E1FA), size: 30),
                      const SizedBox(height: 3),
                      Text(item.$3, style: TextStyle(color: controller.page == item.$1 ? AppColors.white : AppColors.muted, fontSize: 13)),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key, required this.controller});
  final DspController controller;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(18, 2, 18, 8),
      child: Column(
        children: [
          _HomeSliderCard(
            icon: Icons.volume_up_rounded,
            iconColor: AppColors.blue,
            title: 'Master Volume',
            subtitle: 'ปรับระดับเสียงรวม',
            value: controller.masterVolume,
            min: -60,
            max: 12,
            valueText: '${controller.masterVolume.toStringAsFixed(1)} dB',
            labels: const ['-60', '-40', '-20', '0', '+12'],
            onChanged: controller.setMasterVolume,
          ),
          _HomeSliderCard(
            icon: Icons.album_rounded,
            iconColor: AppColors.cyan,
            title: 'Bass Volume',
            subtitle: 'ปรับระดับเสียงเบส',
            value: controller.bassVolume,
            min: -12,
            max: 12,
            valueText: '${controller.bassVolume.toStringAsFixed(1)} dB',
            labels: const ['-12', '-6', '0', '+6', '+12'],
            onChanged: controller.setBassVolume,
          ),
          _HomeSliderCard(
            icon: Icons.call_split_rounded,
            iconColor: AppColors.magenta,
            title: 'Bass Cutoff',
            subtitle: 'ตั้งค่าความถี่ตัดเบส',
            value: controller.bassCutoff,
            min: 20,
            max: 500,
            valueText: '${controller.bassCutoff.round()} Hz',
            labels: const ['20', '50', '100', '200', '500'],
            onChanged: controller.setBassCutoff,
          ),
          _HomeSliderCard(
            icon: Icons.equalizer_rounded,
            iconColor: AppColors.pink,
            title: 'Bass Boost',
            subtitle: 'เพิ่มความหนักแน่นของเบส',
            value: controller.bassBoost,
            min: -10,
            max: 12,
            valueText: '${controller.bassBoost.toStringAsFixed(1)} dB',
            labels: const ['-10', '-6', '0', '+6', '+12'],
            onChanged: controller.setBassBoost,
          ),
          _HomeSliderCard(
            icon: Icons.multiline_chart_rounded,
            iconColor: AppColors.blue,
            title: 'Middle Boost',
            subtitle: 'เพิ่มความชัดเจนย่านกลาง',
            value: controller.middleBoost,
            min: -12,
            max: 12,
            valueText: '${controller.middleBoost.toStringAsFixed(1)} dB',
            labels: const ['-12', '-6', '0', '+6', '+12'],
            onChanged: controller.setMiddleBoost,
          ),
          _HomeSliderCard(
            icon: Icons.auto_awesome_rounded,
            iconColor: AppColors.magenta,
            title: 'Treble Boost',
            subtitle: 'เพิ่มความใสย่านแหลม',
            value: controller.trebleBoost,
            min: -12,
            max: 12,
            valueText: '${controller.trebleBoost.toStringAsFixed(1)} dB',
            labels: const ['-12', '-6', '0', '+6', '+12'],
            onChanged: controller.setTrebleBoost,
          ),
          const SizedBox(height: 3),
          LayoutBuilder(
            builder: (context, constraints) {
              final twoCol = constraints.maxWidth >= 680;
              final left = Column(
                children: [
                  _SelectCard(
                    icon: Icons.music_note_rounded,
                    title: 'Audio Source',
                    subtitle: 'แหล่งสัญญาณเสียง',
                    value: controller.audioSource,
                    values: const ['High Level (Speaker)', 'Low Level (RCA)', 'Bluetooth'],
                    onChanged: (v) {
                      controller.audioSource = v;
                      controller.refresh();
                    },
                  ),
                  _SelectCard(
                    icon: Icons.menu_rounded,
                    title: 'System Preset',
                    subtitle: 'พรีเซ็ตระบบ',
                    value: controller.systemPreset,
                    values: const ['Flat', 'Music', 'Vocal', 'Bass', 'Custom 1'],
                    onChanged: (v) {
                      controller.systemPreset = v;
                      controller.refresh();
                    },
                  ),
                ],
              );
              final status = _DeviceStatusCard(controller: controller);
              if (twoCol) {
                return Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [Expanded(child: left), const SizedBox(width: 12), Expanded(child: status)],
                );
              }
              return Column(children: [left, status]);
            },
          ),
        ],
      ),
    );
  }
}

class _HomeSliderCard extends StatelessWidget {
  const _HomeSliderCard({
    required this.icon,
    required this.iconColor,
    required this.title,
    required this.subtitle,
    required this.value,
    required this.min,
    required this.max,
    required this.valueText,
    required this.labels,
    required this.onChanged,
  });

  final IconData icon;
  final Color iconColor;
  final String title;
  final String subtitle;
  final double value;
  final double min;
  final double max;
  final String valueText;
  final List<String> labels;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context) {
    return _GlassCard(
      margin: const EdgeInsets.only(bottom: 10),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final compact = constraints.maxWidth < 650;
          return Row(
            children: [
              _GlowIcon(icon: icon, color: iconColor, size: compact ? 50 : 72),
              const SizedBox(width: 14),
              SizedBox(
                width: compact ? 120 : 190,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: compact ? 17 : 23, fontWeight: FontWeight.w700)),
                    Text(subtitle, style: const TextStyle(color: AppColors.muted, fontSize: 14)),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  children: [
                    SliderTheme(
                      data: SliderTheme.of(context).copyWith(
                        activeTrackColor: iconColor,
                        inactiveTrackColor: AppColors.track,
                        thumbColor: Colors.white,
                        overlayColor: iconColor.withValues(alpha: .14),
                        trackHeight: 10,
                        thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 15),
                      ),
                      child: Slider(value: value.clamp(min, max).toDouble(), min: min, max: max, onChanged: onChanged),
                    ),
                    _ScaleLabels(labels: labels),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Container(
                width: compact ? 102 : 118,
                padding: const EdgeInsets.symmetric(vertical: 14),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: const Color(0xFF061D32),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: const Color(0xFF31577A)),
                ),
                child: Text(valueText, style: TextStyle(fontSize: compact ? 15 : 21, fontWeight: FontWeight.w600)),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _ScaleLabels extends StatelessWidget {
  const _ScaleLabels({required this.labels});
  final List<String> labels;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: labels.map((e) => Text(e, style: const TextStyle(color: AppColors.muted, fontSize: 12))).toList(),
      ),
    );
  }
}

class _SelectCard extends StatelessWidget {
  const _SelectCard({required this.icon, required this.title, required this.subtitle, required this.value, required this.values, required this.onChanged});
  final IconData icon;
  final String title;
  final String subtitle;
  final String value;
  final List<String> values;
  final ValueChanged<String> onChanged;

  @override
  Widget build(BuildContext context) {
    return _GlassCard(
      margin: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          _SquareIcon(icon: icon),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                Text(subtitle, style: const TextStyle(color: AppColors.muted, fontSize: 13)),
                const SizedBox(height: 8),
                _DropdownBox(value: value, values: values, onChanged: onChanged),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _DeviceStatusCard extends StatelessWidget {
  const _DeviceStatusCard({required this.controller});
  final DspController controller;

  @override
  Widget build(BuildContext context) {
    return _GlassCard(
      margin: const EdgeInsets.only(bottom: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              _SquareIcon(icon: Icons.memory_rounded),
              SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Device Status', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                  Text('สถานะอุปกรณ์', style: TextStyle(color: AppColors.muted, fontSize: 13)),
                ],
              ),
            ],
          ),
          const SizedBox(height: 10),
          _StatusRow(icon: Icons.circle, iconColor: controller.connectedDevice != null ? AppColors.green : const Color(0xFF607D8B), label: controller.bleStatus, value: controller.deviceName),
          const _StatusRow(icon: Icons.battery_5_bar, iconColor: AppColors.green, label: 'Voltage', value: '13.6 V'),
          const _StatusRow(icon: Icons.device_thermostat, iconColor: AppColors.cyan, label: 'Temperature', value: '42 °C'),
          const _StatusRow(icon: Icons.check_circle_outline, iconColor: AppColors.cyan, label: 'System', value: 'Normal', valueColor: AppColors.green),
        ],
      ),
    );
  }
}

class _StatusRow extends StatelessWidget {
  const _StatusRow({required this.icon, required this.iconColor, required this.label, required this.value, this.valueColor});
  final IconData icon;
  final Color iconColor;
  final String label;
  final String value;
  final Color? valueColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 9),
      decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: Color(0x223CA2E8)))),
      child: Row(
        children: [
          Icon(icon, color: iconColor, size: 22),
          const SizedBox(width: 12),
          Expanded(child: Text(label, style: const TextStyle(color: Color(0xFFDCEEFF)))),
          Text(value, style: TextStyle(color: valueColor ?? AppColors.muted)),
        ],
      ),
    );
  }
}

class EqPage extends StatelessWidget {
  const EqPage({super.key, required this.controller});
  final DspController controller;

  @override
  Widget build(BuildContext context) {
    final bands = controller.eqByChannel[controller.selectedChannel];
    final start = controller.eqGroup == 0 ? 0 : (controller.eqGroup == 1 ? 6 : 12);
    final end = math.min(start + (controller.eqGroup == 2 ? 3 : 6), bands.length).toInt();
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(18, 4, 18, 6),
      child: Column(
        children: [
          _GlassCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                LayoutBuilder(
                  builder: (context, constraints) {
                    final compact = constraints.maxWidth < 650;
                    final title = const Row(
                      children: [
                        _WaveLogo(size: 56),
                        SizedBox(width: 12),
                        Expanded(
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text('Parametric EQ', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w700)),
                            Text('ปรับแต่งความถี่เสียงอย่างละเอียด', style: TextStyle(color: AppColors.muted, fontSize: 15)),
                          ]),
                        ),
                      ],
                    );
                    final channelSelect = _DropdownBox(
                      value: 'CH${controller.selectedChannel + 1} - ${channelNames[controller.selectedChannel]}',
                      values: List.generate(7, (i) => 'CH${i + 1} - ${channelNames[i]}'),
                      onChanged: (v) => controller.selectChannel(int.parse(v.substring(2, 3)) - 1),
                    );
                    final reset = OutlinedButton.icon(
                      onPressed: controller.resetEq,
                      icon: const Icon(Icons.refresh_rounded),
                      label: const Text('รีเซ็ต EQ'),
                      style: _outlineStyle(),
                    );
                    if (compact) {
                      return Column(
                        children: [
                          title,
                          const SizedBox(height: 10),
                          Row(children: [Expanded(child: channelSelect), const SizedBox(width: 10), reset]),
                        ],
                      );
                    }
                    return Row(
                      children: [
                        const _WaveLogo(size: 56),
                        const SizedBox(width: 12),
                        const Expanded(
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text('Parametric EQ', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w700)),
                            Text('ปรับแต่งความถี่เสียงอย่างละเอียด', style: TextStyle(color: AppColors.muted, fontSize: 15)),
                          ]),
                        ),
                        SizedBox(width: 170, child: channelSelect),
                        const SizedBox(width: 10),
                        reset,
                      ],
                    );
                  },
                ),
                const SizedBox(height: 12),
                SizedBox(height: 300, width: double.infinity, child: CustomPaint(painter: EqGraphPainter(bands: bands))),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(child: _SegmentButton(label: 'Bands 1 - 6', selected: controller.eqGroup == 0, onTap: () => controller.setEqGroup(0))),
              const SizedBox(width: 7),
              Expanded(child: _SegmentButton(label: 'Bands 7 - 12', selected: controller.eqGroup == 1, onTap: () => controller.setEqGroup(1))),
              const SizedBox(width: 7),
              Expanded(child: _SegmentButton(label: 'Bands 13 - 15', selected: controller.eqGroup == 2, onTap: () => controller.setEqGroup(2))),
            ],
          ),
          const SizedBox(height: 5),
          _GlassCard(
            child: LayoutBuilder(
              builder: (context, constraints) => SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: SizedBox(
                  width: constraints.maxWidth < 760 ? 760.0 : constraints.maxWidth,
                  child: Column(
                    children: [
                      const _EqHeaderRow(),
                      for (var i = start; i < end; i++) _EqBandRow(controller: controller, index: i, band: bands[i]),
                    ],
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 10),
          _GlassCard(
            child: LayoutBuilder(
              builder: (context, constraints) {
                final compact = constraints.maxWidth < 650;
                final save = _ActionTile(icon: Icons.save_rounded, label: 'Save', width: compact ? 78 : 110, height: compact ? 68 : 82, onTap: () async { await controller.saveEqPreset(); if (context.mounted) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Preset saved'))); } });
                final manage = _ActionTile(icon: Icons.description_outlined, label: 'Manage', width: compact ? 78 : 110, height: compact ? 68 : 82, onTap: () => _showPresetManager(context));
                if (compact) {
                  return Column(
                    children: [
                      const Row(children: [
                        _SquareIcon(icon: Icons.folder_open_rounded),
                        SizedBox(width: 14),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text('Preset', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                          Text('ชุดค่าที่ใช้งานอยู่', style: TextStyle(color: AppColors.muted)),
                        ])),
                      ]),
                      const SizedBox(height: 10),
                      Row(children: [
                        Expanded(child: _DropdownBox(value: controller.eqPreset, values: const ['Custom 1', 'Flat', 'Music', 'Vocal'], onChanged: controller.selectEqPreset)),
                        const SizedBox(width: 8),
                        save,
                        const SizedBox(width: 8),
                        manage,
                      ]),
                    ],
                  );
                }
                return Row(
                  children: [
                    const _SquareIcon(icon: Icons.folder_open_rounded),
                    const SizedBox(width: 14),
                    const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('Preset', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                      Text('ชุดค่าที่ใช้งานอยู่', style: TextStyle(color: AppColors.muted)),
                    ])),
                    SizedBox(width: 160, child: _DropdownBox(value: controller.eqPreset, values: const ['Custom 1', 'Flat', 'Music', 'Vocal'], onChanged: controller.selectEqPreset)),
                    const SizedBox(width: 12),
                    save,
                    const SizedBox(width: 10),
                    manage,
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  void _showPresetManager(BuildContext context) {
    const presets = ['Custom 1', 'Flat', 'Music', 'Vocal'];
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppColors.panel2,
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Preset Manager', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
              const SizedBox(height: 10),
              for (final preset in presets)
                ListTile(
                  leading: const Icon(Icons.folder_outlined, color: AppColors.cyan),
                  title: Text(preset),
                  trailing: preset == controller.eqPreset ? const Icon(Icons.check, color: AppColors.green) : null,
                  onTap: () async {
                    await controller.selectEqPreset(preset);
                    if (sheetContext.mounted) Navigator.pop(sheetContext);
                  },
                ),
              const Divider(color: Color(0x334CA7DE)),
              ListTile(
                leading: const Icon(Icons.restart_alt, color: AppColors.orange),
                title: const Text('Reset current EQ to reference values'),
                onTap: () {
                  controller.resetEq();
                  Navigator.pop(sheetContext);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class EqGraphPainter extends CustomPainter {
  EqGraphPainter({required this.bands});
  final List<EqBand> bands;

  static const graphColors = <Color>[
    Color(0xFFFF365F),
    Color(0xFFFF9D25),
    Color(0xFFFFE31B),
    Color(0xFF00F47A),
    Color(0xFF16E7F4),
    Color(0xFF2A78FF),
    Color(0xFF8D40FF),
    Color(0xFFFF4FD5),
  ];

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Rect.fromLTWH(42, 15, size.width - 55, size.height - 45);
    final grid = Paint()..color = const Color(0x33287AB6)..strokeWidth = 1;
    for (var i = 0; i <= 10; i++) {
      final x = rect.left + rect.width * i / 10;
      canvas.drawLine(Offset(x, rect.top), Offset(x, rect.bottom), grid);
    }
    for (var i = 0; i <= 6; i++) {
      final y = rect.top + rect.height * i / 6;
      canvas.drawLine(Offset(rect.left, y), Offset(rect.right, y), grid);
    }
    final axis = Paint()..color = const Color(0xFF8BB1CD)..strokeWidth = 1.2;
    canvas.drawRect(rect, axis..style = PaintingStyle.stroke);

    final points = <Offset>[];
    final active = bands.take(8).toList();
    for (var i = 0; i < active.length; i++) {
      final b = active[i];
      final x = rect.left + _logNorm(b.frequency, 20, 20000) * rect.width;
      final y = rect.top + ((12 - b.gain.clamp(-12, 12).toDouble()) / 24) * rect.height;
      points.add(Offset(x, y));
    }
    if (points.length > 1) {
      final path = Path()..moveTo(points.first.dx, points.first.dy);
      for (var i = 1; i < points.length; i++) {
        final p0 = points[i - 1];
        final p1 = points[i];
        final midX = (p0.dx + p1.dx) / 2;
        path.cubicTo(midX, p0.dy, midX, p1.dy, p1.dx, p1.dy);
      }
      final shadow = Paint()
        ..shader = const LinearGradient(colors: [Color(0x55FF3B6D), Color(0x5500E8FF), Color(0x55E93DFF)])
            .createShader(rect)
        ..strokeWidth = 14
        ..strokeCap = StrokeCap.round
        ..style = PaintingStyle.stroke
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 14);
      canvas.drawPath(path, shadow);
      final line = Paint()
        ..shader = const LinearGradient(colors: [Color(0xFFFF3B6D), Color(0xFFFFE31B), Color(0xFF00F47A), Color(0xFF00E8FF), Color(0xFFE93DFF)]).createShader(rect)
        ..strokeWidth = 3
        ..style = PaintingStyle.stroke;
      canvas.drawPath(path, line);
    }
    for (var i = 0; i < points.length; i++) {
      final c = graphColors[i % graphColors.length];
      canvas.drawCircle(points[i], 8, Paint()..color = c.withValues(alpha: .35)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8));
      canvas.drawCircle(points[i], 7, Paint()..color = c);
      canvas.drawCircle(points[i], 4.5, Paint()..color = AppColors.white);
    }

    final labels = <String>['20', '50', '100', '200', '500', '1k', '2k', '5k', '10k', '20k'];
    final freqs = <double>[20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000];
    for (var i = 0; i < labels.length; i++) {
      final x = rect.left + _logNorm(freqs[i], 20, 20000) * rect.width;
      _text(canvas, labels[i], Offset(x, rect.bottom + 8), center: true);
    }
    for (final db in <int>[12, 6, 0, -6, -12]) {
      final y = rect.top + ((12 - db) / 24) * rect.height;
      _text(canvas, db > 0 ? '+$db' : '$db', Offset(1, y - 7));
    }
    _text(canvas, 'dB', const Offset(2, 15));
    _text(canvas, 'Hz', Offset(rect.right - 2, rect.bottom + 8));
  }

  double _logNorm(double value, double min, double max) {
    final lMin = math.log(min);
    final lMax = math.log(max);
    return ((math.log(value.clamp(min, max)) - lMin) / (lMax - lMin)).clamp(0.0, 1.0).toDouble();
  }

  void _text(Canvas canvas, String text, Offset offset, {bool center = false}) {
    final painter = TextPainter(
      text: TextSpan(text: text, style: const TextStyle(color: Color(0xFFC7E0F5), fontSize: 12)),
      textDirection: TextDirection.ltr,
    )..layout();
    painter.paint(canvas, Offset(center ? offset.dx - painter.width / 2 : offset.dx, offset.dy));
  }

  @override
  bool shouldRepaint(covariant EqGraphPainter oldDelegate) => true;
}

class _EqHeaderRow extends StatelessWidget {
  const _EqHeaderRow();

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.fromLTRB(4, 0, 4, 8),
      child: Row(children: [
        SizedBox(width: 42, child: Text('#')),
        Expanded(flex: 16, child: Text('Type')),
        SizedBox(width: 8),
        Expanded(flex: 15, child: Text('Frequency')),
        SizedBox(width: 8),
        Expanded(flex: 13, child: Text('Gain')),
        SizedBox(width: 8),
        Expanded(flex: 12, child: Text('Q')),
        SizedBox(width: 8),
        SizedBox(width: 72, child: Text('Power')),
      ]),
    );
  }
}

class _EqBandRow extends StatelessWidget {
  const _EqBandRow({required this.controller, required this.index, required this.band});
  final DspController controller;
  final int index;
  final EqBand band;

  @override
  Widget build(BuildContext context) {
    final color = EqGraphPainter.graphColors[index % EqGraphPainter.graphColors.length];
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          SizedBox(width: 42, child: Row(children: [Container(width: 17, height: 17, decoration: BoxDecoration(color: color, shape: BoxShape.circle, boxShadow: [BoxShadow(color: color, blurRadius: 9)])), const SizedBox(width: 6), Text('${index + 1}')])) ,
          Expanded(
            flex: 16,
            child: _DropdownBox(
              dense: true,
              value: band.type,
              values: const ['PEQ', 'Low Shelf', 'High Shelf'],
              onChanged: (v) => controller.updateEqBand(index, type: v),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(flex: 15, child: _StepperBox(text: _formatFrequency(band.frequency), onMinus: () => controller.updateEqBand(index, frequency: (band.frequency / 1.08).clamp(20, 20000).toDouble()), onPlus: () => controller.updateEqBand(index, frequency: (band.frequency * 1.08).clamp(20, 20000).toDouble()))),
          const SizedBox(width: 8),
          Expanded(flex: 13, child: _StepperBox(text: '${band.gain.toStringAsFixed(1)} dB', onMinus: () => controller.updateEqBand(index, gain: (band.gain - .5).clamp(-12, 12).toDouble()), onPlus: () => controller.updateEqBand(index, gain: (band.gain + .5).clamp(-12, 12).toDouble()))),
          const SizedBox(width: 8),
          Expanded(flex: 12, child: _StepperBox(text: band.q.toStringAsFixed(2), onMinus: () => controller.updateEqBand(index, q: (band.q - .05).clamp(.2, 10).toDouble()), onPlus: () => controller.updateEqBand(index, q: (band.q + .05).clamp(.2, 10).toDouble()))),
          const SizedBox(width: 8),
          SizedBox(width: 72, child: Switch(value: band.enabled, onChanged: (v) => controller.updateEqBand(index, enabled: v), activeThumbColor: Colors.white, activeTrackColor: const Color(0xFF00A8FF))),
        ],
      ),
    );
  }

  String _formatFrequency(double f) => f >= 1000 ? '${(f / 1000).toStringAsFixed(1)} kHz' : '${f.round()} Hz';
}

class CrossoverPage extends StatelessWidget {
  const CrossoverPage({super.key, required this.controller});
  final DspController controller;

  @override
  Widget build(BuildContext context) {
    final ch = controller.selectedChannel;
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(18, 4, 18, 6),
      child: Column(
        children: [
          _GlassCard(
            child: Column(
              children: [
                LayoutBuilder(
                  builder: (context, constraints) {
                    final compact = constraints.maxWidth < 620;
                    final select = _DropdownBox(value: controller.crossoverDisplay, values: const ['Magnitude', 'Phase'], onChanged: (v) { controller.crossoverDisplay = v; controller.refresh(); });
                    final reset = OutlinedButton.icon(onPressed: controller.resetCrossover, icon: const Icon(Icons.refresh), label: const Text('Reset'), style: _outlineStyle());
                    if (compact) {
                      return Column(
                        children: [
                          const Row(children: [
                            _GlowIcon(icon: Icons.call_split_rounded, color: AppColors.magenta, size: 62),
                            SizedBox(width: 14),
                            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text('Crossover', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w700)),
                              Text('ตั้งค่าการแบ่งความถี่', style: TextStyle(color: AppColors.muted, fontSize: 14)),
                            ])),
                          ]),
                          const SizedBox(height: 10),
                          Row(children: [Expanded(child: select), const SizedBox(width: 10), reset]),
                        ],
                      );
                    }
                    return Row(children: [
                      const _GlowIcon(icon: Icons.call_split_rounded, color: AppColors.magenta, size: 68),
                      const SizedBox(width: 14),
                      const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('Crossover', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w700)),
                        Text('ตั้งค่าการแบ่งความถี่', style: TextStyle(color: AppColors.muted, fontSize: 15)),
                      ])),
                      SizedBox(width: 150, child: select),
                      const SizedBox(width: 10),
                      reset,
                    ]);
                  },
                ),
                const SizedBox(height: 10),
                SizedBox(height: 280, width: double.infinity, child: CustomPaint(painter: CrossoverGraphPainter(hpf: controller.hpfFrequency[ch], lpf: controller.lpfFrequency[ch]))),
              ],
            ),
          ),
          const SizedBox(height: 10),
          _FilterCard(
            title: 'High Pass Filter (HPF)',
            subtitle: 'กรองความถี่ต่ำออก',
            icon: Icons.show_chart_rounded,
            color: AppColors.cyan,
            bypass: controller.hpfBypass[ch],
            onBypass: (v) { controller.hpfBypass[ch] = v; controller.refresh(); },
            type: controller.hpfType[ch],
            onType: (v) { controller.hpfType[ch] = v; controller.refresh(); },
            frequency: controller.hpfFrequency[ch],
            onFrequency: controller.setHpfFrequency,
            slope: controller.hpfSlope[ch],
            onSlope: (v) { controller.hpfSlope[ch] = v; controller.refresh(); },
          ),
          _FilterCard(
            title: 'Low Pass Filter (LPF)',
            subtitle: 'กรองความถี่สูงออก',
            icon: Icons.show_chart_rounded,
            color: AppColors.magenta,
            bypass: controller.lpfBypass[ch],
            onBypass: (v) { controller.lpfBypass[ch] = v; controller.refresh(); },
            type: controller.lpfType[ch],
            onType: (v) { controller.lpfType[ch] = v; controller.refresh(); },
            frequency: controller.lpfFrequency[ch],
            onFrequency: controller.setLpfFrequency,
            slope: controller.lpfSlope[ch],
            onSlope: (v) { controller.lpfSlope[ch] = v; controller.refresh(); },
          ),
          _GlassCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(children: [
                  _SquareIcon(icon: Icons.settings_suggest_rounded),
                  SizedBox(width: 12),
                  Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Advanced Settings', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                    Text('ตั้งค่าขั้นสูง', style: TextStyle(color: AppColors.muted)),
                  ]),
                ]),
                const SizedBox(height: 12),
                LayoutBuilder(
                  builder: (context, constraints) {
                    final itemWidth = constraints.maxWidth < 700
                        ? (constraints.maxWidth - 10) / 2
                        : (constraints.maxWidth - 30) / 4;
                    return Wrap(
                      spacing: 10,
                      runSpacing: 10,
                      children: [
                        SizedBox(width: itemWidth, child: _StepperSetting(label: 'Phase', text: '${controller.phase}°', icon: Icons.exposure_zero, onMinus: () { controller.phase = ((controller.phase - 5) % 360); controller.refresh(); }, onPlus: () { controller.phase = ((controller.phase + 5) % 360); controller.refresh(); })),
                        SizedBox(width: itemWidth, child: _StepperSetting(label: 'Polarity', text: controller.polarityNormal ? 'Normal' : 'Invert', icon: Icons.swap_vert, onMinus: () { controller.polarityNormal = !controller.polarityNormal; controller.refresh(); }, onPlus: () { controller.polarityNormal = !controller.polarityNormal; controller.refresh(); })),
                        SizedBox(width: itemWidth, child: _ToggleSetting(label: 'Link L/R', icon: Icons.link_rounded, value: controller.linkLr, onChanged: (v) { controller.linkLr = v; controller.refresh(); })),
                        SizedBox(width: itemWidth, child: _DropdownSetting(label: 'Output Mode', icon: Icons.multiline_chart, value: controller.outputMode, values: const ['Stereo', 'Mono', 'Sub'], onChanged: (v) { controller.outputMode = v; controller.refresh(); })),
                      ],
                    );
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class CrossoverGraphPainter extends CustomPainter {
  CrossoverGraphPainter({required this.hpf, required this.lpf});
  final double hpf;
  final double lpf;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Rect.fromLTWH(50, 35, size.width - 65, size.height - 55);
    final grid = Paint()..color = const Color(0x33267FB5)..strokeWidth = 1;
    for (var i = 0; i <= 10; i++) {
      final x = rect.left + rect.width * i / 10;
      canvas.drawLine(Offset(x, rect.top), Offset(x, rect.bottom), grid);
    }
    for (var i = 0; i <= 5; i++) {
      final y = rect.top + rect.height * i / 5;
      canvas.drawLine(Offset(rect.left, y), Offset(rect.right, y), grid);
    }
    canvas.drawRect(rect, Paint()..color = const Color(0xFF7FA6C2)..style = PaintingStyle.stroke);
    final zeroY = rect.top + rect.height * .28;
    final hX = rect.left + _logNorm(hpf) * rect.width;
    final lX = rect.left + _logNorm(lpf) * rect.width;

    final hPath = Path()..moveTo(rect.left, rect.bottom + 8);
    hPath.cubicTo(hX - 130, rect.bottom, hX - 70, zeroY + 30, hX, zeroY);
    hPath.lineTo(rect.right, zeroY);
    _drawCurve(canvas, hPath, AppColors.cyan);

    final lPath = Path()..moveTo(rect.left, zeroY);
    lPath.lineTo(lX, zeroY);
    lPath.cubicTo(lX + 70, zeroY + 8, lX + 130, rect.bottom, rect.right, rect.bottom + 8);
    _drawCurve(canvas, lPath, AppColors.magenta);
    _dot(canvas, Offset(hX, zeroY), AppColors.cyan);
    _dot(canvas, Offset(lX, zeroY), AppColors.magenta);

    _text(canvas, '●  High Pass (HPF)', Offset(rect.right - 250, 2), AppColors.cyan);
    _text(canvas, '●  Low Pass (LPF)', Offset(rect.right - 115, 2), AppColors.magenta);
    final labels = <String>['20', '50', '100', '200', '500', '1k', '2k', '5k', '10k', '20k'];
    final values = <double>[20,50,100,200,500,1000,2000,5000,10000,20000];
    for (var i = 0; i < labels.length; i++) {
      final x = rect.left + _logNorm(values[i]) * rect.width;
      _text(canvas, labels[i], Offset(x - 8, rect.bottom + 6), const Color(0xFFC5DDEF));
    }
    for (final db in <int>[12, 6, 0, -6, -12, -24]) {
      final y = rect.top + ((12 - db) / 36) * rect.height;
      _text(canvas, db > 0 ? '+$db' : '$db', Offset(2, y - 7), const Color(0xFFC5DDEF));
    }
  }

  void _drawCurve(Canvas canvas, Path path, Color color) {
    canvas.drawPath(path, Paint()..color = color.withValues(alpha: .35)..strokeWidth = 13..style = PaintingStyle.stroke..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12));
    canvas.drawPath(path, Paint()..color = color..strokeWidth = 3..style = PaintingStyle.stroke);
  }

  void _dot(Canvas canvas, Offset p, Color color) {
    canvas.drawCircle(p, 12, Paint()..color = color.withValues(alpha: .28)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8));
    canvas.drawCircle(p, 8, Paint()..color = color);
    canvas.drawCircle(p, 5, Paint()..color = AppColors.white);
  }

  double _logNorm(double value) => ((math.log(value.clamp(20, 20000)) - math.log(20)) / (math.log(20000) - math.log(20))).clamp(0.0, 1.0).toDouble();

  void _text(Canvas canvas, String t, Offset p, Color c) {
    final tp = TextPainter(text: TextSpan(text: t, style: TextStyle(color: c, fontSize: 12)), textDirection: TextDirection.ltr)..layout();
    tp.paint(canvas, p);
  }

  @override
  bool shouldRepaint(covariant CrossoverGraphPainter oldDelegate) => oldDelegate.hpf != hpf || oldDelegate.lpf != lpf;
}

class _FilterCard extends StatelessWidget {
  const _FilterCard({required this.title, required this.subtitle, required this.icon, required this.color, required this.bypass, required this.onBypass, required this.type, required this.onType, required this.frequency, required this.onFrequency, required this.slope, required this.onSlope});
  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;
  final bool bypass;
  final ValueChanged<bool> onBypass;
  final String type;
  final ValueChanged<String> onType;
  final double frequency;
  final ValueChanged<double> onFrequency;
  final String slope;
  final ValueChanged<String> onSlope;

  @override
  Widget build(BuildContext context) {
    return _GlassCard(
      margin: const EdgeInsets.only(bottom: 10),
      child: Column(
        children: [
          Row(
            children: [
              _GlowIcon(icon: icon, color: color, size: 64),
              const SizedBox(width: 14),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700)), Text(subtitle, style: const TextStyle(color: AppColors.muted))])),
              const Text('Bypass', style: TextStyle(fontSize: 15, color: Color(0xFFD6E8F7))),
              Switch(value: bypass, onChanged: onBypass),
            ],
          ),
          const SizedBox(height: 12),
          LayoutBuilder(
            builder: (context, constraints) {
              final compact = constraints.maxWidth < 600;
              final typeBox = _DropdownSetting(label: 'Type', icon: Icons.tune, value: type, values: const ['Linkwitz-Riley', 'Butterworth', 'Bessel'], onChanged: onType);
              final frequencyBox = _FrequencySetting(label: 'Frequency', value: frequency, onChanged: onFrequency);
              final slopeBox = _DropdownSetting(label: 'Slope', icon: Icons.show_chart, value: slope, values: const ['6 dB/Oct', '12 dB/Oct', '18 dB/Oct', '24 dB/Oct', '36 dB/Oct', '48 dB/Oct'], onChanged: onSlope);
              if (compact) {
                return Column(
                  children: [
                    typeBox,
                    const SizedBox(height: 10),
                    frequencyBox,
                    const SizedBox(height: 10),
                    slopeBox,
                  ],
                );
              }
              return Row(
                children: [
                  Expanded(child: typeBox),
                  const SizedBox(width: 10),
                  Expanded(child: frequencyBox),
                  const SizedBox(width: 10),
                  Expanded(child: slopeBox),
                ],
              );
            },
          ),
        ],
      ),
    );
  }
}

class DelayPage extends StatelessWidget {
  const DelayPage({super.key, required this.controller});
  final DspController controller;

  @override
  Widget build(BuildContext context) {
    final maxDelay = controller.delaysMs.reduce((a, b) => a > b ? a : b);
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(18, 4, 18, 6),
      child: Column(
        children: [
          _GlassCard(
            child: Column(
              children: [
                LayoutBuilder(
                  builder: (context, constraints) {
                    final compact = constraints.maxWidth < 650;
                    final unit = _TwoWayToggle(left: 'ms', right: 'cm', leftSelected: controller.delayUnitMs, onTap: (left) { controller.delayUnitMs = left; controller.refresh(); });
                    final sync = OutlinedButton.icon(onPressed: controller.syncDelayChannels, icon: const Icon(Icons.refresh), label: const Text('ซิงค์ทุกช่อง'), style: _outlineStyle());
                    if (compact) {
                      return Column(
                        children: [
                          const Row(children: [
                            _GlowIcon(icon: Icons.schedule_rounded, color: Color(0xFF39F6A0), size: 60),
                            SizedBox(width: 14),
                            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text('Delay', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w700)),
                              Text('ตั้งค่าหน่วงเวลาเพื่อการจัดตำแหน่งเสียง', style: TextStyle(color: AppColors.muted)),
                            ])),
                          ]),
                          const SizedBox(height: 10),
                          Row(children: [Expanded(child: unit), const SizedBox(width: 10), sync]),
                        ],
                      );
                    }
                    return Row(children: [
                      const _GlowIcon(icon: Icons.schedule_rounded, color: Color(0xFF39F6A0), size: 64),
                      const SizedBox(width: 14),
                      const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('Delay', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700)),
                        Text('ตั้งค่าหน่วงเวลาเพื่อการจัดตำแหน่งเสียง', style: TextStyle(color: AppColors.muted)),
                      ])),
                      unit,
                      const SizedBox(width: 10),
                      sync,
                    ]);
                  },
                ),
                const SizedBox(height: 10),
                LayoutBuilder(builder: (context, constraints) {
                  final split = constraints.maxWidth > 720;
                  final car = SizedBox(height: 360, child: CustomPaint(painter: CarDelayPainter(delays: controller.delaysMs)));
                  final info = Column(
                    children: [
                      _InfoCard(icon: Icons.event_seat_rounded, title: 'Seat Preset', subtitle: 'ตำแหน่งการฟัง', child: _DropdownBox(value: controller.seatPreset, values: const ['Driver (Left)', 'Passenger (Right)', 'Center', 'Rear'], onChanged: (v) { controller.seatPreset = v; controller.refresh(); })),
                      const _InfoCard(icon: Icons.straighten, title: 'Distance Reference', subtitle: 'อ้างอิงระยะทางเสียง', child: Text('Speed of Sound (20°C)\n343 m/s (34.3 cm/ms)', style: TextStyle(color: Color(0xFFC7E0F5), height: 1.45))),
                      _InfoCard(icon: Icons.bar_chart_rounded, title: 'Total Delay Range', subtitle: 'ช่วงหน่วงเวลาทั้งหมด', child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('0.00 ms\nน้อยที่สุด', textAlign: TextAlign.center), Text('${maxDelay.toStringAsFixed(2)} ms\nมากที่สุด', textAlign: TextAlign.center)])),
                    ],
                  );
                  if (split) return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(flex: 6, child: car), const SizedBox(width: 14), Expanded(flex: 4, child: info)]);
                  return Column(children: [car, info]);
                }),
              ],
            ),
          ),
          const SizedBox(height: 10),
          for (var i = 0; i < 7; i++) _DelayChannelRow(controller: controller, channel: i),
        ],
      ),
    );
  }
}

class CarDelayPainter extends CustomPainter {
  CarDelayPainter({required this.delays});
  final List<double> delays;

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width * .46, size.height * .52);
    final carWidth = size.width * .62 < 290 ? size.width * .62 : 290.0;
    final carRect = Rect.fromCenter(center: center, width: carWidth, height: 310);
    final glow = Paint()..color = const Color(0x330078FF)..style = PaintingStyle.stroke..strokeWidth = 18..maskFilter = const MaskFilter.blur(BlurStyle.normal, 16);
    final body = Paint()..color = const Color(0xFF0B6EFF)..style = PaintingStyle.stroke..strokeWidth = 2.2;
    final rrect = RRect.fromRectAndRadius(carRect, const Radius.circular(70));
    canvas.drawRRect(rrect, glow);
    canvas.drawRRect(rrect, body);
    canvas.drawLine(Offset(center.dx, carRect.top + 30), Offset(center.dx, carRect.bottom - 30), Paint()..color = const Color(0x5538A5FF));
    canvas.drawLine(Offset(carRect.left + 30, center.dy), Offset(carRect.right - 30, center.dy), Paint()..color = const Color(0x5538A5FF));

    final seats = <Rect>[
      Rect.fromCenter(center: Offset(center.dx - 55, center.dy - 65), width: 55, height: 80),
      Rect.fromCenter(center: Offset(center.dx + 55, center.dy - 65), width: 55, height: 80),
      Rect.fromCenter(center: Offset(center.dx - 55, center.dy + 65), width: 55, height: 80),
      Rect.fromCenter(center: Offset(center.dx + 55, center.dy + 65), width: 55, height: 80),
    ];
    for (final seat in seats) {
      canvas.drawRRect(RRect.fromRectAndRadius(seat, const Radius.circular(15)), Paint()..color = const Color(0x332A8DFF)..style = PaintingStyle.fill);
      canvas.drawRRect(RRect.fromRectAndRadius(seat, const Radius.circular(15)), Paint()..color = const Color(0xFF1B77C9)..style = PaintingStyle.stroke..strokeWidth = 1.5);
    }

    final speakerPoints = <Offset>[
      Offset(carRect.left - 10, center.dy - 45),
      Offset(carRect.right + 10, center.dy - 45),
      Offset(carRect.left - 16, center.dy + 70),
      Offset(carRect.right + 16, center.dy + 70),
      Offset(center.dx, carRect.top + 18),
      Offset(center.dx, carRect.bottom - 25),
      Offset(center.dx + 5, carRect.bottom + 20),
    ];
    for (var i = 0; i < speakerPoints.length; i++) {
      final c = channelColors[i];
      final p = speakerPoints[i];
      canvas.drawCircle(p, 24, Paint()..color = c.withValues(alpha: .16)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12));
      canvas.drawCircle(p, 17, Paint()..color = const Color(0xFF07213A)..style = PaintingStyle.fill);
      canvas.drawCircle(p, 16, Paint()..color = c..style = PaintingStyle.stroke..strokeWidth = 4);
      canvas.drawCircle(p, 6, Paint()..color = c);
      final label = '${delays[i].toStringAsFixed(2)} ms';
      final dx = i == 0 || i == 2 ? p.dx - 80 : (i == 1 || i == 3 ? p.dx + 25 : p.dx - 32);
      final dy = i == 4 ? p.dy - 40 : (i >= 5 ? p.dy + 25 : p.dy - 7);
      _text(canvas, label, Offset(dx, dy));
    }
  }

  void _text(Canvas canvas, String t, Offset p) {
    final tp = TextPainter(text: TextSpan(text: t, style: const TextStyle(color: AppColors.white, fontSize: 13, fontWeight: FontWeight.w600)), textDirection: TextDirection.ltr)..layout();
    tp.paint(canvas, p);
  }

  @override
  bool shouldRepaint(covariant CarDelayPainter oldDelegate) => true;
}

class _DelayChannelRow extends StatelessWidget {
  const _DelayChannelRow({required this.controller, required this.channel});
  final DspController controller;
  final int channel;

  @override
  Widget build(BuildContext context) {
    final ms = controller.delaysMs[channel];
    final cm = ms * 34.3;
    final color = channelColors[channel];
    return _GlassCard(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final compact = constraints.maxWidth < 410;
          final label = Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('CH${channel + 1}', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
              Text(channelNames[channel], style: const TextStyle(color: AppColors.muted, fontSize: 12)),
            ],
          );
          final valueBox = Container(
            width: compact ? 96 : 120,
            padding: const EdgeInsets.symmetric(vertical: 8),
            alignment: Alignment.center,
            decoration: BoxDecoration(color: const Color(0xFF061D32), borderRadius: BorderRadius.circular(9), border: Border.all(color: const Color(0xFF31577A))),
            child: Text('${ms.toStringAsFixed(2)} ms\n${cm.toStringAsFixed(1)} cm', textAlign: TextAlign.center, style: const TextStyle(height: 1.35)),
          );
          final slider = SliderTheme(
            data: SliderTheme.of(context).copyWith(activeTrackColor: color, inactiveTrackColor: AppColors.track, thumbColor: Colors.white, trackHeight: 8, thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 12)),
            child: Slider(value: ms.clamp(0, 10).toDouble(), min: 0, max: 10, divisions: 200, onChanged: (v) => controller.setDelay(channel, v)),
          );
          if (compact) {
            return Column(
              children: [
                Row(
                  children: [
                    Container(width: 22, height: 22, decoration: BoxDecoration(color: color, shape: BoxShape.circle, boxShadow: [BoxShadow(color: color, blurRadius: 10)])),
                    const SizedBox(width: 12),
                    Expanded(child: label),
                    valueBox,
                  ],
                ),
                const SizedBox(height: 6),
                slider,
              ],
            );
          }
          return Row(
            children: [
              Container(width: 22, height: 22, decoration: BoxDecoration(color: color, shape: BoxShape.circle, boxShadow: [BoxShadow(color: color, blurRadius: 10)])),
              const SizedBox(width: 14),
              SizedBox(width: 90, child: label),
              Expanded(child: slider),
              valueBox,
            ],
          );
        },
      ),
    );
  }
}

class OutputPage extends StatelessWidget {
  const OutputPage({super.key, required this.controller});
  final DspController controller;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(18, 4, 18, 8),
      child: Column(
        children: [
          _GlassCard(
            child: Column(
              children: [
                LayoutBuilder(
                  builder: (context, constraints) {
                    final compact = constraints.maxWidth < 680;
                    final muteOff = OutlinedButton.icon(onPressed: controller.allMuteOff, icon: const Icon(Icons.volume_off_outlined), label: const Text('All Mute Off'), style: _outlineStyle());
                    final reset = OutlinedButton.icon(onPressed: controller.resetOutputLevels, icon: const Icon(Icons.refresh), label: const Text('Reset Levels'), style: _outlineStyle());
                    if (compact) {
                      return Column(
                        children: [
                          const Row(children: [
                            _GlowIcon(icon: Icons.volume_up_rounded, color: AppColors.orange, size: 62),
                            SizedBox(width: 14),
                            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text('Output', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w700)),
                              Text('ปรับระดับเอาต์พุตแต่ละช่อง', style: TextStyle(color: AppColors.muted)),
                            ])),
                          ]),
                          const SizedBox(height: 10),
                          Row(children: [Expanded(child: muteOff), const SizedBox(width: 10), Expanded(child: reset)]),
                        ],
                      );
                    }
                    return Row(children: [
                      const _GlowIcon(icon: Icons.volume_up_rounded, color: AppColors.orange, size: 70),
                      const SizedBox(width: 14),
                      const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('Output', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w700)),
                        Text('ปรับระดับเอาต์พุตแต่ละช่อง', style: TextStyle(color: AppColors.muted)),
                      ])),
                      muteOff,
                      const SizedBox(width: 10),
                      reset,
                    ]);
                  },
                ),
                const SizedBox(height: 12),
                LayoutBuilder(
                  builder: (context, constraints) {
                    if (constraints.maxWidth < 650) {
                      return Column(children: [
                        _OutputOverview(levels: controller.outputLevels),
                        const SizedBox(height: 10),
                        _MasterOutputCard(controller: controller),
                      ]);
                    }
                    return Row(children: [
                      Expanded(flex: 7, child: _OutputOverview(levels: controller.outputLevels)),
                      const SizedBox(width: 12),
                      Expanded(flex: 3, child: _MasterOutputCard(controller: controller)),
                    ]);
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          for (var i = 0; i < 7; i++) _OutputChannelRow(controller: controller, channel: i),
        ],
      ),
    );
  }
}

class _OutputOverview extends StatelessWidget {
  const _OutputOverview({required this.levels});
  final List<double> levels;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 190,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: const Color(0x88051C30), borderRadius: BorderRadius.circular(10), border: Border.all(color: const Color(0xFF174E77))),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Output Level Overview', style: TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          Expanded(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                for (var i = 0; i < 7; i++)
                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Expanded(child: _MeterBar(level: levels[i], color: channelColors[i])),
                        const SizedBox(height: 5),
                        Text('CH${i + 1}', style: const TextStyle(fontSize: 11)),
                        Text(channelNames[i], style: const TextStyle(color: AppColors.muted, fontSize: 9), overflow: TextOverflow.ellipsis),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _MeterBar extends StatelessWidget {
  const _MeterBar({required this.level, required this.color});
  final double level;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final fill = ((level + 60) / 72).clamp(0.08, 1.0).toDouble();
    return LayoutBuilder(builder: (context, c) {
      final h = c.maxHeight;
      return Stack(
        alignment: Alignment.bottomCenter,
        children: [
          Container(width: 20, decoration: BoxDecoration(color: const Color(0xFF07263F), borderRadius: BorderRadius.circular(5))),
          Container(width: 20, height: h * fill, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(5), boxShadow: [BoxShadow(color: color, blurRadius: 10)])),
          for (var i = 1; i < 8; i++) Positioned(bottom: h * i / 8, child: Container(width: 24, height: 2, color: AppColors.bg)),
        ],
      );
    });
  }
}

class _MasterOutputCard extends StatelessWidget {
  const _MasterOutputCard({required this.controller});
  final DspController controller;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 190,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: const Color(0x88051C30), borderRadius: BorderRadius.circular(10), border: Border.all(color: const Color(0xFF174E77))),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [const Expanded(child: Text('Master Output', style: TextStyle(fontWeight: FontWeight.w600))), Container(padding: const EdgeInsets.all(9), decoration: BoxDecoration(color: AppColors.panel2, borderRadius: BorderRadius.circular(8), border: Border.all(color: AppColors.border)), child: Text('${controller.masterOutput.toStringAsFixed(1)} dB', style: const TextStyle(fontSize: 16)))]),
          const Spacer(),
          SliderTheme(data: SliderTheme.of(context).copyWith(activeTrackColor: AppColors.cyan, inactiveTrackColor: AppColors.track, trackHeight: 9, thumbColor: Colors.white, thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 14)), child: Slider(value: controller.masterOutput.clamp(-60, 12).toDouble(), min: -60, max: 12, onChanged: controller.setMasterOutput)),
          const _ScaleLabels(labels: ['-60', '-40', '-20', '0', '+12']),
          const Spacer(),
        ],
      ),
    );
  }
}

class _OutputChannelRow extends StatelessWidget {
  const _OutputChannelRow({required this.controller, required this.channel});
  final DspController controller;
  final int channel;

  @override
  Widget build(BuildContext context) {
    final value = controller.outputLevels[channel];
    final color = channelColors[channel];
    return _GlassCard(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final compact = constraints.maxWidth < 760;
          final identity = Row(
            children: [
              Container(width: 48, height: 48, alignment: Alignment.center, decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: color, width: 3), boxShadow: [BoxShadow(color: color, blurRadius: 12)]), child: Text('${channel + 1}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700))),
              const SizedBox(width: 12),
              SizedBox(width: compact ? 72 : 88, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('CH${channel + 1}', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)), Text(channelNames[channel], style: const TextStyle(color: AppColors.muted, fontSize: 12))])),
            ],
          );
          final slider = Expanded(
            child: Column(
              children: [
                SliderTheme(data: SliderTheme.of(context).copyWith(activeTrackColor: color, inactiveTrackColor: AppColors.track, trackHeight: 8, thumbColor: Colors.white, thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 12)), child: Slider(value: value.clamp(-60, 12).toDouble(), min: -60, max: 12, onChanged: (v) => controller.setOutputLevel(channel, v))),
                const _ScaleLabels(labels: ['-60', '-40', '-20', '0', '+12']),
              ],
            ),
          );
          final valueBox = Container(width: 86, padding: const EdgeInsets.symmetric(vertical: 10), alignment: Alignment.center, decoration: BoxDecoration(color: AppColors.panel2, borderRadius: BorderRadius.circular(8), border: Border.all(color: AppColors.border)), child: Text('${value.toStringAsFixed(1)} dB', style: const TextStyle(fontSize: 16)));
          final actions = Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              _SmallToggleButton(icon: Icons.volume_off_rounded, label: 'Mute', active: controller.muted[channel], onTap: () { controller.muted[channel] = !controller.muted[channel]; controller.refresh(); }),
              const SizedBox(width: 7),
              _SmallToggleButton(icon: Icons.headphones_rounded, label: 'Solo', active: controller.solo[channel], onTap: () { controller.solo[channel] = !controller.solo[channel]; controller.refresh(); }),
              const SizedBox(width: 7),
              _SmallToggleButton(icon: Icons.not_interested_rounded, label: 'Phase', active: controller.phaseInvert[channel], onTap: () { controller.phaseInvert[channel] = !controller.phaseInvert[channel]; controller.refresh(); }),
              if (channel < 2) ...[
                const SizedBox(width: 7),
                _SmallToggleButton(icon: Icons.link_rounded, label: 'Link', active: controller.linked[channel], onTap: () { controller.linked[channel] = !controller.linked[channel]; controller.refresh(); }),
              ],
            ],
          );
          if (!compact) {
            return Row(children: [identity, slider, valueBox, const SizedBox(width: 10), actions]);
          }
          return Column(
            children: [
              Row(children: [identity, slider, valueBox]),
              const SizedBox(height: 8),
              Align(alignment: Alignment.centerRight, child: SingleChildScrollView(scrollDirection: Axis.horizontal, child: actions)),
            ],
          );
        },
      ),
    );
  }
}

class _GlassCard extends StatelessWidget {
  const _GlassCard({required this.child, this.margin = EdgeInsets.zero, this.padding = const EdgeInsets.all(16)});
  final Widget child;
  final EdgeInsetsGeometry margin;
  final EdgeInsetsGeometry padding;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: margin,
      padding: padding,
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF062B49), Color(0xFF041B30)], begin: Alignment.topLeft, end: Alignment.bottomRight),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF0A5C91)),
        boxShadow: const [BoxShadow(color: Color(0x2B006BBA), blurRadius: 16, offset: Offset(0, 5))],
      ),
      child: child,
    );
  }
}

class _WaveLogo extends StatelessWidget {
  const _WaveLogo({required this.size});
  final double size;

  @override
  Widget build(BuildContext context) {
    const heights = <double>[.42, .72, 1, .78, .48];
    return SizedBox(
      width: size,
      height: size,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          for (final h in heights)
            Container(
              width: size * .095,
              height: size * h,
              decoration: BoxDecoration(
                color: AppColors.cyan,
                borderRadius: BorderRadius.circular(size),
                boxShadow: const [BoxShadow(color: AppColors.cyan, blurRadius: 10)],
              ),
            ),
        ],
      ),
    );
  }
}

class _GlowIcon extends StatelessWidget {
  const _GlowIcon({required this.icon, required this.color, required this.size});
  final IconData icon;
  final Color color;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: color, width: 3), boxShadow: [BoxShadow(color: color.withValues(alpha: .55), blurRadius: 18)]),
      child: Icon(icon, color: color, size: size * .5),
    );
  }
}

class _SquareIcon extends StatelessWidget {
  const _SquareIcon({required this.icon});
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 54,
      height: 54,
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF0B62B8), Color(0xFF053668)]),
        borderRadius: BorderRadius.circular(13),
        border: Border.all(color: const Color(0xFF0C80D9)),
        boxShadow: const [BoxShadow(color: Color(0x550B78FF), blurRadius: 14)],
      ),
      child: Icon(icon, color: const Color(0xFF8FE8FF), size: 30),
    );
  }
}

class _DropdownBox extends StatelessWidget {
  const _DropdownBox({required this.value, required this.values, required this.onChanged, this.dense = false});
  final String value;
  final List<String> values;
  final ValueChanged<String> onChanged;
  final bool dense;

  @override
  Widget build(BuildContext context) {
    return DropdownButtonFormField<String>(
      key: ValueKey<String>('${value}_${values.join('|')}'),
      initialValue: values.contains(value) ? value : values.first,
      isExpanded: true,
      dropdownColor: AppColors.panel,
      decoration: InputDecoration(
        isDense: true,
        contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: dense ? 9 : 12),
        filled: true,
        fillColor: const Color(0xFF061F36),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(9), borderSide: const BorderSide(color: Color(0xFF31577A))),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(9), borderSide: const BorderSide(color: AppColors.cyan)),
      ),
      items: values.map((v) => DropdownMenuItem(value: v, child: Text(v, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: dense ? 12 : 14)))).toList(),
      onChanged: (v) { if (v != null) onChanged(v); },
    );
  }
}

class _StepperBox extends StatelessWidget {
  const _StepperBox({required this.text, required this.onMinus, required this.onPlus});
  final String text;
  final VoidCallback onMinus;
  final VoidCallback onPlus;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 42,
      decoration: BoxDecoration(color: const Color(0xFF061F36), borderRadius: BorderRadius.circular(9), border: Border.all(color: const Color(0xFF31577A))),
      child: Row(
        children: [
          InkWell(onTap: onMinus, child: const SizedBox(width: 28, height: 42, child: Icon(Icons.chevron_left, size: 19))),
          Expanded(child: Text(text, textAlign: TextAlign.center, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12))),
          InkWell(onTap: onPlus, child: const SizedBox(width: 28, height: 42, child: Icon(Icons.chevron_right, size: 19))),
        ],
      ),
    );
  }
}

class _SegmentButton extends StatelessWidget {
  const _SegmentButton({required this.label, required this.selected, required this.onTap});
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(9),
      child: Container(
        height: 54,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          gradient: selected ? const LinearGradient(colors: [Color(0xFF0870FF), Color(0xFF08D7FF)]) : const LinearGradient(colors: [Color(0xFF062842), Color(0xFF051E34)]),
          borderRadius: BorderRadius.circular(9),
          border: Border.all(color: selected ? AppColors.cyan : AppColors.border),
          boxShadow: selected ? const [BoxShadow(color: Color(0x6600BFFF), blurRadius: 14)] : null,
        ),
        child: Text(label, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
      ),
    );
  }
}

class _ActionTile extends StatelessWidget {
  const _ActionTile({required this.icon, required this.label, required this.onTap, this.width = 110, this.height = 82});
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final double width;
  final double height;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: Container(
        width: width,
        height: height,
        decoration: BoxDecoration(color: const Color(0xFF073760), borderRadius: BorderRadius.circular(10), border: Border.all(color: AppColors.border)),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icon, size: 29, color: const Color(0xFFBFE8FF)), const SizedBox(height: 6), Text(label, style: const TextStyle(color: AppColors.muted))]),
      ),
    );
  }
}

class _StepperSetting extends StatelessWidget {
  const _StepperSetting({required this.label, required this.text, required this.icon, required this.onMinus, required this.onPlus});
  final String label;
  final String text;
  final IconData icon;
  final VoidCallback onMinus;
  final VoidCallback onPlus;

  @override
  Widget build(BuildContext context) {
    return _SettingBox(label: label, icon: icon, child: _StepperBox(text: text, onMinus: onMinus, onPlus: onPlus));
  }
}

class _ToggleSetting extends StatelessWidget {
  const _ToggleSetting({required this.label, required this.icon, required this.value, required this.onChanged});
  final String label;
  final IconData icon;
  final bool value;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    return _SettingBox(label: label, icon: icon, child: Align(alignment: Alignment.centerLeft, child: Switch(value: value, onChanged: onChanged)));
  }
}

class _DropdownSetting extends StatelessWidget {
  const _DropdownSetting({required this.label, required this.icon, required this.value, required this.values, required this.onChanged});
  final String label;
  final IconData icon;
  final String value;
  final List<String> values;
  final ValueChanged<String> onChanged;

  @override
  Widget build(BuildContext context) {
    return _SettingBox(label: label, icon: icon, child: _DropdownBox(value: value, values: values, onChanged: onChanged));
  }
}

class _FrequencySetting extends StatelessWidget {
  const _FrequencySetting({required this.label, required this.value, required this.onChanged});
  final String label;
  final double value;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context) {
    final formatted = value >= 1000 ? '${(value / 1000).toStringAsFixed(1)} kHz' : '${value.round()} Hz';
    return _SettingBox(
      label: label,
      icon: Icons.tune_rounded,
      child: _StepperBox(text: formatted, onMinus: () => onChanged((value / 1.12).clamp(20, 20000).toDouble()), onPlus: () => onChanged((value * 1.12).clamp(20, 20000).toDouble())),
    );
  }
}

class _SettingBox extends StatelessWidget {
  const _SettingBox({required this.label, required this.icon, required this.child});
  final String label;
  final IconData icon;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(color: const Color(0x66051A2D), borderRadius: BorderRadius.circular(10), border: Border.all(color: const Color(0xFF174E77))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [Icon(icon, size: 19, color: const Color(0xFFC9E5FA)), const SizedBox(width: 7), Expanded(child: Text(label, style: const TextStyle(fontSize: 13)))]), const SizedBox(height: 7), child]),
    );
  }
}

class _InfoCard extends StatelessWidget {
  const _InfoCard({required this.icon, required this.title, required this.subtitle, required this.child});
  final IconData icon;
  final String title;
  final String subtitle;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(color: const Color(0x66051A2D), borderRadius: BorderRadius.circular(11), border: Border.all(color: const Color(0xFF174E77))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [Icon(icon, color: AppColors.cyan, size: 28), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)), Text(subtitle, style: const TextStyle(color: AppColors.muted, fontSize: 12))]))]), const SizedBox(height: 10), child]),
    );
  }
}

class _TwoWayToggle extends StatelessWidget {
  const _TwoWayToggle({required this.left, required this.right, required this.leftSelected, required this.onTap});
  final String left;
  final String right;
  final bool leftSelected;
  final ValueChanged<bool> onTap;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 48,
      width: 160,
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(color: AppColors.panel2, borderRadius: BorderRadius.circular(10), border: Border.all(color: AppColors.border)),
      child: Row(children: [
        Expanded(child: _togglePart(left, leftSelected, () => onTap(true))),
        Expanded(child: _togglePart(right, !leftSelected, () => onTap(false))),
      ]),
    );
  }

  Widget _togglePart(String text, bool active, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(7),
      child: Container(alignment: Alignment.center, decoration: BoxDecoration(gradient: active ? const LinearGradient(colors: [Color(0xFF076BFF), Color(0xFF03CBFF)]) : null, borderRadius: BorderRadius.circular(7)), child: Text(text, style: TextStyle(fontWeight: FontWeight.w600, color: active ? Colors.white : AppColors.muted))),
    );
  }
}

class _SmallToggleButton extends StatelessWidget {
  const _SmallToggleButton({required this.icon, required this.label, required this.active, required this.onTap});
  final IconData icon;
  final String label;
  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(9),
      child: Container(
        width: 64,
        height: 60,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: active ? const Color(0xFF074D82) : const Color(0xFF061D32),
          borderRadius: BorderRadius.circular(9),
          border: Border.all(color: active ? AppColors.cyan : const Color(0xFF31577A)),
          boxShadow: active ? const [BoxShadow(color: Color(0x5500E8FF), blurRadius: 10)] : null,
        ),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icon, size: 23, color: active ? AppColors.cyan : const Color(0xFFCBE4F9)), const SizedBox(height: 2), Text(label, style: TextStyle(fontSize: 10, color: active ? AppColors.cyan : AppColors.muted))]),
      ),
    );
  }
}

ButtonStyle _outlineStyle() => OutlinedButton.styleFrom(
      foregroundColor: const Color(0xFFDCEEFF),
      side: const BorderSide(color: Color(0xFF31577A)),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    );
