package com.okn.dsp.usbprobe;

import android.app.*;
import android.os.*;
import android.content.*;
import android.hardware.usb.*;
import android.hardware.input.InputManager;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.widget.*;
import java.util.*;
import java.text.SimpleDateFormat;
import java.nio.charset.StandardCharsets;
import java.io.*;

public final class MainActivity extends Activity {
    private static final int OBSERVED_VID = 0x6324;
    private static final int OBSERVED_PID = 0x1719;
    private static final String OBSERVED_MANUFACTURER = "JMDSTECH";
    private static final String OBSERVED_PRODUCT = "DSTech DSP ComboDigitalArchitect";
    private static final String ACTION_USB_PERMISSION = "com.okn.dsp.usbprobe.USB_PERMISSION";

    private static final byte[] EXPECTED_IF4_REPORT = new byte[] {
        0x06,0x00,(byte)0xFF,0x0A,(byte)0xAA,0x55,(byte)0xA1,0x01,
        0x15,0x00,0x26,(byte)0xFF,0x00,0x75,0x08,(byte)0x96,0x00,0x01,
        0x09,0x01,(byte)0x81,0x02,(byte)0x96,0x00,0x01,0x09,0x01,(byte)0x91,0x02,
        (byte)0x95,0x08,0x09,0x01,(byte)0xB1,0x02,(byte)0xC0
    };
    private static final byte[] EXPECTED_FEATURE = new byte[] {0x00,0x01,0x00,0x03,0x04,0x00,0x08,0x00};

    private UsbManager usb;
    private TextView log;
    private UsbDevice selected;
    private UsbDevice candidate;
    private InputManager inputManager;
    private Button enterBoot;
    private Button inspectCandidate;
    private volatile boolean exactNormalGatePassed = false;
    private volatile boolean waitingCandidatePermission = false;

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            String action=i.getAction();
            if (UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(action) || UsbManager.ACTION_USB_DEVICE_DETACHED.equals(action)) {
                UsbDevice d=i.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                add((UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(action)?"USB ATTACHED: ":"USB DETACHED: ")+brief(d));
                return;
            }
            if (!ACTION_USB_PERMISSION.equals(action)) return;
            UsbDevice d = i.getParcelableExtra(UsbManager.EXTRA_DEVICE);
            if (!i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false) || d==null) {
                add("USB permission denied");
                waitingCandidatePermission=false;
                return;
            }
            if (waitingCandidatePermission && candidate!=null && d.getDeviceId()==candidate.getDeviceId()) {
                waitingCandidatePermission=false;
                probeCandidateReadOnly(d);
            } else {
                selected=d;
                probeReadOnly(d);
            }
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        usb = (UsbManager) getSystemService(USB_SERVICE);
        inputManager = (InputManager) getSystemService(INPUT_SERVICE);
        buildUi();
        IntentFilter f = new IntentFilter();
        f.addAction(ACTION_USB_PERMISSION);
        f.addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED);
        f.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, RECEIVER_NOT_EXPORTED);
        else registerReceiver(receiver, f);
        readExitHistory();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        try { unregisterReceiver(receiver); } catch (Exception ignored) {}
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28,28,28,28);

        TextView title = new TextView(this);
        title.setText("OKN BP1048P4 USB-C Diagnostic R15\nBOOTLOADER PREFLIGHT / DISCOVERY\nNo erase / no program / no firmware payload / no endpoint OUT");
        title.setTextSize(18);

        Button exits = new Button(this);
        exits.setText("1) READ APP EXIT HISTORY");
        Button scan = new Button(this);
        scan.setText("2) READ-ONLY NORMAL USB SCAN + EXACT GATE");
        Button inputs = new Button(this);
        inputs.setText("3) READ ANDROID INPUT DEVICES + PASSIVE WATCH");
        Button preflight = new Button(this);
        preflight.setText("4) BOOTLOADER PREFLIGHT (READ-ONLY)");
        enterBoot = new Button(this);
        enterBoot.setText("5) ENTER FLASHBOOT ONCE (AA + GET_REPORT) — MANUAL");
        enterBoot.setEnabled(false);
        inspectCandidate = new Button(this);
        inspectCandidate.setText("6) INSPECT RE-ENUMERATED CANDIDATE (READ-ONLY)");
        inspectCandidate.setEnabled(false);

        log = new TextView(this);
        log.setTextIsSelectable(true);
        ScrollView sv = new ScrollView(this);
        sv.addView(log);

        root.addView(title);
        root.addView(exits);
        root.addView(scan);
        root.addView(inputs);
        root.addView(preflight);
        root.addView(enterBoot);
        root.addView(inspectCandidate);
        root.addView(sv, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);

        exits.setOnClickListener(v -> readExitHistory());
        scan.setOnClickListener(v -> scan());
        inputs.setOnClickListener(v -> scanAndroidInputDevices());
        preflight.setOnClickListener(v -> bootloaderPreflight());
        enterBoot.setOnClickListener(v -> confirmEnterFlashboot());
        inspectCandidate.setOnClickListener(v -> inspectCandidate());
    }

    private void readExitHistory() {
        add("=== ANDROID APP EXIT HISTORY ===");
        add("Model: "+Build.MANUFACTURER+" "+Build.MODEL+" SDK="+Build.VERSION.SDK_INT);
        add("Build fingerprint: "+Build.FINGERPRINT);
        if (Build.VERSION.SDK_INT < 30) {
            add("ApplicationExitInfo unavailable below Android 11 / API 30.");
            return;
        }
        try {
            ActivityManager am=(ActivityManager)getSystemService(ACTIVITY_SERVICE);
            List<ApplicationExitInfo> infos=am.getHistoricalProcessExitReasons(getPackageName(),0,10);
            add("Historical exits: "+infos.size());
            SimpleDateFormat fmt=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS Z",Locale.US);
            int idx=0;
            for (ApplicationExitInfo info: infos) {
                idx++;
                add("EXIT #"+idx+": time="+fmt.format(new Date(info.getTimestamp())));
                add("  reason="+info.getReason()+" ("+exitReasonName(info.getReason())+") status="+info.getStatus()+" importance="+info.getImportance());
                add("  process="+safe(info.getProcessName())+" pss="+info.getPss()+"KB rss="+info.getRss()+"KB");
                String desc=info.getDescription();
                if (desc!=null && !desc.isEmpty()) add("  description="+desc);
                try {
                    InputStream is=info.getTraceInputStream();
                    if (is!=null) {
                        byte[] b=readLimited(is,4096);
                        is.close();
                        String s=new String(b,StandardCharsets.UTF_8).replace('\u0000',' ');
                        add("  trace(first "+b.length+" bytes): "+s);
                    } else add("  trace=<none>");
                } catch (Throwable t) {
                    add("  trace read error: "+t.getClass().getSimpleName()+": "+safe(t.getMessage()));
                }
            }
            if (infos.isEmpty()) add("No historical exit record visible to this package.");
        } catch (Throwable t) {
            add("Exit-history read failed: "+t.getClass().getSimpleName()+": "+safe(t.getMessage()));
        }
        add("=== END EXIT HISTORY ===");
    }

    private static byte[] readLimited(InputStream is,int max) throws IOException {
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        byte[] buf=new byte[512];
        while (out.size()<max) {
            int want=Math.min(buf.length,max-out.size());
            int n=is.read(buf,0,want);
            if (n<0) break;
            out.write(buf,0,n);
        }
        return out.toByteArray();
    }

    private static String exitReasonName(int r) {
        switch (r) {
            case 0: return "UNKNOWN";
            case 1: return "EXIT_SELF";
            case 2: return "SIGNALED";
            case 3: return "LOW_MEMORY";
            case 4: return "CRASH";
            case 5: return "CRASH_NATIVE";
            case 6: return "ANR";
            case 7: return "INITIALIZATION_FAILURE";
            case 8: return "PERMISSION_CHANGE";
            case 9: return "EXCESSIVE_RESOURCE_USAGE";
            case 10: return "USER_REQUESTED";
            case 11: return "USER_STOPPED";
            case 12: return "DEPENDENCY_DIED";
            case 13: return "OTHER";
            case 14: return "FREEZER";
            default: return "REASON_"+r;
        }
    }

    private void scan() {
        add("=== READ-ONLY NORMAL USB SCAN ===");
        exactNormalGatePassed=false;
        uiSetEnter(false);
        selected = null;
        Map<String,UsbDevice> devices = usb.getDeviceList();
        add("USB devices: " + devices.size());
        for (UsbDevice d: devices.values()) {
            int vid=d.getVendorId(), pid=d.getProductId();
            add(String.format(Locale.US,"VID=0x%04X (%d) PID=0x%04X (%d) interfaces=%d",vid,vid,pid,pid,d.getInterfaceCount()));
            dumpInterfaces(d);
            if (isObservedNormal(d)) {
                selected=d;
                add("*** EXACT TARGET VID/PID MATCH: 6324:1719 ***");
            }
        }
        if (selected==null) { add("Exact normal target not found"); return; }
        requestOrProbe(selected);
    }

    private void dumpInterfaces(UsbDevice d) {
        for (int i=0;i<d.getInterfaceCount();i++) {
            UsbInterface ui=d.getInterface(i);
            add("  IDX"+i+" IF"+ui.getId()+" alt="+ui.getAlternateSetting()+" class="+ui.getInterfaceClass()+" sub="+ui.getInterfaceSubclass()+" proto="+ui.getInterfaceProtocol()+" ep="+ui.getEndpointCount());
            for (int e=0;e<ui.getEndpointCount();e++) {
                UsbEndpoint ep=ui.getEndpoint(e);
                add("    EP addr=0x"+String.format(Locale.US,"%02X",ep.getAddress())+" dir="+(ep.getDirection()==UsbConstants.USB_DIR_IN?"IN":"OUT")+" type="+ep.getType()+" max="+ep.getMaxPacketSize()+" interval="+ep.getInterval());
            }
        }
    }

    private static boolean isObservedNormal(UsbDevice d) {
        return d!=null && d.getVendorId()==OBSERVED_VID && d.getProductId()==OBSERVED_PID && d.getInterfaceCount()==7;
    }

    private void requestOrProbe(UsbDevice d) {
        if (usb.hasPermission(d)) { probeReadOnly(d); return; }
        requestPermission(d,false);
    }

    private void requestPermission(UsbDevice d, boolean forCandidate) {
        waitingCandidatePermission=forCandidate;
        int flags=PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT>=31?PendingIntent.FLAG_MUTABLE:0);
        PendingIntent pi=PendingIntent.getBroadcast(this,0,new Intent(ACTION_USB_PERMISSION).setPackage(getPackageName()),flags);
        usb.requestPermission(d,pi);
    }

    private UsbInterface findIf4(UsbDevice d) {
        for (int i=0;i<d.getInterfaceCount();i++) {
            UsbInterface x=d.getInterface(i);
            if (x.getId()==4 && x.getInterfaceClass()==UsbConstants.USB_CLASS_HID) return x;
        }
        return null;
    }

    private UsbInterface findIf3(UsbDevice d) {
        for (int i=0;i<d.getInterfaceCount();i++) {
            UsbInterface x=d.getInterface(i);
            if (x.getId()==3 && x.getInterfaceClass()==UsbConstants.USB_CLASS_HID) return x;
        }
        return null;
    }

    private UsbEndpoint findIf3InterruptIn(UsbInterface x) {
        if (x==null) return null;
        for (int i=0;i<x.getEndpointCount();i++) {
            UsbEndpoint ep=x.getEndpoint(i);
            if (ep.getAddress()==0x81 && ep.getDirection()==UsbConstants.USB_DIR_IN
                    && ep.getType()==UsbConstants.USB_ENDPOINT_XFER_INT && ep.getMaxPacketSize()==64) return ep;
        }
        return null;
    }

    private void probeReadOnly(UsbDevice d) {
        new Thread(() -> {
            UsbDeviceConnection c=usb.openDevice(d);
            if (c==null) { ui("Permission/open: FAILED"); return; }
            try {
                ui("Permission/open: OK");
                String manufacturer=safe(d.getManufacturerName());
                String product=safe(d.getProductName());
                ui("Manufacturer: "+manufacturer);
                ui("Product: "+product);
                ui("Serial: "+safe(d.getSerialNumber()));
                UsbInterface x4=findIf4(d);
                UsbInterface x3=findIf3(d);
                UsbEndpoint ep81=findIf3InterruptIn(x3);
                if (x4==null) { ui("IF4 HID missing"); return; }

                byte[] rd=new byte[255];
                int rn=c.controlTransfer(0x81,0x06,0x2200,x4.getId(),rd,rd.length,1500);
                ui("IF4 HID REPORT => "+rn+" bytes");
                if (rn>0) ui("  "+hex(rd,rn));

                byte[] ft=new byte[8];
                int fn=c.controlTransfer(0xA1,0x01,0x0300,x4.getId(),ft,ft.length,1500);
                ui("GET_REPORT FEATURE IF4 ID0 len8 => "+fn+" bytes");
                if (fn>0) ui("  FEATURE: "+hex(ft,fn));

                boolean exactReport=rn==EXPECTED_IF4_REPORT.length && Arrays.equals(Arrays.copyOf(rd,rn),EXPECTED_IF4_REPORT);
                boolean exactFeature=fn==EXPECTED_FEATURE.length && Arrays.equals(ft,EXPECTED_FEATURE);
                boolean exactIf3In=ep81!=null;
                boolean exactStrings=OBSERVED_MANUFACTURER.equals(manufacturer) && OBSERVED_PRODUCT.equals(product);
                boolean exactDevice=isObservedNormal(d);
                boolean all=exactDevice && exactStrings && exactReport && exactFeature && exactIf3In;
                exactNormalGatePassed=all;
                ui("VID/PID/interface-count exact gate: "+(exactDevice?"PASS":"FAIL"));
                ui("Manufacturer/Product exact gate: "+(exactStrings?"PASS":"FAIL"));
                ui("IF4 descriptor exact gate: "+(exactReport?"PASS":"FAIL"));
                ui("IF4 feature exact gate: "+(exactFeature?"PASS":"FAIL"));
                ui("IF3 EP81 interrupt-IN exact gate: "+(exactIf3In?"PASS":"FAIL"));
                ui("R15 NORMAL PREFLIGHT: "+(all?"PASS — manual flashboot-entry button unlocked":"FAIL — flashboot entry remains locked"));
                uiSetEnter(all);

                byte[] input=new byte[256];
                int in=c.controlTransfer(0xA1,0x01,0x0100,x4.getId(),input,input.length,500);
                ui("GET_REPORT INPUT IF4 ID0 len256 => "+in+" bytes");
                if (in>0) ui("  INPUT: "+hex(input,in));
                ui("R15 normal probe complete. No claimInterface(force=true), no SET_REPORT here, no endpoint OUT, no flash operation.");
            } catch (Throwable t) {
                ui("R15 read-only exception: "+t.getClass().getSimpleName()+": "+safe(t.getMessage()));
            } finally { c.close(); }
        },"okn-r15-readonly").start();
    }

    private void bootloaderPreflight() {
        add("=== R15 BOOTLOADER PREFLIGHT ===");
        add("Required normal fingerprint:");
        add("  VID:PID 6324:1719 / interfaces=7");
        add("  JMDSTECH / DSTech DSP ComboDigitalArchitect");
        add("  IF4 FF00:55AA, 256-IN, 256-OUT, Feature-8");
        add("  FEATURE baseline 00 01 00 03 04 00 08 00");
        add("This preflight itself is read-only. Button 5 remains disabled until every gate passes in the current app session.");
        scan();
    }

    private void confirmEnterFlashboot() {
        if (!exactNormalGatePassed || selected==null || !isObservedNormal(selected)) {
            add("FLASHBOOT ENTRY BLOCKED: exact normal gate is not currently PASS.");
            uiSetEnter(false);
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Enter flashboot once?")
                .setMessage("This changes the running mode but R15 does NOT erase, program, commit, or send a firmware payload. The app will send one HID Feature SET_REPORT with AA after re-checking the exact normal fingerprint, then one Feature GET_REPORT to request the stock handoff. It will only observe USB re-enumeration afterwards. If the board does not return to normal on its own, power-cycle it. Continue only with stable board power and USB cable.")
                .setNegativeButton("CANCEL",null)
                .setPositiveButton("ENTER FLASHBOOT",(d,w) -> enterFlashbootOnce())
                .show();
    }

    private void enterFlashbootOnce() {
        final UsbDevice d=selected;
        if (d==null || !usb.hasPermission(d)) { add("FLASHBOOT ENTRY BLOCKED: USB permission missing"); return; }
        new Thread(() -> {
            UsbDeviceConnection c=usb.openDevice(d);
            if (c==null) { ui("FLASHBOOT ENTRY BLOCKED: openDevice failed"); return; }
            boolean armed=false;
            try {
                UsbInterface x4=findIf4(d);
                UsbInterface x3=findIf3(d);
                UsbEndpoint ep81=findIf3InterruptIn(x3);
                if (x4==null || ep81==null || !isObservedNormal(d)) { ui("FLASHBOOT ENTRY BLOCKED: interface gate changed"); return; }

                byte[] rd=new byte[255];
                int rn=c.controlTransfer(0x81,0x06,0x2200,x4.getId(),rd,rd.length,1500);
                byte[] ft=new byte[8];
                int fn=c.controlTransfer(0xA1,0x01,0x0300,x4.getId(),ft,ft.length,1500);
                String manufacturer=safe(d.getManufacturerName());
                String product=safe(d.getProductName());
                boolean gate=rn==EXPECTED_IF4_REPORT.length && Arrays.equals(Arrays.copyOf(rd,rn),EXPECTED_IF4_REPORT)
                        && fn==EXPECTED_FEATURE.length && Arrays.equals(ft,EXPECTED_FEATURE)
                        && OBSERVED_MANUFACTURER.equals(manufacturer) && OBSERVED_PRODUCT.equals(product);
                if (!gate) { ui("FLASHBOOT ENTRY BLOCKED: final immediate re-check FAIL"); return; }

                ui("=== R15 MANUAL FLASHBOOT ENTRY ===");
                ui("Final immediate normal fingerprint: PASS");
                byte[] arm=new byte[8];
                arm[0]=(byte)0xAA;
                int wn=c.controlTransfer(0x21,0x09,0x0300,x4.getId(),arm,arm.length,1500);
                ui("SET_REPORT FEATURE AA len8 => "+wn+" bytes");
                if (wn!=8) { ui("AA arm transfer did not complete; stopping. No further OUT transfer will be sent."); return; }
                armed=true;
                try { Thread.sleep(40); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }

                byte[] trigger=new byte[8];
                int gn=c.controlTransfer(0xA1,0x01,0x0300,x4.getId(),trigger,trigger.length,1500);
                ui("GET_REPORT FEATURE after AA => "+gn+" bytes");
                if (gn>0) ui("  FEATURE: "+hex(trigger,gn));
                ui("No erase/program/commit/payload was sent. Closing normal-mode connection and observing re-enumeration only.");
            } catch (Throwable t) {
                ui("Flashboot-entry transport exception: "+t.getClass().getSimpleName()+": "+safe(t.getMessage()));
            } finally {
                c.close();
                if (armed) monitorReenumeration();
            }
        },"okn-r15-flashboot-entry").start();
    }

    private void monitorReenumeration() {
        new Thread(() -> {
            ui("=== RE-ENUMERATION WATCH 20s ===");
            candidate=null;
            uiSetInspect(false);
            String last="";
            long end=SystemClock.elapsedRealtime()+20000L;
            while (SystemClock.elapsedRealtime()<end) {
                Map<String,UsbDevice> map=usb.getDeviceList();
                ArrayList<UsbDevice> list=new ArrayList<>(map.values());
                list.sort((a,b) -> Integer.compare(a.getDeviceId(),b.getDeviceId()));
                String sig=deviceSetSignature(list);
                if (!sig.equals(last)) {
                    last=sig;
                    ui("USB SET: "+sig);
                    for (UsbDevice x:list) {
                        ui("  "+brief(x));
                        uiDumpInterfaces(x);
                        boolean changed=!isObservedNormal(x);
                        if (changed) {
                            candidate=x;
                            ui("*** RE-ENUMERATED CANDIDATE DETECTED *** deviceId="+x.getDeviceId());
                            uiSetInspect(true);
                        }
                    }
                }
                try { Thread.sleep(250); } catch (InterruptedException e) { Thread.currentThread().interrupt(); break; }
            }
            if (candidate==null) {
                ui("No changed USB candidate observed during 20s. Do not send AA again. Power-cycle the board once, then run button 2 and send the resulting log.");
            } else {
                ui("Candidate captured. Use button 6 for read-only descriptor inspection. Do not power-cycle until you have copied this log unless the board is unresponsive.");
            }
            ui("=== END RE-ENUMERATION WATCH ===");
        },"okn-r15-reenum-watch").start();
    }

    private void inspectCandidate() {
        UsbDevice d=candidate;
        if (d==null) { add("No re-enumerated candidate captured in this app session."); return; }
        add("=== CANDIDATE READ-ONLY INSPECTION REQUEST ===");
        add(brief(d));
        if (usb.hasPermission(d)) probeCandidateReadOnly(d);
        else requestPermission(d,true);
    }

    private void probeCandidateReadOnly(UsbDevice d) {
        new Thread(() -> {
            UsbDeviceConnection c=usb.openDevice(d);
            if (c==null) { ui("Candidate openDevice failed"); return; }
            try {
                ui("=== CANDIDATE READ-ONLY INSPECTION ===");
                ui("VID:PID="+String.format(Locale.US,"%04X:%04X",d.getVendorId(),d.getProductId())+" deviceId="+d.getDeviceId());
                ui("Manufacturer: "+safe(d.getManufacturerName()));
                ui("Product: "+safe(d.getProductName()));
                ui("Serial: "+safe(d.getSerialNumber()));
                uiDumpInterfaces(d);
                for (int i=0;i<d.getInterfaceCount();i++) {
                    UsbInterface x=d.getInterface(i);
                    if (x.getInterfaceClass()!=UsbConstants.USB_CLASS_HID) continue;
                    byte[] rd=new byte[255];
                    int rn=c.controlTransfer(0x81,0x06,0x2200,x.getId(),rd,rd.length,1000);
                    ui("HID IF"+x.getId()+" REPORT DESCRIPTOR => "+rn+" bytes");
                    if (rn>0) ui("  "+hex(rd,rn));
                    byte[] f=new byte[64];
                    int fn=c.controlTransfer(0xA1,0x01,0x0300,x.getId(),f,f.length,700);
                    ui("HID IF"+x.getId()+" GET_REPORT FEATURE ID0 len64 => "+fn+" bytes");
                    if (fn>0) ui("  "+hex(f,fn));
                }
                ui("Candidate inspection complete: control-IN only. No SET_REPORT / no endpoint OUT / no flash command.");
            } catch (Throwable t) {
                ui("Candidate read-only exception: "+t.getClass().getSimpleName()+": "+safe(t.getMessage()));
            } finally { c.close(); }
        },"okn-r15-candidate-readonly").start();
    }

    private void scanAndroidInputDevices() {
        add("=== ANDROID INPUT DEVICE SCAN / PASSIVE WATCH ===");
        if (inputManager==null) { add("InputManager unavailable"); return; }
        int[] ids=InputDevice.getDeviceIds();
        add("Android InputDevice count: "+ids.length);
        int matches=0;
        for (int id: ids) {
            InputDevice dev=InputDevice.getDevice(id);
            if (dev==null) continue;
            int vid=dev.getVendorId(), pid=dev.getProductId();
            boolean target=(vid==OBSERVED_VID && pid==OBSERVED_PID);
            if (target) matches++;
            add(String.format(Locale.US,
                    "%sInputDevice id=%d name=%s VID=0x%04X PID=0x%04X sources=0x%08X keyboardType=%d virtual=%s",
                    target?"*** TARGET INPUT *** ":"", id, safe(dev.getName()), vid, pid, dev.getSources(),
                    dev.getKeyboardType(), dev.isVirtual()));
            add("  descriptor="+safe(dev.getDescriptor()));
            List<InputDevice.MotionRange> ranges=dev.getMotionRanges();
            add("  motionRanges="+ranges.size());
            for (InputDevice.MotionRange r: ranges) {
                add("    axis="+MotionEvent.axisToString(r.getAxis())+" source=0x"+Integer.toHexString(r.getSource())+
                        " min="+r.getMin()+" max="+r.getMax()+" flat="+r.getFlat()+" fuzz="+r.getFuzz()+" res="+r.getResolution());
            }
        }
        add("Exact 6324:1719 Android InputDevice matches: "+matches);
        if (matches>0) {
            add("PASSIVE WATCH ACTIVE: if Android converts IF3 reports into KeyEvent/MotionEvent while this screen is focused, they will be logged below.");
            add("This watch does not claim/detach USB and sends zero USB OUT packets.");
        } else {
            add("No Android InputDevice with exact VID/PID. IF3 may be kernel-bound without being exposed through the public InputDevice API.");
        }
        add("=== END INPUT DEVICE SCAN ===");
    }

    private boolean isTargetInputEventDevice(int deviceId) {
        InputDevice d=InputDevice.getDevice(deviceId);
        return d!=null && d.getVendorId()==OBSERVED_VID && d.getProductId()==OBSERVED_PID;
    }

    private static String keyActionToString(int action) {
        switch (action) {
            case KeyEvent.ACTION_DOWN: return "ACTION_DOWN";
            case KeyEvent.ACTION_UP: return "ACTION_UP";
            case KeyEvent.ACTION_MULTIPLE: return "ACTION_MULTIPLE";
            default: return "ACTION_"+action;
        }
    }

    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        if (event!=null && isTargetInputEventDevice(event.getDeviceId())) {
            add("TARGET KeyEvent action="+keyActionToString(event.getAction())+
                    " code="+KeyEvent.keyCodeToString(event.getKeyCode())+
                    " scanCode="+event.getScanCode()+" repeat="+event.getRepeatCount()+
                    " source=0x"+Integer.toHexString(event.getSource()));
        }
        return super.dispatchKeyEvent(event);
    }

    @Override public boolean dispatchGenericMotionEvent(MotionEvent event) {
        if (event!=null && isTargetInputEventDevice(event.getDeviceId())) {
            StringBuilder b=new StringBuilder();
            b.append("TARGET MotionEvent action=").append(MotionEvent.actionToString(event.getAction()))
             .append(" source=0x").append(Integer.toHexString(event.getSource()));
            InputDevice d=event.getDevice();
            if (d!=null) {
                for (InputDevice.MotionRange r: d.getMotionRanges()) {
                    b.append(' ').append(MotionEvent.axisToString(r.getAxis())).append('=')
                     .append(event.getAxisValue(r.getAxis()));
                }
            }
            add(b.toString());
        }
        return super.dispatchGenericMotionEvent(event);
    }

    private static String deviceSetSignature(List<UsbDevice> list) {
        StringBuilder b=new StringBuilder();
        for (UsbDevice d:list) {
            if (b.length()>0) b.append(" | ");
            b.append(String.format(Locale.US,"%04X:%04X/i%d/id%d",d.getVendorId(),d.getProductId(),d.getInterfaceCount(),d.getDeviceId()));
        }
        return b.length()==0?"<no USB devices>":b.toString();
    }

    private static String brief(UsbDevice d) {
        if (d==null) return "<null device>";
        return String.format(Locale.US,"VID:PID=%04X:%04X interfaces=%d deviceId=%d name=%s",
                d.getVendorId(),d.getProductId(),d.getInterfaceCount(),d.getDeviceId(),safe(d.getDeviceName()));
    }

    private void uiDumpInterfaces(UsbDevice d) {
        for (int i=0;i<d.getInterfaceCount();i++) {
            UsbInterface x=d.getInterface(i);
            ui("    IDX"+i+" IF"+x.getId()+" alt="+x.getAlternateSetting()+" class="+x.getInterfaceClass()+" sub="+x.getInterfaceSubclass()+" proto="+x.getInterfaceProtocol()+" ep="+x.getEndpointCount());
            for (int e=0;e<x.getEndpointCount();e++) {
                UsbEndpoint ep=x.getEndpoint(e);
                ui("      EP addr=0x"+String.format(Locale.US,"%02X",ep.getAddress())+" dir="+(ep.getDirection()==UsbConstants.USB_DIR_IN?"IN":"OUT")+" type="+ep.getType()+" max="+ep.getMaxPacketSize()+" interval="+ep.getInterval());
            }
        }
    }

    private void uiSetEnter(boolean enabled) { runOnUiThread(() -> enterBoot.setEnabled(enabled)); }
    private void uiSetInspect(boolean enabled) { runOnUiThread(() -> inspectCandidate.setEnabled(enabled)); }
    private static String safe(String s){ return s==null?"<null>":s; }
    private static String hex(byte[] b,int n){
        if (b==null || n<=0) return "<none>";
        StringBuilder s=new StringBuilder();
        for(int i=0;i<n && i<b.length;i++){
            if(i>0)s.append(' ');
            s.append(String.format(Locale.US,"%02X",b[i]&0xFF));
        }
        return s.toString();
    }
    private void add(String s){ runOnUiThread(() -> log.append(s+"\n")); }
    private void ui(String s){ runOnUiThread(() -> log.append(s+"\n")); }
}
