# OKN BP1048P4 Phase3 TRUE7CH R15 — Bootloader Preflight / Discovery

R15 ต่อจาก R14 หลังยืนยันกับบอร์ดจริงบน Samsung S25+ แล้วว่า normal-mode production fingerprint คือ:

- VID:PID `6324:1719`
- Manufacturer `JMDSTECH`
- Product `DSTech DSP ComboDigitalArchitect`
- 7 interfaces
- IF4 vendor HID: Usage Page `FF00`, Usage `55AA`, Input 256, Output 256, Feature 8
- Feature baseline `00 01 00 03 04 00 08 00`
- IF3 interrupt-IN endpoint `0x81`, 64 bytes

## TRUE 7CH DSP core

คงเดิมจาก R14:
- dedicated PCM gain CH1..CH7 หลัง EQ/crossover และก่อน physical output sink
- ห้ามใช้ EQ/Biquad gain ทำ Channel Volume
- IDs 22..28 เป็น custom UFE actuator ของ firmware OKN ใหม่เท่านั้น
- -70..+6 dB, step 0.5 dB

## สิ่งใหม่ใน R15

Android app เพิ่ม manual bootloader discovery ที่ถูกล็อกด้วย exact normal fingerprint ทั้งชุด:

1. ปุ่ม 2/4 ทำ read-only normal probe และเปิดปุ่ม 5 เฉพาะเมื่อทุก gate PASS
2. ปุ่ม 5 แสดง confirmation dialog และ re-check fingerprint ทันทีอีกครั้ง
3. เมื่อผู้ใช้ยืนยันเอง R15 ส่ง Feature SET_REPORT 8 bytes ที่ byte0=`AA` เพียงครั้งเดียว
4. ส่ง Feature GET_REPORT เพียงครั้งเดียวเพื่อขอ stock handoff
5. ปิด connection normal-mode แล้ว monitor USB re-enumeration 20 วินาที
6. ถ้าเจอ VID/PID/interface shape ที่เปลี่ยน จะบันทึกเป็น bootloader candidate
7. ปุ่ม 6 อ่าน descriptor/Feature ของ candidate แบบ control-IN เท่านั้น

## R15 ยังไม่ทำ

- ไม่มี firmware payload
- ไม่มี endpoint OUT / bulk transfer
- ไม่มี erase / sector erase / chip erase
- ไม่มี flash program / verify / commit
- ไม่มี automatic boot entry
- ไม่มี `.bin` / `.mva` สำหรับเขียนบอร์ด

ดังนั้นเป้าหมายของ R15 คือหา **bootloader VID/PID + interface/descriptor shape** จากบอร์ดจริงเท่านั้น ก่อนเริ่ม reverse-engineer wire protocol ในรุ่นถัดไป
