#!/usr/bin/env python3
from pathlib import Path
p=Path(__file__).resolve().parents[1]/"android-usb-probe/app/src/main/java/com/okn/dsp/usbprobe/MainActivity.java"
s=p.read_text(encoding="utf-8")
required=[
    'arm[0]=(byte)0xAA;',
    'controlTransfer(0x21,0x09,0x0300,x4.getId(),arm,arm.length,1500)',
    'controlTransfer(0xA1,0x01,0x0300,x4.getId(),trigger,trigger.length,1500)',
    'No erase/program/commit/payload was sent',
    'exactNormalGatePassed',
    'OBSERVED_VID = 0x6324',
    'OBSERVED_PID = 0x1719',
]
for x in required:
    assert x in s, f"missing R15 guard/flow: {x}"
for forbidden in [
    '.bulkTransfer(', '.claimInterface(', '.releaseInterface(',
    'chipErase', 'sectorErase', 'flashWrite', 'programFlash', 'commitFlash',
    'FirmwarePayload', 'sendFirmware', 'eraseAllFlash'
]:
    assert forbidden not in s, f"forbidden write/program path present: {forbidden}"
assert s.count('controlTransfer(0x21,0x09,0x0300,x4.getId(),arm,arm.length,1500)') == 1
assert s.count('arm[0]=(byte)0xAA;') == 1
print('R15 USB bootloader-preflight safety guard: PASS')
