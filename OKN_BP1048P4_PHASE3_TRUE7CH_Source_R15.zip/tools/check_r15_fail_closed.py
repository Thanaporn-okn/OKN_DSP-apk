#!/usr/bin/env python3
import json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
p=root/'config/FLASHBOOT_RESEARCH_STATE_R15.json'
d=json.loads(p.read_text(encoding='utf-8'))
assert d['verified_normal_board']['verified_on_samsung_s25_plus'] is True
assert d['r15_scope']['manual_feature_aa_boot_entry'] is True
assert d['r15_scope']['automatic_boot_entry'] is False
for k in ['firmware_payload','endpoint_out','erase','program','commit']:
    assert d['r15_scope'][k] is False, k
for k in ['enable_flash_write','enable_erase','enable_commit']:
    assert d['production_gate'][k] is False, k
for k in ['bootloader_vid_pid_observed','bootloader_interfaces_observed','bootloader_read_only_identity_observed','exact_flashboot_wire_protocol','exact_image_format','exact_flash_layout','stock_backup_available','recovery_verified']:
    assert d['production_gate'][k] is False, k
print('R15 fail-closed flash policy: PASS')
