# R15 Build Notes

- Base: R14 TRUE7CH source
- Verified normal production fingerprint imported from Samsung S25+ runtime log
- Android versionCode 15 / versionName 0.15-r15-bootloader-preflight
- Adds manual-only AA Feature SET_REPORT + Feature GET_REPORT handoff path
- Adds 20-second USB re-enumeration watcher and read-only candidate inspection
- No firmware payload, endpoint OUT, erase, program, commit, or automatic boot entry
- Host safety guards updated for the intentionally narrow R15 state-changing surface
