import 'package:flutter/material.dart';

void main()=>runApp(const App());

class App extends StatelessWidget{
 const App({super.key});
 Widget build(BuildContext c)=>MaterialApp(
  debugShowCheckedModeBanner:false,
  theme:ThemeData.dark(),
  home:const Home());
}

class Home extends StatelessWidget{
 const Home({super.key});
 Widget build(BuildContext c)=>Scaffold(
 appBar:AppBar(title:const Text('OKN_DSP BP1048P4 V27')),
 body:ListView(
 padding:const EdgeInsets.all(20),
 children:const[
 Text('Bluetooth DSP Command System',
 style:TextStyle(fontSize:26,color:Colors.cyan)),
 SizedBox(height:20),
 Text('Device Scan Ready\n'
 'Connect / Disconnect\n'
 'BP1048P4 Command Queue\n'
 'TX Packet\n'
 'RX Parser\n'
 'HEX TX RX Log\n'
 'CH1-CH7 DSP Control\n'
 'Volume EQ Delay HPF LPF',
 style:TextStyle(fontSize:18))
 ]));
}
