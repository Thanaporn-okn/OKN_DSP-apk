// BP1048P4 DSP command layer
// Volume EQ Delay HPF LPF
