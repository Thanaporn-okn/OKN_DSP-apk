// BP1048P4 Command Queue
// Packet buffer for DSP commands
