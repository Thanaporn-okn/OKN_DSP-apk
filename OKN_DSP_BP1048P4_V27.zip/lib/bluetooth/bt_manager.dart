// V27 Bluetooth Manager
// Scan / Connect / Disconnect / TX RX handler
