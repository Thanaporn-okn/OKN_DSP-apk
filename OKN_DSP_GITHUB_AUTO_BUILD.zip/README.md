OKN_DSP GitHub Auto Build

1. Upload OKN_DSP_GITHUB_BUILD.zip to this repository
2. Go to Actions
3. Run Build OKN_DSP APK
4. Download OKN_DSP_APK artifact
