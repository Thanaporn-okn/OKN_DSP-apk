# OKN DSP V16 — Phase 1

V16 is built directly from **V14** as requested. The discarded V15 redesign is not used.

## Fixed in V16

- Fixed a touch-routing bug where tapping **Home** or **Mix** on the bottom navigation could change **EQ Gain Band** instead of switching pages.
- Bottom navigation now has first priority for touch input over sliders.
- EQ/Mix slider hit testing is limited to the visible content area and cannot remain active underneath the navigation bar.
- Keeps V14 appearance and behavior: Mix mint/teal/green controls, EQ Frequency blue, Q cyan/teal, Gain Band mint green, presets, real-time persistence, and safe-area WindowInsets.

Version: **16.0.0** (`versionCode 1016`)
