OKN DSP V40 AUTO RANDKEY + LIVE READ-ONLY HANDSHAKE

Verified from V39 Dart 3.6 AOT call-site:
- auth response must be 32 bytes
- TypeID = BE16 bytes 0..1
- VersionID = BE16 bytes 2..3
- ciphertext = bytes 8..31 (24 bytes)
- AES-CFB8 IV = 01 repeated 16 bytes
- default fixed pre-auth key = 2AAF948632A59FF8F2B23E6E4193FD21
- TypeID 53285 fixed pre-auth key = 10E7D2F443924938A28D759BAC0E9E22
- plaintext24 = uniqueID 8 bytes + RandKey 16 bytes
- all 4 official paired vectors reproduce RandKey exactly

V40 live path remains READ-ONLY:
AUTH16 -> derive current-session RandKey -> encrypted Device Description request -> decrypt/reassemble 0x86/0x82 JSON -> send UFE READ 0x58 sensor ID 0 -> decode RESPONSE 0x60 FLOAT32.

DSP parameter WRITE command 0x57 remains locked.
