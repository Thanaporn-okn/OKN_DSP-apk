OKN_DSP V22 — STRICT 15/15 ISO HARDWARE CENTRES
================================================
Graphic EQ centres, Band 1..15:
25, 40, 63, 100, 160, 250, 400, 630, 1000, 1600, 2500, 4000, 6300, 10000, 16000 Hz.

For every CH1..CH7, changing Gain or Q writes a canonical type=12 PEAKING record whose F exactly equals the printed centre.
This includes slot 1, which V21 had left in native type17/type3 form.
Unknown future record types fail closed.
Q range remains 0.05..20.00. Gain remains -12..+12 dB.
Shared 380 ms latest-target scheduler, authenticated AES-CFB8 transport, applicationId and signing key are unchanged.
No auto SaveParams.
