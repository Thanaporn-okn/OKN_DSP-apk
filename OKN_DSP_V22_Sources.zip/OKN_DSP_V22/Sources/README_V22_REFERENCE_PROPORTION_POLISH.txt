OKN_DSP V22 — Phase 1 Reference-Proportion Polish

Purpose
- Re-tune UI proportions against the four user-provided reference screens.
- Keep every screen code-drawn; no uploaded screenshot/video is packaged as a runtime image.
- Preserve immediate local interaction for every Phase-1 control.

V22 visual changes
- Header/logo/title scale and vertical placement re-aligned to the reference compositions.
- UI text uses the platform Roboto system font file when available, with Android sans-serif fallback, so Samsung custom display fonts do not alter the intended DSP UI proportions.
- Mix control cards use capped reference-like heights, larger typography, fixed internal spacing, larger knobs, and adaptive inter-card spacing on tall phones.
- Home device artwork is less vertically stretched; card/status/preset typography has stronger reference scale.
- EQ and Crossover headings/output/filter text increased to match the reference hierarchy.
- DSP chassis perspective, face label, grooves and lower glow are all Canvas/vector drawing.
- Bottom navigation icon/text emphasis and selection underline are closer to the reference screens.
- Tall-screen fill remains responsive; no screenshot background is used.

Phase 2
- BLE/DSP transport remains intentionally deferred until protocol/control data is supplied.
