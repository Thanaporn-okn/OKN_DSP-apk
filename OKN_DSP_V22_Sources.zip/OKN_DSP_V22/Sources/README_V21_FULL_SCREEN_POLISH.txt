OKN_DSP V21 — Phase 1 Full-Screen Polish

Basis: real-device video 29990.mp4 (1080x2340) supplied by user.

Changes:
- Rebalanced every page to consume the usable viewport up to the bottom navigation.
- Removed large vertical dead zones by sizing panels from the actual viewport height.
- Home hero, status, action cards, presets and system status scale as one continuous layout.
- Mix controls use evenly-sized full-height cards with consistent 10px virtual gaps.
- EQ graph/control/output/preset regions resize as a unified layout.
- Crossover hero, graph, filter and delay regions are packed continuously without the prior lower-page gap.
- Enlarged slider touch targets while keeping the visible track clean.
- Drag updates use postInvalidateOnAnimation and retain immediate local state updates.
- Uses the app hardware-accelerated Canvas path; no reference screenshot is bundled or drawn as a bitmap/background.

Phase 1 only: BLE/DSP transport remains disabled until Phase 2 protocol data is supplied.
