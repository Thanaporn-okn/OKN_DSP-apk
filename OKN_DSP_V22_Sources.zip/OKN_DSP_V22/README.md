# OKN DSP V22 — Phase 1

V22 is built from V21 and fixes the last preset-delete confirmation screen that was still using the stock Android AlertDialog.

## V22 UI fix

- Custom rounded Delete Preset dialog matching the app UI.
- Theme-aware Light / Dark / Midnight presentation.
- Red/pink danger accent used only for the destructive delete confirmation.
- Preset name preview and clear irreversible-action note.
- Custom Cancel and Delete buttons.
- Keeps all V21 behavior and performance/touch fixes unchanged.

- versionName: 22.0.0
- versionCode: 1022
- Base: V21
- Phase: 1 UI hardening
