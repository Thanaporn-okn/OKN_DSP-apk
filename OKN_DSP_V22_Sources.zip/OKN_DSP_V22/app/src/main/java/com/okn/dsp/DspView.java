package com.okn.dsp;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

/**
 * OKN_DSP V22 Phase-1 UI — reference-proportion typography + visual polish pass.
 *
 * IMPORTANT: every visible screen is drawn from code with Canvas primitives.
 * No uploaded UI screenshot is used as a background, bitmap, texture or runtime
 * resource.  All sliders/toggles/buttons update local state immediately while the
 * finger is moving.  DSP/BLE transport is intentionally deferred to Phase 2.
 */
public final class DspView extends View {
    private static final float W = 900f;
    private static final float BASE_H = 1600f;
    private static final float NAV_H = 150f;

    private static final int PAGE_HOME = 0;
    private static final int PAGE_MIX = 1;
    private static final int PAGE_EQ = 2;
    private static final int PAGE_CROSS = 3;

    private static final int SL_MASTER = 1;
    private static final int SL_BASS_VOLUME = 2;
    private static final int SL_BASS_CUTOFF = 3;
    private static final int SL_BASS_BOOST = 4;
    private static final int SL_MID_BOOST = 5;
    private static final int SL_TREBLE_BOOST = 6;
    private static final int SL_EQ_FREQ = 20;
    private static final int SL_EQ_GAIN = 21;
    private static final int SL_EQ_Q = 22;
    private static final int SL_EQ_OUTPUT = 23;
    private static final int SL_HPF_FREQ = 30;
    private static final int SL_LPF_FREQ = 31;
    private static final int SL_DELAY_MS = 32;
    private static final int SL_DISTANCE_CM = 33;

    private static final int A_GEAR = 1;
    private static final int A_CONNECT = 2;
    private static final int A_NAV_BASE = 10;
    private static final int A_HOME_MIX = 30;
    private static final int A_HOME_EQ = 31;
    private static final int A_HOME_CROSS = 32;
    private static final int A_HOME_PRESET = 33;
    private static final int A_PRESET_BASE = 50;
    private static final int A_EQ_CH_BASE = 100;
    private static final int A_EQ_BAND_PREV = 120;
    private static final int A_EQ_BAND_NEXT = 121;
    private static final int A_EQ_FREQ_MINUS = 122;
    private static final int A_EQ_FREQ_PLUS = 123;
    private static final int A_EQ_GAIN_MINUS = 124;
    private static final int A_EQ_GAIN_PLUS = 125;
    private static final int A_EQ_Q_MINUS = 126;
    private static final int A_EQ_Q_PLUS = 127;
    private static final int A_EQ_LINK_ALL = 128;
    private static final int A_EQ_SAVE = 129;
    private static final int A_EQ_LOAD = 130;
    private static final int A_EQ_CHANNEL_PILL = 131;
    private static final int A_PRESET_SEE_ALL = 132;
    private static final int A_EQ_POINT_BASE = 150;
    private static final int A_CROSS_CH_BASE = 200;
    private static final int A_HPF_TOGGLE = 220;
    private static final int A_LPF_TOGGLE = 221;
    private static final int A_HPF_SLOPE_BASE = 230;
    private static final int A_LPF_SLOPE_BASE = 240;
    private static final int A_PHASE_0 = 250;
    private static final int A_PHASE_180 = 251;
    private static final int A_LINK_FILTERS = 252;
    private static final int A_HPF_MINUS = 260;
    private static final int A_HPF_PLUS = 261;
    private static final int A_LPF_MINUS = 262;
    private static final int A_LPF_PLUS = 263;
    private static final int A_DELAY_MINUS = 264;
    private static final int A_DELAY_PLUS = 265;
    private static final int A_DISTANCE_MINUS = 266;
    private static final int A_DISTANCE_PLUS = 267;
    private static final int A_DELAY_TOGGLE = 268;
    private static final int A_OVERLAY_RESET = 300;
    private static final int A_OVERLAY_CLOSE = 301;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final Typeface uiRegular = loadUiTypeface(false);
    private final Typeface uiBold = loadUiTypeface(true);
    private final DspState state = new DspState();
    private final ArrayList<Hit> hits = new ArrayList<>();
    private final ArrayList<SliderHit> sliders = new ArrayList<>();

    private final int BG0 = Color.rgb(1, 8, 20);
    private final int BG1 = Color.rgb(0, 17, 39);
    private final int PANEL = Color.rgb(3, 25, 48);
    private final int PANEL_DEEP = Color.rgb(2, 15, 31);
    private final int BORDER = Color.rgb(16, 74, 130);
    private final int WHITE = Color.rgb(245, 249, 255);
    private final int SUB = Color.rgb(166, 190, 225);
    private final int CYAN = Color.rgb(20, 222, 255);
    private final int BLUE = Color.rgb(0, 126, 255);
    private final int MAGENTA = Color.rgb(255, 39, 224);
    private final int PURPLE = Color.rgb(159, 50, 255);
    private final int ORANGE = Color.rgb(255, 153, 16);
    private final int GREEN = Color.rgb(32, 235, 171);

    private int page = PAGE_HOME;
    private float scale = 1f;
    private float offsetX = 0f;
    private float offsetY = 0f;
    private float viewportH = BASE_H;
    private boolean overlayOpen = false;
    private boolean previewConnected = true;
    private int pressedAction = -1;
    private SliderHit activeSlider;
    private boolean draggingEqGraph = false;
    private RectF eqGraphBounds = new RectF();

    private boolean hpfEnabled = true;
    private boolean lpfEnabled = true;
    private boolean linkFilters = false;
    private float hpfHz = 80f;
    private float lpfHz = 4000f;
    private int hpfSlope = 24;
    private int lpfSlope = 24;
    private float delayMs = 0f;
    private float distanceCm = 0f;
    private final boolean[] phase180 = new boolean[DspState.CHANNELS];

    private static final class Hit {
        final RectF r;
        final int action;
        Hit(float l, float t, float rr, float b, int action) {
            this.r = new RectF(l, t, rr, b);
            this.action = action;
        }
    }

    private static final class SliderHit {
        final RectF r;
        final int id;
        final float min;
        final float max;
        final boolean logarithmic;
        SliderHit(float l, float t, float rr, float b, int id, float min, float max, boolean logarithmic) {
            this.r = new RectF(l, t, rr, b);
            this.id = id;
            this.min = min;
            this.max = max;
            this.logarithmic = logarithmic;
        }
    }

    public DspView(Context context) {
        super(context);
        setFocusable(true);
        setClickable(true);
        setHapticFeedbackEnabled(false);
        p.setDither(true);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        loadCrossover();
    }

    private boolean renderFallback = false;
    private String renderFault = "";

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (renderFallback) {
            drawCrashSafeFallback(canvas);
            return;
        }
        try {
            renderUi(canvas);
        } catch (RuntimeException ex) {
            renderFallback = true;
            renderFault = ex.getClass().getSimpleName();
            drawCrashSafeFallback(canvas);
        } catch (LinkageError err) {
            renderFallback = true;
            renderFault = err.getClass().getSimpleName();
            drawCrashSafeFallback(canvas);
        }
    }

    private void renderUi(Canvas canvas) {
        computeViewport();
        canvas.drawColor(BG0);
        hits.clear();
        sliders.clear();

        int saveCount = canvas.save();
        try {
            canvas.translate(offsetX, offsetY);
            canvas.scale(scale, scale);
            drawBackground(canvas);

            if (page == PAGE_HOME) drawHome(canvas);
            else if (page == PAGE_MIX) drawMix(canvas);
            else if (page == PAGE_EQ) drawEq(canvas);
            else drawCrossover(canvas);

            drawBottomNav(canvas);
            if (overlayOpen) drawSettingsOverlay(canvas);
        } finally {
            canvas.restoreToCount(saveCount);
        }
    }

    private void drawCrashSafeFallback(Canvas canvas) {
        canvas.drawColor(Color.rgb(1, 8, 20));
        Paint safe = new Paint(Paint.ANTI_ALIAS_FLAG);
        safe.setStyle(Paint.Style.FILL);
        safe.setColor(Color.WHITE);
        safe.setTextAlign(Paint.Align.CENTER);
        safe.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        float cx = getWidth() * 0.5f;
        float cy = getHeight() * 0.42f;
        safe.setTextSize(Math.max(28f, Math.min(getWidth(), getHeight()) * 0.045f));
        canvas.drawText("OKN_DSP V22", cx, cy, safe);
        safe.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        safe.setTextSize(Math.max(16f, Math.min(getWidth(), getHeight()) * 0.026f));
        safe.setColor(Color.rgb(20, 222, 255));
        canvas.drawText("UI safe mode", cx, cy + 54f, safe);
        safe.setColor(Color.rgb(166, 190, 225));
        safe.setTextSize(Math.max(13f, Math.min(getWidth(), getHeight()) * 0.020f));
        String suffix = renderFault.isEmpty() ? "" : " (" + renderFault + ")";
        canvas.drawText("Renderer recovered instead of closing" + suffix, cx, cy + 92f, safe);
    }

    private void computeViewport() {
        float widthScale = getWidth() / W;
        float hAtWidth = getHeight() / Math.max(widthScale, 0.0001f);
        if (hAtWidth >= BASE_H) {
            scale = widthScale;
            viewportH = hAtWidth;
            offsetX = 0f;
            offsetY = 0f;
        } else {
            scale = Math.min(widthScale, getHeight() / BASE_H);
            viewportH = BASE_H;
            offsetX = (getWidth() - W * scale) * 0.5f;
            offsetY = (getHeight() - BASE_H * scale) * 0.5f;
        }
    }

    private float extraH() {
        return Math.max(0f, viewportH - BASE_H);
    }

    private float y(float base, float stretchFraction) {
        return base + extraH() * stretchFraction;
    }

    private float navTop() {
        return viewportH - NAV_H;
    }

    private void drawBackground(Canvas c) {
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0, 0, 0, viewportH,
                BG1, BG0, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, W, viewportH, p);
        p.setShader(new RadialGradient(450, 320, 520,
                Color.argb(85, 0, 95, 210), Color.TRANSPARENT, Shader.TileMode.CLAMP));
        c.drawCircle(450, 320, 520, p);
        p.setShader(new RadialGradient(780, 980, 430,
                Color.argb(35, 166, 0, 255), Color.TRANSPARENT, Shader.TileMode.CLAMP));
        c.drawCircle(780, 980, 430, p);
        p.setShader(null);
    }

    private void drawHeader(Canvas c, String title, String subtitle, boolean showTitle) {
        drawLogo(c, 43, 18, 1.00f);
        drawConnectionPill(c, 494, 24, 284, 78);
        drawGear(c, 825, 62);
        addHit(796, 25, 865, 100, A_GEAR);
        addHit(492, 22, 775, 108, A_CONNECT);

        if (showTitle) {
            text(c, title, 450, 171, 66, WHITE, true, Paint.Align.CENTER);
            if (subtitle != null && !subtitle.isEmpty()) {
                letterText(c, subtitle.toUpperCase(Locale.US), 450, 205, 15, SUB, Paint.Align.CENTER, 7f);
            }
        }
    }

    private void drawLogo(Canvas c, float x, float top, float s) {
        float size = 64f * s;
        text(c, "OKN_", x, top + 60f * s, size, WHITE, true, Paint.Align.LEFT);
        float w = measure("OKN_", size, true);
        text(c, "DSP", x + w, top + 60f * s, size, Color.rgb(0, 159, 255), true, Paint.Align.LEFT);
        letterText(c, "AUDIO CONTROL", x + 7f * s, top + 88f * s, 13f * s, WHITE, Paint.Align.LEFT, 5.2f * s);
    }

    private void drawConnectionPill(Canvas c, float x, float top, float w, float h) {
        int accent = previewConnected ? CYAN : ORANGE;
        neonPanel(c, x, top, w, h, 38, accent, 0.55f);
        p.setColor(accent);
        p.setShadowLayer(17, 0, 0, accent);
        c.drawCircle(x + 43, top + h * 0.5f, 12, p);
        p.clearShadowLayer();
        text(c, previewConnected ? "Connected" : "Disconnected", x + 82, top + 34, 20, WHITE, true, Paint.Align.LEFT);
        text(c, previewConnected ? "OKN-DSP-7CH" : "DSP Offline", x + 82, top + 59, 15, SUB, false, Paint.Align.LEFT);
    }

    private void drawGear(Canvas c, float cx, float cy) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(4f);
        p.setColor(WHITE);
        p.setShadowLayer(8, 0, 0, Color.argb(170, 70, 150, 255));
        c.drawCircle(cx, cy, 22, p);
        c.drawCircle(cx, cy, 8, p);
        for (int i = 0; i < 8; i++) {
            double a = Math.PI * 2.0 * i / 8.0;
            float x1 = cx + (float) Math.cos(a) * 23f;
            float y1 = cy + (float) Math.sin(a) * 23f;
            float x2 = cx + (float) Math.cos(a) * 31f;
            float y2 = cy + (float) Math.sin(a) * 31f;
            c.drawLine(x1, y1, x2, y2, p);
        }
        p.clearShadowLayer();
        p.setStyle(Paint.Style.FILL);
    }

    private void drawHome(Canvas c) {
        drawHeader(c, "", "", false);

        final float bodyTop = 112f;
        final float bottom = navTop() - 14f;
        final float gap = 12f;
        final float usable = Math.max(1200f, bottom - bodyTop - gap * 5f);
        final float heroH = usable * 0.255f;
        final float statsH = usable * 0.082f;
        final float masterH = usable * 0.115f;
        final float cardsH = usable * 0.275f;
        final float quickH = usable * 0.145f;
        final float statusH = usable - heroH - statsH - masterH - cardsH - quickH;

        float heroTop = bodyTop;
        letterText(c, "PURE SOUND", 52, heroTop + 45, 14, SUB, Paint.Align.LEFT, 5f);
        letterText(c, "YOUR WAY", 52, heroTop + 68, 14, SUB, Paint.Align.LEFT, 5f);
        letterText(c, "DRIVE A", 848, heroTop + 45, 14, SUB, Paint.Align.RIGHT, 5f);
        letterText(c, "BETTER TOMORROW", 848, heroTop + 68, 14, SUB, Paint.Align.RIGHT, 4f);
        drawNeonWave(c, heroTop + heroH * 0.46f, Math.max(58f, heroH * 0.16f), 0f);
        float deviceH = Math.min(286f, heroH * 0.68f);
        float deviceW = Math.min(548f, deviceH * 1.92f);
        drawDevice(c, (W - deviceW) * 0.5f, heroTop + Math.max(28f, heroH * 0.09f), deviceW, deviceH);

        float statY = heroTop + heroH + gap;
        drawHomeStats(c, statY, statsH);

        float masterY = statY + statsH + gap;
        neonPanel(c, 28, masterY, 844, masterH, 22, BLUE, 0.42f);
        drawCircleIcon(c, 103, masterY + masterH * 0.50f, Math.min(52f, masterH * 0.28f), BLUE, 0);
        text(c, "Master Volume", 178, masterY + masterH * 0.33f, 30, WHITE, true, Paint.Align.LEFT);
        text(c, "Adjust the overall output level", 178, masterY + masterH * 0.51f, 17, SUB, false, Paint.Align.LEFT);
        text(c, fmtDb(state.masterVolume), 835, masterY + masterH * 0.34f, 40, CYAN, true, Paint.Align.RIGHT);
        drawSlider(c, 180, masterY + masterH * 0.63f, 625, state.masterVolume, -60, 6, SL_MASTER, BLUE, MAGENTA, false,
                "-60", "-40", "-20", "0", "+6");

        float cardsY = masterY + masterH + gap;
        float rowGap = 10f;
        float rowH = (cardsH - rowGap) * 0.5f;
        drawHomeActionCard(c, 28, cardsY, 414, rowH, CYAN, "Mix", "Balance & Tone Control", 1, A_HOME_MIX);
        drawHomeActionCard(c, 458, cardsY, 414, rowH, MAGENTA, "EQ", "15 Band Equalizer", 2, A_HOME_EQ);
        drawHomeActionCard(c, 28, cardsY + rowH + rowGap, 414, rowH, Color.rgb(35, 236, 239), "Crossover", "Filter & Delay", 3, A_HOME_CROSS);
        drawHomeActionCard(c, 458, cardsY + rowH + rowGap, 414, rowH, ORANGE, "Preset", "Save & Load", 4, A_HOME_PRESET);

        float quickY = cardsY + cardsH + gap;
        drawQuickPreset(c, quickY, quickH, false);

        float statusY = quickY + quickH + gap;
        drawSystemStatus(c, statusY, statusH);
    }

    private void drawHomeStats(Canvas c, float top, float h) {
        String[] topText = {"7", "48 kHz", "32 bit", "Bluetooth"};
        String[] subText = {"Channels", "Sample Rate", "DSP Processing", "Wireless Control"};
        float iconY = top + h * 0.24f;
        float valueY = top + h * 0.63f;
        float labelY = top + h * 0.86f;
        for (int i = 0; i < 4; i++) {
            float x = 112 + i * 225;
            if (i > 0) {
                p.setColor(Color.argb(85, 94, 154, 220));
                c.drawRoundRect(new RectF(x - 112, top + h * 0.16f, x - 110, top + h * 0.88f), 2, 2, p);
            }
            int col = i == 3 ? Color.rgb(49, 133, 255) : CYAN;
            drawStatIcon(c, x, iconY, i, col);
            text(c, topText[i], x, valueY, 25, WHITE, true, Paint.Align.CENTER);
            text(c, subText[i], x, labelY, 16, SUB, false, Paint.Align.CENTER);
        }
    }

    private void drawHomeActionCard(Canvas c, float x, float top, float w, float h, int accent,
                                    String title, String sub, int iconType, int action) {
        neonPanel(c, x, top, w, h, 20, accent, 0.58f);
        float cy = top + h * 0.50f;
        drawCardIcon(c, x + 66, cy, accent, iconType);
        text(c, title, x + 154, top + h * 0.45f, 29, WHITE, true, Paint.Align.LEFT);
        text(c, sub, x + 154, top + h * 0.66f, 16, SUB, false, Paint.Align.LEFT);
        text(c, "›", x + w - 31, top + h * 0.58f, 48, WHITE, false, Paint.Align.CENTER);
        addHit(x, top, x + w, top + h, action);
    }

    private void drawQuickPreset(Canvas c, float top, float h, boolean eqMode) {
        neonPanel(c, 28, top, 844, h, 22, Color.rgb(21, 93, 174), 0.30f);
        text(c, "Quick Preset", 52, top + h * 0.20f, 27, WHITE, true, Paint.Align.LEFT);
        text(c, "See All ›", 840, top + h * 0.20f, 15, SUB, false, Paint.Align.RIGHT);
        addHit(740, top + 4, 860, top + h * 0.29f, A_PRESET_SEE_ALL);
        String[] names = {"Flat", "Pop", "Rock", "Vocal", "Custom"};
        int[] colors = {CYAN, Color.rgb(255, 45, 152), ORANGE, Color.rgb(201, 73, 255), CYAN};
        float gap = 10;
        float cardW = (798 - gap * 4) / 5f;
        float cardTop = top + h * 0.30f;
        float cardH = h * 0.60f;
        for (int i = 0; i < 5; i++) {
            float x = 50 + i * (cardW + gap);
            boolean selected = state.homePreset == i;
            miniPreset(c, x, cardTop, cardW, cardH, names[i], colors[i], selected, i == 4);
            addHit(x, cardTop - 4, x + cardW, cardTop + cardH + 4, A_PRESET_BASE + i);
        }
    }

    private void drawSystemStatus(Canvas c, float top, float h) {
        neonPanel(c, 28, top, 844, h, 22, Color.rgb(14, 73, 132), 0.26f);
        text(c, "System Status", 52, top + h * 0.22f, 26, WHITE, true, Paint.Align.LEFT);
        text(c, "Firmware UI v22", 840, top + h * 0.22f, 14, SUB, false, Paint.Align.RIGHT);
        String[] value = {"36°C", "12.4 V", "-42 dBm", "Normal"};
        String[] label = {"Temperature", "Voltage", "Signal", "Device Status"};
        int[] colors = {BLUE, CYAN, GREEN, CYAN};
        for (int i = 0; i < 4; i++) {
            float x = 92 + i * 200;
            if (i > 0) {
                p.setColor(Color.argb(60, 77, 130, 185));
                c.drawRoundRect(new RectF(x - 90, top + h * 0.35f, x - 88, top + h * 0.88f), 2, 2, p);
            }
            drawSystemIcon(c, x - 20, top + h * 0.62f, i, colors[i]);
            text(c, value[i], x + 20, top + h * 0.60f, 20, WHITE, true, Paint.Align.LEFT);
            text(c, label[i], x + 20, top + h * 0.79f, 14, SUB, false, Paint.Align.LEFT);
        }
    }

    private void drawMix(Canvas c) {
        drawHeader(c, "Mix", "REAL-TIME SOUND CONTROL", true);
        drawNeonWave(c, 235, 50, 0.4f);
        letterText(c, "ADJUST  •  LISTEN  •  FEEL THE DIFFERENCE", 450, 278, 13, SUB, Paint.Align.CENTER, 4f);

        String[] titles = {"Master Volume", "Bass Volume", "Bass Cutoff", "Bass Boost", "Middle Boost", "Treble Boost"};
        String[] subs = {"Adjust the overall output level", "Adjust low frequency level", "Set low frequency cutoff",
                "Enhance low frequencies", "Enhance mid frequencies", "Enhance high frequencies"};
        int[] accents = {BLUE, CYAN, MAGENTA, BLUE, MAGENTA, ORANGE};
        int[] sliderIds = {SL_MASTER, SL_BASS_VOLUME, SL_BASS_CUTOFF, SL_BASS_BOOST, SL_MID_BOOST, SL_TREBLE_BOOST};

        final float bodyTop = 300f;
        final float bottom = navTop() - 14f;
        final float extra = extraH();
        final float panelH = 164f + Math.min(34f, extra * 0.098f);
        final float toneH = 122f + Math.min(30f, extra * 0.086f);
        final float gap = Math.max(8f, (bottom - bodyTop - panelH * 6f - toneH) / 6f);

        for (int i = 0; i < 6; i++) {
            float top = bodyTop + i * (panelH + gap);
            neonPanel(c, 28, top, 844, panelH, 22, accents[i], 0.48f);
            drawCircleIcon(c, 104, top + Math.min(panelH * 0.50f, 91f), 49f, accents[i], i);
            text(c, titles[i], 182, top + 45f, 27, WHITE, true, Paint.Align.LEFT);
            text(c, subs[i], 182, top + 70f, 16, SUB, false, Paint.Align.LEFT);

            float value = getSliderValue(sliderIds[i]);
            String valText;
            float min;
            float max;
            boolean log = false;
            String[] labels;
            if (sliderIds[i] == SL_MASTER) {
                min = -60; max = 6; valText = fmtDb(value); labels = new String[]{"-60", "-40", "-20", "0", "+6"};
            } else if (sliderIds[i] == SL_BASS_VOLUME) {
                min = -20; max = 20; valText = fmtDb(value); labels = new String[]{"-20", "-10", "0", "+10", "+20"};
            } else if (sliderIds[i] == SL_BASS_CUTOFF) {
                min = 20; max = 320; log = true; valText = String.format(Locale.US, "%.0f Hz", value); labels = new String[]{"20", "40", "80", "160", "320"};
            } else {
                min = -12; max = 12; valText = fmtDb(value); labels = new String[]{"-12", "-6", "0", "+6", "+12"};
            }
            text(c, valText, 836, top + 48f, 37, accents[i], true, Paint.Align.RIGHT);
            drawSlider(c, 186, top + Math.min(panelH - 72f, 104f), 618, value, min, max, sliderIds[i], accents[i], i == 5 ? ORANGE : MAGENTA, log, labels);
        }

        float toneY = bodyTop + 6f * (panelH + gap);
        neonPanel(c, 28, toneY, 844, toneH, 22, Color.rgb(19, 74, 140), 0.28f);
        drawBarsIcon(c, 78, toneY + toneH * 0.50f, CYAN, 1.08f);
        text(c, "Tone Balance", 136, toneY + toneH * 0.42f, 24, WHITE, true, Paint.Align.LEFT);
        text(c, "Quick overview of current settings", 136, toneY + toneH * 0.65f, 14, SUB, false, Paint.Align.LEFT);
        float sx = 420;
        float total = 385;
        p.setColor(Color.rgb(13, 44, 79));
        c.drawRoundRect(new RectF(sx, toneY + toneH * 0.22f, sx + total, toneY + toneH * 0.32f), 7, 7, p);
        float[] vals = {state.masterVolume, state.bassVolume, state.middleBoost, state.trebleBoost};
        String[] labs = {"Master", "Bass", "Mid", "Treble"};
        int[] cols = {BLUE, CYAN, MAGENTA, ORANGE};
        float seg = total / 4f;
        for (int i = 0; i < 4; i++) {
            p.setColor(cols[i]);
            p.setShadowLayer(8, 0, 0, cols[i]);
            c.drawRoundRect(new RectF(sx + i * seg + 2, toneY + toneH * 0.23f, sx + (i + 1) * seg - 2, toneY + toneH * 0.31f), 6, 6, p);
            p.clearShadowLayer();
            text(c, fmtDb(vals[i]), sx + i * seg + seg * 0.5f, toneY + toneH * 0.59f, 16, cols[i], true, Paint.Align.CENTER);
            text(c, labs[i], sx + i * seg + seg * 0.5f, toneY + toneH * 0.80f, 13, SUB, false, Paint.Align.CENTER);
        }
    }

    private void drawEq(Canvas c) {
        drawHeader(c, "Eq", "15 BAND × 7 CHANNEL EQUALIZER", true);
        drawNeonWave(c, 218, 45, 0.8f);

        final float bodyTop = 278f;
        final float bottom = navTop() - 14f;
        final float gap = 11f;
        final float usable = bottom - bodyTop - gap * 4f;
        final float tabsH = usable * 0.085f;
        final float graphPanelH = usable * 0.475f;
        final float outH = usable * 0.135f;
        final float actionH = usable * 0.115f;
        final float quickH = usable - tabsH - graphPanelH - outH - actionH;

        float tabsY = bodyTop;
        drawChannelTabs(c, tabsY, tabsH, A_EQ_CH_BASE, state.channel);

        float panelY = tabsY + tabsH + gap;
        neonPanel(c, 22, panelY, 856, graphPanelH, 22, Color.rgb(34, 96, 180), 0.28f);
        text(c, "15 Band Equalizer", 52, panelY + 44, 28, WHITE, true, Paint.Align.LEFT);
        pill(c, 704, panelY + 14, 146, 43, "Channel " + (state.channel + 1) + "  ▾", BLUE, false);
        addHit(694, panelY + 8, 858, panelY + 64, A_EQ_CHANNEL_PILL);

        float controlsH = Math.min(195f, graphPanelH * 0.29f);
        float gx = 76;
        float gy = panelY + 78;
        float gw = 755;
        float gh = Math.max(250f, graphPanelH - 78f - controlsH - 34f);
        eqGraphBounds.set(gx, gy, gx + gw, gy + gh);
        drawEqGraph(c, gx, gy, gw, gh);

        float controlY = panelY + graphPanelH - controlsH - 12f;
        neonPanel(c, 42, controlY, 816, controlsH, 18, Color.rgb(21, 77, 145), 0.22f);
        drawEqControls(c, controlY);

        float outY = panelY + graphPanelH + gap;
        neonPanel(c, 24, outY, 852, outH, 21, Color.rgb(30, 93, 168), 0.28f);
        text(c, "Channel Output", 52, outY + outH * 0.25f, 27, WHITE, true, Paint.Align.LEFT);
        text(c, DspState.CHANNEL_LONG[state.channel] + " Volume & Output Level", 52, outY + outH * 0.43f, 16, SUB, false, Paint.Align.LEFT);
        pill(c, 710, outY + 15, 140, 46, "🔗  Link to All", BLUE, false);
        addHit(700, outY + 8, 858, outY + 72, A_EQ_LINK_ALL);
        drawCircleIcon(c, 86, outY + outH * 0.70f, 38, BLUE, 0);
        text(c, fmtDb(state.fader[state.channel]), 844, outY + outH * 0.73f, 36, CYAN, true, Paint.Align.RIGHT);
        drawSlider(c, 164, outY + outH * 0.64f, 525, state.fader[state.channel], -60, 6, SL_EQ_OUTPUT, BLUE, MAGENTA, false,
                "-60", "-40", "-20", "0", "+6");

        float actionY = outY + outH + gap;
        drawHomeActionCard(c, 24, actionY, 417, actionH, ORANGE, "Save Preset", "Save Current EQ to Preset", 4, A_EQ_SAVE);
        drawHomeActionCard(c, 459, actionY, 417, actionH, MAGENTA, "Load Preset", "Load Saved EQ Preset", 5, A_EQ_LOAD);

        float quickY = actionY + actionH + gap;
        drawQuickPreset(c, quickY, quickH, true);
    }

    private void drawChannelTabs(Canvas c, float top, float h, int actionBase, int selected) {
        neonPanel(c, 22, top, 856, h, 24, Color.rgb(20, 64, 125), 0.18f);
        float gap = 9;
        float tabW = (806 - gap * 6) / 7f;
        float innerTop = top + h * 0.12f;
        float innerH = h * 0.76f;
        for (int i = 0; i < 7; i++) {
            float x = 47 + i * (tabW + gap);
            boolean sel = i == selected;
            if (sel) neonPanel(c, x, innerTop, tabW, innerH, 14, CYAN, 0.70f);
            else simplePanel(c, x, innerTop, tabW, innerH, 14, Color.rgb(3, 26, 50), Color.rgb(17, 66, 119));
            drawBarsIcon(c, x + tabW / 2f, innerTop + innerH * 0.35f, sel ? CYAN : channelColor(i), 0.55f);
            text(c, "CH" + (i + 1), x + tabW / 2f, innerTop + innerH * 0.78f, 14, WHITE, true, Paint.Align.CENTER);
            addHit(x, top + 3, x + tabW, top + h - 3, actionBase + i);
        }
    }

    private int channelColor(int i) {
        int[] cols = {CYAN, Color.rgb(255, 44, 161), ORANGE, Color.rgb(194, 86, 255), CYAN, MAGENTA, Color.rgb(75, 154, 255)};
        return cols[i % cols.length];
    }

    private void drawEqGraph(Canvas c, float x, float top, float w, float h) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.rgb(2, 16, 31));
        c.drawRect(x, top, x + w, top + h, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1f);
        p.setColor(Color.argb(70, 94, 145, 210));
        for (int i = 0; i <= 15; i++) {
            float xx = x + w * i / 15f;
            c.drawLine(xx, top, xx, top + h, p);
        }
        for (int i = 0; i <= 4; i++) {
            float yy = top + h * i / 4f;
            c.drawLine(x, yy, x + w, yy, p);
        }
        p.setStyle(Paint.Style.FILL);
        text(c, "+12", x - 18, top + 8, 13, SUB, false, Paint.Align.RIGHT);
        text(c, "+6", x - 18, top + h * 0.25f + 5, 13, SUB, false, Paint.Align.RIGHT);
        text(c, "0", x - 18, top + h * 0.50f + 5, 13, SUB, false, Paint.Align.RIGHT);
        text(c, "-6", x - 18, top + h * 0.75f + 5, 13, SUB, false, Paint.Align.RIGHT);
        text(c, "-12", x - 18, top + h + 5, 13, SUB, false, Paint.Align.RIGHT);
        text(c, "dB", x + w + 10, top + 8, 13, SUB, false, Paint.Align.LEFT);

        int ch = state.channel;
        Path curve = new Path();
        for (int b = 0; b < DspState.BANDS; b++) {
            float xx = x + w * b / (DspState.BANDS - 1f);
            float yy = gainToY(state.gain[ch][b], top, h);
            if (b == 0) curve.moveTo(xx, yy); else curve.lineTo(xx, yy);
        }
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(4f);
        p.setShader(new LinearGradient(x, 0, x + w, 0,
                new int[]{CYAN, BLUE, PURPLE, MAGENTA, ORANGE}, null, Shader.TileMode.CLAMP));
        p.setShadowLayer(12, 0, 0, Color.argb(190, 42, 157, 255));
        c.drawPath(curve, p);
        p.clearShadowLayer();
        p.setShader(null);

        for (int b = 0; b < DspState.BANDS; b++) {
            float xx = x + w * b / (DspState.BANDS - 1f);
            float yy = gainToY(state.gain[ch][b], top, h);
            int col = gradientBandColor(b);
            p.setColor(col);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(b == state.selectedBand ? 5f : 3f);
            p.setShadowLayer(b == state.selectedBand ? 12 : 5, 0, 0, col);
            c.drawCircle(xx, yy, b == state.selectedBand ? 10f : 8f, p);
            p.clearShadowLayer();
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(100, Color.red(col), Color.green(col), Color.blue(col)));
            c.drawLine(xx, yy + 10, xx, top + h, p);
            String lab = compactHz(state.freq[ch][b]);
            text(c, lab, xx, top + h + 27, 11, SUB, false, Paint.Align.CENTER);
            addHit(xx - 20, yy - 22, xx + 20, yy + 22, A_EQ_POINT_BASE + b);
        }
        p.setStyle(Paint.Style.FILL);
    }

    private void drawEqControls(Canvas c, float top) {
        int ch = state.channel;
        int b = state.selectedBand;
        drawSmallSquareButton(c, 58, top + 21, 48, 46, "‹", A_EQ_BAND_PREV);
        text(c, "Band " + (b + 1), 129, top + 52, 21, WHITE, true, Paint.Align.LEFT);
        drawSmallSquareButton(c, 213, top + 21, 48, 46, "›", A_EQ_BAND_NEXT);
        drawBarsIcon(c, 80, top + 120, CYAN, 0.80f);
        text(c, "Adjust selected band", 126, top + 111, 14, SUB, false, Paint.Align.LEFT);
        text(c, "parameters", 126, top + 132, 14, SUB, false, Paint.Align.LEFT);

        drawParamBox(c, 286, top + 17, 164, 64, "Frequency (Hz)", compactHz(state.freq[ch][b]), CYAN, A_EQ_FREQ_MINUS, A_EQ_FREQ_PLUS);
        drawSlider(c, 303, top + 107, 130, state.freq[ch][b], 20, 20000, SL_EQ_FREQ, BLUE, CYAN, true,
                "20", "20k");
        drawParamBox(c, 474, top + 17, 164, 64, "Gain (dB)", String.format(Locale.US, "%+.1f", state.gain[ch][b]), MAGENTA, A_EQ_GAIN_MINUS, A_EQ_GAIN_PLUS);
        drawSlider(c, 491, top + 107, 130, state.gain[ch][b], -12, 12, SL_EQ_GAIN, MAGENTA, MAGENTA, false,
                "-12", "+12");
        drawParamBox(c, 662, top + 17, 164, 64, "Q (Quality)", String.format(Locale.US, "%.1f", state.q[ch][b]), ORANGE, A_EQ_Q_MINUS, A_EQ_Q_PLUS);
        drawSlider(c, 679, top + 107, 130, state.q[ch][b], 0.1f, 10f, SL_EQ_Q, ORANGE, ORANGE, true,
                "0.1", "10.0");
    }

    private void drawParamBox(Canvas c, float x, float top, float w, float h, String label, String value, int accent,
                              int minusAction, int plusAction) {
        text(c, label, x + w / 2f, top, 13, SUB, false, Paint.Align.CENTER);
        simplePanel(c, x, top + 9, w, h - 9, 12, Color.rgb(4, 32, 60), Color.rgb(16, 79, 143));
        text(c, "‹", x + 22, top + 46, 35, WHITE, false, Paint.Align.CENTER);
        text(c, value, x + w / 2f, top + 47, 24, accent, true, Paint.Align.CENTER);
        text(c, "›", x + w - 22, top + 46, 35, WHITE, false, Paint.Align.CENTER);
        addHit(x, top + 9, x + 44, top + h, minusAction);
        addHit(x + w - 44, top + 9, x + w, top + h, plusAction);
    }

    private float gainToY(float gain, float top, float h) {
        float t = (12f - clamp(gain, -12f, 12f)) / 24f;
        return top + t * h;
    }

    private void drawCrossover(Canvas c) {
        drawHeader(c, "", "", false);

        final float bottom = navTop() - 14f;
        final float gap = 11f;
        final float heroTop = 108f;
        final float heroH = Math.max(345f, Math.min(430f, (bottom - heroTop) * 0.255f));

        letterText(c, "PURE SOUND", 52, heroTop + 46, 13, SUB, Paint.Align.LEFT, 5f);
        letterText(c, "YOUR WAY", 52, heroTop + 68, 13, SUB, Paint.Align.LEFT, 5f);
        letterText(c, "DRIVE A", 845, heroTop + 46, 13, SUB, Paint.Align.RIGHT, 5f);
        letterText(c, "BETTER TOMORROW", 845, heroTop + 68, 13, SUB, Paint.Align.RIGHT, 4f);
        drawNeonWave(c, heroTop + heroH * 0.42f, 56, 0.2f);
        float deviceH = Math.min(238f, heroH * 0.58f);
        float deviceW = Math.min(555f, deviceH * 2.22f);
        drawDevice(c, (W - deviceW) * 0.5f, heroTop + heroH * 0.03f, deviceW, deviceH);
        float titleY = heroTop + heroH * 0.82f;
        drawCrossoverIcon(c, 78, titleY, CYAN, 1.05f);
        text(c, "Crossover", 164, titleY + 8, 44, WHITE, true, Paint.Align.LEFT);
        text(c, "Filter & Delay Control", 164, titleY + 45, 22, SUB, false, Paint.Align.LEFT);

        float remainTop = heroTop + heroH;
        float remainH = bottom - remainTop - gap * 3f;
        float tabsH = remainH * 0.070f;
        float graphH = remainH * 0.255f;
        float filtersH = remainH * 0.285f;
        float lowerH = remainH - tabsH - graphH - filtersH;

        float tabsY = remainTop;
        drawCrossTabs(c, tabsY, tabsH);

        float graphY = tabsY + tabsH + gap;
        neonPanel(c, 28, graphY, 844, graphH, 21, Color.rgb(36, 95, 170), 0.28f);
        text(c, "Crossover Curve (" + DspState.CHANNEL_LONG[state.channel].replace("Channel ", "CH") + ")", 52, graphY + 34, 22, WHITE, true, Paint.Align.LEFT);
        text(c, "HPF: " + compactHz(hpfHz) + "  (" + hpfSlope + " dB/Oct)   |   LPF: " + compactHz(lpfHz) + "  (" + lpfSlope + " dB/Oct)",
                850, graphY + 32, 14, SUB, false, Paint.Align.RIGHT);
        drawCrossoverGraph(c, 72, graphY + 57, 760, Math.max(170f, graphH - 102f));

        float filterY = graphY + graphH + gap;
        drawFilterPanel(c, 28, filterY, 414, filtersH, true);
        drawFilterPanel(c, 458, filterY, 414, filtersH, false);

        float lowerY = filterY + filtersH + gap;
        drawDelayPanel(c, 28, lowerY, 500, lowerH);
        float smallGap = 10f;
        float phaseH = (lowerH - smallGap) * 0.52f;
        drawPhasePanel(c, 546, lowerY, 326, phaseH);
        drawLinkPanel(c, 546, lowerY + phaseH + smallGap, 326, lowerH - phaseH - smallGap);
    }

    private void drawCrossTabs(Canvas c, float top, float h) {
        neonPanel(c, 28, top, 844, h, 22, Color.rgb(16, 68, 126), 0.20f);
        float tabW = 105;
        float innerTop = top + h * 0.10f;
        float innerH = h * 0.80f;
        for (int i = 0; i < 7; i++) {
            float x = 70 + i * 109;
            boolean sel = state.channel == i;
            if (sel) neonPanel(c, x, innerTop, tabW, innerH, 13, CYAN, 0.70f);
            text(c, "CH" + (i + 1), x + tabW / 2f, innerTop + innerH * 0.46f, 17, WHITE, true, Paint.Align.CENTER);
            String[] n = {"Front L", "Front R", "Rear L", "Rear R", "Center", "Sub L", "Sub R"};
            text(c, n[i], x + tabW / 2f, innerTop + innerH * 0.76f, 12, SUB, false, Paint.Align.CENTER);
            addHit(x, top + 2, x + tabW, top + h - 2, A_CROSS_CH_BASE + i);
        }
    }

    private void drawCrossoverGraph(Canvas c, float x, float top, float w, float h) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.rgb(2, 15, 29));
        c.drawRect(x, top, x + w, top + h, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1f);
        p.setColor(Color.argb(74, 82, 141, 202));
        for (int i = 0; i <= 12; i++) {
            float xx = x + w * i / 12f;
            c.drawLine(xx, top, xx, top + h, p);
        }
        for (int i = 0; i <= 4; i++) {
            float yy = top + h * i / 4f;
            c.drawLine(x, yy, x + w, yy, p);
        }
        p.setStyle(Paint.Style.FILL);
        text(c, "+12", x - 15, top + 5, 12, SUB, false, Paint.Align.RIGHT);
        text(c, "0", x - 15, top + h * 0.25f + 5, 12, SUB, false, Paint.Align.RIGHT);
        text(c, "-12", x - 15, top + h * 0.50f + 5, 12, SUB, false, Paint.Align.RIGHT);
        text(c, "-24", x - 15, top + h * 0.75f + 5, 12, SUB, false, Paint.Align.RIGHT);
        text(c, "-48", x - 15, top + h + 5, 12, SUB, false, Paint.Align.RIGHT);

        float left = logPos(hpfHz, 20, 20000);
        float right = logPos(lpfHz, 20, 20000);
        left = clamp(left, 0.02f, 0.92f);
        right = clamp(right, 0.08f, 0.98f);
        if (right < left + 0.04f) right = left + 0.04f;

        Path curve = new Path();
        int samples = 100;
        for (int i = 0; i <= samples; i++) {
            float t = i / (float) samples;
            float amp = 1f;
            if (hpfEnabled && t < left) {
                float q = clamp(t / left, 0f, 1f);
                amp *= smoothStep(q);
            }
            if (lpfEnabled && t > right) {
                float q = clamp((1f - t) / (1f - right), 0f, 1f);
                amp *= smoothStep(q);
            }
            float db = -48f + 48f * amp;
            float yy = top + h * (-db) / 48f;
            float xx = x + w * t;
            if (i == 0) curve.moveTo(xx, yy); else curve.lineTo(xx, yy);
        }
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(4f);
        p.setShader(new LinearGradient(x, 0, x + w, 0, CYAN, MAGENTA, Shader.TileMode.CLAMP));
        p.setShadowLayer(12, 0, 0, CYAN);
        c.drawPath(curve, p);
        p.clearShadowLayer();
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);

        float hx = x + w * left;
        float lx = x + w * right;
        p.setColor(CYAN); p.setShadowLayer(10, 0, 0, CYAN); c.drawCircle(hx, top + h * 0.03f, 10, p); p.clearShadowLayer();
        p.setColor(MAGENTA); p.setShadowLayer(10, 0, 0, MAGENTA); c.drawCircle(lx, top + h * 0.03f, 10, p); p.clearShadowLayer();

        float[] freqs = {20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000};
        for (float f : freqs) {
            float xx = x + w * logPos(f, 20, 20000);
            text(c, compactHz(f), xx, top + h + 23, 11, SUB, false, Paint.Align.CENTER);
        }
        text(c, "Frequency (Hz)", x + w / 2f, top + h + 44, 12, SUB, false, Paint.Align.CENTER);
    }

    private float smoothStep(float t) {
        t = clamp(t, 0f, 1f);
        return t * t * (3f - 2f * t);
    }

    private void drawFilterPanel(Canvas c, float x, float top, float w, float h, boolean highPass) {
        int accent = highPass ? CYAN : MAGENTA;
        boolean enabled = highPass ? hpfEnabled : lpfEnabled;
        neonPanel(c, x, top, w, h, 20, accent, 0.46f);
        drawFilterIcon(c, x + 58, top + h * 0.16f, accent, highPass);
        text(c, highPass ? "High Pass Filter" : "Low Pass Filter", x + 118, top + h * 0.18f, 24, WHITE, true, Paint.Align.LEFT);
        drawToggle(c, x + w - 85, top + h * 0.15f, enabled, accent);
        addHit(x + w - 135, top + 4, x + w - 20, top + h * 0.28f, highPass ? A_HPF_TOGGLE : A_LPF_TOGGLE);

        float freq = highPass ? hpfHz : lpfHz;
        text(c, "Frequency", x + 24, top + h * 0.38f, 16, WHITE, false, Paint.Align.LEFT);
        text(c, highPass ? String.format(Locale.US, "%.0f Hz", freq) : formatFreqFull(freq), x + w - 25, top + h * 0.38f, 23, WHITE, true, Paint.Align.RIGHT);
        float sliderY = top + h * 0.49f;
        drawSmallSquareButton(c, x + 23, sliderY - 20, 41, 42, "−", highPass ? A_HPF_MINUS : A_LPF_MINUS);
        drawSmallSquareButton(c, x + w - 65, sliderY - 20, 41, 42, "+", highPass ? A_HPF_PLUS : A_LPF_PLUS);
        if (highPass) {
            drawSlider(c, x + 80, sliderY, w - 160, hpfHz, 20, 1000, SL_HPF_FREQ, CYAN, CYAN, true, new String[]{});
        } else {
            drawSlider(c, x + 80, sliderY, w - 160, lpfHz, 200, 20000, SL_LPF_FREQ, MAGENTA, MAGENTA, true, new String[]{});
        }

        text(c, "Slope", x + 24, top + h * 0.70f, 16, WHITE, false, Paint.Align.LEFT);
        int[] slopes = {6, 12, 18, 24};
        float bw = 78;
        float by = top + h * 0.74f;
        float bh = Math.max(48f, h * 0.17f);
        for (int i = 0; i < slopes.length; i++) {
            float bx = x + 23 + i * 91;
            boolean sel = (highPass ? hpfSlope : lpfSlope) == slopes[i];
            if (sel) neonPanel(c, bx, by, bw, bh, 11, accent, 0.72f);
            else simplePanel(c, bx, by, bw, bh, 11, Color.rgb(4, 27, 51), Color.rgb(18, 67, 121));
            text(c, slopes[i] + " dB", bx + bw / 2f, by + bh * 0.65f, 15, WHITE, sel, Paint.Align.CENTER);
            addHit(bx, by - 5, bx + bw, by + bh + 5, (highPass ? A_HPF_SLOPE_BASE : A_LPF_SLOPE_BASE) + i);
        }
    }

    private void drawDelayPanel(Canvas c, float x, float top, float w, float h) {
        neonPanel(c, x, top, w, h, 20, ORANGE, 0.44f);
        drawClockIcon(c, x + 62, top + h * 0.16f, ORANGE);
        text(c, "Delay", x + 116, top + h * 0.14f, 22, WHITE, true, Paint.Align.LEFT);
        text(c, "Time Alignment", x + 116, top + h * 0.23f, 14, SUB, false, Paint.Align.LEFT);
        drawToggle(c, x + w - 82, top + h * 0.17f, delayMs > 0.01f, ORANGE);
        addHit(x + w - 132, top + 4, x + w - 18, top + h * 0.29f, A_DELAY_TOGGLE);

        float firstLabel = top + h * 0.42f;
        text(c, "Delay Time", x + 25, firstLabel, 15, WHITE, false, Paint.Align.LEFT);
        text(c, String.format(Locale.US, "%.2f ms", delayMs), x + w - 28, firstLabel, 20, WHITE, true, Paint.Align.RIGHT);
        float firstSlider = top + h * 0.52f;
        drawSmallSquareButton(c, x + 24, firstSlider - 20, 40, 40, "−", A_DELAY_MINUS);
        drawSmallSquareButton(c, x + w - 64, firstSlider - 20, 40, 40, "+", A_DELAY_PLUS);
        drawSlider(c, x + 78, firstSlider, w - 156, delayMs, 0, 20, SL_DELAY_MS, ORANGE, ORANGE, false, new String[]{});

        float secondLabel = top + h * 0.72f;
        text(c, "Distance (at 343 m/s)", x + 25, secondLabel, 15, WHITE, false, Paint.Align.LEFT);
        text(c, String.format(Locale.US, "%.1f cm", distanceCm), x + w - 28, secondLabel, 20, WHITE, true, Paint.Align.RIGHT);
        float secondSlider = top + h * 0.82f;
        drawSmallSquareButton(c, x + 24, secondSlider - 20, 40, 40, "−", A_DISTANCE_MINUS);
        drawSmallSquareButton(c, x + w - 64, secondSlider - 20, 40, 40, "+", A_DISTANCE_PLUS);
        drawSlider(c, x + 78, secondSlider, w - 156, distanceCm, 0, 686, SL_DISTANCE_CM, ORANGE, CYAN, false, new String[]{});
    }

    private void drawPhasePanel(Canvas c, float x, float top, float w, float h) {
        neonPanel(c, x, top, w, h, 20, BLUE, 0.34f);
        drawPhaseIcon(c, x + 55, top + h * 0.31f, CYAN);
        text(c, "Phase / Polarity", x + 103, top + h * 0.30f, 20, WHITE, true, Paint.Align.LEFT);
        float by = top + h * 0.53f;
        float bh = Math.max(48f, h * 0.27f);
        boolean ph = phase180[state.channel];
        if (!ph) neonPanel(c, x + 116, by, 91, bh, 10, CYAN, 0.72f);
        else simplePanel(c, x + 116, by, 91, bh, 10, Color.rgb(4, 27, 51), Color.rgb(18, 67, 121));
        if (ph) neonPanel(c, x + 216, by, 91, bh, 10, CYAN, 0.72f);
        else simplePanel(c, x + 216, by, 91, bh, 10, Color.rgb(4, 27, 51), Color.rgb(18, 67, 121));
        text(c, "0°", x + 161, by + bh * 0.65f, 16, WHITE, true, Paint.Align.CENTER);
        text(c, "180°", x + 261, by + bh * 0.65f, 16, WHITE, true, Paint.Align.CENTER);
        addHit(x + 108, by - 7, x + 211, by + bh + 7, A_PHASE_0);
        addHit(x + 212, by - 7, x + 315, by + bh + 7, A_PHASE_180);
    }

    private void drawLinkPanel(Canvas c, float x, float top, float w, float h) {
        neonPanel(c, x, top, w, h, 20, BLUE, 0.26f);
        drawLinkIcon(c, x + 53, top + h * 0.47f, CYAN);
        text(c, "Link Filters", x + 104, top + h * 0.41f, 20, WHITE, true, Paint.Align.LEFT);
        text(c, "Link HPF & LPF", x + 104, top + h * 0.60f, 14, SUB, false, Paint.Align.LEFT);
        drawToggle(c, x + w - 72, top + h * 0.50f, linkFilters, CYAN);
        addHit(x + w - 125, top + h * 0.22f, x + w - 18, top + h * 0.78f, A_LINK_FILTERS);
    }

    private void drawBottomNav(Canvas c) {
        float top = navTop();
        p.setShader(new LinearGradient(0, top, 0, viewportH,
                Color.rgb(3, 23, 47), Color.rgb(0, 8, 22), Shader.TileMode.CLAMP));
        c.drawRoundRect(new RectF(0, top - 8, W, viewportH + 22), 52, 52, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.5f);
        p.setColor(Color.argb(90, 38, 99, 170));
        c.drawRoundRect(new RectF(0, top - 8, W, viewportH + 22), 52, 52, p);
        p.setStyle(Paint.Style.FILL);

        String[] labels = {"Home", "Mix", "Eq", "Crossover"};
        for (int i = 0; i < 4; i++) {
            float cx = 112.5f + i * 225f;
            boolean sel = page == i;
            int col = sel ? CYAN : Color.rgb(190, 210, 245);
            drawNavIcon(c, cx, top + 46, i, col, sel);
            text(c, labels[i], cx, top + 105, 22, col, false, Paint.Align.CENTER);
            if (sel) {
                p.setColor(CYAN);
                p.setShadowLayer(12, 0, 0, CYAN);
                c.drawRoundRect(new RectF(cx - 58, top + 124, cx + 58, top + 129), 3, 3, p);
                p.clearShadowLayer();
            }
            addHit(i * 225f, top - 6, (i + 1) * 225f, viewportH, A_NAV_BASE + i);
        }
    }

    private void drawSettingsOverlay(Canvas c) {
        p.setColor(Color.argb(185, 0, 4, 14));
        c.drawRect(0, 0, W, viewportH, p);
        float h = 390;
        float top = Math.max(210, viewportH * 0.5f - h * 0.5f);
        neonPanel(c, 120, top, 660, h, 28, CYAN, 0.45f);
        drawGear(c, 450, top + 72);
        text(c, "OKN_DSP • Phase 1", 450, top + 128, 31, WHITE, true, Paint.Align.CENTER);
        text(c, "UI Preview Only", 450, top + 163, 20, CYAN, true, Paint.Align.CENTER);
        text(c, "All controls react instantly on-device.", 450, top + 207, 17, SUB, false, Paint.Align.CENTER);
        text(c, "DSP/BLE control will be connected in Phase 2.", 450, top + 235, 17, SUB, false, Paint.Align.CENTER);
        outlineButton(c, 190, top + 282, 240, 67, "Reset UI", ORANGE, A_OVERLAY_RESET);
        outlineButton(c, 470, top + 282, 240, 67, "Close", CYAN, A_OVERLAY_CLOSE);
    }

    private void drawSlider(Canvas c, float x, float top, float w, float value, float min, float max,
                            int id, int startColor, int endColor, boolean log, String... labels) {
        float h = 14;
        p.setColor(Color.rgb(17, 54, 94));
        c.drawRoundRect(new RectF(x, top, x + w, top + h), 8, 8, p);
        float t = log ? logPos(value, min, max) : (value - min) / (max - min);
        t = clamp(t, 0, 1);
        float knobX = x + w * t;
        p.setShader(new LinearGradient(x, 0, x + w, 0, startColor, endColor, Shader.TileMode.CLAMP));
        p.setShadowLayer(9, 0, 0, startColor);
        c.drawRoundRect(new RectF(x, top, Math.max(x + 2, knobX), top + h), 8, 8, p);
        p.clearShadowLayer();
        p.setShader(null);
        p.setColor(WHITE);
        p.setShadowLayer(12, 0, 0, Color.argb(220, 255, 255, 255));
        c.drawCircle(knobX, top + h / 2f, 20, p);
        p.clearShadowLayer();
        sliders.add(new SliderHit(x - 24, top - 38, x + w + 24, top + 52, id, min, max, log));

        if (labels != null && labels.length > 0) {
            for (int i = 0; i < labels.length; i++) {
                float xx = labels.length == 1 ? x : x + w * i / (labels.length - 1f);
                p.setColor(Color.argb(125, 158, 190, 225));
                c.drawRect(xx - 1, top + 22, xx + 1, top + 34, p);
                text(c, labels[i], xx, top + 55, 13, SUB, false, Paint.Align.CENTER);
            }
        }
    }

    private float getSliderValue(int id) {
        switch (id) {
            case SL_MASTER: return state.masterVolume;
            case SL_BASS_VOLUME: return state.bassVolume;
            case SL_BASS_CUTOFF: return state.bassCutoff;
            case SL_BASS_BOOST: return state.bassBoost;
            case SL_MID_BOOST: return state.middleBoost;
            case SL_TREBLE_BOOST: return state.trebleBoost;
            case SL_EQ_FREQ: return state.freq[state.channel][state.selectedBand];
            case SL_EQ_GAIN: return state.gain[state.channel][state.selectedBand];
            case SL_EQ_Q: return state.q[state.channel][state.selectedBand];
            case SL_EQ_OUTPUT: return state.fader[state.channel];
            case SL_HPF_FREQ: return hpfHz;
            case SL_LPF_FREQ: return lpfHz;
            case SL_DELAY_MS: return delayMs;
            case SL_DISTANCE_CM: return distanceCm;
            default: return 0;
        }
    }

    private void setSliderValue(int id, float v) {
        switch (id) {
            case SL_MASTER:
                state.masterVolume = round(v, 0.1f); break;
            case SL_BASS_VOLUME:
                state.bassVolume = round(v, 0.1f); state.homePreset = 4; break;
            case SL_BASS_CUTOFF:
                state.bassCutoff = round(v, 1f); state.homePreset = 4; break;
            case SL_BASS_BOOST:
                state.bassBoost = round(v, 0.1f); state.homePreset = 4; break;
            case SL_MID_BOOST:
                state.middleBoost = round(v, 0.1f); state.homePreset = 4; break;
            case SL_TREBLE_BOOST:
                state.trebleBoost = round(v, 0.1f); state.homePreset = 4; break;
            case SL_EQ_FREQ:
                state.freq[state.channel][state.selectedBand] = round(v, 1f); break;
            case SL_EQ_GAIN:
                state.gain[state.channel][state.selectedBand] = round(v, 0.1f); break;
            case SL_EQ_Q:
                state.q[state.channel][state.selectedBand] = round(v, 0.1f); break;
            case SL_EQ_OUTPUT:
                state.fader[state.channel] = round(v, 0.1f); break;
            case SL_HPF_FREQ:
                hpfHz = round(v, 1f);
                if (linkFilters && lpfHz < hpfHz * 2f) lpfHz = Math.min(20000f, hpfHz * 2f);
                saveCrossover();
                break;
            case SL_LPF_FREQ:
                lpfHz = round(v, 1f);
                if (linkFilters && hpfHz > lpfHz * 0.5f) hpfHz = Math.max(20f, lpfHz * 0.5f);
                saveCrossover();
                break;
            case SL_DELAY_MS:
                delayMs = round(v, 0.01f);
                distanceCm = round(delayMs * 34.3f, 0.1f);
                saveCrossover();
                break;
            case SL_DISTANCE_CM:
                distanceCm = round(v, 0.1f);
                delayMs = round(distanceCm / 34.3f, 0.01f);
                saveCrossover();
                break;
            default:
                break;
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float vx = (event.getX() - offsetX) / Math.max(scale, 0.0001f);
        float vy = (event.getY() - offsetY) / Math.max(scale, 0.0001f);

        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (overlayOpen) {
                    pressedAction = findAction(vx, vy);
                    return true;
                }
                activeSlider = findSlider(vx, vy);
                if (activeSlider != null) {
                    updateActiveSlider(vx);
                    if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                    return true;
                }
                if (page == PAGE_EQ && eqGraphBounds.contains(vx, vy)) {
                    draggingEqGraph = true;
                    if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                    updateEqGraph(vx, vy);
                    return true;
                }
                pressedAction = findAction(vx, vy);
                return true;

            case MotionEvent.ACTION_MOVE:
                if (activeSlider != null) {
                    updateActiveSlider(vx);
                    return true;
                }
                if (draggingEqGraph) {
                    updateEqGraph(vx, vy);
                    return true;
                }
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (activeSlider != null) {
                    updateActiveSlider(vx);
                    activeSlider = null;
                    if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
                    performClick();
                    return true;
                }
                if (draggingEqGraph) {
                    updateEqGraph(vx, vy);
                    draggingEqGraph = false;
                    if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
                    performClick();
                    return true;
                }
                int a = findAction(vx, vy);
                if (a != -1 && a == pressedAction && event.getActionMasked() == MotionEvent.ACTION_UP) {
                    handleAction(a);
                    performClick();
                }
                pressedAction = -1;
                return true;
            default:
                return true;
        }
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    private void updateActiveSlider(float vx) {
        if (activeSlider == null) return;
        float t = clamp((vx - activeSlider.r.left) / activeSlider.r.width(), 0f, 1f);
        // Slider hit area includes padding; map using the visual track inset.
        float visualLeft = activeSlider.r.left + 22f;
        float visualRight = activeSlider.r.right - 22f;
        t = clamp((vx - visualLeft) / Math.max(1f, visualRight - visualLeft), 0f, 1f);
        float v;
        if (activeSlider.logarithmic) {
            v = (float) Math.exp(Math.log(activeSlider.min) + t * (Math.log(activeSlider.max) - Math.log(activeSlider.min)));
        } else {
            v = activeSlider.min + t * (activeSlider.max - activeSlider.min);
        }
        setSliderValue(activeSlider.id, v);
        postInvalidateOnAnimation();
    }

    private void updateEqGraph(float vx, float vy) {
        int b = Math.round((vx - eqGraphBounds.left) / eqGraphBounds.width() * (DspState.BANDS - 1));
        b = Math.max(0, Math.min(DspState.BANDS - 1, b));
        state.selectedBand = b;
        float t = clamp((vy - eqGraphBounds.top) / eqGraphBounds.height(), 0f, 1f);
        float gain = 12f - 24f * t;
        state.gain[state.channel][b] = round(gain, 0.1f);
        postInvalidateOnAnimation();
    }

    private SliderHit findSlider(float x, float yy) {
        for (int i = sliders.size() - 1; i >= 0; i--) {
            SliderHit s = sliders.get(i);
            if (s.r.contains(x, yy)) return s;
        }
        return null;
    }

    private int findAction(float x, float yy) {
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (h.r.contains(x, yy)) return h.action;
        }
        return -1;
    }

    private void handleAction(int a) {
        if (overlayOpen) {
            if (a == A_OVERLAY_CLOSE || a == A_GEAR) {
                overlayOpen = false;
            } else if (a == A_OVERLAY_RESET) {
                resetUi();
                overlayOpen = false;
                Toast.makeText(getContext(), "UI reset to V22 defaults", Toast.LENGTH_SHORT).show();
            }
            invalidate();
            return;
        }

        if (a == A_GEAR) {
            overlayOpen = true;
        } else if (a == A_CONNECT) {
            previewConnected = !previewConnected;
        } else if (a >= A_NAV_BASE && a < A_NAV_BASE + 4) {
            page = a - A_NAV_BASE;
        } else if (a == A_HOME_MIX) {
            page = PAGE_MIX;
        } else if (a == A_HOME_EQ) {
            page = PAGE_EQ;
        } else if (a == A_HOME_CROSS) {
            page = PAGE_CROSS;
        } else if (a == A_HOME_PRESET) {
            page = PAGE_EQ;
        } else if (a >= A_PRESET_BASE && a < A_PRESET_BASE + 5) {
            int preset = a - A_PRESET_BASE;
            state.applyHomePreset(preset);
            if (page == PAGE_EQ) state.applyEqPreset(preset, state.channel);
        } else if (a >= A_EQ_CH_BASE && a < A_EQ_CH_BASE + 7) {
            state.channel = a - A_EQ_CH_BASE;
        } else if (a == A_EQ_BAND_PREV) {
            state.selectedBand = (state.selectedBand + DspState.BANDS - 1) % DspState.BANDS;
        } else if (a == A_EQ_BAND_NEXT) {
            state.selectedBand = (state.selectedBand + 1) % DspState.BANDS;
        } else if (a == A_EQ_FREQ_MINUS) {
            state.freq[state.channel][state.selectedBand] = clamp(state.freq[state.channel][state.selectedBand] / 1.08f, 20, 20000);
        } else if (a == A_EQ_FREQ_PLUS) {
            state.freq[state.channel][state.selectedBand] = clamp(state.freq[state.channel][state.selectedBand] * 1.08f, 20, 20000);
        } else if (a == A_EQ_GAIN_MINUS) {
            state.gain[state.channel][state.selectedBand] = clamp(round(state.gain[state.channel][state.selectedBand] - 0.5f, 0.1f), -12, 12);
        } else if (a == A_EQ_GAIN_PLUS) {
            state.gain[state.channel][state.selectedBand] = clamp(round(state.gain[state.channel][state.selectedBand] + 0.5f, 0.1f), -12, 12);
        } else if (a == A_EQ_Q_MINUS) {
            state.q[state.channel][state.selectedBand] = clamp(round(state.q[state.channel][state.selectedBand] - 0.1f, 0.1f), 0.1f, 10f);
        } else if (a == A_EQ_Q_PLUS) {
            state.q[state.channel][state.selectedBand] = clamp(round(state.q[state.channel][state.selectedBand] + 0.1f, 0.1f), 0.1f, 10f);
        } else if (a == A_EQ_LINK_ALL) {
            float val = state.fader[state.channel];
            for (int i = 0; i < DspState.CHANNELS; i++) state.fader[i] = val;
            Toast.makeText(getContext(), "Output linked to all 7 channels", Toast.LENGTH_SHORT).show();
        } else if (a == A_EQ_SAVE) {
            state.saveEq(getContext());
            Toast.makeText(getContext(), "EQ preset saved", Toast.LENGTH_SHORT).show();
        } else if (a == A_EQ_LOAD) {
            boolean ok = state.loadEq(getContext());
            Toast.makeText(getContext(), ok ? "EQ preset loaded" : "No saved EQ preset yet", Toast.LENGTH_SHORT).show();
        } else if (a == A_EQ_CHANNEL_PILL) {
            state.channel = (state.channel + 1) % DspState.CHANNELS;
        } else if (a == A_PRESET_SEE_ALL) {
            Toast.makeText(getContext(), "5 quick presets: Flat, Pop, Rock, Vocal, Custom", Toast.LENGTH_SHORT).show();
        } else if (a >= A_EQ_POINT_BASE && a < A_EQ_POINT_BASE + DspState.BANDS) {
            state.selectedBand = a - A_EQ_POINT_BASE;
        } else if (a >= A_CROSS_CH_BASE && a < A_CROSS_CH_BASE + 7) {
            state.channel = a - A_CROSS_CH_BASE;
        } else if (a == A_HPF_TOGGLE) {
            hpfEnabled = !hpfEnabled; saveCrossover();
        } else if (a == A_LPF_TOGGLE) {
            lpfEnabled = !lpfEnabled; saveCrossover();
        } else if (a >= A_HPF_SLOPE_BASE && a < A_HPF_SLOPE_BASE + 4) {
            hpfSlope = new int[]{6, 12, 18, 24}[a - A_HPF_SLOPE_BASE]; saveCrossover();
        } else if (a >= A_LPF_SLOPE_BASE && a < A_LPF_SLOPE_BASE + 4) {
            lpfSlope = new int[]{6, 12, 18, 24}[a - A_LPF_SLOPE_BASE]; saveCrossover();
        } else if (a == A_PHASE_0) {
            phase180[state.channel] = false; saveCrossover();
        } else if (a == A_PHASE_180) {
            phase180[state.channel] = true; saveCrossover();
        } else if (a == A_LINK_FILTERS) {
            linkFilters = !linkFilters; saveCrossover();
        } else if (a == A_HPF_MINUS) {
            hpfHz = clamp(hpfHz / 1.12f, 20, 1000); saveCrossover();
        } else if (a == A_HPF_PLUS) {
            hpfHz = clamp(hpfHz * 1.12f, 20, 1000); saveCrossover();
        } else if (a == A_LPF_MINUS) {
            lpfHz = clamp(lpfHz / 1.12f, 200, 20000); saveCrossover();
        } else if (a == A_LPF_PLUS) {
            lpfHz = clamp(lpfHz * 1.12f, 200, 20000); saveCrossover();
        } else if (a == A_DELAY_MINUS) {
            delayMs = clamp(round(delayMs - 0.1f, 0.01f), 0, 20); distanceCm = round(delayMs * 34.3f, 0.1f); saveCrossover();
        } else if (a == A_DELAY_PLUS) {
            delayMs = clamp(round(delayMs + 0.1f, 0.01f), 0, 20); distanceCm = round(delayMs * 34.3f, 0.1f); saveCrossover();
        } else if (a == A_DISTANCE_MINUS) {
            distanceCm = clamp(round(distanceCm - 1f, 0.1f), 0, 686); delayMs = round(distanceCm / 34.3f, 0.01f); saveCrossover();
        } else if (a == A_DISTANCE_PLUS) {
            distanceCm = clamp(round(distanceCm + 1f, 0.1f), 0, 686); delayMs = round(distanceCm / 34.3f, 0.01f); saveCrossover();
        } else if (a == A_DELAY_TOGGLE) {
            delayMs = delayMs > 0.01f ? 0f : 1f;
            distanceCm = round(delayMs * 34.3f, 0.1f);
            saveCrossover();
        }
        invalidate();
    }

    private void resetUi() {
        state.masterVolume = -12f;
        state.bassVolume = 4f;
        state.bassCutoff = 80f;
        state.bassBoost = 6f;
        state.middleBoost = 2f;
        state.trebleBoost = 3f;
        state.homePreset = 0;
        state.channel = 0;
        state.selectedBand = 4;
        for (int c = 0; c < DspState.CHANNELS; c++) {
            state.resetEq(c);
            state.fader[c] = -12f;
            phase180[c] = false;
        }
        // Restore reference-style curve on CH1 after reset for visual verification.
        float[] curve = {-3, -1, 2, 4, 5, 4, 2, 0, -2, -3, -2, 0, 2, 5, 6};
        for (int b = 0; b < DspState.BANDS; b++) state.gain[0][b] = curve[b];
        hpfEnabled = true;
        lpfEnabled = true;
        linkFilters = false;
        hpfHz = 80;
        lpfHz = 4000;
        hpfSlope = 24;
        lpfSlope = 24;
        delayMs = 0;
        distanceCm = 0;
        saveCrossover();
    }

    private void saveCrossover() {
        SharedPreferences.Editor e = getContext().getSharedPreferences("okn_dsp_cross_v19", Context.MODE_PRIVATE).edit();
        e.putBoolean("hpfEnabled", hpfEnabled)
                .putBoolean("lpfEnabled", lpfEnabled)
                .putBoolean("link", linkFilters)
                .putFloat("hpf", hpfHz)
                .putFloat("lpf", lpfHz)
                .putInt("hpfSlope", hpfSlope)
                .putInt("lpfSlope", lpfSlope)
                .putFloat("delay", delayMs)
                .putFloat("distance", distanceCm);
        for (int i = 0; i < DspState.CHANNELS; i++) e.putBoolean("phase" + i, phase180[i]);
        e.apply();
    }

    private void loadCrossover() {
        SharedPreferences s = getContext().getSharedPreferences("okn_dsp_cross_v19", Context.MODE_PRIVATE);
        hpfEnabled = s.getBoolean("hpfEnabled", true);
        lpfEnabled = s.getBoolean("lpfEnabled", true);
        linkFilters = s.getBoolean("link", false);
        hpfHz = s.getFloat("hpf", 80f);
        lpfHz = s.getFloat("lpf", 4000f);
        hpfSlope = s.getInt("hpfSlope", 24);
        lpfSlope = s.getInt("lpfSlope", 24);
        delayMs = s.getFloat("delay", 0f);
        distanceCm = s.getFloat("distance", delayMs * 34.3f);
        for (int i = 0; i < DspState.CHANNELS; i++) phase180[i] = s.getBoolean("phase" + i, false);
    }

    private void neonPanel(Canvas c, float x, float top, float w, float h, float r, int accent, float glowStrength) {
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(x, top, x + w, top + h,
                new int[]{
                        blend(Color.rgb(4, 30, 57), accent, 0.13f),
                        Color.rgb(3, 24, 48),
                        Color.rgb(1, 16, 34)
                }, null, Shader.TileMode.CLAMP));
        c.drawRoundRect(new RectF(x, top, x + w, top + h), r, r, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2f);
        p.setColor(Color.argb(185, Color.red(accent), Color.green(accent), Color.blue(accent)));
        p.setShadowLayer(13f * glowStrength, 0, 0, accent);
        c.drawRoundRect(new RectF(x + 1, top + 1, x + w - 1, top + h - 1), r, r, p);
        p.clearShadowLayer();
        p.setStyle(Paint.Style.FILL);

        p.setShader(new RadialGradient(x + 50, top + 30, Math.max(w * 0.5f, 150f),
                Color.argb((int) (70 * glowStrength), Color.red(accent), Color.green(accent), Color.blue(accent)),
                Color.TRANSPARENT, Shader.TileMode.CLAMP));
        c.drawRoundRect(new RectF(x, top, x + w, top + h), r, r, p);
        p.setShader(null);
    }

    private void simplePanel(Canvas c, float x, float top, float w, float h, float r, int fill, int border) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(fill);
        c.drawRoundRect(new RectF(x, top, x + w, top + h), r, r, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.5f);
        p.setColor(border);
        c.drawRoundRect(new RectF(x + 1, top + 1, x + w - 1, top + h - 1), r, r, p);
        p.setStyle(Paint.Style.FILL);
    }

    private void pill(Canvas c, float x, float top, float w, float h, String label, int accent, boolean selected) {
        if (selected) neonPanel(c, x, top, w, h, h / 2f, accent, 0.55f);
        else simplePanel(c, x, top, w, h, h / 2f, Color.rgb(4, 28, 52), Color.rgb(15, 76, 138));
        text(c, label, x + w / 2f, top + h * 0.66f, Math.min(16, h * 0.38f), WHITE, true, Paint.Align.CENTER);
    }

    private void outlineButton(Canvas c, float x, float top, float w, float h, String label, int accent, int action) {
        neonPanel(c, x, top, w, h, 15, accent, 0.45f);
        text(c, label, x + w / 2f, top + h * 0.64f, 19, WHITE, true, Paint.Align.CENTER);
        addHit(x, top, x + w, top + h, action);
    }

    private void drawSmallSquareButton(Canvas c, float x, float top, float w, float h, String label, int action) {
        simplePanel(c, x, top, w, h, 10, Color.rgb(5, 33, 61), Color.rgb(20, 81, 144));
        text(c, label, x + w / 2f, top + h * 0.68f, 27, WHITE, false, Paint.Align.CENTER);
        addHit(x - 6, top - 6, x + w + 6, top + h + 6, action);
    }

    private void miniPreset(Canvas c, float x, float top, float w, float h, String name, int accent, boolean selected, boolean star) {
        if (selected) neonPanel(c, x, top, w, h, 16, accent, 0.82f);
        else simplePanel(c, x, top, w, h, 16, Color.rgb(3, 25, 48), Color.rgb(18, 71, 126));
        float iconY = top + h * 0.38f;
        if (star) drawStar(c, x + w / 2f, iconY, Math.min(22f, h * 0.18f), accent);
        else drawBarsIcon(c, x + w / 2f, iconY, accent, Math.min(0.86f, 0.58f + h / 520f));
        text(c, name, x + w / 2f, top + h * 0.80f, 18, WHITE, true, Paint.Align.CENTER);
    }

    private void drawNeonWave(Canvas c, float centerY, float amp, float phase) {
        p.setStyle(Paint.Style.STROKE);
        p.setShader(new LinearGradient(0, 0, W, 0,
                new int[]{Color.rgb(0, 120, 255), CYAN, BLUE, MAGENTA, Color.rgb(255, 57, 190)},
                null, Shader.TileMode.CLAMP));
        for (int line = 0; line < 12; line++) {
            path.reset();
            for (int i = 0; i <= 90; i++) {
                float x = i * 10f;
                float envelope = 0.72f + 0.28f * (float) Math.sin(i * 0.07f + line * 0.15f);
                float yy = centerY
                        + (float) Math.sin(i * 0.16f + phase + line * 0.07f) * amp * envelope
                        + (float) Math.sin(i * 0.047f + phase * 2f) * amp * 0.35f
                        + (line - 5.5f) * 2.7f;
                if (i == 0) path.moveTo(x, yy); else path.lineTo(x, yy);
            }
            p.setStrokeWidth(line == 5 ? 2.4f : 1f);
            p.setAlpha(line == 5 ? 235 : 60 + line * 6);
            if (line == 5) p.setShadowLayer(16, 0, 0, CYAN);
            c.drawPath(path, p);
            p.clearShadowLayer();
        }
        p.setAlpha(255);
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
    }

    private void drawDevice(Canvas c, float x, float top, float w, float h) {
        Path body = new Path();
        body.moveTo(x + 72, top);
        body.lineTo(x + w - 72, top);
        body.lineTo(x + w, top + h - 38);
        body.quadTo(x + w - 4, top + h, x + w - 34, top + h);
        body.lineTo(x + 34, top + h);
        body.quadTo(x + 4, top + h, x, top + h - 30);
        body.close();
        p.setShader(new LinearGradient(0, top, 0, top + h,
                Color.rgb(39, 49, 64), Color.rgb(7, 12, 21), Shader.TileMode.CLAMP));
        p.setShadowLayer(22, 0, 10, Color.argb(200, 0, 98, 255));
        c.drawPath(body, p);
        p.clearShadowLayer();
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2f);
        p.setColor(Color.rgb(60, 75, 95));
        for (int i = 1; i < 12; i++) {
            float yy = top + 16 + i * (h - 52) / 12f;
            float inset = 26f + (yy - top) * 0.045f;
            c.drawLine(x + inset, yy, x + w - inset, yy, p);
        }
        p.setColor(Color.rgb(85, 103, 130));
        c.drawPath(body, p);

        // V22: chassis details are pure vector/Canvas artwork — no screenshot/bitmap asset.
        p.setStrokeWidth(1.4f);
        p.setColor(Color.argb(150, 135, 158, 188));
        c.drawLine(x + 58, top + 7, x + w - 58, top + 7, p);
        p.setColor(Color.argb(115, 18, 35, 58));
        c.drawLine(x + 18, top + h - 34, x + w - 18, top + h - 34, p);
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(x, 0, x + w, 0,
                new int[]{Color.argb(0,0,0,0), Color.argb(120,0,150,255), Color.argb(0,0,0,0)},
                new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(x + 82, top + h - 17, x + w - 82, top + h - 13, p);
        p.setShader(null);
        for (int i = 0; i < 12; i++) {
            float px = x + 48 + i * (w - 96) / 11f;
            p.setColor((i < 2 || i > 9) ? ORANGE : Color.rgb(20, 27, 38));
            c.drawCircle(px, top + h - 8, (i < 2 || i > 9) ? 4.8f : 3.7f, p);
        }
        p.setStyle(Paint.Style.FILL);
        text(c, "OKN_", x + w * 0.50f - 34, top + h * 0.49f, 36, WHITE, true, Paint.Align.RIGHT);
        text(c, "DSP", x + w * 0.50f - 29, top + h * 0.49f, 36, Color.rgb(0, 165, 255), true, Paint.Align.LEFT);
        letterText(c, "7 CHANNEL DSP", x + w * 0.50f, top + h * 0.60f, 11, WHITE, Paint.Align.CENTER, 4.4f);
        p.setColor(CYAN);
        p.setShadowLayer(15, 0, 0, BLUE);
        c.drawRoundRect(new RectF(x + 75, top + h + 6, x + w - 75, top + h + 10), 3, 3, p);
        p.clearShadowLayer();
        for (int i = 0; i < 8; i++) {
            p.setColor(i < 2 || i > 5 ? ORANGE : Color.rgb(40, 48, 61));
            c.drawCircle(x + 65 + i * (w - 130) / 7f, top + h - 2, 4.5f, p);
        }
    }

    private void drawCircleIcon(Canvas c, float cx, float cy, float r, int accent, int type) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(3f);
        p.setColor(accent);
        p.setShadowLayer(16, 0, 0, accent);
        c.drawCircle(cx, cy, r, p);
        p.clearShadowLayer();
        p.setStyle(Paint.Style.FILL);
        switch (type) {
            case 0: drawSpeakerIcon(c, cx, cy, WHITE, 0.85f); break;
            case 1: drawTargetIcon(c, cx, cy, accent); break;
            case 2: drawFilterIcon(c, cx, cy, accent, true); break;
            default: drawBarsIcon(c, cx, cy, accent, 0.88f); break;
        }
    }

    private void drawCardIcon(Canvas c, float cx, float cy, int accent, int type) {
        if (type == 1) drawMixerIcon(c, cx, cy, accent);
        else if (type == 2) drawBarsIcon(c, cx, cy, accent, 1.15f);
        else if (type == 3) drawCrossoverIcon(c, cx, cy, accent, 0.78f);
        else if (type == 4) drawSaveIcon(c, cx, cy, accent);
        else drawFolderIcon(c, cx, cy, accent);
    }

    private void drawNavIcon(Canvas c, float cx, float cy, int type, int col, boolean glow) {
        if (glow) p.setShadowLayer(12, 0, 0, col);
        if (type == 0) drawHouseIcon(c, cx, cy, col);
        else if (type == 1) drawMixerIcon(c, cx, cy, col);
        else if (type == 2) drawBarsIcon(c, cx, cy, col, 0.95f);
        else drawCrossoverIcon(c, cx, cy, col, 0.70f);
        p.clearShadowLayer();
    }

    private void drawStatIcon(Canvas c, float cx, float cy, int type, int col) {
        if (type == 0) drawBarsIcon(c, cx, cy, col, 0.64f);
        else if (type == 1) {
            p.setColor(col);
            for (int i = 0; i < 4; i++) c.drawRoundRect(new RectF(cx - 24 + i * 14, cy + 18 - i * 12, cx - 17 + i * 14, cy + 32), 3, 3, p);
        } else if (type == 2) drawChipIcon(c, cx, cy + 12, col);
        else drawBluetoothIcon(c, cx, cy + 10, col);
    }

    private void drawSystemIcon(Canvas c, float cx, float cy, int type, int col) {
        p.setColor(col);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(4);
        if (type == 0) {
            c.drawCircle(cx, cy + 10, 11, p); c.drawRoundRect(new RectF(cx - 6, cy - 33, cx + 6, cy + 12), 6, 6, p); c.drawLine(cx, cy - 10, cx, cy + 8, p);
        } else if (type == 1) {
            c.drawRoundRect(new RectF(cx - 12, cy - 28, cx + 12, cy + 23), 4, 4, p); c.drawLine(cx - 5, cy - 35, cx + 5, cy - 35, p); c.drawLine(cx, cy - 35, cx, cy - 28, p);
            path.reset(); path.moveTo(cx + 2, cy - 15); path.lineTo(cx - 5, cy); path.lineTo(cx + 2, cy); path.lineTo(cx - 3, cy + 14); path.lineTo(cx + 10, cy - 4); path.lineTo(cx + 3, cy - 4); c.drawPath(path, p);
        } else if (type == 2) {
            p.setStyle(Paint.Style.FILL); for (int i = 0; i < 4; i++) c.drawRoundRect(new RectF(cx - 20 + i * 12, cy + 18 - i * 11, cx - 13 + i * 12, cy + 25), 2, 2, p);
        } else {
            path.reset(); path.moveTo(cx, cy - 28); path.lineTo(cx + 20, cy - 18); path.lineTo(cx + 16, cy + 8); path.quadTo(cx, cy + 27, cx - 16, cy + 8); path.lineTo(cx - 20, cy - 18); path.close(); c.drawPath(path, p); c.drawLine(cx - 8, cy - 2, cx - 1, cy + 6, p); c.drawLine(cx - 1, cy + 6, cx + 10, cy - 8, p);
        }
        p.setStyle(Paint.Style.FILL);
    }

    private void drawSpeakerIcon(Canvas c, float cx, float cy, int col, float s) {
        p.setColor(col);
        p.setStyle(Paint.Style.FILL);
        Path q = new Path();
        q.moveTo(cx - 26 * s, cy - 10 * s); q.lineTo(cx - 12 * s, cy - 10 * s); q.lineTo(cx + 7 * s, cy - 26 * s); q.lineTo(cx + 7 * s, cy + 26 * s); q.lineTo(cx - 12 * s, cy + 10 * s); q.lineTo(cx - 26 * s, cy + 10 * s); q.close(); c.drawPath(q, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(4 * s); c.drawArc(new RectF(cx - 2 * s, cy - 22 * s, cx + 34 * s, cy + 22 * s), -55, 110, false, p); p.setStyle(Paint.Style.FILL);
    }

    private void drawBarsIcon(Canvas c, float cx, float cy, int col, float s) {
        p.setColor(col); p.setStyle(Paint.Style.FILL); p.setShadowLayer(9 * s, 0, 0, col);
        float[] hs = {19, 36, 50, 31, 21};
        for (int i = 0; i < 5; i++) {
            float xx = cx + (i - 2) * 13 * s;
            float hh = hs[i] * s;
            c.drawRoundRect(new RectF(xx - 4 * s, cy - hh / 2, xx + 4 * s, cy + hh / 2), 4 * s, 4 * s, p);
        }
        p.clearShadowLayer();
    }

    private void drawMixerIcon(Canvas c, float cx, float cy, int col) {
        p.setColor(col); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(5f); p.setStrokeCap(Paint.Cap.ROUND); p.setShadowLayer(8, 0, 0, col);
        for (int i = -1; i <= 1; i++) {
            float x = cx + i * 24;
            c.drawLine(x, cy - 37, x, cy + 37, p);
            float k = cy + (i == -1 ? -10 : i == 0 ? 13 : -2);
            p.setStyle(Paint.Style.FILL); c.drawCircle(x, k, 8, p); p.setStyle(Paint.Style.STROKE);
        }
        p.clearShadowLayer(); p.setStrokeCap(Paint.Cap.BUTT); p.setStyle(Paint.Style.FILL);
    }

    private void drawCrossoverIcon(Canvas c, float cx, float cy, int col, float s) {
        p.setColor(col); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(5 * s); p.setStrokeCap(Paint.Cap.ROUND); p.setShadowLayer(9, 0, 0, col);
        RectF r1 = new RectF(cx - 44 * s, cy - 25 * s, cx + 44 * s, cy + 25 * s);
        c.drawArc(r1, 200, 140, false, p); c.drawArc(r1, 20, 140, false, p);
        p.clearShadowLayer(); p.setStrokeCap(Paint.Cap.BUTT); p.setStyle(Paint.Style.FILL);
    }

    private void drawFilterIcon(Canvas c, float cx, float cy, int col, boolean highPass) {
        p.setColor(col); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(5f); p.setStrokeCap(Paint.Cap.ROUND); p.setShadowLayer(8, 0, 0, col);
        path.reset();
        if (highPass) {
            path.moveTo(cx - 33, cy + 22); path.cubicTo(cx - 8, cy + 22, cx - 9, cy - 22, cx + 13, cy - 22); path.lineTo(cx + 33, cy - 22);
        } else {
            path.moveTo(cx - 33, cy - 22); path.lineTo(cx - 13, cy - 22); path.cubicTo(cx + 9, cy - 22, cx + 8, cy + 22, cx + 33, cy + 22);
        }
        c.drawPath(path, p); p.clearShadowLayer(); p.setStrokeCap(Paint.Cap.BUTT); p.setStyle(Paint.Style.FILL);
    }

    private void drawTargetIcon(Canvas c, float cx, float cy, int col) {
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(5); p.setColor(col); p.setShadowLayer(8, 0, 0, col); c.drawCircle(cx, cy, 24, p); c.drawCircle(cx, cy, 9, p); p.clearShadowLayer(); p.setStyle(Paint.Style.FILL);
    }

    private void drawSaveIcon(Canvas c, float cx, float cy, int col) {
        p.setColor(col); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(5); p.setShadowLayer(8, 0, 0, col);
        c.drawRoundRect(new RectF(cx - 31, cy - 36, cx + 31, cy + 36), 5, 5, p); c.drawRect(cx - 17, cy - 34, cx + 16, cy - 10, p); c.drawRoundRect(new RectF(cx - 18, cy + 5, cx + 18, cy + 27), 4, 4, p); p.clearShadowLayer(); p.setStyle(Paint.Style.FILL);
    }

    private void drawFolderIcon(Canvas c, float cx, float cy, int col) {
        p.setColor(col); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(5); p.setShadowLayer(8, 0, 0, col);
        path.reset(); path.moveTo(cx - 36, cy - 24); path.lineTo(cx - 9, cy - 24); path.lineTo(cx, cy - 12); path.lineTo(cx + 35, cy - 12); path.lineTo(cx + 29, cy + 30); path.lineTo(cx - 36, cy + 30); path.close(); c.drawPath(path, p); p.clearShadowLayer(); p.setStyle(Paint.Style.FILL);
    }

    private void drawHouseIcon(Canvas c, float cx, float cy, int col) {
        p.setColor(col); p.setStyle(Paint.Style.FILL); Path h = new Path(); h.moveTo(cx, cy - 33); h.lineTo(cx + 35, cy - 3); h.lineTo(cx + 27, cy - 3); h.lineTo(cx + 27, cy + 31); h.lineTo(cx + 7, cy + 31); h.lineTo(cx + 7, cy + 8); h.lineTo(cx - 8, cy + 8); h.lineTo(cx - 8, cy + 31); h.lineTo(cx - 27, cy + 31); h.lineTo(cx - 27, cy - 3); h.lineTo(cx - 35, cy - 3); h.close(); c.drawPath(h, p);
    }

    private void drawStar(Canvas c, float cx, float cy, float r, int col) {
        p.setColor(col); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(4); p.setShadowLayer(8, 0, 0, col); path.reset();
        for (int i = 0; i < 10; i++) {
            double a = -Math.PI / 2 + i * Math.PI / 5;
            float rr = i % 2 == 0 ? r : r * 0.45f;
            float x = cx + (float) Math.cos(a) * rr; float yy = cy + (float) Math.sin(a) * rr;
            if (i == 0) path.moveTo(x, yy); else path.lineTo(x, yy);
        }
        path.close(); c.drawPath(path, p); p.clearShadowLayer(); p.setStyle(Paint.Style.FILL);
    }

    private void drawChipIcon(Canvas c, float cx, float cy, int col) {
        p.setColor(col); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(4); c.drawRect(cx - 15, cy - 15, cx + 15, cy + 15, p); for (int i = -1; i <= 1; i++) { c.drawLine(cx - 24, cy + i * 10, cx - 15, cy + i * 10, p); c.drawLine(cx + 15, cy + i * 10, cx + 24, cy + i * 10, p); c.drawLine(cx + i * 10, cy - 24, cx + i * 10, cy - 15, p); c.drawLine(cx + i * 10, cy + 15, cx + i * 10, cy + 24, p); } p.setStyle(Paint.Style.FILL);
    }

    private void drawBluetoothIcon(Canvas c, float cx, float cy, int col) {
        p.setColor(col); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(4); p.setStrokeCap(Paint.Cap.ROUND); path.reset(); path.moveTo(cx, cy - 32); path.lineTo(cx + 18, cy - 14); path.lineTo(cx - 10, cy + 10); path.moveTo(cx, cy - 32); path.lineTo(cx, cy + 32); path.lineTo(cx + 18, cy + 14); path.lineTo(cx - 10, cy - 10); c.drawPath(path, p); p.setStrokeCap(Paint.Cap.BUTT); p.setStyle(Paint.Style.FILL);
    }

    private void drawClockIcon(Canvas c, float cx, float cy, int col) {
        p.setColor(col); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(5); p.setShadowLayer(8, 0, 0, col); c.drawCircle(cx, cy, 28, p); c.drawLine(cx, cy, cx, cy - 18, p); c.drawLine(cx, cy, cx + 16, cy + 11, p); p.clearShadowLayer(); p.setStyle(Paint.Style.FILL);
    }

    private void drawPhaseIcon(Canvas c, float cx, float cy, int col) {
        p.setColor(col); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(5); p.setStrokeCap(Paint.Cap.ROUND); c.drawLine(cx, cy - 29, cx, cy + 29, p); c.drawArc(new RectF(cx - 16, cy - 20, cx + 18, cy + 18), 90, 180, false, p); c.drawArc(new RectF(cx - 18, cy - 18, cx + 16, cy + 20), -90, 180, false, p); p.setStrokeCap(Paint.Cap.BUTT); p.setStyle(Paint.Style.FILL);
    }

    private void drawLinkIcon(Canvas c, float cx, float cy, int col) {
        p.setColor(col); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(5); p.setStrokeCap(Paint.Cap.ROUND); c.drawArc(new RectF(cx - 30, cy - 16, cx + 2, cy + 16), 45, 270, false, p); c.drawArc(new RectF(cx - 2, cy - 16, cx + 30, cy + 16), 225, 270, false, p); c.drawLine(cx - 12, cy, cx + 12, cy, p); p.setStrokeCap(Paint.Cap.BUTT); p.setStyle(Paint.Style.FILL);
    }

    private void drawToggle(Canvas c, float cx, float cy, boolean on, int accent) {
        float w = 58, h = 30;
        p.setColor(on ? Color.argb(180, Color.red(accent), Color.green(accent), Color.blue(accent)) : Color.rgb(13, 48, 85));
        if (on) p.setShadowLayer(9, 0, 0, accent);
        c.drawRoundRect(new RectF(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2), h / 2, h / 2, p);
        p.clearShadowLayer(); p.setColor(WHITE); c.drawCircle(cx + (on ? 14 : -14), cy, 12, p);
    }

    private void addHit(float l, float t, float r, float b, int action) {
        hits.add(new Hit(l, t, r, b, action));
    }

    private static Typeface loadUiTypeface(boolean bold) {
        String[] paths = bold
                ? new String[]{"/system/fonts/Roboto-Bold.ttf", "/system/fonts/Roboto-Medium.ttf"}
                : new String[]{"/system/fonts/Roboto-Regular.ttf", "/system/fonts/RobotoStatic-Regular.ttf"};
        for (String path : paths) {
            try {
                java.io.File f = new java.io.File(path);
                if (f.isFile()) return Typeface.createFromFile(f);
            } catch (RuntimeException ignored) {
                // Fall through to Android's built-in sans family.
            }
        }
        return Typeface.create(bold ? "sans-serif-medium" : "sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL);
    }

    private int blend(int base, int accent, float amount) {
        amount = clamp(amount, 0f, 1f);
        int r = Math.round(Color.red(base) * (1f - amount) + Color.red(accent) * amount);
        int g = Math.round(Color.green(base) * (1f - amount) + Color.green(accent) * amount);
        int b = Math.round(Color.blue(base) * (1f - amount) + Color.blue(accent) * amount);
        return Color.rgb(r, g, b);
    }

    private void text(Canvas c, String s, float x, float baseline, float size, int color, boolean bold, Paint.Align align) {
        p.setStyle(Paint.Style.FILL);
        p.setShader(null);
        p.setColor(color);
        p.setTextSize(size);
        p.setTextAlign(align);
        p.setTypeface(bold ? uiBold : uiRegular);
        p.setStrokeWidth(1f);
        c.drawText(s, x, baseline, p);
    }

    private void letterText(Canvas c, String s, float x, float baseline, float size, int color, Paint.Align align, float spacing) {
        p.setStyle(Paint.Style.FILL);
        p.setShader(null);
        p.setColor(color);
        p.setTextSize(size);
        p.setTypeface(uiRegular);
        p.setTextAlign(Paint.Align.LEFT);
        float total = 0;
        for (int i = 0; i < s.length(); i++) total += p.measureText(String.valueOf(s.charAt(i))) + (i == s.length() - 1 ? 0 : spacing);
        float start = x;
        if (align == Paint.Align.CENTER) start = x - total / 2f;
        else if (align == Paint.Align.RIGHT) start = x - total;
        float cur = start;
        for (int i = 0; i < s.length(); i++) {
            String ch = String.valueOf(s.charAt(i));
            c.drawText(ch, cur, baseline, p);
            cur += p.measureText(ch) + spacing;
        }
    }

    private float measure(String s, float size, boolean bold) {
        p.setTextSize(size);
        p.setTypeface(bold ? uiBold : uiRegular);
        return p.measureText(s);
    }

    private String fmtDb(float v) {
        return String.format(Locale.US, "%+.1f dB", v);
    }

    private String compactHz(float v) {
        if (v >= 1000) {
            float k = v / 1000f;
            if (Math.abs(k - Math.round(k)) < 0.04f) return String.format(Locale.US, "%.0fk", k);
            if (k < 10) return String.format(Locale.US, "%.2gk", k);
            return String.format(Locale.US, "%.1fk", k);
        }
        return String.format(Locale.US, "%.0f", v);
    }

    private String formatFreqFull(float v) {
        if (v >= 1000) return String.format(Locale.US, "%.1f kHz", v / 1000f);
        return String.format(Locale.US, "%.0f Hz", v);
    }

    private float logPos(float value, float min, float max) {
        value = clamp(value, min, max);
        return (float) ((Math.log(value) - Math.log(min)) / (Math.log(max) - Math.log(min)));
    }

    private float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    private float round(float v, float step) {
        if (step <= 0) return v;
        return Math.round(v / step) * step;
    }

    private int gradientBandColor(int b) {
        float t = b / (float) (DspState.BANDS - 1);
        if (t < 0.33f) return lerpColor(CYAN, BLUE, t / 0.33f);
        if (t < 0.66f) return lerpColor(BLUE, MAGENTA, (t - 0.33f) / 0.33f);
        return lerpColor(MAGENTA, ORANGE, (t - 0.66f) / 0.34f);
    }

    private int lerpColor(int a, int b, float t) {
        t = clamp(t, 0, 1);
        return Color.rgb(
                (int) (Color.red(a) + (Color.red(b) - Color.red(a)) * t),
                (int) (Color.green(a) + (Color.green(b) - Color.green(a)) * t),
                (int) (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t));
    }
}
