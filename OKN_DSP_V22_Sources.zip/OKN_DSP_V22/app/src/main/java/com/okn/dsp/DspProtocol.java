package com.okn.dsp;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.GeneralSecurityException;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Verified GoloPine/OKN DSP application protocol facts recovered from the
 * project's real-device captures. No guessed AA55 framing is used here.
 */
final class DspProtocol {
    static final int CMD_WRITE_ACTUATOR = 0x57;
    static final int CMD_READ_SENSOR_ACTUATOR = 0x58;
    static final int TYPE_FLOAT32 = 2000;
    static final int TYPE_BIQUAD_CASCADE15_F = 4084;

    static final int ID_MASTER_VOLUME = 2;
    static final int ID_REMIND_SOUND = 3;
    static final int ID_BASS_VOLUME = 8;
    static final int ID_BASS_CUTOFF = 9;
    static final int ID_BASS_BOOST = 10;
    static final int ID_TREBLE_BOOST = 11;
    static final int ID_MIDDLE_BOOST = 13;

    static final int[] VERIFIED_SCALARS = {2, 3, 8, 9, 10, 13, 11};
    static final int[] EQ_ACTUATORS = {4, 5, 6, 14, 15, 16, 17};

    static final int EQ_BANDS = 15;
    static final int EQ_BAND_BYTES = 48;
    static final int EQ_GENERAL_LOWPASS_TYPE = 3;
    static final int EQ_PEAKING_TYPE = 12;
    static final int EQ_TONE_CONTROL_TYPE = 17;
    static final double SAMPLE_RATE = 44100.0;

    static final byte[] AUTH16 = hex("631C062443FD3844558001F3EDA0CCF8");
    static final byte[] DEVICE_DESCRIPTION_REQUEST = hex("661C0624");

    private static final byte[] DEFAULT_PREAUTH_KEY = hex("2AAF948632A59FF8F2B23E6E4193FD21");
    private static final byte[] TYPE_53285_PREAUTH_KEY = hex("10E7D2F443924938A28D759BAC0E9E22");
    private static final byte[] IV = repeat((byte) 0x01, 16);

    private DspProtocol() {}

    static boolean scalarAllowed(int id) {
        for (int v : VERIFIED_SCALARS) if (v == id) return true;
        return false;
    }

    /** Returns NaN when the requested value is outside the verified hardware range. */
    static float sanitizeScalar(int id, float value) {
        if (!Float.isFinite(value)) return Float.NaN;
        float lo, hi;
        switch (id) {
            case ID_MASTER_VOLUME:
            case ID_REMIND_SOUND:
            case ID_BASS_VOLUME:
                lo = -70f; hi = 6f; break;
            case ID_BASS_CUTOFF:
                lo = 20f; hi = 250f; break;
            case ID_BASS_BOOST:
            case ID_MIDDLE_BOOST:
            case ID_TREBLE_BOOST:
                lo = -12f; hi = 12f; break;
            default:
                return Float.NaN;
        }
        if (value < lo || value > hi) return Float.NaN;
        return value;
    }

    static int eqActuatorForChannel0(int channel0) {
        int ch = Math.max(0, Math.min(6, channel0));
        return EQ_ACTUATORS[ch];
    }

    static int eqBandOffset(int band1) {
        int b = Math.max(1, Math.min(EQ_BANDS, band1));
        return (b - 1) * EQ_BAND_BYTES;
    }

    static byte[] encodeFloatWrite(int id, float value) {
        return encodeWrite(id, 0, f32le(value));
    }

    /** 9-byte UFE sensor/actuator read request observed in the original 250401 app. */
    static byte[] encodeRead(int id, int memoryOffset, int length) {
        ByteBuffer b = ByteBuffer.allocate(9);
        b.put((byte) CMD_READ_SENSOR_ACTUATOR);
        b.putInt(id);
        b.putShort((short) (memoryOffset & 0xffff));
        b.putShort((short) (length & 0xffff));
        return b.array();
    }

    static byte[] encodeEqWrite(int channel0, int band1, EqBand target) {
        return encodeWrite(eqActuatorForChannel0(channel0), eqBandOffset(band1), encodeEqBand(target));
    }

    static byte[] encodeWrite(int actuatorId, int memoryOffset, byte[] data) {
        ByteBuffer b = ByteBuffer.allocate(9 + data.length);
        b.put((byte) CMD_WRITE_ACTUATOR);
        b.putInt(actuatorId); // ByteBuffer default BIG_ENDIAN
        b.putShort((short) (memoryOffset & 0xffff));
        b.putShort((short) (data.length & 0xffff));
        b.put(data);
        return b.array();
    }

    static final class PreAuth {
        final int typeId;
        final int versionId;
        final byte[] randKey;
        PreAuth(int typeId, int versionId, byte[] randKey) {
            this.typeId = typeId;
            this.versionId = versionId;
            this.randKey = randKey;
        }
    }

    static PreAuth decodeAuth32(byte[] response32) throws GeneralSecurityException {
        if (response32 == null || response32.length != 32) throw new IllegalArgumentException("auth response must be 32 bytes");
        int typeId = u16be(response32, 0);
        int versionId = u16be(response32, 2);
        byte[] fixed = typeId == 53285 ? TYPE_53285_PREAUTH_KEY : DEFAULT_PREAUTH_KEY;
        Cipher c = Cipher.getInstance("AES/CFB8/NoPadding");
        c.init(Cipher.DECRYPT_MODE, new SecretKeySpec(fixed, "AES"), new IvParameterSpec(IV));
        byte[] plain = c.update(slice(response32, 8, 32));
        if (plain == null || plain.length != 24) throw new GeneralSecurityException("bad pre-auth plaintext");
        return new PreAuth(typeId, versionId, slice(plain, 8, 24));
    }

    static final class StreamCipher {
        private final Cipher cipher;
        StreamCipher(byte[] randKey, boolean encrypt) throws GeneralSecurityException {
            if (randKey == null || randKey.length != 16) throw new IllegalArgumentException("RandKey must be 16 bytes");
            cipher = Cipher.getInstance("AES/CFB8/NoPadding");
            cipher.init(encrypt ? Cipher.ENCRYPT_MODE : Cipher.DECRYPT_MODE,
                    new SecretKeySpec(randKey.clone(), "AES"), new IvParameterSpec(IV));
        }
        synchronized byte[] next(byte[] input) {
            byte[] out = cipher.update(input);
            return out == null ? new byte[0] : out;
        }
    }

    static final class EqBand {
        final int type;
        final float frequency;
        final float frequency2;
        final float q;
        final float boostDb;
        final float gain;
        final float r;
        final float b0, b1, b2, a1, a2;

        EqBand(int type, float frequency, float frequency2, float q, float boostDb,
               float gain, float r, float b0, float b1, float b2, float a1, float a2) {
            this.type = type;
            this.frequency = frequency;
            this.frequency2 = frequency2;
            this.q = q;
            this.boostDb = boostDb;
            this.gain = gain;
            this.r = r;
            this.b0 = b0;
            this.b1 = b1;
            this.b2 = b2;
            this.a1 = a1;
            this.a2 = a2;
        }

        boolean writablePeaking() {
            return type == EQ_PEAKING_TYPE && structurallyFinite();
        }

        /**
         * V17: the one remaining first-band record is not PEAKING on the real DSP.
         * CH1/2/4/5/6/7 use SigmaDSP Tone Control (type 17); CH3 uses General
         * Low-pass (type 3). We preserve those native types and only expose the
         * gain parameter that their own filter math supports.
         */
        /** V22: current GoloPine 15-slot cascade records that may be converted to a true Graphic-EQ PEAKING cell. */
        boolean graphicConvertible() {
            return type == EQ_PEAKING_TYPE || type == EQ_TONE_CONTROL_TYPE || type == EQ_GENERAL_LOWPASS_TYPE;
        }

        boolean writableFirstBandSpecial() {
            if (!structurallyFinite()) return false;
            if (type == EQ_TONE_CONTROL_TYPE) {
                return frequency >= 20f && frequency <= 20000f &&
                        frequency2 >= 20f && frequency2 <= 20000f &&
                        q >= 0.05f && q <= 20f &&
                        boostDb >= -12f && boostDb <= 12f &&
                        r >= -12f && r <= 12f && gain >= -12f && gain <= 12f;
            }
            if (type == EQ_GENERAL_LOWPASS_TYPE) {
                return frequency >= 20f && frequency <= 20000f &&
                        q >= 0.05f && q <= 20f && gain >= -12f && gain <= 12f;
            }
            return false;
        }

        float graphicGainDb() {
            return type == EQ_GENERAL_LOWPASS_TYPE ? gain : boostDb;
        }

        private boolean structurallyFinite() {
            return Float.isFinite(frequency) && Float.isFinite(frequency2) &&
                    Float.isFinite(q) && Float.isFinite(boostDb) &&
                    Float.isFinite(gain) && Float.isFinite(r) &&
                    Float.isFinite(b0) && Float.isFinite(b1) && Float.isFinite(b2) &&
                    Float.isFinite(a1) && Float.isFinite(a2);
        }
    }

    static EqBand peaking(float frequencyHz, float q, float boostDb) {
        if (!Float.isFinite(frequencyHz) || frequencyHz < 20f || frequencyHz > 20000f) throw new IllegalArgumentException("frequency");
        if (!Float.isFinite(q) || q < 0.05f || q > 20f) throw new IllegalArgumentException("q");
        if (!Float.isFinite(boostDb) || boostDb < -12f || boostDb > 12f) throw new IllegalArgumentException("boost");
        float roundedBoost = Math.round(boostDb * 10f) / 10f;
        double a = Math.pow(10.0, roundedBoost / 40.0);
        double w0 = 2.0 * Math.PI * frequencyHz / SAMPLE_RATE;
        double alpha = Math.sin(w0) / (2.0 * q);
        double a0 = 1.0 + alpha / a;
        double b0 = (1.0 + alpha * a) / a0;
        double b1 = (-2.0 * Math.cos(w0)) / a0;
        double b2 = (1.0 - alpha * a) / a0;
        double a1 = (-2.0 * Math.cos(w0)) / a0;
        double a2 = (1.0 - alpha / a) / a0;
        return new EqBand(EQ_PEAKING_TYPE, frequencyHz, 0f, q, roundedBoost, 0f, 0f,
                (float) b0, (float) b1, (float) b2, (float) a1, (float) a2);
    }

    /**
     * V22 strict Graphic-EQ cell builder. Every visible 15-band fader must control
     * the exact centre frequency printed beneath it. Build one canonical PEAKING
     * record at that centre instead of inheriting a different native F/F2/G/R.
     * This is used only for current descriptor record types proven present in this
     * device (PEAKING, Tone-Control, General Low-pass).
     */
    static EqBand graphicPeaking(float frequencyHz, float boostDb, float q) {
        if (!Float.isFinite(frequencyHz) || frequencyHz < 20f || frequencyHz > 20000f)
            throw new IllegalArgumentException("frequency");
        if (!Float.isFinite(boostDb) || boostDb < -12f || boostDb > 12f)
            throw new IllegalArgumentException("gain");
        if (!Float.isFinite(q) || q < 0.05f || q > 20f)
            throw new IllegalArgumentException("q");
        float roundedF = Math.round(frequencyHz * 10f) / 10f;
        float roundedQ = Math.round(q * 100f) / 100f;
        return peaking(roundedF, roundedQ, boostDb);
    }

    /**
     * V16 Graphic-EQ target builder. The DSP's current PEAKING record may carry
     * non-zero auxiliary metadata (F2/G/R). Preserve those exact live fields and
     * change only Boost plus the coefficients derived from live Frequency/Q.
     */
    static EqBand peakingFromCurrent(EqBand current, float boostDb) {
        return peakingFromCurrent(current, boostDb, current == null ? Float.NaN : current.q);
    }

    /** V19: PEAKING writer can update Gain and Q together while preserving live F2/G/R metadata. */
    static EqBand peakingFromCurrent(EqBand current, float boostDb, float q) {
        if (current == null || !current.writablePeaking()) throw new IllegalArgumentException("current");
        if (!Float.isFinite(q) || q < 0.05f || q > 20f) throw new IllegalArgumentException("q");
        float roundedQ = Math.round(q * 100f) / 100f;
        EqBand coeff = peaking(current.frequency, roundedQ, boostDb);
        return new EqBand(EQ_PEAKING_TYPE, current.frequency, current.frequency2, roundedQ,
                coeff.boostDb, current.gain, current.r,
                coeff.b0, coeff.b1, coeff.b2, coeff.a1, coeff.a2);
    }

    /**
     * V21 Graphic-EQ hardware-frequency binding. V18 changed only the labels, while the
     * live PEAKING records could still carry arbitrary parametric frequencies (for example
     * record 2 at 650 Hz while the UI says 40 Hz). For a Graphic EQ control, the hardware
     * record must be retuned to the displayed ISO centre. Preserve the verified auxiliary
     * metadata F2/G/R and change F + Q + Boost + coefficients only.
     */
    static EqBand peakingAtFrequencyFromCurrent(EqBand current, float frequencyHz, float boostDb, float q) {
        if (current == null || !current.writablePeaking()) throw new IllegalArgumentException("current");
        if (!Float.isFinite(frequencyHz) || frequencyHz < 20f || frequencyHz > 20000f)
            throw new IllegalArgumentException("frequency");
        if (!Float.isFinite(q) || q < 0.05f || q > 20f) throw new IllegalArgumentException("q");
        float roundedQ = Math.round(q * 100f) / 100f;
        float roundedF = Math.round(frequencyHz * 10f) / 10f;
        EqBand coeff = peaking(roundedF, roundedQ, boostDb);
        return new EqBand(EQ_PEAKING_TYPE, roundedF, current.frequency2, roundedQ,
                coeff.boostDb, current.gain, current.r,
                coeff.b0, coeff.b1, coeff.b2, coeff.a1, coeff.a2);
    }

    /** Build the V17/V19 first-band target without changing the live filter type. */
    static EqBand firstBandGainFromCurrent(EqBand current, float requestedGainDb) {
        return firstBandFromCurrent(current, requestedGainDb, current == null ? Float.NaN : current.q);
    }

    /** V19: selected first band can update its stored Q while preserving native filter type. */
    static EqBand firstBandFromCurrent(EqBand current, float requestedGainDb, float q) {
        if (current == null || !current.writableFirstBandSpecial()) throw new IllegalArgumentException("current");
        if (!Float.isFinite(requestedGainDb) || requestedGainDb < -12f || requestedGainDb > 12f)
            throw new IllegalArgumentException("gain");
        if (!Float.isFinite(q) || q < 0.05f || q > 20f) throw new IllegalArgumentException("q");
        float rounded = Math.round(requestedGainDb * 10f) / 10f;
        float roundedQ = Math.round(q * 100f) / 100f;
        if (current.type == EQ_TONE_CONTROL_TYPE) return toneControlFromCurrent(current, rounded, roundedQ);
        if (current.type == EQ_GENERAL_LOWPASS_TYPE) return generalLowPassFromCurrent(current, rounded, roundedQ);
        throw new IllegalArgumentException("unsupported first-band type");
    }

    /**
     * Exact SigmaStudio Tone Control math. On the real descriptor the mapping is
     * F=bass cutoff, F2=treble cutoff, B=bass boost, G=cell gain, R=treble boost.
     * With F=220, F2=1800, B=7.8, G=0, R=11.52 this reproduces the captured
     * coefficients to float precision, so V17 can change only the low-band boost
     * while preserving the live treble side of the same Tone Control cell.
     */
    static EqBand toneControlFromCurrent(EqBand current, float bassBoostDb) {
        return toneControlFromCurrent(current, bassBoostDb, current == null ? Float.NaN : current.q);
    }

    static EqBand toneControlFromCurrent(EqBand current, float bassBoostDb, float q) {
        if (current.type != EQ_TONE_CONTROL_TYPE) throw new IllegalArgumentException("type");
        if (!Float.isFinite(q) || q < 0.05f || q > 20f) throw new IllegalArgumentException("q");
        double tb = Math.pow(10.0, current.r / 20.0);
        double bb = Math.pow(10.0, bassBoostDb / 20.0);
        double at = Math.tan(Math.PI * current.frequency2 / SAMPLE_RATE);
        double ab = Math.tan(Math.PI * current.frequency / SAMPLE_RATE);
        double knumT = 2.0 / (1.0 + (1.0 / tb));
        double kdenT = 2.0 / (1.0 + tb);
        double knumB = 2.0 / (1.0 + (1.0 / bb));
        double kdenB = 2.0 / (1.0 + bb);
        double a10 = at + kdenT;
        double b10 = at + knumT;
        double a11 = at - kdenT;
        double b11 = at - knumT;
        double a20 = (ab * kdenB) + 1.0;
        double b20 = (ab * knumB) - 1.0;
        double a21 = (ab * kdenB) - 1.0;
        double b21 = (ab * knumB) + 1.0;
        double a0 = a10 * a20;
        double gl = Math.pow(10.0, current.gain / 20.0);
        float b0 = (float) (((b10 * b20) / a0) * gl);
        float b1 = (float) ((((b10 * b21) + (b11 * b20)) / a0) * gl);
        float b2 = (float) (((b11 * b21) / a0) * gl);
        float a1 = (float) (((a10 * a21) + (a11 * a20)) / a0);
        float a2 = (float) ((a11 * a21) / a0);
        return new EqBand(EQ_TONE_CONTROL_TYPE, current.frequency, current.frequency2, q,
                bassBoostDb, current.gain, current.r, b0, b1, b2, a1, a2);
    }

    /** RBJ/SigmaStudio general low-pass with the cell gain applied to B coefficients. */
    static EqBand generalLowPassFromCurrent(EqBand current, float gainDb) {
        return generalLowPassFromCurrent(current, gainDb, current == null ? Float.NaN : current.q);
    }

    static EqBand generalLowPassFromCurrent(EqBand current, float gainDb, float q) {
        if (current.type != EQ_GENERAL_LOWPASS_TYPE) throw new IllegalArgumentException("type");
        if (!Float.isFinite(q) || q < 0.05f || q > 20f) throw new IllegalArgumentException("q");
        double w0 = 2.0 * Math.PI * current.frequency / SAMPLE_RATE;
        double cs = Math.cos(w0);
        double sn = Math.sin(w0);
        double alpha = sn / (2.0 * q);
        double a0 = 1.0 + alpha;
        double gl = Math.pow(10.0, gainDb / 20.0);
        float b0 = (float) ((((1.0 - cs) / 2.0) / a0) * gl);
        float b1 = (float) (((1.0 - cs) / a0) * gl);
        float b2 = b0;
        float a1 = (float) ((-2.0 * cs) / a0);
        float a2 = (float) ((1.0 - alpha) / a0);
        return new EqBand(EQ_GENERAL_LOWPASS_TYPE, current.frequency, current.frequency2, q,
                current.boostDb, gainDb, current.r, b0, b1, b2, a1, a2);
    }

    static byte[] encodeEqBand(EqBand v) {
        ByteBuffer b = ByteBuffer.allocate(EQ_BAND_BYTES).order(ByteOrder.LITTLE_ENDIAN);
        b.putInt(v.type);
        b.putFloat(v.frequency);
        b.putFloat(v.frequency2);
        b.putFloat(v.q);
        b.putFloat(v.boostDb);
        b.putFloat(v.gain);
        b.putFloat(v.r);
        b.putFloat(v.b0);
        b.putFloat(v.b1);
        b.putFloat(v.b2);
        b.putFloat(v.a1);
        b.putFloat(v.a2);
        return b.array();
    }

    static byte[] f32le(float v) {
        return ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putFloat(v).array();
    }

    static int u16be(byte[] b, int off) {
        return ((b[off] & 0xff) << 8) | (b[off + 1] & 0xff);
    }

    static byte[] hex(String s) {
        s = s.replace(" ", "").replace("\n", "").trim();
        if ((s.length() & 1) != 0) throw new IllegalArgumentException("hex length");
        byte[] out = new byte[s.length() / 2];
        for (int i = 0; i < out.length; i++) out[i] = (byte) Integer.parseInt(s.substring(i * 2, i * 2 + 2), 16);
        return out;
    }

    static String hexOf(byte[] b) {
        if (b == null) return "";
        StringBuilder sb = new StringBuilder(b.length * 2);
        for (byte v : b) sb.append(String.format("%02X", v & 0xff));
        return sb.toString();
    }

    private static byte[] slice(byte[] b, int from, int to) {
        byte[] out = new byte[to - from];
        System.arraycopy(b, from, out, 0, out.length);
        return out;
    }

    private static byte[] repeat(byte v, int n) {
        byte[] b = new byte[n];
        for (int i = 0; i < n; i++) b[i] = v;
        return b;
    }
}
