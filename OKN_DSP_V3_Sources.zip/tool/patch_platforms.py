from pathlib import Path
import plistlib
import re

root = Path(__file__).resolve().parents[1]
manifest = root / 'android/app/src/main/AndroidManifest.xml'
if manifest.exists():
    text = manifest.read_text(encoding='utf-8')
    permissions = '''\n    <uses-feature android:name="android.hardware.bluetooth_le" android:required="false" />\n    <uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30" />\n    <uses-permission android:name="android.permission.BLUETOOTH_ADMIN" android:maxSdkVersion="30" />\n    <uses-permission android:name="android.permission.BLUETOOTH_SCAN" android:usesPermissionFlags="neverForLocation" />\n    <uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />\n    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" android:maxSdkVersion="30" />\n    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" android:maxSdkVersion="30" />\n'''
    marker = '<application'
    if 'android.permission.BLUETOOTH_SCAN' not in text:
        text = text.replace(marker, permissions + '    ' + marker, 1)
    text = text.replace('android:label="okn_dsp"', 'android:label="OKN_DSP"')
    manifest.write_text(text, encoding='utf-8')

# Explicitly compile the application against API 36. This does not change
# minSdk and is independent of runtime target behavior.
for gradle in (
    root / 'android/app/build.gradle.kts',
    root / 'android/app/build.gradle',
):
    if not gradle.exists():
        continue
    text = gradle.read_text(encoding='utf-8')
    text = re.sub(r'(?m)^(\s*compileSdk\s*=\s*)flutter\.compileSdkVersion\s*$', r'\g<1>36', text)
    text = re.sub(r'(?m)^(\s*compileSdkVersion\s+)flutter\.compileSdkVersion\s*$', r'\g<1>36', text)
    text = re.sub(r'(?m)^(\s*compileSdk\s*=\s*)\d+\s*$', r'\g<1>36', text)
    text = re.sub(r'(?m)^(\s*compileSdkVersion\s+)(\d+)\s*$', r'\g<1>36', text)
    gradle.write_text(text, encoding='utf-8')

# Disable Gradle VFS watching in CI to avoid the Linux runner message
# "Already watching path: .../android" seen in the V2 release build log.
gradle_properties = root / 'android/gradle.properties'
if gradle_properties.exists():
    text = gradle_properties.read_text(encoding='utf-8')
    lines = [line for line in text.splitlines() if not line.startswith('org.gradle.vfs.watch=')]
    lines.append('org.gradle.vfs.watch=false')
    gradle_properties.write_text('\n'.join(lines).rstrip() + '\n', encoding='utf-8')

plist = root / 'ios/Runner/Info.plist'
if plist.exists():
    with plist.open('rb') as fh:
        data = plistlib.load(fh)
    data['CFBundleDisplayName'] = 'OKN_DSP'
    data['NSBluetoothAlwaysUsageDescription'] = 'OKN_DSP uses Bluetooth to connect to and control your DSP audio processor.'
    data['NSBluetoothPeripheralUsageDescription'] = 'OKN_DSP uses Bluetooth to communicate with your DSP audio processor.'
    with plist.open('wb') as fh:
        plistlib.dump(data, fh, sort_keys=False)
