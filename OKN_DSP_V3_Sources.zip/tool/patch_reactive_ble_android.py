#!/usr/bin/env python3
"""Compatibility patch for reactive_ble_mobile Android builds.

flutter_reactive_ble 5.5.0 currently pulls reactive_ble_mobile whose published
Android library can declare compileSdk 33. Modern AndroidX artifacts used by the
same plugin require compileSdk >= 34. This script locates the *resolved* package
from .dart_tool/package_config.json and raises only its compile SDK to 36.

The patch is deterministic, idempotent, and intentionally does not modify BLE
source code, targetSdk, minSdk, Kotlin source, or the DSP application protocol.
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path
from urllib.parse import unquote, urlparse

REQUIRED_COMPILE_SDK = 36
PACKAGE_NAME = "reactive_ble_mobile"


def _package_root(project_root: Path) -> Path:
    config = project_root / ".dart_tool" / "package_config.json"
    if not config.exists():
        raise RuntimeError(
            f"{config} does not exist. Run 'flutter pub get' before this patch."
        )

    data = json.loads(config.read_text(encoding="utf-8"))
    for package in data.get("packages", []):
        if package.get("name") != PACKAGE_NAME:
            continue
        raw_uri = package.get("rootUri")
        if not raw_uri:
            raise RuntimeError(f"Package {PACKAGE_NAME} has no rootUri")
        parsed = urlparse(raw_uri)
        if parsed.scheme == "file":
            return Path(unquote(parsed.path)).resolve()
        # package_config allows relative URI values as well.
        return (config.parent / unquote(raw_uri)).resolve()

    raise RuntimeError(
        f"Package {PACKAGE_NAME!r} was not found in {config}. "
        "Check flutter_reactive_ble dependency resolution."
    )


def _patch_gradle_file(path: Path) -> bool:
    if not path.exists():
        return False

    original = path.read_text(encoding="utf-8")
    updated = original

    # Groovy DSL: compileSdkVersion 33 / compileSdk 33
    updated = re.sub(
        r"(?m)^(\s*compileSdkVersion\s+)(\d+)(\s*(?://.*)?)$",
        lambda m: f"{m.group(1)}{max(int(m.group(2)), REQUIRED_COMPILE_SDK)}{m.group(3)}",
        updated,
    )
    updated = re.sub(
        r"(?m)^(\s*compileSdk\s+)(\d+)(\s*(?://.*)?)$",
        lambda m: f"{m.group(1)}{max(int(m.group(2)), REQUIRED_COMPILE_SDK)}{m.group(3)}",
        updated,
    )

    # Kotlin DSL / assignment forms: compileSdk = 33, compileSdkVersion = 33
    updated = re.sub(
        r"(?m)^(\s*compileSdk(?:Version)?\s*=\s*)(\d+)(\s*(?://.*)?)$",
        lambda m: f"{m.group(1)}{max(int(m.group(2)), REQUIRED_COMPILE_SDK)}{m.group(3)}",
        updated,
    )

    # Function-call form: compileSdkVersion(33)
    updated = re.sub(
        r"compileSdkVersion\s*\(\s*(\d+)\s*\)",
        lambda m: f"compileSdkVersion({max(int(m.group(1)), REQUIRED_COMPILE_SDK)})",
        updated,
    )

    if updated != original:
        path.write_text(updated, encoding="utf-8")
        return True
    return False


def _numeric_compile_sdks(text: str) -> list[int]:
    values: list[int] = []
    patterns = [
        r"compileSdkVersion\s+(\d+)",
        r"compileSdk\s+(\d+)",
        r"compileSdk(?:Version)?\s*=\s*(\d+)",
        r"compileSdkVersion\s*\(\s*(\d+)\s*\)",
    ]
    for pattern in patterns:
        values.extend(int(v) for v in re.findall(pattern, text))
    return values


def main() -> int:
    project_root = Path(__file__).resolve().parents[1]
    package_root = _package_root(project_root)
    android_dir = package_root / "android"
    candidates = [android_dir / "build.gradle", android_dir / "build.gradle.kts"]
    existing = [p for p in candidates if p.exists()]
    if not existing:
        raise RuntimeError(
            f"No Android Gradle build file found for {PACKAGE_NAME} at {android_dir}"
        )

    changed = False
    for path in existing:
        changed |= _patch_gradle_file(path)

    # Hard validation: if the plugin contains a numeric compileSdk declaration,
    # it must now be >= REQUIRED_COMPILE_SDK.
    seen_numeric = []
    for path in existing:
        text = path.read_text(encoding="utf-8")
        seen_numeric.extend(_numeric_compile_sdks(text))

    if seen_numeric and min(seen_numeric) < REQUIRED_COMPILE_SDK:
        raise RuntimeError(
            f"{PACKAGE_NAME} still contains compileSdk < {REQUIRED_COMPILE_SDK}: "
            f"{seen_numeric}"
        )

    state = "patched" if changed else "already compatible"
    print(
        f"{PACKAGE_NAME}: {state}; compileSdk requirement is "
        f"{REQUIRED_COMPILE_SDK}; package root={package_root}"
    )
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ERROR: reactive BLE Android compatibility patch failed: {exc}", file=sys.stderr)
        raise SystemExit(1)
