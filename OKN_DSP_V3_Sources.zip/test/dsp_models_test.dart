import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:okn_dsp/models/dsp_models.dart';

void main() {
  test('DSP exposes seven output channels', () {
    expect(dspChannels.length, 7);
    expect(dspChannels.first.name, 'Front L');
    expect(dspChannels.last.name, 'Sub R');
  });

  test('EQ band copyWith preserves unmodified values', () {
    const band = EqBand(
      type: EqFilterType.peq,
      frequencyHz: 1000,
      gainDb: 0,
      q: 1,
      enabled: true,
      color: Color(0xFFFFFFFF),
    );
    final changed = band.copyWith(gainDb: 3.5);
    expect(changed.frequencyHz, 1000);
    expect(changed.gainDb, 3.5);
    expect(changed.enabled, true);
  });
}
