package com.okn.dsp;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Locale;

/**
 * Local UI state + persistence for Phase 1.
 * Every value is changed in memory immediately. During dragging we call apply() so the UI never
 * waits for disk I/O; ACTION_UP calls commitFinal() to synchronously seal the latest value.
 */
public final class UiStateStore {
    public static final int PAGE_HOME = 0;
    public static final int PAGE_MIX = 1;
    public static final int PAGE_EQ = 2;

    public static final int THEME_LIGHT = 0;
    public static final int THEME_DARK = 1;

    public static final int CHANNEL_COUNT = 7;
    public static final int BAND_COUNT = 15;

    // UI-only defaults. Phase 2 will replace ranges/defaults with values proven by DSP protocol data.
    public static final float[] DEFAULT_FREQS = new float[] {
            20f, 31f, 50f, 80f, 125f, 200f, 315f, 500f, 800f,
            1250f, 2000f, 3150f, 5000f, 10000f, 20000f
    };

    private static final float[] DEMO_GAINS = new float[] {
            -3.5f, -2.5f, -0.8f, 2.0f, 4.5f, 2.2f, 0.2f, -1.8f, -2.8f,
            -2.5f, -0.5f, 2.3f, 4.0f, 2.7f, 0.8f
    };

    private static final String PREFS = "okn_dsp_v1_state";
    private final SharedPreferences prefs;

    public int page;
    public int theme;
    public int selectedChannel;
    public int selectedBand;

    public float masterVolume;
    public float bassVolume;
    public float bassCutoff;
    public final float[] channelVolumes = new float[CHANNEL_COUNT];
    public final float[][] eqFrequency = new float[CHANNEL_COUNT][BAND_COUNT];
    public final float[][] eqQ = new float[CHANNEL_COUNT][BAND_COUNT];
    public final float[][] eqGain = new float[CHANNEL_COUNT][BAND_COUNT];

    public boolean presetSaved;

    public UiStateStore(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        load();
    }

    private void load() {
        page = clampInt(prefs.getInt("page", PAGE_HOME), PAGE_HOME, PAGE_EQ);
        theme = clampInt(prefs.getInt("theme", THEME_LIGHT), THEME_LIGHT, THEME_DARK);
        selectedChannel = clampInt(prefs.getInt("selected_channel", 0), 0, CHANNEL_COUNT - 1);
        selectedBand = clampInt(prefs.getInt("selected_band", 0), 0, BAND_COUNT - 1);

        masterVolume = saneFloat(prefs.getFloat("mix_master", -6f), -60f, 12f, -6f);
        bassVolume = saneFloat(prefs.getFloat("mix_bass_volume", 2f), -12f, 12f, 2f);
        bassCutoff = saneFloat(prefs.getFloat("mix_bass_cutoff", 80f), 40f, 250f, 80f);

        for (int ch = 0; ch < CHANNEL_COUNT; ch++) {
            channelVolumes[ch] = saneFloat(prefs.getFloat("mix_ch_" + ch, ch == 0 ? -3f : -6f), -60f, 12f, ch == 0 ? -3f : -6f);
            for (int band = 0; band < BAND_COUNT; band++) {
                String base = keyBase(ch, band);
                eqFrequency[ch][band] = saneFloat(prefs.getFloat(base + "_f", DEFAULT_FREQS[band]), 20f, 20000f, DEFAULT_FREQS[band]);
                eqQ[ch][band] = saneFloat(prefs.getFloat(base + "_q", 1.0f), 0.1f, 10f, 1.0f);
                // The first launch uses a reference-like demo curve only for visual Phase 1 review.
                // It is local UI data and is not sent to hardware.
                eqGain[ch][band] = saneFloat(prefs.getFloat(base + "_g", DEMO_GAINS[band]), -12f, 12f, DEMO_GAINS[band]);
            }
        }
        presetSaved = prefs.getBoolean("preset_saved", false);
    }

    public void savePageAsync() {
        prefs.edit().putInt("page", page).apply();
    }

    public void saveThemeNow() {
        prefs.edit().putInt("theme", theme).commit();
    }

    public void saveSelectionAsync() {
        prefs.edit()
                .putInt("selected_channel", selectedChannel)
                .putInt("selected_band", selectedBand)
                .apply();
    }

    public void saveMasterAsync() {
        prefs.edit().putFloat("mix_master", masterVolume).apply();
    }

    public void saveBassVolumeAsync() {
        prefs.edit().putFloat("mix_bass_volume", bassVolume).apply();
    }

    public void saveBassCutoffAsync() {
        prefs.edit().putFloat("mix_bass_cutoff", bassCutoff).apply();
    }

    public void saveChannelVolumeAsync(int channel) {
        prefs.edit().putFloat("mix_ch_" + channel, channelVolumes[channel]).apply();
    }

    public void saveEqBandAsync(int channel, int band) {
        String base = keyBase(channel, band);
        prefs.edit()
                .putFloat(base + "_f", eqFrequency[channel][band])
                .putFloat(base + "_q", eqQ[channel][band])
                .putFloat(base + "_g", eqGain[channel][band])
                .apply();
    }

    public void commitFinal() {
        SharedPreferences.Editor e = prefs.edit()
                .putInt("page", page)
                .putInt("theme", theme)
                .putInt("selected_channel", selectedChannel)
                .putInt("selected_band", selectedBand)
                .putFloat("mix_master", masterVolume)
                .putFloat("mix_bass_volume", bassVolume)
                .putFloat("mix_bass_cutoff", bassCutoff);

        for (int ch = 0; ch < CHANNEL_COUNT; ch++) {
            e.putFloat("mix_ch_" + ch, channelVolumes[ch]);
            for (int band = 0; band < BAND_COUNT; band++) {
                String base = keyBase(ch, band);
                e.putFloat(base + "_f", eqFrequency[ch][band]);
                e.putFloat(base + "_q", eqQ[ch][band]);
                e.putFloat(base + "_g", eqGain[ch][band]);
            }
        }
        e.commit();
    }

    public void savePreset1() {
        SharedPreferences.Editor e = prefs.edit();
        for (int ch = 0; ch < CHANNEL_COUNT; ch++) {
            e.putFloat("preset_mix_ch_" + ch, channelVolumes[ch]);
            for (int band = 0; band < BAND_COUNT; band++) {
                String dst = "preset_" + keyBase(ch, band);
                e.putFloat(dst + "_f", eqFrequency[ch][band]);
                e.putFloat(dst + "_q", eqQ[ch][band]);
                e.putFloat(dst + "_g", eqGain[ch][band]);
            }
        }
        e.putFloat("preset_master", masterVolume)
                .putFloat("preset_bass_volume", bassVolume)
                .putFloat("preset_bass_cutoff", bassCutoff)
                .putBoolean("preset_saved", true)
                .commit();
        presetSaved = true;
    }

    public boolean loadPreset1() {
        if (!prefs.getBoolean("preset_saved", false)) return false;
        masterVolume = prefs.getFloat("preset_master", masterVolume);
        bassVolume = prefs.getFloat("preset_bass_volume", bassVolume);
        bassCutoff = prefs.getFloat("preset_bass_cutoff", bassCutoff);
        for (int ch = 0; ch < CHANNEL_COUNT; ch++) {
            channelVolumes[ch] = prefs.getFloat("preset_mix_ch_" + ch, channelVolumes[ch]);
            for (int band = 0; band < BAND_COUNT; band++) {
                String src = "preset_" + keyBase(ch, band);
                eqFrequency[ch][band] = prefs.getFloat(src + "_f", eqFrequency[ch][band]);
                eqQ[ch][band] = prefs.getFloat(src + "_q", eqQ[ch][band]);
                eqGain[ch][band] = prefs.getFloat(src + "_g", eqGain[ch][band]);
            }
        }
        commitFinal();
        return true;
    }

    public void deletePreset1() {
        SharedPreferences.Editor e = prefs.edit();
        e.putBoolean("preset_saved", false);
        for (int ch = 0; ch < CHANNEL_COUNT; ch++) {
            e.remove("preset_mix_ch_" + ch);
            for (int band = 0; band < BAND_COUNT; band++) {
                String src = "preset_" + keyBase(ch, band);
                e.remove(src + "_f");
                e.remove(src + "_q");
                e.remove(src + "_g");
            }
        }
        e.remove("preset_master")
                .remove("preset_bass_volume")
                .remove("preset_bass_cutoff")
                .commit();
        presetSaved = false;
    }

    public void resetSelectedChannelEq() {
        int ch = selectedChannel;
        for (int band = 0; band < BAND_COUNT; band++) {
            eqFrequency[ch][band] = DEFAULT_FREQS[band];
            eqQ[ch][band] = 1.0f;
            eqGain[ch][band] = 0f;
        }
        commitFinal();
    }

    public String presetLabel() {
        return presetSaved ? "Preset 1 • Saved" : "Preset 1 • Empty";
    }

    public static String formatFrequency(float hz) {
        if (hz >= 1000f) {
            float khz = hz / 1000f;
            if (khz >= 10f) return String.format(Locale.US, "%.0f kHz", khz);
            return String.format(Locale.US, "%.2f kHz", khz).replace(".00", "");
        }
        return String.format(Locale.US, "%.0f Hz", hz);
    }

    private static String keyBase(int channel, int band) {
        return "eq_c" + channel + "_b" + band;
    }

    private static float saneFloat(float value, float min, float max, float fallback) {
        if (Float.isNaN(value) || Float.isInfinite(value)) return fallback;
        return Math.max(min, Math.min(max, value));
    }

    private static int clampInt(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }
}
