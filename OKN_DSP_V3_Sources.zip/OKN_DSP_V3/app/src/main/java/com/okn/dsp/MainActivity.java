package com.okn.dsp;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.Toast;

public class MainActivity extends Activity implements BleManager.Listener {
    private static final int REQ_BLE = 7001;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private DspView dspView;
    private BleManager bleManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // V3 rule: UI must be able to open even if Bluetooth/OEM permission code fails.
        enterImmersiveSafely();
        dspView = new DspView(this, null);
        setContentView(dspView);
        dspView.setBleStatus("พร้อมใช้งาน • กำลังเตรียม Bluetooth", "OKN-DSP_7CH", false);

        // Let the first frame render before touching Bluetooth APIs/permission UI.
        mainHandler.postDelayed(this::initializeBleSafely, 450L);
    }

    private void initializeBleSafely() {
        if (isFinishing() || isDestroyed()) return;
        try {
            bleManager = new BleManager(this, this);
            dspView.setBleManager(bleManager);
            requestBlePermissionsIfNeeded();
        } catch (RuntimeException e) {
            showBleUnavailable("Bluetooth เริ่มทำงานไม่ได้: " + e.getClass().getSimpleName());
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        enterImmersiveSafely();
    }

    @Override
    protected void onDestroy() {
        mainHandler.removeCallbacksAndMessages(null);
        if (bleManager != null) bleManager.close();
        super.onDestroy();
    }

    @Override
    public void onBleStatus(String status, String deviceName, boolean connected) {
        if (dspView != null) dspView.setBleStatus(status, deviceName, connected);
    }

    @Override
    public void onBleMessage(String message) {
        if (dspView != null) dspView.setDiagnostic(message);
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private void requestBlePermissionsIfNeeded() {
        if (bleManager == null) return;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                boolean scan = checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED;
                boolean connect = checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
                if (!scan || !connect) {
                    dspView.setBleStatus("รออนุญาต Bluetooth", "OKN-DSP_7CH", false);
                    requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}, REQ_BLE);
                } else {
                    bleManager.startScan();
                }
            } else {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    dspView.setBleStatus("รออนุญาตตำแหน่งสำหรับ BLE", "OKN-DSP_7CH", false);
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_BLE);
                } else {
                    bleManager.startScan();
                }
            }
        } catch (RuntimeException e) {
            showBleUnavailable("ขอสิทธิ์ Bluetooth ไม่สำเร็จ: " + e.getClass().getSimpleName());
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_BLE) return;

        boolean ok = grantResults.length > 0;
        for (int result : grantResults) ok &= result == PackageManager.PERMISSION_GRANTED;
        if (ok && bleManager != null) {
            bleManager.startScan();
        } else {
            if (dspView != null) dspView.setBleStatus("UI ใช้งานได้ • Bluetooth ยังไม่ได้รับสิทธิ์", "OKN-DSP_7CH", false);
            Toast.makeText(this, "แอปเปิดใช้งานได้ แต่ต้องอนุญาต Bluetooth ก่อนเชื่อมต่อ DSP", Toast.LENGTH_LONG).show();
        }
    }

    private void showBleUnavailable(String message) {
        if (dspView != null) {
            dspView.setBleStatus("UI พร้อมใช้งาน • Bluetooth ยังไม่พร้อม", "OKN-DSP_7CH", false);
            dspView.setDiagnostic(message);
        }
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private void enterImmersiveSafely() {
        try {
            Window window = getWindow();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                window.setDecorFitsSystemWindows(false);
                WindowInsetsController controller = window.getInsetsController();
                if (controller != null) {
                    controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                    controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                }
            } else {
                window.getDecorView().setSystemUiVisibility(
                        android.view.View.SYSTEM_UI_FLAG_FULLSCREEN |
                                android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                                android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                                android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                                android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                                android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            }
        } catch (RuntimeException ignored) {
            // Fullscreen failure must never prevent the DSP UI from opening.
        }
    }
}
