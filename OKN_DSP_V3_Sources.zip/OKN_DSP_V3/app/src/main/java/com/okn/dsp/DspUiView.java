package com.okn.dsp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class DspUiView extends View {
    private static final int HOME = 0, MIX = 1, EQ = 2, CROSS = 3;
    private static final int HIT_BUTTON = 1, HIT_SLIDER = 2, HIT_KNOB = 3,
            HIT_EQ_GRAPH = 4, HIT_EQ_POINT = 5;

    private static final int NAV_BASE = 100;
    private static final int BTN_GEAR = 120, BTN_STATUS = 121;
    private static final int SRC_BASE = 140;
    private static final int QUICK_LOAD = 150, QUICK_SAVE = 151, QUICK_DEVICE = 152, QUICK_ABOUT = 153;
    private static final int MIX_MASTER = 200, MIX_BASS = 201, MIX_CUTOFF = 202,
            MIX_BASS_BOOST = 203, MIX_MID_BOOST = 204, MIX_TREBLE_BOOST = 205;
    private static final int EQ_CHANNEL_BASE = 300, EQ_SAVE = 310, EQ_LOAD = 311,
            EQ_PREV_BAND = 312, EQ_NEXT_BAND = 313, EQ_MORE = 314,
            EQ_FREQ = 320, EQ_GAIN = 321, EQ_Q = 322, EQ_OUTPUT = 323;
    private static final int CROSS_VIEW_MAG = 400, CROSS_VIEW_PHASE = 401,
            CROSS_PRESET = 402, CROSS_LINK = 403, CROSS_MODE_BASE = 410,
            CROSS_SLOPE_BASE = 420, CROSS_LOW_BASE = 430, CROSS_HIGH_BASE = 440,
            CROSS_DELAY_BASE = 450, CROSS_UNIT_BASE = 460, CROSS_RESET = 470,
            CROSS_AUTO = 471, CROSS_FILTER_BASE = 480;
    private static final int OVERLAY_CLOSE = 900;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<Hit> hits = new ArrayList<>();
    private Hit activeHit;

    private int page = HOME;
    private boolean connected = true;
    private boolean settingsOverlay = false;
    private int inputSource = 0;

    private float masterVolume = -6f;
    private float bassVolume = 0f;
    private float bassCutoff = 80f;
    private float bassBoost = 4f;
    private float middleBoost = 2f;
    private float trebleBoost = 3f;

    private int eqChannel = 0;
    private int selectedBand = 5;
    private float outputLevel = 0f;
    private final float[][] eqGain = new float[7][15];
    private final float[][] eqFreq = new float[7][15];
    private final float[][] eqQ = new float[7][15];
    private float[][] savedGain = null;
    private float[][] savedFreq = null;
    private float[][] savedQ = null;
    private float savedOutput = 0f;
    private RectF eqGraphRect = new RectF();

    private boolean crossMagnitude = true;
    private boolean linkLR = true;
    private final int[] crossMode = {0, 1, 2, 3};
    private final int[] crossSlope = {1, 1, 1, 0};
    private final int[] crossFilter = {0, 1, 0, 2};
    private final float[] crossLow = {20f, 80f, 3000f, 20f};
    private final float[] crossHigh = {80f, 3000f, 20000f, 20000f};
    private final float[] delayMs = {2.50f, 1.20f, 0.00f, 0.80f};
    private int delayUnit = 0;

    private float logicalW = 430f, logicalH = 930f, canvasScale = 1f;
    // V3 keeps the uploaded 430-wide reference proportions while distributing
    // vertical space responsively on tall phones/tablets instead of leaving a blank zone.

    private final int BG_TOP = Color.rgb(2, 20, 43);
    private final int BG_BOTTOM = Color.rgb(1, 10, 24);
    private final int PANEL = Color.rgb(5, 35, 64);
    private final int PANEL2 = Color.rgb(5, 43, 77);
    private final int LINE = Color.rgb(18, 74, 116);
    private final int WHITE = Color.rgb(235, 245, 255);
    private final int MUTED = Color.rgb(145, 173, 202);
    private final int BLUE = Color.rgb(0, 160, 255);
    private final int CYAN = Color.rgb(0, 220, 245);
    private final int GREEN = Color.rgb(0, 230, 166);
    private final int PURPLE = Color.rgb(184, 64, 255);
    private final int ORANGE = Color.rgb(255, 170, 50);

    private static class Hit {
        RectF rect;
        int kind, code, index, index2;
        float min, max;
        Hit(RectF rect, int kind, int code, int index, int index2, float min, float max) {
            this.rect = new RectF(rect);
            this.kind = kind;
            this.code = code;
            this.index = index;
            this.index2 = index2;
            this.min = min;
            this.max = max;
        }
    }

    public DspUiView(Context context) {
        super(context);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        text.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        stroke.setStyle(Paint.Style.STROKE);
        initEq();
        setFocusable(true);
    }

    private void initEq() {
        float[] baseF = {20, 40, 80, 160, 315, 630, 1000, 1250, 2500, 4000, 5000, 8000, 10000, 12500, 20000};
        float[] shape = {-2, 1, 4, 2.8f, 1.4f, 2.0f, 4.0f, 1.0f, -1.0f, 2.5f, 4.6f, 3.6f, 1.4f, 0.5f, -2.0f};
        for (int ch = 0; ch < 7; ch++) {
            for (int b = 0; b < 15; b++) {
                eqFreq[ch][b] = baseF[b];
                eqGain[ch][b] = shape[b] - (ch * 0.15f);
                eqQ[ch][b] = 1.2f;
            }
        }
    }

    @Override
    private void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        // Width is the anchor because the supplied reference is 430 logical pixels wide.
        // Height remains responsive, so cards expand/reflow on tall screens without stretching text.
        canvasScale = w / 430f;
        if (canvasScale <= 0f) canvasScale = 1f;
        logicalW = 430f;
        logicalH = h / canvasScale;
        if (logicalH < 690f) {
            canvasScale = Math.min(w / 430f, h / 690f);
            logicalW = w / canvasScale;
            logicalH = h / canvasScale;
        }
        canvas.save();
        canvas.scale(canvasScale, canvasScale);
        hits.clear();
        drawBackground(canvas);
        drawHeader(canvas);
        float navH = clamp(logicalH * 0.082f, 70f, 82f);
        float navTop = logicalH - navH;
        float contentTop = 76f;
        float contentBottom = navTop - 7f;
        if (page == HOME) drawHome(canvas, contentTop, contentBottom);
        else if (page == MIX) drawMix(canvas, contentTop, contentBottom);
        else if (page == EQ) drawEq(canvas, contentTop, contentBottom);
        else drawCrossover(canvas, contentTop, contentBottom);
        drawBottomNav(canvas, navTop);
        if (settingsOverlay) drawSettingsOverlay(canvas);
        canvas.restore();
    }

    private void drawBackground(Canvas c) {
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0, 0, 0, logicalH,
                new int[]{Color.rgb(6, 31, 70), Color.rgb(2, 19, 43), Color.rgb(0, 8, 19)},
                new float[]{0f, .30f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, logicalW, logicalH, p);
        p.setShader(null);

        // Code-drawn mountain atmosphere (no bitmap/screenshot is used).
        Path far = new Path();
        far.moveTo(-20, 143); far.lineTo(25, 111); far.lineTo(60, 128); far.lineTo(104, 91);
        far.lineTo(141, 124); far.lineTo(181, 99); far.lineTo(224, 130); far.lineTo(267, 88);
        far.lineTo(305, 122); far.lineTo(346, 95); far.lineTo(392, 126); far.lineTo(455, 102);
        far.lineTo(455, 172); far.lineTo(-20, 172); far.close();
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0, 87, 0, 172, Color.argb(118, 9, 57, 105), Color.argb(225, 1, 23, 48), Shader.TileMode.CLAMP));
        c.drawPath(far, p); p.setShader(null);

        Path near = new Path();
        near.moveTo(-20, 160); near.lineTo(45, 126); near.lineTo(83, 145); near.lineTo(120, 112);
        near.lineTo(164, 151); near.lineTo(203, 121); near.lineTo(248, 157); near.lineTo(292, 117);
        near.lineTo(334, 151); near.lineTo(374, 127); near.lineTo(452, 163); near.lineTo(452, 184);
        near.lineTo(-20, 184); near.close();
        p.setShader(new LinearGradient(0, 110, 0, 184, Color.argb(168, 4, 46, 88), Color.argb(245, 0, 14, 31), Shader.TileMode.CLAMP));
        c.drawPath(near, p); p.setShader(null);

        // Fine neon mountain ridges like the visual language of the reference.
        for (int layer = 0; layer < 4; layer++) {
            Path ridge = new Path();
            float base = 118 + layer * 11;
            ridge.moveTo(-12, base + 28);
            for (int x = -12; x <= 450; x += 24) {
                float wave = (float)Math.sin((x + layer * 31) * .052f) * (8 + layer * 1.4f);
                float spike = (((x + 12) / 24 + layer) % 4 == 0) ? -16f : 0f;
                ridge.lineTo(x, base + wave + spike);
            }
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(layer == 0 ? 1.0f : .65f);
            p.setColor(Color.argb(70 - layer * 10, 0, 155, 255)); c.drawPath(ridge, p);
        }

        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0, 0, logicalW, 0,
                new int[]{Color.TRANSPARENT, Color.argb(82, 0, 162, 255), Color.TRANSPARENT}, null, Shader.TileMode.CLAMP));
        c.drawRect(0, 171, logicalW, 172, p); p.setShader(null);
    }

    private void drawHeader(Canvas c) {
        float x = 20f;
        text.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        text.setTextSize(30f);
        text.setColor(WHITE);
        c.drawText("OKN_", x, 38f, text);
        float m = text.measureText("OKN_");
        text.setColor(BLUE);
        p.setShadowLayer(8, 0, 0, Color.argb(150, 0, 140, 255));
        c.drawText("DSP", x + m, 38f, text);
        p.clearShadowLayer();

        text.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        text.setTextSize(9f);
        text.setLetterSpacing(.25f);
        text.setColor(Color.rgb(170, 194, 224));
        c.drawText("SOUND IN HIGHER DEFINITION", x + 2, 57f, text);
        text.setLetterSpacing(0f);

        RectF status = new RectF(logicalW - 126, 25, logicalW - 24, 55);
        panel(c, status, 16, Color.argb(184, 1, 25, 45), Color.rgb(0, 95, 142), 1f);
        p.setStyle(Paint.Style.FILL);
        p.setShadowLayer(7, 0, 0, connected ? GREEN : Color.rgb(255, 85, 85));
        p.setColor(connected ? GREEN : Color.rgb(255, 85, 85));
        c.drawCircle(status.left + 17, status.centerY(), 5.5f, p);
        p.clearShadowLayer();
        label(c, connected ? "Connected" : "Offline", status.left + 30, status.centerY() + 4,
                10.5f, connected ? GREEN : Color.rgb(255, 110, 110), false);
        addHit(status, HIT_BUTTON, BTN_STATUS, 0, 0, 0, 0);

        RectF gear = new RectF(logicalW - 31, 6, logicalW - 7, 30);
        drawGear(c, gear.centerX(), gear.centerY(), 8.5f, WHITE);
        addHit(new RectF(logicalW - 46, 0, logicalW, 42), HIT_BUTTON, BTN_GEAR, 0, 0, 0, 0);
    }

    private void drawHome(Canvas c, float top, float bottom) {
        float pad = 16f;
        float gap = clamp((bottom - top) * .010f, 7f, 10f);
        float available = bottom - top;
        float heroH = clamp(available * .085f, 48f, 72f);
        float remaining = Math.max(420f, available - heroH - gap * 4f);
        float deviceH = remaining * .496f;
        float inputH = remaining * .165f;
        float quickH = remaining * .272f;
        float bannerH = Math.max(34f, remaining - deviceH - inputH - quickH);

        // Reference-style handwritten hero copy, positioned over code-drawn mountains.
        float heroY = top + 8f;
        text.setTypeface(Typeface.create("sans-serif", Typeface.ITALIC));
        text.setTextSize(12.5f); text.setColor(Color.rgb(225, 238, 255));
        c.drawText("Hear", logicalW - 112, heroY + 9, text);
        c.drawText("More", logicalW - 95, heroY + 24, text);
        c.drawText("Feel More", logicalW - 111, heroY + 40, text);

        float y = top + heroH;
        RectF device = new RectF(pad, y, logicalW - pad, y + deviceH);
        panel(c, device, 12, Color.argb(226, 3, 43, 78), Color.rgb(0, 91, 153), 1.2f);
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(device.left, device.top, device.right, device.bottom,
                new int[]{Color.argb(55, 0, 153, 255), Color.TRANSPARENT, Color.argb(35, 0, 92, 180)},
                null, Shader.TileMode.CLAMP));
        c.drawRoundRect(device, 12, 12, p); p.setShader(null);
        label(c, "DSP DEVICE", device.left + 12, device.top + 18, 8.5f, MUTED, false);
        label(c, "OKN DSP-8 Pro", device.left + 12, device.top + 45, 21, WHITE, true);
        label(c, "8-Channel Digital Signal Processor", device.left + 12, device.top + 63, 9.5f, MUTED, false);

        RectF unit = new RectF(device.left + 12, device.top + 76, device.left + device.width() * .58f, device.bottom - 14);
        drawDspChassis(c, unit);
        float ix = device.left + device.width() * .60f;
        float rowY = device.top + 76;
        float rowStep = Math.max(35f, (device.bottom - rowY - 9) / 5f);
        drawInfoRow(c, ix, rowY, GREEN, "Connected", "Ready for audio control", "BT");
        drawInfoRow(c, ix, rowY + rowStep, GREEN, "Excellent", "Signal Strength", "|||");
        drawInfoRow(c, ix, rowY + rowStep * 2, GREEN, "100%", "Battery", "BAT");
        drawInfoRow(c, ix, rowY + rowStep * 3, GREEN, "v1.2.3", "Firmware", "DSP");
        drawInfoRow(c, ix, rowY + rowStep * 4, CYAN, "OKN-8P-0047", "Device ID", "i");
        y = device.bottom + gap;

        RectF input = new RectF(pad, y, logicalW - pad, y + inputH);
        panel(c, input, 11, Color.argb(222, 3, 34, 62), LINE, 1f);
        label(c, "INPUT SOURCE", input.left + 12, input.top + 17, 8.5f, MUTED, false);
        String[] sources = {"Bluetooth", "AUX", "Optical", "USB"};
        String[] icons = {"B", "AUX", "□", "USB"};
        float inner = input.width() - 16;
        float bw = inner / 4f;
        for (int i = 0; i < 4; i++) {
            RectF r = new RectF(input.left + 8 + i * bw, input.top + 27,
                    input.left + 8 + (i + 1) * bw - 6, input.bottom - 8);
            boolean on = i == inputSource;
            int accent = on ? BLUE : Color.rgb(19, 74, 116);
            panel(c, r, 7, on ? Color.argb(235, 3, 61, 108) : Color.argb(192, 6, 39, 67), accent, on ? 1.5f : 1f);
            if (on) { p.setShadowLayer(10,0,0,Color.argb(170,0,145,255)); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.3f); p.setColor(BLUE); c.drawRoundRect(r,7,7,p); p.clearShadowLayer(); }
            labelCenter(c, icons[i], r.centerX(), r.top + Math.min(25f, r.height()*.38f), i == 0 ? 13f : 8.5f, on ? WHITE : Color.rgb(190, 210, 235), i == 0);
            labelCenter(c, sources[i], r.centerX(), r.bottom - 9, 7.7f, on ? WHITE : MUTED, false);
            addHit(r, HIT_BUTTON, SRC_BASE + i, i, 0, 0, 0);
        }
        y = input.bottom + gap;

        RectF quick = new RectF(pad, y, logicalW - pad, y + quickH);
        panel(c, quick, 11, Color.argb(218, 3, 34, 62), LINE, 1f);
        label(c, "QUICK ACTIONS", quick.left + 12, quick.top + 17, 8.5f, MUTED, false);
        float qw = (quick.width() - 26) / 2f;
        float qh = (quick.height() - 34) / 2f;
        quickButton(c, new RectF(quick.left + 8, quick.top + 26, quick.left + 8 + qw, quick.top + 26 + qh - 4), PURPLE, "Load Preset", "Recall saved setup", QUICK_LOAD);
        quickButton(c, new RectF(quick.left + 14 + qw, quick.top + 26, quick.right - 8, quick.top + 26 + qh - 4), BLUE, "Save Preset", "Save current setup", QUICK_SAVE);
        quickButton(c, new RectF(quick.left + 8, quick.top + 26 + qh + 2, quick.left + 8 + qw, quick.bottom - 8), GREEN, "Device Settings", "Advanced options", QUICK_DEVICE);
        quickButton(c, new RectF(quick.left + 14 + qw, quick.top + 26 + qh + 2, quick.right - 8, quick.bottom - 8), ORANGE, "About Device", "Info & support", QUICK_ABOUT);
        y = quick.bottom + gap;

        RectF banner = new RectF(pad, y, logicalW - pad, Math.min(bottom, y + bannerH));
        panel(c, banner, 10, Color.argb(214, 4, 41, 76), Color.rgb(0, 92, 162), 1f);
        drawWave(c, banner.left + 10, banner.centerY(), banner.width() - 20, Math.min(15f, banner.height() * .30f), BLUE);
        labelCenter(c, "Premium Sound Experience", banner.centerX(), banner.centerY() - 1, 8.5f, WHITE, true);
        labelCenter(c, "Precision Audio. In Your Hands.", banner.centerX(), banner.centerY() + 10, 6.7f, MUTED, false);
    }

    private void drawMix(Canvas c, float top, float bottom) {
        float pad = 16f;
        label(c, "Mix", pad, top + 25, 24, WHITE, true);
        label(c, "Real-time mixing and tone control", pad, top + 44, 10, MUTED, false);
        drawMiniWave(c, logicalW - 120, top + 5, 95, 28);
        labelCenter(c, "LIVE AUDIO CONTROL", logicalW - 72, top + 44, 6.2f, MUTED, false);

        float y = top + 55f;
        float rem = bottom - y;
        float sliderH = clamp(rem * .145f, 92f, 108f);
        float cellH = clamp((rem - sliderH * 2f - 26f) / 2f, 150f, 220f);
        float gap = clamp((rem - sliderH * 2f - cellH * 2f) / 3f, 8f, 20f);
        drawHorizontalControl(c, new RectF(pad, y, logicalW - pad, y + sliderH), PURPLE,
                "Master Volume", "Control overall output level", masterVolume, -60, 0, "dB", MIX_MASTER);
        y += sliderH + gap;
        drawHorizontalControl(c, new RectF(pad, y, logicalW - pad, y + sliderH), CYAN,
                "Bass Volume", "Adjust bass channel level", bassVolume, -20, 20, "dB", MIX_BASS);
        y += sliderH + gap;
        float cellW = (logicalW - pad * 2 - gap) / 2f;
        drawKnobControl(c, new RectF(pad, y, pad + cellW, y + cellH), GREEN,
                "Bass Cutoff", "Low-pass filter cutoff", bassCutoff, 20, 300, "Hz", MIX_CUTOFF);
        drawKnobControl(c, new RectF(pad + cellW + gap, y, logicalW - pad, y + cellH), PURPLE,
                "Bass Boost", "Boost low frequencies", bassBoost, -12, 12, "dB", MIX_BASS_BOOST);
        y += cellH + gap;
        drawKnobControl(c, new RectF(pad, y, pad + cellW, Math.min(bottom, y + cellH)), BLUE,
                "Middle Boost", "Boost mid frequencies", middleBoost, -12, 12, "dB", MIX_MID_BOOST);
        drawKnobControl(c, new RectF(pad + cellW + gap, y, logicalW - pad, Math.min(bottom, y + cellH)), ORANGE,
                "Treble Boost", "Boost high frequencies", trebleBoost, -12, 12, "dB", MIX_TREBLE_BOOST);
    }

    private void drawEq(Canvas c, float top, float bottom) {
        float pad = 16f, gap = 7f;
        label(c, "Eq", pad, top + 24, 24, WHITE, true);
        label(c, "SHAPE YOUR SOUND", pad, top + 42, 8.5f, MUTED, false);
        smallButton(c, new RectF(logicalW - 233, top + 3, logicalW - 145, top + 34), GREEN, "↓  Save Preset", EQ_SAVE);
        smallButton(c, new RectF(logicalW - 139, top + 3, logicalW - 48, top + 34), PURPLE, "▣  Load Preset", EQ_LOAD);
        RectF more = new RectF(logicalW - 42, top + 3, logicalW - 16, top + 34);
        panel(c, more, 7, Color.argb(205, 5, 38, 66), LINE, 1f);
        labelCenter(c, "⋮", more.centerX(), more.centerY() + 4, 16, MUTED, true);
        addHit(more, HIT_BUTTON, EQ_MORE, 0, 0, 0, 0);

        float chipsY = top + 50;
        String[] ch = {"Ch 1\nFL", "Ch 2\nFR", "Ch 3\nC", "Ch 4\nRL", "Ch 5\nRR", "Ch 6\nSUB", "Ch 7\nAUX"};
        float cw = (logicalW - pad * 2 - 6 * 5) / 7f;
        for (int i = 0; i < 7; i++) {
            RectF r = new RectF(pad + i * (cw + 5), chipsY, pad + i * (cw + 5) + cw, chipsY + 46);
            boolean on = i == eqChannel;
            panel(c, r, 6, on ? Color.argb(235, 2, 67, 118) : Color.argb(188, 5, 35, 64), on ? BLUE : LINE, on ? 1.6f : 1f);
            if (on) { p.setShadowLayer(8,0,0,Color.argb(130,0,150,255)); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.2f); p.setColor(BLUE); c.drawRoundRect(r,6,6,p); p.clearShadowLayer(); }
            String[] parts = ch[i].split("\\n");
            labelCenter(c, parts[0], r.centerX(), r.top + 17, 7.6f, on ? WHITE : MUTED, false);
            labelCenter(c, parts[1], r.centerX(), r.top + 34, 10, on ? WHITE : Color.rgb(185, 205, 232), true);
            addHit(r, HIT_BUTTON, EQ_CHANNEL_BASE + i, i, 0, 0, 0);
        }

        float y = chipsY + 54;
        float eqAvail = bottom - y;
        float graphH = clamp(eqAvail * .43f, 205f, 270f);
        RectF graphPanel = new RectF(pad, y, logicalW - pad, y + graphH);
        panel(c, graphPanel, 10, Color.argb(219, 3, 35, 62), LINE, 1f);
        label(c, "15 Band Equalizer", graphPanel.left + 10, graphPanel.top + 20, 13, WHITE, true);
        RectF gr = new RectF(graphPanel.left + 31, graphPanel.top + 34, graphPanel.right - 10, graphPanel.bottom - 29);
        drawEqGraph(c, gr);
        eqGraphRect.set(gr);
        addHit(gr, HIT_EQ_GRAPH, 0, 0, 0, 0, 0);

        y = graphPanel.bottom + gap;
        float controlsH = clamp(eqAvail * .30f, 157f, 190f);
        RectF controls = new RectF(pad, y, logicalW - pad, y + controlsH);
        panel(c, controls, 10, Color.argb(214, 4, 41, 72), LINE, 1f);
        label(c, "Band Controls", controls.left + 10, controls.top + 20, 13, WHITE, true);
        label(c, "Band " + (selectedBand + 1) + " of 15", controls.right - 100, controls.top + 20, 8, MUTED, false);
        RectF prev = new RectF(controls.right - 48, controls.top + 6, controls.right - 27, controls.top + 27);
        RectF next = new RectF(controls.right - 24, controls.top + 6, controls.right - 3, controls.top + 27);
        circleButton(c, prev, "‹", MUTED); circleButton(c, next, "›", MUTED);
        addHit(prev, HIT_BUTTON, EQ_PREV_BAND, 0, 0, 0, 0);
        addHit(next, HIT_BUTTON, EQ_NEXT_BAND, 0, 0, 0, 0);

        float colW = (controls.width() - 20) / 3f;
        drawBandSlider(c, new RectF(controls.left + 6, controls.top + 32, controls.left + 6 + colW, controls.bottom - 8), BLUE,
                "Frequency", formatHz(eqFreq[eqChannel][selectedBand]), eqFreq[eqChannel][selectedBand], 20, 20000, EQ_FREQ, true);
        drawBandSlider(c, new RectF(controls.left + 7 + colW, controls.top + 32, controls.left + 7 + colW * 2, controls.bottom - 8), GREEN,
                "Gain", signed(eqGain[eqChannel][selectedBand]) + " dB", eqGain[eqChannel][selectedBand], -12, 12, EQ_GAIN, false);
        drawBandSlider(c, new RectF(controls.left + 8 + colW * 2, controls.top + 32, controls.right - 6, controls.bottom - 8), PURPLE,
                "Q (Quality Factor)", String.format(Locale.US, "%.1f", eqQ[eqChannel][selectedBand]), eqQ[eqChannel][selectedBand], .1f, 10f, EQ_Q, false);

        y = controls.bottom + gap;
        float outH = clamp(bottom - y, 82f, 100f);
        if (y + outH <= bottom) {
            RectF out = new RectF(pad, y, logicalW - pad, y + outH);
            panel(c, out, 10, Color.argb(214, 4, 41, 72), LINE, 1f);
            drawSpeaker(c, out.left + 27, out.top + 26, CYAN);
            label(c, "Output Level - Ch " + (eqChannel + 1) + channelLabel(eqChannel), out.left + 49, out.top + 23, 9.5f, WHITE, true);
            RectF badge = new RectF(out.right - 63, out.top + 10, out.right - 10, out.top + 32);
            valueBadge(c, badge, CYAN, signed(outputLevel) + " dB");
            RectF sr = new RectF(out.left + 49, out.top + 39, out.right - 18, out.top + 58);
            drawSlider(c, sr, outputLevel, -60, 12, CYAN, false);
            addHit(new RectF(sr.left, sr.top - 9, sr.right, sr.bottom + 9), HIT_SLIDER, EQ_OUTPUT, 0, 0, -60, 12);
            label(c, "-60 dB", sr.left, out.bottom - 8, 7.2f, MUTED, false);
            label(c, "+12 dB", sr.right - 29, out.bottom - 8, 7.2f, MUTED, false);
        }
    }

    private void drawCrossover(Canvas c, float top, float bottom) {
        float pad = 16f, gap = 7f;
        label(c, "Crossover", pad, top + 24, 23, WHITE, true);
        label(c, "Configure crossover filters and time alignment for each channel.", pad, top + 42, 8.5f, MUTED, false);
        smallButton(c, new RectF(logicalW - 137, top + 3, logicalW - 16, top + 34), BLUE, "▢  Crossover Preset", CROSS_PRESET);

        float y = top + 51;
        float crossAvail = bottom - y;
        float graphH = clamp(crossAvail * .32f, 182f, 235f);
        RectF gp = new RectF(pad, y, logicalW - pad, y + graphH);
        panel(c, gp, 10, Color.argb(219, 3, 35, 62), LINE, 1f);
        label(c, "CROSSOVER RESPONSE", gp.left + 10, gp.top + 17, 8.2f, MUTED, false);
        label(c, "View", gp.right - 142, gp.top + 17, 7.4f, MUTED, false);
        toggleButton(c, new RectF(gp.right - 114, gp.top + 5, gp.right - 59, gp.top + 25), "Magnitude", crossMagnitude, CROSS_VIEW_MAG);
        toggleButton(c, new RectF(gp.right - 57, gp.top + 5, gp.right - 8, gp.top + 25), "Phase", !crossMagnitude, CROSS_VIEW_PHASE);
        RectF graph = new RectF(gp.left + 31, gp.top + 32, gp.right - 10, gp.bottom - 34);
        drawCrossoverGraph(c, graph);
        drawCrossLegend(c, gp.left + 34, gp.bottom - 17);

        y = gp.bottom + gap;
        float settingsH = clamp(crossAvail * .36f, 224f, 255f);
        RectF sp = new RectF(pad, y, logicalW - pad, y + settingsH);
        panel(c, sp, 10, Color.argb(214, 4, 41, 72), LINE, 1f);
        label(c, "CROSSOVER SETTINGS", sp.left + 10, sp.top + 17, 8.3f, MUTED, false);
        label(c, "Link L/R", sp.right - 105, sp.top + 17, 8, CYAN, false);
        RectF link = new RectF(sp.right - 42, sp.top + 6, sp.right - 9, sp.top + 22);
        drawSwitch(c, link, linkLR);
        addHit(new RectF(link.left - 8, link.top - 6, link.right + 8, link.bottom + 6), HIT_BUTTON, CROSS_LINK, 0, 0, 0, 0);

        String[] names = {"SUB", "MID", "HIGH", "FULL"};
        int[] accents = {PURPLE, BLUE, GREEN, ORANGE};
        float cgap = 5f;
        float colW = (sp.width() - 16 - cgap * 3) / 4f;
        float cy = sp.top + 29;
        for (int i = 0; i < 4; i++) {
            RectF cell = new RectF(sp.left + 8 + i * (colW + cgap), cy,
                    sp.left + 8 + i * (colW + cgap) + colW, sp.bottom - 7);
            panel(c, cell, 7, Color.argb(184, 4, 34, 59), Color.argb(175, Color.red(accents[i]), Color.green(accents[i]), Color.blue(accents[i])), 1f);
            p.setStyle(Paint.Style.FILL); p.setColor(accents[i]); p.setShadowLayer(6,0,0,accents[i]); c.drawCircle(cell.left + 9, cell.top + 11, 4, p); p.clearShadowLayer();
            label(c, names[i], cell.left + 17, cell.top + 14, 8.2f, accents[i], true);

            RectF modeR = new RectF(cell.left + 5, cell.top + 23, cell.right - 5, cell.top + 43);
            miniSelect(c, modeR, modeName(crossMode[i]), CROSS_MODE_BASE + i, i);
            RectF filterR = new RectF(cell.left + 5, cell.top + 46, cell.right - 5, cell.top + 66);
            miniSelect(c, filterR, filterName(crossFilter[i]), CROSS_FILTER_BASE + i, i);

            float sliderTop = cell.top + 71;
            if (i == 1) {
                labelCenter(c, compactHz(crossLow[i]) + " - " + compactHz(crossHigh[i]), cell.centerX(), sliderTop + 8, 7.8f, WHITE, true);
                RectF r1 = new RectF(cell.left + 7, sliderTop + 16, cell.right - 7, sliderTop + 30);
                drawLogSlider(c, r1, crossLow[i], 20, 20000, accents[i]);
                addHit(new RectF(r1.left, r1.top - 7, r1.right, r1.bottom + 7), HIT_SLIDER, CROSS_LOW_BASE + i, i, 0, 20, 20000);
                RectF r2 = new RectF(cell.left + 7, sliderTop + 32, cell.right - 7, sliderTop + 46);
                drawLogSlider(c, r2, crossHigh[i], 20, 20000, accents[i]);
                addHit(new RectF(r2.left, r2.top - 7, r2.right, r2.bottom + 7), HIT_SLIDER, CROSS_HIGH_BASE + i, i, 0, 20, 20000);
            } else {
                float value = i == 0 ? crossHigh[i] : i == 2 ? crossLow[i] : crossHigh[i];
                labelCenter(c, compactHz(value), cell.centerX(), sliderTop + 8, 8.2f, WHITE, true);
                RectF r = new RectF(cell.left + 7, sliderTop + 18, cell.right - 7, sliderTop + 33);
                int code = i == 0 ? CROSS_HIGH_BASE + i : i == 2 ? CROSS_LOW_BASE + i : CROSS_HIGH_BASE + i;
                drawLogSlider(c, r, value, 20, 20000, accents[i]);
                addHit(new RectF(r.left, r.top - 7, r.right, r.bottom + 7), HIT_SLIDER, code, i, 0, 20, 20000);
                label(c, "20 Hz", cell.left + 5, sliderTop + 46, 5.8f, MUTED, false);
                label(c, "20 kHz", cell.right - 27, sliderTop + 46, 5.8f, MUTED, false);
            }

            label(c, "Slope", cell.left + 5, cell.bottom - 41, 6.8f, MUTED, false);
            String[] slopes = {"12 dB", "24 dB", "36 dB"};
            float sw = (cell.width() - 14) / 3f;
            for (int sl = 0; sl < 3; sl++) {
                RectF br = new RectF(cell.left + 5 + sl * (sw + 2), cell.bottom - 31,
                        cell.left + 5 + sl * (sw + 2) + sw, cell.bottom - 7);
                boolean on = crossSlope[i] == sl;
                panel(c, br, 4, on ? Color.argb(220, 0, 74, 130) : Color.argb(170, 4, 31, 52), on ? accents[i] : LINE, 1f);
                labelCenter(c, slopes[sl], br.centerX(), br.centerY() + 2.5f, 5.8f, on ? WHITE : MUTED, false);
                addHit(br, HIT_BUTTON, CROSS_SLOPE_BASE + i, i, sl, 0, 0);
            }
        }

        y = sp.bottom + gap;
        float delayH = clamp(bottom - y, 138f, 185f);
        RectF dp = new RectF(pad, y, logicalW - pad, y + delayH);
        panel(c, dp, 10, Color.argb(214, 4, 41, 72), LINE, 1f);
        label(c, "CHANNEL DELAY / TIME ALIGNMENT", dp.left + 10, dp.top + 17, 8.3f, MUTED, false);
        String[] units = {"ms", "cm", "in"};
        for (int i = 0; i < 3; i++) {
            RectF ur = new RectF(dp.right - 111 + i * 34, dp.top + 4, dp.right - 80 + i * 34, dp.top + 23);
            toggleButton(c, ur, units[i], delayUnit == i, CROSS_UNIT_BASE + i);
        }
        float dw = (dp.width() - 16 - cgap * 3) / 4f;
        String[] dn = {"SUB", "MID", "HIGH", "FULL"};
        int[] da = {PURPLE, BLUE, GREEN, ORANGE};
        float cardBottom = dp.bottom - 34;
        for (int i = 0; i < 4; i++) {
            RectF cell = new RectF(dp.left + 8 + i * (dw + cgap), dp.top + 28,
                    dp.left + 8 + i * (dw + cgap) + dw, cardBottom);
            panel(c, cell, 6, Color.argb(175, 4, 34, 59), Color.argb(150, Color.red(da[i]), Color.green(da[i]), Color.blue(da[i])), 1f);
            p.setColor(da[i]); p.setStyle(Paint.Style.FILL); c.drawCircle(cell.left + 8, cell.top + 10, 3.5f, p);
            label(c, dn[i], cell.left + 15, cell.top + 13, 7.3f, da[i], true);
            labelCenter(c, formatDelay(delayMs[i]), cell.centerX(), cell.top + 31, 8.5f, WHITE, true);
            RectF r = new RectF(cell.left + 7, cell.top + 37, cell.right - 7, cell.top + 51);
            drawSlider(c, r, delayMs[i], 0, 20, da[i], false);
            addHit(new RectF(r.left, r.top - 7, r.right, r.bottom + 7), HIT_SLIDER, CROSS_DELAY_BASE + i, i, 0, 0, 20);
            label(c, "0.00", cell.left + 4, cell.top + 61, 5.8f, MUTED, false);
            label(c, "20.00", cell.right - 23, cell.top + 61, 5.8f, MUTED, false);
            labelCenter(c, distanceText(delayMs[i]), cell.centerX(), cell.bottom - 6, 6.6f, MUTED, false);
        }
        smallButton(c, new RectF(dp.left + 8, dp.bottom - 29, dp.left + 112, dp.bottom - 5), MUTED, "↻  Reset Delays", CROSS_RESET);
        smallButton(c, new RectF(dp.right - 112, dp.bottom - 29, dp.right - 8, dp.bottom - 5), BLUE, "✣  Auto Align", CROSS_AUTO);
    }

    private void drawBottomNav(Canvas c, float top) {
        RectF bar = new RectF(0, top, logicalW, logicalH + 2);
        p.setShader(new LinearGradient(0, top, 0, logicalH,
                Color.argb(248, 4, 30, 56), Color.argb(252, 1, 15, 31), Shader.TileMode.CLAMP));
        p.setStyle(Paint.Style.FILL); c.drawRoundRect(bar, 24, 24, p); p.setShader(null);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1); p.setColor(Color.rgb(12, 76, 122)); c.drawRoundRect(bar, 24, 24, p);

        String[] names = {"Home", "Mix", "Eq", "Crossover"};
        float tabW = logicalW / 4f;
        for (int i = 0; i < 4; i++) {
            float cx = tabW * i + tabW / 2f;
            boolean on = page == i;
            int icon = on ? Color.rgb(35, 185, 255) : Color.rgb(145, 179, 225);
            if (on) {
                p.setStyle(Paint.Style.FILL); p.setColor(Color.argb(22, 0, 160, 255));
                c.drawCircle(cx, top + 25, 28, p);
            }
            drawNavIcon(c, i, cx, top + 23, icon);
            labelCenter(c, names[i], cx, top + 50, 9.5f, on ? WHITE : Color.rgb(160, 184, 216), false);
            if (on) {
                p.setStyle(Paint.Style.FILL); p.setColor(BLUE); p.setShadowLayer(8,0,0,BLUE);
                c.drawRoundRect(new RectF(cx - 29, top + 62, cx + 29, top + 64), 2, 2, p); p.clearShadowLayer();
            }
            addHit(new RectF(tabW * i, top, tabW * (i + 1), logicalH), HIT_BUTTON, NAV_BASE + i, i, 0, 0, 0);
        }
    }

    private void drawSettingsOverlay(Canvas c) {
        p.setColor(Color.argb(194, 0, 7, 16)); p.setStyle(Paint.Style.FILL); c.drawRect(0, 0, logicalW, logicalH, p);
        float w = Math.min(350, logicalW - 40);
        RectF box = new RectF((logicalW - w) / 2f, logicalH * .28f, (logicalW + w) / 2f, logicalH * .64f);
        panel(c, box, 16, Color.rgb(5, 35, 64), BLUE, 1.3f);
        label(c, "OKN_DSP · Version 3", box.left + 18, box.top + 34, 19, WHITE, true);
        label(c, "Phase 1 · Reference-match UI", box.left + 18, box.top + 62, 11, CYAN, false);
        label(c, "• Responsive 430-wide layout matched to the supplied reference", box.left + 18, box.top + 92, 9.4f, MUTED, false);
        label(c, "• Cards now fill tall screens instead of leaving blank space", box.left + 18, box.top + 115, 9.4f, MUTED, false);
        label(c, "• EQ / crossover graphs and controls redraw in real time", box.left + 18, box.top + 138, 9.4f, MUTED, false);
        label(c, "• Stable V3 development signing key enables future in-place updates", box.left + 18, box.top + 161, 9.4f, MUTED, false);
        RectF close = new RectF(box.left + 18, box.bottom - 52, box.right - 18, box.bottom - 16);
        panel(c, close, 9, Color.rgb(3, 70, 116), BLUE, 1f);
        labelCenter(c, "Close", close.centerX(), close.centerY() + 4, 11, WHITE, true);
        addHit(close, HIT_BUTTON, OVERLAY_CLOSE, 0, 0, 0, 0);
    }

    // ---------- UI components ----------

    private void drawDspChassis(Canvas c, RectF r) {
        // Card-sized vector product illustration. No bitmap is embedded.
        p.setStyle(Paint.Style.FILL); p.setColor(Color.argb(185, 0, 6, 14)); c.drawRoundRect(r, 8, 8, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1); p.setColor(Color.rgb(20, 57, 86)); c.drawRoundRect(r, 8, 8, p);

        float l = r.left + 12, t = r.top + 27, rr = r.right - 9, b = r.bottom - 20;
        Path top = new Path();
        top.moveTo(l + 15, t); top.lineTo(rr - 25, t - 10); top.lineTo(rr, t + 5); top.lineTo(l + 40, t + 17); top.close();
        p.setStyle(Paint.Style.FILL); p.setShader(new LinearGradient(l,t,rr,b,Color.rgb(37,43,53),Color.rgb(10,15,22),Shader.TileMode.CLAMP)); c.drawPath(top,p); p.setShader(null);
        Path front = new Path();
        front.moveTo(l + 40, t + 17); front.lineTo(rr, t + 5); front.lineTo(rr, b - 10); front.lineTo(l + 40, b); front.close();
        p.setColor(Color.rgb(10,15,22)); c.drawPath(front,p);
        Path side = new Path();
        side.moveTo(l + 15,t); side.lineTo(l+40,t+17); side.lineTo(l+40,b); side.lineTo(l+15,b-13); side.close();
        p.setColor(Color.rgb(7,11,17)); c.drawPath(side,p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1); p.setColor(Color.rgb(56,66,80)); c.drawPath(top,p); c.drawPath(front,p); c.drawPath(side,p);

        float lineY = t + 40;
        p.setStyle(Paint.Style.FILL); p.setColor(BLUE); p.setShadowLayer(12,0,0,BLUE);
        c.drawRoundRect(new RectF(l + 72, lineY, rr - 22, lineY + 3), 2, 2, p); p.clearShadowLayer();
        label(c, "OKN_DSP", l + 57, t + 23, 8.8f, Color.rgb(190, 201, 214), true);
        label(c, "DSP-8 PRO", rr - 47, b - 16, 5.8f, Color.rgb(160, 181, 207), false);
    }

    private void valueBadge(Canvas c, RectF r, int accent, String title) {
        panel(c, r, 6, Color.argb(188, 5, 35, 62), Color.argb(210, Color.red(accent), Color.green(accent), Color.blue(accent)), 1f);
        labelCenter(c, title, r.centerX(), r.centerY() + 3.5f, 8.3f, accent, false);
    }

    private String channelLabel(int ch) {
        String[] n = {" (Front Left)", " (Front Right)", " (Center)", " (Rear Left)", " (Rear Right)", " (Sub)", " (Aux)"};
        return n[Math.max(0, Math.min(n.length - 1, ch))];
    }

    private String filterName(int f) {
        switch (f) { case 0: return "Butterworth"; case 1: return "Linkwitz-Riley"; default: return "Bessel"; }
    }

    private String compactHz(float f) {
        if (f >= 1000) return String.format(Locale.US, f >= 10000 ? "%.0fk" : "%.1fk", f / 1000f);
        return String.format(Locale.US, "%.0f Hz", f);
    }

    private void drawHorizontalControl(Canvas c, RectF r, int accent, String title, String subtitle,
                                       float value, float min, float max, String unit, int code) {
        panel(c, r, 11, Color.argb(220, 4, 41, 72), Color.rgb(13, 78, 121), 1f);
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.argb(96, Color.red(accent), Color.green(accent), Color.blue(accent)));
        p.setShadowLayer(8, 0, 0, Color.argb(120, Color.red(accent), Color.green(accent), Color.blue(accent)));
        c.drawCircle(r.left + 31, r.top + 29, 18, p); p.clearShadowLayer();
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.3f); p.setColor(accent); c.drawCircle(r.left + 31, r.top + 29, 18, p);
        drawSpeaker(c, r.left + 31, r.top + 29, accent);
        label(c, title, r.left + 60, r.top + 27, 11.5f, WHITE, true);
        label(c, subtitle, r.left + 60, r.top + 44, 8.4f, MUTED, false);
        RectF val = new RectF(r.right - 73, r.top + 11, r.right - 10, r.top + 39);
        valueBadge(c, val, accent, signed(value) + " " + unit);
        RectF sr = new RectF(r.left + 16, r.bottom - 34, r.right - 16, r.bottom - 17);
        drawSlider(c, sr, value, min, max, accent, false);
        addHit(new RectF(sr.left, sr.top - 10, sr.right, sr.bottom + 10), HIT_SLIDER, code, 0, 0, min, max);
        label(c, fmt(min) + " " + unit, sr.left, r.bottom - 5, 7.1f, MUTED, false);
        String right = (max > 0 ? "+" : "") + fmt(max) + " " + unit;
        label(c, right, sr.right - textWidth(right, 7.1f), r.bottom - 5, 7.1f, MUTED, false);
    }

    private void drawKnobControl(Canvas c, RectF r, int accent, String title, String subtitle,
                                 float value, float min, float max, String unit, int code) {
        panel(c, r, 10, Color.argb(216, 4, 39, 69), Color.rgb(13, 72, 112), 1f);
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.argb(90, Color.red(accent), Color.green(accent), Color.blue(accent)));
        c.drawCircle(r.left + 23, r.top + 23, 17, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1); p.setColor(accent); c.drawCircle(r.left + 23, r.top + 23, 17, p);
        String glyph = code == MIX_CUTOFF ? "∿" : code == MIX_MID_BOOST ? "▥" : "▥";
        labelCenter(c, glyph, r.left + 23, r.top + 28, code == MIX_CUTOFF ? 16 : 11, accent, true);
        label(c, title, r.left + 47, r.top + 21, 9.8f, WHITE, true);
        label(c, subtitle, r.left + 47, r.top + 36, 7.2f, MUTED, false);
        String valText = code == MIX_CUTOFF ? formatHz(value) : signed(value) + " " + unit;
        RectF badge = new RectF(r.right - 62, r.top + 8, r.right - 8, r.top + 31);
        valueBadge(c, badge, accent, valText);

        float radius = Math.min(48f, Math.max(36f, Math.min(r.width(), r.height()) * .27f));
        float cx = r.centerX(), cy = r.top + Math.min(r.height() * .66f, r.height() - 44f);
        drawKnob(c, cx, cy, radius, value, min, max, accent);
        label(c, code == MIX_CUTOFF ? "20 Hz" : "-12 dB", r.left + 10, r.bottom - 9, 6.8f, MUTED, false);
        String hi = code == MIX_CUTOFF ? "300 Hz" : "+12 dB";
        label(c, hi, r.right - textWidth(hi, 6.8f) - 10, r.bottom - 9, 6.8f, MUTED, false);
        RectF hit = new RectF(cx - radius - 18, cy - radius - 18, cx + radius + 18, cy + radius + 18);
        addHit(hit, HIT_KNOB, code, 0, 0, min, max);
    }

    private void drawKnob(Canvas c, float cx, float cy, float rad, float value, float min, float max, int accent) {
        float t = clamp((value - min) / (max - min), 0, 1);
        RectF arc = new RectF(cx - rad, cy - rad, cx + rad, cy + rad);
        p.setStyle(Paint.Style.STROKE); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeWidth(6f); p.setColor(Color.rgb(18, 48, 75));
        c.drawArc(arc, 135, 270, false, p);
        p.setShadowLayer(8,0,0,accent); p.setColor(accent); c.drawArc(arc, 135, 270 * t, false, p); p.clearShadowLayer();

        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(cx, cy-rad, cx, cy+rad, Color.rgb(18,43,67), Color.rgb(4,18,34), Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, rad - 7, p); p.setShader(null);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.2f); p.setColor(Color.rgb(37, 82, 118)); c.drawCircle(cx, cy, rad - 7, p);
        double a = Math.toRadians(135 + 270 * t);
        float mx = cx + (float)Math.cos(a) * (rad - 10);
        float my = cy + (float)Math.sin(a) * (rad - 10);
        p.setStyle(Paint.Style.FILL); p.setColor(WHITE); p.setShadowLayer(7,0,0,WHITE); c.drawCircle(mx, my, 4.2f, p); p.clearShadowLayer();
        p.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawEqGraph(Canvas c, RectF gr) {
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(.65f); p.setColor(Color.rgb(16, 69, 105));
        for (int i = 0; i <= 10; i++) { float x = gr.left + gr.width() * i / 10f; c.drawLine(x, gr.top, x, gr.bottom, p); }
        for (int i = 0; i <= 8; i++) { float y = gr.top + gr.height() * i / 8f; c.drawLine(gr.left, y, gr.right, y, p); }
        float zero = mapLinear(0, -12, 12, gr.bottom, gr.top);
        p.setStrokeWidth(1.2f); p.setColor(Color.rgb(45, 94, 132)); c.drawLine(gr.left, zero, gr.right, zero, p);

        Path path = new Path();
        float[] xs = new float[15], ys = new float[15];
        for (int i = 0; i < 15; i++) {
            xs[i] = freqToX(eqFreq[eqChannel][i], gr);
            ys[i] = mapLinear(eqGain[eqChannel][i], -12, 12, gr.bottom, gr.top);
            if (i == 0) path.moveTo(xs[i], ys[i]); else path.lineTo(xs[i], ys[i]);
        }
        Path fill = new Path(path); fill.lineTo(xs[14], gr.bottom); fill.lineTo(xs[0], gr.bottom); fill.close();
        int[] fillCols = {Color.argb(50,0,120,255), Color.argb(45,0,220,255), Color.argb(45,0,235,160), Color.argb(42,220,230,40), Color.argb(44,255,150,50), Color.argb(44,185,60,255)};
        p.setStyle(Paint.Style.FILL); p.setShader(new LinearGradient(gr.left,0,gr.right,0,fillCols,null,Shader.TileMode.CLAMP)); c.drawPath(fill,p); p.setShader(null);

        int[] colors = {BLUE, Color.rgb(0, 210, 255), GREEN, Color.rgb(185, 230, 55), ORANGE, PURPLE};
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2.6f); p.setShader(new LinearGradient(gr.left,0,gr.right,0,colors,null,Shader.TileMode.CLAMP));
        p.setShadowLayer(6,0,0,Color.argb(105,0,170,255)); c.drawPath(path,p); p.clearShadowLayer(); p.setShader(null);

        for (int i = 0; i < 15; i++) {
            int col = bandColor(i);
            p.setStyle(Paint.Style.FILL); p.setColor(col); p.setShadowLayer(i == selectedBand ? 8 : 4,0,0,col); c.drawCircle(xs[i], ys[i], i == selectedBand ? 5.6f : 4.1f, p); p.clearShadowLayer();
            if (i == selectedBand) { p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.4f); p.setColor(WHITE); c.drawCircle(xs[i], ys[i], 8f, p); }
            addHit(new RectF(xs[i] - 12, ys[i] - 12, xs[i] + 12, ys[i] + 12), HIT_EQ_POINT, 0, i, 0, 0, 0);
        }
        String[] labels = {"20", "40", "80", "160", "315", "630", "1.25k", "2.5k", "5k", "10k", "20k"};
        float[] freqs = {20,40,80,160,315,630,1250,2500,5000,10000,20000};
        for (int i = 0; i < labels.length; i++) labelCenter(c, labels[i], freqToX(freqs[i], gr), gr.bottom + 13, 6.4f, MUTED, false);
        label(c, "+12", gr.left - 26, gr.top + 4, 6.3f, MUTED, false);
        label(c, "+6", gr.left - 22, mapLinear(6,-12,12,gr.bottom,gr.top)+3, 6.3f, MUTED, false);
        label(c, "0", gr.left - 13, zero + 3, 6.3f, MUTED, false);
        label(c, "-6", gr.left - 21, mapLinear(-6,-12,12,gr.bottom,gr.top)+3, 6.3f, MUTED, false);
        label(c, "-12", gr.left - 24, gr.bottom, 6.3f, MUTED, false);
        labelCenter(c, "Frequency (Hz)", gr.centerX(), gr.bottom + 24, 6.6f, MUTED, false);
    }

    private void drawBandSlider(Canvas c, RectF r, int accent, String title, String valueText,
                                float value, float min, float max, int code, boolean log) {
        label(c, title, r.left + 3, r.top + 13, 8.2f, MUTED, false);
        label(c, valueText, r.left + 3, r.top + 32, 13, WHITE, true);
        RectF sr = new RectF(r.left + 4, r.top + 44, r.right - 7, r.top + 62);
        if (log) drawLogSlider(c, sr, value, min, max, accent); else drawSlider(c, sr, value, min, max, accent, false);
        addHit(new RectF(sr.left, sr.top - 9, sr.right, sr.bottom + 9), HIT_SLIDER, code, 0, 0, min, max);
        RectF minus = new RectF(r.left + 4, r.bottom - 28, r.left + 28, r.bottom - 4);
        RectF plus = new RectF(r.right - 31, r.bottom - 28, r.right - 7, r.bottom - 4);
        circleButton(c, minus, "−", MUTED); circleButton(c, plus, "+", MUTED);
        // Buttons use code offset; handled in button action.
        addHit(minus, HIT_BUTTON, code + 1000, -1, 0, min, max);
        addHit(plus, HIT_BUTTON, code + 1000, +1, 0, min, max);
        if (code == EQ_FREQ) labelCenter(c, "20 Hz – 20 kHz", r.centerX(), r.bottom - 9, 6.6f, MUTED, false);
        else if (code == EQ_GAIN) labelCenter(c, "-12 dB – +12 dB", r.centerX(), r.bottom - 9, 6.6f, MUTED, false);
        else labelCenter(c, "0.1 – 10.0", r.centerX(), r.bottom - 9, 6.6f, MUTED, false);
    }

    private void drawCrossoverGraph(Canvas c, RectF gr) {
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(.6f); p.setColor(Color.rgb(17, 66, 101));
        for (int i = 0; i <= 8; i++) { float x = gr.left + gr.width() * i / 8f; c.drawLine(x, gr.top, x, gr.bottom, p); }
        for (int i = 0; i <= 6; i++) { float y = gr.top + gr.height() * i / 6f; c.drawLine(gr.left, y, gr.right, y, p); }
        String[] labels = {"20", "50", "100", "500", "1k", "5k", "10k", "20k"};
        float[] fs = {20,50,100,500,1000,5000,10000,20000};
        for (int i = 0; i < fs.length; i++) labelCenter(c, labels[i], freqToX(fs[i], gr), gr.bottom + 13, 6.3f, MUTED, false);
        if (crossMagnitude) {
            drawResponse(c, gr, 0, PURPLE); drawResponse(c, gr, 1, BLUE); drawResponse(c, gr, 2, GREEN); drawResponse(c, gr, 3, ORANGE);
        } else {
            drawPhase(c, gr, 0, PURPLE, -110); drawPhase(c, gr, 1, BLUE, -35); drawPhase(c, gr, 2, GREEN, 42); drawPhase(c, gr, 3, ORANGE, 105);
        }
        label(c, "+12", gr.left - 28, gr.top + 4, 6.2f, MUTED, false);
        label(c, "0", gr.left - 14, gr.top + gr.height() * .30f + 3, 6.2f, MUTED, false);
        label(c, "-12", gr.left - 24, gr.top + gr.height() * .62f + 3, 6.2f, MUTED, false);
        label(c, "-24", gr.left - 25, gr.bottom - 2, 6.2f, MUTED, false);
        labelCenter(c, "Frequency (Hz)", gr.centerX(), gr.bottom + 25, 6.5f, MUTED, false);
    }

    private void drawResponse(Canvas c, RectF gr, int band, int color) {
        Path path = new Path();
        for (int i = 0; i <= 160; i++) {
            float x = gr.left + gr.width() * i / 160f;
            float f = xToFreq(x, gr);
            float db;
            if (band == 0) db = lowPassDb(f, crossHigh[0]);
            else if (band == 1) db = Math.min(highPassDb(f, crossLow[1]), lowPassDb(f, crossHigh[1]));
            else if (band == 2) db = highPassDb(f, crossLow[2]);
            else db = 0;
            float y = mapLinear(db, -30, 6, gr.bottom, gr.top);
            if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
        }
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2.2f); p.setColor(color); p.setShadowLayer(5,0,0,color); c.drawPath(path, p); p.clearShadowLayer();
    }

    private void drawPhase(Canvas c, RectF gr, int band, int color, float offset) {
        Path path = new Path();
        for (int i = 0; i <= 140; i++) {
            float x = gr.left + gr.width() * i / 140f;
            float phase = (float)Math.sin(i * 0.055 + band * 0.8) * 48f + offset * 0.15f;
            float y = mapLinear(phase, -90, 90, gr.bottom, gr.top);
            if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
        }
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2f); p.setColor(color); c.drawPath(path, p);
    }

    private void drawCrossLegend(Canvas c, float x, float y) {
        String[] n = {"SUB", "MID", "HIGH", "FULL"};
        int[] col = {PURPLE, BLUE, GREEN, ORANGE};
        for (int i = 0; i < 4; i++) {
            p.setStyle(Paint.Style.FILL); p.setColor(col[i]); c.drawCircle(x + i * 82, y - 2, 4, p);
            label(c, n[i], x + 9 + i * 82, y + 1, 7.2f, MUTED, false);
        }
    }

    private void drawInfoRow(Canvas c, float x, float y, int accent, String title, String sub, String icon) {
        p.setStyle(Paint.Style.FILL); p.setColor(Color.argb(70, Color.red(accent), Color.green(accent), Color.blue(accent))); c.drawCircle(x + 16, y + 12, 14.5f, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1); p.setColor(accent); c.drawCircle(x + 16, y + 12, 14.5f, p);
        labelCenter(c, icon, x + 16, y + 15, icon.length() > 2 ? 5.8f : 9f, accent, true);
        label(c, title, x + 36, y + 10, 8.8f, accent, true);
        label(c, sub, x + 36, y + 23, 6.5f, MUTED, false);
    }

    private void quickButton(Canvas c, RectF r, int accent, String title, String sub, int code) {
        panel(c, r, 8, Color.argb(205, 6, 44, 75), Color.argb(170, Color.red(accent), Color.green(accent), Color.blue(accent)), 1f);
        p.setStyle(Paint.Style.FILL); p.setColor(Color.argb(95, Color.red(accent), Color.green(accent), Color.blue(accent))); c.drawCircle(r.left + 25, r.centerY(), 17, p);
        String glyph = title.startsWith("Load") ? "L" : title.startsWith("Save") ? "S" : title.startsWith("Device") ? "⚙" : "i";
        labelCenter(c, glyph, r.left + 25, r.centerY() + 4, 11, WHITE, true);
        label(c, title, r.left + 48, r.centerY() - 2, 9, WHITE, true);
        label(c, sub, r.left + 48, r.centerY() + 14, 7.1f, MUTED, false);
        label(c, "›", r.right - 17, r.centerY() + 5, 18, MUTED, false);
        addHit(r, HIT_BUTTON, code, 0, 0, 0, 0);
    }

    private void smallButton(Canvas c, RectF r, int accent, String title, int code) {
        panel(c, r, 7, Color.argb(205, 5, 38, 66), Color.argb(180, Color.red(accent), Color.green(accent), Color.blue(accent)), 1f);
        labelCenter(c, title, r.centerX(), r.centerY() + 3.5f, 8.3f, WHITE, false);
        addHit(r, HIT_BUTTON, code, 0, 0, 0, 0);
    }

    private void toggleButton(Canvas c, RectF r, String title, boolean on, int code) {
        panel(c, r, 7, on ? Color.rgb(3, 73, 126) : Color.argb(195, 5, 37, 64), on ? BLUE : LINE, 1f);
        labelCenter(c, title, r.centerX(), r.centerY() + 2.8f, 6.8f, on ? WHITE : MUTED, false);
        addHit(r, HIT_BUTTON, code, 0, 0, 0, 0);
    }

    private void miniSelect(Canvas c, RectF r, String title, int code, int index) {
        panel(c, r, 5, Color.argb(190, 6, 38, 66), LINE, 1f);
        label(c, title, r.left + 6, r.centerY() + 3, 6.8f, WHITE, false);
        label(c, "⌄", r.right - 12, r.centerY() + 3, 8, MUTED, false);
        addHit(r, HIT_BUTTON, code, index, 0, 0, 0);
    }

    private void drawSwitch(Canvas c, RectF r, boolean on) {
        p.setStyle(Paint.Style.FILL); p.setColor(on ? Color.rgb(0, 100, 168) : Color.rgb(35, 52, 65)); c.drawRoundRect(r, r.height()/2, r.height()/2, p);
        p.setColor(WHITE); float rad = r.height()/2 - 2; c.drawCircle(on ? r.right - rad - 2 : r.left + rad + 2, r.centerY(), rad, p);
    }

    private void circleButton(Canvas c, RectF r, String title, int color) {
        p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(4, 30, 52)); c.drawCircle(r.centerX(), r.centerY(), r.width()/2, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1); p.setColor(LINE); c.drawCircle(r.centerX(), r.centerY(), r.width()/2, p);
        labelCenter(c, title, r.centerX(), r.centerY() + 4, 14, color, false);
    }

    private void drawSlider(Canvas c, RectF r, float value, float min, float max, int accent, boolean maybeLog) {
        float t = clamp((value - min) / (max - min), 0, 1);
        p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(9, 28, 48)); c.drawRoundRect(new RectF(r.left, r.centerY() - 2.5f, r.right, r.centerY() + 2.5f), 3, 3, p);
        p.setColor(accent); c.drawRoundRect(new RectF(r.left, r.centerY() - 2.5f, r.left + r.width() * t, r.centerY() + 2.5f), 3, 3, p);
        p.setColor(WHITE); c.drawCircle(r.left + r.width() * t, r.centerY(), 7, p);
    }

    private void drawLogSlider(Canvas c, RectF r, float value, float min, float max, int accent) {
        float t = (float)((Math.log10(value) - Math.log10(min)) / (Math.log10(max) - Math.log10(min)));
        p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(9, 28, 48)); c.drawRoundRect(new RectF(r.left, r.centerY() - 2.5f, r.right, r.centerY() + 2.5f), 3, 3, p);
        p.setColor(accent); c.drawRoundRect(new RectF(r.left, r.centerY() - 2.5f, r.left + r.width() * t, r.centerY() + 2.5f), 3, 3, p);
        p.setColor(WHITE); c.drawCircle(r.left + r.width() * t, r.centerY(), 7, p);
    }

    private void drawMiniWave(Canvas c, float x, float y, float w, float h) {
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.5f); p.setColor(BLUE);
        for (int i = 0; i < 28; i++) {
            float xx = x + w * i / 27f;
            float amp = (float)(0.15 + 0.85 * Math.abs(Math.sin(i * 1.71))) * h * 0.5f;
            c.drawLine(xx, y + h/2 - amp, xx, y + h/2 + amp, p);
        }
        labelCenter(c, "LIVE AUDIO CONTROL", x + w/2, y + h + 9, 5.8f, MUTED, false);
    }

    private void drawWave(Canvas c, float x, float y, float w, float amp, int color) {
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1); p.setColor(Color.argb(165, Color.red(color), Color.green(color), Color.blue(color)));
        Path path = new Path();
        for (int i = 0; i <= 100; i++) {
            float xx = x + w * i / 100f;
            float yy = y + (float)(Math.sin(i * .55) * Math.sin(i * .09) * amp);
            if (i == 0) path.moveTo(xx, yy); else path.lineTo(xx, yy);
        }
        c.drawPath(path, p);
    }

    private void drawSpeaker(Canvas c, float cx, float cy, int color) {
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.7f); p.setColor(color);
        Path q = new Path(); q.moveTo(cx - 7, cy - 4); q.lineTo(cx - 3, cy - 4); q.lineTo(cx + 2, cy - 9); q.lineTo(cx + 2, cy + 9); q.lineTo(cx - 3, cy + 4); q.lineTo(cx - 7, cy + 4); q.close(); c.drawPath(q, p);
        c.drawArc(new RectF(cx - 1, cy - 7, cx + 11, cy + 7), -55, 110, false, p);
        c.drawArc(new RectF(cx - 2, cy - 11, cx + 16, cy + 11), -48, 96, false, p);
    }

    private void drawGear(Canvas c, float cx, float cy, float r, int color) {
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2f); p.setColor(color); c.drawCircle(cx, cy, r - 2, p); c.drawCircle(cx, cy, 2.5f, p);
        for (int i = 0; i < 8; i++) {
            double a = Math.PI * 2 * i / 8.0;
            float x1 = cx + (float)Math.cos(a) * (r - 1);
            float y1 = cy + (float)Math.sin(a) * (r - 1);
            float x2 = cx + (float)Math.cos(a) * (r + 2);
            float y2 = cy + (float)Math.sin(a) * (r + 2);
            c.drawLine(x1, y1, x2, y2, p);
        }
    }

    private void drawNavIcon(Canvas c, int index, float cx, float cy, int color) {
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2.8f); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeJoin(Paint.Join.ROUND); p.setColor(color);
        if (index == 0) {
            Path h = new Path(); h.moveTo(cx - 9, cy); h.lineTo(cx, cy - 8); h.lineTo(cx + 9, cy); h.moveTo(cx - 6, cy - 1); h.lineTo(cx - 6, cy + 9); h.lineTo(cx + 6, cy + 9); h.lineTo(cx + 6, cy - 1); c.drawPath(h, p);
        } else if (index == 1) {
            for (int i = -1; i <= 1; i++) { float x = cx + i*8; c.drawLine(x, cy - 10, x, cy + 10, p); c.drawCircle(x, cy + (i==0?-4:i<0?3:5), 2.5f, p); }
        } else if (index == 2) {
            c.drawLine(cx - 9, cy + 9, cx - 9, cy + 1, p); c.drawLine(cx, cy + 9, cx, cy - 8, p); c.drawLine(cx + 9, cy + 9, cx + 9, cy - 2, p);
        } else {
            RectF a = new RectF(cx - 12, cy - 10, cx + 2, cy + 10); RectF b = new RectF(cx - 2, cy - 10, cx + 12, cy + 10); c.drawArc(a, -70, 140, false, p); c.drawArc(b, 110, 140, false, p);
        }
        p.setStrokeCap(Paint.Cap.BUTT); p.setStrokeJoin(Paint.Join.MITER);
    }

    private void panel(Canvas c, RectF r, float rad, int fill, int border, float borderW) {
        p.setStyle(Paint.Style.FILL); p.setColor(fill); c.drawRoundRect(r, rad, rad, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(borderW); p.setColor(border); c.drawRoundRect(r, rad, rad, p);
    }

    private void label(Canvas c, String s, float x, float y, float size, int color, boolean bold) {
        text.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        text.setTextSize(size); text.setColor(color); c.drawText(s, x, y, text);
    }

    private void labelCenter(Canvas c, String s, float x, float y, float size, int color, boolean bold) {
        text.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL)); text.setTextSize(size); text.setColor(color);
        c.drawText(s, x - text.measureText(s)/2f, y, text);
    }

    private float textWidth(String s, float size) { text.setTextSize(size); return text.measureText(s); }

    private void addHit(RectF r, int kind, int code, int index, int index2, float min, float max) {
        hits.add(new Hit(r, kind, code, index, index2, min, max));
    }

    // ---------- Touch / state ----------

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX() / canvasScale;
        float y = event.getY() / canvasScale;
        int action = event.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN) {
            activeHit = findHit(x, y);
            if (activeHit == null) return true;
            if (isContinuous(activeHit.kind)) {
                updateContinuous(activeHit, x, y);
                invalidate();
            }
            return true;
        } else if (action == MotionEvent.ACTION_MOVE) {
            if (activeHit != null && isContinuous(activeHit.kind)) {
                updateContinuous(activeHit, x, y);
                invalidate();
            }
            return true;
        } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            if (activeHit != null) {
                if (isContinuous(activeHit.kind)) updateContinuous(activeHit, x, y);
                else if (activeHit.rect.contains(x, y)) handleButton(activeHit);
                activeHit = null;
                invalidate();
            }
            return true;
        }
        return true;
    }

    private Hit findHit(float x, float y) {
        for (int i = hits.size() - 1; i >= 0; i--) if (hits.get(i).rect.contains(x, y)) return hits.get(i);
        return null;
    }

    private boolean isContinuous(int kind) {
        return kind == HIT_SLIDER || kind == HIT_KNOB || kind == HIT_EQ_GRAPH || kind == HIT_EQ_POINT;
    }

    private void updateContinuous(Hit h, float x, float y) {
        if (h.kind == HIT_EQ_GRAPH || h.kind == HIT_EQ_POINT) {
            if (h.kind == HIT_EQ_POINT) selectedBand = h.index;
            else selectedBand = nearestEqBand(x);
            float nx = clamp((x - eqGraphRect.left) / eqGraphRect.width(), 0, 1);
            float ny = clamp((y - eqGraphRect.top) / eqGraphRect.height(), 0, 1);
            eqFreq[eqChannel][selectedBand] = (float)Math.pow(10, Math.log10(20) + nx * (Math.log10(20000) - Math.log10(20)));
            eqGain[eqChannel][selectedBand] = clamp(12f - ny * 24f, -12f, 12f);
            performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK);
            return;
        }
        float t = clamp((x - h.rect.left) / h.rect.width(), 0, 1);
        boolean log = h.code == EQ_FREQ || (h.code >= CROSS_LOW_BASE && h.code < CROSS_HIGH_BASE + 4);
        float v;
        if (log && h.min > 0) v = (float)Math.pow(10, Math.log10(h.min) + t * (Math.log10(h.max) - Math.log10(h.min)));
        else v = h.min + t * (h.max - h.min);
        setContinuousValue(h.code, v);
    }

    private int nearestEqBand(float x) {
        int best = 0; float bd = Float.MAX_VALUE;
        for (int i = 0; i < 15; i++) {
            float px = freqToX(eqFreq[eqChannel][i], eqGraphRect);
            float d = Math.abs(px - x); if (d < bd) { bd = d; best = i; }
        }
        return best;
    }

    private void setContinuousValue(int code, float v) {
        switch (code) {
            case MIX_MASTER: masterVolume = round1(v); break;
            case MIX_BASS: bassVolume = round1(v); break;
            case MIX_CUTOFF: bassCutoff = Math.round(v); break;
            case MIX_BASS_BOOST: bassBoost = round1(v); break;
            case MIX_MID_BOOST: middleBoost = round1(v); break;
            case MIX_TREBLE_BOOST: trebleBoost = round1(v); break;
            case EQ_FREQ: eqFreq[eqChannel][selectedBand] = clamp(v, 20, 20000); break;
            case EQ_GAIN: eqGain[eqChannel][selectedBand] = round1(clamp(v, -12, 12)); break;
            case EQ_Q: eqQ[eqChannel][selectedBand] = round1(clamp(v, .1f, 10)); break;
            case EQ_OUTPUT: outputLevel = round1(clamp(v, -60, 12)); break;
            default:
                if (code >= CROSS_LOW_BASE && code < CROSS_LOW_BASE + 4) {
                    int i = code - CROSS_LOW_BASE; crossLow[i] = clamp(v, 20, 20000); if (i == 1 && crossLow[i] > crossHigh[i]) crossHigh[i] = crossLow[i];
                } else if (code >= CROSS_HIGH_BASE && code < CROSS_HIGH_BASE + 4) {
                    int i = code - CROSS_HIGH_BASE; crossHigh[i] = clamp(v, 20, 20000); if (i == 1 && crossHigh[i] < crossLow[i]) crossLow[i] = crossHigh[i];
                } else if (code >= CROSS_DELAY_BASE && code < CROSS_DELAY_BASE + 4) {
                    delayMs[code - CROSS_DELAY_BASE] = round2(clamp(v, 0, 20));
                }
        }
    }

    private void handleButton(Hit h) {
        int code = h.code;
        if (code >= NAV_BASE && code < NAV_BASE + 4) { page = code - NAV_BASE; return; }
        if (code == BTN_GEAR) { settingsOverlay = true; return; }
        if (code == OVERLAY_CLOSE) { settingsOverlay = false; return; }
        if (settingsOverlay) return;
        if (code == BTN_STATUS) { connected = !connected; toast(connected ? "UI demo: connected" : "UI demo: offline"); return; }
        if (code >= SRC_BASE && code < SRC_BASE + 4) { inputSource = code - SRC_BASE; toast("Input: " + new String[]{"Bluetooth","AUX","Optical","USB"}[inputSource]); return; }
        if (code == QUICK_SAVE || code == EQ_SAVE) { savePreset(); toast("Preset saved in memory"); return; }
        if (code == QUICK_LOAD || code == EQ_LOAD) { loadPreset(); toast(savedGain == null ? "No saved preset yet" : "Preset loaded"); return; }
        if (code == QUICK_DEVICE) { settingsOverlay = true; return; }
        if (code == QUICK_ABOUT) { toast("OKN_DSP Version 2 · Phase 1 UI"); return; }
        if (code >= EQ_CHANNEL_BASE && code < EQ_CHANNEL_BASE + 7) { eqChannel = code - EQ_CHANNEL_BASE; selectedBand = 5; return; }
        if (code == EQ_PREV_BAND) { selectedBand = (selectedBand + 14) % 15; return; }
        if (code == EQ_NEXT_BAND) { selectedBand = (selectedBand + 1) % 15; return; }
        if (code == EQ_MORE) { toast("EQ options · Version 2 UI demo"); return; }
        if (code >= EQ_FREQ + 1000 && code <= EQ_Q + 1000) { adjustEqButton(code - 1000, h.index); return; }
        if (code == CROSS_VIEW_MAG) { crossMagnitude = true; return; }
        if (code == CROSS_VIEW_PHASE) { crossMagnitude = false; return; }
        if (code == CROSS_PRESET) { resetCrossover(); toast("Crossover preset recalled"); return; }
        if (code == CROSS_LINK) { linkLR = !linkLR; return; }
        if (code >= CROSS_MODE_BASE && code < CROSS_MODE_BASE + 4) { int i=code-CROSS_MODE_BASE; crossMode[i]=(crossMode[i]+1)%4; return; }
        if (code >= CROSS_FILTER_BASE && code < CROSS_FILTER_BASE + 4) { int i=code-CROSS_FILTER_BASE; crossFilter[i]=(crossFilter[i]+1)%3; return; }
        if (code >= CROSS_SLOPE_BASE && code < CROSS_SLOPE_BASE + 4) { crossSlope[h.index] = h.index2; return; }
        if (code >= CROSS_UNIT_BASE && code < CROSS_UNIT_BASE + 3) { delayUnit = code - CROSS_UNIT_BASE; return; }
        if (code == CROSS_RESET) { Arrays.fill(delayMs, 0f); return; }
        if (code == CROSS_AUTO) { autoAlign(); toast("Demo auto alignment applied"); }
    }

    private void adjustEqButton(int code, int dir) {
        if (code == EQ_FREQ) {
            float f = eqFreq[eqChannel][selectedBand];
            f *= dir > 0 ? 1.08f : 1f/1.08f;
            eqFreq[eqChannel][selectedBand] = clamp(f, 20, 20000);
        } else if (code == EQ_GAIN) {
            eqGain[eqChannel][selectedBand] = clamp(round1(eqGain[eqChannel][selectedBand] + dir * 0.5f), -12, 12);
        } else if (code == EQ_Q) {
            eqQ[eqChannel][selectedBand] = clamp(round1(eqQ[eqChannel][selectedBand] + dir * 0.1f), .1f, 10);
        }
    }

    private void savePreset() {
        savedGain = deepCopy(eqGain); savedFreq = deepCopy(eqFreq); savedQ = deepCopy(eqQ); savedOutput = outputLevel;
    }

    private void loadPreset() {
        if (savedGain == null) return;
        copyInto(savedGain, eqGain); copyInto(savedFreq, eqFreq); copyInto(savedQ, eqQ); outputLevel = savedOutput;
    }

    private void resetCrossover() {
        crossLow[0]=20; crossHigh[0]=80; crossLow[1]=80; crossHigh[1]=3000; crossLow[2]=3000; crossHigh[2]=20000; crossLow[3]=20; crossHigh[3]=20000;
        crossMode[0]=0; crossMode[1]=1; crossMode[2]=2; crossMode[3]=3;
        crossSlope[0]=1; crossSlope[1]=1; crossSlope[2]=1; crossSlope[3]=0;
        crossFilter[0]=0; crossFilter[1]=1; crossFilter[2]=0; crossFilter[3]=2;
    }

    private void autoAlign() {
        float max = 3.2f;
        delayMs[0] = round2(max - 2.50f);
        delayMs[1] = round2(max - 1.20f);
        delayMs[2] = round2(max - 0.00f);
        delayMs[3] = round2(max - 0.80f);
    }

    // ---------- helpers ----------

    private float freqToX(float f, RectF r) {
        float t = (float)((Math.log10(clamp(f,20,20000)) - Math.log10(20)) / (Math.log10(20000) - Math.log10(20)));
        return r.left + t * r.width();
    }

    private float xToFreq(float x, RectF r) {
        float t = clamp((x-r.left)/r.width(), 0, 1);
        return (float)Math.pow(10, Math.log10(20) + t*(Math.log10(20000)-Math.log10(20)));
    }

    private float lowPassDb(float f, float fc) {
        if (f <= fc) return 0;
        return Math.max(-30f, -(float)(24.0 * Math.log10(f / fc)));
    }
    private float highPassDb(float f, float fc) {
        if (f >= fc) return 0;
        return Math.max(-30f, -(float)(24.0 * Math.log10(fc / Math.max(f,1))));
    }

    private int bandColor(int i) {
        float hue = 205f - i * 18f;
        while (hue < 0) hue += 360;
        return Color.HSVToColor(new float[]{hue, 0.82f, 1f});
    }

    private String modeName(int mode) {
        switch (mode) { case 0: return "Low Pass"; case 1: return "Band Pass"; case 2: return "High Pass"; default: return "Bypass"; }
    }

    private String formatHz(float f) {
        if (f >= 1000) {
            float k = f / 1000f;
            if (k >= 10 || Math.abs(k - Math.round(k)) < .05f) return String.format(Locale.US, "%.0f kHz", k);
            return String.format(Locale.US, "%.1f kHz", k);
        }
        return String.format(Locale.US, "%.0f Hz", f);
    }

    private String formatDelay(float ms) {
        if (delayUnit == 0) return String.format(Locale.US, "%.2f ms", ms);
        if (delayUnit == 1) return String.format(Locale.US, "%.1f cm", ms * 34.3f);
        return String.format(Locale.US, "%.1f in", ms * 13.504f);
    }

    private String distanceText(float ms) {
        if (delayUnit == 0) return String.format(Locale.US, "%.1f cm", ms * 34.3f);
        if (delayUnit == 1) return String.format(Locale.US, "%.2f ms", ms);
        return String.format(Locale.US, "%.2f ms", ms);
    }

    private String signed(float v) { return String.format(Locale.US, "%+.1f", v); }
    private String fmt(float v) { return Math.abs(v - Math.round(v)) < .05f ? String.format(Locale.US, "%.0f", v) : String.format(Locale.US, "%.1f", v); }

    private float mapLinear(float v, float inMin, float inMax, float outMin, float outMax) {
        return outMin + (v - inMin) / (inMax - inMin) * (outMax - outMin);
    }
    private float clamp(float v, float min, float max) { return Math.max(min, Math.min(max, v)); }
    private float round1(float v) { return Math.round(v * 10f) / 10f; }
    private float round2(float v) { return Math.round(v * 100f) / 100f; }

    private float[][] deepCopy(float[][] src) {
        float[][] out = new float[src.length][]; for (int i=0;i<src.length;i++) out[i]=src[i].clone(); return out;
    }
    private void copyInto(float[][] src, float[][] dst) {
        for (int i=0;i<src.length;i++) System.arraycopy(src[i],0,dst[i],0,src[i].length);
    }

    private void toast(String s) { Toast.makeText(getContext(), s, Toast.LENGTH_SHORT).show(); }
}
