package com.okn.dsp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import java.util.Locale;

final class DspView extends View {
    private static final float W = 786f;
    private static final float H = 1536f;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final DspState state = new DspState();
    private BleManager ble;

    private int page = 0; // 0 Home, 1 EQ
    private int draggingHomeSlider = -1;
    private boolean draggingEqPoint = false;
    private boolean draggingFader = false;
    private float scale = 1f;
    private float offsetX = 0f;
    private float offsetY = 0f;
    private String bleStatus = "กำลังค้นหา...";
    private String bleDevice = "OKN-DSP_7CH";
    private boolean bleConnected = false;
    private String diagnostic = "";

    private final int CYAN = Color.rgb(0, 216, 255);
    private final int BLUE = Color.rgb(0, 132, 255);
    private final int PANEL = Color.rgb(3, 27, 48);
    private final int PANEL2 = Color.rgb(2, 19, 36);
    private final int BORDER = Color.rgb(13, 67, 112);
    private final int WHITE = Color.rgb(238, 245, 255);
    private final int SUB = Color.rgb(155, 184, 222);
    private final int GREEN = Color.rgb(0, 236, 123);

    private final int[] bandColors = {
            Color.rgb(255, 70, 80), Color.rgb(255, 191, 58), Color.rgb(52, 231, 91),
            Color.rgb(24, 203, 237), Color.rgb(157, 73, 235), Color.rgb(255, 103, 172)
    };

    DspView(Context context, BleManager ble) {
        super(context);
        this.ble = ble;
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        setFocusable(true);
    }

    void setBleManager(BleManager ble) {
        this.ble = ble;
    }

    void setBleStatus(String status, String deviceName, boolean connected) {
        bleStatus = status == null ? "" : status;
        if (deviceName != null && !deviceName.isEmpty()) bleDevice = deviceName;
        bleConnected = connected;
        invalidate();
    }

    void setDiagnostic(String message) {
        diagnostic = message == null ? "" : message;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float sx = getWidth() / W;
        float sy = getHeight() / H;
        scale = Math.min(sx, sy);
        offsetX = (getWidth() - W * scale) * 0.5f;
        offsetY = (getHeight() - H * scale) * 0.5f;

        canvas.drawColor(Color.rgb(0, 6, 17));
        canvas.save();
        canvas.translate(offsetX, offsetY);
        canvas.scale(scale, scale);
        drawBackdrop(canvas);
        drawHeader(canvas);
        if (page == 0) drawHome(canvas); else drawEq(canvas);
        drawBottomNav(canvas);
        canvas.restore();
    }

    private void drawBackdrop(Canvas c) {
        p.setShader(new LinearGradient(0, 0, W, H,
                Color.rgb(0, 13, 28), Color.rgb(0, 4, 12), Shader.TileMode.CLAMP));
        c.drawRect(0, 0, W, H, p);
        p.setShader(null);
    }

    private void drawHeader(Canvas c) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(bleConnected ? GREEN : Color.rgb(255, 191, 44));
        p.setShadowLayer(14, 0, 0, p.getColor());
        c.drawCircle(36, 64, 12, p);
        p.clearShadowLayer();

        text(c, bleConnected ? "เชื่อมต่อแล้ว" : bleStatus, 66, 60, 24, bleConnected ? GREEN : WHITE, true, Paint.Align.LEFT);
        text(c, bleDevice, 66, 92, 20, SUB, false, Paint.Align.LEFT);
        text(c, "›", 214, 91, 40, SUB, false, Paint.Align.CENTER);

        p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        p.setTextSkewX(-0.14f);
        text(c, "OKN_", 242, 58, 47, WHITE, true, Paint.Align.LEFT);
        float a = textWidth("OKN_", 47, true);
        text(c, "DSP", 242 + a, 58, 47, CYAN, true, Paint.Align.LEFT);
        p.setTextSkewX(0f);
        text(c, "DIGITAL SOUND PROCESSOR", 258, 84, 14, CYAN, true, Paint.Align.LEFT);

        // gear approximation
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(4);
        p.setColor(Color.rgb(176, 201, 244));
        c.drawCircle(718, 64, 23, p);
        c.drawCircle(718, 64, 8, p);
        for (int i = 0; i < 8; i++) {
            double a1 = i * Math.PI / 4.0;
            float x1 = 718 + (float) Math.cos(a1) * 25;
            float y1 = 64 + (float) Math.sin(a1) * 25;
            float x2 = 718 + (float) Math.cos(a1) * 31;
            float y2 = 64 + (float) Math.sin(a1) * 31;
            c.drawLine(x1, y1, x2, y2, p);
        }
        p.setStyle(Paint.Style.FILL);
    }

    private void drawHome(Canvas c) {
        float[] ys = {132, 277, 422, 569, 715, 861};
        String[] title = {"Master Volume", "Bass Volume", "Bass Cutoff", "Bass Boost", "Middle Boost", "Treble Boost"};
        String[] sub = {"ปรับระดับเสียงรวม", "ปรับระดับเสียงเบส", "ตั้งค่าความถี่ตัดเบส", "เพิ่มความหนักแน่นของเบส", "เพิ่มความชัดเจนย่านกลาง", "เพิ่มความใสย่านแหลม"};
        int[] colors = {Color.rgb(0, 139, 255), Color.rgb(0, 219, 239), Color.rgb(218, 45, 238), Color.rgb(255, 39, 111), Color.rgb(0, 151, 255), Color.rgb(209, 53, 241)};
        for (int i = 0; i < ys.length; i++) {
            roundPanel(c, 6, ys[i], 764, 130, 22, PANEL, BORDER);
            drawHomeIcon(c, 76, ys[i] + 64, colors[i], i);
            text(c, title[i], 148, ys[i] + 56, 27, WHITE, true, Paint.Align.LEFT);
            text(c, sub[i], 148, ys[i] + 91, 18, SUB, false, Paint.Align.LEFT);
            drawHomeSlider(c, i, ys[i] + 58, colors[i]);
        }

        // Preset panel
        roundPanel(c, 6, 1014, 764, 342, 24, PANEL, BORDER);
        drawBookmark(c, 52, 1062, CYAN);
        text(c, "พรีเซ็ตเสียง", 110, 1060, 29, WHITE, true, Paint.Align.LEFT);
        text(c, "เลือกโทนเสียงที่คุณชอบ", 110, 1096, 18, SUB, false, Paint.Align.LEFT);
        outlineButton(c, 578, 1033, 172, 56, "ดูเพิ่มเติม  ›", false);

        String[] presets = {"Flat", "Pop", "Rock", "Jazz"};
        for (int i = 0; i < 4; i++) {
            float x = 27 + i * 184;
            boolean sel = state.homePreset == i;
            roundPanel(c, x, 1131, 170, 94, 16,
                    sel ? Color.rgb(0, 137, 255) : PANEL2,
                    sel ? CYAN : BORDER);
            if (sel) glowRect(c, x, 1131, 170, 94, 16, CYAN);
            drawPresetIcon(c, x + 52, 1178, i, sel ? WHITE : Color.rgb(190, 213, 245));
            text(c, presets[i], x + 96, 1188, 21, WHITE, false, Paint.Align.CENTER);
        }

        outlineButton(c, 27, 1248, 354, 85, "⇩   บันทึกเป็นพรีเซ็ต", false);
        outlineButton(c, 394, 1248, 356, 85, "⇧   โหลดพรีเซ็ต", false);
    }

    private void drawHomeSlider(Canvas c, int idx, float cy, int accent) {
        float min, max, value;
        if (idx == 0) { min = -60; max = 12; value = state.masterVolume; }
        else if (idx == 2) { min = 20; max = 500; value = state.bassCutoff; }
        else {
            min = -12; max = 12;
            value = idx == 1 ? state.bassVolume : idx == 3 ? state.bassBoost : idx == 4 ? state.middleBoost : state.trebleBoost;
        }
        float x0 = 343, x1 = 612;
        float frac;
        if (idx == 2) frac = (float) ((Math.log(value) - Math.log(min)) / (Math.log(max) - Math.log(min)));
        else frac = (value - min) / (max - min);
        frac = clamp(frac, 0, 1);
        float knob = x0 + frac * (x1 - x0);

        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(14);
        p.setColor(Color.rgb(29, 63, 100));
        c.drawLine(x0, cy, x1, cy, p);
        if (Math.abs(knob - x0) > 0.5f) {
            p.setShader(new LinearGradient(x0, cy, knob, cy, accent, CYAN, Shader.TileMode.CLAMP));
        } else {
            p.setShader(null);
            p.setColor(accent);
        }
        p.setShadowLayer(8, 0, 0, accent);
        c.drawLine(x0, cy, knob, cy, p);
        p.clearShadowLayer();
        p.setShader(null);
        p.setColor(Color.rgb(242, 247, 253));
        c.drawCircle(knob, cy, 18, p);
        p.setStrokeCap(Paint.Cap.BUTT);

        String[] labels = idx == 0 ? new String[]{"-60", "-40", "-20", "0", "+12"}
                : idx == 2 ? new String[]{"20", "50", "100", "200", "500"}
                : new String[]{"-12", "-6", "0", "+6", "+12"};
        for (int i = 0; i < labels.length; i++) {
            float tx = x0 + i * (x1 - x0) / (labels.length - 1f);
            p.setColor(Color.rgb(24, 101, 170));
            c.drawRect(tx - 1, cy + 17, tx + 1, cy + 28, p);
            text(c, labels[i], tx, cy + 51, 17, SUB, false, Paint.Align.CENTER);
        }
        String valueText = idx == 2 ? String.format(Locale.US, "%.0f Hz", value) : DspState.db(value);
        roundPanel(c, 637, cy - 34, 114, 62, 13, Color.rgb(2, 18, 35), Color.rgb(24, 74, 128));
        text(c, valueText, 694, cy + 8, 22, WHITE, false, Paint.Align.CENTER);
    }

    private void drawEq(Canvas c) {
        roundPanel(c, 6, 110, 774, 784, 23, PANEL, BORDER);
        text(c, "กราฟิก EQ", 32, 169, 38, WHITE, true, Paint.Align.LEFT);
        text(c, "ปรับแต่งความถี่ เสียงของคุณ", 32, 202, 19, SUB, false, Paint.Align.LEFT);

        roundPanel(c, 315, 137, 304, 58, 14, PANEL2, BORDER);
        text(c, DspState.CHANNEL_LONG[state.channel], 337, 176, 20, WHITE, false, Paint.Align.LEFT);
        text(c, "‹", 541, 178, 44, SUB, false, Paint.Align.CENTER);
        text(c, "›", 595, 178, 44, SUB, false, Paint.Align.CENTER);
        outlineButton(c, 630, 137, 139, 58, "↻  Reset", false);

        drawEqGraph(c);
        drawBandCards(c);

        roundPanel(c, 7, 908, 772, 150, 20, PANEL, BORDER);
        text(c, "เลือกช่องสัญญาณ", 27, 945, 22, WHITE, true, Paint.Align.LEFT);
        for (int ch = 0; ch < DspState.CHANNELS; ch++) {
            float x = 26 + ch * 106.5f;
            boolean sel = ch == state.channel;
            roundPanel(c, x, 966, 100, 80, 14, sel ? Color.rgb(0, 132, 255) : PANEL2, sel ? CYAN : BORDER);
            if (sel) glowRect(c, x, 966, 100, 80, 14, CYAN);
            String[] parts = DspState.CHANNEL_SHORT[ch].split("\\n");
            text(c, parts[0], x + 50, 1001, 18, WHITE, false, Paint.Align.CENTER);
            text(c, parts[1], x + 50, 1027, 16, WHITE, false, Paint.Align.CENTER);
        }

        // fader / mute / phase row
        roundPanel(c, 8, 1072, 418, 162, 18, PANEL, BORDER);
        text(c, "เฟดเดอร์ (ระดับเสียง)", 27, 1111, 20, WHITE, true, Paint.Align.LEFT);
        drawSpeaker(c, 49, 1170, SUB);
        drawEqFader(c, 91, 1164, 300, state.fader[state.channel]);
        roundPanel(c, 315, 1134, 95, 55, 12, PANEL2, BORDER);
        text(c, DspState.db(state.fader[state.channel]), 362, 1170, 19, WHITE, false, Paint.Align.CENTER);

        roundPanel(c, 432, 1072, 166, 162, 18, PANEL, BORDER);
        text(c, "มิวท์", 451, 1111, 20, WHITE, true, Paint.Align.LEFT);
        drawMuteToggle(c, 483, 1160, state.mute[state.channel]);

        roundPanel(c, 607, 1072, 171, 162, 18, PANEL, BORDER);
        text(c, "เฟส", 624, 1111, 20, WHITE, true, Paint.Align.LEFT);
        phaseButton(c, 624, 1140, 73, 64, "0°", !state.phase180[state.channel]);
        phaseButton(c, 700, 1140, 64, 64, "180°", state.phase180[state.channel]);

        outlineButton(c, 12, 1249, 254, 96, "⇩  โหลดจากอุปกรณ์\nดึงค่าปัจจุบันจาก DSP", false);
        outlineButton(c, 273, 1249, 246, 96, "⇧  โหลดพรีเซ็ต\nโหลดพรีเซ็ตจากไฟล์", false);
        outlineButton(c, 526, 1249, 252, 96, "▣  บันทึกเป็นพรีเซ็ต\nเก็บไว้ใช้งานภายหลัง", false);

        if (!diagnostic.isEmpty()) {
            text(c, diagnostic.length() > 52 ? diagnostic.substring(0, 52) + "…" : diagnostic,
                    18, 1374, 13, Color.rgb(91, 143, 194), false, Paint.Align.LEFT);
        }
    }

    private void drawEqGraph(Canvas c) {
        float gx = 80, gy = 226, gw = 688, gh = 314;
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.rgb(0, 12, 24));
        c.drawRoundRect(new RectF(gx, gy, gx + gw, gy + gh), 8, 8, p);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(1);
        stroke.setColor(Color.rgb(15, 56, 91));
        for (int i = 0; i <= 12; i++) {
            float x = gx + gw * i / 12f;
            c.drawLine(x, gy, x, gy + gh, stroke);
        }
        for (int i = 0; i <= 6; i++) {
            float y = gy + gh * i / 6f;
            c.drawLine(gx, y, gx + gw, y, stroke);
        }
        stroke.setStrokeWidth(2);
        stroke.setColor(Color.rgb(82, 117, 158));
        c.drawRoundRect(new RectF(gx, gy, gx + gw, gy + gh), 8, 8, stroke);

        String[] gl = {"+12", "+6", "0", "-6", "-12"};
        for (int i = 0; i < gl.length; i++) {
            float y = gy + gh * i / 4f;
            text(c, gl[i], 58, y + 7, 17, SUB, false, Paint.Align.RIGHT);
        }
        text(c, "Gain", 25, 256, 18, SUB, false, Paint.Align.LEFT);
        text(c, "(dB)", 25, 284, 17, SUB, false, Paint.Align.LEFT);

        float[] ticks = {20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000};
        String[] tickText = {"20", "50", "100", "200", "500", "1K", "2K", "5K", "10K", "20K"};
        for (int i = 0; i < ticks.length; i++) {
            float x = freqX(ticks[i], gx, gw);
            text(c, tickText[i], x, gy + gh + 39, 16, SUB, false, Paint.Align.CENTER);
        }
        text(c, "Frequency (Hz)", gx + gw, gy + gh + 69, 15, SUB, false, Paint.Align.RIGHT);

        int ch = state.channel;
        Path line = new Path();
        Path fill = new Path();
        float firstX = gx;
        float firstY = gainY(state.gain[ch][0], gy, gh);
        line.moveTo(firstX, firstY);
        fill.moveTo(gx, gy + gh);
        fill.lineTo(firstX, firstY);
        for (int b = 0; b < DspState.BANDS; b++) {
            float x = freqX(state.freq[ch][b], gx, gw);
            float y = gainY(state.gain[ch][b], gy, gh);
            if (b == 0) {
                line.moveTo(x, y);
            } else {
                float px = freqX(state.freq[ch][b - 1], gx, gw);
                float py = gainY(state.gain[ch][b - 1], gy, gh);
                float mx = (px + x) * 0.5f;
                line.cubicTo(mx, py, mx, y, x, y);
            }
        }
        float lastX = freqX(state.freq[ch][DspState.BANDS - 1], gx, gw);
        float lastY = gainY(state.gain[ch][DspState.BANDS - 1], gy, gh);
        fill.reset();
        fill.moveTo(gx, gy + gh);
        fill.lineTo(freqX(state.freq[ch][0], gx, gw), gainY(state.gain[ch][0], gy, gh));
        for (int b = 1; b < DspState.BANDS; b++) {
            float x = freqX(state.freq[ch][b], gx, gw);
            float y = gainY(state.gain[ch][b], gy, gh);
            float px = freqX(state.freq[ch][b - 1], gx, gw);
            float py = gainY(state.gain[ch][b - 1], gy, gh);
            float mx = (px + x) * 0.5f;
            fill.cubicTo(mx, py, mx, y, x, y);
        }
        fill.lineTo(gx + gw, lastY);
        fill.lineTo(gx + gw, gy + gh);
        fill.close();
        p.setShader(new LinearGradient(0, gy, 0, gy + gh, Color.argb(100, 0, 110, 255), Color.argb(0, 0, 110, 255), Shader.TileMode.CLAMP));
        c.drawPath(fill, p);
        p.setShader(null);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(4);
        stroke.setColor(Color.rgb(0, 128, 255));
        stroke.setShadowLayer(10, 0, 0, BLUE);
        c.drawPath(line, stroke);
        stroke.clearShadowLayer();

        for (int b = 0; b < DspState.BANDS; b++) {
            float x = freqX(state.freq[ch][b], gx, gw);
            float y = gainY(state.gain[ch][b], gy, gh);
            p.setColor(bandColors[b]);
            p.setShadowLayer(12, 0, 0, bandColors[b]);
            c.drawCircle(x, y, 12, p);
            p.clearShadowLayer();
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(3);
            stroke.setColor(WHITE);
            c.drawCircle(x, y, b == state.selectedBand ? 14 : 12, stroke);
        }
    }

    private void drawBandCards(Canvas c) {
        int ch = state.channel;
        float y = 626;
        for (int b = 0; b < DspState.BANDS; b++) {
            float x = 20 + b * 124.3f;
            boolean sel = b == state.selectedBand;
            roundPanel(c, x, y, 113, 252, 15, Color.rgb(2, 18, 33), sel ? CYAN : Color.rgb(17, 58, 94));
            if (sel) glowRect(c, x, y, 113, 252, 15, CYAN);
            p.setColor(bandColors[b]);
            c.drawCircle(x + 32, y + 30, 12, p);
            text(c, Integer.toString(b + 1), x + 64, y + 38, 17, WHITE, false, Paint.Align.LEFT);
            divider(c, x + 15, y + 62, x + 98, y + 62);
            text(c, "Freq", x + 16, y + 95, 16, SUB, false, Paint.Align.LEFT);
            text(c, DspState.hz(state.freq[ch][b]), x + 69, y + 96, 17, WHITE, false, Paint.Align.CENTER);
            divider(c, x + 15, y + 119, x + 98, y + 119);
            text(c, "Gain", x + 16, y + 150, 16, SUB, false, Paint.Align.LEFT);
            text(c, DspState.db(state.gain[ch][b]), x + 69, y + 151, 16, WHITE, false, Paint.Align.CENTER);
            divider(c, x + 15, y + 177, x + 98, y + 177);
            text(c, "Q", x + 16, y + 205, 16, SUB, false, Paint.Align.LEFT);
            text(c, String.format(Locale.US, "%.1f", state.q[ch][b]), x + 70, y + 206, 17, WHITE, false, Paint.Align.CENTER);
            drawBell(c, x + 56, y + 230, WHITE);
        }
    }

    private void drawBottomNav(Canvas c) {
        roundPanel(c, 0, 1391, 786, 145, 42, Color.rgb(1, 14, 27), Color.rgb(13, 52, 83));
        String[] labels = {"Home", "EQ", "Crossover", "Delay", "Settings"};
        for (int i = 0; i < 5; i++) {
            float cx = 78.6f + i * 157.2f;
            boolean sel = (page == 0 && i == 0) || (page == 1 && i == 1);
            int color = sel ? CYAN : Color.rgb(170, 198, 244);
            if (i == 0) drawHomeNavIcon(c, cx, 1444, color, sel);
            else if (i == 1) drawEqNavIcon(c, cx, 1444, color, sel);
            else if (i == 2) drawCrossoverIcon(c, cx, 1444, color);
            else if (i == 3) drawClock(c, cx, 1444, color);
            else drawGearSmall(c, cx, 1444, color);
            text(c, labels[i], cx, 1503, 20, color, false, Paint.Align.CENTER);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (scale <= 0f || Float.isNaN(scale) || Float.isInfinite(scale)) return true;
        float x = (event.getX() - offsetX) / scale;
        float y = (event.getY() - offsetY) / scale;
        if (x < 0 || x > W || y < 0 || y > H) return true;

        if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
            if (y < 110 && (x < 245 || x > 675)) {
                if (ble != null) ble.startScan();
                else toast("Bluetooth กำลังเตรียมพร้อม");
                return true;
            }
            if (y >= 1390) {
                int tab = Math.min(4, Math.max(0, (int) (x / (W / 5f))));
                if (tab == 0) page = 0;
                else if (tab == 1) page = 1;
                else toast("ยังไม่มีภาพ UI อ้างอิงสำหรับหน้านี้ จึงไม่สร้างหน้าจอเดาเอง");
                invalidate();
                return true;
            }
            if (page == 0) return handleHomeDown(x, y);
            else return handleEqDown(x, y);
        }

        if (event.getActionMasked() == MotionEvent.ACTION_MOVE) {
            if (page == 0 && draggingHomeSlider >= 0) {
                updateHomeSlider(draggingHomeSlider, x);
                invalidate();
                return true;
            }
            if (page == 1 && draggingEqPoint) {
                updateEqPoint(x, y);
                invalidate();
                return true;
            }
            if (page == 1 && draggingFader) {
                updateFader(x);
                invalidate();
                return true;
            }
        }

        if (event.getActionMasked() == MotionEvent.ACTION_UP || event.getActionMasked() == MotionEvent.ACTION_CANCEL) {
            draggingHomeSlider = -1;
            draggingEqPoint = false;
            draggingFader = false;
            return true;
        }
        return true;
    }

    private boolean handleHomeDown(float x, float y) {
        float[] ys = {190, 335, 480, 627, 773, 919};
        for (int i = 0; i < ys.length; i++) {
            if (x >= 320 && x <= 630 && Math.abs(y - ys[i]) < 36) {
                draggingHomeSlider = i;
                updateHomeSlider(i, x);
                invalidate();
                return true;
            }
        }
        if (y >= 1125 && y <= 1232) {
            int i = (int) ((x - 20) / 184f);
            if (i >= 0 && i < 4) {
                state.applyHomePreset(i);
                invalidate();
                return true;
            }
        }
        if (x >= 27 && x <= 381 && y >= 1244 && y <= 1340) {
            state.saveHome(getContext());
            toast("บันทึกพรีเซ็ตแล้ว");
            return true;
        }
        if (x >= 394 && x <= 750 && y >= 1244 && y <= 1340) {
            boolean ok = state.loadHome(getContext());
            toast(ok ? "โหลดพรีเซ็ตแล้ว" : "ยังไม่มีพรีเซ็ตที่บันทึกไว้");
            invalidate();
            return true;
        }
        if (x >= 570 && y >= 1025 && y <= 1100) {
            toast("ยังไม่มีภาพ UI อ้างอิงสำหรับรายการพรีเซ็ตเพิ่มเติม");
            return true;
        }
        return true;
    }

    private void updateHomeSlider(int idx, float x) {
        float frac = clamp((x - 343f) / (612f - 343f), 0f, 1f);
        if (idx == 0) state.masterVolume = round1(-60f + frac * 72f);
        else if (idx == 1) state.bassVolume = round1(-12f + frac * 24f);
        else if (idx == 2) {
            double v = Math.exp(Math.log(20) + frac * (Math.log(500) - Math.log(20)));
            state.bassCutoff = Math.round((float) v);
        } else if (idx == 3) state.bassBoost = round1(-12f + frac * 24f);
        else if (idx == 4) state.middleBoost = round1(-12f + frac * 24f);
        else state.trebleBoost = round1(-12f + frac * 24f);
    }

    private boolean handleEqDown(float x, float y) {
        if (x >= 630 && y >= 132 && y <= 205) {
            state.resetEq(state.channel);
            invalidate();
            return true;
        }
        if (x >= 520 && x <= 570 && y >= 132 && y <= 205) {
            state.channel = (state.channel + DspState.CHANNELS - 1) % DspState.CHANNELS;
            invalidate();
            return true;
        }
        if (x >= 570 && x <= 620 && y >= 132 && y <= 205) {
            state.channel = (state.channel + 1) % DspState.CHANNELS;
            invalidate();
            return true;
        }
        if (x >= 20 && x <= 770 && y >= 620 && y <= 885) {
            int b = Math.min(DspState.BANDS - 1, Math.max(0, (int) ((x - 20) / 124.3f)));
            state.selectedBand = b;
            invalidate();
            return true;
        }
        if (x >= 80 && x <= 768 && y >= 220 && y <= 550) {
            int nearest = nearestBand(x, y);
            if (nearest >= 0) {
                state.selectedBand = nearest;
                draggingEqPoint = true;
                updateEqPoint(x, y);
                invalidate();
            }
            return true;
        }
        if (y >= 960 && y <= 1053) {
            int ch = (int) ((x - 22) / 106.5f);
            if (ch >= 0 && ch < DspState.CHANNELS) {
                state.channel = ch;
                invalidate();
            }
            return true;
        }
        if (x >= 82 && x <= 306 && y >= 1134 && y <= 1198) {
            draggingFader = true;
            updateFader(x);
            invalidate();
            return true;
        }
        if (x >= 460 && x <= 590 && y >= 1125 && y <= 1208) {
            state.mute[state.channel] = !state.mute[state.channel];
            invalidate();
            return true;
        }
        if (x >= 620 && x <= 700 && y >= 1132 && y <= 1210) {
            state.phase180[state.channel] = false;
            invalidate();
            return true;
        }
        if (x >= 700 && x <= 775 && y >= 1132 && y <= 1210) {
            state.phase180[state.channel] = true;
            invalidate();
            return true;
        }
        if (x >= 12 && x <= 266 && y >= 1242 && y <= 1360) {
            if (ble != null) ble.readKnownCharacteristic();
            else toast("Bluetooth ยังไม่พร้อม");
            return true;
        }
        if (x >= 273 && x <= 519 && y >= 1242 && y <= 1360) {
            boolean ok = state.loadEq(getContext());
            toast(ok ? "โหลดพรีเซ็ต EQ แล้ว" : "ยังไม่มีพรีเซ็ต EQ ที่บันทึกไว้");
            invalidate();
            return true;
        }
        if (x >= 526 && x <= 780 && y >= 1242 && y <= 1360) {
            state.saveEq(getContext());
            toast("บันทึกพรีเซ็ต EQ แล้ว");
            return true;
        }
        return true;
    }

    private int nearestBand(float x, float y) {
        float gx = 80, gy = 226, gw = 688, gh = 314;
        int best = -1;
        float bestDist = Float.MAX_VALUE;
        for (int b = 0; b < DspState.BANDS; b++) {
            float px = freqX(state.freq[state.channel][b], gx, gw);
            float py = gainY(state.gain[state.channel][b], gy, gh);
            float dx = px - x, dy = py - y;
            float d = dx * dx + dy * dy;
            if (d < bestDist) { bestDist = d; best = b; }
        }
        return bestDist <= 58f * 58f ? best : -1;
    }

    private void updateEqPoint(float x, float y) {
        float gx = 80, gy = 226, gw = 688, gh = 314;
        int b = state.selectedBand;
        float fracX = clamp((x - gx) / gw, 0f, 1f);
        float f = (float) Math.exp(Math.log(20) + fracX * (Math.log(20000) - Math.log(20)));
        if (b > 0) f = Math.max(f, state.freq[state.channel][b - 1] * 1.08f);
        if (b < DspState.BANDS - 1) f = Math.min(f, state.freq[state.channel][b + 1] / 1.08f);
        state.freq[state.channel][b] = Math.round(f);
        float gain = 12f - clamp((y - gy) / gh, 0f, 1f) * 24f;
        state.gain[state.channel][b] = round1(gain);
    }

    private void updateFader(float x) {
        float frac = clamp((x - 91f) / (300f - 91f), 0f, 1f);
        state.fader[state.channel] = round1(-60f + frac * 72f);
    }

    private void drawHomeIcon(Canvas c, float cx, float cy, int color, int type) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.argb(20, Color.red(color), Color.green(color), Color.blue(color)));
        p.setShadowLayer(18, 0, 0, color);
        c.drawCircle(cx, cy, 49, p);
        p.clearShadowLayer();
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(3);
        stroke.setColor(color);
        c.drawCircle(cx, cy, 49, stroke);
        if (type == 0) drawSpeaker(c, cx - 5, cy, color);
        else if (type == 1) {
            stroke.setStrokeWidth(5); c.drawCircle(cx, cy, 20, stroke); c.drawCircle(cx, cy, 8, stroke);
        } else if (type == 2) {
            stroke.setStrokeWidth(4); c.drawLine(cx - 25, cy - 18, cx + 25, cy - 18, stroke); c.drawLine(cx - 10, cy - 18, cx - 10, cy + 24, stroke); c.drawLine(cx - 10, cy - 18, cx + 20, cy + 2, stroke);
        } else if (type == 3) {
            p.setColor(color); for (int i = 0; i < 6; i++) c.drawRoundRect(new RectF(cx - 25 + i * 9, cy + 22 - i * 8, cx - 19 + i * 9, cy + 26), 3, 3, p);
        } else if (type == 4) {
            Path path = new Path(); path.moveTo(cx - 28, cy); path.lineTo(cx - 18, cy); path.lineTo(cx - 10, cy - 18); path.lineTo(cx, cy + 20); path.lineTo(cx + 11, cy - 8); path.lineTo(cx + 20, cy + 6); path.lineTo(cx + 28, cy + 6); stroke.setStrokeWidth(4); c.drawPath(path, stroke);
        } else {
            p.setColor(color); Path star = new Path(); for (int i = 0; i < 8; i++) { double a = -Math.PI/2 + i*Math.PI/4; float r = (i%2==0)?24:9; float xx=cx+(float)Math.cos(a)*r; float yy=cy+(float)Math.sin(a)*r; if(i==0)star.moveTo(xx,yy);else star.lineTo(xx,yy);} star.close(); c.drawPath(star,p);
        }
    }

    private void drawSpeaker(Canvas c, float cx, float cy, int color) {
        p.setColor(color);
        Path tri = new Path(); tri.moveTo(cx - 22, cy - 8); tri.lineTo(cx - 8, cy - 8); tri.lineTo(cx + 7, cy - 21); tri.lineTo(cx + 7, cy + 21); tri.lineTo(cx - 8, cy + 8); tri.lineTo(cx - 22, cy + 8); tri.close(); c.drawPath(tri, p);
        stroke.setColor(color); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(3); c.drawArc(new RectF(cx, cy - 17, cx + 31, cy + 17), -55, 110, false, stroke); c.drawArc(new RectF(cx - 1, cy - 25, cx + 45, cy + 25), -50, 100, false, stroke);
    }

    private void drawBookmark(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(6);
        Path path = new Path(); path.moveTo(cx - 14, cy - 24); path.lineTo(cx + 14, cy - 24); path.lineTo(cx + 14, cy + 24); path.lineTo(cx, cy + 14); path.lineTo(cx - 14, cy + 24); path.close(); c.drawPath(path, stroke);
    }

    private void drawPresetIcon(Canvas c, float cx, float cy, int type, int color) {
        stroke.setColor(color); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(3);
        if (type == 0) { for (int i = -2; i <= 2; i++) c.drawLine(cx + i*8, cy - 15 + Math.abs(i)*5, cx + i*8, cy + 15 - Math.abs(i)*5, stroke); }
        else if (type == 1) { c.drawCircle(cx-10,cy-3,6,stroke);c.drawCircle(cx+6,cy-7,6,stroke);c.drawCircle(cx+20,cy-1,6,stroke);c.drawLine(cx-16,cy+13,cx+26,cy+13,stroke); }
        else if (type == 2) { c.drawLine(cx-20,cy+15,cx+17,cy-20,stroke);c.drawCircle(cx-14,cy+11,8,stroke); }
        else { Path path = new Path(); path.moveTo(cx-8,cy+18);path.lineTo(cx-8,cy-20);path.lineTo(cx+14,cy-25);path.lineTo(cx+14,cy+8);c.drawPath(path,stroke);c.drawCircle(cx-13,cy+18,8,stroke);c.drawCircle(cx+9,cy+8,8,stroke); }
    }

    private void drawEqFader(Canvas c, float x0, float cy, float x1, float value) {
        float frac = clamp((value + 60f) / 72f, 0, 1);
        float knob = x0 + frac * (x1 - x0);
        p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeWidth(12); p.setColor(Color.rgb(32, 67, 100)); c.drawLine(x0, cy, x1, cy, p);
        if (Math.abs(knob - x0) > 0.5f) p.setShader(new LinearGradient(x0, cy, knob, cy, BLUE, CYAN, Shader.TileMode.CLAMP)); else { p.setShader(null); p.setColor(BLUE); } p.setShadowLayer(8,0,0,CYAN); c.drawLine(x0,cy,knob,cy,p); p.clearShadowLayer();p.setShader(null);p.setColor(WHITE);c.drawCircle(knob,cy,17,p);p.setStrokeCap(Paint.Cap.BUTT);
        String[] labels={"-60","-40","-20","0","+12"};for(int i=0;i<labels.length;i++){float tx=x0+i*(x1-x0)/4f;text(c,labels[i],tx,cy+47,15,SUB,false,Paint.Align.CENTER);}    }

    private void drawMuteToggle(Canvas c, float cx, float cy, boolean on) {
        roundPanel(c, cx, cy-25, 96, 50, 25, on ? Color.rgb(0, 118, 190) : Color.rgb(45, 72, 102), on ? CYAN : Color.rgb(60, 91, 126));
        float kx = on ? cx + 69 : cx + 27; p.setColor(WHITE);c.drawCircle(kx,cy,20,p);
        drawSpeaker(c, cx-24, cy, SUB);
        if (on) { stroke.setColor(Color.rgb(255,90,100));stroke.setStrokeWidth(3);c.drawLine(cx-37,cy-15,cx-12,cy+15,stroke); }
    }

    private void phaseButton(Canvas c,float x,float y,float w,float h,String label,boolean selected){roundPanel(c,x,y,w,h,12,selected?Color.rgb(0,132,255):PANEL2,selected?CYAN:BORDER);if(selected)glowRect(c,x,y,w,h,12,CYAN);text(c,label,x+w/2,y+h/2+8,19,WHITE,false,Paint.Align.CENTER);}

    private void drawBell(Canvas c, float cx, float cy, int color) { stroke.setStyle(Paint.Style.STROKE);stroke.setStrokeWidth(2.5f);stroke.setColor(color);Path b=new Path();b.moveTo(cx-19,cy+8);b.cubicTo(cx-10,cy+8,cx-10,cy-15,cx,cy-15);b.cubicTo(cx+10,cy-15,cx+10,cy+8,cx+19,cy+8);c.drawPath(b,stroke); }

    private void drawHomeNavIcon(Canvas c,float cx,float cy,int color,boolean selected){p.setColor(selected?Color.argb(60,0,216,255):Color.TRANSPARENT);if(selected){p.setShadowLayer(18,0,0,color);c.drawCircle(cx,cy,30,p);p.clearShadowLayer();}stroke.setColor(color);stroke.setStrokeWidth(4);stroke.setStyle(Paint.Style.STROKE);Path h=new Path();h.moveTo(cx-24,cy);h.lineTo(cx,cy-22);h.lineTo(cx+24,cy);h.lineTo(cx+19,cy);h.lineTo(cx+19,cy+23);h.lineTo(cx+4,cy+23);h.lineTo(cx+4,cy+7);h.lineTo(cx-5,cy+7);h.lineTo(cx-5,cy+23);h.lineTo(cx-19,cy+23);h.lineTo(cx-19,cy);h.close();c.drawPath(h,stroke);}
    private void drawEqNavIcon(Canvas c,float cx,float cy,int color,boolean selected){stroke.setColor(color);stroke.setStrokeWidth(3);for(int i=-1;i<=1;i++){float xx=cx+i*17;c.drawLine(xx,cy-25,xx,cy+25,stroke);float ky=cy+(i==0?-8:i==-1?8:3);c.drawLine(xx-7,ky,xx+7,ky,stroke);c.drawCircle(xx,ky,5,stroke);}if(selected){p.setColor(Color.argb(50,0,216,255));p.setShadowLayer(12,0,0,color);c.drawCircle(cx,cy,31,p);p.clearShadowLayer();}}
    private void drawCrossoverIcon(Canvas c,float cx,float cy,int color){stroke.setColor(color);stroke.setStrokeWidth(3);c.drawCircle(cx,cy-20,6,stroke);c.drawCircle(cx-22,cy+20,6,stroke);c.drawCircle(cx+22,cy+20,6,stroke);c.drawLine(cx,cy-14,cx,cy,stroke);c.drawLine(cx,cy,cx-22,cy+14,stroke);c.drawLine(cx,cy,cx+22,cy+14,stroke);}
    private void drawClock(Canvas c,float cx,float cy,int color){stroke.setColor(color);stroke.setStrokeWidth(3);c.drawCircle(cx,cy,24,stroke);c.drawLine(cx,cy,cx,cy-14,stroke);c.drawLine(cx,cy,cx+10,cy+8,stroke);}
    private void drawGearSmall(Canvas c,float cx,float cy,int color){stroke.setColor(color);stroke.setStrokeWidth(3);c.drawCircle(cx,cy,20,stroke);c.drawCircle(cx,cy,7,stroke);for(int i=0;i<8;i++){double a=i*Math.PI/4;float x1=cx+(float)Math.cos(a)*21,y1=cy+(float)Math.sin(a)*21,x2=cx+(float)Math.cos(a)*27,y2=cy+(float)Math.sin(a)*27;c.drawLine(x1,y1,x2,y2,stroke);}}

    private void roundPanel(Canvas c, float x, float y, float w, float h, float r, int fill, int border) { p.setStyle(Paint.Style.FILL);p.setColor(fill);c.drawRoundRect(new RectF(x,y,x+w,y+h),r,r,p);stroke.setStyle(Paint.Style.STROKE);stroke.setStrokeWidth(1.5f);stroke.setColor(border);c.drawRoundRect(new RectF(x,y,x+w,y+h),r,r,stroke); }
    private void glowRect(Canvas c,float x,float y,float w,float h,float r,int color){stroke.setStyle(Paint.Style.STROKE);stroke.setStrokeWidth(2.5f);stroke.setColor(color);stroke.setShadowLayer(15,0,0,color);c.drawRoundRect(new RectF(x,y,x+w,y+h),r,r,stroke);stroke.clearShadowLayer();}
    private void outlineButton(Canvas c,float x,float y,float w,float h,String label,boolean selected){roundPanel(c,x,y,w,h,15,selected?Color.rgb(0,128,240):PANEL2,selected?CYAN:Color.rgb(11,115,183));String[] lines=label.split("\\n");if(lines.length==1)text(c,lines[0],x+w/2,y+h/2+7,20,WHITE,false,Paint.Align.CENTER);else{ text(c,lines[0],x+w/2,y+h/2-3,19,WHITE,true,Paint.Align.CENTER); text(c,lines[1],x+w/2,y+h/2+25,14,SUB,false,Paint.Align.CENTER);}}
    private void divider(Canvas c,float x1,float y1,float x2,float y2){stroke.setColor(Color.rgb(20,50,78));stroke.setStrokeWidth(1);c.drawLine(x1,y1,x2,y2,stroke);}
    private void text(Canvas c,String s,float x,float y,float size,int color,boolean bold,Paint.Align align){p.setShader(null);p.setStyle(Paint.Style.FILL);p.setColor(color);p.setTextSize(size);p.setTextAlign(align);p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));c.drawText(s,x,y,p);}
    private float textWidth(String s,float size,boolean bold){p.setTextSize(size);p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));return p.measureText(s);}
    private float freqX(float freq,float gx,float gw){double frac=(Math.log(Math.max(20f,freq))-Math.log(20))/(Math.log(20000)-Math.log(20));return gx+(float)frac*gw;}
    private float gainY(float gain,float gy,float gh){return gy+(12f-clamp(gain,-12f,12f))/24f*gh;}
    private float clamp(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}
    private float round1(float v){return Math.round(v*10f)/10f;}
    private void toast(String s){Toast.makeText(getContext(),s,Toast.LENGTH_SHORT).show();}
}
