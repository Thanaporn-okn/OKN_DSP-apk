OKN_DSP Version 3 - Phase 1 UI

This version focuses on matching the supplied four-screen visual reference using native Canvas drawing only.
The reference image is NOT copied into the app as a background or UI bitmap.

Screens:
- Home: device status, vector DSP chassis, source selector, quick actions, sound banner
- Mix: master/bass sliders plus Bass Cutoff/Bass Boost/Middle Boost/Treble Boost rotary controls
- Eq: seven channel tabs, interactive 15-band response, Frequency/Gain/Q controls, output level
- Crossover: response graph, four filter blocks, slopes, delay/time alignment and units

Interaction:
- UI redraws immediately during drag/touch.
- Phase 1 contains simulated/local UI state only.
- Real DSP/BLE protocol transport is reserved for Phase 2.

Install/update note:
V1/V2 GitHub debug builds could be signed by different temporary runner keys. Android will reject an in-place update when signatures differ.
V3 introduces a stable DEVELOPMENT signing key included in the source so V3 -> V4 -> later development builds can update in place.
For the first V3 install, uninstall the older V1/V2 app once if Android reports an incompatible update. App data from that old install will be removed.
For Phase 3 release builds, replace the development key with a private release key stored in GitHub Secrets; do not use this development key for production distribution.
