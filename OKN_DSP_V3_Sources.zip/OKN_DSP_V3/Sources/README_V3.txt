OKN_DSP V3

V3 is a new version because V2 could be built but was reported not to open.

Changes:
- The Home/EQ UI remains based only on the two supplied reference images.
- The first UI frame is shown before Bluetooth initialization and permission requests.
- Bluetooth initialization is isolated so an OEM/Bluetooth runtime exception cannot close the app at startup.
- Fullscreen/immersive setup is guarded so it cannot prevent app launch.
- BLE scan/connect calls catch runtime failures and report them in the UI instead of crashing the Activity.
- Slider gradients are protected against a zero-length LinearGradient edge case.
- Touch handling is protected against invalid/zero view scale.
- Version bumped to 3 / 3.0.0.

Protocol note:
The known characteristic 0000ab01-0000-1000-8000-00805f9b34fb is retained for READ/Notify discovery. No unverified DSP WRITE packet format is invented.
