OKN_DSP V3 - PHASE 1 UI
=======================
This source package recreates the uploaded DSP UI with code-drawn Android Canvas controls.
The uploaded screenshot is NOT used as an app background.

Pages:
- Home
- Mix
- Eq
- Crossover

V3 Phase-1 behavior:
- Touch controls update local values immediately.
- EQ and crossover graphs redraw immediately from local state.
- 7 EQ channels x 15 bands keep independent Frequency / Gain / Q values.
- Full preset Save/Load now includes Mix, EQ, Output, Crossover, Delay, input source, and related UI DSP settings.
- Presets are also persisted with SharedPreferences so Load can restore after an app restart.
- Frequency and crossover slider thumb positions now use the same logarithmic mapping as touch input.
- Crossover filter modes expose the cutoff control(s) required by the selected mode.
- Crossover Preset applies the reference values visible in the Phase-1 design.
- Delay unit buttons ms / cm / in are interactive and update displayed values immediately.
- Full-screen/immersive mode and V2 startup/render recovery hardening remain enabled.

Not included yet:
- Real DSP/BLE protocol commands. These belong to Phase 2 and will be based only on uploaded protocol/control data.
