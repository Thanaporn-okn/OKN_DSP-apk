OKN_DSP V3 / PHASE 1 UI

This version is a new version, not an overwrite of V2.
The UI is written from Android Canvas/vector primitives. The uploaded reference image is not used as a background.

V3 startup-hardening changes:
- Native FrameLayout is attached first, before the custom DSP view.
- Custom DSP UI is mounted in a guarded second step.
- If UI construction fails, the app remains open and shows a Safe startup mode screen.
- Removed the global uncaught-exception handler from V2.
- Removed version-sensitive window setup from startup.
- Uses conservative immersive compatibility flags.
- Uses software Canvas rendering to avoid device/GPU-driver-specific rendering failures.
- UI draw/touch boundaries catch Throwable and switch to an in-app recovery screen instead of terminating the process.
- Preset storage uses a new V3 namespace so corrupted V1/V2 state cannot be loaded.

Phase 2 DSP/BLE transport is intentionally not connected yet.
