OKN DSP V3 — Phase 1 UI graph/persistence stability release

V3 is created after the V2 device test showed the app launches and the Phase 1 controls work,
but the EQ polyline could cross/backtrack when a band frequency moved past another band.

Changes from V2:
- Android versionCode 1003 and visible V3 label.
- EQ graph segments are now connected in live frequency order, not fixed band-number order.
- Band identity remains unchanged: selecting Band 1..15 still edits that exact band's Frequency/Q/Gain.
- Frequency crossings no longer create a backward/crossed graph segment.
- Graph updates on every slider move with no intentional debounce/delay.
- Persisted Master/Bass/Cutoff/channel/EQ values are range-sanitized on restore, including NaN/Infinity protection.
- Existing V2 safe-launch and safe-render protections are retained.
- Theme, page, selected channel/band and all control values remain locally persisted.

Phase 2 DSP transport remains intentionally disabled until real DSP protocol/packet data is supplied.
The uploaded screenshots are visual references only; no screenshot is used as a screen background.
