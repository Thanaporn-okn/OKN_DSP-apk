# OKN DSP V3 — Phase 1 Preset Manager

V3 is an in-place upgrade of V2. It keeps the same Android application ID and stable signing key so it can update V1/V2 while preserving saved state.

## V3 changes
- Renames the EQ control label from `Gain / Ch Volume` to `Gain Band`.
- Replaces the old single-preset storage with a multi-preset collection.
- Each different preset name is saved independently; saving the same name overwrites only that preset.
- The Saved Presets field opens a picker so any stored preset can be selected and loaded.
- Adds a Delete button with confirmation for the selected preset.
- Migrates the V2 single saved preset into the V3 preset collection automatically when present.
- Keeps theme, slider values, EQ state, selected page/channel/band, and preset selection persistent across app restarts.
- Phase 2 DSP transport remains intentionally unimplemented until the real protocol/control data is supplied.

Build input: `OKN_DSP_V3_Sources.zip` using `OKN_DSP_AutoBuild.yml`.
