import 'dart:async';

import '../models/dsp_models.dart';
import 'ble_dsp_service.dart';

/// Routes immediate UI control events toward the hardware transport.
///
/// The visual/control layer is fully functional. Actual DSP byte frames are
/// deliberately not fabricated: until the real device protocol is supplied,
/// commands remain observable in [lastCommand] while BLE connection and raw
/// characteristic access stay available through [BleDspService].
class DspCommandGateway {
  DspCommandGateway(this._bleService);

  final BleDspService _bleService;
  final ValueStream<DspControlCommand?> _lastCommand = ValueStream(null);

  ValueStream<DspControlCommand?> get lastCommand => _lastCommand;

  bool get hardwareProtocolMapped => false;

  void dispatch(DspControlCommand command) {
    _lastCommand.value = command;
  }

  Future<void> sendRaw(List<int> bytes, {bool withResponse = false}) {
    return _bleService.writeRaw(bytes, withResponse: withResponse);
  }

  void dispose() {
    _lastCommand.close();
  }
}

class ValueStream<T> {
  ValueStream(this._value);

  T _value;
  final StreamController<T> _controller = StreamController<T>.broadcast(sync: true);

  T get value => _value;

  set value(T next) {
    _value = next;
    if (!_controller.isClosed) {
      _controller.add(next);
    }
  }

  Stream<T> get stream => _controller.stream;

  void close() {
    _controller.close();
  }
}
