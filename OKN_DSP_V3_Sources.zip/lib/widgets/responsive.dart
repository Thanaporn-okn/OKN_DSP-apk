import 'package:flutter/material.dart';

class ResponsivePage extends StatelessWidget {
  const ResponsivePage({
    required this.child,
    super.key,
    this.maxWidth = 1180,
    this.scrollable = true,
  });

  final Widget child;
  final double maxWidth;
  final bool scrollable;

  @override
  Widget build(BuildContext context) {
    final media = MediaQuery.of(context);
    final horizontal = media.size.width >= 900 ? 28.0 : 14.0;
    final content = Center(
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: maxWidth),
        child: Padding(
          padding: EdgeInsets.fromLTRB(horizontal, 8, horizontal, 14),
          child: child,
        ),
      ),
    );
    if (!scrollable) {
      return content;
    }
    return SingleChildScrollView(
      keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
      physics: const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
      child: content,
    );
  }
}

class AdaptiveColumns extends StatelessWidget {
  const AdaptiveColumns({
    required this.children,
    super.key,
    this.breakpoint = 760,
    this.gap = 14,
    this.leftFlex = 1,
    this.rightFlex = 1,
  });

  final List<Widget> children;
  final double breakpoint;
  final double gap;
  final int leftFlex;
  final int rightFlex;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth < breakpoint || children.length != 2) {
          return Column(
            children: [
              children.first,
              SizedBox(height: gap),
              if (children.length > 1) children[1],
            ],
          );
        }
        return Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(flex: leftFlex, child: children[0]),
            SizedBox(width: gap),
            Expanded(flex: rightFlex, child: children[1]),
          ],
        );
      },
    );
  }
}
