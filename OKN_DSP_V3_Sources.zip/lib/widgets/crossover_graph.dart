import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../models/dsp_models.dart';
import '../theme/app_theme.dart';

class CrossoverGraph extends StatelessWidget {
  const CrossoverGraph({required this.settings, super.key});

  final CrossoverSettings settings;

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 2.35,
      child: CustomPaint(painter: _CrossoverPainter(settings)),
    );
  }
}

class _CrossoverPainter extends CustomPainter {
  const _CrossoverPainter(this.settings);

  final CrossoverSettings settings;

  double _x(double frequency, double width) {
    final ratio = math.log(frequency / 20) / math.log(20000 / 20);
    return ratio.clamp(0.0, 1.0).toDouble() * width;
  }

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    canvas.drawRRect(
      RRect.fromRectAndRadius(rect, const Radius.circular(12)),
      Paint()..color = const Color(0xFF071426),
    );

    final grid = Paint()
      ..color = const Color(0xFF1A4160).withValues(alpha: 0.45)
      ..strokeWidth = 0.7;
    for (var i = 0; i <= 12; i++) {
      final x = size.width * i / 12;
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (var i = 0; i <= 6; i++) {
      final y = size.height * i / 6;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }

    _drawCurve(canvas, size, hpf: true);
    _drawCurve(canvas, size, hpf: false);
    _paintLabels(canvas, size);
  }

  void _drawCurve(Canvas canvas, Size size, {required bool hpf}) {
    final cutoff = hpf ? settings.hpfFrequencyHz : settings.lpfFrequencyHz;
    final bypass = hpf ? settings.hpfBypass : settings.lpfBypass;
    final slope = hpf ? settings.hpfSlope : settings.lpfSlope;
    final color = hpf ? AppColors.cyan : AppColors.pink;
    final path = Path();

    for (var i = 0; i <= 180; i++) {
      final x = size.width * i / 180;
      final logF = math.log(20) + (math.log(20000) - math.log(20)) * (i / 180);
      final f = math.exp(logF);
      double db;
      if (bypass) {
        db = 0;
      } else {
        final octaves = math.log(f / cutoff) / math.log(2);
        if (hpf) {
          db = octaves >= 0 ? 0 : (octaves * slope).clamp(-30.0, 0.0).toDouble();
        } else {
          db = octaves <= 0 ? 0 : (-octaves * slope).clamp(-30.0, 0.0).toDouble();
        }
      }
      final y = size.height * (1 - ((db + 30) / 36)).clamp(0.0, 1.0).toDouble();
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }

    canvas.drawPath(
      path,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 10
        ..color = color.withValues(alpha: 0.13)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8),
    );
    canvas.drawPath(
      path,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.6
        ..color = color,
    );

    final nodeX = _x(cutoff, size.width);
    final nodeY = size.height * (1 - (30 / 36));
    canvas.drawCircle(
      Offset(nodeX, nodeY),
      12,
      Paint()
        ..color = color.withValues(alpha: 0.25)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8),
    );
    canvas.drawCircle(Offset(nodeX, nodeY), 7, Paint()..color = Colors.white);
    canvas.drawCircle(Offset(nodeX, nodeY), 4.5, Paint()..color = color);
  }

  void _paintLabels(Canvas canvas, Size size) {
    const frequencies = [20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000];
    for (final f in frequencies) {
      final x = _x(f.toDouble(), size.width);
      final label = f >= 1000 ? '${(f / 1000).round()}k' : '$f';
      final tp = TextPainter(
        text: TextSpan(text: label, style: const TextStyle(fontSize: 9, color: AppColors.textMuted)),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, Offset((x - tp.width / 2).clamp(0.0, size.width - tp.width).toDouble(), size.height - tp.height - 2));
    }
    for (final db in [-24, -12, -6, 0, 6, 12]) {
      final y = size.height * (1 - ((db + 30) / 36)).clamp(0.0, 1.0).toDouble();
      final tp = TextPainter(
        text: TextSpan(text: db > 0 ? '+$db' : '$db', style: const TextStyle(fontSize: 9, color: AppColors.textMuted)),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, Offset(3, (y - tp.height / 2).clamp(0.0, size.height - tp.height).toDouble()));
    }
  }

  @override
  bool shouldRepaint(covariant _CrossoverPainter oldDelegate) => oldDelegate.settings != settings;
}
