import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

class DspLogo extends StatelessWidget {
  const DspLogo({super.key, this.size = 44});

  final double size;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(painter: _DspLogoPainter()),
    );
  }
}

class _DspLogoPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final glow = Paint()
      ..color = AppColors.cyan.withValues(alpha: 0.28)
      ..strokeCap = StrokeCap.round
      ..strokeWidth = size.width * 0.10
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8);
    final core = Paint()
      ..color = AppColors.cyan
      ..strokeCap = StrokeCap.round
      ..strokeWidth = size.width * 0.075;
    const heights = [0.42, 0.70, 0.96, 0.72, 0.44];
    for (var i = 0; i < heights.length; i++) {
      final x = size.width * (0.13 + i * 0.185);
      final half = size.height * heights[i] / 2;
      final centerY = size.height / 2;
      canvas.drawLine(Offset(x, centerY - half), Offset(x, centerY + half), glow);
      canvas.drawLine(Offset(x, centerY - half), Offset(x, centerY + half), core);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
