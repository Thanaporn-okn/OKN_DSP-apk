import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../models/dsp_models.dart';
import '../theme/app_theme.dart';

class InteractiveEqGraph extends StatefulWidget {
  const InteractiveEqGraph({
    required this.bands,
    required this.onBandChanged,
    super.key,
  });

  final List<ValueNotifier<EqBand>> bands;
  final void Function(int index, EqBand value) onBandChanged;

  @override
  State<InteractiveEqGraph> createState() => _InteractiveEqGraphState();
}

class _InteractiveEqGraphState extends State<InteractiveEqGraph> {
  int? _dragBand;

  static double _xForFrequency(double frequency, double width) {
    final ratio = math.log(frequency / 20) / math.log(20000 / 20);
    return ratio.clamp(0.0, 1.0).toDouble() * width;
  }

  static double _frequencyForX(double x, double width) {
    final ratio = (x / width).clamp(0.0, 1.0).toDouble();
    return 20 * math.pow(1000, ratio).toDouble();
  }

  static double _yForGain(double gain, double height) {
    return ((12 - gain) / 24).clamp(0.0, 1.0).toDouble() * height;
  }

  static double _gainForY(double y, double height) {
    return (12 - (y / height).clamp(0.0, 1.0).toDouble() * 24).clamp(-12.0, 12.0).toDouble();
  }

  void _startDrag(Offset local, Size size) {
    var best = double.infinity;
    int? bestIndex;
    for (var i = 0; i < widget.bands.length; i++) {
      final band = widget.bands[i].value;
      if (!band.enabled) continue;
      final point = Offset(
        _xForFrequency(band.frequencyHz, size.width),
        _yForGain(band.gainDb, size.height),
      );
      final d = (point - local).distanceSquared;
      if (d < best) {
        best = d;
        bestIndex = i;
      }
    }
    if (bestIndex != null && best < 1800) {
      setState(() => _dragBand = bestIndex);
      _updateDrag(local, size);
    }
  }

  void _updateDrag(Offset local, Size size) {
    final index = _dragBand;
    if (index == null) return;
    final current = widget.bands[index].value;
    final frequency = _frequencyForX(local.dx, size.width).clamp(20.0, 20000.0).toDouble();
    final gain = _gainForY(local.dy, size.height);
    widget.onBandChanged(
      index,
      current.copyWith(
        frequencyHz: double.parse(frequency.toStringAsFixed(1)),
        gainDb: double.parse(gain.toStringAsFixed(1)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 2.25,
      child: LayoutBuilder(
        builder: (context, constraints) {
          final size = Size(constraints.maxWidth, constraints.maxHeight);
          return GestureDetector(
            behavior: HitTestBehavior.opaque,
            onPanStart: (details) => _startDrag(details.localPosition, size),
            onPanUpdate: (details) => _updateDrag(details.localPosition, size),
            onPanEnd: (_) => setState(() => _dragBand = null),
            onPanCancel: () => setState(() => _dragBand = null),
            child: AnimatedBuilder(
              animation: Listenable.merge(widget.bands),
              builder: (context, _) {
                return CustomPaint(
                  painter: _EqPainter(
                    bands: widget.bands.map((e) => e.value).toList(growable: false),
                    dragBand: _dragBand,
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}

class _EqPainter extends CustomPainter {
  const _EqPainter({required this.bands, required this.dragBand});

  final List<EqBand> bands;
  final int? dragBand;

  @override
  void paint(Canvas canvas, Size size) {
    final background = RRect.fromRectAndRadius(Offset.zero & size, const Radius.circular(12));
    canvas.drawRRect(background, Paint()..color = const Color(0xFF071426));

    final grid = Paint()
      ..color = const Color(0xFF1A4160).withValues(alpha: 0.45)
      ..strokeWidth = 0.7;
    for (var i = 0; i <= 12; i++) {
      final x = size.width * i / 12;
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (var i = 0; i <= 8; i++) {
      final y = size.height * i / 8;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
    canvas.drawLine(
      Offset(0, size.height / 2),
      Offset(size.width, size.height / 2),
      Paint()..color = AppColors.textMuted.withValues(alpha: 0.45),
    );

    final active = <({int index, EqBand band, Offset point})>[];
    for (var i = 0; i < bands.length; i++) {
      final band = bands[i];
      if (!band.enabled) continue;
      active.add((
        index: i,
        band: band,
        point: Offset(
          _InteractiveEqGraphState._xForFrequency(band.frequencyHz, size.width),
          _InteractiveEqGraphState._yForGain(band.gainDb, size.height),
        ),
      ));
    }
    active.sort((a, b) => a.point.dx.compareTo(b.point.dx));

    if (active.length >= 2) {
      final path = Path()..moveTo(active.first.point.dx, active.first.point.dy);
      for (var i = 0; i < active.length - 1; i++) {
        final a = active[i].point;
        final b = active[i + 1].point;
        final midX = (a.dx + b.dx) / 2;
        path.cubicTo(midX, a.dy, midX, b.dy, b.dx, b.dy);
      }
      final glow = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 8
        ..color = AppColors.cyan.withValues(alpha: 0.16)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8);
      canvas.drawPath(path, glow);
      final line = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.5
        ..shader = const LinearGradient(
          colors: [AppColors.pink, AppColors.orange, AppColors.yellow, AppColors.green, AppColors.cyan, AppColors.purple],
        ).createShader(Offset.zero & size);
      canvas.drawPath(path, line);
    }

    for (final entry in active) {
      final radius = entry.index == dragBand ? 8.5 : 6.5;
      canvas.drawCircle(
        entry.point,
        radius + 7,
        Paint()
          ..color = entry.band.color.withValues(alpha: 0.30)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8),
      );
      canvas.drawCircle(entry.point, radius, Paint()..color = entry.band.color);
      canvas.drawCircle(
        entry.point,
        radius - 2.2,
        Paint()..color = const Color(0xFF0E2440),
      );
    }

    _paintLabels(canvas, size);
  }

  void _paintLabels(Canvas canvas, Size size) {
    const frequencies = [20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000];
    for (final f in frequencies) {
      final x = _InteractiveEqGraphState._xForFrequency(f.toDouble(), size.width);
      final text = f >= 1000 ? '${(f / 1000).toStringAsFixed(f % 1000 == 0 ? 0 : 1)}k' : '$f';
      final tp = TextPainter(
        text: TextSpan(text: text, style: const TextStyle(fontSize: 9, color: AppColors.textMuted)),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, Offset((x - tp.width / 2).clamp(0.0, size.width - tp.width).toDouble(), size.height - tp.height - 2));
    }
    for (final db in [-12, -6, 0, 6, 12]) {
      final y = _InteractiveEqGraphState._yForGain(db.toDouble(), size.height);
      final tp = TextPainter(
        text: TextSpan(text: db > 0 ? '+$db' : '$db', style: const TextStyle(fontSize: 9, color: AppColors.textMuted)),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, Offset(3, (y - tp.height / 2).clamp(0.0, size.height - tp.height).toDouble()));
    }
  }

  @override
  bool shouldRepaint(covariant _EqPainter oldDelegate) => true;
}
