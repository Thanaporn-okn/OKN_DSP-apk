import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import 'glass_card.dart';

class DspBottomNav extends StatelessWidget {
  const DspBottomNav({required this.index, required this.onChanged, super.key});

  final int index;
  final ValueChanged<int> onChanged;

  static const items = <({IconData icon, String label})>[
    (icon: Icons.home_rounded, label: 'Home'),
    (icon: Icons.graphic_eq_rounded, label: 'EQ'),
    (icon: Icons.multiline_chart_rounded, label: 'Crossover'),
    (icon: Icons.access_time_filled_rounded, label: 'Delay'),
    (icon: Icons.bar_chart_rounded, label: 'Output'),
  ];

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      padding: const EdgeInsets.all(5),
      borderRadius: 17,
      child: Row(
        children: [
          for (var i = 0; i < items.length; i++)
            Expanded(
              child: _NavItem(
                icon: items[i].icon,
                label: items[i].label,
                active: i == index,
                onTap: () => onChanged(i),
              ),
            ),
        ],
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  const _NavItem({
    required this.icon,
    required this.label,
    required this.active,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(13),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 110),
          padding: const EdgeInsets.symmetric(vertical: 9),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(13),
            gradient: active
                ? LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      AppColors.blue.withValues(alpha: 0.72),
                      AppColors.blue.withValues(alpha: 0.25),
                    ],
                  )
                : null,
            boxShadow: active
                ? [BoxShadow(color: AppColors.blue.withValues(alpha: 0.28), blurRadius: 16)]
                : null,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                icon,
                color: active ? AppColors.cyan : AppColors.textMuted,
                size: 25,
              ),
              const SizedBox(height: 3),
              FittedBox(
                child: Text(
                  label,
                  style: TextStyle(
                    color: active ? AppColors.text : AppColors.textMuted,
                    fontWeight: active ? FontWeight.w700 : FontWeight.w500,
                    fontSize: 11,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
