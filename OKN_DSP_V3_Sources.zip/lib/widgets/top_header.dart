import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_reactive_ble/flutter_reactive_ble.dart';

import '../controllers/dsp_controller.dart';
import '../services/ble_dsp_service.dart';
import '../theme/app_theme.dart';
import 'dsp_logo.dart';

class TopHeader extends StatelessWidget {
  const TopHeader({required this.controller, super.key, this.homeBrand = false});

  final DspController controller;
  final bool homeBrand;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final compact = constraints.maxWidth < 560;
        final title = homeBrand ? 'OKN_DSP' : 'DSP Control';
        return Padding(
          padding: const EdgeInsets.only(top: 4, bottom: 10),
          child: Row(
            children: [
              const DspLogo(size: 50),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    FittedBox(
                      fit: BoxFit.scaleDown,
                      alignment: Alignment.centerLeft,
                      child: Text(
                        title,
                        style: TextStyle(
                          fontSize: compact ? 25 : 31,
                          fontWeight: FontWeight.w900,
                          letterSpacing: -0.4,
                          color: AppColors.text,
                        ),
                      ),
                    ),
                    Text(
                      'Professional Audio Processor',
                      maxLines: 1,
                      overflow: TextOverflow.fade,
                      style: TextStyle(
                        color: AppColors.textMuted,
                        fontSize: compact ? 11 : 13,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              _ConnectionButton(controller: controller, compact: compact),
              if (!compact) ...[
                const SizedBox(width: 8),
                IconButton(
                  onPressed: () => _showSettings(context, controller),
                  icon: const Icon(Icons.settings_outlined, color: AppColors.text),
                  tooltip: 'Settings',
                ),
              ],
            ],
          ),
        );
      },
    );
  }

  static Future<void> _showSettings(BuildContext context, DspController controller) async {
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppColors.background,
      showDragHandle: true,
      builder: (context) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'OKN_DSP Settings',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 12),
                Text('Application version: ${DspController.appVersion}'),
                const SizedBox(height: 8),
                const Text(
                  'BLE target characteristic: 0000AB01-0000-1000-8000-00805F9B34FB',
                  style: TextStyle(color: AppColors.textMuted),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Hardware byte-frame mapping is intentionally disabled until the real DSP command protocol is supplied. UI state and BLE transport remain fully operational.',
                  style: TextStyle(color: AppColors.textMuted),
                ),
                const SizedBox(height: 18),
                FilledButton.icon(
                  onPressed: () async {
                    await controller.bleService.disconnect();
                    if (context.mounted) Navigator.of(context).pop();
                  },
                  icon: const Icon(Icons.bluetooth_disabled),
                  label: const Text('Disconnect BLE'),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _ConnectionButton extends StatelessWidget {
  const _ConnectionButton({required this.controller, required this.compact});

  final DspController controller;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<DeviceConnectionState>(
      valueListenable: controller.bleService.connectionState,
      builder: (context, state, _) {
        final connected = state == DeviceConnectionState.connected;
        final connecting = state == DeviceConnectionState.connecting;
        return Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: () => _openDevicePicker(context),
            child: Container(
              constraints: BoxConstraints(minWidth: compact ? 122 : 176),
              padding: EdgeInsets.symmetric(
                horizontal: compact ? 9 : 13,
                vertical: compact ? 8 : 9,
              ),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: AppColors.border),
                color: const Color(0xFF0A1A2D),
                boxShadow: [
                  BoxShadow(
                    color: (connected ? AppColors.green : AppColors.blue).withValues(alpha: 0.12),
                    blurRadius: 16,
                  ),
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (connecting)
                    const SizedBox(
                      width: 14,
                      height: 14,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  else
                    Container(
                      width: 13,
                      height: 13,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: connected ? AppColors.green : AppColors.orange,
                        boxShadow: [
                          BoxShadow(
                            color: (connected ? AppColors.green : AppColors.orange)
                                .withValues(alpha: 0.55),
                            blurRadius: 9,
                          ),
                        ],
                      ),
                    ),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          connected ? 'Connected' : connecting ? 'Connecting' : 'Connect',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: connected ? AppColors.green : AppColors.text,
                            fontWeight: FontWeight.w800,
                            fontSize: compact ? 12 : 13,
                          ),
                        ),
                        ValueListenableBuilder<String>(
                          valueListenable: controller.bleService.connectedDeviceName,
                          builder: (_, name, __) => Text(
                            name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(color: AppColors.textMuted, fontSize: 11),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 5),
                  const Icon(Icons.chevron_right, size: 20, color: AppColors.textMuted),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Future<void> _openDevicePicker(BuildContext context) async {
    await showDialog<void>(
      context: context,
      builder: (_) => BleDeviceDialog(service: controller.bleService),
    );
  }
}

class BleDeviceDialog extends StatefulWidget {
  const BleDeviceDialog({required this.service, super.key});

  final BleDspService service;

  @override
  State<BleDeviceDialog> createState() => _BleDeviceDialogState();
}

class _BleDeviceDialogState extends State<BleDeviceDialog> {
  StreamSubscription<DiscoveredDevice>? _sub;
  final Map<String, DiscoveredDevice> _devices = {};
  bool _scanning = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _startScan();
  }

  void _startScan() {
    _sub?.cancel();
    setState(() {
      _scanning = true;
      _error = null;
      _devices.clear();
    });
    _sub = widget.service.scan().listen(
      (device) {
        if (!mounted) return;
        setState(() => _devices[device.id] = device);
      },
      onError: (Object error) {
        if (!mounted) return;
        setState(() {
          _scanning = false;
          if (error is! TimeoutException) _error = '$error';
        });
      },
      onDone: () {
        if (mounted) setState(() => _scanning = false);
      },
      cancelOnError: false,
    );
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final devices = _devices.values.toList()
      ..sort((a, b) {
        final aDsp = a.name.toUpperCase().contains('DSP') ? 1 : 0;
        final bDsp = b.name.toUpperCase().contains('DSP') ? 1 : 0;
        final priority = bDsp.compareTo(aDsp);
        return priority != 0 ? priority : b.rssi.compareTo(a.rssi);
      });

    return Dialog(
      backgroundColor: AppColors.background,
      insetPadding: const EdgeInsets.all(18),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 560, maxHeight: 620),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Row(
                children: [
                  const Icon(Icons.bluetooth_searching, color: AppColors.cyan),
                  const SizedBox(width: 10),
                  const Expanded(
                    child: Text(
                      'Select DSP device',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                    ),
                  ),
                  IconButton(
                    onPressed: _startScan,
                    icon: const Icon(Icons.refresh),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              if (_scanning) const LinearProgressIndicator(minHeight: 2),
              if (_error != null)
                Padding(
                  padding: const EdgeInsets.all(8),
                  child: Text(_error!, style: const TextStyle(color: AppColors.orange)),
                ),
              Expanded(
                child: devices.isEmpty
                    ? const Center(
                        child: Text(
                          'Scanning for nearby BLE devices…',
                          style: TextStyle(color: AppColors.textMuted),
                        ),
                      )
                    : ListView.separated(
                        itemCount: devices.length,
                        separatorBuilder: (_, __) => const Divider(height: 1),
                        itemBuilder: (context, index) {
                          final device = devices[index];
                          return ListTile(
                            leading: const Icon(Icons.memory, color: AppColors.cyan),
                            title: Text(
                              device.name.trim().isEmpty ? 'Unnamed BLE device' : device.name,
                            ),
                            subtitle: Text('${device.id}  •  RSSI ${device.rssi} dBm'),
                            trailing: const Icon(Icons.chevron_right),
                            onTap: () async {
                              try {
                                await widget.service.connect(device);
                                if (context.mounted) Navigator.of(context).pop();
                              } catch (error) {
                                if (!context.mounted) return;
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text('Connection failed: $error')),
                                );
                              }
                            },
                          );
                        },
                      ),
              ),
              const SizedBox(height: 8),
              const Text(
                'The app discovers the known AB01 DSP characteristic after connection.',
                style: TextStyle(color: AppColors.textMuted, fontSize: 11),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
