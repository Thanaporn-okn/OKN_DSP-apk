import 'package:flutter/material.dart';

import '../models/dsp_models.dart';
import '../theme/app_theme.dart';

class ChannelSelector extends StatelessWidget {
  const ChannelSelector({
    required this.selectedIndex,
    required this.onSelected,
    super.key,
  });

  final int selectedIndex;
  final ValueChanged<int> onSelected;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final compact = constraints.maxWidth < 700;
        if (compact) {
          return SizedBox(
            height: 72,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: dspChannels.length,
              separatorBuilder: (_, __) => const SizedBox(width: 7),
              itemBuilder: (context, index) => _ChannelButton(
                channel: dspChannels[index],
                active: index == selectedIndex,
                onTap: () => onSelected(index),
                width: 98,
              ),
            ),
          );
        }
        return Row(
          children: [
            for (var i = 0; i < dspChannels.length; i++) ...[
              Expanded(
                child: _ChannelButton(
                  channel: dspChannels[i],
                  active: i == selectedIndex,
                  onTap: () => onSelected(i),
                ),
              ),
              if (i < dspChannels.length - 1) const SizedBox(width: 7),
            ],
          ],
        );
      },
    );
  }
}

class _ChannelButton extends StatelessWidget {
  const _ChannelButton({
    required this.channel,
    required this.active,
    required this.onTap,
    this.width,
  });

  final DspChannel channel;
  final bool active;
  final VoidCallback onTap;
  final double? width;

  @override
  Widget build(BuildContext context) {
    final color = active ? AppColors.cyan : AppColors.border;
    return SizedBox(
      width: width,
      child: Material(
        color: active ? const Color(0xFF043D7A) : const Color(0xFF0A1B30),
        borderRadius: BorderRadius.circular(11),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(11),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 100),
            height: 70,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(11),
              border: Border.all(color: color, width: active ? 1.4 : 1),
              boxShadow: active
                  ? [
                      BoxShadow(
                        color: AppColors.cyan.withValues(alpha: 0.30),
                        blurRadius: 18,
                      ),
                    ]
                  : null,
              gradient: active
                  ? LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        AppColors.blue.withValues(alpha: 0.95),
                        AppColors.cyan.withValues(alpha: 0.60),
                      ],
                    )
                  : null,
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  channel.shortName,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                    fontSize: 15,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  channel.name,
                  style: TextStyle(
                    color: active ? Colors.white : AppColors.textMuted,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
