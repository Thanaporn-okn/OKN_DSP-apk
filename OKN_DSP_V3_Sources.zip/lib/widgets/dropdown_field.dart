import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

class DspDropdown<T> extends StatelessWidget {
  const DspDropdown({
    required this.value,
    required this.items,
    required this.labelBuilder,
    required this.onChanged,
    super.key,
    this.label,
  });

  final T value;
  final List<T> items;
  final String Function(T value) labelBuilder;
  final ValueChanged<T> onChanged;
  final String? label;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (label != null) ...[
          Text(label!, style: const TextStyle(color: AppColors.textMuted, fontSize: 12)),
          const SizedBox(height: 5),
        ],
        Container(
          decoration: BoxDecoration(
            color: const Color(0xFF0A1930),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.border),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<T>(
              value: value,
              isExpanded: true,
              dropdownColor: AppColors.surface2,
              borderRadius: BorderRadius.circular(12),
              icon: const Icon(Icons.keyboard_arrow_down, color: AppColors.textMuted),
              items: [
                for (final item in items)
                  DropdownMenuItem<T>(
                    value: item,
                    child: Text(
                      labelBuilder(item),
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: AppColors.text),
                    ),
                  ),
              ],
              onChanged: (item) {
                if (item != null) onChanged(item);
              },
            ),
          ),
        ),
      ],
    );
  }
}
