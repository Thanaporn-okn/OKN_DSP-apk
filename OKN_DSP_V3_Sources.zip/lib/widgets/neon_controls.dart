import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

class NeonSlider extends StatelessWidget {
  const NeonSlider({
    required this.value,
    required this.min,
    required this.max,
    required this.onChanged,
    super.key,
    this.color = AppColors.cyan,
    this.divisions,
  });

  final double value;
  final double min;
  final double max;
  final ValueChanged<double> onChanged;
  final Color color;
  final int? divisions;

  @override
  Widget build(BuildContext context) {
    return SliderTheme(
      data: SliderTheme.of(context).copyWith(
        activeTrackColor: color,
        inactiveTrackColor: const Color(0xFF214A70),
        thumbColor: Colors.white,
        overlayColor: color.withValues(alpha: 0.15),
        valueIndicatorColor: color,
        thumbShape: _GlowThumb(color: color),
      ),
      child: Slider(
        value: value.clamp(min, max).toDouble(),
        min: min,
        max: max,
        divisions: divisions,
        onChanged: onChanged,
      ),
    );
  }
}

class _GlowThumb extends SliderComponentShape {
  const _GlowThumb({required this.color});

  final Color color;

  @override
  Size getPreferredSize(bool isEnabled, bool isDiscrete) => const Size.square(28);

  @override
  void paint(
    PaintingContext context,
    Offset center, {
    required Animation<double> activationAnimation,
    required Animation<double> enableAnimation,
    required bool isDiscrete,
    required TextPainter labelPainter,
    required RenderBox parentBox,
    required SliderThemeData sliderTheme,
    required TextDirection textDirection,
    required double value,
    required double textScaleFactor,
    required Size sizeWithOverflow,
  }) {
    final canvas = context.canvas;
    canvas.drawCircle(
      center,
      17,
      Paint()
        ..color = color.withValues(alpha: 0.30)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12),
    );
    canvas.drawCircle(center, 11, Paint()..color = Colors.white);
  }
}

class NeonSwitch extends StatelessWidget {
  const NeonSwitch({
    required this.value,
    required this.onChanged,
    super.key,
    this.color = AppColors.blue,
  });

  final bool value;
  final ValueChanged<bool> onChanged;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Switch(
      value: value,
      onChanged: onChanged,
      activeTrackColor: color,
      activeThumbColor: Colors.white,
      inactiveTrackColor: const Color(0xFF233B5D),
      inactiveThumbColor: Colors.white,
    );
  }
}

class ValuePill extends StatelessWidget {
  const ValuePill({required this.text, super.key, this.color = AppColors.border});

  final String text;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 80),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: AppColors.surface.withValues(alpha: 0.75),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withValues(alpha: 0.8)),
      ),
      child: Text(
        text,
        textAlign: TextAlign.center,
        style: const TextStyle(
          color: AppColors.text,
          fontWeight: FontWeight.w800,
          fontSize: 16,
        ),
      ),
    );
  }
}

class NeonIconButton extends StatelessWidget {
  const NeonIconButton({
    required this.icon,
    required this.label,
    required this.onTap,
    super.key,
    this.active = false,
    this.color = AppColors.cyan,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool active;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: active ? color.withValues(alpha: 0.12) : Colors.transparent,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 100),
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: active ? color : AppColors.border,
              width: active ? 1.4 : 1,
            ),
            boxShadow: active
                ? [BoxShadow(color: color.withValues(alpha: 0.20), blurRadius: 16)]
                : null,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: active ? color : AppColors.textMuted, size: 22),
              const SizedBox(height: 4),
              Text(
                label,
                maxLines: 1,
                style: TextStyle(
                  fontSize: 11,
                  color: active ? AppColors.text : AppColors.textMuted,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
