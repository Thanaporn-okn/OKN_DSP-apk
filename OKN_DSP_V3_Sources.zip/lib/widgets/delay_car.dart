import 'package:flutter/material.dart';

import '../models/dsp_models.dart';
import '../theme/app_theme.dart';

class DelayCarDiagram extends StatelessWidget {
  const DelayCarDiagram({required this.delays, super.key});

  final List<ValueNotifier<double>> delays;

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 0.92,
      child: AnimatedBuilder(
        animation: Listenable.merge(delays),
        builder: (context, _) {
          return CustomPaint(
            painter: _DelayCarPainter(delays.map((e) => e.value).toList(growable: false)),
          );
        },
      ),
    );
  }
}

class _DelayCarPainter extends CustomPainter {
  const _DelayCarPainter(this.delays);

  final List<double> delays;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final car = RRect.fromRectAndRadius(
      Rect.fromCenter(center: Offset(w / 2, h * 0.52), width: w * 0.60, height: h * 0.78),
      Radius.circular(w * 0.18),
    );

    canvas.drawRRect(
      car,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 13
        ..color = AppColors.blue.withValues(alpha: 0.12)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10),
    );
    canvas.drawRRect(
      car,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = AppColors.blue.withValues(alpha: 0.78),
    );

    final windshield = RRect.fromRectAndRadius(
      Rect.fromCenter(center: Offset(w / 2, h * 0.32), width: w * 0.42, height: h * 0.18),
      Radius.circular(w * 0.08),
    );
    canvas.drawRRect(
      windshield,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.2
        ..color = AppColors.cyan.withValues(alpha: 0.45),
    );

    _seat(canvas, Offset(w * 0.42, h * 0.43), w * 0.12, h * 0.17);
    _seat(canvas, Offset(w * 0.58, h * 0.43), w * 0.12, h * 0.17);
    _seat(canvas, Offset(w * 0.42, h * 0.65), w * 0.12, h * 0.17);
    _seat(canvas, Offset(w * 0.58, h * 0.65), w * 0.12, h * 0.17);

    final points = <Offset>[
      Offset(w * 0.23, h * 0.38),
      Offset(w * 0.77, h * 0.38),
      Offset(w * 0.21, h * 0.68),
      Offset(w * 0.79, h * 0.68),
      Offset(w * 0.50, h * 0.18),
      Offset(w * 0.50, h * 0.86),
      Offset(w * 0.50, h * 0.94),
    ];
    final colors = dspChannels.map((c) => c.color).toList(growable: false);

    for (var i = 0; i < points.length; i++) {
      _speaker(canvas, points[i], colors[i], delays[i], i, size);
    }
  }

  void _seat(Canvas canvas, Offset center, double width, double height) {
    final rect = RRect.fromRectAndRadius(
      Rect.fromCenter(center: center, width: width, height: height),
      Radius.circular(width * 0.28),
    );
    canvas.drawRRect(rect, Paint()..color = AppColors.blue.withValues(alpha: 0.12));
    canvas.drawRRect(
      rect,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.2
        ..color = AppColors.blue.withValues(alpha: 0.55),
    );
  }

  void _speaker(Canvas canvas, Offset center, Color color, double delay, int index, Size size) {
    for (final radius in [27.0, 20.0, 14.0]) {
      canvas.drawCircle(
        center,
        radius,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1
          ..color = color.withValues(alpha: radius == 14 ? 0.55 : 0.16),
      );
    }
    canvas.drawCircle(
      center,
      16,
      Paint()
        ..color = color.withValues(alpha: 0.28)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10),
    );
    canvas.drawCircle(center, 10, Paint()..color = color);
    canvas.drawCircle(center, 5, Paint()..color = const Color(0xFF10243B));

    final above = index == 4;
    final below = index >= 5;
    final left = index == 0 || index == 2;
    final text = '${delay.toStringAsFixed(2)} ms';
    final tp = TextPainter(
      text: TextSpan(
        text: text,
        style: const TextStyle(color: AppColors.text, fontWeight: FontWeight.w700, fontSize: 11),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    Offset textOffset;
    if (above) {
      textOffset = Offset(center.dx - tp.width / 2, center.dy - 33);
    } else if (below) {
      textOffset = Offset(center.dx - tp.width / 2, center.dy + 18);
    } else if (left) {
      textOffset = Offset((center.dx - tp.width - 18).clamp(2.0, size.width - tp.width - 2).toDouble(), center.dy - tp.height / 2);
    } else {
      textOffset = Offset((center.dx + 18).clamp(2.0, size.width - tp.width - 2).toDouble(), center.dy - tp.height / 2);
    }
    tp.paint(canvas, textOffset);
  }

  @override
  bool shouldRepaint(covariant _DelayCarPainter oldDelegate) => true;
}
