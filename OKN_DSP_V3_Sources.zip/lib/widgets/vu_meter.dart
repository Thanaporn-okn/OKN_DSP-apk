import 'package:flutter/material.dart';

import '../models/dsp_models.dart';
import '../theme/app_theme.dart';

class OutputVuOverview extends StatelessWidget {
  const OutputVuOverview({required this.channels, super.key});

  final List<ValueNotifier<OutputChannelState>> channels;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 160,
      child: AnimatedBuilder(
        animation: Listenable.merge(channels),
        builder: (context, _) {
          return CustomPaint(
            painter: _VuPainter(channels.map((e) => e.value).toList(growable: false)),
          );
        },
      ),
    );
  }
}

class _VuPainter extends CustomPainter {
  const _VuPainter(this.states);

  final List<OutputChannelState> states;

  @override
  void paint(Canvas canvas, Size size) {
    const topPad = 12.0;
    const bottomPad = 30.0;
    final graphHeight = size.height - topPad - bottomPad;
    final meterWidth = size.width / 7;
    const segments = 15;

    for (var channel = 0; channel < 7; channel++) {
      final info = dspChannels[channel];
      final state = states[channel];
      final normalized = state.muted
          ? 0.0
          : ((state.levelDb + 60) / 72).clamp(0.0, 1.0).toDouble();
      final lit = (segments * normalized).round();
      final centerX = meterWidth * channel + meterWidth / 2;
      final segmentW = (meterWidth * 0.38).clamp(7.0, 22.0).toDouble();
      final segmentH = (graphHeight / segments) * 0.55;
      final gap = graphHeight / segments;

      for (var s = 0; s < segments; s++) {
        final active = s < lit;
        final y = topPad + graphHeight - gap * (s + 1);
        final rect = RRect.fromRectAndRadius(
          Rect.fromCenter(center: Offset(centerX, y), width: segmentW, height: segmentH),
          const Radius.circular(2),
        );
        final color = active ? info.color : const Color(0xFF15334C);
        if (active) {
          canvas.drawRRect(
            rect,
            Paint()
              ..color = color.withValues(alpha: 0.28)
              ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
          );
        }
        canvas.drawRRect(rect, Paint()..color = color.withValues(alpha: active ? 0.95 : 0.48));
      }

      final label = TextPainter(
        text: TextSpan(
          text: 'CH${channel + 1}',
          style: const TextStyle(color: AppColors.text, fontSize: 10, fontWeight: FontWeight.w700),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      label.paint(canvas, Offset(centerX - label.width / 2, size.height - 25));

      final name = TextPainter(
        text: TextSpan(
          text: info.name,
          style: const TextStyle(color: AppColors.textMuted, fontSize: 8),
        ),
        textDirection: TextDirection.ltr,
      )..layout(maxWidth: meterWidth - 4);
      name.paint(canvas, Offset(centerX - name.width / 2, size.height - 12));
    }
  }

  @override
  bool shouldRepaint(covariant _VuPainter oldDelegate) => true;
}
