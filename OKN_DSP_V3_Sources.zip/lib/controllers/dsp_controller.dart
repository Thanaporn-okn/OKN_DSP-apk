import 'package:flutter/foundation.dart';

import '../models/dsp_models.dart';
import '../services/ble_dsp_service.dart';
import '../services/dsp_command_gateway.dart';
import '../theme/app_theme.dart';

class DspController {
  DspController({required this.gateway, required this.bleService}) {
    eqBands = List.generate(7, (channel) {
      return List.generate(15, (band) => ValueNotifier(_initialBand(band)));
    });
    crossovers = List.generate(
      7,
      (_) => ValueNotifier(
        const CrossoverSettings(
          hpfFamily: FilterFamily.linkwitzRiley,
          hpfFrequencyHz: 100,
          hpfSlope: 24,
          hpfBypass: false,
          lpfFamily: FilterFamily.linkwitzRiley,
          lpfFrequencyHz: 1000,
          lpfSlope: 24,
          lpfBypass: false,
          phaseDegrees: 0,
          polarity: PolarityMode.normal,
          linkLR: true,
          outputMode: OutputMode.stereo,
        ),
      ),
    );
    delaysMs = <double>[0, 1.25, 2.60, 2.30, 0.80, 3.10, 1.90]
        .map(ValueNotifier<double>.new)
        .toList(growable: false);
    outputChannels = <double>[-3, -2.5, -4, -1, -2, -3.5, -4.5]
        .map(
          (level) => ValueNotifier(
            OutputChannelState(
              levelDb: level,
              muted: false,
              solo: false,
              phaseInverted: false,
              linked: false,
            ),
          ),
        )
        .toList(growable: false);
  }

  final DspCommandGateway gateway;
  final BleDspService bleService;

  static const appVersion = 'V1';

  final pageIndex = ValueNotifier<int>(0);
  final selectedChannel = ValueNotifier<int>(0);
  final eqBandGroup = ValueNotifier<int>(0);

  final masterVolumeDb = ValueNotifier<double>(-3);
  final bassVolumeDb = ValueNotifier<double>(4);
  final bassCutoffHz = ValueNotifier<double>(100);
  final bassBoostDb = ValueNotifier<double>(3);
  final middleBoostDb = ValueNotifier<double>(-2);
  final trebleBoostDb = ValueNotifier<double>(1);
  final audioSource = ValueNotifier<String>('High Level (Speaker)');
  final systemPreset = ValueNotifier<String>('Flat');
  final voltage = ValueNotifier<double>(13.6);
  final temperatureC = ValueNotifier<double>(42);

  late final List<List<ValueNotifier<EqBand>>> eqBands;
  late final List<ValueNotifier<CrossoverSettings>> crossovers;
  late final List<ValueNotifier<double>> delaysMs;
  late final List<ValueNotifier<OutputChannelState>> outputChannels;

  final delayUnitMs = ValueNotifier<bool>(true);
  final seatPreset = ValueNotifier<String>('Driver (Left)');
  final masterOutputDb = ValueNotifier<double>(-1);

  static EqBand _initialBand(int index) {
    const frequencies = <double>[
      32,
      100,
      200,
      500,
      2000,
      10000,
      63,
      125,
      250,
      1000,
      4000,
      16000,
      80,
      800,
      8000,
    ];
    const gains = <double>[
      -3,
      2.5,
      6,
      -4,
      3,
      -2,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
    ];
    const colors = [
      AppColors.pink,
      AppColors.orange,
      AppColors.yellow,
      AppColors.green,
      AppColors.cyan,
      AppColors.purple,
      AppColors.blue,
      AppColors.pink,
      AppColors.orange,
      AppColors.yellow,
      AppColors.green,
      AppColors.cyan,
      AppColors.purple,
      AppColors.blue,
      AppColors.pink,
    ];
    final type = index == 1
        ? EqFilterType.lowShelf
        : index == 5
            ? EqFilterType.highShelf
            : EqFilterType.peq;
    return EqBand(
      type: type,
      frequencyHz: frequencies[index],
      gainDb: gains[index],
      q: index == 0 || index == 5 ? 0.70 : (index == 2 ? 1.20 : 1.00),
      enabled: true,
      color: colors[index],
    );
  }

  void setPage(int value) => pageIndex.value = value.clamp(0, 4).toInt();

  void setSelectedChannel(int value) {
    selectedChannel.value = value.clamp(0, 6).toInt();
  }

  void setHomeValue(String key, double value) {
    final command = DspControlCommand(path: 'home/$key', value: value);
    switch (key) {
      case 'masterVolumeDb':
        masterVolumeDb.value = value;
      case 'bassVolumeDb':
        bassVolumeDb.value = value;
      case 'bassCutoffHz':
        bassCutoffHz.value = value;
      case 'bassBoostDb':
        bassBoostDb.value = value;
      case 'middleBoostDb':
        middleBoostDb.value = value;
      case 'trebleBoostDb':
        trebleBoostDb.value = value;
      default:
        return;
    }
    gateway.dispatch(command);
  }

  void setAudioSource(String value) {
    audioSource.value = value;
    gateway.dispatch(DspControlCommand(path: 'home/audioSource', value: value));
  }

  void setSystemPreset(String value) {
    systemPreset.value = value;
    gateway.dispatch(DspControlCommand(path: 'home/systemPreset', value: value));
  }

  void updateEqBand(int channel, int band, EqBand value) {
    eqBands[channel][band].value = value;
    gateway.dispatch(
      DspControlCommand(
        path: 'eq/band',
        value: <String, Object>{
          'type': value.type.name,
          'frequencyHz': value.frequencyHz,
          'gainDb': value.gainDb,
          'q': value.q,
          'enabled': value.enabled,
        },
        channel: channel + 1,
        band: band + 1,
      ),
    );
  }

  void resetEq(int channel) {
    for (var band = 0; band < 15; band++) {
      eqBands[channel][band].value = _initialBand(band);
    }
    gateway.dispatch(
      DspControlCommand(path: 'eq/reset', value: true, channel: channel + 1),
    );
  }

  void updateCrossover(int channel, CrossoverSettings value) {
    crossovers[channel].value = value;
    gateway.dispatch(
      DspControlCommand(
        path: 'crossover/settings',
        value: <String, Object>{
          'hpfFamily': value.hpfFamily.name,
          'hpfFrequencyHz': value.hpfFrequencyHz,
          'hpfSlope': value.hpfSlope,
          'hpfBypass': value.hpfBypass,
          'lpfFamily': value.lpfFamily.name,
          'lpfFrequencyHz': value.lpfFrequencyHz,
          'lpfSlope': value.lpfSlope,
          'lpfBypass': value.lpfBypass,
          'phaseDegrees': value.phaseDegrees,
          'polarity': value.polarity.name,
          'linkLR': value.linkLR,
          'outputMode': value.outputMode.name,
        },
        channel: channel + 1,
      ),
    );
  }

  void resetCrossover(int channel) {
    updateCrossover(
      channel,
      const CrossoverSettings(
        hpfFamily: FilterFamily.linkwitzRiley,
        hpfFrequencyHz: 100,
        hpfSlope: 24,
        hpfBypass: false,
        lpfFamily: FilterFamily.linkwitzRiley,
        lpfFrequencyHz: 1000,
        lpfSlope: 24,
        lpfBypass: false,
        phaseDegrees: 0,
        polarity: PolarityMode.normal,
        linkLR: true,
        outputMode: OutputMode.stereo,
      ),
    );
  }

  void setDelay(int channel, double value) {
    final normalized = value.clamp(0.0, 10.0).toDouble();
    delaysMs[channel].value = normalized;
    gateway.dispatch(
      DspControlCommand(
        path: 'delay/ms',
        value: normalized,
        channel: channel + 1,
      ),
    );
  }

  void applySeatPreset(String preset) {
    seatPreset.value = preset;
    final values = switch (preset) {
      'Passenger (Right)' => <double>[1.25, 0, 2.30, 2.60, 0.80, 3.10, 1.90],
      'Center' => <double>[0.65, 0.65, 2.45, 2.45, 0, 3.10, 1.90],
      _ => <double>[0, 1.25, 2.60, 2.30, 0.80, 3.10, 1.90],
    };
    for (var i = 0; i < values.length; i++) {
      delaysMs[i].value = values[i];
    }
    gateway.dispatch(DspControlCommand(path: 'delay/seatPreset', value: preset));
  }

  void setMasterOutput(double value) {
    masterOutputDb.value = value;
    gateway.dispatch(DspControlCommand(path: 'output/masterDb', value: value));
  }

  void updateOutputChannel(int channel, OutputChannelState value) {
    outputChannels[channel].value = value;
    gateway.dispatch(
      DspControlCommand(
        path: 'output/channel',
        value: <String, Object>{
          'levelDb': value.levelDb,
          'muted': value.muted,
          'solo': value.solo,
          'phaseInverted': value.phaseInverted,
          'linked': value.linked,
        },
        channel: channel + 1,
      ),
    );
  }

  void allMuteOff() {
    for (var i = 0; i < outputChannels.length; i++) {
      final current = outputChannels[i].value;
      outputChannels[i].value = current.copyWith(muted: false);
    }
    gateway.dispatch(const DspControlCommand(path: 'output/allMuteOff', value: true));
  }

  void resetOutputLevels() {
    const levels = <double>[-3, -2.5, -4, -1, -2, -3.5, -4.5];
    masterOutputDb.value = -1;
    for (var i = 0; i < outputChannels.length; i++) {
      outputChannels[i].value = outputChannels[i].value.copyWith(levelDb: levels[i]);
    }
    gateway.dispatch(const DspControlCommand(path: 'output/resetLevels', value: true));
  }

  void dispose() {
    pageIndex.dispose();
    selectedChannel.dispose();
    eqBandGroup.dispose();
    masterVolumeDb.dispose();
    bassVolumeDb.dispose();
    bassCutoffHz.dispose();
    bassBoostDb.dispose();
    middleBoostDb.dispose();
    trebleBoostDb.dispose();
    audioSource.dispose();
    systemPreset.dispose();
    voltage.dispose();
    temperatureC.dispose();
    delayUnitMs.dispose();
    seatPreset.dispose();
    masterOutputDb.dispose();
    for (final channelBands in eqBands) {
      for (final band in channelBands) {
        band.dispose();
      }
    }
    for (final crossover in crossovers) {
      crossover.dispose();
    }
    for (final delay in delaysMs) {
      delay.dispose();
    }
    for (final output in outputChannels) {
      output.dispose();
    }
  }
}
