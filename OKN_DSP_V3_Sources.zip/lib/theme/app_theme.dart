import 'package:flutter/material.dart';

abstract final class AppColors {
  static const background = Color(0xFF080D1A);
  static const surface = Color(0xFF0A1628);
  static const surface2 = Color(0xFF0D2138);
  static const cyan = Color(0xFF00F0FF);
  static const blue = Color(0xFF0088FF);
  static const pink = Color(0xFFFF007F);
  static const purple = Color(0xFF8A2BE2);
  static const orange = Color(0xFFFF8C00);
  static const green = Color(0xFF00F07A);
  static const yellow = Color(0xFFFFE600);
  static const text = Color(0xFFF4F8FF);
  static const textMuted = Color(0xFF9CC7E8);
  static const border = Color(0xFF14518A);
}

abstract final class AppTheme {
  static ThemeData get dark {
    final scheme = ColorScheme.fromSeed(
      seedColor: AppColors.cyan,
      brightness: Brightness.dark,
      surface: AppColors.surface,
    );
    return ThemeData(
      brightness: Brightness.dark,
      colorScheme: scheme,
      scaffoldBackgroundColor: AppColors.background,
      splashFactory: InkRipple.splashFactory,
      visualDensity: VisualDensity.standard,
      useMaterial3: true,
      fontFamilyFallback: const ['Roboto', 'Noto Sans Thai', 'sans-serif'],
      textTheme: const TextTheme(
        headlineMedium: TextStyle(
          color: AppColors.text,
          fontWeight: FontWeight.w800,
          letterSpacing: -0.4,
        ),
        titleLarge: TextStyle(
          color: AppColors.text,
          fontWeight: FontWeight.w700,
        ),
        titleMedium: TextStyle(
          color: AppColors.text,
          fontWeight: FontWeight.w700,
        ),
        bodyLarge: TextStyle(color: AppColors.text),
        bodyMedium: TextStyle(color: AppColors.textMuted),
      ),
      sliderTheme: const SliderThemeData(
        trackHeight: 7,
        thumbShape: RoundSliderThumbShape(enabledThumbRadius: 11),
        overlayShape: RoundSliderOverlayShape(overlayRadius: 22),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.surface2.withValues(alpha: 0.58),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AppColors.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AppColors.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AppColors.cyan, width: 1.3),
        ),
      ),
    );
  }
}
