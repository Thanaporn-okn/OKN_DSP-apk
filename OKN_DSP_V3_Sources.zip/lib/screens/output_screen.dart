import 'package:flutter/material.dart';

import '../controllers/dsp_controller.dart';
import '../models/dsp_models.dart';
import '../theme/app_theme.dart';
import '../widgets/channel_selector.dart';
import '../widgets/glass_card.dart';
import '../widgets/neon_controls.dart';
import '../widgets/responsive.dart';
import '../widgets/section_header.dart';
import '../widgets/top_header.dart';
import '../widgets/vu_meter.dart';

class OutputScreen extends StatelessWidget {
  const OutputScreen({required this.controller, super.key});

  final DspController controller;

  @override
  Widget build(BuildContext context) {
    return ResponsivePage(
      child: Padding(
        padding: const EdgeInsets.only(bottom: 104),
        child: Column(
          children: [
            TopHeader(controller: controller),
            ValueListenableBuilder<int>(
              valueListenable: controller.selectedChannel,
              builder: (context, selected, _) => ChannelSelector(
                selectedIndex: selected,
                onSelected: controller.setSelectedChannel,
              ),
            ),
            const SizedBox(height: 12),
            GlassCard(
              glowColor: AppColors.orange,
              child: Column(
                children: [
                  SectionHeader(
                    icon: Icons.volume_up_rounded,
                    title: 'Output',
                    subtitle: 'ปรับระดับเอาต์พุตแต่ละช่อง',
                    color: AppColors.orange,
                    trailing: Wrap(
                      spacing: 8,
                      children: [
                        OutlinedButton.icon(
                          onPressed: controller.allMuteOff,
                          icon: const Icon(Icons.volume_off_rounded),
                          label: const Text('All Mute Off'),
                        ),
                        OutlinedButton.icon(
                          onPressed: controller.resetOutputLevels,
                          icon: const Icon(Icons.refresh_rounded),
                          label: const Text('Reset Levels'),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  AdaptiveColumns(
                    breakpoint: 740,
                    leftFlex: 3,
                    rightFlex: 2,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Output Level Overview', style: TextStyle(fontWeight: FontWeight.w700)),
                          const SizedBox(height: 4),
                          OutputVuOverview(channels: controller.outputChannels),
                        ],
                      ),
                      _MasterOutputCard(controller: controller),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            for (var i = 0; i < dspChannels.length; i++) ...[
              _OutputChannelCard(controller: controller, channel: i),
              if (i < dspChannels.length - 1) const SizedBox(height: 8),
            ],
          ],
        ),
      ),
    );
  }
}

class _MasterOutputCard extends StatelessWidget {
  const _MasterOutputCard({required this.controller});

  final DspController controller;

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      padding: const EdgeInsets.all(12),
      glowColor: AppColors.cyan,
      child: ValueListenableBuilder<double>(
        valueListenable: controller.masterOutputDb,
        builder: (context, value, _) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  const Expanded(child: Text('Master Output', style: TextStyle(fontWeight: FontWeight.w800))),
                  ValuePill(text: '${value.toStringAsFixed(1)} dB', color: AppColors.cyan),
                ],
              ),
              const SizedBox(height: 16),
              NeonSlider(
                value: value,
                min: -60,
                max: 12,
                divisions: 72,
                onChanged: controller.setMasterOutput,
              ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 12),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('-60', style: TextStyle(color: AppColors.textMuted, fontSize: 10)),
                    Text('-20', style: TextStyle(color: AppColors.textMuted, fontSize: 10)),
                    Text('0', style: TextStyle(color: AppColors.textMuted, fontSize: 10)),
                    Text('+12', style: TextStyle(color: AppColors.textMuted, fontSize: 10)),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _OutputChannelCard extends StatelessWidget {
  const _OutputChannelCard({required this.controller, required this.channel});

  final DspController controller;
  final int channel;

  @override
  Widget build(BuildContext context) {
    final info = dspChannels[channel];
    return GlassCard(
      glowColor: info.color,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      child: ValueListenableBuilder<OutputChannelState>(
        valueListenable: controller.outputChannels[channel],
        builder: (context, state, _) {
          return LayoutBuilder(
            builder: (context, constraints) {
              final compact = constraints.maxWidth < 760;
              final identity = Row(
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: info.color, width: 2),
                      color: info.color.withValues(alpha: 0.12),
                      boxShadow: [BoxShadow(color: info.color.withValues(alpha: 0.28), blurRadius: 13)],
                    ),
                    child: Text(
                      '${channel + 1}',
                      style: TextStyle(color: info.color, fontWeight: FontWeight.w900, fontSize: 18),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(info.shortName, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
                      Text(info.name, style: const TextStyle(color: AppColors.textMuted, fontSize: 11)),
                    ],
                  ),
                ],
              );
              final slider = NeonSlider(
                value: state.levelDb,
                min: -60,
                max: 12,
                divisions: 144,
                color: info.color,
                onChanged: (v) => controller.updateOutputChannel(
                  channel,
                  state.copyWith(levelDb: double.parse(v.toStringAsFixed(1))),
                ),
              );
              final value = ValuePill(text: '${state.levelDb.toStringAsFixed(1)} dB', color: info.color);
              final buttons = Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Expanded(
                    child: NeonIconButton(
                      icon: Icons.volume_off_rounded,
                      label: 'Mute',
                      active: state.muted,
                      color: AppColors.pink,
                      onTap: () => controller.updateOutputChannel(channel, state.copyWith(muted: !state.muted)),
                    ),
                  ),
                  const SizedBox(width: 6),
                  Expanded(
                    child: NeonIconButton(
                      icon: Icons.headphones_rounded,
                      label: 'Solo',
                      active: state.solo,
                      color: AppColors.orange,
                      onTap: () => controller.updateOutputChannel(channel, state.copyWith(solo: !state.solo)),
                    ),
                  ),
                  const SizedBox(width: 6),
                  Expanded(
                    child: NeonIconButton(
                      icon: Icons.change_circle_outlined,
                      label: 'Phase',
                      active: state.phaseInverted,
                      color: AppColors.purple,
                      onTap: () => controller.updateOutputChannel(
                        channel,
                        state.copyWith(phaseInverted: !state.phaseInverted),
                      ),
                    ),
                  ),
                  const SizedBox(width: 6),
                  Expanded(
                    child: NeonIconButton(
                      icon: Icons.link_rounded,
                      label: 'Link',
                      active: state.linked,
                      color: AppColors.cyan,
                      onTap: () => controller.updateOutputChannel(channel, state.copyWith(linked: !state.linked)),
                    ),
                  ),
                ],
              );

              if (compact) {
                return Column(
                  children: [
                    Row(children: [Expanded(child: identity), SizedBox(width: 112, child: value)]),
                    const SizedBox(height: 5),
                    slider,
                    const SizedBox(height: 6),
                    buttons,
                  ],
                );
              }
              return Row(
                children: [
                  SizedBox(width: 150, child: identity),
                  Expanded(child: slider),
                  const SizedBox(width: 8),
                  SizedBox(width: 108, child: value),
                  const SizedBox(width: 8),
                  SizedBox(width: 280, child: buttons),
                ],
              );
            },
          );
        },
      ),
    );
  }
}
