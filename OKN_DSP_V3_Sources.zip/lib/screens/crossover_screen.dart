import 'package:flutter/material.dart';

import '../controllers/dsp_controller.dart';
import '../models/dsp_models.dart';
import '../theme/app_theme.dart';
import '../widgets/channel_selector.dart';
import '../widgets/crossover_graph.dart';
import '../widgets/dropdown_field.dart';
import '../widgets/glass_card.dart';
import '../widgets/neon_controls.dart';
import '../widgets/responsive.dart';
import '../widgets/section_header.dart';
import '../widgets/top_header.dart';

class CrossoverScreen extends StatelessWidget {
  const CrossoverScreen({required this.controller, super.key});

  final DspController controller;

  @override
  Widget build(BuildContext context) {
    return ResponsivePage(
      child: Padding(
        padding: const EdgeInsets.only(bottom: 104),
        child: Column(
          children: [
            TopHeader(controller: controller),
            ValueListenableBuilder<int>(
              valueListenable: controller.selectedChannel,
              builder: (context, selected, _) => ChannelSelector(
                selectedIndex: selected,
                onSelected: controller.setSelectedChannel,
              ),
            ),
            const SizedBox(height: 12),
            ValueListenableBuilder<int>(
              valueListenable: controller.selectedChannel,
              builder: (context, channel, _) {
                return ValueListenableBuilder<CrossoverSettings>(
                  valueListenable: controller.crossovers[channel],
                  builder: (context, settings, _) {
                    return Column(
                      children: [
                        GlassCard(
                          glowColor: AppColors.purple,
                          child: Column(
                            children: [
                              SectionHeader(
                                icon: Icons.multiline_chart_rounded,
                                title: 'Crossover',
                                subtitle: 'ตั้งค่าการแบ่งความถี่',
                                color: AppColors.pink,
                                trailing: IconButton.filledTonal(
                                  tooltip: 'Reset crossover',
                                  onPressed: () => controller.resetCrossover(channel),
                                  icon: const Icon(Icons.refresh_rounded),
                                ),
                              ),
                              const SizedBox(height: 12),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  Container(width: 9, height: 9, decoration: const BoxDecoration(shape: BoxShape.circle, color: AppColors.cyan)),
                                  const SizedBox(width: 5),
                                  const Text('High Pass (HPF)', style: TextStyle(color: AppColors.textMuted, fontSize: 11)),
                                  const SizedBox(width: 14),
                                  Container(width: 9, height: 9, decoration: const BoxDecoration(shape: BoxShape.circle, color: AppColors.pink)),
                                  const SizedBox(width: 5),
                                  const Text('Low Pass (LPF)', style: TextStyle(color: AppColors.textMuted, fontSize: 11)),
                                ],
                              ),
                              const SizedBox(height: 6),
                              CrossoverGraph(settings: settings),
                            ],
                          ),
                        ),
                        const SizedBox(height: 12),
                        _FilterCard(
                          title: 'High Pass Filter (HPF)',
                          subtitle: 'กรองความถี่ต่ำออก',
                          color: AppColors.cyan,
                          icon: Icons.show_chart_rounded,
                          family: settings.hpfFamily,
                          frequency: settings.hpfFrequencyHz,
                          slope: settings.hpfSlope,
                          bypass: settings.hpfBypass,
                          onFamily: (v) => controller.updateCrossover(channel, settings.copyWith(hpfFamily: v)),
                          onFrequency: (v) => controller.updateCrossover(channel, settings.copyWith(hpfFrequencyHz: v)),
                          onSlope: (v) => controller.updateCrossover(channel, settings.copyWith(hpfSlope: v)),
                          onBypass: (v) => controller.updateCrossover(channel, settings.copyWith(hpfBypass: v)),
                        ),
                        const SizedBox(height: 12),
                        _FilterCard(
                          title: 'Low Pass Filter (LPF)',
                          subtitle: 'กรองความถี่สูงออก',
                          color: AppColors.pink,
                          icon: Icons.stacked_line_chart_rounded,
                          family: settings.lpfFamily,
                          frequency: settings.lpfFrequencyHz,
                          slope: settings.lpfSlope,
                          bypass: settings.lpfBypass,
                          onFamily: (v) => controller.updateCrossover(channel, settings.copyWith(lpfFamily: v)),
                          onFrequency: (v) => controller.updateCrossover(channel, settings.copyWith(lpfFrequencyHz: v)),
                          onSlope: (v) => controller.updateCrossover(channel, settings.copyWith(lpfSlope: v)),
                          onBypass: (v) => controller.updateCrossover(channel, settings.copyWith(lpfBypass: v)),
                        ),
                        const SizedBox(height: 12),
                        _AdvancedCard(
                          settings: settings,
                          onChanged: (v) => controller.updateCrossover(channel, v),
                        ),
                      ],
                    );
                  },
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _FilterCard extends StatelessWidget {
  const _FilterCard({
    required this.title,
    required this.subtitle,
    required this.color,
    required this.icon,
    required this.family,
    required this.frequency,
    required this.slope,
    required this.bypass,
    required this.onFamily,
    required this.onFrequency,
    required this.onSlope,
    required this.onBypass,
  });

  final String title;
  final String subtitle;
  final Color color;
  final IconData icon;
  final FilterFamily family;
  final double frequency;
  final int slope;
  final bool bypass;
  final ValueChanged<FilterFamily> onFamily;
  final ValueChanged<double> onFrequency;
  final ValueChanged<int> onSlope;
  final ValueChanged<bool> onBypass;

  @override
  Widget build(BuildContext context) {
    const frequencyChoices = <double>[20, 31.5, 40, 50, 63, 80, 100, 125, 160, 200, 250, 315, 400, 500, 630, 800, 1000, 1250, 1600, 2000, 2500, 3150, 4000, 5000, 6300, 8000, 10000, 12500, 16000, 20000];
    final nearest = frequencyChoices.reduce((a, b) => (a - frequency).abs() < (b - frequency).abs() ? a : b);
    return GlassCard(
      glowColor: color,
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 58,
                height: 58,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: color, width: 2),
                  boxShadow: [BoxShadow(color: color.withValues(alpha: 0.24), blurRadius: 18)],
                ),
                child: Icon(icon, color: color, size: 31),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
                    Text(subtitle, style: const TextStyle(color: AppColors.textMuted, fontSize: 12)),
                  ],
                ),
              ),
              const Text('Bypass', style: TextStyle(color: AppColors.textMuted)),
              const SizedBox(width: 5),
              NeonSwitch(value: bypass, onChanged: onBypass, color: color),
            ],
          ),
          const SizedBox(height: 12),
          LayoutBuilder(
            builder: (context, constraints) {
              final width = constraints.maxWidth;
              final fields = [
                Expanded(
                  child: DspDropdown<FilterFamily>(
                    label: 'Type',
                    value: family,
                    items: FilterFamily.values,
                    labelBuilder: _familyLabel,
                    onChanged: onFamily,
                  ),
                ),
                const SizedBox(width: 9),
                Expanded(
                  child: DspDropdown<double>(
                    label: 'Frequency',
                    value: nearest,
                    items: frequencyChoices,
                    labelBuilder: _frequencyLabel,
                    onChanged: onFrequency,
                  ),
                ),
                const SizedBox(width: 9),
                Expanded(
                  child: DspDropdown<int>(
                    label: 'Slope',
                    value: slope,
                    items: const [6, 12, 18, 24, 36, 48],
                    labelBuilder: (v) => '$v dB/Oct',
                    onChanged: onSlope,
                  ),
                ),
              ];
              if (width < 600) {
                return Column(
                  children: [
                    Row(children: fields.sublist(0, 3)),
                    const SizedBox(height: 9),
                    Row(children: fields.sublist(4, 5)),
                  ],
                );
              }
              return Row(children: fields);
            },
          ),
        ],
      ),
    );
  }

  static String _familyLabel(FilterFamily value) => switch (value) {
        FilterFamily.linkwitzRiley => 'Linkwitz-Riley',
        FilterFamily.butterworth => 'Butterworth',
        FilterFamily.bessel => 'Bessel',
      };

  static String _frequencyLabel(double value) {
    if (value >= 1000) return '${(value / 1000).toStringAsFixed(value % 1000 == 0 ? 1 : 2)} kHz';
    return '${value.toStringAsFixed(value % 1 == 0 ? 0 : 1)} Hz';
  }
}

class _AdvancedCard extends StatelessWidget {
  const _AdvancedCard({required this.settings, required this.onChanged});

  final CrossoverSettings settings;
  final ValueChanged<CrossoverSettings> onChanged;

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.settings_outlined, color: AppColors.cyan),
              SizedBox(width: 9),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Advanced Settings', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
                  Text('ตั้งค่าขั้นสูง', style: TextStyle(color: AppColors.textMuted, fontSize: 11)),
                ],
              ),
            ],
          ),
          const SizedBox(height: 11),
          LayoutBuilder(
            builder: (context, constraints) {
              final cardWidth = constraints.maxWidth >= 760
                  ? (constraints.maxWidth - 30) / 4
                  : constraints.maxWidth >= 470
                      ? (constraints.maxWidth - 10) / 2
                      : constraints.maxWidth;
              return Wrap(
                spacing: 10,
                runSpacing: 10,
                children: [
                  SizedBox(
                    width: cardWidth,
                    child: DspDropdown<int>(
                      label: 'Phase',
                      value: settings.phaseDegrees,
                      items: const [0, 45, 90, 135, 180, 225, 270, 315],
                      labelBuilder: (v) => '$v°',
                      onChanged: (v) => onChanged(settings.copyWith(phaseDegrees: v)),
                    ),
                  ),
                  SizedBox(
                    width: cardWidth,
                    child: DspDropdown<PolarityMode>(
                      label: 'Polarity',
                      value: settings.polarity,
                      items: PolarityMode.values,
                      labelBuilder: (v) => v == PolarityMode.normal ? 'Normal' : 'Inverted',
                      onChanged: (v) => onChanged(settings.copyWith(polarity: v)),
                    ),
                  ),
                  SizedBox(
                    width: cardWidth,
                    child: _ToggleTile(
                      label: 'Link L/R',
                      value: settings.linkLR,
                      onChanged: (v) => onChanged(settings.copyWith(linkLR: v)),
                    ),
                  ),
                  SizedBox(
                    width: cardWidth,
                    child: DspDropdown<OutputMode>(
                      label: 'Output Mode',
                      value: settings.outputMode,
                      items: OutputMode.values,
                      labelBuilder: (v) => v == OutputMode.stereo ? 'Stereo' : 'Mono',
                      onChanged: (v) => onChanged(settings.copyWith(outputMode: v)),
                    ),
                  ),
                ],
              );
            },
          ),
        ],
      ),
    );
  }
}

class _ToggleTile extends StatelessWidget {
  const _ToggleTile({required this.label, required this.value, required this.onChanged});

  final String label;
  final bool value;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(color: AppColors.textMuted, fontSize: 12)),
        const SizedBox(height: 5),
        Container(
          height: 49,
          padding: const EdgeInsets.symmetric(horizontal: 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.border),
            color: const Color(0xFF0A1930),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Icon(Icons.link_rounded, color: value ? AppColors.cyan : AppColors.textMuted),
              NeonSwitch(value: value, onChanged: onChanged),
            ],
          ),
        ),
      ],
    );
  }
}
