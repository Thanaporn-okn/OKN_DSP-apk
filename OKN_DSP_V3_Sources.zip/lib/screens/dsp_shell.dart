import 'package:flutter/material.dart';

import '../controllers/dsp_controller.dart';
import '../theme/app_theme.dart';
import '../widgets/bottom_nav.dart';
import 'crossover_screen.dart';
import 'delay_screen.dart';
import 'eq_screen.dart';
import 'home_screen.dart';
import 'output_screen.dart';

class DspShell extends StatelessWidget {
  const DspShell({required this.controller, super.key});

  final DspController controller;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: DecoratedBox(
        decoration: const BoxDecoration(
          color: AppColors.background,
          gradient: RadialGradient(
            center: Alignment(-0.8, -1.0),
            radius: 1.25,
            colors: [Color(0xFF063156), AppColors.background],
            stops: [0, 0.52],
          ),
        ),
        child: SafeArea(
          bottom: false,
          child: ValueListenableBuilder<int>(
            valueListenable: controller.pageIndex,
            builder: (context, index, _) {
              return Stack(
                children: [
                  IndexedStack(
                    index: index,
                    children: [
                      HomeScreen(controller: controller),
                      EqScreen(controller: controller),
                      CrossoverScreen(controller: controller),
                      DelayScreen(controller: controller),
                      OutputScreen(controller: controller),
                    ],
                  ),
                  Positioned(
                    left: 0,
                    right: 0,
                    bottom: 0,
                    child: SafeArea(
                      top: false,
                      minimum: const EdgeInsets.fromLTRB(14, 0, 14, 8),
                      child: Center(
                        child: ConstrainedBox(
                          constraints: const BoxConstraints(maxWidth: 1180),
                          child: DspBottomNav(
                            index: index,
                            onChanged: controller.setPage,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}
