import 'package:flutter/foundation.dart' show ValueListenable;
import 'package:flutter/material.dart';

import '../controllers/dsp_controller.dart';
import '../models/dsp_models.dart';
import '../theme/app_theme.dart';
import '../widgets/channel_selector.dart';
import '../widgets/dropdown_field.dart';
import '../widgets/eq_graph.dart';
import '../widgets/glass_card.dart';
import '../widgets/neon_controls.dart';
import '../widgets/responsive.dart';
import '../widgets/section_header.dart';
import '../widgets/top_header.dart';

class EqScreen extends StatelessWidget {
  const EqScreen({required this.controller, super.key});

  final DspController controller;

  @override
  Widget build(BuildContext context) {
    return ResponsivePage(
      child: Padding(
        padding: const EdgeInsets.only(bottom: 104),
        child: Column(
          children: [
            TopHeader(controller: controller),
            ValueListenableBuilder<int>(
              valueListenable: controller.selectedChannel,
              builder: (context, selected, _) => ChannelSelector(
                selectedIndex: selected,
                onSelected: controller.setSelectedChannel,
              ),
            ),
            const SizedBox(height: 12),
            ValueListenableBuilder<int>(
              valueListenable: controller.selectedChannel,
              builder: (context, channel, _) {
                return Column(
                  children: [
                    GlassCard(
                      glowColor: AppColors.cyan,
                      child: Column(
                        children: [
                          SectionHeader(
                            icon: Icons.graphic_eq_rounded,
                            title: 'Parametric EQ',
                            subtitle: 'ปรับแต่งความถี่เสียงอย่างละเอียด',
                            trailing: IconButton.filledTonal(
                              tooltip: 'Reset EQ',
                              onPressed: () => controller.resetEq(channel),
                              icon: const Icon(Icons.refresh_rounded),
                            ),
                          ),
                          const SizedBox(height: 14),
                          InteractiveEqGraph(
                            bands: controller.eqBands[channel],
                            onBandChanged: (band, value) => controller.updateEqBand(channel, band, value),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    _BandGroupSelector(controller: controller),
                    const SizedBox(height: 10),
                    ValueListenableBuilder<int>(
                      valueListenable: controller.eqBandGroup,
                      builder: (context, group, _) {
                        final start = group == 0 ? 0 : group == 1 ? 6 : 12;
                        final count = group < 2 ? 6 : 3;
                        return GlassCard(
                          padding: const EdgeInsets.all(10),
                          child: Column(
                            children: [
                              for (var local = 0; local < count; local++) ...[
                                _EqBandRow(
                                  number: start + local + 1,
                                  listenable: controller.eqBands[channel][start + local],
                                  onChanged: (value) => controller.updateEqBand(channel, start + local, value),
                                ),
                                if (local < count - 1) const Divider(height: 10, color: Color(0x33285A80)),
                              ],
                            ],
                          ),
                        );
                      },
                    ),
                    const SizedBox(height: 12),
                    _PresetPanel(controller: controller),
                  ],
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _BandGroupSelector extends StatelessWidget {
  const _BandGroupSelector({required this.controller});

  final DspController controller;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<int>(
      valueListenable: controller.eqBandGroup,
      builder: (context, group, _) {
        return Row(
          children: [
            for (final entry in const [(0, 'Bands 1 - 6'), (1, 'Bands 7 - 12'), (2, 'Bands 13 - 15')]) ...[
              Expanded(
                child: _GroupButton(
                  label: entry.$2,
                  active: group == entry.$1,
                  onTap: () => controller.eqBandGroup.value = entry.$1,
                ),
              ),
              if (entry.$1 < 2) const SizedBox(width: 8),
            ],
          ],
        );
      },
    );
  }
}

class _GroupButton extends StatelessWidget {
  const _GroupButton({required this.label, required this.active, required this.onTap});

  final String label;
  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 100),
          padding: const EdgeInsets.symmetric(vertical: 13),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: active ? AppColors.cyan : AppColors.border),
            gradient: active
                ? LinearGradient(colors: [AppColors.blue.withValues(alpha: 0.8), AppColors.cyan.withValues(alpha: 0.4)])
                : null,
            color: active ? null : AppColors.surface2,
            boxShadow: active
                ? [BoxShadow(color: AppColors.cyan.withValues(alpha: 0.22), blurRadius: 14)]
                : null,
          ),
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: const TextStyle(fontWeight: FontWeight.w700),
          ),
        ),
      ),
    );
  }
}

class _EqBandRow extends StatelessWidget {
  const _EqBandRow({
    required this.number,
    required this.listenable,
    required this.onChanged,
  });

  final int number;
  final ValueListenable<EqBand> listenable;
  final ValueChanged<EqBand> onChanged;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<EqBand>(
      valueListenable: listenable,
      builder: (context, band, _) {
        return LayoutBuilder(
          builder: (context, constraints) {
            final compact = constraints.maxWidth < 740;
            final indicator = SizedBox(
              width: 48,
              child: Row(
                children: [
                  Container(
                    width: 16,
                    height: 16,
                    decoration: BoxDecoration(
                      color: band.color,
                      shape: BoxShape.circle,
                      boxShadow: [BoxShadow(color: band.color.withValues(alpha: 0.42), blurRadius: 8)],
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text('$number', style: const TextStyle(fontWeight: FontWeight.w800)),
                ],
              ),
            );
            final type = SizedBox(
              width: compact ? double.infinity : 165,
              child: DspDropdown<EqFilterType>(
                value: band.type,
                items: EqFilterType.values,
                labelBuilder: _eqTypeLabel,
                onChanged: (v) => onChanged(band.copyWith(type: v)),
              ),
            );
            final frequency = _AdjustField(
              label: _frequencyLabel(band.frequencyHz),
              onMinus: () => onChanged(band.copyWith(frequencyHz: (band.frequencyHz / 1.08).clamp(20.0, 20000.0).toDouble())),
              onPlus: () => onChanged(band.copyWith(frequencyHz: (band.frequencyHz * 1.08).clamp(20.0, 20000.0).toDouble())),
            );
            final gain = _AdjustField(
              label: '${band.gainDb.toStringAsFixed(1)} dB',
              onMinus: () => onChanged(band.copyWith(gainDb: (band.gainDb - 0.5).clamp(-12.0, 12.0).toDouble())),
              onPlus: () => onChanged(band.copyWith(gainDb: (band.gainDb + 0.5).clamp(-12.0, 12.0).toDouble())),
            );
            final q = _AdjustField(
              label: band.q.toStringAsFixed(2),
              onMinus: () => onChanged(band.copyWith(q: (band.q - 0.05).clamp(0.10, 10.0).toDouble())),
              onPlus: () => onChanged(band.copyWith(q: (band.q + 0.05).clamp(0.10, 10.0).toDouble())),
            );
            final power = NeonSwitch(
              value: band.enabled,
              color: AppColors.blue,
              onChanged: (v) => onChanged(band.copyWith(enabled: v)),
            );

            if (compact) {
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 5),
                child: Column(
                  children: [
                    Row(children: [indicator, Expanded(child: type), const SizedBox(width: 8), power]),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(child: frequency),
                        const SizedBox(width: 7),
                        Expanded(child: gain),
                        const SizedBox(width: 7),
                        Expanded(child: q),
                      ],
                    ),
                  ],
                ),
              );
            }

            return Row(
              children: [
                indicator,
                const SizedBox(width: 5),
                type,
                const SizedBox(width: 8),
                Expanded(child: frequency),
                const SizedBox(width: 8),
                Expanded(child: gain),
                const SizedBox(width: 8),
                Expanded(child: q),
                const SizedBox(width: 8),
                power,
              ],
            );
          },
        );
      },
    );
  }

  static String _eqTypeLabel(EqFilterType type) => switch (type) {
        EqFilterType.peq => 'PEQ',
        EqFilterType.lowShelf => 'Low Shelf',
        EqFilterType.highShelf => 'High Shelf',
      };

  static String _frequencyLabel(double value) {
    if (value >= 1000) return '${(value / 1000).toStringAsFixed(value >= 10000 ? 1 : 2)} kHz';
    return '${value.round()} Hz';
  }
}

class _AdjustField extends StatelessWidget {
  const _AdjustField({required this.label, required this.onMinus, required this.onPlus});

  final String label;
  final VoidCallback onMinus;
  final VoidCallback onPlus;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 44,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.border),
        color: const Color(0xFF09192C),
      ),
      child: Row(
        children: [
          InkWell(
            onTap: onMinus,
            child: const SizedBox(width: 30, height: 44, child: Icon(Icons.chevron_left, size: 18)),
          ),
          Expanded(
            child: FittedBox(
              fit: BoxFit.scaleDown,
              child: Text(label, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12)),
            ),
          ),
          InkWell(
            onTap: onPlus,
            child: const SizedBox(width: 30, height: 44, child: Icon(Icons.chevron_right, size: 18)),
          ),
        ],
      ),
    );
  }
}

class _PresetPanel extends StatelessWidget {
  const _PresetPanel({required this.controller});

  final DspController controller;

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      child: LayoutBuilder(
        builder: (context, constraints) {
          final compact = constraints.maxWidth < 580;
          final selector = ValueListenableBuilder<String>(
            valueListenable: controller.systemPreset,
            builder: (context, value, _) => DspDropdown<String>(
              value: value,
              items: const ['Flat', 'Custom 1', 'Custom 2', 'Music', 'Vocal'],
              labelBuilder: (v) => v,
              onChanged: controller.setSystemPreset,
            ),
          );
          final buttons = Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              FilledButton.tonalIcon(
                onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Preset values are held in memory for this session.'))),
                icon: const Icon(Icons.save_rounded),
                label: const Text('Save'),
              ),
              const SizedBox(width: 8),
              OutlinedButton.icon(
                onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Preset manager is ready for persisted protocol data.'))),
                icon: const Icon(Icons.folder_open_rounded),
                label: const Text('Manage'),
              ),
            ],
          );
          if (compact) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text('Preset', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
                const Text('ชุดค่าที่ใช้งานอยู่', style: TextStyle(color: AppColors.textMuted, fontSize: 12)),
                const SizedBox(height: 9),
                selector,
                const SizedBox(height: 10),
                buttons,
              ],
            );
          }
          return Row(
            children: [
              const Icon(Icons.folder_outlined, color: AppColors.cyan, size: 38),
              const SizedBox(width: 12),
              const SizedBox(
                width: 170,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Preset', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
                    Text('ชุดค่าที่ใช้งานอยู่', style: TextStyle(color: AppColors.textMuted, fontSize: 12)),
                  ],
                ),
              ),
              Expanded(child: selector),
              const SizedBox(width: 12),
              buttons,
            ],
          );
        },
      ),
    );
  }
}
