import 'package:flutter/material.dart';

import '../controllers/dsp_controller.dart';
import '../models/dsp_models.dart';
import '../theme/app_theme.dart';
import '../widgets/channel_selector.dart';
import '../widgets/delay_car.dart';
import '../widgets/dropdown_field.dart';
import '../widgets/glass_card.dart';
import '../widgets/neon_controls.dart';
import '../widgets/responsive.dart';
import '../widgets/section_header.dart';
import '../widgets/top_header.dart';

class DelayScreen extends StatelessWidget {
  const DelayScreen({required this.controller, super.key});

  final DspController controller;
  static const cmPerMs = 34.3;

  @override
  Widget build(BuildContext context) {
    return ResponsivePage(
      child: Padding(
        padding: const EdgeInsets.only(bottom: 104),
        child: Column(
          children: [
            TopHeader(controller: controller),
            ValueListenableBuilder<int>(
              valueListenable: controller.selectedChannel,
              builder: (context, selected, _) => ChannelSelector(
                selectedIndex: selected,
                onSelected: controller.setSelectedChannel,
              ),
            ),
            const SizedBox(height: 12),
            GlassCard(
              glowColor: AppColors.green,
              child: Column(
                children: [
                  SectionHeader(
                    icon: Icons.access_time_rounded,
                    title: 'Delay',
                    subtitle: 'ตั้งค่าหน่วงเวลาเพื่อการจัดตำแหน่งเสียง',
                    color: AppColors.green,
                    trailing: _UnitToggle(controller: controller),
                  ),
                  const SizedBox(height: 14),
                  AdaptiveColumns(
                    breakpoint: 720,
                    leftFlex: 3,
                    rightFlex: 2,
                    children: [
                      DelayCarDiagram(delays: controller.delaysMs),
                      Column(
                        children: [
                          _SeatPresetCard(controller: controller),
                          const SizedBox(height: 10),
                          const _InfoCard(
                            icon: Icons.straighten_rounded,
                            title: 'Distance Reference',
                            subtitle: 'อ้างอิงระยะทางเสียง',
                            body: 'Speed of Sound (20°C)\n343 m/s (34.3 cm/ms)',
                          ),
                          const SizedBox(height: 10),
                          AnimatedBuilder(
                            animation: Listenable.merge(controller.delaysMs),
                            builder: (context, _) {
                              final min = controller.delaysMs.map((e) => e.value).reduce((a, b) => a < b ? a : b);
                              final max = controller.delaysMs.map((e) => e.value).reduce((a, b) => a > b ? a : b);
                              return _InfoCard(
                                icon: Icons.equalizer_rounded,
                                title: 'Total Delay Range',
                                subtitle: 'ช่วงหน่วงเวลาทั้งหมด',
                                body: '${min.toStringAsFixed(2)} ms  —  ${max.toStringAsFixed(2)} ms',
                              );
                            },
                          ),
                          const SizedBox(height: 10),
                          SizedBox(
                            width: double.infinity,
                            child: OutlinedButton.icon(
                              onPressed: () {
                                final selected = controller.selectedChannel.value;
                                final value = controller.delaysMs[selected].value;
                                for (var i = 0; i < controller.delaysMs.length; i++) {
                                  controller.setDelay(i, value);
                                }
                              },
                              icon: const Icon(Icons.sync_rounded),
                              label: const Text('ซิงค์ทุกช่อง'),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            for (var i = 0; i < dspChannels.length; i++) ...[
              _DelayChannelRow(controller: controller, channel: i),
              if (i < dspChannels.length - 1) const SizedBox(height: 8),
            ],
          ],
        ),
      ),
    );
  }
}

class _UnitToggle extends StatelessWidget {
  const _UnitToggle({required this.controller});

  final DspController controller;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: controller.delayUnitMs,
      builder: (context, ms, _) {
        return Container(
          padding: const EdgeInsets.all(3),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(11),
            border: Border.all(color: AppColors.border),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              _UnitButton(label: 'ms', active: ms, onTap: () => controller.delayUnitMs.value = true),
              _UnitButton(label: 'cm', active: !ms, onTap: () => controller.delayUnitMs.value = false),
            ],
          ),
        );
      },
    );
  }
}

class _UnitButton extends StatelessWidget {
  const _UnitButton({required this.label, required this.active, required this.onTap});

  final String label;
  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 90),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          color: active ? AppColors.blue : Colors.transparent,
          boxShadow: active ? [BoxShadow(color: AppColors.cyan.withValues(alpha: 0.25), blurRadius: 10)] : null,
        ),
        child: Text(label, style: TextStyle(fontWeight: FontWeight.w700, color: active ? Colors.white : AppColors.textMuted)),
      ),
    );
  }
}

class _SeatPresetCard extends StatelessWidget {
  const _SeatPresetCard({required this.controller});

  final DspController controller;

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      padding: const EdgeInsets.all(12),
      child: ValueListenableBuilder<String>(
        valueListenable: controller.seatPreset,
        builder: (context, value, _) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Row(
                children: [
                  Icon(Icons.event_seat_outlined, color: AppColors.cyan),
                  SizedBox(width: 8),
                  Text('Seat Preset', style: TextStyle(fontWeight: FontWeight.w800)),
                ],
              ),
              const SizedBox(height: 8),
              DspDropdown<String>(
                value: value,
                items: const ['Driver (Left)', 'Passenger (Right)', 'Center'],
                labelBuilder: (v) => v,
                onChanged: controller.applySeatPreset,
              ),
            ],
          );
        },
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  const _InfoCard({required this.icon, required this.title, required this.subtitle, required this.body});

  final IconData icon;
  final String title;
  final String subtitle;
  final String body;

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      padding: const EdgeInsets.all(12),
      child: Row(
        children: [
          Icon(icon, color: AppColors.cyan, size: 28),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
                Text(subtitle, style: const TextStyle(color: AppColors.textMuted, fontSize: 11)),
                const SizedBox(height: 7),
                Text(body, style: const TextStyle(color: AppColors.text, fontSize: 12)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _DelayChannelRow extends StatelessWidget {
  const _DelayChannelRow({required this.controller, required this.channel});

  final DspController controller;
  final int channel;

  @override
  Widget build(BuildContext context) {
    final info = dspChannels[channel];
    return GlassCard(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
      glowColor: info.color,
      child: ValueListenableBuilder<double>(
        valueListenable: controller.delaysMs[channel],
        builder: (context, value, _) {
          return LayoutBuilder(
            builder: (context, constraints) {
              final compact = constraints.maxWidth < 600;
              final label = Row(
                children: [
                  Container(
                    width: 25,
                    height: 25,
                    decoration: BoxDecoration(
                      color: info.color,
                      shape: BoxShape.circle,
                      boxShadow: [BoxShadow(color: info.color.withValues(alpha: 0.34), blurRadius: 10)],
                    ),
                  ),
                  const SizedBox(width: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(info.shortName, style: const TextStyle(fontWeight: FontWeight.w800)),
                      Text(info.name, style: const TextStyle(color: AppColors.textMuted, fontSize: 11)),
                    ],
                  ),
                ],
              );
              final slider = NeonSlider(
                value: value,
                min: 0,
                max: 10,
                divisions: 200,
                color: info.color,
                onChanged: (v) => controller.setDelay(channel, double.parse(v.toStringAsFixed(2))),
              );
              final readout = ValueListenableBuilder<bool>(
                valueListenable: controller.delayUnitMs,
                builder: (context, ms, _) {
                  return ValuePill(
                    color: info.color,
                    text: ms
                        ? '${value.toStringAsFixed(2)} ms\n${(value * DelayScreen.cmPerMs).toStringAsFixed(1)} cm'
                        : '${(value * DelayScreen.cmPerMs).toStringAsFixed(1)} cm\n${value.toStringAsFixed(2)} ms',
                  );
                },
              );
              if (compact) {
                return Column(
                  children: [
                    Row(children: [Expanded(child: label), SizedBox(width: 126, child: readout)]),
                    slider,
                  ],
                );
              }
              return Row(
                children: [
                  SizedBox(width: 145, child: label),
                  Expanded(child: slider),
                  const SizedBox(width: 8),
                  SizedBox(width: 138, child: readout),
                ],
              );
            },
          );
        },
      ),
    );
  }
}
