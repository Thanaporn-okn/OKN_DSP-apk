import 'package:flutter/material.dart';

import 'controllers/dsp_controller.dart';
import 'screens/dsp_shell.dart';
import 'services/ble_dsp_service.dart';
import 'services/dsp_command_gateway.dart';
import 'theme/app_theme.dart';

class OknDspApp extends StatefulWidget {
  const OknDspApp({super.key});

  @override
  State<OknDspApp> createState() => _OknDspAppState();
}

class _OknDspAppState extends State<OknDspApp> {
  late final BleDspService _bleService;
  late final DspCommandGateway _gateway;
  late final DspController _controller;

  @override
  void initState() {
    super.initState();
    _bleService = BleDspService();
    _gateway = DspCommandGateway(_bleService);
    _controller = DspController(gateway: _gateway, bleService: _bleService);
  }

  @override
  void dispose() {
    _controller.dispose();
    _gateway.dispose();
    _bleService.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'OKN_DSP',
      debugShowCheckedModeBanner: false,
      themeMode: ThemeMode.dark,
      darkTheme: AppTheme.dark,
      home: DspShell(controller: _controller),
    );
  }
}
