import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

enum EqFilterType { peq, lowShelf, highShelf }

enum FilterFamily { linkwitzRiley, butterworth, bessel }

enum OutputMode { stereo, mono }

enum PolarityMode { normal, inverted }

@immutable
class DspChannel {
  const DspChannel({
    required this.number,
    required this.name,
    required this.shortName,
    required this.color,
  });

  final int number;
  final String name;
  final String shortName;
  final Color color;
}

const dspChannels = <DspChannel>[
  DspChannel(number: 1, name: 'Front L', shortName: 'CH1', color: AppColors.blue),
  DspChannel(number: 2, name: 'Front R', shortName: 'CH2', color: AppColors.cyan),
  DspChannel(number: 3, name: 'Rear L', shortName: 'CH3', color: AppColors.green),
  DspChannel(number: 4, name: 'Rear R', shortName: 'CH4', color: AppColors.yellow),
  DspChannel(number: 5, name: 'Center', shortName: 'CH5', color: AppColors.orange),
  DspChannel(number: 6, name: 'Sub L', shortName: 'CH6', color: AppColors.pink),
  DspChannel(number: 7, name: 'Sub R', shortName: 'CH7', color: AppColors.purple),
];

@immutable
class EqBand {
  const EqBand({
    required this.type,
    required this.frequencyHz,
    required this.gainDb,
    required this.q,
    required this.enabled,
    required this.color,
  });

  final EqFilterType type;
  final double frequencyHz;
  final double gainDb;
  final double q;
  final bool enabled;
  final Color color;

  EqBand copyWith({
    EqFilterType? type,
    double? frequencyHz,
    double? gainDb,
    double? q,
    bool? enabled,
    Color? color,
  }) {
    return EqBand(
      type: type ?? this.type,
      frequencyHz: frequencyHz ?? this.frequencyHz,
      gainDb: gainDb ?? this.gainDb,
      q: q ?? this.q,
      enabled: enabled ?? this.enabled,
      color: color ?? this.color,
    );
  }
}

@immutable
class CrossoverSettings {
  const CrossoverSettings({
    required this.hpfFamily,
    required this.hpfFrequencyHz,
    required this.hpfSlope,
    required this.hpfBypass,
    required this.lpfFamily,
    required this.lpfFrequencyHz,
    required this.lpfSlope,
    required this.lpfBypass,
    required this.phaseDegrees,
    required this.polarity,
    required this.linkLR,
    required this.outputMode,
  });

  final FilterFamily hpfFamily;
  final double hpfFrequencyHz;
  final int hpfSlope;
  final bool hpfBypass;
  final FilterFamily lpfFamily;
  final double lpfFrequencyHz;
  final int lpfSlope;
  final bool lpfBypass;
  final int phaseDegrees;
  final PolarityMode polarity;
  final bool linkLR;
  final OutputMode outputMode;

  CrossoverSettings copyWith({
    FilterFamily? hpfFamily,
    double? hpfFrequencyHz,
    int? hpfSlope,
    bool? hpfBypass,
    FilterFamily? lpfFamily,
    double? lpfFrequencyHz,
    int? lpfSlope,
    bool? lpfBypass,
    int? phaseDegrees,
    PolarityMode? polarity,
    bool? linkLR,
    OutputMode? outputMode,
  }) {
    return CrossoverSettings(
      hpfFamily: hpfFamily ?? this.hpfFamily,
      hpfFrequencyHz: hpfFrequencyHz ?? this.hpfFrequencyHz,
      hpfSlope: hpfSlope ?? this.hpfSlope,
      hpfBypass: hpfBypass ?? this.hpfBypass,
      lpfFamily: lpfFamily ?? this.lpfFamily,
      lpfFrequencyHz: lpfFrequencyHz ?? this.lpfFrequencyHz,
      lpfSlope: lpfSlope ?? this.lpfSlope,
      lpfBypass: lpfBypass ?? this.lpfBypass,
      phaseDegrees: phaseDegrees ?? this.phaseDegrees,
      polarity: polarity ?? this.polarity,
      linkLR: linkLR ?? this.linkLR,
      outputMode: outputMode ?? this.outputMode,
    );
  }
}

@immutable
class OutputChannelState {
  const OutputChannelState({
    required this.levelDb,
    required this.muted,
    required this.solo,
    required this.phaseInverted,
    required this.linked,
  });

  final double levelDb;
  final bool muted;
  final bool solo;
  final bool phaseInverted;
  final bool linked;

  OutputChannelState copyWith({
    double? levelDb,
    bool? muted,
    bool? solo,
    bool? phaseInverted,
    bool? linked,
  }) {
    return OutputChannelState(
      levelDb: levelDb ?? this.levelDb,
      muted: muted ?? this.muted,
      solo: solo ?? this.solo,
      phaseInverted: phaseInverted ?? this.phaseInverted,
      linked: linked ?? this.linked,
    );
  }
}

@immutable
class DspControlCommand {
  const DspControlCommand({
    required this.path,
    required this.value,
    this.channel,
    this.band,
  });

  final String path;
  final Object value;
  final int? channel;
  final int? band;

  @override
  String toString() {
    return 'DspControlCommand(path: $path, value: $value, channel: $channel, band: $band)';
  }
}
