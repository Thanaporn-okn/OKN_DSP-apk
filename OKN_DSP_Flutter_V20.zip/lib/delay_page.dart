import 'package:flutter/material.dart';

class DelayPage extends StatelessWidget{
 const DelayPage({super.key});
 Widget build(BuildContext c)=>ListView(
 children:List.generate(7,(i)=>ListTile(
 title:Text('CH${i+1} Delay'),
 trailing:const Text('0 ms')))
 );
}
