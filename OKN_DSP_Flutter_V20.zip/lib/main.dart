import 'package:flutter/material.dart';
import 'eq_page.dart';
import 'crossover_page.dart';
import 'delay_page.dart';

void main()=>runApp(const OKNDSP());

class OKNDSP extends StatelessWidget{
 const OKNDSP({super.key});
 Widget build(BuildContext c)=>MaterialApp(
 debugShowCheckedModeBanner:false,
 theme:ThemeData.dark(),
 home:const Home());
}

class Home extends StatefulWidget{
 const Home({super.key});
 State<Home> createState()=>_Home();
}

class _Home extends State<Home>{
 int page=0;
 final pages=[
 const Text('MAIN DSP 7CH'),
 const EQPage(),
 const CrossoverPage(),
 const DelayPage()
 ];

 Widget build(BuildContext c)=>Scaffold(
 backgroundColor:const Color(0xff0b1016),
 body:SafeArea(child:Column(children:[
 Expanded(child:Center(child:pages[page])),
 ),
 Row(
 mainAxisAlignment:MainAxisAlignment.spaceAround,
 children:[
  'MAIN','EQ','XOVER','DELAY'
 ].asMap().entries.map((e)=>TextButton(
 onPressed:()=>setState(()=>page=e.key),
 child:Text(e.value)
 )).toList())
 ])));
}
