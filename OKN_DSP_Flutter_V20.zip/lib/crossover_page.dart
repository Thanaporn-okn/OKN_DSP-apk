import 'package:flutter/material.dart';

class CrossoverPage extends StatelessWidget{
 const CrossoverPage({super.key});
 Widget build(BuildContext c)=>Column(children:[
 const Text('HPF'),
 Slider(value:.4,onChanged:null),
 const Text('LPF'),
 Slider(value:.7,onChanged:null)
 ]);
}
