class PresetManager{
 void save(int id){}
 void load(int id){}
}
