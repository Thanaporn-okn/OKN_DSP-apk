import 'package:flutter/material.dart';

class EQPage extends StatelessWidget{
 const EQPage({super.key});
 Widget build(BuildContext c)=>ListView.builder(
 itemCount:15,
 itemBuilder:(c,i)=>Column(children:[
 Text('EQ Band ${i+1}'),
 Slider(value:.5,onChanged:null)
 ]));
}
