class DSPState{
 List<double> volume=List.filled(7,.5);
 List<int> eq=List.filled(15,0);
 List<int> delay=List.filled(7,0);
 int hpf=80;
 int lpf=20000;
}
