OKN_DSP V100 — MORE SCREEN COMPILE FIX / ALL-DATA MASTER
===========================================
VersionCode: 100
VersionName: 8.0.1-v100-more-screen-compile-fix
Package: com.okn.dsp
Platform: Native Android / Kotlin, minSdk 26, targetSdk 35

PURPOSE
-------
V100 retains the V99 all-data consolidation and fixes the MoreScreen Kotlin compile defect. V99 consolidated the verified OKN_DSP project history into one buildable Android source package.
It starts from the V98 master-reference modular source and preserves the frozen verified DSP protocol/transport boundary.
The latest portrait multi-screen UI concept is also retained under evidence/ as the current design direction.
Unverified DSP commands are not guessed or enabled merely because a control appears in the concept artwork.

VERIFIED DSP / BLE SCOPE
------------------------
- BLE service: 0000ab00-0000-1000-8000-00805f9b34fb
- BLE write:   0000ab01-0000-1000-8000-00805f9b34fb
- BLE notify:  0000ab02-0000-1000-8000-00805f9b34fb
- Auth/session + Device Description + Health Gate before realtime replay.
- Verified scalar IDs: 2,3,8,9,10,13,11.
- MasterVolume ID2 is synchronized with Android STREAM_MUSIC / physical volume keys.
- EQ actuator map CH1..CH7: 4,5,6,14,15,16,17.
- 15 EQ bands/channel; full 48-byte records; writable only for PEAKING type=12.
- SaveParams ID7 trigger: 570000000700000000; manual guarded action only.
- One GATT write in flight, latest-target-wins realtime coalescing, critical FIFO.
- Minimum 38 ms pacing; 2.5 s callback timeout fail-closed.
- TrebleBoost ID11 is slewed in <=0.5 dB callback-gated steps, nominal 48 ms.
- Local verified state persists and can replay only after a fresh Health Gate.

REAL APP UI
-----------
The runtime remains a real native Android control UI rather than a static screenshot:
- Home: scan/connect, connection health, DSP/device status, Master Volume, CH1..CH7.
- Global: seven verified scalar controls.
- EQ: 7-channel overview + per-channel 15-band editor and response graph.
- Sensors: descriptor-backed read-only system values.
- Guarded SaveParams.
- More: reconnect/refresh/logs, verified write boundary, and current design-module status.
- Full-screen portrait/landscape handling keeps the current GATT/session state in place.

LATEST DESIGN DATA INCLUDED
---------------------------
evidence/OKN_DSP_V99_LATEST_UI_CONCEPT_REFERENCE.png is the latest dark/blue vertical UI board covering
Connect/Home, 7-channel mixer, EQ, Crossover, Delay, Limiter, Presets and Settings.
It is included as a design master. Controls whose DSP packet/actuator evidence is not verified remain locked.

LOCKED / NOT GUESSED
--------------------
- Hardware Crossover writes
- Hardware Delay writes
- Hardware per-channel Output / Mute / Phase writes
- Hardware Preset recall/write
- Limiter writes without verified actuator/packet evidence
- 40af UUID role assignment
- Any generic/unknown actuator write

UPGRADE CONTINUITY
------------------
The local preference namespace intentionally remains okn_dsp_v98_local_state so V99 can retain verified local
state across an in-place V98 -> V99 upgrade. This does not bypass the fresh Health Gate required before replay.
The stable debug signing identity is carried forward unchanged.

VALIDATION
----------
Run: python3 preflight_v100.py
The preflight verifies frozen protocol hashes, BLE role boundary, writer policy, queue invariants, UI markers,
stable signing keystore, V100 identity and both UI reference hashes.
The separate GitHub Actions workflow is the authoritative Android 35 compile/sign path.
Physical target-DSP listening/measurement is still required before claiming acoustic no-pop/no-stutter behavior.
