
import 'package:flutter/material.dart';

void main() => runApp(const OKNDSP());

class OKNDSP extends StatelessWidget {
  const OKNDSP({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'OKN_DSP BP1048P4 V5',
      theme: ThemeData.dark(),
      home: const DSPHome(),
    );
  }
}

class DSPHome extends StatefulWidget {
  const DSPHome({super.key});
  @override
  State<DSPHome> createState() => _DSPHomeState();
}

class _DSPHomeState extends State<DSPHome> {
  double volume = 50;
  final eq = List<double>.filled(15, 0);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('OKN_DSP BP1048P4 V5')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Master Volume ${volume.toInt()}'),
          Slider(
            value: volume,
            min: 0,
            max: 100,
            onChanged: (v)=>setState(()=>volume=v),
          ),
          const Divider(),
          const Text('15 Band EQ'),
          ...List.generate(15, (i)=>Slider(
            value:eq[i],
            min:-12,
            max:12,
            label:'Band ${i+1}',
            onChanged:(v)=>setState(()=>eq[i]=v),
          )),
          ElevatedButton(
            onPressed:(){},
            child:const Text('Save Preset'),
          ),
        ],
      ),
    );
  }
}
