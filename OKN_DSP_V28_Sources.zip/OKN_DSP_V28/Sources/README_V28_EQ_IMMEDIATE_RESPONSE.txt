OKN_DSP V28 — EQ IMMEDIATE RESPONSE
====================================

AUTHORITATIVE BASE
- Built directly from OKN_DSP V17.
- V18–V27 are NOT used as source baseline.
- DspProtocol.java, DspState.java, DspView.java and MainActivity.java remain byte-identical to V17.
- Stable applicationId/signing key are unchanged.

USER-REPORTED ISSUE
- In V17, EQ UI moves immediately but the audible DSP update can wait for the shared
  ~380 ms command scheduler slot, which feels like relay/delay while tuning each channel.

V28 CHANGE — TRANSPORT LATENCY ONLY
- EQ full-record writes get a dedicated callback-gated fast lane.
- First EQ target is dispatched as soon as AB01 is safe/free.
- Subsequent EQ targets are coalesced latest-target-wins with a minimum 120 ms interval.
- Exactly one live control write may be in flight.
- Continuous MOVE events never accumulate a packet backlog.
- Idle sensor polling is paused for 650 ms after the latest EQ gesture, then resumes.
- The 380 ms scheduler remains unchanged for scalar controls.
- TrebleBoost ID11 keeps the V17/V14 <=0.5 dB safe-slew policy.

WHAT V28 DOES NOT CHANGE
- No frequency remapping.
- No ISO-band conversion.
- No filter-type conversion.
- No coefficient formula changes.
- Band1 remains V17 native filter-aware behavior.
- No Crossover/Delay/Preset/routing hardware writes.
- No automatic SaveParams.

EXPECTED RUNTIME EFFECT
- When a writable EQ band is moved on CH1–CH7, the hardware should start responding
  without waiting for the next 380 ms scheduler tick. Real acoustic latency must still
  be confirmed on the physical DSP.
