# OKN DSP V28 — Phase 1 (rebased from V25)

Base: **V25 only**. V26 and V27 design changes are intentionally excluded.

## V28 rebase baseline

- Functional/UI behavior is carried directly from V25.
- Keeps V25 red + pink accents, V24 touch isolation, smooth canvas overlays, preset manager, persistence, safe-area handling, scrolling, sliders, and EQ behavior.
- Does **not** include the V26/V27 Home icon redesigns.
- This new version number is used so the automatic GitHub workflow selects this rebased package even if older V26/V27 ZIPs still exist in the repository.
- No orange or amber colors are reintroduced.

versionName: 28.0.0
versionCode: 1028
Phase: 1 stable V25 rebase
