# OKN DSP V45

V45 moves Out Volume Ch1-Ch7 away from the native Band1 G field after the V44 real-hardware video showed a loud transient even with the UI safely capped at 0 dB. Out Volume now uses the verified strict-safe PEQ Band2 carrier and scales only B0/B1/B2, preserving EQ metadata and denominator coefficients. Range remains -12..0 dB and hardware write occurs once on touch release.

# OKN DSP V44

Base: **V43 touch-release Out Volume + V42 verified native first-cell G mapping + V41 guarded Save/Restore/readback**.

V44 is a real-device safety correction. In the V43 hardware video a fast Out Volume gesture could reach +10/+12 dB and create a short loud burst. The convenience Out Volume control is therefore attenuation-only: **-12 dB to 0 dB**. Positive values are rejected both by the BLE entry point and by the protocol target builder.

V44 also removes the second `applySlider(..., ACTION_UP x)` sample for an active drag. The hardware commit now uses the last value already previewed during ACTION_MOVE, so a fast release coordinate cannot jump the target to an edge before the single commit. A stationary tap still applies and commits once.

The proven V42 mapping is unchanged: channel cascade actuator IDs `4,5,6,14,15,16,17`, first-record offset `0`, native `G` coefficient math, and one full 48-byte first-record write for the final settled value. No ChannelVolume actuator is invented.

DSP readback remains authoritative on connect/reconnect/refresh. CH3 Band1 and Out Volume Ch3 still refer to the same native General Low-pass `G` field. V38 safe-PEQ gating, V39 Safe Reset EQ, V40 readback, and V41 guarded Save/Restore remain unchanged.
