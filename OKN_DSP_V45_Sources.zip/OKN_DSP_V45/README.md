# OKN DSP V45

V45 targets the real-device symptom shown in `37857.mp4`: the Bass Volume slider moves through large positive values but audible bass stays almost unchanged.

## Bass Volume — restore the old +74 behavior
The V44 implementation sent the displayed number directly to BassVolume actuator **ID8** as FLOAT32. The real descriptor, however, defines ID8 around **-70..+6 dB**, while the user reports that an older UI became loud at displayed **+74**. V45 therefore restores an offset-style 0–100 Bass control:

`ID8 wire dB = Bass UI level - 70`

Examples: **+70 UI = 0 dB**, **+74 UI = +4 dB**, **+76 UI = +6 dB**, **+100 UI = +30 dB**. This lets the reported +74 position land near the real DSP's high-gain region instead of sending a literal +74 dB value that the audio path may not use. The UI shows both the 0–100 level and the actual ID8 dB readback.

ID8 final-write and hardware readback verification from V44 remain enabled. Values above the descriptor +6 dB are still permitted for device testing, up to +30 dB wire value.

## Unchanged
- No Bass Boost control/write (ID10 is not used by the Mix UI).
- Master Volume is not used to fake Bass gain.
- EQ order remains **CH1=ID4, CH2=ID5, CH3=ID6 Bass, CH4=ID14, CH5=ID15, CH6=ID16, CH7=ID17**.
- EQ actuator IDs, 15-band records, Gain/Frequency/Q limits, filter math and safe-row gate are unchanged.
- V42 audio-stability controls and V41 guarded Save/Restore remain.

Version: **45.0.0** (`versionCode 1045`).
