# OKN DSP V45 — Bass Volume Only / Verified ID8

V45 is based on V43 and deliberately removes the V44 Bass/Sub DSP Gain experiment. It does **not** use any EQ band to make the bass louder.

## What V45 changes
- Bass Volume remains the real hardware scalar actuator **ID8 / FLOAT32** only.
- Keeps the device-declared BassVolume range **-70..+6 dB**. No out-of-range gain is guessed or forced.
- After the latest Bass Volume write settles, V45 performs one small direct **ID8 readback** (`0x58`, length 4) and decodes the `0x60` FLOAT32 response.
- If the DSP does not return the requested value, V45 retries **ID8 only** up to 2 times and reports the real DSP value.
- No Bass/Sub EQ gain control is present; no EQ band is modified by this feature.
- V43 hard audio isolation remains: autonomous sensor polling stays disabled after sync.

## Why this build exists
The supplied screen recording shows Bass Volume reaching **+6.0 dB** while the audible bass remains very low. Previous UI code treated a successful GATT write callback as if the DSP had applied the value. V45 verifies the actual DSP-side BassVolume value instead.

The real device descriptor declares BassVolume as `min=-70,max=6,scale='linear',unit=dB`. If V45 reads back **+6.0 dB confirmed** and the bass is still very quiet, then the documented BassVolume actuator itself is already at its firmware maximum; making it louder would require changing another DSP/firmware stage, not an EQ band disguised as Bass Volume.

Version: **45.0.0** (`versionCode 1045`).
