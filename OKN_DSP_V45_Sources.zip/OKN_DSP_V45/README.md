# OKN DSP V45

V45 is based on **V44** and retains the fixes already confirmed on the real board: no connect thump, music-safe passive-poll guard, and music-safe Safe Reset EQ pacing.

## What V45 changes

- **Music-safe Band EQ:** while music is active/held, Gain/Frequency/Q changes update the UI immediately but are coalesced on the BLE/DSP side. Hardware waits **380 ms after the newest EQ interaction**, then sends only the latest pending target per band.
- **No multi-write burst during a drag:** if several bands are pending, EQ writes during music are spaced by at least **380 ms**.
- **No-music behavior retained:** Gain keeps the proven **45 ms** lane and Frequency/Q keeps the **110 ms** lane when music is not active.
- **Safe Reset retained:** gain-only, full-record, F/Q-preserving reset still uses the V44 music-safe pacing.
- **Verified CH mapping retained:** `CH1 → ID4`, `CH2 → ID5`, `CH3 → ID6`, `CH4 → ID14`, `CH5 → ID15`, `CH6 → ID16`, `CH7 → ID17`.

## Hi-Fi / Hi-Res boundary

The Android app is a DSP controller, not the PCM renderer. V45 reduces BLE-control bursts that can disturb Bluetooth audio; it does not change codec, bit depth or sample rate.

Version: **45.0.0** (`versionCode 1045`).
