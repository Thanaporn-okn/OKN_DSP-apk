# OKN DSP V45

V45 is the fail-closed response to the real-DSP V44 incident: Channel 1 trim usually changed level without changing EQ tone, but an occasional ~1 second loud transient coincided with other Channel Volume controls jumping to maximum. The V44 partial structured-biquad write is therefore rejected and is not present in V45.

V45 returns non-CH3 trims to the full 48-byte Band1 record path that previously changed CH1 level without the V44 cross-channel jump, but it no longer writes that record while normal audio is exposed. Every CH1/2/4/5/6/7 trim is a guarded transaction:

1. fresh authenticated Device Description precheck;
2. require S7/7, EQ105/105, sensors>=4, safe PEQ55/55 and Band1 pattern 17,17,3,17,17,17,17;
3. mute the verified MasterVolume ID2 to -70 dB;
4. wait 450 ms;
5. write one full Band1.G target record using the already-verified channel EQ actuator;
6. keep Master at -70 dB for 1800 ms;
7. fresh Device Description postcheck and compare every verified scalar and all 105 EQ rows against the intended snapshot;
8. restore the previous MasterVolume only if the complete postcheck matches.

If any other channel/row changes, any health gate fails, or GATT/TX state becomes uncertain, Master is **not** restored by the transaction. The session fails closed and requires reconnect/re-auth. Batch `Reset Channels` is locked in V45 so seven structured filter writes can never be launched together.

CH3 remains the already-proven ID8 BassVolume scalar path and does not use the structured Band1 guard.

No new actuator ID and no new packet format are introduced. V38 safe F/Q, V39 Safe Reset, V40 readback, and V41 guarded manual Save/Restore remain in place.

Version: **45.0.0** (`versionCode 1045`)

Current V45 proof/test notes:
- `Sources/V45_GUARDED_CHANNEL_TRIM.txt`
- `Sources/V45_V44_INCIDENT_ANALYSIS.txt`
- `Sources/V45_ORIGINAL_APP_FINDINGS.txt`
- `Sources/V45_VALIDATION_PROOF.txt`
- `Sources/V45_REAL_DSP_TEST_PLAN.txt`
- `Sources/validate_v45_guarded_channel_trim.py`

V45 is a real-DSP test candidate. V41 remains the safe rollback baseline until V45 is explicitly qualified on hardware.
