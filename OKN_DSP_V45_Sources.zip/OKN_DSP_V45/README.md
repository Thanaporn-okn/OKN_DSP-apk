# OKN DSP V45 — BP1048P4 Gain Probe

V45 is a diagnostic/safety release based on the real V44 hardware result.

**Normal output control**
- CH3 remains the hardware-confirmed `BassVolume` actuator ID8.
- CH1, CH2, CH4, CH5, CH6 and CH7 normal hardware fader writes are locked. V45 does not
  repeat the V44 48-byte Tone-Control write that produced the audible click.

**CH1 probe**
The Mix page has `CH1 -0.5 dB Probe` and `Restore CH1`. The probe writes only B0/B1/B2
(offset 28, length 12) of CH1 actuator ID4, applies a tiny attenuation, and automatically
restores the original three coefficients after 2.6 seconds. It never calls SaveParams and
Save is blocked while the probe is pending/active.

This is intentionally not called a working 7-channel Output Volume implementation yet.
Its purpose is to determine on the real BP1048P4 board whether a numerator-only update can
change level without the click caused by replacing the complete 48-byte filter record.

See `Sources/V45_BP1048P4_GAIN_PROBE.txt`.
