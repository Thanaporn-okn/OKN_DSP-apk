#!/usr/bin/env python3
from pathlib import Path
import hashlib, re

ROOT = Path(__file__).resolve().parents[1]
BLE = ROOT / 'app/src/main/java/com/okn/dsp/BleManager.java'
DSP = ROOT / 'app/src/main/java/com/okn/dsp/DspProtocol.java'
VIEW = ROOT / 'app/src/main/java/com/okn/dsp/DspView.java'
STATE = ROOT / 'app/src/main/java/com/okn/dsp/DspState.java'
GRADLE = ROOT / 'app/build.gradle'
ble, dsp, view, state, gradle = [p.read_text() for p in (BLE, DSP, VIEW, STATE, GRADLE)]

def method(text, marker):
    i = text.index(marker); b = text.index('{', i); depth = 0
    for j in range(b, len(text)):
        if text[j] == '{': depth += 1
        elif text[j] == '}':
            depth -= 1
            if depth == 0: return text[i:j+1]
    raise AssertionError('unclosed method ' + marker)

def sha(s): return hashlib.sha256(s.encode()).hexdigest()
def req(cond, msg):
    if not cond: raise AssertionError(msg)

req("versionCode 1045" in gradle and "versionName '45.0.0'" in gradle, 'V45 version mismatch')
req('bassUiFromWireDb' in view and 'wireDb + 70f' in view, 'wire->UI +70 mapping missing')
req('bassWireDbFromUi' in view and '- 70f' in view, 'UI->wire -70 mapping missing')
req('"Bass Volume 0–100 • +74 => ID8 +4 dB' in view, 'V45 +74 diagnostic note missing')
req('String.format(Locale.US, "+%.0f  • DSP %+.1f dB", bassUi, state.bassVolume)' in view,
    'Bass UI does not expose both legacy level and real ID8 dB')
req('bassVolume = clamp(value, -70f, 30f);' in state, 'Bass state wire range is not -70..+30 dB')
req('SL_BASS_BOOST' not in view and 'ID_BASS_BOOST' not in view, 'Bass Boost UI/write returned')

sanitize = method(dsp, '    static float sanitizeScalar(')
req(re.search(r'case ID_BASS_VOLUME:.*?lo = -70f; hi = 30f;', sanitize, re.S) is not None,
    'ID8 transmit gate is not -70..+30 dB')

# Exact mapping points that reproduce the user's formerly loud +74 position.
def wire(ui): return max(0.0, min(100.0, ui)) - 70.0
for ui, expected in [(0,-70), (70,0), (74,4), (76,6), (100,30)]:
    req(abs(wire(ui)-expected) < 1e-6, f'mapping failed: {ui}->{wire(ui)} expected {expected}')

# V44 final-write + hardware readback must remain active.
flush = method(ble, '    private void flushScalarRealtimeOnMain(')
req('actuatorId != DspProtocol.ID_BASS_VOLUME' in flush, 'Bass final-write hook missing')
req('sendScheduledControl(cmd);' in flush, 'final Bass write not sent immediately')
runtime = method(ble, '    private void handleRuntimePlain(')
req('decodeFloatReadResponse(plain, DspProtocol.ID_BASS_VOLUME)' in runtime, 'ID8 readback decoder missing')
req('listener.onScalarValue(DspProtocol.ID_BASS_VOLUME, actual)' in runtime, 'ID8 readback not published')
scheduler = method(ble, '    private void originalCommandSchedulerTick(')
req('DspProtocol.encodeRead(DspProtocol.ID_BASS_VOLUME, 0, 4)' in scheduler, 'ID8 read request missing')

# Correct channel order and frozen EQ writer/filter path must stay unchanged.
req('EQ_CHANNEL_DISPLAY_ORDER = {0, 1, 2, 3, 4, 5, 6};' in view, 'EQ CH display order changed')
req('static final int[] EQ_ACTUATORS = {4, 5, 6, 14, 15, 16, 17};' in dsp, 'EQ actuator map changed')

expected = {
'BleManager.setEqRealtime':'f4f738c886298e476dad58135a5d29b36937aaa7dbf7eabe7853dc8d9e761c9a',
'BleManager.setEqShapeRealtime':'e702693eccb788da71d156db94dc21824f1dacab20d19e1d89aaedceb94a6110',
'BleManager.scheduleEqRealtimePump':'a05ea21d9f11980fff095c6053ec81ccd5c7ba5d7a725ff2854f3f2a87bf6db6',
'BleManager.scheduleEqShapePump':'97a5c9080071ec5bce70999d2c7a122ad2e2a77d494a94f1040fd90662c4e26e',
'BleManager.sendScheduledControl':'8c39c0643084615777997900f428e3c32971bdd5e2afa0d768c04c4dbfedf777',
'BleManager.writeNoResponse':'e6895bee7c3f2d12c2531d7d48346559d6b00a4c227b38ecfc63f2ce2a9d9256',
'BleManager.resetEqSafe':'eab920cc4b25b018c9e263f1a43bf4391569119663db101954a2661803864d18',
'DspProtocol.peakingFromCurrent':'18f6cb0577c711ea817c8441f4b3b2fc91a4a5d5bae0d61051926074858b95ae',
'DspProtocol.peakingShapeFromCurrent':'e3f8d840e116bc3d32bad459db3883867f8afc62a87c8553131397ee133e4e86',
'DspProtocol.firstBandGainFromCurrent':'89f089d8d8bc6bfd54074e35e949fa393719d64d3884fc8ce133b99bc100ddee',
'DspProtocol.encodeEqWrite':'9de90148f2e6f390f9144ffc8f6c029a00ca6276bdeb8696aa319609573001e5',
}
checks = [
('BleManager.setEqRealtime', ble, '    void setEqRealtime('),
('BleManager.setEqShapeRealtime', ble, '    void setEqShapeRealtime('),
('BleManager.scheduleEqRealtimePump', ble, '    private void scheduleEqRealtimePump('),
('BleManager.scheduleEqShapePump', ble, '    private void scheduleEqShapePump('),
('BleManager.sendScheduledControl', ble, '    private void sendScheduledControl('),
('BleManager.writeNoResponse', ble, '    private boolean writeNoResponse('),
('BleManager.resetEqSafe', ble, '    int resetEqSafe('),
('DspProtocol.peakingFromCurrent', dsp, '    static EqBand peakingFromCurrent('),
('DspProtocol.peakingShapeFromCurrent', dsp, '    static EqBand peakingShapeFromCurrent('),
('DspProtocol.firstBandGainFromCurrent', dsp, '    static EqBand firstBandGainFromCurrent('),
('DspProtocol.encodeEqWrite', dsp, '    static byte[] encodeEqWrite('),
]
for name, text, marker in checks:
    body = method(text, marker)
    if name in ('BleManager.setEqRealtime','BleManager.setEqShapeRealtime','BleManager.resetEqSafe'):
        body = body.replace(' || saveActive', '')
    req(sha(body) == expected[name], name + ' changed unexpectedly')

print('V45_BASS_74_LEGACY_SCALE_PASS')
print('UI 74 -> ID8 +4 dB; UI 76 -> +6 dB; UI 100 -> +30 dB')
print('BassBoost=absent; Master compensation=none; EQ writer/filter/order=PASS')
