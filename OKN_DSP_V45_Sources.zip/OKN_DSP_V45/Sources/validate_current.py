#!/usr/bin/env python3
"""Current-version preflight entry point used by the reusable GitHub Actions workflow."""
from pathlib import Path
import runpy
HERE = Path(__file__).resolve().parent
runpy.run_path(str(HERE / 'validate_v45_gain_probe.py'), run_name='__main__')
