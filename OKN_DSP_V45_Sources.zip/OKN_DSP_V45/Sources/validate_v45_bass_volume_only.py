#!/usr/bin/env python3
from pathlib import Path
import re, sys
root = Path(__file__).resolve().parent.parent
ble = (root/'app/src/main/java/com/okn/dsp/BleManager.java').read_text()
dsp = (root/'app/src/main/java/com/okn/dsp/DspProtocol.java').read_text()
view = (root/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
build = (root/'app/build.gradle').read_text()
evidence = (root/'Sources/ProtocolEvidence/GoloPine_DeviceDescription_REAL_20260906_204555.json').read_text()
checks = {
    'version45': 'versionCode 1045' in build and "versionName '45.0.0'" in build,
    'id8': 'static final int ID_BASS_VOLUME = 8;' in dsp,
    'id8_range': 'case ID_BASS_VOLUME:' in dsp and 'lo = -70f; hi = 6f;' in dsp,
    'descriptor_range': '"name": "BassVolume"' in evidence and "min=-70,max=6" in evidence,
    'float_write_only': 'DspProtocol.encodeFloatWrite(id, value)' in ble,
    'direct_read': 'DspProtocol.encodeRead(DspProtocol.ID_BASS_VOLUME, 0, 4)' in ble,
    'read_response': 'decodeFloatReadResponse' in dsp and '(plain[0] & 0xff) != 0x60' in dsp,
    'readback_handler': 'handleBassReadback' in ble,
    'coalesced_settle': 'BASS_VERIFY_SETTLE_MS = 520L' in ble,
    'retry_cap': 'BASS_VERIFY_MAX_RETRIES = 2' in ble,
    'no_v44_bass_eq_slider': 'SL_BASS_CHANNEL_GAIN' not in view and 'Bass/Sub DSP Gain' not in view,
    'no_band1_bass_volume_hook': 'sendVerifiedEqGain(2, 0)' not in view,
    'hard_isolation': 'BACKGROUND_SENSOR_POLLING_ENABLED = false' in ble,
    'no_pcm_pipeline': all(x not in '\n'.join(p.read_text(errors='ignore') for p in (root/'app/src/main/java').rglob('*.java'))
                           for x in ('import android.media.AudioTrack;', 'import android.media.MediaPlayer;', 'androidx.media3.exoplayer')),
}
for k,v in checks.items(): print(f'{k}={"PASS" if v else "FAIL"}')
if not all(checks.values()): sys.exit(1)
print('V45_BASS_VOLUME_ONLY_STATIC_PASS')
