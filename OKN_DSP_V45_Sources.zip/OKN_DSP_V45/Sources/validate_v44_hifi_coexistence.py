#!/usr/bin/env python3
from pathlib import Path
import hashlib

root = Path(__file__).resolve().parents[1]
ble = (root/'app/src/main/java/com/okn/dsp/BleManager.java').read_text()
view = (root/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
proto = (root/'app/src/main/java/com/okn/dsp/DspProtocol.java').read_text()
gradle = (root/'app/build.gradle').read_text()

def method(text, marker):
    i = text.index(marker)
    b = text.index('{', i)
    depth = 0
    for j in range(b, len(text)):
        if text[j] == '{': depth += 1
        elif text[j] == '}':
            depth -= 1
            if depth == 0: return text[i:j+1]
    raise AssertionError('unclosed method ' + marker)

def sha(s):
    return hashlib.sha256(s.encode()).hexdigest()

scheduler = method(ble, '    private void originalCommandSchedulerTick(')
realtime_pump = method(ble, '    private void scheduleEqRealtimePump(')
guard = method(ble, '    private boolean isHiFiAudioGuardActive(')
interactive_pos = scheduler.find('if (next != null)')
guard_pos = scheduler.find('boolean musicGuardActive = isHiFiAudioGuardActive()')
return_pos = scheduler.find('if (musicGuardActive) return;')
poll_pos = scheduler.find('int idx = originalPollIndex % ORIGINAL_POLL_IDS.length;')

checks = {
    'V44 version': "versionCode 1044" in gradle and "versionName '44.0.0'" in gradle,
    'verified EQ mapping': 'static final int[] EQ_ACTUATORS = {4, 5, 6, 14, 15, 16, 17};' in proto,
    'raw music detection retained': 'audioManager.isMusicActive()' in ble,
    '8s dropout hold': 'AUDIO_GUARD_HOLD_MS = 8000L' in ble,
    'guard latches true sample': 'lastMusicActiveUptimeMs = now;' in guard,
    'guard holds after false sample': '(now - lastMusicActiveUptimeMs) < AUDIO_GUARD_HOLD_MS' in guard,
    'passive polls blocked after interactive lane': 0 <= interactive_pos < guard_pos < return_pos < poll_pos,
    'normal scheduler remains 380ms': 'ORIGINAL_COMMAND_CADENCE_MS = 380L' in ble,
    'reset no-music baseline remains 110ms': 'EQ_RESET_MIN_GAP_MS = 110L' in ble,
    'reset music cadence 380ms': 'EQ_RESET_MUSIC_MIN_GAP_MS = 380L' in ble,
    'reset pump selects music-safe cadence': 'isHiFiAudioGuardActive() ? EQ_RESET_MUSIC_MIN_GAP_MS : EQ_RESET_MIN_GAP_MS' in realtime_pump,
    'EQ gain lane remains 45ms': 'EQ_REALTIME_MIN_GAP_MS = 45L' in ble,
    'EQ shape lane remains 110ms': 'EQ_SHAPE_MIN_GAP_MS = 110L' in ble,
    'poll IDs unchanged': 'private static final int[] ORIGINAL_POLL_IDS = {19, 20, 0, 21};' in ble,
    'poll lengths unchanged': 'private static final int[] ORIGINAL_POLL_LENGTHS = {1, 1, 4, 4};' in ble,
    'no CH fake slider constant': 'SL_CHANNEL' not in view,
    'CH gain locked label': 'GAIN LOCKED' in view,
    'verified CH to EQ navigation': '"chEq" + ch' in view,
    'save ID7 retained': 'static final int ID_SAVE_PARAMS = 7;' in proto and 'encodeSaveParamsTrigger()' in proto,
    'manual save retained': 'void requestPersistentSave()' in ble,
    'readback restore retained': 'requestVerifiedRestore()' in ble,
}

expected = {
    'BleManager.setEqRealtime':'f4f738c886298e476dad58135a5d29b36937aaa7dbf7eabe7853dc8d9e761c9a',
    'BleManager.setEqShapeRealtime':'e702693eccb788da71d156db94dc21824f1dacab20d19e1d89aaedceb94a6110',
    'BleManager.scheduleEqRealtimePump':'bd474d8f3d50bf01f68a77ab05c6b7a79f412c9bab7391fa4b51cb51abe565c6',
    'BleManager.scheduleEqShapePump':'97a5c9080071ec5bce70999d2c7a122ad2e2a77d494a94f1040fd90662c4e26e',
    'BleManager.sendScheduledControl':'8c39c0643084615777997900f428e3c32971bdd5e2afa0d768c04c4dbfedf777',
    'BleManager.writeNoResponse':'e6895bee7c3f2d12c2531d7d48346559d6b00a4c227b38ecfc63f2ce2a9d9256',
    'BleManager.resetEqSafe':'eab920cc4b25b018c9e263f1a43bf4391569119663db101954a2661803864d18',
    'DspProtocol.peakingFromCurrent':'18f6cb0577c711ea817c8441f4b3b2fc91a4a5d5bae0d61051926074858b95ae',
    'DspProtocol.peakingShapeFromCurrent':'e3f8d840e116bc3d32bad459db3883867f8afc62a87c8553131397ee133e4e86',
    'DspProtocol.firstBandGainFromCurrent':'89f089d8d8bc6bfd54074e35e949fa393719d64d3884fc8ce133b99bc100ddee',
    'DspProtocol.encodeEqWrite':'9de90148f2e6f390f9144ffc8f6c029a00ca6276bdeb8696aa319609573001e5',
}
for name, text, marker in [
    ('BleManager.setEqRealtime', ble, '    void setEqRealtime('),
    ('BleManager.setEqShapeRealtime', ble, '    void setEqShapeRealtime('),
    ('BleManager.scheduleEqRealtimePump', ble, '    private void scheduleEqRealtimePump('),
    ('BleManager.scheduleEqShapePump', ble, '    private void scheduleEqShapePump('),
    ('BleManager.sendScheduledControl', ble, '    private void sendScheduledControl('),
    ('BleManager.writeNoResponse', ble, '    private boolean writeNoResponse('),
    ('BleManager.resetEqSafe', ble, '    int resetEqSafe('),
    ('DspProtocol.peakingFromCurrent', proto, '    static EqBand peakingFromCurrent('),
    ('DspProtocol.peakingShapeFromCurrent', proto, '    static EqBand peakingShapeFromCurrent('),
    ('DspProtocol.firstBandGainFromCurrent', proto, '    static EqBand firstBandGainFromCurrent('),
    ('DspProtocol.encodeEqWrite', proto, '    static byte[] encodeEqWrite('),
]:
    body = method(text, marker)
    if name in ('BleManager.setEqRealtime','BleManager.setEqShapeRealtime','BleManager.resetEqSafe'):
        body = body.replace(' || saveActive', '')
    checks['frozen '+name] = sha(body) == expected[name]

failed = [k for k,v in checks.items() if not v]
for k,v in checks.items():
    print(('PASS' if v else 'FAIL'), k)
if failed:
    raise SystemExit('V44 validation failed: ' + ', '.join(failed))
print('V44 validation PASS')
