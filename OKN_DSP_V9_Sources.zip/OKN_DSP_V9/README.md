# OKN DSP V9 — Phase 1

V9 restores the Preset-name popup used before V8. On the EQ page, tapping **New preset name…** or **Save Preset** opens the **Preset name** dialog. Enter the name there and press **Save**. Multiple named presets can still be selected, loaded and deleted.

EQ colors also follow the latest requested palette: **Frequency = blue**, **Q = cyan/teal**, **Gain Band = mint green**, while the spectrum-style 15-band graph and channel colors remain.
