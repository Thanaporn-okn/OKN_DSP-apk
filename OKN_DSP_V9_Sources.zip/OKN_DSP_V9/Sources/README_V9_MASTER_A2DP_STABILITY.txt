OKN_DSP V9 — MASTER VOLUME / BLUETOOTH AUDIO STABILITY
========================================================

Real-device result that triggered V9:
- V8 changes the DSP MasterVolume, but dragging still causes audible stutter/pumping.
- The original GoloPine app on the same phone/DSP is stable.

V9 changes only the control/transport behavior needed to close that gap:
1. BLE connection priority is BALANCED instead of HIGH.
2. Priority is explicitly returned to BALANCED after authenticated descriptor Health Gate passes.
3. MasterVolume leaves the V8 sparse/direct large-step path and uses callback-gated latest-target ramp.
4. Master step is adaptive 0.25..1.0 dB, nominal 85 ms after confirmed GATT write.
5. One GATT write remains in flight; stale finger samples are coalesced.
6. No tuning haptic/click feedback.
7. Protocol, AES-CFB8 stream, AB00/AB01/AB02, scalar ID2 and signing key are unchanged.

Reasoning:
- V6/V7/V8 prove the ID2 packet changes real hardware.
- Changing pacing alone did not remove the symptom.
- V8 still forced CONNECTION_PRIORITY_HIGH for the BLE link while the phone was also carrying Bluetooth audio.
- V9 removes that radio-priority difference and keeps Master writes smooth/bounded.

No claim of acoustic pass is made until this APK is tested on the physical DSP.
