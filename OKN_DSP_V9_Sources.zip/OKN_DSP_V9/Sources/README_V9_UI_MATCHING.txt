OKN_DSP V9 — Phase 1 UI Matching Pass

Base: V8
Goal: move the running UI closer to the supplied four-screen reference without embedding the reference image.
Changes: refined procedural mountain depth/snow highlights, enlarged vector DSP enclosure, rebalanced Home status layout, stronger Hear More / Feel More callout, version bump to 9.0.0.
Interaction behavior from V8 remains intact: responsive controls, event-driven redraw, local preset/session persistence, and fixed signing key for in-place updates.
Phase 2 DSP transport remains NOT STARTED.
