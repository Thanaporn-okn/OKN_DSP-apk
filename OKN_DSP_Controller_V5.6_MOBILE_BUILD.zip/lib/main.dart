import 'package:flutter/material.dart';

void main(){
  runApp(const OKN());
}

class OKN extends StatelessWidget{
  const OKN({super.key});

  @override
  Widget build(BuildContext context){
    return MaterialApp(
      debugShowCheckedModeBanner:false,
      theme: ThemeData.dark(),
      home: const Scaffold(
        body: Center(
          child: Text('OKN DSP Controller V5.6\nMobile Build Ready'),
        ),
      ),
    );
  }
}
