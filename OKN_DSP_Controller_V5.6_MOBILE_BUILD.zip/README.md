OKN DSP Controller V5.6 Mobile Build

สำหรับ Upload ผ่านมือถือ:
นำไฟล์ทั้งหมดใน ZIP ขึ้น Root ของ GitHub Repository

ต้องเห็น:
.github/
lib/
pubspec.yaml

Workflow ไม่มี ZIP extraction และไม่มี Find Gradle Project.
