# OKN_DSP v4

ปรับ UI ตามรูปอ้างอิงล่าสุด 2 รูป โดยเน้นสัดส่วนบนมือถือและการใช้งานจริง

- หน้า Home ปรับตำแหน่ง header, device card, slider cards, preset และ bottom navigation ตามภาพ
- หน้า EQ ปรับ top tabs, graph, 7-band cards และ bottom navigation ตามภาพ
- ใช้สเกลตามความกว้างหน้าจอและเลื่อนแนวตั้งเมื่อพื้นที่ไม่พอ
- Slider หน้า Home และ EQ ใช้งานได้
- Reset EQ ใช้งานได้
- Preset Flat / Pop / Rock / Jazz / Vocal ใช้งานได้
- สถานะ UI ถูกบันทึกไว้เมื่อปิด/เปิดแอปใหม่
- ปุ่มเชื่อมต่อเป็น UI state เท่านั้น ยังไม่เชื่อม BLE/DSP จริง
- ยังไม่เพิ่ม Delay / Crossover / Output ใน v4
