#!/usr/bin/env python3
"""V28 read-only hardware discovery verifier.

This module validates content-bound enumeration captures only. It never sends
vendor commands, programmer packets, erase/program requests, boot-mode
sequences, or target writes, and it cannot authorize hardware by itself.
"""
from __future__ import annotations
from pathlib import Path
import argparse, hashlib, json, re
from android_discovery_capture import validate_capture_file

PROJECT_VERSION = 28
SCHEMA = 1
POLICY = "READ_ONLY_DISCOVERY_NO_VENDOR_COMMANDS_NO_AUTHORIZATION"
HEX64 = re.compile(r"^[0-9a-f]{64}$")
ALLOWED_KINDS = {
    "android_usb_enumeration",
    "android_ble_advertisement",
    "android_serial_enumeration",
    "vendor_tool_readonly_log",
    "board_photo_metadata",
}


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _safe_capture(root: Path, bundle_root: str, rel: str | None):
    if not isinstance(bundle_root, str) or not bundle_root:
        return None, "bundle_root missing"
    b = Path(bundle_root)
    if b.is_absolute() or ".." in b.parts:
        return None, "bundle_root must be relative and traversal-free"
    base = root / b
    if not isinstance(rel, str) or not rel:
        return None, "capture path missing"
    p = Path(rel)
    if p.is_absolute() or ".." in p.parts:
        return None, "capture path must be relative and traversal-free"
    full = base / p
    try:
        full.resolve().relative_to(base.resolve())
    except ValueError:
        return None, "capture path escapes bundle root"
    if full.is_symlink():
        return None, "symlink capture is forbidden"
    if not full.is_file():
        return None, "capture file missing"
    return full, None


def load_and_verify(manifest_path: Path, root: Path | None = None) -> dict:
    manifest_path = Path(manifest_path)
    root = Path(root) if root is not None else manifest_path.parent
    root = root.resolve()
    m = json.loads(manifest_path.read_text())
    errors: list[str] = []

    if m.get("schema") != SCHEMA: errors.append("discovery schema mismatch")
    if m.get("project_version") != PROJECT_VERSION: errors.append("discovery project_version mismatch")
    if m.get("target") != "BP1048P4" or m.get("board") != "GoloPine 7CH": errors.append("target/board mismatch")
    if m.get("policy") != POLICY: errors.append("discovery policy mismatch")
    if m.get("automatic_authorization") is not False: errors.append("automatic authorization is forbidden")
    if m.get("android_host_transport_verified") is not False: errors.append("discovery capture may not directly verify android_host_transport")

    safety = m.get("safety", {})
    required_safety = {
        "read_only_only": True,
        "vendor_commands_allowed": False,
        "programmer_packets_allowed": False,
        "destructive_io_allowed": False,
        "capture_does_not_authorize": True,
    }
    for k, v in required_safety.items():
        if safety.get(k) is not v: errors.append("safety mismatch: " + k)

    captures = m.get("captures", [])
    if not isinstance(captures, list):
        errors.append("captures must be a list")
        captures = []
    ids: set[str] = set()
    valid = 0
    kinds: set[str] = set()
    bundle_root = m.get("bundle_root")
    for i, rec in enumerate(captures):
        prefix = f"capture[{i}]"
        if not isinstance(rec, dict):
            errors.append(prefix + ": record must be object"); continue
        cid = rec.get("id")
        if not isinstance(cid, str) or not cid:
            errors.append(prefix + ": id missing")
        elif cid in ids:
            errors.append(prefix + ": duplicate id")
        else:
            ids.add(cid)
        kind = rec.get("kind")
        if kind not in ALLOWED_KINDS: errors.append(prefix + ": unsupported kind")
        else: kinds.add(kind)
        if rec.get("read_only") is not True: errors.append(prefix + ": read_only must be true")
        if rec.get("write_attempted") is not False: errors.append(prefix + ": write_attempted must be false")
        if rec.get("commands_sent") != []: errors.append(prefix + ": commands_sent must be empty")
        full, err = _safe_capture(root, bundle_root, rec.get("path"))
        if err:
            errors.append(prefix + ": " + err); continue
        declared = rec.get("sha256")
        if not isinstance(declared, str) or not HEX64.fullmatch(declared):
            errors.append(prefix + ": sha256 invalid"); continue
        if sha256_file(full) != declared:
            errors.append(prefix + ": sha256 mismatch"); continue
        if rec.get("capture_format") == "android_discovery_capture_v1":
            inner = validate_capture_file(full)
            if not inner.get("ok"):
                errors.append(prefix + ": inner Android capture invalid: " + "; ".join(inner.get("errors", []))); continue
            if rec.get("canonical_sha256") != inner.get("canonical_sha256"):
                errors.append(prefix + ": canonical capture hash mismatch"); continue
            expected_kind = {"usb_host":"android_usb_enumeration","ble":"android_ble_advertisement","serial_enumeration":"android_serial_enumeration"}.get(inner.get("transport"))
            if kind != expected_kind:
                errors.append(prefix + ": kind/inner transport mismatch"); continue
        valid += 1

    expected_state = "CAPTURE_READY_FOR_REVIEW_NOT_AUTHORIZED" if captures and not errors else "LOCKED_NO_CAPTURE"
    if m.get("state") != expected_state:
        errors.append("discovery state is stale or inconsistent")

    return {
        "ok": not errors,
        "state": m.get("state"),
        "capture_count": len(captures),
        "valid_capture_count": valid,
        "observed_kinds": sorted(kinds),
        "review_ready": bool(captures) and not errors,
        "hardware_authorized": False,
        "mobile_flash_authorized": False,
        "programmer_io_available": False,
        "errors": errors,
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="Verify V28 read-only hardware discovery captures; never writes hardware.")
    ap.add_argument("--root", default=".")
    ap.add_argument("--expect-empty", action="store_true")
    a = ap.parse_args()
    root = Path(a.root).resolve()
    r = load_and_verify(root / "hardware_discovery_manifest.json", root)
    print("HARDWARE_DISCOVERY=" + ("REVIEW_READY" if r["review_ready"] else "LOCKED"))
    print("PROGRAMMER_IO=NOT_IMPLEMENTED")
    for e in r["errors"]:
        print("BLOCKED:" + e)
    if a.expect_empty and (r["capture_count"] != 0 or r["review_ready"]):
        print("ERROR: shipped V28 discovery bundle must remain empty/locked")
        return 1
    return 0 if r["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
