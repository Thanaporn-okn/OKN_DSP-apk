#!/usr/bin/env python3
from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'evidence_manifest.json').read_text())
errors=[]
if m.get('schema')!=4: errors.append('evidence schema must be 4')
if m.get('project_version')!=28: errors.append('project_version must be 28')
if m.get('target')!='BP1048P4' or m.get('board')!='GoloPine 7CH': errors.append('target/board mismatch')
if m.get('policy')!='FAIL_CLOSED_NO_INFERENCE': errors.append('policy mismatch')
if m.get('hardware_authorized') is not False: errors.append('hardware_authorized must be false')
req=m.get('required_exact_evidence',{})
if any(bool(v) for v in req.values()): errors.append('V28 exact evidence flags must all remain false')
prov=m.get('provenance',{})
if prov.get('previous_source_sha256')!='01a0ea0e1c7646f79d3ffe34f75110ace36cec7bcced3e34e19a291e24761fe5': errors.append('V27 source provenance mismatch')
if prov.get('validation_zip_sha256')!='2c9cadb2374696d62908bf7fbb344bac8c5488d019042be9f2ef0da123da7150': errors.append('V27 validation provenance mismatch')
if not any(o.get('id')=='v27-ci-validation' for o in m.get('observations',[])): errors.append('V27 CI observation missing')
for ob in m.get('observations',[]):
    if ob.get('authorizes') not in ([],None): errors.append('observations may not authorize hardware in V28')
if errors:
    [print('BLOCKED:',e) for e in errors]; sys.exit(1)
print('PASS: V28 evidence manifest is internally consistent and non-authorizing')
