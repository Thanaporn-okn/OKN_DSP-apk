# OKN_BP1048P4_FW_V28

V28 is a target-toolchain acceptance hardening revision of the portable clean-room firmware foundation. It preserves V27 wire/persistence golden vectors, fuzzing, provenance, evidence gates, mobile-flash safety boundaries, and all fail-closed hardware locks.

## What V28 adds

- A compile-only target toolchain contract for the C/ABI assumptions the portable core actually needs.
- Explicit requirements for 8-bit bytes, exact 8/16/32-bit integers, and IEEE-754 binary32-compatible `float` because persistence stores canonical float bit patterns.
- `tools/toolchain_probe.py --cc <compiler>` which invokes only the compiler's `-c` stage: no link, no target execution, no image emission, and no hardware/programmer I/O.
- GCC and Clang host compiler-matrix coverage now includes the compile-only toolchain contract before golden-vector execution.
- Persistence generation ordering no longer relies on implementation-defined `uint32_t -> int32_t` conversion; wrap ordering uses unsigned half-range serial arithmetic with a regression test across `UINT32_MAX -> 0`.
- Passing this harness never authorizes BP1048P4/GoloPine hardware, linker placement, programmer transport, image format, or mobile flashing.

## Safety state

Protocol V2 remains unchanged and persistence remains schema 2. Exact BP1048P4/GoloPine hardware integration, target linker/memory map, programmer transport, flash image format, recovery path, RAM placement, Android programmer transport, and all destructive execution remain locked. No `.bin`/`.img` is produced or shipped.

## Preserved project details

## Safety status

- Exact BP1048P4/GoloPine hardware integration: LOCKED.
- Hardware flashable: NO.
- Mobile flashable: NO.
- Programmer I/O: NOT IMPLEMENTED.
- Destructive executor: NOT IMPLEMENTED.
- Target `.bin/.img`: NONE.
- No guessed register/address/pin/programmer packet is introduced by V28.
