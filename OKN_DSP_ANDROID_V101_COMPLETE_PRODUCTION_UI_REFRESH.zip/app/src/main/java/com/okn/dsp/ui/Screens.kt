package com.okn.dsp.ui

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Space
import android.widget.TextView
import com.okn.dsp.protocol.EqBand48
import com.okn.dsp.protocol.LiveEqPolicy
import com.okn.dsp.protocol.ParameterMapper
import com.okn.dsp.protocol.VerifiedScalarControls
import com.okn.dsp.state.ConnectionState
import com.okn.dsp.state.DspState
import java.util.Locale
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.roundToInt

interface UiActions {
    fun scanConnect()
    fun disconnect()
    fun reconnect()
    fun refresh()
    fun scalarChanged(id: Int, value: Float)
    fun channelSelected(channel: Int, openEditor: Boolean)
    fun bandSelected(band: Int)
    fun eqChanged(channel: Int, band: Int, frequency: Float, q: Float, gain: Float)
    fun linkAllChanged(enabled: Boolean)
    fun saveParams()
    fun showLogs()
    fun resetEqViewport()
}

interface BoundScreen {
    val view: View
    fun bind(state: DspState)
}

private fun Context.scrollPage(content: LinearLayout): ScrollView = ScrollView(this).apply {
    isFillViewport = true
    clipToPadding = false
    setBackgroundColor(OknColors.BG)
    addView(content, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
}

private fun Context.pageColumn(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    setPadding(dp(14), 0, dp(14), dp(22))
}

private fun formatControl(id: Int, v: Float?): String {
    if (v == null || !v.isFinite()) return "--"
    val c = VerifiedScalarControls.byId(id) ?: return "--"
    return if (c.unit == "Hz") {
        String.format(Locale.US, "%.0f Hz", v)
    } else {
        String.format(Locale.US, "%+.1f dB", v).replace("+0.0", "0.0")
    }
}

private fun channelColor(ch: Int): Int = when (ch) {
    1 -> OknColors.BLUE
    2 -> OknColors.CYAN
    3 -> OknColors.PURPLE
    4 -> OknColors.YELLOW
    5 -> OknColors.GREEN
    6 -> OknColors.PINK
    else -> OknColors.ORANGE
}

private fun connectionText(state: ConnectionState): String = when (state) {
    ConnectionState.DISCONNECTED -> "Disconnected"
    ConnectionState.SCANNING -> "Scanning"
    ConnectionState.CONNECTING -> "Connecting"
    ConnectionState.DISCOVERING -> "Discovering"
    ConnectionState.AUTHENTICATING -> "Authenticating"
    ConnectionState.SYNCHRONIZING -> "Synchronizing"
    ConnectionState.CONNECTED -> "Connected"
    ConnectionState.RECONNECTING -> "Reconnecting"
    ConnectionState.FAILED -> "Connection failed"
}

private fun connectionColor(state: ConnectionState): Int = when (state) {
    ConnectionState.CONNECTED -> OknColors.GREEN
    ConnectionState.FAILED -> OknColors.RED
    ConnectionState.DISCONNECTED -> OknColors.MUTED
    else -> OknColors.CYAN
}

class HomeScreen(private val context: Context, private val actions: UiActions) : BoundScreen {
    private val root = context.pageColumn()
    override val view: View = context.scrollPage(root)

    private val statusDot = context.text("●", 12, OknColors.MUTED, true, Gravity.CENTER)
    private val status = context.text("Disconnected", 13, OknColors.MUTED, true)
    private val deviceName = context.text("Tap Connect to find your DSP", 10, OknColors.MUTED)
    private val connectButton = context.neonButton("Connect DSP") { actions.scanConnect() }
    private val deviceTitle = context.text("OKN DSP 7CH", 18, OknColors.TEXT, true)
    private val deviceSub = context.text("Waiting for device description", 11, OknColors.MUTED)
    private val fw = context.text("Firmware  --", 10, OknColors.MUTED)
    private val health = context.text("NOT READY", 10, OknColors.MUTED, true, Gravity.CENTER)
    private val masterValue = context.text("--", 26, OknColors.CYAN, true, Gravity.END)
    private val masterSeek = context.makeSeek(-70f, 6f, -70f) { v, fromUser ->
        if (fromUser) actions.scalarChanged(2, v)
    }
    private val writesValue = context.text("0", 19, OknColors.TEXT, true)
    private val eqValue = context.text("0 / 105", 19, OknColors.TEXT, true)
    private val sessionValue = context.text("Idle", 19, OknColors.TEXT, true)
    private val channelButtons = mutableListOf<TextView>()
    private var linkAll = false
    private val linkText = context.text("Link EQ", 10, OknColors.CYAN, true, Gravity.CENTER)

    init {
        root.addView(context.appBar())
        root.addView(heroConnection(), LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(7) })
        root.addView(masterCard(), LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(12) })
        root.addView(statusMetrics(), LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(10) })
        root.addView(channelSection(), LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(15) })
        root.addView(context.text("Only verified DSP controls are writable. Unknown hardware functions remain locked.", 9, OknColors.MUTED, false, Gravity.CENTER).apply {
            setPadding(0, context.dp(14), 0, 0)
        })
    }

    private fun heroConnection(): View = context.card(OknColors.BORDER, Color.rgb(10, 25, 40), 22).apply {
        addView(context.row().apply {
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                addView(context.row().apply {
                    addView(statusDot, LinearLayout.LayoutParams(context.dp(20), context.dp(24)))
                    addView(status)
                })
                addView(deviceName, LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(3) })
            }, LinearLayout.LayoutParams(0, -2, 1f))
            addView(health.apply {
                background = roundedBg(OknColors.CARD_ALT, context.dp(30).toFloat(), OknColors.BORDER_SOFT, context.dp(1))
                setPadding(context.dp(9), context.dp(5), context.dp(9), context.dp(5))
            })
        })

        addView(context.row().apply {
            addView(GlowDspView(context), LinearLayout.LayoutParams(context.dp(126), context.dp(105)))
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_VERTICAL
                addView(deviceTitle)
                addView(deviceSub, LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(4) })
                addView(fw, LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(5) })
            }, LinearLayout.LayoutParams(0, context.dp(105), 1f).apply { leftMargin = context.dp(12) })
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(10) })

        addView(connectButton, LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(12) })
    }

    private fun masterCard(): View = context.card(OknColors.BORDER_SOFT, OknColors.CARD, 20).apply {
        addView(context.row().apply {
            addView(context.text("MASTER", 10, OknColors.MUTED, true).apply { letterSpacing = 0.12f }, LinearLayout.LayoutParams(0, -2, 1f))
            addView(context.pill("PHONE SYNC", OknColors.GREEN))
        })
        addView(context.row().apply {
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                addView(context.text("Master Volume", 17, OknColors.TEXT, true))
                addView(context.text("ระดับเสียงหลัก • DSP + ปุ่มเสียงมือถือ", 10, OknColors.MUTED), LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(2) })
            }, LinearLayout.LayoutParams(0, -2, 1f))
            addView(masterValue, LinearLayout.LayoutParams(context.dp(112), -2))
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(9) })
        addView(masterSeek, LinearLayout.LayoutParams(-1, context.dp(44)).apply { topMargin = context.dp(4) })
        addView(context.row().apply {
            addView(context.text("-70 dB", 9, OknColors.MUTED), LinearLayout.LayoutParams(0, -2, 1f))
            addView(context.text("+6 dB", 9, OknColors.MUTED, false, Gravity.END), LinearLayout.LayoutParams(0, -2, 1f))
        })
    }

    private fun statusMetrics(): View = context.row().apply {
        addView(context.metric("WRITES", writesValue), LinearLayout.LayoutParams(0, context.dp(73), 1f))
        addView(context.metric("EQ DATA", eqValue, OknColors.PURPLE), LinearLayout.LayoutParams(0, context.dp(73), 1f).apply { leftMargin = context.dp(7) })
        addView(context.metric("QUEUE", sessionValue, OknColors.GREEN), LinearLayout.LayoutParams(0, context.dp(73), 1f).apply { leftMargin = context.dp(7) })
    }

    private fun channelSection(): View = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        addView(context.row().apply {
            addView(context.sectionHeader("Channels", "แตะช่องเพื่อเปิด Parametric EQ"), LinearLayout.LayoutParams(0, -2, 1f))
            addView(linkText.apply {
                background = roundedBg(OknColors.CARD_ALT, context.dp(12).toFloat(), OknColors.BORDER, context.dp(1))
                setPadding(context.dp(11), context.dp(7), context.dp(11), context.dp(7))
                setOnClickListener { actions.linkAllChanged(!linkAll) }
            })
        })

        val grid = GridLayout(context).apply {
            columnCount = 2
            setPadding(0, context.dp(9), 0, 0)
        }
        DspState.CHANNELS.forEach { ch ->
            val button = context.text("${ch.shortName}\n${ch.displayName}", 12, OknColors.TEXT, true).apply {
                gravity = Gravity.CENTER_VERTICAL
                background = roundedBg(OknColors.CARD_ALT, context.dp(16).toFloat(), OknColors.BORDER_SOFT, context.dp(1))
                setPadding(context.dp(13), context.dp(10), context.dp(13), context.dp(10))
                setOnClickListener { actions.channelSelected(ch.index, true) }
                isClickable = true
            }
            channelButtons += button
            grid.addView(button, GridLayout.LayoutParams().apply {
                width = 0
                height = context.dp(65)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(context.dp(3), context.dp(3), context.dp(3), context.dp(3))
            })
        }
        addView(grid, LinearLayout.LayoutParams(-1, -2))
    }

    override fun bind(state: DspState) {
        val color = connectionColor(state.connection)
        val connected = state.connection == ConnectionState.CONNECTED
        status.text = connectionText(state.connection)
        status.setTextColor(color)
        statusDot.setTextColor(color)
        deviceName.text = state.device.bluetoothName ?: state.connectionMessage
        deviceTitle.text = state.device.bluetoothName ?: "OKN DSP 7CH"
        deviceSub.text = state.device.address ?: if (connected) "Authenticated DSP session" else "Waiting for device description"
        fw.text = "Firmware  ${state.device.firmwareText ?: "--"}"
        health.text = if (state.healthGatePass) "READY" else "NOT READY"
        health.setTextColor(if (state.healthGatePass) OknColors.GREEN else OknColors.MUTED)
        health.background = roundedBg(
            if (state.healthGatePass) Color.rgb(13, 58, 46) else OknColors.CARD_ALT,
            context.dp(30).toFloat(),
            if (state.healthGatePass) OknColors.GREEN else OknColors.BORDER_SOFT,
            context.dp(1),
        )
        connectButton.text = if (connected) "Manage Connection" else if (state.connection == ConnectionState.SCANNING) "Scanning…" else "Connect DSP"

        val master = state.scalars[2]
        masterValue.text = formatControl(2, master)
        masterSeek.isEnabled = master != null && state.healthGatePass
        masterSeek.alpha = if (masterSeek.isEnabled) 1f else .45f
        master?.let { masterSeek.progress = (((it + 70f) / 76f).coerceIn(0f, 1f) * 1000).roundToInt() }

        writesValue.text = state.writesSent.toString()
        val eqCount = state.eq.sumOf { row -> row.count { it != null } }
        eqValue.text = "$eqCount / 105"
        sessionValue.text = if (state.protocolIdle) "Idle" else "Busy"
        sessionValue.setTextColor(if (state.protocolIdle) OknColors.GREEN else OknColors.YELLOW)

        linkAll = state.linkAllEq
        linkText.text = if (linkAll) "Linked ON" else "Link EQ"
        linkText.setTextColor(if (linkAll) OknColors.GREEN else OknColors.CYAN)
        channelButtons.forEachIndexed { i, button ->
            val hasData = state.eq[i].any { it != null }
            val selected = state.selectedChannel == i + 1
            val accent = channelColor(i + 1)
            button.alpha = if (hasData) 1f else .55f
            button.background = roundedBg(
                if (selected) Color.rgb(20, 42, 61) else OknColors.CARD_ALT,
                context.dp(16).toFloat(),
                if (selected || hasData) accent else OknColors.BORDER_SOFT,
                context.dp(1),
            )
        }
    }
}

class GlobalScreen(private val context: Context, private val actions: UiActions) : BoundScreen {
    private data class RowRefs(val value: TextView, val seek: SeekBar)
    private val refs = linkedMapOf<Int, RowRefs>()
    private val root = context.pageColumn()
    override val view: View = context.scrollPage(root)

    init {
        root.addView(context.appBar())
        root.addView(context.sectionHeader("Sound Controls", "ค่าที่ผ่านการยืนยันและเขียน DSP ได้จริง"), LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = context.dp(7)
            bottomMargin = context.dp(5)
        })
        root.addView(context.pill("7 VERIFIED CONTROLS", OknColors.GREEN), LinearLayout.LayoutParams(-2, -2).apply { bottomMargin = context.dp(12) })

        ParameterMapper.globals.forEachIndexed { index, meta ->
            if (index == 0) root.addView(context.sectionLabel("LEVEL"), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = context.dp(6) })
            if (index == 2) root.addView(context.sectionLabel("BASS"), LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(7); bottomMargin = context.dp(6) })
            if (index == 5) root.addView(context.sectionLabel("TONE"), LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(7); bottomMargin = context.dp(6) })

            val control = VerifiedScalarControls.byId(meta.id) ?: return@forEachIndexed
            val value = context.text("--", 19, OknColors.CYAN, true, Gravity.END)
            val seek = context.makeSeek(control.min, control.max, control.min) { v, from ->
                if (from) actions.scalarChanged(meta.id, v)
            }
            refs[meta.id] = RowRefs(value, seek)
            root.addView(controlCard(meta.id, meta.title, meta.thai, meta.symbol, control.min, control.max, control.unit, value, seek), LinearLayout.LayoutParams(-1, -2).apply {
                bottomMargin = context.dp(8)
            })
        }
    }

    private fun controlCard(
        id: Int,
        title: String,
        thai: String,
        symbol: String,
        min: Float,
        max: Float,
        unit: String,
        value: TextView,
        seek: SeekBar,
    ): View = context.card(OknColors.BORDER_SOFT, OknColors.CARD, 18).apply {
        addView(context.row().apply {
            addView(context.text(symbol, 24, if (id == 11) OknColors.YELLOW else OknColors.CYAN, true, Gravity.CENTER).apply {
                background = roundedBg(OknColors.SURFACE, context.dp(13).toFloat())
            }, LinearLayout.LayoutParams(context.dp(46), context.dp(46)))
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                addView(context.text(title.replace("Volume", " Volume").replace("Boost", " Boost").replace("Cutoff", " Cutoff").trim(), 14, OknColors.TEXT, true))
                addView(context.text(thai, 10, OknColors.MUTED), LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(2) })
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = context.dp(10) })
            addView(value, LinearLayout.LayoutParams(context.dp(110), -2))
        })
        addView(seek, LinearLayout.LayoutParams(-1, context.dp(41)).apply { topMargin = context.dp(5) })
        addView(context.row().apply {
            val minText = if (unit == "Hz") "${min.toInt()} Hz" else "${min.toInt()} dB"
            val maxText = if (unit == "Hz") "${max.toInt()} Hz" else "+${max.toInt()} dB"
            addView(context.text(minText, 9, OknColors.MUTED), LinearLayout.LayoutParams(0, -2, 1f))
            addView(context.text(maxText, 9, OknColors.MUTED, false, Gravity.END), LinearLayout.LayoutParams(0, -2, 1f))
        })
        if (id == 11) {
            addView(context.text("Safe-slew active • changes are stepped to reduce transient risk", 9, OknColors.YELLOW).apply {
                setPadding(0, context.dp(7), 0, 0)
            })
        }
    }

    override fun bind(state: DspState) {
        refs.forEach { (id, ref) ->
            val control = VerifiedScalarControls.byId(id) ?: return@forEach
            val value = state.scalars[id]
            ref.value.text = formatControl(id, value)
            ref.seek.isEnabled = value != null && state.healthGatePass
            ref.seek.alpha = if (ref.seek.isEnabled) 1f else .45f
            value?.let {
                ref.seek.progress = (((it - control.min) / (control.max - control.min)).coerceIn(0f, 1f) * 1000).roundToInt()
            }
        }
    }
}

class EqScreen(private val context: Context, private val actions: UiActions) : BoundScreen {
    private val host = FrameLayout(context).apply { setBackgroundColor(OknColors.BG) }
    override val view: View = host
    private var editor = false
    private var lastState = DspState()
    private var overview: EqOverview? = null
    private var edit: EqEditor? = null

    init { showOverview() }

    fun openEditor(channel: Int) {
        actions.channelSelected(channel, false)
        editor = true
        rebuild()
    }

    fun isEditor(): Boolean = editor

    fun backToOverview(): Boolean {
        if (!editor) return false
        editor = false
        rebuild()
        return true
    }

    fun resetViewport() { edit?.graph?.resetViewport() }

    private fun rebuild() {
        host.removeAllViews()
        if (editor) {
            val e = EqEditor(context, actions) {
                editor = false
                rebuild()
            }
            edit = e
            overview = null
            host.addView(e.view)
            e.bind(lastState)
        } else {
            showOverview()
        }
    }

    private fun showOverview() {
        host.removeAllViews()
        val o = EqOverview(context, actions) { ch -> openEditor(ch) }
        overview = o
        edit = null
        host.addView(o.view)
        o.bind(lastState)
    }

    override fun bind(state: DspState) {
        lastState = state
        if (editor) edit?.bind(state) else overview?.bind(state)
    }

    private class EqOverview(
        private val context: Context,
        private val actions: UiActions,
        private val open: (Int) -> Unit,
    ) : BoundScreen {
        private val root = context.pageColumn()
        override val view: View = context.scrollPage(root)
        private val graphs = mutableListOf<EqCurveView>()
        private val link = context.text("Link all channels", 10, OknColors.CYAN, true, Gravity.CENTER)
        private var linked = false

        init {
            root.addView(context.appBar())
            root.addView(context.row().apply {
                addView(context.sectionHeader("Parametric EQ", "7 channels • 15 bands per channel"), LinearLayout.LayoutParams(0, -2, 1f))
                addView(link.apply {
                    background = roundedBg(OknColors.CARD_ALT, context.dp(13).toFloat(), OknColors.BORDER, context.dp(1))
                    setPadding(context.dp(10), context.dp(8), context.dp(10), context.dp(8))
                    setOnClickListener { actions.linkAllChanged(!linked) }
                })
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(7); bottomMargin = context.dp(10) })

            root.addView(context.text("Tap a channel to edit. Only verified PEAKING type=12 bands are writable.", 10, OknColors.MUTED), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = context.dp(10) })

            DspState.CHANNELS.forEach { channel ->
                val graph = EqCurveView(context)
                graphs += graph
                root.addView(context.card(OknColors.BORDER_SOFT, OknColors.CARD, 18).apply {
                    addView(context.row().apply {
                        addView(context.text("●", 17, channelColor(channel.index), true, Gravity.CENTER), LinearLayout.LayoutParams(context.dp(28), context.dp(36)))
                        addView(LinearLayout(context).apply {
                            orientation = LinearLayout.VERTICAL
                            addView(context.text("${channel.shortName}  ${channel.displayName}", 14, OknColors.TEXT, true))
                            addView(context.text("Live response from DSP coefficients", 9, OknColors.MUTED))
                        }, LinearLayout.LayoutParams(0, -2, 1f))
                        addView(context.text("Edit  ›", 11, OknColors.CYAN, true, Gravity.END))
                    })
                    addView(graph, LinearLayout.LayoutParams(-1, context.dp(116)).apply { topMargin = context.dp(5) })
                }.apply {
                    setOnClickListener { open(channel.index) }
                    isClickable = true
                }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = context.dp(8) })
            }
        }

        override fun bind(state: DspState) {
            linked = state.linkAllEq
            graphs.forEachIndexed { i, graph ->
                graph.bind(state.eq[i], channelColor(i + 1), state.selectedEqBand)
            }
            link.text = if (state.linkAllEq) "Linked • ON" else "Link all channels"
            link.setTextColor(if (state.linkAllEq) OknColors.GREEN else OknColors.CYAN)
        }
    }

    private class EqEditor(
        private val context: Context,
        private val actions: UiActions,
        private val back: () -> Unit,
    ) : BoundScreen {
        private val root = context.pageColumn()
        override val view: View = context.scrollPage(root)
        val graph = EqCurveView(context)
        private val channelChips = mutableListOf<TextView>()
        private val bandChips = mutableListOf<TextView>()
        private val editableBadge = context.pill("READ ONLY", OknColors.MUTED)
        private val freqValue = context.text("--", 17, OknColors.CYAN, true, Gravity.END)
        private val qValue = context.text("--", 17, OknColors.CYAN, true, Gravity.END)
        private val gainValue = context.text("--", 17, OknColors.CYAN, true, Gravity.END)
        private val freqSeek = SeekBar(context).apply { max = 1000 }
        private val qSeek = SeekBar(context).apply { max = 1000 }
        private val gainSeek = SeekBar(context).apply { max = 240 }
        private val tableRows = mutableListOf<TableRow>()
        private var suppress = false
        private var current = DspState()

        init {
            listOf(freqSeek, qSeek, gainSeek).forEach { seek ->
                if (android.os.Build.VERSION.SDK_INT >= 21) {
                    seek.progressTintList = ColorStateList.valueOf(OknColors.CYAN)
                    seek.thumbTintList = ColorStateList.valueOf(Color.WHITE)
                    seek.progressBackgroundTintList = ColorStateList.valueOf(Color.rgb(35, 55, 72))
                }
            }

            root.addView(context.appBar(back = back))
            root.addView(context.row().apply {
                addView(context.sectionHeader("Parametric EQ", "Realtime verified editor"), LinearLayout.LayoutParams(0, -2, 1f))
                addView(editableBadge)
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(7); bottomMargin = context.dp(9) })
            root.addView(channelSelector())
            graph.setOnBandTap { actions.bandSelected(it) }
            root.addView(graph, LinearLayout.LayoutParams(-1, context.dp(255)).apply { topMargin = context.dp(9) })
            root.addView(context.row().apply {
                addView(context.text("Tap a node or select a band below", 9, OknColors.MUTED), LinearLayout.LayoutParams(0, -2, 1f))
                addView(context.outlineButton("Reset view") {
                    graph.resetViewport()
                    actions.resetEqViewport()
                })
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(6) })
            root.addView(bandSelector(), LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(10) })
            root.addView(parameterCard(), LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(10) })
            root.addView(context.sectionLabel("ALL 15 BANDS"), LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(15); bottomMargin = context.dp(7) })
            repeat(15) { index ->
                val row = TableRow(context, index + 1) { actions.bandSelected(index + 1) }
                tableRows += row
                root.addView(row.view, LinearLayout.LayoutParams(-1, context.dp(48)).apply { bottomMargin = context.dp(4) })
            }
            setupSeekListeners()
        }

        private fun channelSelector(): View {
            val strip = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(context.dp(2), context.dp(2), context.dp(2), context.dp(2))
            }
            DspState.CHANNELS.forEach { ch ->
                val chip = context.text("${ch.shortName}\n${ch.displayName}", 10, OknColors.MUTED, true, Gravity.CENTER).apply {
                    background = roundedBg(OknColors.CARD_ALT, context.dp(13).toFloat(), OknColors.BORDER_SOFT, context.dp(1))
                    setPadding(context.dp(10), context.dp(7), context.dp(10), context.dp(7))
                    setOnClickListener { actions.channelSelected(ch.index, false) }
                }
                channelChips += chip
                strip.addView(chip, LinearLayout.LayoutParams(context.dp(91), context.dp(52)).apply { rightMargin = context.dp(6) })
            }
            return HorizontalScrollView(context).apply {
                isHorizontalScrollBarEnabled = false
                addView(strip, ViewGroup.LayoutParams(-2, -2))
            }
        }

        private fun bandSelector(): View {
            val strip = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
            repeat(15) { idx ->
                val chip = context.text((idx + 1).toString(), 10, OknColors.MUTED, true, Gravity.CENTER).apply {
                    background = roundedBg(OknColors.CARD_ALT, context.dp(11).toFloat(), OknColors.BORDER_SOFT, context.dp(1))
                    setOnClickListener { actions.bandSelected(idx + 1) }
                }
                bandChips += chip
                strip.addView(chip, LinearLayout.LayoutParams(context.dp(42), context.dp(38)).apply { rightMargin = context.dp(5) })
            }
            return HorizontalScrollView(context).apply {
                isHorizontalScrollBarEnabled = false
                addView(strip, ViewGroup.LayoutParams(-2, -2))
            }
        }

        private fun parameterCard(): View = context.card(OknColors.BORDER, OknColors.CARD, 20).apply {
            addView(context.row().apply {
                addView(context.text("Selected band", 12, OknColors.TEXT, true), LinearLayout.LayoutParams(0, -2, 1f))
                addView(context.text("PEAKING type=12 only", 9, OknColors.MUTED, true))
            })
            addView(controlRow("Frequency", "20 Hz", "20 kHz", freqValue, freqSeek), LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(7) })
            addView(controlRow("Gain", "-12 dB", "+12 dB", gainValue, gainSeek), LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(4) })
            addView(controlRow("Q", "0.05", "20.00", qValue, qSeek), LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(4) })
        }

        private fun controlRow(label: String, min: String, max: String, value: TextView, seek: SeekBar): View = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            addView(context.row().apply {
                addView(context.text(label, 11, OknColors.TEXT, true), LinearLayout.LayoutParams(0, -2, 1f))
                addView(value, LinearLayout.LayoutParams(context.dp(110), -2))
            })
            addView(seek, LinearLayout.LayoutParams(-1, context.dp(37)))
            addView(context.row().apply {
                addView(context.text(min, 8, OknColors.MUTED), LinearLayout.LayoutParams(0, -2, 1f))
                addView(context.text(max, 8, OknColors.MUTED, false, Gravity.END), LinearLayout.LayoutParams(0, -2, 1f))
            })
        }

        private fun setupSeekListeners() {
            freqSeek.setOnSeekBarChangeListener(simpleListener { p, from ->
                if (from && !suppress) send(freq = 20f * exp(ln(1000f) * (p / 1000f)))
            })
            gainSeek.setOnSeekBarChangeListener(simpleListener { p, from ->
                if (from && !suppress) send(gain = -12f + p / 10f)
            })
            qSeek.setOnSeekBarChangeListener(simpleListener { p, from ->
                if (from && !suppress) send(q = 0.05f * exp(ln(400f) * (p / 1000f)))
            })
        }

        private fun simpleListener(f: (Int, Boolean) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) = f(progress, fromUser)
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        }

        private fun send(freq: Float? = null, q: Float? = null, gain: Float? = null) {
            val band = current.eq[current.selectedChannel - 1][current.selectedEqBand - 1] ?: return
            if (!LiveEqPolicy.isWritable(band)) return
            actions.eqChanged(
                current.selectedChannel,
                current.selectedEqBand,
                freq ?: band.frequency,
                q ?: band.q,
                gain ?: band.boostDb,
            )
        }

        override fun bind(state: DspState) {
            current = state
            val channel = state.selectedChannel.coerceIn(1, 7)
            val bandIndex = state.selectedEqBand.coerceIn(1, 15)
            graph.bind(state.eq[channel - 1], channelColor(channel), bandIndex)

            channelChips.forEachIndexed { index, chip ->
                val selected = index + 1 == channel
                chip.setTextColor(if (selected) OknColors.TEXT else OknColors.MUTED)
                chip.background = roundedBg(
                    if (selected) Color.rgb(21, 57, 80) else OknColors.CARD_ALT,
                    context.dp(13).toFloat(),
                    if (selected) channelColor(channel) else OknColors.BORDER_SOFT,
                    context.dp(1),
                )
            }
            bandChips.forEachIndexed { index, chip ->
                val selected = index + 1 == bandIndex
                val available = state.eq[channel - 1][index] != null
                chip.setTextColor(if (selected) Color.WHITE else if (available) OknColors.TEXT else OknColors.MUTED_2)
                chip.background = roundedBg(
                    if (selected) Color.rgb(22, 74, 98) else OknColors.CARD_ALT,
                    context.dp(11).toFloat(),
                    if (selected) OknColors.CYAN else OknColors.BORDER_SOFT,
                    context.dp(1),
                )
            }

            val band = state.eq[channel - 1][bandIndex - 1]
            val writable = band != null && LiveEqPolicy.isWritable(band)
            suppress = true
            if (band != null) {
                freqValue.text = String.format(Locale.US, "%.0f Hz", band.frequency)
                gainValue.text = String.format(Locale.US, "%+.1f dB", band.boostDb).replace("+0.0", "0.0")
                qValue.text = String.format(Locale.US, "%.2f", band.q)
                freqSeek.progress = ((ln((band.frequency / 20f).coerceAtLeast(1f)) / ln(1000f)) * 1000).roundToInt().coerceIn(0, 1000)
                gainSeek.progress = ((band.boostDb + 12f) * 10).roundToInt().coerceIn(0, 240)
                qSeek.progress = ((ln((band.q / 0.05f).coerceAtLeast(1f)) / ln(400f)) * 1000).roundToInt().coerceIn(0, 1000)
            } else {
                freqValue.text = "--"
                gainValue.text = "--"
                qValue.text = "--"
            }
            listOf(freqSeek, gainSeek, qSeek).forEach {
                it.isEnabled = writable && state.healthGatePass
                it.alpha = if (it.isEnabled) 1f else .4f
            }
            editableBadge.text = if (writable) "LIVE EDIT" else "READ ONLY"
            editableBadge.setTextColor(if (writable) OknColors.GREEN else OknColors.MUTED)
            editableBadge.background = roundedBg(
                if (writable) Color.rgb(13, 58, 46) else OknColors.CARD_ALT,
                context.dp(30).toFloat(),
                if (writable) OknColors.GREEN else OknColors.BORDER_SOFT,
                context.dp(1),
            )
            suppress = false
            tableRows.forEachIndexed { i, row -> row.bind(state.eq[channel - 1][i], bandIndex == i + 1) }
        }

        private class TableRow(private val context: Context, private val n: Int, select: () -> Unit) {
            val view = context.row().apply {
                background = roundedBg(OknColors.CARD_ALT, context.dp(13).toFloat(), OknColors.BORDER_SOFT, context.dp(1))
                setPadding(context.dp(9), 0, context.dp(9), 0)
                setOnClickListener { select() }
                isClickable = true
            }
            private val num = context.text(n.toString(), 10, OknColors.MUTED, true, Gravity.CENTER)
            private val type = context.text("--", 10, OknColors.TEXT, true)
            private val freq = context.text("--", 10, OknColors.TEXT, false, Gravity.END)
            private val gain = context.text("--", 10, OknColors.TEXT, false, Gravity.END)
            private val q = context.text("--", 10, OknColors.TEXT, false, Gravity.END)
            private val access = context.text("LOCK", 8, OknColors.MUTED, true, Gravity.CENTER)

            init {
                view.addView(num, LinearLayout.LayoutParams(context.dp(28), -1))
                view.addView(type, LinearLayout.LayoutParams(0, -1, 1f))
                view.addView(freq, LinearLayout.LayoutParams(context.dp(72), -1))
                view.addView(gain, LinearLayout.LayoutParams(context.dp(66), -1))
                view.addView(q, LinearLayout.LayoutParams(context.dp(48), -1))
                view.addView(access, LinearLayout.LayoutParams(context.dp(43), context.dp(28)))
            }

            fun bind(band: EqBand48?, selected: Boolean) {
                view.background = roundedBg(
                    if (selected) Color.rgb(18, 47, 68) else OknColors.CARD_ALT,
                    context.dp(13).toFloat(),
                    if (selected) OknColors.CYAN else OknColors.BORDER_SOFT,
                    context.dp(1),
                )
                if (band == null) {
                    type.text = "No data"
                    freq.text = "--"
                    gain.text = "--"
                    q.text = "--"
                    access.text = "LOCK"
                    access.setTextColor(OknColors.MUTED_2)
                    return
                }
                val writable = LiveEqPolicy.isWritable(band)
                type.text = if (writable) "PEAK" else "TYPE ${band.type}"
                freq.text = String.format(Locale.US, "%.0f", band.frequency)
                gain.text = String.format(Locale.US, "%+.1f", band.boostDb)
                q.text = String.format(Locale.US, "%.2f", band.q)
                access.text = if (writable) "LIVE" else "LOCK"
                access.setTextColor(if (writable) OknColors.GREEN else OknColors.MUTED)
                access.background = roundedBg(
                    if (writable) Color.rgb(13, 58, 46) else Color.rgb(28, 34, 42),
                    context.dp(20).toFloat(),
                    if (writable) OknColors.GREEN else OknColors.BORDER_SOFT,
                    context.dp(1),
                )
            }
        }
    }
}

class SensorsScreen(private val context: Context, private val actions: UiActions) : BoundScreen {
    private val root = context.pageColumn()
    override val view: View = context.scrollPage(root)
    private val values = linkedMapOf<Int, TextView>()
    private val readyValue = context.text("OFFLINE", 18, OknColors.MUTED, true)
    private val queueValue = context.text("Idle", 18, OknColors.GREEN, true)
    private val saveButton = context.neonButton("Save verified settings to DSP", true) { actions.saveParams() }
    private val saveStatus = context.text("Manual only • never automatic", 9, OknColors.RED, true)

    init {
        root.addView(context.appBar())
        root.addView(context.sectionHeader("System Monitor", "สถานะอุปกรณ์ เซ็นเซอร์ และการบันทึก"), LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = context.dp(7)
            bottomMargin = context.dp(10)
        })
        root.addView(context.row().apply {
            addView(context.metric("HEALTH GATE", readyValue, OknColors.GREEN), LinearLayout.LayoutParams(0, context.dp(76), 1f))
            addView(context.metric("DSP QUEUE", queueValue, OknColors.CYAN), LinearLayout.LayoutParams(0, context.dp(76), 1f).apply { leftMargin = context.dp(8) })
        })
        root.addView(context.sectionLabel("SENSORS"), LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(15); bottomMargin = context.dp(7) })

        val sensorMeta = listOf(
            19 to Triple("Front audio jack", "ช่องเสียบด้านหน้า", "IN"),
            20 to Triple("Rear audio jack", "ช่องเสียบด้านหลัง", "IN"),
            0 to Triple("Power stage voltage", "แรงดันภาคจ่ายไฟ", "V"),
            21 to Triple("CPU load", "การใช้งานหน่วยประมวลผล", "%"),
        )
        sensorMeta.forEach { (id, meta) ->
            val value = context.text("--", 16, OknColors.TEXT, true, Gravity.END)
            values[id] = value
            root.addView(context.card(OknColors.BORDER_SOFT, OknColors.CARD, 17).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                addView(context.text(meta.third, 11, OknColors.CYAN, true, Gravity.CENTER).apply {
                    background = roundedBg(OknColors.SURFACE, context.dp(14).toFloat(), OknColors.BORDER, context.dp(1))
                }, LinearLayout.LayoutParams(context.dp(44), context.dp(44)))
                addView(LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                    addView(context.text(meta.first, 13, OknColors.TEXT, true))
                    addView(context.text(meta.second, 10, OknColors.MUTED), LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(2) })
                }, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = context.dp(11) })
                addView(value, LinearLayout.LayoutParams(context.dp(92), -2))
            }, LinearLayout.LayoutParams(-1, context.dp(73)).apply { bottomMargin = context.dp(7) })
        }

        root.addView(context.sectionLabel("PERSIST TO DEVICE"), LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(10); bottomMargin = context.dp(7) })
        root.addView(context.card(OknColors.RED, Color.rgb(37, 18, 25), 18).apply {
            addView(context.row().apply {
                addView(context.text("Guarded SaveParams", 15, OknColors.TEXT, true), LinearLayout.LayoutParams(0, -2, 1f))
                addView(context.pill("MANUAL ONLY", OknColors.RED))
            })
            addView(context.text("บันทึกค่าที่ผ่านการยืนยันลงหน่วยความจำ DSP แบบถาวร กรุณาเชื่อมต่อให้ READY และอย่าปิดอุปกรณ์ระหว่างบันทึก", 10, OknColors.MUTED).apply {
                setPadding(0, context.dp(8), 0, 0)
            })
            addView(saveButton, LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(11); bottomMargin = context.dp(7) })
            addView(saveStatus)
        })
    }

    override fun bind(state: DspState) {
        fun fmt(id: Int): String {
            val raw = state.sensors[id]?.raw ?: return "--"
            return when (id) {
                19, 20 -> if (raw.equals("true", true)) "Connected" else if (raw.equals("false", true)) "Open" else raw
                0 -> raw.toFloatOrNull()?.let { String.format(Locale.US, "%.1f V", it) } ?: raw
                21 -> raw.toFloatOrNull()?.let { v -> String.format(Locale.US, "%.0f %%", if (v in 0f..1f) v * 100f else v) } ?: raw
                else -> raw
            }
        }
        values.forEach { (id, text) ->
            text.text = fmt(id)
            if (id == 19 || id == 20) text.setTextColor(if (text.text == "Connected") OknColors.GREEN else OknColors.TEXT)
        }
        readyValue.text = if (state.healthGatePass) "READY" else "OFFLINE"
        readyValue.setTextColor(if (state.healthGatePass) OknColors.GREEN else OknColors.MUTED)
        queueValue.text = if (state.protocolIdle) "Idle" else "Busy"
        queueValue.setTextColor(if (state.protocolIdle) OknColors.GREEN else OknColors.YELLOW)

        saveButton.isEnabled = state.healthGatePass && state.protocolIdle && !state.saveInFlight
        saveButton.alpha = if (saveButton.isEnabled) 1f else .45f
        saveButton.text = if (state.saveInFlight) "Saving…" else "Save verified settings to DSP"
        saveStatus.text = if (state.saveInFlight) "Guarded write in progress" else "Manual only • never automatic"
    }
}

class MoreScreen(private val context: Context, private val actions: UiActions) : BoundScreen {
    private val root = context.pageColumn()
    override val view: View = context.scrollPage(root)
    private val connection = context.text("Disconnected", 14, OknColors.MUTED, true)
    private val sessionMessage = context.text("No active DSP session", 10, OknColors.MUTED)
    private val errorText = context.text("No active error", 10, OknColors.MUTED)

    init {
        root.addView(context.appBar())
        root.addView(context.sectionHeader("Device & Settings", "การเชื่อมต่อ เครื่องมือ และขอบเขตที่ตรวจสอบแล้ว"), LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = context.dp(7)
            bottomMargin = context.dp(10)
        })
        root.addView(sessionCard(), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = context.dp(12) })
        root.addView(context.sectionLabel("DSP MODULES"), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = context.dp(7) })
        root.addView(moduleGrid())
        root.addView(context.sectionLabel("TOOLS"), LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(15); bottomMargin = context.dp(7) })
        root.addView(context.card(OknColors.BORDER_SOFT, OknColors.CARD, 18).apply {
            addView(context.row().apply {
                addView(context.text("Debug log", 13, OknColors.TEXT, true), LinearLayout.LayoutParams(0, -2, 1f))
                addView(context.outlineButton("Open log") { actions.showLogs() })
            })
            addView(context.text("Raw runtime diagnostics are available for troubleshooting BLE/session issues.", 9, OknColors.MUTED).apply {
                setPadding(0, context.dp(6), 0, 0)
            })
        })
        root.addView(context.text("OKN_DSP V101 • Complete production UI refresh • Verified write boundary preserved", 9, OknColors.MUTED, false, Gravity.CENTER), LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(16) })
    }

    private fun sessionCard(): View = context.card(OknColors.BORDER, OknColors.CARD, 20).apply {
        addView(context.row().apply {
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                addView(context.text("Device session", 15, OknColors.TEXT, true))
                addView(connection, LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(4) })
                addView(sessionMessage, LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(2) })
            }, LinearLayout.LayoutParams(0, -2, 1f))
            addView(context.pill("BLE", OknColors.CYAN))
        })
        addView(errorText, LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(9) })
        addView(context.row().apply {
            addView(context.outlineButton("Reconnect") { actions.reconnect() }, LinearLayout.LayoutParams(0, -2, 1f))
            addView(context.outlineButton("Refresh") { actions.refresh() }, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = context.dp(7) })
            addView(context.outlineButton("Disconnect") { actions.disconnect() }, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = context.dp(7) })
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(11) })
    }

    private fun moduleGrid(): View {
        val grid = GridLayout(context).apply { columnCount = 2 }
        val modules = listOf(
            Triple("EQ", "15 bands × 7 CH", true),
            Triple("Crossover", "Hardware write locked", false),
            Triple("Delay", "Hardware write locked", false),
            Triple("Mixer / Output", "Hardware write locked", false),
            Triple("Presets", "Local concept only", false),
            Triple("SaveParams", "Manual guarded write", true),
        )
        modules.forEach { (title, detail, live) ->
            val card = context.card(
                if (live) Color.rgb(35, 86, 73) else OknColors.BORDER_SOFT,
                OknColors.CARD_ALT,
                16,
            ).apply {
                setPadding(context.dp(12), context.dp(11), context.dp(12), context.dp(11))
                addView(context.row().apply {
                    addView(context.text(title, 12, OknColors.TEXT, true), LinearLayout.LayoutParams(0, -2, 1f))
                    addView(context.text(if (live) "LIVE" else "LOCK", 8, if (live) OknColors.GREEN else OknColors.MUTED, true, Gravity.CENTER))
                })
                addView(context.text(detail, 9, OknColors.MUTED), LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(5) })
            }
            grid.addView(card, GridLayout.LayoutParams().apply {
                width = 0
                height = context.dp(84)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(context.dp(3), context.dp(3), context.dp(3), context.dp(3))
            })
        }
        return grid
    }

    override fun bind(state: DspState) {
        connection.text = connectionText(state.connection)
        connection.setTextColor(connectionColor(state.connection))
        sessionMessage.text = state.connectionMessage
        errorText.text = state.lastError ?: "No active error"
        errorText.setTextColor(if (state.lastError != null) OknColors.RED else OknColors.MUTED)
    }
}
