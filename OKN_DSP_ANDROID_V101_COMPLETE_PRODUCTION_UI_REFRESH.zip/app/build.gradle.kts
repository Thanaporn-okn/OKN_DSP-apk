plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

kotlin { jvmToolchain(17) }

android {
    namespace = "com.okn.dsp"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.okn.dsp"
        minSdk = 26
        targetSdk = 35
        versionCode = 101
        versionName = "9.0.0-v101-complete-production-ui-refresh"
    }

    signingConfigs {
        create("stableDebug") {
            storeFile = file("okn_dsp_stable_debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("stableDebug")
            isMinifyEnabled = false
        }
        getByName("release") {
            isMinifyEnabled = false
        }
    }

    buildFeatures { buildConfig = true }
}

dependencies { }
