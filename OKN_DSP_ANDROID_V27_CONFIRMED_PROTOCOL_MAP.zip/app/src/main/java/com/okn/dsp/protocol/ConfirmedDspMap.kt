package com.okn.dsp.protocol

/**
 * V27 mappings recovered from the official app runtime descriptor + controlled HCI capture.
 * These IDs are evidence for UI/model mapping only. They do NOT bypass WriteGate.
 */
object ConfirmedDspMap {
    const val MASTER_VOLUME = 2
    const val REMIND_SOUND_VOLUME = 3
    const val SAVE_PARAMS = 7
    const val BASS_VOLUME = 8
    const val BASS_CUTOFF = 9
    const val BASS_BOOST = 10
    const val TREBLE_BOOST = 11
    const val MIDDLE_BOOST = 13

    // Official descriptor order / controlled CH1→CH2→CH1 capture.
    val EQ_ACTUATOR_BY_CHANNEL = intArrayOf(4, 5, 6, 14, 15, 16, 17)

    const val EQ_BAND_COUNT = 15
    const val EQ_BAND_BYTES = 48

    fun eqActuator(channelIndex: Int): Int = EQ_ACTUATOR_BY_CHANNEL[channelIndex.coerceIn(0, 6)]

    /** Band number is 1-based. Example: Band 6 -> 240 bytes. */
    fun eqBandOffset(band: Int): Int = (band.coerceIn(1, EQ_BAND_COUNT) - 1) * EQ_BAND_BYTES
}
