OKN DSP ANDROID V27 — CONFIRMED ACTUATOR / EQ MAP

Confirmed from official-app runtime descriptor + controlled HCI capture:
- MasterVolume ID 2
- RemindSoundVolume ID 3 (omit in OKN app)
- SaveParams ID 7
- BassVolume ID 8
- BassCutoff ID 9
- BassBoost ID 10
- TrebleBoost ID 11
- MiddleBoost ID 13
- EQ CH1..CH7 actuator IDs = 4,5,6,14,15,16,17
- CH1=ID4 and CH2=ID5 runtime-confirmed by CH1 -> CH2 -> CH1 controlled test
- EQ one filter/band structure = 48 bytes
- EQ memory offset = (band-1)*48; Band 6 => offset 240
- AES-CFB8 with the session RandKey is confirmed for observed application payloads.

WRITE POLICY:
DSP parameter writes remain locked. The real AES-CFB8 IV/session initialization plus full command/header serializer still need independent verification before V27/V28 may transmit control packets.
