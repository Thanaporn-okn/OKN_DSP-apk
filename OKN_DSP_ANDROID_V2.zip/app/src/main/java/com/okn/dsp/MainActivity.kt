package com.okn.dsp

import android.Manifest
import android.app.Activity
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import java.util.UUID

class MainActivity : Activity() {
    private lateinit var log: TextView
    private lateinit var list: LinearLayout
    private val handler = Handler(Looper.getMainLooper())
    private var scanner: BluetoothLeScanner? = null
    private val found = LinkedHashMap<String, BluetoothDevice>()
    private var gatt: BluetoothGatt? = null

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        buildUi()
        requestBlePermissions()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
        }
        val title = TextView(this).apply {
            text = "OKN DSP Controller\nV2 BLE DISCOVERY"
            textSize = 22f
        }
        val status = TextView(this).apply {
            text = "WRITE DISABLED — service/characteristic discovery only"
            textSize = 15f
        }
        val scan = Button(this).apply {
            text = "SCAN DSP"
            setOnClickListener { startScan() }
        }
        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        log = TextView(this).apply {
            text = "Log:\n"
            textSize = 13f
        }
        root.addView(title)
        root.addView(status)
        root.addView(scan)
        root.addView(list)
        root.addView(log)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun requestBlePermissions() {
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT
                ),
                100
            )
        }
    }

    private fun startScan() {
        if (!hasBlePermission()) {
            append("Bluetooth permission not granted")
            return
        }
        val manager = getSystemService(BluetoothManager::class.java)
        val bt = manager?.adapter
        if (bt == null) {
            append("Bluetooth adapter not available")
            return
        }
        if (!bt.isEnabled) {
            append("Bluetooth is OFF — turn Bluetooth ON and scan again")
            return
        }
        scanner = bt.bluetoothLeScanner
        if (scanner == null) {
            append("BLE scanner not available")
            return
        }

        found.clear()
        list.removeAllViews()
        append("Scanning for DSP ...")
        try {
            scanner?.startScan(callback)
        } catch (e: SecurityException) {
            append("Bluetooth permission denied")
            return
        }
        handler.postDelayed({
            try { scanner?.stopScan(callback) } catch (_: Exception) {}
            append("Scan finished")
        }, 10000)
    }

    private fun hasBlePermission(): Boolean =
        android.os.Build.VERSION.SDK_INT < 31 ||
        (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
         checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED)

    private val callback = object : ScanCallback() {
        override fun onScanResult(type: Int, result: ScanResult) {
            val d = result.device
            val name = result.scanRecord?.deviceName
                ?: try { d.name } catch (_: SecurityException) { null }

            if (name == "GoloPineDSPAudioTurning" ||
                name?.contains("GoloPine", true) == true ||
                name?.contains("DSP", true) == true) {
                if (!found.containsKey(d.address)) {
                    found[d.address] = d
                    runOnUiThread {
                        val b = Button(this@MainActivity).apply {
                            text = "${name ?: "Unnamed DSP"}\n${d.address}\nTAP TO DISCOVER SERVICES"
                            setOnClickListener { discover(d, name ?: "DSP") }
                        }
                        list.addView(b)
                    }
                }
            }
        }

        override fun onScanFailed(errorCode: Int) {
            append("BLE scan failed: $errorCode")
        }
    }

    private fun discover(device: BluetoothDevice, name: String) {
        if (!hasBlePermission()) {
            append("Bluetooth permission not granted")
            return
        }
        try {
            gatt?.close()
            gatt = null
            append("Connecting to $name ${device.address} ...")
            gatt = device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
        } catch (e: SecurityException) {
            append("Bluetooth permission denied")
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            append("GATT state=$newState status=$status")
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                append("Connected — discovering services")
                try { g.discoverServices() }
                catch (e: SecurityException) { append("Cannot discover: permission denied") }
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                append("Disconnected")
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            append("Services discovered: status=$status")
            if (status != BluetoothGatt.GATT_SUCCESS) return

            g.services.forEachIndexed { index, service ->
                append("SERVICE[$index] ${service.uuid}")
                service.characteristics.forEachIndexed { ci, ch ->
                    val p = mutableListOf<String>()
                    if (ch.properties and BluetoothGattCharacteristic.PROPERTY_READ != 0) p.add("READ")
                    if (ch.properties and BluetoothGattCharacteristic.PROPERTY_WRITE != 0) p.add("WRITE")
                    if (ch.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0) p.add("WRITE_NR")
                    if (ch.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0) p.add("NOTIFY")
                    if (ch.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0) p.add("INDICATE")
                    append("  CHAR[$ci] ${ch.uuid} [${p.joinToString(",")}]")
                    ch.descriptors.forEach { d ->
                        append("    DESC ${d.uuid}")
                    }
                }
            }
            append("DISCOVERY COMPLETE — no DSP data was written")
        }

        override fun onCharacteristicRead(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, status: Int) {
            append("CHAR READ ${characteristic.uuid} status=$status len=${characteristic.value?.size ?: 0}")
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            append("NOTIFY ${characteristic.uuid} len=${value.size} HEX=${value.toHex()}")
        }
    }

    private fun ByteArray.toHex(): String =
        take(64).joinToString(" ") { "%02X".format(it) }

    private fun append(s: String) {
        runOnUiThread { log.append("$s\n") }
    }

    override fun onDestroy() {
        try { gatt?.close() } catch (_: Exception) {}
        gatt = null
        super.onDestroy()
    }
}
