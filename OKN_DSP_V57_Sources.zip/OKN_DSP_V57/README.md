# OKN DSP V57 — Passive Sensor RX Qualifier

V57 is BLE-only and keeps the working OKN_DSP transport/UI baseline. It does not probe hidden actuator IDs.

## Why V57 exists

V55 returned NO_REPLY for actuator ID2 as well as IDs 1, 12, and 18. Because ID2 was not independently proven as an individual-read positive control on this firmware, those NO_REPLY results cannot classify the hidden IDs.

## V57 diagnostic

Button: `PASSIVE SENSOR RX CAPTURE (0 ADDED TX)`

The app already runs the sensor poll scheduler recovered from the original GoloPine HCI capture:

- ID19 length 1
- ID20 length 1
- ID0 length 4
- ID21 length 4
- approximately 380 ms command cadence

Pressing the V57 diagnostic button does not stop, reset, reorder, or add to that scheduler. It does not call `txCipher.next`, `writeNoResponse`, or `encodeRead`. It only observes the already-authenticated AB02 RX stream for 5 seconds after normal continuous AES-CFB8 decryption and reports any UFE `0x60` read responses.

Diagnostic-added state-changing traffic is zero: no UFE `0x57`, no EQ write, no SaveParams, and no USB path.

CH3 remains mapped to the verified BassVolume actuator ID8. CH1/2/4/5/6/7 hardware Out Volume remains locked until a true gain/mixer path is proven.
