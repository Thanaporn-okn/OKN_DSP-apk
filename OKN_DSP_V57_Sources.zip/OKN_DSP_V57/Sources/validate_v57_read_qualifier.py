#!/usr/bin/env python3
from pathlib import Path
root=Path(__file__).resolve().parents[1]
ble=(root/'app/src/main/java/com/okn/dsp/BleManager.java').read_text()
main=(root/'app/src/main/java/com/okn/dsp/MainActivity.java').read_text()
view=(root/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
gradle=(root/'app/build.gradle').read_text()
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
def req(c,m):
    if not c: raise SystemExit('V57_FAIL: '+m)
req('versionCode 1057' in gradle, 'versionCode')
req("versionName '57.0.0'" in gradle, 'versionName')
req('runV57ActuatorReadQualifier' in ble, 'qualifier method')
req('V57_READ_QUALIFIER_MS = 4500L' in ble, 'timeout')
req('sendV57QualifierRead' in ble and 'DspProtocol.encodeRead(id, 0, 4)' in ble, 'read serializer')
req('int id = v57ReadQualifierPhase == 1 ? 0 : 2;' in ble, 'only ID0 then ID2')
req('v57ReadQualifierPhase = 3' in ble, 'ID2 gated after ID0 reply')
req('Hidden IDs 1/12/18 are NOT queried in V57.' in ble, 'explicit hidden-id lock')
# Qualifier code may call transport only for encoded READ. It must not construct 0x57/Save/EQ writes.
a=ble.index('private void runV57ActuatorReadQualifierOnMain()')
b=ble.index('/** Re-read the real DSP descriptor', a)
q=ble[a:b]
for forbidden in ['encodeFloatWrite(', 'encodeEqWrite(', 'SAVE_PARAMS_ID7']:
    req(forbidden not in q, 'forbidden qualifier write surface: '+forbidden)
req('READ PATH: SENSOR ID0 → ACTUATOR ID2' in view, 'UI label')
req('requestV57ActuatorReadQualifier' in view and 'requestV57ActuatorReadQualifier' in main, 'UI wiring')
req('requestV56PassiveSensorRxCapture' not in view and 'requestV56PassiveSensorRxCapture' not in main, 'V56 UI still exposed')
req('android.hardware.usb.host' not in manifest, 'USB host present')
print('V57_SENSOR_TO_ACTUATOR_READ_QUALIFIER_STATIC_PASS')
