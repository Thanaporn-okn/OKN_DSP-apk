#!/usr/bin/env python3
from pathlib import Path
import runpy
HERE=Path(__file__).resolve().parent
for name in ['validate_v38_gate.py','validate_v39_reset.py','validate_v57_read_qualifier.py']:
    runpy.run_path(str(HERE/name), run_name='__main__')
