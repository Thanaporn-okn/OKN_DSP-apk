OKN_DSP V13 — Phase 1 UI Fidelity Pass

Basis: V12 runtime video review on the target Samsung phone and the four-page uploaded UI reference.

Changes in V13:
- Keeps the V12 HTML/CSS/JavaScript rebuild and the stable Android wrapper.
- Fixes Quick Actions labels inheriting Android/WebView button text styling.
- Adds tall-phone responsive geometry so Home, Mix, EQ and Crossover fill modern 19.5:9 / 20:9 displays instead of leaving a large unused band above bottom navigation.
- Enlarges Home device/status/source/action sections proportionally on tall phones.
- Enlarges EQ/Crossover graphs and control cards on tall phones while preserving scroll safety on smaller screens.
- Keeps all sliders, knobs, channel tabs, graphs, presets and navigation interactive.
- Phase 2 DSP transport remains intentionally disabled until Phase 1 UI is approved.

Reference-image policy: the uploaded composite reference is used only for visual comparison; it is not bundled as a screen/background asset.
