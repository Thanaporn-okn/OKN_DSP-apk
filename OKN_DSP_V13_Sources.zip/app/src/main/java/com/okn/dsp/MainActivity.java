package com.okn.dsp;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;

/**
 * OKN_DSP V13 - Phase 1 UI fidelity and tall-screen layout pass.
 * The UI is authored from HTML/CSS/Canvas controls and bundled original/supporting artwork.
 * The user's uploaded reference screenshot is NOT bundled or used as a background image.
 */
public final class MainActivity extends Activity {
    private FrameLayout root;
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureWindow();
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(1, 10, 24));
        setContentView(root);
        root.post(this::mountUi);
    }

    @Override
    protected void onResume() {
        super.onResume();
        configureWindow();
        if (webView != null) webView.onResume();
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    private void configureWindow() {
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        window.setStatusBarColor(Color.TRANSPARENT);
        window.setNavigationBarColor(Color.TRANSPARENT);
        window.getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    private void mountUi() {
        try {
            if (isFinishing() || root == null) return;
            WebView w = new WebView(this);
            w.setBackgroundColor(Color.TRANSPARENT);
            WebSettings settings = w.getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setDomStorageEnabled(true);
            settings.setAllowFileAccess(true);
            settings.setAllowContentAccess(false);
            settings.setSupportZoom(false);
            settings.setBuiltInZoomControls(false);
            settings.setDisplayZoomControls(false);
            settings.setTextZoom(100);
            settings.setMediaPlaybackRequiresUserGesture(true);
            w.setWebViewClient(new WebViewClient());
            w.setWebChromeClient(new WebChromeClient());
            w.setOverScrollMode(View.OVER_SCROLL_NEVER);
            w.loadUrl("file:///android_asset/index.html");
            root.removeAllViews();
            root.addView(w, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT));
            webView = w;
        } catch (Throwable error) {
            showFallback(error);
        }
    }

    private void showFallback(Throwable error) {
        if (root == null) return;
        root.removeAllViews();
        TextView fallback = new TextView(this);
        fallback.setTextColor(Color.WHITE);
        fallback.setTextSize(18f);
        fallback.setGravity(Gravity.CENTER);
        fallback.setPadding(36, 36, 36, 36);
        String type = error == null ? "unknown" : error.getClass().getSimpleName();
        fallback.setText("OKN_DSP V13\n\nSafe startup mode\nUI load failed: " + type);
        root.addView(fallback, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
    }
}
