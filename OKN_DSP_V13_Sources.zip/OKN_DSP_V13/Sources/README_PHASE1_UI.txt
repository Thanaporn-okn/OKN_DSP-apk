OKN_DSP Version 13 - Phase 1 UI

Purpose
- Rebuild the interface from code to visually approach the supplied four-screen reference.
- The supplied reference image is NOT embedded or copied as an app background.
- Phase 2 DSP/BLE transport remains disabled until the Phase 1 UI is accepted.

Pages
- Home
- Mix
- Eq
- Crossover

V13 focus
- Correct the large empty lower-screen area observed in the running V12 recording (30607.mp4).
- Preserve the reference-width geometry while adapting vertical spacing/cards to tall phones without stretching text or circular controls.
- Keep the vector OKN_DSP wordmark independent of the phone's selected display font.
- Keep all sliders, knobs, EQ points, crossover filters and delay controls interactive with immediate redraw.
- Preserve the stable development signing identity for update-in-place builds.

Signing / update path
V3 introduced a stable DEVELOPMENT signing key. V4 through V13 preserve the same key, so V3 and later development builds can update in place.
If moving from V1/V2 and Android reports an incompatible update, uninstall the old V1/V2 app once. V3 and later use the stable key.

Build
Use OKN_DSP_AutoBuild.yml. The workflow automatically selects the highest OKN_DSP_V*_Sources.zip in the repository root, verifies Sources/SHA256SUMS.txt, verifies the signing key, builds the signed debug APK and uploads the APK artifact.
