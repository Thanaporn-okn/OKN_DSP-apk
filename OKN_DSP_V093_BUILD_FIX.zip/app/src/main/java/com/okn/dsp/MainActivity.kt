package com.okn.dsp
import android.app.Activity
import android.os.Bundle
import android.widget.*
class MainActivity:Activity(){
 override fun onCreate(b:Bundle?){
  super.onCreate(b)
  val l=LinearLayout(this)
  l.orientation=LinearLayout.VERTICAL
  l.addView(TextView(this).apply{text="Connected\nBP1048P4 7CH DSP FW:1.2.6";textSize=22f})
  for(i in 1..7){l.addView(TextView(this).apply{text="CH$i"});l.addView(SeekBar(this));l.addView(Button(this).apply{text="MUTE"})}
  setContentView(l)
 }
}