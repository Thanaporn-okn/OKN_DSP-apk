import 'package:flutter/material.dart';

void main(){runApp(const App());}

class App extends StatelessWidget{
 const App({super.key});
 @override
 Widget build(BuildContext context){
  return MaterialApp(
   home: Scaffold(
    backgroundColor: const Color(0xff101018),
    body: Center(
     child: Text(
      'OKN_DSP BP1048P4 V25 FIX4',
      style: const TextStyle(color: Colors.cyan,fontSize:24),
     ),
    ),
   ),
  );
 }
}
