OKN_DSP BP1048P4 V25_FIX

Next development step:
- CH1-CH7 channel selector
- Volume control per channel
- 15 Band EQ structure
- Delay ms structure
- HPF/LPF crossover structure
- Preset Save/Load framework
- Bluetooth command packet placeholder

This is the next project scaffold for continuing Android build work.
