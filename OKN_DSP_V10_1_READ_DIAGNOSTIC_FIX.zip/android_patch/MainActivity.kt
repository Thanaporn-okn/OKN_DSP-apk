package com.okn.okn_dsp

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.*
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.app.ActivityCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class MainActivity : FlutterActivity() {
    private val methods = "okn_dsp/methods"
    private val events = "okn_dsp/events"
    private var sink: EventChannel.EventSink? = null
    private var gatt: BluetoothGatt? = null

    private val serviceUuid = UUID.fromString("0000ab00-0000-1000-8000-00805f9b34fb")
    private val ab01Uuid = UUID.fromString("0000ab01-0000-1000-8000-00805f9b34fb")
    private val rxUuids = listOf(
        UUID.fromString("0000ab02-0000-1000-8000-00805f9b34fb"),
        UUID.fromString("0000ab03-0000-1000-8000-00805f9b34fb")
    )
    private val cccdUuid = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    private val handler = Handler(Looper.getMainLooper())

    private var notifyQueue: MutableList<BluetoothGattCharacteristic> = mutableListOf()
    private var notifyIndex = 0
    private var waitingDescriptor = false

    override fun configureFlutterEngine(engine: FlutterEngine) {
        super.configureFlutterEngine(engine)
        EventChannel(engine.dartExecutor.binaryMessenger, events)
            .setStreamHandler(object : EventChannel.StreamHandler {
                override fun onListen(a: Any?, s: EventChannel.EventSink?) { sink = s }
                override fun onCancel(a: Any?) { sink = null }
            })

        MethodChannel(engine.dartExecutor.binaryMessenger, methods)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "connect" -> {
                        val address = call.argument<String>("address")
                        if (address == null) result.error("ADDRESS", "Missing address", null)
                        else { connect(address); result.success(null) }
                    }
                    "readAb01" -> {
                        val g = gatt
                        if (g == null) result.error("GATT", "Not connected", null)
                        else { readAb01(g); result.success(null) }
                    }
                    else -> result.notImplemented()
                }
            }
    }

    private fun emit(m: Map<String, Any?>) =
        runOnUiThread { sink?.success(m) }

    private fun permissionOk(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
        ActivityCompat.checkSelfPermission(
            this, Manifest.permission.BLUETOOTH_CONNECT
        ) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    private fun connect(address: String) {
        if (!permissionOk()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 3001)
            emit(mapOf("type" to "status", "message" to "ต้องอนุญาต Bluetooth ก่อน"))
            return
        }
        gatt?.close()
        notifyQueue.clear()
        notifyIndex = 0
        waitingDescriptor = false

        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val device = manager.adapter.getRemoteDevice(address)
        emit(mapOf("type" to "status", "message" to "กำลังเชื่อมต่อ $address ..."))
        gatt = device.connectGatt(this, false, callback, BluetoothDevice.TRANSPORT_LE)
    }

    @SuppressLint("MissingPermission")
    private fun readAb01(g: BluetoothGatt) {
        val service = g.getService(serviceUuid)
        val c = service?.getCharacteristic(ab01Uuid)
        if (c == null) {
            emit(mapOf("type" to "ab01", "message" to "ไม่พบ AB01"))
            return
        }
        emit(mapOf("type" to "ab01", "message" to "กำลังอ่าน AB01..."))
        val ok = g.readCharacteristic(c)
        emit(mapOf("type" to "ab01", "message" to "AB01 read accepted=$ok"))
    }

    @SuppressLint("MissingPermission")
    private fun startNotifyQueue(g: BluetoothGatt) {
        val service = g.getService(serviceUuid)
        if (service == null) {
            emit(mapOf("type" to "status", "message" to "ไม่พบ Service AB00"))
            return
        }

        notifyQueue = rxUuids.mapNotNull { service.getCharacteristic(it) }
            .filter {
                val p = it.properties
                (p and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0 ||
                (p and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0
            }.toMutableList()

        notifyIndex = 0
        waitingDescriptor = false

        if (notifyQueue.isEmpty()) {
            emit(mapOf("type" to "notify", "message" to "ไม่พบ AB02/AB03 ที่รองรับ Notify/Indicate"))
            return
        }

        enableNextNotify(g)
    }

    @SuppressLint("MissingPermission")
    private fun enableNextNotify(g: BluetoothGatt) {
        if (notifyIndex >= notifyQueue.size) {
            emit(mapOf(
                "type" to "status",
                "message" to "เปิด Notify ครบแล้ว — กำลังอ่าน AB01 แบบ READ เท่านั้น"
            ))
            handler.postDelayed({ readAb01(g) }, 250)
            return
        }

        val c = notifyQueue[notifyIndex]
        val short = c.uuid.toString().substring(4, 8).uppercase()
        val props = c.properties

        val local = g.setCharacteristicNotification(c, true)
        val d = c.getDescriptor(cccdUuid)

        if (!local || d == null) {
            emit(mapOf(
                "type" to "notify",
                "message" to "$short: local=$local CCCD=${d != null}"))
            notifyIndex++
            handler.post { enableNextNotify(g) }
            return
        }

        d.value =
            if ((props and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0)
                BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
            else
                BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE

        waitingDescriptor = true
        val ok = g.writeDescriptor(d)
        emit(mapOf(
            "type" to "notify",
            "message" to "$short: local=$local กำลังเขียน CCCD... accepted=$ok"
        ))

        if (!ok) {
            waitingDescriptor = false
            notifyIndex++
            handler.postDelayed({ enableNextNotify(g) }, 250)
        }
    }

    private val callback = object : BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, state: Int) {
            if (state == BluetoothProfile.STATE_CONNECTED) {
                emit(mapOf("type" to "connected"))
                emit(mapOf("type" to "status", "message" to "เชื่อมต่อแล้ว — กำลังค้นหา Service"))
                g.discoverServices()
            } else if (state == BluetoothProfile.STATE_DISCONNECTED) {
                emit(mapOf("type" to "disconnected"))
                emit(mapOf("type" to "status", "message" to "ตัดการเชื่อมต่อ status=$status"))
            }
        }

        @SuppressLint("MissingPermission")
        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            val out = StringBuilder("GATT STATUS: $status\nSERVICES: ${g.services.size}\n\n")
            for ((si, service) in g.services.withIndex()) {
                out.append("SERVICE ${si + 1}: ${service.uuid}\n")
                for ((ci, c) in service.characteristics.withIndex()) {
                    val p = c.properties
                    val props = mutableListOf<String>()
                    if (p and BluetoothGattCharacteristic.PROPERTY_READ != 0) props.add("READ")
                    if (p and BluetoothGattCharacteristic.PROPERTY_WRITE != 0) props.add("WRITE")
                    if (p and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0) props.add("WRITE_NR")
                    if (p and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0) props.add("NOTIFY")
                    if (p and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0) props.add("INDICATE")
                    out.append("  CHAR ${ci + 1}: ${c.uuid}\n")
                    out.append("    PROPERTIES: ${props.joinToString(", ")}\n")
                    for (d in c.descriptors) out.append("    DESC: ${d.uuid}\n")
                }
            }
            emit(mapOf("type" to "gatt", "text" to out.toString()))
            emit(mapOf("type" to "status", "message" to "พบ GATT แล้ว — กำลังเปิด Notify AB02 / AB03"))
            startNotifyQueue(g)
        }

        override fun onCharacteristicRead(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            status: Int
        ) {
            val b = characteristic.value ?: byteArrayOf()
            if (characteristic.uuid == ab01Uuid) {
                val hex = b.joinToString(" ") { "%02X".format(it.toInt() and 0xFF) }
                emit(mapOf(
                    "type" to "ab01rx",
                    "data" to hex,
                    "length" to b.size,
                    "status" to status
                ))
            }
        }

        @SuppressLint("MissingPermission")
        override fun onDescriptorWrite(
            g: BluetoothGatt,
            descriptor: BluetoothGattDescriptor,
            status: Int
        ) {
            if (!waitingDescriptor) return
            waitingDescriptor = false

            val short = descriptor.characteristic.uuid.toString()
                .substring(4, 8).uppercase()

            emit(mapOf(
                "type" to "notify",
                "message" to "$short: CCCD status=$status"
            ))

            notifyIndex++
            handler.postDelayed({ enableNextNotify(g) }, 180)
        }

        override fun onCharacteristicChanged(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic
        ) {
            val b = characteristic.value ?: byteArrayOf()
            emitRx(characteristic, b)
        }

        @SuppressLint("MissingPermission")
        override fun onCharacteristicChanged(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            value: ByteArray
        ) {
            emitRx(characteristic, value)
        }
    }

    private fun emitRx(c: BluetoothGattCharacteristic, b: ByteArray) {
        val hex = b.joinToString(" ") { "%02X".format(it.toInt() and 0xFF) }
        val now = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date())
        emit(mapOf(
            "type" to "rx",
            "characteristic" to c.uuid.toString(),
            "data" to hex,
            "length" to b.size,
            "time" to now
        ))
    }
}
