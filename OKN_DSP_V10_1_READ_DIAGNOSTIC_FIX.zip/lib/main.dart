import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() => runApp(const OknDspApp());

class OknDspApp extends StatelessWidget {
  const OknDspApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'OKN DSP',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.blue),
      home: const HomePage(),
    );
  }
}

class Packet {
  final String ch;
  final String hex;
  final String time;
  final int len;
  const Packet(this.ch, this.hex, this.time, this.len);
}

class _Ab01Read {
  final String data;
  final int length;
  final int status;
  const _Ab01Read(this.data, this.length, this.status);
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  static const methods = MethodChannel('okn_dsp/methods');
  static const events = EventChannel('okn_dsp/events');

  static const dspName = 'LE-GoIoPine_DSP_A';
  static const dspAddress = 'DC:E0:D9:88:C7:04';

  StreamSubscription? sub;
  final packets = <Packet>[];
  final ab01Reads = <_Ab01Read>[];

  String status = 'พร้อมเชื่อมต่อ DSP';
  String gatt = '';
  String notifyStatus = 'ยังไม่ได้เปิด Notify';
  bool connected = false;
  bool reading = false;

  @override
  void initState() {
    super.initState();
    sub = events.receiveBroadcastStream().listen((event) {
      if (!mounted || event is! Map) return;

      final type = event['type']?.toString() ?? '';

      if (type == 'status') {
        setState(() => status = event['message']?.toString() ?? '');
      } else if (type == 'gatt') {
        setState(() => gatt = event['text']?.toString() ?? '');
      } else if (type == 'notify') {
        setState(() => notifyStatus = event['message']?.toString() ?? '');
      } else if (type == 'connected') {
        setState(() {
          connected = true;
          status = 'เชื่อมต่อ DSP แล้ว';
        });
      } else if (type == 'disconnected') {
        setState(() {
          connected = false;
          reading = false;
          notifyStatus = 'ตัดการเชื่อมต่อ';
        });
      } else if (type == 'rx') {
        final hex = event['data']?.toString() ?? '';
        final len = int.tryParse(event['length']?.toString() ?? '') ?? 0;
        final ch = event['characteristic']?.toString() ?? '';
        final time = event['time']?.toString() ?? '';

        setState(() {
          packets.insert(0, Packet(ch, hex, time, len));
          if (packets.length > 100) packets.removeLast();
        });
      } else if (type == 'ab01') {
        setState(() => status = event['message']?.toString() ?? '');
      } else if (type == 'ab01rx') {
        final data = event['data']?.toString() ?? '';
        final length = int.tryParse(event['length']?.toString() ?? '') ?? 0;
        final readStatus = int.tryParse(event['status']?.toString() ?? '') ?? -1;

        setState(() {
          reading = false;
          ab01Reads.insert(0, _Ab01Read(data, length, readStatus));
          if (ab01Reads.length > 20) ab01Reads.removeLast();
        });
      }
    });
  }

  @override
  void dispose() {
    sub?.cancel();
    super.dispose();
  }

  Future<void> connect() async {
    setState(() {
      packets.clear();
      ab01Reads.clear();
      gatt = '';
      connected = false;
      reading = false;
      status = 'กำลังเชื่อมต่อ $dspName...';
      notifyStatus = 'กำลังเชื่อมต่อ';
    });

    try {
      await methods.invokeMethod('connect', {'address': dspAddress});
    } catch (e) {
      if (mounted) {
        setState(() => status = 'เชื่อมต่อไม่ได้: $e');
      }
    }
  }

  Future<void> readAb01() async {
    if (!connected) return;

    setState(() {
      reading = true;
      status = 'กำลัง READ AB01...';
    });

    try {
      await methods.invokeMethod('readAb01');
    } catch (e) {
      if (mounted) {
        setState(() {
          reading = false;
          status = 'อ่าน AB01 ไม่สำเร็จ: $e';
        });
      }
    }
  }

  Future<void> copyAll() async {
    final lines = <String>[];

    for (final p in packets.reversed) {
      lines.add('${p.time} | ${p.ch} | LEN=${p.len} | ${p.hex}');
    }

    for (final r in ab01Reads.reversed) {
      lines.add('AB01 READ | STATUS=${r.status} | LEN=${r.length} | ${r.data}');
    }

    if (lines.isEmpty) return;

    await Clipboard.setData(ClipboardData(text: lines.join('\n')));

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('คัดลอกข้อมูลแล้ว')),
      );
    }
  }

  void clearData() {
    setState(() {
      packets.clear();
      ab01Reads.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('OKN DSP Controller V10.1'),
        actions: [
          IconButton(
            tooltip: 'เชื่อมต่อ DSP',
            onPressed: connect,
            icon: Icon(
              connected ? Icons.bluetooth_connected : Icons.bluetooth,
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'DSP ที่ตรวจพบจริง',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 5),
                    const Text(
                      '$dspName\n$dspAddress',
                      style: TextStyle(fontSize: 16),
                    ),
                    const SizedBox(height: 12),
                    Text(status, style: const TextStyle(fontSize: 15)),
                    const SizedBox(height: 10),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton.icon(
                        onPressed: connect,
                        icon: const Icon(Icons.bluetooth_connected),
                        label: const Text('เชื่อมต่อ DSP และเปิด Notify'),
                      ),
                    ),
                    const SizedBox(height: 8),
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        onPressed: connected && !reading ? readAb01 : null,
                        icon: const Icon(Icons.download),
                        label: Text(
                          reading
                              ? 'กำลังอ่าน AB01...'
                              : 'อ่านข้อมูล AB01 (READ เท่านั้น)',
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Row(
              children: [
                Expanded(
                  child: Card(
                    child: ListTile(
                      dense: true,
                      title: const Text('Notify'),
                      subtitle: Text(notifyStatus),
                      leading: Icon(
                        connected
                            ? Icons.notifications_active
                            : Icons.notifications_none,
                      ),
                    ),
                  ),
                ),
                IconButton(
                  tooltip: 'คัดลอกข้อมูล',
                  onPressed:
                      packets.isEmpty && ab01Reads.isEmpty ? null : copyAll,
                  icon: const Icon(Icons.copy),
                ),
                IconButton(
                  tooltip: 'ล้างข้อมูล',
                  onPressed:
                      packets.isEmpty && ab01Reads.isEmpty ? null : clearData,
                  icon: const Icon(Icons.delete_outline),
                ),
              ],
            ),
            if (gatt.isNotEmpty)
              SizedBox(
                height: 210,
                child: Card(
                  child: Padding(
                    padding: const EdgeInsets.all(10),
                    child: SingleChildScrollView(
                      child: SelectableText(
                        gatt,
                        style: const TextStyle(
                          fontSize: 11,
                          fontFamily: 'monospace',
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            const SizedBox(height: 4),
            const Text(
              'AB01 READ RESPONSE',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            Expanded(
              child: ab01Reads.isEmpty
                  ? const Center(
                      child: Text(
                        'ยังไม่มีผล AB01 READ\nกด “อ่านข้อมูล AB01” หลังเชื่อมต่อ',
                        textAlign: TextAlign.center,
                      ),
                    )
                  : ListView.builder(
                      itemCount: ab01Reads.length,
                      itemBuilder: (_, index) {
                        final r = ab01Reads[index];
                        return Card(
                          child: Padding(
                            padding: const EdgeInsets.all(10),
                            child: SelectableText(
                              'STATUS=${r.status}\nLEN=${r.length}\n${r.data}',
                              style: const TextStyle(
                                fontFamily: 'monospace',
                                fontSize: 13,
                              ),
                            ),
                          ),
                        );
                      },
                    ),
            ),
            const SizedBox(height: 4),
            Row(
              children: [
                const Expanded(
                  child: Text(
                    'RX จาก Notify',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Text('${packets.length} packets'),
              ],
            ),
            SizedBox(
              height: 150,
              child: packets.isEmpty
                  ? const Center(
                      child: Text('ยังไม่มี packet จาก AB02 / AB03'),
                    )
                  : ListView.builder(
                      itemCount: packets.length,
                      itemBuilder: (_, index) {
                        final p = packets[index];
                        return Card(
                          child: Padding(
                            padding: const EdgeInsets.all(8),
                            child: SelectableText(
                              '${p.time}  ${p.ch}\nLEN=${p.len}\n${p.hex}',
                              style: const TextStyle(
                                fontFamily: 'monospace',
                                fontSize: 12,
                              ),
                            ),
                          ),
                        );
                      },
                    ),
            ),
            const Text(
              '🛑 V10.1: READ AB01 + รับ Notify AB02/AB03 เท่านั้น — ไม่มีการส่ง payload คำสั่ง DSP',
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
