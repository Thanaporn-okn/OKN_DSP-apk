# OKN DSP Android V17 — Multi-Session Evidence Correlation

V17 extends the passive BLE research workflow with multi-session correlation.

- Discovery/read/notify only.
- DSP WRITE path remains hard-disabled.
- AB02/AB03 notifications are captured when available.
- Import up to 5 saved capture sessions.
- Compare recurring packet lengths, exact payload reuse, stable byte positions, timing spans and notify sources.
- No packet field, checksum, encryption, command ID or DSP parameter meaning is inferred from statistics alone.
- Repeated controlled-event sessions are required before any wire-level WRITE hypothesis can be considered.
