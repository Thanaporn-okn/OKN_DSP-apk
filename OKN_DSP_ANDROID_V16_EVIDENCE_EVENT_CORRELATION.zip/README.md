# OKN DSP Android V16 — Evidence Gate + Event Correlation

V16 combines the V15 controlled-event capture workflow with the V14 Evidence Gate research bundle.

## Confirmed passive BLE evidence
- AB00 service: 0000ab00-0000-1000-8000-00805f9b34fb
- AB01: READ / WRITE / WRITE_NR
- AB02: NOTIFY + CCCD
- AB03: NOTIFY + CCCD
- The device observed in testing: LE-GOLOPINE_DSP_A

## Capture observations incorporated
- AB02 notifications observed as 10-byte and 13-byte records in the supplied controlled-event captures.
- Capture-derived TYPE-A/TYPE-B labels are only statistical labels; they are NOT asserted as protocol frame types.
- Captured text contains eventMs and deltaMs values; V16 measures their timing behavior but does not assign protocol meaning.
- The supplied captures show regular notification activity during baseline and controlled-event windows.

## UFE evidence gate
Reference command IDs from the research bundle are retained:
- WRITE actuator: 0x57
- READ sensor/actuator: 0x58
- READ JSON: 0x59
- READ FIFO: 0x61
- READ bulk: 0x63
- CONTINUE bulk: 0x82

These IDs are reference evidence, NOT proof of the BLE wire framing. Exact framing, integrity/checking,
encryption/key derivation, actuator mapping, and serializer remain unverified.

Therefore:
**WRITE IS HARD-DISABLED.**

## V16 workflow
1. Connect and subscribe to AB02/AB03.
2. Run 5-second idle baseline.
3. Change exactly one DSP parameter using the original controller.
4. Capture the 10-second controlled-event window.
5. Analyze timing, lengths, payload reuse, byte-position differences and notification sources.
6. Repeat the same single parameter change across multiple sessions.

No guessed command, checksum, key, address, or DSP value is transmitted.
