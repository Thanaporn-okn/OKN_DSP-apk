package com.okn.dsp

import android.Manifest
import android.app.Activity
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.*
import android.content.Intent
import android.content.ActivityNotFoundException
import android.net.Uri
import android.provider.OpenableColumns
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.core.app.ActivityCompat
import java.util.UUID
import com.okn.dsp.transport.BleProfile
import com.okn.dsp.protocol.ProtocolEvidence
import com.okn.dsp.protocol.UfeConstants

class MainActivity : Activity() {
    private lateinit var log: TextView
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val found = LinkedHashMap<String, BluetoothDevice>()
    private var scanner: BluetoothLeScanner? = null
    private var gatt: BluetoothGatt? = null
    private val notifyQueue = ArrayDeque<BluetoothGattCharacteristic>()
    private var descriptorWriteInProgress = false
    private val logLines = StringBuilder()
    private val captureLines = mutableListOf<String>()
    private var packetNo = 0
    private var sessionNo = 0
    private val ts = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    private val OPEN_CAPTURE = 200
    private var importedA: List<String>? = null
    private var importedB: List<String>? = null

    private enum class CaptureMode { IDLE, BASELINE, EVENT }
    private var captureMode = CaptureMode.IDLE
    private var modeStartMs = 0L
    private var eventWindowSeconds = 10
    private val evidence = ProtocolEvidence() // all false: actuator WRITE remains hard-disabled

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        buildUi()
        requestBlePermissions()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }

        val title = TextView(this).apply {
            text = "OKN DSP Controller\nV16 EVIDENCE GATE + EVENT CORRELATION"
            textSize = 22f
        }

        status = TextView(this).apply {
            text = "WRITE DISABLED — evidence gate: capture/read/notify only"
            textSize = 15f
        }

        val scan = Button(this).apply {
            text = "SCAN DSP"
            setOnClickListener { startScan() }
        }

        val save = Button(this).apply {
            text = "SAVE CAPTURE"
            setOnClickListener { shareCapture() }
        }

        val analyze = Button(this).apply {
            text = "ANALYZE CAPTURE\n(baseline vs event)"
            setOnClickListener { analyzeCapture() }
        }

        val evidenceBtn = Button(this).apply {
            text = "EVIDENCE GATE"
            setOnClickListener { showEvidenceGate() }
        }

        val importBtn = Button(this).apply {
            text = "IMPORT CAPTURE"
            setOnClickListener { openCaptureFile() }
        }

        val baseline = Button(this).apply {
            text = "START EVENT BASELINE"
            setOnClickListener { startBaseline() }
        }

        val markEvent = Button(this).apply {
            text = "MARK CONTROLLED EVENT\n(change ONE DSP parameter immediately)"
            setOnClickListener { markControlledEvent() }
        }

        val clear = Button(this).apply {
            text = "CLEAR LOG"
            setOnClickListener {
                logLines.clear()
                captureLines.clear()
                importedA = null
                importedB = null
                captureMode = CaptureMode.IDLE
                modeStartMs = 0L
                log.text = "Log:\n"
            }
        }

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        log = TextView(this).apply {
            text = "Log:\n"
            textSize = 13f
        }

        root.addView(title)
        root.addView(status)
        root.addView(scan)
        root.addView(save)
        root.addView(analyze)
        root.addView(evidenceBtn)
        root.addView(importBtn)
        root.addView(baseline)
        root.addView(markEvent)
        root.addView(clear)
        root.addView(list)
        root.addView(log)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun requestBlePermissions() {
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT
                ),
                100
            )
        }
    }

    private fun startScan() {
        if (!hasBlePermission()) {
            append("Bluetooth permission not granted")
            return
        }

        val manager = getSystemService(BluetoothManager::class.java)
        val adapter = manager?.adapter
        if (adapter == null) {
            append("Bluetooth adapter not available")
            return
        }
        if (!adapter.isEnabled) {
            append("Bluetooth is OFF — turn Bluetooth ON and scan again")
            return
        }

        scanner = adapter.bluetoothLeScanner
        if (scanner == null) {
            append("BLE scanner not available")
            return
        }

        found.clear()
        list.removeAllViews()
        append("Scanning for LE-GOLOPINE DSP ...")

        try {
            scanner?.startScan(callback)
        } catch (_: SecurityException) {
            append("Bluetooth permission denied")
            return
        }

        handler.postDelayed({
            try { scanner?.stopScan(callback) } catch (_: Exception) {}
            append("Scan finished")
        }, 10000)
    }

    private fun hasBlePermission(): Boolean =
        android.os.Build.VERSION.SDK_INT < 31 ||
        (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
         checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED)

    private val callback = object : ScanCallback() {
        override fun onScanResult(type: Int, result: ScanResult) {
            val device = result.device
            val name = result.scanRecord?.deviceName
                ?: try { device.name } catch (_: SecurityException) { null }

            if (name?.contains("GOLOPINE", true) == true ||
                name?.contains("DSP", true) == true) {
                if (!found.containsKey(device.address)) {
                    found[device.address] = device
                    runOnUiThread {
                        val b = Button(this@MainActivity).apply {
                            text = "${name ?: "DSP"}\n${device.address}\nTAP TO CONNECT"
                            setOnClickListener { connect(device, name ?: "DSP") }
                        }
                        list.addView(b)
                    }
                }
            }
        }

        override fun onScanFailed(errorCode: Int) {
            append("BLE scan failed: $errorCode")
        }
    }

    private fun connect(device: BluetoothDevice, name: String) {
        sessionNo += 1
        packetNo = 0
        synchronized(captureLines) { captureLines.add("=== SESSION #$sessionNo START ${ts.format(Date())} ===") }
        if (!hasBlePermission()) {
            append("Bluetooth permission not granted")
            return
        }

        try {
            gatt?.close()
            gatt = null
            notifyQueue.clear()
            descriptorWriteInProgress = false
            status.text = "CONNECTING — $name"
            append("Connecting to $name ${device.address} ...")
            gatt = device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
        } catch (_: SecurityException) {
            append("Bluetooth permission denied")
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, statusCode: Int, newState: Int) {
            append("GATT state=$newState status=$statusCode")
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                status.text = "CONNECTED — discovery/read/notify only"
                append("Connected — discovering services")
                try { g.discoverServices() }
                catch (_: SecurityException) { append("Service discovery permission denied") }
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                status.text = "DISCONNECTED"
                append("Disconnected")
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, statusCode: Int) {
            append("Services discovered: status=$statusCode")
            if (statusCode == BluetoothGatt.GATT_SUCCESS) append("Evidence gate active: passive mode only")
            if (statusCode != BluetoothGatt.GATT_SUCCESS) return

            notifyQueue.clear()
            readableQueue.clear()

            val abService = g.services.firstOrNull { it.uuid == BleProfile.AB00_SERVICE }
            val preferredNotify = abService?.characteristics?.filter { it.uuid == BleProfile.AB02_NOTIFY || it.uuid == BleProfile.AB03_NOTIFY } ?: emptyList()
            abService?.getCharacteristic(BleProfile.AB01_WRITE)?.let { ch ->
                if ((ch.properties and BluetoothGattCharacteristic.PROPERTY_READ) != 0) {
                    readableQueue.addLast(ch)
                }
            }

            g.services.forEachIndexed { si, service ->
                append("SERVICE[$si] ${service.uuid}")
                service.characteristics.forEachIndexed { ci, ch ->
                    val props = properties(ch)
                    append("  CHAR[$ci] ${ch.uuid} [$props]")
                    ch.descriptors.forEach { d ->
                        append("    DESC ${d.uuid}")
                    }

                    if (preferredNotify.isNotEmpty()) {
                        if (preferredNotify.any { it.uuid == ch.uuid }) notifyQueue.addLast(ch)
                    } else if ((ch.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0 ||
                        (ch.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) {
                        notifyQueue.addLast(ch)
                    }
                }
            }

            append("NOTIFY TARGETS=${notifyQueue.size} (AB02/AB03 preferred when present)")
            processNextNotificationSubscription(g)

            // Read one characteristic at a time to avoid GATT_BUSY.
            handler.postDelayed({ readNextReadable(g) }, 500)
        }

        override fun onDescriptorWrite(
            g: BluetoothGatt,
            descriptor: BluetoothGattDescriptor,
            statusCode: Int
        ) {
            append("CCCD WRITE ${descriptor.uuid} status=$statusCode")
            descriptorWriteInProgress = false
            handler.postDelayed({ processNextNotificationSubscription(g) }, 250)
        }

        override fun onCharacteristicChanged(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            value: ByteArray
        ) {
            capture("RX_NOTIFY", characteristic.uuid.toString(), value)
        }

        override fun onCharacteristicRead(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            value: ByteArray,
            statusCode: Int
        ) {
            capture("RX_READ", characteristic.uuid.toString(), value, "status=$statusCode")
            handler.postDelayed({ readNextReadable(g) }, 250)
        }

        @Suppress("DEPRECATION")
        override fun onCharacteristicRead(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            statusCode: Int
        ) {
            capture("RX_READ", characteristic.uuid.toString(), characteristic.value ?: byteArrayOf(), "status=$statusCode")
            handler.postDelayed({ readNextReadable(g) }, 250)
        }
    }

    private var readableQueue = ArrayDeque<BluetoothGattCharacteristic>()

    private fun readNextReadable(g: BluetoothGatt) {
        if (!hasBlePermission()) return
        val ch = readableQueue.removeFirstOrNull() ?: return
        append("READ REQUEST ${shortUuid(ch.uuid)}")
        try {
            g.readCharacteristic(ch)
        } catch (_: Exception) {
            handler.postDelayed({ readNextReadable(g) }, 300)
        }
    }

    private fun processNextNotificationSubscription(g: BluetoothGatt) {
        if (descriptorWriteInProgress) return
        val ch = notifyQueue.removeFirstOrNull() ?: return
        subscribeToNotifications(g, ch)
    }

    private fun subscribeToNotifications(g: BluetoothGatt, ch: BluetoothGattCharacteristic) {
        if (!hasBlePermission()) return

        try {
            val localOk = g.setCharacteristicNotification(ch, true)
            append("SUBSCRIBE ${shortUuid(ch.uuid)} local=$localOk")

            val cccd = ch.getDescriptor(
                UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
            )

            if (cccd == null) {
                append("  CCCD NOT FOUND")
                handler.postDelayed({ processNextNotificationSubscription(g) }, 250)
                return
            }

            val value =
                if ((ch.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0)
                    BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
                else
                    BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE

            descriptorWriteInProgress = true

            if (android.os.Build.VERSION.SDK_INT >= 33) {
                val rc = g.writeDescriptor(cccd, value)
                append("  CCCD REQUEST rc=$rc")
                if (rc != BluetoothGatt.GATT_SUCCESS) {
                    descriptorWriteInProgress = false
                    handler.postDelayed({ processNextNotificationSubscription(g) }, 500)
                }
            } else {
                @Suppress("DEPRECATION")
                cccd.value = value
                @Suppress("DEPRECATION")
                val ok = g.writeDescriptor(cccd)
                append("  CCCD REQUEST ok=$ok")
                if (!ok) {
                    descriptorWriteInProgress = false
                    handler.postDelayed({ processNextNotificationSubscription(g) }, 500)
                }
            }
        } catch (_: SecurityException) {
            append("  CCCD permission denied")
            descriptorWriteInProgress = false
        } catch (e: Exception) {
            append("  CCCD error=${e.message}")
            descriptorWriteInProgress = false
        }
    }

    private fun properties(ch: BluetoothGattCharacteristic): String {
        val p = mutableListOf<String>()
        if (ch.properties and BluetoothGattCharacteristic.PROPERTY_READ != 0) p.add("READ")
        if (ch.properties and BluetoothGattCharacteristic.PROPERTY_WRITE != 0) p.add("WRITE")
        if (ch.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0) p.add("WRITE_NR")
        if (ch.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0) p.add("NOTIFY")
        if (ch.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0) p.add("INDICATE")
        return p.joinToString(",")
    }

    private fun shortUuid(uuid: UUID): String = uuid.toString()

    private fun ByteArray.toHex(): String =
        take(128).joinToString(" ") { "%02X".format(it.toInt() and 0xFF) }

    private fun startBaseline() {
        if (gatt == null) {
            append("BASELINE: connect to DSP first")
            return
        }
        captureMode = CaptureMode.BASELINE
        modeStartMs = System.currentTimeMillis()
        append("=== BASELINE START — collect idle packets for 5 seconds ===")
        handler.postDelayed({
            if (captureMode == CaptureMode.BASELINE) {
                captureMode = CaptureMode.IDLE
                append("=== BASELINE END — idle reference locked ===")
            }
        }, 5000)
    }

    private fun markControlledEvent() {
        if (gatt == null) {
            append("EVENT: connect to DSP first")
            return
        }
        captureMode = CaptureMode.EVENT
        modeStartMs = System.currentTimeMillis()
        append("=== CONTROLLED EVENT START — change exactly ONE DSP parameter NOW ===")
        append("EVENT WINDOW=${eventWindowSeconds}s — WRITE remains disabled in this app")
        append("Capture is automatic; do not change another parameter during this window")

        handler.postDelayed({
            if (captureMode == CaptureMode.EVENT) {
                captureMode = CaptureMode.IDLE
                val elapsed = System.currentTimeMillis() - modeStartMs
                append("=== CONTROLLED EVENT END — captured for ${elapsed}ms ===")
                append("Press ANALYZE CAPTURE to compare BASELINE vs EVENT")
            }
        }, eventWindowSeconds * 1000L)
    }

    private fun captureMeta(kind: String, uuid: String) {
        val n = synchronized(captureLines) { packetNo += 1; packetNo }
        val line = "${ts.format(Date())}\t#$n\t$kind\t$uuid"
        synchronized(captureLines) { captureLines.add(line) }
        append(line)
    }

    private fun capture(kind: String, uuid: String, bytes: ByteArray, extra: String = "") {
        val n = synchronized(captureLines) { packetNo += 1; packetNo }
        val eventMs = if (modeStartMs > 0L) System.currentTimeMillis() - modeStartMs else 0L
        val mode = captureMode.name
        val line = "${ts.format(Date())}\t#$n\t$kind\t$uuid\tlen=${bytes.size}\tmode=$mode\teventMs=$eventMs\t$extra\thex=${bytes.joinToString("") { "%02X".format(it.toInt() and 0xFF) }}"
        synchronized(captureLines) { captureLines.add(line) }
        append(line)
    }


    private fun showEvidenceGate() {
        append("=== V16 EVIDENCE GATE ===")
        append("Transport: AB00/AB01/AB02/AB03 observed and usable for passive capture")
        append("AB01: READ/WRITE/WRITE_NR capability observed; app WRITE path remains disabled")
        append("AB02/AB03: NOTIFY + CCCD observed; passive notification subscription succeeds")
        append("Observed capture classes: AB02 10B/13B records; TYPE-A/TYPE-B are capture-derived labels only")
        append("Observed eventMs/deltaMs fields are analyzer-derived from captured text, not proven protocol fields")
        append("UFE reference command IDs: WRITE=0x57 READ=0x58 JSON=0x59 FIFO=0x61 BULK=0x63")
        append("UFE IDs above are reference evidence only; wire framing/check/integrity/encryption are NOT verified")
        append("WRITE ENABLED = ${evidence.writeEnabled}")
        append("GATE MISSING: ${evidence.missingRequirements().joinToString("; ")}")
    }

    private fun openCaptureFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "text/plain"
            addCategory(Intent.CATEGORY_OPENABLE)
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        try { startActivityForResult(intent, OPEN_CAPTURE) }
        catch (e: Exception) { append("IMPORT ERROR=${e.message}") }
    }

    @Deprecated("Activity result API retained for phone-only compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != OPEN_CAPTURE || resultCode != RESULT_OK || data == null) return
        try {
            val uris = mutableListOf<Uri>()
            data.data?.let { uris.add(it) }
            data.clipData?.let { clip -> for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri) }
            val unique = uris.distinct().take(2)
            if (unique.isEmpty()) return
            val imported = unique.map { uri ->
                contentResolver.openInputStream(uri)?.use { input -> BufferedReader(InputStreamReader(input)).readLines() } ?: emptyList()
            }
            if (imported.size == 1) {
                importedA = imported[0]
                append("IMPORTED SESSION A: ${imported[0].size} lines")
            } else {
                importedA = imported[0]
                importedB = imported[1]
                append("IMPORTED A=${imported[0].size} lines, B=${imported[1].size} lines")
                analyzeDifferential(imported[0], imported[1])
            }
        } catch (e: Exception) { append("IMPORT ERROR=${e.message}") }
    }

    private fun payload(line: String): ByteArray? {
        val h = line.substringAfter("hex=", "").trim().takeIf { it.isNotBlank() } ?: return null
        if (h.length % 2 != 0 || !h.all { it in "0123456789abcdefABCDEF" }) return null
        return ByteArray(h.length / 2) { i -> h.substring(i * 2, i * 2 + 2).toInt(16).toByte() }
    }

    private fun captureRecords(lines: List<String>, len: Int? = null, kindPrefix: String? = null): List<ByteArray> =
        lines.filter { line ->
            (len == null || Regex("\\blen=$len\\b").containsMatchIn(line)) &&
            (kindPrefix == null || line.contains("\\t$kindPrefix"))
        }.mapNotNull { payload(it) }

    private fun analyzeDifferential(a: List<String>, b: List<String>) {
        append("=== V13 CROSS-SESSION DIFFERENTIAL ===")
        compareClass("9B", captureRecords(a, 9), captureRecords(b, 9))
        compareClass("13B", captureRecords(a, 13), captureRecords(b, 13))
        compareClass("16B", captureRecords(a, 16), captureRecords(b, 16))
        compareClass("32B", captureRecords(a, 32), captureRecords(b, 32))
        val aBulk = captureRecords(a, 235) + captureRecords(a, 157)
        val bBulk = captureRecords(b, 235) + captureRecords(b, 157)
        append("BULK A=${aBulk.sumOf { it.size }}B B=${bBulk.sumOf { it.size }}B")
        if (aBulk.isNotEmpty()) bulkStructure("A", aBulk)
        if (bBulk.isNotEmpty()) bulkStructure("B", bBulk)
        append("RULE: differing bytes are candidates only; no field meaning/key/checksum is claimed")
    }

    private fun compareClass(label: String, a: List<ByteArray>, b: List<ByteArray>) {
        append("[$label] A=${a.size} B=${b.size}")
        if (a.isEmpty() || b.isEmpty()) return
        val n = minOf(a.size, b.size)
        val diffCounts = IntArray(label.removeSuffix("B").toInt())
        var exact = 0
        for (i in 0 until n) {
            if (a[i].contentEquals(b[i])) exact++
            for (j in diffCounts.indices) if (a[i][j] != b[i][j]) diffCounts[j]++
        }
        append("[$label] aligned=$n exact=$exact/${n} differing-per-position=" + diffCounts.mapIndexed { i,c -> "$i:$c" }.joinToString(","))
        append("[$label] Aunique=${a.map { it.toHexFull() }.toSet().size} Bunique=${b.map { it.toHexFull() }.toSet().size}")
    }

    private fun bulkStructure(label: String, chunks: List<ByteArray>) {
        val stream = chunks.fold(ByteArray(0)) { acc, x -> acc + x }
        append("BULK $label chunks=${chunks.size} reassembled=${stream.size}B")
        if (stream.isNotEmpty()) {
            append("BULK $label first64=${stream.take(64).joinToString("") { "%02X".format(it.toInt() and 0xFF) }}")
            val zeros = stream.count { it.toInt() == 0 }
            append("BULK $label zeroBytes=$zeros/${stream.size}")
        }
    }

    private fun ByteArray.toHexFull(): String = joinToString("") { "%02X".format(it.toInt() and 0xFF) }

    private fun shareCapture() {
        val body = synchronized(captureLines) { captureLines.joinToString("\n") }
        if (body.isBlank()) { append("CAPTURE EMPTY"); return }
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "OKN DSP V15 event-correlation capture")
            putExtra(Intent.EXTRA_TEXT, body)
        }
        startActivity(Intent.createChooser(intent, "Export DSP capture"))
    }


    private fun analyzeCapture() {
        val lines = synchronized(captureLines) { captureLines.toList() }
        if (lines.isEmpty()) { append("ANALYSIS: CAPTURE EMPTY"); return }

        append("=== V16 EVIDENCE GATE + EVENT CORRELATION ===")
        val rx = lines.filter { "\tRX_NOTIFY\t" in it }
        val base = rx.filter { "\tmode=BASELINE\t" in it }
        val event = rx.filter { "\tmode=EVENT\t" in it }
        append("RX notify records=${rx.size} baseline=${base.size} event=${event.size}")
        append("baseline lengths=${lengthHistogram(base)}")
        append("event lengths=${lengthHistogram(event)}")

        val baseDur = base.mapNotNull { Regex("\\beventMs=(\\d+)").find(it)?.groupValues?.get(1)?.toLongOrNull() }.maxOrNull() ?: 0L
        val eventDur = event.mapNotNull { Regex("\\beventMs=(\\d+)").find(it)?.groupValues?.get(1)?.toLongOrNull() }.maxOrNull() ?: 0L
        append("baseline window=${baseDur}ms event window=${eventDur}ms")

        compareLengthRates(base, event)
        comparePayloadReuse(base, event)
        comparePositionEntropy(base, event)
        reportEventTiming(event)
        analyzeObservedEventFields(event)
        compareNotifySources(base, event)
        append("RULE: event differences are candidates only; no packet field, encryption, checksum or DSP meaning is claimed")
        append("NEXT: repeat the SAME single control change across multiple sessions")
    }

    private fun analyzeObservedEventFields(event: List<String>) {
        if (event.isEmpty()) return
        val deltas = event.mapNotNull {
            Regex("\\bdeltaMs=(\\d+)").find(it)?.groupValues?.get(1)?.toLongOrNull()
        }
        val eventMs = event.mapNotNull {
            Regex("\\beventMs=(\\d+)").find(it)?.groupValues?.get(1)?.toLongOrNull()
        }
        val a = event.count { it.contains("len=10") }
        val b = event.count { it.contains("len=13") }
        append("OBSERVED CLASSES: 10B=$a 13B=$b (capture-derived only)")
        if (deltas.isNotEmpty()) {
            append("OBSERVED deltaMs: min=${deltas.minOrNull()} max=${deltas.maxOrNull()} avg=${"%.1f".format(Locale.US, deltas.average())}")
        }
        if (eventMs.size >= 2) {
            val monotonic = eventMs.zipWithNext().all { it.first <= it.second }
            append("OBSERVED eventMs: first=${eventMs.first()} last=${eventMs.last()} monotonic=$monotonic")
        }
    }

    private fun reportEventTiming(event: List<String>) {
        if (event.isEmpty()) {
            append("EVENT TIMING: no RX_NOTIFY packets captured inside event window")
            return
        }
        val times = event.mapNotNull {
            Regex("\\beventMs=(\\d+)").find(it)?.groupValues?.get(1)?.toLongOrNull()
        }
        if (times.isNotEmpty()) {
            append("EVENT TIMING: first=${times.minOrNull()}ms last=${times.maxOrNull()}ms count=${times.size}")
        }
    }

    private fun compareNotifySources(base: List<String>, event: List<String>) {
        fun sourceCounts(xs: List<String>): String {
            val m = linkedMapOf<String, Int>()
            xs.forEach { line ->
                val uuid = line.split("\\t").getOrNull(3) ?: return@forEach
                m[uuid] = (m[uuid] ?: 0) + 1
            }
            return if (m.isEmpty()) "none" else m.entries.joinToString { "${it.key}:${it.value}" }
        }
        append("SOURCES baseline=${sourceCounts(base)}")
        append("SOURCES event=${sourceCounts(event)}")
    }

    private fun lengthHistogram(lines: List<String>): String {
        val m = linkedMapOf<Int,Int>()
        for (line in lines) {
            val n = Regex("\\blen=(\\d+)").find(line)?.groupValues?.get(1)?.toIntOrNull() ?: continue
            m[n] = (m[n] ?: 0) + 1
        }
        return if (m.isEmpty()) "none" else m.entries.sortedBy { it.key }.joinToString { "${it.key}B:${it.value}" }
    }

    private fun compareLengthRates(base: List<String>, event: List<String>) {
        val bl = base.mapNotNull { Regex("\\blen=(\\d+)").find(it)?.groupValues?.get(1)?.toIntOrNull() }.groupingBy { it }.eachCount()
        val el = event.mapNotNull { Regex("\\blen=(\\d+)").find(it)?.groupValues?.get(1)?.toIntOrNull() }.groupingBy { it }.eachCount()
        val keys = (bl.keys + el.keys).toSortedSet()
        for (k in keys) append("RATE $k B baseline=${bl[k] ?: 0} event=${el[k] ?: 0}")
    }

    private fun comparePayloadReuse(base: List<String>, event: List<String>) {
        fun hexes(xs: List<String>) = xs.mapNotNull { it.substringAfter("hex=", "").takeIf { h -> h.isNotBlank() } }
        val bh = hexes(base); val eh = hexes(event)
        val common = bh.toSet().intersect(eh.toSet()).size
        append("PAYLOAD reuse: baselineUnique=${bh.toSet().size} eventUnique=${eh.toSet().size} exactCommon=${common}")
    }

    private fun comparePositionEntropy(base: List<String>, event: List<String>) {
        fun bytes(xs: List<String>) = xs.mapNotNull { payload(it) }
        val b = bytes(base); val e = bytes(event)
        for (len in listOf(10,13)) {
            val bb = b.filter { it.size == len }; val ee = e.filter { it.size == len }
            if (bb.isEmpty() || ee.isEmpty()) continue
            val stableB = (0 until len).count { i -> bb.map { it[i] }.toSet().size == 1 }
            val stableE = (0 until len).count { i -> ee.map { it[i] }.toSet().size == 1 }
            append("POSITION $len B stable=$stableB/$len E stable=$stableE/$len")
        }
    }

    private fun uniquePayloads(lines: List<String>): Int {
        return lines.mapNotNull { line ->
            line.substringAfter("hex=", "").takeIf { it.isNotBlank() }
        }.toSet().size
    }

    private fun append(message: String) {
        runOnUiThread {
            logLines.append(message).append('\n')
            log.text = "Log:\n$logLines"
        }
    }

    override fun onDestroy() {
        try { scanner?.stopScan(callback) } catch (_: Exception) {}
        try { gatt?.close() } catch (_: Exception) {}
        gatt = null
        super.onDestroy()
    }
}
