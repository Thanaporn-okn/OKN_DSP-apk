package com.okn.dsp

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.le.*
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.*
import androidx.core.app.ActivityCompat
import com.okn.dsp.transport.BleProfile

class MainActivity : Activity() {
    private lateinit var log: TextView
    private lateinit var list: LinearLayout
    private val handler = Handler(Looper.getMainLooper())
    private var scanner: BluetoothLeScanner? = null
    private val found = LinkedHashMap<String, BluetoothDevice>()

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        buildUi()
        requestBlePermissions()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
        }
        val title = TextView(this).apply {
            text = "OKN DSP Controller\nResearch / READ-DISCOVERY build"
            textSize = 22f
        }
        val status = TextView(this).apply {
            text = "WRITE DISABLED — waiting for verified UFE framing"
            textSize = 15f
        }
        val scan = Button(this).apply {
            text = "SCAN DSP"
            setOnClickListener { startScan() }
        }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        log = TextView(this).apply {
            text = "Log:\n"
            textSize = 13f
        }
        root.addView(title)
        root.addView(status)
        root.addView(scan)
        root.addView(list)
        root.addView(log)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun requestBlePermissions() {
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT),
                100
            )
        }
    }

    private fun startScan() {
        if (!hasBlePermission()) return
        found.clear()
        list.removeAllViews()
        val manager = getSystemService(android.bluetooth.BluetoothManager::class.java)
        val bt = manager?.adapter
        if (bt == null) {
            append("Bluetooth adapter not available")
            return
        }
        if (!bt.isEnabled) {
            append("Bluetooth is OFF — turn Bluetooth ON and scan again")
            return
        }
        scanner = bt.bluetoothLeScanner
        if (scanner == null) {
            append("BLE scanner not available")
            return
        }
        append("Scanning for ${BleProfile.DEVICE_NAME} ...")
        try {
            scanner?.startScan(callback)
        } catch (e: SecurityException) {
            append("Bluetooth permission denied")
            return
        }
        handler.postDelayed({ scanner?.stopScan(callback); append("Scan finished") }, 10000)
    }

    private fun hasBlePermission(): Boolean =
        android.os.Build.VERSION.SDK_INT < 31 ||
        (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
         checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED)

    private val callback = object : ScanCallback() {
        override fun onScanResult(type: Int, result: ScanResult) {
            val d = result.device
            val name = result.scanRecord?.deviceName ?: try { d.name } catch (_: SecurityException) { null }
            if (name == BleProfile.DEVICE_NAME || name?.contains("GoloPine", true) == true) {
                if (!found.containsKey(d.address)) {
                    found[d.address] = d
                    runOnUiThread {
                        val b = Button(this@MainActivity).apply {
                            text = "$name\n${d.address}"
                            setOnClickListener {
                                append("Selected $name ${d.address}")
                                append("Next: capture/discover services; no DSP write is performed.")
                            }
                        }
                        list.addView(b)
                    }
                }
            }
        }
        override fun onScanFailed(errorCode: Int) {
            append("BLE scan failed: $errorCode")
        }
    }

    private fun append(s: String) {
        runOnUiThread { log.append("$s\n") }
    }
}
