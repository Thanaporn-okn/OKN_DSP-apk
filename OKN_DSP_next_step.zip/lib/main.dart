import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() => runApp(const OknDspApp());

class OknDspApp extends StatelessWidget {
  const OknDspApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'OKN DSP',
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple), useMaterial3: true),
    home: const DspHomePage(),
  );
}

class DspHomePage extends StatefulWidget {
  const DspHomePage({super.key});
  @override
  State<DspHomePage> createState() => _DspHomePageState();
}

class _DspHomePageState extends State<DspHomePage> {
  static const _ble = MethodChannel('okn_dsp/ble');
  StreamSubscription? _events;
  bool _scanning = false, _connected = false;
  String _status = 'พร้อมค้นหา DSP-OKN';
  final _devices = <Map<String, dynamic>>[];
  final _chars = <Map<String, dynamic>>[];
  final _hex = TextEditingController(text: '01 00');
  String _lastRx = '-';

  @override
  void initState() {
    super.initState();
    _events = _ble.receiveBroadcastStream().listen((event) {
      if (!mounted) return;
      final e = Map<String, dynamic>.from(event as Map);
      switch (e['type']) {
        case 'scan':
          if (e['name'] == 'DSP-OKN') {
            final d = {'name': e['name'], 'address': e['address'], 'rssi': e['rssi']};
            setState(() {
              _devices.removeWhere((x) => x['address'] == d['address']);
              _devices.add(d);
            });
          }
          break;
        case 'state':
          setState(() {
            _connected = e['connected'] == true;
            _status = e['message']?.toString() ?? '';
          });
          break;
        case 'characteristic':
          setState(() => _chars.add({
            'service': e['service'] ?? '', 'uuid': e['uuid'] ?? '', 'properties': e['properties'] ?? ''
          }));
          break;
        case 'rx':
          setState(() => _lastRx = e['hex']?.toString() ?? '-');
          break;
        case 'error':
          setState(() => _status = 'ERROR: ${e['message']}');
          break;
      }
    });
  }

  @override
  void dispose() { _events?.cancel(); _hex.dispose(); super.dispose(); }

  Future<void> _scan() async {
    setState(() { _devices.clear(); _chars.clear(); _scanning = true; _status = 'กำลังค้นหา DSP-OKN...'; });
    try { await _ble.invokeMethod('startScan', {'seconds': 8}); }
    catch (e) { setState(() => _status = 'Scan ไม่ได้: $e'); }
    finally { if (mounted) setState(() => _scanning = false); }
  }

  Future<void> _connect(String address) async {
    setState(() => _status = 'กำลังเชื่อมต่อ DSP-OKN...');
    try { await _ble.invokeMethod('connect', {'address': address}); }
    catch (e) { setState(() => _status = 'เชื่อมต่อไม่ได้: $e'); }
  }

  Future<void> _disconnect() async { try { await _ble.invokeMethod('disconnect'); } catch (_) {} }

  Future<void> _readAll() async {
    try { await _ble.invokeMethod('readAll'); }
    catch (e) { setState(() => _status = 'อ่านไม่ได้: $e'); }
  }

  Future<void> _writeHex() async {
    try {
      await _ble.invokeMethod('writeHex', {'hex': _hex.text.trim()});
      setState(() => _status = 'ส่ง: ${_hex.text.trim()}');
    } catch (e) { setState(() => _status = 'ส่งไม่ได้: $e'); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('OKN DSP Controller'),
      actions: [IconButton(onPressed: _scanning ? null : _scan, icon: const Icon(Icons.bluetooth_searching))],
    ),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      Card(child: ListTile(
        leading: Icon(_connected ? Icons.bluetooth_connected : Icons.bluetooth,
          color: _connected ? Colors.green : null),
        title: const Text('DSP-OKN'),
        subtitle: Text(_status),
        trailing: _connected ? IconButton(onPressed: _disconnect, icon: const Icon(Icons.link_off)) : null,
      )),
      FilledButton.icon(
        onPressed: _scanning ? null : _scan,
        icon: const Icon(Icons.search),
        label: Text(_scanning ? 'กำลังค้นหา...' : 'ค้นหา DSP-OKN'),
      ),
      const SizedBox(height: 8),
      if (_devices.isEmpty) const Text('กดค้นหา แล้วเปิด Bluetooth ของบอร์ดให้ชื่อเป็น DSP-OKN',
        textAlign: TextAlign.center),
      ..._devices.map((d) => Card(child: ListTile(
        leading: const Icon(Icons.memory),
        title: Text(d['name'].toString()),
        subtitle: Text('${d['address']}   RSSI ${d['rssi']}'),
        trailing: FilledButton(onPressed: _connected ? null : () => _connect(d['address']), child: const Text('เชื่อมต่อ')),
      ))),
      const Divider(height: 32),
      const Text('BLE Services / Characteristics',
        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      if (_chars.isEmpty) const Text('ยังไม่ได้ค้นหา Characteristic'),
      ..._chars.map((c) => Card(child: ListTile(
        dense: true,
        title: Text(c['uuid'].toString()),
        subtitle: Text('Service: ${c['service']}\nProperties: ${c['properties']}'),
      ))),
      if (_connected) ...[
        const SizedBox(height: 12),
        OutlinedButton.icon(onPressed: _readAll, icon: const Icon(Icons.download),
          label: const Text('อ่าน Characteristic ที่อ่านได้')),
        const SizedBox(height: 16),
        TextField(controller: _hex, decoration: const InputDecoration(
          labelText: 'ข้อมูล HEX สำหรับทดสอบส่ง DSP',
          hintText: 'เช่น 01 00 FF', border: OutlineInputBorder())),
        const SizedBox(height: 8),
        FilledButton.icon(onPressed: _writeHex, icon: const Icon(Icons.send), label: const Text('ส่งข้อมูล HEX')),
        const SizedBox(height: 12),
        Text('ข้อมูลล่าสุดจาก DSP: $_lastRx'),
      ],
      const SizedBox(height: 24),
      const Text('ขั้นนี้ค้นหา/เชื่อมต่อ DSP-OKN และค้นหา UUID อัตโนมัติ '
        'ก่อนกำหนดคำสั่ง EQ/Gain/Crossover ของ BP1048P4 เพื่อไม่เดาคำสั่งผิด',
        style: TextStyle(color: Colors.black54)),
    ]),
  );
}
