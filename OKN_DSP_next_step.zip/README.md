# OKN DSP Controller

Bluetooth ของบอร์ด:
- OKN-BT = Media / เล่นเพลง
- DSP-OKN = ควบคุม DSP

รุ่นนี้ไม่ใช้ flutter_blue_plus เพื่อหลีกเลี่ยงปัญหา Gradle/plugin ที่พบก่อนหน้า
และใช้ Android BLE API โดยตรงผ่าน Kotlin + Flutter MethodChannel

ฟังก์ชัน:
- Scan หา DSP-OKN
- Connect / Disconnect
- Discover Services และ Characteristics
- แสดง UUID / Properties
- อ่าน Characteristic ที่รองรับ READ
- ส่งข้อมูล HEX ไปยัง Characteristic ที่รองรับ WRITE

ยังไม่เดาคำสั่ง EQ/Gain/Crossover ของ BP1048P4 จนกว่าจะได้ UUID และ protocol จริงจากบอร์ด
