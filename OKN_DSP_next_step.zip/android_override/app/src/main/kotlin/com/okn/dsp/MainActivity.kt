package com.okn.dsp

import android.Manifest
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val channel = "okn_dsp/ble"
    private var sink: EventChannel.EventSink? = null
    private var gatt: BluetoothGatt? = null
    private var writeCh: BluetoothGattCharacteristic? = null

    private fun emit(m: Map<String, Any?>) = runOnUiThread { sink?.success(m) }

    private val scanCb = object : ScanCallback() {
        override fun onScanResult(type: Int, r: ScanResult) {
            val d = r.device
            val name = try { d.name ?: r.scanRecord?.deviceName ?: "" } catch (_: SecurityException) { "" }
            if (name == "DSP-OKN") emit(mapOf("type" to "scan", "name" to name, "address" to d.address, "rssi" to r.rssi))
        }
        override fun onScanFailed(code: Int) = emit(mapOf("type" to "error", "message" to "BLE scan failed: $code"))
    }

    override fun configureFlutterEngine(engine: FlutterEngine) {
        super.configureFlutterEngine(engine)
        EventChannel(engine.dartExecutor.binaryMessenger, channel).setStreamHandler(object: EventChannel.StreamHandler {
            override fun onListen(a: Any?, s: EventChannel.EventSink?) { sink = s }
            override fun onCancel(a: Any?) { sink = null }
        })
        MethodChannel(engine.dartExecutor.binaryMessenger, channel).setMethodCallHandler { call, result ->
            when (call.method) {
                "startScan" -> { startScan((call.argument<Int>("seconds") ?: 8).coerceIn(3,20)); result.success(null) }
                "connect" -> { val a=call.argument<String>("address"); if(a==null) result.error("ARG","Missing address",null) else { connect(a); result.success(null) } }
                "disconnect" -> { disconnect(); result.success(null) }
                "readAll" -> { readAll(); result.success(null) }
                "writeHex" -> { writeHex(call.argument<String>("hex") ?: ""); result.success(null) }
                else -> result.notImplemented()
            }
        }
    }

    private fun permitted() = if(Build.VERSION.SDK_INT >= 31)
        checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED &&
        checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED
    else checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED

    private fun askPermission() {
        if(permitted()) return
        if(Build.VERSION.SDK_INT >= 31) requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT),1001)
        else requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),1001)
    }

    private fun startScan(seconds:Int) {
        askPermission(); if(!permitted()){emit(mapOf("type" to "error","message" to "กรุณาอนุญาต Bluetooth"));return}
        val a=(getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if(a==null || !a.isEnabled){emit(mapOf("type" to "error","message" to "กรุณาเปิด Bluetooth"));return}
        val s=a.bluetoothLeScanner
        try{s.startScan(scanCb)}catch(e:Exception){emit(mapOf("type" to "error","message" to e.message))}
        Handler(Looper.getMainLooper()).postDelayed({try{s.stopScan(scanCb)}catch(_:Exception){}},seconds*1000L)
    }

    private fun connect(address:String) {
        askPermission(); if(!permitted()){emit(mapOf("type" to "error","message" to "ไม่มีสิทธิ์ Bluetooth"));return}
        try {
            gatt?.close()
            val d=BluetoothAdapter.getDefaultAdapter().getRemoteDevice(address)
            gatt=d.connectGatt(this,false,cb,BluetoothDevice.TRANSPORT_LE)
            emit(mapOf("type" to "state","connected" to false,"message" to "กำลังเชื่อมต่อ DSP-OKN..."))
        } catch(e:Exception){emit(mapOf("type" to "error","message" to (e.message?:"connect error")))}
    }

    private val cb=object:BluetoothGattCallback(){
        override fun onConnectionStateChange(g:BluetoothGatt,status:Int,state:Int){
            if(state==BluetoothProfile.STATE_CONNECTED){gatt=g;emit(mapOf("type" to "state","connected" to true,"message" to "เชื่อมต่อ DSP-OKN แล้ว"));try{g.discoverServices()}catch(_:Exception){}}
            else {writeCh=null;emit(mapOf("type" to "state","connected" to false,"message" to "ตัดการเชื่อมต่อ (status $status)"))}
        }
        override fun onServicesDiscovered(g:BluetoothGatt,status:Int){
            if(status!=BluetoothGatt.GATT_SUCCESS){emit(mapOf("type" to "error","message" to "ค้นหา Service ไม่สำเร็จ: $status"));return}
            for(s in g.services) for(c in s.characteristics){
                val p=mutableListOf<String>(); val x=c.properties
                if(x and BluetoothGattCharacteristic.PROPERTY_READ!=0)p.add("READ")
                if(x and BluetoothGattCharacteristic.PROPERTY_WRITE!=0)p.add("WRITE")
                if(x and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE!=0)p.add("WRITE_NO_RESPONSE")
                if(x and BluetoothGattCharacteristic.PROPERTY_NOTIFY!=0)p.add("NOTIFY")
                if(x and BluetoothGattCharacteristic.PROPERTY_INDICATE!=0)p.add("INDICATE")
                emit(mapOf("type" to "characteristic","service" to s.uuid.toString(),"uuid" to c.uuid.toString(),"properties" to p.joinToString(", ")))
                if(writeCh==null && (x and (BluetoothGattCharacteristic.PROPERTY_WRITE or BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE))!=0) writeCh=c
            }
        }
        override fun onCharacteristicRead(g:BluetoothGatt,c:BluetoothGattCharacteristic,status:Int){
            if(status==BluetoothGatt.GATT_SUCCESS)emit(mapOf("type" to "rx","hex" to c.value.toHex()))
        }
    }

    private fun readAll(){
        val g=gatt ?: return
        if(!permitted())return
        for(s in g.services) for(c in s.characteristics)
            if(c.properties and BluetoothGattCharacteristic.PROPERTY_READ!=0) try{g.readCharacteristic(c)}catch(_:Exception){}
    }

    private fun writeHex(text:String){
        val g=gatt ?: run{emit(mapOf("type" to "error","message" to "ยังไม่ได้เชื่อมต่อ"));return}
        val c=writeCh ?: run{emit(mapOf("type" to "error","message" to "ไม่พบ Characteristic สำหรับ WRITE"));return}
        val b=parse(text) ?: run{emit(mapOf("type" to "error","message" to "HEX ไม่ถูกต้อง"));return}
        try{
            c.value=b
            c.writeType=if(c.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE!=0)
                BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE else BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
            g.writeCharacteristic(c)
        }catch(e:Exception){emit(mapOf("type" to "error","message" to (e.message?:"write error")))}
    }

    private fun parse(s:String):ByteArray?{
        val q=s.replace("0x","",true).replace("[^0-9A-Fa-f]".toRegex(),"")
        if(q.isEmpty()||q.length%2!=0)return null
        return try{ByteArray(q.length/2){i->q.substring(i*2,i*2+2).toInt(16).toByte()}}catch(_:Exception){null}
    }
    private fun ByteArray.toHex()=joinToString(" "){"%02X".format(it.toInt() and 255)}
    private fun disconnect(){try{gatt?.disconnect();gatt?.close()}catch(_:Exception){};gatt=null;writeCh=null;emit(mapOf("type" to "state","connected" to false,"message" to "ตัดการเชื่อมต่อแล้ว"))}
}
