#include "bp1048p4_port_contract.h"

okn_status_t bp1048p4_hal_validate_contract(const bp1048p4_hal_t *hal,
                                             const bp1048p4_port_evidence_t *evidence) {
    if (!hal || !evidence) return OKN_ERR_ARG;
    if (evidence->magic != BP1048P4_PORT_EVIDENCE_MAGIC ||
        evidence->abi_version != BP1048P4_PORT_ABI_VERSION) return OKN_ERR_FORMAT;

    if (!evidence->bp1048p4_target_verified ||
        !evidence->board_profile_verified ||
        !evidence->platform_init_verified ||
        !evidence->output_safety_mute_verified ||
        !evidence->audio_path_verified) return OKN_ERR_HAL_LOCKED;

    if (!hal->platform_init || !hal->set_output_safety_mute || !hal->audio_start ||
        !hal->apply_master_gain || !hal->apply_channel_state) return OKN_ERR_ARG;
    return OKN_OK;
}
