# OKN_BP1048P4_FW_V8

Clean-room replacement firmware foundation for GoloPine / BP1048P4 7CH.

V8 preserves the tested V7 DSP, protocol, persistence, stream and safe-boot
core. It tightens the hardware boundary by separating **family**, **exact chip**
and **exact board** evidence. An exact BP1048P4 SDK alone can no longer be
mistaken for proof of GoloPine board routing or flash-image layout.

## V8 additions
- SDK adapter ABI 2 with FAMILY_ONLY / EXACT_CHIP / EXACT_BOARD levels
- exact-chip evidence cannot unlock any GoloPine board operation by itself
- per-subsystem board proof for audio, BLE, NVM and flash image layout
- provenance link to the validated V7 source and validation artifact SHA256
- machine-readable `evidence_manifest.json`
- evidence-manifest consistency test and fail-closed verification
- `tools/evidence_inventory.py` hashes future vendor artifacts without inferring
  or authorizing hardware facts

## Existing core
- 7 independent channels
- gain / mute / phase / 0-50 ms delay
- 15-band PEQ per channel; notch / low shelf / high shelf
- HPF / LPF
- CRC-framed OKN Protocol V2 + state readback
- BLE-like fragmented stream reassembly/resync
- portable 48 kHz reference audio engine
- CRC32 A/B persistence with rollback/read-after-write verification
- fail-closed boot contract with output safety mute

## Hardware safety
V8 is **not hardware-flashable**. No BP1048P4 register, MMIO address, boot
vector, pin map, linker address, vendor BLE call or flash command is guessed.
The public MVsB1/BP1048-family SDK remains family-only evidence.

Validation:
```sh
make host-test
```
