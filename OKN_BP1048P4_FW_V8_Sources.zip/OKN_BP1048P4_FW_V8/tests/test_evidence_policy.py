#!/usr/bin/env python3
from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
e=json.loads((root/'evidence_manifest.json').read_text())
t=json.loads((root/'target_port_manifest.json').read_text())
assert e['project_version']==8
assert e['hardware_authorized'] is False
assert all(v is False for v in e['required_exact_evidence'].values())
assert t['hardware_flashable'] is False
assert all(v is False for v in t['evidence'].values())
assert t['public_family_sdk']['p4_use_authorized'] is False
for obs in e['observations']:
    assert obs['authorizes']==[]
print('ALL V8 EVIDENCE POLICY TESTS PASS')
