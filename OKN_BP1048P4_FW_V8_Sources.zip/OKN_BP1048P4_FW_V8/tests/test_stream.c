#include "../src/transport/okn_stream.h"
#include "../src/core/okn_controller.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

static size_t finish_pkt(uint8_t *p, uint8_t cmd, const uint8_t *payload, uint16_t plen) {
    p[0]='O'; p[1]='K'; p[2]=OKN_PROTO_VERSION; p[3]=cmd;
    p[4]=(uint8_t)plen; p[5]=(uint8_t)(plen>>8);
    if (plen) memcpy(&p[6], payload, plen);
    const uint16_t crc=okn_crc16_ccitt(p,6u+plen);
    p[6u+plen]=(uint8_t)crc; p[7u+plen]=(uint8_t)(crc>>8);
    return 8u+plen;
}

typedef struct {
    okn_controller_t ctl;
    unsigned calls;
    uint8_t last_cmd;
} sink_t;

static okn_status_t on_frame(void *u, const uint8_t *f, size_t n) {
    sink_t *s=(sink_t*)u;
    uint8_t rsp[160]; size_t rn=0u;
    ++s->calls; s->last_cmd=f[3];
    return okn_protocol_execute(&s->ctl,f,n,rsp,sizeof(rsp),&rn);
}

int main(void) {
    okn_stream_t st; sink_t sink;
    okn_stream_init(&st); okn_controller_init(&sink.ctl); sink.calls=0u; sink.last_cmd=0u;

    uint8_t a[32], b[32];
    size_t an=finish_pkt(a,OKN_CMD_PING,NULL,0u);
    uint8_t ch=3u; size_t bn=finish_pkt(b,OKN_CMD_GET_CHANNEL_STATE,&ch,1u);

    /* BLE-like fragmentation: 1 byte, then partial header, then remainder. */
    assert(okn_stream_feed(&st,a,1u,on_frame,&sink)==OKN_OK);
    assert(sink.calls==0u);
    assert(okn_stream_feed(&st,a+1u,4u,on_frame,&sink)==OKN_OK);
    assert(sink.calls==0u);
    assert(okn_stream_feed(&st,a+5u,an-5u,on_frame,&sink)==OKN_OK);
    assert(sink.calls==1u && sink.last_cmd==OKN_CMD_PING);

    /* Noise before frame must be discarded and resynchronized. */
    const uint8_t noise[]={0x00,0xFF,'O',0x00,0x11};
    assert(okn_stream_feed(&st,noise,sizeof(noise),on_frame,&sink)==OKN_OK);
    assert(okn_stream_feed(&st,b,bn,on_frame,&sink)==OKN_OK);
    assert(sink.calls==2u && sink.last_cmd==OKN_CMD_GET_CHANNEL_STATE);

    /* Two concatenated frames in a single transport chunk. */
    uint8_t combo[64]; memcpy(combo,a,an); memcpy(combo+an,b,bn);
    assert(okn_stream_feed(&st,combo,an+bn,on_frame,&sink)==OKN_OK);
    assert(sink.calls==4u);

    /* Corrupt frame is not delivered; following valid frame still is. */
    uint8_t bad[32]; memcpy(bad,a,an); bad[an-1u]^=1u;
    memcpy(combo,bad,an); memcpy(combo+an,a,an);
    assert(okn_stream_feed(&st,combo,an+an,on_frame,&sink)==OKN_OK);
    assert(sink.calls==5u);
    assert(st.crc_errors>=1u);
    assert(st.frames_ok==5u);

    puts("ALL V8 STREAM TESTS PASS");
    return 0;
}
