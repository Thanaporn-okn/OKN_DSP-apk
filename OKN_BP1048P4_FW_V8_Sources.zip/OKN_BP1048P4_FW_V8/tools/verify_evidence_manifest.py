#!/usr/bin/env python3
from pathlib import Path
import json, re, sys
root = Path(__file__).resolve().parents[1]
p = root / 'evidence_manifest.json'
m = json.loads(p.read_text())
errors=[]
if m.get('schema') != 1: errors.append('evidence schema must be 1')
if m.get('project_version') != 8: errors.append('project version must be 8')
if m.get('target') != 'BP1048P4' or m.get('board') != 'GoloPine 7CH': errors.append('target/board mismatch')
if m.get('policy') != 'FAIL_CLOSED_NO_INFERENCE': errors.append('evidence policy must fail closed')
sha = m.get('provenance',{}).get('previous_source_sha256','')
if not re.fullmatch(r'[0-9a-f]{64}', sha): errors.append('invalid V7 source SHA256 provenance')
vsha = m.get('provenance',{}).get('validation_zip_sha256','')
if not re.fullmatch(r'[0-9a-f]{64}', vsha): errors.append('invalid V7 validation SHA256 provenance')
for obs in m.get('observations',[]):
    if obs.get('class') in {'FAMILY_ONLY','SOFTWARE_VALIDATION','BOARD_OBSERVATION'} and obs.get('authorizes'):
        errors.append(f"non-authoritative observation {obs.get('id')} must authorize nothing")
req=m.get('required_exact_evidence',{})
if not req: errors.append('missing required_exact_evidence')
if any(bool(v) for v in req.values()): errors.append('V8 required exact evidence must ship false')
if m.get('hardware_authorized') is not False: errors.append('V8 hardware_authorized must be false')
if errors:
    for e in errors: print('BLOCKED:',e)
    sys.exit(1)
print('PASS: V8 evidence manifest is coherent, provenance-linked, and non-authorizing')
