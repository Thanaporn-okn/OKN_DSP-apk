# V8 SDK adapter / target gate

V7 adds a compile-time/runtime-neutral SDK adapter authorization layer. It does
not import or call vendor code. Its purpose is to prevent family-level evidence
from being accidentally treated as exact BP1048P4 evidence.

Public family evidence currently inspected:
- repository: `leadercxn/bp1048_sdk_v0.1.12`
- label: `MVsB1_BT_Audio_SDK_v0.1.12`
- Andes/Eclipse project settings are present
- the inspected flash preference names `b1_download_v1.7.exe`

That last observation is especially important: a B1 downloader/configuration is
not authorization to program a BP1048P4. V8 therefore rejects FAMILY_ONLY
capabilities for runtime audio, BLE, NVM, and flash-image use.

To unlock a future target version, exact P4/GoloPine evidence must be reviewed
for each subsystem independently: chip identity, startup, linker memory map,
flash programmer, audio path, BLE API, NVM API, and board pin map.
