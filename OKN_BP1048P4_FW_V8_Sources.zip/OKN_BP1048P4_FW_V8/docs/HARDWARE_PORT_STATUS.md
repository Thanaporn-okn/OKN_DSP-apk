# Hardware port status — V8

| Port area | V8 state |
|---|---|
| BP1048 family SDK existence | EVIDENCE FOUND / FAMILY ONLY |
| Exact BP1048P4 chip SDK compatibility | NOT VERIFIED |
| Exact GoloPine board identity/profile | NOT VERIFIED |
| Startup + linker memory map | NOT VERIFIED |
| Output safety-mute implementation | CONTRACT ONLY / LOCKED |
| Audio source/sink routing | CONTRACT ONLY / LOCKED |
| BLE/GATT implementation and board route | LOCKED |
| NVM API and board layout | LOCKED |
| Programmer + image layout for this board | NOT VERIFIED |
| Hardware-flashable image | NO |

V8 adds a second boundary: even authentic BP1048P4 **chip** evidence does not
unlock a GoloPine **board** operation. The board identity and the specific
routing/layout evidence must also be exact and reviewed.
