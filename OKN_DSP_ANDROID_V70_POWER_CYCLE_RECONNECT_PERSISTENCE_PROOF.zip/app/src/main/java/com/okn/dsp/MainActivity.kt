package com.okn.dsp

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * V70 production persistence-proof control hub.
 *
 * V70 preserves the runtime-qualified V69 writer scope and PRE/POST SaveParams guards.
 * New in V70 is a read-only, user-armed power-cycle/reconnect persistence proof using a
 * stored POST-SAVE snapshot of 7 scalars + all 105 EQ bands. No new write family is enabled.
 */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
    }

    private fun buildUi(): ScrollView {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 32)
        }

        root.addView(TextView(this).apply {
            text = "OKN DSP V70 — POWER-CYCLE / RECONNECT PERSISTENCE PROOF"
            textSize = 22f
        })

        root.addView(TextView(this).apply {
            text = "REAL DSP CONTROLS ONLY • NO MOCK EQ • NO LOCAL PRESET WRITE • GENERIC WRITES LOCKED"
            textSize = 14f
            setPadding(0, 8, 0, 12)
        })

        root.addView(TextView(this).apply {
            text = "Verified coverage\n" +
                "• Global FLOAT32: IDs 2,3,8,9,10,13,11\n" +
                "• EQ 7CH: actuator IDs 4,5,6,14,15,16,17 • 15 bands/channel\n" +
                "• SaveParams: ID7 exact trigger 570000000700000000\n" +
                "• V70 unified dashboard: V68-qualified Global + safe-PEAKING EQ writes preserved; SaveParams now requires fresh PRE-SAVE and POST-SAVE descriptor checks.\n" +
                "• REFRESH ALL now visibly reports START/COMPLETE + time + changed counts even when values are unchanged.\n" +
                "• Preset, Delay and unknown writes remain locked."
            textSize = 13f
            setPadding(0, 0, 0, 16)
        })

        root.addView(Button(this).apply {
            text = "UNIFIED V70 • V69 VERIFIED WRITES + POWER-CYCLE PERSISTENCE PROOF"
            setOnClickListener { startActivity(Intent(this@MainActivity, UnifiedControlActivity::class.java)) }
        })
        root.addView(TextView(this).apply {
            text = "V70 Phase 4: all V69 scalar/EQ write/verify/rollback + PRE/POST Save guards are preserved. After a successful save, V70 stores the fresh 7-scalar + 105-EQ POST-SAVE state. ARM the proof, power-cycle the DSP, reconnect and START; V70 compares the next fresh authenticated descriptor read-only. No protocol writer is added."
            textSize = 12f
            setPadding(0, 2, 0, 12)
        })

        root.addView(Button(this).apply {
            text = "GLOBAL CONTROLS • 7 VERIFIED REAL DSP CONTROLS • APPLY + VERIFY + PERMANENT SAVE"
            setOnClickListener { startActivity(Intent(this@MainActivity, ScalarControlActivity::class.java)) }
        })
        root.addView(TextView(this).apply {
            text = "Production Global Controls: every APPLY uses WRITE 0x57 → fresh Device Description verify → automatic rollback if verify fails. Permanent Save remains a separate guarded action."
            textSize = 12f
            setPadding(0, 2, 0, 12)
        })

        root.addView(Button(this).apply {
            text = "LIVE EQ 7CH • REAL DSP • APPLY + VERIFY + PERMANENT SAVE"
            setOnClickListener { startActivity(Intent(this@MainActivity, LiveEqActivity::class.java)) }
        })
        root.addView(TextView(this).apply {
            text = "7CH real EQ from live Device Description • 105 bands • writes only verified safe PEAKING bands • automatic rollback when readback does not match."
            textSize = 12f
            setPadding(0, 2, 0, 12)
        })

        root.addView(Button(this).apply {
            text = "ADVANCED • EVIDENCE / CAPTURE LAB (READ-ONLY / PROOF TOOLS)"
            setOnClickListener { startActivity(Intent(this@MainActivity, EvidenceLabActivity::class.java)) }
        })

        return ScrollView(this).apply { addView(root) }
    }
}
