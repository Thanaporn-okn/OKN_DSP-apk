package com.okn.dsp

import androidx.compose.material3.*
import androidx.compose.runtime.Composable

@Composable
fun MainScreen(){
 Text("OKN_DSP BP1048P4 7CH Controller")
}
