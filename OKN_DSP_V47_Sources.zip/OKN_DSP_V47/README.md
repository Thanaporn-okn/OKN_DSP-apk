# OKN DSP V47 — Bass Volume ID8 +24 dB

V47 continues the verified V46 path and follows the user requirement: **Bass Volume only**. It does not increase bass through any EQ band and does not modify Master Volume or channel volume.

The Bass Volume slider now requests **-70..+24 dB** on the same verified `BassVolume` actuator **ID8 / FLOAT32**. The original descriptor remains preserved as protocol evidence and still advertises -70..+6 dB; V46 testing showed the user's DSP accepts +12 dB, so V47 extends the diagnostic/usable range to +24 dB without changing packet format.

After the latest Bass Volume write settles, the app reads ID8 back. If the DSP accepts the value, the confirmed value remains on screen. If firmware clamps a request above +12 to about +12 dB (or older firmware clamps above +6 to about +6 dB), V47 stops retrying and reports the actual DSP value.

Safety: high positive bass gain can clip the DSP, overdrive an amplifier, or stress a subwoofer. Increase gradually and reduce immediately if distortion, mechanical noise, or protection behavior appears.
