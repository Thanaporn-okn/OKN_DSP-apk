# OKN DSP V47

V47 is based on the validated V46 build and changes **only the Bass Volume controller range**.

## V47 audio change
- Bass Volume stays on the existing UFE scalar actuator **ID 8 / BassVolume**.
- Controller range is now **`0..+74 dB`**. Negative Bass Volume values are no longer selectable.
- Maximum remains `+74 dB`, which the user verified on the real board and verified persists after **Save DSP + power cycle**.
- Default/Reset Bass Volume remains `+2 dB`.
- Master Volume remains `-70..+6 dB`.
- **BassBoost ID10 is not used or repurposed.**
- **No EQ actuator mapping, EQ gain/F/Q range, coefficient formula, 48-byte EQ writer, EQ cadence, or Safe Reset behavior is changed.**

The stock device descriptor in `Sources/ProtocolEvidence/` is kept unchanged. V47 changes only the Android controller's allowed BassVolume ID8 range; it does not rewrite the board descriptor.

## Build
GitHub Actions workflow: `.github/workflows/OKN_DSP_AutoBuild.yml`. It auto-selects the newest packaged source/repo tree, validates SHA256 + DSP safety invariants, installs Android SDK packages/licenses, builds the signed Release APK and uploads APK + SHA256.
