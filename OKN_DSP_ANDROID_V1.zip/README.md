# OKN DSP Android Controller V1

สร้างจาก `DSP_APP_RESEARCH_BUNDLE_V1.zip`

## สถานะ
- Android app สำหรับมือถือ
- BLE scan หา `GoloPineDSPAudioTurning`
- ใช้ UUID ที่ค้นพบใน bundle
- โหมดนี้เป็น READ/DISCOVERY เท่านั้น
- ปิดการ WRITE DSP ไว้จนกว่าจะยืนยัน packet framing, checksum/CRC, authentication/encryption และ actuator paths จาก capture จริง

## Build บนมือถือผ่าน GitHub
1. สร้าง repository ใหม่บน GitHub
2. อัปโหลดไฟล์ ZIP นี้แล้วแตกไฟล์ให้โครงสร้าง `app/`, `build.gradle.kts`, `.github/` อยู่ที่ root
3. ไปที่ Actions
4. เลือก `Build Android APK`
5. กด `Run workflow`
6. เมื่อเสร็จ เปิด run นั้น แล้วดาวน์โหลด artifact `OKN-DSP-debug-apk`

หมายเหตุ: Android Studio ไม่จำเป็นต้องใช้บนมือถือ เพราะ GitHub Actions เป็นตัว build APK ให้
