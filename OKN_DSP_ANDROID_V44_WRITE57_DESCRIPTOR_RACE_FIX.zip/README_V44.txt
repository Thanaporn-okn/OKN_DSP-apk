OKN DSP V44 — WRITE57 Descriptor Verification Race Fix

Evidence from V43 live capture:
- MasterVolume baseline from descriptor: 1.840005 dB
- WRITE 0x57 plaintext: 57 + ID=2(BE32) + offset=0(BE16) + length=4(BE16) + FLOAT32LE
- Temporary target: 0.840005 dB
- Target descriptor stream contained MasterVolume=0.840005
- Failsafe RESTORE 0x57 sent original 1.840005 dB
- Restore descriptor stream contained MasterVolume=1.840005
- SaveParams ID=7 was never sent

V43 protocol write/restore therefore worked on the real DSP. Its proof tracker missed the first 0x86 header because the descriptor response raced the stage transition, and its 5 s failsafe expired while the 18,143-byte descriptor was still arriving.

V44 fixes only that verifier race/timing:
1. arms TARGET/RESTORE collector stage before issuing the descriptor refresh write;
2. recovers an 0x86 header even if it arrives while stage 3/5 is still visible;
3. increases the target failsafe window to 15 s and rearms 12 s at refresh;
4. keeps normal writes and SaveParams locked.
