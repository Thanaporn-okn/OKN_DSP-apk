package com.okn.dsp.protocol

/**
 * V44 gate: normal UI writes remain locked.
 * Only the Evidence Lab controlled MasterVolume proof may issue WRITE 0x57,
 * with a descriptor-baseline -> -1 dB -> descriptor-verify -> automatic restore -> descriptor-verify sequence.
 * SaveParams (ID 7), EQ, presets, delay and persistent writes remain blocked.
 */
object WriteGate {
    const val enabled: Boolean = false
    const val controlledMasterVolumeProofEnabled: Boolean = true
}
