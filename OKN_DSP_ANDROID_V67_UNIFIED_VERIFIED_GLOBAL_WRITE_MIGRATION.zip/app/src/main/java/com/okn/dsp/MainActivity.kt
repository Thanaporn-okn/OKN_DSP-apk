package com.okn.dsp

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * V67 production verified control hub.
 *
 * New in V67: migrates only the seven verified Global scalar writes into the shared
 * unified BLE/auth/RandKey session. EQ and sensors remain read-only. V66 same-session
 * REFRESH ALL behavior is preserved. SaveParams remains separate/manual/guarded.
 */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
    }

    private fun buildUi(): ScrollView {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 32)
        }

        root.addView(TextView(this).apply {
            text = "OKN DSP V67 — PRODUCTION VERIFIED CONTROL HUB"
            textSize = 22f
        })

        root.addView(TextView(this).apply {
            text = "REAL DSP CONTROLS ONLY • NO MOCK EQ • NO LOCAL PRESET WRITE • GENERIC WRITES LOCKED"
            textSize = 14f
            setPadding(0, 8, 0, 12)
        })

        root.addView(TextView(this).apply {
            text = "Verified coverage\n" +
                "• Global FLOAT32: IDs 2,3,8,9,10,13,11\n" +
                "• EQ 7CH: actuator IDs 4,5,6,14,15,16,17 • 15 bands/channel\n" +
                "• SaveParams: ID7 exact trigger 570000000700000000\n" +
                "• V67 unified dashboard: one BLE/auth/RandKey session loads Global + EQ + 4 sensors; only verified Global IDs 2,3,8,9,10,13,11 are writable.\n" +
                "• REFRESH ALL now visibly reports START/COMPLETE + time + changed counts even when values are unchanged.\n" +
                "• Preset, Delay and unknown writes remain locked."
            textSize = 13f
            setPadding(0, 0, 0, 16)
        })

        root.addView(Button(this).apply {
            text = "UNIFIED V67 • VERIFIED GLOBAL WRITES + EQ/SENSORS READ ONLY"
            setOnClickListener { startActivity(Intent(this@MainActivity, UnifiedControlActivity::class.java)) }
        })
        root.addView(TextView(this).apply {
            text = "V67 Phase 1: connect/auth once; each Global APPLY does fresh preflight → exact baseline → write → GATT success → fresh verify, with exact rollback + verify on failure. REFRESH ALL stays same-session. EQ/Sensors stay read-only. SaveParams is manual guarded after verified scalar change only."
            textSize = 12f
            setPadding(0, 2, 0, 12)
        })

        root.addView(Button(this).apply {
            text = "GLOBAL CONTROLS • 7 VERIFIED REAL DSP CONTROLS • APPLY + VERIFY + PERMANENT SAVE"
            setOnClickListener { startActivity(Intent(this@MainActivity, ScalarControlActivity::class.java)) }
        })
        root.addView(TextView(this).apply {
            text = "Production Global Controls: every APPLY uses WRITE 0x57 → fresh Device Description verify → automatic rollback if verify fails. Permanent Save remains a separate guarded action."
            textSize = 12f
            setPadding(0, 2, 0, 12)
        })

        root.addView(Button(this).apply {
            text = "LIVE EQ 7CH • REAL DSP • APPLY + VERIFY + PERMANENT SAVE"
            setOnClickListener { startActivity(Intent(this@MainActivity, LiveEqActivity::class.java)) }
        })
        root.addView(TextView(this).apply {
            text = "7CH real EQ from live Device Description • 105 bands • writes only verified safe PEAKING bands • automatic rollback when readback does not match."
            textSize = 12f
            setPadding(0, 2, 0, 12)
        })

        root.addView(Button(this).apply {
            text = "ADVANCED • EVIDENCE / CAPTURE LAB (READ-ONLY / PROOF TOOLS)"
            setOnClickListener { startActivity(Intent(this@MainActivity, EvidenceLabActivity::class.java)) }
        })

        return ScrollView(this).apply { addView(root) }
    }
}
