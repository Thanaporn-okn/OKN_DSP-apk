package com.okn.dsp

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.ContentValues
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import com.okn.dsp.protocol.*
import com.okn.dsp.transport.BleProfile
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * V67 unified verified global-write migration, phase 1.
 *
 * One BLE connection/auth/RandKey session owns all Device Description reads and the only
 * write-capable path exposed here: the seven already-verified FLOAT32 scalar actuators
 * IDs 2,3,8,9,10,13,11. Every scalar APPLY performs a fresh full-descriptor preflight,
 * captures the exact live baseline, sends the narrow UFE FLOAT32 write, requires a GATT
 * success callback, then requests another fresh full descriptor and verifies readback.
 * Verification failure triggers an exact baseline rollback plus another fresh descriptor
 * verification. EQ (7 x 15) and the four sensors remain read-only in this phase.
 * Generic/unknown/preset/delay writes stay locked. SaveParams ID7 is manual and guarded,
 * and can only be sent after a scalar target has verified in this V67 unified session.
 */
class UnifiedControlActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private val ts = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    private val startupProbe16 = ByteCodec.hexToBytes("631C062443FD3844558001F3EDA0CCF8")

    private lateinit var status: TextView
    private lateinit var deviceList: LinearLayout
    private lateinit var startSessionButton: Button
    private lateinit var refreshButton: Button
    private lateinit var refreshInfo: TextView
    private lateinit var scalarHost: LinearLayout
    private lateinit var sensorHost: LinearLayout
    private lateinit var channelSpinner: Spinner
    private lateinit var eqHost: LinearLayout
    private lateinit var logView: TextView

    private var scanner: android.bluetooth.le.BluetoothLeScanner? = null
    private val found = LinkedHashMap<String, BluetoothDevice>()
    private var gatt: BluetoothGatt? = null
    private var ab01: BluetoothGattCharacteristic? = null
    private var ab02: BluetoothGattCharacteristic? = null
    private var connectedName: String? = null

    private var waitingAuth = false
    private var sessionReady = false
    private var txCipher: SessionTxCipher? = null
    private var rxCipher: SessionRxCipher? = null

    private enum class DescMode { INITIAL, REFRESH, WRITE_PREFLIGHT, VERIFY_TARGET, VERIFY_RESTORE }
    private enum class PendingGattPurpose { SCALAR_TARGET, SCALAR_RESTORE, SAVE_PARAMS }
    private enum class GattWriteKind { OTHER, SCALAR_TARGET, SCALAR_RESTORE, SAVE_PARAMS }
    private val gattWriteTickets = java.util.ArrayDeque<GattWriteKind>()
    private var descMode: DescMode? = null
    private var descExpected = -1
    private val descBytes = ByteArrayOutputStream()
    private var descriptorTimeout: Runnable? = null

    private var pendingId: Int? = null
    private var pendingTarget: Float? = null
    private var pendingOriginal: Float? = null
    private var pendingGattPurpose: PendingGattPurpose? = null
    private var gattActionTimeout: Runnable? = null

    private val saveCommitSettleMs = 5000L
    private var unsavedVerifiedChanges = false
    private var verifiedChangeCount = 0
    private var saveInFlight = false
    private var saveGattOk = false
    private var saveSettleRunnable: Runnable? = null
    private lateinit var permanentSaveButton: Button
    private lateinit var dirtyInfo: TextView

    private val scalarValues = LinkedHashMap<Int, Float>()
    private val bands = Array(7) { arrayOfNulls<EqBand48>(15) }
    private val sensors = mutableListOf<SensorSnapshot>()
    private var selectedChannel = 1

    private var refreshCount = 0
    private var refreshStartedElapsedMs = 0L
    private var refreshBeforeScalars: Map<Int, Float> = emptyMap()
    private var refreshBeforeSensors: Map<Int, String> = emptyMap()
    private var refreshBeforeEq: Map<String, String> = emptyMap()

    private data class SensorSnapshot(val id: Int, val name: String, val valueText: String)

    private val captureLines = mutableListOf<String>()
    private var packetNo = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestBlePermissions()
        record("META", "V67_UNIFIED_ACTIVITY_START")
        record("META", "V67_UNIFIED_POLICY scalarWrites=true scalarIds=2,3,8,9,10,13,11 eqReadOnly=true sensorReadOnly=true genericWrites=false saveParams=manualGuarded expectedScalars=7 expectedEqBands=105 expectedSensors=4")
        record("META", "V67_UNIFIED_RUNTIME_EVIDENCE scalarProduction=V64 eqProduction=V62/V64 saveParamsPersistence=V57")
    }

    override fun onDestroy() {
        cancelDescriptorTimeout()
        cancelGattActionTimeout()
        cancelSaveTimers()
        try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
        try { gatt?.close() } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 22, 22, 28)
        }
        root.addView(TextView(this).apply {
            text = "OKN DSP V67 — UNIFIED VERIFIED GLOBAL-WRITE DASHBOARD"
            textSize = 22f
        })
        status = TextView(this).apply {
            text = "DISCONNECTED • one BLE session • 7 VERIFIED scalar writes • EQ/Sensors READ ONLY"
            textSize = 14f
            setPadding(0, 8, 0, 10)
        }
        root.addView(status)
        root.addView(TextView(this).apply {
            text = "V67 Phase 1 ย้ายเฉพาะ verified scalar writes IDs 2,3,8,9,10,13,11 เข้า Unified session เดียว. ทุก APPLY ใช้ fresh descriptor preflight → exact live baseline → WRITE 0x57 → GATT success → fresh descriptor verify; หาก verify ไม่ผ่านจะ exact rollback + fresh restore verify. EQ และ Sensors ยัง READ ONLY. Generic/unknown/preset/delay writes ถูกล็อก. SaveParams เป็น manual guarded เท่านั้น."
            textSize = 13f
        })

        root.addView(Button(this).apply {
            text = "SCAN DSP"
            setOnClickListener { startScan() }
        })
        deviceList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(deviceList)

        startSessionButton = Button(this).apply {
            text = "START V67 UNIFIED VERIFIED CONTROL SESSION"
            isEnabled = false
            setOnClickListener { confirmStartSession() }
        }
        root.addView(startSessionButton)

        refreshButton = Button(this).apply {
            text = "REFRESH ALL • SAME SESSION"
            isEnabled = false
            setOnClickListener { beginRefresh() }
        }
        root.addView(refreshButton)
        refreshInfo = TextView(this).apply {
            text = "REFRESH STATUS • ยังไม่ได้ refresh • เมื่อกดแล้ว V67 จะแสดง START/COMPLETE + เวลา + จำนวนค่าที่เปลี่ยน แม้ค่าทั้งหมดเหมือนเดิม"
            textSize = 12f
            setPadding(0, 2, 0, 8)
        }
        root.addView(refreshInfo)

        root.addView(TextView(this).apply {
            text = "GLOBAL • 7 VERIFIED SCALARS • APPLY + VERIFY"
            textSize = 19f
            setPadding(0, 18, 0, 4)
        })
        scalarHost = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(scalarHost)

        dirtyInfo = TextView(this).apply {
            text = "RAM DIRTY • 0 verified scalar changes • Permanent Save locked"
            textSize = 13f
            setPadding(0, 6, 0, 4)
        }
        root.addView(dirtyInfo)
        permanentSaveButton = Button(this).apply {
            text = "PERMANENT SAVE • MANUAL GUARDED • LOCKED"
            isEnabled = false
            setOnClickListener { confirmPermanentSave() }
        }
        root.addView(permanentSaveButton)
        root.addView(TextView(this).apply {
            text = "SaveParams ID7 exact trigger 570000000700000000 จะส่งได้เฉพาะหลัง scalar target verify ผ่านใน V67 session นี้. ไม่มี auto-save. SaveParams บันทึก turning parameters ปัจจุบันทั้งชุด ดังนั้นตรวจ final state ก่อนกด SAVE."
            textSize = 12f
            setPadding(0, 0, 0, 8)
        })

        root.addView(TextView(this).apply {
            text = "SENSORS"
            textSize = 19f
            setPadding(0, 18, 0, 4)
        })
        sensorHost = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(sensorHost)

        root.addView(TextView(this).apply {
            text = "EQ • 7 CHANNELS × 15 BANDS • LIVE READ ONLY"
            textSize = 19f
            setPadding(0, 18, 0, 4)
        })
        channelSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@UnifiedControlActivity, android.R.layout.simple_spinner_dropdown_item,
                (1..7).map { "CH$it / ID${LiveEqPolicy.actuatorForChannel(it)}" })
            onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                    selectedChannel = position + 1
                    renderEq()
                }
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
            }
        }
        root.addView(channelSpinner)
        eqHost = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(eqHost)

        root.addView(Button(this).apply {
            text = "SAVE V67 UNIFIED WRITE-MIGRATION CAPTURE TO DOWNLOADS"
            setOnClickListener { saveCapture() }
        })
        logView = TextView(this).apply { textSize = 11f; setPadding(0, 12, 0, 0) }
        root.addView(logView)

        setContentView(ScrollView(this).apply { addView(root) })
        renderAll()
    }

    private fun beginRefresh() {
        if (!sessionReady || descMode != null || waitingAuth || txCipher == null || gatt == null || ab01 == null || pendingId != null || saveInFlight || pendingGattPurpose != null) {
            Toast.makeText(this, "V67 session busy/not ready", Toast.LENGTH_SHORT).show()
            record("META", "V67_UNIFIED_REFRESH_BLOCKED sessionReady=$sessionReady descMode=$descMode waitingAuth=$waitingAuth txReady=${txCipher != null} gattReady=${gatt != null} ab01Ready=${ab01 != null}")
            return
        }
        refreshCount += 1
        refreshStartedElapsedMs = android.os.SystemClock.elapsedRealtime()
        refreshBeforeScalars = LinkedHashMap(scalarValues)
        refreshBeforeSensors = sensors.associate { it.id to it.valueText }
        refreshBeforeEq = snapshotEqSignatures()
        refreshButton.isEnabled = false
        refreshButton.text = "REFRESHING #$refreshCount • PLEASE WAIT"
        status.text = "V67 REFRESHING #$refreshCount • SAME SESSION • re-reading 7 scalars + 105 EQ + 4 sensors"
        refreshInfo.text = "REFRESH #$refreshCount STARTED • ${ts.format(Date())} • กำลังอ่าน Device Description ใหม่ทั้งชุด"
        record("META", "V67_UNIFIED_REFRESH_TAP refresh=$refreshCount sameSession=true scalarWrites=true eqReadOnly=true sensorReadOnly=true beforeScalars=${refreshBeforeScalars.size} beforeEq=${refreshBeforeEq.size} beforeSensors=${refreshBeforeSensors.size}")
        if (!requestDescriptor(DescMode.REFRESH)) {
            refreshButton.text = "REFRESH ALL • SAME SESSION"
            refreshButton.isEnabled = sessionReady
            refreshInfo.text = "REFRESH #$refreshCount FAILED TO QUEUE • ${ts.format(Date())} • descriptor refresh queue failed; no REFRESH write exists"
            record("META", "V67_UNIFIED_REFRESH_QUEUE_FAILED refresh=$refreshCount")
        }
    }

    private fun confirmStartSession() {
        if (saveInFlight || pendingId != null || descMode != null || pendingGattPurpose != null || waitingAuth) {
            Toast.makeText(this, "V67 protocol busy • รอ pipeline ปัจจุบันให้จบก่อน START ใหม่", Toast.LENGTH_LONG).show(); return
        }
        if (gatt == null || ab01 == null || ab02 == null) {
            Toast.makeText(this, "เชื่อม DSP และรอ AB02 READY ก่อน", Toast.LENGTH_LONG).show(); return
        }
        AlertDialog.Builder(this)
            .setTitle("Start V67 unified verified-control session")
            .setMessage("AUTH16 → derive RandKey → อ่าน Device Description สด → โหลด Global 7 + EQ 105 bands + 4 sensors ใน session เดียว\n\nV67 อนุญาต WRITE 0x57 เฉพาะ scalar IDs 2,3,8,9,10,13,11 ผ่าน fresh-preflight + GATT success + fresh verify + exact rollback. EQ/Sensors READ ONLY. SaveParams manual guarded เท่านั้น")
            .setNegativeButton("ยกเลิก", null)
            .setPositiveButton("START V67") { _, _ -> startSession() }
            .show()
    }

    private fun startSession() {
        val g = gatt ?: return
        val w = ab01 ?: return
        waitingAuth = true
        sessionReady = false
        txCipher = null
        rxCipher = null
        descMode = null
        descExpected = -1
        descBytes.reset()
        scalarValues.clear()
        sensors.clear()
        for (c in bands.indices) for (b in bands[c].indices) bands[c][b] = null
        clearPending("new-session", recordEvent = false)
        pendingGattPurpose = null
        synchronized(gattWriteTickets) { gattWriteTickets.clear() }
        cancelDescriptorTimeout()
        cancelGattActionTimeout()
        cancelSaveTimers()
        unsavedVerifiedChanges = false
        verifiedChangeCount = 0
        saveInFlight = false
        saveGattOk = false
        refreshButton.isEnabled = false
        refreshButton.text = "REFRESH ALL • SAME SESSION"
        refreshCount = 0
        refreshStartedElapsedMs = 0L
        refreshBeforeScalars = emptyMap()
        refreshBeforeSensors = emptyMap()
        refreshBeforeEq = emptyMap()
        if (::refreshInfo.isInitialized) refreshInfo.text = "REFRESH STATUS • session ใหม่กำลังเริ่ม • รอ V67 UNIFIED READY"
        renderAll()
        record("META", "V67_UNIFIED_SESSION_START")
        if (!writeNoResponse(g, w, startupProbe16, "TX_AUTH16_V67_UNIFIED")) {
            waitingAuth = false
            status.text = "AUTH16 queue failed"
        } else status.text = "AUTH16 sent • waiting 32B auth response"
    }

    private fun requestDescriptor(mode: DescMode): Boolean {
        val g = gatt
        val w = ab01
        val tx = txCipher
        if (g == null || w == null || tx == null) {
            record("META", "V67_UNIFIED_DESC_BLOCKED mode=$mode reason=session-object-missing")
            onDescriptorFailure(mode, "session-object-missing")
            return false
        }
        if (descMode != null) {
            record("META", "V67_UNIFIED_DESC_BLOCKED mode=$mode reason=descriptor-busy current=$descMode")
            onDescriptorFailure(mode, "descriptor-busy")
            return false
        }
        descMode = mode
        descExpected = -1
        descBytes.reset()
        val plain = SessionCryptoFacts.DEVICE_DESCRIPTION_REQUEST
        val enc = tx.encryptNext(plain)
        record("META", "V67_UNIFIED_DESC_REQUEST mode=$mode plain=${ByteCodec.run { plain.toHex() }} sameSession=true")
        if (!writeNoResponse(g, w, enc, "TX_DESC_V67_UNIFIED_${mode.name}")) {
            descMode = null
            onDescriptorFailure(mode, "queue-failed")
            return false
        }
        cancelDescriptorTimeout()
        descriptorTimeout = Runnable {
            if (descMode != mode) return@Runnable
            record("META", "V67_UNIFIED_DESC_TIMEOUT mode=$mode id=${pendingId ?: -1}")
            descMode = null
            descExpected = -1
            descBytes.reset()
            onDescriptorFailure(mode, "timeout")
        }.also { handler.postDelayed(it, 15000L) }
        return true
    }

    private fun onDescriptorFailure(mode: DescMode, reason: String) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            handler.post { onDescriptorFailure(mode, reason) }
            return
        }
        when (mode) {
            DescMode.WRITE_PREFLIGHT -> {
                status.text = "V67 WRITE BLOCKED • fresh preflight descriptor failed ($reason)"
                clearPending("preflight-$reason")
            }
            DescMode.VERIFY_TARGET -> restorePending("target-verify-$reason")
            DescMode.VERIFY_RESTORE -> {
                sessionReady = false
                status.text = "RESTORE VERIFY FAILED/UNCONFIRMED — STOP • export capture"
                record("META", "V67_UNIFIED_RESTORE_VERIFY_FATAL reason=$reason id=${pendingId ?: -1}")
                clearPending("restore-verify-$reason")
            }
            DescMode.INITIAL, DescMode.REFRESH -> {
                sessionReady = false
                status.text = "V67 descriptor read failed ($mode/$reason)"
                updateActionButtons()
            }
        }
    }

    private fun cancelDescriptorTimeout() {
        descriptorTimeout?.let { handler.removeCallbacks(it) }
        descriptorTimeout = null
    }

    private fun handleAb02(value: ByteArray) {
        record("RX_NOTIFY", "len=${value.size} hex=${ByteCodec.run { value.toHex() }}")
        if (waitingAuth) {
            if (value.size != 32) return
            try {
                val d = PreAuthRandKeyDecoder.decode(value)
                txCipher = SessionTxCipher(d.randKey)
                rxCipher = SessionRxCipher(d.randKey)
                waitingAuth = false
                record("META", "V67_UNIFIED_RANDKEY_DERIVED type=${d.typeId} ver=${d.versionId} rand=${ByteCodec.run { d.randKey.toHex() }}")
                requestDescriptor(DescMode.INITIAL)
            } catch (e: Exception) {
                waitingAuth = false
                record("META", "V67_UNIFIED_AUTH_DECODE_ERROR ${e.javaClass.simpleName}:${e.message}")
                runOnUiThread { status.text = "Auth decode failed" }
            }
            return
        }
        val rx = rxCipher ?: return
        val plain = try { rx.decryptNext(value) } catch (e: Exception) {
            val activeMode = descMode
            record("META", "V67_UNIFIED_RX_DECRYPT_ERROR ${e.javaClass.simpleName}:${e.message} mode=${activeMode ?: "NONE"}")
            sessionReady = false
            if (activeMode != null) {
                descMode = null
                descExpected = -1
                descBytes.reset()
                cancelDescriptorTimeout()
                onDescriptorFailure(activeMode, "rx-decrypt-error")
            }
            return
        }
        record("RX_PLAIN", "len=${plain.size} hex=${ByteCodec.run { plain.toHex() }}")
        if (descMode != null) collectDescriptor(plain)
    }

    private fun collectDescriptor(plain: ByteArray) {
        val mode = descMode ?: return
        if (descExpected < 0) {
            if (plain.size < 4 || (plain[0].toInt() and 0xff) != 0x86) {
                record("META", "V67_UNIFIED_DESC_NONHEADER mode=$mode marker=${plain.firstOrNull()?.toInt()?.and(0xff)} len=${plain.size}")
                return
            }
            descExpected = (plain[1].toInt() and 0xff) or
                ((plain[2].toInt() and 0xff) shl 8) or
                ((plain[3].toInt() and 0xff) shl 16)
            descBytes.reset()
            descBytes.write(plain, 4, plain.size - 4)
            record("META", "V67_UNIFIED_DESC_HEADER mode=$mode jsonLen=$descExpected")
        } else {
            if (plain.isEmpty() || (plain[0].toInt() and 0xff) != 0x82) {
                record("META", "V67_UNIFIED_DESC_NONCONT mode=$mode marker=${plain.firstOrNull()?.toInt()?.and(0xff)} len=${plain.size}")
                return
            }
            descBytes.write(plain, 1, plain.size - 1)
        }
        if (descExpected > 0 && descBytes.size() >= descExpected) {
            val bytes = descBytes.toByteArray().copyOf(descExpected)
            val obj = try { JSONObject(bytes.toString(Charsets.UTF_8)) } catch (e: Exception) {
                record("META", "V67_UNIFIED_DESC_JSON_ERROR mode=$mode ${e.javaClass.simpleName}:${e.message}")
                cancelDescriptorTimeout()
                descMode = null
                descExpected = -1
                descBytes.reset()
                sessionReady = false
                onDescriptorFailure(mode, "json-error")
                return
            }
            record("META", "V67_UNIFIED_DESC_COMPLETE mode=$mode bytes=${bytes.size}")
            cancelDescriptorTimeout()
            descMode = null
            descExpected = -1
            descBytes.reset()
            handler.post { loadUnified(mode, obj) }
        }
    }

    private fun loadUnified(mode: DescMode, obj: JSONObject) {
        scalarValues.clear()
        val acts = obj.optJSONArray("actuators")
        if (acts != null) {
            for (i in 0 until acts.length()) {
                val a = acts.optJSONObject(i) ?: continue
                val id = a.optInt("ID", -1)
                if (VerifiedScalarControls.allowed(id) && a.optInt("type", -1) == 2000 && a.has("UFE_TYPE_FLOAT32")) {
                    val v = a.optDouble("UFE_TYPE_FLOAT32", Double.NaN).toFloat()
                    if (v.isFinite()) scalarValues[id] = v
                }
            }
        }

        var eqCount = 0
        var writableCount = 0
        for (ch in 1..7) {
            val actuator = LiveEqPolicy.actuatorForChannel(ch)
            for (band1 in 1..15) {
                val band = extractBand(obj, actuator, band1)
                bands[ch - 1][band1 - 1] = band
                if (band != null) {
                    eqCount++
                    if (LiveEqPolicy.isWritable(band)) writableCount++
                }
            }
        }

        sensors.clear()
        val sArr = obj.optJSONArray("sensors")
        if (sArr != null) {
            for (i in 0 until sArr.length()) {
                val s = sArr.optJSONObject(i) ?: continue
                val id = s.optInt("ID", -999)
                val name = s.optString("name", "Sensor$id")
                val valueText = when {
                    s.has("UFE_TYPE_FLOAT32") -> {
                        val v = s.optDouble("UFE_TYPE_FLOAT32", Double.NaN)
                        if (v.isFinite()) String.format(Locale.US, "%.3f", v) else "NaN"
                    }
                    s.has("UFE_TYPE_BOOLEAN_INDICATE") -> s.optBoolean("UFE_TYPE_BOOLEAN_INDICATE").toString()
                    else -> "unknown"
                }
                sensors.add(SensorSnapshot(id, name, valueText))
            }
        }

        val scalarOk = scalarValues.size == VerifiedScalarControls.controls.size
        val eqOk = eqCount == 105
        val sensorOk = sensors.size == 4
        sessionReady = scalarOk && eqOk && sensorOk
        record("META", "V67_UNIFIED_LOAD mode=$mode scalarCount=${scalarValues.size} expectedScalars=7 eqBands=$eqCount expectedEqBands=105 writablePeakingBands=$writableCount sensors=${sensors.size} expectedSensors=4 ready=$sessionReady scalarWrites=true eqReadOnly=true sensorReadOnly=true genericWrites=false saveParamsManual=true")
        renderAll()

        when (mode) {
            DescMode.INITIAL -> {
                status.text = if (sessionReady) {
                    "V67 UNIFIED READY • 7 writable verified scalars + 105 EQ READ ONLY + 4 sensors READ ONLY"
                } else {
                    "V67 UNIFIED BLOCKED • scalar=${scalarValues.size}/7 EQ=$eqCount/105 sensors=${sensors.size}/4"
                }
                refreshInfo.text = if (sessionReady) {
                    "REFRESH STATUS • READY • REFRESH ALL re-reads 7 + 105 + 4 in this same authenticated session"
                } else "REFRESH STATUS • BLOCKED • initial load incomplete"
            }
            DescMode.REFRESH -> finishRefresh(eqCount)
            DescMode.WRITE_PREFLIGHT -> handleWritePreflight(eqCount)
            DescMode.VERIFY_TARGET -> handleTargetVerify(eqCount)
            DescMode.VERIFY_RESTORE -> handleRestoreVerify(eqCount)
        }
        updateActionButtons()
        record("META", "V67_UNIFIED_RENDER_COMPLETE mode=$mode scalarRows=${scalarValues.size} eqRows=${bands[selectedChannel - 1].count { it != null }} sensorRows=${sensors.size} mainThread=${Looper.myLooper() == Looper.getMainLooper()}")
    }

    private fun finishRefresh(eqCount: Int) {
        val afterEq = snapshotEqSignatures()
        val scalarChanged = VerifiedScalarControls.controls.count { c ->
            val before = refreshBeforeScalars[c.id]
            val after = scalarValues[c.id]
            before == null || after == null || kotlin.math.abs(before - after) > 0.0001f
        }
        val afterSensors = sensors.associate { it.id to it.valueText }
        val sensorKeys = refreshBeforeSensors.keys + afterSensors.keys
        val sensorChanged = sensorKeys.count { refreshBeforeSensors[it] != afterSensors[it] }
        val eqKeys = refreshBeforeEq.keys + afterEq.keys
        val eqChanged = eqKeys.count { refreshBeforeEq[it] != afterEq[it] }
        val elapsed = if (refreshStartedElapsedMs > 0L) android.os.SystemClock.elapsedRealtime() - refreshStartedElapsedMs else -1L
        val unchanged = scalarChanged == 0 && sensorChanged == 0 && eqChanged == 0
        val summary = if (unchanged) "NO VALUE CHANGES • refresh สำเร็จ แต่ DSP ส่งค่าชุดเดิม" else "CHANGED • scalars=$scalarChanged • EQ=$eqChanged • sensors=$sensorChanged"
        refreshInfo.text = "REFRESH #$refreshCount COMPLETE • ${ts.format(Date())} • ${elapsed}ms • $summary"
        status.text = if (sessionReady) "V67 UNIFIED READY • REFRESH #$refreshCount COMPLETE • same session" else "V67 REFRESH #$refreshCount BLOCKED • scalar=${scalarValues.size}/7 EQ=$eqCount/105 sensors=${sensors.size}/4"
        record("META", "V67_UNIFIED_REFRESH_COMPLETE refresh=$refreshCount elapsedMs=$elapsed scalarChanged=$scalarChanged eqChanged=$eqChanged sensorChanged=$sensorChanged unchanged=$unchanged scalarCount=${scalarValues.size} eqBands=$eqCount sensors=${sensors.size} ready=$sessionReady sameSession=true")
        Toast.makeText(this, "REFRESH #$refreshCount COMPLETE • ${if (unchanged) "values unchanged" else "values updated"}", Toast.LENGTH_LONG).show()
    }

    private fun handleWritePreflight(eqCount: Int) {
        val id = pendingId ?: return
        val target = pendingTarget ?: return
        if (!sessionReady || eqCount != 105 || !VerifiedScalarControls.allowed(id)) {
            record("META", "V67_UNIFIED_SCALAR_PREFLIGHT_BLOCKED id=$id ready=$sessionReady scalarCount=${scalarValues.size} eqBands=$eqCount sensors=${sensors.size}")
            status.text = "V67 WRITE BLOCKED • fresh descriptor/count/allow-list preflight failed"
            clearPending("preflight-invariants-failed")
            return
        }
        val original = scalarValues[id]
        if (original == null) {
            status.text = "V67 WRITE BLOCKED • fresh baseline missing for ID$id"
            clearPending("preflight-baseline-missing")
            return
        }
        pendingOriginal = original
        record("META", "V67_UNIFIED_SCALAR_PREFLIGHT_OK id=$id freshBaseline=$original target=$target scalarCount=7 eqBands=105 sensors=4 sameSession=true")
        if (VerifiedScalarControls.matches(id, original, target)) {
            status.text = "V67 NO WRITE • target already equals fresh baseline for ID$id"
            record("META", "V67_UNIFIED_SCALAR_NOOP id=$id baseline=$original target=$target")
            clearPending("target-equals-baseline", recordEvent = false)
            return
        }
        sendScalarTargetAfterPreflight()
    }

    private fun handleTargetVerify(eqCount: Int) {
        val id = pendingId ?: return
        val expected = pendingTarget ?: return
        val actual = scalarValues[id]
        val ok = sessionReady && eqCount == 105 && actual != null && VerifiedScalarControls.matches(id, actual, expected)
        record("META", "V67_UNIFIED_TARGET_DESCRIPTOR_VERIFY id=$id expected=$expected actual=${actual ?: "MISSING"} verified=$ok fullDescriptorReady=$sessionReady")
        if (ok) {
            unsavedVerifiedChanges = true
            verifiedChangeCount += 1
            status.text = "V67 VERIFIED • ID$id=${fmt(actual!!)} • RAM DIRTY • Permanent Save remains manual"
            record("META", "V67_UNIFIED_SCALAR_WRITE_COMPLETE id=$id verified=true persistence=RAM_DIRTY verifiedChangeCount=$verifiedChangeCount saveParamsSent=false")
            clearPending("target-verified", recordEvent = false)
        } else {
            restorePending("target-verify-failed")
        }
    }

    private fun handleRestoreVerify(eqCount: Int) {
        val id = pendingId ?: return
        val expected = pendingOriginal ?: return
        val actual = scalarValues[id]
        val ok = sessionReady && eqCount == 105 && actual != null && VerifiedScalarControls.matches(id, actual, expected)
        record("META", "V67_UNIFIED_RESTORE_DESCRIPTOR_VERIFY id=$id expected=$expected actual=${actual ?: "MISSING"} verified=$ok fullDescriptorReady=$sessionReady")
        if (ok) {
            status.text = "V67 TARGET VERIFY FAILED • exact fresh baseline restored safely • no SaveParams"
        } else {
            sessionReady = false
            status.text = "RESTORE VERIFY FAILED — STOP CONTROL • DO NOT SAVE • export capture"
            record("META", "V67_UNIFIED_RESTORE_VERIFY_FATAL id=$id expected=$expected actual=${actual ?: "MISSING"}")
        }
        clearPending(if (ok) "restore-verified" else "restore-verify-failed", recordEvent = false)
    }

    private fun snapshotEqSignatures(): Map<String, String> {
        val out = LinkedHashMap<String, String>(105)
        for (ch in 1..7) {
            for (band1 in 1..15) {
                val b = bands[ch - 1][band1 - 1]
                out["$ch:$band1"] = if (b == null) {
                    "MISSING"
                } else {
                    listOf(
                        b.type.toString(), b.frequency.toString(), b.frequency2.toString(), b.q.toString(),
                        b.boostDb.toString(), b.gain.toString(), b.r.toString(), b.b0.toString(), b.b1.toString(),
                        b.b2.toString(), b.a1.toString(), b.a2.toString()
                    ).joinToString("|")
                }
            }
        }
        return out
    }

    private fun renderAll() {
        renderScalars()
        renderSensors()
        renderEq()
    }

    private fun renderScalars() {
        if (!::scalarHost.isInitialized) return
        scalarHost.removeAllViews()
        if (!sessionReady && scalarValues.isEmpty()) {
            scalarHost.addView(TextView(this).apply { text = "START V67 unified session เพื่อโหลดค่าจริง"; textSize = 14f })
            updateDirtyUi()
            return
        }
        for (c in VerifiedScalarControls.controls) {
            val current = scalarValues[c.id]
            val block = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, 10, 0, 10)
            }
            block.addView(TextView(this).apply {
                text = "${c.name} • ID ${c.id} • current=${current?.let { fmt(it) } ?: "MISSING"} ${c.unit} • range=${fmt(c.min)}..${fmt(c.max)}"
                textSize = 15f
            })
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val edit = EditText(this).apply {
                inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED
                setText(current?.let { fmt(it) } ?: "")
                hint = c.unit
                isEnabled = current != null && sessionReady
            }
            row.addView(edit, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(Button(this).apply {
                text = "APPLY + VERIFY"
                isEnabled = current != null && sessionReady && pendingId == null && descMode == null && pendingGattPurpose == null && !saveInFlight
                setOnClickListener {
                    val requested = edit.text.toString().toFloatOrNull()
                    if (requested == null) Toast.makeText(this@UnifiedControlActivity, "กรอกตัวเลขก่อน", Toast.LENGTH_SHORT).show()
                    else confirmScalarWrite(c, requested)
                }
            })
            block.addView(row)
            scalarHost.addView(block)
        }
        updateDirtyUi()
    }

    private fun updateDirtyUi() {
        if (::dirtyInfo.isInitialized) {
            dirtyInfo.text = if (unsavedVerifiedChanges) {
                "RAM DIRTY • $verifiedChangeCount verified scalar change(s) • Permanent Save available when protocol idle"
            } else {
                "RAM CLEAN/UNARMED • 0 verified V67 scalar changes • Permanent Save locked"
            }
        }
        if (::permanentSaveButton.isInitialized) {
            val enabled = sessionReady && unsavedVerifiedChanges && verifiedChangeCount > 0 && !saveInFlight && pendingId == null && descMode == null && pendingGattPurpose == null && !waitingAuth
            permanentSaveButton.isEnabled = enabled
            permanentSaveButton.text = if (enabled) "PERMANENT SAVE • MANUAL GUARDED • $verifiedChangeCount VERIFIED CHANGE(S)" else "PERMANENT SAVE • MANUAL GUARDED • LOCKED"
        }
    }

    private fun updateActionButtons() {
        if (::refreshButton.isInitialized) {
            refreshButton.text = if (descMode == DescMode.REFRESH) "REFRESHING #$refreshCount • PLEASE WAIT" else "REFRESH ALL • SAME SESSION"
            refreshButton.isEnabled = sessionReady && descMode == null && pendingId == null && pendingGattPurpose == null && !saveInFlight && !waitingAuth
        }
        updateDirtyUi()
        if (::scalarHost.isInitialized && Looper.myLooper() == Looper.getMainLooper()) {
            // Re-rendering refreshes APPLY button guards and displayed fresh values.
            if (scalarHost.childCount > 0 || scalarValues.isNotEmpty()) {
                // Avoid recursive render: updateActionButtons is also called from renderScalars.
            }
        }
    }

    private fun confirmScalarWrite(c: VerifiedScalarControl, requested: Float) {
        if (!WriteGate.unifiedVerifiedScalarWritesEnabled || WriteGate.enabled) {
            Toast.makeText(this, "V67 unified scalar write gate blocked", Toast.LENGTH_LONG).show()
            record("META", "V67_UNIFIED_SCALAR_WRITE_BLOCKED reason=write-gate id=${c.id} genericWrites=${WriteGate.enabled}")
            return
        }
        val target = VerifiedScalarControls.sanitize(c.id, requested)
        if (target == null || !VerifiedScalarControls.allowed(c.id)) {
            Toast.makeText(this, "ค่านอกช่วง/ID ไม่อยู่ใน verified allow-list", Toast.LENGTH_LONG).show()
            return
        }
        if (!sessionReady || descMode != null || pendingId != null || pendingGattPurpose != null || saveInFlight || waitingAuth) {
            Toast.makeText(this, "V67 session busy/not ready", Toast.LENGTH_LONG).show()
            return
        }
        val displayed = scalarValues[c.id]
        AlertDialog.Builder(this)
            .setTitle("V67 VERIFIED UNIFIED SCALAR WRITE")
            .setMessage("${c.name} • ID=${c.id}\nDisplayed=${displayed?.let { fmt(it) } ?: "?"} → requested=${fmt(target)} ${c.unit}\n\nก่อนเขียน V67 จะอ่าน fresh Device Description ทั้งชุดใน session เดิม แล้วใช้ค่าจริงสดเป็น exact rollback baseline. จากนั้น WRITE 0x57 → require GATT success → fresh full-descriptor verify. ถ้า verify ไม่ผ่านจะคืน exact baseline และ fresh-verify การคืนค่า.\n\nไม่มี auto-save; Permanent Save ต้องกดแยกหลัง verify ผ่านเท่านั้น.")
            .setNegativeButton("ยกเลิก", null)
            .setPositiveButton("FRESH PREFLIGHT + APPLY") { _, _ -> beginScalarPreflight(c, target) }
            .show()
    }

    private fun beginScalarPreflight(c: VerifiedScalarControl, target: Float) {
        if (!sessionReady || pendingId != null || descMode != null || pendingGattPurpose != null || saveInFlight) return
        pendingId = c.id
        pendingTarget = target
        pendingOriginal = null
        status.text = "V67 FRESH PREFLIGHT • ${c.name} ID${c.id} • reading 7 + 105 + 4 before write"
        record("META", "V67_UNIFIED_SCALAR_PREFLIGHT_START id=${c.id} name=${c.name} requestedTarget=$target sameSession=true genericWrites=false")
        renderScalars()
        requestDescriptor(DescMode.WRITE_PREFLIGHT)
    }

    private fun sendScalarTargetAfterPreflight() {
        val id = pendingId ?: return
        val target = pendingTarget ?: return
        val original = pendingOriginal ?: return
        val c = VerifiedScalarControls.byId(id) ?: run { clearPending("id-not-allowed"); return }
        val g = gatt ?: return
        val w = ab01 ?: return
        val tx = txCipher ?: return
        if (!sessionReady || !VerifiedScalarControls.allowed(id) || pendingGattPurpose != null || descMode != null) {
            clearPending("target-send-guard-failed")
            return
        }
        val plain = UfeCodec.encodeFloat32Write(id, target)
        val enc = tx.encryptNext(plain)
        pendingGattPurpose = PendingGattPurpose.SCALAR_TARGET
        record("META", "V67_UNIFIED_SCALAR_WRITE_PLAIN=${ByteCodec.run { plain.toHex() }} id=$id name=${c.name} freshOriginal=$original target=$target saveParams=false genericWrites=false")
        if (!writeNoResponse(g, w, enc, "TX_SCALAR_WRITE_V67_UNIFIED_ID$id", PendingGattPurpose.SCALAR_TARGET)) {
            pendingGattPurpose = null
            restorePending("target-write-queue-failed")
            return
        }
        status.text = "V67 WRITE queued • waiting required GATT success before fresh verify"
        armGattActionTimeout(PendingGattPurpose.SCALAR_TARGET)
    }

    private fun restorePending(reason: String) {
        val id = pendingId ?: return
        val original = pendingOriginal ?: run {
            status.text = "V67 rollback impossible • fresh baseline missing • STOP"
            sessionReady = false
            clearPending("rollback-baseline-missing")
            return
        }
        val g = gatt ?: return
        val w = ab01 ?: return
        val tx = txCipher ?: return
        if (!VerifiedScalarControls.allowed(id)) { clearPending("restore-id-not-allowed"); return }
        if (descMode != null) {
            record("META", "V67_UNIFIED_RESTORE_DEFER_BLOCKED reason=descriptor-busy mode=$descMode")
            sessionReady = false
            clearPending("restore-descriptor-busy")
            return
        }
        val plain = UfeCodec.encodeFloat32Write(id, original)
        val enc = tx.encryptNext(plain)
        pendingGattPurpose = PendingGattPurpose.SCALAR_RESTORE
        record("META", "V67_UNIFIED_FAILSAFE_RESTORE_PLAIN=${ByteCodec.run { plain.toHex() }} id=$id exactFreshBaseline=$original reason=$reason saveParams=false")
        if (!writeNoResponse(g, w, enc, "TX_SCALAR_RESTORE_V67_UNIFIED_ID$id", PendingGattPurpose.SCALAR_RESTORE)) {
            pendingGattPurpose = null
            sessionReady = false
            status.text = "RESTORE WRITE QUEUE FAILED — STOP • DO NOT SAVE • export capture"
            clearPending("restore-queue-failed")
            return
        }
        status.text = "V67 FAILSAFE RESTORE queued • waiting required GATT success"
        armGattActionTimeout(PendingGattPurpose.SCALAR_RESTORE)
    }

    private fun armGattActionTimeout(purpose: PendingGattPurpose) {
        cancelGattActionTimeout()
        gattActionTimeout = Runnable {
            if (pendingGattPurpose != purpose) return@Runnable
            pendingGattPurpose = null
            record("META", "V67_UNIFIED_GATT_RESULT_TIMEOUT purpose=$purpose id=${pendingId ?: -1}")
            when (purpose) {
                PendingGattPurpose.SCALAR_TARGET -> restorePending("target-gatt-unconfirmed")
                PendingGattPurpose.SCALAR_RESTORE -> {
                    sessionReady = false
                    status.text = "RESTORE GATT UNCONFIRMED — STOP • DO NOT SAVE • export capture"
                    clearPending("restore-gatt-unconfirmed")
                }
                PendingGattPurpose.SAVE_PARAMS -> markSaveUnconfirmed("save-gatt-timeout")
            }
        }.also { handler.postDelayed(it, 3000L) }
    }

    private fun cancelGattActionTimeout() {
        gattActionTimeout?.let { handler.removeCallbacks(it) }
        gattActionTimeout = null
    }

    private fun clearPending(reason: String, recordEvent: Boolean = true) {
        if (recordEvent) record("META", "V67_UNIFIED_PENDING_CLEAR reason=$reason id=${pendingId ?: -1}")
        pendingId = null
        pendingTarget = null
        pendingOriginal = null
        cancelGattActionTimeout()
        pendingGattPurpose = null
        if (Looper.myLooper() == Looper.getMainLooper()) renderScalars() else handler.post { renderScalars() }
    }

    private fun confirmPermanentSave() {
        if (!WriteGate.verifiedScalarPersistentSaveEnabled || !WriteGate.unifiedVerifiedScalarWritesEnabled) {
            Toast.makeText(this, "V67 permanent-save gate disabled", Toast.LENGTH_LONG).show(); return
        }
        if (!sessionReady || gatt == null || ab01 == null || txCipher == null || waitingAuth) {
            Toast.makeText(this, "เชื่อม DSP และ START V67 session ก่อน", Toast.LENGTH_LONG).show(); return
        }
        if (saveInFlight || pendingId != null || descMode != null || pendingGattPurpose != null) {
            Toast.makeText(this, "Protocol busy • รอ write/verify/refresh ให้จบก่อน SAVE", Toast.LENGTH_LONG).show(); return
        }
        if (!unsavedVerifiedChanges || verifiedChangeCount <= 0) {
            Toast.makeText(this, "ยังไม่มี verified scalar change ใน V67 session นี้ • SaveParams locked", Toast.LENGTH_LONG).show(); return
        }
        if (!SaveParamsPolicy.triggerIsExact()) {
            record("META", "V67_UNIFIED_SAVEPARAMS_BLOCKED reason=trigger-not-exact")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("V67 PERMANENT SAVE • MANUAL GUARDED")
            .setMessage("Verified scalar changes in this session = $verifiedChangeCount\n\nจะส่ง SaveParams ID7 exact plaintext 570000000700000000 ซึ่ง V57 พิสูจน์ persistence ผ่าน power-cycle แล้ว. SaveParams บันทึก turning parameters ปัจจุบันทั้งชุด รวม EQ ปัจจุบันด้วย.\n\nตรวจ final state ให้ถูกต้องและห้ามปิด DSP ระหว่าง commit 5 วินาที.")
            .setNegativeButton("ยกเลิก", null)
            .setPositiveButton("SAVE PERMANENTLY") { _, _ -> sendPermanentSave() }
            .show()
    }

    private fun sendPermanentSave() {
        val g = gatt ?: return
        val w = ab01 ?: return
        val tx = txCipher ?: return
        if (!sessionReady || saveInFlight || pendingId != null || descMode != null || pendingGattPurpose != null || waitingAuth || !unsavedVerifiedChanges || verifiedChangeCount <= 0) {
            record("META", "V67_UNIFIED_SAVEPARAMS_BLOCKED reason=guard-race")
            return
        }
        val plain = SaveParamsPolicy.encodeTrigger()
        if (ByteCodec.run { plain.toHex() } != "570000000700000000") {
            record("META", "V67_UNIFIED_SAVEPARAMS_BLOCKED reason=unexpected-trigger plain=${ByteCodec.run { plain.toHex() }}")
            return
        }
        saveInFlight = true
        saveGattOk = false
        pendingGattPurpose = PendingGattPurpose.SAVE_PARAMS
        val enc = tx.encryptNext(plain)
        record("META", "V67_UNIFIED_SAVEPARAMS_TRIGGER_PLAIN=${ByteCodec.run { plain.toHex() }} actuator=7 offset=0 length=0 verifiedScalarChanges=$verifiedChangeCount manualGuarded=true")
        if (!writeNoResponse(g, w, enc, "TX_SAVEPARAMS_ID7_V67_UNIFIED", PendingGattPurpose.SAVE_PARAMS)) {
            pendingGattPurpose = null
            saveInFlight = false
            status.text = "V67 SAVE queue failed • changes remain RAM DIRTY"
            updateDirtyUi()
            return
        }
        status.text = "V67 SaveParams queued • waiting required GATT success"
        armGattActionTimeout(PendingGattPurpose.SAVE_PARAMS)
        updateDirtyUi()
    }

    private fun beginSaveSettle() {
        cancelSaveSettle()
        saveSettleRunnable = Runnable {
            if (!saveInFlight || !saveGattOk) return@Runnable
            val savedCount = verifiedChangeCount
            unsavedVerifiedChanges = false
            verifiedChangeCount = 0
            saveInFlight = false
            saveGattOk = false
            record("META", "V67_UNIFIED_PERSISTENT_SAVE_COMPLETE savedVerifiedScalarChanges=$savedCount trigger=570000000700000000 gattStatus=0 settleMs=$saveCommitSettleMs persistenceBasis=V57_TWO_POWER_CYCLE_PROOF")
            status.text = "V67 PERMANENT SAVE COMPLETE • safe after verified 5s settle"
            renderScalars()
        }.also { handler.postDelayed(it, saveCommitSettleMs) }
    }

    private fun markSaveUnconfirmed(reason: String) {
        cancelSaveTimers()
        pendingGattPurpose = null
        saveInFlight = false
        saveGattOk = false
        record("META", "V67_UNIFIED_PERSISTENT_SAVE_UNCONFIRMED reason=$reason changesRemainUnsaved=true")
        status.text = "V67 SAVE UNCONFIRMED • DO NOT RETRY BLINDLY • export capture • RAM DIRTY retained"
        updateDirtyUi()
    }

    private fun cancelSaveSettle() {
        saveSettleRunnable?.let { handler.removeCallbacks(it) }
        saveSettleRunnable = null
    }

    private fun cancelSaveTimers() {
        cancelSaveSettle()
    }

    private fun renderSensors() {
        if (!::sensorHost.isInitialized) return
        sensorHost.removeAllViews()
        if (sensors.isEmpty()) {
            sensorHost.addView(TextView(this).apply { text = "ยังไม่ได้โหลด sensor จาก Device Description"; textSize = 14f })
            return
        }
        sensors.forEach { s ->
            sensorHost.addView(TextView(this).apply {
                text = "${s.name} • ID ${s.id} • ${s.valueText} • READ ONLY"
                textSize = 15f
                setPadding(0, 4, 0, 4)
            })
        }
    }

    private fun renderEq() {
        if (!::eqHost.isInitialized) return
        eqHost.removeAllViews()
        val ch = selectedChannel
        eqHost.addView(TextView(this).apply {
            text = "CH$ch • Actuator ID ${LiveEqPolicy.actuatorForChannel(ch)}"
            textSize = 17f
            setPadding(0, 8, 0, 6)
        })
        if (!sessionReady && bands[ch - 1].all { it == null }) {
            eqHost.addView(TextView(this).apply { text = "START V67 unified session เพื่อโหลด EQ จริง"; textSize = 14f })
            return
        }
        for (band1 in 1..15) {
            val b = bands[ch - 1][band1 - 1]
            eqHost.addView(TextView(this).apply {
                text = if (b == null) {
                    "Band $band1 • MISSING"
                } else {
                    val safe = if (LiveEqPolicy.isWritable(b)) "SAFE-PEAKING" else "READ-ONLY-SHAPE"
                    "Band $band1 • typ=${b.type} • F=${fmt(b.frequency)}Hz • Q=${fmt(b.q)} • B=${fmt(b.boostDb)}dB • $safe • V67 EQ READ ONLY"
                }
                textSize = 13f
                setPadding(0, 3, 0, 3)
            })
        }
    }

    private fun extractBand(obj: JSONObject, actuatorId: Int, bandIndex1: Int): EqBand48? {
        val arr = obj.optJSONArray("actuators") ?: return null
        for (i in 0 until arr.length()) {
            val a = arr.optJSONObject(i) ?: continue
            if (a.optInt("ID", -1) != actuatorId || a.optInt("type", -1) != 4084) continue
            val bandArr = a.optJSONArray("UFE_TYPE_BIQUAD_CASCADE15_F") ?: return null
            val b = bandArr.optJSONObject(bandIndex1 - 1) ?: return null
            fun f(key: String): Float = b.optDouble(key, Double.NaN).toFloat()
            val out = EqBand48(
                type = b.optInt("typ", -1),
                frequency = f("F"), frequency2 = f("F2"), q = f("Q"), boostDb = f("B"),
                gain = f("G"), r = f("R"), b0 = f("B0"), b1 = f("B1"), b2 = f("B2"),
                a1 = f("A1"), a2 = f("A2")
            )
            if (listOf(out.frequency, out.frequency2, out.q, out.boostDb, out.gain, out.r, out.b0, out.b1, out.b2, out.a1, out.a2).any { !it.isFinite() }) return null
            return out
        }
        return null
    }

    private fun startScan() {
        if (saveInFlight || pendingId != null || descMode != null || pendingGattPurpose != null) {
            Toast.makeText(this, "V67 protocol busy • ห้ามเปลี่ยน connection", Toast.LENGTH_LONG).show(); return
        }
        if (!hasBlePermission()) { requestBlePermissions(); return }
        val adapter = getSystemService(BluetoothManager::class.java)?.adapter ?: return
        if (!adapter.isEnabled) { Toast.makeText(this, "เปิด Bluetooth ก่อน", Toast.LENGTH_SHORT).show(); return }
        found.clear(); deviceList.removeAllViews()
        scanner = adapter.bluetoothLeScanner
        status.text = "SCANNING"
        try { scanner?.startScan(scanCallback) } catch (_: SecurityException) { return }
        handler.postDelayed({ try { scanner?.stopScan(scanCallback) } catch (_: Exception) {} }, 10000L)
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val d = result.device
            val name = result.scanRecord?.deviceName ?: try { d.name } catch (_: SecurityException) { null }
            if (name?.contains("GOLOPINE", true) != true && name?.contains("DSP", true) != true) return
            if (found.putIfAbsent(d.address, d) != null) return
            runOnUiThread {
                deviceList.addView(Button(this@UnifiedControlActivity).apply {
                    text = "${name ?: "DSP"} • ${d.address}\nแตะเพื่อเชื่อมต่อ"
                    setOnClickListener { connect(d, name ?: "DSP") }
                })
            }
        }
    }

    private fun connect(device: BluetoothDevice, name: String) {
        if (saveInFlight || pendingId != null || descMode != null || pendingGattPurpose != null) {
            Toast.makeText(this, "V67 protocol busy • ห้ามเปลี่ยน connection", Toast.LENGTH_LONG).show(); return
        }
        if (!hasBlePermission()) return
        try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
        try { gatt?.close() } catch (_: Exception) {}
        connectedName = name
        status.text = "CONNECTING $name"
        record("META", "V67_UNIFIED_CONNECT_START name=$name address=${device.address}")
        try { gatt = device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE) }
        catch (_: SecurityException) { status.text = "CONNECT permission error" }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, statusCode: Int, newState: Int) {
            record("META", "GATT_STATE status=$statusCode newState=$newState")
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                runOnUiThread { status.text = "CONNECTED ${connectedName ?: "DSP"} • discovering" }
                try {
                    g.requestMtu(517)
                    handler.postDelayed({ try { g.discoverServices() } catch (_: SecurityException) {} }, 250L)
                } catch (_: SecurityException) {}
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                if (saveInFlight) record("META", "V67_UNIFIED_PERSISTENT_SAVE_UNCONFIRMED reason=disconnect-during-save changesRemainUnsaved=true")
                if (pendingId != null) record("META", "V67_UNIFIED_WRITE_STATE_UNCONFIRMED reason=disconnect-during-scalar-pipeline id=${pendingId ?: -1}")
                cancelDescriptorTimeout()
                cancelGattActionTimeout()
                cancelSaveTimers()
                sessionReady = false
                waitingAuth = false
                txCipher = null
                rxCipher = null
                descMode = null
                pendingGattPurpose = null
                synchronized(gattWriteTickets) { gattWriteTickets.clear() }
                saveInFlight = false
                saveGattOk = false
                pendingId = null
                pendingTarget = null
                pendingOriginal = null
                runOnUiThread {
                    status.text = "DISCONNECTED • reconnect + START • inspect capture if write/save was active"
                    startSessionButton.isEnabled = false
                    refreshButton.isEnabled = false
                    refreshButton.text = "REFRESH ALL • SAME SESSION"
                    if (::refreshInfo.isInitialized) refreshInfo.text = "REFRESH STATUS • DISCONNECTED • reconnect + START"
                    renderAll()
                }
            }
        }

        override fun onMtuChanged(g: BluetoothGatt, mtu: Int, statusCode: Int) {
            record("META", "MTU_CHANGED mtu=$mtu status=$statusCode")
        }

        override fun onServicesDiscovered(g: BluetoothGatt, statusCode: Int) {
            val service = g.getService(BleProfile.AB00_SERVICE)
            ab01 = service?.getCharacteristic(BleProfile.AB01_WRITE)
            ab02 = service?.getCharacteristic(BleProfile.AB02_NOTIFY)
            val ok = statusCode == BluetoothGatt.GATT_SUCCESS && ab01 != null && ab02 != null
            record("META", "SERVICES_DISCOVERED status=$statusCode AB01=${ab01 != null} AB02=${ab02 != null}")
            if (!ok) { runOnUiThread { status.text = "AB00/AB01/AB02 profile not found" }; return }
            subscribeAb02(g, ab02!!)
            runOnUiThread { status.text = "CONNECTED • enabling AB02 notifications"; startSessionButton.isEnabled = false }
        }

        override fun onDescriptorWrite(g: BluetoothGatt, descriptor: BluetoothGattDescriptor, statusCode: Int) {
            record("META", "CCCD_WRITE status=$statusCode")
            runOnUiThread {
                if (statusCode == BluetoothGatt.GATT_SUCCESS) {
                    status.text = "CONNECTED • AB02 notifications READY"
                    startSessionButton.isEnabled = true
                } else {
                    status.text = "CCCD notification enable failed: $statusCode"
                    startSessionButton.isEnabled = false
                }
            }
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, statusCode: Int) {
            val ticket = synchronized(gattWriteTickets) { if (gattWriteTickets.isEmpty()) null else gattWriteTickets.removeFirst() }
            record("META", "TX_WRITE_RESULT status=$statusCode uuid=${characteristic.uuid} ticket=${ticket ?: "NONE"}")
            if (characteristic.uuid != BleProfile.AB01_WRITE || ticket == null || ticket == GattWriteKind.OTHER) return
            val purpose = when (ticket) {
                GattWriteKind.SCALAR_TARGET -> PendingGattPurpose.SCALAR_TARGET
                GattWriteKind.SCALAR_RESTORE -> PendingGattPurpose.SCALAR_RESTORE
                GattWriteKind.SAVE_PARAMS -> PendingGattPurpose.SAVE_PARAMS
                GattWriteKind.OTHER -> return
            }
            if (pendingGattPurpose != purpose) {
                record("META", "V67_UNIFIED_GATT_TICKET_MISMATCH ticket=$ticket pending=${pendingGattPurpose ?: "NONE"} status=$statusCode")
                return
            }
            cancelGattActionTimeout()
            pendingGattPurpose = null
            val ok = statusCode == BluetoothGatt.GATT_SUCCESS
            record("META", "V67_UNIFIED_GATT_RESULT purpose=$purpose ticket=$ticket status=$statusCode ok=$ok id=${pendingId ?: -1}")
            handler.post {
                when (purpose) {
                    PendingGattPurpose.SCALAR_TARGET -> {
                        if (ok) {
                            status.text = "V67 target GATT success • requesting fresh full descriptor verify"
                            handler.postDelayed({ requestDescriptor(DescMode.VERIFY_TARGET) }, 350L)
                        } else restorePending("target-gatt-failed-$statusCode")
                    }
                    PendingGattPurpose.SCALAR_RESTORE -> {
                        if (ok) {
                            status.text = "V67 restore GATT success • requesting fresh restore verify"
                            handler.postDelayed({ requestDescriptor(DescMode.VERIFY_RESTORE) }, 350L)
                        } else {
                            sessionReady = false
                            status.text = "RESTORE GATT FAILED — STOP • DO NOT SAVE • export capture"
                            clearPending("restore-gatt-failed-$statusCode")
                        }
                    }
                    PendingGattPurpose.SAVE_PARAMS -> {
                        if (ok) {
                            saveGattOk = true
                            record("META", "V67_UNIFIED_SAVEPARAMS_GATT_SUCCESS settleMs=$saveCommitSettleMs")
                            status.text = "V67 SaveParams GATT success • DO NOT POWER OFF • settling 5s"
                            beginSaveSettle()
                        } else markSaveUnconfirmed("save-gatt-failed-$statusCode")
                    }
                }
                renderScalars()
            }
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            if (characteristic.uuid == BleProfile.AB02_NOTIFY) handleAb02(value)
        }

        @Suppress("DEPRECATION")
        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            if (android.os.Build.VERSION.SDK_INT < 33 && characteristic.uuid == BleProfile.AB02_NOTIFY) handleAb02(characteristic.value ?: byteArrayOf())
        }
    }

    private fun subscribeAb02(g: BluetoothGatt, ch: BluetoothGattCharacteristic) {
        if (!hasBlePermission()) return
        try {
            g.setCharacteristicNotification(ch, true)
            val cccd = ch.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")) ?: return
            val v = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            if (android.os.Build.VERSION.SDK_INT >= 33) g.writeDescriptor(cccd, v)
            else {
                @Suppress("DEPRECATION") cccd.value = v
                @Suppress("DEPRECATION") g.writeDescriptor(cccd)
            }
        } catch (e: Exception) {
            record("META", "V67_UNIFIED_SUBSCRIBE_ERROR ${e.javaClass.simpleName}:${e.message}")
        }
    }

    private fun writeNoResponse(
        g: BluetoothGatt,
        ch: BluetoothGattCharacteristic,
        bytes: ByteArray,
        label: String,
        purpose: PendingGattPurpose? = null,
    ): Boolean {
        if (!hasBlePermission()) return false
        record("TX", "$label len=${bytes.size} hex=${ByteCodec.run { bytes.toHex() }}")
        val queued = try {
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                g.writeCharacteristic(ch, bytes, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE) == BluetoothStatusCodes.SUCCESS
            } else {
                @Suppress("DEPRECATION") ch.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                @Suppress("DEPRECATION") ch.value = bytes
                @Suppress("DEPRECATION") g.writeCharacteristic(ch)
            }
        } catch (e: Exception) {
            record("META", "$label ERROR ${e.javaClass.simpleName}:${e.message}")
            false
        }
        if (queued) {
            val kind = when (purpose) {
                PendingGattPurpose.SCALAR_TARGET -> GattWriteKind.SCALAR_TARGET
                PendingGattPurpose.SCALAR_RESTORE -> GattWriteKind.SCALAR_RESTORE
                PendingGattPurpose.SAVE_PARAMS -> GattWriteKind.SAVE_PARAMS
                null -> GattWriteKind.OTHER
            }
            synchronized(gattWriteTickets) { gattWriteTickets.addLast(kind) }
            record("META", "V67_UNIFIED_GATT_TICKET_QUEUED label=$label kind=$kind depth=${synchronized(gattWriteTickets) { gattWriteTickets.size }}")
        }
        return queued
    }

    private fun record(kind: String, text: String) {
        val line = "${ts.format(Date())}\t#${++packetNo}\t$kind\t$text"
        synchronized(captureLines) { captureLines.add(line) }
        if (::logView.isInitialized) runOnUiThread { logView.text = (logView.text.toString() + line + "\n").takeLast(16000) }
    }

    private fun saveCapture() {
        val text = buildString {
            append("=== OKN DSP V67 UNIFIED VERIFIED GLOBAL-WRITE MIGRATION CAPTURE ===\n")
            synchronized(captureLines) { captureLines.forEach { append(it).append('\n') } }
        }
        val name = "OKN_DSP_V67_UNIFIED_GLOBAL_WRITE_CAPTURE_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.txt"
        try {
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: error("insert failed")
                contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) }
                Toast.makeText(this, "Saved Downloads/$name", Toast.LENGTH_LONG).show()
            } else {
                val f = java.io.File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), name)
                f.writeText(text)
                Toast.makeText(this, "Saved ${f.absolutePath}", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Save failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun requestBlePermissions() {
        val perms = if (android.os.Build.VERSION.SDK_INT >= 31) {
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        } else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (perms.any { ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }) {
            ActivityCompat.requestPermissions(this, perms, 1065)
        }
    }

    private fun hasBlePermission(): Boolean = if (android.os.Build.VERSION.SDK_INT >= 31) {
        ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
    } else ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun fmt(v: Float): String = String.format(Locale.US, "%.3f", v)
}
