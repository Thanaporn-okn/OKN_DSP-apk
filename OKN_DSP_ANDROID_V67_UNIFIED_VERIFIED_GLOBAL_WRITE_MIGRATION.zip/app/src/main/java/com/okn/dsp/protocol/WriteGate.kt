package com.okn.dsp.protocol

/**
 * V67 gate. Generic writes stay disabled. Verified scalar controls remain enabled, including ID3 after the V63 guarded proof.
 * V49/V50 runtime-proved the full 7CH EQ actuator map. V62 keeps the
 * guarded live PEAKING-band editor: one band write at a time, descriptor verify,
 * automatic rollback on verify failure, and explicit persistent SAVE using the V57-proven SaveParams ID7 trigger.
 * ID3 RemindSoundVolume is now in the production scalar allow-list based on the successful V63 guarded proof; the dedicated proof gate remains only for archived evidence use.
 * Presets, delay and unknown writes remain blocked.
 */
object WriteGate {
    const val enabled: Boolean = false
    const val controlledMasterVolumeProofEnabled: Boolean = true
    const val verifiedScalarControlsEnabled: Boolean = true
    const val unifiedVerifiedScalarWritesEnabled: Boolean = true
    const val controlledEqBandProofEnabled: Boolean = false
    const val eqBandRecoveryEnabled: Boolean = false
    const val finalEqWriteRestoreProofEnabled: Boolean = false
    const val sevenChannelEqMapProofEnabled: Boolean = true
    const val liveEqEditorEnabled: Boolean = true
    const val saveParamsPersistenceProofEnabled: Boolean = true
    const val liveEqPersistentSaveEnabled: Boolean = true
    const val verifiedScalarPersistentSaveEnabled: Boolean = true
    const val remindSoundVolumeProofEnabled: Boolean = true
}
