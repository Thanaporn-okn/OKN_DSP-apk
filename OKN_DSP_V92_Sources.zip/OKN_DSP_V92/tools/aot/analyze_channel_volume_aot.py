#!/usr/bin/env python3
"""Extract high-signal evidence from Blutter output for OKN_DSP V92.

This tool is evidence-only. It never writes to the DSP and never invents an actuator map.
"""
from __future__ import annotations
import argparse
import hashlib
import os
import re
from pathlib import Path

HIGH = [
    r"WriteActuatorPeriperalCommand",
    r"ReadActuatorPeriperalCommand",
    r"SensorActuatorDataBinaryConverter",
    r"DSPAmplifierConfig",
    r"Create(?:SigmaDSPfiltr|Filter)UpdateCommand",
    r"SpeakerEQAddresses",
    r"SpeakerDRCAddresses",
    r"MasterEQ(?:left|right)Address",
    r"BassDRCprocessorAddress",
    r"ReverbProcessorAddress",
]
CONTROL = [
    r"(?i)channel.{0,40}(?:volume|gain|level|output)",
    r"(?i)(?:volume|gain|level|output).{0,40}channel",
    r"(?i)speaker.{0,40}(?:volume|gain|level|output)",
    r"(?i)(?:volume|gain|level|output).{0,40}speaker",
    r"(?i)output.{0,24}gain",
    r"(?i)output.{0,24}volume",
    r"(?i)attenuat",
    r"(?i)mixer",
]
GENERIC = [
    r"(?i)volume",
    r"(?i)gain",
    r"(?i)output",
    r"(?i)channel",
    r"(?i)speaker",
    r"UFE_TYPE_FLOAT32",
    r"UFE_WRITE_ACTUATOR_COMMAND",
]
TEXT_SUFFIXES = {".txt", ".asm", ".s", ".dart", ".json", ".log", ".c", ".cc", ".cpp", ".h"}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def likely_text(path: Path) -> bool:
    if path.suffix.lower() in TEXT_SUFFIXES:
        return True
    return path.name in {"pp.txt", "objs.txt"}


def iter_text_files(root: Path):
    if not root.exists():
        return
    for p in sorted(root.rglob("*")):
        if p.is_file() and likely_text(p):
            try:
                if p.stat().st_size <= 150 * 1024 * 1024:
                    yield p
            except OSError:
                continue


def read_lines(path: Path):
    try:
        return path.read_text(errors="replace").splitlines()
    except Exception:
        return []


def compile_many(patterns):
    return [re.compile(p) for p in patterns]


def collect(root: Path, patterns, context=3, cap=250):
    regs = compile_many(patterns)
    out = []
    seen = set()
    for path in iter_text_files(root):
        lines = read_lines(path)
        for i, line in enumerate(lines):
            if any(r.search(line) for r in regs):
                a = max(0, i - context); b = min(len(lines), i + context + 1)
                key = (str(path), i)
                if key in seen:
                    continue
                seen.add(key)
                out.append((path, i + 1, lines[a:b], a + 1))
                if len(out) >= cap:
                    return out
    return out


def file_score(path: Path, text: str) -> tuple[int, list[str]]:
    terms = {
        "WriteActuator": r"WriteActuatorPeriperalCommand",
        "ReadActuator": r"ReadActuatorPeriperalCommand",
        "DSPConfig": r"DSPAmplifierConfig",
        "SpeakerAddress": r"Speaker(?:EQ|DRC)Addresses",
        "ChannelControl": r"(?i)channel.{0,50}(?:volume|gain|level|output)|(?:volume|gain|level|output).{0,50}channel",
        "SpeakerControl": r"(?i)speaker.{0,50}(?:volume|gain|level|output)|(?:volume|gain|level|output).{0,50}speaker",
        "OutputGain": r"(?i)output.{0,30}(?:gain|volume)|(?:gain|volume).{0,30}output",
        "Mixer": r"(?i)mixer",
    }
    hit = [name for name, pat in terms.items() if re.search(pat, text)]
    weights = {"WriteActuator": 6, "ReadActuator": 3, "DSPConfig": 4, "SpeakerAddress": 5,
               "ChannelControl": 7, "SpeakerControl": 7, "OutputGain": 8, "Mixer": 3}
    return sum(weights[x] for x in hit), hit


def write_hits(f, title, hits, root: Path):
    f.write(f"\n=== {title} ({len(hits)} hits, capped) ===\n")
    if not hits:
        f.write("NO HITS\n")
        return
    for path, line_no, block, block_start in hits:
        try: rel = path.relative_to(root)
        except Exception: rel = path
        f.write(f"\n--- {rel}:{line_no} ---\n")
        for off, line in enumerate(block):
            f.write(f"{block_start + off:8d}: {line}\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True, help="Blutter output directory")
    ap.add_argument("--target", required=True, help="Directory with extracted APK libs/logs")
    ap.add_argument("--out", required=True, help="Evidence output directory")
    args = ap.parse_args()
    root = Path(args.root).resolve()
    target = Path(args.target).resolve()
    out = Path(args.out).resolve(); out.mkdir(parents=True, exist_ok=True)

    report = out / "OKN_DSP_V92_CHANNEL_VOLUME_AOT_REPORT.txt"
    high_hits = collect(root, HIGH, context=5, cap=300)
    control_hits = collect(root, CONTROL, context=6, cap=350)
    generic_hits = collect(root, GENERIC, context=2, cap=250)

    ranked = []
    for p in iter_text_files(root):
        try:
            text = p.read_text(errors="replace")
        except Exception:
            continue
        score, tags = file_score(p, text)
        if score:
            ranked.append((score, str(p), tags))
    ranked.sort(key=lambda x: (-x[0], x[1]))

    with report.open("w", encoding="utf-8") as f:
        f.write("OKN DSP V92 — CHANNEL OUTPUT VOLUME AOT DISCOVERY REPORT\n")
        f.write("=========================================================\n")
        f.write("POLICY: evidence-only; no DSP write is generated by this analyzer.\n")
        f.write("Unlock requires exact CH1-CH7 hardware path + independent readback/capture proof.\n\n")
        f.write(f"blutter_root={root}\n")
        f.write(f"target={target}\n")
        for name in ("libapp.so", "libflutter.so"):
            p = target / name
            if p.exists(): f.write(f"{name}_sha256={sha256(p)}\n")
        rt = target / "dart_runtime.txt"
        if rt.exists(): f.write("dart_runtime=" + rt.read_text(errors="replace").strip().replace("\n", " | ") + "\n")
        log = target / "blutter_run.log"
        if log.exists():
            f.write("blutter_log_sha256=" + sha256(log) + "\n")
        f.write("\n=== RANKED CANDIDATE FILES ===\n")
        if ranked:
            for score, path, tags in ranked[:100]:
                try: rel = Path(path).relative_to(root)
                except Exception: rel = path
                f.write(f"score={score:02d}\t{rel}\t{','.join(tags)}\n")
        else:
            f.write("NO RANKED CANDIDATE FILES\n")
        write_hits(f, "HIGH-SIGNAL PROTOCOL / DSP CONFIG", high_hits, root)
        write_hits(f, "CHANNEL / OUTPUT CONTROL CANDIDATES", control_hits, root)
        write_hits(f, "GENERIC CONTROL TERMS", generic_hits, root)
        f.write("\n=== INTERPRETATION GATE ===\n")
        if control_hits:
            f.write("Candidate control call-sites were found. They are NOT automatically a verified output-volume map.\n")
            f.write("Next proof must associate exact actuator/address/offset/value changes with CH1..CH7 on target hardware.\n")
        else:
            f.write("No high-signal Channel/Output Volume/Gain call-site was recovered from these text outputs.\n")
            f.write("This is evidence that more dynamic/capture work is required, not permission to guess a DSP write.\n")

    # Compact TSV for machine comparison on later runs.
    tsv = out / "OKN_DSP_V92_AOT_CANDIDATES.tsv"
    with tsv.open("w", encoding="utf-8") as f:
        f.write("score\tfile\ttags\n")
        for score, path, tags in ranked:
            try: rel = Path(path).relative_to(root)
            except Exception: rel = path
            f.write(f"{score}\t{rel}\t{','.join(tags)}\n")

    print(report)
    print(f"high_signal_hits={len(high_hits)} control_hits={len(control_hits)} generic_hits={len(generic_hits)} ranked_files={len(ranked)}")

if __name__ == "__main__":
    main()
