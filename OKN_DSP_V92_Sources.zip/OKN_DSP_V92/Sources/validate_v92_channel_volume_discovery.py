#!/usr/bin/env python3
from pathlib import Path
import hashlib, re, sys

ROOT = Path(__file__).resolve().parents[1]
BLE = ROOT / 'app/src/main/java/com/okn/dsp/BleManager.java'
DSP = ROOT / 'app/src/main/java/com/okn/dsp/DspProtocol.java'
VIEW = ROOT / 'app/src/main/java/com/okn/dsp/DspView.java'
GRADLE = ROOT / 'app/build.gradle'
ble = BLE.read_text()
dsp = DSP.read_text()
view = VIEW.read_text()
gradle = GRADLE.read_text()

def method(text, marker):
    i = text.index(marker); b = text.index('{', i); depth = 0
    for j in range(b, len(text)):
        if text[j] == '{': depth += 1
        elif text[j] == '}':
            depth -= 1
            if depth == 0: return text[i:j+1]
    raise AssertionError('unclosed method ' + marker)

def sha(s): return hashlib.sha256(s.encode()).hexdigest()

def req(cond, msg):
    if not cond: raise AssertionError(msg)

req("versionCode 1092" in gradle and "versionName '92.0.0'" in gradle, 'V92 version mismatch')
req('static final int ID_SAVE_PARAMS = 7;' in dsp, 'ID7 missing')
trigger = method(dsp, '    static byte[] encodeSaveParamsTrigger(')
req('encodeWrite(ID_SAVE_PARAMS, 0, new byte[0])' in trigger, 'SaveParams must be zero-payload verified UFE write')
req('void requestPersistentSave()' in ble, 'manual save entry point missing')
req('startDescriptorRequest("SAVE_PRECHECK")' in ble, 'fresh save precheck missing')
req('startDescriptorRequest("SAVE_POSTCHECK")' in ble, 'fresh save postcheck missing')
req('safePeakingRows == EXPECTED_SAFE_PEAKING_ROWS' in ble, '55-row gate missing')
req('scalarValues.size() == DspProtocol.VERIFIED_SCALARS.length' in ble, '7/7 scalar gate missing')
req('boolean eqOk = eqCount == 105;' in ble, '105/105 EQ gate missing')
req('boolean sensorOk = sensorCount >= 4;' in ble, 'sensor >=4 gate missing')
req('SAVE UNCONFIRMED' in ble and 'DO NOT RETRY automatically' in ble, 'save failure warning missing')
req('realtimeQueuesIdleForSave()' in ble and 'writeTickets.isEmpty()' in ble, 'idle GATT/realtime gate missing')
req('requestVerifiedRestore()' in ble and 'startDescriptorRequest("RESTORE")' in ble, 'readback-only Restore missing')
req('listener.onDspSyncComplete(syncSource, scalarCount, publishedEqCount, safeCount)' in ble, 'V40 sync-complete ordering missing')
req('state.setMasterVolume(value);' in view and 'state.setBassVolume(value);' in view and 'state.setBassCutoff(value);' in view, 'V40 scalar readback setters missing')
req('state.setEqFreq(channel0, band0, frequency);' in view and 'state.setEqQ(channel0, band0, q);' in view and 'state.setEqGain(channel0, band0, gainDb);' in view, 'V40 EQ readback setters missing')
req('state.flushPending(false);' in view, 'V40 synchronized checkpoint missing')
req('themePickerOpen || presetPickerOpen || deletePresetOpen || saveConfirmOpen' in view, 'same-Canvas save modal touch isolation missing')
req('saveConfirmOpen' in view and 'Save once' in view and 'requestPersistentSave()' in view, 'manual same-Canvas save confirmation missing')
# V40 authoritative readback callbacks must remain local-only and never echo hardware writes.
for marker in ('    void setScalarFromDsp(', '    void setEqFromDsp('):
    body = method(view, marker)
    req(all(x not in body for x in ('sendVerified', 'setScalarRealtime', 'setEqRealtime', 'setEqShapeRealtime')), marker.strip() + ' echoes a hardware write')

# Save entry must only be called from the explicit confirmation path in DspView.
req(view.count('requestPersistentSave()') == 1, 'unexpected automatic/UI duplicate SaveParams caller')
req(ble.count('sendSaveParamsOnce()') == 2, 'SaveParams send helper must have one definition and one guarded call')
req('DspProtocol.encodeSaveParamsTrigger()' in ble, 'SaveParams serializer not used')

expected = {
'BleManager.setEqRealtime':'f4f738c886298e476dad58135a5d29b36937aaa7dbf7eabe7853dc8d9e761c9a',
'BleManager.setEqShapeRealtime':'e702693eccb788da71d156db94dc21824f1dacab20d19e1d89aaedceb94a6110',
'BleManager.scheduleEqRealtimePump':'a05ea21d9f11980fff095c6053ec81ccd5c7ba5d7a725ff2854f3f2a87bf6db6',
'BleManager.scheduleEqShapePump':'97a5c9080071ec5bce70999d2c7a122ad2e2a77d494a94f1040fd90662c4e26e',
'BleManager.sendScheduledControl':'8c39c0643084615777997900f428e3c32971bdd5e2afa0d768c04c4dbfedf777',
'BleManager.writeNoResponse':'e6895bee7c3f2d12c2531d7d48346559d6b00a4c227b38ecfc63f2ce2a9d9256',
'BleManager.resetEqSafe':'eab920cc4b25b018c9e263f1a43bf4391569119663db101954a2661803864d18',
'DspProtocol.peakingFromCurrent':'18f6cb0577c711ea817c8441f4b3b2fc91a4a5d5bae0d61051926074858b95ae',
'DspProtocol.peakingShapeFromCurrent':'e3f8d840e116bc3d32bad459db3883867f8afc62a87c8553131397ee133e4e86',
'DspProtocol.firstBandGainFromCurrent':'89f089d8d8bc6bfd54074e35e949fa393719d64d3884fc8ce133b99bc100ddee',
'DspProtocol.encodeEqWrite':'9de90148f2e6f390f9144ffc8f6c029a00ca6276bdeb8696aa319609573001e5',
}
checks = [
('BleManager.setEqRealtime', ble, '    void setEqRealtime('),
('BleManager.setEqShapeRealtime', ble, '    void setEqShapeRealtime('),
('BleManager.scheduleEqRealtimePump', ble, '    private void scheduleEqRealtimePump('),
('BleManager.scheduleEqShapePump', ble, '    private void scheduleEqShapePump('),
('BleManager.sendScheduledControl', ble, '    private void sendScheduledControl('),
('BleManager.writeNoResponse', ble, '    private boolean writeNoResponse('),
('BleManager.resetEqSafe', ble, '    int resetEqSafe('),
('DspProtocol.peakingFromCurrent', dsp, '    static EqBand peakingFromCurrent('),
('DspProtocol.peakingShapeFromCurrent', dsp, '    static EqBand peakingShapeFromCurrent('),
('DspProtocol.firstBandGainFromCurrent', dsp, '    static EqBand firstBandGainFromCurrent('),
('DspProtocol.encodeEqWrite', dsp, '    static byte[] encodeEqWrite('),
]
for name, text, marker in checks:
    body = method(text, marker)
    if name in ('BleManager.setEqRealtime','BleManager.setEqShapeRealtime','BleManager.resetEqSafe'):
        body = body.replace(' || saveActive', '')
    req(sha(body) == expected[name], name + ' changed outside V41 save guard')


# V92 retained UI-only EQ Gain +/- controls must reuse the proven realtime writer and respect readback gating.
req('addHit("eqGainMinus", minus);' in view and 'addHit("eqGainPlus", plus);' in view, 'V92 retained +/- hit targets missing')
req('adjustSelectedEqGain(-0.5f);' in view and 'adjustSelectedEqGain(0.5f);' in view, 'V92 retained +/- 0.5 dB step missing')
req('if (!eqGainWritable[ch][band])' in view, 'V92 retained gainWritable gate missing')
req('if (ble == null || !bleReady)' in view, 'V92 retained BLE READY gate missing')
req('clamp(roundTo(state.eqGain[ch][band] + deltaDb, 0.5f), -12f, 12f)' in view, 'V92 retained gain clamp/step mismatch')
req('sendVerifiedEqGain(ch, band);' in view, 'V92 does not reuse verified EQ Gain writer')
plus_body = method(view, '    private void adjustSelectedEqGain(')
req('requestPersistentSave' not in plus_body and 'SaveParams' not in plus_body, 'V92 retained +/- must not persist or call SaveParams')
req('setChannelVolume' not in plus_body and 'ID_' not in plus_body, 'V92 retained +/- must not invent channel-output/scalar mapping')
req('float hitTop = type == SL_EQ_GAIN ? y - dp(8) : y - dp(18);' in view, 'V92 retained +/- touch isolation missing')

# Existing safe timing and reset semantics remain visible.
req('EQ_REALTIME_MIN_GAP_MS = 45L' in ble, 'Gain 45 ms lane changed')
req('EQ_SHAPE_MIN_GAP_MS = 110L' in ble, 'F/Q 110 ms lane changed')
req('EQ_RESET_MIN_GAP_MS = 110L' in ble, 'Reset 110 ms lane changed')
req('DspProtocol.peakingFromCurrent(current, 0f)' in ble, 'Gain-only reset target changed')


# V92 discovery assets must be authentic and discovery-only.
REF = ROOT / 'tools/reference/golopine_250401.apk'
ANALYZER = ROOT / 'tools/aot/analyze_channel_volume_aot.py'
req(REF.exists(), 'V92 authentic reference APK missing')
req(hashlib.sha256(REF.read_bytes()).hexdigest() == 'b1700436077aa0dcebf3fd8bc509a7a377c2eb9b62c9cb96980a5fe0bbd0fddb', 'V92 reference APK SHA256 mismatch')
req(ANALYZER.exists(), 'V92 AOT analyzer missing')
a = ANALYZER.read_text()
req('WriteActuatorPeriperalCommand' in a and 'CHANNEL OUTPUT VOLUME AOT DISCOVERY REPORT' in a, 'V92 AOT analyzer targets missing')
req('writeNoResponse' not in a and 'encodeWrite(' not in a, 'V92 analyzer must not contain runtime DSP write implementation')
bridge = (ROOT / 'app/src/main/java/com/okn/dsp/protocol/Phase2ProtocolBridge.java').read_text()
req('channelVolumeNotYetMapped' in bridge and 'UnsupportedOperationException' in bridge, 'V92 channel output write must remain fail-closed')


# Every Android Java runtime source must match the V91 baseline manifest bundled with V92.
frozen = ROOT / 'Sources/V92_V91_RUNTIME_FROZEN_HASHES.txt'
req(frozen.exists(), 'V92 V91-runtime frozen hash manifest missing')
for line in frozen.read_text().splitlines():
    if not line.strip():
        continue
    expected_sha, rel = line.split(None, 1)
    rel = rel.strip()
    fp = ROOT / rel
    req(fp.exists(), 'V92 frozen runtime file missing: ' + rel)
    req(hashlib.sha256(fp.read_bytes()).hexdigest() == expected_sha, 'V92 runtime changed from V91 baseline: ' + rel)

print('V92 retained runtime + AOT discovery safety validation: PASS')
print('versionName=92.0.0 versionCode=1092')
print('SaveParams plaintext=570000000700000000')
print('V40 writer/filter frozen hashes: PASS')
