# OKN DSP V92 — Real CH1–CH7 Output Volume Discovery (AOT Evidence Build)

V92 continues from V91 without inventing a per-channel Output Volume write. The Android runtime Java sources are intentionally unchanged from V91; only the app version is bumped.

The new work in V92 is a reproducible reverse-engineering path using the authentic GoloPine 250401 APK. The package includes the exact reference APK (SHA-256 `b1700436077aa0dcebf3fd8bc509a7a377c2eb9b62c9cb96980a5fe0bbd0fddb`) plus an AOT evidence analyzer. The GitHub Actions workflow runs the matching ARM64 Blutter binary for the Dart runtime embedded in the APK, then extracts high-signal call-site evidence around `WriteActuatorPeriperalCommand`, actuator reads/writes, DSP config/address terms, Volume/Gain/Output/Channel terms, and related serializer code.

This is discovery-only. It does **not** unlock CH1–CH7 Output Volume until the exact hardware path is independently proved. Existing V91 UI controls remain visible, but unverified Channel Output Volume stays fail-closed. No Band1.G shortcut, no guessed actuator/address/packet, and no automatic SaveParams are added.
