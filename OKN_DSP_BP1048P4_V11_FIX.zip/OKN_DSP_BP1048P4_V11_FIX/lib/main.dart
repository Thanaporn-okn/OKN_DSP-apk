
import 'package:flutter/material.dart';

void main(){
  runApp(const OKNDSP());
}

class OKNDSP extends StatelessWidget{
  const OKNDSP({super.key});

  @override
  Widget build(BuildContext context){
    return MaterialApp(
      debugShowCheckedModeBanner:false,
      theme: ThemeData.dark(),
      home: Scaffold(
        backgroundColor: const Color(0xff111017),
        appBar: AppBar(title: const Text('OKN_DSP BP1048P4 V11 FIX')),
        body: const Center(
          child: Text(
            'Bluetooth Module Ready\nBP1048P4 Command System',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize:24,color:Colors.cyan),
          ),
        ),
      ),
    );
  }
}
