
V11 FIX
Removed incompatible flutter_blue_plus dependency.
Prepared for GitHub Actions build.
