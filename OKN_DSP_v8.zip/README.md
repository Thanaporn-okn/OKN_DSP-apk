# OKN_DSP v8

UI is locked to the supplied OKN_DSP reference screens. No new custom screen or visual style is added.

v8 changes:
- Keeps the Home and EQ UI/layout from v7 unchanged.
- Keeps the stable update signing key introduced in v7, so v8 is designed to install over v7.
- Remembers the last DSP only after the proven AB01 characteristic is discovered successfully.
- On later connections, tries the remembered DSP directly first and falls back to the original OKN-DSP scan if direct reconnect fails.
- Captures target advertisement raw bytes, advertised service UUIDs, manufacturer-specific data and service data.
- Captures every discovered GATT descriptor in addition to service/characteristic/property data.
- Captures connected-device RSSI after AB01 becomes ready.
- Continues safe AB01 READ/NOTIFY capture exactly as before.
- Does NOT transmit guessed DSP command bytes.
- The existing gear icon still copies/shares the BLE diagnostic report; no extra diagnostic screen was added.

Target: Android 8.0+ (minSdk 26), compile/target SDK 35.

## Update signing
- applicationId remains com.okn.dsp.
- app/okn_dsp_update.jks remains byte-for-byte the same stable key first used in v7.
- Keep this key unchanged in every future version so Android can update in place.
