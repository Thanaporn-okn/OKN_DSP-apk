package com.okn.dsp;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/**
 * BLE transport/protocol-capture foundation for OKN_DSP v8.
 *
 * Proven information currently used:
 * characteristic UUID = 0000ab01-0000-1000-8000-00805f9b34fb
 *
 * v8 keeps the proven AB01-safe capture flow, adds remembered-device reconnect,
 * advertisement metadata, descriptor mapping and RSSI capture. It deliberately
 * sends no guessed DSP command bytes.
 */
public final class DspBleManager {
    public enum State { DISCONNECTED, SCANNING, CONNECTING, DISCOVERING, READY, ERROR }

    public interface Listener {
        void onBleStateChanged(State state, String deviceName, String detail);
        void onCharacteristicData(UUID characteristic, byte[] data);
    }

    public static final UUID AB01_UUID = UUID.fromString("0000ab01-0000-1000-8000-00805f9b34fb");
    private static final UUID CCCD_UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    private static final String TAG = "OKN_DSP_BLE";
    private static final long SCAN_TIMEOUT_MS = 12000L;
    private static final long SAVED_DEVICE_CONNECT_TIMEOUT_MS = 6500L;
    private static final int MAX_DIAGNOSTIC_LINES = 320;
    private static final String PREFS_NAME = "okn_ble";
    private static final String KEY_LAST_ADDRESS = "last_address";
    private static final String KEY_LAST_NAME = "last_name";

    private final Context appContext;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final BluetoothAdapter adapter;
    private final SharedPreferences prefs;
    private final ArrayDeque<String> diagnosticLines = new ArrayDeque<>();

    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic ab01;
    private State state = State.DISCONNECTED;
    private String deviceName = "OKN-DSP";
    private String ab01ServiceUuid = "-";
    private int ab01Properties = 0;
    private int rxCount = 0;
    private int lastRxLength = -1;
    private String lastRxHex = "";
    private long sessionStartElapsedMs = 0L;
    private int sessionNumber = 0;
    private boolean readyIssued = false;
    private boolean tryingSavedDevice = false;
    private String lastDeviceAddress = "";
    private String lastDeviceName = "OKN-DSP";
    private String currentDeviceAddress = "";

    public DspBleManager(Context context, Listener listener) {
        this.appContext = context.getApplicationContext();
        this.listener = listener;
        BluetoothManager manager = (BluetoothManager) appContext.getSystemService(Context.BLUETOOTH_SERVICE);
        this.adapter = manager == null ? null : manager.getAdapter();
        this.prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        this.lastDeviceAddress = prefs.getString(KEY_LAST_ADDRESS, "");
        this.lastDeviceName = prefs.getString(KEY_LAST_NAME, "OKN-DSP");
        addDiagnostic("BLE manager created; API=" + Build.VERSION.SDK_INT);
        if (lastDeviceAddress != null && !lastDeviceAddress.isEmpty()) {
            addDiagnostic("Saved DSP available address=" + maskAddress(lastDeviceAddress)
                    + " name=" + lastDeviceName);
        }
    }

    public boolean isBluetoothAvailable() {
        return adapter != null;
    }

    public boolean isBluetoothEnabled() {
        return adapter != null && adapter.isEnabled();
    }

    public State getState() {
        return state;
    }

    public void connect() {
        if (adapter == null) {
            update(State.ERROR, deviceName, "Bluetooth not available");
            return;
        }
        if (!hasScanPermission() || !hasConnectPermission()) {
            update(State.ERROR, deviceName, "Bluetooth permission required");
            return;
        }
        if (!adapter.isEnabled()) {
            update(State.ERROR, deviceName, "Bluetooth is off");
            return;
        }

        disconnectInternal(false);
        beginSession();

        if (tryConnectSavedDevice()) return;
        beginScan();
    }

    public void disconnect() {
        disconnectInternal(true);
    }

    public void close() {
        main.removeCallbacksAndMessages(null);
        stopScan();
        if (gatt != null) {
            try { gatt.close(); } catch (Throwable ignored) { }
        }
        gatt = null;
        ab01 = null;
        readyIssued = false;
        state = State.DISCONNECTED;
    }

    public boolean hasKnownCharacteristic() {
        return ab01 != null;
    }

    /**
     * Safe transport validation only. A READ cannot change DSP settings.
     */
    public boolean readKnownCharacteristic() {
        if (gatt == null || ab01 == null || !hasConnectPermission()) return false;
        if ((ab01.getProperties() & BluetoothGattCharacteristic.PROPERTY_READ) == 0) return false;
        try {
            boolean queued = gatt.readCharacteristic(ab01);
            addDiagnostic("AB01 READ queued=" + queued);
            return queued;
        } catch (SecurityException e) {
            addDiagnostic("AB01 READ blocked by permission");
            return false;
        } catch (Throwable t) {
            addDiagnostic("AB01 READ exception=" + t.getClass().getSimpleName());
            return false;
        }
    }

    /**
     * Raw write support exists for the later decoded protocol layer only.
     * v8 never calls this method automatically and invents no command bytes.
     */
    public boolean writeKnownCharacteristic(byte[] data) {
        if (gatt == null || ab01 == null || data == null || !hasConnectPermission()) return false;
        int props = ab01.getProperties();
        boolean canWrite = (props & BluetoothGattCharacteristic.PROPERTY_WRITE) != 0
                || (props & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0;
        if (!canWrite) return false;
        try {
            int writeType = (props & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0
                    ? BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                    : BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT;
            addDiagnostic("TX requested len=" + data.length + " type=" + writeType + " hex=" + toHex(data));
            if (Build.VERSION.SDK_INT >= 33) {
                return gatt.writeCharacteristic(ab01, data, writeType) == 0;
            }
            ab01.setValue(data);
            ab01.setWriteType(writeType);
            return gatt.writeCharacteristic(ab01);
        } catch (SecurityException e) {
            addDiagnostic("TX blocked by permission");
            return false;
        } catch (Throwable t) {
            addDiagnostic("TX exception=" + t.getClass().getSimpleName());
            return false;
        }
    }

    public String getDiagnosticReport() {
        StringBuilder out = new StringBuilder(4096);
        out.append("OKN_DSP v8 BLE diagnostic\n");
        out.append("Known characteristic: ").append(AB01_UUID).append('\n');
        out.append("State: ").append(state).append('\n');
        out.append("Device: ").append(deviceName).append('\n');
        out.append("Current address: ").append(maskAddress(currentDeviceAddress)).append('\n');
        out.append("Saved address: ").append(maskAddress(lastDeviceAddress)).append('\n');
        out.append("AB01 service: ").append(ab01ServiceUuid).append('\n');
        out.append("AB01 properties: 0x").append(Integer.toHexString(ab01Properties))
                .append(" [").append(propertiesText(ab01Properties)).append("]\n");
        out.append("RX packets: ").append(rxCount).append('\n');
        out.append("Last RX len: ").append(lastRxLength).append('\n');
        out.append("Last RX hex: ").append(lastRxHex).append("\n\n");
        synchronized (diagnosticLines) {
            for (String line : diagnosticLines) out.append(line).append('\n');
        }
        return out.toString();
    }

    private void beginSession() {
        sessionNumber++;
        sessionStartElapsedMs = SystemClock.elapsedRealtime();
        ab01ServiceUuid = "-";
        ab01Properties = 0;
        rxCount = 0;
        lastRxLength = -1;
        lastRxHex = "";
        readyIssued = false;
        tryingSavedDevice = false;
        currentDeviceAddress = "";
        addDiagnostic("SESSION #" + sessionNumber + " START");
    }

    private boolean tryConnectSavedDevice() {
        if (adapter == null || lastDeviceAddress == null || lastDeviceAddress.isEmpty()) return false;
        if (!hasConnectPermission()) return false;
        try {
            BluetoothDevice device = adapter.getRemoteDevice(lastDeviceAddress);
            tryingSavedDevice = true;
            currentDeviceAddress = lastDeviceAddress;
            if (lastDeviceName != null && !lastDeviceName.trim().isEmpty()) deviceName = lastDeviceName;
            addDiagnostic("SAVED connect address=" + maskAddress(lastDeviceAddress));
            connectGatt(device);
            if (state == State.ERROR) {
                tryingSavedDevice = false;
                return false;
            }
            main.removeCallbacks(savedDeviceConnectTimeout);
            main.postDelayed(savedDeviceConnectTimeout, SAVED_DEVICE_CONNECT_TIMEOUT_MS);
            return true;
        } catch (IllegalArgumentException e) {
            addDiagnostic("SAVED address invalid; clearing remembered DSP");
            forgetSavedDevice();
        } catch (SecurityException e) {
            addDiagnostic("SAVED connect blocked by permission");
        } catch (Throwable t) {
            addDiagnostic("SAVED connect exception=" + t.getClass().getSimpleName());
        }
        tryingSavedDevice = false;
        return false;
    }

    private void beginScan() {
        main.removeCallbacks(savedDeviceConnectTimeout);
        tryingSavedDevice = false;
        scanner = adapter == null ? null : adapter.getBluetoothLeScanner();
        if (scanner == null) {
            update(State.ERROR, deviceName, "BLE scanner unavailable");
            return;
        }
        update(State.SCANNING, deviceName, "Scanning for OKN-DSP");
        addDiagnostic("SCAN start timeout=" + SCAN_TIMEOUT_MS + "ms");
        try {
            scanner.startScan(scanCallback);
            main.removeCallbacks(scanTimeout);
            main.postDelayed(scanTimeout, SCAN_TIMEOUT_MS);
        } catch (SecurityException e) {
            update(State.ERROR, deviceName, "Bluetooth permission denied");
        } catch (Throwable t) {
            Log.e(TAG, "startScan failed", t);
            addDiagnostic("SCAN exception=" + t.getClass().getSimpleName());
            update(State.ERROR, deviceName, "Unable to start BLE scan");
        }
    }

    private final Runnable savedDeviceConnectTimeout = new Runnable() {
        @Override public void run() {
            if (!tryingSavedDevice || state != State.CONNECTING) return;
            addDiagnostic("SAVED connect timeout; falling back to scan");
            closeGattForFallback();
            beginScan();
        }
    };

    private final Runnable scanTimeout = new Runnable() {
        @Override public void run() {
            if (state == State.SCANNING) {
                stopScan();
                addDiagnostic("SCAN timeout: target not found");
                update(State.ERROR, deviceName, "OKN-DSP not found");
            }
        }
    };

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            handleScanResult(result);
        }

        @Override
        public void onBatchScanResults(List<ScanResult> results) {
            if (results == null) return;
            for (ScanResult result : results) {
                if (state != State.SCANNING) break;
                handleScanResult(result);
            }
        }

        @Override
        public void onScanFailed(int errorCode) {
            addDiagnostic("SCAN failed code=" + errorCode);
            update(State.ERROR, deviceName, "BLE scan error " + errorCode);
        }
    };

    private void handleScanResult(ScanResult result) {
        if (result == null || result.getDevice() == null || state != State.SCANNING) return;
        String name = null;
        if (result.getScanRecord() != null) name = result.getScanRecord().getDeviceName();
        if ((name == null || name.trim().isEmpty()) && hasConnectPermission()) {
            try { name = result.getDevice().getName(); } catch (SecurityException ignored) { }
        }
        if (!isTargetName(name)) return;
        deviceName = name == null ? "OKN-DSP" : name;
        try { currentDeviceAddress = result.getDevice().getAddress(); } catch (Throwable ignored) { currentDeviceAddress = ""; }
        addDiagnostic("SCAN target name=" + deviceName + " address=" + maskAddress(currentDeviceAddress)
                + " rssi=" + result.getRssi());
        logAdvertisement(result);
        stopScan();
        connectGatt(result.getDevice());
    }

    private boolean isTargetName(String name) {
        if (name == null) return false;
        String normalized = name.trim().toUpperCase(Locale.ROOT)
                .replace('_', '-')
                .replace(" ", "");
        return normalized.equals("OKN-DSP") || normalized.equals("OKNDSP");
    }

    private void connectGatt(BluetoothDevice device) {
        if (!hasConnectPermission()) {
            update(State.ERROR, deviceName, "Bluetooth connect permission required");
            return;
        }
        update(State.CONNECTING, deviceName, "Connecting");
        addDiagnostic("GATT connect requested");
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                gatt = device.connectGatt(appContext, false, gattCallback, BluetoothDevice.TRANSPORT_LE);
            } else {
                gatt = device.connectGatt(appContext, false, gattCallback);
            }
        } catch (SecurityException e) {
            update(State.ERROR, deviceName, "Bluetooth permission denied");
        } catch (Throwable t) {
            Log.e(TAG, "connectGatt failed", t);
            addDiagnostic("GATT connect exception=" + t.getClass().getSimpleName());
            update(State.ERROR, deviceName, "GATT connection failed");
        }
    }

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt bluetoothGatt, int status, int newState) {
            addDiagnostic("GATT state status=" + status + " newState=" + newState);
            if (newState == android.bluetooth.BluetoothProfile.STATE_CONNECTED && status == BluetoothGatt.GATT_SUCCESS) {
                main.removeCallbacks(savedDeviceConnectTimeout);
                tryingSavedDevice = false;
                try { currentDeviceAddress = bluetoothGatt.getDevice().getAddress(); } catch (Throwable ignored) { }
                update(State.DISCOVERING, deviceName, "Discovering services");
                try {
                    if (hasConnectPermission()) {
                        boolean queued = bluetoothGatt.discoverServices();
                        addDiagnostic("SERVICE discovery queued=" + queued);
                        if (!queued) update(State.ERROR, deviceName, "Unable to start service discovery");
                    }
                } catch (SecurityException e) {
                    update(State.ERROR, deviceName, "Bluetooth permission denied");
                }
            } else if (newState == android.bluetooth.BluetoothProfile.STATE_DISCONNECTED) {
                boolean fallbackToScan = tryingSavedDevice && state == State.CONNECTING;
                main.removeCallbacks(savedDeviceConnectTimeout);
                ab01 = null;
                readyIssued = false;
                try { bluetoothGatt.close(); } catch (Throwable ignored) { }
                if (gatt == bluetoothGatt) gatt = null;
                if (fallbackToScan) {
                    addDiagnostic("SAVED connect disconnected; falling back to scan");
                    tryingSavedDevice = false;
                    beginScan();
                } else if (state != State.DISCONNECTED) {
                    update(State.DISCONNECTED, deviceName, "Disconnected");
                }
            } else if (status != BluetoothGatt.GATT_SUCCESS) {
                if (tryingSavedDevice) {
                    addDiagnostic("SAVED connect GATT status=" + status + "; falling back to scan");
                    tryingSavedDevice = false;
                    main.removeCallbacks(savedDeviceConnectTimeout);
                    closeGattForFallback();
                    beginScan();
                } else {
                    update(State.ERROR, deviceName, "GATT status " + status);
                }
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt bluetoothGatt, int status) {
            addDiagnostic("SERVICE discovery status=" + status);
            if (status != BluetoothGatt.GATT_SUCCESS) {
                update(State.ERROR, deviceName, "Service discovery failed " + status);
                return;
            }
            BluetoothGattCharacteristic found = null;
            String foundService = "-";
            List<BluetoothGattService> services = bluetoothGatt.getServices();
            addDiagnostic("SERVICE count=" + (services == null ? 0 : services.size()));
            if (services != null) {
                for (BluetoothGattService service : services) {
                    addDiagnostic("SERVICE " + service.getUuid());
                    for (BluetoothGattCharacteristic characteristic : service.getCharacteristics()) {
                        int props = characteristic.getProperties();
                        addDiagnostic(" CHAR " + characteristic.getUuid() + " props=0x"
                                + Integer.toHexString(props) + " [" + propertiesText(props) + "]");
                        List<BluetoothGattDescriptor> descriptors = characteristic.getDescriptors();
                        if (descriptors != null) {
                            for (BluetoothGattDescriptor descriptor : descriptors) {
                                addDiagnostic("  DESC " + descriptor.getUuid());
                            }
                        }
                        if (AB01_UUID.equals(characteristic.getUuid())) {
                            found = characteristic;
                            foundService = service.getUuid().toString();
                        }
                    }
                }
            }
            ab01 = found;
            if (ab01 == null) {
                update(State.ERROR, deviceName, "Connected, but AB01 was not found");
                return;
            }

            ab01ServiceUuid = foundService;
            ab01Properties = ab01.getProperties();
            rememberSuccessfulDevice(bluetoothGatt.getDevice());
            addDiagnostic("AB01 FOUND service=" + ab01ServiceUuid + " props=0x"
                    + Integer.toHexString(ab01Properties) + " [" + propertiesText(ab01Properties) + "]");
            configureAb01(bluetoothGatt, ab01);
        }

        @Override
        public void onReadRemoteRssi(BluetoothGatt bluetoothGatt, int rssi, int status) {
            addDiagnostic("RSSI value=" + rssi + " status=" + status);
        }

        @Override
        public void onDescriptorWrite(BluetoothGatt bluetoothGatt, BluetoothGattDescriptor descriptor, int status) {
            UUID descriptorUuid = descriptor == null ? null : descriptor.getUuid();
            addDiagnostic("DESCRIPTOR write uuid=" + descriptorUuid + " status=" + status);
            if (descriptor != null && CCCD_UUID.equals(descriptor.getUuid())) {
                if (status == BluetoothGatt.GATT_SUCCESS) {
                    markReadyAndSafeProbe();
                } else {
                    addDiagnostic("CCCD enable failed; AB01 remains available without notification subscription");
                    markReadyAndSafeProbe();
                }
            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt bluetoothGatt, BluetoothGattCharacteristic characteristic) {
            byte[] value = characteristic == null ? null : characteristic.getValue();
            dispatchData("NOTIFY", characteristic, value, BluetoothGatt.GATT_SUCCESS);
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt bluetoothGatt, BluetoothGattCharacteristic characteristic, byte[] value) {
            dispatchData("NOTIFY", characteristic, value, BluetoothGatt.GATT_SUCCESS);
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt bluetoothGatt, BluetoothGattCharacteristic characteristic, int status) {
            byte[] value = characteristic == null ? null : characteristic.getValue();
            dispatchData("READ", characteristic, value, status);
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt bluetoothGatt, BluetoothGattCharacteristic characteristic, byte[] value, int status) {
            dispatchData("READ", characteristic, value, status);
        }

        @Override
        public void onCharacteristicWrite(BluetoothGatt bluetoothGatt, BluetoothGattCharacteristic characteristic, int status) {
            addDiagnostic("WRITE callback uuid=" + (characteristic == null ? "-" : characteristic.getUuid())
                    + " status=" + status);
        }
    };

    private void configureAb01(BluetoothGatt bluetoothGatt, BluetoothGattCharacteristic characteristic) {
        int props = characteristic.getProperties();
        boolean notify = (props & BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0;
        boolean indicate = (props & BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0;

        if (!notify && !indicate) {
            addDiagnostic("AB01 has no NOTIFY/INDICATE; skip CCCD");
            markReadyAndSafeProbe();
            return;
        }
        if (!hasConnectPermission()) {
            update(State.ERROR, deviceName, "Bluetooth connect permission required");
            return;
        }

        try {
            boolean localEnabled = bluetoothGatt.setCharacteristicNotification(characteristic, true);
            addDiagnostic("AB01 local notification enabled=" + localEnabled);
            BluetoothGattDescriptor descriptor = characteristic.getDescriptor(CCCD_UUID);
            if (descriptor == null) {
                addDiagnostic("AB01 CCCD not present");
                markReadyAndSafeProbe();
                return;
            }
            byte[] value = indicate
                    ? BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
                    : BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE;
            boolean queued;
            if (Build.VERSION.SDK_INT >= 33) {
                queued = bluetoothGatt.writeDescriptor(descriptor, value) == 0;
            } else {
                descriptor.setValue(value);
                queued = bluetoothGatt.writeDescriptor(descriptor);
            }
            addDiagnostic("AB01 CCCD write queued=" + queued + " mode=" + (indicate ? "INDICATE" : "NOTIFY"));
            if (!queued) markReadyAndSafeProbe();
        } catch (SecurityException e) {
            addDiagnostic("AB01 notification blocked by permission");
            markReadyAndSafeProbe();
        } catch (Throwable t) {
            addDiagnostic("AB01 notification exception=" + t.getClass().getSimpleName());
            markReadyAndSafeProbe();
        }
    }

    private void markReadyAndSafeProbe() {
        if (readyIssued || ab01 == null) return;
        readyIssued = true;
        update(State.READY, deviceName, "AB01 ready: " + propertiesText(ab01Properties));
        addDiagnostic("AB01 READY elapsedMs=" + elapsedMs());

        if (gatt != null && hasConnectPermission()) {
            try {
                boolean rssiQueued = gatt.readRemoteRssi();
                addDiagnostic("RSSI read queued=" + rssiQueued);
            } catch (Throwable t) {
                addDiagnostic("RSSI read exception=" + t.getClass().getSimpleName());
            }
        }

        if ((ab01Properties & BluetoothGattCharacteristic.PROPERTY_READ) != 0) {
            // Delay slightly so a completed CCCD transaction is fully clear before READ.
            main.postDelayed(new Runnable() {
                @Override public void run() {
                    if (state == State.READY && ab01 != null) readKnownCharacteristic();
                }
            }, 180L);
        } else {
            addDiagnostic("AB01 READ not supported; no safe read probe performed");
        }
    }

    private void dispatchData(String source, BluetoothGattCharacteristic characteristic, byte[] value, int status) {
        if (characteristic == null) return;
        byte[] safe = value == null ? new byte[0] : value.clone();
        String hex = toHex(safe);
        if (AB01_UUID.equals(characteristic.getUuid())) {
            rxCount++;
            lastRxLength = safe.length;
            lastRxHex = hex;
        }
        addDiagnostic(source + " " + characteristic.getUuid() + " len=" + safe.length
                + " status=" + status + " hex=" + hex);
        if (status == BluetoothGatt.GATT_SUCCESS && listener != null) {
            listener.onCharacteristicData(characteristic.getUuid(), safe);
        }
    }

    private void disconnectInternal(boolean notify) {
        main.removeCallbacks(scanTimeout);
        main.removeCallbacks(savedDeviceConnectTimeout);
        stopScan();
        ab01 = null;
        readyIssued = false;
        tryingSavedDevice = false;
        if (gatt != null) {
            addDiagnostic("GATT disconnect requested");
            try {
                if (hasConnectPermission()) gatt.disconnect();
            } catch (SecurityException ignored) { }
            try { gatt.close(); } catch (Throwable ignored) { }
            gatt = null;
        }
        if (notify) {
            addDiagnostic("SESSION END elapsedMs=" + elapsedMs());
            update(State.DISCONNECTED, deviceName, "Disconnected");
        } else {
            state = State.DISCONNECTED;
        }
    }

    private void closeGattForFallback() {
        ab01 = null;
        readyIssued = false;
        if (gatt != null) {
            try { if (hasConnectPermission()) gatt.disconnect(); } catch (Throwable ignored) { }
            try { gatt.close(); } catch (Throwable ignored) { }
            gatt = null;
        }
    }

    private void rememberSuccessfulDevice(BluetoothDevice device) {
        if (device == null || !hasConnectPermission()) return;
        try {
            String address = device.getAddress();
            String name = device.getName();
            if (address == null || address.trim().isEmpty()) return;
            lastDeviceAddress = address;
            currentDeviceAddress = address;
            if (name != null && !name.trim().isEmpty()) {
                lastDeviceName = name;
                deviceName = name;
            }
            prefs.edit().putString(KEY_LAST_ADDRESS, lastDeviceAddress)
                    .putString(KEY_LAST_NAME, lastDeviceName).apply();
            addDiagnostic("DSP remembered address=" + maskAddress(lastDeviceAddress));
        } catch (SecurityException e) {
            addDiagnostic("DSP remember blocked by permission");
        } catch (Throwable t) {
            addDiagnostic("DSP remember exception=" + t.getClass().getSimpleName());
        }
    }

    private void forgetSavedDevice() {
        lastDeviceAddress = "";
        lastDeviceName = "OKN-DSP";
        prefs.edit().remove(KEY_LAST_ADDRESS).remove(KEY_LAST_NAME).apply();
    }

    private void logAdvertisement(ScanResult result) {
        if (result == null || result.getScanRecord() == null) return;
        try {
            android.bluetooth.le.ScanRecord record = result.getScanRecord();
            byte[] raw = record.getBytes();
            addDiagnostic("ADV raw len=" + (raw == null ? 0 : raw.length) + " hex=" + toHex(raw));

            List<android.os.ParcelUuid> serviceUuids = record.getServiceUuids();
            if (serviceUuids != null) {
                for (android.os.ParcelUuid uuid : serviceUuids) addDiagnostic("ADV service=" + uuid);
            }

            android.util.SparseArray<byte[]> manufacturer = record.getManufacturerSpecificData();
            if (manufacturer != null) {
                for (int i = 0; i < manufacturer.size(); i++) {
                    int id = manufacturer.keyAt(i);
                    byte[] data = manufacturer.valueAt(i);
                    addDiagnostic("ADV manufacturer id=" + id + " len="
                            + (data == null ? 0 : data.length) + " hex=" + toHex(data));
                }
            }

        } catch (Throwable t) {
            addDiagnostic("ADV parse exception=" + t.getClass().getSimpleName());
        }
    }

    private void stopScan() {
        main.removeCallbacks(scanTimeout);
        if (scanner != null && hasScanPermission()) {
            try { scanner.stopScan(scanCallback); } catch (SecurityException ignored) { }
        }
        scanner = null;
    }

    private boolean hasScanPermission() {
        if (Build.VERSION.SDK_INT >= 31) {
            return appContext.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED;
        }
        if (Build.VERSION.SDK_INT >= 23) {
            return appContext.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    private boolean hasConnectPermission() {
        if (Build.VERSION.SDK_INT >= 31) {
            return appContext.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    private void update(final State newState, final String name, final String detail) {
        state = newState;
        addDiagnostic("STATE " + newState + " detail=" + detail);
        Log.i(TAG, newState + " " + detail);
        if (listener != null) {
            main.post(new Runnable() {
                @Override public void run() {
                    listener.onBleStateChanged(newState, name, detail);
                }
            });
        }
    }

    private void addDiagnostic(String message) {
        String line = timestamp() + " +" + elapsedMs() + "ms " + message;
        Log.i(TAG, line);
        synchronized (diagnosticLines) {
            while (diagnosticLines.size() >= MAX_DIAGNOSTIC_LINES) diagnosticLines.removeFirst();
            diagnosticLines.addLast(line);
        }
    }

    private long elapsedMs() {
        if (sessionStartElapsedMs <= 0L) return 0L;
        return Math.max(0L, SystemClock.elapsedRealtime() - sessionStartElapsedMs);
    }

    private static String maskAddress(String address) {
        if (address == null || address.trim().isEmpty()) return "-";
        String[] parts = address.split(":");
        if (parts.length != 6) return "saved";
        return "XX:XX:XX:" + parts[3] + ":" + parts[4] + ":" + parts[5];
    }

    private static String timestamp() {
        return new SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(new Date());
    }

    public static String toHex(byte[] data) {
        if (data == null || data.length == 0) return "";
        StringBuilder out = new StringBuilder(data.length * 2);
        for (byte b : data) out.append(String.format(Locale.US, "%02X", b & 0xFF));
        return out.toString();
    }

    public static String propertiesText(int props) {
        StringBuilder out = new StringBuilder();
        appendProp(out, props, BluetoothGattCharacteristic.PROPERTY_READ, "READ");
        appendProp(out, props, BluetoothGattCharacteristic.PROPERTY_WRITE, "WRITE");
        appendProp(out, props, BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE, "WRITE_NR");
        appendProp(out, props, BluetoothGattCharacteristic.PROPERTY_NOTIFY, "NOTIFY");
        appendProp(out, props, BluetoothGattCharacteristic.PROPERTY_INDICATE, "INDICATE");
        appendProp(out, props, BluetoothGattCharacteristic.PROPERTY_BROADCAST, "BROADCAST");
        return out.length() == 0 ? "NONE" : out.toString();
    }

    private static void appendProp(StringBuilder out, int props, int flag, String label) {
        if ((props & flag) == 0) return;
        if (out.length() > 0) out.append('|');
        out.append(label);
    }
}
