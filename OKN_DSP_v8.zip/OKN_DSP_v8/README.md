# OKN DSP v8

Native Android / Jetpack Compose DSP controller UI.

Features:
- Samsung-inspired light UI
- Home connection/status dashboard
- Mix: Master, Bass, Bass Cutoff, CH1-CH7 volume sliders + editable numeric values
- EQ: 15 bands × 7 channels, per-band Frequency / Q / Gain, channel volume
- Preset save/load/delete using local SharedPreferences
- Android Bluetooth permission scaffolding ready for DSP transport integration

Package: `com.okn.dsp`
Version: `8.0` (code 8)
Minimum Android: 8.0 (API 26)
