package com.okn.dsp

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlin.math.roundToInt

private val SamsungBlue = Color(0xFF0B72FF)
private val PageBg = Color(0xFFF7F9FC)
private val CardBg = Color.White
private val Muted = Color(0xFF6E7D99)
private val Green = Color(0xFF28C840)
private val Orange = Color(0xFFFF8A1F)
private val Purple = Color(0xFF7A5CFF)
private val Cyan = Color(0xFF16B8D4)
private val Pink = Color(0xFFF04F72)

private val AppColors = lightColorScheme(
    primary = SamsungBlue,
    background = PageBg,
    surface = CardBg,
    onBackground = Color(0xFF0A1020),
    onSurface = Color(0xFF0A1020)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = AppColors) {
                OknDspApp()
            }
        }
    }
}

enum class AppPage(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Default.Home),
    MIX("Mix", Icons.Default.Tune),
    EQ("Eq", Icons.Default.Equalizer)
}

data class EqBand(
    val frequency: Float,
    val q: Float,
    val gain: Float
)

data class EqChannel(
    val name: String,
    val volume: Float,
    val bands: List<EqBand>
)

private fun defaultBands(): List<EqBand> {
    val frequencies = listOf(25f, 40f, 63f, 100f, 160f, 250f, 400f, 630f, 1000f, 1600f, 2500f, 4000f, 6300f, 10000f, 16000f)
    return frequencies.map { EqBand(it, 1.0f, 0f) }
}

private fun defaultChannel(index: Int) = EqChannel(
    name = "Ch${index + 1}",
    volume = 0f,
    bands = defaultBands()
)

@Composable
fun OknDspApp() {
    var page by remember { mutableStateOf(AppPage.HOME) }
    val eqChannels = remember {
        mutableStateListOf<EqChannel>().apply { repeat(7) { add(defaultChannel(it)) } }
    }

    var masterVolume by remember { mutableFloatStateOf(-6f) }
    var bassVolume by remember { mutableFloatStateOf(2f) }
    var bassCutoff by remember { mutableFloatStateOf(80f) }
    val channelVolumes = remember {
        mutableStateListOf(-3f, -6f, -2f, -8f, 0f, -4f, -10f)
    }

    Scaffold(
        containerColor = PageBg,
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                AppPage.entries.forEach { item ->
                    NavigationBarItem(
                        selected = page == item,
                        onClick = { page = item },
                        icon = { Icon(item.icon, contentDescription = item.label) },
                        label = { Text(item.label) }
                    )
                }
            }
        }
    ) { padding ->
        when (page) {
            AppPage.HOME -> HomeScreen(Modifier.padding(padding))
            AppPage.MIX -> MixScreen(
                modifier = Modifier.padding(padding),
                masterVolume = masterVolume,
                onMasterVolume = { masterVolume = it },
                bassVolume = bassVolume,
                onBassVolume = { bassVolume = it },
                bassCutoff = bassCutoff,
                onBassCutoff = { bassCutoff = it },
                channelVolumes = channelVolumes,
                onChannelVolume = { index, value -> channelVolumes[index] = value }
            )
            AppPage.EQ -> EqScreen(
                modifier = Modifier.padding(padding),
                channels = eqChannels,
                onChannelUpdate = { index, channel -> eqChannels[index] = channel }
            )
        }
    }
}

@Composable
private fun HomeScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val manager = remember { context.getSystemService(BluetoothManager::class.java) }
    val adapter = remember { manager?.adapter }
    fun bluetoothIsOn(): Boolean = runCatching { adapter?.isEnabled == true }.getOrDefault(false)
    var bluetoothEnabled by remember { mutableStateOf(bluetoothIsOn()) }

    val permissions = remember {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        } else emptyArray()
    }
    var permissionsGranted by remember {
        mutableStateOf(permissions.all { context.checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED })
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        permissionsGranted = result.values.all { it }
    }

    DisposableEffect(adapter) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                if (intent?.action == BluetoothAdapter.ACTION_STATE_CHANGED) {
                    bluetoothEnabled = bluetoothIsOn()
                }
            }
        }
        ContextCompat.registerReceiver(
            context, receiver, IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED
        )
        onDispose { runCatching { context.unregisterReceiver(receiver) } }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize().background(PageBg),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("OKN DSP", fontSize = 36.sp, fontWeight = FontWeight.Bold)
            Text("DSP Controller", color = Muted, fontSize = 18.sp)
        }
        item {
            Card(
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF1FFF4)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(Modifier.padding(22.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier.size(64.dp).background(Green.copy(alpha = .15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Green, modifier = Modifier.size(42.dp))
                    }
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text("SYSTEM STATUS", color = Muted, fontSize = 13.sp)
                        Text(
                            if (bluetoothEnabled && permissionsGranted) "System Ready" else "Setup Required",
                            fontSize = 26.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            if (bluetoothEnabled && permissionsGranted) "Bluetooth is ready for DSP connection."
                            else "Enable Bluetooth and grant permission to continue.",
                            color = Muted
                        )
                    }
                }
            }
        }
        item { SectionTitle("Connection & Status") }
        item {
            StatusCard(
                icon = Icons.Default.Bluetooth,
                iconColor = SamsungBlue,
                title = "Bluetooth",
                subtitle = if (bluetoothEnabled) "Phone Bluetooth enabled" else "Bluetooth is turned off",
                status = if (bluetoothEnabled) "Ready" else "Off",
                statusColor = if (bluetoothEnabled) Green else Pink,
                onClick = { context.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
            )
        }
        item {
            StatusCard(
                icon = Icons.Default.Memory,
                iconColor = Purple,
                title = "DSP Device",
                subtitle = "Waiting for DSP transport integration",
                status = "Ready",
                statusColor = SamsungBlue,
                onClick = null
            )
        }
        item {
            StatusCard(
                icon = Icons.Default.VolumeUp,
                iconColor = Orange,
                title = "Audio Control",
                subtitle = "Mix and 7-channel EQ engine",
                status = "Active",
                statusColor = SamsungBlue,
                onClick = null
            )
        }
        item {
            StatusCard(
                icon = Icons.Default.Save,
                iconColor = Cyan,
                title = "Preset Storage",
                subtitle = "Saved locally on this phone",
                status = "Available",
                statusColor = Green,
                onClick = null
            )
        }
        if (!permissionsGranted && permissions.isNotEmpty()) {
            item {
                Button(
                    onClick = { permissionLauncher.launch(permissions) },
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Text("Allow Bluetooth Permission")
                }
            }
        }
        item { Spacer(Modifier.height(8.dp)) }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, fontWeight = FontWeight.Bold, fontSize = 24.sp, modifier = Modifier.padding(top = 6.dp))
}

@Composable
private fun StatusCard(
    icon: ImageVector,
    iconColor: Color,
    title: String,
    subtitle: String,
    status: String,
    statusColor: Color,
    onClick: (() -> Unit)?
) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        modifier = Modifier.fillMaxWidth().then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
    ) {
        Row(
            modifier = Modifier.padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(52.dp).background(iconColor.copy(alpha = .12f), CircleShape),
                contentAlignment = Alignment.Center
            ) { Icon(icon, null, tint = iconColor) }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                Text(subtitle, color = Muted, fontSize = 14.sp)
            }
            Box(Modifier.size(9.dp).background(statusColor, CircleShape))
            Spacer(Modifier.width(8.dp))
            Text(status, color = statusColor, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun MixScreen(
    modifier: Modifier = Modifier,
    masterVolume: Float,
    onMasterVolume: (Float) -> Unit,
    bassVolume: Float,
    onBassVolume: (Float) -> Unit,
    bassCutoff: Float,
    onBassCutoff: (Float) -> Unit,
    channelVolumes: List<Float>,
    onChannelVolume: (Int, Float) -> Unit
) {
    LazyColumn(
        modifier = modifier.fillMaxSize().background(PageBg),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Mix", fontSize = 36.sp, fontWeight = FontWeight.Bold)
            Text("Channel and bass controls", color = Muted, fontSize = 18.sp)
        }
        item {
            ControlGroup(title = "Global", subtitle = "Overall output and bass settings") {
                EditableSliderRow("Master Volume", masterVolume, -60f..12f, "dB", onMasterVolume)
                EditableSliderRow("Bass Volume", bassVolume, -24f..12f, "dB", onBassVolume)
                EditableSliderRow("Bass Cutoff", bassCutoff, 20f..250f, "Hz", onBassCutoff, decimals = 0)
            }
        }
        item { SectionTitle("Channels") }
        itemsIndexed(channelVolumes) { index, value ->
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        val palette = listOf(SamsungBlue, Green, Orange, Pink, Purple, Cyan, Color(0xFF635BFF))
                        Box(
                            Modifier.size(40.dp).background(palette[index], CircleShape),
                            contentAlignment = Alignment.Center
                        ) { Text("${index + 1}", color = Color.White, fontWeight = FontWeight.Bold) }
                        Spacer(Modifier.width(12.dp))
                        Text("Volume Ch${index + 1}", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    }
                    EditableSliderRow("", value, -60f..12f, "dB", { onChannelVolume(index, it) }, compact = true)
                }
            }
        }
        item { Spacer(Modifier.height(8.dp)) }
    }
}

@Composable
private fun ControlGroup(title: String, subtitle: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(18.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 24.sp, modifier = Modifier.weight(1f))
                Text(subtitle, color = Muted, fontSize = 13.sp)
            }
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun EditableSliderRow(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    suffix: String,
    onValueChange: (Float) -> Unit,
    decimals: Int = 1,
    compact: Boolean = false
) {
    var text by remember(value) { mutableStateOf(formatNumber(value, decimals)) }
    val commit: () -> Unit = {
        val parsed = text.toFloatOrNull()
        if (parsed != null) onValueChange(parsed.coerceIn(range.start, range.endInclusive))
        else text = formatNumber(value, decimals)
    }
    Column(Modifier.padding(vertical = if (compact) 3.dp else 8.dp)) {
        if (label.isNotBlank()) Text(label, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Slider(
                value = value.coerceIn(range.start, range.endInclusive),
                onValueChange = { onValueChange(it); text = formatNumber(it, decimals) },
                valueRange = range,
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(12.dp))
            OutlinedTextField(
                value = text,
                onValueChange = { input -> text = input.filter { it.isDigit() || it == '-' || it == '.' } },
                singleLine = true,
                suffix = { Text(suffix) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.width(if (suffix == "Hz") 125.dp else 112.dp)
            )
        }
        LaunchedEffect(text) {
            // Numeric edits are applied live when valid, making typed values behave like the slider.
            val parsed = text.toFloatOrNull()
            if (parsed != null && parsed in range) onValueChange(parsed)
        }
    }
}

private fun formatNumber(value: Float, decimals: Int): String =
    if (decimals == 0) value.roundToInt().toString() else String.format(Locale.US, "%.${decimals}f", value)

@Composable
private fun EqScreen(
    modifier: Modifier = Modifier,
    channels: List<EqChannel>,
    onChannelUpdate: (Int, EqChannel) -> Unit
) {
    val context = LocalContext.current
    val presetRepo = remember { PresetRepository(context) }
    var selectedChannel by remember { mutableIntStateOf(0) }
    var selectedBand by remember { mutableIntStateOf(3) }
    var presetName by remember { mutableStateOf("") }
    var showLoadDialog by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf("") }

    val channel = channels[selectedChannel]
    val band = channel.bands[selectedBand]

    fun updateBand(newBand: EqBand) {
        val newBands = channel.bands.toMutableList().apply { this[selectedBand] = newBand }
        onChannelUpdate(selectedChannel, channel.copy(bands = newBands))
    }

    LazyColumn(
        modifier = modifier.fillMaxSize().background(PageBg),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Eq", fontSize = 36.sp, fontWeight = FontWeight.Bold)
            Text("15-band equalizer • 7 channels", color = Muted, fontSize = 18.sp)
        }
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                channels.forEachIndexed { index, _ ->
                    Button(
                        onClick = { selectedChannel = index },
                        shape = RoundedCornerShape(20.dp)
                    ) { Text("Ch${index + 1}") }
                }
            }
        }
        item {
            Card(
                shape = RoundedCornerShape(26.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(18.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Channel ${selectedChannel + 1}", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                            Text("15-band parametric EQ", color = Muted)
                        }
                        TextButton(onClick = {
                            onChannelUpdate(selectedChannel, defaultChannel(selectedChannel))
                            selectedBand = 3
                        }) { Text("Reset EQ") }
                    }
                    Spacer(Modifier.height(12.dp))
                    EqGraph(channel = channel, selectedBand = selectedBand)
                }
            }
        }
        item {
            Card(
                shape = RoundedCornerShape(26.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(18.dp)) {
                    Text("Band ${selectedBand + 1}", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Tap a band below or adjust its parameters", color = Muted)
                    Spacer(Modifier.height(8.dp))
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        repeat(15) { index ->
                            TextButton(onClick = { selectedBand = index }) {
                                Text("${index + 1}", fontWeight = if (index == selectedBand) FontWeight.Bold else FontWeight.Normal)
                            }
                        }
                    }
                    EditableSliderRow("Frequency", band.frequency, 20f..20000f, "Hz", { updateBand(band.copy(frequency = it)) }, decimals = 0)
                    EditableSliderRow("Q (Quality Factor)", band.q, 0.1f..10f, "Q", { updateBand(band.copy(q = it)) }, decimals = 2)
                    EditableSliderRow("Band Gain", band.gain, -12f..12f, "dB", { updateBand(band.copy(gain = it)) }, decimals = 1)
                    EditableSliderRow("Ch Volume", channel.volume, -60f..12f, "dB", {
                        onChannelUpdate(selectedChannel, channel.copy(volume = it))
                    }, decimals = 1)
                }
            }
        }
        item {
            Card(
                shape = RoundedCornerShape(26.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(18.dp)) {
                    Text("Presets", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Save and load all 7-channel EQ settings", color = Muted)
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = presetName,
                        onValueChange = { presetName = it.take(32) },
                        label = { Text("Preset name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = {
                                if (presetName.isBlank()) statusMessage = "Enter a preset name first"
                                else {
                                    presetRepo.save(presetName.trim(), channels)
                                    statusMessage = "Saved: ${presetName.trim()}"
                                }
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Save, null)
                            Spacer(Modifier.width(8.dp))
                            Text("Save Preset")
                        }
                        Button(
                            onClick = { showLoadDialog = true },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Settings, null)
                            Spacer(Modifier.width(8.dp))
                            Text("Load Preset")
                        }
                    }
                    if (statusMessage.isNotBlank()) {
                        Spacer(Modifier.height(10.dp))
                        Text(statusMessage, color = SamsungBlue)
                    }
                }
            }
        }
        item { Spacer(Modifier.height(8.dp)) }
    }

    if (showLoadDialog) {
        PresetDialog(
            names = presetRepo.names(),
            onDismiss = { showLoadDialog = false },
            onLoad = { name ->
                presetRepo.load(name)?.let { loaded ->
                    loaded.take(7).forEachIndexed { index, item -> onChannelUpdate(index, item) }
                    statusMessage = "Loaded: $name"
                }
                showLoadDialog = false
            },
            onDelete = { name ->
                presetRepo.delete(name)
                statusMessage = "Deleted: $name"
                showLoadDialog = false
            }
        )
    }
}

@Composable
private fun EqGraph(channel: EqChannel, selectedBand: Int) {
    Column {
        Canvas(
            modifier = Modifier.fillMaxWidth().height(230.dp).background(Color(0xFFFBFCFF), RoundedCornerShape(18.dp))
        ) {
            val w = size.width
            val h = size.height
            val left = 18f
            val right = w - 18f
            val top = 18f
            val bottom = h - 18f
            val stepX = (right - left) / 14f
            val centerY = (top + bottom) / 2f
            val scaleY = (bottom - top) / 24f

            for (i in 0..6) {
                val y = top + (bottom - top) * i / 6f
                drawLine(Color(0xFFE7ECF4), Offset(left, y), Offset(right, y), 1f)
            }
            for (i in 0..14) {
                val x = left + stepX * i
                drawLine(Color(0xFFF0F3F8), Offset(x, top), Offset(x, bottom), 1f)
            }

            val path = Path()
            channel.bands.forEachIndexed { index, b ->
                val x = left + stepX * index
                val y = centerY - b.gain * scaleY
                if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(path, SamsungBlue, style = Stroke(width = 4f, cap = StrokeCap.Round))

            channel.bands.forEachIndexed { index, b ->
                val x = left + stepX * index
                val y = centerY - b.gain * scaleY
                drawCircle(
                    color = if (index == selectedBand) Color.White else SamsungBlue,
                    radius = if (index == selectedBand) 10f else 7f,
                    center = Offset(x, y)
                )
                if (index == selectedBand) drawCircle(SamsungBlue, 7f, Offset(x, y))
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("20 Hz", color = Muted, fontSize = 12.sp)
            Text("0 dB center", color = Muted, fontSize = 12.sp)
            Text("20 kHz", color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun PresetDialog(
    names: List<String>,
    onDismiss: () -> Unit,
    onLoad: (String) -> Unit,
    onDelete: (String) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Load Preset") },
        text = {
            if (names.isEmpty()) Text("No presets saved yet.")
            else Column {
                names.forEach { name ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onLoad(name) }.padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(name, modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium)
                        IconButton(onClick = { onDelete(name) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete preset", tint = Pink)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

class PresetRepository(context: Context) {
    private val prefs = context.getSharedPreferences("okn_dsp_presets_v8", Context.MODE_PRIVATE)

    fun names(): List<String> = prefs.all.keys.sorted()

    fun save(name: String, channels: List<EqChannel>) {
        val root = JSONObject()
        val channelArray = JSONArray()
        channels.forEach { channel ->
            val c = JSONObject()
            c.put("name", channel.name)
            c.put("volume", channel.volume.toDouble())
            val bands = JSONArray()
            channel.bands.forEach { band ->
                bands.put(JSONObject().apply {
                    put("frequency", band.frequency.toDouble())
                    put("q", band.q.toDouble())
                    put("gain", band.gain.toDouble())
                })
            }
            c.put("bands", bands)
            channelArray.put(c)
        }
        root.put("channels", channelArray)
        prefs.edit().putString(name, root.toString()).apply()
    }

    fun load(name: String): List<EqChannel>? = runCatching {
        val text = prefs.getString(name, null) ?: return null
        val root = JSONObject(text)
        val channelArray = root.getJSONArray("channels")
        buildList {
            for (i in 0 until channelArray.length()) {
                val c = channelArray.getJSONObject(i)
                val bandArray = c.getJSONArray("bands")
                val bands = buildList {
                    for (j in 0 until bandArray.length()) {
                        val b = bandArray.getJSONObject(j)
                        add(EqBand(
                            frequency = b.getDouble("frequency").toFloat(),
                            q = b.getDouble("q").toFloat(),
                            gain = b.getDouble("gain").toFloat()
                        ))
                    }
                }
                add(EqChannel(
                    name = c.optString("name", "Ch${i + 1}"),
                    volume = c.optDouble("volume", 0.0).toFloat(),
                    bands = bands
                ))
            }
        }
    }.getOrNull()

    fun delete(name: String) {
        prefs.edit().remove(name).apply()
    }
}
