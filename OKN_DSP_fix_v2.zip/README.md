# OKN DSP Controller v2

แก้ปัญหา MethodChannel.receiveBroadcastStream() โดยใช้ EventChannel แยก:
- MethodChannel: okn_dsp/ble
- EventChannel: okn_dsp/events

Bluetooth:
- OKN-BT = Media / เล่นเพลง
- DSP-OKN = ควบคุม DSP
