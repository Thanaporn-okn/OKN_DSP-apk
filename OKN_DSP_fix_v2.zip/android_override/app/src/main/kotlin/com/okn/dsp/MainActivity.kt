package com.okn.dsp

import android.Manifest
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {

    private val METHOD_CHANNEL = "okn_dsp/ble"
    private val EVENT_CHANNEL = "okn_dsp/events"

    private var eventSink: EventChannel.EventSink? = null
    private var gatt: BluetoothGatt? = null
    private var writeCharacteristic: BluetoothGattCharacteristic? = null

    private fun emit(data: Map<String, Any?>) {
        runOnUiThread {
            eventSink?.success(data)
        }
    }

    private val scanCallback =
        object : ScanCallback() {

            override fun onScanResult(
                callbackType: Int,
                result: ScanResult
            ) {
                val device = result.device

                val name =
                    try {
                        device.name
                            ?: result.scanRecord?.deviceName
                            ?: ""
                    } catch (
                        _: SecurityException
                    ) {
                        ""
                    }

                if (name == "DSP-OKN") {
                    emit(
                        mapOf(
                            "type" to "scan",
                            "name" to name,
                            "address" to device.address,
                            "rssi" to result.rssi
                        )
                    )
                }
            }

            override fun onScanFailed(errorCode: Int) {
                emit(
                    mapOf(
                        "type" to "error",
                        "message" to
                            "BLE scan failed: $errorCode"
                    )
                )
            }
        }

    override fun configureFlutterEngine(
        engine: FlutterEngine
    ) {
        super.configureFlutterEngine(engine)

        EventChannel(
            engine.dartExecutor.binaryMessenger,
            EVENT_CHANNEL
        ).setStreamHandler(
            object : EventChannel.StreamHandler {

                override fun onListen(
                    arguments: Any?,
                    events: EventChannel.EventSink?
                ) {
                    eventSink = events
                }

                override fun onCancel(
                    arguments: Any?
                ) {
                    eventSink = null
                }
            }
        )

        MethodChannel(
            engine.dartExecutor.binaryMessenger,
            METHOD_CHANNEL
        ).setMethodCallHandler { call, result ->

            when (call.method) {

                "startScan" -> {
                    val seconds =
                        (call.argument<Int>("seconds")
                            ?: 8).coerceIn(3, 20)

                    startScan(seconds)
                    result.success(null)
                }

                "connect" -> {
                    val address =
                        call.argument<String>("address")

                    if (address == null) {
                        result.error(
                            "ARG",
                            "Missing Bluetooth address",
                            null
                        )
                    } else {
                        connect(address)
                        result.success(null)
                    }
                }

                "disconnect" -> {
                    disconnect()
                    result.success(null)
                }

                "readAll" -> {
                    readAll()
                    result.success(null)
                }

                "writeHex" -> {
                    writeHex(
                        call.argument<String>("hex") ?: ""
                    )
                    result.success(null)
                }

                else -> result.notImplemented()
            }
        }
    }

    private fun hasBluetoothPermission(): Boolean {

        return if (Build.VERSION.SDK_INT >= 31) {

            checkSelfPermission(
                Manifest.permission.BLUETOOTH_SCAN
            ) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(
                Manifest.permission.BLUETOOTH_CONNECT
            ) == PackageManager.PERMISSION_GRANTED

        } else {

            checkSelfPermission(
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun requestBluetoothPermission() {

        if (hasBluetoothPermission()) return

        if (Build.VERSION.SDK_INT >= 31) {

            requestPermissions(
                arrayOf(
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT
                ),
                1001
            )

        } else {

            requestPermissions(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION
                ),
                1001
            )
        }
    }

    private fun startScan(seconds: Int) {

        requestBluetoothPermission()

        if (!hasBluetoothPermission()) {
            emit(
                mapOf(
                    "type" to "error",
                    "message" =>
                        "กรุณาอนุญาต Bluetooth"
                )
            )
            return
        }

        val manager =
            getSystemService(
                Context.BLUETOOTH_SERVICE
            ) as BluetoothManager

        val adapter = manager.adapter

        if (adapter == null ||
            !adapter.isEnabled
        ) {
            emit(
                mapOf(
                    "type" to "error",
                    "message" =>
                        "กรุณาเปิด Bluetooth"
                )
            )
            return
        }

        val scanner =
            adapter.bluetoothLeScanner

        try {
            scanner.startScan(scanCallback)
        } catch (e: Exception) {
            emit(
                mapOf(
                    "type" to "error",
                    "message" =>
                        e.message ?: "scan error"
                )
            )
            return
        }

        Handler(Looper.getMainLooper())
            .postDelayed(
                {
                    try {
                        scanner.stopScan(scanCallback)
                    } catch (_: Exception) {
                    }
                },
                seconds * 1000L
            )
    }

    private fun connect(address: String) {

        requestBluetoothPermission()

        if (!hasBluetoothPermission()) {
            emit(
                mapOf(
                    "type" to "error",
                    "message" =>
                        "ไม่มีสิทธิ์ Bluetooth"
                )
            )
            return
        }

        try {

            gatt?.close()

            val device =
                BluetoothAdapter
                    .getDefaultAdapter()
                    .getRemoteDevice(address)

            gatt = if (Build.VERSION.SDK_INT >= 23) {
                device.connectGatt(
                    this,
                    false,
                    gattCallback,
                    BluetoothDevice.TRANSPORT_LE
                )
            } else {
                device.connectGatt(
                    this,
                    false,
                    gattCallback
                )
            }

            emit(
                mapOf(
                    "type" to "state",
                    "connected" to false,
                    "message" =>
                        "กำลังเชื่อมต่อ DSP-OKN..."
                )
            )

        } catch (e: Exception) {

            emit(
                mapOf(
                    "type" to "error",
                    "message" =>
                        e.message ?: "connect error"
                )
            )
        }
    }

    private val gattCallback =
        object : BluetoothGattCallback() {

            override fun onConnectionStateChange(
                g: BluetoothGatt,
                status: Int,
                newState: Int
            ) {

                if (newState ==
                    BluetoothProfile.STATE_CONNECTED
                ) {

                    gatt = g

                    emit(
                        mapOf(
                            "type" to "state",
                            "connected" to true,
                            "message" =>
                                "เชื่อมต่อ DSP-OKN แล้ว"
                        )
                    )

                    try {
                        g.discoverServices()
                    } catch (_: Exception) {
                    }

                } else {

                    writeCharacteristic = null

                    emit(
                        mapOf(
                            "type" to "state",
                            "connected" to false,
                            "message" =>
                                "ตัดการเชื่อมต่อ status=$status"
                        )
                    )
                }
            }

            override fun onServicesDiscovered(
                g: BluetoothGatt,
                status: Int
            ) {

                if (status !=
                    BluetoothGatt.GATT_SUCCESS
                ) {
                    emit(
                        mapOf(
                            "type" to "error",
                            "message" =>
                                "ค้นหา Service ไม่สำเร็จ: $status"
                        )
                    )
                    return
                }

                for (service in g.services) {

                    for (
                        characteristic
                        in service.characteristics
                    ) {

                        val properties =
                            mutableListOf<String>()

                        val p =
                            characteristic.properties

                        if (
                            p and
                            BluetoothGattCharacteristic
                                .PROPERTY_READ != 0
                        ) properties.add("READ")

                        if (
                            p and
                            BluetoothGattCharacteristic
                                .PROPERTY_WRITE != 0
                        ) properties.add("WRITE")

                        if (
                            p and
                            BluetoothGattCharacteristic
                                .PROPERTY_WRITE_NO_RESPONSE != 0
                        ) properties.add(
                            "WRITE_NO_RESPONSE"
                        )

                        if (
                            p and
                            BluetoothGattCharacteristic
                                .PROPERTY_NOTIFY != 0
                        ) properties.add("NOTIFY")

                        if (
                            p and
                            BluetoothGattCharacteristic
                                .PROPERTY_INDICATE != 0
                        ) properties.add("INDICATE")

                        emit(
                            mapOf(
                                "type" to
                                    "characteristic",
                                "service" to
                                    service.uuid.toString(),
                                "uuid" to
                                    characteristic.uuid.toString(),
                                "properties" to
                                    properties.joinToString(", ")
                            )
                        )

                        if (
                            writeCharacteristic == null &&
                            (
                                p and
                                (
                                    BluetoothGattCharacteristic
                                        .PROPERTY_WRITE or
                                    BluetoothGattCharacteristic
                                        .PROPERTY_WRITE_NO_RESPONSE
                                )
                            ) != 0
                        ) {
                            writeCharacteristic =
                                characteristic
                        }
                    }
                }
            }

            override fun onCharacteristicRead(
                g: BluetoothGatt,
                characteristic:
                    BluetoothGattCharacteristic,
                status: Int
            ) {

                if (
                    status ==
                    BluetoothGatt.GATT_SUCCESS
                ) {
                    emit(
                        mapOf(
                            "type" to "rx",
                            "hex" =>
                                characteristic.value
                                    .toHex()
                        )
                    )
                }
            }
        }

    private fun readAll() {

        val g = gatt ?: return

        if (!hasBluetoothPermission()) return

        for (service in g.services) {

            for (
                characteristic
                in service.characteristics
            ) {

                if (
                    characteristic.properties and
                    BluetoothGattCharacteristic
                        .PROPERTY_READ != 0
                ) {
                    try {
                        g.readCharacteristic(
                            characteristic
                        )
                    } catch (_: Exception) {
                    }
                }
            }
        }
    }

    private fun writeHex(text: String) {

        val g = gatt

        if (g == null) {
            emit(
                mapOf(
                    "type" to "error",
                    "message" =>
                        "ยังไม่ได้เชื่อมต่อ"
                )
            )
            return
        }

        val characteristic =
            writeCharacteristic

        if (characteristic == null) {
            emit(
                mapOf(
                    "type" to "error",
                    "message" =>
                        "ไม่พบ Characteristic สำหรับ WRITE"
                )
            )
            return
        }

        val bytes = parseHex(text)

        if (bytes == null) {
            emit(
                mapOf(
                    "type" to "error",
                    "message" =>
                        "HEX ไม่ถูกต้อง"
                )
            )
            return
        }

        try {

            characteristic.value = bytes

            characteristic.writeType =
                if (
                    characteristic.properties and
                    BluetoothGattCharacteristic
                        .PROPERTY_WRITE_NO_RESPONSE != 0
                ) {
                    BluetoothGattCharacteristic
                        .WRITE_TYPE_NO_RESPONSE
                } else {
                    BluetoothGattCharacteristic
                        .WRITE_TYPE_DEFAULT
                }

            g.writeCharacteristic(
                characteristic
            )

        } catch (e: Exception) {

            emit(
                mapOf(
                    "type" to "error",
                    "message" =>
                        e.message ?: "write error"
                )
            )
        }
    }

    private fun parseHex(text: String): ByteArray? {

        val clean = text
            .replace("0x", "", ignoreCase = true)
            .replace(
                "[^0-9A-Fa-f]".toRegex(),
                ""
            )

        if (
            clean.isEmpty() ||
            clean.length % 2 != 0
        ) return null

        return try {

            ByteArray(clean.length / 2) { i ->

                clean.substring(
                    i * 2,
                    i * 2 + 2
                ).toInt(16).toByte()
            }

        } catch (_: Exception) {
            null
        }
    }

    private fun ByteArray.toHex(): String {

        return joinToString(" ") {
            "%02X".format(
                it.toInt() and 0xFF
            )
        }
    }

    private fun disconnect() {

        try {
            gatt?.disconnect()
            gatt?.close()
        } catch (_: Exception) {
        }

        gatt = null
        writeCharacteristic = null

        emit(
            mapOf(
                "type" to "state",
                "connected" to false,
                "message" =>
                    "ตัดการเชื่อมต่อแล้ว"
            )
        )
    }
}
