import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() => runApp(const OknDspApp());

class OknDspApp extends StatelessWidget {
  const OknDspApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'OKN DSP',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const DspHomePage(),
    );
  }
}

class DspHomePage extends StatefulWidget {
  const DspHomePage({super.key});

  @override
  State<DspHomePage> createState() => _DspHomePageState();
}

class _DspHomePageState extends State<DspHomePage> {
  static const MethodChannel _ble =
      MethodChannel('okn_dsp/ble');

  static const EventChannel _events =
      EventChannel('okn_dsp/events');

  StreamSubscription? _subscription;

  bool _scanning = false;
  bool _connected = false;

  String _status = 'พร้อมค้นหา DSP-OKN';
  String _lastRx = '-';

  final List<Map<String, dynamic>> _devices = [];
  final List<Map<String, dynamic>> _chars = [];

  final TextEditingController _hex =
      TextEditingController(text: '01 00');

  @override
  void initState() {
    super.initState();

    _subscription = _events
        .receiveBroadcastStream()
        .listen(
      _onEvent,
      onError: (error) {
        if (!mounted) return;
        setState(() {
          _status = 'BLE ERROR: $error';
        });
      },
    );
  }

  void _onEvent(dynamic event) {
    if (!mounted) return;

    if (event is! Map) return;

    final Map<String, dynamic> e =
        Map<String, dynamic>.from(event);

    final type = e['type']?.toString();

    if (type == 'scan') {
      if (e['name']?.toString() == 'DSP-OKN') {
        final device = {
          'name': e['name'],
          'address': e['address'],
          'rssi': e['rssi'],
        };

        setState(() {
          _devices.removeWhere(
            (x) => x['address'] == device['address'],
          );
          _devices.add(device);
        });
      }
    }

    if (type == 'state') {
      setState(() {
        _connected = e['connected'] == true;
        _status = e['message']?.toString() ?? '';
      });
    }

    if (type == 'characteristic') {
      final item = {
        'service': e['service'] ?? '',
        'uuid': e['uuid'] ?? '',
        'properties': e['properties'] ?? '',
      };

      setState(() {
        _chars.add(item);
      });
    }

    if (type == 'rx') {
      setState(() {
        _lastRx = e['hex']?.toString() ?? '-';
      });
    }

    if (type == 'error') {
      setState(() {
        _status =
            'ERROR: ${e['message'] ?? 'unknown error'}';
      });
    }
  }

  @override
  void dispose() {
    _subscription?.cancel();
    _hex.dispose();
    super.dispose();
  }

  Future<void> _scan() async {
    setState(() {
      _devices.clear();
      _chars.clear();
      _scanning = true;
      _status = 'กำลังค้นหา DSP-OKN...';
    });

    try {
      await _ble.invokeMethod(
        'startScan',
        {'seconds': 8},
      );
    } catch (e) {
      if (mounted) {
        setState(() {
          _status = 'Scan ไม่ได้: $e';
        });
      }
    }

    if (mounted) {
      setState(() {
        _scanning = false;
      });
    }
  }

  Future<void> _connect(String address) async {
    setState(() {
      _status = 'กำลังเชื่อมต่อ DSP-OKN...';
    });

    try {
      await _ble.invokeMethod(
        'connect',
        {'address': address},
      );
    } catch (e) {
      if (mounted) {
        setState(() {
          _status = 'เชื่อมต่อไม่ได้: $e';
        });
      }
    }
  }

  Future<void> _disconnect() async {
    try {
      await _ble.invokeMethod('disconnect');
    } catch (_) {}
  }

  Future<void> _readAll() async {
    try {
      await _ble.invokeMethod('readAll');
    } catch (e) {
      setState(() {
        _status = 'อ่านไม่ได้: $e';
      });
    }
  }

  Future<void> _writeHex() async {
    try {
      await _ble.invokeMethod(
        'writeHex',
        {'hex': _hex.text.trim()},
      );

      setState(() {
        _status = 'ส่ง: ${_hex.text.trim()}';
      });
    } catch (e) {
      setState(() {
        _status = 'ส่งไม่ได้: $e';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('OKN DSP Controller'),
        actions: [
          IconButton(
            onPressed: _scanning ? null : _scan,
            icon: const Icon(
              Icons.bluetooth_searching,
            ),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              leading: Icon(
                _connected
                    ? Icons.bluetooth_connected
                    : Icons.bluetooth,
                color: _connected ? Colors.green : null,
              ),
              title: const Text('DSP-OKN'),
              subtitle: Text(_status),
              trailing: _connected
                  ? IconButton(
                      onPressed: _disconnect,
                      icon: const Icon(Icons.link_off),
                    )
                  : null,
            ),
          ),

          const SizedBox(height: 8),

          FilledButton.icon(
            onPressed: _scanning ? null : _scan,
            icon: const Icon(Icons.search),
            label: Text(
              _scanning
                  ? 'กำลังค้นหา...'
                  : 'ค้นหา DSP-OKN',
            ),
          ),

          const SizedBox(height: 12),

          if (_devices.isEmpty)
            const Text(
              'กดค้นหา แล้วเปิด Bluetooth ของบอร์ด\n'
              'ชื่อควรเป็น DSP-OKN',
              textAlign: TextAlign.center,
            ),

          ..._devices.map(
            (d) => Card(
              child: ListTile(
                leading: const Icon(Icons.memory),
                title: Text('${d['name']}'),
                subtitle: Text(
                  '${d['address']}   RSSI ${d['rssi']}',
                ),
                trailing: FilledButton(
                  onPressed: _connected
                      ? null
                      : () => _connect(
                            d['address'].toString(),
                          ),
                  child: const Text('เชื่อมต่อ'),
                ),
              ),
            ),
          ),

          const Divider(height: 32),

          const Text(
            'BLE Services / Characteristics',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 8),

          if (_chars.isEmpty)
            const Text(
              'ยังไม่ได้ค้นหา Characteristic',
            ),

          ..._chars.map(
            (c) => Card(
              child: ListTile(
                dense: true,
                title: Text('${c['uuid']}'),
                subtitle: Text(
                  'Service: ${c['service']}\n'
                  'Properties: ${c['properties']}',
                ),
              ),
            ),
          ),

          if (_connected) ...[
            const SizedBox(height: 12),

            OutlinedButton.icon(
              onPressed: _readAll,
              icon: const Icon(Icons.download),
              label: const Text(
                'อ่าน Characteristic ที่อ่านได้',
              ),
            ),

            const SizedBox(height: 16),

            TextField(
              controller: _hex,
              decoration: const InputDecoration(
                labelText: 'ข้อมูล HEX สำหรับทดสอบส่ง DSP',
                hintText: 'เช่น 01 00 FF',
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 8),

            FilledButton.icon(
              onPressed: _writeHex,
              icon: const Icon(Icons.send),
              label: const Text('ส่งข้อมูล HEX'),
            ),

            const SizedBox(height: 12),

            Text(
              'ข้อมูลล่าสุดจาก DSP: $_lastRx',
            ),
          ],

          const SizedBox(height: 24),

          const Text(
            'OKN-BT = Media / เล่นเพลง\n'
            'DSP-OKN = ควบคุม DSP\n\n'
            'ขั้นนี้จะค้นหา UUID และ protocol จริงก่อน '
            'จึงค่อยทำ EQ/Gain/Crossover สำหรับ BP1048P4',
            style: TextStyle(color: Colors.black54),
          ),
        ],
      ),
    );
  }
}
