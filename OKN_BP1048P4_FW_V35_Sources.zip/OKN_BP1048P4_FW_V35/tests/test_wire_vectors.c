#include "../src/core/okn_controller.h"
#include "../src/core/okn_protocol.h"
#include "../src/persist/okn_persistence.h"
#include <assert.h>
#include <ctype.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

static int hexval(int c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

static size_t load_hex(const char *path, uint8_t *out, size_t cap) {
    FILE *f = fopen(path, "rb");
    assert(f != NULL);
    size_t n = 0u;
    int hi = -1;
    int c;
    while ((c = fgetc(f)) != EOF) {
        if (isspace((unsigned char)c)) continue;
        const int v = hexval(c);
        assert(v >= 0);
        if (hi < 0) {
            hi = v;
        } else {
            assert(n < cap);
            out[n++] = (uint8_t)((hi << 4) | v);
            hi = -1;
        }
    }
    assert(fclose(f) == 0);
    assert(hi < 0);
    return n;
}

static void assert_bytes(const uint8_t *actual, size_t actual_len,
                         const char *golden_path) {
    uint8_t expected[OKN_PERSIST_IMAGE_SIZE + 64u];
    const size_t expected_len = load_hex(golden_path, expected, sizeof(expected));
    assert(actual_len == expected_len);
    assert(memcmp(actual, expected, actual_len) == 0);
}

int main(void) {
    uint8_t request[OKN_PROTO_MAX_PAYLOAD + 8u];
    uint8_t response[OKN_PROTO_MAX_PAYLOAD + 8u];
    size_t request_len = 0u;
    size_t response_len = 0u;
    okn_controller_t ctl;
    okn_controller_init(&ctl);

    request_len = load_hex("tests/golden/get_info_req.vec", request, sizeof(request));
    assert(request_len == 8u);
    assert(okn_protocol_execute(&ctl, request, request_len,
                                response, sizeof(response), &response_len) == OKN_OK);
    assert_bytes(response, response_len, "tests/golden/get_info_rsp.vec");

    request_len = load_hex("tests/golden/get_capabilities_req.vec", request, sizeof(request));
    assert(request_len == 8u);
    assert(okn_protocol_execute(&ctl, request, request_len,
                                response, sizeof(response), &response_len) == OKN_OK);
    assert_bytes(response, response_len, "tests/golden/get_capabilities_rsp.vec");

    request_len = load_hex("tests/golden/set_ch3_gain_neg3_5_req.vec", request, sizeof(request));
    assert(request_len == 13u);
    assert(okn_protocol_execute(&ctl, request, request_len,
                                response, sizeof(response), &response_len) == OKN_OK);
    assert(fabsf(ctl.state.ch[3].gain_db - (-3.5f)) < 0.0001f);
    assert(ctl.revision == 1u);
    assert_bytes(response, response_len, "tests/golden/set_ch3_gain_neg3_5_ack.vec");

    okn_controller_t defaults;
    okn_controller_init(&defaults);
    uint8_t image[OKN_PERSIST_IMAGE_SIZE];
    size_t image_len = 0u;
    assert(okn_persist_encode(&defaults.state, 0x01020304u,
                              image, sizeof(image), &image_len) == OKN_OK);
    assert(image_len == OKN_PERSIST_IMAGE_SIZE);
    assert_bytes(image, image_len, "tests/golden/persist_default_gen01020304.vec");

    uint8_t frozen[OKN_PERSIST_IMAGE_SIZE];
    const size_t frozen_len = load_hex("tests/golden/persist_default_gen01020304.vec",
                                       frozen, sizeof(frozen));
    okn_dsp_state_t decoded;
    uint32_t generation = 0u;
    assert(frozen_len == OKN_PERSIST_IMAGE_SIZE);
    assert(okn_persist_decode(frozen, frozen_len, &decoded, &generation) == OKN_OK);
    assert(generation == 0x01020304u);
    assert(decoded.master_gain_db == 0.0f);
    assert(decoded.ch[0].gain_db == 0.0f);
    assert(decoded.ch[6].delay_ms == 0.0f);

    puts("ALL V35 WIRE/PERSISTENCE GOLDEN VECTOR TESTS PASS");
    return 0;
}
