#include "portability/okn_toolchain_contract.h"
#include "core/okn_version.h"
#include "persist/okn_persistence.h"

/* Compile-only probe: no main(), no linker, no execution. */
int okn_toolchain_compile_probe(void) {
    return (int)(OKN_FW_VERSION + OKN_PROTO_VERSION + OKN_PERSIST_SCHEMA);
}
