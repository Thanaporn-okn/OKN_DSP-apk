# OKN_BP1048P4_FW_V35

V35 closes a same-stream callback re-entrancy hole in the portable BLE-like parser while keeping Protocol V2 and persistence schema 2 unchanged.

## What V35 adds

- Every CRC-valid frame is copied to a bounded local snapshot and removed from the parser buffer **before** application callback invocation.
- Recursive `okn_stream_feed()` on the same parser while its callback is active is rejected with `OKN_ERR_REENTRANT`.
- Adds `dispatch_active` and `reentrant_rejections` diagnostics; no hardware clock, BLE timing, address, pin, or programmer semantics are introduced.
- Adds a mutating `SET_CH_GAIN` regression proving recursive feed cannot redispatch the same frame or increment controller revision twice.
- Preserves V34 callback-error exactly-once behavior and concatenated-frame ordering.
- V34 Source ZIP and uploaded GitHub validation Artifact are bound as the immediate predecessor.

## Safety status

This package is **not** a BP1048P4/GoloPine flash image. It emits no programmer packet, does not invoke a target linker, and contains no guessed BP1048P4 address, pin, boot command, memory capacity, or image format. Hardware and mobile flashing remain locked.

Run:

```sh
make host-test
```
