#!/usr/bin/env python3
from pathlib import Path
import json, sys
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'tools'))
from hardware_discovery import load_and_verify
m=json.loads((root/'hardware_discovery_manifest.json').read_text())
r=load_and_verify(root/'hardware_discovery_manifest.json',root)
errors=[]
if not r['ok']: errors.extend(r['errors'])

if m.get('android_capture_schema')!='android_discovery_capture_schema.json': errors.append('Android capture schema link missing')
if m.get('android_capture_importer')!='tools/import_android_discovery.py': errors.append('Android capture importer link missing')
if m.get('safety',{}).get('canonical_capture_hash_required') is not True: errors.append('canonical capture hash safety flag missing')
if m.get('state')!='LOCKED_NO_CAPTURE': errors.append('shipped V35 discovery state must remain LOCKED_NO_CAPTURE')
if m.get('captures')!=[]: errors.append('shipped V35 discovery captures must remain empty')
if r['review_ready'] or r['programmer_io_available']: errors.append('shipped V35 discovery must not enable hardware IO')
if errors:
    [print('BLOCKED:',e) for e in errors]; sys.exit(1)
print('PASS: V35 read-only hardware discovery is content-bound, non-authorizing, and emits no programmer IO')
