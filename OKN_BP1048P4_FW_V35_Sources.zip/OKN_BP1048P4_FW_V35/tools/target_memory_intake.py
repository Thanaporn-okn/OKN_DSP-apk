#!/usr/bin/env python3
"""V35 read-only target linker/memory evidence intake.

This tool parses GNU-style MEMORY region declarations from a supplied linker script
or text map. It performs no target execution, no linker invocation, no hardware I/O,
and never authorizes BP1048P4/GoloPine hardware by itself.
"""
from __future__ import annotations
import argparse, hashlib, json, re, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
REPORT=ROOT/'target_memory_report.json'

REGION_RE=re.compile(
    r"^\s*([A-Za-z_][A-Za-z0-9_.-]*)\s*(?:\([^)]*\))?\s*:\s*"
    r"ORIGIN\s*=\s*([^,]+),\s*LENGTH\s*=\s*([^\s}]+)", re.I)


def sha256_file(path:Path)->str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()


def parse_num(s:str):
    s=s.strip().replace('_','')
    m=re.fullmatch(r'(0[xX][0-9A-Fa-f]+|[0-9]+)([KkMm]?)',s)
    if not m: return None
    v=int(m.group(1),0)
    unit=m.group(2).lower()
    if unit=='k': v*=1024
    elif unit=='m': v*=1024*1024
    return v


def parse_memory_regions(text:str):
    # Strip C comments and // comments conservatively; values are accepted only as literals.
    t=re.sub(r'/\*.*?\*/','',text,flags=re.S)
    t=re.sub(r'//.*','',t)
    regions=[]
    in_mem=False
    depth=0
    for line in t.splitlines():
        if not in_mem:
            if re.search(r'\bMEMORY\b',line):
                in_mem=True
                depth += line.count('{')-line.count('}')
            continue
        depth += line.count('{')-line.count('}')
        m=REGION_RE.match(line)
        if m:
            origin=parse_num(m.group(2))
            length=parse_num(m.group(3))
            regions.append({
                'name':m.group(1),
                'origin_literal':m.group(2).strip(),
                'length_literal':m.group(3).strip(),
                'origin_value':origin,
                'length_bytes':length,
                'literal_values_only': origin is not None and length is not None,
            })
        if depth<=0 and '}' in line:
            break
    return regions


def locked_ok(m):
    return (
        m.get('project_version')==35 and
        m.get('state')=='LOCKED_NO_EXACT_TARGET_LINKER_ARTIFACT' and
        m.get('artifact') is None and
        m.get('parsed_regions')==[] and
        m.get('review_ready') is False and
        m.get('exact_ram_capacity_verified') is False and
        m.get('authorizes_hardware') is False and
        m.get('authorizes_mobile_flash') is False
    )


def build_report(path:Path, classification:str, reviewed:bool):
    raw=path.read_bytes()
    text=raw.decode('utf-8',errors='replace')
    regions=parse_memory_regions(text)
    exact=classification=='EXACT_TARGET'
    # Parsing and review can make a document ready for claim mapping, but this tool
    # never asserts RAM capacity or placement and never authorizes hardware.
    state = ('PARSED_EXACT_TARGET_REVIEWED_NON_AUTHORIZING' if exact and reviewed
             else 'PARSED_EXACT_TARGET_UNREVIEWED_NON_AUTHORIZING' if exact
             else 'PARSED_FAMILY_ONLY_NON_AUTHORIZING')
    return {
      'schema':1,'project_version':35,'target':'BP1048P4','board':'GoloPine 7CH',
      'policy':'CONTENT_BOUND_READ_ONLY_LINKER_MEMORY_INTAKE_NO_INFERENCE',
      'state':state,
      'artifact':{
        'path':path.name,'sha256':hashlib.sha256(raw).hexdigest(),
        'size_bytes':len(raw),'classification':classification,'reviewed':bool(reviewed)
      },
      'parsed_regions':regions,
      'review_ready': bool(exact and reviewed and regions),
      'exact_ram_capacity_verified':False,
      'delay_arena_placement_verified':False,
      'persistence_workspace_verified':False,
      'authorizes_hardware':False,'authorizes_mobile_flash':False,
      'notes':'Parsed values are evidence observations only. Region semantics/capacity/placement require separate content-bound claim review.'
    }


def main():
    ap=argparse.ArgumentParser(description='Read-only V35 linker/memory evidence intake; never programs hardware.')
    ap.add_argument('--expect-locked',action='store_true')
    ap.add_argument('--input',type=Path)
    ap.add_argument('--classification',choices=['FAMILY_ONLY','EXACT_TARGET'],default='FAMILY_ONLY')
    ap.add_argument('--reviewed',action='store_true')
    ap.add_argument('--output',type=Path)
    a=ap.parse_args()
    if a.expect_locked:
        m=json.loads(REPORT.read_text(encoding='utf-8'))
        if not locked_ok(m):
            print('ERROR: shipped V35 target-memory report is not locked/empty',file=sys.stderr); return 1
        print('TARGET_MEMORY_INTAKE=LOCKED_NO_EXACT_TARGET_LINKER_ARTIFACT')
        print('PASS: V35 target-memory intake is read-only, value-empty, and non-authorizing')
        return 0
    if not a.input or not a.input.is_file():
        ap.error('--input existing file is required unless --expect-locked is used')
    r=build_report(a.input,a.classification,a.reviewed)
    out=json.dumps(r,indent=2,sort_keys=True)+'\n'
    if a.output: a.output.write_text(out,encoding='utf-8')
    else: print(out,end='')
    return 0

if __name__=='__main__': raise SystemExit(main())
