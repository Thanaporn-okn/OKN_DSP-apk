#!/usr/bin/env python3
"""V35 discovery-review packet derivation.

Consumes the V35 read-only discovery/fingerprint manifests and emits a
content-bound review packet. Stable observations remain observations only;
this module never promotes target claims, authorizes hardware, or emits
programmer I/O.
"""
from __future__ import annotations
from pathlib import Path
import argparse, hashlib, json

PROJECT_VERSION = 35
SCHEMA = 1
POLICY = "STABLE_OBSERVATION_REVIEW_PACKET_NO_AUTOMATIC_PROMOTION"


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _review_scope(transport: str) -> list[str]:
    if transport in ("usb_host", "serial_enumeration"):
        return ["android_host_transport_observation"]
    if transport == "ble":
        return ["ble_transport_observation"]
    return []


def build_manifest(root: Path) -> dict:
    root = Path(root).resolve()
    fp_path = root / "transport_fingerprint_manifest.json"
    hd_path = root / "hardware_discovery_manifest.json"
    fp = json.loads(fp_path.read_text())
    hd = json.loads(hd_path.read_text())
    if fp.get("project_version") != PROJECT_VERSION:
        raise ValueError("fingerprint project_version mismatch")
    if hd.get("project_version") != PROJECT_VERSION:
        raise ValueError("hardware discovery project_version mismatch")

    packets = []
    for transport, rec in sorted(fp.get("transports", {}).items()):
        if rec.get("state") != "OBSERVED_STABLE":
            continue
        stable = rec.get("stable_fingerprint_sha256")
        bindings = rec.get("capture_bindings", [])
        packets.append({
            "packet_id": f"{transport}:{stable[:16] if isinstance(stable,str) else 'invalid'}",
            "transport": transport,
            "observation_state": "OBSERVED_STABLE",
            "session_count": rec.get("session_count", 0),
            "stable_fingerprint_sha256": stable,
            "capture_ids": [x.get("capture_id") for x in bindings],
            "capture_raw_sha256": [x.get("raw_sha256") for x in bindings],
            "review_scope": _review_scope(transport),
            "review_state": "PENDING_HUMAN_REVIEW",
            "reviewed": False,
            "approved": False,
            "exact_target_claims_granted": [],
            "can_promote_target_qualification": False,
            "hardware_authorized": False,
            "mobile_flash_authorized": False,
        })

    state = "LOCKED_NO_STABLE_OBSERVATION" if not packets else "REVIEW_PACKET_AVAILABLE_NOT_AUTHORIZED"
    return {
        "schema": SCHEMA,
        "project_version": PROJECT_VERSION,
        "target": "BP1048P4",
        "board": "GoloPine 7CH",
        "policy": POLICY,
        "state": state,
        "automatic_promotion": False,
        "automatic_authorization": False,
        "hardware_authorized": False,
        "mobile_flash_authorized": False,
        "programmer_io_available": False,
        "destructive_executor_available": False,
        "bindings": {
            "transport_fingerprint_manifest_sha256": sha256_file(fp_path),
            "hardware_discovery_manifest_sha256": sha256_file(hd_path),
        },
        "review_packets": packets,
        "boundary": {
            "stable_observation_is_exact_chip_proof": False,
            "stable_observation_is_exact_board_proof": False,
            "stable_observation_is_programmer_transport_proof": False,
            "human_review_required_before_any_evidence_promotion": True,
            "content_bound_exact_evidence_still_required": True,
            "explicit_authorization_still_required": True,
        },
    }


def verify(root: Path, manifest: dict | None = None) -> dict:
    root = Path(root).resolve()
    if manifest is None:
        manifest = json.loads((root / "discovery_review_manifest.json").read_text())
    expected = build_manifest(root)
    errors = []
    if manifest != expected:
        errors.append("discovery review manifest is stale or not derived from current fingerprint/discovery inputs")
    if manifest.get("automatic_promotion") is not False:
        errors.append("automatic promotion must remain false")
    if manifest.get("automatic_authorization") is not False:
        errors.append("automatic authorization must remain false")
    if manifest.get("hardware_authorized") is not False or manifest.get("mobile_flash_authorized") is not False:
        errors.append("discovery review must not authorize hardware/mobile flash")
    if manifest.get("programmer_io_available") is not False or manifest.get("destructive_executor_available") is not False:
        errors.append("review layer may not provide programmer/destructive IO")
    for packet in manifest.get("review_packets", []):
        if packet.get("exact_target_claims_granted") != []:
            errors.append("review packet may not grant exact target claims")
        if packet.get("can_promote_target_qualification") is not False:
            errors.append("review packet may not auto-promote target qualification")
        if packet.get("reviewed") is not False or packet.get("approved") is not False:
            errors.append("derived packet must remain pending human review")
    return {"ok": not errors, "errors": errors, "state": manifest.get("state")}


def main() -> int:
    ap = argparse.ArgumentParser(description="Derive/verify V35 stable-observation review packets; no hardware I/O.")
    ap.add_argument("--root", default=".")
    ap.add_argument("--write", action="store_true")
    ap.add_argument("--expect-empty", action="store_true")
    args = ap.parse_args()
    root = Path(args.root).resolve()
    if args.write:
        (root / "discovery_review_manifest.json").write_text(json.dumps(build_manifest(root), indent=2) + "\n")
    result = verify(root)
    print("DISCOVERY_REVIEW=" + str(result["state"]))
    for e in result["errors"]:
        print("BLOCKED:" + e)
    if args.expect_empty:
        m = json.loads((root / "discovery_review_manifest.json").read_text())
        if m.get("state") != "LOCKED_NO_STABLE_OBSERVATION" or m.get("review_packets") != []:
            print("ERROR: shipped V35 review bundle must remain empty/locked")
            return 1
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
