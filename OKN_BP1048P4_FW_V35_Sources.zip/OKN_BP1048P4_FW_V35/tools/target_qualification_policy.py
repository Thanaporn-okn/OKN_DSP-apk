#!/usr/bin/env python3
"""Pure V35 target-qualification policy with content-bound artifact linkage."""
import re
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
CLAIM_CLASSES = {
    "exact_chip_identity": {"EXACT_TARGET"},
    "exact_golopine_board_identity": {"EXACT_BOARD"},
    "startup": {"EXACT_TARGET"},
    "linker_memory_map": {"EXACT_TARGET"},
    "flash_programmer": {"EXACT_TOOLING"},
    "programmer_transport": {"EXACT_TOOLING"},
    "image_layout": {"EXACT_TARGET", "EXACT_TOOLING"},
    "image_format": {"EXACT_TARGET", "EXACT_TOOLING"},
    "recovery_path": {"EXACT_TOOLING", "EXACT_BOARD_TEST"},
    "power_safety": {"EXACT_BOARD", "EXACT_BOARD_TEST"},
    "board_pin_map": {"EXACT_BOARD"},
    "audio_api": {"EXACT_TARGET"},
    "board_audio_route": {"EXACT_BOARD"},
    "output_safety_mute": {"EXACT_BOARD", "EXACT_BOARD_TEST"},
    "ble_api": {"EXACT_TARGET"},
    "board_ble_route": {"EXACT_BOARD"},
    "nvm_api": {"EXACT_TARGET"},
    "board_nvm_layout": {"EXACT_BOARD"},
    "original_firmware_backup_readback": {"EXACT_BOARD_TEST"},
    "post_flash_readback_verify": {"EXACT_BOARD_TEST"},
    "exact_ram_capacity": {"EXACT_TARGET"},
    "delay_arena_placement": {"EXACT_TARGET", "EXACT_BOARD"},
    "persistence_workspace_strategy": {"EXACT_TARGET", "EXACT_BOARD"},
    "platform_init_output_safe": {"EXACT_BOARD", "EXACT_BOARD_TEST"},
    "android_host_transport": {"EXACT_MOBILE_TRANSPORT"},
}
HARDWARE_CLAIMS = tuple(k for k in CLAIM_CLASSES if k != "android_host_transport")
MOBILE_CLAIMS = HARDWARE_CLAIMS + ("android_host_transport",)

def record_is_qualified(claim, record, verified_artifacts=None):
    if claim not in CLAIM_CLASSES or not isinstance(record,dict): return False
    if record.get('verified') is not True or record.get('reviewed') is not True: return False
    classification=record.get('classification')
    if classification not in CLAIM_CLASSES[claim]: return False
    sha=str(record.get('artifact_sha256') or '').lower()
    if not SHA256_RE.fullmatch(sha): return False
    if not str(record.get('source') or '').strip() or not str(record.get('evidence_locator') or '').strip(): return False
    aid=record.get('artifact_id')
    if not isinstance(aid,str) or not aid: return False
    if not isinstance(verified_artifacts,dict): return False
    artifact=verified_artifacts.get(aid)
    if not isinstance(artifact,dict): return False
    if artifact.get('sha256') != sha: return False
    if artifact.get('source') != record.get('source'): return False
    if artifact.get('reviewed') is not True: return False
    if classification not in set(artifact.get('classifications') or ()): return False
    return True

def evaluate(manifest, verified_artifacts=None):
    claims=manifest.get('claims',{})
    qualified={name:record_is_qualified(name,claims.get(name),verified_artifacts) for name in CLAIM_CLASSES}
    hardware_complete=all(qualified.get(k,False) for k in HARDWARE_CLAIMS)
    mobile_complete=all(qualified.get(k,False) for k in MOBILE_CLAIMS)
    hardware_ready=hardware_complete and manifest.get('hardware_authorized') is True
    mobile_ready=hardware_ready and mobile_complete and manifest.get('mobile_flash_authorized') is True
    return {
      'qualified':qualified,
      'hardware_complete':hardware_complete,
      'mobile_complete':mobile_complete,
      'hardware_ready':hardware_ready,
      'mobile_ready':mobile_ready,
      'hardware_missing':[k for k in HARDWARE_CLAIMS if not qualified.get(k,False)],
      'mobile_missing':[k for k in MOBILE_CLAIMS if not qualified.get(k,False)],
    }
