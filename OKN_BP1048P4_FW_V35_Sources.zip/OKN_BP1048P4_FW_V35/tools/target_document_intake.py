#!/usr/bin/env python3
"""V35 read-only exact-target document intake.

Hashes supplied document bytes (and, optionally, a reviewed extracted-text companion)
and records source provenance. A filename, public listing, or caller-provided classification
never authorizes hardware. This tool performs no network access, target I/O, linking,
programmer I/O, or firmware image generation.
"""
from __future__ import annotations
import argparse, hashlib, json, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
MANIFEST=ROOT/'target_document_manifest.json'
TARGET_TOKEN='BP1048P4'


def sha256_file(path:Path)->str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):
            h.update(b)
    return h.hexdigest()


def token_in_bytes(path:Path, token:str=TARGET_TOKEN)->bool:
    # Deliberately conservative: no OCR, no PDF parser, no inference. This only catches
    # a literal token present in the bytes/text supplied to the intake.
    return token.encode('ascii') in path.read_bytes().upper()


def build_record(path:Path, source:str, classification:str, reviewed:bool=False,
                 text_evidence:Path|None=None)->dict:
    raw_sha=sha256_file(path)
    filename_mentions=TARGET_TOKEN.lower() in path.name.lower()
    raw_token=token_in_bytes(path)
    text_rec=None
    text_token=False
    if text_evidence is not None:
        if not text_evidence.is_file():
            raise ValueError('text evidence file does not exist')
        text_token=token_in_bytes(text_evidence)
        text_rec={
            'path':text_evidence.name,
            'sha256':sha256_file(text_evidence),
            'size_bytes':text_evidence.stat().st_size,
            'target_token_observed':text_token,
        }
    exact_candidate=classification=='EXACT_TARGET_CANDIDATE'
    content_anchor=raw_token or text_token
    review_ready=bool(exact_candidate and reviewed and content_anchor)
    if exact_candidate and reviewed and content_anchor:
        state='REVIEWED_EXACT_TARGET_DOCUMENT_CONTENT_ANCHORED_NON_AUTHORIZING'
    elif exact_candidate:
        state='EXACT_TARGET_CANDIDATE_NOT_CONTENT_VERIFIED_NON_AUTHORIZING'
    else:
        state='FAMILY_OR_OTHER_DOCUMENT_NON_AUTHORIZING'
    return {
        'schema':1,'project_version':35,'target':'BP1048P4','board':'GoloPine 7CH',
        'policy':'CONTENT_BOUND_DOCUMENT_BYTES_REVIEW_REQUIRED_NO_FILENAME_AUTHORIZATION',
        'state':state,
        'document':{
            'path':path.name,'sha256':raw_sha,'size_bytes':path.stat().st_size,
            'source':source,'classification':classification,'reviewed':bool(reviewed),
            'filename_mentions_target':filename_mentions,
            'raw_bytes_target_token_observed':raw_token,
        },
        'text_evidence':text_rec,
        'content_anchor_observed':content_anchor,
        'review_ready_for_claim_mapping':review_ready,
        'promoted_claims':[],
        'exact_chip_identity_verified':False,
        'linker_memory_map_verified':False,
        'programmer_transport_verified':False,
        'image_format_verified':False,
        'board_pin_map_verified':False,
        'authorizes_hardware':False,'authorizes_mobile_flash':False,
        'notes':'Filename/listing/classification cannot authorize. Review-ready only means content-bound human claim mapping may begin in a separate step.'
    }


def locked_ok(m:dict)->bool:
    return (
        m.get('schema')==1 and m.get('project_version')==35 and
        m.get('state')=='LOCKED_NO_EXACT_TARGET_DOCUMENT' and
        m.get('documents')==[] and m.get('promoted_claims')==[] and
        m.get('exact_target_document_content_verified') is False and
        m.get('reviewed_claim_mapping_complete') is False and
        m.get('authorizes_hardware') is False and
        m.get('authorizes_mobile_flash') is False
    )


def main()->int:
    ap=argparse.ArgumentParser(description='Read-only V35 exact-target document intake; never authorizes hardware.')
    ap.add_argument('--expect-locked',action='store_true')
    ap.add_argument('--input',type=Path)
    ap.add_argument('--text-evidence',type=Path)
    ap.add_argument('--source',default='unspecified')
    ap.add_argument('--classification',choices=['FAMILY_OR_OTHER','EXACT_TARGET_CANDIDATE'],default='FAMILY_OR_OTHER')
    ap.add_argument('--reviewed',action='store_true')
    ap.add_argument('--output',type=Path)
    a=ap.parse_args()
    if a.expect_locked:
        m=json.loads(MANIFEST.read_text(encoding='utf-8'))
        if not locked_ok(m):
            print('ERROR: shipped V35 target document manifest is not locked/empty',file=sys.stderr)
            return 1
        print('TARGET_DOCUMENT_INTAKE=LOCKED_NO_EXACT_TARGET_DOCUMENT')
        print('PASS: V35 exact-target document intake is content-bound-ready and non-authorizing')
        return 0
    if not a.input or not a.input.is_file():
        ap.error('--input existing file is required unless --expect-locked is used')
    rec=build_record(a.input,a.source,a.classification,a.reviewed,a.text_evidence)
    out=json.dumps(rec,indent=2,sort_keys=True,ensure_ascii=False)+'\n'
    if a.output: a.output.write_text(out,encoding='utf-8')
    else: print(out,end='')
    return 0

if __name__=='__main__': raise SystemExit(main())
