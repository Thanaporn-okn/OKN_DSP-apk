#!/usr/bin/env python3
from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[1]
fm=json.loads((root/'firmware_manifest.json').read_text())
tm=json.loads((root/'target_port_manifest.json').read_text())
errors=[]
ts=fm.get('transport_safety',{})
sb=fm.get('safe_boot',{})
if ts.get('partial_frame_idle_reset') is not True: errors.append('partial-frame idle reset must be declared')
if ts.get('transport_supplies_elapsed_time') is not True: errors.append('portable parser must not own/guess a target clock')
if ts.get('timeout_value_target_specific') is not True: errors.append('timeout value must remain transport/target policy')
if sb.get('platform_init_output_safe_evidence_required') is not True: errors.append('safe boot must require platform_init output-safe evidence')
if tm.get('evidence',{}).get('platform_init_output_safe') is not False: errors.append('platform_init_output_safe target evidence must remain locked')
h=(root/'src/hal/bp1048p4_port_contract.h').read_text()
if 'BP1048P4_PORT_ABI_VERSION 2u' not in h: errors.append('port ABI must remain ABI 2')
if 'platform_init_output_safe_verified' not in h: errors.append('port contract missing safe-init evidence')
sh=(root/'src/transport/okn_stream.h').read_text()
for sym in ('okn_stream_note_idle','okn_stream_reset_partial','timeout_resets','callback_errors','dispatch_active','reentrant_rejections'):
    if sym not in sh: errors.append('stream safety symbol missing: '+sym)
for key in ('validated_frame_exactly_once_dispatch','callback_error_implicit_redispatch_prevented','validated_frame_snapshot_before_callback','validated_frame_consumed_before_callback','same_stream_reentrant_feed_rejected'):
    if ts.get(key) is not True: errors.append(key+' must be declared')
sc=(root/'src/transport/okn_stream.c').read_text()
copy=sc.find('memcpy(frame_copy, s->buf, frame_len);')
consume=sc.find('memmove(s->buf, s->buf + frame_len', copy)
active=sc.find('s->dispatch_active = true;', consume)
callback=sc.find('cb ? cb(user, frame_copy, frame_len)', active)
if min(copy,consume,active,callback) < 0 or not (copy < consume < active < callback):
    errors.append('validated frame must be snapshotted and consumed before callback invocation')
if 'if (s->dispatch_active)' not in sc or 'return OKN_ERR_REENTRANT;' not in sc:
    errors.append('same-stream recursive feed guard missing')
if errors:
    [print('BLOCKED:',e) for e in errors]; sys.exit(1)
print('PASS: V35 stream snapshots+consumes valid frames before callback, rejects same-stream reentrancy, and remains fail-closed')
