#!/usr/bin/env python3
from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'evidence_manifest.json').read_text())
errors=[]
if m.get('schema')!=4: errors.append('evidence schema must be 4')
if m.get('project_version')!=35: errors.append('project_version must be 35')
if m.get('target')!='BP1048P4' or m.get('board')!='GoloPine 7CH': errors.append('target/board mismatch')
if m.get('policy')!='FAIL_CLOSED_NO_INFERENCE': errors.append('policy mismatch')
if m.get('hardware_authorized') is not False: errors.append('hardware_authorized must be false')
req=m.get('required_exact_evidence',{})
if any(bool(v) for v in req.values()): errors.append('V35 exact evidence flags must all remain false')
prov=m.get('provenance',{})
if prov.get('previous_source_sha256')!='501c2cbabaaab5b7471e1e7ba9f7b182e1d4d9bb9e7717dc75c9b46f6cb50642': errors.append('V34 source provenance mismatch')
if prov.get('validation_zip_sha256')!='dfc5cb35bb9579a3d3a73a120182324cd6801465aec080e152c617dade9f5410': errors.append('V34 validation provenance mismatch')
if not any(o.get('id')=='v34-ci-validation' for o in m.get('observations',[])): errors.append('V34 CI observation missing')
for ob in m.get('observations',[]):
    if ob.get('authorizes') not in ([],None): errors.append('observations may not authorize hardware in V35')
if errors:
    [print('BLOCKED:',e) for e in errors]; sys.exit(1)
print('PASS: V35 evidence manifest is internally consistent and non-authorizing')
