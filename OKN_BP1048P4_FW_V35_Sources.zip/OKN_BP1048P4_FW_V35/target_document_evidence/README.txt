V33 exact-target document evidence intake directory.

Place only user/vendor-supplied document bytes or reviewed extracted-text companions here.
Filename/title matches are never treated as exact BP1048P4 evidence by themselves.
Every accepted artifact must be content-bound by SHA-256 and source provenance.
The shipped V33 bundle intentionally contains no BP1048P4 datasheet/programmer document bytes.
