#ifndef OKN_TOOLCHAIN_CONTRACT_H
#define OKN_TOOLCHAIN_CONTRACT_H

#include <float.h>
#include <limits.h>
#include <stdint.h>

/* Portable-core compile contract. These are language/ABI requirements only.
 * Passing them does NOT prove BP1048P4 compatibility, board routing, linker
 * placement, image format, programmer transport, or flash safety. */
_Static_assert(CHAR_BIT == 8, "OKN requires 8-bit bytes");
_Static_assert(sizeof(uint8_t) == 1u && UINT8_MAX == 0xFFu,
               "OKN requires exact uint8_t");
_Static_assert(sizeof(uint16_t) == 2u && UINT16_MAX == 0xFFFFu,
               "OKN requires exact uint16_t");
_Static_assert(sizeof(uint32_t) == 4u && UINT32_MAX == 0xFFFFFFFFu,
               "OKN requires exact uint32_t");
_Static_assert(sizeof(int32_t) == 4u && INT32_MAX == 2147483647,
               "OKN requires exact int32_t");

/* Persistence serializes float bit patterns explicitly as little-endian u32.
 * Therefore a target compiler must implement IEEE-754 binary32-compatible
 * float semantics, not merely a 4-byte object representation. */
_Static_assert(sizeof(float) == 4u, "OKN persistence requires 32-bit float");
_Static_assert(FLT_RADIX == 2, "OKN persistence requires binary float radix");
_Static_assert(FLT_MANT_DIG == 24, "OKN persistence requires binary32 precision");
_Static_assert(FLT_MAX_EXP == 128, "OKN persistence requires binary32 max exponent");
_Static_assert(FLT_MIN_EXP == -125, "OKN persistence requires binary32 min exponent");

#endif
