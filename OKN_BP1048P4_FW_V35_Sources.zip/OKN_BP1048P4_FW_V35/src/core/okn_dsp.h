#ifndef OKN_DSP_H
#define OKN_DSP_H

#include "okn_params.h"
#include <stddef.h>

typedef enum {
    OKN_OK = 0,
    OKN_ERR_ARG = -1,
    OKN_ERR_RANGE = -2,
    OKN_ERR_UNSUPPORTED = -3,
    OKN_ERR_CRC = -4,
    OKN_ERR_FORMAT = -5,
    OKN_ERR_HAL_LOCKED = -6,
    OKN_ERR_HAL = -7,
    OKN_ERR_BUFFER = -8,
    OKN_ERR_STORAGE = -9,
    OKN_ERR_STATE_CRC = -10,
    OKN_ERR_STATE_SCHEMA = -11,
    OKN_ERR_REENTRANT = -12
} okn_status_t;

void okn_dsp_init(okn_dsp_state_t *state);
okn_status_t okn_validate_state(const okn_dsp_state_t *state);
okn_status_t okn_set_master_gain(okn_dsp_state_t *state, float db);
okn_status_t okn_set_channel_gain(okn_dsp_state_t *state, unsigned channel, float db);
okn_status_t okn_set_channel_mute(okn_dsp_state_t *state, unsigned channel, bool mute);
okn_status_t okn_set_channel_phase(okn_dsp_state_t *state, unsigned channel, bool invert);
okn_status_t okn_set_channel_delay(okn_dsp_state_t *state, unsigned channel, float ms);
okn_status_t okn_set_peq_band(okn_dsp_state_t *state, unsigned channel, unsigned band,
                              bool enabled, okn_filter_type_t type,
                              float freq_hz, float gain_db, float q);
okn_status_t okn_set_hpf(okn_dsp_state_t *state, unsigned channel, bool enabled, float freq_hz, float q);
okn_status_t okn_set_lpf(okn_dsp_state_t *state, unsigned channel, bool enabled, float freq_hz, float q);
float okn_db_to_linear(float db);
float okn_effective_channel_linear_gain(const okn_dsp_state_t *state, unsigned channel);

#endif
