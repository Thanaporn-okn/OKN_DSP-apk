# V26 Numeric and Persistence State Hardening

V26 keeps Protocol V2 and the fail-closed BP1048P4/GoloPine hardware gates unchanged. It does not add target addresses, pins, programmer packets, boot commands, image formats, or flashable output.

## Finite-number policy

All public DSP setters continue to require finite values inside the documented portable ranges. NaN and positive/negative infinity are rejected. V26 additionally canonicalizes any accepted floating-point zero to positive zero at the mutation boundary so readback and persistence do not preserve a meaningless negative-zero sign bit.

Persistence serialization also canonicalizes zero, including states constructed directly in memory rather than through setters. A state containing NaN or infinity cannot be encoded because `okn_validate_state()` rejects it first.

## Schema-1 migration policy

Runtime restore remains schema-2-only. Schema 1 used a payload-only CRC, so its generation counter was not integrity protected and must never participate in automatic A/B newest-slot selection.

`okn_persist_migrate_v1_state()` is an explicit state-only migration function. It verifies schema-1 magic, reserved fields, payload length, payload CRC, and the fully decoded DSP state. It intentionally does not return or trust the legacy generation. A caller that deliberately migrates a legacy record must save the returned state as a fresh schema-2 record, starting a new trusted generation sequence.

This migration policy is portable host logic only; exact BP1048P4/GoloPine NVM layout is still unverified and remains locked.
