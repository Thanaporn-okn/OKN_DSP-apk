# V33 Reviewed Target Claim Mapping

V33 adds a separate claim-mapping boundary after the V32 exact-target document intake.

A document that is merely named `BP1048P4`, listed on a web page, or even marked as an exact-target candidate cannot become a qualification claim. The document bytes are re-hashed, any bound reviewed text is re-hashed, the intake record must already be review-ready, and the reviewer must choose one exact claim plus a concrete locator.

Evidence scopes are deliberately narrow. For example, an exact-chip datasheet can support chip identity or RAM-capacity review, but it cannot support GoloPine board routing. Board-specific claims require board-specific evidence; measured readback claims require measured evidence.

A successful mapping has state `REVIEWED_SUPPORT_MAPPING_NON_AUTHORIZING`. It does not edit `target_qualification_manifest.json`, does not enable hardware/mobile flash, and does not emit programmer I/O. Promotion remains a separate explicit reviewed step after actual vendor/board evidence is available.
