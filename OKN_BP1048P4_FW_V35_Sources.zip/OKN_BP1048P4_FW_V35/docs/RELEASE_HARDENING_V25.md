# V25 Release-Candidate Hardening

V25 does not add any target-specific BP1048P4 register, pin, address, boot command, programmer packet or image format.

It hardens the portable software boundary in three ways:

1. `source_inventory.json` records SHA-256 and size for every shipped source/config/test/document file except the inventory itself. Verification fails on edits, missing files, renamed files or unlisted additions.
2. `test_protocol_fuzz` uses deterministic malformed framing/noise/CRC/oversized-length corpora and valid-frame recovery checks. It performs no hardware I/O.
3. `test_persistence_fuzz` verifies truncation rejection and single-bit corruption rejection across the full persistence image.

Persistence schema is bumped from 1 to 2. Schema 2 CRC covers header bytes 0..15 (including generation and payload length) plus the payload, while excluding only the stored CRC field at bytes 16..19. Image size remains unchanged. V25 intentionally does not claim target NVM compatibility because the exact BP1048P4/GoloPine storage layout is still unverified.

These checks are host-side validation only and do not authorize hardware or mobile flashing.
