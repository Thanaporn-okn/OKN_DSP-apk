# V33 Exact Target Document Intake

V33 adds a read-only intake boundary for exact-model BP1048P4 documents.

A public download-page listing, filename containing `BP1048P4`, seller description, or caller-selected classification is not proof of chip identity, memory map, pin map, programmer transport, image format, or GoloPine board compatibility.

The intake records the exact document bytes by SHA-256 and source provenance. If a PDF's text is not directly visible in the raw bytes, a separately reviewed extracted-text companion may be supplied and is hashed independently. Only a content-anchored, reviewed exact-target candidate becomes `review_ready_for_claim_mapping`; that state still authorizes nothing.

Claim promotion remains a separate content-bound human-review step. V33 ships with no vendor datasheet/programmer bytes and all hardware/mobile-flash authorization disabled.
