# V35 Validated-Frame Exactly-Once Dispatch

A CRC-valid frame becomes owned by the application callback when the callback is invoked. V35 consumes that frame from the parser buffer exactly once regardless of the callback return status.

This closes a retry ambiguity in the previous parser: a callback could apply a mutating command and then return an error, leaving the same valid frame buffered for a later implicit redispatch. In V35 the failing frame is removed, `frames_ok` is incremented, `callback_errors` records the failure, and any subsequent concatenated frame remains buffered for an explicit later drain.

This is a portable stream/parser rule only. It does not define BLE retry timing, programmer transport, target packets, or any BP1048P4 hardware value. Transport/session retry of an externally retransmitted frame remains handled by the control-session exact-duplicate cache.
