# V29 Reproducible Release Contract

V29 makes the portable source package reproducible before any BP1048P4 target
toolchain is allowed into the release path.

The deterministic builder sorts POSIX paths, fixes every ZIP timestamp to
1980-01-01 00:00:00, normalizes regular file mode to 0644, forbids symlinks,
excludes build/cache artifacts, and uses DEFLATE level 9. Two builds from the
same source tree must be byte-for-byte identical. The verifier also reads every
ZIP member back and compares it with the source bytes.

This contract applies only to the clean-room source package. Passing it does not
prove BP1048P4 compatibility, does not authorize GoloPine hardware, does not
link a target image, and does not emit programmer commands.
