# V27 Wire and Persistence Portability Contract

V27 freezes host-independent byte representations before any target-specific BP1048P4 integration is attempted.

The following fixtures in `tests/golden/` are byte-for-byte regression contracts:

- `get_info_req.vec` / `get_info_rsp.vec`
- `get_capabilities_req.vec` / `get_capabilities_rsp.vec`
- `set_ch3_gain_neg3_5_req.vec` / `set_ch3_gain_neg3_5_ack.vec`
- `persist_default_gen01020304.vec` (full 1,690-byte schema-2 image)

The fixtures are intentionally independent of C struct layout. Protocol and persistence code serialize integer and IEEE-754 float bit patterns with explicit little-endian byte helpers. Packed structs and raw `okn_dsp_state_t` serialization are forbidden for these formats.

`make test` runs the frozen-vector test with the normal compiler and then runs a compiler matrix with GCC and Clang when installed. A compiler missing from the host is reported as SKIP; a present compiler must compile with `-Wall -Wextra -Werror -pedantic` and produce the exact same bytes.

This contract proves portable format stability only. It does not prove the BP1048P4 CPU ABI, flash image format, board memory map, programmer protocol, or GoloPine wiring.
