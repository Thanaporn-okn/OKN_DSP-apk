# V29 Target Toolchain Acceptance Contract

V29 adds a compile-only acceptance harness for a future exact BP1048P4 toolchain. It is intentionally unable to link a target image, execute target code, or communicate with hardware.

A compiler passes this stage only when it accepts the portable core's actual representation requirements: 8-bit bytes, exact 8/16/32-bit integer types, and IEEE-754 binary32-compatible `float`. Persistence uses explicit little-endian byte encoding, but float payloads preserve IEEE binary32 bit patterns; this is now a checked requirement instead of an implicit assumption.

`python3 tools/toolchain_probe.py --cc <compiler>` compiles `tests/toolchain_compile_probe.c` with `-c` only. Passing this probe is **not** evidence of BP1048P4 identity, linker/memory-map correctness, GoloPine board compatibility, programmer transport, image format, or flash authorization.

V29 also removes the implementation-defined `uint32_t -> int32_t` cast previously used for persistence generation ordering. Wrap-aware generation comparison now uses unsigned serial-number arithmetic only.
