# V24 Immediate-Predecessor Provenance Chain

V24 adds a machine-verifiable, non-authorizing provenance chain for firmware source revisions.
The chain binds the current project to exactly one immediate predecessor using the predecessor's
source ZIP SHA-256 and uploaded GitHub validation ZIP SHA-256.

For V24 the required predecessor is V23:

- source: `OKN_BP1048P4_FW_V23_Sources.zip`
- source SHA-256: `24bea15f5552cab0e6fac591d0d194029bb843658f1be8220f10e1c29dcb21a5`
- validation artifact: `OKN-BP1048P4-FW-V23-validation.zip`
- validation SHA-256: `edb5cefe26993deecb595effd5c9f63341dc6db423e026e44d32abe7a2319c31`

`tools/verify_provenance_chain.py` rejects a version skip, stale source hash, stale validation hash,
missing immediate-predecessor CI observation, or disagreement between the firmware/evidence manifests.
This chain proves software lineage only. It does not authorize BP1048P4 hardware access, flashing,
programmer packets, image formats, board pin mappings, or mobile-flash execution.
