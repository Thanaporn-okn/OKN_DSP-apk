# V35 stream callback re-entrancy boundary

A CRC-valid frame is copied into a bounded `OKN_PROTO_MAX_PACKET` local snapshot and removed from the parser buffer before application code is invoked. This makes parser ownership explicit: once callback execution begins, that frame can no longer be found at the head of the stream buffer.

`okn_stream_feed()` rejects recursive calls on the same `okn_stream_t` while its callback is active with `OKN_ERR_REENTRANT`. This is a portable control-flow rule, not a BLE timing or BP1048P4 hardware claim.

The regression test applies `SET_CH_GAIN`, attempts recursive same-stream drain from inside the callback, and verifies that controller revision advances exactly once. A following concatenated PING is then processed once in normal order.
