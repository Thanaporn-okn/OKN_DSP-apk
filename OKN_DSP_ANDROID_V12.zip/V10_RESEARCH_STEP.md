# V10 Research Step

Passive packet analysis only. DSP writes remain disabled.

## Goals
- Capture AB02 and AB03 notifications.
- Classify packets by length: 10-byte TYPE-A, 13-byte TYPE-B, otherwise OTHER.
- Record sequence, timestamp, delta time, UUID, HEX, and fingerprint.
- Compare packet changes against controlled, one-variable-at-a-time events.

## Current observation from V9
AB02 produced a repeated 10,10,13,13 length cadence in the captured sample. This is an observation, not yet a protocol conclusion.

## Next experiment
Capture idle baseline, then perform exactly one controlled change in the original controller and capture again. Compare byte-by-byte and timing differences.

No DSP write commands are included.
