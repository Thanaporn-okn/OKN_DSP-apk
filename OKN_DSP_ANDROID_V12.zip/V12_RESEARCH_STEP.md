# V12 Controlled Event Capture

V12 fixes the V11 UI so the controlled-event controls are separate and visible.

Controls:
1. START EVENT BASELINE — starts a baseline phase.
2. MARK CONTROLLED EVENT — marks the exact point before one controlled change.
3. CAPTURE NOTIFY — enables notification logging.
4. ANALYZE PACKETS — prints the current analysis reminder.

Notification lines include:
- packet number
- timestamp
- AB02/AB03 UUID
- length
- TYPE-A (10 bytes) / TYPE-B (13 bytes) / OTHER
- deltaMs
- mode (BASELINE/EVENT/IDLE)
- eventMs
- HEX
- fingerprint

Safety:
- No DSP write command is added.
- Change exactly one value in the original DSP controller during the EVENT phase.
