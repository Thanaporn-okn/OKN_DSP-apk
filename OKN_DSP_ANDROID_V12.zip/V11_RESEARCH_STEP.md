# V11 Controlled Event Capture

Purpose:
- Compare an idle BLE notification baseline against exactly one controlled DSP change.
- Keep all DSP writes disabled.
- Capture AB02/AB03 notification packets with timestamp, length, HEX and event phase.

Procedure:
1. Connect the DSP and subscribe to AB02/AB03.
2. Press START EVENT BASELINE.
3. Leave the original DSP controller untouched for about 5 seconds.
4. Press MARK CONTROLLED EVENT.
5. In the original DSP controller, change exactly ONE value (for example Volume by one step).
6. Wait about 5 seconds.
7. Save/send the V11 log.

Interpretation:
- Baseline packets = packets before the controlled change.
- Event packets = packets after the marked change.
- Compare packet length, byte-by-byte differences, ordering and timing.
- Do not infer command/checksum fields until repeated controlled captures confirm a relationship.

Safety:
- No DSP write command is implemented in V11.
