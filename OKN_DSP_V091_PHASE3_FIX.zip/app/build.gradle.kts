
plugins {
 id("com.android.application")
 id("org.jetbrains.kotlin.android")
}
android {
 namespace="com.okn.dsp"
 compileSdk=35
 defaultConfig {
  applicationId="com.okn.dsp"
  minSdk=26
  targetSdk=35
  versionCode=91
  versionName="0.9.1"
 }
 kotlinOptions { jvmTarget="17" }
}
dependencies {
 implementation("androidx.core:core-ktx:1.13.1")
 implementation("androidx.appcompat:appcompat:1.7.0")
}
