#!/usr/bin/env python3
from pathlib import Path
import hashlib, re, sys

ROOT = Path(__file__).resolve().parent

def sha(p): return hashlib.sha256((ROOT/p).read_bytes()).hexdigest()
def need(cond, msg):
    if not cond:
        print('FAIL:', msg); sys.exit(1)
    print('PASS:', msg)

def contains(path, text):
    return text in (ROOT/path).read_text(errors='replace')

need(sha('evidence/OKN_DSP_V98_UI_MASTER_REFERENCE.png') == '6f5f2eab24de53cd7460abd79e76b04382edd8c62eb7c1e317bbd1bdbfb5b2b0', 'exact supplied UI MASTER REFERENCE hash')
need(sha('app/okn_dsp_stable_debug.keystore') == 'ba1c52f2607c09953c52fdd79c5f72026aaf0adb8aa44bcba277f7d9b49d9511', 'stable signing keystore hash')

frozen = {
 'ByteCodec.kt':'04843cec90b69886607d98a0aabf0ad81812fc8d25df913c5b1847a10fd7a3ae',
 'ConfirmedDspMap.kt':'6e68295f194dd0b0f70d0b83b9ba2324a9a2a8eaf2350b5d5a821f838ae2c66d',
 'EqBandCodec.kt':'4f033a406e363b2418af9b39fa2e42a13674b09f9de2bb7acf1eb6ff1918cd58',
 'LiveEqPolicy.kt':'4bfa2678b824e5776d332214fcce1dd6e571e3aa2157c1bfb0e61da774b52090',
 'PreAuthRandKeyDecoder.kt':'58d8a287449c849fb925070ac1f61ea26ba02875f58605fd7008439da78533ac',
 'SaveParamsPolicy.kt':'88005dba77d2b84597f5bd5e23eaaacec7d25b59dc0f38b8affbde2d2cfbeb85',
 'SessionCrypto.kt':'bae330efd6e9beb628b287e43e36bd98d80b3f9b4d1c014f65c63ef16efa586e',
 'UfeCodec.kt':'b47f66afec8fd3383581c30b2dc1ad9ad41e3b7089f427f0b094e91581588c34',
 'UfeConstants.kt':'e64de468c11d80ea052b97c9298a0a8a7f8cc49362f5bd06193d2c7c6d0108aa',
 'VerifiedScalarControls.kt':'4c096b001523704dcb6aa36496dd17263d6df84a0a1fee20c2fc40d60e898f6b',
 'WriteGate.kt':'8aa82bb069dd64dc2d1274801f1f4420a764f52670246e9c813b0723531be472',
}
for name, expected in frozen.items():
    p = 'app/src/main/java/com/okn/dsp/protocol/' + name
    need(sha(p) == expected, 'frozen verified protocol ' + name)

ble='app/src/main/java/com/okn/dsp/ble/BleProfile.kt'
need(all(contains(ble,x) for x in ['0000ab00-0000-1000-8000-00805f9b34fb','0000ab01-0000-1000-8000-00805f9b34fb','0000ab02-0000-1000-8000-00805f9b34fb']), 'verified AB00/AB01/AB02 profile present')
need(contains(ble,'UNVERIFIED_40AF') and contains(ble,'never used for DSP writes'), '40af roles explicitly locked/unverified')

repo=(ROOT/'app/src/main/java/com/okn/dsp/repository/DspRepository.kt').read_text()
need('SaveParamsPolicy.encodeTrigger()' in repo, 'SaveParams exact policy used')
need('fun saveParamsManual()' in repo, 'SaveParams exposed only as explicit manual repository method')
need('restoreLocalAfterHealthGate' in repo and 'scalarRamp.setTarget' in repo and 'eqSlew.setTarget' in repo, 'safe post-Health-Gate ramped restore')

main=(ROOT/'app/src/main/java/com/okn/dsp/MainActivity.kt').read_text()
need('setPositiveButton("Save to Device")' in main and 'saveParamsManual()' in main, 'manual guarded Save UI path')
need('dispatchKeyEvent' in main and 'PhoneVolumeBridge' in main, 'phone volume synchronization path')

queue=(ROOT/'app/src/main/java/com/okn/dsp/queue/RealtimeCommandQueue.kt').read_text()
need('LinkedHashMap<String, Command>' in queue and 'realtime[command.key] = command' in queue, 'latest-value-wins realtime coalescing')
need('ArrayDeque<Command>' in queue and 'critical.addLast(command)' in queue, 'critical FIFO queue')
need('writeTimeoutMs = 2500L' in queue, 'GATT callback timeout fail-closed hook')

screens=(ROOT/'app/src/main/java/com/okn/dsp/ui/Screens.kt').read_text()
for marker in ['HomeScreen','GlobalScreen','EqScreen','SensorsScreen','MoreScreen','SaveParams (Guarded)','Channel EQ Overview','EQ Editor']:
    need(marker in screens, 'UI marker ' + marker)
nav=(ROOT/'app/src/main/java/com/okn/dsp/ui/OknDspUi.kt').read_text()
need(all(x in nav for x in ['"Home"','"Global"','"EQ"','"Sensors"','"More"']), 'five-tab bottom navigation')

manifest=(ROOT/'app/src/main/AndroidManifest.xml').read_text()
need('orientation|screenSize|smallestScreenSize|keyboardHidden' in manifest and 'fullSensor' in manifest, 'portrait/landscape session-preserving configuration')

gradle=(ROOT/'app/build.gradle.kts').read_text()
need('versionCode = 98' in gradle and 'versionName = "7.1.0-v98-master-reference-modular"' in gradle, 'V98 identity')

# Ensure app source never routes writes through the explicitly-unverified 40af list.
for p in (ROOT/'app/src/main/java').rglob('*.kt'):
    if p.name == 'BleProfile.kt': continue
    t=p.read_text(errors='replace')
    need('UNVERIFIED_40AF' not in t, 'no 40af write/use in '+str(p.relative_to(ROOT)))

print('V98 PREFLIGHT: PASS')
