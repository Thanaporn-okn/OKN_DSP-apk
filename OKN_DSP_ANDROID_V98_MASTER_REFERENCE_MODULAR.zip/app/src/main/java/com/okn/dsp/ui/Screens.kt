package com.okn.dsp.ui

import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.okn.dsp.protocol.LiveEqPolicy
import com.okn.dsp.protocol.ParameterMapper
import com.okn.dsp.protocol.VerifiedScalarControls
import com.okn.dsp.state.ConnectionState
import com.okn.dsp.state.DspState
import java.util.Locale
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.roundToInt

interface UiActions {
    fun scanConnect()
    fun disconnect()
    fun reconnect()
    fun refresh()
    fun scalarChanged(id: Int, value: Float)
    fun channelSelected(channel: Int, openEditor: Boolean)
    fun bandSelected(band: Int)
    fun eqChanged(channel: Int, band: Int, frequency: Float, q: Float, gain: Float)
    fun linkAllChanged(enabled: Boolean)
    fun saveParams()
    fun showLogs()
    fun resetEqViewport()
}

interface BoundScreen {
    val view: View
    fun bind(state: DspState)
}

private fun Context.scrollPage(content: LinearLayout): ScrollView = ScrollView(this).apply {
    isFillViewport = true
    setBackgroundColor(OknColors.BG)
    addView(content, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
}

private fun Context.pageColumn(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    setPadding(dp(12), 0, dp(12), dp(18))
}

private fun formatControl(id: Int, v: Float?): String {
    if (v == null || !v.isFinite()) return "--"
    val c = VerifiedScalarControls.byId(id) ?: return "--"
    return if (c.unit == "Hz") String.format(Locale.US, "%.0f Hz", v)
    else String.format(Locale.US, "%+.1f dB", v).replace("+0.0", "0.0")
}

private fun channelColor(ch: Int): Int = when (ch) {
    1 -> OknColors.BLUE
    2 -> OknColors.CYAN
    3 -> OknColors.PURPLE
    4 -> OknColors.YELLOW
    5 -> OknColors.GREEN
    6 -> OknColors.PINK
    else -> OknColors.ORANGE
}

class HomeScreen(private val context: Context, private val actions: UiActions) : BoundScreen {
    private val root = context.pageColumn()
    override val view: View = context.scrollPage(root)
    private val statusDot = context.text("●", 15, OknColors.MUTED, true)
    private val status = context.text("Disconnected", 15, OknColors.MUTED, true)
    private val deviceName = context.text("Tap to scan / connect", 11, OknColors.MUTED)
    private val deviceTitle = context.text("Awaiting DSP", 17, OknColors.TEXT, true)
    private val deviceSub = context.text("7 Channel DSP", 12, OknColors.MUTED)
    private val fw = context.text("FW: --", 11, OknColors.MUTED)
    private val health = context.text("Health Gate --", 16, OknColors.MUTED, true)
    private val writes = context.text("0", 13, OknColors.TEXT, true)
    private val idle = context.text("true", 13, OknColors.TEXT, true)
    private val summary = context.text("7 Scalars\n105 EQ Bands\n4 Sensors", 12, OknColors.TEXT, true)
    private val masterValue = context.text("--", 23, OknColors.CYAN, true, Gravity.END)
    private val masterSeek = context.makeSeek(-70f, 6f, -70f) { v, fromUser -> if (fromUser) actions.scalarChanged(2, v) }
    private val channelButtons = mutableListOf<TextView>()
    private var linkAll = false
    private val linkText = context.text("↻ Link All", 12, OknColors.CYAN, true)

    init {
        root.addView(context.appBar())
        root.addView(connectionCard(), LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(5) })
        root.addView(deviceCard(), LinearLayout.LayoutParams(-1, context.dp(132)).apply { topMargin = context.dp(10) })
        root.addView(healthCard(), LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(10) })
        root.addView(sessionCards(), LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(10) })
        root.addView(masterCard(), LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(10) })
        root.addView(channelSection(), LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(12) })
    }

    private fun connectionCard(): View = context.card().apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(context.text("ᛒ", 34, OknColors.CYAN, true, Gravity.CENTER), LinearLayout.LayoutParams(context.dp(54), context.dp(52)))
        addView(context.row().apply {
            addView(statusDot, LinearLayout.LayoutParams(context.dp(23), -2))
            addView(LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; addView(status); addView(deviceName) }, LinearLayout.LayoutParams(0, -2, 1f))
        }, LinearLayout.LayoutParams(0, -2, 1f))
        addView(context.text("⋮", 28, OknColors.TEXT, true, Gravity.CENTER).apply {
            setOnClickListener { if (status.text.toString() == "Connected") actions.disconnect() else actions.scanConnect() }
        }, LinearLayout.LayoutParams(context.dp(34), context.dp(50)))
        setOnClickListener { actions.scanConnect() }
        isClickable = true
    }

    private fun deviceCard(): View = context.card().apply {
        orientation = LinearLayout.HORIZONTAL
        val art = GlowDspView(context)
        addView(art, LinearLayout.LayoutParams(context.dp(135), -1))
        addView(LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            addView(deviceTitle); addView(deviceSub); addView(fw)
        }, LinearLayout.LayoutParams(0, -1, 1f).apply { leftMargin = context.dp(12) })
    }

    private fun healthCard(): View = context.card(OknColors.BORDER, Color.rgb(4, 36, 39)).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        addView(context.text("⬡", 31, OknColors.GREEN, true, Gravity.CENTER), LinearLayout.LayoutParams(context.dp(50), context.dp(50)))
        addView(LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL; addView(health); addView(context.text("ระบบพร้อมใช้งานเมื่อข้อมูลจริงครบถ้วน", 11, OknColors.MUTED))
        }, LinearLayout.LayoutParams(0, -2, 1f))
    }

    private fun sessionCards(): View = context.row().apply {
        fun smallCard(title: String, body: View): View = context.card().apply {
            addView(context.text(title, 12, OknColors.TEXT, true)); addView(body, LinearLayout.LayoutParams(-1, -2).apply { topMargin = context.dp(8) })
        }
        val sessBody = context.row().apply {
            addView(LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; addView(context.text("writesSent", 11, OknColors.MUTED)); addView(context.text("protocolIdle", 11, OknColors.MUTED)) }, LinearLayout.LayoutParams(0,-2,1f))
            addView(LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.END; addView(writes); addView(idle) }, LinearLayout.LayoutParams(context.dp(55),-2))
        }
        addView(smallCard("Session Info\nข้อมูลการเชื่อมต่อ", sessBody), LinearLayout.LayoutParams(0,-2,1f))
        addView(smallCard("System Summary\nภาพรวมระบบ", summary), LinearLayout.LayoutParams(0,-2,1f).apply { leftMargin = context.dp(8) })
    }

    private fun masterCard(): View = context.card().apply {
        addView(context.row().apply {
            addView(context.text("◖", 31, OknColors.TEXT, true, Gravity.CENTER), LinearLayout.LayoutParams(context.dp(48), context.dp(52)))
            addView(LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; addView(context.text("Master Volume", 15, OknColors.TEXT, true)); addView(context.text("ระดับเสียงหลัก", 11, OknColors.MUTED)) }, LinearLayout.LayoutParams(0,-2,1f))
            addView(masterValue, LinearLayout.LayoutParams(context.dp(95), -2))
        })
        addView(masterSeek, LinearLayout.LayoutParams(-1, context.dp(42)))
        addView(context.row().apply {
            addView(context.text("-70", 9, OknColors.MUTED), LinearLayout.LayoutParams(0,-2,1f)); addView(context.text("+6", 9, OknColors.MUTED, false, Gravity.END), LinearLayout.LayoutParams(0,-2,1f))
        })
    }

    private fun channelSection(): View = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        addView(context.row().apply {
            addView(context.text("Channels (7)  ช่องสัญญาณ", 16, OknColors.TEXT, true), LinearLayout.LayoutParams(0,-2,1f))
            addView(linkText.apply { setOnClickListener { actions.linkAllChanged(!linkAll) } })
        })
        val grid = GridLayout(context).apply { columnCount = 4; rowCount = 2; setPadding(0, context.dp(8), 0, 0) }
        DspState.CHANNELS.forEach { ch ->
            val b = context.text("${ch.shortName}\n${ch.displayName}", 11, OknColors.TEXT, true, Gravity.CENTER).apply {
                background = roundedBg(OknColors.CARD_ALT, context.dp(10).toFloat(), channelColor(ch.index), context.dp(1))
                setPadding(context.dp(3), context.dp(8), context.dp(3), context.dp(8))
                setOnClickListener { actions.channelSelected(ch.index, true) }
            }
            channelButtons += b
            grid.addView(b, GridLayout.LayoutParams().apply {
                width = 0; height = context.dp(61); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(context.dp(2),context.dp(2),context.dp(2),context.dp(2))
            })
        }
        addView(grid, LinearLayout.LayoutParams(-1,-2))
    }

    override fun bind(state: DspState) {
        val connected = state.connection == ConnectionState.CONNECTED
        status.text = when (state.connection) {
            ConnectionState.DISCONNECTED -> "Disconnected"; ConnectionState.SCANNING -> "Scanning"; ConnectionState.CONNECTING -> "Connecting"
            ConnectionState.DISCOVERING -> "Discovering"; ConnectionState.AUTHENTICATING -> "Authenticating"; ConnectionState.SYNCHRONIZING -> "Synchronizing"
            ConnectionState.CONNECTED -> "Connected"; ConnectionState.RECONNECTING -> "Reconnecting"; ConnectionState.FAILED -> "Connection Failed"
        }
        status.setTextColor(if (connected) OknColors.GREEN else if (state.connection == ConnectionState.FAILED) OknColors.RED else OknColors.CYAN)
        statusDot.setTextColor(if (connected) OknColors.GREEN else if (state.connection == ConnectionState.FAILED) OknColors.RED else OknColors.MUTED)
        deviceName.text = state.device.bluetoothName ?: state.connectionMessage
        deviceTitle.text = state.device.bluetoothName?.let { "OKN DSP-7" } ?: "Awaiting DSP"
        fw.text = "FW: ${state.device.firmwareText ?: "--"}"
        health.text = if (state.healthGatePass) "Health Gate PASS" else "Health Gate --"
        health.setTextColor(if (state.healthGatePass) OknColors.GREEN else OknColors.MUTED)
        writes.text = state.writesSent.toString(); idle.text = state.protocolIdle.toString()
        val master = state.scalars[2]
        masterValue.text = formatControl(2, master)
        masterSeek.isEnabled = master != null
        master?.let { masterSeek.progress = (((it + 70f) / 76f).coerceIn(0f,1f) * 1000).roundToInt() }
        linkAll = state.linkAllEq
        linkText.text = if (linkAll) "↻ Link All • ON" else "↻ Link All"
        channelButtons.forEachIndexed { i, b -> b.alpha = if (state.eq[i].any { it != null }) 1f else .72f }
    }
}

class GlobalScreen(private val context: Context, private val actions: UiActions) : BoundScreen {
    private data class RowRefs(val value: TextView, val seek: SeekBar)
    private val refs = linkedMapOf<Int, RowRefs>()
    private val root = context.pageColumn()
    override val view: View = context.scrollPage(root)

    init {
        root.addView(context.appBar())
        root.addView(context.sectionHeader("Global Controls", "การควบคุมรวม (7 รายการ)"), LinearLayout.LayoutParams(-1,-2).apply { topMargin=context.dp(7); bottomMargin=context.dp(8) })
        ParameterMapper.globals.forEach { m ->
            val c = VerifiedScalarControls.byId(m.id)!!
            val value = context.text("--", 17, OknColors.CYAN, true, Gravity.END)
            val seek = context.makeSeek(c.min, c.max, c.min) { v, from -> if (from) actions.scalarChanged(m.id, v) }
            refs[m.id] = RowRefs(value, seek)
            root.addView(context.card().apply {
                addView(context.row().apply {
                    addView(context.text(m.symbol, 28, OknColors.CYAN, true, Gravity.CENTER), LinearLayout.LayoutParams(context.dp(50), context.dp(48)))
                    addView(LinearLayout(context).apply { orientation=LinearLayout.VERTICAL; addView(context.text(m.title, 14, OknColors.TEXT, true)); addView(context.text(m.thai, 10, OknColors.MUTED)) }, LinearLayout.LayoutParams(0,-2,1f))
                    addView(value, LinearLayout.LayoutParams(context.dp(100),-2))
                })
                addView(seek, LinearLayout.LayoutParams(-1, context.dp(38)))
                addView(context.row().apply {
                    addView(context.text(if (c.unit=="Hz") c.min.toInt().toString() else c.min.toInt().toString(), 9, OknColors.MUTED), LinearLayout.LayoutParams(0,-2,1f))
                    addView(context.text(if (c.unit=="Hz") c.max.toInt().toString() else "+${c.max.toInt()}", 9, OknColors.MUTED, false, Gravity.END), LinearLayout.LayoutParams(0,-2,1f))
                })
            }, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=context.dp(8) })
        }
    }

    override fun bind(state: DspState) {
        refs.forEach { (id, r) ->
            val c = VerifiedScalarControls.byId(id)!!; val v = state.scalars[id]
            r.value.text = formatControl(id, v); r.seek.isEnabled = v != null
            v?.let { r.seek.progress = (((it-c.min)/(c.max-c.min)).coerceIn(0f,1f)*1000).roundToInt() }
        }
    }
}

class EqScreen(private val context: Context, private val actions: UiActions) : BoundScreen {
    private val host = FrameLayout(context).apply { setBackgroundColor(OknColors.BG) }
    override val view: View = host
    private var editor = false
    private var lastState = DspState()
    private var overview: EqOverview? = null
    private var edit: EqEditor? = null

    init { showOverview() }
    fun openEditor(channel: Int) { actions.channelSelected(channel, false); editor = true; rebuild() }
    fun isEditor() = editor
    fun backToOverview(): Boolean { if (!editor) return false; editor=false; rebuild(); return true }
    fun resetViewport() { edit?.graph?.resetViewport() }

    private fun rebuild() {
        host.removeAllViews()
        if (editor) {
            val e = EqEditor(context, actions) { editor=false; rebuild() }
            edit=e; overview=null; host.addView(e.view); e.bind(lastState)
        } else showOverview()
    }
    private fun showOverview() {
        host.removeAllViews(); val o = EqOverview(context, actions) { ch -> openEditor(ch) }; overview=o; edit=null; host.addView(o.view); o.bind(lastState)
    }
    override fun bind(state: DspState) { lastState=state; if (editor) edit?.bind(state) else overview?.bind(state) }

    private class EqOverview(val context: Context, val actions: UiActions, val open: (Int)->Unit) : BoundScreen {
        private val root=context.pageColumn(); override val view=context.scrollPage(root)
        private val graphs = mutableListOf<EqCurveView>()
        private val link = context.text("All Channels ▾", 11, OknColors.TEXT, true, Gravity.CENTER)
        private var linked = false
        init {
            root.addView(context.appBar())
            root.addView(context.row().apply {
                addView(context.sectionHeader("Channel EQ Overview", "ภาพรวม EQ แต่ละช่อง"), LinearLayout.LayoutParams(0,-2,1f))
                addView(link.apply { background=roundedBg(OknColors.CARD,context.dp(8).toFloat(),OknColors.BORDER,context.dp(1)); pad(8,7); setOnClickListener { actions.linkAllChanged(!linked) } })
            }, LinearLayout.LayoutParams(-1,-2).apply{topMargin=context.dp(6);bottomMargin=context.dp(8)})
            DspState.CHANNELS.forEach { ch ->
                val g=EqCurveView(context); graphs+=g
                root.addView(context.card().apply {
                    orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL
                    addView(context.text("●",20,channelColor(ch.index),true,Gravity.CENTER),LinearLayout.LayoutParams(context.dp(30),-1))
                    addView(LinearLayout(context).apply {
                        orientation=LinearLayout.VERTICAL
                        addView(context.row().apply { addView(context.text(ch.shortName,13,OknColors.TEXT,true)); addView(context.text("   ${ch.displayName}",12,OknColors.MUTED)) })
                        addView(g,LinearLayout.LayoutParams(-1,context.dp(72)))
                        addView(context.text("15 bands  |  PEAKING editable",9,OknColors.MUTED))
                    },LinearLayout.LayoutParams(0,context.dp(104),1f))
                    addView(context.text("›",30,OknColors.TEXT,false,Gravity.CENTER),LinearLayout.LayoutParams(context.dp(28),-1))
                    setOnClickListener { open(ch.index) }
                },LinearLayout.LayoutParams(-1,context.dp(126)).apply{bottomMargin=context.dp(8)})
            }
        }
        override fun bind(state:DspState){ linked=state.linkAllEq; graphs.forEachIndexed{i,g->g.bind(state.eq[i],channelColor(i+1),state.selectedEqBand)}; link.text=if(state.linkAllEq)"All Channels • Linked" else "All Channels ▾" }
    }

    private class EqEditor(val context:Context,val actions:UiActions,val back:()->Unit):BoundScreen{
        private val root=context.pageColumn(); override val view=context.scrollPage(root)
        val graph=EqCurveView(context)
        private val channelTitle=context.text("CH1 - Front L ▾",13,OknColors.TEXT,true)
        private val typeInfo=context.text("PEAKING (Editable)     Other Types (Read-only)",11,OknColors.MUTED)
        private val freqValue=context.text("--",12,OknColors.CYAN,true,Gravity.END)
        private val qValue=context.text("--",12,OknColors.CYAN,true,Gravity.END)
        private val gainValue=context.text("--",12,OknColors.CYAN,true,Gravity.END)
        private val freqSeek=SeekBar(context).apply{max=1000}
        private val qSeek=SeekBar(context).apply{max=1000}
        private val gainSeek=SeekBar(context).apply{max=240}
        private val tableRows=mutableListOf<TableRow>()
        private var suppress=false
        private var current:DspState=DspState()
        init{
            listOf(freqSeek,qSeek,gainSeek).forEach{ s-> if(android.os.Build.VERSION.SDK_INT>=21){s.progressTintList=android.content.res.ColorStateList.valueOf(OknColors.CYAN);s.thumbTintList=android.content.res.ColorStateList.valueOf(Color.WHITE);s.progressBackgroundTintList=android.content.res.ColorStateList.valueOf(Color.rgb(31,74,94))}}
            root.addView(context.appBar(back=back))
            root.addView(channelTitle.apply{background=roundedBg(OknColors.CARD,context.dp(8).toFloat(),OknColors.BORDER,context.dp(1));pad(9,7);setOnClickListener{showChannelPicker()}},LinearLayout.LayoutParams(-1,-2).apply{topMargin=context.dp(5)})
            root.addView(context.row().apply{
                addView(context.sectionHeader("EQ Editor","ปรับแต่ง EQ รายช่อง"),LinearLayout.LayoutParams(0,-2,1f))
                addView(context.text("Reset View",10,OknColors.TEXT,true,Gravity.CENTER).apply{background=roundedBg(OknColors.CARD,context.dp(8).toFloat(),OknColors.BORDER,context.dp(1));pad(8,7);setOnClickListener{graph.resetViewport();actions.resetEqViewport()}})
            },LinearLayout.LayoutParams(-1,-2).apply{topMargin=context.dp(8);bottomMargin=context.dp(6)})
            graph.setOnBandTap{actions.bandSelected(it)};root.addView(graph,LinearLayout.LayoutParams(-1,context.dp(245)))
            root.addView(typeInfo,LinearLayout.LayoutParams(-1,-2).apply{topMargin=context.dp(5);bottomMargin=context.dp(5)})
            root.addView(control("Freq",freqValue,freqSeek,"20 Hz","20 kHz"));root.addView(control("Q",qValue,qSeek,"0.05","20"));root.addView(control("Gain",gainValue,gainSeek,"-12 dB","+12 dB"))
            setupSeekListeners()
            root.addView(context.text("#     Type       Freq        Q        Gain       Edit",10,OknColors.MUTED,true),LinearLayout.LayoutParams(-1,-2).apply{topMargin=context.dp(9);bottomMargin=context.dp(3)})
            repeat(15){idx->val r=TableRow(context,idx+1){actions.bandSelected(idx+1)};tableRows+=r;root.addView(r.view,LinearLayout.LayoutParams(-1,context.dp(35)).apply{bottomMargin=context.dp(2)})}
        }
        private fun control(label:String,value:TextView,seek:SeekBar,min:String,max:String)=context.card().apply{
            setPadding(context.dp(10),context.dp(6),context.dp(10),context.dp(4));addView(context.row().apply{addView(context.text(label,11,OknColors.TEXT,true),LinearLayout.LayoutParams(0,-2,1f));addView(value,LinearLayout.LayoutParams(context.dp(100),-2))});addView(seek,LinearLayout.LayoutParams(-1,context.dp(34)));addView(context.row().apply{addView(context.text(min,8,OknColors.MUTED),LinearLayout.LayoutParams(0,-2,1f));addView(context.text(max,8,OknColors.MUTED,false,Gravity.END),LinearLayout.LayoutParams(0,-2,1f))})
        }
        private fun setupSeekListeners(){
            freqSeek.setOnSeekBarChangeListener(simpleListener{p,from->if(from&&!suppress)send(freq=20f*exp(ln(1000f)*(p/1000f)))});qSeek.setOnSeekBarChangeListener(simpleListener{p,from->if(from&&!suppress)send(q=0.05f*exp(ln(400f)*(p/1000f)))});gainSeek.setOnSeekBarChangeListener(simpleListener{p,from->if(from&&!suppress)send(gain=-12f+p/10f)})
        }
        private fun simpleListener(f:(Int,Boolean)->Unit)=object:SeekBar.OnSeekBarChangeListener{override fun onProgressChanged(s:SeekBar?,p:Int,u:Boolean)=f(p,u);override fun onStartTrackingTouch(s:SeekBar?){};override fun onStopTrackingTouch(s:SeekBar?){} }
        private fun send(freq:Float?=null,q:Float?=null,gain:Float?=null){val b=current.eq[current.selectedChannel-1][current.selectedEqBand-1]?:return;if(!LiveEqPolicy.isWritable(b))return;actions.eqChanged(current.selectedChannel,current.selectedEqBand,freq?:b.frequency,q?:b.q,gain?:b.boostDb)}
        private fun showChannelPicker(){
            val names=DspState.CHANNELS.map{"${it.shortName} - ${it.displayName}"}.toTypedArray();android.app.AlertDialog.Builder(context).setTitle("Select Channel").setItems(names){_,which->actions.channelSelected(which+1,false)}.show()
        }
        override fun bind(state:DspState){
            current=state;val ch=DspState.CHANNELS[state.selectedChannel-1];channelTitle.text="${ch.shortName} - ${ch.displayName} ▾";graph.bind(state.eq[state.selectedChannel-1],channelColor(state.selectedChannel),state.selectedEqBand)
            val b=state.eq[state.selectedChannel-1][state.selectedEqBand-1];val writable=b!=null&&LiveEqPolicy.isWritable(b);suppress=true
            if(b!=null){freqValue.text=String.format(Locale.US,"%.0f Hz",b.frequency);qValue.text=String.format(Locale.US,"%.2f",b.q);gainValue.text=String.format(Locale.US,"%+.1f dB",b.boostDb);freqSeek.progress=((ln((b.frequency/20f).coerceAtLeast(1f))/ln(1000f))*1000).roundToInt().coerceIn(0,1000);qSeek.progress=((ln((b.q/0.05f).coerceAtLeast(1f))/ln(400f))*1000).roundToInt().coerceIn(0,1000);gainSeek.progress=((b.boostDb+12f)*10).roundToInt().coerceIn(0,240)}else{freqValue.text="--";qValue.text="--";gainValue.text="--"}
            freqSeek.isEnabled=writable;qSeek.isEnabled=writable;gainSeek.isEnabled=writable;typeInfo.setTextColor(if(writable)OknColors.CYAN else OknColors.MUTED);suppress=false
            tableRows.forEachIndexed{i,r->r.bind(state.eq[state.selectedChannel-1][i],state.selectedEqBand==i+1)}
        }
        private class TableRow(val context:Context,val n:Int,val select:()->Unit){
            val view=context.row().apply{background=roundedBg(OknColors.CARD,context.dp(6).toFloat(),OknColors.BORDER,context.dp(1));setPadding(context.dp(5),0,context.dp(5),0);setOnClickListener{select()}}
            private val num=context.text(n.toString(),9,OknColors.MUTED);private val type=context.text("--",9,OknColors.TEXT,true);private val freq=context.text("--",9,OknColors.TEXT);private val q=context.text("--",9,OknColors.TEXT);private val gain=context.text("--",9,OknColors.TEXT);private val edit=context.text("🔒",10,OknColors.MUTED,false,Gravity.CENTER)
            init{view.addView(num,LinearLayout.LayoutParams(context.dp(22),-1));view.addView(type,LinearLayout.LayoutParams(context.dp(55),-1));view.addView(freq,LinearLayout.LayoutParams(context.dp(64),-1));view.addView(q,LinearLayout.LayoutParams(context.dp(46),-1));view.addView(gain,LinearLayout.LayoutParams(0,-1,1f));view.addView(edit,LinearLayout.LayoutParams(context.dp(35),-1))}
            fun bind(b:com.okn.dsp.protocol.EqBand48?,selected:Boolean){view.background=roundedBg(if(selected)Color.rgb(7,45,62)else OknColors.CARD,context.dp(6).toFloat(),if(selected)OknColors.CYAN else OknColors.BORDER,context.dp(1));if(b==null){type.text="--";freq.text="--";q.text="--";gain.text="--";edit.text="🔒";return};val w=LiveEqPolicy.isWritable(b);type.text=if(w)"PEAK" else "TYPE ${b.type}";freq.text=String.format(Locale.US,"%.0f",b.frequency);q.text=String.format(Locale.US,"%.2f",b.q);gain.text=String.format(Locale.US,"%+.1f",b.boostDb);edit.text=if(w)"●" else "🔒";edit.setTextColor(if(w)OknColors.CYAN else OknColors.MUTED)}
        }
    }
}

class SensorsScreen(private val context:Context,private val actions:UiActions):BoundScreen{
    private val root=context.pageColumn();override val view=context.scrollPage(root)
    private val values=linkedMapOf<Int,TextView>()
    private val saveButton=context.neonButton("🔒  Save to Device\nบันทึกไปยังอุปกรณ์",true){actions.saveParams()}
    private val saveStatus=context.text("Manual only. Never automatic.",10,OknColors.RED,true)
    init{
        root.addView(context.appBar());root.addView(context.sectionHeader("Sensors & System","เซ็นเซอร์และสถานะระบบ"),LinearLayout.LayoutParams(-1,-2).apply{topMargin=context.dp(7);bottomMargin=context.dp(8)})
        listOf(19 to Triple("FrontAudioJackPluggedIn","ช่องเสียบหน้า","♧"),20 to Triple("RearAudioJackPluggedIn","ช่องเสียบหลัง","♧"),0 to Triple("PowerStageVoltage","แรงดันภาคจ่ายไฟ","ϟ"),21 to Triple("CPU Load","การใช้งาน CPU","▣")).forEach{(id,m)->
            val value=context.text("--",15,OknColors.TEXT,true,Gravity.END);values[id]=value
            root.addView(context.card().apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;addView(context.text(m.third,25,OknColors.CYAN,true,Gravity.CENTER),LinearLayout.LayoutParams(context.dp(46),context.dp(48)));addView(LinearLayout(context).apply{orientation=LinearLayout.VERTICAL;addView(context.text(m.first,12,OknColors.TEXT,true));addView(context.text(m.second,10,OknColors.MUTED))},LinearLayout.LayoutParams(0,-2,1f));addView(value,LinearLayout.LayoutParams(context.dp(85),-2));addView(context.text("›",22,OknColors.MUTED,false,Gravity.CENTER),LinearLayout.LayoutParams(context.dp(24),-1))},LinearLayout.LayoutParams(-1,context.dp(72)).apply{bottomMargin=context.dp(7)})
        }
        root.addView(context.card(OknColors.RED,Color.rgb(45,12,17)).apply{
            addView(context.text("⚠  SaveParams (Guarded)",16,OknColors.RED,true));addView(context.text("บันทึกพารามิเตอร์ (ต้องยืนยัน)",11,OknColors.RED,true).apply{setPadding(0,context.dp(2),0,context.dp(7))});addView(context.text("This will write current settings to the device.\nUse only when you are ready.\nจะบันทึกการตั้งค่าปัจจุบันลงอุปกรณ์ ใช้เฉพาะเมื่อคุณพร้อมเท่านั้น",10,OknColors.TEXT));addView(saveButton,LinearLayout.LayoutParams(-1,-2).apply{topMargin=context.dp(11);bottomMargin=context.dp(8)});addView(saveStatus);addView(context.text("◉  Write only verified parameters.\n⚠  Keep device stable during write.",10,OknColors.RED).apply{setPadding(0,context.dp(6),0,0)})
        },LinearLayout.LayoutParams(-1,-2).apply{topMargin=context.dp(8)})
    }
    override fun bind(state:DspState){
        fun fmt(id:Int):String{val r=state.sensors[id]?.raw?:return "--";return when(id){19,20->if(r.equals("true",true))"Yes" else if(r.equals("false",true))"No" else r;0->r.toFloatOrNull()?.let{String.format(Locale.US,"%.1f V",it)}?:r;21->r.toFloatOrNull()?.let{v->String.format(Locale.US,"%.0f %%",if(v in 0f..1f)v*100f else v)}?:r;else->r}}
        values.forEach{(id,t)->t.text=fmt(id);t.setTextColor(if(id==19||id==20)if(t.text=="Yes")OknColors.GREEN else OknColors.TEXT else OknColors.TEXT)}
        saveButton.isEnabled=state.healthGatePass&&state.protocolIdle&&!state.saveInFlight;saveButton.alpha=if(saveButton.isEnabled)1f else .5f;saveStatus.text=if(state.saveInFlight)"Saving… guarded transaction in progress" else "Manual only. Never automatic."
    }
}

class MoreScreen(private val context:Context,private val actions:UiActions):BoundScreen{
    private val root=context.pageColumn();override val view=context.scrollPage(root)
    private val connection=context.text("Disconnected",13,OknColors.MUTED,true)
    private val err=context.text("No active error",11,OknColors.MUTED)
    init{
        root.addView(context.appBar());root.addView(context.sectionHeader("More","Diagnostics & verified scope"),LinearLayout.LayoutParams(-1,-2).apply{topMargin=context.dp(7);bottomMargin=context.dp(8)})
        root.addView(context.card().apply{addView(context.text("Device Session",14,OknColors.TEXT,true));addView(connection,LinearLayout.LayoutParams(-1,-2).apply{topMargin=context.dp(7)});addView(err,LinearLayout.LayoutParams(-1,-2).apply{topMargin=context.dp(4)});addView(context.row().apply{addView(context.neonButton("Reconnect"){actions.reconnect()},LinearLayout.LayoutParams(0,-2,1f));addView(context.neonButton("Refresh"){actions.refresh()},LinearLayout.LayoutParams(0,-2,1f).apply{leftMargin=context.dp(7)});addView(context.neonButton("Disconnect"){actions.disconnect()},LinearLayout.LayoutParams(0,-2,1f).apply{leftMargin=context.dp(7)})},LinearLayout.LayoutParams(-1,-2).apply{topMargin=context.dp(9)})},LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=context.dp(8)})
        root.addView(context.card().apply{addView(context.text("Verified Write Boundary",14,OknColors.GREEN,true));addView(context.text("✓  7 scalar controls\n✓  PEAKING type=12 EQ rows only\n✓  SaveParams ID7 manual-only\n\n🔒  Preset writes — UNVERIFIED\n🔒  Delay writes — UNVERIFIED\n🔒  Hardware crossover writes — UNVERIFIED\n🔒  Channel output / mute / phase writes — UNVERIFIED\n\nNo generic DSP write surface is exposed.",11,OknColors.TEXT))},LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=context.dp(8)})
        root.addView(context.neonButton("Open Debug Log"){actions.showLogs()},LinearLayout.LayoutParams(-1,-2))
        root.addView(context.text("OKN_DSP V98 • Native Android • Verified protocol boundary",9,OknColors.MUTED,false,Gravity.CENTER),LinearLayout.LayoutParams(-1,-2).apply{topMargin=context.dp(12)})
    }
    override fun bind(state:DspState){connection.text="${state.connection}: ${state.connectionMessage}";connection.setTextColor(if(state.healthGatePass)OknColors.GREEN else OknColors.CYAN);err.text=state.lastError?:"No active error";err.setTextColor(if(state.lastError!=null)OknColors.RED else OknColors.MUTED)}
}
