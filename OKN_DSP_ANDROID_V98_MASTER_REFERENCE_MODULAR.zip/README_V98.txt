OKN_DSP V98 — MASTER REFERENCE MODULAR ANDROID REBUILD
=======================================================
VersionCode: 98
VersionName: 7.1.0-v98-master-reference-modular
Package: com.okn.dsp
Platform: Native Android / Kotlin, minSdk 26, targetSdk 35

PURPOSE
-------
Fresh project structure created from scratch around the supplied UI MASTER REFERENCE.
The reference image is kept under evidence/ only for acceptance/hash validation; the app UI is built as real Android Views and controls, not as a screenshot/mockup.

REAL / VERIFIED DSP WRITE SCOPE
-------------------------------
- Verified BLE service/characteristics used by production transport:
  AB00 service 0000ab00-0000-1000-8000-00805f9b34fb
  AB01 write   0000ab01-0000-1000-8000-00805f9b34fb
  AB02 notify  0000ab02-0000-1000-8000-00805f9b34fb
- Auth/session flow: recovered startup probe + validated pre-auth decoder + continuous AES-CFB8 RandKey session.
- Device Description is read before Health Gate and before any reconnect replay.
- Verified scalar IDs only: 2,3,8,9,10,13,11.
- EQ actuator map: CH1..CH7 = 4,5,6,14,15,16,17.
- 15 bands/channel, 48-byte records; only live PEAKING type=12 rows can write F/Q/Gain.
- SaveParams ID7 exact trigger 570000000700000000; manual guarded button only.
- Generic writes are disabled.

UI / FUNCTIONAL STRUCTURE
-------------------------
- Home: real connection state, scan/connect, device/session health, master volume, 7 channels.
- Global: exactly 7 verified scalar controls with live slider updates.
- EQ: 7-channel overview, coefficient-derived live graph, per-channel editor, 15-row table, read-only locks on unsupported rows.
- Sensors: 4 verified descriptor sensors, read-only.
- Guarded Save: fresh Health Gate precheck -> exact ID7 manual trigger -> postcheck.
- More: connection tools, diagnostics, locked/unverified write boundary.
- Fixed five-tab bottom navigation: Home / Global / EQ / Sensors / More.
- Portrait + landscape use one central state store; Activity handles orientation without dropping GATT/session state.

REALTIME / STABILITY
--------------------
- One GATT write in flight.
- Latest-value-wins coalescing for realtime parameter targets.
- Critical FIFO for authentication, descriptor and SaveParams.
- 38 ms minimum GATT pacing plus callback timeout fail-closed behavior.
- Scalar ramping; TrebleBoost ID11 <=0.5 dB steps with nominal 48 ms callback-gated spacing.
- EQ gain/frequency/Q interpolation; full verified 48-byte PEAKING records.
- Phone STREAM_MUSIC volume and MasterVolume ID2 are synchronized with a feedback guard.
- Local persistence is debounced and separate from DSP SaveParams.
- Reconnect reads real DSP state first, passes Health Gate, then replays only remembered verified writable values through smoothing.

ARCHITECTURE
------------
app/             DspViewModel
ui/              screens, bottom navigation, cards, EQ graph
state/           central DspStateStore
ble/             BLE scan/connect/auth/GATT manager and verified profile
protocol/        frozen verified packet/parameter/EQ codecs and ParameterMapper
queue/           one-inflight realtime/critical command queue
smoothing/       scalar/EQ ramping and phone-volume bridge
persistence/     debounced local state persistence
repository/      DSP, Device and read-only Sensor repositories
logging/         structured bounded debug log
error/           centralized recoverable error classification

UNVERIFIED / LOCKED
-------------------
The following hardware write families remain locked because no verified packet/actuator evidence is used in V98:
- Preset write/recall
- Delay
- Hardware crossover
- Per-channel output/mute/phase
- 40af UUID role assignment
- Any generic/unknown actuator write
No guessed packet was added to expose these controls.

VALIDATION BOUNDARY
-------------------
The pure Kotlin protocol core is JVM-compiled and vector-tested by tools/ProtocolJvmSmoke.kt.
preflight_v98.py validates protocol/source invariants, the supplied UI reference hash, stable signing key hash, write boundary, and SaveParams policy.
A full Android APK compile is not claimed locally in this environment because the Android SDK toolchain is absent. The separate GitHub Actions workflow is the authoritative compile/sign path.
No source-only test can guarantee acoustic 'never pop/stutter'; target-DSP runtime listening/measurement remains required after installing the built APK.
