# OKN DSP V10 — Phase 1

V10 removes **purple** from the UI palette. Former purple accents are replaced with **gold/amber** or **teal** so the interface stays colorful without purple.

EQ colors: **Frequency = blue**, **Q = cyan/teal**, **Gain Band = mint green**. Ch1–Ch7 use blue, green, orange, red, gold, cyan and teal. The 15-band EQ graph remains spectrum-style but uses no purple points.

Preset behavior remains the V9 behavior: tapping the preset-name area or Save Preset opens the **Preset name** dialog; multiple presets can be saved, loaded and deleted.
