OKN_DSP V10 — MASTER VOLUME SINGLE-COMMIT ISOLATION

Real-device trigger
- V6/V7/V8/V9 all changed MasterVolume on the DSP but produced audible stutter/pumping while the finger was moving.
- The original GoloPine app on the same phone/DSP is acoustically stable.

Evidence used for V10
- Confirmed control characteristic: AB01.
- Confirmed verified MasterVolume actuator: ID2 FLOAT32.
- Historical original-app transport capture contained only 5 x 13-byte application writes in the observed session, while many repeated 9-byte messages were reads/other traffic.
- Therefore V10 stops inventing a high-rate stream of intermediate MasterVolume writes.

V10 behavior
1. Master slider UI follows the finger immediately on every MOVE.
2. No ID2 BLE packet is transmitted while the finger is moving.
3. ACTION_UP commits the exact final verified MasterVolume value once.
4. flushScalarRealtime(ID2) is a no-op so no duplicate final packet is generated.
5. No synthetic Master ramp / no sparse timer / no intermediate Master target queue.
6. BLE authentication, AES-CFB8 stream, AB00/AB01/AB02 transport and all verified packet formats are unchanged.
7. Other verified scalar/EQ paths are unchanged.

Purpose
This version isolates the remaining acoustic fault to Master write cadence. If V10 is acoustically clean, the root cause is the continuous/intermediate ID2 write stream used by V6-V9 rather than the ID2 packet itself.
