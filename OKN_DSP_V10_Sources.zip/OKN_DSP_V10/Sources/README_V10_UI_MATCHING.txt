OKN_DSP V10 — Phase 1 UI Matching Pass

Based on the V9 real-device video review.
Changes in V10:
- Locks UI typography to Android system Roboto font files when available, bypassing Samsung user-font substitution.
- Shrinks and relocates transient status messages so they no longer cover the main cards.
- Refines the vector-only DSP enclosure toward the reference proportions and uses a slim blue display/LED.
- Reduces the secondary EQ preview line and selected-point size so the 15-band colored curve matches the reference more closely.
- Adds a dropdown indicator to functional crossover filter-type controls.
- Keeps all V9 real-time controls, responsive layout, local session/presets, and fixed update signing key.

The uploaded reference image is NOT bundled, copied, or painted as a background.
Phase 2 DSP transport remains intentionally disabled.
