# Phase 1 UI only. Keep rules minimal.
