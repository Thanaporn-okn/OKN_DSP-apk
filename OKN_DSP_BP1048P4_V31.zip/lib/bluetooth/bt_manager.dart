// V31 Bluetooth scanner and connection manager
