import 'package:flutter/material.dart';

void main()=>runApp(const OKN());

class OKN extends StatelessWidget{
 const OKN({super.key});
 Widget build(BuildContext c)=>MaterialApp(
 debugShowCheckedModeBanner:false,
 theme:ThemeData.dark(),
 home:Scaffold(
 appBar:AppBar(title:const Text('OKN_DSP BP1048P4 V31')),
 body:const Padding(
 padding:EdgeInsets.all(20),
 child:Text(
 'Bluetooth DSP Controller\n\n'
 'Scan Device\n'
 'Connect / Disconnect\n'
 'TX Packet\n'
 'RX Data Buffer\n'
 'HEX TX RX Log\n'
 'BP1048P4 Command Handler\n'
 'CH1-CH7 DSP Control',
 style:TextStyle(fontSize:20)))
 ));
}
