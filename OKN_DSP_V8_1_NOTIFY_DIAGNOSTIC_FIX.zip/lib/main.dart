import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() => runApp(const OknDspApp());

class OknDspApp extends StatelessWidget {
  const OknDspApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'OKN DSP',
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.blue),
    home: const HomePage(),
  );
}

class Packet {
  final String ch, hex, time;
  final int len;
  const Packet(this.ch, this.hex, this.time, this.len);
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  static const methods = MethodChannel('okn_dsp/methods');
  static const events = EventChannel('okn_dsp/events');
  static const dspName = 'LE-GoIoPine_DSP_A';
  static const dspAddress = 'DC:E0:D9:88:C7:04';

  StreamSubscription? sub;
  final packets = <Packet>[];
  String status = 'พร้อมเชื่อมต่อ DSP';
  String gatt = '';
  String notifyStatus = 'ยังไม่ได้เปิด Notify';
  bool connected = false;

  @override
  void initState() {
    super.initState();
    sub = events.receiveBroadcastStream().listen((e) {
      if (!mounted || e is! Map) return;
      final type = e['type']?.toString() ?? '';
      if (type == 'status') {
        setState(() => status = e['message']?.toString() ?? '');
      } else if (type == 'gatt') {
        setState(() => gatt = e['text']?.toString() ?? '');
      } else if (type == 'notify') {
        setState(() => notifyStatus = e['message']?.toString() ?? '');
      } else if (type == 'connected') {
        setState(() => connected = true);
      } else if (type == 'disconnected') {
        setState(() {
          connected = false;
          notifyStatus = 'ตัดการเชื่อมต่อ';
        });
      } else if (type == 'rx') {
        final hex = e['data']?.toString() ?? '';
        final len = int.tryParse(e['length']?.toString() ?? '') ?? 0;
        final ch = e['characteristic']?.toString() ?? '';
        final t = e['time']?.toString() ?? '';
        setState(() {
          packets.insert(0, Packet(ch, hex, t, len));
          if (packets.length > 100) packets.removeLast();
        });
      }
    });
  }

  @override
  void dispose() {
    sub?.cancel();
    super.dispose();
  }

  Future<void> connect() async {
    setState(() {
      packets.clear();
      gatt = '';
      status = 'กำลังเชื่อมต่อ $dspName...';
      notifyStatus = 'กำลังเชื่อมต่อ';
    });
    try {
      await methods.invokeMethod('connect', {'address': dspAddress});
    } catch (e) {
      setState(() => status = 'เชื่อมต่อไม่ได้: $e');
    }
  }

  Future<void> copyPackets() async {
    final text = packets.reversed.map((p) =>
      '${p.time} | ${p.ch} | LEN=${p.len} | ${p.hex}').join('\n');
    if (text.isEmpty) return;
    await Clipboard.setData(ClipboardData(text: text));
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('คัดลอก RX ทั้งหมดแล้ว')),
      );
    }
  }

  Future<void> clearPackets() async {
    setState(() => packets.clear());
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('OKN DSP Controller V8'),
      actions: [
        IconButton(
          tooltip: 'เชื่อมต่อ DSP',
          onPressed: connect,
          icon: Icon(connected ? Icons.bluetooth_connected : Icons.bluetooth),
        ),
      ],
    ),
    body: Padding(
      padding: const EdgeInsets.all(12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Card(child: Padding(
          padding: const EdgeInsets.all(14),
          child: Text(
            'DSP ที่ตรวจพบจริง\n$dspName\n$dspAddress\n\n$status',
            style: const TextStyle(fontSize: 16),
          ),
        )),
        Row(children: [
          Expanded(child: Card(child: ListTile(
            dense: true,
            title: const Text('Notify'),
            subtitle: Text(notifyStatus),
            leading: Icon(connected ? Icons.notifications_active : Icons.notifications_none),
          ))),
          IconButton(
            tooltip: 'คัดลอก RX',
            onPressed: packets.isEmpty ? null : copyPackets,
            icon: const Icon(Icons.copy),
          ),
          IconButton(
            tooltip: 'ล้าง RX',
            onPressed: packets.isEmpty ? null : clearPackets,
            icon: const Icon(Icons.delete_outline),
          ),
        ]),
        if (gatt.isNotEmpty)
          SizedBox(height: 245, child: Card(
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: SingleChildScrollView(child: SelectableText(gatt,
                style: const TextStyle(fontSize: 11, fontFamily: 'monospace'))),
            ),
          )),
        const SizedBox(height: 4),
        Row(children: [
          const Expanded(child: Text('RX จาก Notify',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
          Text('${packets.length} packets'),
        ]),
        Expanded(
          child: packets.isEmpty
            ? const Center(child: Text(
                'ยังไม่มี packet\nเชื่อมต่อ DSP แล้วรอดู AB02 / AB03',
                textAlign: TextAlign.center))
            : ListView.builder(
                itemCount: packets.length,
                itemBuilder: (_, i) {
                  final p = packets[i];
                  return Card(
                    child: Padding(
                      padding: const EdgeInsets.all(8),
                      child: SelectableText(
                        '${p.time}  ${p.ch}\nLEN=${p.len}\n${p.hex}',
                        style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
                      ),
                    ),
                  );
                }),
        ),
        const Text('🛑 V8 อ่าน/รับ Notify เท่านั้น — ไม่มี Write และไม่ส่งคำสั่ง DSP',
          textAlign: TextAlign.center),
      ]),
    ),
  );
}
