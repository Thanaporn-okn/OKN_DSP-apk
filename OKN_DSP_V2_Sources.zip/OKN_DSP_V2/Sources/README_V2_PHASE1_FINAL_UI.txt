OKN DSP - VERSION 2 - PHASE 1 FINAL UI
=======================================

BASIS
- Version 2 is built from the working Version 1 source.
- Home / Mix / Eq are native Android views written in Java.
- The supplied screenshots remain design references only in Sources/.
- No screenshot is loaded by the app or used as a screen background.

VERSION 2 UI / REALTIME CHANGES
1. UI spacing and responsive sizing refined for phones and tablets.
2. EQ channel selector now keeps all Ch1-Ch7 tabs visible using weighted responsive tabs.
3. EQ graph was rebuilt as a real parametric-EQ response graph:
   - 15 peaking-EQ biquads are evaluated together at 48 kHz.
   - Frequency changes update the graph immediately.
   - Gain changes update the graph immediately.
   - Q (Quality Factor) now visibly changes curve width/shape immediately.
   - Curve includes a soft filled response area and selected-band highlight.
4. Direct EQ graph control:
   - Touch selects the nearest band.
   - Drag left/right changes selected-band frequency in real time.
   - Drag up/down changes selected-band gain in real time.
   - On release, the lower parameter controls refresh to the exact dragged values.
5. Reset EQ now restores Frequency + Gain + Q for the selected channel.
6. Auto-save remains active while controls move.
   - Fast writes are rate-limited to keep slider/graph rendering smooth.
   - onPause() and drag/slider release perform synchronous persistence.
7. Values from Version 1 remain compatible because the same preference store is retained.
8. Themes remain persistent: Ice Light / Midnight / AMOLED.
9. Stable app signing identity is preserved.

CONTROLS PRESENT IN PHASE 1
- Master Volume
- Bass Volume
- Bass Cutoff
- Volume Ch1-Ch7
- EQ: 15 bands x 7 channels
- Per-band Frequency 20 Hz - 20 kHz
- Per-band Q 0.10 - 10.00
- Per-band Gain -12 dB - +12 dB
- Local preset save/load
- Persistent page/channel/band/theme/control state

PHASE BOUNDARY
- Version 2 still does not invent a DSP/BLE protocol.
- Real Bluetooth device discovery, command frames, DSP writes/reads and hardware verification belong to Phase 2 and will be implemented from the DSP protocol/source data supplied by the user.

AUTOMATIC BUILD
- Put the separate OKN_DSP_AutoBuild.yml in .github/workflows/ once.
- Upload OKN_DSP_V2_Sources.zip to the repository root.
- The workflow detects the highest OKN_DSP_V*_Sources.zip automatically and builds it.
- Future source ZIPs (V3, V4, ...) use the same workflow without replacing it.

VERSION RULE
- Version 2: versionCode 1002, versionName 2.0.0-phase1-final.
- If an error is found, do not overwrite Version 2. Create Version 3.

SHA256
- Sources/SHA256SUMS.txt hashes all files in this source tree except SHA256SUMS.txt itself.
- The ZIP's SHA256 is supplied separately because a ZIP cannot contain a stable hash of itself.
