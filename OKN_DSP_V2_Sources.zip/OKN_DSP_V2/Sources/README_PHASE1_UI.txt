OKN_DSP V2 - Phase 1 UI Refinement
===================================

V2 is a code-drawn refinement based on the uploaded four-page reference and the V1 run video.
The reference screenshot is NOT embedded, copied, or used as an application background.
The UI is drawn at runtime with Android Canvas primitives, paths, gradients, text, sliders, knobs and graphs.

V2 visual changes
- Reworked the whole Home / Mix / Eq / Crossover layout to follow the reference proportions more closely.
- Switched the logical design baseline to 430 x 768 so tall phones do not stretch control cards excessively.
- Added code-drawn mountain/wave atmosphere, neon highlights, compact value badges and a vector DSP chassis.
- Home now follows the reference hierarchy: hero, DSP device card, five status rows, input source, quick actions and sound banner.
- Mix cards are denser and closer to the reference; knobs and slider badges no longer grow into large empty panels on tall phones.
- Eq now has 7 channel tabs, a filled 15-band graph, selected-band navigation, Frequency / Gain / Q controls and a compact output level card.
- Crossover now has magnitude/phase response, filter-mode selectors, filter-family selectors, slope buttons, frequency sliders and compact time alignment cards.

Interaction
- All visible navigation, source, preset, channel, filter, slope, unit and action buttons are touchable.
- Sliders and knobs update during ACTION_MOVE and redraw immediately.
- EQ graph points can be dragged in frequency and gain; the graph follows immediately.
- Crossover curves follow crossover frequency changes immediately.
- Save / Load preset remains an in-memory Phase 1 demo.

Responsive behavior
- Full-screen immersive mode is enabled.
- Layout is based on a 430 x 768 reference canvas and scales to the available viewport.
- Taller phones keep component proportions and add breathing room instead of vertically stretching the controls.
- Wider tablet viewports receive additional logical width while preserving the reference-height proportions.

Phase boundary
- Phase 1 contains UI and local demo state only.
- No BLE / DSP command transport is included in V2.
- Real DSP transport is reserved for Phase 2 using the protocol/control files supplied by the user.

Version rule
- V1 remains unchanged.
- If a delivered V2 build/runtime error is found, the correction must be delivered as V3 rather than silently replacing V2.
