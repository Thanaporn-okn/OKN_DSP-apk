OKN_DSP V2 - PHASE 1 UI
=======================
This source package is a clean code-drawn DSP interface inspired by the uploaded visual reference.
The uploaded screenshot is NOT used as an app background.

Pages:
- Home
- Mix
- Eq
- Crossover

Phase-1 behavior:
- Touch controls update local values immediately.
- EQ/crossover graphs redraw immediately from local state.
- UI scales to the available phone/tablet view size.
- Full-screen/immersive mode is requested safely.
- V2 includes startup/render recovery hardening after the V1 runtime crash report.

Not included yet:
- Real DSP/BLE protocol commands. These belong to Phase 2 and will be based only on uploaded protocol/control data.
