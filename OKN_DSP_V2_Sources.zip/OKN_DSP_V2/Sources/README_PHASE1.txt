OKN DSP V2 - PHASE 1 UI REFINEMENT
==================================

Goal
----
Refine the Version 1 UI foundation so the real coded Android interface more closely matches the
supplied Home, Mix and EQ visual references while preserving immediate interaction and persistence.
The screenshots in Sources/References are reference-only and are NOT used as page backgrounds,
overlays, WebViews or runtime screen images.

Implemented in V2
-----------------
1. Responsive Home / Mix / EQ pages for phones and tablets.
2. Seven EQ channel tabs now share the available width instead of requiring horizontal scrolling.
3. Card radius, spacing, header sizing and bottom navigation proportions refined toward the reference UI.
4. Light/Dark theme toggle remains live and persisted.
5. Master Volume, Bass Volume, Bass Cutoff and seven Channel Volume controls update immediately.
6. Seven EQ channels, each with fifteen bands.
7. Per-band Frequency, Q and Gain controls; Q display refined to one decimal place.
8. Direct graph dragging updates Frequency and Gain with no artificial delay.
9. EQ line is now smoothly interpolated between all fifteen band points and redraws on every change.
10. Selected EQ point has a clearer focus/glow state.
11. Automatic SharedPreferences persistence still occurs on every value change.
12. Last page, selected EQ channel and selected band are restored after app restart.
13. Activity pause adds a synchronous durability checkpoint after the non-blocking real-time writes.
14. Local preset save/load, search, theme menu and Bluetooth settings shortcut remain functional.
15. Stable signing key is retained for install/update continuity.

Phase boundary
--------------
Phase 1 does not invent DSP/BLE packets or fake a hardware connection. Phase 2 will bind these already-live
UI values to the real control protocol from the user's uploaded DSP data, including device feedback.

Version rule
------------
V1 is never overwritten. This refinement is V2. Any later build/runtime correction or new iteration must
become V3, then V4, and so on.
