OKN DSP VERSION 2 - PHASE 1 UI REFINEMENT

Basis
- Rebuilt UI remains code-drawn; none of the supplied screenshots are used as runtime backgrounds.
- Version 2 refines Version 1 using the supplied UI references and the Version 1 test video.
- Phase 1 still does not send any commands to DSP hardware.

Version 2 changes
- Wider usable content area and refined mobile/tablet typography scaling.
- Home, Mix and Eq cards use tighter reference-like page margins.
- Eq channel tabs and cards have more reference-like spacing and dimensions.
- Eq graph redraw remains immediate while controls move.
- Eq graph points can now be dragged directly: horizontal movement changes frequency and vertical movement changes gain.
- Frequency remains logarithmic from 20 Hz to 20 kHz.
- Preset name field is now interactive and opens the keyboard for editing.
- User preset name is persisted locally and reused by Save/Load.
- Bottom navigation remains fixed while page content scrolls.
- Touch targets are expanded around small controls without changing the visible design.

Implemented screens
1. Home
   - System Ready status card
   - Connection/status cards
   - Quick Control shortcut
   - Search and overflow buttons
2. Mix
   - Master Volume, Bass Volume and Bass Cutoff
   - Channel 1-7 volume sliders
   - Values update immediately while dragging
3. Eq
   - Channel tabs 1-7
   - 15-band interactive response graph
   - Direct graph-point dragging
   - Frequency / Q / Ch Volume controls
   - Reset EQ and previous/next band
   - Editable local preset name and local preset save/load demo

Responsive behavior
- Density-independent drawing; no fixed bitmap layout.
- Adaptive centered content width up to 760 dp.
- Typography scales modestly on wider tablets.
- Vertical scrolling is enabled whenever content is taller than the available area.
- Bottom navigation stays fixed and usable.

Version policy
- This is V2. V1 remains unchanged.
- Every later correction/error fix must be released as a new version number (V3, V4, ...).
