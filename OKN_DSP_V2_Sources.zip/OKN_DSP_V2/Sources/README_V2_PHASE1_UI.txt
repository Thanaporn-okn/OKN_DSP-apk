OKN_DSP V2 - Phase 1 UI

Reason for V2
- Android Device Care screenshot reported that OKN_DSP was failing frequently.
- The screenshot does not contain a stack trace, so it does not identify the exact crashing line.
- Per project rule, an observed runtime error creates a new version instead of overwriting V1.

V2 stability changes
- Removed the permanent 60 ms redraw loop from the Mix screen. The UI is now event-driven while controls still update immediately during drag/touch.
- The Mix waveform is rendered statically instead of forcing continuous background redraws.
- Added lifecycle-aware hostActive state so paused/background UI does not schedule work.
- Added guarded Canvas rendering. A RuntimeException enters a lightweight recovery screen instead of repeatedly crashing the Activity.
- Added guarded touch handling so invalid runtime input cannot terminate the UI thread.
- Added lightweight crash diagnostics (class/message + stack trace in private app preferences) for the next failure.
- Isolated V2 SharedPreferences from earlier builds.
- Disabled Android Auto Backup for this prototype so stale app-state from older builds is not silently restored.
- Hardware acceleration remains explicitly enabled.

Phase scope
- Phase 1 UI only.
- No real BLE/DSP transport is enabled yet.
- Uploaded design is reference only; it is NOT copied or used as an image background.
