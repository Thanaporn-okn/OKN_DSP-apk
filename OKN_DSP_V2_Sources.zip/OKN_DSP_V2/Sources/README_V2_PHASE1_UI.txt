OKN DSP V2 — Phase 1 UI startup-hardening release

This version is created because V1 was reported to close immediately on launch.
The exact device exception was not available, so V2 does not claim a guessed root cause.
Instead, V2 hardens all launch-critical paths while preserving the Phase 1 UI design and behavior.

Changes from V1:
- New Android versionCode 1002 and visible V2 label.
- Removed direct WindowInsetsController usage from launch path; uses broad-compatible system-bar flags.
- UI icon is decoded at a bounded sample size to avoid loading the full launcher bitmap into the custom view.
- Custom rendering is guarded: a runtime drawing failure displays a recovery screen instead of terminating Activity.
- Startup construction is guarded: if the main custom UI cannot initialize, an in-app recovery screen is shown.
- State remains local and persists in SharedPreferences.
- Home / Mix / EQ behavior and Phase 1 DSP transport boundary are preserved.

Phase 2 DSP hardware transport is still intentionally disabled until real protocol files are supplied.
The reference images are design references only; no screenshot is used as a screen background.
