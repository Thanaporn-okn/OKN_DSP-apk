OKN_DSP V2
===========

Version reason:
- V2 is created because V1 failed at :app:compileDebugJavaWithJavac.
- Exact V1 compiler error:
  BleManager.java: cannot find symbol BluetoothGatt.TRANSPORT_LE

V2 fix:
- Uses BluetoothDevice.TRANSPORT_LE, which is the Android BLE transport constant used by BluetoothDevice.connectGatt(..., transport).
- Added import android.bluetooth.BluetoothDevice.
- No UI layout/interaction behavior was changed by this compile fix.

Scope retained from the clean restart:
- UI is based only on the two supplied reference screens: Home and EQ.
- Visible sliders/toggles/presets/channels/reset/save/load controls have immediate local interaction.
- BLE scanning/connection is implemented.
- Known captured GATT characteristic is retained exactly:
  0000ab01-0000-1000-8000-00805f9b34fb
- The app can discover/read/subscribe to that characteristic when supported.

Protocol boundary:
The captured data available so far does not contain a verified DSP parameter WRITE packet format.
V2 does not invent hardware commands. UI values update immediately; real DSP parameter writes must wait
for a verified writable characteristic and packet format from the actual device protocol.

Version rule:
If V2 produces another build/runtime/install/opening error, fix it as V3 and keep V2 unchanged.
