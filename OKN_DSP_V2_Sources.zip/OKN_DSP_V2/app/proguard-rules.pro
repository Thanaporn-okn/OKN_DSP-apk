# Phase 1: no custom ProGuard/R8 rules required.
