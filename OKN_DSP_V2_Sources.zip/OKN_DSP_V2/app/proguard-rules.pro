# Phase 1 intentionally uses no reflection and needs no custom keep rules.
