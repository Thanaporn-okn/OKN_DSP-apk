# Phase 1 uses no reflection-heavy libraries. Keep rules intentionally minimal.
