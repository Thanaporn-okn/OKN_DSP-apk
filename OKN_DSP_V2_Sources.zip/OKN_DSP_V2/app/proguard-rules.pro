# V1 UI prototype: no custom ProGuard/R8 rules required.
