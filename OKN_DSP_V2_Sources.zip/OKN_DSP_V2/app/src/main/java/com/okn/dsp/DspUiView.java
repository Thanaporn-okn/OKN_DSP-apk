package com.okn.dsp;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

/**
 * OKN_DSP Version 2 - Phase 1 UI.
 * Entire interface is drawn from code. The uploaded design is used only as a visual reference;
 * no screenshot or bitmap from it is used as a background.
 */
public class DspUiView extends View {
    private static final float DESIGN_W = 430f;
    private static final float DESIGN_H = 900f;

    private static final int PAGE_HOME = 0;
    private static final int PAGE_MIX = 1;
    private static final int PAGE_EQ = 2;
    private static final int PAGE_CROSS = 3;

    private static final int TYPE_BUTTON = 1;
    private static final int TYPE_SLIDER = 2;
    private static final int TYPE_EQ_GRAPH = 3;

    private static final int ID_NAV = 100;
    private static final int ID_CONNECT = 110;
    private static final int ID_GEAR = 111;
    private static final int ID_INPUT = 120;
    private static final int ID_QUICK = 130;
    private static final int ID_EQ_CHANNEL = 140;
    private static final int ID_EQ_SAVE = 141;
    private static final int ID_EQ_LOAD = 142;
    private static final int ID_EQ_MORE = 143;
    private static final int ID_EQ_PREV = 144;
    private static final int ID_EQ_NEXT = 145;
    private static final int ID_CROSS_PRESET = 150;
    private static final int ID_CROSS_VIEW = 151;
    private static final int ID_CROSS_LINK = 152;
    private static final int ID_CROSS_FILTER = 153;
    private static final int ID_CROSS_SLOPE = 154;
    private static final int ID_DELAY_UNIT = 155;
    private static final int ID_RESET_DELAY = 156;
    private static final int ID_AUTO_ALIGN = 157;

    private static final int S_MASTER = 200;
    private static final int S_BASS = 201;
    private static final int S_BASS_CUTOFF = 202;
    private static final int S_BASS_BOOST = 203;
    private static final int S_MIDDLE_BOOST = 204;
    private static final int S_TREBLE_BOOST = 205;
    private static final int S_EQ_FREQ = 210;
    private static final int S_EQ_GAIN = 211;
    private static final int S_EQ_Q = 212;
    private static final int S_EQ_OUTPUT = 213;
    private static final int S_CROSS_CUTOFF = 220;
    private static final int S_DELAY = 221;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final ArrayList<Hit> hits = new ArrayList<>();
    private final SharedPreferences prefs;

    private int page = PAGE_HOME;
    private boolean connected = true;
    private int selectedInput = 0;

    private float masterVolume = -6f;
    private float bassVolume = 0f;
    private float bassCutoff = 80f;
    private float bassBoost = 4f;
    private float middleBoost = 2f;
    private float trebleBoost = 3f;

    private final String[] channelNames = {"FL", "FR", "C", "RL", "RR", "SUB", "AUX"};
    private final float[][] eqFreq = new float[7][15];
    private final float[][] eqGain = new float[7][15];
    private final float[][] eqQ = new float[7][15];
    private final float[] outputLevel = new float[7];
    private int selectedChannel = 0;
    private int selectedBand = 5;

    private final String[] crossNames = {"SUB", "MID", "HIGH", "FULL"};
    private final int[] crossColors = {
            Color.rgb(212, 53, 255), Color.rgb(20, 141, 255),
            Color.rgb(0, 238, 171), Color.rgb(255, 175, 45)};
    private final float[] crossCutoff = {80f, 3000f, 3000f, 20000f};
    private final int[] crossFilter = {0, 1, 2, 3};
    private final int[] crossSlope = {0, 0, 0, 0};
    private final float[] delayMs = {2.50f, 1.20f, 0.00f, 0.80f};
    private boolean linkLR = true;
    private int crossView = 0;
    private int delayUnit = 0;

    private Hit activeHit;
    private boolean renderFault = false;
    private String renderFaultMessage = "";

    public DspUiView(Context context) {
        super(context);
        // Keep the default hardware-accelerated layer. V1 forced a software layer,
        // which is unnecessary for this UI and can trigger vendor-specific render paths.
        setFocusable(true);
        prefs = context.getSharedPreferences("okn_dsp_phase1", Context.MODE_PRIVATE);
        initEqDefaults();
    }

    private void initEqDefaults() {
        float[] defaults = {25f, 40f, 63f, 100f, 160f, 250f, 400f, 630f, 1000f,
                1600f, 2500f, 4000f, 6300f, 10000f, 16000f};
        float[] shape = {-1f, 1f, 4f, 6f, 4f, 2f, 2.5f, 5f, 2f, -0.5f, 3f, 6f, 4.5f, 1.5f, -1f};
        for (int ch = 0; ch < 7; ch++) {
            for (int b = 0; b < 15; b++) {
                eqFreq[ch][b] = defaults[b];
                eqGain[ch][b] = shape[b] * (1f - ch * 0.045f);
                eqQ[ch][b] = 1.2f;
            }
            outputLevel[ch] = 0f;
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        hits.clear();

        if (renderFault) {
            drawRenderFallback(canvas);
            return;
        }

        try {
            float sx = Math.max(1f, getWidth()) / DESIGN_W;
            float sy = Math.max(1f, getHeight()) / DESIGN_H;
            canvas.save();
            try {
                canvas.scale(sx, sy);
                drawBackground(canvas);
                drawHeader(canvas);
                switch (page) {
                    case PAGE_HOME: drawHome(canvas); break;
                    case PAGE_MIX: drawMix(canvas); break;
                    case PAGE_EQ: drawEq(canvas); break;
                    case PAGE_CROSS: drawCrossover(canvas); break;
                    default: drawHome(canvas);
                }
                drawBottomNav(canvas);
            } finally {
                canvas.restore();
            }
        } catch (RuntimeException e) {
            renderFault = true;
            renderFaultMessage = e.getClass().getSimpleName();
            Log.e("OKN_DSP", "UI render failure", e);
            drawRenderFallback(canvas);
        }
    }

    private void drawRenderFallback(Canvas canvas) {
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.rgb(3, 14, 32));
        canvas.drawRect(0, 0, getWidth(), getHeight(), p);

        p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        p.setTextAlign(Paint.Align.CENTER);
        p.setTextSize(Math.max(18f, getWidth() * 0.055f));
        p.setColor(Color.WHITE);
        canvas.drawText("OKN_DSP", getWidth() * 0.5f, getHeight() * 0.42f, p);

        p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
        p.setTextSize(Math.max(12f, getWidth() * 0.032f));
        p.setColor(Color.rgb(90, 190, 255));
        canvas.drawText("V2 UI safe mode", getWidth() * 0.5f, getHeight() * 0.48f, p);

        p.setTextSize(Math.max(10f, getWidth() * 0.026f));
        p.setColor(Color.rgb(185, 205, 230));
        String detail = renderFaultMessage.isEmpty() ? "Renderer recovered" : "Renderer recovered: " + renderFaultMessage;
        canvas.drawText(detail, getWidth() * 0.5f, getHeight() * 0.53f, p);
    }

    private void drawBackground(Canvas c) {
        p.setShader(new LinearGradient(0, 0, 0, DESIGN_H,
                new int[]{Color.rgb(4, 10, 26), Color.rgb(0, 25, 54), Color.rgb(3, 14, 32)},
                null, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, DESIGN_W, DESIGN_H, p);
        p.setShader(null);

        p.setColor(Color.argb(90, 0, 110, 255));
        p.setShader(new RadialGradient(310, 60, 170,
                Color.argb(95, 0, 112, 255), Color.TRANSPARENT, Shader.TileMode.CLAMP));
        c.drawCircle(310, 60, 170, p);
        p.setShader(null);

        // Abstract code-drawn horizon, not a bitmap.
        path.reset();
        path.moveTo(0, 118);
        path.lineTo(65, 92);
        path.lineTo(120, 120);
        path.lineTo(180, 82);
        path.lineTo(236, 121);
        path.lineTo(302, 91);
        path.lineTo(360, 116);
        path.lineTo(430, 83);
        path.lineTo(430, 165);
        path.lineTo(0, 165);
        path.close();
        p.setColor(Color.argb(80, 0, 92, 170));
        c.drawPath(path, p);
    }

    private void drawHeader(Canvas c) {
        text(c, "OKN", 22, 44, 31, Color.WHITE, true);
        text(c, "_DSP", 103, 44, 31, Color.rgb(28, 148, 255), true);
        text(c, "S O U N D   I N   H I G H E R   D E F I N I T I O N", 23, 63, 8.5f,
                Color.rgb(174, 191, 219), false);

        rounded(c, 314, 38, 406, 70, 16, Color.argb(110, 1, 40, 76), Color.argb(130, 23, 116, 179), 1);
        p.setColor(connected ? Color.rgb(21, 244, 165) : Color.rgb(255, 105, 105));
        c.drawCircle(328, 54, 6, p);
        text(c, connected ? "Connected" : "Offline", 340, 59, 11,
                connected ? Color.rgb(70, 255, 190) : Color.rgb(255, 150, 150), false);
        addButton(314, 38, 406, 70, ID_CONNECT, 0);

        text(c, "⚙", 405, 27, 20, Color.WHITE, false, Paint.Align.CENTER);
        addButton(386, 8, 426, 38, ID_GEAR, 0);
    }

    private void drawHome(Canvas c) {
        rounded(c, 16, 132, 414, 402, 14, Color.argb(160, 3, 36, 72), Color.argb(120, 16, 123, 206), 1);
        text(c, "DSP DEVICE", 28, 151, 10, Color.rgb(166, 190, 225), false);
        text(c, "OKN DSP-8 Pro", 28, 177, 22, Color.WHITE, true);
        text(c, "8-Channel Digital Signal Processor", 28, 196, 11, Color.rgb(184, 202, 229), false);

        // Device illustration drawn with geometry.
        p.setShader(new LinearGradient(28, 230, 232, 328,
                new int[]{Color.rgb(25, 31, 42), Color.rgb(2, 8, 16)}, null, Shader.TileMode.CLAMP));
        path.reset();
        path.moveTo(28, 238); path.lineTo(188, 218); path.lineTo(233, 238); path.lineTo(75, 260); path.close();
        c.drawPath(path, p);
        path.reset();
        path.moveTo(28, 238); path.lineTo(75, 260); path.lineTo(75, 326); path.lineTo(28, 300); path.close();
        c.drawPath(path, p);
        path.reset();
        path.moveTo(75, 260); path.lineTo(233, 238); path.lineTo(233, 304); path.lineTo(75, 326); path.close();
        c.drawPath(path, p);
        p.setShader(null);
        p.setColor(Color.rgb(0, 106, 255));
        c.drawRoundRect(new RectF(140, 281, 205, 285), 2, 2, p);
        text(c, "OKN_DSP", 98, 249, 9, Color.rgb(195, 209, 230), true);
        text(c, "DSP-8 PRO", 176, 300, 6.5f, Color.rgb(186, 198, 218), false);

        statusRow(c, 270, 187, Color.rgb(0, 141, 255), "◊", "Connected", "Ready for audio control");
        statusRow(c, 270, 240, Color.rgb(0, 230, 160), "▥", "Excellent", "Signal Strength");
        statusRow(c, 270, 293, Color.rgb(0, 220, 155), "▣", "100%", "Battery");
        statusRow(c, 270, 346, Color.rgb(0, 214, 174), "▤", "v2.0.0", "UI Phase 1");

        rounded(c, 16, 411, 414, 502, 13, Color.argb(150, 3, 34, 65), Color.argb(105, 18, 115, 191), 1);
        text(c, "INPUT SOURCE", 28, 429, 9, Color.rgb(169, 191, 224), false);
        String[] inputs = {"Bluetooth", "AUX", "Optical", "USB"};
        for (int i = 0; i < 4; i++) {
            float l = 27 + i * 94;
            int fill = i == selectedInput ? Color.argb(170, 0, 89, 172) : Color.argb(120, 9, 43, 77);
            int stroke = i == selectedInput ? Color.rgb(0, 145, 255) : Color.argb(80, 80, 145, 200);
            rounded(c, l, 438, l + 86, 490, 9, fill, stroke, 1);
            text(c, i == 0 ? "⌁" : i == 1 ? "AUX" : i == 2 ? "▣" : "↯", l + 43, 458, i == 1 ? 8 : 17,
                    i == selectedInput ? Color.rgb(69, 193, 255) : Color.rgb(204, 218, 237), i == 1, Paint.Align.CENTER);
            text(c, inputs[i], l + 43, 480, 9.5f, Color.WHITE, false, Paint.Align.CENTER);
            addButton(l, 438, l + 86, 490, ID_INPUT, i);
        }

        rounded(c, 16, 509, 414, 660, 13, Color.argb(150, 3, 34, 65), Color.argb(105, 18, 115, 191), 1);
        text(c, "QUICK ACTIONS", 28, 528, 9, Color.rgb(169, 191, 224), false);
        quickCard(c, 27, 539, 204, 594, 0, "Load Preset", "Recall saved setup", Color.rgb(167, 50, 240));
        quickCard(c, 212, 539, 403, 594, 1, "Save Preset", "Save current setup", Color.rgb(14, 126, 255));
        quickCard(c, 27, 601, 204, 648, 2, "Device Settings", "Advanced options", Color.rgb(0, 209, 163));
        quickCard(c, 212, 601, 403, 648, 3, "About Device", "Info & support", Color.rgb(236, 131, 25));

        rounded(c, 16, 670, 414, 708, 13, Color.argb(140, 3, 40, 78), Color.argb(100, 13, 116, 208), 1);
        for (int i = 0; i < 48; i++) {
            float x = 25 + i * 7.8f;
            float amp = 4f + (float) (Math.sin(i * 0.53) * 5 + 5);
            p.setColor(Color.argb(145, 0, 146, 255));
            c.drawRect(x, 689 - amp, x + 1.2f, 689 + amp, p);
        }
        text(c, "Premium Sound Experience", 215, 687, 10, Color.WHITE, true, Paint.Align.CENTER);
        text(c, "Precision Audio. In Your Hands.", 215, 700, 7.5f, Color.rgb(174, 196, 224), false, Paint.Align.CENTER);
    }

    private void drawMix(Canvas c) {
        text(c, "Mix", 20, 111, 26, Color.WHITE, true);
        text(c, "Real-time mixing and tone control", 20, 132, 12, Color.rgb(173, 195, 225), false);
        text(c, "▥▥▥▥▥▥", 354, 109, 13, Color.rgb(38, 161, 255), false, Paint.Align.CENTER);
        text(c, "LIVE AUDIO CONTROL", 354, 128, 7.5f, Color.rgb(167, 193, 225), false, Paint.Align.CENTER);

        sliderCard(c, 18, 145, 412, 242, "Master Volume", "Control overall output level", masterVolume, -60, 0,
                Color.rgb(185, 58, 255), S_MASTER, "dB");
        sliderCard(c, 18, 252, 412, 349, "Bass Volume", "Adjust bass channel level", bassVolume, -20, 20,
                Color.rgb(0, 213, 255), S_BASS, "dB");

        knobCard(c, 18, 360, 209, 507, "Bass Cutoff", "Low-pass filter cutoff", bassCutoff, 20, 300,
                Color.rgb(0, 245, 184), S_BASS_CUTOFF, "Hz");
        knobCard(c, 219, 360, 412, 507, "Bass Boost", "Boost low frequencies", bassBoost, -12, 12,
                Color.rgb(196, 68, 255), S_BASS_BOOST, "dB");
        knobCard(c, 18, 516, 209, 663, "Middle Boost", "Boost mid frequencies", middleBoost, -12, 12,
                Color.rgb(0, 128, 255), S_MIDDLE_BOOST, "dB");
        knobCard(c, 219, 516, 412, 663, "Treble Boost", "Boost high frequencies", trebleBoost, -12, 12,
                Color.rgb(255, 175, 44), S_TREBLE_BOOST, "dB");
    }

    private void drawEq(Canvas c) {
        text(c, "Eq", 20, 111, 26, Color.WHITE, true);
        text(c, "S H A P E   Y O U R   S O U N D", 20, 129, 7.5f, Color.rgb(167, 190, 221), false);
        smallButton(c, 182, 96, 275, 132, "⇩  Save Preset", ID_EQ_SAVE, 0, Color.rgb(0, 168, 165));
        smallButton(c, 281, 96, 376, 132, "▣  Load Preset", ID_EQ_LOAD, 0, Color.rgb(139, 49, 221));
        smallButton(c, 382, 96, 413, 132, "⋮", ID_EQ_MORE, 0, Color.rgb(24, 59, 91));

        for (int i = 0; i < 7; i++) {
            float l = 18 + i * 56;
            rounded(c, l, 142, l + 50, 187, 7,
                    i == selectedChannel ? Color.argb(170, 0, 91, 171) : Color.argb(110, 5, 41, 75),
                    i == selectedChannel ? Color.rgb(0, 147, 255) : Color.argb(70, 77, 132, 183), 1);
            text(c, "Ch " + (i + 1), l + 25, 157, 7.5f, Color.rgb(163, 189, 221), false, Paint.Align.CENTER);
            text(c, channelNames[i], l + 25, 177, 10, Color.WHITE, true, Paint.Align.CENTER);
            addButton(l, 142, l + 50, 187, ID_EQ_CHANNEL, i);
        }

        rounded(c, 16, 197, 414, 410, 13, Color.argb(145, 2, 41, 75), Color.argb(100, 15, 119, 192), 1);
        text(c, "15 Band Equalizer", 28, 219, 13, Color.WHITE, true);
        RectF graph = new RectF(47, 232, 398, 386);
        drawGrid(c, graph, 10, 6);
        drawEqGraph(c, graph);
        text(c, "+12", 25, 247, 7, Color.rgb(166, 194, 225), false);
        text(c, "0", 30, 309, 7, Color.rgb(166, 194, 225), false);
        text(c, "-12", 24, 375, 7, Color.rgb(166, 194, 225), false);
        text(c, "20", 47, 399, 7, Color.rgb(166, 194, 225), false, Paint.Align.CENTER);
        text(c, "630", 185, 399, 7, Color.rgb(166, 194, 225), false, Paint.Align.CENTER);
        text(c, "20k", 398, 399, 7, Color.rgb(166, 194, 225), false, Paint.Align.CENTER);
        addEqGraph(graph.left, graph.top, graph.right, graph.bottom);

        rounded(c, 16, 421, 414, 561, 13, Color.argb(145, 2, 41, 75), Color.argb(100, 15, 119, 192), 1);
        text(c, "Band Controls", 28, 442, 13, Color.WHITE, true);
        text(c, "Band " + (selectedBand + 1) + " of 15", 325, 442, 8, Color.rgb(164, 188, 219), false, Paint.Align.CENTER);
        smallButton(c, 359, 427, 382, 450, "‹", ID_EQ_PREV, 0, Color.rgb(15, 53, 89));
        smallButton(c, 386, 427, 409, 450, "›", ID_EQ_NEXT, 0, Color.rgb(15, 53, 89));

        eqControl(c, 25, 462, 136, "Frequency", formatHz(eqFreq[selectedChannel][selectedBand]),
                eqFreq[selectedChannel][selectedBand], 20, 20000, Color.rgb(35, 163, 255), S_EQ_FREQ, true);
        eqControl(c, 159, 462, 270, "Gain", formatDb(eqGain[selectedChannel][selectedBand]),
                eqGain[selectedChannel][selectedBand], -12, 12, Color.rgb(0, 235, 177), S_EQ_GAIN, false);
        eqControl(c, 293, 462, 404, "Q (Quality Factor)", String.format(Locale.US, "%.1f", eqQ[selectedChannel][selectedBand]),
                eqQ[selectedChannel][selectedBand], 0.1f, 10f, Color.rgb(198, 66, 255), S_EQ_Q, false);

        rounded(c, 16, 571, 414, 648, 13, Color.argb(145, 2, 41, 75), Color.argb(100, 15, 119, 192), 1);
        text(c, "Output Level - Ch " + (selectedChannel + 1) + " (" + channelNames[selectedChannel] + ")",
                75, 594, 11, Color.WHITE, false);
        text(c, formatDb(outputLevel[selectedChannel]), 390, 594, 10, Color.rgb(52, 197, 255), false, Paint.Align.RIGHT);
        slider(c, 72, 620, 388, outputLevel[selectedChannel], -60, 12, Color.rgb(31, 158, 255), S_EQ_OUTPUT, 0, false);
        text(c, "-60 dB", 72, 640, 7, Color.rgb(166, 191, 222), false);
        text(c, "+12 dB", 388, 640, 7, Color.rgb(166, 191, 222), false, Paint.Align.RIGHT);
    }

    private void drawCrossover(Canvas c) {
        text(c, "Crossover", 20, 111, 24, Color.WHITE, true);
        text(c, "Configure crossover filters and time alignment for each channel.", 20, 130, 9.5f,
                Color.rgb(173, 195, 224), false);
        smallButton(c, 316, 96, 412, 132, "▱  Preset  ›", ID_CROSS_PRESET, 0, Color.rgb(18, 49, 81));

        rounded(c, 16, 144, 414, 309, 13, Color.argb(145, 2, 41, 75), Color.argb(100, 15, 119, 192), 1);
        text(c, "C R O S S O V E R   R E S P O N S E", 28, 163, 8, Color.rgb(168, 191, 222), false);
        smallButton(c, 278, 152, 338, 177, "Magnitude", ID_CROSS_VIEW, 0, crossView == 0 ? Color.rgb(0, 107, 193) : Color.rgb(18, 54, 87));
        smallButton(c, 343, 152, 401, 177, "Phase", ID_CROSS_VIEW, 1, crossView == 1 ? Color.rgb(0, 107, 193) : Color.rgb(18, 54, 87));
        RectF graph = new RectF(48, 180, 398, 274);
        drawGrid(c, graph, 10, 4);
        drawCrossoverGraph(c, graph);
        String[] marks = {"20", "50", "100", "500", "1k", "5k", "10k", "20k"};
        for (int i = 0; i < marks.length; i++) {
            float x = graph.left + i * graph.width() / (marks.length - 1);
            text(c, marks[i], x, 287, 6.8f, Color.rgb(162, 190, 221), false, Paint.Align.CENTER);
        }
        text(c, "Frequency (Hz)", 223, 299, 7.5f, Color.rgb(163, 190, 222), false, Paint.Align.CENTER);

        text(c, "CROSSOVER SETTINGS", 28, 329, 9, Color.rgb(168, 191, 222), false);
        text(c, "Link L/R", 345, 329, 9, Color.rgb(167, 191, 222), false, Paint.Align.RIGHT);
        rounded(c, 354, 315, 402, 337, 11, linkLR ? Color.rgb(0, 126, 216) : Color.rgb(34, 57, 83), Color.TRANSPARENT, 0);
        p.setColor(Color.WHITE); c.drawCircle(linkLR ? 390 : 366, 326, 8, p);
        addButton(350, 310, 410, 342, ID_CROSS_LINK, 0);

        for (int i = 0; i < 4; i++) {
            float l = 18 + i * 99;
            crossCard(c, l, 345, l + 94, 526, i);
        }

        rounded(c, 16, 539, 414, 688, 13, Color.argb(145, 2, 41, 75), Color.argb(100, 15, 119, 192), 1);
        text(c, "CHANNEL DELAY / TIME ALIGNMENT", 28, 559, 9, Color.rgb(168, 191, 222), false);
        String[] units = {"ms", "cm", "in"};
        for (int i = 0; i < 3; i++) {
            float l = 320 + i * 30;
            smallButton(c, l, 546, l + 27, 568, units[i], ID_DELAY_UNIT, i,
                    i == delayUnit ? Color.rgb(0, 111, 191) : Color.rgb(17, 54, 88));
        }
        for (int i = 0; i < 4; i++) {
            float l = 22 + i * 97;
            delayCard(c, l, 574, l + 90, 669, i);
        }
        smallButton(c, 23, 697, 180, 733, "↻  Reset Delays", ID_RESET_DELAY, 0, Color.rgb(16, 52, 82));
        smallButton(c, 251, 697, 407, 733, "⌘  Auto Align", ID_AUTO_ALIGN, 0, Color.rgb(12, 62, 91));
    }

    private void drawBottomNav(Canvas c) {
        rounded(c, 0, 761, 430, 900, 30, Color.argb(225, 2, 22, 46), Color.argb(130, 14, 95, 160), 1);
        String[] labels = {"Home", "Mix", "Eq", "Crossover"};
        String[] icons = {"⌂", "‡", "▥", "⌁"};
        for (int i = 0; i < 4; i++) {
            float cx = 58 + i * 105;
            int col = i == page ? Color.rgb(36, 158, 255) : Color.rgb(174, 199, 233);
            text(c, icons[i], cx, 811, 28, col, true, Paint.Align.CENTER);
            text(c, labels[i], cx, 838, 11, col, false, Paint.Align.CENTER);
            if (i == page) {
                p.setColor(Color.rgb(0, 142, 255));
                c.drawRoundRect(new RectF(cx - 33, 852, cx + 33, 855), 2, 2, p);
            }
            addButton(cx - 48, 780, cx + 48, 865, ID_NAV, i);
        }
    }

    private void statusRow(Canvas c, float x, float y, int accent, String icon, String title, String sub) {
        p.setColor(Color.argb(65, Color.red(accent), Color.green(accent), Color.blue(accent)));
        c.drawCircle(x, y, 19, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.2f); p.setColor(accent); c.drawCircle(x, y, 19, p); p.setStyle(Paint.Style.FILL);
        text(c, icon, x, y + 6, 17, accent, true, Paint.Align.CENTER);
        text(c, title, x + 31, y - 2, 11, accent, true);
        text(c, sub, x + 31, y + 14, 8, Color.rgb(171, 193, 221), false);
    }

    private void quickCard(Canvas c, float l, float t, float r, float b, int index, String title, String sub, int accent) {
        rounded(c, l, t, r, b, 9, Color.argb(135, 8, 48, 87), Color.argb(85, Color.red(accent), Color.green(accent), Color.blue(accent)), 1);
        p.setColor(Color.argb(65, Color.red(accent), Color.green(accent), Color.blue(accent)));
        c.drawCircle(l + 28, (t + b) / 2f, 18, p);
        text(c, index == 0 ? "◉" : index == 1 ? "□" : index == 2 ? "▥" : "i", l + 28, (t + b) / 2f + 6,
                17, accent, true, Paint.Align.CENTER);
        text(c, title, l + 54, t + 22, 10, Color.WHITE, false);
        text(c, sub, l + 54, t + 39, 7.5f, Color.rgb(169, 191, 219), false);
        text(c, "›", r - 15, (t + b) / 2f + 6, 18, Color.rgb(190, 213, 239), false, Paint.Align.CENTER);
        addButton(l, t, r, b, ID_QUICK, index);
    }

    private void sliderCard(Canvas c, float l, float t, float r, float b, String title, String sub,
                            float value, float min, float max, int accent, int sliderId, String unit) {
        rounded(c, l, t, r, b, 13, Color.argb(150, 2, 44, 83), Color.argb(100, 16, 117, 190), 1);
        p.setColor(Color.argb(65, Color.red(accent), Color.green(accent), Color.blue(accent)));
        c.drawCircle(l + 35, t + 32, 21, p);
        text(c, "◖", l + 35, t + 39, 22, accent, false, Paint.Align.CENTER);
        text(c, title, l + 68, t + 27, 13, Color.WHITE, false);
        text(c, sub, l + 68, t + 46, 9, Color.rgb(170, 193, 223), false);
        rounded(c, r - 84, t + 13, r - 12, t + 43, 7, Color.argb(90, Color.red(accent), Color.green(accent), Color.blue(accent)), accent, 1);
        text(c, format(value, unit), r - 48, t + 33, 11, accent, false, Paint.Align.CENTER);
        slider(c, l + 16, b - 35, r - 16, value, min, max, accent, sliderId, 0, false);
        text(c, format(min, unit), l + 16, b - 10, 7.5f, Color.rgb(164, 190, 221), false);
        text(c, format(max, unit), r - 16, b - 10, 7.5f, Color.rgb(164, 190, 221), false, Paint.Align.RIGHT);
    }

    private void knobCard(Canvas c, float l, float t, float r, float b, String title, String sub,
                          float value, float min, float max, int accent, int sliderId, String unit) {
        rounded(c, l, t, r, b, 13, Color.argb(150, 2, 44, 83), Color.argb(100, 16, 117, 190), 1);
        text(c, title, l + 55, t + 25, 11, Color.WHITE, false);
        text(c, sub, l + 55, t + 42, 7.5f, Color.rgb(169, 191, 221), false);
        rounded(c, r - 63, t + 10, r - 9, t + 36, 7, Color.argb(70, Color.red(accent), Color.green(accent), Color.blue(accent)), accent, 1);
        text(c, format(value, unit), r - 36, t + 28, 9, accent, false, Paint.Align.CENTER);
        float cx = (l + r) / 2f, cy = t + 93;
        float frac = clamp((value - min) / (max - min), 0f, 1f);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(8); p.setStrokeCap(Paint.Cap.ROUND);
        p.setColor(Color.rgb(20, 37, 58)); c.drawArc(new RectF(cx - 38, cy - 38, cx + 38, cy + 38), 135, 270, false, p);
        p.setColor(accent); c.drawArc(new RectF(cx - 38, cy - 38, cx + 38, cy + 38), 135, 270 * frac, false, p);
        p.setStyle(Paint.Style.FILL); p.setStrokeCap(Paint.Cap.BUTT);
        p.setShader(new RadialGradient(cx - 8, cy - 10, 44, Color.rgb(28, 50, 75), Color.rgb(1, 10, 20), Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, 33, p); p.setShader(null);
        double ang = Math.toRadians(135 + 270 * frac);
        p.setColor(Color.WHITE); c.drawCircle(cx + (float)Math.cos(ang) * 31, cy + (float)Math.sin(ang) * 31, 5, p);
        text(c, format(min, unit), l + 12, b - 15, 7, Color.rgb(164, 190, 221), false);
        text(c, format(max, unit), r - 12, b - 15, 7, Color.rgb(164, 190, 221), false, Paint.Align.RIGHT);
        addSlider(l + 8, t + 55, r - 8, b - 7, sliderId, 0, min, max, false);
    }

    private void eqControl(Canvas c, float l, float t, float r, String label, String value,
                           float current, float min, float max, int accent, int sliderId, boolean log) {
        text(c, label, l + 2, t + 10, label.startsWith("Q") ? 7.5f : 8.5f, Color.rgb(170, 193, 223), false);
        text(c, value, l + 2, t + 31, 13, Color.WHITE, false);
        slider(c, l, t + 51, r, current, min, max, accent, sliderId, 0, log);
        rounded(c, l, t + 69, l + 24, t + 93, 12, Color.argb(110, 11, 45, 79), Color.argb(100, 72, 127, 178), 1);
        rounded(c, r - 24, t + 69, r, t + 93, 12, Color.argb(110, 11, 45, 79), Color.argb(100, 72, 127, 178), 1);
        text(c, "−", l + 12, t + 86, 16, Color.rgb(181, 208, 237), false, Paint.Align.CENTER);
        text(c, "+", r - 12, t + 86, 16, Color.rgb(181, 208, 237), false, Paint.Align.CENTER);
        text(c, sliderId == S_EQ_FREQ ? "20 Hz – 20 kHz" : sliderId == S_EQ_GAIN ? "-12 dB – +12 dB" : "0.1 – 10.0",
                (l + r) / 2f, t + 111, 6.8f, Color.rgb(159, 186, 218), false, Paint.Align.CENTER);
    }

    private void drawEqGraph(Canvas c, RectF graph) {
        float[] xs = new float[15];
        float[] ys = new float[15];
        for (int i = 0; i < 15; i++) {
            float fracX = logFraction(eqFreq[selectedChannel][i], 20f, 20000f);
            xs[i] = graph.left + fracX * graph.width();
            ys[i] = graph.centerY() - (eqGain[selectedChannel][i] / 12f) * (graph.height() * 0.44f);
        }
        path.reset(); path.moveTo(xs[0], ys[0]);
        for (int i = 1; i < 15; i++) path.lineTo(xs[i], ys[i]);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeJoin(Paint.Join.ROUND);
        p.setShader(new LinearGradient(graph.left, graph.top, graph.right, graph.bottom,
                new int[]{Color.rgb(35, 135, 255), Color.rgb(0, 239, 164), Color.rgb(255, 186, 50), Color.rgb(211, 50, 242)},
                null, Shader.TileMode.CLAMP));
        c.drawPath(path, p); p.setShader(null); p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < 15; i++) {
            int col = eqPointColor(i);
            p.setColor(col); c.drawCircle(xs[i], ys[i], i == selectedBand ? 6.5f : 4.5f, p);
            if (i == selectedBand) {
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.5f); p.setColor(Color.WHITE); c.drawCircle(xs[i], ys[i], 8.5f, p); p.setStyle(Paint.Style.FILL);
            }
        }
    }

    private int eqPointColor(int i) {
        if (i < 3) return Color.rgb(24, 137, 255);
        if (i < 7) return Color.rgb(0, 232, 169);
        if (i < 10) return Color.rgb(255, 198, 57);
        if (i < 12) return Color.rgb(255, 89, 89);
        return Color.rgb(205, 67, 246);
    }

    private void crossCard(Canvas c, float l, float t, float r, float b, int index) {
        int accent = crossColors[index];
        rounded(c, l, t, r, b, 9, Color.argb(130, 3, 40, 74), Color.argb(90, 26, 102, 159), 1);
        p.setColor(accent); c.drawCircle(l + 13, t + 14, 5, p);
        text(c, crossNames[index], l + 23, t + 18, 8.5f, accent, true);
        String[] filterNames = {"Low Pass", "Band Pass", "High Pass", "Bypass"};
        rounded(c, l + 6, t + 27, r - 6, t + 50, 5, Color.argb(110, 11, 48, 80), Color.argb(70, 92, 144, 190), 1);
        text(c, filterNames[crossFilter[index]], l + 11, t + 43, 7.2f, Color.rgb(218, 229, 242), false);
        text(c, "⌄", r - 13, t + 43, 9, Color.rgb(192, 212, 235), false, Paint.Align.CENTER);
        addButton(l + 4, t + 25, r - 4, t + 53, ID_CROSS_FILTER, index);

        text(c, formatHz(crossCutoff[index]), (l + r) / 2f, t + 82, 10, Color.WHITE, true, Paint.Align.CENTER);
        slider(c, l + 10, t + 96, r - 10, crossCutoff[index], 20, 20000, accent, S_CROSS_CUTOFF, index, true);
        text(c, "20 Hz", l + 7, t + 118, 6.1f, Color.rgb(161, 186, 216), false);
        text(c, "20 kHz", r - 7, t + 118, 6.1f, Color.rgb(161, 186, 216), false, Paint.Align.RIGHT);
        text(c, "Slope", l + 7, t + 139, 7, Color.rgb(171, 194, 221), false);
        String[] slopes = {"12 dB", "24 dB", "36 dB"};
        for (int i = 0; i < 3; i++) {
            float sl = l + 5 + i * 29;
            rounded(c, sl, t + 145, sl + 26, t + 166, 4,
                    i == crossSlope[index] ? Color.argb(140, Color.red(accent), Color.green(accent), Color.blue(accent)) : Color.argb(110, 9, 42, 72),
                    i == crossSlope[index] ? accent : Color.argb(70, 88, 139, 182), 1);
            text(c, slopes[i], sl + 13, t + 159, 5.5f, Color.rgb(212, 225, 240), false, Paint.Align.CENTER);
            addButton(sl, t + 143, sl + 27, t + 168, ID_CROSS_SLOPE, index * 10 + i);
        }
    }

    private void delayCard(Canvas c, float l, float t, float r, float b, int index) {
        int accent = crossColors[index];
        rounded(c, l, t, r, b, 8, Color.argb(120, 4, 39, 72), Color.argb(70, 70, 126, 174), 1);
        p.setColor(accent); c.drawCircle(l + 12, t + 13, 4.5f, p);
        text(c, crossNames[index], l + 22, t + 16, 7.5f, accent, true);
        text(c, delayValueText(index), l + 12, t + 37, 9.5f, Color.WHITE, true);
        slider(c, l + 9, t + 49, r - 9, delayMs[index], 0, 20, accent, S_DELAY, index, false);
        text(c, "0.00", l + 7, t + 70, 5.8f, Color.rgb(158, 186, 216), false);
        text(c, "20.00", r - 7, t + 70, 5.8f, Color.rgb(158, 186, 216), false, Paint.Align.RIGHT);
        float cm = delayMs[index] * 34.3f;
        text(c, delayUnit == 0 ? String.format(Locale.US, "%.1f cm", cm) : delayUnit == 1 ? String.format(Locale.US, "%.1f ms", delayMs[index]) : String.format(Locale.US, "%.1f in", cm / 2.54f),
                (l + r) / 2f, t + 88, 6.6f, Color.rgb(185, 204, 228), false, Paint.Align.CENTER);
    }

    private String delayValueText(int index) {
        float ms = delayMs[index];
        if (delayUnit == 0) return String.format(Locale.US, "%.2f ms", ms);
        float cm = ms * 34.3f;
        if (delayUnit == 1) return String.format(Locale.US, "%.1f cm", cm);
        return String.format(Locale.US, "%.1f in", cm / 2.54f);
    }

    private void drawCrossoverGraph(Canvas c, RectF g) {
        for (int idx = 0; idx < 4; idx++) {
            path.reset();
            for (int i = 0; i <= 80; i++) {
                float frac = i / 80f;
                float hz = 20f * (float)Math.pow(1000.0, frac);
                float amp;
                if (idx == 0) {
                    amp = 1f / (1f + (float)Math.pow(hz / Math.max(21f, crossCutoff[0]), 4));
                } else if (idx == 1) {
                    float low = 1f - 1f / (1f + (float)Math.pow(hz / 80f, 4));
                    float high = 1f / (1f + (float)Math.pow(hz / Math.max(100f, crossCutoff[1]), 4));
                    amp = low * high;
                } else if (idx == 2) {
                    amp = 1f - 1f / (1f + (float)Math.pow(hz / Math.max(100f, crossCutoff[2]), 4));
                } else {
                    amp = 0.76f;
                }
                float y;
                if (crossView == 0) {
                    float db = 20f * (float)Math.log10(Math.max(0.02f, amp));
                    y = g.top + clamp((-db) / 36f, 0f, 1f) * g.height();
                } else {
                    float phase = (float)Math.sin((Math.log10(hz) + idx * 0.55) * 3.0) * 0.45f;
                    y = g.centerY() - phase * g.height();
                }
                float x = g.left + frac * g.width();
                if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
            }
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2.2f); p.setColor(crossColors[idx]); c.drawPath(path, p); p.setStyle(Paint.Style.FILL);
        }
    }

    private void drawGrid(Canvas c, RectF r, int cols, int rows) {
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(0.7f); p.setColor(Color.argb(80, 79, 128, 174));
        c.drawRect(r, p);
        for (int i = 1; i < cols; i++) {
            float x = r.left + r.width() * i / cols;
            c.drawLine(x, r.top, x, r.bottom, p);
        }
        for (int i = 1; i < rows; i++) {
            float y = r.top + r.height() * i / rows;
            c.drawLine(r.left, y, r.right, y, p);
        }
        p.setStyle(Paint.Style.FILL);
    }

    private void slider(Canvas c, float l, float y, float r, float value, float min, float max,
                        int accent, int sliderId, int index, boolean log) {
        float frac = log ? logFraction(value, min, max) : clamp((value - min) / (max - min), 0f, 1f);
        rounded(c, l, y - 3, r, y + 3, 3, Color.rgb(16, 38, 61), Color.argb(80, 76, 133, 181), 1);
        p.setShader(new LinearGradient(l, y, r, y,
                new int[]{accent, Color.rgb(111, 216, 255)}, null, Shader.TileMode.CLAMP));
        c.drawRoundRect(new RectF(l, y - 3, l + frac * (r - l), y + 3), 3, 3, p); p.setShader(null);
        p.setShadowLayer(8, 0, 0, accent); p.setColor(Color.WHITE); c.drawCircle(l + frac * (r - l), y, 8, p); p.clearShadowLayer();
        addSlider(l - 5, y - 14, r + 5, y + 14, sliderId, index, min, max, log);
    }

    private void smallButton(Canvas c, float l, float t, float r, float b, String label, int id, int index, int fill) {
        rounded(c, l, t, r, b, 8, fill, Color.argb(80, 85, 145, 194), 1);
        text(c, label, (l + r) / 2f, (t + b) / 2f + 4, Math.min(9f, (r - l) / Math.max(4f, label.length() * 0.72f)),
                Color.rgb(222, 233, 246), false, Paint.Align.CENTER);
        addButton(l, t, r, b, id, index);
    }

    private void rounded(Canvas c, float l, float t, float r, float b, float radius, int fill, int stroke, float strokeWidth) {
        p.setStyle(Paint.Style.FILL); p.setColor(fill); c.drawRoundRect(new RectF(l, t, r, b), radius, radius, p);
        if (Color.alpha(stroke) > 0 && strokeWidth > 0) {
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(strokeWidth); p.setColor(stroke); c.drawRoundRect(new RectF(l, t, r, b), radius, radius, p); p.setStyle(Paint.Style.FILL);
        }
    }

    private void text(Canvas c, String value, float x, float y, float size, int color, boolean bold) {
        text(c, value, x, y, size, color, bold, Paint.Align.LEFT);
    }

    private void text(Canvas c, String value, float x, float y, float size, int color, boolean bold, Paint.Align align) {
        p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(color); p.setTextSize(size);
        p.setTextAlign(align); p.setTypeface(Typeface.create("sans", bold ? Typeface.BOLD : Typeface.NORMAL));
        c.drawText(value, x, y, p);
    }

    private void addButton(float l, float t, float r, float b, int id, int index) {
        hits.add(new Hit(new RectF(l, t, r, b), TYPE_BUTTON, id, index, 0, 0, false));
    }

    private void addSlider(float l, float t, float r, float b, int id, int index, float min, float max, boolean log) {
        hits.add(new Hit(new RectF(l, t, r, b), TYPE_SLIDER, id, index, min, max, log));
    }

    private void addEqGraph(float l, float t, float r, float b) {
        hits.add(new Hit(new RectF(l, t, r, b), TYPE_EQ_GRAPH, 0, 0, -12, 12, false));
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (getWidth() <= 0 || getHeight() <= 0) return true;
        float x = event.getX() * DESIGN_W / getWidth();
        float y = event.getY() * DESIGN_H / getHeight();
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                activeHit = findHit(x, y);
                if (activeHit != null) {
                    if (activeHit.type == TYPE_SLIDER) updateSlider(activeHit, x);
                    else if (activeHit.type == TYPE_EQ_GRAPH) updateEqGraph(x, y, activeHit.rect);
                    else handleButton(activeHit.id, activeHit.index);
                    invalidate();
                }
                return true;
            case MotionEvent.ACTION_MOVE:
                if (activeHit != null) {
                    if (activeHit.type == TYPE_SLIDER) updateSlider(activeHit, x);
                    else if (activeHit.type == TYPE_EQ_GRAPH) updateEqGraph(x, y, activeHit.rect);
                    invalidate();
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                activeHit = null;
                invalidate();
                return true;
            default:
                return true;
        }
    }

    private Hit findHit(float x, float y) {
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (h.rect.contains(x, y)) return h;
        }
        return null;
    }

    private void handleButton(int id, int index) {
        if (id == ID_NAV) {
            page = index;
        } else if (id == ID_CONNECT) {
            connected = !connected;
            toast(connected ? "Demo status: Connected" : "Demo status: Offline");
        } else if (id == ID_GEAR) {
            toast("UI Settings • Phase 1");
        } else if (id == ID_INPUT) {
            selectedInput = index;
            toast("Input: " + new String[]{"Bluetooth", "AUX", "Optical", "USB"}[index]);
        } else if (id == ID_QUICK) {
            if (index == 0) loadPreset();
            else if (index == 1) savePreset();
            else if (index == 2) toast("Device Settings • controls will connect to DSP in Phase 2");
            else toast("OKN_DSP Version 2 • Phase 1 UI");
        } else if (id == ID_EQ_CHANNEL) {
            selectedChannel = index;
        } else if (id == ID_EQ_SAVE) {
            savePreset();
        } else if (id == ID_EQ_LOAD) {
            loadPreset();
        } else if (id == ID_EQ_MORE) {
            toast("EQ menu • 15 bands × 7 channels");
        } else if (id == ID_EQ_PREV) {
            selectedBand = Math.max(0, selectedBand - 1);
        } else if (id == ID_EQ_NEXT) {
            selectedBand = Math.min(14, selectedBand + 1);
        } else if (id == ID_CROSS_PRESET) {
            crossCutoff[0] = 80; crossCutoff[1] = 3000; crossCutoff[2] = 3000; crossCutoff[3] = 20000;
            toast("Crossover preset recalled");
        } else if (id == ID_CROSS_VIEW) {
            crossView = index;
        } else if (id == ID_CROSS_LINK) {
            linkLR = !linkLR;
        } else if (id == ID_CROSS_FILTER) {
            crossFilter[index] = (crossFilter[index] + 1) % 4;
        } else if (id == ID_CROSS_SLOPE) {
            int card = index / 10;
            int slope = index % 10;
            if (card >= 0 && card < crossSlope.length && slope >= 0 && slope < 3) crossSlope[card] = slope;
        } else if (id == ID_DELAY_UNIT) {
            delayUnit = index;
        } else if (id == ID_RESET_DELAY) {
            for (int i = 0; i < delayMs.length; i++) delayMs[i] = 0f;
            toast("Delays reset");
        } else if (id == ID_AUTO_ALIGN) {
            delayMs[0] = 2.50f; delayMs[1] = 1.20f; delayMs[2] = 0f; delayMs[3] = 0.80f;
            toast("Demo auto alignment applied");
        }
    }

    private void updateSlider(Hit h, float x) {
        float frac = clamp((x - h.rect.left) / Math.max(1f, h.rect.width()), 0f, 1f);
        float value = h.log ? expMap(frac, h.min, h.max) : h.min + frac * (h.max - h.min);
        switch (h.id) {
            case S_MASTER: masterVolume = round(value, 1); break;
            case S_BASS: bassVolume = round(value, 1); break;
            case S_BASS_CUTOFF: bassCutoff = Math.round(value); break;
            case S_BASS_BOOST: bassBoost = round(value, 1); break;
            case S_MIDDLE_BOOST: middleBoost = round(value, 1); break;
            case S_TREBLE_BOOST: trebleBoost = round(value, 1); break;
            case S_EQ_FREQ: eqFreq[selectedChannel][selectedBand] = Math.round(value); break;
            case S_EQ_GAIN: eqGain[selectedChannel][selectedBand] = round(value, 1); break;
            case S_EQ_Q: eqQ[selectedChannel][selectedBand] = Math.max(0.1f, round(value, 1)); break;
            case S_EQ_OUTPUT: outputLevel[selectedChannel] = round(value, 1); break;
            case S_CROSS_CUTOFF:
                crossCutoff[h.index] = Math.round(value);
                if (linkLR && h.index == 1) crossCutoff[2] = crossCutoff[1];
                else if (linkLR && h.index == 2) crossCutoff[1] = crossCutoff[2];
                break;
            case S_DELAY:
                delayMs[h.index] = round(value, 2);
                break;
            default: break;
        }
    }

    private void updateEqGraph(float x, float y, RectF graph) {
        int nearest = 0;
        float best = Float.MAX_VALUE;
        for (int i = 0; i < 15; i++) {
            float px = graph.left + logFraction(eqFreq[selectedChannel][i], 20, 20000) * graph.width();
            float d = Math.abs(px - x);
            if (d < best) { best = d; nearest = i; }
        }
        selectedBand = nearest;
        float fracY = clamp((y - graph.top) / graph.height(), 0f, 1f);
        float gain = (0.5f - fracY) * (24f / 0.88f);
        eqGain[selectedChannel][selectedBand] = clamp(round(gain, 1), -12f, 12f);
    }

    private void savePreset() {
        SharedPreferences.Editor e = prefs.edit();
        e.putFloat("master", masterVolume).putFloat("bass", bassVolume).putFloat("bassCut", bassCutoff)
                .putFloat("bassBoost", bassBoost).putFloat("midBoost", middleBoost).putFloat("trebleBoost", trebleBoost)
                .putInt("input", selectedInput).putBoolean("link", linkLR);
        for (int ch = 0; ch < 7; ch++) {
            e.putFloat("out_" + ch, outputLevel[ch]);
            for (int b = 0; b < 15; b++) {
                e.putFloat("f_" + ch + "_" + b, eqFreq[ch][b]);
                e.putFloat("g_" + ch + "_" + b, eqGain[ch][b]);
                e.putFloat("q_" + ch + "_" + b, eqQ[ch][b]);
            }
        }
        for (int i = 0; i < 4; i++) {
            e.putFloat("xo_" + i, crossCutoff[i]);
            e.putInt("xf_" + i, crossFilter[i]);
            e.putInt("xs_" + i, crossSlope[i]);
            e.putFloat("d_" + i, delayMs[i]);
        }
        e.apply();
        toast("Preset saved on device");
    }

    private void loadPreset() {
        if (!prefs.contains("master")) {
            toast("No saved preset yet");
            return;
        }
        masterVolume = prefs.getFloat("master", masterVolume);
        bassVolume = prefs.getFloat("bass", bassVolume);
        bassCutoff = prefs.getFloat("bassCut", bassCutoff);
        bassBoost = prefs.getFloat("bassBoost", bassBoost);
        middleBoost = prefs.getFloat("midBoost", middleBoost);
        trebleBoost = prefs.getFloat("trebleBoost", trebleBoost);
        selectedInput = prefs.getInt("input", selectedInput);
        linkLR = prefs.getBoolean("link", linkLR);
        for (int ch = 0; ch < 7; ch++) {
            outputLevel[ch] = prefs.getFloat("out_" + ch, outputLevel[ch]);
            for (int b = 0; b < 15; b++) {
                eqFreq[ch][b] = prefs.getFloat("f_" + ch + "_" + b, eqFreq[ch][b]);
                eqGain[ch][b] = prefs.getFloat("g_" + ch + "_" + b, eqGain[ch][b]);
                eqQ[ch][b] = prefs.getFloat("q_" + ch + "_" + b, eqQ[ch][b]);
            }
        }
        for (int i = 0; i < 4; i++) {
            crossCutoff[i] = prefs.getFloat("xo_" + i, crossCutoff[i]);
            crossFilter[i] = prefs.getInt("xf_" + i, crossFilter[i]);
            crossSlope[i] = prefs.getInt("xs_" + i, crossSlope[i]);
            delayMs[i] = prefs.getFloat("d_" + i, delayMs[i]);
        }
        toast("Preset loaded");
        invalidate();
    }

    private void toast(String s) {
        Toast.makeText(getContext(), s, Toast.LENGTH_SHORT).show();
    }

    private static float clamp(float v, float min, float max) { return Math.max(min, Math.min(max, v)); }
    private static float round(float v, int digits) {
        float m = (float)Math.pow(10, digits);
        return Math.round(v * m) / m;
    }
    private static float logFraction(float value, float min, float max) {
        double a = Math.log(Math.max(min, value) / min);
        double b = Math.log(max / min);
        return (float) clamp((float)(a / b), 0f, 1f);
    }
    private static float expMap(float fraction, float min, float max) {
        return min * (float)Math.pow(max / min, fraction);
    }
    private static String formatDb(float v) { return String.format(Locale.US, "%+.1f dB", v); }
    private static String formatHz(float v) {
        if (v >= 1000) return v >= 10000 ? String.format(Locale.US, "%.0f kHz", v / 1000f) : String.format(Locale.US, "%.1f kHz", v / 1000f);
        return String.format(Locale.US, "%.0f Hz", v);
    }
    private static String format(float v, String unit) {
        if ("Hz".equals(unit)) return formatHz(v);
        if ("dB".equals(unit)) return formatDb(v);
        return String.format(Locale.US, "%.1f %s", v, unit);
    }

    private static final class Hit {
        final RectF rect;
        final int type;
        final int id;
        final int index;
        final float min;
        final float max;
        final boolean log;

        Hit(RectF rect, int type, int id, int index, float min, float max, boolean log) {
            this.rect = rect;
            this.type = type;
            this.id = id;
            this.index = index;
            this.min = min;
            this.max = max;
            this.log = log;
        }
    }
}
