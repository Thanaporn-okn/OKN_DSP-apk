package com.okn.dsp;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.PrintWriter;
import java.io.StringWriter;

/** Lightweight crash recorder used only for stability diagnostics. */
public final class CrashStore {
    private static final String PREFS = "okn_dsp_v2_diagnostics";
    private static final String KEY_SUMMARY = "last_crash_summary";
    private static final String KEY_TRACE = "last_crash_trace";
    private static volatile boolean installed;

    private CrashStore() {}

    public static synchronized void install(Context context) {
        if (installed) return;
        final Context app = context.getApplicationContext();
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, error) -> {
            record(app, error);
            if (previous != null) {
                previous.uncaughtException(thread, error);
            } else {
                android.os.Process.killProcess(android.os.Process.myPid());
                System.exit(10);
            }
        });
        installed = true;
    }

    public static void recordNonFatal(Context context, Throwable error) {
        record(context.getApplicationContext(), error);
    }

    public static String getLastCrashSummary(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_SUMMARY, null);
    }

    private static void record(Context context, Throwable error) {
        try {
            String message = error.getMessage();
            String summary = error.getClass().getSimpleName() + (message == null || message.isEmpty() ? "" : ": " + message);
            StringWriter sw = new StringWriter(4096);
            error.printStackTrace(new PrintWriter(sw));
            SharedPreferences.Editor e = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit();
            e.putString(KEY_SUMMARY, summary);
            e.putString(KEY_TRACE, sw.toString());
            e.putLong("last_crash_time", System.currentTimeMillis());
            e.commit();
        } catch (RuntimeException ignored) {
            // Never let diagnostics cause another crash.
        }
    }
}
