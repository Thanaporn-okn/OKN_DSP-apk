package com.okn.dsp;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Locale;
import java.util.Map;
import java.util.Set;

public final class DspState {
    public static final int CHANNELS = 7;
    public static final int BANDS = 15;
    public static final float[] DEFAULT_FREQS = {
            20f, 31.5f, 50f, 80f, 125f,
            200f, 315f, 500f, 800f, 1250f,
            2000f, 3150f, 5000f, 10000f, 20000f
    };

    private static final String PREFS_NAME = "okn_dsp_state";
    private static final String LEGACY_V1_PREFS = "okn_dsp_v1_state";
    private static final int STATE_SCHEMA = 2;

    private final SharedPreferences prefs;

    public float masterVolume;
    public float bassVolume;
    public float bassCutoff;
    public final float[] channelVolume = new float[CHANNELS];
    public final float[][] eqFreq = new float[CHANNELS][BANDS];
    public final float[][] eqQ = new float[CHANNELS][BANDS];
    public final float[][] eqGain = new float[CHANNELS][BANDS];

    public int page;
    public int theme;
    public int selectedChannel;
    public int selectedBand;
    public String presetName;

    private static final float[] DEFAULT_CHANNEL_VOL = {-3f, -6f, -2f, -8f, 0f, -4f, -10f};
    private static final float[] DEFAULT_EQ_GAIN = {-2f, -1f, 1.5f, 4f, 2f, 0.2f, -1.1f, -2f, -1.5f, 0f, 2.1f, 3f, 2.5f, 1f, -1f};

    public DspState(Context context) {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        migrateV1IfNeeded(context);
        load();
        prefs.edit().putInt("stateSchema", STATE_SCHEMA).apply();
    }

    private void migrateV1IfNeeded(Context context) {
        if (prefs.contains("stateSchema") || !prefs.getAll().isEmpty()) return;
        SharedPreferences old = context.getSharedPreferences(LEGACY_V1_PREFS, Context.MODE_PRIVATE);
        Map<String, ?> source = old.getAll();
        if (source.isEmpty()) return;

        SharedPreferences.Editor e = prefs.edit();
        for (Map.Entry<String, ?> entry : source.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();
            if (value instanceof String) e.putString(key, (String) value);
            else if (value instanceof Integer) e.putInt(key, (Integer) value);
            else if (value instanceof Long) e.putLong(key, (Long) value);
            else if (value instanceof Float) e.putFloat(key, (Float) value);
            else if (value instanceof Boolean) e.putBoolean(key, (Boolean) value);
            else if (value instanceof Set) {
                @SuppressWarnings("unchecked")
                Set<String> set = (Set<String>) value;
                e.putStringSet(key, set);
            }
        }
        e.putInt("stateSchema", STATE_SCHEMA);
        e.commit();
    }

    private void load() {
        masterVolume = clamp(prefs.getFloat("masterVolume", -6f), -60f, 0f);
        bassVolume = clamp(prefs.getFloat("bassVolume", 2f), -12f, 12f);
        bassCutoff = clamp(prefs.getFloat("bassCutoff", 80f), 20f, 200f);
        page = clampInt(prefs.getInt("page", 0), 0, 2);
        theme = clampInt(prefs.getInt("theme", 0), 0, 2);
        selectedChannel = clampInt(prefs.getInt("selectedChannel", 0), 0, CHANNELS - 1);
        selectedBand = clampInt(prefs.getInt("selectedBand", 3), 0, BANDS - 1);
        presetName = prefs.getString("presetName", "Flat");

        for (int ch = 0; ch < CHANNELS; ch++) {
            channelVolume[ch] = clamp(prefs.getFloat("channelVolume_" + ch, DEFAULT_CHANNEL_VOL[ch]), -12f, 12f);
            for (int b = 0; b < BANDS; b++) {
                eqFreq[ch][b] = clamp(prefs.getFloat(key("freq", ch, b), DEFAULT_FREQS[b]), 20f, 20000f);
                eqQ[ch][b] = clamp(prefs.getFloat(key("q", ch, b), 1f), 0.1f, 10f);
                float defaultGain = ch == 0 ? DEFAULT_EQ_GAIN[b] : 0f;
                eqGain[ch][b] = clamp(prefs.getFloat(key("gain", ch, b), defaultGain), -12f, 12f);
            }
        }
    }

    public void setPage(int value) {
        page = clampInt(value, 0, 2);
        prefs.edit().putInt("page", page).apply();
    }

    public void setTheme(int value) {
        theme = clampInt(value, 0, 2);
        prefs.edit().putInt("theme", theme).apply();
    }

    public void setSelectedChannel(int value) {
        selectedChannel = clampInt(value, 0, CHANNELS - 1);
        prefs.edit().putInt("selectedChannel", selectedChannel).apply();
    }

    public void setSelectedBand(int value) {
        selectedBand = clampInt(value, 0, BANDS - 1);
        prefs.edit().putInt("selectedBand", selectedBand).apply();
    }

    public void setMasterVolume(float value) {
        masterVolume = clamp(value, -60f, 0f);
        prefs.edit().putFloat("masterVolume", masterVolume).apply();
    }

    public void setBassVolume(float value) {
        bassVolume = clamp(value, -12f, 12f);
        prefs.edit().putFloat("bassVolume", bassVolume).apply();
    }

    public void setBassCutoff(float value) {
        bassCutoff = clamp(value, 20f, 200f);
        prefs.edit().putFloat("bassCutoff", bassCutoff).apply();
    }

    public void setChannelVolume(int ch, float value) {
        if (ch < 0 || ch >= CHANNELS) return;
        channelVolume[ch] = clamp(value, -12f, 12f);
        prefs.edit().putFloat("channelVolume_" + ch, channelVolume[ch]).apply();
    }

    public void setEqFreq(int ch, int band, float value) {
        if (!validBand(ch, band)) return;
        eqFreq[ch][band] = clamp(value, 20f, 20000f);
        prefs.edit().putFloat(key("freq", ch, band), eqFreq[ch][band]).apply();
    }

    public void setEqQ(int ch, int band, float value) {
        if (!validBand(ch, band)) return;
        eqQ[ch][band] = clamp(value, 0.1f, 10f);
        prefs.edit().putFloat(key("q", ch, band), eqQ[ch][band]).apply();
    }

    public void setEqGain(int ch, int band, float value) {
        if (!validBand(ch, band)) return;
        eqGain[ch][band] = clamp(value, -12f, 12f);
        prefs.edit().putFloat(key("gain", ch, band), eqGain[ch][band]).apply();
    }

    public void resetEqChannel(int ch) {
        if (ch < 0 || ch >= CHANNELS) return;
        SharedPreferences.Editor e = prefs.edit();
        for (int b = 0; b < BANDS; b++) {
            eqFreq[ch][b] = DEFAULT_FREQS[b];
            eqQ[ch][b] = 1f;
            eqGain[ch][b] = 0f;
            e.putFloat(key("freq", ch, b), eqFreq[ch][b]);
            e.putFloat(key("q", ch, b), eqQ[ch][b]);
            e.putFloat(key("gain", ch, b), eqGain[ch][b]);
        }
        e.apply();
    }

    public void setPresetName(String name) {
        if (name == null) return;
        String clean = name.trim();
        if (clean.isEmpty()) clean = "Preset";
        presetName = clean;
        prefs.edit().putString("presetName", clean).apply();
    }

    public void savePreset(String name) {
        setPresetName(name);
        StringBuilder sb = new StringBuilder(8192);
        sb.append(masterVolume).append('|')
                .append(bassVolume).append('|')
                .append(bassCutoff).append('|');
        for (float v : channelVolume) sb.append(v).append(',');
        sb.append('|');
        for (int ch = 0; ch < CHANNELS; ch++) {
            for (int b = 0; b < BANDS; b++) {
                sb.append(eqFreq[ch][b]).append(',')
                        .append(eqQ[ch][b]).append(',')
                        .append(eqGain[ch][b]).append(';');
            }
            sb.append('|');
        }
        prefs.edit()
                .putString("lastPresetData", sb.toString())
                .putString("lastPresetName", presetName)
                .putString("presetName", presetName)
                .commit();
    }

    public boolean loadLastPreset() {
        String data = prefs.getString("lastPresetData", null);
        if (data == null || data.isEmpty()) return false;
        try {
            String[] parts = data.split("\\|", -1);
            if (parts.length < 4 + CHANNELS) return false;
            masterVolume = clamp(Float.parseFloat(parts[0]), -60f, 0f);
            bassVolume = clamp(Float.parseFloat(parts[1]), -12f, 12f);
            bassCutoff = clamp(Float.parseFloat(parts[2]), 20f, 200f);
            String[] cv = parts[3].split(",");
            for (int i = 0; i < CHANNELS && i < cv.length; i++) {
                if (!cv[i].isEmpty()) channelVolume[i] = clamp(Float.parseFloat(cv[i]), -12f, 12f);
            }
            for (int ch = 0; ch < CHANNELS; ch++) {
                String[] triples = parts[4 + ch].split(";");
                for (int b = 0; b < BANDS && b < triples.length; b++) {
                    if (triples[b].isEmpty()) continue;
                    String[] t = triples[b].split(",");
                    if (t.length >= 3) {
                        eqFreq[ch][b] = clamp(Float.parseFloat(t[0]), 20f, 20000f);
                        eqQ[ch][b] = clamp(Float.parseFloat(t[1]), 0.1f, 10f);
                        eqGain[ch][b] = clamp(Float.parseFloat(t[2]), -12f, 12f);
                    }
                }
            }
            presetName = prefs.getString("lastPresetName", "Preset");
            persistAll(true);
            return true;
        } catch (Exception ignored) {
            return false;
        }
    }

    public void persistAll(boolean synchronous) {
        SharedPreferences.Editor e = prefs.edit();
        e.putInt("stateSchema", STATE_SCHEMA)
                .putFloat("masterVolume", masterVolume)
                .putFloat("bassVolume", bassVolume)
                .putFloat("bassCutoff", bassCutoff)
                .putInt("page", page)
                .putInt("theme", theme)
                .putInt("selectedChannel", selectedChannel)
                .putInt("selectedBand", selectedBand)
                .putString("presetName", presetName);
        for (int ch = 0; ch < CHANNELS; ch++) {
            e.putFloat("channelVolume_" + ch, channelVolume[ch]);
            for (int b = 0; b < BANDS; b++) {
                e.putFloat(key("freq", ch, b), eqFreq[ch][b]);
                e.putFloat(key("q", ch, b), eqQ[ch][b]);
                e.putFloat(key("gain", ch, b), eqGain[ch][b]);
            }
        }
        if (synchronous) e.commit(); else e.apply();
    }

    public String getDisplayPresetName() {
        return presetName == null || presetName.trim().isEmpty() ? "Flat" : presetName;
    }

    public static String formatHz(float hz) {
        if (hz >= 1000f) {
            float k = hz / 1000f;
            if (k >= 10f || Math.abs(k - Math.round(k)) < 0.05f) {
                return String.format(Locale.US, "%.0f kHz", k);
            }
            return String.format(Locale.US, "%.1f kHz", k);
        }
        if (hz >= 100f) return String.format(Locale.US, "%.0f Hz", hz);
        return String.format(Locale.US, "%.1f Hz", hz).replace(".0", "");
    }

    private static String key(String prefix, int ch, int band) {
        return prefix + '_' + ch + '_' + band;
    }

    private static boolean validBand(int ch, int band) {
        return ch >= 0 && ch < CHANNELS && band >= 0 && band < BANDS;
    }

    private static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    private static int clampInt(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }
}
