package com.okn.dsp;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Persistent Phase 1 state shared across Version 1/Version 2 upgrades.
 *
 * Every setter updates SharedPreferences immediately via apply(). SharedPreferences updates its
 * in-memory map synchronously and schedules disk persistence asynchronously, so the UI can react
 * with no artificial delay while values survive process/app restarts.
 */
public final class AppState {
    public static final int CHANNELS = 7;
    public static final int BANDS = 15;

    private static final float[] DEFAULT_FREQS = {
            20f, 31.5f, 50f, 80f, 125f,
            200f, 315f, 500f, 800f, 1250f,
            2000f, 3150f, 5000f, 10000f, 20000f
    };

    private final SharedPreferences prefs;

    public AppState(Context context) {
        prefs = context.getSharedPreferences("okn_dsp_v1_state", Context.MODE_PRIVATE);
    }

    private String channelKey(int channel) { return "channel." + channel + ".volume"; }
    private String gainKey(int channel, int band) { return "eq." + channel + "." + band + ".gain"; }
    private String freqKey(int channel, int band) { return "eq." + channel + "." + band + ".freq"; }
    private String qKey(int channel, int band) { return "eq." + channel + "." + band + ".q"; }

    public boolean isDarkTheme() { return prefs.getBoolean("theme.dark", false); }
    public void setDarkTheme(boolean dark) { prefs.edit().putBoolean("theme.dark", dark).apply(); }

    public float getMasterVolume() { return prefs.getFloat("mix.master", -6f); }
    public void setMasterVolume(float value) { prefs.edit().putFloat("mix.master", clamp(value, -60f, 12f)).apply(); }

    public float getBassVolume() { return prefs.getFloat("mix.bass", 2f); }
    public void setBassVolume(float value) { prefs.edit().putFloat("mix.bass", clamp(value, -12f, 12f)).apply(); }

    public float getBassCutoff() { return prefs.getFloat("mix.cutoff", 80f); }
    public void setBassCutoff(float value) { prefs.edit().putFloat("mix.cutoff", clamp(value, 40f, 250f)).apply(); }

    public float getChannelVolume(int channel) {
        float[] defaults = {-3f, -6f, -2f, -8f, 0f, -4f, -10f};
        return prefs.getFloat(channelKey(channel), defaults[clampIndex(channel, CHANNELS)]);
    }

    public void setChannelVolume(int channel, float value) {
        prefs.edit().putFloat(channelKey(channel), clamp(value, -12f, 12f)).apply();
    }

    public float getBandGain(int channel, int band) {
        return prefs.getFloat(gainKey(channel, band), 0f);
    }

    public void setBandGain(int channel, int band, float value) {
        prefs.edit().putFloat(gainKey(channel, band), clamp(value, -12f, 12f)).apply();
    }

    public float getBandFrequency(int channel, int band) {
        return prefs.getFloat(freqKey(channel, band), DEFAULT_FREQS[clampIndex(band, BANDS)]);
    }

    public void setBandFrequency(int channel, int band, float value) {
        float low = 20f;
        float high = 20000f;
        if (band > 0) low = Math.max(low, getBandFrequency(channel, band - 1) * 1.01f);
        if (band < BANDS - 1) high = Math.min(high, getBandFrequency(channel, band + 1) / 1.01f);
        if (low > high) {
            low = Math.min(low, 20000f);
            high = low;
        }
        prefs.edit().putFloat(freqKey(channel, band), clamp(value, low, high)).apply();
    }

    public float getBandQ(int channel, int band) {
        return prefs.getFloat(qKey(channel, band), 1f);
    }

    public void setBandQ(int channel, int band, float value) {
        prefs.edit().putFloat(qKey(channel, band), clamp(value, 0.1f, 10f)).apply();
    }

    public int getSelectedChannel() { return prefs.getInt("ui.selected.channel", 0); }
    public void setSelectedChannel(int channel) { prefs.edit().putInt("ui.selected.channel", clampIndex(channel, CHANNELS)).apply(); }

    public int getSelectedBand() { return prefs.getInt("ui.selected.band", 0); }
    public void setSelectedBand(int band) { prefs.edit().putInt("ui.selected.band", clampIndex(band, BANDS)).apply(); }

    public int getSelectedPage() { return prefs.getInt("ui.selected.page", 0); }
    public void setSelectedPage(int page) { prefs.edit().putInt("ui.selected.page", Math.max(0, Math.min(2, page))).apply(); }

    /**
     * SharedPreferences.apply() keeps slider updates non-blocking. Calling commit on a tiny marker
     * when the Activity pauses waits for pending writes, giving an explicit durability checkpoint
     * without adding latency while the user is dragging controls.
     */
    public void flushToDisk() {
        prefs.edit().putLong("state.last.flush", System.currentTimeMillis()).commit();
    }

    public void resetEq(int channel) {
        SharedPreferences.Editor e = prefs.edit();
        for (int b = 0; b < BANDS; b++) {
            e.putFloat(gainKey(channel, b), 0f);
            e.putFloat(freqKey(channel, b), DEFAULT_FREQS[b]);
            e.putFloat(qKey(channel, b), 1f);
        }
        e.apply();
    }

    public void resetControlsKeepThemeAndPresets() {
        SharedPreferences.Editor e = prefs.edit();
        for (String key : prefs.getAll().keySet()) {
            if (key.startsWith("preset.") || key.equals("theme.dark") || key.equals("ui.selected.page")) continue;
            e.remove(key);
        }
        e.apply();
    }

    public void savePreset(String name) {
        String cleaned = sanitizePresetName(name);
        if (cleaned.isEmpty()) return;
        prefs.edit().putString("preset." + cleaned, encodeCurrentState()).apply();
    }

    public boolean loadPreset(String name) {
        String cleaned = sanitizePresetName(name);
        String encoded = prefs.getString("preset." + cleaned, null);
        if (encoded == null || encoded.isEmpty()) return false;

        String[] values = encoded.split("\\|", -1);
        int expected = 3 + CHANNELS + CHANNELS * BANDS * 3;
        if (values.length != expected) return false;

        try {
            int i = 0;
            SharedPreferences.Editor e = prefs.edit();
            e.putFloat("mix.master", Float.parseFloat(values[i++]));
            e.putFloat("mix.bass", Float.parseFloat(values[i++]));
            e.putFloat("mix.cutoff", Float.parseFloat(values[i++]));
            for (int ch = 0; ch < CHANNELS; ch++) e.putFloat(channelKey(ch), Float.parseFloat(values[i++]));
            for (int ch = 0; ch < CHANNELS; ch++) {
                for (int b = 0; b < BANDS; b++) {
                    e.putFloat(gainKey(ch, b), Float.parseFloat(values[i++]));
                    e.putFloat(freqKey(ch, b), Float.parseFloat(values[i++]));
                    e.putFloat(qKey(ch, b), Float.parseFloat(values[i++]));
                }
            }
            e.apply();
            return true;
        } catch (NumberFormatException ex) {
            return false;
        }
    }

    public List<String> listPresets() {
        List<String> names = new ArrayList<>();
        for (Map.Entry<String, ?> entry : prefs.getAll().entrySet()) {
            if (entry.getKey().startsWith("preset.")) names.add(entry.getKey().substring("preset.".length()));
        }
        Collections.sort(names, String.CASE_INSENSITIVE_ORDER);
        return names;
    }

    private String encodeCurrentState() {
        StringBuilder sb = new StringBuilder(4096);
        append(sb, getMasterVolume());
        append(sb, getBassVolume());
        append(sb, getBassCutoff());
        for (int ch = 0; ch < CHANNELS; ch++) append(sb, getChannelVolume(ch));
        for (int ch = 0; ch < CHANNELS; ch++) {
            for (int b = 0; b < BANDS; b++) {
                append(sb, getBandGain(ch, b));
                append(sb, getBandFrequency(ch, b));
                append(sb, getBandQ(ch, b));
            }
        }
        if (sb.length() > 0) sb.setLength(sb.length() - 1);
        return sb.toString();
    }

    private static void append(StringBuilder sb, float value) {
        sb.append(value).append('|');
    }

    private static String sanitizePresetName(String name) {
        if (name == null) return "";
        return name.trim().replace("|", "").replace("\n", " ").replace("\r", " ");
    }

    public static float defaultFrequency(int band) {
        return DEFAULT_FREQS[clampIndex(band, BANDS)];
    }

    private static int clampIndex(int index, int size) {
        return Math.max(0, Math.min(size - 1, index));
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}
