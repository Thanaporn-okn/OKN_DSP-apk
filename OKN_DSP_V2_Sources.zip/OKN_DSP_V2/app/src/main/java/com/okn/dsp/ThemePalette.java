package com.okn.dsp;

import android.graphics.Color;

final class ThemePalette {
    final int background;
    final int card;
    final int cardAlt;
    final int text;
    final int muted;
    final int accent;
    final int accentSoft;
    final int border;
    final int success;
    final int warning;
    final int track;
    final boolean lightSystemBars;

    private ThemePalette(int background, int card, int cardAlt, int text, int muted,
                         int accent, int accentSoft, int border, int success, int warning,
                         int track, boolean lightSystemBars) {
        this.background = background;
        this.card = card;
        this.cardAlt = cardAlt;
        this.text = text;
        this.muted = muted;
        this.accent = accent;
        this.accentSoft = accentSoft;
        this.border = border;
        this.success = success;
        this.warning = warning;
        this.track = track;
        this.lightSystemBars = lightSystemBars;
    }

    static ThemePalette of(int theme) {
        if (theme == 1) {
            return new ThemePalette(
                    Color.rgb(15, 23, 42),
                    Color.rgb(30, 41, 59),
                    Color.rgb(24, 34, 52),
                    Color.rgb(248, 250, 252),
                    Color.rgb(148, 163, 184),
                    Color.rgb(56, 189, 248),
                    Color.rgb(14, 59, 79),
                    Color.rgb(51, 65, 85),
                    Color.rgb(34, 197, 94),
                    Color.rgb(251, 146, 60),
                    Color.rgb(71, 85, 105),
                    false
            );
        }
        if (theme == 2) {
            return new ThemePalette(
                    Color.BLACK,
                    Color.rgb(12, 12, 14),
                    Color.rgb(19, 19, 22),
                    Color.WHITE,
                    Color.rgb(160, 160, 170),
                    Color.rgb(10, 132, 255),
                    Color.rgb(15, 36, 61),
                    Color.rgb(42, 42, 48),
                    Color.rgb(48, 209, 88),
                    Color.rgb(255, 159, 10),
                    Color.rgb(52, 52, 58),
                    false
            );
        }
        return new ThemePalette(
                Color.rgb(245, 247, 251),
                Color.WHITE,
                Color.rgb(249, 250, 252),
                Color.rgb(17, 24, 39),
                Color.rgb(113, 128, 150),
                Color.rgb(10, 132, 255),
                Color.rgb(231, 243, 255),
                Color.rgb(229, 234, 242),
                Color.rgb(34, 197, 94),
                Color.rgb(255, 149, 0),
                Color.rgb(222, 229, 239),
                true
        );
    }

    static String name(int theme) {
        switch (theme) {
            case 1: return "Midnight";
            case 2: return "AMOLED";
            default: return "Ice Light";
        }
    }
}
