package com.okn.dsp;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

final class DspUiState {
    static final int CHANNELS = 7;
    static final int BANDS = 15;
    static final String PREFS = "okn_dsp_v1_state"; // keep stable across app versions

    static final float[] DEFAULT_FREQ = {
            20f, 31.5f, 50f, 80f, 100f,
            160f, 250f, 400f, 630f, 1000f,
            1600f, 2500f, 4000f, 8000f, 16000f
    };

    int theme = 0;
    int page = 0;
    int selectedChannel = 0;
    int selectedBand = 4;

    float masterVolume = -6f;
    float bassVolume = 2f;
    float bassCutoff = 80f;

    final float[] channelVolume = {-3f, -6f, -2f, -8f, 0f, -4f, -10f};
    final float[][] freq = new float[CHANNELS][BANDS];
    final float[][] gain = new float[CHANNELS][BANDS];
    final float[][] q = new float[CHANNELS][BANDS];

    private final SharedPreferences prefs;
    private long lastFastWriteMs = 0L;

    DspUiState(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        seedDefaults();
        load();
    }

    private void seedDefaults() {
        float[] shape = {-2f, -1f, 1.5f, 4f, 2.5f, 0.4f, -1.4f, -2f, 0f, 2.3f, 3.2f, 2.7f, 1.2f, -0.5f, -1.7f};
        for (int c = 0; c < CHANNELS; c++) {
            for (int b = 0; b < BANDS; b++) {
                freq[c][b] = DEFAULT_FREQ[b];
                gain[c][b] = c == 0 ? shape[b] : 0f;
                q[c][b] = 1.0f;
            }
        }
    }

    void load() {
        theme = clamp(prefs.getInt("theme", theme), 0, 2);
        page = clamp(prefs.getInt("page", page), 0, 2);
        selectedChannel = clamp(prefs.getInt("selected_channel", selectedChannel), 0, CHANNELS - 1);
        selectedBand = clamp(prefs.getInt("selected_band", selectedBand), 0, BANDS - 1);
        masterVolume = clamp(prefs.getFloat("master", masterVolume), -60f, 0f);
        bassVolume = clamp(prefs.getFloat("bass", bassVolume), -12f, 12f);
        bassCutoff = clamp(prefs.getFloat("cutoff", bassCutoff), 40f, 250f);

        for (int c = 0; c < CHANNELS; c++) {
            channelVolume[c] = clamp(prefs.getFloat("ch_vol_" + c, channelVolume[c]), -60f, 12f);
            for (int b = 0; b < BANDS; b++) {
                freq[c][b] = clamp(prefs.getFloat("freq_" + c + "_" + b, freq[c][b]), 20f, 20000f);
                gain[c][b] = clamp(prefs.getFloat("gain_" + c + "_" + b, gain[c][b]), -12f, 12f);
                q[c][b] = clamp(prefs.getFloat("q_" + c + "_" + b, q[c][b]), 0.1f, 10f);
            }
        }
    }

    void saveFast() {
        long now = android.os.SystemClock.elapsedRealtime();
        if (now - lastFastWriteMs < 40L) return;
        lastFastWriteMs = now;
        write(false);
    }

    void saveSync() {
        write(true);
    }

    private void write(boolean sync) {
        SharedPreferences.Editor e = prefs.edit()
                .putInt("theme", theme)
                .putInt("page", page)
                .putInt("selected_channel", selectedChannel)
                .putInt("selected_band", selectedBand)
                .putFloat("master", masterVolume)
                .putFloat("bass", bassVolume)
                .putFloat("cutoff", bassCutoff);

        for (int c = 0; c < CHANNELS; c++) {
            e.putFloat("ch_vol_" + c, channelVolume[c]);
            for (int b = 0; b < BANDS; b++) {
                e.putFloat("freq_" + c + "_" + b, freq[c][b]);
                e.putFloat("gain_" + c + "_" + b, gain[c][b]);
                e.putFloat("q_" + c + "_" + b, q[c][b]);
            }
        }
        if (sync) e.commit(); else e.apply();
    }

    void flattenSelectedChannel() {
        for (int b = 0; b < BANDS; b++) {
            freq[selectedChannel][b] = DEFAULT_FREQ[b];
            gain[selectedChannel][b] = 0f;
            q[selectedChannel][b] = 1f;
        }
        saveSync();
    }

    void resetSelectedBand() {
        int c = selectedChannel;
        int b = selectedBand;
        freq[c][b] = DEFAULT_FREQ[b];
        gain[c][b] = 0f;
        q[c][b] = 1f;
        saveFast();
    }

    void resetAll() {
        theme = 0;
        page = 0;
        selectedChannel = 0;
        selectedBand = 4;
        masterVolume = -6f;
        bassVolume = 2f;
        bassCutoff = 80f;
        float[] initial = {-3f, -6f, -2f, -8f, 0f, -4f, -10f};
        for (int c = 0; c < CHANNELS; c++) {
            channelVolume[c] = initial[c];
            for (int b = 0; b < BANDS; b++) {
                freq[c][b] = DEFAULT_FREQ[b];
                gain[c][b] = 0f;
                q[c][b] = 1f;
            }
        }
        saveSync();
    }

    ArrayList<String> presetNames() {
        Set<String> names = prefs.getStringSet("preset_names", Collections.emptySet());
        ArrayList<String> out = new ArrayList<>();
        out.add("Flat (Factory)");
        if (names != null) out.addAll(names);
        if (out.size() > 1) Collections.sort(out.subList(1, out.size()), String.CASE_INSENSITIVE_ORDER);
        return out;
    }

    boolean savePreset(String rawName) {
        String name = rawName == null ? "" : rawName.trim();
        if (name.isEmpty() || name.equals("Flat (Factory)")) return false;
        try {
            JSONObject root = new JSONObject();
            root.put("master", masterVolume);
            root.put("bass", bassVolume);
            root.put("cutoff", bassCutoff);

            JSONArray channels = new JSONArray();
            for (int c = 0; c < CHANNELS; c++) {
                JSONObject ch = new JSONObject();
                ch.put("volume", channelVolume[c]);
                JSONArray fa = new JSONArray();
                JSONArray ga = new JSONArray();
                JSONArray qa = new JSONArray();
                for (int b = 0; b < BANDS; b++) {
                    fa.put(freq[c][b]);
                    ga.put(gain[c][b]);
                    qa.put(q[c][b]);
                }
                ch.put("freq", fa);
                ch.put("gain", ga);
                ch.put("q", qa);
                channels.put(ch);
            }
            root.put("channels", channels);

            Set<String> current = prefs.getStringSet("preset_names", Collections.emptySet());
            Set<String> copy = new HashSet<>();
            if (current != null) copy.addAll(current);
            copy.add(name);
            prefs.edit()
                    .putStringSet("preset_names", copy)
                    .putString("preset_" + encodeName(name), root.toString())
                    .commit();
            return true;
        } catch (JSONException e) {
            return false;
        }
    }

    boolean loadPreset(String name) {
        if (name == null) return false;
        if (name.equals("Flat (Factory)")) {
            for (int c = 0; c < CHANNELS; c++) {
                for (int b = 0; b < BANDS; b++) {
                    freq[c][b] = DEFAULT_FREQ[b];
                    gain[c][b] = 0f;
                    q[c][b] = 1f;
                }
            }
            saveSync();
            return true;
        }
        String raw = prefs.getString("preset_" + encodeName(name), null);
        if (raw == null) return false;
        try {
            JSONObject root = new JSONObject(raw);
            masterVolume = clamp((float) root.optDouble("master", masterVolume), -60f, 0f);
            bassVolume = clamp((float) root.optDouble("bass", bassVolume), -12f, 12f);
            bassCutoff = clamp((float) root.optDouble("cutoff", bassCutoff), 40f, 250f);
            JSONArray channels = root.getJSONArray("channels");
            for (int c = 0; c < Math.min(CHANNELS, channels.length()); c++) {
                JSONObject ch = channels.getJSONObject(c);
                channelVolume[c] = clamp((float) ch.optDouble("volume", channelVolume[c]), -60f, 12f);
                JSONArray fa = ch.getJSONArray("freq");
                JSONArray ga = ch.getJSONArray("gain");
                JSONArray qa = ch.getJSONArray("q");
                for (int b = 0; b < BANDS; b++) {
                    if (b < fa.length()) freq[c][b] = clamp((float) fa.getDouble(b), 20f, 20000f);
                    if (b < ga.length()) gain[c][b] = clamp((float) ga.getDouble(b), -12f, 12f);
                    if (b < qa.length()) q[c][b] = clamp((float) qa.getDouble(b), 0.1f, 10f);
                }
            }
            saveSync();
            return true;
        } catch (JSONException e) {
            return false;
        }
    }

    private static String encodeName(String name) {
        return Base64.encodeToString(name.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP | Base64.URL_SAFE);
    }

    static int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }

    static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    static String db(float v) {
        if (Math.abs(v - Math.round(v)) < 0.05f) return String.format(Locale.US, "%d dB", Math.round(v));
        return String.format(Locale.US, "%.1f dB", v);
    }

    static String hz(float v) {
        if (v >= 1000f) {
            float k = v / 1000f;
            if (Math.abs(k - Math.round(k)) < 0.05f) return String.format(Locale.US, "%.0f kHz", k);
            return String.format(Locale.US, "%.1f kHz", k);
        }
        return String.format(Locale.US, "%.0f Hz", v);
    }

    static String qText(float v) {
        return String.format(Locale.US, "%.2f", v);
    }
}
