package com.okn.dsp;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.TextView;

/**
 * V2 startup-hardened host Activity.
 *
 * The UI is still rendered from code by DspUiView.  V2 deliberately keeps the Activity launch
 * path dependent only on Android APIs available at the app's minimum SDK and provides an in-app
 * recovery view if main UI construction fails, instead of immediately closing the process.
 */
public final class MainActivity extends Activity implements DspUiView.Host {
    private UiStateStore store;
    private DspUiView ui;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            store = new UiStateStore(getApplicationContext());
            applySystemBars();
            ui = new DspUiView(this, store, new NoOpDspTransport(), this);
            setContentView(ui);
        } catch (RuntimeException | LinkageError error) {
            showLaunchRecovery(error);
        }
    }

    @Override
    public void onThemeChanged() {
        applySystemBars();
    }

    private void applySystemBars() {
        Window window = getWindow();
        boolean dark = store != null && store.theme == UiStateStore.THEME_DARK;
        int barColor = Color.parseColor(dark ? "#0B111B" : "#F5F7FB");
        window.setStatusBarColor(barColor);
        window.setNavigationBarColor(barColor);

        // Compatible from the app minimum SDK. Avoid direct WindowInsetsController references in
        // the startup path so launch does not depend on API-30 class verification/behavior.
        int flags = window.getDecorView().getSystemUiVisibility();
        if (dark) {
            flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                flags &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            }
        } else {
            if (android.os.Build.VERSION.SDK_INT >= 23) {
                flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            }
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            }
        }
        window.getDecorView().setSystemUiVisibility(flags);
    }

    private void showLaunchRecovery(Throwable error) {
        // Keep the app open even if a launch-critical custom-UI path fails.  This screen is built
        // with framework widgets only and therefore also makes field diagnostics possible.
        TextView fallback = new TextView(this);
        fallback.setGravity(Gravity.CENTER);
        fallback.setPadding(dp(28), dp(28), dp(28), dp(28));
        fallback.setTextSize(16f);
        fallback.setTextColor(Color.parseColor("#0A1324"));
        fallback.setBackgroundColor(Color.parseColor("#F5F7FB"));
        String type = error == null ? "Unknown" : error.getClass().getSimpleName();
        fallback.setText(
                "OKN DSP V2\n\n" +
                "Safe launch mode is active.\n" +
                "UI startup error: " + type + "\n\n" +
                "The app stayed open so the next fix can use the real error instead of guessing."
        );
        setContentView(fallback);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (store != null) store.commitFinal();
    }

    @Override
    public void onBackPressed() {
        if (store != null && store.page != UiStateStore.PAGE_HOME) {
            store.page = UiStateStore.PAGE_HOME;
            store.savePageAsync();
            if (ui != null) ui.resetScrollAndRefresh();
            return;
        }
        super.onBackPressed();
    }
}
