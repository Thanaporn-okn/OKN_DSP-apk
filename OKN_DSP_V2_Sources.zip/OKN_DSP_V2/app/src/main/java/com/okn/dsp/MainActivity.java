package com.okn.dsp;

import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.widget.TextView;

/**
 * OKN_DSP V2 / Phase 1
 *
 * V2 hardens app startup for newer Samsung/Android devices. Window/full-screen
 * operations are isolated from UI creation so an OEM window exception cannot
 * terminate the app. Phase 1 still contains UI-only local controls; no DSP/BLE
 * protocol is guessed here.
 */
public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        configureWindowSafely();
        enterImmersiveSafely();

        try {
            setContentView(new DspUiView(this));
        } catch (Throwable error) {
            showStartupRecovery(error);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        configureWindowSafely();
        enterImmersiveSafely();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) enterImmersiveSafely();
    }

    private void configureWindowSafely() {
        try {
            Window window = getWindow();
            window.setStatusBarColor(0xFF020713);
            window.setNavigationBarColor(0xFF020713);
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                WindowManager.LayoutParams lp = window.getAttributes();
                lp.layoutInDisplayCutoutMode =
                        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
                window.setAttributes(lp);
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                window.setStatusBarContrastEnforced(false);
                window.setNavigationBarContrastEnforced(false);
            }
        } catch (Throwable ignored) {
            // A vendor/OEM window implementation must never block app startup.
        }
    }

    private void enterImmersiveSafely() {
        try {
            Window window = getWindow();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                window.setDecorFitsSystemWindows(false);
                WindowInsetsController controller = window.getInsetsController();
                if (controller != null) {
                    controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                    controller.setSystemBarsBehavior(
                            WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                    );
                }
            } else {
                window.getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                );
            }
        } catch (Throwable ignored) {
            // Full-screen failure must not terminate the app.
        }
    }

    private void showStartupRecovery(Throwable error) {
        TextView fallback = new TextView(this);
        fallback.setBackgroundColor(Color.rgb(2, 9, 25));
        fallback.setTextColor(Color.WHITE);
        fallback.setGravity(Gravity.CENTER);
        fallback.setPadding(48, 48, 48, 48);
        fallback.setTextSize(18f);
        fallback.setText(
                "OKN_DSP V2\n\n"
                        + "UI startup recovery is active.\n"
                        + "The app stayed open instead of closing.\n\n"
                        + "Error: " + error.getClass().getSimpleName()
        );
        setContentView(fallback);
    }
}
