package com.okn.dsp;

import android.app.Activity;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private DspUiState state;
    private ThemePalette palette;
    private FrameLayout root;
    private FrameLayout pageHost;
    private EqGraphView eqGraph;

    private static final int[] CHANNEL_COLORS = {
            Color.rgb(46, 157, 255), Color.rgb(52, 211, 88), Color.rgb(255, 159, 10),
            Color.rgb(255, 55, 95), Color.rgb(126, 87, 255), Color.rgb(20, 200, 215),
            Color.rgb(106, 92, 255)
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        state = new DspUiState(this);
        palette = ThemePalette.of(state.theme);
        configureWindow();
        buildApp();
    }

    @Override
    protected void onPause() {
        if (state != null) state.saveSync();
        super.onPause();
    }

    private void configureWindow() {
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false);
        }
        applySystemBars();
    }

    private void applySystemBars() {
        Window window = getWindow();
        window.setStatusBarColor(palette.background);
        window.setNavigationBarColor(palette.background);
        int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
        if (palette.lightSystemBars && Build.VERSION.SDK_INT >= 23) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        if (palette.lightSystemBars && Build.VERSION.SDK_INT >= 26) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        window.getDecorView().setSystemUiVisibility(flags);
        if (Build.VERSION.SDK_INT >= 29) {
            window.setStatusBarContrastEnforced(false);
            window.setNavigationBarContrastEnforced(false);
        }
    }

    private void buildApp() {
        palette = ThemePalette.of(state.theme);
        applySystemBars();

        root = new FrameLayout(this);
        root.setBackgroundColor(palette.background);
        root.setClipToPadding(false);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(
                    insets.getSystemWindowInsetLeft(),
                    insets.getSystemWindowInsetTop(),
                    insets.getSystemWindowInsetRight(),
                    insets.getSystemWindowInsetBottom());
            return insets;
        });

        pageHost = new FrameLayout(this);
        FrameLayout.LayoutParams pageLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT);
        pageLp.bottomMargin = dp(82);
        root.addView(pageHost, pageLp);

        View page = buildPage(state.page);
        FrameLayout.LayoutParams contentLp = new FrameLayout.LayoutParams(
                maxContentWidth(), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER_HORIZONTAL);
        pageHost.addView(page, contentLp);

        View nav = buildBottomNav();
        FrameLayout.LayoutParams navLp = new FrameLayout.LayoutParams(
                maxContentWidth(), dp(74), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        navLp.leftMargin = dp(12);
        navLp.rightMargin = dp(12);
        navLp.bottomMargin = dp(8);
        root.addView(nav, navLp);

        setContentView(root);
        root.requestApplyInsets();
    }

    private int maxContentWidth() {
        int screenDp = getResources().getConfiguration().screenWidthDp;
        if (screenDp >= 1200) return dp(980);
        if (screenDp >= 840) return dp(820);
        if (screenDp >= 600) return dp(700);
        return ViewGroup.LayoutParams.MATCH_PARENT;
    }

    private View buildPage(int page) {
        if (page == 1) return buildMixPage();
        if (page == 2) return buildEqPage();
        return buildHomePage();
    }

    private ScrollView newScrollPage() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        return scroll;
    }

    private LinearLayout newPageColumn(ScrollView scroll) {
        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        int horizontal = getResources().getConfiguration().screenWidthDp >= 600 ? 24 : 16;
        column.setPadding(dp(horizontal), dp(16), dp(horizontal), dp(28));
        scroll.addView(column, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return column;
    }

    private View buildHeader(String title, String subtitle) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(4), dp(6), dp(4), dp(14));

        LinearLayout textCol = new LinearLayout(this);
        textCol.setOrientation(LinearLayout.VERTICAL);
        TextView t = text(title, 32, palette.text, true);
        TextView s = text(subtitle, 17, palette.muted, false);
        textCol.addView(t);
        textCol.addView(s);
        row.addView(textCol, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        ImageButton search = iconButton(com.okn.dsp.R.drawable.ic_search);
        search.setContentDescription("Search");
        search.setOnClickListener(v -> Toast.makeText(this,
                "Phase 1: UI พร้อมแล้ว • การสแกน DSP จริงจะเชื่อมใน Phase 2",
                Toast.LENGTH_SHORT).show());
        row.addView(search, new LinearLayout.LayoutParams(dp(52), dp(52)));

        SpaceShim gap = new SpaceShim(this);
        row.addView(gap, new LinearLayout.LayoutParams(dp(8), 1));

        ImageButton more = iconButton(com.okn.dsp.R.drawable.ic_more);
        more.setContentDescription("More");
        more.setOnClickListener(v -> showMainMenu(more));
        row.addView(more, new LinearLayout.LayoutParams(dp(52), dp(52)));
        return row;
    }

    private void showMainMenu(View anchor) {
        PopupMenu menu = new PopupMenu(this, anchor);
        menu.getMenu().add(0, 100, 0, "Theme: Ice Light");
        menu.getMenu().add(0, 101, 1, "Theme: Midnight");
        menu.getMenu().add(0, 102, 2, "Theme: AMOLED");
        menu.getMenu().add(0, 200, 3, "Version 2 • Phase 1 Final UI");
        menu.getMenu().add(0, 201, 4, "Reset local UI data");
        menu.setOnMenuItemClickListener(item -> {
            if (item.getItemId() >= 100 && item.getItemId() <= 102) {
                state.theme = item.getItemId() - 100;
                state.saveSync();
                buildApp();
                Toast.makeText(this, "Theme: " + ThemePalette.name(state.theme), Toast.LENGTH_SHORT).show();
                return true;
            }
            if (item.getItemId() == 200) {
                Toast.makeText(this, "OKN DSP Version 2 • Phase 1 Final UI", Toast.LENGTH_SHORT).show();
                return true;
            }
            if (item.getItemId() == 201) {
                state.resetAll();
                buildApp();
                Toast.makeText(this, "Local UI data reset", Toast.LENGTH_SHORT).show();
                return true;
            }
            return false;
        });
        menu.show();
    }

    private View buildHomePage() {
        ScrollView scroll = newScrollPage();
        LinearLayout col = newPageColumn(scroll);
        col.addView(buildHeader("OKN DSP", "DSP Controller • Version 2"));

        LinearLayout hero = card();
        hero.setPadding(dp(18), dp(18), dp(18), dp(18));
        hero.setGravity(Gravity.CENTER_VERTICAL);
        hero.setOrientation(LinearLayout.HORIZONTAL);
        TextView check = circleText("✓", 54, Color.rgb(48, 209, 88), Color.WHITE, 27, true);
        hero.addView(check, new LinearLayout.LayoutParams(dp(64), dp(64)));
        LinearLayout.LayoutParams heroTextLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        heroTextLp.leftMargin = dp(16);
        LinearLayout heroText = new LinearLayout(this);
        heroText.setOrientation(LinearLayout.VERTICAL);
        heroText.addView(text("SYSTEM STATUS", 12, palette.muted, true));
        heroText.addView(text("Phase 1 UI Final", 24, palette.text, true));
        heroText.addView(text("Controls are live and saved locally in real time.", 14, palette.muted, false));
        hero.addView(heroText, heroTextLp);
        TextView arrow = text("›", 34, palette.muted, false);
        hero.addView(arrow);
        hero.setOnClickListener(v -> Toast.makeText(this,
                "Phase 1 ทำเฉพาะ UI • การเชื่อม DSP จริงเริ่มใน Phase 2",
                Toast.LENGTH_SHORT).show());
        col.addView(hero, marginBottom(16));

        LinearLayout sectionHead = new LinearLayout(this);
        sectionHead.setOrientation(LinearLayout.HORIZONTAL);
        sectionHead.setGravity(Gravity.CENTER_VERTICAL);
        sectionHead.setPadding(dp(4), dp(8), dp(4), dp(8));
        sectionHead.addView(text("Connection & Status", 22, palette.text, true),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView status = text("UI Ready  ●", 15, palette.success, true);
        sectionHead.addView(status);
        col.addView(sectionHead);

        col.addView(statusRow("BT", "Bluetooth", "Phase 2 connection", "Pending", Color.rgb(46,157,255), palette.warning));
        col.addView(statusRow("DSP", "DSP Device", "OKN DSP • waiting for protocol", "Pending", Color.rgb(126,87,255), palette.warning));
        col.addView(statusRow("IN", "Audio Input", "AUX (Analog)", "Preview", Color.rgb(255,159,10), palette.accent));
        col.addView(statusRow("AMP", "Amplifier Link", "External amplifier", "Preview", Color.rgb(255,55,95), palette.accent));
        col.addView(statusRow("P", "Preset Sync", "Auto-save is active", "Synced", Color.rgb(20,200,215), palette.success));
        col.addView(statusRow("V2", "Firmware Status", "App UI build", "Phase 1 Final", Color.rgb(106,92,255), palette.accent));

        LinearLayout quick = card();
        quick.setOrientation(LinearLayout.HORIZONTAL);
        quick.setGravity(Gravity.CENTER_VERTICAL);
        quick.setPadding(dp(18), dp(15), dp(18), dp(15));
        quick.addView(circleText("≋", 42, palette.accentSoft, palette.accent, 26, true),
                new LinearLayout.LayoutParams(dp(54), dp(54)));
        LinearLayout qText = new LinearLayout(this);
        qText.setOrientation(LinearLayout.VERTICAL);
        qText.addView(text("Quick Control", 19, palette.text, true));
        qText.addView(text("Adjust volume, channels and EQ", 14, palette.muted, false));
        LinearLayout.LayoutParams qlp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        qlp.leftMargin = dp(14);
        quick.addView(qText, qlp);
        quick.addView(text("›", 34, palette.muted, false));
        quick.setOnClickListener(v -> switchPage(1));
        col.addView(quick, marginTopBottom(14, 12));

        TextView note = text("Version 2 • Native responsive UI • realtime EQ response", 12, palette.muted, false);
        note.setGravity(Gravity.CENTER);
        col.addView(note, marginTopBottom(4, 12));
        return scroll;
    }

    private View statusRow(String badge, String title, String sub, String status, int badgeColor, int statusColor) {
        LinearLayout row = card();
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(12), dp(14), dp(12));
        row.addView(circleText(badge, 36, badgeColor, Color.WHITE, badge.length() > 2 ? 10 : 17, true),
                new LinearLayout.LayoutParams(dp(52), dp(52)));
        LinearLayout tc = new LinearLayout(this);
        tc.setOrientation(LinearLayout.VERTICAL);
        tc.addView(text(title, 18, palette.text, true));
        tc.addView(text(sub, 14, palette.muted, false));
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        tlp.leftMargin = dp(14);
        row.addView(tc, tlp);
        TextView st = text("●  " + status, 14, statusColor, true);
        row.addView(st);
        TextView arrow = text("  ›", 28, palette.muted, false);
        row.addView(arrow);
        row.setOnClickListener(v -> Toast.makeText(this, title + ": " + status, Toast.LENGTH_SHORT).show());
        LinearLayout.LayoutParams lp = marginBottom(10);
        row.setLayoutParams(lp);
        return row;
    }

    private View buildMixPage() {
        ScrollView scroll = newScrollPage();
        LinearLayout col = newPageColumn(scroll);
        col.addView(buildHeader("Mix", "Channel and bass controls"));

        col.addView(sectionLabel("Global", "Overall output and bass settings"));
        LinearLayout global = card();
        global.setOrientation(LinearLayout.VERTICAL);
        global.setPadding(dp(16), dp(10), dp(16), dp(10));
        global.addView(linearSliderRow("Master Volume", state.masterVolume, -60f, 0f, 600,
                v -> DspUiState.db(v), v -> state.masterVolume = v, palette.accent));
        global.addView(divider());
        global.addView(linearSliderRow("Bass Volume", state.bassVolume, -12f, 12f, 240,
                v -> DspUiState.db(v), v -> state.bassVolume = v, Color.rgb(255,159,10)));
        global.addView(divider());
        global.addView(linearSliderRow("Bass Cutoff", state.bassCutoff, 40f, 250f, 210,
                v -> String.format(Locale.US, "%.0f Hz", v), v -> state.bassCutoff = v, Color.rgb(126,87,255)));
        col.addView(global, marginBottom(18));

        col.addView(sectionLabel("Channels", "Individual channel levels"));
        LinearLayout channels = card();
        channels.setOrientation(LinearLayout.VERTICAL);
        channels.setPadding(dp(14), dp(8), dp(14), dp(8));
        for (int i = 0; i < DspUiState.CHANNELS; i++) {
            final int ch = i;
            LinearLayout row = linearSliderRow("Volume Ch" + (i + 1), state.channelVolume[i], -60f, 12f, 720,
                    v -> DspUiState.db(v), v -> state.channelVolume[ch] = v, CHANNEL_COLORS[i]);
            TextView badge = circleText(String.valueOf(i + 1), 34, CHANNEL_COLORS[i], Color.WHITE, 18, true);
            row.addView(badge, 0, new LinearLayout.LayoutParams(dp(44), dp(44)));
            channels.addView(row);
            if (i < DspUiState.CHANNELS - 1) channels.addView(divider());
        }
        col.addView(channels, marginBottom(20));
        return scroll;
    }

    private View sectionLabel(String left, String right) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.BOTTOM);
        row.setPadding(dp(4), dp(6), dp(4), dp(8));
        row.addView(text(left, 23, palette.text, true),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView r = text(right, 13, palette.muted, false);
        r.setGravity(Gravity.END);
        row.addView(r);
        return row;
    }

    private View buildEqPage() {
        ScrollView scroll = newScrollPage();
        LinearLayout col = newPageColumn(scroll);
        col.addView(buildHeader("Eq", "15-band equalizer • 7 channels"));
        col.addView(buildChannelTabs(), marginBottom(12));

        LinearLayout eqCard = card();
        eqCard.setOrientation(LinearLayout.VERTICAL);
        eqCard.setPadding(dp(16), dp(14), dp(16), dp(16));

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout tc = new LinearLayout(this);
        tc.setOrientation(LinearLayout.VERTICAL);
        tc.addView(text("Channel " + (state.selectedChannel + 1), 22, palette.text, true));
        tc.addView(text(channelName(state.selectedChannel) + "  •  15-band EQ", 14, palette.muted, false));
        titleRow.addView(tc, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView reset = pillButton("↻  Reset EQ", false);
        reset.setOnClickListener(v -> {
            state.flattenSelectedChannel();
            if (eqGraph != null) eqGraph.invalidate();
            buildApp();
        });
        titleRow.addView(reset);
        eqCard.addView(titleRow);

        eqGraph = new EqGraphView(this, state, palette);
        eqGraph.setListener(band -> buildApp());
        LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(280));
        glp.topMargin = dp(10);
        eqCard.addView(eqGraph, glp);
        col.addView(eqCard, marginBottom(14));

        LinearLayout bandCard = card();
        bandCard.setOrientation(LinearLayout.VERTICAL);
        bandCard.setPadding(dp(16), dp(14), dp(16), dp(14));
        LinearLayout bandHead = new LinearLayout(this);
        bandHead.setOrientation(LinearLayout.HORIZONTAL);
        bandHead.setGravity(Gravity.CENTER_VERTICAL);
        bandHead.addView(circleText(String.valueOf(state.selectedBand + 1), 42, palette.accentSoft, palette.accent, 22, true),
                new LinearLayout.LayoutParams(dp(54), dp(54)));
        LinearLayout bt = new LinearLayout(this);
        bt.setOrientation(LinearLayout.VERTICAL);
        bt.addView(text("Band " + (state.selectedBand + 1), 20, palette.text, true));
        bt.addView(text("Frequency • Q • Gain update immediately", 13, palette.muted, false));
        LinearLayout.LayoutParams btlp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        btlp.leftMargin = dp(14);
        bandHead.addView(bt, btlp);
        TextView prev = circleText("‹", 40, palette.cardAlt, palette.text, 30, false);
        prev.setOnClickListener(v -> {
            state.selectedBand = (state.selectedBand + DspUiState.BANDS - 1) % DspUiState.BANDS;
            state.saveFast();
            buildApp();
        });
        bandHead.addView(prev, new LinearLayout.LayoutParams(dp(48), dp(48)));
        SpaceShim g = new SpaceShim(this);
        bandHead.addView(g, new LinearLayout.LayoutParams(dp(8), 1));
        TextView next = circleText("›", 40, palette.cardAlt, palette.text, 30, false);
        next.setOnClickListener(v -> {
            state.selectedBand = (state.selectedBand + 1) % DspUiState.BANDS;
            state.saveFast();
            buildApp();
        });
        bandHead.addView(next, new LinearLayout.LayoutParams(dp(48), dp(48)));
        bandCard.addView(bandHead);
        bandCard.addView(freqSliderRow());
        bandCard.addView(qSliderRow());
        bandCard.addView(gainSliderRow());
        TextView resetBand = pillButton("Reset selected band", false);
        LinearLayout.LayoutParams rblp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(42));
        rblp.gravity = Gravity.END;
        rblp.topMargin = dp(8);
        resetBand.setOnClickListener(v -> {
            state.resetSelectedBand();
            buildApp();
        });
        bandCard.addView(resetBand, rblp);
        col.addView(bandCard, marginBottom(14));

        col.addView(buildPresetCard(), marginBottom(20));
        return scroll;
    }

    private View buildChannelTabs() {
        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.setGravity(Gravity.CENTER);
        tabs.setPadding(0, 0, 0, 0);
        for (int i = 0; i < DspUiState.CHANNELS; i++) {
            final int ch = i;
            boolean selected = i == state.selectedChannel;
            TextView tab = text("Ch" + (i + 1), 14, selected ? Color.WHITE : palette.muted, selected);
            tab.setGravity(Gravity.CENTER);
            tab.setMinWidth(0);
            tab.setBackground(roundRect(selected ? palette.accent : palette.cardAlt, 22, palette.border, selected ? 0 : 1));
            tab.setOnClickListener(v -> {
                state.selectedChannel = ch;
                state.saveFast();
                buildApp();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(46), 1f);
            if (i > 0) lp.leftMargin = dp(5);
            tabs.addView(tab, lp);
        }
        return tabs;
    }

    private View freqSliderRow() {
        int ch = state.selectedChannel;
        int band = state.selectedBand;
        float current = state.freq[ch][band];
        LinearLayout row = baseControlRow("Frequency", "20 Hz", "20 kHz");
        TextView value = valueChip(DspUiState.hz(current));
        ((LinearLayout) row.getChildAt(0)).addView(value);
        SeekBar seek = seekBar(palette.accent);
        seek.setMax(1000);
        seek.setProgress(freqToProgress(current));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser) return;
                float v = progressToFreq(progress);
                state.freq[state.selectedChannel][state.selectedBand] = v;
                value.setText(DspUiState.hz(v));
                if (eqGraph != null) eqGraph.invalidate();
                state.saveFast();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) { state.saveSync(); }
        });
        ((LinearLayout) row.getChildAt(1)).addView(seek, 1, new LinearLayout.LayoutParams(0, dp(38), 1f));
        return row;
    }

    private View qSliderRow() {
        int ch = state.selectedChannel;
        int band = state.selectedBand;
        float current = state.q[ch][band];
        LinearLayout row = baseControlRow("Q (Quality Factor)", "0.1", "10.0");
        TextView value = valueChip(DspUiState.qText(current));
        ((LinearLayout) row.getChildAt(0)).addView(value);
        SeekBar seek = seekBar(palette.accent);
        seek.setMax(990);
        seek.setProgress(Math.round((current - 0.1f) * 100f));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser) return;
                float v = DspUiState.clamp(0.1f + progress / 100f, 0.1f, 10f);
                state.q[state.selectedChannel][state.selectedBand] = v;
                value.setText(DspUiState.qText(v));
                if (eqGraph != null) eqGraph.invalidate();
                state.saveFast();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) { state.saveSync(); }
        });
        ((LinearLayout) row.getChildAt(1)).addView(seek, 1, new LinearLayout.LayoutParams(0, dp(38), 1f));
        return row;
    }

    private View gainSliderRow() {
        int ch = state.selectedChannel;
        int band = state.selectedBand;
        float current = state.gain[ch][band];
        LinearLayout row = baseControlRow("Gain / Ch Volume", "-12 dB", "+12 dB");
        TextView value = valueChip(DspUiState.db(current));
        ((LinearLayout) row.getChildAt(0)).addView(value);
        SeekBar seek = seekBar(palette.accent);
        seek.setMax(240);
        seek.setProgress(Math.round((current + 12f) * 10f));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser) return;
                float v = -12f + progress / 10f;
                state.gain[state.selectedChannel][state.selectedBand] = v;
                value.setText(DspUiState.db(v));
                if (eqGraph != null) eqGraph.invalidate();
                state.saveFast();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) { state.saveSync(); }
        });
        ((LinearLayout) row.getChildAt(1)).addView(seek, 1, new LinearLayout.LayoutParams(0, dp(38), 1f));
        return row;
    }

    private LinearLayout baseControlRow(String label, String min, String max) {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setPadding(0, dp(9), 0, dp(6));
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(text(label, 16, palette.text, true), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        outer.addView(top);
        LinearLayout lower = new LinearLayout(this);
        lower.setOrientation(LinearLayout.HORIZONTAL);
        lower.setGravity(Gravity.CENTER_VERTICAL);
        TextView minT = text(min, 11, palette.muted, false);
        minT.setMinWidth(dp(54));
        lower.addView(minT);
        TextView maxT = text(max, 11, palette.muted, false);
        maxT.setGravity(Gravity.END);
        maxT.setMinWidth(dp(54));
        lower.addView(maxT);
        outer.addView(lower);
        return outer;
    }

    private View buildPresetCard() {
        LinearLayout card = card();
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(16));

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(circleText("P", 40, Color.rgb(20, 200, 215), Color.WHITE, 19, true),
                new LinearLayout.LayoutParams(dp(50), dp(50)));
        LinearLayout text = new LinearLayout(this);
        text.setOrientation(LinearLayout.VERTICAL);
        text.addView(text("Presets", 20, palette.text, true));
        text.addView(text("Save and load all 7-channel EQ values", 13, palette.muted, false));
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        tlp.leftMargin = dp(12);
        head.addView(text, tlp);
        head.addView(text("⋮", 28, palette.muted, false));
        card.addView(head);

        LinearLayout saveRow = new LinearLayout(this);
        saveRow.setOrientation(LinearLayout.HORIZONTAL);
        saveRow.setGravity(Gravity.CENTER_VERTICAL);
        saveRow.setPadding(0, dp(12), 0, dp(8));
        EditText name = new EditText(this);
        name.setSingleLine(true);
        name.setTextColor(palette.text);
        name.setHintTextColor(palette.muted);
        name.setHint("Preset name");
        name.setTextSize(15);
        name.setPadding(dp(12), 0, dp(12), 0);
        name.setBackground(roundRect(palette.cardAlt, 12, palette.border, 1));
        saveRow.addView(name, new LinearLayout.LayoutParams(0, dp(50), 1f));
        TextView save = pillButton("Save Preset", true);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(dp(136), dp(50));
        slp.leftMargin = dp(10);
        saveRow.addView(save, slp);
        card.addView(saveRow);

        ArrayList<String> names = state.presetNames();
        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, names) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                TextView v = (TextView) super.getView(position, convertView, parent);
                v.setTextColor(palette.text);
                v.setTextSize(15);
                v.setPadding(dp(12), 0, dp(8), 0);
                return v;
            }
        };
        spinner.setAdapter(adapter);
        spinner.setBackground(roundRect(palette.cardAlt, 12, palette.border, 1));

        LinearLayout loadRow = new LinearLayout(this);
        loadRow.setOrientation(LinearLayout.HORIZONTAL);
        loadRow.setGravity(Gravity.CENTER_VERTICAL);
        loadRow.addView(spinner, new LinearLayout.LayoutParams(0, dp(50), 1f));
        TextView load = pillButton("Load", false);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(dp(112), dp(50));
        llp.leftMargin = dp(10);
        loadRow.addView(load, llp);
        card.addView(loadRow);

        save.setOnClickListener(v -> {
            if (state.savePreset(name.getText().toString())) {
                Toast.makeText(this, "Preset saved", Toast.LENGTH_SHORT).show();
                buildApp();
            } else {
                Toast.makeText(this, "Enter a preset name", Toast.LENGTH_SHORT).show();
            }
        });
        load.setOnClickListener(v -> {
            Object selected = spinner.getSelectedItem();
            if (selected != null && state.loadPreset(String.valueOf(selected))) {
                Toast.makeText(this, "Preset loaded: " + selected, Toast.LENGTH_SHORT).show();
                buildApp();
            } else {
                Toast.makeText(this, "Preset could not be loaded", Toast.LENGTH_SHORT).show();
            }
        });
        return card;
    }

    private LinearLayout linearSliderRow(String label, float value, float min, float max, int steps,
                                         Formatter formatter, ValueSetter setter, int accent) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(8), 0, dp(8));

        LinearLayout center = new LinearLayout(this);
        center.setOrientation(LinearLayout.VERTICAL);
        TextView labelView = text(label, 16, palette.text, true);
        center.addView(labelView);
        LinearLayout sliderLine = new LinearLayout(this);
        sliderLine.setOrientation(LinearLayout.HORIZONTAL);
        sliderLine.setGravity(Gravity.CENTER_VERTICAL);
        SeekBar seek = seekBar(accent);
        seek.setMax(steps);
        seek.setProgress(Math.round((value - min) / (max - min) * steps));
        sliderLine.addView(seek, new LinearLayout.LayoutParams(0, dp(38), 1f));
        TextView valueView = valueChip(formatter.format(value));
        LinearLayout.LayoutParams vlp = new LinearLayout.LayoutParams(dp(92), dp(44));
        vlp.leftMargin = dp(10);
        sliderLine.addView(valueView, vlp);
        center.addView(sliderLine);
        row.addView(center, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser) return;
                float v = min + (max - min) * (progress / (float) steps);
                setter.set(v);
                valueView.setText(formatter.format(v));
                state.saveFast();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) { state.saveSync(); }
        });
        return row;
    }

    private SeekBar seekBar(int accent) {
        SeekBar seek = new SeekBar(this);
        seek.setProgressTintList(ColorStateList.valueOf(accent));
        seek.setThumbTintList(ColorStateList.valueOf(accent));
        seek.setProgressBackgroundTintList(ColorStateList.valueOf(palette.track));
        return seek;
    }

    private TextView valueChip(String value) {
        TextView tv = text(value, 15, palette.text, false);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(10), 0, dp(10), 0);
        tv.setBackground(roundRect(palette.cardAlt, 12, palette.border, 0));
        return tv;
    }

    private View buildBottomNav() {
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(10), dp(8), dp(10), dp(8));
        nav.setBackground(roundRect(palette.card, 28, palette.border, 1));
        if (Build.VERSION.SDK_INT >= 21) nav.setElevation(dp(5));
        nav.addView(navItem(0, "Home", com.okn.dsp.R.drawable.ic_home), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        nav.addView(navItem(1, "Mix", com.okn.dsp.R.drawable.ic_mix), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        nav.addView(navItem(2, "Eq", com.okn.dsp.R.drawable.ic_eq), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        return nav;
    }

    private View navItem(int page, String label, int iconRes) {
        boolean selected = state.page == page;
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        item.setPadding(dp(4), dp(5), dp(4), dp(4));
        if (selected) item.setBackground(roundRect(palette.accentSoft, 20, palette.accentSoft, 0));
        ImageView icon = new ImageView(this);
        icon.setImageResource(iconRes);
        icon.setColorFilter(selected ? palette.accent : palette.muted);
        item.addView(icon, new LinearLayout.LayoutParams(dp(27), dp(27)));
        TextView t = text(label, 13, selected ? palette.accent : palette.muted, selected);
        item.addView(t);
        item.setOnClickListener(v -> switchPage(page));
        return item;
    }

    private void switchPage(int page) {
        if (state.page == page) return;
        state.page = page;
        state.saveFast();
        buildApp();
    }

    private ImageButton iconButton(int drawableRes) {
        ImageButton b = new ImageButton(this);
        b.setImageResource(drawableRes);
        b.setColorFilter(palette.text);
        b.setScaleType(ImageView.ScaleType.CENTER);
        b.setPadding(dp(14), dp(14), dp(14), dp(14));
        b.setBackground(rippleRound(palette.cardAlt, 26));
        return b;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setBackground(rippleRound(palette.card, 24));
        if (Build.VERSION.SDK_INT >= 21 && state.theme == 0) c.setElevation(dp(1));
        return c;
    }

    private TextView pillButton(String text, boolean accent) {
        TextView b = text(text, 14, accent ? Color.WHITE : palette.muted, true);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(14), 0, dp(14), 0);
        b.setBackground(rippleRound(accent ? palette.accent : palette.cardAlt, 18));
        b.setMinHeight(dp(44));
        b.setClickable(true);
        b.setFocusable(true);
        return b;
    }

    private TextView circleText(String content, int sizeDp, int bg, int fg, int sp, boolean bold) {
        TextView tv = text(content, sp, fg, bold);
        tv.setGravity(Gravity.CENTER);
        tv.setBackground(rippleRound(bg, sizeDp / 2));
        tv.setClickable(true);
        tv.setFocusable(true);
        return tv;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView tv = new TextView(this);
        tv.setText(s);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        tv.setIncludeFontPadding(false);
        if (bold) tv.setTypeface(Typeface.create("sans", Typeface.BOLD));
        else tv.setTypeface(Typeface.create("sans", Typeface.NORMAL));
        return tv;
    }

    private View divider() {
        View v = new View(this);
        v.setBackgroundColor(palette.border);
        v.setAlpha(0.75f);
        v.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)));
        return v;
    }

    private Drawable rippleRound(int color, int radiusDp) {
        GradientDrawable shape = roundRect(color, radiusDp, color, 0);
        ColorStateList ripple = ColorStateList.valueOf(withAlpha(palette.accent, 36));
        return new RippleDrawable(ripple, shape, null);
    }

    private GradientDrawable roundRect(int fill, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) d.setStroke(dp(strokeDp), strokeColor);
        return d;
    }

    private LinearLayout.LayoutParams marginBottom(int bottom) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(bottom);
        return lp;
    }

    private LinearLayout.LayoutParams marginTopBottom(int top, int bottom) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(top);
        lp.bottomMargin = dp(bottom);
        return lp;
    }

    private int freqToProgress(float freq) {
        double t = Math.log(freq / 20.0) / Math.log(1000.0);
        return DspUiState.clamp((int) Math.round(t * 1000.0), 0, 1000);
    }

    private float progressToFreq(int progress) {
        double t = progress / 1000.0;
        return (float) (20.0 * Math.pow(1000.0, t));
    }

    private String channelName(int ch) {
        switch (ch) {
            case 0: return "Front Left";
            case 1: return "Front Right";
            case 2: return "Rear Left";
            case 3: return "Rear Right";
            case 4: return "Center";
            case 5: return "Sub";
            default: return "Aux";
        }
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | ((alpha & 0xFF) << 24);
    }

    private interface Formatter { String format(float value); }
    private interface ValueSetter { void set(float value); }

    private static final class SpaceShim extends View {
        SpaceShim(Activity context) { super(context); }
    }
}
