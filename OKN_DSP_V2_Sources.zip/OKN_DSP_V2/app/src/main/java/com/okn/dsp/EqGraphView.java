package com.okn.dsp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

/**
 * Native realtime parametric-EQ graph.
 *
 * The curve is calculated from all 15 peaking-EQ bands using standard biquad
 * magnitude response math at 48 kHz. Q therefore visibly changes the graph,
 * not only the stored value. The graph can also be dragged: horizontal motion
 * changes the selected band's frequency and vertical motion changes its gain.
 */
final class EqGraphView extends View {
    interface Listener {
        void onBandSelected(int band);
    }

    private static final double SAMPLE_RATE = 48000.0;
    private static final int CURVE_SAMPLES = 180;

    private final DspUiState state;
    private ThemePalette palette;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path responsePath = new Path();
    private final Path fillPath = new Path();
    private Listener listener;
    private final float density;
    private boolean dragging;

    EqGraphView(Context context, DspUiState state, ThemePalette palette) {
        super(context);
        this.state = state;
        this.palette = palette;
        density = getResources().getDisplayMetrics().density;
        setMinimumHeight((int) (250f * density));
        setFocusable(true);
        setClickable(true);
    }

    void setPalette(ThemePalette palette) {
        this.palette = palette;
        invalidate();
    }

    void setListener(Listener listener) {
        this.listener = listener;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int desired = (int) (280f * density);
        int height = resolveSize(desired, heightMeasureSpec);
        setMeasuredDimension(width, height);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        final float w = getWidth();
        final float h = getHeight();
        final float left = 44f * density;
        final float right = w - 14f * density;
        final float top = 18f * density;
        final float bottom = h - 38f * density;

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(palette.cardAlt);
        canvas.drawRoundRect(new RectF(0, 0, w, h), 22f * density, 22f * density, paint);

        float selectedX = xForFreq(state.freq[state.selectedChannel][state.selectedBand], left, right);
        paint.setColor(withAlpha(palette.accent, 24));
        canvas.drawRoundRect(new RectF(selectedX - 14f * density, top, selectedX + 14f * density, bottom),
                11f * density, 11f * density, paint);

        drawGrid(canvas, left, right, top, bottom, h);
        drawResponse(canvas, left, right, top, bottom);
        drawBandNodes(canvas, left, right, top, bottom);
    }

    private void drawGrid(Canvas canvas, float left, float right, float top, float bottom, float h) {
        paint.setStrokeWidth(1f * density);
        paint.setColor(withAlpha(palette.muted, 44));
        paint.setStyle(Paint.Style.STROKE);

        for (int db = -12; db <= 12; db += 6) {
            float y = yForGain(db, top, bottom);
            canvas.drawLine(left, y, right, y, paint);
        }

        float[] gridFreq = {20f, 50f, 100f, 200f, 500f, 1000f, 2000f, 5000f, 10000f, 20000f};
        for (float f : gridFreq) {
            float x = xForFreq(f, left, right);
            canvas.drawLine(x, top, x, bottom, paint);
        }

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(palette.muted);
        paint.setTextSize(11f * getResources().getDisplayMetrics().scaledDensity);
        paint.setTextAlign(Paint.Align.RIGHT);
        for (int db = -12; db <= 12; db += 6) {
            float y = yForGain(db, top, bottom);
            String label = db > 0 ? "+" + db : String.valueOf(db);
            canvas.drawText(label, left - 7f * density, y + 4f * density, paint);
        }

        paint.setTextAlign(Paint.Align.CENTER);
        for (float f : gridFreq) {
            float x = xForFreq(f, left, right);
            String label = f >= 1000f ? Math.round(f / 1000f) + "k" : String.valueOf(Math.round(f));
            canvas.drawText(label, x, h - 13f * density, paint);
        }
    }

    private void drawResponse(Canvas canvas, float left, float right, float top, float bottom) {
        int ch = state.selectedChannel;
        responsePath.reset();
        fillPath.reset();

        float zeroY = yForGain(0f, top, bottom);
        for (int i = 0; i < CURVE_SAMPLES; i++) {
            float t = i / (float) (CURVE_SAMPLES - 1);
            float x = left + t * (right - left);
            float freq = freqForX(x, left, right);
            float db = responseDbAt(ch, freq);
            float y = yForGain(db, top, bottom);
            if (i == 0) {
                responsePath.moveTo(x, y);
                fillPath.moveTo(x, zeroY);
                fillPath.lineTo(x, y);
            } else {
                responsePath.lineTo(x, y);
                fillPath.lineTo(x, y);
            }
        }
        fillPath.lineTo(right, zeroY);
        fillPath.close();

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withAlpha(palette.accent, 22));
        canvas.drawPath(fillPath, paint);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2.2f * density);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setColor(palette.accent);
        canvas.drawPath(responsePath, paint);
    }

    private void drawBandNodes(Canvas canvas, float left, float right, float top, float bottom) {
        int ch = state.selectedChannel;
        paint.setStyle(Paint.Style.FILL);
        for (int b = 0; b < DspUiState.BANDS; b++) {
            float f = state.freq[ch][b];
            float x = xForFreq(f, left, right);
            float y = yForGain(responseDbAt(ch, f), top, bottom);
            boolean selected = b == state.selectedBand;
            if (selected) {
                paint.setColor(palette.card);
                canvas.drawCircle(x, y, 9f * density, paint);
            }
            paint.setColor(palette.accent);
            canvas.drawCircle(x, y, (selected ? 6f : 4.2f) * density, paint);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        final float left = 44f * density;
        final float right = getWidth() - 14f * density;
        final float top = 18f * density;
        final float bottom = getHeight() - 38f * density;

        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                getParent().requestDisallowInterceptTouchEvent(true);
                state.selectedBand = nearestBand(event.getX(), left, right);
                dragging = true;
                updateSelectedBandFromTouch(event.getX(), event.getY(), left, right, top, bottom);
                state.saveFast();
                invalidate();
                return true;

            case MotionEvent.ACTION_MOVE:
                if (!dragging) return false;
                updateSelectedBandFromTouch(event.getX(), event.getY(), left, right, top, bottom);
                state.saveFast();
                invalidate();
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (dragging) {
                    dragging = false;
                    state.saveSync();
                    getParent().requestDisallowInterceptTouchEvent(false);
                    if (listener != null) listener.onBandSelected(state.selectedBand);
                    performClick();
                    invalidate();
                    return true;
                }
                break;
        }
        return super.onTouchEvent(event);
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    private int nearestBand(float touchX, float left, float right) {
        int ch = state.selectedChannel;
        int nearest = 0;
        float best = Float.MAX_VALUE;
        for (int b = 0; b < DspUiState.BANDS; b++) {
            float x = xForFreq(state.freq[ch][b], left, right);
            float d = Math.abs(touchX - x);
            if (d < best) {
                best = d;
                nearest = b;
            }
        }
        return nearest;
    }

    private void updateSelectedBandFromTouch(float x, float y, float left, float right, float top, float bottom) {
        int ch = state.selectedChannel;
        int band = state.selectedBand;
        float clampedX = Math.max(left, Math.min(right, x));
        float clampedY = Math.max(top, Math.min(bottom, y));
        state.freq[ch][band] = freqForX(clampedX, left, right);
        state.gain[ch][band] = gainForY(clampedY, top, bottom);
    }

    private float responseDbAt(int channel, float freq) {
        double totalDb = 0.0;
        for (int b = 0; b < DspUiState.BANDS; b++) {
            totalDb += peakingEqDb(freq,
                    state.freq[channel][b],
                    state.q[channel][b],
                    state.gain[channel][b]);
        }
        return DspUiState.clamp((float) totalDb, -12f, 12f);
    }

    private static double peakingEqDb(double freq, double center, double q, double gainDb) {
        if (Math.abs(gainDb) < 0.0001) return 0.0;

        double a = Math.pow(10.0, gainDb / 40.0);
        double w0 = 2.0 * Math.PI * Math.min(center, SAMPLE_RATE * 0.49) / SAMPLE_RATE;
        double alpha = Math.sin(w0) / (2.0 * Math.max(0.1, q));
        double cosW0 = Math.cos(w0);

        double b0 = 1.0 + alpha * a;
        double b1 = -2.0 * cosW0;
        double b2 = 1.0 - alpha * a;
        double a0 = 1.0 + alpha / a;
        double a1 = -2.0 * cosW0;
        double a2 = 1.0 - alpha / a;

        double w = 2.0 * Math.PI * Math.min(freq, SAMPLE_RATE * 0.49) / SAMPLE_RATE;
        double cosW = Math.cos(w);
        double sinW = Math.sin(w);
        double cos2W = Math.cos(2.0 * w);
        double sin2W = Math.sin(2.0 * w);

        double numRe = b0 + b1 * cosW + b2 * cos2W;
        double numIm = -b1 * sinW - b2 * sin2W;
        double denRe = a0 + a1 * cosW + a2 * cos2W;
        double denIm = -a1 * sinW - a2 * sin2W;

        double num = numRe * numRe + numIm * numIm;
        double den = denRe * denRe + denIm * denIm;
        if (num <= 0.0 || den <= 0.0) return 0.0;
        return 10.0 * Math.log10(num / den);
    }

    private float xForFreq(float f, float left, float right) {
        double min = Math.log10(20.0);
        double max = Math.log10(20000.0);
        double t = (Math.log10(Math.max(20f, Math.min(20000f, f))) - min) / (max - min);
        return left + (float) t * (right - left);
    }

    private float freqForX(float x, float left, float right) {
        float t = DspUiState.clamp((x - left) / Math.max(1f, right - left), 0f, 1f);
        double min = Math.log10(20.0);
        double max = Math.log10(20000.0);
        return (float) Math.pow(10.0, min + t * (max - min));
    }

    private float yForGain(float gain, float top, float bottom) {
        float g = DspUiState.clamp(gain, -12f, 12f);
        float t = (12f - g) / 24f;
        return top + t * (bottom - top);
    }

    private float gainForY(float y, float top, float bottom) {
        float t = DspUiState.clamp((y - top) / Math.max(1f, bottom - top), 0f, 1f);
        return 12f - t * 24f;
    }

    private static int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | ((alpha & 0xFF) << 24);
    }
}
