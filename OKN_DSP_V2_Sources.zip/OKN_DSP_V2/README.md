# OKN DSP V2 — Phase 1 Hardening

V2 is an in-place upgrade of V1. It keeps the same Android application ID and signing key so the APK can update the installed V1 build while preserving user data.

## V2 changes
- Locks Canvas and dialog typography to Android's bundled Roboto files when available; no font file is shipped in Sources.
- Migrates V1 SharedPreferences (`okn_dsp_v1_state`) into the stable V2 state store (`okn_dsp_state`).
- Keeps real-time `apply()` writes while sliders move and performs synchronous durability checkpoints on gesture completion and Activity lifecycle transitions.
- Persists theme, page, selected channel/band, Master Volume, Bass Volume, Bass Cutoff, all seven channel levels, 15-band Frequency/Q/Gain values for all seven channels, and preset data.
- Keeps the responsive centered layout used by V1 for phones and tablets.
- Phase 2 DSP transport remains intentionally unimplemented until the real protocol/control data is supplied.

Build input: `OKN_DSP_V2_Sources.zip` using `OKN_DSP_AutoBuild.yml`.
