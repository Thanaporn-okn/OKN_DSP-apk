#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

tmp_dir="$(mktemp -d)"
trap 'rm -rf "$tmp_dir"' EXIT

flutter create \
  --platforms=android,ios \
  --org com.okn \
  --project-name okn_dsp \
  "$tmp_dir/okn_dsp"

rm -rf android ios
cp -R "$tmp_dir/okn_dsp/android" ./android
cp -R "$tmp_dir/okn_dsp/ios" ./ios
python3 tool/patch_platforms.py
flutter pub get
