from pathlib import Path
import plistlib

root = Path(__file__).resolve().parents[1]
manifest = root / 'android/app/src/main/AndroidManifest.xml'
if manifest.exists():
    text = manifest.read_text(encoding='utf-8')
    permissions = '''\n    <uses-feature android:name="android.hardware.bluetooth_le" android:required="false" />\n    <uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30" />\n    <uses-permission android:name="android.permission.BLUETOOTH_ADMIN" android:maxSdkVersion="30" />\n    <uses-permission android:name="android.permission.BLUETOOTH_SCAN" android:usesPermissionFlags="neverForLocation" />\n    <uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />\n    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" android:maxSdkVersion="30" />\n    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" android:maxSdkVersion="30" />\n'''
    marker = '<application'
    if 'android.permission.BLUETOOTH_SCAN' not in text:
        text = text.replace(marker, permissions + '    ' + marker, 1)
    text = text.replace('android:label="okn_dsp"', 'android:label="OKN_DSP"')
    manifest.write_text(text, encoding='utf-8')

plist = root / 'ios/Runner/Info.plist'
if plist.exists():
    with plist.open('rb') as fh:
        data = plistlib.load(fh)
    data['CFBundleDisplayName'] = 'OKN_DSP'
    data['NSBluetoothAlwaysUsageDescription'] = 'OKN_DSP uses Bluetooth to connect to and control your DSP audio processor.'
    data['NSBluetoothPeripheralUsageDescription'] = 'OKN_DSP uses Bluetooth to communicate with your DSP audio processor.'
    with plist.open('wb') as fh:
        plistlib.dump(data, fh, sort_keys=False)
