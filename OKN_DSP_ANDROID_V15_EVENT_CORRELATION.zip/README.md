# OKN DSP Android V15 — Event Correlation

V15 is a passive BLE research build for the OKN DSP device.

## Safety / protocol scope
- WRITE is disabled.
- The app only performs BLE discovery, reads, CCCD notification subscription, capture and offline analysis.
- No DSP control command is generated or transmitted by this app.

## V15 controlled-event method
1. Connect to the DSP.
2. Start a 5-second idle baseline.
3. Press MARK CONTROLLED EVENT.
4. Immediately change exactly ONE parameter using the original controller.
5. V15 automatically captures the next 10 seconds as EVENT.
6. Analyze the capture and compare baseline vs event.

The analysis reports packet counts, length distributions, timing, payload reuse,
byte-position stability, and notification sources. These are observations only;
no field meaning or protocol framing is assumed.
