package com.okn.dsp.protocol

import kotlin.math.abs

/**
 * V46 single-band proof policy.
 * Only CH1 / actuator ID4 / Band4 is allowed. The target always lowers PEAKING
 * boost by 0.5 dB, then the exact original 48-byte record is restored.
 */
object ControlledEqBandProof {
    const val ACTUATOR_ID = 4
    const val BAND_INDEX_1 = 4
    const val OFFSET = (BAND_INDEX_1 - 1) * EqBandCodec.BYTES
    const val STEP_DOWN_DB = 0.5f
    const val MIN_SAFE_BOOST_DB = -12.0f
    const val MAX_SAFE_BOOST_DB = 12.0f
    const val FIELD_TOL = 0.0025f

    fun validateBaseline(v: EqBand48): String? {
        if (v.type != EqBandCodec.PEAKING_TYPE) return "band type must be PEAKING(12), actual=${v.type}"
        if (!v.frequency.isFinite() || v.frequency !in 20f..20000f) return "frequency out of safe range: ${v.frequency}"
        if (!v.q.isFinite() || v.q !in 0.10f..20f) return "Q out of safe range: ${v.q}"
        if (!v.boostDb.isFinite() || v.boostDb !in MIN_SAFE_BOOST_DB..MAX_SAFE_BOOST_DB) return "boost outside proof range: ${v.boostDb}"
        if (abs(v.frequency2) > 0.001f) return "F2 must be 0 for PEAKING proof: ${v.frequency2}"
        if (abs(v.gain) > 0.001f) return "G must be 0 for PEAKING proof: ${v.gain}"
        if (abs(v.r) > 0.001f) return "R must be 0 for PEAKING proof: ${v.r}"
        if (v.boostDb - STEP_DOWN_DB < MIN_SAFE_BOOST_DB) return "cannot safely lower by ${STEP_DOWN_DB}dB"
        return null
    }

    fun targetFrom(original: EqBand48): EqBand48 {
        require(validateBaseline(original) == null)
        return EqBandCodec.peaking(
            original.frequency.toDouble(),
            original.q.toDouble(),
            (original.boostDb - STEP_DOWN_DB).toDouble(),
        )
    }

    fun encodeWrite(v: EqBand48): ByteArray =
        UfeCodec.encodeWrite(ACTUATOR_ID, OFFSET, EqBandCodec.encode(v))

    fun matches(actual: EqBand48, expected: EqBand48): Boolean =
        actual.type == expected.type &&
            abs(actual.frequency - expected.frequency) <= FIELD_TOL &&
            abs(actual.frequency2 - expected.frequency2) <= FIELD_TOL &&
            abs(actual.q - expected.q) <= FIELD_TOL &&
            abs(actual.boostDb - expected.boostDb) <= FIELD_TOL &&
            abs(actual.gain - expected.gain) <= FIELD_TOL &&
            abs(actual.r - expected.r) <= FIELD_TOL &&
            abs(actual.b0 - expected.b0) <= FIELD_TOL &&
            abs(actual.b1 - expected.b1) <= FIELD_TOL &&
            abs(actual.b2 - expected.b2) <= FIELD_TOL &&
            abs(actual.a1 - expected.a1) <= FIELD_TOL &&
            abs(actual.a2 - expected.a2) <= FIELD_TOL
}
