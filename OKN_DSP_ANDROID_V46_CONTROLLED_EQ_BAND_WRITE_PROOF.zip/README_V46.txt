OKN DSP V46 — CONTROLLED EQ BAND WRITE PROOF

Purpose
- V45 proved a real user-initiated scalar write on MasterVolume ID2 and live descriptor verification.
- V46 performs the first constrained runtime proof for the 48-byte EQ actuator serializer.

Proof scope ONLY
- Channel: CH1
- Actuator: ID4 (BiquadCascadeLeftChannel / type 4084)
- Band: 4
- Offset: 144 = (4-1)*48
- Record: 48 bytes = INT32 LE type + 11 x FLOAT32 LE
- Allowed baseline type: PEAKING / type 12
- Target: original Boost B minus 0.5 dB (never increases)
- Verify: full live Device Description refresh
- Restore: exact original 48-byte band record, then another Device Description refresh
- SaveParams ID7: NEVER SENT

User flow
1) Open "V46 CONTROLLED EQ BAND WRITE PROOF".
2) SCAN DSP and connect LE-GoloPine_DSP_A.
3) START V46 EQ PROOF SESSION and wait for V46 EQ BASELINE READY.
4) RUN CONTROLLED CH1 BAND4 PROOF (-0.5 dB -> RESTORE) once.
5) Wait for V46 COMPLETE.
6) SAVE V46 CAPTURE TO DOWNLOADS and send the TXT capture for review.

Normal EQ 7CH page remains LOCAL ONLY. Scalar V45 controls remain available because their live write path is already verified. Generic writes, SaveParams, preset, delay and unknown actuator writes remain locked.
