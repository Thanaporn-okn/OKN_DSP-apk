#!/usr/bin/env python3
from pathlib import Path
root = Path(__file__).resolve().parents[1]
text = "\n".join(p.read_text(errors="ignore") for p in (root / "firmware").rglob("*.[ch]"))
for forbidden in ("biquad", "peq", "eq_gain", "equalizer"):
    if forbidden.lower() in text.lower():
        raise SystemExit(f"FAIL: TRUE7CH gain implementation contains forbidden EQ-based token: {forbidden}")
print("PASS: TRUE7CH gain remains PCM multiplier based; no EQ-gain substitution token found.")
