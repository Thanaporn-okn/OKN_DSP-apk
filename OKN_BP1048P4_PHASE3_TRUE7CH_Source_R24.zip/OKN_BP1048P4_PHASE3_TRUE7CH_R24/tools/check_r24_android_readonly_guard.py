#!/usr/bin/env python3
from pathlib import Path
import re
root = Path(__file__).resolve().parents[1]
app = root / "android-bt-probe"
java_files = list((app / "app/src/main/java").rglob("*.java"))
if not java_files:
    raise SystemExit("FAIL: Android Java source missing")
java = "\n".join(p.read_text(errors="ignore") for p in java_files)
manifest = (app / "app/src/main/AndroidManifest.xml").read_text(errors="ignore")
gradle = (app / "app/build.gradle").read_text(errors="ignore")

forbidden = {
    "USB API": r"android\.hardware\.usb|\bUsbManager\b|\bUsbDevice\b|controlTransfer\s*\(|bulkTransfer\s*\(",
    "RFCOMM/socket client": r"\bBluetoothSocket\b|createRfcommSocket|createInsecureRfcommSocket|listenUsingRfcomm",
    "output stream": r"getOutputStream\s*\(|FileOutputStream|openOutputStream",
    "GATT characteristic write": r"writeCharacteristic\s*\(",
    "GATT descriptor write": r"writeDescriptor\s*\(",
    "OBEX client/session": r"javax\.obex|\bClientSession\b|\bHeaderSet\b|\bClientOperation\b",
    "firmware picker/file send": r"ACTION_OPEN_DOCUMENT|ACTION_GET_CONTENT|ContentResolver.*openInputStream|\.mva",
    "network permission": r"android\.permission\.INTERNET",
}
for name, pattern in forbidden.items():
    target = manifest if name == "network permission" else java
    if re.search(pattern, target, flags=re.I | re.S):
        raise SystemExit(f"FAIL: R24 read-only guard found forbidden {name}")

required = [
    "fetchUuidsWithSdp()",
    "discoverServices()",
    "UUID_OPP_OBJECT_PUSH",
    "UUID_UFE_AB00",
    "BluetoothLeScanner",
]
for token in required:
    if token not in java:
        raise SystemExit(f"FAIL: required R24 capability token missing: {token}")
if "compileSdk 36" not in gradle or "targetSdk 36" not in gradle or "versionCode 24" not in gradle:
    raise SystemExit("FAIL: R24 Android SDK/version gate mismatch")
if "android.hardware.usb.host" in manifest:
    raise SystemExit("FAIL: USB host feature must not be present in R24")
print("PASS: R24 Android probe is capability-only: no USB, no socket/OBEX transfer, no GATT write, no firmware-file path.")
