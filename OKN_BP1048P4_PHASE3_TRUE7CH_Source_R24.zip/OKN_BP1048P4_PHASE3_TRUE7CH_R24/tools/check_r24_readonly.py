#!/usr/bin/env python3
from pathlib import Path
import json
import sys

root = Path(__file__).resolve().parents[1]
java = root / "android-bt-probe/app/src/main/java/com/okn/dsp/btprobe/MainActivity.java"
manifest = root / "android-bt-probe/app/src/main/AndroidManifest.xml"
state = root / "config/R24_BT_OTA_CAPABILITY_STATE.json"

for p in (java, manifest, state):
    if not p.is_file():
        raise SystemExit(f"missing required R24 file: {p}")

src = java.read_text(encoding="utf-8")
man = manifest.read_text(encoding="utf-8")
obj = json.loads(state.read_text(encoding="utf-8"))

forbidden_java = [
    "android.hardware.usb",
    "UsbManager",
    "UsbDevice",
    "controlTransfer(",
    "bulkTransfer(",
    "import android.bluetooth.BluetoothSocket;",
    "createRfcommSocket",
    "listenUsingRfcomm",
    "getOutputStream(",
    "writeCharacteristic(",
    "readCharacteristic(",
    "setCharacteristicNotification(",
    "beginReliableWrite(",
    "executeReliableWrite(",
    "ACTION_OPEN_DOCUMENT",
    "java.io.File",
    "openInputStream(",
]
for token in forbidden_java:
    if token in src:
        raise SystemExit(f"R24 FAIL: forbidden active API/token found in Java: {token}")

required_java = [
    "fetchUuidsWithSdp()",
    "startDiscovery()",
    "startScan(scanCallback)",
    "connectGatt(",
    "discoverServices()",
    "0000%04x-0000-1000-8000-00805f9b34fb",
    "UUID_OBJECT_PUSH",
    "UUID_UFE_SERVICE_AB00",
]
for token in required_java:
    if token not in src:
        raise SystemExit(f"R24 FAIL: required read-only capability code missing: {token}")

if "android.hardware.usb.host" in man:
    raise SystemExit("R24 FAIL: USB host feature must not be present")
if "BLUETOOTH_ADVERTISE" in man:
    raise SystemExit("R24 FAIL: advertising permission is unnecessary and forbidden")
for perm in ("BLUETOOTH_SCAN", "BLUETOOTH_CONNECT"):
    if perm not in man:
        raise SystemExit(f"R24 FAIL: manifest missing {perm}")

if obj.get("revision") != "R24" or obj.get("mode") != "READ_ONLY_CAPABILITY_PROBE":
    raise SystemExit("R24 FAIL: state file revision/mode mismatch")

for op in ("rfcomm_socket", "obex_put", "mva_send", "erase", "program", "commit"):
    if op not in obj.get("forbidden_operations", []):
        raise SystemExit(f"R24 FAIL: state file missing forbidden op {op}")

print("R24 read-only guard: PASS")
print("- no USB API")
print("- no RFCOMM/OBEX transport socket")
print("- no file/.mva send path")
print("- no GATT value read/write/subscribe")
print("- SDP + BLE service discovery paths present")
