#!/usr/bin/env python3
from pathlib import Path
import json
root = Path(__file__).resolve().parents[1]
state = json.loads((root / "config/R24_BLUETOOTH_OTA_CAPABILITY_STATE.json").read_text())
assert state["revision"] == "R24"
assert state["mode"] == "READ_ONLY_CAPABILITY_DISCOVERY"
assert state["sdk_evidence"]["BT_OBEX_SUPPORT_default"] == "DISABLE"
assert state["sdk_evidence"]["classic_opp_service_uuid16"] == "0x1105"
assert state["sdk_evidence"]["ble_ufe_service_uuid16"] == "0xAB00"
print("PASS: R24 reverse state encodes OBEX gate + OPP 0x1105 + BLE AB00 evidence without claiming stock OTA is enabled.")
