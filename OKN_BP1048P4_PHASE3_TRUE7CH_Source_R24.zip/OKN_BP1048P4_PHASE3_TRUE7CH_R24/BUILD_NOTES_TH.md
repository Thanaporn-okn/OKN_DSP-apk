# R24 Build Notes

- Android compileSdk/targetSdk: 36 (Android 16)
- Android Gradle Plugin: 8.10.1
- Gradle in GitHub Actions: 8.11.1
- JDK: 17
- No external Android libraries; app uses platform Bluetooth APIs only.
- GitHub-hosted runner workflow first reuses preinstalled Android SDK 36 when available; sdkmanager is only used if platform 36 is missing.
- Host test gate includes R24 static read-only guard before APK build.
