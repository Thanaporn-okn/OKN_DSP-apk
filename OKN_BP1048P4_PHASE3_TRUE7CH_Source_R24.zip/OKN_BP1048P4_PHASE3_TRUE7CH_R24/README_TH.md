# OKN BP1048P4 / GoloPine TRUE7CH — R24

R24 ทำต่อจากผล R23 โดยเปลี่ยนเส้นทางทดลองเป็น **Samsung S25+ Bluetooth / OTA Capability Probe แบบ READ-ONLY** เท่านั้น

เป้าหมายของ R24 คือพิสูจน์ว่า stock GoloPine firmware “เปิดให้เห็น” Bluetooth capability ที่สอดคล้องกับเส้นทาง OTA ใน SDK หรือไม่ โดยไม่ส่ง firmware และไม่เขียนข้อมูลใด ๆ ไปยังบอร์ด

## สิ่งที่ R24 ทำ
- สแกน BLE advertisement และแสดง advertised service UUIDs
- ค้นอุปกรณ์ Bluetooth Classic และแสดง device class / bond state / cached UUIDs
- ใช้ Android public API `fetchUuidsWithSdp()` เพื่อขอ Classic SDP UUID list
- ตรวจสัญญาณ Object Push Profile UUID `0x1105`
- เชื่อม BLE แบบ metadata-only เพื่อ `discoverServices()` แล้วแสดง GATT service / characteristic UUID + properties
- ตรวจ AB00/AB01/AB02/AB03 ในฐานะ BLE/UFE signal เท่านั้น

## สิ่งที่ R24 ไม่มีโดยตั้งใจ
- ไม่มี USB probe หรือ USB SET_REPORT
- ไม่มี AA / 0x55 / ACP 0x00 / ACP 0x11
- ไม่มี OBEX client และไม่มี RFCOMM socket
- ไม่มี file picker / firmware file transfer
- ไม่มี GATT characteristic write / descriptor write
- ไม่มี erase / program / commit / BankB apply / reset

อ่าน `docs/R24_SDK_REVERSE_OBEX_OTA_TH.md` และ `docs/R24_ANDROID_READONLY_PROBE_TH.md` ก่อนใช้งาน
