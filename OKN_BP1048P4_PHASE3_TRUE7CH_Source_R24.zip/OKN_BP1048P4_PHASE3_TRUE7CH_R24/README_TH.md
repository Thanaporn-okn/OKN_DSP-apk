# OKN BP1048P4 / GoloPine TRUE7CH — R24

R24 ทำต่อจาก R23 โดยหยุดเส้นทาง USB boot-entry ที่ทดลองครบแล้ว และเปลี่ยนไปตรวจ **Bluetooth / OTA capability แบบ READ-ONLY บน Samsung S25+** ตามหลักฐานจาก SDK ที่ผู้ใช้อัปโหลด.

อ่าน `docs/R24_OBEX_REVERSE_TH.md` ก่อนใช้งาน.

## สิ่งที่ R24 ทำ

- Classic Bluetooth discovery
- แสดง paired devices / cached UUIDs
- Classic SDP UUID discovery ด้วย `fetchUuidsWithSdp()`
- BLE scan และ advertised service UUIDs
- BLE GATT service/characteristic/descriptor UUID discovery เท่านั้น
- highlight `0x1105` Object Push/OPP และ known BLE UFE `AB00`
- สรุป capability โดยไม่ overclaim ว่า MVA OTA เปิดจริง

## สิ่งที่ R24 ไม่ทำ

ไม่มี USB probing, ไม่มี AA/0x55/ACP, ไม่มี RFCOMM socket, ไม่มี OBEX PUT, ไม่มี `.mva`, ไม่มี file picker, ไม่มี GATT value read/write, ไม่มี erase/program/commit/apply/reset.

## ใช้บนมือถือผ่าน GitHub Actions

1. อัปโหลด `OKN_BP1048P4_PHASE3_TRUE7CH_Source_R24.zip` ไปที่ repo.
2. วาง workflow `OKN_BP1048P4_R24_ANDROID.yml` ใน `.github/workflows/`.
3. เปิดแท็บ Actions จาก GitHub บนมือถือ แล้ว Run workflow.
4. เมื่อ job สำเร็จ ดาวน์โหลด artifact `OKN_BT_OTA_Capability_R24` ซึ่งมี debug APK.

Workflow รองรับทั้งกรณีแตก source tree ไว้ใน repo และกรณีอัปโหลด source ZIP อย่างเดียว.
