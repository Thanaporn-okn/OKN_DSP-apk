package com.okn.dsp.btprobe;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothClass;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * R24 is intentionally capability-only.
 *
 * Allowed: BLE advertisements, Classic discovery, cached UUIDs, public SDP UUID lookup,
 * and BLE GATT service metadata discovery.
 *
 * Deliberately absent: USB APIs, Bluetooth sockets, OBEX client operations, file transfer,
 * characteristic/descriptor writes, and every flash erase/program/apply operation.
 */
public final class MainActivity extends Activity {
    private static final int REQ_BT_PERMS = 2401;
    private static final long SCAN_MS = 15_000L;
    private static final long GATT_TIMEOUT_MS = 12_000L;

    // Standard Bluetooth Object Push Profile service UUID recovered from SDK obex_sdp.o.
    private static final UUID UUID_OPP_OBJECT_PUSH =
            UUID.fromString("00001105-0000-1000-8000-00805f9b34fb");

    // MVSilicon/UFE BLE surface seen in the supplied SDK. This is NOT itself OTA evidence.
    private static final UUID UUID_UFE_AB00 = uuid16(0xAB00);
    private static final UUID UUID_UFE_AB01 = uuid16(0xAB01);
    private static final UUID UUID_UFE_AB02 = uuid16(0xAB02);
    private static final UUID UUID_UFE_AB03 = uuid16(0xAB03);

    private final Handler main = new Handler(Looper.getMainLooper());
    private final Map<String, BluetoothDevice> devices = new LinkedHashMap<>();
    private final Map<String, String> labels = new LinkedHashMap<>();
    private final List<String> visibleKeys = new ArrayList<>();

    private BluetoothAdapter adapter;
    private BluetoothLeScanner leScanner;
    private ScanCallback leCallback;
    private boolean leScanning;
    private BluetoothDevice selected;
    private BluetoothGatt activeGatt;

    private TextView selectedView;
    private TextView logView;
    private ArrayAdapter<String> deviceListAdapter;
    private ListView deviceList;

    private final BroadcastReceiver btReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                BluetoothDevice d = getBtDevice(intent);
                if (d != null) {
                    addOrUpdateDevice(d, "Classic discovery", null);
                    add("CLASSIC FOUND: " + describeDevice(d));
                }
                return;
            }
            if (BluetoothAdapter.ACTION_DISCOVERY_STARTED.equals(action)) {
                add("Classic discovery: STARTED");
                return;
            }
            if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
                add("Classic discovery: FINISHED");
                return;
            }
            if (BluetoothDevice.ACTION_UUID.equals(action)) {
                BluetoothDevice d = getBtDevice(intent);
                ParcelableUuidResult result = parseUuidIntent(intent);
                add("=== CLASSIC SDP UUID RESULT ===");
                add("Device: " + (d == null ? "<unknown>" : describeDevice(d)));
                if (result.uuids.isEmpty()) {
                    add("SDP UUIDs: <none returned>");
                    add("RESULT: OPP/OBEX Object Push UUID 0x1105 NOT OBSERVED via this Android SDP result.");
                    add("NOTE: not-observed is not proof of absolute absence.");
                } else {
                    boolean opp = false;
                    for (UUID u : result.uuids) {
                        add("  SDP UUID: " + u + labelUuid(u));
                        if (UUID_OPP_OBJECT_PUSH.equals(u)) opp = true;
                    }
                    if (opp) {
                        add("CAPABILITY SIGNAL: OPP/OBEX Object Push UUID 0x1105 PRESENT.");
                        add("STOP CONDITION REACHED: discovery only; no transfer is implemented in R24.");
                    } else {
                        add("RESULT: OPP/OBEX Object Push UUID 0x1105 NOT OBSERVED in returned UUID list.");
                        add("NOTE: not-observed is not proof of absolute absence.");
                    }
                }
                if (result.rawCount == 0) add("Android EXTRA_UUID array count=0");
            }
        }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        BluetoothManager manager = (BluetoothManager) getSystemService(BLUETOOTH_SERVICE);
        adapter = manager == null ? null : manager.getAdapter();
        buildUi();
        registerBtReceiver();
        add("=== OKN R24 READ-ONLY BLUETOOTH/OTA CAPABILITY PROBE ===");
        add("Device: " + Build.MANUFACTURER + " " + Build.MODEL + " / Android API " + Build.VERSION.SDK_INT);
        add("Build: " + BuildConfig.VERSION_NAME);
        add("Safety: no USB path, no socket/OBEX transfer, no GATT writes, no flash operations.");
        showBluetoothStatus();
    }

    @Override protected void onDestroy() {
        stopBleScan();
        stopClassicDiscovery();
        closeGatt("activity destroy");
        try { unregisterReceiver(btReceiver); } catch (Exception ignored) {}
        super.onDestroy();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_BT_PERMS) {
            boolean ok = true;
            for (int r : grantResults) if (r != PackageManager.PERMISSION_GRANTED) ok = false;
            add("Bluetooth permission result: " + (ok ? "GRANTED" : "DENIED/PARTIAL"));
            showBluetoothStatus();
        }
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(20, 20, 20, 20);

        TextView title = new TextView(this);
        title.setText("OKN BT/OTA Capability Probe R24\nSamsung S25+ → GoloPine BP1048P4\nREAD-ONLY discovery; STOP before any transfer");
        title.setTextSize(18f);
        root.addView(title);

        Button p = button("1) PERMISSIONS / BT STATUS", v -> permissionAndStatus());
        Button bonded = button("2) LOAD BONDED / CACHED DEVICES", v -> loadBonded());
        Button ble = button("3) BLE SCAN 15s", v -> startBleScan());
        Button classic = button("4) CLASSIC DISCOVERY 15s", v -> startClassicDiscovery());
        root.addView(p); root.addView(bonded); root.addView(ble); root.addView(classic);

        selectedView = new TextView(this);
        selectedView.setText("SELECTED: <none>");
        selectedView.setTextIsSelectable(true);
        root.addView(selectedView);

        deviceList = new ListView(this);
        deviceListAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<>());
        deviceList.setAdapter(deviceListAdapter);
        deviceList.setOnItemClickListener((parent, view, position, id) -> selectAt(position));
        root.addView(deviceList, new LinearLayout.LayoutParams(-1, dp(190)));

        Button sdp = button("5) CLASSIC SDP UUIDs — SELECTED", v -> fetchClassicSdp());
        Button gatt = button("6) BLE GATT METADATA — SELECTED", v -> discoverGattMetadata());
        Button copy = button("7) COPY WHOLE LOG", v -> copyLog());
        Button clear = button("CLEAR LOG", v -> logView.setText(""));
        root.addView(sdp); root.addView(gatt); root.addView(copy); root.addView(clear);

        logView = new TextView(this);
        logView.setTextIsSelectable(true);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(logView);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
    }

    private Button button(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setOnClickListener(listener);
        return b;
    }

    private int dp(int n) {
        return (int) (n * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void registerBtReceiver() {
        IntentFilter f = new IntentFilter();
        f.addAction(BluetoothDevice.ACTION_FOUND);
        f.addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED);
        f.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        f.addAction(BluetoothDevice.ACTION_UUID);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(btReceiver, f, RECEIVER_EXPORTED);
        else registerReceiver(btReceiver, f);
    }

    private void permissionAndStatus() {
        if (!ensurePermissions(true)) return;
        if (adapter == null) {
            add("Bluetooth adapter: unavailable");
            return;
        }
        if (!adapter.isEnabled()) {
            add("Bluetooth is OFF; opening Android Bluetooth enable prompt.");
            try { startActivity(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)); }
            catch (Exception e) { add("Cannot open Bluetooth prompt: " + e); }
        } else {
            showBluetoothStatus();
        }
    }

    private boolean ensurePermissions(boolean request) {
        List<String> need = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 31) {
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED)
                need.add(Manifest.permission.BLUETOOTH_SCAN);
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED)
                need.add(Manifest.permission.BLUETOOTH_CONNECT);
        } else {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
                need.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if (need.isEmpty()) return true;
        add("Missing runtime permissions: " + need);
        if (request) requestPermissions(need.toArray(new String[0]), REQ_BT_PERMS);
        return false;
    }

    private void showBluetoothStatus() {
        if (!ensurePermissions(false)) {
            add("Bluetooth status: permissions required; press button 1.");
            return;
        }
        if (adapter == null) {
            add("Bluetooth adapter: <none>");
            return;
        }
        try {
            add("Bluetooth adapter enabled=" + adapter.isEnabled() + " name=" + safe(adapter.getName()) +
                    " state=" + adapter.getState() + " scanMode=" + adapter.getScanMode());
        } catch (SecurityException e) {
            add("Bluetooth status SecurityException: " + e.getMessage());
        }
    }

    private void loadBonded() {
        if (!ready()) return;
        try {
            Set<BluetoothDevice> bonded = adapter.getBondedDevices();
            add("=== BONDED/CACHED DEVICES: " + bonded.size() + " ===");
            for (BluetoothDevice d : bonded) {
                addOrUpdateDevice(d, "Bonded", null);
                add("BONDED: " + describeDevice(d));
                logCachedUuids(d);
            }
        } catch (SecurityException e) {
            add("Bonded devices SecurityException: " + e.getMessage());
        }
    }

    private void startBleScan() {
        if (!ready()) return;
        stopClassicDiscovery();
        stopBleScan();
        try {
            leScanner = adapter.getBluetoothLeScanner();
            if (leScanner == null) {
                add("BLE scanner unavailable.");
                return;
            }
            leCallback = new ScanCallback() {
                @Override public void onScanResult(int callbackType, ScanResult result) {
                    if (result == null || result.getDevice() == null) return;
                    List<ParcelUuid> advUuids = result.getScanRecord() == null ? null : result.getScanRecord().getServiceUuids();
                    String extra = "BLE rssi=" + result.getRssi() + " adv=" + uuidList(advUuids);
                    addOrUpdateDevice(result.getDevice(), extra, advUuids);
                }

                @Override public void onBatchScanResults(List<ScanResult> results) {
                    if (results == null) return;
                    for (ScanResult r : results) onScanResult(0, r);
                }

                @Override public void onScanFailed(int errorCode) {
                    leScanning = false;
                    add("BLE scan failed: code=" + errorCode);
                }
            };
            ScanSettings settings = new ScanSettings.Builder()
                    .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                    .build();
            leScanner.startScan(null, settings, leCallback);
            leScanning = true;
            add("BLE scan: STARTED for 15 seconds (advertisement metadata only)");
            main.postDelayed(() -> {
                stopBleScan();
                add("BLE scan: STOPPED after timeout");
            }, SCAN_MS);
        } catch (SecurityException e) {
            add("BLE scan SecurityException: " + e.getMessage());
        }
    }

    private void stopBleScan() {
        if (!leScanning || leScanner == null || leCallback == null) return;
        try { leScanner.stopScan(leCallback); } catch (Exception ignored) {}
        leScanning = false;
    }

    private void startClassicDiscovery() {
        if (!ready()) return;
        stopBleScan();
        stopClassicDiscovery();
        try {
            boolean ok = adapter.startDiscovery();
            add("Classic discovery request=" + ok + " (15 seconds, no connection opened)");
            main.postDelayed(() -> {
                stopClassicDiscovery();
                add("Classic discovery: timeout/cancel issued");
            }, SCAN_MS);
        } catch (SecurityException e) {
            add("Classic discovery SecurityException: " + e.getMessage());
        }
    }

    private void stopClassicDiscovery() {
        if (adapter == null) return;
        try { if (adapter.isDiscovering()) adapter.cancelDiscovery(); } catch (Exception ignored) {}
    }

    private boolean ready() {
        if (!ensurePermissions(true)) return false;
        if (adapter == null) {
            add("Bluetooth adapter unavailable.");
            return false;
        }
        if (!adapter.isEnabled()) {
            add("Bluetooth OFF. Press button 1 and enable Bluetooth.");
            return false;
        }
        return true;
    }

    private void addOrUpdateDevice(BluetoothDevice d, String source, List<ParcelUuid> advUuids) {
        if (d == null || !ensurePermissions(false)) return;
        String key = deviceKey(d);
        devices.put(key, d);
        String label = describeDevice(d) + "\n  via=" + source;
        if (advUuids != null && !advUuids.isEmpty()) {
            label += "\n  advertised=" + uuidList(advUuids);
            for (ParcelUuid pu : advUuids) {
                if (pu != null && UUID_UFE_AB00.equals(pu.getUuid()))
                    add("BLE CAPABILITY SIGNAL: advertised AB00 present on " + safeAddress(d) + " (UFE/BLE; NOT OTA proof)");
            }
        }
        labels.put(key, label);
        refreshList();
    }

    private void refreshList() {
        main.post(() -> {
            visibleKeys.clear();
            visibleKeys.addAll(devices.keySet());
            deviceListAdapter.clear();
            for (String key : visibleKeys) deviceListAdapter.add(labels.get(key));
            deviceListAdapter.notifyDataSetChanged();
        });
    }

    private void selectAt(int position) {
        if (position < 0 || position >= visibleKeys.size()) return;
        String key = visibleKeys.get(position);
        selected = devices.get(key);
        selectedView.setText("SELECTED: " + (selected == null ? "<none>" : describeDevice(selected)));
        if (selected != null) {
            add("SELECTED: " + describeDevice(selected));
            logCachedUuids(selected);
        }
    }

    private void fetchClassicSdp() {
        if (!ready()) return;
        if (selected == null) {
            add("Select a device first.");
            return;
        }
        stopBleScan();
        stopClassicDiscovery();
        try {
            add("=== REQUEST CLASSIC SDP UUIDs ===");
            add("Target: " + describeDevice(selected));
            logCachedUuids(selected);
            boolean started = selected.fetchUuidsWithSdp();
            add("fetchUuidsWithSdp() started=" + started);
            add("Waiting for Android ACTION_UUID broadcast. No socket and no OBEX session is opened.");
        } catch (SecurityException e) {
            add("SDP SecurityException: " + e.getMessage());
        } catch (Exception e) {
            add("SDP request error: " + e);
        }
    }

    private void discoverGattMetadata() {
        if (!ready()) return;
        if (selected == null) {
            add("Select a BLE device first.");
            return;
        }
        stopBleScan();
        stopClassicDiscovery();
        closeGatt("new GATT probe");
        add("=== BLE GATT METADATA DISCOVERY ===");
        add("Target: " + describeDevice(selected));
        add("Mode: connect → discover service metadata → disconnect. No characteristic/descriptor values are written.");
        try {
            BluetoothGattCallback cb = new BluetoothGattCallback() {
                @Override public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
                    ui("GATT state: status=" + status + " newState=" + profileState(newState));
                    if (status == BluetoothGatt.GATT_SUCCESS && newState == BluetoothProfile.STATE_CONNECTED) {
                        try {
                            boolean started = gatt.discoverServices();
                            ui("discoverServices() started=" + started);
                            if (!started) closeSpecificGatt(gatt, "discoverServices refused");
                        } catch (SecurityException e) {
                            ui("GATT discover SecurityException: " + e.getMessage());
                            closeSpecificGatt(gatt, "security exception");
                        }
                    } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                        closeSpecificGatt(gatt, "disconnected");
                    }
                }

                @Override public void onServicesDiscovered(BluetoothGatt gatt, int status) {
                    ui("onServicesDiscovered status=" + status);
                    if (status == BluetoothGatt.GATT_SUCCESS) dumpGattMetadata(gatt);
                    else ui("GATT metadata discovery failed; no data operation attempted.");
                    try { gatt.disconnect(); } catch (Exception ignored) {}
                    main.postDelayed(() -> closeSpecificGatt(gatt, "metadata complete"), 500L);
                }
            };
            activeGatt = selected.connectGatt(this, false, cb, BluetoothDevice.TRANSPORT_LE);
            if (activeGatt == null) add("connectGatt returned null.");
            BluetoothGatt captured = activeGatt;
            main.postDelayed(() -> {
                if (captured != null && captured == activeGatt) closeSpecificGatt(captured, "12s timeout");
            }, GATT_TIMEOUT_MS);
        } catch (SecurityException e) {
            add("GATT SecurityException: " + e.getMessage());
        } catch (Exception e) {
            add("GATT start error: " + e);
        }
    }

    private void dumpGattMetadata(BluetoothGatt gatt) {
        List<BluetoothGattService> services;
        try { services = gatt.getServices(); }
        catch (Exception e) { ui("getServices error: " + e); return; }
        boolean ab00 = false;
        ui("GATT services count=" + services.size());
        for (BluetoothGattService s : services) {
            UUID su = s.getUuid();
            if (UUID_UFE_AB00.equals(su)) ab00 = true;
            ui("  SERVICE " + su + labelUuid(su) + " type=" + s.getType());
            for (BluetoothGattCharacteristic c : s.getCharacteristics()) {
                UUID cu = c.getUuid();
                ui("    CHAR " + cu + labelUuid(cu) + " props=" + properties(c.getProperties()));
                for (BluetoothGattDescriptor d : c.getDescriptors()) {
                    ui("      DESC " + d.getUuid());
                }
            }
        }
        if (ab00) {
            ui("BLE CAPABILITY SIGNAL: AB00 PRESENT (matches MVSilicon/UFE BLE surface; NOT OBEX OTA proof).");
        } else {
            ui("BLE RESULT: AB00 NOT OBSERVED in discovered GATT services.");
        }
        ui("GATT discovery complete. No value read/write or notification subscription performed.");
    }

    private void closeGatt(String why) {
        BluetoothGatt g = activeGatt;
        if (g != null) closeSpecificGatt(g, why);
    }

    private void closeSpecificGatt(BluetoothGatt gatt, String why) {
        try { gatt.disconnect(); } catch (Exception ignored) {}
        try { gatt.close(); } catch (Exception ignored) {}
        if (gatt == activeGatt) activeGatt = null;
        ui("GATT closed: " + why);
    }

    private void logCachedUuids(BluetoothDevice d) {
        try {
            ParcelUuid[] uuids = d.getUuids();
            if (uuids == null || uuids.length == 0) {
                add("  cached UUIDs: <none>");
                return;
            }
            boolean opp = false;
            for (ParcelUuid p : uuids) {
                UUID u = p == null ? null : p.getUuid();
                if (u == null) continue;
                add("  cached UUID: " + u + labelUuid(u));
                if (UUID_OPP_OBJECT_PUSH.equals(u)) opp = true;
            }
            if (opp) add("  cached signal: OPP/Object Push 0x1105 PRESENT");
        } catch (SecurityException e) {
            add("  cached UUID SecurityException: " + e.getMessage());
        }
    }

    private String describeDevice(BluetoothDevice d) {
        if (d == null) return "<null>";
        try {
            BluetoothClass bc = d.getBluetoothClass();
            String cls = bc == null ? "?" : ("major=" + bc.getMajorDeviceClass() + ",device=" + bc.getDeviceClass());
            return safe(d.getName()) + " | " + safeAddress(d) + " | type=" + d.getType() +
                    " | bond=" + d.getBondState() + " | class=" + cls;
        } catch (SecurityException e) {
            return "<permission-restricted device>";
        }
    }

    private String deviceKey(BluetoothDevice d) {
        try { return d.getAddress(); }
        catch (Exception e) { return "device@" + Integer.toHexString(System.identityHashCode(d)); }
    }

    private String safeAddress(BluetoothDevice d) {
        try { return d.getAddress(); }
        catch (Exception e) { return "<address unavailable>"; }
    }

    private static String safe(String s) { return s == null || s.isEmpty() ? "<unnamed>" : s; }

    private static UUID uuid16(int shortUuid) {
        return UUID.fromString(String.format(Locale.US, "0000%04x-0000-1000-8000-00805f9b34fb", shortUuid & 0xffff));
    }

    private static String labelUuid(UUID u) {
        if (u == null) return "";
        if (UUID_OPP_OBJECT_PUSH.equals(u)) return " [Object Push / OPP 0x1105 — Classic OBEX signal]";
        if (UUID_UFE_AB00.equals(u)) return " [AB00 UFE BLE service — NOT OTA proof]";
        if (UUID_UFE_AB01.equals(u)) return " [AB01]";
        if (UUID_UFE_AB02.equals(u)) return " [AB02]";
        if (UUID_UFE_AB03.equals(u)) return " [AB03]";
        Integer s = bluetooth16(u);
        return s == null ? " [128-bit/vendor-or-other]" : String.format(Locale.US, " [UUID16 0x%04X]", s);
    }

    private static Integer bluetooth16(UUID u) {
        String s = u.toString().toLowerCase(Locale.US);
        if (s.startsWith("0000") && s.endsWith("-0000-1000-8000-00805f9b34fb")) {
            try { return Integer.parseInt(s.substring(4, 8), 16); } catch (Exception ignored) {}
        }
        return null;
    }

    private static String uuidList(List<ParcelUuid> list) {
        if (list == null || list.isEmpty()) return "[]";
        StringBuilder b = new StringBuilder("[");
        for (int i = 0; i < list.size(); i++) {
            if (i > 0) b.append(", ");
            ParcelUuid p = list.get(i);
            b.append(p == null ? "null" : p.getUuid());
        }
        return b.append(']').toString();
    }

    private static String properties(int p) {
        List<String> x = new ArrayList<>();
        if ((p & BluetoothGattCharacteristic.PROPERTY_BROADCAST) != 0) x.add("BROADCAST");
        if ((p & BluetoothGattCharacteristic.PROPERTY_READ) != 0) x.add("READ");
        if ((p & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0) x.add("WRITE_NO_RSP");
        if ((p & BluetoothGattCharacteristic.PROPERTY_WRITE) != 0) x.add("WRITE");
        if ((p & BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0) x.add("NOTIFY");
        if ((p & BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) x.add("INDICATE");
        if ((p & BluetoothGattCharacteristic.PROPERTY_SIGNED_WRITE) != 0) x.add("SIGNED_WRITE");
        if ((p & BluetoothGattCharacteristic.PROPERTY_EXTENDED_PROPS) != 0) x.add("EXTENDED");
        return x.toString();
    }

    private static String profileState(int s) {
        if (s == BluetoothProfile.STATE_CONNECTED) return "CONNECTED";
        if (s == BluetoothProfile.STATE_CONNECTING) return "CONNECTING";
        if (s == BluetoothProfile.STATE_DISCONNECTED) return "DISCONNECTED";
        if (s == BluetoothProfile.STATE_DISCONNECTING) return "DISCONNECTING";
        return String.valueOf(s);
    }

    private BluetoothDevice getBtDevice(Intent i) {
        if (Build.VERSION.SDK_INT >= 33) return i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice.class);
        @SuppressWarnings("deprecation") BluetoothDevice d = i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
        return d;
    }

    private ParcelableUuidResult parseUuidIntent(Intent i) {
        android.os.Parcelable[] raw;
        if (Build.VERSION.SDK_INT >= 33) raw = i.getParcelableArrayExtra(BluetoothDevice.EXTRA_UUID, ParcelUuid.class);
        else {
            @SuppressWarnings("deprecation") android.os.Parcelable[] old = i.getParcelableArrayExtra(BluetoothDevice.EXTRA_UUID);
            raw = old;
        }
        List<UUID> out = new ArrayList<>();
        if (raw != null) for (android.os.Parcelable p : raw) if (p instanceof ParcelUuid) out.add(((ParcelUuid) p).getUuid());
        return new ParcelableUuidResult(out, raw == null ? 0 : raw.length);
    }

    private static final class ParcelableUuidResult {
        final List<UUID> uuids;
        final int rawCount;
        ParcelableUuidResult(List<UUID> uuids, int rawCount) { this.uuids = uuids; this.rawCount = rawCount; }
    }

    private void copyLog() {
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (cm == null) { add("Clipboard unavailable."); return; }
        cm.setPrimaryClip(ClipData.newPlainText("OKN_R24_BT_OTA_probe", logView.getText()));
        add("Whole log copied to clipboard.");
    }

    private void add(String s) {
        String ts = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(new Date());
        ui("[" + ts + "] " + s);
    }

    private void ui(String s) {
        main.post(() -> logView.append(s + "\n"));
    }
}
