# R24 Android build matrix

- compileSdk: 36
- targetSdk: 36
- minSdk: 26
- Android Gradle Plugin: 8.10.1
- Gradle: 8.11.1
- JDK: 17
- SDK Build Tools: 35.0.0

เหตุผล: AGP 8.10 รองรับ API 36 และระบุ Gradle 8.11.1 / JDK 17 / Build Tools 35.0.0 เป็น compatibility baseline จึงไม่ต้องบังคับ Build Tools 36.0.0

workflow ภายนอกไม่ใช้ `android-actions/setup-android`; จะค้น `sdkmanager` ที่มีบน GitHub-hosted runner แล้วติดตั้งเฉพาะ `platforms;android-36`, `build-tools;35.0.0`, `platform-tools` แบบ non-interactive
