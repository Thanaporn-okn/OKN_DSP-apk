# R24 — Offline reverse: MVSilicon Bluetooth / OBEX OTA path

แหล่งหลัก: SDK ที่แนบ `MVsB1_BT_Audio_SDK_v0.1.11+P01+P02+P03+P04+P05+P06.zip` โดยเริ่มจาก `sdk_evidence/obex/bt_obex_upgrade.c` และ `sdk_evidence/r23_reverse/` ตาม handoff

## 1) Compile gates ที่ต้องเปิด

### `BT_Audio_APP/bt_audio_app_src/inc/bt_config.h`
ค่าอ้างอิงใน SDK นี้กำหนด `BT_OBEX_SUPPORT` เป็น `DISABLE` ทั้ง branch A2DP-enabled และ A2DP-disabled

ภายใน block `#if (BT_OBEX_SUPPORT == ENABLE)` มีบรรทัด:

`//#define MVA_BT_OBEX_UPDATE_FUNC_SUPPORT`

ดังนั้น source reference ที่แนบ **ไม่ได้เปิด OBEX และไม่ได้เปิด MVA-over-OBEX OTA เป็นค่าเริ่มต้น** การมี source รองรับจึงยังไม่พิสูจน์ว่า stock GoloPine เปิด feature นี้

## 2) Registration path

- `MVsB1_Base_SDK/middleware/bluetooth/src/bt_app_func.c`
  - เมื่อ `BT_OBEX_SUPPORT == ENABLE` จะเพิ่ม `BT_PROFILE_SUPPORTED_OBEX`
  - และเรียก `ObexAppCallbackRegister(BtObexCallback)`
- `MVsB1_Base_SDK/middleware/bluetooth/src/bt_obex_app.c`
  - รับ event connected / disconnected / data received
  - เฉพาะเมื่อ `MVA_BT_OBEX_UPDATE_FUNC_SUPPORT` ถูก define จึง forward payload metadata/body ไป `ObexUpdateProc()` และจบด้วย `ObexUpgradeEnd()`
- `BT_Audio_APP/bt_audio_app_src/services/bt_stack_service.c`
  - เฉพาะเมื่อ `MVA_BT_OBEX_UPDATE_FUNC_SUPPORT` ถูก define จึงสร้าง task `bt_obex_upgrate`

สรุป gate ที่ต้องมีสำหรับ OTA path ตาม SDK:
1. `BT_OBEX_SUPPORT == ENABLE` เพื่อเปิด OBEX profile/SDP/callback
2. `MVA_BT_OBEX_UPDATE_FUNC_SUPPORT` เพื่อผูก OBEX data เข้ากับ MVA staging + upgrade task

## 3) Write path ที่พบใน SDK — หลักฐานเท่านั้น, R24 ห้ามเรียก

`bt_obex_upgrade.c` ยืนยันพฤติกรรม:
- รับ OBEX name/length/body callback
- ตรวจชื่อไฟล์ `.mva`
- staging เริ่มที่ `0x200000`
- erase/write SPI flash เป็น block/sector
- ตรวจ CRC16-CCITT
- เมื่อผ่าน CRC เรียก Bank-B upgrade apply แล้ว reset

ส่วนนี้เป็นเหตุผลว่าทำไม R24 ต้องหยุดที่ capability discovery และไม่มี client ส่งข้อมูล

## 4) Reverse `libBtStack.a` — SDP fingerprint

archive `MVsB1_Base_SDK/middleware/bluetooth/libBtStack.a` มี object `obex_sdp.o` แบบ ELF 32-bit Andes embedded RISC และไม่ได้ strip symbol สำคัญ

หลักฐานใน `obex_sdp.o`:
- service name string: `Object Push`
- `ObexClassId` bytes: `35 03 19 11 05`
  - SDP sequence ที่บรรจุ UUID16 `0x1105` = Object Push Profile
- `ObexProfileDescList` มี UUID `0x1105`
- `ObexProtoDescList` มี UUID `0x0100` (L2CAP), `0x0003` (RFCOMM), `0x0008` (OBEX)
- relocation ของ `BTStackInitObex` อ้าง `ObexRegisterSdpService`
- `ObexAppInit` อ้าง `BTStackInitObex`

ดังนั้นเมื่อ OBEX profile ถูกเปิดและ init สำเร็จ ควรมี SDP signal แบบมาตรฐานที่ Android สามารถเห็นเป็น service UUID `00001105-0000-1000-8000-00805f9b34fb` ได้

ข้อจำกัด: Android public API ให้ UUID list ผ่าน SDP แต่ไม่เปิด raw SDP attributes/RFCOMM channel ให้แอปทั่วไป จึงใช้ UUID 0x1105 เป็น capability signal ไม่ใช่ protocol proof เต็มรูปแบบ

## 5) BLE AB00 ใน SDK

SDK ยังมี GATT profile ตัวอย่าง/แอปที่ระบุ:
- Primary Service `AB00`
- `AB01` read/write
- `AB02` notify
- `AB03` notify

R24 จึงตรวจ AB00/AB01/AB02/AB03 เพื่อยืนยัน identity/UFE-style BLE surface แต่ **AB00 ไม่ใช่หลักฐานว่า OBEX OTA เปิดอยู่** เพราะ OBEX path อยู่บน Bluetooth Classic SDP/RFCOMM/OBEX คนละชั้นกับ BLE GATT

## 6) เกณฑ์แปลผล R24

- พบ Classic UUID `0x1105`:
  - ยืนยันว่า Object Push / OBEX service ถูก expose ผ่าน SDP ณ เวลาทดสอบ
  - เป็น prerequisite ที่สอดคล้องกับ SDK OTA path
  - **ยังไม่ยืนยัน** ว่า `MVA_BT_OBEX_UPDATE_FUNC_SUPPORT` เปิด จนกว่าจะมีหลักฐาน read-only เพิ่ม
- ไม่พบ `0x1105`:
  - รายงานว่า “not observed via Android SDP”
  - ยังไม่ควรอ้าง absolute absence เพราะ discovery state, discoverability, identity/mode หรือ Android API อาจจำกัดผล
- พบ AB00:
  - ยืนยัน BLE/UFE surface เท่านั้น ไม่จัดเป็น OTA proof

## Stop condition
ถ้าพบ `0x1105` ให้หยุดที่ discovery และเก็บ log เพื่อออกแบบ R25 read-only handshake/status จากหลักฐาน SDK ต่อไป ห้ามส่งไฟล์และห้ามเปิด write path
