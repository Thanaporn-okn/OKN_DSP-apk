# วิธีใช้ R24 บน Samsung S25+ — READ-ONLY

## ก่อนเริ่ม
1. ติดตั้ง APK ที่ GitHub Actions สร้างจาก source R24
2. เปิด Bluetooth
3. เปิดแอป `OKN BT/OTA Capability Probe R24`
4. กด `1) PERMISSIONS / BT STATUS` และอนุญาต Nearby devices

## ลำดับแนะนำ
1. กด `2) LOAD BONDED / CACHED DEVICES`
2. ถ้าไม่เห็นบอร์ด ให้กด `3) BLE SCAN 15s` และ/หรือ `4) CLASSIC DISCOVERY 15s`
3. แตะชื่ออุปกรณ์ GoloPine/JMDSTECH/DSP ที่ต้องการในรายการให้ขึ้น `SELECTED`
4. กด `5) CLASSIC SDP UUIDs — SELECTED`
5. จากนั้นเลือก BLE identity ของบอร์ด (ถ้าเป็นคนละรายการ) แล้วกด `6) BLE GATT METADATA — SELECTED`
6. กด `7) COPY WHOLE LOG` แล้วส่ง log กลับมา

## ความหมายของผล
- `OPP/OBEX Object Push UUID 0x1105 PRESENT`
  - พบ Classic SDP service ที่ตรงกับ Object Push ใน SDK
  - หยุดที่จุดนี้ R24 จะไม่ส่ง data
- `0x1105 NOT OBSERVED`
  - ยังไม่พบผ่าน Android public SDP ในรอบนี้ ไม่ใช่ข้อพิสูจน์ 100% ว่า firmware ไม่มี capability
- `AB00 PRESENT`
  - พบ BLE service ที่สัมพันธ์กับ UFE/BLE profile ใน SDK; ไม่ใช่ OTA proof

## การรับประกันเชิงโค้ดของ R24
`tools/check_r24_android_readonly_guard.py` จะ fail build หากพบ USB API, BluetoothSocket/RFCOMM client, output stream, GATT write, descriptor write หรือ file-send APIs ใน Android source
