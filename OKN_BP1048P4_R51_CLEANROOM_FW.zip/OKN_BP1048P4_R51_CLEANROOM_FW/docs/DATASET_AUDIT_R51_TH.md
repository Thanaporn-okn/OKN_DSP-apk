# Dataset audit R51

ชุดที่อ่าน/สแกนในรอบนี้:

- multipart `ข้อมูลชุด.z01 + ข้อมูลชุด.z02 + ข้อมูลชุด.zip` ถูกประกอบเป็น ZIP สมบูรณ์: 451 entries, uncompressed 462,353,314 bytes.
- `ข้อมูลDSPสำคัญมาก.zip`: 15 entries, uncompressed 1,851,075 bytes.
- ทำ text/source index 274 ไฟล์ (~2.9M characters) และไล่ checkpoint R23/R26/R27/R28/R31/R32/R34/R35/R40/R41/R44/R46/R49/R50.
- recursive binary/archive scan: 52 unique nested archives, 2,480 nested files, ~346 MB decompressed data; ตรวจ magic MVA `4D56B158`, application header `C9BDBEB0`, flashboot command strings และ firmware-like extensions.
- ผล: ไม่พบ stock/factory `.mva` หรือ recovery/full-flash image ที่ซ่อนใน APK/ZIP; binary application header ที่พบจริงเป็น R41 `NOT_FOR_FLASH` checkpoint.
- Datasheet BP1048P4 V0.8 ถูกตรวจครบโครงสร้างสำคัญ: 32-bit RISC/DSP/FPU, internal 32Mbit flash, USB FS OTG, 3 DAC, 2 I2S, 8 DMA, dual-bank bootloader/programming support.
- Stock DeviceDescription ถูกตรวจ: มี 7 EQ paths (IDs 4,5,6,14,15,16,17) แต่ไม่มี independent CH1..CH7 gain/volume actuators.

หมายเหตุ: ภาพบอร์ด/พินเอาต์ใช้ประกอบ mapping ที่มีใน checkpoint; R51 ไม่ hardcode pinmux ที่ยังไม่พิสูจน์.
