# BP1048P4 target-port gate (must close before any stock-board flash)

R51 intentionally contains no guessed MMIO and no stock-board erase/program code.
The DSP/control core is ready for host testing; the following board-specific items are still gates:

1. **First-flash/recovery:** prove a production BP1048P4 bootloader entry that actually detaches runtime USB and enumerates the bootloader, or obtain a trusted stock full-flash/recovery image/readback path.
2. **Production image layout:** confirm application header fields, CRC/check fields, code length, and exact production flash regions. R41 linked image is NOT_FOR_FLASH.
3. **Startup/linker:** bind the clean-room app to the exact BP1048P4 production startup/vector/header contract.
4. **Audio port:** confirm board pinmux/clock ownership and bind logical outputs: CH1 DAC0-L, CH2 DAC0-R, CH3 DACX/bass, CH4/5 I2S0 L/R, CH6/7 I2S1 L/R.
5. **USB device port:** expose a 256-byte HID runtime interface for OKN2 and verify Samsung S25+ USB Host control transfers.
6. **Future updater from our firmware:** only after first install is recoverable, implement a deliberate bootloader handoff and Android writer with image validation before erase/program.

Current stock-board observation from the supplied dataset: Feature AA -> 55 succeeds, but runtime USB remains VID:PID 6324:1719 and the runtime Feature handler remains alive. Therefore boot handoff is not yet proven.
