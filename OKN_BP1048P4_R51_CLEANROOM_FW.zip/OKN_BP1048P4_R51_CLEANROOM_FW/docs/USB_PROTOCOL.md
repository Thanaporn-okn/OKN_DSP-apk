# R51 USB HID runtime protocol

Transport after the custom firmware is installed: one fixed **256-byte HID report**, no report ID.
This is a new clean-room protocol; it is not the stock GoloPine UFE protocol.

Layout: bytes 0..3=`OKN2`, 4=version(1), 5=command, 6=flags, 7=status in replies,
8..9=sequence LE, 10..11=payload length LE, 12..253=payload/padding, 254..255=CRC16/XMODEM over bytes 0..253.

Commands: `01 GET_INFO`, `10 SET_GAIN`, `11 GET_GAIN`, `12 GET_ALL_GAINS`,
`20 SET_PEQ_COEFF`, `21 GET_PEQ_COEFF`, `22 SET_EQ_BYPASS`, `30 RESET_DSP_STATE`,
`7E ENTER_BOOT` (compiled **disabled** in R51).

`SET_GAIN` payload is `[channel0:u8][half_db:i16 LE]`, channel 0..6, range -140..12,
meaning -70.0 dB .. +6.0 dB in 0.5 dB steps. It writes only the dedicated gain state.

`SET_PEQ_COEFF` payload is `[channel][band][enabled][b0][b1][b2][a1][a2]`, each coefficient i32 LE Q2.30.
Use `tools/peq_design.py` to generate coefficients. EQ and channel Gain are intentionally separate.
