# Samsung S25+ USB-C plan

เป้าหมายสุดท้ายแบ่งเป็นสองช่วง:

1. **หลัง custom firmware ถูกติดตั้งแล้ว** — ใช้ Android USB Host คุยกับ OKN2 HID 256-byte โดยตรง, ปรับ Gain CH1..CH7 และ PEQ ได้ live. R51 protocol พร้อมแล้ว.
2. **first flash จาก stock firmware** — ยังเป็น gate เดียวที่ไม่ปิด. ห้ามเปิด erase/program จนเห็นการ re-enumerate เป็น bootloader จริงหรือมี recovery/full backup.

Flash-writer state machine ที่จะใช้เมื่อ boot entry ถูกพิสูจน์:

`STOCK_RUNTIME -> REQUEST_BOOT -> WAIT_DETACH -> BOOTLOADER_ENUM -> VALIDATE_IMAGE -> PROGRAM -> VERIFY -> REBOOT -> OKN2_RUNTIME`

กฎบังคับ:
- `REQUEST_BOOT` สำเร็จก็ต่อเมื่อ stock runtime หายและมี bootloader USB identity ใหม่; `AA -> 55` อย่างเดียวไม่ถือว่าสำเร็จ.
- image ต้องผ่าน header/length/CRC/region validation ก่อน destructive command.
- โปรแกรมเฉพาะ user-code region; ไม่แตะ boot area จนมี recovery proof.
- ถ้า descriptor/identity ไม่ตรง expected bootloader ให้หยุดทันที.
