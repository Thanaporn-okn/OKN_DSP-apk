# ผลวิเคราะห์ R51 จากชุดข้อมูลทั้งหมด

## ข้อสรุปที่มีหลักฐานรองรับ

- แอป/DeviceDescription เดิมมี MasterVolume/BassVolume และ EQ 7 เส้นทาง แต่ไม่มี actuator สำหรับ Gain/Volume อิสระ CH1..CH7 ดังนั้นไม่มี “hidden 7CH gain” ใน runtime path ที่พบ การทำ firmware ใหม่เป็นแนวทางที่ตรงโจทย์กว่าแก้ UI เดิม
- เส้นทางเสียงที่ใช้เป็นฐาน: CH1 DAC0-L, CH2 DAC0-R, CH3 DACX/bass, CH4/5 I2S0 L/R, CH6/7 I2S1 L/R
- R51 แยก PEQ กับ Gain คนละ state/คนละ module และลำดับประมวลผลคือ `route -> PEQ -> dedicated per-channel gain -> sink`
- Gain 7CH: -70 ถึง +6 dB, step 0.5 dB, Q2.14; การเปลี่ยน gain ช่องหนึ่งไม่แก้ coefficient/state config ของ EQ ช่องใด
- USB stock IF4 เป็น HID 256B Input/Output + Feature 8B. Feature AA -> 55 พิสูจน์ handler แต่ยังไม่พิสูจน์ bootloader handoff
- จาก enum ของ SDK: `AppModeBtAudioPlay` อยู่หลัง `AppModeLineAudioPlay`; เพราะฉะนั้นเงื่อนไข `GetSystemMode() < AppModeLineAudioPlay` ไม่ได้อธิบายความล้มเหลวใน BT mode
- การทดลอง late-attach ที่มีในชุดข้อมูลก็ยังได้ ACK แล้วค้าง runtime ดังนั้น “แค่รอ/เสียบ USB ช้าลง” ไม่ใช่คำตอบ
- ตัวเลือกที่ยังเป็นไปได้มากกว่าคือ production build ปิด/เปลี่ยน `FLASH_BOOT_EN`, resource registration ของ USB ไม่ตรง SDK อ้างอิง, หรือ production boot path ถูกแก้จาก public SDK
- สแกน binary/APK/archive ในชุดอัปโหลดแล้ว ไม่พบ factory firmware/MVA/recovery image ที่ซ่อนอยู่; APP magic ที่เป็น binary จริงพบใน R41 NOT_FOR_FLASH เท่านั้น

## สิ่งที่ R51 ทำแล้ว

- clean-room DSP core 7CH
- 15-band PEQ/ch แบบ fixed-point Q2.30 และ bypass ต่อช่อง
- dedicated Gain หลัง EQ
- protocol OKN2 fixed HID 256B สำหรับ Android หลังติดตั้ง firmware ใหม่
- boot command ถูก compile-disable
- host tests + static audit ว่า Gain ไม่แตะ EQ

## สิ่งที่ยังไม่ควรทำกับบอร์ด stock

อย่าส่งคำสั่ง erase/program/commit, `chiperas`, `bootdat`, `codedata`, `constdat`, `cnfgdat`, `btupdat`, `upinfo` หรือเดา address จนกว่าจะมี recovery/readback หรือพิสูจน์ bootloader identity จริง เพราะชุดคำสั่งที่ reverse ได้ไม่มี read-only flash command ที่ปลอดภัย และ `cxxx/upinfo` มี side effect
