# Flashboot evidence R51

## Reference SDK path

`otg_device_standard_request.c` ของ SDK ที่แนบมี Feature handler ดังนี้โดยสาระ:

- SET Feature ถ้า byte แรก `0xAA` -> `pc_upgrade = 1`
- GET Feature ถ้า `pc_upgrade` -> เปลี่ยน byte แรกเป็น `0x55`, ส่งกลับ 8 bytes, แล้วเรียก `start_up_grate(AppResourceUsbDevice)` เฉพาะเมื่อ `FLASH_BOOT_EN` ถูก compile เปิด
- `start_up_grate()` ล้าง boot flag; จะตั้ง PC/update flag เมื่อ `ResourceValue(AppResourceUsbDevice)` เป็นจริง และเมื่อ update flag เป็นจริงจึง shutdown runtime resources + jump address 0

Reference `flash_boot.h` ใน SDK ที่แนบกำหนด `FLASH_BOOT_EN 1` และระบุ flashboot กิน 64 KiB แรก ส่วน user code เริ่มหลัง boot area. อย่างไรก็ตาม `sys_gpio.h` อีกส่วนมี conditional macro ตาม upgrade configuration; source tree จึงมี configuration history ที่ไม่ควรเอาไปฟันธง production binary โดยไม่มี binary จริง.

## Real board evidence

บอร์ดจริงตอบ `AA -> 55` ได้ แต่หลัง 10s ยังคง VID:PID `6324:1719`, topology/report descriptor เดิม และ Feature runtime handler ยังตอบ `55...`. Late-attach experiment ก็ไม่เกิด handoff.

ดังนั้น `55` เป็นเพียง ACK ว่า runtime Feature state ถูก arm ไม่ใช่หลักฐานว่า flashboot รันแล้ว. Behavior นี้เข้ากันได้กับอย่างน้อย 2 กรณี: (1) production build ตัด/แก้ flashboot call จาก reference SDK, หรือ (2) `ResourceValue(AppResourceUsbDevice)` ไม่ผ่านใน production.

## ตัดสมมติฐานออก

SDK enum วาง `AppModeBtAudioPlay` หลัง `AppModeLineAudioPlay`; ดังนั้น early-return `GetSystemMode() < AppModeLineAudioPlay` ไม่ใช่คำอธิบายสำหรับการทดสอบที่อยู่ BT mode. Late attach ก็ไม่แก้ปัญหา.

## Bluetooth OTA

Reference SDK มี MVA-over-OBEX path แต่ live SDP ใน dataset เห็น `0x1101/0x110B/0x110E` และ **ไม่เห็น Object Push 0x1105**; AB00 เป็น tuning/UFE path ไม่ใช่หลักฐาน OTA. จึงไม่มีหลักฐานว่า stock firmware expose MVA OBEX OTA.
