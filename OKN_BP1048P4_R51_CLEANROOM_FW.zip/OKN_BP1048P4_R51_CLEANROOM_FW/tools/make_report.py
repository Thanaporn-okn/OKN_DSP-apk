#!/usr/bin/env python3
"""Create/inspect the fixed 256-byte OKN2 HID report used by R51."""
import argparse,struct,binascii

def crc16(data):
    crc=0
    for x in data:
        crc ^= x<<8
        for _ in range(8): crc=((crc<<1)^0x1021)&0xffff if crc&0x8000 else (crc<<1)&0xffff
    return crc

def make(cmd,payload=b'',seq=1):
    if len(payload)>242: raise ValueError('payload too long')
    b=bytearray(256);b[:4]=b'OKN2';b[4]=1;b[5]=cmd;b[8:10]=struct.pack('<H',seq);b[10:12]=struct.pack('<H',len(payload));b[12:12+len(payload)]=payload
    b[254:256]=struct.pack('<H',crc16(b[:254]));return bytes(b)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('cmd',type=lambda s:int(s,0));ap.add_argument('--payload-hex',default='');ap.add_argument('--seq',type=int,default=1)
    a=ap.parse_args();p=bytes.fromhex(a.payload_hex);r=make(a.cmd,p,a.seq);print(r.hex())
if __name__=='__main__':main()
