#!/usr/bin/env python3
"""Generate one RBJ peaking-EQ biquad as signed Q2.30 coefficients.
This tool designs EQ coefficients only. It never computes channel volume/gain.
"""
import argparse, math

Q=30
LIMIT=(1<<31)-1

def q30(v):
    n=round(v*(1<<Q))
    if not -(1<<31) <= n <= LIMIT:
        raise ValueError(f"coefficient {v:.9f} does not fit signed Q2.30")
    return n

def peaking(fs,f0,q,gain_db):
    if not (8000 <= fs <= 192000): raise ValueError('fs out of range')
    if not (20 <= f0 < fs/2-10): raise ValueError('f0 out of range')
    if not (0.1 <= q <= 20): raise ValueError('Q out of range')
    if not (-18 <= gain_db <= 18): raise ValueError('EQ gain out of range')
    A=10**(gain_db/40)
    w=2*math.pi*f0/fs
    alpha=math.sin(w)/(2*q)
    c=math.cos(w)
    a0=1+alpha/A
    return [(1+alpha*A)/a0, (-2*c)/a0, (1-alpha*A)/a0,
            (-2*c)/a0, (1-alpha/A)/a0]

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--fs',type=int,default=48000)
    ap.add_argument('--f0',type=float,required=True)
    ap.add_argument('--q',type=float,default=1.0)
    ap.add_argument('--gain-db',type=float,required=True)
    a=ap.parse_args()
    f=peaking(a.fs,a.f0,a.q,a.gain_db)
    qi=[q30(v) for v in f]
    print('float: b0 b1 b2 a1 a2 =', ' '.join(f'{v:.9f}' for v in f))
    print('q30  :', ' '.join(str(v) for v in qi))
    print('hex  :', ' '.join(f'0x{(v & 0xffffffff):08X}' for v in qi))
if __name__=='__main__': main()
