#!/usr/bin/env python3
"""Static guard: executable channel-gain code must not reference PEQ symbols."""
from pathlib import Path
import sys,re
root=Path(__file__).resolve().parents[1]
gain=(root/'firmware/dsp/okn_gain7.c').read_text()
router=(root/'firmware/audio/okn_router7.c').read_text()
# Ignore comments when scanning the gain implementation.
code=re.sub(r'/\\*.*?\\*/','',gain,flags=re.S)
code=re.sub(r'//.*','',code)
errors=[]
if re.search(r'\\b(?:peq|eq_)',code,re.I): errors.append('gain executable code references EQ/PEQ')
pos_eq=router.find('okn_peq7_apply')
pos_gain=router.find('okn_gain7_apply')
if pos_eq<0 or pos_gain<0 or pos_eq>pos_gain: errors.append('router must apply PEQ before dedicated gain')
if errors:
    print('FAIL:',*errors,sep='\\n- ');sys.exit(1)
print('PASS: gain executable code is EQ-independent; signal order is PEQ -> dedicated gain')
