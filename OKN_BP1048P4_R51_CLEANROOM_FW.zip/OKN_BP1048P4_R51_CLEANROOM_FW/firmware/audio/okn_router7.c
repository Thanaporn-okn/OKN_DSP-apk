#include "okn_router7.h"
#include "okn_gain7.h"
#include "okn_peq7.h"

static int32_t mono_mix(int32_t l, int32_t r)
{
    return (int32_t)(((int64_t)l + (int64_t)r) / 2);
}

void okn_router7_route_stereo(int32_t left, int32_t right, okn_r51_frame7_t *out)
{
    if (!out) return;
    out->sample[0] = left;
    out->sample[1] = right;
    out->sample[2] = mono_mix(left, right);
    out->sample[3] = left;
    out->sample[4] = right;
    out->sample[5] = left;
    out->sample[6] = right;
}

void okn_router7_process_stereo(int32_t left, int32_t right, okn_r51_frame7_t *out)
{
    uint8_t ch;
    okn_router7_route_stereo(left, right, out);
    if (!out) return;
    for (ch = 0; ch < OKN_R51_CHANNELS; ++ch) {
        /* Hard project rule: EQ is an EQ stage. Gain is a separate stage AFTER EQ. */
        out->sample[ch] = okn_peq7_apply(ch, out->sample[ch]);
        out->sample[ch] = okn_gain7_apply(ch, out->sample[ch]);
    }
}
