#ifndef OKN_ROUTER7_H
#define OKN_ROUTER7_H
#include <stdint.h>
#include "okn_r51.h"

void okn_router7_route_stereo(int32_t left, int32_t right, okn_r51_frame7_t *out);
void okn_router7_process_stereo(int32_t left, int32_t right, okn_r51_frame7_t *out);

#endif
