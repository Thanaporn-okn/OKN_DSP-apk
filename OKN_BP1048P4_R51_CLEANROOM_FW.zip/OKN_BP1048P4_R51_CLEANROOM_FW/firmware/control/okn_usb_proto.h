#ifndef OKN_USB_PROTO_H
#define OKN_USB_PROTO_H
#include <stdint.h>
#include "okn_r51.h"

#define OKN_PROTO_VERSION 1u
#define OKN_PROTO_PAYLOAD_MAX 242u

#define OKN_CMD_GET_INFO          0x01u
#define OKN_CMD_SET_GAIN          0x10u
#define OKN_CMD_GET_GAIN          0x11u
#define OKN_CMD_GET_ALL_GAINS     0x12u
#define OKN_CMD_SET_PEQ_COEFF     0x20u
#define OKN_CMD_GET_PEQ_COEFF     0x21u
#define OKN_CMD_SET_EQ_BYPASS     0x22u
#define OKN_CMD_RESET_DSP_STATE   0x30u
#define OKN_CMD_ENTER_BOOT        0x7Eu

#define OKN_STATUS_OK             0u
#define OKN_STATUS_BAD_MAGIC      1u
#define OKN_STATUS_BAD_VERSION    2u
#define OKN_STATUS_BAD_LENGTH     3u
#define OKN_STATUS_BAD_CRC        4u
#define OKN_STATUS_BAD_ARGUMENT   5u
#define OKN_STATUS_UNSUPPORTED    6u
#define OKN_STATUS_BOOT_DISABLED  7u

uint16_t okn_crc16_xmodem(const uint8_t *p, uint16_t n);
int okn_usb_proto_handle(const uint8_t in[OKN_R51_USB_REPORT_BYTES],
                         uint8_t out[OKN_R51_USB_REPORT_BYTES]);

#endif
