#include "okn_usb_proto.h"
#include "okn_gain7.h"
#include "okn_peq7.h"
#include <string.h>

#ifndef OKN_ENABLE_BOOT_JUMP
#define OKN_ENABLE_BOOT_JUMP 0
#endif

#if OKN_ENABLE_BOOT_JUMP
#include "okn_platform.h"
#endif

#define HDR 12u
#define CRC_OFF 254u

static uint16_t r16(const uint8_t *p){ return (uint16_t)p[0] | ((uint16_t)p[1] << 8); }
static int16_t ri16(const uint8_t *p){ return (int16_t)r16(p); }
static uint32_t r32(const uint8_t *p){ return (uint32_t)p[0] | ((uint32_t)p[1]<<8) | ((uint32_t)p[2]<<16) | ((uint32_t)p[3]<<24); }
static void w16(uint8_t *p,uint16_t v){ p[0]=(uint8_t)v; p[1]=(uint8_t)(v>>8); }
static void w32(uint8_t *p,uint32_t v){ p[0]=(uint8_t)v; p[1]=(uint8_t)(v>>8); p[2]=(uint8_t)(v>>16); p[3]=(uint8_t)(v>>24); }

uint16_t okn_crc16_xmodem(const uint8_t *p, uint16_t n)
{
    uint16_t crc = 0, i;
    uint8_t bit;
    for (i = 0; i < n; ++i) {
        crc ^= (uint16_t)p[i] << 8;
        for (bit = 0; bit < 8; ++bit) crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
    }
    return crc;
}

static void begin_reply(const uint8_t *in, uint8_t *out, uint8_t status, uint16_t payload_len)
{
    memset(out, 0, OKN_R51_USB_REPORT_BYTES);
    out[0]='O'; out[1]='K'; out[2]='N'; out[3]='2'; out[4]=OKN_PROTO_VERSION;
    out[5]=(uint8_t)(in[5] | 0x80u); out[6]=0u; out[7]=status;
    out[8]=in[8]; out[9]=in[9];
    w16(out+10, payload_len);
}

static void finish_reply(uint8_t *out)
{
    uint16_t crc = okn_crc16_xmodem(out, CRC_OFF);
    w16(out + CRC_OFF, crc);
}

static int valid_frame(const uint8_t *in, uint8_t *status)
{
    uint16_t len, want, got;
    if (in[0]!='O'||in[1]!='K'||in[2]!='N'||in[3]!='2') { *status=OKN_STATUS_BAD_MAGIC; return 0; }
    if (in[4]!=OKN_PROTO_VERSION) { *status=OKN_STATUS_BAD_VERSION; return 0; }
    len=r16(in+10);
    if (len>OKN_PROTO_PAYLOAD_MAX) { *status=OKN_STATUS_BAD_LENGTH; return 0; }
    want=okn_crc16_xmodem(in,CRC_OFF); got=r16(in+CRC_OFF);
    if (want!=got) { *status=OKN_STATUS_BAD_CRC; return 0; }
    *status=OKN_STATUS_OK; return 1;
}

static void pack_coeff(uint8_t *p, const okn_peq_coeff_t *c)
{
    p[0]=c->enabled;
    w32(p+1,(uint32_t)c->b0_q30); w32(p+5,(uint32_t)c->b1_q30);
    w32(p+9,(uint32_t)c->b2_q30); w32(p+13,(uint32_t)c->a1_q30); w32(p+17,(uint32_t)c->a2_q30);
}

static void unpack_coeff(const uint8_t *p, okn_peq_coeff_t *c)
{
    c->enabled=p[0]; c->b0_q30=(int32_t)r32(p+1); c->b1_q30=(int32_t)r32(p+5);
    c->b2_q30=(int32_t)r32(p+9); c->a1_q30=(int32_t)r32(p+13); c->a2_q30=(int32_t)r32(p+17);
}

int okn_usb_proto_handle(const uint8_t in[OKN_R51_USB_REPORT_BYTES], uint8_t out[OKN_R51_USB_REPORT_BYTES])
{
    uint8_t st, cmd, ch, band;
    uint16_t len;
    okn_peq_coeff_t c;
    if (!in || !out) return 0;
    if (!valid_frame(in,&st)) { begin_reply(in,out,st,0); finish_reply(out); return 1; }
    cmd=in[5]; len=r16(in+10);
    switch(cmd) {
    case OKN_CMD_GET_INFO:
        if (len!=0) { st=OKN_STATUS_BAD_LENGTH; begin_reply(in,out,st,0); break; }
        begin_reply(in,out,OKN_STATUS_OK,16);
        memcpy(out+HDR,"R51-CLEANROOM",13); out[HDR+13]=OKN_R51_CHANNELS; out[HDR+14]=OKN_R51_EQ_BANDS; out[HDR+15]=0;
        break;
    case OKN_CMD_SET_GAIN:
        if (len!=3) { begin_reply(in,out,OKN_STATUS_BAD_LENGTH,0); break; }
        ch=in[HDR];
        if (!okn_gain7_set_half_db(ch,ri16(in+HDR+1))) { begin_reply(in,out,OKN_STATUS_BAD_ARGUMENT,0); break; }
        begin_reply(in,out,OKN_STATUS_OK,3); out[HDR]=ch; w16(out+HDR+1,(uint16_t)okn_gain7_get_half_db(ch));
        break;
    case OKN_CMD_GET_GAIN:
        if (len!=1 || in[HDR]>=OKN_R51_CHANNELS) { begin_reply(in,out,OKN_STATUS_BAD_ARGUMENT,0); break; }
        ch=in[HDR]; begin_reply(in,out,OKN_STATUS_OK,3); out[HDR]=ch; w16(out+HDR+1,(uint16_t)okn_gain7_get_half_db(ch));
        break;
    case OKN_CMD_GET_ALL_GAINS:
        if (len!=0) { begin_reply(in,out,OKN_STATUS_BAD_LENGTH,0); break; }
        begin_reply(in,out,OKN_STATUS_OK,OKN_R51_CHANNELS*2u);
        for(ch=0;ch<OKN_R51_CHANNELS;++ch) w16(out+HDR+ch*2u,(uint16_t)okn_gain7_get_half_db(ch));
        break;
    case OKN_CMD_SET_PEQ_COEFF:
        if (len!=23) { begin_reply(in,out,OKN_STATUS_BAD_LENGTH,0); break; }
        ch=in[HDR]; band=in[HDR+1]; unpack_coeff(in+HDR+2,&c);
        if(!okn_peq7_set(ch,band,&c)){begin_reply(in,out,OKN_STATUS_BAD_ARGUMENT,0);break;}
        begin_reply(in,out,OKN_STATUS_OK,23); out[HDR]=ch;out[HDR+1]=band;pack_coeff(out+HDR+2,&c);
        break;
    case OKN_CMD_GET_PEQ_COEFF:
        if (len!=2) { begin_reply(in,out,OKN_STATUS_BAD_LENGTH,0); break; }
        ch=in[HDR];band=in[HDR+1];if(!okn_peq7_get(ch,band,&c)){begin_reply(in,out,OKN_STATUS_BAD_ARGUMENT,0);break;}
        begin_reply(in,out,OKN_STATUS_OK,23);out[HDR]=ch;out[HDR+1]=band;pack_coeff(out+HDR+2,&c);
        break;
    case OKN_CMD_SET_EQ_BYPASS:
        if(len!=2 || in[HDR]>=OKN_R51_CHANNELS || in[HDR+1]>1u){begin_reply(in,out,OKN_STATUS_BAD_ARGUMENT,0);break;}
        ch=in[HDR];okn_peq7_set_channel_bypass(ch,in[HDR+1]);begin_reply(in,out,OKN_STATUS_OK,2);out[HDR]=ch;out[HDR+1]=okn_peq7_get_channel_bypass(ch);
        break;
    case OKN_CMD_RESET_DSP_STATE:
        if(len!=0){begin_reply(in,out,OKN_STATUS_BAD_LENGTH,0);break;}
        /* Reset runtime DSP config only; it does NOT reset MCU or write flash. */
        okn_gain7_init(); okn_peq7_init(); begin_reply(in,out,OKN_STATUS_OK,0);
        break;
    case OKN_CMD_ENTER_BOOT:
#if OKN_ENABLE_BOOT_JUMP
        if(len!=4 || memcmp(in+HDR,"BOOT",4)!=0){begin_reply(in,out,OKN_STATUS_BAD_ARGUMENT,0);break;}
        begin_reply(in,out,OKN_STATUS_OK,0); finish_reply(out);
        okn_platform_request_bootloader();
        return 1;
#else
        begin_reply(in,out,OKN_STATUS_BOOT_DISABLED,0);
#endif
        break;
    default:
        begin_reply(in,out,OKN_STATUS_UNSUPPORTED,0); break;
    }
    finish_reply(out); return 1;
}
