#include "okn_platform.h"

/* BP1048P4 TARGET PORT TEMPLATE — intentionally not flash-ready.
 *
 * Verified project-level logical sinks:
 *   CH1 DAC0-L, CH2 DAC0-R, CH3 DACX/bass,
 *   CH4/5 I2S0 L/R, CH6/7 I2S1 L/R.
 *
 * Public SDK evidence also exposes AudioCore sink and I2S APIs, but the exact
 * production board pinmux, clock ownership, DMA timing, USB descriptor setup,
 * startup/linker layout, first-flash boot entry, and recovery image are not
 * proven. This file therefore contains NO guessed register writes.
 *
 * Bind only after each item in docs/TARGET_PORT_GATE.md is proven.
 */

int okn_platform_init(uint32_t sample_rate)
{
    (void)sample_rate;
    return 0; /* gate closed */
}

int okn_platform_write_frame7(const okn_r51_frame7_t *frame)
{
    (void)frame;
    return 0; /* gate closed */
}

int okn_platform_usb_send(const uint8_t *report256, size_t n)
{
    (void)report256; (void)n;
    return 0; /* gate closed */
}

void okn_platform_request_bootloader(void)
{
    /* Deliberately inert in R51. Do not jump/erase/program stock flash here. */
}
