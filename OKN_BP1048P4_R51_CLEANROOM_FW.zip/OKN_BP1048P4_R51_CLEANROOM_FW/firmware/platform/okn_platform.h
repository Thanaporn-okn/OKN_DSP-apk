#ifndef OKN_PLATFORM_H
#define OKN_PLATFORM_H
#include <stddef.h>
#include <stdint.h>
#include "okn_r51.h"

/* NO guessed MMIO lives in the clean-room core. The target port must bind
 * these functions to documented/public-SDK BP1048P4 services. */
int okn_platform_init(uint32_t sample_rate);
int okn_platform_write_frame7(const okn_r51_frame7_t *frame);
int okn_platform_usb_send(const uint8_t *report256, size_t n);
void okn_platform_request_bootloader(void);

#endif
