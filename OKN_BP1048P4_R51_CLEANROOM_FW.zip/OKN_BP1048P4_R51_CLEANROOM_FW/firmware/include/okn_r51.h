#ifndef OKN_R51_H
#define OKN_R51_H

#include <stddef.h>
#include <stdint.h>

#define OKN_R51_CHANNELS 7u
#define OKN_R51_EQ_BANDS 15u
#define OKN_R51_USB_REPORT_BYTES 256u
#define OKN_R51_SAMPLE_RATE_DEFAULT 48000u

/* Logical output order proven by the project dataset. Physical board wiring is
 * finalized only in the BP1048P4 platform port. */
typedef enum {
    OKN_CH1_DAC0_L = 0,
    OKN_CH2_DAC0_R = 1,
    OKN_CH3_DACX_MONO = 2,
    OKN_CH4_I2S0_L = 3,
    OKN_CH5_I2S0_R = 4,
    OKN_CH6_I2S1_L = 5,
    OKN_CH7_I2S1_R = 6
} okn_r51_channel_t;

typedef struct {
    int32_t sample[OKN_R51_CHANNELS];
} okn_r51_frame7_t;

void okn_r51_init(uint32_t sample_rate);
void okn_r51_process_stereo(int32_t left, int32_t right, okn_r51_frame7_t *out);
int okn_r51_handle_usb_report(const uint8_t in[OKN_R51_USB_REPORT_BYTES],
                              uint8_t out[OKN_R51_USB_REPORT_BYTES]);

#endif
