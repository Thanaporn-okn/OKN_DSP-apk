#include "okn_gain7.h"
#include <limits.h>

/* Dedicated gain table: -70.0 dB .. +6.0 dB in 0.5 dB steps, Q2.14.
 * This stage is independent of PEQ state and is applied AFTER PEQ. */
static const uint16_t k_gain_q14[153] = {
    5, 5, 6, 6, 7, 7, 7, 8, 8, 9, 9, 10,
    10, 11, 12, 12, 13, 14, 15, 15, 16, 17, 18, 19,
    21, 22, 23, 25, 26, 28, 29, 31, 33, 35, 37, 39,
    41, 44, 46, 49, 52, 55, 58, 62, 65, 69, 73, 78,
    82, 87, 92, 98, 103, 110, 116, 123, 130, 138, 146, 155,
    164, 174, 184, 195, 206, 218, 231, 245, 260, 275, 291, 309,
    327, 346, 367, 389, 412, 436, 462, 489, 518, 549, 581, 616,
    652, 691, 732, 775, 821, 870, 921, 976, 1034, 1095, 1160, 1229,
    1301, 1379, 1460, 1547, 1638, 1735, 1838, 1947, 2063, 2185, 2314, 2451,
    2597, 2751, 2914, 3086, 3269, 3463, 3668, 3885, 4115, 4359, 4618, 4891,
    5181, 5488, 5813, 6158, 6523, 6909, 7318, 7752, 8211, 8698, 9213, 9759,
    10338, 10950, 11599, 12286, 13014, 13785, 14602, 15467, 16384, 17355, 18383, 19472,
    20626, 21848, 23143, 24514, 25967, 27506, 29135, 30862, 32690
};

static int16_t g_half_db[OKN_GAIN7_CHANNELS];

void okn_gain7_init(void)
{
    uint8_t ch;
    for (ch = 0; ch < OKN_GAIN7_CHANNELS; ++ch) g_half_db[ch] = 0;
}

int okn_gain7_set_half_db(uint8_t ch0, int16_t half_db)
{
    if (ch0 >= OKN_GAIN7_CHANNELS) return 0;
    if (half_db < OKN_GAIN7_MIN_HALF_DB || half_db > OKN_GAIN7_MAX_HALF_DB) return 0;
    g_half_db[ch0] = half_db;
    return 1;
}

int16_t okn_gain7_get_half_db(uint8_t ch0)
{
    return ch0 < OKN_GAIN7_CHANNELS ? g_half_db[ch0] : 0;
}

uint16_t okn_gain7_get_q14(uint8_t ch0)
{
    int idx;
    if (ch0 >= OKN_GAIN7_CHANNELS) return 0;
    idx = (int)g_half_db[ch0] - OKN_GAIN7_MIN_HALF_DB;
    return k_gain_q14[idx];
}

int32_t okn_gain7_apply(uint8_t ch0, int32_t sample)
{
    int64_t v;
    uint16_t g;
    if (ch0 >= OKN_GAIN7_CHANNELS) return 0;
    g = okn_gain7_get_q14(ch0);
    v = (int64_t)sample * (int64_t)g;
    v = (v >= 0) ? ((v + (1LL << 13)) >> 14) : -(((-v) + (1LL << 13)) >> 14);
    if (v > INT32_MAX) return INT32_MAX;
    if (v < INT32_MIN) return INT32_MIN;
    return (int32_t)v;
}
