#include "okn_peq7.h"
#include <limits.h>
#include <string.h>

typedef struct {
    okn_peq_coeff_t c;
    int32_t x1, x2, y1, y2;
} band_state_t;

typedef struct {
    uint8_t bypass[OKN_PEQ7_CHANNELS];
    okn_peq_coeff_t coeff[OKN_PEQ7_CHANNELS][OKN_PEQ7_BANDS];
} config_snapshot_t;

static band_state_t g_band[OKN_PEQ7_CHANNELS][OKN_PEQ7_BANDS];
static uint8_t g_bypass[OKN_PEQ7_CHANNELS];

static int32_t sat32(int64_t x)
{
    if (x > INT32_MAX) return INT32_MAX;
    if (x < INT32_MIN) return INT32_MIN;
    return (int32_t)x;
}

static void identity(okn_peq_coeff_t *c)
{
    memset(c, 0, sizeof(*c));
    c->b0_q30 = (int32_t)(1UL << OKN_PEQ_Q);
}

void okn_peq7_init(void)
{
    uint8_t ch, b;
    memset(g_band, 0, sizeof(g_band));
    memset(g_bypass, 0, sizeof(g_bypass));
    for (ch = 0; ch < OKN_PEQ7_CHANNELS; ++ch) {
        for (b = 0; b < OKN_PEQ7_BANDS; ++b) identity(&g_band[ch][b].c);
    }
}

int okn_peq7_set(uint8_t ch0, uint8_t band0, const okn_peq_coeff_t *coeff)
{
    band_state_t *s;
    if (!coeff || ch0 >= OKN_PEQ7_CHANNELS || band0 >= OKN_PEQ7_BANDS) return 0;
    if (coeff->enabled > 1u) return 0;
    s = &g_band[ch0][band0];
    s->c = *coeff;
    s->x1 = s->x2 = s->y1 = s->y2 = 0;
    return 1;
}

int okn_peq7_get(uint8_t ch0, uint8_t band0, okn_peq_coeff_t *coeff)
{
    if (!coeff || ch0 >= OKN_PEQ7_CHANNELS || band0 >= OKN_PEQ7_BANDS) return 0;
    *coeff = g_band[ch0][band0].c;
    return 1;
}

void okn_peq7_set_channel_bypass(uint8_t ch0, uint8_t bypass)
{
    if (ch0 < OKN_PEQ7_CHANNELS) g_bypass[ch0] = bypass ? 1u : 0u;
}

uint8_t okn_peq7_get_channel_bypass(uint8_t ch0)
{
    return ch0 < OKN_PEQ7_CHANNELS ? g_bypass[ch0] : 1u;
}

static int32_t run_band(band_state_t *s, int32_t x)
{
    int64_t acc;
    int32_t y;
    /* Direct Form I; coefficients are signed Q2.30, PCM remains signed int32. */
    acc  = (int64_t)s->c.b0_q30 * x;
    acc += (int64_t)s->c.b1_q30 * s->x1;
    acc += (int64_t)s->c.b2_q30 * s->x2;
    acc -= (int64_t)s->c.a1_q30 * s->y1;
    acc -= (int64_t)s->c.a2_q30 * s->y2;
    acc = (acc >= 0) ? ((acc + (1LL << 29)) >> 30) : -(((-acc) + (1LL << 29)) >> 30);
    y = sat32(acc);
    s->x2 = s->x1; s->x1 = x;
    s->y2 = s->y1; s->y1 = y;
    return y;
}

int32_t okn_peq7_apply(uint8_t ch0, int32_t sample)
{
    uint8_t b;
    int32_t y = sample;
    if (ch0 >= OKN_PEQ7_CHANNELS || g_bypass[ch0]) return sample;
    for (b = 0; b < OKN_PEQ7_BANDS; ++b) {
        if (g_band[ch0][b].c.enabled) y = run_band(&g_band[ch0][b], y);
    }
    return y;
}

size_t okn_peq7_config_size(void) { return sizeof(config_snapshot_t); }

void okn_peq7_config_snapshot(void *dst, size_t cap)
{
    config_snapshot_t snap;
    uint8_t ch, b;
    if (!dst || cap < sizeof(snap)) return;
    memset(&snap, 0, sizeof(snap));
    memcpy(snap.bypass, g_bypass, sizeof(g_bypass));
    for (ch = 0; ch < OKN_PEQ7_CHANNELS; ++ch)
        for (b = 0; b < OKN_PEQ7_BANDS; ++b)
            snap.coeff[ch][b] = g_band[ch][b].c;
    memcpy(dst, &snap, sizeof(snap));
}
