#ifndef OKN_PEQ7_H
#define OKN_PEQ7_H
#include <stdint.h>
#include <stddef.h>

#define OKN_PEQ7_CHANNELS 7u
#define OKN_PEQ7_BANDS 15u
#define OKN_PEQ_Q 30u

typedef struct {
    uint8_t enabled;
    int32_t b0_q30;
    int32_t b1_q30;
    int32_t b2_q30;
    int32_t a1_q30;
    int32_t a2_q30;
} okn_peq_coeff_t;

void okn_peq7_init(void);
int okn_peq7_set(uint8_t ch0, uint8_t band0, const okn_peq_coeff_t *coeff);
int okn_peq7_get(uint8_t ch0, uint8_t band0, okn_peq_coeff_t *coeff);
void okn_peq7_set_channel_bypass(uint8_t ch0, uint8_t bypass);
uint8_t okn_peq7_get_channel_bypass(uint8_t ch0);
int32_t okn_peq7_apply(uint8_t ch0, int32_t sample);

/* For tests/audits: snapshots coefficients/bypass only, never filter history. */
size_t okn_peq7_config_size(void);
void okn_peq7_config_snapshot(void *dst, size_t cap);

#endif
