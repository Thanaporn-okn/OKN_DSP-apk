#ifndef OKN_GAIN7_H
#define OKN_GAIN7_H
#include <stdint.h>

#define OKN_GAIN7_CHANNELS 7u
#define OKN_GAIN7_MIN_HALF_DB (-140)
#define OKN_GAIN7_MAX_HALF_DB (12)
#define OKN_GAIN7_DEFAULT_HALF_DB (0)

void okn_gain7_init(void);
int okn_gain7_set_half_db(uint8_t ch0, int16_t half_db);
int16_t okn_gain7_get_half_db(uint8_t ch0);
uint16_t okn_gain7_get_q14(uint8_t ch0);
int32_t okn_gain7_apply(uint8_t ch0, int32_t sample);

#endif
