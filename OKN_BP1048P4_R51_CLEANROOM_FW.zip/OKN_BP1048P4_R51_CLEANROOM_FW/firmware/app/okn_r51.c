#include "okn_r51.h"
#include "okn_gain7.h"
#include "okn_peq7.h"
#include "okn_router7.h"
#include "okn_usb_proto.h"

static uint32_t g_sample_rate;

void okn_r51_init(uint32_t sample_rate)
{
    g_sample_rate = sample_rate ? sample_rate : OKN_R51_SAMPLE_RATE_DEFAULT;
    (void)g_sample_rate;
    okn_gain7_init();
    okn_peq7_init();
}

void okn_r51_process_stereo(int32_t left, int32_t right, okn_r51_frame7_t *out)
{
    okn_router7_process_stereo(left, right, out);
}

int okn_r51_handle_usb_report(const uint8_t in[OKN_R51_USB_REPORT_BYTES],
                              uint8_t out[OKN_R51_USB_REPORT_BYTES])
{
    return okn_usb_proto_handle(in, out);
}
