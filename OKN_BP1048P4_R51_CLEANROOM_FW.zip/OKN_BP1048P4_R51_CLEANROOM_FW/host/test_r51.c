#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "okn_r51.h"
#include "okn_gain7.h"
#include "okn_peq7.h"
#include "okn_router7.h"
#include "okn_usb_proto.h"

static void seal(uint8_t r[256]){ uint16_t c=okn_crc16_xmodem(r,254);r[254]=(uint8_t)c;r[255]=(uint8_t)(c>>8); }
static void init_req(uint8_t r[256],uint8_t cmd,uint16_t n){memset(r,0,256);memcpy(r,"OKN2",4);r[4]=1;r[5]=cmd;r[8]=1;r[10]=(uint8_t)n;r[11]=(uint8_t)(n>>8);seal(r);}

static void test_gain_independence(void)
{
    okn_r51_frame7_t o;
    int i;
    okn_r51_init(48000);
    assert(okn_gain7_set_half_db(3,-12)); /* CH4 = -6 dB */
    okn_r51_process_stereo(1000000,2000000,&o);
    assert(o.sample[0]==1000000);
    assert(o.sample[1]==2000000);
    assert(o.sample[3] > 500000-4000 && o.sample[3] < 500000+4000);
    assert(o.sample[4]==2000000);
    for(i=0;i<7;i++) if(i!=3) assert(okn_gain7_get_half_db((uint8_t)i)==0);
}

static void test_gain_does_not_touch_eq(void)
{
    size_t n;
    unsigned char *a,*b;
    okn_peq_coeff_t c={1,1073741824,0,0,0,0};
    okn_r51_init(48000); assert(okn_peq7_set(2,4,&c));
    n=okn_peq7_config_size();a=malloc(n);b=malloc(n);assert(a&&b);
    okn_peq7_config_snapshot(a,n);
    assert(okn_gain7_set_half_db(6,10));
    okn_peq7_config_snapshot(b,n);
    assert(memcmp(a,b,n)==0);
    free(a);free(b);
}

static void test_protocol(void)
{
    uint8_t in[256],out[256];
    init_req(in,OKN_CMD_SET_GAIN,3); in[12]=6; in[13]=(uint8_t)(-20 & 0xff); in[14]=(uint8_t)(((uint16_t)-20)>>8); seal(in);
    assert(okn_usb_proto_handle(in,out)); assert(out[7]==OKN_STATUS_OK); assert(okn_gain7_get_half_db(6)==-20);
    in[254]^=1; assert(okn_usb_proto_handle(in,out)); assert(out[7]==OKN_STATUS_BAD_CRC);
}

static void test_eq_identity_and_bypass(void)
{
    okn_r51_frame7_t a,b;
    okn_peq_coeff_t c={1,1073741824,0,0,0,0};
    okn_r51_init(48000);
    okn_r51_process_stereo(123456,-654321,&a);
    assert(okn_peq7_set(0,0,&c));
    okn_r51_process_stereo(123456,-654321,&b);
    assert(a.sample[0]==b.sample[0]);
}

static void test_plus6_saturates(void)
{
    int32_t y;
    okn_gain7_init(); assert(okn_gain7_set_half_db(0,12));
    y=okn_gain7_apply(0,2000000000); assert(y==INT32_MAX);
}

int main(void)
{
    test_gain_independence();
    test_gain_does_not_touch_eq();
    test_protocol();
    test_eq_identity_and_bypass();
    test_plus6_saturates();
    puts("R51 HOST TESTS: PASS");
    return 0;
}
