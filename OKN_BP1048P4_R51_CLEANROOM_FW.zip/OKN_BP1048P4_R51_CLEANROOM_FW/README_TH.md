# OKN BP1048P4 R51 Clean-room Firmware Core

เป้าหมาย: firmware DSP ใหม่สำหรับ BP1048P4 ที่มี **Gain/Volume อิสระ 7 ช่องจริง** โดย **ห้ามใช้ EQ ทำ Gain** และไม่ต้องแก้ฮาร์ดแวร์

สถานะ R51: **DSP/control source พร้อมทดสอบบน host; ยังไม่ใช่ไฟล์สำหรับแฟลชทับ stock firmware** เพราะ first-flash boot entry/recovery และ production image layout ยังไม่พิสูจน์จากบอร์ดจริง

สถาปัตยกรรมสัญญาณ: `Stereo source -> 7CH router -> 15-band PEQ/ch -> dedicated Gain/ch -> board sinks`.
Gain ใช้ Q2.14 -70..+6 dB step 0.5 dB. PEQ ใช้ coefficient Q2.30 และอยู่คนละ module/state กับ Gain.

ทดสอบบน PC/Linux:

```sh
make test
```

ออกแบบ coefficient PEQ:

```sh
python3 tools/peq_design.py --fs 48000 --f0 1000 --q 1.0 --gain-db 3
```

USB runtime protocol ใหม่ดู `docs/USB_PROTOCOL.md`. Target/flash gates ดู `docs/TARGET_PORT_GATE.md`.

สำคัญ: R51 ไม่มี guessed MMIO, ไม่มีคำสั่ง erase/program stock flash, และ `ENTER_BOOT` ถูกปิดด้วยค่าเริ่มต้น (`OKN_ENABLE_BOOT_JUMP=0`).
