package com.example.dspcontroller

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class MainActivity: Activity(){
 override fun onCreate(b:Bundle?){
  super.onCreate(b)
  val t=TextView(this)
  t.text="BP1048P4 7CH DSP Controller\n\nPhase 1 UI Main Screen\nBluetooth: Connected\nCH1 Front L\nCH2 Front R\nCH3 SUB\nCH4 Rear L\nCH5 Rear R\nCH6 AUX L\nCH7 AUX R"
  t.setTextColor(0xffffffff.toInt())
  t.setBackgroundColor(0xff101820.toInt())
  setContentView(t)
 }
}
