package com.okn.dsp

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/** V88 lifecycle-destroy persistent observability + READ-ONLY recreate probe launcher; V87 safety baseline carried unchanged. */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startActivity(Intent(this, UnifiedControlActivity::class.java))
        finish()
    }
}
