package com.okn.dsp.protocol

/**
 * V51 gate. Generic writes stay disabled. V45 scalar controls remain enabled.
 * V49/V50 runtime-proved the full 7CH EQ actuator map. V51 enables only the
 * guarded live PEAKING-band editor: one band write at a time, descriptor verify,
 * automatic rollback on verify failure, and no SaveParams ID7.
 * Presets, delay and unknown writes remain blocked.
 */
object WriteGate {
    const val enabled: Boolean = false
    const val controlledMasterVolumeProofEnabled: Boolean = true
    const val verifiedScalarControlsEnabled: Boolean = true
    const val controlledEqBandProofEnabled: Boolean = false
    const val eqBandRecoveryEnabled: Boolean = false
    const val finalEqWriteRestoreProofEnabled: Boolean = false
    const val sevenChannelEqMapProofEnabled: Boolean = true
    const val liveEqEditorEnabled: Boolean = true
}
