# OKN_BP1048P4_FW_V17

V17 is the content-bound target-qualification release built on the
GitHub-validated V16 baseline.

The wire frame remains Protocol V2. The portable DSP/control core keeps the V16
`GET_CAPABILITIES (0x06)` / `CAPABILITIES (0x76)` handshake unchanged.
V17 does not add a BP1048P4 programmer command and does not produce a target
`.bin`.

## V17 qualification evidence bundle

V16 required SHA256 + provenance + human review for each exact hardware claim.
V17 closes the remaining integrity gap: a claim is not qualified unless its
`artifact_id` resolves to a concrete regular file inside the declared evidence
bundle, that file is re-hashed successfully, its source/classification matches
the claim, and the artifact itself is reviewed.

The shipped `qualification_bundle_manifest.json` is intentionally empty and
locked. `qualification_evidence/README.txt` is informational only and is not an
evidence artifact.

Safety rules enforced by `tools/qualification_bundle.py`:

- evidence paths must be relative and remain inside the bundle root;
- path traversal is rejected;
- symlink evidence is rejected;
- declared SHA256 must match the actual file bytes;
- duplicate artifact IDs are rejected;
- unreviewed files never enter the policy-visible verified index;
- a claim cannot borrow the hash or ID of another artifact;
- filename/text matches never authorize BP1048P4/GoloPine hardware.

Hardware and mobile-flash authorization remain explicit and false. The exact
BP1048P4/GoloPine programmer transport, image format, linker/memory map, board
routing, backup/readback and Android host transport are still unverified.

See `docs/QUALIFICATION_BUNDLE_V17.md`, `docs/TARGET_QUALIFICATION_V16.md`, and
`docs/CAPABILITY_HANDSHAKE_V16.md`.
