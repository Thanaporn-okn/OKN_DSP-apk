V17 evidence bundle directory. Files placed here authorize nothing until listed, hash-verified, classified, and reviewed.
