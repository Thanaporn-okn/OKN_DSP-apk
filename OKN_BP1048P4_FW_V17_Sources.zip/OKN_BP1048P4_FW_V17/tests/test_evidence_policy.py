#!/usr/bin/env python3
from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
e=json.loads((root/'evidence_manifest.json').read_text())
t=json.loads((root/'target_port_manifest.json').read_text())
s=json.loads((root/'flash_session_manifest.json').read_text())
r=json.loads((root/'resource_requirements.json').read_text())
assert e['project_version']==17 and e['schema']==4
assert e['hardware_authorized'] is False
assert all(v is False for v in e['required_exact_evidence'].values())
assert t['hardware_flashable'] is False and t['mobile_flashable'] is False
assert all(v is False for v in t['evidence'].values())
assert t['public_family_evidence']['p4_use_authorized'] is False
assert s['execution_authorized'] is False and s['image']['path'] is None
assert r['target_memory']['exact_ram_capacity_verified'] is False
assert r['target_memory']['delay_arena_placement_verified'] is False
assert r['target_memory']['persistence_workspace_verified'] is False
for obs in e['observations']: assert obs['authorizes']==[]
print('ALL V17 EVIDENCE POLICY TESTS PASS')
