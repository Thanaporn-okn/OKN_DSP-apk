#!/usr/bin/env python3
from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'evidence_manifest.json').read_text())
errors=[]
if m.get('schema')!=4: errors.append('evidence schema must be 4')
if m.get('project_version')!=17: errors.append('project_version must be 17')
if m.get('target')!='BP1048P4' or m.get('board')!='GoloPine 7CH': errors.append('target/board mismatch')
if m.get('policy')!='FAIL_CLOSED_NO_INFERENCE': errors.append('policy mismatch')
if m.get('hardware_authorized') is not False: errors.append('hardware_authorized must be false')
req=m.get('required_exact_evidence',{})
if any(bool(v) for v in req.values()): errors.append('V17 exact evidence flags must all remain false')
prov=m.get('provenance',{})
if prov.get('previous_source_sha256')!='117007bca5eabc58dd49897e5096230c324eda280c46744510e460cb5118b676': errors.append('V16 source provenance mismatch')
if prov.get('validation_zip_sha256')!='c037aef8e7e55b053936bdbfa6c112c76e72a1a8134b02285deeb4c6157d4cb2': errors.append('V16 validation provenance mismatch')
if not any(o.get('id')=='v16-ci-validation' for o in m.get('observations',[])): errors.append('V16 CI observation missing')
for ob in m.get('observations',[]):
    if ob.get('authorizes') not in ([],None): errors.append('observations may not authorize hardware in V17')
if errors:
    [print('BLOCKED:',e) for e in errors]; sys.exit(1)
print('PASS: V17 evidence manifest is internally consistent and non-authorizing')
