OKN_DSP Version 7 - Phase 1 UI

Purpose
- Rebuild the interface from code to visually approach the supplied four-screen reference.
- The supplied reference image is NOT embedded or copied as an app background.
- Phase 2 DSP/BLE transport remains disabled until the Phase 1 UI is accepted.

Pages
- Home
- Mix
- Eq
- Crossover

V7 focus
- Correct visual differences observed in the running V6 recording (30499.mp4).
- Fix tall-screen density: V6 stretched outer cards but left many internal controls/text too small.
- Give the top branding a safe top margin so OKN_DSP is not clipped in edge-to-edge capture.
- Move page content lower to match the visual spacing of the supplied reference.
- Rebalance the Home device/input/quick-action card proportions.
- Scale Mix knobs and slider handles with their cards so controls fill the available space.
- Remove the large unused vertical gap on the Eq page by allowing graph/controls/output to consume the full content region.
- Increase Crossover graph/settings/delay density and smooth the response curves.
- Keep all sliders, knobs, EQ points and crossover controls updating immediately while dragging.
- Preserve the stable development signing identity for update-in-place builds.

Signing / update path
V3 introduced a stable DEVELOPMENT signing key. V4, V5, V6 and V7 preserve the same key, so V3 -> V4 -> V5 -> V6 -> V7 -> later development builds can update in place.
If moving from V1/V2 and Android reports an incompatible update, uninstall the old V1/V2 app once. V3 and later use the stable key.

Build
Use OKN_DSP_AutoBuild.yml. The workflow automatically selects the highest OKN_DSP_V*_Sources.zip in the repository root, verifies Sources/SHA256SUMS.txt, verifies the signing key, builds the signed debug APK and uploads the APK artifact.
