OKN_DSP V7 — PHASE 1 UI MATCHING PASS

Goal
- Match the uploaded 4-screen reference more closely without using it as a background.
- Keep all Phase-1 controls interactive and graph updates event-driven.
- Preserve package com.okn.dsp and the fixed signing key from V5/V6 for in-place updates.

V7 visual changes
- Header/logo/Connected pill resized to match the reference hierarchy.
- Home device/status card now follows Connected / Signal Strength / Battery / Firmware / Device ID layout.
- Selected input cards receive a brighter cyan border/glow.
- Panels use a richer dark-blue gradient and brighter borders.
- EQ graph now uses 11 log-frequency labels, +/-6 dB guides, 15 colored connected band points, plus a faint Q-aware DSP response layer.
- Crossover graph adds cutoff markers and the delay section adds working ms/cm/in unit buttons.
- Existing real-time sliders, knobs, EQ, crossover, delay, presets and responsive sizing remain intact.

Phase 2 hardware transport is intentionally NOT implemented in V7.
