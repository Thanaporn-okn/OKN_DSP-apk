OKN_DSP V7 — SMOOTH REALTIME / MASTER ANTI-STUTTER
==================================================

WHY V7 EXISTS
V6 proved that the physical DSP really changes sound from the OKN_DSP Home/EQ UI.
Real-device testing then exposed an acoustic defect while dragging Master Volume:
the sound could stutter/pump and alternate louder/quieter because V6 allowed large
latest-target gain jumps to reach the DSP at the normal BLE queue pace.

V7 FIX — UI INSTANT, HARDWARE BOUNDED RAMP
- The visible slider/value still follows the finger immediately.
- Verified scalar hardware writes no longer jump directly to every sampled UI value.
- Each scalar keeps one latest target only.
- The DSP approaches that target only after the previous GATT write callback succeeds.
- Master/Bass/global dB controls use adaptive 0.5..2.0 dB steps.
- Bass Cutoff uses adaptive 3..12 Hz steps.
- Normal scalar pacing is >=90 ms between successful steps.
- TrebleBoost keeps the stricter <=0.5 dB step and >=96 ms profile.
- A stale pending scalar step is replaced before encryption; an in-flight command is
  never cancelled, preserving exact GATT callback order and continuous AES-CFB8 state.
- EQ realtime transport remains on the existing one-inflight/latest-target queue.

VERIFIED CONTROL PATH RETAINED FROM V6
BLE scan/connect
  -> service AB00
  -> AB02 notification enable
  -> AUTH16 631C062443FD3844558001F3EDA0CCF8 on AB01
  -> decode 32-byte auth response
  -> derive current 16-byte RandKey
  -> independent continuous AES/CFB8/NoPadding TX/RX streams, IV=01 x 16
  -> encrypted Device Description request plaintext 661C0624
  -> collect/decrypt 0x86 header + 0x82 continuation JSON
  -> Health Gate: 7 known scalars + 105 EQ records + >=4 sensors
  -> READY
  -> encrypted UFE WRITE_ACTUATOR (0x57) writes on AB01

VERIFIED HOME HARDWARE ACTUATORS
ID 2  MasterVolume       -70 .. +6 dB
ID 8  BassVolume         -70 .. +6 dB
ID 9  BassCutoff          20 .. 250 Hz
ID 10 BassBoost          -12 .. +12 dB
ID 13 MiddleBoost        -12 .. +12 dB
ID 11 TrebleBoost        -12 .. +12 dB
(ID 3 RemindSoundVolume remains verified but is not exposed by the supplied Home UI.)

VERIFIED EQ HARDWARE
CH1..CH7 actuator IDs = 4,5,6,14,15,16,17
15 records per channel, 48 bytes per record.
Only live Device Description records that are PEAKING type=12 with the verified field
shape are writable. The six supplied-UI points map dynamically to the nearest six
verified PEAKING records for each channel.

LOCKED / NOT GUESSED
- per-channel Fader / Mute / Phase hardware packets
- Crossover hardware packets
- Delay hardware packets
- hardware Preset recall/write packet
- generic/unknown actuator writes

UPDATE SIGNING
V7 keeps the exact V6/V5 signing keystore bytes and applicationId com.okn.dsp.
Do not regenerate the keystore in future versions.
