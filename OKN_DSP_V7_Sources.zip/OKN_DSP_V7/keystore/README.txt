OKN_DSP fixed update signing key (introduced in V5)

File: OKN_DSP_update.jks
Alias: okn_dsp
Store password: OKN_DSP_2026
Key password: OKN_DSP_2026

Certificate SHA-256:
8F:9E:7F:4F:0F:18:09:1F:41:7A:2D:0D:51:8C:7B:CF:A8:FA:C8:6D:08:6F:F2:05:A2:72:47:D9:C0:EF:E0:36

DO NOT regenerate or replace this keystore in V7+ or Android updates will fail again.
This bundled key is intended for this direct-sideload project workflow, not Play Store production security.
