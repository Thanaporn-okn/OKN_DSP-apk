# OKN DSP V7 — Phase 1 compiler fix

V7 is a new version created from V6 after the GitHub Actions compile failure. It does not overwrite V6.

## V7 fix
- Fixed `DspView.java` compilation errors caused by unresolved `BuildConfig.VERSION_NAME` references.
- The UI now reads the installed application version at runtime through Android `PackageManager`, so it does not depend on AGP BuildConfig generation.
- Home > Firmware Status and the Firmware Status detail message both use the same runtime version source.
- Android version updated to `7.0.0` / `1007`.
- All V6 EQ color work remains intact: per-channel colors, 15-band spectrum points, selected-band highlight, cyan Frequency, purple Q, orange Gain Band, red Reset EQ, themes, presets and persistence.
- All controls remain code-rendered; no screenshot/image is used as a background.
- Phase 2 DSP hardware transport remains intentionally unimplemented until the real DSP protocol/control data is supplied.

Build input: `OKN_DSP_V7_Sources.zip` using the existing reusable `OKN_DSP_AutoBuild.yml`.
