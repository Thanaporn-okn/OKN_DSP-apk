package com.okn.dsp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class DspView extends View {
    public interface Host {
        void requestThemePicker(int currentTheme);
        void requestPresetName(String currentName);
        void requestPresetPicker(String currentName);
        void requestDeletePreset(String currentName);
        void showMessage(String message);
    }

    private final Host host;
    private final DspState state;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    // V2: lock Canvas typography to Android's bundled Roboto instead of the
    // user-selected Samsung/system font.
    private final Typeface normal = AppFonts.REGULAR;
    private final Typeface medium = AppFonts.MEDIUM;
    private final Typeface bold = AppFonts.BOLD;
    private final float density;

    private int bg, card, cardAlt, text, sub, line, accent, accentSoft, green, orange, purple, cyan, red;
    private final List<Hit> hits = new ArrayList<>();
    private final List<SliderHit> sliders = new ArrayList<>();
    private final float[] scrollY = new float[3];
    private final float[] maxScroll = new float[3];
    private SliderHit activeSlider;
    private float downX, downY, startScroll;
    private boolean scrolling;
    private float contentTop, navTop;

    private static final int SL_MASTER = 1;
    private static final int SL_BASS = 2;
    private static final int SL_CUTOFF = 3;
    private static final int SL_CHANNEL = 4;
    private static final int SL_EQ_FREQ = 5;
    private static final int SL_EQ_Q = 6;
    private static final int SL_EQ_GAIN = 7;

    public DspView(Context context) {
        super(context);
        if (!(context instanceof Host)) throw new IllegalArgumentException("Host Activity required");
        host = (Host) context;
        state = new DspState(context);
        density = getResources().getDisplayMetrics().density;
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        setFocusable(true);
        setClickable(true);
    }

    public int getThemeIndex() {
        return state.theme;
    }

    public void setThemeIndex(int index) {
        state.setTheme(index);
        invalidate();
    }

    public void flushState() {
        state.persistAll(true);
    }

    /**
     * Reads the installed package version at runtime. This deliberately avoids
     * BuildConfig because AGP 8 projects can have BuildConfig generation
     * disabled, which caused the V6 GitHub Actions javac failure.
     */
    private String appVersionName() {
        try {
            String version = getContext().getPackageManager()
                    .getPackageInfo(getContext().getPackageName(), 0).versionName;
            return (version == null || version.trim().isEmpty()) ? "7.0.0" : version;
        } catch (Exception ignored) {
            return "7.0.0";
        }
    }

    public void savePreset(String name) {
        state.savePreset(name);
        host.showMessage("Saved preset: " + state.getDisplayPresetName());
        invalidate();
    }

    public String[] getPresetNames() {
        return state.getPresetNames();
    }

    public void selectPreset(String name) {
        if (state.selectPreset(name)) {
            state.persistAll(true);
            invalidate();
        }
    }

    public void deletePreset(String name) {
        if (state.deletePreset(name)) {
            state.persistAll(true);
            host.showMessage("Deleted preset: " + name);
        } else {
            host.showMessage("Preset not found");
        }
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        updatePalette();
        c.drawColor(bg);
        hits.clear();
        sliders.clear();

        float w = getWidth();
        float h = getHeight();
        contentTop = dp(82);
        navTop = h - dp(84);

        drawHeader(c, w);

        int save = c.save();
        c.clipRect(0, contentTop, w, navTop - dp(4));
        if (state.page == 0) drawHome(c, w);
        else if (state.page == 1) drawMix(c, w);
        else drawEq(c, w);
        c.restoreToCount(save);

        drawBottomNav(c, w, h);
    }

    private void updatePalette() {
        if (state.theme == 0) {
            bg = 0xFFF4F7FB;
            card = 0xFFFFFFFF;
            cardAlt = 0xFFF0F4F9;
            text = 0xFF0C1220;
            sub = 0xFF79869A;
            line = 0xFFE4EAF2;
            accent = 0xFF138CF5;
            accentSoft = 0xFFE7F2FF;
        } else if (state.theme == 1) {
            bg = 0xFF0D1320;
            card = 0xFF151E2D;
            cardAlt = 0xFF1B2638;
            text = 0xFFF3F7FD;
            sub = 0xFF9EABBE;
            line = 0xFF28364A;
            accent = 0xFF2E9BFF;
            accentSoft = 0xFF142C45;
        } else {
            bg = 0xFF050A13;
            card = 0xFF0C1421;
            cardAlt = 0xFF101C2D;
            text = 0xFFF6F8FC;
            sub = 0xFF8E9AAF;
            line = 0xFF1D2B3E;
            accent = 0xFF21B7FF;
            accentSoft = 0xFF09253A;
        }
        green = 0xFF25C85A;
        orange = 0xFFFF9D24;
        purple = 0xFF7B5CFF;
        cyan = 0xFF16C4D7;
        red = 0xFFF25579;
    }

    private void drawHeader(Canvas c, float w) {
        float left = contentLeft(w);
        float right = contentRight(w);
        String title = state.page == 0 ? "OKN DSP" : state.page == 1 ? "Mix" : "Eq";
        String subtitle = state.page == 0 ? "DSP Controller" : state.page == 1 ? "Channel and bass controls" : "15-band equalizer";

        drawText(c, title, left, dp(34), dp(state.page == 0 ? 28 : 32), text, bold, Paint.Align.LEFT);
        drawText(c, subtitle, left, dp(58), dp(16), sub, normal, Paint.Align.LEFT);

        float r = dp(21);
        float cy = dp(37);
        float searchX = right - dp(70);
        float menuX = right - dp(22);
        drawCircleButton(c, searchX, cy, r);
        drawSearchIcon(c, searchX, cy);
        addHit("search", new RectF(searchX - r, cy - r, searchX + r, cy + r));

        drawCircleButton(c, menuX, cy, r);
        drawOverflowIcon(c, menuX, cy);
        addHit("theme", new RectF(menuX - r, cy - r, menuX + r, cy + r));
    }

    private void drawHome(Canvas c, float w) {
        float left = contentLeft(w), right = contentRight(w);
        float y = contentTop + dp(8) - scrollY[0];
        float fullW = right - left;

        RectF statusCard = new RectF(left, y, right, y + dp(120));
        drawRoundRect(c, statusCard, dp(24), state.theme == 0 ? 0xFFF0FFF4 : card);
        drawCircle(c, left + dp(48), y + dp(59), dp(31), withAlpha(green, 40));
        drawCircle(c, left + dp(48), y + dp(59), dp(24), green);
        drawCheck(c, left + dp(48), y + dp(59), 0xFFFFFFFF);
        drawText(c, "SYSTEM STATUS", left + dp(92), y + dp(40), dp(13), sub, medium, Paint.Align.LEFT);
        drawText(c, "System Ready", left + dp(92), y + dp(68), dp(22), text, bold, Paint.Align.LEFT);
        drawText(c, "All devices connected and running normally.", left + dp(92), y + dp(91), dp(14), sub, normal, Paint.Align.LEFT);
        drawChevron(c, right - dp(24), y + dp(60), sub);
        addHit("homeSystem", statusCard);

        y += dp(146);
        drawText(c, "Connection & Status", left + dp(4), y, dp(22), text, bold, Paint.Align.LEFT);
        drawText(c, "All Good", right - dp(24), y, dp(15), accent, medium, Paint.Align.RIGHT);
        drawCircle(c, right - dp(10), y - dp(5), dp(5), green);
        y += dp(18);

        String[] names = {"Bluetooth", "DSP Device", "Audio Input", "Amplifier Link", "Preset Sync", "Firmware Status"};
        String[] details = {"Phone connected", "OKN DSP-8 Pro", "AUX (Analog)", "External Amplifier", "User presets", "v" + appVersionName() + " (Phase 1)"};
        String[] statuses = {"Connected", "Connected", "Active", "Connected", "Synced", "Up to date"};
        int[] iconColors = {accent, purple, orange, red, cyan, purple};
        for (int i = 0; i < names.length; i++) {
            y += dp(12);
            RectF row = new RectF(left, y, right, y + dp(66));
            drawRoundRect(c, row, dp(18), card);
            drawCircle(c, left + dp(35), y + dp(33), dp(23), withAlpha(iconColors[i], state.theme == 0 ? 34 : 70));
            drawMiniHomeIcon(c, i, left + dp(35), y + dp(33), iconColors[i]);
            drawText(c, names[i], left + dp(72), y + dp(28), dp(17), text, medium, Paint.Align.LEFT);
            drawText(c, details[i], left + dp(72), y + dp(48), dp(13), sub, normal, Paint.Align.LEFT);
            int stColor = i == 2 || i == 5 ? accent : green;
            drawCircle(c, right - dp(116), y + dp(33), dp(5), stColor);
            drawText(c, statuses[i], right - dp(28), y + dp(38), dp(14), stColor, medium, Paint.Align.RIGHT);
            drawChevron(c, right - dp(14), y + dp(33), sub);
            addHit("homeRow" + i, row);
            y += dp(66);
        }

        y += dp(16);
        RectF quick = new RectF(left, y, right, y + dp(78));
        drawRoundRect(c, quick, dp(20), card);
        drawCircle(c, left + dp(37), y + dp(39), dp(24), accentSoft);
        drawEqBarsIcon(c, left + dp(37), y + dp(39), accent);
        drawText(c, "Quick Control", left + dp(76), y + dp(34), dp(18), text, medium, Paint.Align.LEFT);
        drawText(c, "Adjust volume, presets and more", left + dp(76), y + dp(55), dp(13), sub, normal, Paint.Align.LEFT);
        drawChevron(c, right - dp(18), y + dp(39), sub);
        addHit("homeQuick", quick);
        y += dp(90);

        setContentHeight(0, y + scrollY[0] - contentTop);
    }

    private void drawMix(Canvas c, float w) {
        float left = contentLeft(w), right = contentRight(w);
        float y = contentTop + dp(8) - scrollY[1];

        float globalH = dp(252);
        RectF global = new RectF(left, y, right, y + globalH);
        drawRoundRect(c, global, dp(22), card);
        drawText(c, "Global", left + dp(18), y + dp(31), dp(22), text, bold, Paint.Align.LEFT);
        drawText(c, "Overall output and bass settings", right - dp(18), y + dp(29), dp(12), sub, normal, Paint.Align.RIGHT);
        y += dp(52);
        drawMixSliderRow(c, left, right, y, "Master Volume", "VOL", accent, state.masterVolume,
                String.format(Locale.US, "%.0f dB", state.masterVolume), -60f, 0f, SL_MASTER, -1);
        y += dp(64);
        drawMixSliderRow(c, left, right, y, "Bass Volume", "BASS", orange, state.bassVolume,
                String.format(Locale.US, "%+.1f dB", state.bassVolume).replace("+", ""), -12f, 12f, SL_BASS, -1);
        y += dp(64);
        drawMixSliderRow(c, left, right, y, "Bass Cutoff", "Hz", purple, state.bassCutoff,
                String.format(Locale.US, "%.0f Hz", state.bassCutoff), 20f, 200f, SL_CUTOFF, -1);
        y += dp(78);

        float channelsH = dp(54 + DspState.CHANNELS * 64);
        RectF channels = new RectF(left, y, right, y + channelsH);
        drawRoundRect(c, channels, dp(22), card);
        drawText(c, "Channels", left + dp(18), y + dp(33), dp(22), text, bold, Paint.Align.LEFT);
        drawText(c, "Individual channel levels", right - dp(18), y + dp(31), dp(12), sub, normal, Paint.Align.RIGHT);
        y += dp(54);
        int[] colors = {accent, green, orange, red, purple, cyan, purple};
        for (int ch = 0; ch < DspState.CHANNELS; ch++) {
            if (ch > 0) drawLine(c, left + dp(56), y, right - dp(12), y, line, dp(1));
            drawCircle(c, left + dp(34), y + dp(32), dp(20), colors[ch]);
            drawText(c, Integer.toString(ch + 1), left + dp(34), y + dp(39), dp(17), 0xFFFFFFFF, bold, Paint.Align.CENTER);
            drawText(c, "Volume Ch" + (ch + 1), left + dp(72), y + dp(25), dp(15), text, medium, Paint.Align.LEFT);
            float trackX = left + dp(72), trackW = Math.max(dp(100), right - left - dp(190));
            float trackY = y + dp(43);
            drawSlider(c, trackX, trackY, trackW, state.channelVolume[ch], -12f, 12f,
                    SL_CHANNEL, ch, false);
            RectF pill = new RectF(right - dp(88), y + dp(14), right - dp(14), y + dp(50));
            drawValuePill(c, pill, String.format(Locale.US, "%.0f dB", state.channelVolume[ch]));
            y += dp(64);
        }
        y += dp(16);
        setContentHeight(1, y + scrollY[1] - contentTop);
    }

    private void drawMixSliderRow(Canvas c, float left, float right, float y, String title, String iconText,
                                  int iconColor, float value, String valueText, float min, float max,
                                  int sliderType, int index) {
        drawCircle(c, left + dp(34), y + dp(31), dp(22), withAlpha(iconColor, state.theme == 0 ? 32 : 70));
        drawText(c, iconText, left + dp(34), y + dp(36), dp(iconText.length() > 2 ? 8 : 11), iconColor, bold, Paint.Align.CENTER);
        drawText(c, title, left + dp(72), y + dp(24), dp(15), text, medium, Paint.Align.LEFT);
        float trackX = left + dp(72), trackW = Math.max(dp(100), right - left - dp(190));
        drawSlider(c, trackX, y + dp(42), trackW, value, min, max, sliderType, index, false);
        RectF pill = new RectF(right - dp(88), y + dp(12), right - dp(14), y + dp(50));
        drawValuePill(c, pill, valueText);
        drawLine(c, left + dp(16), y + dp(63), right - dp(16), y + dp(63), line, dp(1));
    }

    private void drawEq(Canvas c, float w) {
        float left = contentLeft(w), right = contentRight(w);
        float y = contentTop + dp(7) - scrollY[2];
        float gap = dp(7);
        float chipW = (right - left - gap * 6f) / 7f;
        for (int ch = 0; ch < 7; ch++) {
            RectF chip = new RectF(left + ch * (chipW + gap), y, left + ch * (chipW + gap) + chipW, y + dp(36));
            int channelColor = eqChannelColor(ch);
            boolean selected = ch == state.selectedChannel;
            drawRoundRect(c, chip, dp(18), selected ? channelColor
                    : withAlpha(channelColor, state.theme == 0 ? 24 : 48));
            drawText(c, "Ch" + (ch + 1), chip.centerX(), chip.centerY() + dp(5), dp(13),
                    selected ? 0xFFFFFFFF : channelColor, medium, Paint.Align.CENTER);
            addHit("chip" + ch, chip);
        }
        y += dp(52);

        RectF graphCard = new RectF(left, y, right, y + dp(326));
        drawRoundRect(c, graphCard, dp(22), card);
        int activeChannelColor = eqChannelColor(state.selectedChannel);
        drawRoundRect(c, new RectF(left + dp(18), y + dp(14), left + dp(23), y + dp(52)), dp(3), activeChannelColor);
        drawText(c, "Channel " + (state.selectedChannel + 1), left + dp(32), y + dp(30), dp(20), activeChannelColor, bold, Paint.Align.LEFT);
        drawText(c, channelPositionName(state.selectedChannel) + "  •  15-band EQ", left + dp(32), y + dp(51), dp(13), sub, normal, Paint.Align.LEFT);
        RectF reset = new RectF(right - dp(110), y + dp(14), right - dp(14), y + dp(48));
        drawRoundRect(c, reset, dp(17), withAlpha(red, state.theme == 0 ? 22 : 42));
        drawText(c, "↻  Reset EQ", reset.centerX(), reset.centerY() + dp(5), dp(12), red, medium, Paint.Align.CENTER);
        addHit("resetEq", reset);
        drawEqGraph(c, left + dp(42), y + dp(72), right - dp(18), y + dp(288));
        y += dp(342);

        RectF controlCard = new RectF(left, y, right, y + dp(284));
        drawRoundRect(c, controlCard, dp(22), card);
        int activeBandColor = eqBandColor(state.selectedBand);
        drawCircle(c, left + dp(34), y + dp(35), dp(21), activeBandColor);
        drawText(c, Integer.toString(state.selectedBand + 1), left + dp(34), y + dp(42), dp(20), 0xFFFFFFFF, bold, Paint.Align.CENTER);
        drawText(c, "Band " + (state.selectedBand + 1), left + dp(72), y + dp(29), dp(18), activeBandColor, bold, Paint.Align.LEFT);
        drawText(c, "Adjust the selected band parameters", left + dp(72), y + dp(48), dp(12), sub, normal, Paint.Align.LEFT);
        RectF prev = new RectF(right - dp(92), y + dp(14), right - dp(55), y + dp(51));
        RectF next = new RectF(right - dp(47), y + dp(14), right - dp(10), y + dp(51));
        drawRoundRect(c, prev, dp(18), cardAlt);
        drawRoundRect(c, next, dp(18), cardAlt);
        drawChevronLeft(c, prev.centerX(), prev.centerY(), text);
        drawChevron(c, next.centerX(), next.centerY(), text);
        addHit("bandPrev", prev);
        addHit("bandNext", next);

        int ch = state.selectedChannel, b = state.selectedBand;
        float rowY = y + dp(72);
        drawEqSliderRow(c, left, right, rowY, "Frequency", "F", DspState.formatHz(state.eqFreq[ch][b]),
                state.eqFreq[ch][b], 20f, 20000f, SL_EQ_FREQ, true, "20 Hz", "20 kHz", cyan);
        rowY += dp(68);
        drawEqSliderRow(c, left, right, rowY, "Q (Quality Factor)", "Q", String.format(Locale.US, "%.1f", state.eqQ[ch][b]),
                state.eqQ[ch][b], 0.1f, 10f, SL_EQ_Q, false, "0.1", "10.0", purple);
        rowY += dp(68);
        drawEqSliderRow(c, left, right, rowY, "Gain Band", "dB", String.format(Locale.US, "%+.1f dB", state.eqGain[ch][b]).replace("+", "+"),
                state.eqGain[ch][b], -12f, 12f, SL_EQ_GAIN, false, "-12 dB", "+12 dB", orange);
        y += dp(300);

        RectF presetCard = new RectF(left, y, right, y + dp(205));
        drawRoundRect(c, presetCard, dp(22), card);
        drawCircle(c, left + dp(35), y + dp(35), dp(22), withAlpha(cyan, state.theme == 0 ? 34 : 70));
        drawText(c, "P", left + dp(35), y + dp(41), dp(17), cyan, bold, Paint.Align.CENTER);
        drawText(c, "Presets", left + dp(72), y + dp(29), dp(18), text, bold, Paint.Align.LEFT);
        drawText(c, "Save, load and delete EQ presets", left + dp(72), y + dp(49), dp(12), sub, normal, Paint.Align.LEFT);

        RectF nameBox = new RectF(left + dp(18), y + dp(68), right - dp(148), y + dp(110));
        drawRoundRect(c, nameBox, dp(12), cardAlt);
        String saveName = "New preset name…";
        drawText(c, saveName, nameBox.left + dp(12), nameBox.centerY() + dp(5), dp(13), sub, normal, Paint.Align.LEFT);
        addHit("presetName", nameBox);
        RectF save = new RectF(right - dp(136), y + dp(68), right - dp(18), y + dp(110));
        drawRoundRect(c, save, dp(13), accent);
        drawText(c, "Save Preset", save.centerX(), save.centerY() + dp(5), dp(13), 0xFFFFFFFF, medium, Paint.Align.CENTER);
        addHit("savePreset", save);

        drawText(c, "Saved Presets", left + dp(18), y + dp(135), dp(12), sub, normal, Paint.Align.LEFT);
        RectF loadName = new RectF(left + dp(18), y + dp(145), right - dp(148), y + dp(187));
        drawRoundRect(c, loadName, dp(12), cardAlt);
        drawText(c, state.getDisplayPresetName(), loadName.left + dp(12), loadName.centerY() + dp(5), dp(13), text, normal, Paint.Align.LEFT);
        drawText(c, "▼", loadName.right - dp(14), loadName.centerY() + dp(4), dp(10), sub, medium, Paint.Align.CENTER);
        addHit("pickPreset", loadName);

        float actionLeft = right - dp(136);
        float actionGap = dp(6);
        float actionW = (dp(118) - actionGap) / 2f;
        RectF load = new RectF(actionLeft, y + dp(145), actionLeft + actionW, y + dp(187));
        drawRoundRect(c, load, dp(12), cardAlt);
        drawText(c, "Load", load.centerX(), load.centerY() + dp(5), dp(12), text, medium, Paint.Align.CENTER);
        addHit("loadPreset", load);
        RectF delete = new RectF(load.right + actionGap, y + dp(145), right - dp(18), y + dp(187));
        drawRoundRect(c, delete, dp(12), withAlpha(red, state.theme == 0 ? 24 : 45));
        drawText(c, "Delete", delete.centerX(), delete.centerY() + dp(5), dp(11), red, medium, Paint.Align.CENTER);
        addHit("deletePreset", delete);
        y += dp(221);

        setContentHeight(2, y + scrollY[2] - contentTop);
    }

    private void drawEqSliderRow(Canvas c, float left, float right, float y, String title, String icon,
                                 String valueText, float value, float min, float max, int type,
                                 boolean logScale, String minLabel, String maxLabel, int rowColor) {
        drawCircle(c, left + dp(32), y + dp(26), dp(18), withAlpha(rowColor, state.theme == 0 ? 28 : 58));
        drawText(c, icon, left + dp(32), y + dp(31), dp(icon.length() > 1 ? 9 : 14), rowColor, bold, Paint.Align.CENTER);
        drawText(c, title, left + dp(59), y + dp(19), dp(13), text, medium, Paint.Align.LEFT);
        RectF pill = new RectF(right - dp(92), y + dp(3), right - dp(17), y + dp(31));
        drawRoundRect(c, pill, dp(10), withAlpha(rowColor, state.theme == 0 ? 22 : 44));
        drawText(c, valueText, pill.centerX(), pill.centerY() + dp(5), dp(12), rowColor, medium, Paint.Align.CENTER);
        float tx = left + dp(58), tw = right - tx - dp(18);
        drawSliderColored(c, tx, y + dp(40), tw, value, min, max, type, state.selectedBand, logScale, rowColor);
        drawText(c, minLabel, tx, y + dp(60), dp(10), sub, normal, Paint.Align.LEFT);
        drawText(c, maxLabel, tx + tw, y + dp(60), dp(10), sub, normal, Paint.Align.RIGHT);
    }

    private void drawEqGraph(Canvas c, float x1, float y1, float x2, float y2) {
        float plotTop = y1 + dp(4), plotBottom = y2 - dp(18);
        float plotLeft = x1, plotRight = x2;
        int ch = state.selectedChannel;

        int[] dbs = {12, 6, 0, -6, -12};
        for (int db : dbs) {
            float yy = map(db, 12, -12, plotTop, plotBottom);
            drawLine(c, plotLeft, yy, plotRight, yy, line, dp(0.8f));
            drawText(c, (db > 0 ? "+" : "") + db, plotLeft - dp(12), yy + dp(4), dp(9), sub, normal, Paint.Align.RIGHT);
        }
        float[] ticks = {20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000};
        for (float f : ticks) {
            float xx = freqToX(f, plotLeft, plotRight);
            drawLine(c, xx, plotTop, xx, plotBottom, line, dp(0.6f));
            String label = f >= 1000 ? ((int)(f / 1000)) + "K" : Integer.toString((int)f);
            drawText(c, label, xx, plotBottom + dp(15), dp(9), sub, normal, Paint.Align.CENTER);
        }

        int b = state.selectedBand;
        int channelColor = eqChannelColor(ch);
        int selectedBandColor = eqBandColor(b);
        float selectedX = freqToX(state.eqFreq[ch][b], plotLeft, plotRight);
        RectF hi = new RectF(selectedX - dp(12), plotTop, selectedX + dp(12), plotBottom);
        p.setColor(withAlpha(selectedBandColor, state.theme == 0 ? 24 : 42));
        c.drawRect(hi, p);
        float zeroY = map(0, 12, -12, plotTop, plotBottom);
        drawLine(c, plotLeft, zeroY, plotRight, zeroY, withAlpha(channelColor, state.theme == 0 ? 80 : 120), dp(1.1f));

        path.reset();
        int samples = 150;
        for (int i = 0; i < samples; i++) {
            float t = i / (float) (samples - 1);
            float f = (float) (20.0 * Math.pow(1000.0, t));
            float resp = eqResponse(ch, f);
            float xx = plotLeft + (plotRight - plotLeft) * t;
            float yy = map(resp, 12, -12, plotTop, plotBottom);
            if (i == 0) path.moveTo(xx, yy); else path.lineTo(xx, yy);
        }
        stroke.setColor(channelColor);
        stroke.setStrokeWidth(dp(2.0f));
        stroke.setStyle(Paint.Style.STROKE);
        c.drawPath(path, stroke);

        for (int band = 0; band < DspState.BANDS; band++) {
            float f = state.eqFreq[ch][band];
            float resp = eqResponse(ch, f);
            float xx = freqToX(f, plotLeft, plotRight);
            float yy = map(resp, 12, -12, plotTop, plotBottom);
            int bandColor = eqBandColor(band);
            if (band == b) {
                drawCircle(c, xx, yy, dp(9), withAlpha(bandColor, 90));
                drawCircle(c, xx, yy, dp(6.2f), bandColor);
                stroke.setColor(state.theme == 0 ? 0xFFFFFFFF : text);
                stroke.setStrokeWidth(dp(1.5f));
                c.drawCircle(xx, yy, dp(7.2f), stroke);
            } else {
                drawCircle(c, xx, yy, dp(4.3f), bandColor);
                stroke.setColor(card);
                stroke.setStrokeWidth(dp(1.2f));
                c.drawCircle(xx, yy, dp(4.8f), stroke);
            }
        }
        drawText(c, "(dB)", plotLeft - dp(12), plotBottom + dp(16), dp(9), sub, normal, Paint.Align.RIGHT);
        drawText(c, "(Hz)", plotRight, plotBottom + dp(31), dp(9), sub, normal, Paint.Align.RIGHT);
    }

    private float eqResponse(int ch, float frequency) {
        double logF = Math.log(frequency);
        double sum = 0.0;
        for (int b = 0; b < DspState.BANDS; b++) {
            double fc = Math.max(20.0, state.eqFreq[ch][b]);
            double q = Math.max(0.1, state.eqQ[ch][b]);
            double width = 0.30 / Math.sqrt(q);
            double d = (logF - Math.log(fc)) / width;
            sum += state.eqGain[ch][b] * Math.exp(-0.5 * d * d);
        }
        return clamp((float) sum, -12f, 12f);
    }

    private void drawBottomNav(Canvas c, float w, float h) {
        float left = contentLeft(w), right = contentRight(w);
        float top = h - dp(76), bottom = h - dp(8);
        RectF panel = new RectF(left, top, right, bottom);
        drawRoundRect(c, panel, dp(22), card);
        float itemW = panel.width() / 3f;
        String[] labels = {"Home", "Mix", "Eq"};
        for (int i = 0; i < 3; i++) {
            float l = panel.left + i * itemW;
            RectF item = new RectF(l + dp(5), top + dp(5), l + itemW - dp(5), bottom - dp(5));
            boolean selected = state.page == i;
            if (selected) drawRoundRect(c, item, dp(18), accentSoft);
            float cx = item.centerX(), iconY = top + dp(24);
            if (i == 0) drawHomeIcon(c, cx, iconY, selected ? accent : sub);
            else if (i == 1) drawMixIcon(c, cx, iconY, selected ? accent : sub);
            else drawEqBarsIcon(c, cx, iconY, selected ? accent : sub);
            drawText(c, labels[i], cx, bottom - dp(10), dp(13), selected ? accent : sub,
                    selected ? medium : normal, Paint.Align.CENTER);
            addHit("nav" + i, item);
        }
    }

    private void drawSlider(Canvas c, float x, float y, float width, float value, float min, float max,
                            int type, int index, boolean logScale) {
        float t;
        if (logScale) {
            t = (float) ((Math.log(value) - Math.log(min)) / (Math.log(max) - Math.log(min)));
        } else {
            t = (value - min) / (max - min);
        }
        t = clamp(t, 0f, 1f);
        RectF track = new RectF(x, y - dp(2.5f), x + width, y + dp(2.5f));
        drawRoundRect(c, track, dp(3), state.theme == 0 ? 0xFFDCE4EF : line);
        RectF fill = new RectF(x, y - dp(2.5f), x + width * t, y + dp(2.5f));
        drawRoundRect(c, fill, dp(3), accent);
        float knobX = x + width * t;
        drawCircle(c, knobX, y, dp(9), state.theme == 0 ? 0xFFFFFFFF : 0xFFEAF2FA);
        stroke.setColor(state.theme == 0 ? 0xFFCBD5E2 : 0xFF53657E);
        stroke.setStrokeWidth(dp(0.7f));
        c.drawCircle(knobX, y, dp(9), stroke);
        sliders.add(new SliderHit(type, index, new RectF(x - dp(10), y - dp(18), x + width + dp(10), y + dp(18)),
                x, x + width, min, max, logScale));
    }

    private void drawSliderColored(Canvas c, float x, float y, float width, float value, float min, float max,
                                   int type, int index, boolean logScale, int fillColor) {
        float t;
        if (logScale) {
            t = (float) ((Math.log(value) - Math.log(min)) / (Math.log(max) - Math.log(min)));
        } else {
            t = (value - min) / (max - min);
        }
        t = clamp(t, 0f, 1f);
        RectF track = new RectF(x, y - dp(2.5f), x + width, y + dp(2.5f));
        drawRoundRect(c, track, dp(3), state.theme == 0 ? 0xFFDCE4EF : line);
        RectF fill = new RectF(x, y - dp(2.5f), x + width * t, y + dp(2.5f));
        drawRoundRect(c, fill, dp(3), fillColor);
        float knobX = x + width * t;
        drawCircle(c, knobX, y, dp(10.5f), withAlpha(fillColor, state.theme == 0 ? 34 : 58));
        drawCircle(c, knobX, y, dp(8.5f), state.theme == 0 ? 0xFFFFFFFF : 0xFFEAF2FA);
        stroke.setColor(fillColor);
        stroke.setStrokeWidth(dp(1.3f));
        c.drawCircle(knobX, y, dp(8.5f), stroke);
        sliders.add(new SliderHit(type, index, new RectF(x - dp(10), y - dp(18), x + width + dp(10), y + dp(18)),
                x, x + width, min, max, logScale));
    }

    private int eqChannelColor(int ch) {
        int[] colors = {
                0xFF138CF5, 0xFF25C85A, 0xFFFF9D24, 0xFFF25579,
                0xFF7B5CFF, 0xFF16C4D7, 0xFF8B5CF6
        };
        return colors[Math.max(0, Math.min(ch, colors.length - 1))];
    }

    private int eqBandColor(int band) {
        int[] colors = {
                0xFF0EA5E9, 0xFF06B6D4, 0xFF14B8A6, 0xFF22C55E, 0xFF84CC16,
                0xFFEAB308, 0xFFF59E0B, 0xFFF97316, 0xFFEF4444, 0xFFEC4899,
                0xFFD946EF, 0xFFA855F7, 0xFF8B5CF6, 0xFF6366F1, 0xFF3B82F6
        };
        return colors[Math.max(0, Math.min(band, colors.length - 1))];
    }

    private void drawValuePill(Canvas c, RectF r, String value) {
        drawRoundRect(c, r, dp(10), cardAlt);
        drawText(c, value, r.centerX(), r.centerY() + dp(5), dp(12), text, medium, Paint.Align.CENTER);
    }

    private void drawCircleButton(Canvas c, float cx, float cy, float r) {
        drawCircle(c, cx, cy, r, cardAlt);
    }

    private void drawSearchIcon(Canvas c, float cx, float cy) {
        stroke.setColor(text);
        stroke.setStrokeWidth(dp(2));
        stroke.setStyle(Paint.Style.STROKE);
        c.drawCircle(cx - dp(3), cy - dp(3), dp(7), stroke);
        c.drawLine(cx + dp(2), cy + dp(2), cx + dp(8), cy + dp(8), stroke);
    }

    private void drawOverflowIcon(Canvas c, float cx, float cy) {
        drawCircle(c, cx, cy - dp(7), dp(1.7f), text);
        drawCircle(c, cx, cy, dp(1.7f), text);
        drawCircle(c, cx, cy + dp(7), dp(1.7f), text);
    }

    private void drawMiniHomeIcon(Canvas c, int type, float cx, float cy, int color) {
        stroke.setColor(color);
        stroke.setStrokeWidth(dp(1.8f));
        stroke.setStyle(Paint.Style.STROKE);
        if (type == 0) {
            path.reset();
            path.moveTo(cx, cy - dp(12)); path.lineTo(cx, cy + dp(12));
            path.moveTo(cx, cy - dp(12)); path.lineTo(cx + dp(8), cy - dp(4)); path.lineTo(cx - dp(7), cy + dp(4)); path.lineTo(cx + dp(8), cy + dp(12));
            c.drawPath(path, stroke);
        } else if (type == 1) {
            RectF chip = new RectF(cx - dp(8), cy - dp(8), cx + dp(8), cy + dp(8));
            c.drawRoundRect(chip, dp(2), dp(2), stroke);
            for (int i = -1; i <= 1; i++) {
                c.drawLine(cx - dp(12), cy + i * dp(6), cx - dp(8), cy + i * dp(6), stroke);
                c.drawLine(cx + dp(8), cy + i * dp(6), cx + dp(12), cy + i * dp(6), stroke);
            }
        } else if (type == 2) {
            for (int i = -2; i <= 2; i++) {
                float hh = dp(5 + (2 - Math.abs(i)) * 3);
                c.drawLine(cx + i * dp(5), cy - hh, cx + i * dp(5), cy + hh, stroke);
            }
        } else if (type == 3) {
            path.reset();
            path.moveTo(cx - dp(9), cy - dp(4)); path.lineTo(cx - dp(4), cy - dp(4));
            path.lineTo(cx + dp(3), cy - dp(10)); path.lineTo(cx + dp(3), cy + dp(10));
            path.lineTo(cx - dp(4), cy + dp(4)); path.lineTo(cx - dp(9), cy + dp(4)); path.close();
            c.drawPath(path, stroke);
        } else if (type == 4) {
            RectF doc = new RectF(cx - dp(8), cy - dp(10), cx + dp(8), cy + dp(10));
            c.drawRoundRect(doc, dp(2), dp(2), stroke);
            c.drawLine(cx - dp(4), cy - dp(4), cx + dp(4), cy - dp(4), stroke);
            c.drawLine(cx - dp(4), cy + dp(1), cx + dp(4), cy + dp(1), stroke);
            c.drawLine(cx - dp(4), cy + dp(6), cx + dp(1), cy + dp(6), stroke);
        } else {
            c.drawCircle(cx, cy, dp(8), stroke);
            c.drawCircle(cx, cy, dp(3), stroke);
            for (int i = 0; i < 8; i++) {
                double a = i * Math.PI / 4.0;
                float x1 = cx + (float)Math.cos(a) * dp(10);
                float y1 = cy + (float)Math.sin(a) * dp(10);
                float x2 = cx + (float)Math.cos(a) * dp(13);
                float y2 = cy + (float)Math.sin(a) * dp(13);
                c.drawLine(x1, y1, x2, y2, stroke);
            }
        }
    }

    private void drawHomeIcon(Canvas c, float cx, float cy, int color) {
        p.setColor(color);
        path.reset();
        path.moveTo(cx - dp(10), cy);
        path.lineTo(cx, cy - dp(9));
        path.lineTo(cx + dp(10), cy);
        path.lineTo(cx + dp(8), cy + dp(10));
        path.lineTo(cx + dp(2), cy + dp(10));
        path.lineTo(cx + dp(2), cy + dp(3));
        path.lineTo(cx - dp(2), cy + dp(3));
        path.lineTo(cx - dp(2), cy + dp(10));
        path.lineTo(cx - dp(8), cy + dp(10));
        path.close();
        c.drawPath(path, p);
    }

    private void drawMixIcon(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color);
        stroke.setStrokeWidth(dp(2));
        for (int i = -1; i <= 1; i++) {
            float x = cx + i * dp(8);
            c.drawLine(x, cy - dp(12), x, cy + dp(12), stroke);
            float ky = cy + (i == -1 ? -dp(3) : i == 0 ? dp(5) : -dp(6));
            drawCircle(c, x, ky, dp(3), color);
        }
    }

    private void drawEqBarsIcon(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color);
        stroke.setStrokeWidth(dp(2.4f));
        stroke.setStrokeCap(Paint.Cap.ROUND);
        float[] hs = {dp(6), dp(13), dp(9)};
        for (int i = -1; i <= 1; i++) {
            float x = cx + i * dp(8);
            float h = hs[i + 1];
            c.drawLine(x, cy - h, x, cy + h, stroke);
        }
    }

    private void drawCheck(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color);
        stroke.setStrokeWidth(dp(3.2f));
        stroke.setStrokeCap(Paint.Cap.ROUND);
        path.reset();
        path.moveTo(cx - dp(9), cy);
        path.lineTo(cx - dp(2), cy + dp(7));
        path.lineTo(cx + dp(11), cy - dp(8));
        c.drawPath(path, stroke);
    }

    private void drawChevron(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color);
        stroke.setStrokeWidth(dp(1.8f));
        stroke.setStrokeCap(Paint.Cap.ROUND);
        c.drawLine(cx - dp(3), cy - dp(6), cx + dp(3), cy, stroke);
        c.drawLine(cx + dp(3), cy, cx - dp(3), cy + dp(6), stroke);
    }

    private void drawChevronLeft(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color);
        stroke.setStrokeWidth(dp(1.8f));
        stroke.setStrokeCap(Paint.Cap.ROUND);
        c.drawLine(cx + dp(3), cy - dp(6), cx - dp(3), cy, stroke);
        c.drawLine(cx - dp(3), cy, cx + dp(3), cy + dp(6), stroke);
    }

    private String channelPositionName(int ch) {
        String[] names = {"Front Left", "Front Right", "Rear Left", "Rear Right", "Center", "Subwoofer", "Aux"};
        return names[Math.max(0, Math.min(ch, names.length - 1))];
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = x;
                downY = y;
                scrolling = false;
                activeSlider = findSlider(x, y);
                startScroll = scrollY[state.page];
                if (activeSlider != null) {
                    applySlider(activeSlider, x);
                    getParent().requestDisallowInterceptTouchEvent(true);
                }
                return true;
            case MotionEvent.ACTION_MOVE:
                if (activeSlider != null) {
                    applySlider(activeSlider, x);
                    return true;
                }
                if (y >= contentTop && y < navTop) {
                    float dy = y - downY;
                    if (Math.abs(dy) > dp(5)) scrolling = true;
                    if (scrolling) {
                        scrollY[state.page] = clamp(startScroll - dy, 0f, maxScroll[state.page]);
                        invalidate();
                    }
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (activeSlider != null) {
                    applySlider(activeSlider, x);
                    activeSlider = null;
                    // V2 durability barrier: every completed gesture is on disk
                    // before control returns to the user. MOVE events still use
                    // SharedPreferences.apply() for smooth real-time response.
                    state.persistAll(true);
                    getParent().requestDisallowInterceptTouchEvent(false);
                    return true;
                }
                if (e.getActionMasked() == MotionEvent.ACTION_UP && !scrolling
                        && distance(downX, downY, x, y) < dp(14)) {
                    Hit h = findHit(x, y);
                    if (h != null) handleHit(h.id);
                }
                scrolling = false;
                return true;
            default:
                return super.onTouchEvent(e);
        }
    }

    private void handleHit(String id) {
        if (id.startsWith("nav")) {
            state.setPage(Integer.parseInt(id.substring(3)));
            state.persistAll(true);
            invalidate();
            return;
        }
        if (id.equals("search")) {
            host.showMessage("Device scan/search will connect to the real DSP in Phase 2");
        } else if (id.equals("theme")) {
            host.requestThemePicker(state.theme);
        } else if (id.equals("homeQuick")) {
            state.setPage(1);
            state.persistAll(true);
            invalidate();
        } else if (id.equals("homeSystem")) {
            host.showMessage("System Ready • Phase 1 UI simulation");
        } else if (id.startsWith("homeRow")) {
            int index = Integer.parseInt(id.substring(7));
            String[] msg = {"Bluetooth UI ready for Phase 2", "DSP device details", "Audio input: AUX (Analog)",
                    "Amplifier link status", "Preset sync status", "Version " + appVersionName() + " • Preset manager"};
            host.showMessage(msg[Math.max(0, Math.min(index, msg.length - 1))]);
        } else if (id.startsWith("chip")) {
            state.setSelectedChannel(Integer.parseInt(id.substring(4)));
            state.persistAll(true);
            invalidate();
        } else if (id.equals("resetEq")) {
            state.resetEqChannel(state.selectedChannel);
            state.persistAll(true);
            host.showMessage("Channel " + (state.selectedChannel + 1) + " EQ reset to Flat");
            invalidate();
        } else if (id.equals("bandPrev")) {
            state.setSelectedBand((state.selectedBand + DspState.BANDS - 1) % DspState.BANDS);
            state.persistAll(true);
            invalidate();
        } else if (id.equals("bandNext")) {
            state.setSelectedBand((state.selectedBand + 1) % DspState.BANDS);
            state.persistAll(true);
            invalidate();
        } else if (id.equals("presetName") || id.equals("savePreset")) {
            host.requestPresetName("");
        } else if (id.equals("pickPreset")) {
            host.requestPresetPicker(state.getDisplayPresetName());
        } else if (id.equals("loadPreset")) {
            boolean ok = state.loadSelectedPreset();
            if (ok) state.persistAll(true);
            host.showMessage(ok ? "Loaded preset: " + state.getDisplayPresetName() : "No saved preset selected");
            invalidate();
        } else if (id.equals("deletePreset")) {
            if (state.hasPresets()) host.requestDeletePreset(state.getDisplayPresetName());
            else host.showMessage("No saved presets to delete");
        }
    }

    private void applySlider(SliderHit s, float x) {
        float t = clamp((x - s.x1) / Math.max(1f, s.x2 - s.x1), 0f, 1f);
        float v;
        if (s.logScale) {
            v = (float) Math.exp(Math.log(s.min) + t * (Math.log(s.max) - Math.log(s.min)));
        } else {
            v = s.min + t * (s.max - s.min);
        }
        int ch = state.selectedChannel;
        int b = state.selectedBand;
        if (s.type == SL_MASTER) state.setMasterVolume(roundTo(v, 0.5f));
        else if (s.type == SL_BASS) state.setBassVolume(roundTo(v, 0.1f));
        else if (s.type == SL_CUTOFF) state.setBassCutoff(Math.round(v));
        else if (s.type == SL_CHANNEL) state.setChannelVolume(s.index, roundTo(v, 0.5f));
        else if (s.type == SL_EQ_FREQ) {
            float step = v < 1000f ? 1f : 10f;
            state.setEqFreq(ch, b, roundTo(v, step));
        } else if (s.type == SL_EQ_Q) state.setEqQ(ch, b, roundTo(v, 0.1f));
        else if (s.type == SL_EQ_GAIN) state.setEqGain(ch, b, roundTo(v, 0.1f));
        invalidate();
    }

    private SliderHit findSlider(float x, float y) {
        for (int i = sliders.size() - 1; i >= 0; i--) {
            SliderHit s = sliders.get(i);
            if (s.rect.contains(x, y)) return s;
        }
        return null;
    }

    private Hit findHit(float x, float y) {
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (h.rect.contains(x, y)) return h;
        }
        return null;
    }

    private void addHit(String id, RectF r) {
        hits.add(new Hit(id, new RectF(r)));
    }

    private void setContentHeight(int page, float contentHeight) {
        float visible = Math.max(dp(100), navTop - contentTop - dp(8));
        maxScroll[page] = Math.max(0f, contentHeight - visible);
        scrollY[page] = clamp(scrollY[page], 0f, maxScroll[page]);
    }

    private float contentLeft(float w) {
        float maxWidth = dp(760);
        float usable = Math.min(w - dp(24), maxWidth);
        return (w - usable) / 2f;
    }

    private float contentRight(float w) {
        return w - contentLeft(w);
    }

    private float freqToX(float freq, float x1, float x2) {
        float t = (float) ((Math.log(clamp(freq, 20f, 20000f)) - Math.log(20f)) / (Math.log(20000f) - Math.log(20f)));
        return x1 + (x2 - x1) * t;
    }

    private void drawRoundRect(Canvas c, RectF r, float radius, int color) {
        p.setColor(color);
        p.setStyle(Paint.Style.FILL);
        c.drawRoundRect(r, radius, radius, p);
    }

    private void drawCircle(Canvas c, float cx, float cy, float radius, int color) {
        p.setColor(color);
        p.setStyle(Paint.Style.FILL);
        c.drawCircle(cx, cy, radius, p);
    }

    private void drawLine(Canvas c, float x1, float y1, float x2, float y2, int color, float width) {
        stroke.setColor(color);
        stroke.setStrokeWidth(width);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        c.drawLine(x1, y1, x2, y2, stroke);
    }

    private void drawText(Canvas c, String s, float x, float baseline, float size, int color, Typeface tf, Paint.Align align) {
        p.setStyle(Paint.Style.FILL);
        p.setTypeface(tf);
        p.setTextSize(size);
        p.setTextAlign(align);
        p.setColor(color);
        c.drawText(s, x, baseline, p);
    }

    private float dp(float v) {
        return v * density;
    }

    private static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    private static float map(float v, float srcMin, float srcMax, float dstMin, float dstMax) {
        float t = (v - srcMin) / (srcMax - srcMin);
        return dstMin + (dstMax - dstMin) * t;
    }

    private static int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | ((alpha & 0xFF) << 24);
    }

    private static float roundTo(float v, float step) {
        return Math.round(v / step) * step;
    }

    private static float distance(float x1, float y1, float x2, float y2) {
        float dx = x2 - x1, dy = y2 - y1;
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    private static final class Hit {
        final String id;
        final RectF rect;
        Hit(String id, RectF rect) { this.id = id; this.rect = rect; }
    }

    private static final class SliderHit {
        final int type;
        final int index;
        final RectF rect;
        final float x1, x2, min, max;
        final boolean logScale;
        SliderHit(int type, int index, RectF rect, float x1, float x2, float min, float max, boolean logScale) {
            this.type = type;
            this.index = index;
            this.rect = rect;
            this.x1 = x1;
            this.x2 = x2;
            this.min = min;
            this.max = max;
            this.logScale = logScale;
        }
    }
}
