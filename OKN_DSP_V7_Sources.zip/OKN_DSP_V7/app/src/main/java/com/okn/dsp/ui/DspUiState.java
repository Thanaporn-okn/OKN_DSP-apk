package com.okn.dsp.ui;

import java.util.Arrays;

/** Mutable UI state for Phase 1. No hardware I/O exists in this class. */
public final class DspUiState {
    public static final int PAGE_HOME = 0;
    public static final int PAGE_MIX = 1;
    public static final int PAGE_EQ = 2;
    public static final int PAGE_CROSSOVER = 3;

    public int page = PAGE_HOME;
    public int inputSource = 0;

    public float masterVolume = -6f;
    public float bassVolume = 0f;
    public float bassCutoff = 80f;
    public float bassBoost = 4f;
    public float middleBoost = 2f;
    public float trebleBoost = 3f;

    public int eqChannel = 0;
    public int eqBand = 5;
    public final float[][] eqFreq = new float[7][15];
    public final float[][] eqGain = new float[7][15];
    public final float[][] eqQ = new float[7][15];
    public final float[] output = new float[7];

    public final float[] xoLow = {20f, 80f, 3000f, 20f};
    public final float[] xoHigh = {80f, 3000f, 20000f, 20000f};
    public final int[] xoType = {0, 1, 2, 3}; // LP, BP, HP, Bypass
    public final int[] xoSlope = {12, 24, 24, 12};
    public final float[] delayMs = {2.50f, 1.20f, 0.00f, 0.80f};
    public boolean linkLR = true;
    public boolean phaseView = false;
    public int delayUnit = 0; // 0=ms, 1=cm, 2=in

    public DspUiState() {
        float[] baseFreq = {20f, 31.5f, 50f, 80f, 125f, 200f, 315f, 500f, 800f, 1250f, 2000f, 3150f, 5000f, 8000f, 12500f};
        float[] baseGain = {-2f, 0f, 3f, 6f, 4.5f, 2f, 1f, 2.5f, 5.5f, 2f, 0f, 3.5f, 6f, 4.5f, 1.5f};
        for (int ch = 0; ch < 7; ch++) {
            for (int b = 0; b < 15; b++) {
                eqFreq[ch][b] = baseFreq[b];
                eqGain[ch][b] = baseGain[b] - ch * 0.15f;
                eqQ[ch][b] = 1.2f;
            }
            output[ch] = 0f;
        }
    }

    public static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    public String serialize() {
        StringBuilder sb = new StringBuilder(4096);
        sb.append(masterVolume).append(',').append(bassVolume).append(',').append(bassCutoff).append(',')
                .append(bassBoost).append(',').append(middleBoost).append(',').append(trebleBoost).append(';');
        for (int ch = 0; ch < 7; ch++) {
            for (int b = 0; b < 15; b++) {
                sb.append(eqFreq[ch][b]).append(',').append(eqGain[ch][b]).append(',').append(eqQ[ch][b]).append('|');
            }
            sb.append(output[ch]).append(';');
        }
        for (int i = 0; i < 4; i++) {
            sb.append(xoLow[i]).append(',').append(xoHigh[i]).append(',').append(xoType[i]).append(',')
                    .append(xoSlope[i]).append(',').append(delayMs[i]).append('|');
        }
        sb.append(linkLR ? '1' : '0');
        return sb.toString();
    }

    public boolean restore(String raw) {
        if (raw == null || raw.isEmpty()) return false;
        try {
            String[] sections = raw.split(";", -1);
            if (sections.length < 9) return false;
            String[] mix = sections[0].split(",");
            masterVolume = Float.parseFloat(mix[0]);
            bassVolume = Float.parseFloat(mix[1]);
            bassCutoff = Float.parseFloat(mix[2]);
            bassBoost = Float.parseFloat(mix[3]);
            middleBoost = Float.parseFloat(mix[4]);
            trebleBoost = Float.parseFloat(mix[5]);
            for (int ch = 0; ch < 7; ch++) {
                String[] chunks = sections[ch + 1].split("\\|");
                for (int b = 0; b < 15; b++) {
                    String[] v = chunks[b].split(",");
                    eqFreq[ch][b] = Float.parseFloat(v[0]);
                    eqGain[ch][b] = Float.parseFloat(v[1]);
                    eqQ[ch][b] = Float.parseFloat(v[2]);
                }
                output[ch] = Float.parseFloat(chunks[15]);
            }
            String[] xo = sections[8].split("\\|");
            for (int i = 0; i < 4; i++) {
                String[] v = xo[i].split(",");
                xoLow[i] = Float.parseFloat(v[0]);
                xoHigh[i] = Float.parseFloat(v[1]);
                xoType[i] = Integer.parseInt(v[2]);
                xoSlope[i] = Integer.parseInt(v[3]);
                delayMs[i] = Float.parseFloat(v[4]);
            }
            if (xo.length > 4) linkLR = "1".equals(xo[4]);
            return true;
        } catch (RuntimeException ignored) {
            return false;
        }
    }

    public String serializeSession() {
        return serialize() + "#ui," + page + ',' + inputSource + ',' + eqChannel + ',' + eqBand + ',' + (phaseView ? 1 : 0) + ',' + delayUnit;
    }

    public boolean restoreSession(String raw) {
        if (raw == null || raw.isEmpty()) return false;
        String[] parts = raw.split("#ui,", 2);
        if (!restore(parts[0])) return false;
        if (parts.length > 1) {
            try {
                String[] ui = parts[1].split(",");
                if (ui.length >= 5) {
                    page = Math.max(PAGE_HOME, Math.min(PAGE_CROSSOVER, Integer.parseInt(ui[0])));
                    inputSource = Math.max(0, Math.min(3, Integer.parseInt(ui[1])));
                    eqChannel = Math.max(0, Math.min(6, Integer.parseInt(ui[2])));
                    eqBand = Math.max(0, Math.min(14, Integer.parseInt(ui[3])));
                    phaseView = "1".equals(ui[4]);
                    if (ui.length >= 6) delayUnit = Math.max(0, Math.min(2, Integer.parseInt(ui[5])));
                }
            } catch (RuntimeException ignored) {
                // DSP values were restored; invalid view metadata is safe to ignore.
            }
        }
        return true;
    }

    public void resetDelays() {
        Arrays.fill(delayMs, 0f);
    }
}
