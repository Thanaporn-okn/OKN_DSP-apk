# OKN DSP V26 — Phase 1

Base: V25. V26 keeps the V25 UI/touch/performance/preset fixes and updates only the circled Home status icons from the latest reference.

## V26 icon update

All Home icons are recreated from **Canvas/vector/shape code**. The uploaded reference is used only as a visual guide; it is **not copied into the app, embedded as a screenshot, or used as a background**.

- Bluetooth — blue glossy circle, white Bluetooth glyph
- DSP Device — pink glossy circle, white chip glyph
- Audio Input — red/rose glossy circle, white waveform glyph
- Amplifier Link — pink/red glossy circle, white speaker glyph
- Preset Sync — cyan/teal glossy circle, white preset/document glyph
- Firmware Status — violet glossy circle, white gear glyph
- Quick Control — soft pink rounded badge, pink EQ bars

versionName: 26.0.0
versionCode: 1026
Phase: 1 UI hardening
