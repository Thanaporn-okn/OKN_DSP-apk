OKN_DSP V25 - CROSSOVER DISCOVERY (READ ONLY)

Purpose
- Preserve the V24 real-DSP audio baseline unchanged.
- Do not guess or transmit Crossover hardware writes.
- Tapping the existing Crossover bottom-nav item exports a READ-ONLY evidence file to Download/OKN_DSP/.
- The file contains the authenticated Device Description plus records 1-3 of all seven EQ actuators.

Qualification workflow
1. Power-cycle DSP and capture baseline with V25 by tapping Crossover once.
2. Close V25. Open the official GoloPine app.
3. Change exactly ONE Crossover parameter on ONE channel (for example CH3 LPF cutoff only). Do not touch EQ/volume and do not save permanently.
4. Close the official app. Open V25 and tap Crossover again.
5. Send both exported TXT files back for byte/field comparison.

Safety
- V25 Crossover discovery performs zero Crossover writes.
- V24 Scalar/EQ writers remain unchanged.
- No final Crossover UI is invented in V25.
