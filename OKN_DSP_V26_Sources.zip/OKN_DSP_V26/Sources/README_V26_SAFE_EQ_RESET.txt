OKN_DSP V26 - SAFE EQ RESET
===========================
Base: V25/V24 line.
Scope: fixes only the real-device transient produced by the EQ Reset button.

Reset semantics are now strict:
- Gain -> 0 dB
- Frequency stays exactly at the current hardware value
- Q stays exactly at the current hardware value
- F2/G/R metadata stays unchanged
- Band 1 stays its native filter type
- no ISO centre migration is started by Reset
- no auto SaveParams

Normal per-band Gain/Q editing keeps the V24/V21 behavior and V24 safe centre migration.
Crossover discovery from V25 remains READ ONLY and does not add DSP write packets.
