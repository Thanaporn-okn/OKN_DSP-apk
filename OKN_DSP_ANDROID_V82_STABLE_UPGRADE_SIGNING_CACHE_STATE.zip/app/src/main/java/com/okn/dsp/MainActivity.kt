package com.okn.dsp

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/** V82 stable-upgrade signing + explicit last-DSP cache-state launcher: open the verified DSP control UI directly. */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startActivity(Intent(this, UnifiedControlActivity::class.java))
        finish()
    }
}
