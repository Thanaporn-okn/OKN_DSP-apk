package com.okn.dsp

import android.app.Activity
import android.os.Bundle
import android.widget.TextView
import android.widget.SeekBar
import android.widget.Button

class MainActivity : Activity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  setContentView(R.layout.activity_main)

  val ch = findViewById<TextView>(R.id.channel)
  val names = arrayOf("CH1 Front L","CH2 Front R","CH3 Rear L","CH4 Rear R","CH5 Center","CH6 AUX","CH7 SUB")
  var index=0

  findViewById<Button>(R.id.next).setOnClickListener {
   index=(index+1)%7
   ch.text=names[index]
  }
 }
}
