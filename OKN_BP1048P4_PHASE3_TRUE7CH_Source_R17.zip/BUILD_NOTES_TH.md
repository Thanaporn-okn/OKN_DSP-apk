# R16 Build Notes

- Base: R15 TRUE7CH / bootloader discovery
- Android versionCode 16 / versionName 0.16-r16-same-address-discriminator
- Imports R15 real-board result: AA accepted, Feature response changed 00 -> 55, no Android re-enumeration observed
- Adds normal raw USB device-descriptor baseline
- Adds three post-handoff standard GET_DESCRIPTOR snapshots at 150 ms / 700 ms / 2500 ms
- Adds public-SDK flashboot descriptor fingerprint as cross-family reference only
- Candidate inspection no longer sends class GET_REPORT to an unknown candidate; descriptor-only control-IN
- One AA attempt max per app process
- No firmware payload, endpoint OUT, erase, program, commit, or automatic boot entry
