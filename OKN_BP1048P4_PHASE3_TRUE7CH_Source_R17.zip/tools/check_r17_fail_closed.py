#!/usr/bin/env python3
import json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
d=json.loads((root/'config/PCTOOLS_SAFE_READ_STATE_R17.json').read_text(encoding='utf-8'))
assert d['r16_real_board_result']['feature_aa_accepted'] is True
assert d['r16_real_board_result']['observable_flashboot_handoff'] is False
assert d['r16_real_board_result']['power_cycle_recovery_verified'] is True
r=d['r17_allowlist']
assert r['controls']==['0x00','0x11','0xFF']
for k in ['writes_parameters','feature_aa','ctrl_fe_upgrade','ctrl_fd_save','erase','program','commit','firmware_payload']:
    assert r[k] is False, k
g=d['production_gate']
for k,v in g.items():
    assert v is False, k
print('R17 fail-closed policy: PASS')
