#!/usr/bin/env python3
from pathlib import Path
p=Path(__file__).resolve().parents[1]/"android-usb-probe/app/src/main/java/com/okn/dsp/usbprobe/MainActivity.java"
s=p.read_text(encoding="utf-8")
required=[
    'private static final int[] SAFE_READ_CONTROLS = new int[] {0x00,0x11,0xFF};',
    'tx[0]=(byte)0xA5; tx[1]=0x5A; tx[2]=(byte)ctrl; tx[3]=0x00; tx[4]=0x16;',
    'controlTransfer(0x21,0x09,0x0200,x4.getId(),tx,tx.length,1200)',
    'controlTransfer(0xA1,0x01,0x0100,x4.getId(),rx,rx.length,1200)',
    'validAcpFrameLength(rx,rn,ctrl)',
    'stale/nonmatching report ignored',
]
for x in required:
    assert x in s, f"missing R17 safe-read flow: {x}"
for forbidden in [
    'arm[0]=(byte)0xAA',
    '0x0300,x4.getId(),arm',
    '.bulkTransfer(', '.claimInterface(', '.releaseInterface(',
    'chipErase', 'sectorErase', 'flashWrite', 'programFlash', 'commitFlash',
    'sendFirmware', 'eraseAllFlash'
]:
    assert forbidden not in s, f"forbidden R17 path present: {forbidden}"
# The only explicit ACP query controls in the allowlist must remain 00,11,FF.
line=[ln for ln in s.splitlines() if 'SAFE_READ_CONTROLS = new int[]' in ln]
assert len(line)==1 and '{0x00,0x11,0xFF}' in line[0]
# No normal-mode upgrade/save control is ever formed as a constant query.
assert 'safeAcpRead(0xFE)' not in s
assert 'safeAcpRead(0xFD)' not in s
print('R17 ACP/PCTools safe-read guard: PASS')
