# OKN BP1048P4 Phase3 TRUE7CH — R17

R17 เปลี่ยนงาน USB จากการทดลอง Feature `AA` ของ R16 มาเป็น **PCTools/ACP query-only probe** เพื่อเก็บข้อมูล production firmware โดยไม่เข้า upgrade mode.

Android probe ใช้ fingerprint บอร์ดจริง `6324:1719 / JMDSTECH / DSTech DSP ComboDigitalArchitect / IF4 FF00:55AA` และจะส่ง HID Output report เฉพาะเมื่อ exact gate ผ่านเท่านั้น. Allowlist มีเพียง `CTRL 0x00`, `0x11`, `0xFF` และทุก frame มี `LEN=0`.

R17 ไม่มี Feature AA, ไม่มี CTRL FE/FD, ไม่มี erase/program/commit/firmware payload. TRUE7CH firmware core เดิมยังคงใช้ dedicated gain IDs 22..28 และไม่ใช้ EQ ทำ Gain.

บน S25+: กด 2 ให้ขึ้น `R17 NORMAL EXACT GATE: PASS` แล้วกด 6 `RUN SAFE READ BUNDLE`. ส่ง log ตั้งแต่ `SAFE READ BUNDLE START` ถึง `END` กลับมา.
