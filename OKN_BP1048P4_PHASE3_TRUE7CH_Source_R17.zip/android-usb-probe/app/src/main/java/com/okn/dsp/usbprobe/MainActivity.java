package com.okn.dsp.usbprobe;

import android.app.*;
import android.os.*;
import android.content.*;
import android.hardware.usb.*;
import android.widget.*;
import java.util.*;
import java.text.SimpleDateFormat;
import java.nio.charset.StandardCharsets;
import java.io.*;

public final class MainActivity extends Activity {
    private static final int OBSERVED_VID = 0x6324;
    private static final int OBSERVED_PID = 0x1719;
    private static final String OBSERVED_MANUFACTURER = "JMDSTECH";
    private static final String OBSERVED_PRODUCT = "DSTech DSP ComboDigitalArchitect";
    private static final String ACTION_USB_PERMISSION = "com.okn.dsp.usbprobe.USB_PERMISSION";

    private static final byte[] EXPECTED_IF4_REPORT = new byte[] {
        0x06,0x00,(byte)0xFF,0x0A,(byte)0xAA,0x55,(byte)0xA1,0x01,
        0x15,0x00,0x26,(byte)0xFF,0x00,0x75,0x08,(byte)0x96,0x00,0x01,
        0x09,0x01,(byte)0x81,0x02,(byte)0x96,0x00,0x01,0x09,0x01,(byte)0x91,0x02,
        (byte)0x95,0x08,0x09,0x01,(byte)0xB1,0x02,(byte)0xC0
    };
    private static final byte[] EXPECTED_FEATURE = new byte[] {0x00,0x01,0x00,0x03,0x04,0x00,0x08,0x00};

    // ACP/PCTools read requests only. LEN=0 means query/read.
    // 0x00 = firmware info, 0x11 = PCTools burn/version info, 0xFF = encryption-state query.
    private static final int[] SAFE_READ_CONTROLS = new int[] {0x00,0x11,0xFF};

    private UsbManager usb;
    private TextView log;
    private UsbDevice selected;
    private volatile boolean exactNormalGatePassed = false;

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            if (!ACTION_USB_PERMISSION.equals(i.getAction())) return;
            UsbDevice d=i.getParcelableExtra(UsbManager.EXTRA_DEVICE);
            if (!i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false) || d==null) {
                add("USB permission denied");
                return;
            }
            selected=d;
            probeNormal(d);
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        usb=(UsbManager)getSystemService(USB_SERVICE);
        buildUi();
        IntentFilter f=new IntentFilter(ACTION_USB_PERMISSION);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver,f,RECEIVER_NOT_EXPORTED);
        else registerReceiver(receiver,f);
        readExitHistory();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        try { unregisterReceiver(receiver); } catch (Exception ignored) {}
    }

    private void buildUi() {
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28,28,28,28);

        TextView title=new TextView(this);
        title.setText("OKN BP1048P4 USB-C Diagnostic R17\nPCTOOLS / ACP SAFE READ PROBE\nOUT is query-only: LEN=0 / no AA / no FE / no FD / no erase / no program");
        title.setTextSize(18);

        Button exits=new Button(this); exits.setText("1) READ APP EXIT HISTORY");
        Button scan=new Button(this); scan.setText("2) NORMAL USB SCAN + EXACT GATE");
        Button fw=new Button(this); fw.setText("3) SAFE ACP READ 0x00 — FIRMWARE INFO");
        Button pct=new Button(this); pct.setText("4) SAFE PCTOOLS READ 0x11 — BURN/VERSION INFO");
        Button enc=new Button(this); enc.setText("5) SAFE ACP READ 0xFF — ENCRYPTION STATE");
        Button bundle=new Button(this); bundle.setText("6) RUN SAFE READ BUNDLE 00 + 11 + FF");

        log=new TextView(this); log.setTextIsSelectable(true);
        ScrollView sv=new ScrollView(this); sv.addView(log);

        root.addView(title); root.addView(exits); root.addView(scan); root.addView(fw);
        root.addView(pct); root.addView(enc); root.addView(bundle);
        root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);

        exits.setOnClickListener(v->readExitHistory());
        scan.setOnClickListener(v->scan());
        fw.setOnClickListener(v->safeAcpRead(0x00));
        pct.setOnClickListener(v->safeAcpRead(0x11));
        enc.setOnClickListener(v->safeAcpRead(0xFF));
        bundle.setOnClickListener(v->runSafeBundle());
    }

    private void readExitHistory() {
        add("=== ANDROID APP EXIT HISTORY ===");
        add("Model: "+Build.MANUFACTURER+" "+Build.MODEL+" SDK="+Build.VERSION.SDK_INT);
        if (Build.VERSION.SDK_INT < 30) { add("ApplicationExitInfo unavailable below API 30."); return; }
        try {
            ActivityManager am=(ActivityManager)getSystemService(ACTIVITY_SERVICE);
            List<ApplicationExitInfo> infos=am.getHistoricalProcessExitReasons(getPackageName(),0,8);
            add("Historical exits: "+infos.size());
            SimpleDateFormat fmt=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS Z",Locale.US);
            int idx=0;
            for (ApplicationExitInfo info: infos) {
                idx++;
                add("EXIT #"+idx+": time="+fmt.format(new Date(info.getTimestamp()))+" reason="+info.getReason()+" status="+info.getStatus());
                String desc=info.getDescription(); if(desc!=null&&!desc.isEmpty()) add("  description="+desc);
            }
        } catch(Throwable t) { add("Exit-history read failed: "+t.getClass().getSimpleName()+": "+safe(t.getMessage())); }
        add("=== END EXIT HISTORY ===");
    }

    private void scan() {
        add("=== R17 NORMAL USB SCAN ===");
        exactNormalGatePassed=false;
        selected=null;
        Map<String,UsbDevice> devices=usb.getDeviceList();
        add("USB devices: "+devices.size());
        for(UsbDevice d:devices.values()) {
            add(String.format(Locale.US,"VID=0x%04X PID=0x%04X interfaces=%d",d.getVendorId(),d.getProductId(),d.getInterfaceCount()));
            dumpInterfaces(d);
            if(isObservedNormal(d)) selected=d;
        }
        if(selected==null){ add("Exact target 6324:1719 / i7 not found"); return; }
        if(usb.hasPermission(selected)) probeNormal(selected); else requestPermission(selected);
    }

    private void requestPermission(UsbDevice d) {
        int flags=PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT>=31?PendingIntent.FLAG_MUTABLE:0);
        PendingIntent pi=PendingIntent.getBroadcast(this,0,new Intent(ACTION_USB_PERMISSION).setPackage(getPackageName()),flags);
        usb.requestPermission(d,pi);
    }

    private static boolean isObservedNormal(UsbDevice d) {
        return d!=null && d.getVendorId()==OBSERVED_VID && d.getProductId()==OBSERVED_PID && d.getInterfaceCount()==7;
    }

    private UsbInterface findIf4(UsbDevice d) {
        for(int i=0;i<d.getInterfaceCount();i++) {
            UsbInterface x=d.getInterface(i);
            if(x.getId()==4 && x.getInterfaceClass()==UsbConstants.USB_CLASS_HID) return x;
        }
        return null;
    }

    private UsbInterface findIf3(UsbDevice d) {
        for(int i=0;i<d.getInterfaceCount();i++) {
            UsbInterface x=d.getInterface(i);
            if(x.getId()==3 && x.getInterfaceClass()==UsbConstants.USB_CLASS_HID) return x;
        }
        return null;
    }

    private UsbEndpoint findIf3InterruptIn(UsbInterface x) {
        if(x==null) return null;
        for(int i=0;i<x.getEndpointCount();i++) {
            UsbEndpoint ep=x.getEndpoint(i);
            if(ep.getAddress()==0x81 && ep.getDirection()==UsbConstants.USB_DIR_IN &&
                    ep.getType()==UsbConstants.USB_ENDPOINT_XFER_INT && ep.getMaxPacketSize()==64) return ep;
        }
        return null;
    }

    private void probeNormal(UsbDevice d) {
        new Thread(()->{
            UsbDeviceConnection c=usb.openDevice(d);
            if(c==null){ ui("Permission/open: FAILED"); return; }
            try {
                ui("Permission/open: OK");
                String manufacturer=safe(d.getManufacturerName());
                String product=safe(d.getProductName());
                ui("Manufacturer: "+manufacturer); ui("Product: "+product); ui("Serial: "+safe(d.getSerialNumber()));
                UsbInterface x4=findIf4(d); UsbInterface x3=findIf3(d); UsbEndpoint ep81=findIf3InterruptIn(x3);
                if(x4==null){ ui("IF4 HID missing"); return; }

                byte[] dd=new byte[18];
                int dn=c.controlTransfer(0x80,0x06,0x0100,0,dd,dd.length,1500);
                ui("GET_DESCRIPTOR DEVICE => "+dn+" bytes"+(dn>0?"\n  "+hex(dd,dn):""));
                byte[] rd=new byte[255];
                int rn=c.controlTransfer(0x81,0x06,0x2200,x4.getId(),rd,rd.length,1500);
                ui("IF4 HID REPORT => "+rn+" bytes"+(rn>0?"\n  "+hex(rd,rn):""));
                byte[] ft=new byte[8];
                int fn=c.controlTransfer(0xA1,0x01,0x0300,x4.getId(),ft,ft.length,1500);
                ui("GET_REPORT FEATURE => "+fn+" bytes"+(fn>0?"\n  "+hex(ft,fn):""));

                boolean exactReport=rn==EXPECTED_IF4_REPORT.length && Arrays.equals(Arrays.copyOf(rd,rn),EXPECTED_IF4_REPORT);
                boolean exactFeature=fn==EXPECTED_FEATURE.length && Arrays.equals(ft,EXPECTED_FEATURE);
                boolean exactStrings=OBSERVED_MANUFACTURER.equals(manufacturer)&&OBSERVED_PRODUCT.equals(product);
                boolean exactIf3=ep81!=null;
                boolean exactDevice=isObservedNormal(d);
                exactNormalGatePassed=exactReport&&exactFeature&&exactStrings&&exactIf3&&exactDevice;
                ui("R17 NORMAL EXACT GATE: "+(exactNormalGatePassed?"PASS — safe LEN=0 ACP/PCTools reads enabled":"FAIL — all query buttons remain fail-closed"));
                ui("R17 normal scan sent control-IN only. No ACP OUT was sent by button 2.");
            } catch(Throwable t){ ui("R17 normal probe exception: "+t.getClass().getSimpleName()+": "+safe(t.getMessage())); }
            finally { c.close(); }
        },"okn-r17-normal").start();
    }

    private void safeAcpRead(int ctrl) {
        if(!isSafeReadControl(ctrl)){ add(String.format(Locale.US,"BLOCKED: CTRL 0x%02X is not on R17 read-only allowlist",ctrl)); return; }
        UsbDevice d=selected;
        if(!exactNormalGatePassed || d==null || !isObservedNormal(d) || !usb.hasPermission(d)) {
            add("BLOCKED: run button 2 first and require R17 NORMAL EXACT GATE: PASS");
            return;
        }
        new Thread(()->doSafeAcpRead(d,ctrl),"okn-r17-acp-read").start();
    }

    private void runSafeBundle() {
        UsbDevice d=selected;
        if(!exactNormalGatePassed || d==null || !isObservedNormal(d) || !usb.hasPermission(d)) {
            add("BLOCKED: run button 2 first and require R17 NORMAL EXACT GATE: PASS");
            return;
        }
        new Thread(()->{
            ui("=== R17 SAFE READ BUNDLE START ===");
            for(int ctrl:SAFE_READ_CONTROLS) {
                doSafeAcpRead(d,ctrl);
                try { Thread.sleep(25); } catch(InterruptedException e){ Thread.currentThread().interrupt(); break; }
            }
            ui("=== R17 SAFE READ BUNDLE END ===");
            ui("No AA / no FE / no FD / no parameter payload / no erase / no program / no commit was sent.");
        },"okn-r17-safe-bundle").start();
    }

    private static boolean isSafeReadControl(int ctrl) {
        for(int x:SAFE_READ_CONTROLS) if(x==ctrl) return true;
        return false;
    }

    private void doSafeAcpRead(UsbDevice d,int ctrl) {
        if(!isSafeReadControl(ctrl)) { ui("INTERNAL BLOCK: non-allowlisted control"); return; }
        UsbDeviceConnection c=usb.openDevice(d);
        if(c==null){ ui(String.format(Locale.US,"CTRL 0x%02X: openDevice failed",ctrl)); return; }
        try {
            UsbInterface x4=findIf4(d);
            if(x4==null){ ui("CTRL query blocked: IF4 missing"); return; }
            byte[] tx=new byte[256];
            tx[0]=(byte)0xA5; tx[1]=0x5A; tx[2]=(byte)ctrl; tx[3]=0x00; tx[4]=0x16;
            ui(String.format(Locale.US,"=== SAFE QUERY CTRL 0x%02X ===",ctrl));
            ui("TX semantic frame: "+hex(tx,5)+" (LEN=0 READ; remaining HID report bytes are zero padding)");

            boolean matched=false;
            for(int attempt=1;attempt<=4;attempt++) {
                int wn=c.controlTransfer(0x21,0x09,0x0200,x4.getId(),tx,tx.length,1200);
                ui("  attempt "+attempt+" SET_REPORT OUTPUT query => "+wn+" bytes");
                if(wn<0) continue;
                try { Thread.sleep(attempt==1?2:10); } catch(InterruptedException e){ Thread.currentThread().interrupt(); break; }
                byte[] rx=new byte[256];
                int rn=c.controlTransfer(0xA1,0x01,0x0100,x4.getId(),rx,rx.length,1200);
                ui("  attempt "+attempt+" GET_REPORT INPUT => "+rn+" bytes");
                if(rn<=0) continue;
                int frameLen=validAcpFrameLength(rx,rn,ctrl);
                if(frameLen>0) {
                    matched=true;
                    ui("  MATCHED FRESH CTRL: "+hex(rx,frameLen));
                    decodeKnownRead(ctrl,rx,frameLen);
                    break;
                } else {
                    int seen=(rn>=3?(rx[2]&0xFF):-1);
                    ui(String.format(Locale.US,"  stale/nonmatching report ignored (reply CTRL=%s)",seen<0?"<none>":String.format(Locale.US,"0x%02X",seen)));
                    ui("  first bytes: "+hex(rx,Math.min(rn,32)));
                }
            }
            if(!matched) ui(String.format(Locale.US,"CTRL 0x%02X: NO MATCHING REPLY after 4 attempts",ctrl));
        } catch(Throwable t){ ui(String.format(Locale.US,"CTRL 0x%02X exception: %s: %s",ctrl,t.getClass().getSimpleName(),safe(t.getMessage()))); }
        finally { c.close(); }
    }

    private static int validAcpFrameLength(byte[] b,int n,int expectedCtrl) {
        if(b==null || n<5) return -1;
        if((b[0]&0xFF)!=0xA5 || (b[1]&0xFF)!=0x5A || (b[2]&0xFF)!=expectedCtrl) return -1;
        int len=b[3]&0xFF;
        int total=len+5;
        if(total>n || total>b.length || total<5) return -1;
        if((b[total-1]&0xFF)!=0x16) return -1;
        return total;
    }

    private void decodeKnownRead(int ctrl,byte[] b,int frameLen) {
        int len=b[3]&0xFF;
        if(ctrl==0x00 && len>=7 && frameLen>=12) {
            ui(String.format(Locale.US,"  0x00 firmware info: family/type=0x%02X app=%d.%d.%d audioLib=%d.%d.%d",
                    b[4]&0xFF,b[5]&0xFF,b[6]&0xFF,b[7]&0xFF,b[8]&0xFF,b[9]&0xFF,b[10]&0xFF));
        } else if(ctrl==0x11 && len>=4) {
            StringBuilder s=new StringBuilder();
            s.append(String.format(Locale.US,"  0x11 PCTools version info: firmwareType=0x%02X",b[4]&0xFF));
            if(len>=4) s.append(String.format(Locale.US," version=%d.%d.%d",b[5]&0xFF,b[6]&0xFF,b[7]&0xFF));
            if(len>4) s.append(" reserved/data="+hex(Arrays.copyOfRange(b,8,4+len),Math.max(0,len-4)));
            ui(s.toString());
        } else if(ctrl==0xFF) {
            ui("  0xFF encryption-state raw body: "+hex(Arrays.copyOfRange(b,4,4+len),len));
            if(len>=2) ui("  legacy interpretation: selector="+(b[4]&0xFF)+" encryptedFlag="+(b[5]&0xFF));
            if(len>=3) ui("  modern protocol interpretation: parameterCode="+(b[4]&0xFF)+" valueLE="+((b[5]&0xFF)|((b[6]&0xFF)<<8)));
        }
    }

    private void dumpInterfaces(UsbDevice d) {
        for(int i=0;i<d.getInterfaceCount();i++) {
            UsbInterface x=d.getInterface(i);
            add("  IDX"+i+" IF"+x.getId()+" alt="+x.getAlternateSetting()+" class="+x.getInterfaceClass()+" sub="+x.getInterfaceSubclass()+" proto="+x.getInterfaceProtocol()+" ep="+x.getEndpointCount());
            for(int e=0;e<x.getEndpointCount();e++) {
                UsbEndpoint ep=x.getEndpoint(e);
                add("    EP addr=0x"+String.format(Locale.US,"%02X",ep.getAddress())+" dir="+(ep.getDirection()==UsbConstants.USB_DIR_IN?"IN":"OUT")+" type="+ep.getType()+" max="+ep.getMaxPacketSize()+" interval="+ep.getInterval());
            }
        }
    }

    private static String safe(String s){ return s==null?"<null>":s; }
    private static String hex(byte[] b,int n) {
        if(b==null||n<=0) return "<none>";
        StringBuilder s=new StringBuilder();
        for(int i=0;i<n&&i<b.length;i++){ if(i>0)s.append(' '); s.append(String.format(Locale.US,"%02X",b[i]&0xFF)); }
        return s.toString();
    }
    private void add(String s){ runOnUiThread(()->log.append(s+"\n")); }
    private void ui(String s){ runOnUiThread(()->log.append(s+"\n")); }
}
