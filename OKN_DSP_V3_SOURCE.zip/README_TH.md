# OKN_DSP V3

V3 ปรับ UI ใหม่โดยล็อกสัดส่วนกับภาพอ้างอิง 864×1536 ทั้ง 5 หน้าโดยตรง

- Home / EQ / Crossover / Delay / Output ใช้ภาพอ้างอิงของผู้ใช้เป็น skin หลัก
- พิกัดปุ่ม, slider, dropdown, switch และ navigation อยู่บน coordinate system เดียวกับภาพ 864×1536
- scale แบบ uniform เท่านั้น จึงไม่ยืด/บีบแนวนอนและแนวตั้งแยกกัน
- ค่า slider / switch / dropdown เปลี่ยนใน UI ทันที
- BLE Scan/Connect จริงยังคงอยู่
- UUID ที่ยืนยันแล้ว: 0000ab01-0000-1000-8000-00805f9b34fb
- ยังไม่ส่ง command byte ที่เดาเองไป DSP; จะส่งได้เมื่อ frame จริงถูกยืนยัน
- versionCode 3 / versionName 3.0.0
- SHA256 อยู่ใน Sources

ไฟล์ workflow เดิม OKN_DSP_AUTO_BUILD.yml รองรับ V3 โดยไม่ต้องอัปโหลด workflow ใหม่
