package com.okn.dsp

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class BleController(private val context: Context) {
    enum class State { Disconnected, Scanning, Connecting, Connected }

    data class DeviceItem(val address: String, val name: String, val device: BluetoothDevice)

    var state by mutableStateOf(State.Disconnected)
        private set
    var deviceName by mutableStateOf("DSP-7900")
        private set
    var devices by mutableStateOf<List<DeviceItem>>(emptyList())
        private set
    var lastInfo by mutableStateOf("Ready")
        private set

    private val handler = Handler(Looper.getMainLooper())
    private val manager = context.getSystemService(BluetoothManager::class.java)
    private val adapter get() = manager?.adapter
    private val scanner get() = adapter?.bluetoothLeScanner
    private var gatt: BluetoothGatt? = null
    private var controlCharacteristic: BluetoothGattCharacteristic? = null

    private val scanCallback = object : ScanCallback() {
        @SuppressLint("MissingPermission")
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val d = result.device
            val n = runCatching { result.scanRecord?.deviceName ?: d.name }.getOrNull()
                ?: "BLE ${d.address.takeLast(5)}"
            handler.post {
                if (devices.none { it.address == d.address }) {
                    devices = (devices + DeviceItem(d.address, n, d))
                        .sortedWith(compareByDescending<DeviceItem> { it.name.contains("DSP", true) }
                            .thenBy { it.name })
                }
            }
        }

        override fun onScanFailed(errorCode: Int) {
            handler.post {
                state = State.Disconnected
                lastInfo = "BLE scan error $errorCode"
            }
        }
    }

    @SuppressLint("MissingPermission")
    fun startScan() {
        stopScan()
        devices = emptyList()
        if (adapter?.isEnabled != true || scanner == null) {
            state = State.Disconnected
            lastInfo = "Bluetooth is off"
            return
        }
        state = State.Scanning
        lastInfo = "Scanning"
        runCatching { scanner?.startScan(scanCallback) }
            .onFailure {
                state = State.Disconnected
                lastInfo = it.message ?: "Scan failed"
            }
        handler.postDelayed({ stopScan() }, 10_000)
    }

    @SuppressLint("MissingPermission")
    fun stopScan() {
        runCatching { scanner?.stopScan(scanCallback) }
        if (state == State.Scanning) state = State.Disconnected
    }

    @SuppressLint("MissingPermission")
    fun connect(item: DeviceItem) {
        stopScan()
        gatt?.close()
        controlCharacteristic = null
        state = State.Connecting
        deviceName = item.name
        lastInfo = "Connecting ${item.name}"
        gatt = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            item.device.connectGatt(context, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
        } else {
            item.device.connectGatt(context, false, gattCallback)
        }
    }

    @SuppressLint("MissingPermission")
    fun disconnect() {
        runCatching { gatt?.disconnect() }
        runCatching { gatt?.close() }
        gatt = null
        controlCharacteristic = null
        state = State.Disconnected
        lastInfo = "Disconnected"
    }

    private val gattCallback = object : BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            handler.post {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    state = State.Connected
                    lastInfo = "Connected; discovering services"
                    runCatching { g.discoverServices() }
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    state = State.Disconnected
                    controlCharacteristic = null
                    lastInfo = "Disconnected"
                }
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            val found = findVerifiedCharacteristic(g.services)
            handler.post {
                controlCharacteristic = found
                lastInfo = if (found == null) {
                    "Connected; AB01 write characteristic not found"
                } else {
                    "Connected; AB01 characteristic found"
                }
            }
        }
    }

    private fun findVerifiedCharacteristic(services: List<BluetoothGattService>): BluetoothGattCharacteristic? {
        val target = DspProtocol.VERIFIED_CHARACTERISTIC_UUID
        return services.asSequence()
            .flatMap { it.characteristics.asSequence() }
            .firstOrNull { ch ->
                ch.uuid == target && ((ch.properties and BluetoothGattCharacteristic.PROPERTY_WRITE) != 0 ||
                    (ch.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0)
            }
    }

    @SuppressLint("MissingPermission")
    fun parameterChanged(change: DspProtocol.Change) {
        val payload = DspProtocol.encodeVerified(change) ?: run {
            lastInfo = "UI updated instantly; DSP frame not guessed"
            return
        }
        val g = gatt ?: return
        val ch = controlCharacteristic ?: return
        val noResponse = (ch.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0
        val type = if (noResponse) BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
        else BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
        runCatching {
            if (Build.VERSION.SDK_INT >= 33) {
                g.writeCharacteristic(ch, payload, type)
            } else {
                @Suppress("DEPRECATION")
                ch.writeType = type
                @Suppress("DEPRECATION")
                ch.value = payload
                @Suppress("DEPRECATION")
                g.writeCharacteristic(ch)
            }
        }.onFailure { lastInfo = it.message ?: "BLE write failed" }
    }
}
