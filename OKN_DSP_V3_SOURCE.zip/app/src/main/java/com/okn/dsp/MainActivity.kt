package com.okn.dsp

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

private val Bg = Color(0xFF00111F)
private val Panel = Color(0xFF06243A)
private val Panel2 = Color(0xFF031B2C)
private val Line = Color(0xFF0A4F7A)
private val Cyan = Color(0xFF00E5FF)
private val Blue = Color(0xFF078BFF)
private val Magenta = Color(0xFFFF35E8)
private val Green = Color(0xFF00F58B)
private val Orange = Color(0xFFFF9D2E)
private val Red = Color(0xFFFF3B6A)
private val Yellow = Color(0xFFFFE62D)
private val Purple = Color(0xFFB72CFF)
private val Muted = Color(0xFF9EC5E5)
private val TextWhite = Color(0xFFF5FAFF)
private val channelColors = listOf(Blue, Cyan, Green, Yellow, Orange, Red, Purple)
private val channelNames = listOf("Front L", "Front R", "Rear L", "Rear R", "Center", "Sub L", "Sub R")
private val channelX = listOf(19f, 139f, 258f, 377f, 496f, 616f, 735f)
private val channelW = listOf(115f, 113f, 113f, 113f, 113f, 113f, 110f)

enum class Screen { Home, EQ, Crossover, Delay, Output }

class EqBand(
    type: String,
    frequency: Float,
    gain: Float,
    q: Float,
    enabled: Boolean = true
) {
    var type by mutableStateOf(type)
    var frequency by mutableFloatStateOf(frequency)
    var gain by mutableFloatStateOf(gain)
    var q by mutableFloatStateOf(q)
    var enabled by mutableStateOf(enabled)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = Color.Black) {
                    OknDspApp()
                }
            }
        }
    }
}

@Composable
fun OknDspApp() {
    val context = LocalContext.current
    val ble = remember { BleController(context.applicationContext) }
    var screen by rememberSaveable { mutableStateOf(Screen.Home) }
    var channel by rememberSaveable { mutableIntStateOf(0) }
    var showDevices by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }

    val permissions = remember {
        if (Build.VERSION.SDK_INT >= 31) arrayOf(
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_CONNECT
        ) else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        if (grants.values.all { it }) {
            ble.startScan()
            showDevices = true
        }
    }

    fun openBlePicker() {
        val missing = permissions.any { context.checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing) launcher.launch(permissions) else {
            ble.startScan()
            showDevices = true
        }
    }

    ReferenceViewport {
        Box(Modifier.requiredSize(864.dp, 1536.dp).background(Bg)) {
            Image(
                painter = painterResource(
                    when (screen) {
                        Screen.Home -> R.drawable.ui_home
                        Screen.EQ -> R.drawable.ui_eq
                        Screen.Crossover -> R.drawable.ui_crossover
                        Screen.Delay -> R.drawable.ui_delay
                        Screen.Output -> R.drawable.ui_output
                    }
                ),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.FillBounds
            )

            ConnectionOverlay(ble, onClick = ::openBlePicker)
            Box(Modifier.refRect(786f, 18f, 64f, 70f).clickable { showSettings = true })

            if (screen != Screen.Home) {
                ChannelOverlay(channel = channel, onChannel = { channel = it })
            }

            when (screen) {
                Screen.Home -> HomeOverlay(ble)
                Screen.EQ -> EqOverlay(channel, ble)
                Screen.Crossover -> CrossoverOverlay(channel, ble)
                Screen.Delay -> DelayOverlay(ble)
                Screen.Output -> OutputOverlay(ble)
            }

            BottomNavigationOverlay(screen) { screen = it }
        }
    }

    if (showDevices) {
        DeviceDialog(
            ble = ble,
            onDismiss = {
                ble.stopScan()
                showDevices = false
            },
            onSelect = {
                ble.connect(it)
                showDevices = false
            }
        )
    }

    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            containerColor = Panel,
            title = { Text("OKN_DSP V3", color = TextWhite, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("Reference UI: 864 × 1536 (9:16)", color = TextWhite)
                    Spacer(Modifier.height(8.dp))
                    Text(ble.lastInfo, color = Muted)
                    Spacer(Modifier.height(8.dp))
                    Text("BLE characteristic: ${DspProtocol.VERIFIED_CHARACTERISTIC_UUID}", color = Muted, fontSize = 12.sp)
                }
            },
            confirmButton = {
                Button(onClick = { showSettings = false }, colors = ButtonDefaults.buttonColors(containerColor = Blue)) {
                    Text("Close")
                }
            }
        )
    }
}

@Composable
private fun ReferenceViewport(content: @Composable () -> Unit) {
    BoxWithConstraints(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.TopCenter) {
        val baseDensity = LocalDensity.current
        val sx = maxWidth.value / 864f
        val sy = maxHeight.value / 1536f
        val scale = min(sx, sy).coerceAtLeast(0.01f)
        CompositionLocalProvider(
            LocalDensity provides Density(
                density = baseDensity.density * scale,
                fontScale = baseDensity.fontScale
            )
        ) {
            content()
        }
    }
}

private fun Modifier.refRect(x: Float, y: Float, w: Float, h: Float): Modifier =
    this.offset(x.dp, y.dp).size(w.dp, h.dp)

@Composable
private fun ConnectionOverlay(ble: BleController, onClick: () -> Unit) {
    val connected = ble.state == BleController.State.Connected
    val scanning = ble.state == BleController.State.Scanning
    val connecting = ble.state == BleController.State.Connecting
    val differsFromReference = !connected || ble.deviceName != "DSP-7900"
    Box(
        Modifier.refRect(505f, 18f, 257f, 72f)
            .clickable { onClick() }
    ) {
        if (differsFromReference) {
            Box(
                Modifier.fillMaxSize()
                    .background(Color(0xF2051727), RoundedCornerShape(14.dp))
                    .border(1.dp, Color(0xFF1765A2), RoundedCornerShape(14.dp))
            )
            Row(Modifier.fillMaxSize().padding(horizontal = 22.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(20.dp).background(if (connected) Green else if (scanning || connecting) Yellow else Color(0xFF637789), CircleShape))
                Spacer(Modifier.width(19.dp))
                Column(Modifier.width(148.dp)) {
                    Text(
                        when {
                            connected -> "Connected"
                            scanning -> "Scanning"
                            connecting -> "Connecting"
                            else -> "Tap to Connect"
                        },
                        color = if (connected) Green else TextWhite,
                        fontSize = 19.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1
                    )
                    Text(ble.deviceName, color = Muted, fontSize = 16.sp, maxLines = 1)
                }
                Text("›", color = Muted, fontSize = 34.sp)
            }
        }
    }
}

@Composable
private fun ChannelOverlay(channel: Int, onChannel: (Int) -> Unit) {
    channelX.indices.forEach { i ->
        Box(Modifier.refRect(channelX[i], 103f, channelW[i], 80f).clickable { onChannel(i) })
    }

    if (channel != 0) {
        ChannelTabVisual(0, active = false)
        ChannelTabVisual(channel, active = true)
    }
}

@Composable
private fun ChannelTabVisual(index: Int, active: Boolean) {
    val shape = RoundedCornerShape(10.dp)
    Box(
        modifier = Modifier.refRect(channelX[index], 104f, channelW[index], 78f)
            .background(
                if (active) Brush.verticalGradient(listOf(Color(0xFF087DFF), Color(0xFF00CFF5)))
                else Brush.verticalGradient(listOf(Color(0xF2042236), Color(0xF2021727))),
                shape
            )
            .border(1.dp, if (active) Cyan else Line, shape),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("CH${index + 1}", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(channelNames[index], color = TextWhite, fontSize = 15.sp)
        }
    }
}

@Composable
private fun BottomNavigationOverlay(screen: Screen, onScreen: (Screen) -> Unit) {
    val screens = listOf(Screen.Home, Screen.EQ, Screen.Crossover, Screen.Delay, Screen.Output)
    val lefts = listOf(18f, 184f, 350f, 516f, 682f)
    screens.forEachIndexed { i, target ->
        Box(Modifier.refRect(lefts[i], 1380f, 164f, 118f).clickable { onScreen(target) })
    }
}

@Composable
private fun DeviceDialog(ble: BleController, onDismiss: () -> Unit, onSelect: (BleController.DeviceItem) -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text("Bluetooth DSP", color = TextWhite, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text(ble.lastInfo, color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                if (ble.devices.isEmpty()) {
                    Text("กำลังค้นหาอุปกรณ์ BLE…", color = TextWhite)
                } else {
                    ble.devices.take(12).forEach { item ->
                        Row(
                            modifier = Modifier.clickable { onSelect(item) }.padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.size(10.dp).background(Cyan, CircleShape))
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(item.name, color = TextWhite)
                                Text(item.address, color = Muted, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = { ble.startScan() }, colors = ButtonDefaults.buttonColors(containerColor = Blue)) {
                Text("Scan")
            }
        },
        dismissButton = {
            Button(onClick = onDismiss, colors = ButtonDefaults.buttonColors(containerColor = Panel2)) {
                Text("Close")
            }
        }
    )
}

@Composable
private fun HomeOverlay(ble: BleController) {
    var master by rememberSaveable { mutableFloatStateOf(-3f) }
    var bass by rememberSaveable { mutableFloatStateOf(4f) }
    var cutoff by rememberSaveable { mutableFloatStateOf(100f) }
    var bassBoost by rememberSaveable { mutableFloatStateOf(3f) }
    var middle by rememberSaveable { mutableFloatStateOf(-2f) }
    var treble by rememberSaveable { mutableFloatStateOf(1f) }
    var source by rememberSaveable { mutableStateOf("High Level (Speaker)") }
    var preset by rememberSaveable { mutableStateOf("Flat") }

    HomeSlider(382f, 163f, 288f, 55f, 699f, 150f, master, -3f, -60f..12f, Blue, "${fmt(master, 1)} dB") {
        master = it
        ble.parameterChanged(DspProtocol.Change("home", parameter = "master_volume", numericValue = it))
    }
    HomeSlider(382f, 310f, 288f, 55f, 699f, 299f, bass, 4f, -12f..12f, Cyan, "${fmt(bass, 1)} dB") {
        bass = it
        ble.parameterChanged(DspProtocol.Change("home", parameter = "bass_volume", numericValue = it))
    }
    HomeSlider(382f, 456f, 288f, 55f, 699f, 446f, cutoff, 100f, 20f..500f, Magenta, "${fmt(cutoff, 0)} Hz", logarithmic = true) {
        cutoff = it
        ble.parameterChanged(DspProtocol.Change("home", parameter = "bass_cutoff", numericValue = it))
    }
    HomeSlider(382f, 604f, 288f, 55f, 699f, 594f, bassBoost, 3f, -10f..12f, Red, "${fmt(bassBoost, 1)} dB") {
        bassBoost = it
        ble.parameterChanged(DspProtocol.Change("home", parameter = "bass_boost", numericValue = it))
    }
    HomeSlider(382f, 753f, 288f, 55f, 699f, 743f, middle, -2f, -12f..12f, Blue, "${fmt(middle, 1)} dB") {
        middle = it
        ble.parameterChanged(DspProtocol.Change("home", parameter = "middle_boost", numericValue = it))
    }
    HomeSlider(382f, 899f, 288f, 55f, 699f, 891f, treble, 1f, -12f..12f, Magenta, "${fmt(treble, 1)} dB") {
        treble = it
        ble.parameterChanged(DspProtocol.Change("home", parameter = "treble_boost", numericValue = it))
    }

    RefDropdown(
        x = 139f, y = 1115f, w = 270f, h = 52f,
        value = source,
        initialValue = "High Level (Speaker)",
        options = listOf("High Level (Speaker)", "Low Level (RCA)", "Bluetooth")
    ) {
        source = it
        ble.parameterChanged(DspProtocol.Change("home", parameter = "audio_source", textValue = it))
    }

    RefDropdown(
        x = 139f, y = 1290f, w = 270f, h = 51f,
        value = preset,
        initialValue = "Flat",
        options = listOf("Flat", "Driver", "SQL", "Bass", "Custom 1")
    ) {
        preset = it
        ble.parameterChanged(DspProtocol.Change("home", parameter = "system_preset", textValue = it))
    }
}

@Composable
private fun HomeSlider(
    x: Float, y: Float, w: Float, h: Float,
    valueX: Float, valueY: Float,
    value: Float, initialValue: Float,
    range: ClosedFloatingPointRange<Float>,
    color: Color,
    display: String,
    logarithmic: Boolean = false,
    onValue: (Float) -> Unit
) {
    RefSlider(x, y, w, h, value, initialValue, range, color, logarithmic, onValue)
    RefValueBox(valueX, valueY, 126f, 65f, display, changed = abs(value - initialValue) > .001f)
}

@Composable
private fun EqOverlay(channel: Int, ble: BleController) {
    val bands = remember {
        mutableStateListOf<EqBand>().apply {
            add(EqBand("PEQ", 32f, -3f, .70f))
            add(EqBand("Low Shelf", 100f, 2.5f, 1f))
            add(EqBand("PEQ", 200f, 6f, 1.2f))
            add(EqBand("PEQ", 500f, -4f, 1f))
            add(EqBand("PEQ", 2000f, 3f, 1f))
            add(EqBand("High Shelf", 10000f, -2f, .70f))
            val defaults = listOf(63f, 125f, 250f, 1000f, 4000f, 8000f, 16000f, 50f, 315f)
            defaults.forEach { add(EqBand("PEQ", it, 0f, 1f)) }
        }
    }
    var group by rememberSaveable { mutableIntStateOf(0) }
    var selectedChannel by rememberSaveable(channel) { mutableIntStateOf(channel) }
    val starts = listOf(0, 6, 12)
    val counts = listOf(6, 6, 3)
    val start = starts[group]
    val count = counts[group]

    RefDropdown(484f, 217f, 180f, 72f, "CH${selectedChannel + 1} - ${channelNames[selectedChannel]}", "CH1 - Front L",
        channelNames.indices.map { "CH${it + 1} - ${channelNames[it]}" }) { text ->
        val idx = text.substringAfter("CH").substringBefore(" ").toIntOrNull()?.minus(1) ?: 0
        selectedChannel = idx.coerceIn(0, 6)
    }

    Box(Modifier.refRect(676f, 216f, 160f, 74f).clickable {
        bands.forEach { it.gain = 0f; it.enabled = true }
        ble.parameterChanged(DspProtocol.Change("eq", selectedChannel, "reset_eq", boolValue = true))
    })

    val tabRects = listOf(18f to 221f, 244f to 203f, 455f to 201f)
    tabRects.forEachIndexed { i, pair ->
        Box(Modifier.refRect(pair.first, 651f, pair.second, 58f).clickable { group = i })
    }
    if (group != 0) {
        RefTabVisual(18f, 651f, 221f, 58f, "Bands 1 - 6", false)
        val r = tabRects[group]
        RefTabVisual(r.first, 651f, r.second, 58f, if (group == 1) "Bands 7 - 12" else "Bands 13 - 15", true)
    }

    val rowYs = listOf(781f, 843f, 905f, 968f, 1030f, 1093f)
    repeat(6) { row ->
        if (row < count) {
            val index = start + row
            val band = bands[index]
            val force = group != 0
            if (force) {
                RefRowIndex(34f, rowYs[row], 62f, 51f, index, channelColors[index % channelColors.size])
            }
            RefDropdown(101f, rowYs[row], 174f, 49f, band.type, if (group == 0) listOf("PEQ", "Low Shelf", "PEQ", "PEQ", "PEQ", "High Shelf")[row] else "", listOf("PEQ", "Low Shelf", "High Shelf"), forceDraw = force) {
                band.type = it
                ble.parameterChanged(DspProtocol.Change("eq", selectedChannel, "band_${index + 1}_type", textValue = it))
            }
            RefStepper(289f, rowYs[row], 135f, 49f, formatFreq(band.frequency), forceDraw = force,
                onMinus = {
                    band.frequency = nextFrequency(band.frequency, -1)
                    ble.parameterChanged(DspProtocol.Change("eq", selectedChannel, "band_${index + 1}_frequency", numericValue = band.frequency))
                },
                onPlus = {
                    band.frequency = nextFrequency(band.frequency, 1)
                    ble.parameterChanged(DspProtocol.Change("eq", selectedChannel, "band_${index + 1}_frequency", numericValue = band.frequency))
                }
            )
            RefStepper(435f, rowYs[row], 141f, 49f, "${fmt(band.gain, 1)} dB", forceDraw = force,
                onMinus = { band.gain = (band.gain - .5f).coerceAtLeast(-12f); ble.parameterChanged(DspProtocol.Change("eq", selectedChannel, "band_${index + 1}_gain", numericValue = band.gain)) },
                onPlus = { band.gain = (band.gain + .5f).coerceAtMost(12f); ble.parameterChanged(DspProtocol.Change("eq", selectedChannel, "band_${index + 1}_gain", numericValue = band.gain)) }
            )
            RefStepper(590f, rowYs[row], 146f, 49f, fmt(band.q, 2), forceDraw = force,
                onMinus = { band.q = (band.q - .05f).coerceAtLeast(.1f); ble.parameterChanged(DspProtocol.Change("eq", selectedChannel, "band_${index + 1}_q", numericValue = band.q)) },
                onPlus = { band.q = (band.q + .05f).coerceAtMost(10f); ble.parameterChanged(DspProtocol.Change("eq", selectedChannel, "band_${index + 1}_q", numericValue = band.q)) }
            )
            RefSwitch(756f, rowYs[row] + 1f, 77f, 47f, band.enabled, initial = true, forceDraw = force) {
                band.enabled = it
                ble.parameterChanged(DspProtocol.Change("eq", selectedChannel, "band_${index + 1}_power", boolValue = it))
            }
        }
    }

    RefDropdown(140f, 1277f, 187f, 51f, "Custom 1", "Custom 1", listOf("Custom 1", "Custom 2", "Factory")) { }
    Box(Modifier.refRect(341f, 1219f, 134f, 113f).clickable {
        ble.parameterChanged(DspProtocol.Change("eq", selectedChannel, "preset_save", textValue = "Custom 1"))
    })
    Box(Modifier.refRect(485f, 1219f, 153f, 113f).clickable {
        ble.parameterChanged(DspProtocol.Change("eq", selectedChannel, "preset_manage", textValue = "Custom 1"))
    })
}

@Composable
private fun CrossoverOverlay(channel: Int, ble: BleController) {
    var magnitude by rememberSaveable { mutableStateOf("Magnitude") }
    var hpfType by rememberSaveable { mutableStateOf("Linkwitz-Riley") }
    var hpfFreq by rememberSaveable { mutableFloatStateOf(100f) }
    var hpfSlope by rememberSaveable { mutableStateOf("24 dB/Oct") }
    var hpfBypass by rememberSaveable { mutableStateOf(false) }
    var lpfType by rememberSaveable { mutableStateOf("Linkwitz-Riley") }
    var lpfFreq by rememberSaveable { mutableFloatStateOf(1000f) }
    var lpfSlope by rememberSaveable { mutableStateOf("24 dB/Oct") }
    var lpfBypass by rememberSaveable { mutableStateOf(false) }
    var phase by rememberSaveable { mutableIntStateOf(0) }
    var polarity by rememberSaveable { mutableStateOf("Normal") }
    var linked by rememberSaveable { mutableStateOf(true) }
    var outputMode by rememberSaveable { mutableStateOf("Stereo") }

    RefDropdown(492f, 234f, 172f, 55f, magnitude, "Magnitude", listOf("Magnitude", "Phase")) { magnitude = it }
    Box(Modifier.refRect(679f, 230f, 153f, 61f).clickable {
        hpfType = "Linkwitz-Riley"; hpfFreq = 100f; hpfSlope = "24 dB/Oct"; hpfBypass = false
        lpfType = "Linkwitz-Riley"; lpfFreq = 1000f; lpfSlope = "24 dB/Oct"; lpfBypass = false
        phase = 0; polarity = "Normal"; linked = true; outputMode = "Stereo"
        ble.parameterChanged(DspProtocol.Change("crossover", channel, "reset", boolValue = true))
    })

    RefSwitch(750f, 712f, 73f, 47f, hpfBypass, false) { hpfBypass = it; ble.parameterChanged(DspProtocol.Change("crossover", channel, "hpf_bypass", boolValue = it)) }
    RefDropdown(54f, 839f, 227f, 48f, hpfType, "Linkwitz-Riley", listOf("Linkwitz-Riley", "Butterworth", "Bessel")) { hpfType = it; ble.parameterChanged(DspProtocol.Change("crossover", channel, "hpf_type", textValue = it)) }
    RefDropdown(321f, 839f, 229f, 48f, formatFreq(hpfFreq), "100 Hz", crossoverFrequencies.map(::formatFreq)) {
        hpfFreq = parseFrequency(it); ble.parameterChanged(DspProtocol.Change("crossover", channel, "hpf_frequency", numericValue = hpfFreq))
    }
    RefDropdown(589f, 839f, 224f, 48f, hpfSlope, "24 dB/Oct", listOf("6 dB/Oct", "12 dB/Oct", "18 dB/Oct", "24 dB/Oct", "36 dB/Oct", "48 dB/Oct")) {
        hpfSlope = it; ble.parameterChanged(DspProtocol.Change("crossover", channel, "hpf_slope", textValue = it))
    }

    RefSwitch(750f, 960f, 73f, 47f, lpfBypass, false) { lpfBypass = it; ble.parameterChanged(DspProtocol.Change("crossover", channel, "lpf_bypass", boolValue = it)) }
    RefDropdown(54f, 1085f, 227f, 48f, lpfType, "Linkwitz-Riley", listOf("Linkwitz-Riley", "Butterworth", "Bessel")) { lpfType = it; ble.parameterChanged(DspProtocol.Change("crossover", channel, "lpf_type", textValue = it)) }
    RefDropdown(321f, 1085f, 229f, 48f, formatFreq(lpfFreq), "1.0 kHz", crossoverFrequencies.map(::formatFreq)) {
        lpfFreq = parseFrequency(it); ble.parameterChanged(DspProtocol.Change("crossover", channel, "lpf_frequency", numericValue = lpfFreq))
    }
    RefDropdown(589f, 1085f, 224f, 48f, lpfSlope, "24 dB/Oct", listOf("6 dB/Oct", "12 dB/Oct", "18 dB/Oct", "24 dB/Oct", "36 dB/Oct", "48 dB/Oct")) {
        lpfSlope = it; ble.parameterChanged(DspProtocol.Change("crossover", channel, "lpf_slope", textValue = it))
    }

    RefStepper(42f, 1304f, 195f, 54f, "${phase}°", forceDraw = phase != 0,
        onMinus = { phase = (phase - 1).coerceAtLeast(-180); ble.parameterChanged(DspProtocol.Change("crossover", channel, "phase", numericValue = phase.toFloat())) },
        onPlus = { phase = (phase + 1).coerceAtMost(180); ble.parameterChanged(DspProtocol.Change("crossover", channel, "phase", numericValue = phase.toFloat())) })
    RefStepper(252f, 1304f, 191f, 54f, polarity, forceDraw = polarity != "Normal",
        onMinus = { polarity = if (polarity == "Normal") "Inverted" else "Normal"; ble.parameterChanged(DspProtocol.Change("crossover", channel, "polarity", textValue = polarity)) },
        onPlus = { polarity = if (polarity == "Normal") "Inverted" else "Normal"; ble.parameterChanged(DspProtocol.Change("crossover", channel, "polarity", textValue = polarity)) })
    RefSwitch(496f, 1306f, 92f, 51f, linked, true) { linked = it; ble.parameterChanged(DspProtocol.Change("crossover", channel, "link_lr", boolValue = it)) }
    RefDropdown(626f, 1303f, 188f, 55f, outputMode, "Stereo", listOf("Stereo", "Mono", "L", "R")) { outputMode = it; ble.parameterChanged(DspProtocol.Change("crossover", channel, "output_mode", textValue = it)) }

    CrossoverMarkers(hpfFreq, lpfFreq)
}

@Composable
private fun CrossoverMarkers(hpf: Float, lpf: Float) {
    val hpfChanged = abs(hpf - 100f) > .01f
    val lpfChanged = abs(lpf - 1000f) > .01f
    if (!hpfChanged && !lpfChanged) return
    Canvas(Modifier.refRect(76f, 371f, 752f, 245f)) {
        fun pxFor(freq: Float): Float {
            val f = ((ln(freq.coerceIn(20f, 20000f)) - ln(20f)) / (ln(20000f) - ln(20f))).toFloat()
            return size.width * f
        }
        if (hpfChanged) {
            val x = pxFor(hpf)
            drawCircle(Cyan, 12f, Offset(x, size.height * .38f))
            drawCircle(TextWhite, 6f, Offset(x, size.height * .38f))
        }
        if (lpfChanged) {
            val x = pxFor(lpf)
            drawCircle(Magenta, 12f, Offset(x, size.height * .38f))
            drawCircle(TextWhite, 6f, Offset(x, size.height * .38f))
        }
    }
}

@Composable
private fun DelayOverlay(ble: BleController) {
    val initial = listOf(0f, 1.25f, 2.60f, 2.30f, .80f, 3.10f, 1.90f)
    val delays = remember { mutableStateListOf<Float>().apply { addAll(initial) } }
    var unitMs by rememberSaveable { mutableStateOf(true) }
    var seat by rememberSaveable { mutableStateOf("Driver (Left)") }

    Box(Modifier.refRect(487f, 222f, 80f, 58f).clickable { unitMs = true })
    Box(Modifier.refRect(568f, 222f, 80f, 58f).clickable { unitMs = false })
    if (!unitMs) {
        RefTabVisual(487f, 222f, 80f, 58f, "ms", false)
        RefTabVisual(568f, 222f, 80f, 58f, "cm", true)
    }
    Box(Modifier.refRect(663f, 221f, 168f, 59f).clickable {
        val first = delays.firstOrNull() ?: 0f
        delays.indices.forEach { delays[it] = first }
        ble.parameterChanged(DspProtocol.Change("delay", parameter = "sync_all", numericValue = first))
    })
    RefDropdown(583f, 368f, 230f, 48f, seat, "Driver (Left)", listOf("Driver (Left)", "Passenger (Right)", "Center")) { seat = it }

    val rowY = listOf(750f, 837f, 925f, 1012f, 1099f, 1187f, 1274f)
    repeat(7) { i ->
        RefSlider(198f, rowY[i], 452f, 52f, delays[i], initial[i], 0f..10f, channelColors[i], false) {
            delays[i] = it
            ble.parameterChanged(DspProtocol.Change("delay", i, "delay_ms", numericValue = it))
        }
        val cm = delays[i] * 34.3f
        val changed = abs(delays[i] - initial[i]) > .001f || !unitMs
        RefValueBox(679f, rowY[i] - 4f, 157f, 64f,
            if (unitMs) "${fmt(delays[i], 2)} ms\n${fmt(cm, 1)} cm" else "${fmt(cm, 1)} cm\n${fmt(delays[i], 2)} ms",
            changed = changed,
            fontSize = 15f)
    }
}

@Composable
private fun OutputOverlay(ble: BleController) {
    val initialGains = listOf(-3f, -2.5f, -4f, -1f, -2f, -3.5f, -4.5f)
    var master by rememberSaveable { mutableFloatStateOf(-1f) }
    val gains = remember { mutableStateListOf<Float>().apply { addAll(initialGains) } }
    val mute = remember { mutableStateListOf(false, false, false, false, false, false, false) }
    val solo = remember { mutableStateListOf(false, false, false, false, false, false, false) }
    val phase = remember { mutableStateListOf(false, false, false, false, false, false, false) }
    val link = remember { mutableStateListOf(true, true, false, false, false, false, false) }

    Box(Modifier.refRect(478f, 233f, 167f, 66f).clickable {
        mute.indices.forEach { mute[it] = false }
        ble.parameterChanged(DspProtocol.Change("output", parameter = "all_mute_off", boolValue = true))
    })
    Box(Modifier.refRect(656f, 233f, 174f, 66f).clickable {
        master = -1f
        gains.indices.forEach { gains[it] = initialGains[it] }
        ble.parameterChanged(DspProtocol.Change("output", parameter = "reset_levels", boolValue = true))
    })

    RefSlider(588f, 424f, 231f, 58f, master, -1f, -60f..12f, Cyan, false) {
        master = it
        ble.parameterChanged(DspProtocol.Change("output", parameter = "master_output", numericValue = it))
    }
    RefValueBox(721f, 352f, 99f, 52f, "${fmt(master, 1)} dB", abs(master + 1f) > .001f, fontSize = 17f)

    val rowY = listOf(580f, 687f, 794f, 901f, 1008f, 1115f, 1222f)
    repeat(7) { i ->
        RefSlider(193f, rowY[i], 235f, 52f, gains[i], initialGains[i], -60f..12f, channelColors[i], false) {
            gains[i] = it
            ble.parameterChanged(DspProtocol.Change("output", i, "gain", numericValue = it))
        }
        RefValueBox(443f, rowY[i] - 2f, 92f, 52f, "${fmt(gains[i], 1)} dB", abs(gains[i] - initialGains[i]) > .001f, fontSize = 16f)
        RefButtonState(548f, rowY[i] - 7f, 63f, 74f, mute[i]) {
            mute[i] = !mute[i]; ble.parameterChanged(DspProtocol.Change("output", i, "mute", boolValue = mute[i]))
        }
        RefButtonState(622f, rowY[i] - 7f, 63f, 74f, solo[i]) {
            solo[i] = !solo[i]; ble.parameterChanged(DspProtocol.Change("output", i, "solo", boolValue = solo[i]))
        }
        RefButtonState(696f, rowY[i] - 7f, 63f, 74f, phase[i]) {
            phase[i] = !phase[i]; ble.parameterChanged(DspProtocol.Change("output", i, "phase", boolValue = phase[i]))
        }
        if (i < 2) {
            RefButtonState(772f, rowY[i] - 7f, 63f, 74f, link[i], initial = true) {
                link[i] = !link[i]; ble.parameterChanged(DspProtocol.Change("output", i, "link", boolValue = link[i]))
            }
        }
    }
}

@Composable
private fun RefSlider(
    x: Float, y: Float, w: Float, h: Float,
    value: Float,
    initialValue: Float,
    range: ClosedFloatingPointRange<Float>,
    color: Color,
    logarithmic: Boolean = false,
    onValue: (Float) -> Unit
) {
    var widthPx by remember { mutableFloatStateOf(1f) }
    fun fractionToValue(fraction: Float): Float {
        val f = fraction.coerceIn(0f, 1f)
        return if (logarithmic) {
            val a = ln(range.start)
            val b = ln(range.endInclusive)
            kotlin.math.exp(a + (b - a) * f)
        } else range.start + (range.endInclusive - range.start) * f
    }
    fun valueToFraction(v: Float): Float = if (logarithmic) {
        ((ln(v.coerceIn(range.start, range.endInclusive)) - ln(range.start)) / (ln(range.endInclusive) - ln(range.start))).coerceIn(0f, 1f)
    } else ((v - range.start) / (range.endInclusive - range.start)).coerceIn(0f, 1f)

    val changed = abs(value - initialValue) > .001f
    Box(
        Modifier.refRect(x, y, w, h)
            .onSizeChanged { widthPx = max(1f, it.width.toFloat()) }
            .pointerInput(range.start, range.endInclusive, logarithmic) {
                detectTapGestures { p -> onValue(fractionToValue(p.x / widthPx)) }
            }
            .pointerInput(range.start, range.endInclusive, logarithmic) {
                detectDragGestures { change, _ ->
                    change.consume()
                    onValue(fractionToValue(change.position.x / widthPx))
                }
            }
    ) {
        if (changed) {
            Canvas(Modifier.fillMaxSize()) {
                val cy = size.height / 2f
                val fraction = valueToFraction(value)
                val thumbX = size.width * fraction
                drawLine(Color(0xFF244967), Offset(0f, cy), Offset(size.width, cy), strokeWidth = 13f, cap = StrokeCap.Round)
                drawLine(color, Offset(0f, cy), Offset(thumbX, cy), strokeWidth = 13f, cap = StrokeCap.Round)
                drawCircle(color.copy(alpha = .22f), 28f, Offset(thumbX, cy))
                drawCircle(TextWhite, 18f, Offset(thumbX, cy))
            }
        }
    }
}

@Composable
private fun RefValueBox(x: Float, y: Float, w: Float, h: Float, text: String, changed: Boolean, fontSize: Float = 18f) {
    if (!changed) return
    Box(
        Modifier.refRect(x, y, w, h)
            .background(Color(0xF0041424), RoundedCornerShape(10.dp))
            .border(1.dp, Color(0xFF315D82), RoundedCornerShape(10.dp)),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = TextWhite, fontSize = fontSize.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, maxLines = 2)
    }
}

@Composable
private fun RefDropdown(
    x: Float, y: Float, w: Float, h: Float,
    value: String,
    initialValue: String,
    options: List<String>,
    forceDraw: Boolean = false,
    onValue: (String) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    Box(Modifier.refRect(x, y, w, h)) {
        if (forceDraw || value != initialValue) {
            Row(
                Modifier.fillMaxSize()
                    .background(Color(0xF0041728), RoundedCornerShape(8.dp))
                    .border(1.dp, Color(0xFF315D82), RoundedCornerShape(8.dp))
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(value, color = TextWhite, fontSize = 16.sp, modifier = Modifier.width((w - 44f).dp), maxLines = 1)
                Text("⌄", color = Muted, fontSize = 20.sp)
            }
        }
        Box(Modifier.fillMaxSize().clickable { open = true })
        DropdownMenu(expanded = open, onDismissRequest = { open = false }, modifier = Modifier.background(Panel2)) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option, color = TextWhite) },
                    onClick = { onValue(option); open = false }
                )
            }
        }
    }
}

@Composable
private fun RefStepper(
    x: Float, y: Float, w: Float, h: Float,
    text: String,
    forceDraw: Boolean = true,
    onMinus: () -> Unit,
    onPlus: () -> Unit
) {
    Box(Modifier.refRect(x, y, w, h)) {
        if (forceDraw) {
            Row(
                Modifier.fillMaxSize()
                    .background(Color(0xF0041728), RoundedCornerShape(8.dp))
                    .border(1.dp, Color(0xFF315D82), RoundedCornerShape(8.dp)),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("‹", color = Muted, fontSize = 24.sp, modifier = Modifier.width(28.dp), textAlign = TextAlign.Center)
                Text(text, color = TextWhite, fontSize = 15.sp, modifier = Modifier.width((w - 56f).dp), textAlign = TextAlign.Center, maxLines = 1)
                Text("›", color = Muted, fontSize = 24.sp, modifier = Modifier.width(28.dp), textAlign = TextAlign.Center)
            }
        }
        Box(Modifier.offset(0.dp, 0.dp).size((w / 2f).dp, h.dp).clickable { onMinus() })
        Box(Modifier.offset((w / 2f).dp, 0.dp).size((w / 2f).dp, h.dp).clickable { onPlus() })
    }
}

@Composable
private fun RefSwitch(x: Float, y: Float, w: Float, h: Float, checked: Boolean, initial: Boolean, forceDraw: Boolean = false, onChecked: (Boolean) -> Unit) {
    Box(Modifier.refRect(x, y, w, h).clickable { onChecked(!checked) }) {
        if (forceDraw || checked != initial) {
            val shape = RoundedCornerShape((h / 2f).dp)
            Box(
                Modifier.fillMaxSize()
                    .background(if (checked) Color(0xFF078BFF) else Color(0xFF244364), shape)
                    .border(1.dp, if (checked) Cyan.copy(alpha = .7f) else Color(0xFF38506A), shape)
            )
            Box(
                Modifier.offset(if (checked) (w - h + 4f).dp else 4.dp, 4.dp)
                    .size((h - 8f).dp)
                    .background(TextWhite, CircleShape)
            )
        }
    }
}

@Composable
private fun RefTabVisual(x: Float, y: Float, w: Float, h: Float, text: String, active: Boolean) {
    Box(
        Modifier.refRect(x, y, w, h)
            .background(
                if (active) Brush.verticalGradient(listOf(Color(0xFF078BFF), Color(0xFF00CFF5)))
                else Brush.verticalGradient(listOf(Color(0xF2042236), Color(0xF2021727))),
                RoundedCornerShape(9.dp)
            )
            .border(1.dp, if (active) Cyan else Line, RoundedCornerShape(9.dp)),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = TextWhite, fontSize = 18.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
private fun RefRowIndex(x: Float, y: Float, w: Float, h: Float, index: Int, color: Color) {
    Row(Modifier.refRect(x, y, w, h).background(Color(0xE9041728)), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(22.dp).background(color, CircleShape))
        Spacer(Modifier.width(10.dp))
        Text("${index + 1}", color = TextWhite, fontSize = 17.sp)
    }
}

@Composable
private fun RefButtonState(x: Float, y: Float, w: Float, h: Float, checked: Boolean, initial: Boolean = false, onClick: () -> Unit) {
    Box(Modifier.refRect(x, y, w, h).clickable { onClick() }) {
        if (checked != initial) {
            Box(
                Modifier.fillMaxSize()
                    .background(if (checked) Color(0xC9064B88) else Color(0xE9041728), RoundedCornerShape(9.dp))
                    .border(2.dp, if (checked) Cyan else Line, RoundedCornerShape(9.dp))
            )
        }
    }
}

private val crossoverFrequencies = listOf(20f, 25f, 31.5f, 40f, 50f, 63f, 80f, 100f, 125f, 160f, 200f, 250f, 315f, 400f, 500f, 630f, 800f, 1000f, 1250f, 1600f, 2000f, 2500f, 3150f, 4000f, 5000f, 6300f, 8000f, 10000f, 12500f, 16000f, 20000f)
private val eqFrequencies = listOf(20f, 25f, 32f, 40f, 50f, 63f, 80f, 100f, 125f, 160f, 200f, 250f, 315f, 400f, 500f, 630f, 800f, 1000f, 1250f, 1600f, 2000f, 2500f, 3150f, 4000f, 5000f, 6300f, 8000f, 10000f, 12500f, 16000f, 20000f)

private fun nextFrequency(current: Float, direction: Int): Float {
    val idx = eqFrequencies.indices.minByOrNull { abs(eqFrequencies[it] - current) } ?: 0
    return eqFrequencies[(idx + direction).coerceIn(0, eqFrequencies.lastIndex)]
}

private fun parseFrequency(text: String): Float {
    val clean = text.lowercase(Locale.US).replace("hz", "").trim()
    return if (clean.contains("k")) {
        clean.replace("k", "").trim().toFloatOrNull()?.times(1000f) ?: 1000f
    } else clean.toFloatOrNull() ?: 100f
}

private fun fmt(value: Float, decimals: Int): String = String.format(Locale.US, "%.${decimals}f", value)
private fun formatFreq(value: Float): String = if (value >= 1000f) "${fmt(value / 1000f, 1)} kHz" else if (value % 1f == 0f) "${fmt(value, 0)} Hz" else "${fmt(value, 1)} Hz"
