package com.okn.dsp

import java.util.UUID

/**
 * Protocol facts that are verified from the user's captured data.
 * We intentionally do not invent DSP command bytes.
 */
object DspProtocol {
    val VERIFIED_CHARACTERISTIC_UUID: UUID = UUID.fromString("0000ab01-0000-1000-8000-00805f9b34fb")

    data class Change(
        val page: String,
        val channel: Int? = null,
        val parameter: String,
        val numericValue: Float? = null,
        val textValue: String? = null,
        val boolValue: Boolean? = null
    )

    /**
     * Returns null until a byte-for-byte command frame has been verified from a real DSP capture.
     * This prevents V3 from transmitting guessed bytes to the hardware.
     */
    fun encodeVerified(change: Change): ByteArray? = null
}
