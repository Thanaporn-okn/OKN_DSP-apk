# V2: no custom shrinking rules required.
