# OKN DSP V11.1 — AB01 → AB02 → AB03 Diagnostic

แก้ไข V11.1:
- เพิ่ม HomePage StatefulWidget ที่ขาดใน V11
- AB01 = READ เท่านั้น
- AB02 = เปิด Notify และเก็บ packet
- AB03 = เปิด Notify และเก็บ packet
- ไม่มีการส่ง payload ควบคุม DSP
- มีปุ่มคัดลอกผล HEX ทั้งหมด

ลำดับการทดสอบ:
1. เลือกอุปกรณ์ช่องควบคุม DSP
2. Connect
3. ระบบเปิด Notify AB02 และ AB03
4. กดเริ่มทดสอบ AB01 → AB02 → AB03
5. ส่งภาพ/ผล HEX กลับมาเพื่อแกะ protocol ต่อ
