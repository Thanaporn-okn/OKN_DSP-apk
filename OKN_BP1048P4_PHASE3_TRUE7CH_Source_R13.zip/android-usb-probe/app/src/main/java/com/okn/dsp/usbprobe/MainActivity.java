package com.okn.dsp.usbprobe;

import android.app.*;
import android.os.*;
import android.content.*;
import android.hardware.usb.*;
import android.hardware.input.InputManager;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.widget.*;
import java.util.*;
import java.text.SimpleDateFormat;
import java.nio.charset.StandardCharsets;
import java.io.*;

public final class MainActivity extends Activity {
    private static final int OBSERVED_VID = 0x6324;
    private static final int OBSERVED_PID = 0x1719;
    private static final String ACTION_USB_PERMISSION = "com.okn.dsp.usbprobe.USB_PERMISSION";

    private static final byte[] EXPECTED_IF4_REPORT = new byte[] {
        0x06,0x00,(byte)0xFF,0x0A,(byte)0xAA,0x55,(byte)0xA1,0x01,
        0x15,0x00,0x26,(byte)0xFF,0x00,0x75,0x08,(byte)0x96,0x00,0x01,
        0x09,0x01,(byte)0x81,0x02,(byte)0x96,0x00,0x01,0x09,0x01,(byte)0x91,0x02,
        (byte)0x95,0x08,0x09,0x01,(byte)0xB1,0x02,(byte)0xC0
    };
    private static final byte[] EXPECTED_FEATURE = new byte[] {0x00,0x01,0x00,0x03,0x04,0x00,0x08,0x00};

    private UsbManager usb;
    private TextView log;
    private UsbDevice selected;
    private InputManager inputManager;

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            if (!ACTION_USB_PERMISSION.equals(i.getAction())) return;
            UsbDevice d = i.getParcelableExtra(UsbManager.EXTRA_DEVICE);
            if (i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false) && d != null) {
                selected = d;
                probeReadOnly(d);
            } else add("USB permission denied");
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        usb = (UsbManager) getSystemService(USB_SERVICE);
        inputManager = (InputManager) getSystemService(INPUT_SERVICE);
        buildUi();
        IntentFilter f = new IntentFilter(ACTION_USB_PERMISSION);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, RECEIVER_NOT_EXPORTED);
        else registerReceiver(receiver, f);
        readExitHistory();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        try { unregisterReceiver(receiver); } catch (Exception ignored) {}
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28,28,28,28);

        TextView title = new TextView(this);
        title.setText("OKN BP1048P4 USB-C Diagnostic R12\nREAD-ONLY USB + Android InputDevice classifier/watch\nNO force detach / NO SET_REPORT / NO OUT / NO erase / NO firmware write");
        title.setTextSize(18);

        Button exits = new Button(this);
        exits.setText("1) READ R9 / APP EXIT HISTORY");
        Button scan = new Button(this);
        scan.setText("2) READ-ONLY USB SCAN + QUALIFY");
        Button inputs = new Button(this);
        inputs.setText("3) READ ANDROID INPUT DEVICES + PASSIVE WATCH");

        log = new TextView(this);
        log.setTextIsSelectable(true);
        ScrollView sv = new ScrollView(this);
        sv.addView(log);

        root.addView(title);
        root.addView(exits);
        root.addView(scan);
        root.addView(inputs);
        root.addView(sv, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);

        exits.setOnClickListener(v -> readExitHistory());
        scan.setOnClickListener(v -> scan());
        inputs.setOnClickListener(v -> scanAndroidInputDevices());
    }

    private void readExitHistory() {
        add("=== ANDROID APP EXIT HISTORY ===");
        add("Model: "+Build.MANUFACTURER+" "+Build.MODEL+" SDK="+Build.VERSION.SDK_INT);
        add("Build fingerprint: "+Build.FINGERPRINT);
        if (Build.VERSION.SDK_INT < 30) {
            add("ApplicationExitInfo unavailable below Android 11 / API 30.");
            return;
        }
        try {
            ActivityManager am=(ActivityManager)getSystemService(ACTIVITY_SERVICE);
            List<ApplicationExitInfo> infos=am.getHistoricalProcessExitReasons(getPackageName(),0,10);
            add("Historical exits: "+infos.size());
            SimpleDateFormat fmt=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS Z",Locale.US);
            int idx=0;
            for (ApplicationExitInfo info: infos) {
                idx++;
                add("EXIT #"+idx+": time="+fmt.format(new Date(info.getTimestamp())));
                add("  reason="+info.getReason()+" ("+exitReasonName(info.getReason())+") status="+info.getStatus()+" importance="+info.getImportance());
                add("  process="+safe(info.getProcessName())+" pss="+info.getPss()+"KB rss="+info.getRss()+"KB");
                String desc=info.getDescription();
                if (desc!=null && !desc.isEmpty()) add("  description="+desc);
                try {
                    InputStream is=info.getTraceInputStream();
                    if (is!=null) {
                        byte[] b=readLimited(is,4096);
                        is.close();
                        String s=new String(b,StandardCharsets.UTF_8).replace('\u0000',' ');
                        add("  trace(first "+b.length+" bytes): "+s);
                    } else add("  trace=<none>");
                } catch (Throwable t) {
                    add("  trace read error: "+t.getClass().getSimpleName()+": "+safe(t.getMessage()));
                }
            }
            if (infos.isEmpty()) add("No historical exit record visible to this package.");
        } catch (Throwable t) {
            add("Exit-history read failed: "+t.getClass().getSimpleName()+": "+safe(t.getMessage()));
        }
        add("=== END EXIT HISTORY ===");
    }

    private static byte[] readLimited(InputStream is,int max) throws IOException {
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        byte[] buf=new byte[512];
        while (out.size()<max) {
            int want=Math.min(buf.length,max-out.size());
            int n=is.read(buf,0,want);
            if (n<0) break;
            out.write(buf,0,n);
        }
        return out.toByteArray();
    }

    private static String exitReasonName(int r) {
        switch (r) {
            case 0: return "UNKNOWN";
            case 1: return "EXIT_SELF";
            case 2: return "SIGNALED";
            case 3: return "LOW_MEMORY";
            case 4: return "CRASH";
            case 5: return "CRASH_NATIVE";
            case 6: return "ANR";
            case 7: return "INITIALIZATION_FAILURE";
            case 8: return "PERMISSION_CHANGE";
            case 9: return "EXCESSIVE_RESOURCE_USAGE";
            case 10: return "USER_REQUESTED";
            case 11: return "USER_STOPPED";
            case 12: return "DEPENDENCY_DIED";
            case 13: return "OTHER";
            case 14: return "FREEZER";
            default: return "REASON_"+r;
        }
    }

    private void scan() {
        add("=== READ-ONLY USB SCAN ===");
        selected = null;
        Map<String,UsbDevice> devices = usb.getDeviceList();
        add("USB devices: " + devices.size());
        for (UsbDevice d: devices.values()) {
            int vid=d.getVendorId(), pid=d.getProductId();
            add(String.format(Locale.US,"VID=0x%04X (%d) PID=0x%04X (%d) interfaces=%d",vid,vid,pid,pid,d.getInterfaceCount()));
            dumpInterfaces(d);
            if (vid==OBSERVED_VID && pid==OBSERVED_PID) {
                selected=d;
                add("*** EXACT TARGET MATCH: 6324:1719 ***");
            }
        }
        if (selected==null) { add("Exact target not found"); return; }
        requestOrProbe(selected);
    }

    private void dumpInterfaces(UsbDevice d) {
        for (int i=0;i<d.getInterfaceCount();i++) {
            UsbInterface ui=d.getInterface(i);
            add("  IDX"+i+" IF"+ui.getId()+" alt="+ui.getAlternateSetting()+" class="+ui.getInterfaceClass()+" sub="+ui.getInterfaceSubclass()+" proto="+ui.getInterfaceProtocol()+" ep="+ui.getEndpointCount());
            for (int e=0;e<ui.getEndpointCount();e++) {
                UsbEndpoint ep=ui.getEndpoint(e);
                add("    EP addr=0x"+String.format(Locale.US,"%02X",ep.getAddress())+" dir="+(ep.getDirection()==UsbConstants.USB_DIR_IN?"IN":"OUT")+" type="+ep.getType()+" max="+ep.getMaxPacketSize()+" interval="+ep.getInterval());
            }
        }
    }

    private void requestOrProbe(UsbDevice d) {
        if (usb.hasPermission(d)) { probeReadOnly(d); return; }
        int flags=PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT>=31?PendingIntent.FLAG_MUTABLE:0);
        PendingIntent pi=PendingIntent.getBroadcast(this,0,new Intent(ACTION_USB_PERMISSION).setPackage(getPackageName()),flags);
        usb.requestPermission(d,pi);
    }

    private UsbInterface findIf4(UsbDevice d) {
        for (int i=0;i<d.getInterfaceCount();i++) {
            UsbInterface x=d.getInterface(i);
            if (x.getId()==4 && x.getInterfaceClass()==UsbConstants.USB_CLASS_HID) return x;
        }
        return null;
    }

    private UsbInterface findIf3(UsbDevice d) {
        for (int i=0;i<d.getInterfaceCount();i++) {
            UsbInterface x=d.getInterface(i);
            if (x.getId()==3 && x.getInterfaceClass()==UsbConstants.USB_CLASS_HID) return x;
        }
        return null;
    }

    private UsbEndpoint findIf3InterruptIn(UsbInterface x) {
        if (x==null) return null;
        for (int i=0;i<x.getEndpointCount();i++) {
            UsbEndpoint ep=x.getEndpoint(i);
            if (ep.getAddress()==0x81 && ep.getDirection()==UsbConstants.USB_DIR_IN
                    && ep.getType()==UsbConstants.USB_ENDPOINT_XFER_INT && ep.getMaxPacketSize()==64) return ep;
        }
        return null;
    }

    private void probeReadOnly(UsbDevice d) {
        new Thread(() -> {
            UsbDeviceConnection c=usb.openDevice(d);
            if (c==null) { ui("Permission/open: FAILED"); return; }
            try {
                ui("Permission/open: OK");
                ui("Manufacturer: "+safe(d.getManufacturerName()));
                ui("Product: "+safe(d.getProductName()));
                ui("Serial: "+safe(d.getSerialNumber()));
                UsbInterface x4=findIf4(d);
                UsbInterface x3=findIf3(d);
                UsbEndpoint ep81=findIf3InterruptIn(x3);
                if (x4==null) { ui("IF4 HID missing"); return; }

                byte[] rd=new byte[255];
                int rn=c.controlTransfer(0x81,0x06,0x2200,x4.getId(),rd,rd.length,1500);
                ui("IF4 HID REPORT => "+rn+" bytes");
                if (rn>0) ui("  "+hex(rd,rn));

                byte[] ft=new byte[8];
                int fn=c.controlTransfer(0xA1,0x01,0x0300,x4.getId(),ft,ft.length,1500);
                ui("GET_REPORT FEATURE IF4 ID0 len8 => "+fn+" bytes");
                if (fn>0) ui("  FEATURE: "+hex(ft,fn));

                boolean exactReport=rn==EXPECTED_IF4_REPORT.length && Arrays.equals(Arrays.copyOf(rd,rn),EXPECTED_IF4_REPORT);
                boolean exactFeature=fn==EXPECTED_FEATURE.length && Arrays.equals(ft,EXPECTED_FEATURE);
                boolean exactIf3In=ep81!=null;
                ui("IF4 descriptor exact gate: "+(exactReport?"PASS":"FAIL"));
                ui("IF4 feature exact gate: "+(exactFeature?"PASS":"FAIL"));
                ui("IF3 EP81 interrupt-IN exact gate: "+(exactIf3In?"PASS":"FAIL"));

                byte[] input=new byte[256];
                int in=c.controlTransfer(0xA1,0x01,0x0100,x4.getId(),input,input.length,500);
                ui("GET_REPORT INPUT IF4 ID0 len256 => "+in+" bytes");
                if (in>0) ui("  INPUT: "+hex(input,in));
                ui("R12 READ-ONLY USB complete. No claimInterface(force=true), no SET_REPORT, no class OUT, no endpoint OUT.");
            } catch (Throwable t) {
                ui("R12 read-only exception: "+t.getClass().getSimpleName()+": "+safe(t.getMessage()));
            } finally { c.close(); }
        },"okn-r12-readonly").start();
    }

    private static String safe(String s){ return s==null?"<null>":s; }

    private void scanAndroidInputDevices() {
        add("=== ANDROID INPUT DEVICE SCAN / PASSIVE WATCH ===");
        if (inputManager==null) { add("InputManager unavailable"); return; }
        int[] ids=InputDevice.getDeviceIds();
        add("Android InputDevice count: "+ids.length);
        int matches=0;
        for (int id: ids) {
            InputDevice dev=InputDevice.getDevice(id);
            if (dev==null) continue;
            int vid=dev.getVendorId(), pid=dev.getProductId();
            boolean target=(vid==OBSERVED_VID && pid==OBSERVED_PID);
            if (target) matches++;
            add(String.format(Locale.US,
                    "%sInputDevice id=%d name=%s VID=0x%04X PID=0x%04X sources=0x%08X keyboardType=%d virtual=%s",
                    target?"*** TARGET INPUT *** ":"", id, safe(dev.getName()), vid, pid, dev.getSources(),
                    dev.getKeyboardType(), dev.isVirtual()));
            add("  descriptor="+safe(dev.getDescriptor()));
            List<InputDevice.MotionRange> ranges=dev.getMotionRanges();
            add("  motionRanges="+ranges.size());
            for (InputDevice.MotionRange r: ranges) {
                add("    axis="+MotionEvent.axisToString(r.getAxis())+" source=0x"+Integer.toHexString(r.getSource())+
                        " min="+r.getMin()+" max="+r.getMax()+" flat="+r.getFlat()+" fuzz="+r.getFuzz()+" res="+r.getResolution());
            }
        }
        add("Exact 6324:1719 Android InputDevice matches: "+matches);
        if (matches>0) {
            add("PASSIVE WATCH ACTIVE: if Android converts IF3 reports into KeyEvent/MotionEvent while this screen is focused, they will be logged below.");
            add("This watch does not claim/detach USB and sends zero USB OUT packets.");
        } else {
            add("No Android InputDevice with exact VID/PID. IF3 may be kernel-bound without being exposed through the public InputDevice API.");
        }
        add("=== END INPUT DEVICE SCAN ===");
    }

    private boolean isTargetInputEventDevice(int deviceId) {
        InputDevice d=InputDevice.getDevice(deviceId);
        return d!=null && d.getVendorId()==OBSERVED_VID && d.getProductId()==OBSERVED_PID;
    }

    private static String keyActionToString(int action) {
        switch (action) {
            case KeyEvent.ACTION_DOWN: return "ACTION_DOWN";
            case KeyEvent.ACTION_UP: return "ACTION_UP";
            case KeyEvent.ACTION_MULTIPLE: return "ACTION_MULTIPLE";
            default: return "ACTION_"+action;
        }
    }

    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        if (event!=null && isTargetInputEventDevice(event.getDeviceId())) {
            add("TARGET KeyEvent action="+keyActionToString(event.getAction())+
                    " code="+KeyEvent.keyCodeToString(event.getKeyCode())+
                    " scanCode="+event.getScanCode()+" repeat="+event.getRepeatCount()+
                    " source=0x"+Integer.toHexString(event.getSource()));
        }
        return super.dispatchKeyEvent(event);
    }

    @Override public boolean dispatchGenericMotionEvent(MotionEvent event) {
        if (event!=null && isTargetInputEventDevice(event.getDeviceId())) {
            StringBuilder b=new StringBuilder();
            b.append("TARGET MotionEvent action=").append(MotionEvent.actionToString(event.getAction()))
             .append(" source=0x").append(Integer.toHexString(event.getSource()));
            InputDevice d=event.getDevice();
            if (d!=null) {
                for (InputDevice.MotionRange r: d.getMotionRanges()) {
                    b.append(' ').append(MotionEvent.axisToString(r.getAxis())).append('=')
                     .append(event.getAxisValue(r.getAxis()));
                }
            }
            add(b.toString());
        }
        return super.dispatchGenericMotionEvent(event);
    }
    private static String hex(byte[] b,int n){
        if (b==null || n<=0) return "<none>";
        StringBuilder s=new StringBuilder();
        for(int i=0;i<n && i<b.length;i++){
            if(i>0)s.append(' ');
            s.append(String.format(Locale.US,"%02X",b[i]&0xFF));
        }
        return s.toString();
    }
    private void add(String s){ log.append(s+"\n"); }
    private void ui(String s){ runOnUiThread(() -> add(s)); }
}
