# BUILD NOTES R13

แก้ compile error จาก R12 ที่บรรทัด passive KeyEvent logger:
`KeyEvent.actionToString(event.getAction())` -> `keyActionToString(event.getAction())`

สาเหตุ: Android `KeyEvent` ไม่มี static method `actionToString(int)` ใน API ที่ compile อยู่ ขณะที่ `MotionEvent.actionToString(int)` ใช้ได้

R13 ไม่เพิ่ม USB write path และไม่เปลี่ยน TRUE7CH gain core
