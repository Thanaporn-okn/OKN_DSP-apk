# จุด reverse-engineering ที่ให้ผลคุ้มที่สุดต่อจากนี้

## A. Factory 7CH gain path
Windows client มี class `SignalMerger` และ method `get_GainList` / `set_GainList`. งานต่อคือ recover protected runtime IL ของสอง method นี้ แล้ว trace:
- address/list layout
- 7 channel ordering
- data type / scaling
- serializer command

ทำขั้นนี้แบบ static/read-only ก่อน ไม่ส่ง write ไปบอร์ด.

## B. Audio callback mapping
ใน firmware clean-room ให้ trace จุดที่ได้ buffer ของ:
- main L/R
- bass mono
- i2s0 L/R
- i2s1 L/R
จากนั้นเสียบ `okn_gain7_process_topology()` หลัง EQ/crossover.

## C. First-install boot path
ค้น read-only bootloader identity/capability ของ exact board. ห้ามนำ flash map/linker ของ generic SDK ไปใช้กับ GoloPine โดยตรง.
