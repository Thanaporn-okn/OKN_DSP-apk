# Samsung S25+ USB-C first-flash gate

ข้อมูลบอร์ดที่ยืนยันแล้วในโครงการมี USB composite และ HID vendor interface แต่การทดลอง read/version แบบปลอดภัยยังไม่ยืนยันว่า interface นั้นคือ bootloader/updater.

Phase3 จึงให้ Android `usb-readonly-probe` ทำเฉพาะ:
- enumerate USB device/interface/endpoint
- ตรวจ VID/PID ที่คาดไว้
- claim HID interface
- GET_REPORT Feature (IN/read-only)

**ไม่มี** SET_REPORT firmware packet, erase, program, commit, reboot-to-bootloader หรือ hard-coded flash address.

ก่อนสร้าง first-flash จริงต้องมีหลักฐานครบ:
1. วิธีเข้า boot/recovery ที่กู้ได้แม้ application firmware เสีย
2. exact flash size/protected area/bank/metadata ของบอร์ด revision นี้
3. read-only bootloader identity/version/capabilities ที่ยืนยัน exact protocol
4. image header/checksum/sign/encryption/package format
5. backup/restore path หรือ recovery ที่ทดสอบได้
6. ทดสอบกับบอร์ดสำรองก่อนเปิด write จาก S25+

หลังผ่าน gate นี้ค่อยเพิ่ม transport writer โดยยังต้อง verify image, board ID และ read-back ก่อน commit.
