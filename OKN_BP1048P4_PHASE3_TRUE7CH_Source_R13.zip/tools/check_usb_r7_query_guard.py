from pathlib import Path
p = Path(__file__).resolve().parents[1] / 'android-usb-probe/app/src/main/java/com/okn/dsp/usbprobe/MainActivity.java'
s = p.read_text(encoding='utf-8')
required = [
    'OBSERVED_VID = 0x6324',
    'OBSERVED_PID = 0x1719',
    'EXPECTED_IF4_REPORT',
    'EXPECTED_FEATURE',
    'findIf3InterruptIn',
    'ep.getAddress()==0x81',
    'USB_ENDPOINT_XFER_INT',
    'claimInterface(x3,false)',
    'A5',
    '0x5A',
    'out[2]=0x00',
    'out[3]=0x00',
    'out[4]=0x16',
    '0x21',
    '0x09',
    '0x0200',
    'bulkTransfer(ep81',
    'No IF3 EP81 interrupt response observed',
]
for x in required:
    assert x in s, f'missing R7 guard token: {x}'
# One explicit HID SET_REPORT call only.
assert s.count('c.controlTransfer(\n                        0x21') == 1, 'unexpected number of host-to-device class control transfers'
# No firmware-write vocabulary/API paths.
for bad in ['eraseFlash(', 'programFlash(', 'rebootToBootloader(', 'SaveParams(', '0x57,']:
    assert bad not in s, f'forbidden token: {bad}'
print('R7 guarded IF3-listen version-query USB safety: PASS')
