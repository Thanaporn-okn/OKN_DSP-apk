from pathlib import Path
root=Path(__file__).resolve().parents[1]
p=root/'android-usb-probe/app/src/main/java/com/okn/dsp/usbprobe/MainActivity.java'
s=p.read_text(encoding='utf-8')
for bad in [
    'claimInterface(x3,true)', 'claimInterface(x3, true)',
    'controlTransfer(0x21', 'controlTransfer(0x01',
    'bulkTransfer(', 'new UsbRequest(',
    'out[0]=(byte)0xA5', 'SET_REPORT result'
]:
    if bad in s:
        raise SystemExit(f'R13 safety guard FAIL: forbidden transport token {bad!r}')
for needed in ['InputDevice.getDeviceIds()', 'dispatchKeyEvent', 'dispatchGenericMotionEvent', 'keyActionToString', 'R12 READ-ONLY USB complete']:
    if needed not in s:
        raise SystemExit(f'R13 safety guard FAIL: missing {needed!r}')

if 'KeyEvent.actionToString' in s:
    raise SystemExit('R13 compile guard FAIL: KeyEvent.actionToString does not exist')
print('R13 Android InputDevice + USB read-only guard: PASS')
