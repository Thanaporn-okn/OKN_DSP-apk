from pathlib import Path
p = Path(__file__).resolve().parents[1] / 'android-usb-probe/app/src/main/java/com/okn/dsp/usbprobe/MainActivity.java'
s = p.read_text(encoding='utf-8')
required = [
    'OBSERVED_VID = 0x6324',
    'OBSERVED_PID = 0x1719',
    'EXPECTED_IF4_REPORT',
    'EXPECTED_FEATURE',
    'findIf3InterruptIn',
    'ep.getAddress()==0x81',
    'USB_ENDPOINT_XFER_INT',
    'claimInterface(x3,true)',
    'IF3 claim(force=true)',
    'readIf3ReportDescriptorClaimed',
    'UsbRequest',
    'responseReq.queue(responseBuf)',
    'A5',
    '0x5A',
    'out[2]=0x00',
    'out[3]=0x00',
    'out[4]=0x16',
    '0x21',
    '0x09',
    '0x0200',
    'releaseInterface(x3)',
    'If Android audio/HID behavior changed, unplug/replug USB-C once',
]
for x in required:
    assert x in s, f'missing R9 guard token: {x}'

# Exactly one host-to-device HID SET_REPORT remains.
assert s.count('c.controlTransfer(\n                        0x21') == 1, 'unexpected number of host-to-device class control transfers'

# Force-detach is allowed ONLY for IF3; IF4 remains non-force.
assert s.count('claimInterface(x3,true)') == 1, 'IF3 force-claim count must be exactly one'
assert 'claimInterface(x4,true)' not in s, 'IF4 must never be force-claimed'
assert 'claimInterface(x3,false)' not in s, 'R9 uses the explicit one-time force claim for IF3 only'

# No endpoint OUT API. UsbRequest is allowed only because ep81 is proven IN/interrupt/64 by findIf3InterruptIn.
for bad in ['bulkTransfer(', 'UsbEndpoint epOut', 'USB_DIR_OUT', 'endpointTransferOut']:
    assert bad not in s, f'forbidden endpoint OUT path: {bad}'

# No firmware/DSP write vocabulary/API paths.
for bad in ['eraseFlash(', 'programFlash(', 'rebootToBootloader(', 'SaveParams(', '0x57,']:
    assert bad not in s, f'forbidden token: {bad}'

print('R9 guarded temporary-IF3-detach + EP81-IN version-query USB safety: PASS')
