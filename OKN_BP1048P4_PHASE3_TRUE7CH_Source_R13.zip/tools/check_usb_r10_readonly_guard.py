from pathlib import Path
root=Path(__file__).resolve().parents[1]
p=root/'android-usb-probe/app/src/main/java/com/okn/dsp/usbprobe/MainActivity.java'
s=p.read_text(encoding='utf-8')
for bad in [
    'claimInterface(x3,true)', 'claimInterface(x3, true)',
    'controlTransfer(0x21', 'controlTransfer(0x01',
    'bulkTransfer(', 'new UsbRequest(',
    'out[0]=(byte)0xA5', 'SET_REPORT result'
]:
    if bad in s:
        raise SystemExit(f'R11 safety guard FAIL: forbidden transport token {bad!r}')
if 'ApplicationExitInfo' not in s:
    raise SystemExit('R11 safety guard FAIL: exit history code missing')
if 'R11 READ-ONLY complete' not in s:
    raise SystemExit('R11 safety guard FAIL: completion marker missing')
print('R11 exit-history + USB read-only guard: PASS')
