# OKN BP1048P4 Phase3 TRUE7CH R13

R13 แก้ build error ของ R12: Android `KeyEvent` ไม่มี static method `actionToString(int)` จึงเปลี่ยนเป็น helper `keyActionToString()` ที่ map ACTION_DOWN / ACTION_UP / ACTION_MULTIPLE โดยตรง

ฟังก์ชันของ R12 คงเดิม:
- TRUE 7CH gain core เดิม ไม่ใช้ EQ ทำ Gain
- USB qualification แบบ read-only
- Android InputDevice VID/PID/source/descriptor/motion-range metadata
- Passive KeyEvent/MotionEvent logger เฉพาะ VID/PID 6324:1719
- ไม่มี SET_REPORT / class OUT / endpoint OUT / force detach / erase / program
