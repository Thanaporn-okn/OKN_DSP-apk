# OKN DSP V52

V52 fixes intermittent slider writes where the UI changed but the DSP sometimes did not react until the slider was adjusted a second time.

## Reliable Final Commit
- During drag, scalar values still use the existing latest-value/coalesced scheduler.
- On finger release, the newest value is promoted to a one-shot priority commit instead of waiting only for the next 380 ms slot.
- Master release commits MasterVolume ID2 first, then BassVolume ID8, preserving the V51 rise-only relation.
- Bass release commits BassVolume ID8 only.
- Bass Cutoff release commits ID9.
- Final writes remain serialized; no concurrent GATT/CFB8 writes are introduced.
- Master/Bass final pair is spaced by 120 ms to avoid a release burst.
- Bass ID8 still uses DSP readback/retry after a successful write.

V51 behavior is preserved: Master down does not decrease Bass ID8; Master up increases Bass ID8 by the same positive dB delta. No Band EQ, Ch3 EQ gain, or Channel Volume compensation is used.

EQ order remains: Ch1 Left, Ch2 Right, Ch3 Bass/Subwoofer, Ch4 4th, Ch5 5th, Ch6 6th, Ch7 7th.
