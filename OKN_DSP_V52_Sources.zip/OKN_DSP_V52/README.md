# OKN DSP V52 — BP1048P4 USB IF3 Zero-TX Qualification

V52 follows the real-board V46–V51 USB evidence. V49 and V51 proved that HID IF4 accepts a 256-byte Output Report, but IF4 `GET_REPORT(Input)` produced no response for either a Generic ACP catalog query or the already hardware-proven BLE UFE authentication request.

V52 therefore sends **zero host-to-device payload bytes** and identifies the other HID interface before trying any further transport hypothesis.

## What V52 reads

The physical board reports HID IF3 with one interrupt-IN endpoint `0x81`, max packet 64 bytes, and a 33-byte HID report descriptor. V52:
1. claims IF3 with `force=false` only;
2. reads the IF3 HID report descriptor using standard `GET_DESCRIPTOR(report)`;
3. reports descriptor hints (Generic Desktop / keyboard usage / Consumer page / vendor FF00);
4. performs only HID `GET_REPORT(Input)` reads on IF3 to see whether any cached/idle Input report exists;
5. stops.

## Safety

V52 contains no HID `SET_REPORT`, no ACP frame, no UFE authentication frame, no Device Description request, and no actuator/gain/EQ/biquad/effect/SaveParams write in the USB probe. CH1/2/4/5/6/7 output sliders remain fail-closed; CH3/ID8 remains unchanged.
