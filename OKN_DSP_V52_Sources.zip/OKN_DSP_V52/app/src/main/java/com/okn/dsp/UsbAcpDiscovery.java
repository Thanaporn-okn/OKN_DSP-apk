package com.okn.dsp;

import android.content.Context;
import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * V52 zero-TX qualification of the second HID interface on the real OKN BP1048P4 board.
 *
 * V46/V48 proved:
 *   VID 0x6324, PID 0x1719
 *   IF3 = HID, one IN endpoint 0x81, maxPacket 64, report descriptor length 33
 *   IF4 = HID, endpoint-less vendor channel, 256-byte Input/Output + 8-byte Feature
 *
 * V49/V51 proved IF4 accepts 256-byte Output SET_REPORT transfers but no IF4 Input
 * GET_REPORT response appeared for either Generic ACP catalog or proven BLE UFE auth.
 *
 * V52 sends ZERO host-to-device payload bytes. It only:
 *   - claims IF3 with force=false;
 *   - reads IF3 HID report descriptor using standard GET_DESCRIPTOR(IN);
 *   - performs GET_REPORT(Input) on IF3 (IN only) to check for a cached/idle report;
 *   - reports the real IF3 endpoint metadata already exposed by Android.
 *
 * There is no SET_REPORT, no ACP/UFE TX, no actuator/gain/EQ/effect/SaveParams write.
 */
public final class UsbAcpDiscovery {
    public static final int TARGET_VID = 0x6324;
    public static final int TARGET_PID = 0x1719;
    public static final int TARGET_INTERFACE = 3;

    private static final int USB_RECIP_INTERFACE = 0x01;
    private static final int USB_REQ_GET_DESCRIPTOR = 0x06;
    private static final int HID_REQ_GET_REPORT = 0x01;
    private static final int HID_DT_REPORT = 0x22;
    private static final int HID_REPORT_TYPE_INPUT = 0x01;
    private static final int IF3_INPUT_READ_SIZE = 64;
    private static final int IO_TIMEOUT_MS = 1000;
    private static final int INPUT_GET_ATTEMPTS = 4;
    private static final long INPUT_GET_DELAY_MS = 40L;

    private UsbAcpDiscovery() {}

    public static UsbDevice findTarget(Context context) {
        UsbManager manager = (UsbManager) context.getSystemService(Context.USB_SERVICE);
        if (manager == null) return null;
        Map<String, UsbDevice> map = manager.getDeviceList();
        if (map == null || map.isEmpty()) return null;
        UsbDevice pid1719Fallback = null;
        for (UsbDevice d : map.values()) {
            if (d == null) continue;
            if (d.getVendorId() == TARGET_VID && d.getProductId() == TARGET_PID && hasTargetHidInterface(d)) return d;
            if (d.getProductId() == TARGET_PID && hasTargetHidInterface(d)) pid1719Fallback = d;
        }
        return pid1719Fallback;
    }

    public static String summary(Context context) {
        UsbManager manager = (UsbManager) context.getSystemService(Context.USB_SERVICE);
        if (manager == null) return "UsbManager unavailable";
        UsbDevice d = findTarget(context);
        if (d == null) return "target 0x6324:0x1719 IF3 not detected";
        return String.format(Locale.US, "%04X:%04X IF3 READ-ONLY permission=%s",
                d.getVendorId(), d.getProductId(), manager.hasPermission(d) ? "yes" : "no");
    }

    public static String buildEnumerationReport(Context context) {
        UsbManager manager = (UsbManager) context.getSystemService(Context.USB_SERVICE);
        StringBuilder out = new StringBuilder(3072);
        out.append("OKN DSP V52 — USB IF3 HID read-only discovery\n")
                .append("SAFETY: USB OUT=0; SET_REPORT=0; ACP/UFE TX=0; DSP writes=0.\n\n");
        if (manager == null) return out.append("UsbManager unavailable on this device.").toString();
        Map<String, UsbDevice> map = manager.getDeviceList();
        if (map == null || map.isEmpty()) return out.append("No USB device detected.\n").toString();
        List<String> keys = new ArrayList<>(map.keySet());
        Collections.sort(keys);
        out.append("Detected devices: ").append(keys.size()).append("\n\n");
        int n=0;
        for (String key: keys) {
            UsbDevice d=map.get(key); if (d==null) continue; n++;
            out.append('#').append(n).append(' ')
                    .append(String.format(Locale.US,"VID=%04X PID=%04X",d.getVendorId(),d.getProductId()))
                    .append(" ifaces=").append(d.getInterfaceCount())
                    .append(" permission=").append(manager.hasPermission(d)?"yes":"no")
                    .append(isExactTarget(d)?"  <V52 TARGET>":(isTransportCandidate(d)?"  <candidate>":""))
                    .append('\n');
            appendInterfaces(out,d); out.append('\n');
        }
        return out.toString();
    }

    /** Requires explicit Android USB permission. IN-only IF3 probe; zero host payload bytes. */
    public static String buildIf3ReadOnlyProbe(Context context, UsbDevice requestedDevice) {
        UsbManager manager = (UsbManager) context.getSystemService(Context.USB_SERVICE);
        StringBuilder out = new StringBuilder(12288);
        out.append("OKN DSP V52 — IF3 HID INPUT READ-ONLY probe\n")
                .append("SAFETY: USB OUT=0; SET_REPORT=0; ACP/UFE TX=0; DSP writes=0; SaveParams=0.\n")
                .append("Only standard GET_DESCRIPTOR(report) and HID GET_REPORT(Input) are issued.\n\n");
        if (manager == null) return out.append("UsbManager unavailable.").toString();
        UsbDevice d = requestedDevice != null ? requestedDevice : findTarget(context);
        if (d == null) return out.append("Target 0x6324:0x1719 IF3 HID not detected.").toString();
        out.append(String.format(Locale.US,"Target VID=%04X PID=%04X interfaces=%d\n",d.getVendorId(),d.getProductId(),d.getInterfaceCount()));
        if (d.getProductId()!=TARGET_PID || !hasTargetHidInterface(d)) return out.append("FAIL-CLOSED: PID/IF3 mismatch.\n").toString();
        if (!manager.hasPermission(d)) return out.append("USB permission=no. No device connection opened.\n").toString();
        out.append("USB permission=yes\n");
        UsbInterface hid=findInterface(d,TARGET_INTERFACE);
        if (hid==null || hid.getInterfaceClass()!=UsbConstants.USB_CLASS_HID) return out.append("FAIL-CLOSED: IF3 missing/not HID.\n").toString();
        out.append("IF3 class=HID sub=").append(hid.getInterfaceSubclass())
                .append(" proto=").append(hid.getInterfaceProtocol())
                .append(" endpoints=").append(hid.getEndpointCount()).append('\n');

        UsbEndpoint inputEp = null;
        for (int e=0; e<hid.getEndpointCount(); e++) {
            UsbEndpoint ep=hid.getEndpoint(e);
            out.append(String.format(Locale.US,"  EP 0x%02X %s type=%d maxPacket=%d interval=%d\n",
                    ep.getAddress(), ep.getDirection()==UsbConstants.USB_DIR_IN?"IN":"OUT",
                    ep.getType(), ep.getMaxPacketSize(), ep.getInterval()));
            if (ep.getDirection()==UsbConstants.USB_DIR_IN && ep.getType()==UsbConstants.USB_ENDPOINT_XFER_INT) inputEp=ep;
        }
        out.append("interruptInEndpoint=").append(inputEp!=null?String.format(Locale.US,"0x%02X",inputEp.getAddress()):"NONE").append('\n');

        UsbDeviceConnection conn=manager.openDevice(d);
        if (conn==null) return out.append("openDevice failed.\n").toString();
        boolean claimed=false;
        try {
            claimed=conn.claimInterface(hid,false);
            out.append("claim IF3 force=false => ").append(claimed?"OK":"FAILED").append(" (force=true forbidden)\n");
            if(!claimed) return out.append("FAIL-CLOSED: IF3 not claimed. No control request issued.\n").toString();

            byte[] desc=new byte[128];
            int reportLen=conn.controlTransfer(
                    UsbConstants.USB_DIR_IN | UsbConstants.USB_TYPE_STANDARD | USB_RECIP_INTERFACE,
                    USB_REQ_GET_DESCRIPTOR, HID_DT_REPORT<<8, TARGET_INTERFACE,
                    desc, desc.length, IO_TIMEOUT_MS);
            out.append("\n[1] IF3 HID report descriptor (IN only)\n")
                    .append("GET_DESCRIPTOR(report) result=").append(reportLen).append('\n');
            if(reportLen>0) out.append("if3ReportDescriptor=").append(hex(desc,reportLen)).append('\n');
            appendDescriptorHints(out, desc, reportLen);

            out.append("\n[2] IF3 cached Input GET_REPORT checks (IN only)\n")
                    .append("bmRequestType=0xA1 bRequest=0x01 wValue=0x0100 wIndex=3 wLength=64\n");
            boolean any=false;
            for(int attempt=1; attempt<=INPUT_GET_ATTEMPTS; attempt++) {
                if(attempt>1) sleepQuietly(INPUT_GET_DELAY_MS);
                byte[] input=new byte[IF3_INPUT_READ_SIZE];
                int got=conn.controlTransfer(
                        UsbConstants.USB_DIR_IN | UsbConstants.USB_TYPE_CLASS | USB_RECIP_INTERFACE,
                        HID_REQ_GET_REPORT, HID_REPORT_TYPE_INPUT<<8, TARGET_INTERFACE,
                        input, input.length, IO_TIMEOUT_MS);
                out.append("GET_REPORT IF3 attempt=").append(attempt).append(" result=").append(got).append('\n');
                if(got>0) {
                    any=true;
                    out.append("if3InputReport=").append(hex(input,got)).append('\n');
                }
            }
            if(!any) out.append("No cached IF3 Input report returned by control GET_REPORT.\n");

            out.append("\nV52 COMPLETE: host-to-device payload bytes=0; SET_REPORT=0; ACP/UFE TX=0.\n")
                    .append("Copy this full report. IF3 descriptor bytes determine whether IF3 is media/keyboard or a second vendor data path.");
            return out.toString();
        } catch (RuntimeException e) {
            return out.append("\nProbe exception: ").append(e.getClass().getSimpleName())
                    .append("\nV52 remains zero-TX.\n").toString();
        } finally {
            if(claimed){try{conn.releaseInterface(hid);}catch(RuntimeException ignored){}}
            conn.close();
        }
    }

    private static void appendDescriptorHints(StringBuilder out, byte[] d, int len) {
        boolean genericDesktop = contains(d,len,new byte[]{0x05,0x01}) || contains(d,len,new byte[]{0x06,0x01,0x00});
        boolean keyboardUsage = contains(d,len,new byte[]{0x09,0x06});
        boolean consumerPage = contains(d,len,new byte[]{0x05,0x0C}) || contains(d,len,new byte[]{0x06,0x0C,0x00});
        boolean vendorFF00 = contains(d,len,new byte[]{0x06,0x00,(byte)0xFF});
        out.append("descriptorHints: genericDesktop=").append(genericDesktop?"YES":"NO")
                .append(" keyboardUsage=").append(keyboardUsage?"YES":"NO")
                .append(" consumerPage=").append(consumerPage?"YES":"NO")
                .append(" vendorFF00=").append(vendorFF00?"YES":"NO").append('\n');
    }

    private static boolean contains(byte[] h,int len,byte[] n){
        if(h==null||n==null||n.length==0) return false;
        int lim=Math.min(len,h.length)-n.length;
        for(int i=0;i<=lim;i++){boolean ok=true;for(int j=0;j<n.length;j++)if(h[i+j]!=n[j]){ok=false;break;}if(ok)return true;}
        return false;
    }
    private static void sleepQuietly(long ms){
        try{Thread.sleep(ms);}catch(InterruptedException e){Thread.currentThread().interrupt();}
    }
    private static boolean isExactTarget(UsbDevice d){return d!=null&&d.getVendorId()==TARGET_VID&&d.getProductId()==TARGET_PID&&hasTargetHidInterface(d);}
    private static boolean isTransportCandidate(UsbDevice d){return d!=null&&d.getProductId()==TARGET_PID&&hasTargetHidInterface(d);}
    private static boolean hasTargetHidInterface(UsbDevice d){UsbInterface i=findInterface(d,TARGET_INTERFACE);return i!=null&&i.getInterfaceClass()==UsbConstants.USB_CLASS_HID;}
    private static UsbInterface findInterface(UsbDevice d,int id){if(d==null)return null;for(int i=0;i<d.getInterfaceCount();i++){UsbInterface ui=d.getInterface(i);if(ui!=null&&ui.getId()==id)return ui;}return null;}
    private static void appendInterfaces(StringBuilder out,UsbDevice d){
        for(int i=0;i<d.getInterfaceCount();i++){UsbInterface ui=d.getInterface(i);out.append("  IF ").append(ui.getId()).append(" class=").append(ui.getInterfaceClass()).append(" sub=").append(ui.getInterfaceSubclass()).append(" proto=").append(ui.getInterfaceProtocol()).append(" eps=").append(ui.getEndpointCount());if(ui.getInterfaceClass()==UsbConstants.USB_CLASS_HID)out.append(" HID");out.append('\n');for(int e=0;e<ui.getEndpointCount();e++){UsbEndpoint ep=ui.getEndpoint(e);out.append(String.format(Locale.US,"    EP 0x%02X %s type=%d maxPacket=%d interval=%d\n",ep.getAddress(),ep.getDirection()==UsbConstants.USB_DIR_IN?"IN":"OUT",ep.getType(),ep.getMaxPacketSize(),ep.getInterval()));}}
    }
    private static String hex(byte[] b,int len){if(b==null||len<=0)return "";int n=Math.min(len,b.length);StringBuilder s=new StringBuilder(n*2);for(int i=0;i<n;i++)s.append(String.format(Locale.US,"%02X",b[i]&0xFF));return s.toString();}
}
