import 'package:flutter/material.dart';

void main()=>runApp(const OKNDSP());

class OKNDSP extends StatelessWidget{
 const OKNDSP({super.key});
 @override
 Widget build(BuildContext c){
  return MaterialApp(
   debugShowCheckedModeBanner:false,
   theme:ThemeData.dark(),
   home:const MainScreen()
  );
 }
}

class MainScreen extends StatelessWidget{
 const MainScreen({super.key});

 @override
 Widget build(BuildContext c){
  final ch=['CH1 Front L','CH2 Front R','CH3 SUB','CH4 Rear L','CH5 Rear R','CH6 AUX L','CH7 AUX R'];
  return Scaffold(
   backgroundColor:const Color(0xff101318),
   body:SafeArea(
    child:Column(children:[
     Container(
      margin:const EdgeInsets.all(12),
      padding:const EdgeInsets.all(16),
      decoration:BoxDecoration(color:const Color(0xff1b2028),borderRadius:BorderRadius.circular(12)),
      child:const Row(children:[
       Icon(Icons.bluetooth,color:Colors.cyan),
       SizedBox(width:10),
       Text('Connected\nBP1048P4 7CH DSP\nFW:1.2.6')
      ]),
     ),
     const Text('Master Volume  -12.5 dB',style:TextStyle(fontSize:20)),
     Expanded(
      child:ListView.builder(
       scrollDirection:Axis.horizontal,
       itemCount:7,
       itemBuilder:(c,i)=>ChannelCard(name:ch[i])
      )
     ),
     const SizedBox(height:10),
     const Text('⌂  MAIN     EQ     CROSSOVER     DELAY     MIXER     PRESET     SETTINGS',
      style:TextStyle(color:Colors.cyan,fontSize:14))
    ])
   )
  );
 }
}

class ChannelCard extends StatelessWidget{
 final String name;
 const ChannelCard({super.key,required this.name});
 @override
 Widget build(BuildContext c){
  return Container(
   width:130,
   margin:const EdgeInsets.all(6),
   decoration:BoxDecoration(color:const Color(0xff171c22),borderRadius:BorderRadius.circular(12)),
   child:Column(children:[
    const SizedBox(height:12),
    Text(name,textAlign:TextAlign.center),
    const SizedBox(height:20),
    const Expanded(child:RotatedBox(quarterTurns:3,child:Slider(value:-2,min:-60,max:6,onChanged:null))),
    ElevatedButton(onPressed:null,child:const Text('Mute'))
   ])
  );
 }
}
