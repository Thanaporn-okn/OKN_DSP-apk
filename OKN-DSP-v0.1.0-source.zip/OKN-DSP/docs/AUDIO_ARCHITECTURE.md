# Audio architecture

OKN-DSP v0.1 defines seven independent channels.

Signal order for every channel:

`Input -> 15-band PEQ -> dedicated Gain/Volume -> Mute -> Output`

Gain/Volume is not implemented by consuming an EQ band. Each channel has its own dedicated gain scalar after all PEQ bands.

Default PEQ center frequencies:

31.5, 50, 80, 125, 200, 315, 500, 800, 1250, 2000, 3150, 5000, 8000, 12500, 16000 Hz.

Reference limits:

- Dedicated Gain: -60 dB to +12 dB.
- PEQ Gain: -18 dB to +18 dB.
- Q: 0.10 to 20.0.
- Default sample rate: 48 kHz.

The portable C reference core uses transposed Direct Form II peaking biquads. The BP1048P4 production port may later map these settings to optimized target DSP blocks, but the visible behavior and signal order must stay the same.
