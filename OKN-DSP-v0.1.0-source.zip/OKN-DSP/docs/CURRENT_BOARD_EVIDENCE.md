# Current production-board evidence used by OKN-DSP

This file records only constraints used by the codebase; it is not permission to flash.

- Target board: GoloPine / DSTech 7-channel DSP using MVSilicon BP1048P4.
- Required installer: Samsung Galaxy S25+ in Android USB Host mode through a direct USB-C to USB-C cable.
- Hardware modification is forbidden.
- Observed normal USB identity: VID:PID `6324:1719`, 7 interfaces.
- A custom HID interface was previously observed with 256-byte input/output reports and an 8-byte feature report.
- Previous `AA -> 55` probing must not be repeated.
- Legacy/runtime `0x11` must not be sent to the stock board because it is associated with erase/write behavior in the reference path.
- CH3 DACX physical mapping and production I2S physical mapping are still unproven.
- The reference SDK/flashboot must not be assumed identical to the production GoloPine firmware.
- Latest R101 offline audit did not prove a safe RAM-only arbitrary read/write/code-execution path from the stock USB runtime. Production flashing therefore remains locked.
