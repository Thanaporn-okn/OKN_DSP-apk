# Production flash gate

Target installation rule: **Samsung Galaxy S25+ USB-C directly to the DSP board USB-C only. No soldering, debug probe, board cutting, strap modification, or hardware modification.**

The first installation of OKN-DSP onto the real GoloPine/DSTech BP1048P4 board is currently locked. A successful host build of new firmware logic does not prove that a production image can be safely written.

All six gates below must be proven for the exact production board before enabling erase/program:

1. Exact production first-bootstrap sequence reachable from the stock firmware over the existing USB-C port.
2. Full stock backup or an independently proven recovery/rollback path.
3. Exact production flash layout, including regions that must be preserved.
4. Exact production image header/CRC/signature/acceptance rules.
5. Production recovery/updater USB identity, descriptors, interfaces, endpoints and transfer semantics.
6. End-to-end S25+ Android USB Host implementation matching that verified production transport.

Current state (2026-09-22): `FLASH_ALLOWED=NO`.

Do not substitute a BP1048B2 layout, reference SDK flashboot layout, or programmer/debug workflow for the production GoloPine BP1048P4 USB-C path.
