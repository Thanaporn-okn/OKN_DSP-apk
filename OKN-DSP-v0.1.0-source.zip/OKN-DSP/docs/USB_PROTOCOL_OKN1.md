# OKN1 runtime protocol

This protocol belongs to the **new OKN-DSP firmware**. It must never be sent to the stock GoloPine/DSTech firmware.

## Transport contract

- Packet size: 256 bytes fixed.
- Magic: `OKN1`.
- Protocol version: 1.
- CRC32: IEEE CRC32 over bytes 0..251, stored little-endian at bytes 252..255.
- Channel: 0..6 for CH1..CH7, `0xFF` for global commands.
- Byte order: little-endian.
- Runtime TX remains disabled in Android v0.1 until the first production flash path is proven and the running firmware can be positively identified as OKN-DSP.

## Header

| Offset | Size | Field |
|---:|---:|---|
| 0 | 4 | `OKN1` magic |
| 4 | 1 | protocol version |
| 5 | 1 | command |
| 6 | 1 | channel |
| 7 | 1 | flags |
| 8 | 4 | sequence |
| 12 | 2 | payload length (0..236) |
| 14 | 2 | reserved |
| 16 | 236 | payload area |
| 252 | 4 | CRC32 |

## Commands

- `0x20` HELLO
- `0x21` GET_INFO
- `0x22` GET_CHANNEL
- `0x40` SET_GAIN — one float32 dB value
- `0x41` SET_PEQ — band/enabled/frequency/Q/gain
- `0x42` SET_MUTE
- `0x70` UPDATE_STATUS
- `0x7A` ENTER_UPDATE — compile-time locked in v0.1

No command uses the stock/legacy `0x11` path.
