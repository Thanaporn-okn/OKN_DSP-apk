#include "okn_dsp.h"

#include <math.h>
#include <stddef.h>
#include <string.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

static int channel_valid(uint8_t channel) {
    return channel < OKN_DSP_CHANNELS;
}

static int band_valid(uint8_t band) {
    return band < OKN_DSP_PEQ_BANDS;
}

static int finite_in_range(float value, float min_value, float max_value) {
    return isfinite(value) && value >= min_value && value <= max_value;
}

static void biquad_identity(okn_biquad_t *bq) {
    bq->b0 = 1.0f;
    bq->b1 = 0.0f;
    bq->b2 = 0.0f;
    bq->a1 = 0.0f;
    bq->a2 = 0.0f;
    bq->z1 = 0.0f;
    bq->z2 = 0.0f;
}

static void update_peaking_coefficients(okn_biquad_t *bq,
                                        uint32_t sample_rate,
                                        const okn_peq_band_config_t *cfg) {
    if (!cfg->enabled || fabsf(cfg->gain_db) < 1.0e-7f) {
        float z1 = bq->z1;
        float z2 = bq->z2;
        biquad_identity(bq);
        bq->z1 = z1;
        bq->z2 = z2;
        return;
    }

    const float a = powf(10.0f, cfg->gain_db / 40.0f);
    const float w0 = 2.0f * (float)M_PI * cfg->frequency_hz / (float)sample_rate;
    const float alpha = sinf(w0) / (2.0f * cfg->q);
    const float cw0 = cosf(w0);

    const float b0 = 1.0f + alpha * a;
    const float b1 = -2.0f * cw0;
    const float b2 = 1.0f - alpha * a;
    const float a0 = 1.0f + alpha / a;
    const float a1 = -2.0f * cw0;
    const float a2 = 1.0f - alpha / a;

    bq->b0 = b0 / a0;
    bq->b1 = b1 / a0;
    bq->b2 = b2 / a0;
    bq->a1 = a1 / a0;
    bq->a2 = a2 / a0;
}

float okn_dsp_db_to_linear(float db) {
    return powf(10.0f, db / 20.0f);
}

void okn_dsp_init(okn_dsp_t *dsp, uint32_t sample_rate) {
    if (dsp == NULL) {
        return;
    }

    memset(dsp, 0, sizeof(*dsp));
    dsp->sample_rate = sample_rate == 0u ? OKN_DSP_DEFAULT_SAMPLE_RATE : sample_rate;

    static const float defaults[OKN_DSP_PEQ_BANDS] = {
        31.5f, 50.0f, 80.0f, 125.0f, 200.0f,
        315.0f, 500.0f, 800.0f, 1250.0f, 2000.0f,
        3150.0f, 5000.0f, 8000.0f, 12500.0f, 16000.0f
    };

    for (uint8_t ch = 0; ch < OKN_DSP_CHANNELS; ++ch) {
        dsp->channel[ch].gain_db = 0.0f;
        dsp->channel[ch].mute = false;
        dsp->linear_gain[ch] = 1.0f;

        for (uint8_t band = 0; band < OKN_DSP_PEQ_BANDS; ++band) {
            dsp->channel[ch].peq[band].frequency_hz = defaults[band];
            dsp->channel[ch].peq[band].q = 1.0f;
            dsp->channel[ch].peq[band].gain_db = 0.0f;
            dsp->channel[ch].peq[band].enabled = true;
            biquad_identity(&dsp->biquad[ch][band]);
        }
    }
}

void okn_dsp_reset_state(okn_dsp_t *dsp) {
    if (dsp == NULL) {
        return;
    }

    for (uint8_t ch = 0; ch < OKN_DSP_CHANNELS; ++ch) {
        for (uint8_t band = 0; band < OKN_DSP_PEQ_BANDS; ++band) {
            dsp->biquad[ch][band].z1 = 0.0f;
            dsp->biquad[ch][band].z2 = 0.0f;
        }
    }
}

okn_dsp_result_t okn_dsp_set_gain_db(okn_dsp_t *dsp, uint8_t channel, float gain_db) {
    if (dsp == NULL || !channel_valid(channel)) {
        return OKN_DSP_ERR_ARGUMENT;
    }
    if (!finite_in_range(gain_db, OKN_DSP_GAIN_MIN_DB, OKN_DSP_GAIN_MAX_DB)) {
        return OKN_DSP_ERR_RANGE;
    }

    dsp->channel[channel].gain_db = gain_db;
    dsp->linear_gain[channel] = okn_dsp_db_to_linear(gain_db);
    return OKN_DSP_OK;
}

okn_dsp_result_t okn_dsp_set_mute(okn_dsp_t *dsp, uint8_t channel, bool mute) {
    if (dsp == NULL || !channel_valid(channel)) {
        return OKN_DSP_ERR_ARGUMENT;
    }
    dsp->channel[channel].mute = mute;
    return OKN_DSP_OK;
}

okn_dsp_result_t okn_dsp_set_peq(okn_dsp_t *dsp,
                                 uint8_t channel,
                                 uint8_t band,
                                 const okn_peq_band_config_t *config) {
    if (dsp == NULL || config == NULL || !channel_valid(channel) || !band_valid(band)) {
        return OKN_DSP_ERR_ARGUMENT;
    }

    const float nyquist_guard = (float)dsp->sample_rate * 0.49f;
    if (!finite_in_range(config->frequency_hz, 10.0f, nyquist_guard) ||
        !finite_in_range(config->q, OKN_DSP_Q_MIN, OKN_DSP_Q_MAX) ||
        !finite_in_range(config->gain_db, OKN_DSP_PEQ_GAIN_MIN_DB, OKN_DSP_PEQ_GAIN_MAX_DB)) {
        return OKN_DSP_ERR_RANGE;
    }

    dsp->channel[channel].peq[band] = *config;
    update_peaking_coefficients(&dsp->biquad[channel][band], dsp->sample_rate, config);
    return OKN_DSP_OK;
}

static float process_biquad(okn_biquad_t *bq, float x) {
    const float y = bq->b0 * x + bq->z1;
    bq->z1 = bq->b1 * x - bq->a1 * y + bq->z2;
    bq->z2 = bq->b2 * x - bq->a2 * y;
    return y;
}

void okn_dsp_process_frame(okn_dsp_t *dsp, float frame[OKN_DSP_CHANNELS]) {
    if (dsp == NULL || frame == NULL) {
        return;
    }

    for (uint8_t ch = 0; ch < OKN_DSP_CHANNELS; ++ch) {
        float sample = frame[ch];

        for (uint8_t band = 0; band < OKN_DSP_PEQ_BANDS; ++band) {
            sample = process_biquad(&dsp->biquad[ch][band], sample);
        }

        /* Required signal order: PEQ -> dedicated Gain/Volume -> Mute. */
        sample *= dsp->linear_gain[ch];
        if (dsp->channel[ch].mute) {
            sample = 0.0f;
        }
        frame[ch] = sample;
    }
}

void okn_dsp_process_interleaved(okn_dsp_t *dsp, float *samples, uint32_t frames) {
    if (dsp == NULL || samples == NULL) {
        return;
    }

    for (uint32_t frame = 0; frame < frames; ++frame) {
        okn_dsp_process_frame(dsp, samples + (frame * OKN_DSP_CHANNELS));
    }
}
