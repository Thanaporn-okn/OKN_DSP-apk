#include "okn_control.h"

#include <stdio.h>
#include <string.h>

static okn_status_t validate_channel(uint8_t channel) {
    return channel < OKN_DSP_CHANNELS ? OKN_STATUS_OK : OKN_STATUS_BAD_CHANNEL;
}

static void response_base(const okn_packet_t *request, okn_packet_t *response) {
    memset(response, 0, sizeof(*response));
    response->version = OKN_PROTOCOL_VERSION;
    response->command = request->command;
    response->channel = request->channel;
    response->flags = 0x80u;
    response->sequence = request->sequence;
}

void okn_control_init(okn_control_t *control,
                      okn_dsp_t *dsp,
                      const char *firmware_name,
                      const char *firmware_version) {
    if (control == NULL) {
        return;
    }
    control->dsp = dsp;
    control->firmware_name = firmware_name;
    control->firmware_version = firmware_version;
}

okn_status_t okn_control_handle(const okn_control_t *control,
                                const okn_packet_t *request,
                                okn_packet_t *response) {
    if (control == NULL || control->dsp == NULL || request == NULL || response == NULL) {
        return OKN_STATUS_BAD_ARGUMENT;
    }

    response_base(request, response);

    switch ((okn_command_t)request->command) {
        case OKN_CMD_HELLO:
        case OKN_CMD_GET_INFO: {
            const char *name = control->firmware_name ? control->firmware_name : "OKN-DSP";
            const char *version = control->firmware_version ? control->firmware_version : "0.0.0";
            int n = snprintf((char *)response->payload,
                             OKN_PACKET_PAYLOAD_MAX,
                             "%s|%s|CH=%u|PEQ=%u|FS=%lu|FLASH=%s",
                             name,
                             version,
                             (unsigned)OKN_DSP_CHANNELS,
                             (unsigned)OKN_DSP_PEQ_BANDS,
                             (unsigned long)control->dsp->sample_rate,
#if OKN_ENABLE_FLASH_UPDATE
                             "ENABLED"
#else
                             "LOCKED"
#endif
            );
            if (n < 0) {
                return OKN_STATUS_BAD_ARGUMENT;
            }
            if ((size_t)n >= OKN_PACKET_PAYLOAD_MAX) {
                n = (int)OKN_PACKET_PAYLOAD_MAX - 1;
            }
            response->payload_length = (uint16_t)n;
            return OKN_STATUS_OK;
        }

        case OKN_CMD_SET_GAIN: {
            if (validate_channel(request->channel) != OKN_STATUS_OK) {
                return OKN_STATUS_BAD_CHANNEL;
            }
            if (request->payload_length != 4u) {
                return OKN_STATUS_BAD_LENGTH;
            }
            const float gain_db = okn_read_f32_le(request->payload);
            return okn_dsp_set_gain_db(control->dsp, request->channel, gain_db) == OKN_DSP_OK
                ? OKN_STATUS_OK : OKN_STATUS_BAD_ARGUMENT;
        }

        case OKN_CMD_SET_MUTE: {
            if (validate_channel(request->channel) != OKN_STATUS_OK) {
                return OKN_STATUS_BAD_CHANNEL;
            }
            if (request->payload_length != 1u || request->payload[0] > 1u) {
                return OKN_STATUS_BAD_ARGUMENT;
            }
            return okn_dsp_set_mute(control->dsp,
                                    request->channel,
                                    request->payload[0] != 0u) == OKN_DSP_OK
                ? OKN_STATUS_OK : OKN_STATUS_BAD_ARGUMENT;
        }

        case OKN_CMD_SET_PEQ: {
            if (validate_channel(request->channel) != OKN_STATUS_OK) {
                return OKN_STATUS_BAD_CHANNEL;
            }
            /* band:u8, enabled:u8, reserved:u16, f32 freq, f32 q, f32 gain = 16 bytes */
            if (request->payload_length != 16u) {
                return OKN_STATUS_BAD_LENGTH;
            }
            const uint8_t band = request->payload[0];
            if (band >= OKN_DSP_PEQ_BANDS || request->payload[1] > 1u) {
                return OKN_STATUS_BAD_ARGUMENT;
            }
            okn_peq_band_config_t cfg;
            cfg.enabled = request->payload[1] != 0u;
            cfg.frequency_hz = okn_read_f32_le(request->payload + 4);
            cfg.q = okn_read_f32_le(request->payload + 8);
            cfg.gain_db = okn_read_f32_le(request->payload + 12);
            return okn_dsp_set_peq(control->dsp, request->channel, band, &cfg) == OKN_DSP_OK
                ? OKN_STATUS_OK : OKN_STATUS_BAD_ARGUMENT;
        }

        case OKN_CMD_GET_CHANNEL: {
            if (validate_channel(request->channel) != OKN_STATUS_OK) {
                return OKN_STATUS_BAD_CHANNEL;
            }
            const okn_channel_config_t *cfg = &control->dsp->channel[request->channel];
            uint8_t *p = response->payload;
            okn_write_f32_le(p, cfg->gain_db);
            p[4] = cfg->mute ? 1u : 0u;
            p[5] = OKN_DSP_PEQ_BANDS;
            p[6] = 0u;
            p[7] = 0u;
            size_t offset = 8u;
            for (uint8_t band = 0; band < OKN_DSP_PEQ_BANDS; ++band) {
                p[offset + 0] = band;
                p[offset + 1] = cfg->peq[band].enabled ? 1u : 0u;
                okn_write_u16_le(p + offset + 2, 0u);
                okn_write_f32_le(p + offset + 4, cfg->peq[band].frequency_hz);
                okn_write_f32_le(p + offset + 8, cfg->peq[band].q);
                okn_write_f32_le(p + offset + 12, cfg->peq[band].gain_db);
                offset += 16u;
            }
            response->payload_length = (uint16_t)offset;
            return OKN_STATUS_OK;
        }

        case OKN_CMD_UPDATE_STATUS: {
            const char *msg =
#if OKN_ENABLE_FLASH_UPDATE
                "UPDATE_ENABLED";
#else
                "UPDATE_LOCKED: production bootstrap/layout/recovery gate not proven";
#endif
            const size_t n = strlen(msg);
            memcpy(response->payload, msg, n);
            response->payload_length = (uint16_t)n;
#if OKN_ENABLE_FLASH_UPDATE
            return OKN_STATUS_OK;
#else
            return OKN_STATUS_FLASH_LOCKED;
#endif
        }

        case OKN_CMD_ENTER_UPDATE:
#if OKN_ENABLE_FLASH_UPDATE
            return OKN_STATUS_OK;
#else
            return OKN_STATUS_FLASH_LOCKED;
#endif

        default:
            return OKN_STATUS_BAD_COMMAND;
    }
}
