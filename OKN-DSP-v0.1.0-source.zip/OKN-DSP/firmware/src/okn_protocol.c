#include "okn_protocol.h"

#include <string.h>

void okn_write_u16_le(uint8_t *dst, uint16_t value) {
    dst[0] = (uint8_t)(value & 0xFFu);
    dst[1] = (uint8_t)((value >> 8u) & 0xFFu);
}

void okn_write_u32_le(uint8_t *dst, uint32_t value) {
    dst[0] = (uint8_t)(value & 0xFFu);
    dst[1] = (uint8_t)((value >> 8u) & 0xFFu);
    dst[2] = (uint8_t)((value >> 16u) & 0xFFu);
    dst[3] = (uint8_t)((value >> 24u) & 0xFFu);
}

void okn_write_f32_le(uint8_t *dst, float value) {
    uint32_t bits = 0;
    memcpy(&bits, &value, sizeof(bits));
    okn_write_u32_le(dst, bits);
}

uint16_t okn_read_u16_le(const uint8_t *src) {
    return (uint16_t)((uint16_t)src[0] | ((uint16_t)src[1] << 8u));
}

uint32_t okn_read_u32_le(const uint8_t *src) {
    return (uint32_t)src[0] |
           ((uint32_t)src[1] << 8u) |
           ((uint32_t)src[2] << 16u) |
           ((uint32_t)src[3] << 24u);
}

float okn_read_f32_le(const uint8_t *src) {
    uint32_t bits = okn_read_u32_le(src);
    float value = 0.0f;
    memcpy(&value, &bits, sizeof(value));
    return value;
}

uint32_t okn_crc32(const uint8_t *data, size_t length) {
    uint32_t crc = 0xFFFFFFFFu;
    for (size_t i = 0; i < length; ++i) {
        crc ^= data[i];
        for (unsigned bit = 0; bit < 8u; ++bit) {
            const uint32_t mask = (uint32_t)-(int32_t)(crc & 1u);
            crc = (crc >> 1u) ^ (0xEDB88320u & mask);
        }
    }
    return ~crc;
}

okn_status_t okn_packet_encode(const okn_packet_t *packet,
                               uint8_t out[OKN_PACKET_SIZE]) {
    if (packet == NULL || out == NULL) {
        return OKN_STATUS_BAD_ARGUMENT;
    }
    if (packet->payload_length > OKN_PACKET_PAYLOAD_MAX) {
        return OKN_STATUS_BAD_LENGTH;
    }

    memset(out, 0, OKN_PACKET_SIZE);
    out[0] = OKN_MAGIC_0;
    out[1] = OKN_MAGIC_1;
    out[2] = OKN_MAGIC_2;
    out[3] = OKN_MAGIC_3;
    out[4] = packet->version;
    out[5] = packet->command;
    out[6] = packet->channel;
    out[7] = packet->flags;
    okn_write_u32_le(out + 8, packet->sequence);
    okn_write_u16_le(out + 12, packet->payload_length);
    out[14] = 0;
    out[15] = 0;
    if (packet->payload_length != 0u) {
        memcpy(out + 16, packet->payload, packet->payload_length);
    }
    okn_write_u32_le(out + 252, okn_crc32(out, 252u));
    return OKN_STATUS_OK;
}

okn_status_t okn_packet_decode(const uint8_t in[OKN_PACKET_SIZE],
                               okn_packet_t *packet) {
    if (in == NULL || packet == NULL) {
        return OKN_STATUS_BAD_ARGUMENT;
    }
    if (in[0] != OKN_MAGIC_0 || in[1] != OKN_MAGIC_1 ||
        in[2] != OKN_MAGIC_2 || in[3] != OKN_MAGIC_3) {
        return OKN_STATUS_BAD_MAGIC;
    }
    if (in[4] != OKN_PROTOCOL_VERSION) {
        return OKN_STATUS_BAD_VERSION;
    }

    const uint16_t payload_length = okn_read_u16_le(in + 12);
    if (payload_length > OKN_PACKET_PAYLOAD_MAX) {
        return OKN_STATUS_BAD_LENGTH;
    }

    const uint32_t expected_crc = okn_read_u32_le(in + 252);
    const uint32_t actual_crc = okn_crc32(in, 252u);
    if (expected_crc != actual_crc) {
        return OKN_STATUS_BAD_CRC;
    }

    memset(packet, 0, sizeof(*packet));
    packet->version = in[4];
    packet->command = in[5];
    packet->channel = in[6];
    packet->flags = in[7];
    packet->sequence = okn_read_u32_le(in + 8);
    packet->payload_length = payload_length;
    if (payload_length != 0u) {
        memcpy(packet->payload, in + 16, payload_length);
    }
    return OKN_STATUS_OK;
}
