#ifndef OKN_BOARD_H
#define OKN_BOARD_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    OKN_BOARD_OK = 0,
    OKN_BOARD_ERR = -1,
    OKN_BOARD_LOCKED = -2,
    OKN_BOARD_UNSUPPORTED = -3
} okn_board_result_t;

okn_board_result_t okn_board_init(void);
okn_board_result_t okn_board_usb_poll(uint8_t *rx_256, uint8_t *has_packet);
okn_board_result_t okn_board_usb_send(const uint8_t *tx_256);

okn_board_result_t okn_board_flash_begin(uint32_t image_size, uint32_t expected_crc32);
okn_board_result_t okn_board_flash_write(uint32_t offset, const uint8_t *data, size_t length);
okn_board_result_t okn_board_flash_finalize(void);

#ifdef __cplusplus
}
#endif

#endif
