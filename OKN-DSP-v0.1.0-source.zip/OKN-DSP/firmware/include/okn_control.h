#ifndef OKN_CONTROL_H
#define OKN_CONTROL_H

#include <stdint.h>
#include "okn_dsp.h"
#include "okn_protocol.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef OKN_ENABLE_FLASH_UPDATE
#define OKN_ENABLE_FLASH_UPDATE 0
#endif

typedef struct {
    okn_dsp_t *dsp;
    const char *firmware_name;
    const char *firmware_version;
} okn_control_t;

void okn_control_init(okn_control_t *control,
                      okn_dsp_t *dsp,
                      const char *firmware_name,
                      const char *firmware_version);

okn_status_t okn_control_handle(const okn_control_t *control,
                                const okn_packet_t *request,
                                okn_packet_t *response);

#ifdef __cplusplus
}
#endif

#endif
