#ifndef OKN_PROTOCOL_H
#define OKN_PROTOCOL_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define OKN_PACKET_SIZE 256u
#define OKN_PACKET_PAYLOAD_MAX 236u
#define OKN_PROTOCOL_VERSION 1u
#define OKN_CHANNEL_GLOBAL 0xFFu

#define OKN_MAGIC_0 ((uint8_t)'O')
#define OKN_MAGIC_1 ((uint8_t)'K')
#define OKN_MAGIC_2 ((uint8_t)'N')
#define OKN_MAGIC_3 ((uint8_t)'1')

typedef enum {
    OKN_CMD_HELLO = 0x20,
    OKN_CMD_GET_INFO = 0x21,
    OKN_CMD_GET_CHANNEL = 0x22,
    OKN_CMD_SET_GAIN = 0x40,
    OKN_CMD_SET_PEQ = 0x41,
    OKN_CMD_SET_MUTE = 0x42,
    OKN_CMD_SAVE_PRESET = 0x50,
    OKN_CMD_LOAD_PRESET = 0x51,
    OKN_CMD_UPDATE_STATUS = 0x70,
    OKN_CMD_ENTER_UPDATE = 0x7A
} okn_command_t;

typedef enum {
    OKN_STATUS_OK = 0,
    OKN_STATUS_BAD_MAGIC = 1,
    OKN_STATUS_BAD_VERSION = 2,
    OKN_STATUS_BAD_LENGTH = 3,
    OKN_STATUS_BAD_CRC = 4,
    OKN_STATUS_BAD_COMMAND = 5,
    OKN_STATUS_BAD_CHANNEL = 6,
    OKN_STATUS_BAD_ARGUMENT = 7,
    OKN_STATUS_FLASH_LOCKED = 8
} okn_status_t;

typedef struct {
    uint8_t version;
    uint8_t command;
    uint8_t channel;
    uint8_t flags;
    uint32_t sequence;
    uint16_t payload_length;
    uint8_t payload[OKN_PACKET_PAYLOAD_MAX];
} okn_packet_t;

uint32_t okn_crc32(const uint8_t *data, size_t length);

okn_status_t okn_packet_encode(const okn_packet_t *packet,
                               uint8_t out[OKN_PACKET_SIZE]);
okn_status_t okn_packet_decode(const uint8_t in[OKN_PACKET_SIZE],
                               okn_packet_t *packet);

void okn_write_u16_le(uint8_t *dst, uint16_t value);
void okn_write_u32_le(uint8_t *dst, uint32_t value);
void okn_write_f32_le(uint8_t *dst, float value);
uint16_t okn_read_u16_le(const uint8_t *src);
uint32_t okn_read_u32_le(const uint8_t *src);
float okn_read_f32_le(const uint8_t *src);

#ifdef __cplusplus
}
#endif

#endif
