#ifndef OKN_DSP_H
#define OKN_DSP_H

#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define OKN_DSP_CHANNELS 7u
#define OKN_DSP_PEQ_BANDS 15u
#define OKN_DSP_DEFAULT_SAMPLE_RATE 48000u

#define OKN_DSP_GAIN_MIN_DB (-60.0f)
#define OKN_DSP_GAIN_MAX_DB (12.0f)
#define OKN_DSP_PEQ_GAIN_MIN_DB (-18.0f)
#define OKN_DSP_PEQ_GAIN_MAX_DB (18.0f)
#define OKN_DSP_Q_MIN (0.10f)
#define OKN_DSP_Q_MAX (20.0f)

typedef enum {
    OKN_DSP_OK = 0,
    OKN_DSP_ERR_ARGUMENT = -1,
    OKN_DSP_ERR_RANGE = -2
} okn_dsp_result_t;

typedef struct {
    float frequency_hz;
    float q;
    float gain_db;
    bool enabled;
} okn_peq_band_config_t;

typedef struct {
    okn_peq_band_config_t peq[OKN_DSP_PEQ_BANDS];
    float gain_db;
    bool mute;
} okn_channel_config_t;

typedef struct {
    float b0;
    float b1;
    float b2;
    float a1;
    float a2;
    float z1;
    float z2;
} okn_biquad_t;

typedef struct {
    uint32_t sample_rate;
    okn_channel_config_t channel[OKN_DSP_CHANNELS];
    okn_biquad_t biquad[OKN_DSP_CHANNELS][OKN_DSP_PEQ_BANDS];
    float linear_gain[OKN_DSP_CHANNELS];
} okn_dsp_t;

void okn_dsp_init(okn_dsp_t *dsp, uint32_t sample_rate);
void okn_dsp_reset_state(okn_dsp_t *dsp);

okn_dsp_result_t okn_dsp_set_gain_db(okn_dsp_t *dsp, uint8_t channel, float gain_db);
okn_dsp_result_t okn_dsp_set_mute(okn_dsp_t *dsp, uint8_t channel, bool mute);
okn_dsp_result_t okn_dsp_set_peq(okn_dsp_t *dsp,
                                 uint8_t channel,
                                 uint8_t band,
                                 const okn_peq_band_config_t *config);

void okn_dsp_process_frame(okn_dsp_t *dsp, float frame[OKN_DSP_CHANNELS]);
void okn_dsp_process_interleaved(okn_dsp_t *dsp, float *samples, uint32_t frames);

float okn_dsp_db_to_linear(float db);

#ifdef __cplusplus
}
#endif

#endif
