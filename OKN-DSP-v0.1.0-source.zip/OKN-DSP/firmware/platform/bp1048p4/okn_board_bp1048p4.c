#include "okn_board.h"
#include "okn_bp1048p4_gate.h"

/*
 * Clean-room board port placeholder.
 *
 * What is intentionally NOT guessed here:
 * - production first-bootstrap sequence
 * - stock flash map / reserved calibration regions
 * - USB updater endpoint semantics
 * - CH3 DACX and production I2S physical mapping
 *
 * Once those are proven, this file is the only hardware-facing layer that
 * needs to change. The DSP/control code above remains independent.
 */

okn_board_result_t okn_board_init(void) {
    return OKN_BOARD_OK;
}

okn_board_result_t okn_board_usb_poll(uint8_t *rx_256, uint8_t *has_packet) {
    (void)rx_256;
    if (has_packet != 0) {
        *has_packet = 0u;
    }
    return OKN_BOARD_UNSUPPORTED;
}

okn_board_result_t okn_board_usb_send(const uint8_t *tx_256) {
    (void)tx_256;
    return OKN_BOARD_UNSUPPORTED;
}

okn_board_result_t okn_board_flash_begin(uint32_t image_size, uint32_t expected_crc32) {
    (void)image_size;
    (void)expected_crc32;
    return OKN_BOARD_LOCKED;
}

okn_board_result_t okn_board_flash_write(uint32_t offset, const uint8_t *data, size_t length) {
    (void)offset;
    (void)data;
    (void)length;
    return OKN_BOARD_LOCKED;
}

okn_board_result_t okn_board_flash_finalize(void) {
    return OKN_BOARD_LOCKED;
}
