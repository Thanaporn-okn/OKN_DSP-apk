#ifndef OKN_BP1048P4_GATE_H
#define OKN_BP1048P4_GATE_H

/*
 * These values are intentionally 0 until production evidence exists for the
 * exact GoloPine/DSTech BP1048P4 board. Do not flip them from inference or a
 * BP1048B2/reference-SDK layout.
 */
#define OKN_PROD_BOOTSTRAP_PROVEN 0
#define OKN_PROD_STOCK_BACKUP_PROVEN 0
#define OKN_PROD_RECOVERY_PROVEN 0
#define OKN_PROD_FLASH_LAYOUT_PROVEN 0
#define OKN_PROD_IMAGE_ACCEPTANCE_PROVEN 0
#define OKN_PROD_USB_UPDATE_TRANSPORT_PROVEN 0

#define OKN_PROD_FLASH_READY \
    (OKN_PROD_BOOTSTRAP_PROVEN && \
     OKN_PROD_STOCK_BACKUP_PROVEN && \
     OKN_PROD_RECOVERY_PROVEN && \
     OKN_PROD_FLASH_LAYOUT_PROVEN && \
     OKN_PROD_IMAGE_ACCEPTANCE_PROVEN && \
     OKN_PROD_USB_UPDATE_TRANSPORT_PROVEN)

#if defined(OKN_FORCE_ENABLE_PRODUCTION_FLASH) && OKN_FORCE_ENABLE_PRODUCTION_FLASH
# if !OKN_PROD_FLASH_READY
#  error "Production flash requested while OKN-DSP safety gates are incomplete"
# endif
#endif

#endif
