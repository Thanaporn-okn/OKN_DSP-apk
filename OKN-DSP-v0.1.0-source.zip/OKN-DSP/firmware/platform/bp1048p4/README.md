# BP1048P4 production port

This directory is the only place where GoloPine/DSTech board-specific code is allowed.

The host/reference DSP engine is complete enough to test 7 independent channels, 15 PEQ bands per channel, and a dedicated gain stage after PEQ. The production board port remains deliberately locked because the exact stock first-bootstrap path, stock-backup/recovery path, production flash layout/image rules, and production USB updater transport are not yet proven.

Do not copy a BP1048B2 layout or reference SDK flashboot layout into this port and call it production-safe.
