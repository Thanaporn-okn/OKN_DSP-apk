#include "okn_control.h"
#include "okn_protocol.h"

#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

static void test_round_trip(void) {
    okn_packet_t src = {0};
    src.version = OKN_PROTOCOL_VERSION;
    src.command = OKN_CMD_SET_GAIN;
    src.channel = 2u;
    src.sequence = 0x12345678u;
    src.payload_length = 4u;
    okn_write_f32_le(src.payload, -3.5f);

    uint8_t raw[OKN_PACKET_SIZE];
    assert(okn_packet_encode(&src, raw) == OKN_STATUS_OK);

    okn_packet_t dst;
    assert(okn_packet_decode(raw, &dst) == OKN_STATUS_OK);
    assert(dst.command == src.command);
    assert(dst.channel == src.channel);
    assert(dst.sequence == src.sequence);
    assert(dst.payload_length == src.payload_length);
    assert(fabsf(okn_read_f32_le(dst.payload) + 3.5f) < 1.0e-6f);
}

static void test_crc_rejects_tamper(void) {
    okn_packet_t packet = {0};
    packet.version = OKN_PROTOCOL_VERSION;
    packet.command = OKN_CMD_HELLO;
    packet.channel = OKN_CHANNEL_GLOBAL;
    uint8_t raw[OKN_PACKET_SIZE];
    assert(okn_packet_encode(&packet, raw) == OKN_STATUS_OK);
    raw[100] ^= 0x5Au;
    okn_packet_t decoded;
    assert(okn_packet_decode(raw, &decoded) == OKN_STATUS_BAD_CRC);
}

static void test_control_gain(void) {
    okn_dsp_t dsp;
    okn_dsp_init(&dsp, 48000u);
    okn_control_t control;
    okn_control_init(&control, &dsp, "OKN-DSP", "0.1.0");

    okn_packet_t request = {0};
    request.version = OKN_PROTOCOL_VERSION;
    request.command = OKN_CMD_SET_GAIN;
    request.channel = 4u;
    request.sequence = 9u;
    request.payload_length = 4u;
    okn_write_f32_le(request.payload, 2.5f);

    okn_packet_t response;
    assert(okn_control_handle(&control, &request, &response) == OKN_STATUS_OK);
    assert(fabsf(dsp.channel[4].gain_db - 2.5f) < 1.0e-6f);
    assert(fabsf(dsp.channel[0].gain_db) < 1.0e-6f);
}

static void test_flash_update_locked(void) {
    okn_dsp_t dsp;
    okn_dsp_init(&dsp, 48000u);
    okn_control_t control;
    okn_control_init(&control, &dsp, "OKN-DSP", "0.1.0");

    okn_packet_t request = {0};
    request.version = OKN_PROTOCOL_VERSION;
    request.command = OKN_CMD_ENTER_UPDATE;
    request.channel = OKN_CHANNEL_GLOBAL;
    okn_packet_t response;
    assert(okn_control_handle(&control, &request, &response) == OKN_STATUS_FLASH_LOCKED);
}

int main(void) {
    test_round_trip();
    test_crc_rejects_tamper();
    test_control_gain();
    test_flash_update_locked();
    puts("OKN-DSP protocol tests: PASS");
    return 0;
}
