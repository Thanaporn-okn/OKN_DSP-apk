#include "okn_dsp.h"

#include <assert.h>
#include <math.h>
#include <stdio.h>

static int nearly_equal(float a, float b, float eps) {
    return fabsf(a - b) <= eps;
}

static void test_identity(void) {
    okn_dsp_t dsp;
    okn_dsp_init(&dsp, 48000u);

    float frame[OKN_DSP_CHANNELS] = {0.1f, -0.2f, 0.3f, -0.4f, 0.5f, -0.6f, 0.7f};
    const float expected[OKN_DSP_CHANNELS] = {0.1f, -0.2f, 0.3f, -0.4f, 0.5f, -0.6f, 0.7f};
    okn_dsp_process_frame(&dsp, frame);
    for (unsigned ch = 0; ch < OKN_DSP_CHANNELS; ++ch) {
        assert(nearly_equal(frame[ch], expected[ch], 1.0e-6f));
    }
}

static void test_independent_gain(void) {
    okn_dsp_t dsp;
    okn_dsp_init(&dsp, 48000u);
    assert(okn_dsp_set_gain_db(&dsp, 3u, 6.0f) == OKN_DSP_OK);

    float frame[OKN_DSP_CHANNELS] = {1, 1, 1, 1, 1, 1, 1};
    okn_dsp_process_frame(&dsp, frame);
    for (unsigned ch = 0; ch < OKN_DSP_CHANNELS; ++ch) {
        if (ch == 3u) {
            assert(nearly_equal(frame[ch], okn_dsp_db_to_linear(6.0f), 1.0e-5f));
        } else {
            assert(nearly_equal(frame[ch], 1.0f, 1.0e-6f));
        }
    }
}

static void test_mute_is_per_channel(void) {
    okn_dsp_t dsp;
    okn_dsp_init(&dsp, 48000u);
    assert(okn_dsp_set_mute(&dsp, 6u, true) == OKN_DSP_OK);

    float frame[OKN_DSP_CHANNELS] = {1, 1, 1, 1, 1, 1, 1};
    okn_dsp_process_frame(&dsp, frame);
    for (unsigned ch = 0; ch < OKN_DSP_CHANNELS - 1u; ++ch) {
        assert(nearly_equal(frame[ch], 1.0f, 1.0e-6f));
    }
    assert(frame[6] == 0.0f);
}

static void test_peq_is_channel_local(void) {
    okn_dsp_t dsp;
    okn_dsp_init(&dsp, 48000u);
    okn_peq_band_config_t peq = {
        .frequency_hz = 1000.0f,
        .q = 1.0f,
        .gain_db = 12.0f,
        .enabled = true
    };
    assert(okn_dsp_set_peq(&dsp, 0u, 7u, &peq) == OKN_DSP_OK);

    double e0 = 0.0;
    double e1 = 0.0;
    const unsigned total = 4800u;
    for (unsigned n = 0; n < total; ++n) {
        const float x = sinf(2.0f * 3.14159265358979323846f * 1000.0f * (float)n / 48000.0f);
        float frame[OKN_DSP_CHANNELS] = {x, x, 0, 0, 0, 0, 0};
        okn_dsp_process_frame(&dsp, frame);
        if (n > 500u) {
            e0 += (double)frame[0] * frame[0];
            e1 += (double)frame[1] * frame[1];
        }
    }
    assert(e0 > e1 * 5.0);
}

static void test_range_checks(void) {
    okn_dsp_t dsp;
    okn_dsp_init(&dsp, 48000u);
    assert(okn_dsp_set_gain_db(&dsp, 7u, 0.0f) == OKN_DSP_ERR_ARGUMENT);
    assert(okn_dsp_set_gain_db(&dsp, 0u, 30.0f) == OKN_DSP_ERR_RANGE);

    okn_peq_band_config_t bad = {.frequency_hz = 30000.0f, .q = 1.0f, .gain_db = 0.0f, .enabled = true};
    assert(okn_dsp_set_peq(&dsp, 0u, 0u, &bad) == OKN_DSP_ERR_RANGE);
}

int main(void) {
    test_identity();
    test_independent_gain();
    test_mute_is_per_channel();
    test_peq_is_channel_local();
    test_range_checks();
    puts("OKN-DSP DSP tests: PASS");
    return 0;
}
