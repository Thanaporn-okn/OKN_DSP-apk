# OKN-DSP

Clean-room replacement DSP firmware + Samsung Galaxy S25+ Android controller for the GoloPine/DSTech 7-channel BP1048P4 board.

## What is implemented in v0.1

- New portable firmware logic; not a patch of the stock application.
- 7 independent channels.
- 15-band PEQ on every channel.
- Dedicated per-channel Gain/Volume **after** PEQ.
- Per-channel mute.
- Fixed 256-byte `OKN1` control protocol with CRC32.
- Native Android app named **OKN-DSP** for Samsung S25+ / Android USB Host.
- CH1..CH7 UI with dedicated Gain −/+ buttons and 15 PEQ −/+ controls per channel.
- Read-only USB descriptor inspection for the currently observed stock `6324:1719` device.
- Compile-time gates that keep runtime USB TX and production flash disabled.
- Host unit tests for DSP channel independence, PEQ behavior, packet encoding and CRC.

## Important first-flash status

The new DSP/control code exists, but the **first safe write to the production board is not yet proven**. The stock production first-bootstrap, backup/recovery path, exact flash layout/image acceptance, and updater USB transport must all be proven before `OKN_PRODUCTION_FLASH_ENABLED` can become true.

This project does not use soldering, debug probes, programmer dongles or board modification as an alternative. The final installation path remains S25+ USB-C directly to the board USB-C.

## Firmware host build

```sh
cmake -S firmware -B firmware/build -G Ninja -DCMAKE_BUILD_TYPE=Debug
cmake --build firmware/build
ctest --test-dir firmware/build --output-on-failure
```

## Android host protocol test

```sh
mkdir -p android-app/host-test/out
javac -d android-app/host-test/out \
  android-app/app/src/main/java/com/okn/dsp/DspModel.java \
  android-app/app/src/main/java/com/okn/dsp/OknPacket.java \
  android-app/host-test/OknPacketHostTest.java
java -cp android-app/host-test/out com.okn.dsp.OknPacketHostTest
```

## Android APK

The Android project lives in `android-app/`. CI can build `app-debug.apk` without connecting to a DSP board. USB transmit and flash remain disabled in v0.1.
