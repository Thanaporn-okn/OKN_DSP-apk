package com.okn.dsp;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.zip.CRC32;

public final class OknPacketHostTest {
    private static void check(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        byte[] packet = new OknPacket(OknPacket.CMD_SET_GAIN, 3, 0x12345678L, OknPacket.f32(-2.5f)).encode();
        check(packet.length == 256, "size");
        check(packet[0] == 'O' && packet[1] == 'K' && packet[2] == 'N' && packet[3] == '1', "magic");
        check((packet[5] & 0xFF) == OknPacket.CMD_SET_GAIN, "command");
        check((packet[6] & 0xFF) == 3, "channel");

        ByteBuffer b = ByteBuffer.wrap(packet).order(ByteOrder.LITTLE_ENDIAN);
        check((b.getInt(8) & 0xFFFF_FFFFL) == 0x12345678L, "sequence");
        check((b.getShort(12) & 0xFFFF) == 4, "payload length");
        check(Math.abs(b.getFloat(16) + 2.5f) < 1e-6f, "float payload");

        CRC32 crc = new CRC32();
        crc.update(packet, 0, 252);
        check((b.getInt(252) & 0xFFFF_FFFFL) == crc.getValue(), "crc32");

        DspModel model = new DspModel();
        model.channel[6].gainDb = DspModel.clamp(25f, -60f, 12f);
        check(model.channel[6].gainDb == 12f, "gain clamp");
        check(model.channel[0].gainDb == 0f, "channel independence");

        System.out.println("OKN-DSP Android host protocol test: PASS");
    }
}
