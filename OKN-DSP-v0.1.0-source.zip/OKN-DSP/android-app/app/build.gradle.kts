plugins {
    id("com.android.application")
}

android {
    namespace = "com.okn.dsp"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.okn.dsp"
        minSdk = 28
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"

        buildConfigField("boolean", "OKN_RUNTIME_USB_TX_ENABLED", "false")
        buildConfigField("boolean", "OKN_PRODUCTION_FLASH_ENABLED", "false")
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
