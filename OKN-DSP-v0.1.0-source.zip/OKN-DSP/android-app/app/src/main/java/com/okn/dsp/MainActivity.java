package com.okn.dsp;

import android.app.Activity;
import android.graphics.Typeface;
import android.hardware.usb.UsbDevice;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class MainActivity extends Activity {
    private final DspModel model = new DspModel();
    private final OknRuntimeTransport runtimeTransport = new OknRuntimeTransport();
    private final List<TextView> bandValueViews = new ArrayList<>();

    private UsbInspector usbInspector;
    private UsbDevice selectedUsbDevice;
    private TextView usbStatus;
    private TextView channelTitle;
    private TextView gainValue;
    private Button muteButton;
    private int selectedChannel = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        usbInspector = new UsbInspector(this);
        setContentView(buildUi());
        inspectUsb();
        refreshChannelUi();
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = vertical();
        root.setPadding(dp(16), dp(18), dp(16), dp(40));
        scroll.addView(root);

        TextView title = text("OKN-DSP", 30, true);
        root.addView(title);
        root.addView(text("BP1048P4 • 7CH • 15-band PEQ • dedicated Gain/Volume", 14, false));

        usbStatus = text("กำลังตรวจ USB…", 13, false);
        usbStatus.setPadding(0, dp(16), 0, dp(8));
        root.addView(usbStatus);

        Button scanUsb = button("ตรวจ USB-C DSP (อ่านอย่างเดียว)");
        scanUsb.setOnClickListener(v -> inspectUsb());
        root.addView(scanUsb);

        TextView gate = text(FirmwareGate.status(), 13, true);
        gate.setPadding(0, dp(12), 0, dp(12));
        root.addView(gate);

        root.addView(section("เลือก Channel"));
        HorizontalScrollView channelScroll = new HorizontalScrollView(this);
        LinearLayout channels = horizontal();
        for (int i = 0; i < DspModel.CHANNELS; i++) {
            final int ch = i;
            Button b = button("CH" + (i + 1));
            b.setOnClickListener(v -> {
                selectedChannel = ch;
                refreshChannelUi();
            });
            channels.addView(b, new LinearLayout.LayoutParams(dp(72), dp(48)));
        }
        channelScroll.addView(channels);
        root.addView(channelScroll);

        channelTitle = section("CH1");
        root.addView(channelTitle);

        root.addView(text("Dedicated Gain / Volume (หลัง PEQ)", 16, true));
        LinearLayout gainRow = horizontal();
        Button gainMinus = button("−");
        Button gainPlus = button("+");
        gainValue = centeredValue();
        gainMinus.setOnClickListener(v -> adjustGain(-0.5f));
        gainPlus.setOnClickListener(v -> adjustGain(+0.5f));
        gainRow.addView(gainMinus, new LinearLayout.LayoutParams(dp(72), dp(52)));
        gainRow.addView(gainValue, new LinearLayout.LayoutParams(0, dp(52), 1f));
        gainRow.addView(gainPlus, new LinearLayout.LayoutParams(dp(72), dp(52)));
        root.addView(gainRow);

        muteButton = button("Mute: OFF");
        muteButton.setOnClickListener(v -> {
            model.channel[selectedChannel].mute = !model.channel[selectedChannel].mute;
            refreshChannelUi();
        });
        root.addView(muteButton);

        root.addView(section("15-band PEQ — ปุ่ม − / + แยกแต่ละ Band"));
        for (int band = 0; band < DspModel.BANDS; band++) {
            root.addView(buildBandRow(band));
        }

        Button send = button("ส่งค่าช่องนี้ไป OKN-DSP Firmware");
        send.setOnClickListener(v -> sendCurrentChannel());
        root.addView(send);

        Button firmware = button("Firmware Update / Flash");
        firmware.setEnabled(FirmwareGate.canFlash());
        firmware.setOnClickListener(v -> Toast.makeText(this, FirmwareGate.status(), Toast.LENGTH_LONG).show());
        root.addView(firmware);

        root.addView(text(
                "หมายเหตุ: v0.1 ไม่ส่ง packet ใด ๆ ไป stock firmware และไม่ erase/program flash. "
                        + "หน้าจอ EQ/Gain ใช้งานเป็น model/simulator จนกว่าจะพิสูจน์ production bootstrap ได้",
                12,
                false));

        return scroll;
    }

    private View buildBandRow(int band) {
        LinearLayout row = horizontal();
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(4), 0, dp(4));

        TextView f = text(String.format(Locale.US, "%02d  %s", band + 1,
                DspModel.frequencyLabel(DspModel.FREQUENCIES[band])), 13, false);
        Button minus = button("−");
        Button plus = button("+");
        TextView value = centeredValue();
        bandValueViews.add(value);

        minus.setOnClickListener(v -> adjustBand(band, -0.5f));
        plus.setOnClickListener(v -> adjustBand(band, +0.5f));

        row.addView(f, new LinearLayout.LayoutParams(dp(132), dp(48)));
        row.addView(minus, new LinearLayout.LayoutParams(dp(58), dp(48)));
        row.addView(value, new LinearLayout.LayoutParams(0, dp(48), 1f));
        row.addView(plus, new LinearLayout.LayoutParams(dp(58), dp(48)));
        return row;
    }

    private void adjustGain(float delta) {
        DspModel.Channel ch = model.channel[selectedChannel];
        ch.gainDb = DspModel.clamp(ch.gainDb + delta, -60f, 12f);
        refreshChannelUi();
    }

    private void adjustBand(int band, float delta) {
        DspModel.Channel ch = model.channel[selectedChannel];
        ch.peqGainDb[band] = DspModel.clamp(ch.peqGainDb[band] + delta, -18f, 18f);
        refreshChannelUi();
    }

    private void refreshChannelUi() {
        if (channelTitle == null) return;
        DspModel.Channel ch = model.channel[selectedChannel];
        channelTitle.setText("CH" + (selectedChannel + 1));
        gainValue.setText(DspModel.db(ch.gainDb));
        muteButton.setText(ch.mute ? "Mute: ON" : "Mute: OFF");
        for (int band = 0; band < DspModel.BANDS; band++) {
            bandValueViews.get(band).setText(DspModel.db(ch.peqGainDb[band]));
        }
    }

    private void inspectUsb() {
        UsbInspector.Result result = usbInspector.inspect();
        selectedUsbDevice = result.device;
        usbStatus.setText(result.text);
    }

    private void sendCurrentChannel() {
        if (!runtimeTransport.isTxEnabled()) {
            Toast.makeText(this,
                    "USB TX ถูกล็อกเพื่อไม่ส่ง packet ไป stock firmware โดยไม่พิสูจน์ protocol",
                    Toast.LENGTH_LONG).show();
            return;
        }
        try {
            DspModel.Channel ch = model.channel[selectedChannel];
            runtimeTransport.sendGain(selectedUsbDevice, selectedChannel, ch.gainDb);
            for (int band = 0; band < DspModel.BANDS; band++) {
                runtimeTransport.sendPeq(selectedUsbDevice, selectedChannel, band,
                        DspModel.FREQUENCIES[band], ch.q[band], ch.peqGainDb[band]);
            }
            Toast.makeText(this, "ส่งค่า CH" + (selectedChannel + 1) + " แล้ว", Toast.LENGTH_SHORT).show();
        } catch (RuntimeException ex) {
            Toast.makeText(this, ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        return l;
    }

    private TextView text(String value, int sp, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(sp);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private TextView section(String value) {
        TextView v = text(value, 20, true);
        v.setPadding(0, dp(20), 0, dp(8));
        return v;
    }

    private TextView centeredValue() {
        TextView v = text("+0.0 dB", 15, true);
        v.setGravity(Gravity.CENTER);
        return v;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        return b;
    }

    private int dp(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }
}
