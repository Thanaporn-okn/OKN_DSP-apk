package com.okn.dsp;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;
import java.util.zip.CRC32;

final class OknPacket {
    static final int SIZE = 256;
    static final int PAYLOAD_MAX = 236;
    static final int VERSION = 1;

    static final int CMD_HELLO = 0x20;
    static final int CMD_GET_INFO = 0x21;
    static final int CMD_GET_CHANNEL = 0x22;
    static final int CMD_SET_GAIN = 0x40;
    static final int CMD_SET_PEQ = 0x41;
    static final int CMD_SET_MUTE = 0x42;
    static final int CMD_UPDATE_STATUS = 0x70;
    static final int CMD_ENTER_UPDATE = 0x7A;

    final int command;
    final int channel;
    final long sequence;
    final byte[] payload;

    OknPacket(int command, int channel, long sequence, byte[] payload) {
        if (payload.length > PAYLOAD_MAX) {
            throw new IllegalArgumentException("payload too large");
        }
        this.command = command;
        this.channel = channel;
        this.sequence = sequence & 0xFFFF_FFFFL;
        this.payload = Arrays.copyOf(payload, payload.length);
    }

    byte[] encode() {
        ByteBuffer out = ByteBuffer.allocate(SIZE).order(ByteOrder.LITTLE_ENDIAN);
        out.put((byte) 'O');
        out.put((byte) 'K');
        out.put((byte) 'N');
        out.put((byte) '1');
        out.put((byte) VERSION);
        out.put((byte) command);
        out.put((byte) channel);
        out.put((byte) 0);
        out.putInt((int) sequence);
        out.putShort((short) payload.length);
        out.putShort((short) 0);
        out.put(payload);
        out.position(252);
        CRC32 crc = new CRC32();
        crc.update(out.array(), 0, 252);
        out.putInt((int) crc.getValue());
        return out.array();
    }

    static byte[] f32(float value) {
        return ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putFloat(value).array();
    }

    static byte[] peqPayload(int band, boolean enabled, float frequency, float q, float gainDb) {
        ByteBuffer b = ByteBuffer.allocate(16).order(ByteOrder.LITTLE_ENDIAN);
        b.put((byte) band);
        b.put((byte) (enabled ? 1 : 0));
        b.putShort((short) 0);
        b.putFloat(frequency);
        b.putFloat(q);
        b.putFloat(gainDb);
        return b.array();
    }
}
