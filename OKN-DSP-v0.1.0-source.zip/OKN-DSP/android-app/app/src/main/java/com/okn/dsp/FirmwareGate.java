package com.okn.dsp;

final class FirmwareGate {
    private FirmwareGate() {}

    static boolean canFlash() {
        return BuildConfig.OKN_PRODUCTION_FLASH_ENABLED;
    }

    static String status() {
        if (canFlash()) {
            return "FLASH ENABLED";
        }
        return "FLASH LOCKED\n"
                + "ยังต้องพิสูจน์: production first-bootstrap, stock backup/recovery, "
                + "production flash layout/image acceptance และ USB update transport";
    }
}
