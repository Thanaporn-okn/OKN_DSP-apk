package com.okn.dsp;

import android.hardware.usb.UsbDevice;

/**
 * Runtime transport for the NEW OKN-DSP firmware only.
 *
 * It is deliberately compile-time locked in v0.1. The stock production board
 * must never receive guessed OKN packets. Enable only after the first-flash
 * path is proven and the running firmware can be positively identified as
 * OKN-DSP.
 */
final class OknRuntimeTransport {
    private long sequence = 1;

    boolean isTxEnabled() {
        return BuildConfig.OKN_RUNTIME_USB_TX_ENABLED;
    }

    void sendGain(UsbDevice device, int channel, float gainDb) {
        requireEnabled(device);
        OknPacket packet = new OknPacket(OknPacket.CMD_SET_GAIN, channel, sequence++, OknPacket.f32(gainDb));
        sendEncodedToVerifiedOknFirmware(device, packet.encode());
    }

    void sendPeq(UsbDevice device, int channel, int band, float frequency, float q, float gainDb) {
        requireEnabled(device);
        OknPacket packet = new OknPacket(
                OknPacket.CMD_SET_PEQ,
                channel,
                sequence++,
                OknPacket.peqPayload(band, true, frequency, q, gainDb));
        sendEncodedToVerifiedOknFirmware(device, packet.encode());
    }

    private void requireEnabled(UsbDevice device) {
        if (device == null) {
            throw new IllegalStateException("USB device not selected");
        }
        if (!BuildConfig.OKN_RUNTIME_USB_TX_ENABLED) {
            throw new SecurityException("OKN runtime USB TX is compile-time locked");
        }
    }

    private void sendEncodedToVerifiedOknFirmware(UsbDevice device, byte[] packet) {
        /*
         * Intentionally no stock transport implementation here.
         * After production bootstrap is solved, add a verified OKN-firmware
         * identity handshake before claiming the dedicated OKN HID interface
         * and sending exactly 256-byte packets.
         */
        throw new UnsupportedOperationException(
                "Verified OKN-DSP USB runtime endpoint mapping not installed yet: " +
                        device.getDeviceName() + " packet=" + packet.length);
    }
}
