package com.okn.dsp;

import android.content.Context;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;

import java.util.Locale;
import java.util.Map;

final class UsbInspector {
    static final int STOCK_VID = 0x6324;
    static final int STOCK_PID = 0x1719;

    static final class Result {
        final UsbDevice device;
        final String text;

        Result(UsbDevice device, String text) {
            this.device = device;
            this.text = text;
        }
    }

    private final UsbManager manager;

    UsbInspector(Context context) {
        manager = (UsbManager) context.getSystemService(Context.USB_SERVICE);
    }

    Result inspect() {
        Map<String, UsbDevice> devices = manager.getDeviceList();
        if (devices.isEmpty()) {
            return new Result(null, "ยังไม่พบอุปกรณ์ USB-C DSP");
        }

        UsbDevice preferred = null;
        for (UsbDevice d : devices.values()) {
            if (d.getVendorId() == STOCK_VID && d.getProductId() == STOCK_PID) {
                preferred = d;
                break;
            }
            if (preferred == null) preferred = d;
        }

        StringBuilder s = new StringBuilder();
        s.append(String.format(Locale.US,
                "USB: %04X:%04X  interfaces=%d\n",
                preferred.getVendorId(), preferred.getProductId(), preferred.getInterfaceCount()));

        if (preferred.getVendorId() == STOCK_VID && preferred.getProductId() == STOCK_PID) {
            s.append("ตรงกับ production identity ที่เคยตรวจพบ (อ่าน descriptor เท่านั้น)\n");
        } else {
            s.append("เป็น USB device อื่น — ไม่ส่งข้อมูลออก\n");
        }

        for (int i = 0; i < preferred.getInterfaceCount(); i++) {
            UsbInterface intf = preferred.getInterface(i);
            s.append(String.format(Locale.US,
                    "IF%d class=%d sub=%d proto=%d ep=%d",
                    intf.getId(), intf.getInterfaceClass(), intf.getInterfaceSubclass(),
                    intf.getInterfaceProtocol(), intf.getEndpointCount()));
            for (int e = 0; e < intf.getEndpointCount(); e++) {
                UsbEndpoint ep = intf.getEndpoint(e);
                s.append(String.format(Locale.US,
                        " [0x%02X type=%d max=%d]",
                        ep.getAddress(), ep.getType(), ep.getMaxPacketSize()));
            }
            s.append('\n');
        }

        s.append("TX=LOCKED / FLASH=LOCKED");
        return new Result(preferred, s.toString());
    }
}
