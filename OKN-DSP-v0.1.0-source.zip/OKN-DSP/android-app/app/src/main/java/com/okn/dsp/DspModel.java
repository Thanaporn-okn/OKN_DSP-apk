package com.okn.dsp;

import java.util.Locale;

final class DspModel {
    static final int CHANNELS = 7;
    static final int BANDS = 15;
    static final float[] FREQUENCIES = {
            31.5f, 50f, 80f, 125f, 200f,
            315f, 500f, 800f, 1250f, 2000f,
            3150f, 5000f, 8000f, 12500f, 16000f
    };

    static final class Channel {
        float gainDb = 0f;
        boolean mute = false;
        final float[] peqGainDb = new float[BANDS];
        final float[] q = new float[BANDS];

        Channel() {
            for (int i = 0; i < BANDS; i++) {
                q[i] = 1.0f;
            }
        }
    }

    final Channel[] channel = new Channel[CHANNELS];

    DspModel() {
        for (int i = 0; i < CHANNELS; i++) {
            channel[i] = new Channel();
        }
    }

    static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    static String db(float value) {
        return String.format(Locale.US, "%+.1f dB", value);
    }

    static String frequencyLabel(float hz) {
        if (hz >= 1000f) {
            return String.format(Locale.US, "%.2g kHz", hz / 1000f);
        }
        return String.format(Locale.US, "%.1f Hz", hz);
    }
}
