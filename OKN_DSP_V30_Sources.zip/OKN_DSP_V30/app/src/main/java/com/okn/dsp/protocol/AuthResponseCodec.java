package com.okn.dsp.protocol;

/** Structural parser only. It intentionally does not guess how to decrypt the 16-byte RandKey field. */
public final class AuthResponseCodec {
    private AuthResponseCodec() {}

    public static Header parse32(byte[] bytes) {
        if (bytes == null || bytes.length != 32) throw new IllegalArgumentException("authentication response must be 32 bytes");
        byte[] f4 = new byte[4];
        byte[] fixed8 = new byte[8];
        byte[] encryptedRandKey = new byte[16];
        System.arraycopy(bytes, 4, f4, 0, 4);
        System.arraycopy(bytes, 8, fixed8, 0, 8);
        System.arraycopy(bytes, 16, encryptedRandKey, 0, 16);
        return new Header(ByteCodec.readU16be(bytes, 0), ByteCodec.readU16be(bytes, 2), f4, fixed8, encryptedRandKey);
    }

    public static final class Header {
        public final int typeId;
        public final int versionId;
        public final byte[] field4to7;
        public final byte[] fixed8;
        public final byte[] encryptedRandKey;
        Header(int typeId, int versionId, byte[] field4to7, byte[] fixed8, byte[] encryptedRandKey) {
            this.typeId = typeId; this.versionId = versionId; this.field4to7 = field4to7; this.fixed8 = fixed8; this.encryptedRandKey = encryptedRandKey;
        }
    }
}
