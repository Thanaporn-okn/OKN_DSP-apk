package com.okn.dsp.protocol;

/** Offline vectors imported from the supplied V35 proof. No BLE traffic is emitted. */
public final class ProtocolSelfTest {
    private ProtocolSelfTest() {}

    public static void runOrThrow() {
        // Verified read request format: 58 + ID(BE32) + offset(BE16) + length(BE16)
        String read19 = ByteCodec.toHex(UfeCodec.encodeRead(19, 0, 1));
        if (!"580000001300000001".equals(read19)) throw new IllegalStateException("read serializer mismatch: " + read19);

        // V35 same-session vector: first post-auth TX 661C0624 encrypts to 5DFCB7E5.
        byte[] rand = ByteCodec.hexToBytes("0168DEEB916838D752E0D696BB3655E6");
        byte[] out = new SessionCrypto(rand, true).update(ByteCodec.hexToBytes("661C0624"));
        String cipher = ByteCodec.toHex(out);
        if (!"5DFCB7E5".equals(cipher)) throw new IllegalStateException("AES/CFB8 vector mismatch: " + cipher);

        if (Phase2ProtocolBridge.eqBand(0, 0, 100f, 1f, 0f).length != 57)
            throw new IllegalStateException("EQ write packet length mismatch");
    }
}
