package com.okn.dsp.protocol;

/**
 * V30 safety gate. Everything after authentication is sufficiently characterized to serialize
 * real writes, but standalone extraction of the current-session RandKey from AUTH32 is not yet
 * independently verified. Do not transmit actuator writes until that final requirement is proved.
 */
public final class WriteGate {
    private WriteGate() {}
    public static final boolean ENABLED = false;
    public static final String BLOCKER = "Standalone current-session RandKey extraction from 32-byte auth response is not independently verified";
}
