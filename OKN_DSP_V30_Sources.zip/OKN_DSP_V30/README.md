# OKN DSP V30 — Phase 2 protocol foundation

Base: **V29 accepted UI**. V30 begins Phase 2 using the user-supplied V35 protocol proof; it does not invent missing BLE/auth details.

## Verified and implemented in source

- AB00 BLE service, AB01 write characteristic, AB02 notify characteristic constants.
- UFE write `0x57`, read `0x58`, read-response `0x60` framing.
- Big-endian UFE header fields and little-endian FLOAT32 payloads.
- Real actuator mapping for Master Volume (2), Bass Volume (8), Bass Cutoff (9), and seven 15-band EQ cascades (4,5,6,14,15,16,17).
- 48-byte EQ-band packet encoder and 44.1 kHz peaking-EQ coefficient generation.
- Post-auth AES/CFB8 continuous-stream implementation with IV `01` x16.
- Offline self-test includes the supplied session vector `661C0624 -> 5DFCB7E5` with RandKey `0168DEEB916838D752E0D696BB3655E6`.
- Exact supplied proof files are retained under `Sources/ProtocolEvidence/` for provenance.

## Safety gate

Live DSP writes remain **disabled** in V30 because the supplied proof explicitly states that standalone derivation/extraction of the *current session* RandKey from the 32-byte authentication response is not yet independently verified. V30 therefore prepares verified packets but does not transmit actuator changes.

The supplied descriptor also does not prove a standalone actuator mapping for the current UI's `Volume Ch1-Ch7`; V30 intentionally leaves that binding unresolved instead of guessing.

versionName: 30.0.0  
versionCode: 1030  
Phase: 2
