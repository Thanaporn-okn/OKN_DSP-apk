OKN_DSP V1.0.4 STYLE FIX

Fix:
AAPT error:
resource style/AppTheme not found

Added:
app/src/main/res/values/styles.xml

Merge this folder into V103 project.