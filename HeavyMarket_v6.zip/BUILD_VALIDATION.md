# BUILD VALIDATION — Heavy Market v6

วันที่ตรวจ: 2026-09-20

## สิ่งที่แก้จากวิดีโอ v5

- Demo data ยัง 26 รายการ/26 built-in categories แต่ v6 เปลี่ยนเป็น 26 local image assets แยกกันจริง ไม่วน fallback 10 รูปแบบ v5
- `imageModel()` map `res://...` ของทั้ง 26 รายการไป resource ที่มีอยู่จริง และ fallback แยกละเอียดตามหมวด
- Groups ยุบ Add Group / Import Post เป็น expandable action ลดพื้นที่ฟอร์มถาวร
- Settings เปลี่ยนรายชื่อหมวดยาวเป็น horizontal chips + category count
- UI display name แปล Backhoe/Wheel Loader และ source filter ให้เป็นมิตรกับภาษาไทยขึ้น
- ปรับขนาด ProductCard / Marketplace image ratio และ compact typography
- Material typography ใช้ system SansSerif โดยไม่ bundle font file เพิ่ม
- Demo seed ยังคง idempotent upsert: ติดตั้ง v6 ทับ v5 แล้ว image key/data ใหม่ถูก refresh โดยไม่ต้อง Clear Data

## Android compatibility set

- `compileSdk = 37`
- `compileSdkMinor = 2`
- `targetSdk = 36`
- AGP `9.4.0` / Gradle `9.6.1` / JDK 17
- dependency set เดียวกับ v4/v5 ที่ build และเปิด APK ได้จริงจาก GitHub Actions/วิดีโอผู้ใช้

## Validation ใน environment นี้

- Kotlin domain smoke: classifier / price parser / search parser ผ่าน
- `DemoData.kt` compile กับ model stub และ smoke test ผ่าน: 26 รายการ / 26 category
- ตรวจ 26 `res://...` current demo keys ว่าไม่ซ้ำและมี PNG จริงครบ 26/26
- ตรวจทุก current demo key ถูก handle ใน `imageModel()` และทุก `R.drawable.demo_*` ที่อ้างมีไฟล์จริง
- ตรวจ Kotlin UI file ไม่มี parser/syntax-error pattern; unresolved Android/Compose refs คาดหมายเพราะ container ไม่มี Android classpath
- ตรวจ Android XML parse
- ตรวจ GitHub Actions YAML parse
- ตรวจ workflow ภายใน ZIP ตรงกับ `android-build.yml` ที่ส่งแยก
- ตรวจ ZIP ด้วย `unzip -t`

## ข้อจำกัด

container นี้ไม่มี Android SDK/Google Maven dependency cache ครบสำหรับ full `assembleDebug` แบบ offline จึงไม่อ้างว่า APK v6 build สำเร็จในเครื่องนี้ Full Android build จริงให้ GitHub Actions รัน `clean testDebugUnitTest assembleDebug --stacktrace`; หากมี build log รอบใหม่ให้แก้ต่อจาก v6 โดยไม่ย้อน UI/feature.
