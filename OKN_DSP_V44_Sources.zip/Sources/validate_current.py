#!/usr/bin/env python3
from pathlib import Path
import runpy
here=Path(__file__).resolve().parent
for name in ('validate_v38_gate.py','validate_v39_reset.py','validate_v44_safe_out_volume.py'):
    print('Running', name)
    runpy.run_path(str(here/name), run_name='__main__')
print('CURRENT PACKAGE PREFLIGHT: PASS')
