# OKN DSP V44

V44 is based on **V43** and keeps the verified BLE/UFE protocol, CH/EQ mapping, guarded Save/Restore, Safe Reset gain-only behavior, and DSP readback synchronization.

## What V44 changes

- **Continuous-play Hi-Fi Guard:** once Android reports active music, passive BLE sensor polling stays suspended for an 8-second hold window after the last positive `isMusicActive()` sample. Short false dropouts therefore cannot leak a single poll into playback.
- **Music-safe Safe Reset EQ:** Reset EQ still uses the exact verified full 48-byte Gain writer and preserves live Frequency/Q/type/metadata. With music active/held, reset rows are paced at **380 ms** minimum instead of the 110 ms no-music baseline.
- **No invented bulk reset:** V44 does not add an unverified reset opcode or DSP address.
- **CH page remains verified:** `CH1 → EQ ID4`, `CH2 → ID5`, `CH3 → ID6`, `CH4 → ID14`, `CH5 → ID15`, `CH6 → ID16`, `CH7 → ID17`. Independent per-channel Gain remains `GAIN LOCKED`.

## Hi-Fi / Hi-Res boundary

This Android app is a **DSP controller, not the music renderer**. It does not decode, buffer, resample, or change PCM bit depth/sample rate. V44 improves Bluetooth control/audio coexistence; it does not claim to convert the stock board into true Hi-Res hardware.

Version: **44.0.0** (`versionCode 1044`).
