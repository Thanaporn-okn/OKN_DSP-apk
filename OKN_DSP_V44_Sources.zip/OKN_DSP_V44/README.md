# OKN DSP V44

V44 is based on V43 and addresses the second real-hardware CH1 output-volume result.

Hardware evidence now established:
- V42: CH1 Band1.G changes CH1 output level and does not change the audible EQ tone.
- V43: even one final full 48-byte Band1 write on finger release still causes a loud transient/stutter of about 1 second.

V44 therefore keeps the proven Band1.G mapping but narrows the write. For CH1/2/4/5/6/7 the release-time command writes only the contiguous Band1 bytes G,R,B0,B1,B2 (offset +20, length 20). R is rewritten unchanged only because it lies between G and B0. F/F2/Q/B and denominator A1/A2 are not written by the channel-volume command. CH3 remains the verified scalar ID8 BassVolume path.

No new actuator ID and no new UFE packet format are introduced. V41 guarded Save/Restore, V39 Safe Reset, V38 safe-PEQ gate and single-GATT-write AES-CFB8 ordering are retained.

Version: **44.0.0** (`versionCode 1044`)

V44 is a real-DSP test candidate. V41 remains the rollback baseline until the narrow Band1 patch is confirmed on hardware.
