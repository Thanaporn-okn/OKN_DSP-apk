# OKN DSP V44

V44 fixes the Bass/Subwoofer control mapping using the project's captured real Device Description.

## What was wrong in V43

The DSP EQ actuator order is `4,5,6,14,15,16,17`. Actuator **ID6** is explicitly named `BiquadCascadeBassChannel`, so the real Bass/Subwoofer EQ is **UI Ch3** (zero-based index 2). V43's friendly position labels incorrectly called Ch6 "Subwoofer". The separate Channel Volume rows were already marked as UI-only because no per-channel volume actuator has been verified.

## V44 changes

- Correct EQ labels: Ch1 Left, Ch2 Right, **Ch3 Bass / Subwoofer**, Ch4 I2S0 Left, Ch5 I2S0 Right, Ch6 I2S1 Left, Ch7 I2S1 Right.
- Add **Bass/Sub DSP Gain** to the Mix page. It writes the native first-band gain of actuator ID6 through the existing verified safe writer.
- Gain range is **-12 to +12 dB**. Start at 0 dB and raise gradually.
- Bass Volume ID8 remains a separate `-70..+6 dB` hardware control.
- V43 hard audio isolation behavior remains unchanged.

Version: **44.0.0** (`versionCode 1044`).

## Headroom

If Bass Volume is near +6 dB and Bass/Sub DSP Gain is positive, lower Master Volume enough to avoid clipping. Do not assume more digital gain improves fidelity once the DSP or amplifier clips.
