# OKN DSP V44

V44 fixes the repeated audible stutter reported while moving **Out Volume Ch1-Ch7** on real hardware.

- **CH3:** remains the hardware-confirmed `BassVolume` actuator **ID8** and uses the scalar control path.
- **CH1, CH2, CH4, CH5, CH6, CH7:** retain the descriptor-grounded first Tone-Control EQ record `G` carrier on actuators 4, 5, 14, 15, 16, 17.
- V43 sent a complete 48-byte Tone-Control record every 1 dB / ~45 ms. Hardware testing showed that those repeated record replacements themselves are audible.
- V44 therefore sends **zero non-CH3 biquad writes while the finger is moving**. The UI still follows the finger and keeps only the newest target.
- On finger release, V44 rebuilds from the latest confirmed DSP row and sends **one** full 48-byte record.
- No new actuator ID and no unverified partial-record write are introduced.
- Output range remains **-70 dB to +6 dB**, 1 dB UI increments, matching the BassVolume descriptor grid.

The goal of this version is specifically to remove the repeated click/stutter train during adjustment. If the hardware still makes one click exactly at release, that is a different result: it means the Tone-Control record itself is not a click-free volume actuator and the next investigation must capture a true per-output volume command rather than increasing write frequency.

See `Sources/V44_RELEASE_ONLY_OUT_VOLUME.txt`.
