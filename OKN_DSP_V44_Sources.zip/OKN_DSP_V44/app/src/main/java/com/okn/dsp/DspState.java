package com.okn.dsp;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public final class DspState {
    public static final int CHANNELS = 7;
    public static final int BANDS = 15;
    public static final float[] DEFAULT_FREQS = {
            20f, 31.5f, 50f, 80f, 125f,
            200f, 315f, 500f, 800f, 1250f,
            2000f, 3150f, 5000f, 10000f, 20000f
    };

    private static final String PREFS_NAME = "okn_dsp_state";
    private static final String LEGACY_V1_PREFS = "okn_dsp_v1_state";
    private static final int STATE_SCHEMA = 3;
    private static final String PRESET_NAMES = "presetNames";
    private static final String PRESET_KEY_PREFIX = "presetData::";

    private final SharedPreferences prefs;

    // V20 persistence baseline: coalesce rapid UI-state writes into one SharedPreferences
    // apply per frame burst instead of enqueueing a disk write for every MotionEvent.
    // The in-memory state still changes immediately; persistence follows within
    // a short 120 ms window and is synchronously flushed when the app stops.
    private static final long PERSIST_COALESCE_MS = 120L;
    private final Handler persistHandler = new Handler(Looper.getMainLooper());
    private SharedPreferences.Editor pendingEditor;
    private boolean fullPersistPending;
    private boolean persistFlushScheduled;
    private final Runnable persistRunnable = () -> {
        persistFlushScheduled = false;
        SharedPreferences.Editor queued = pendingEditor;
        pendingEditor = null;
        if (queued != null) queued.apply();
        if (fullPersistPending) {
            fullPersistPending = false;
            persistAll(false);
        }
    };

    public float masterVolume;
    public float bassVolume;
    public float bassCutoff;
    public final float[] channelVolume = new float[CHANNELS];
    public final float[][] eqFreq = new float[CHANNELS][BANDS];
    public final float[][] eqQ = new float[CHANNELS][BANDS];
    public final float[][] eqGain = new float[CHANNELS][BANDS];

    public int page;
    public int theme;
    public int selectedChannel;
    public int selectedBand;
    public String presetName;

    private static final float[] DEFAULT_CHANNEL_VOL = {0f, 0f, 0f, 0f, 0f, 0f, 0f};
    private static final float[] DEFAULT_EQ_GAIN = {-2f, -1f, 1.5f, 4f, 2f, 0.2f, -1.1f, -2f, -1.5f, 0f, 2.1f, 3f, 2.5f, 1f, -1f};

    public DspState(Context context) {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        migrateV1IfNeeded(context);
        load();
        migrateSinglePresetIfNeeded();
        normalizePresetSelection();
        prefs.edit().putInt("stateSchema", STATE_SCHEMA).apply();
    }

    private void migrateV1IfNeeded(Context context) {
        if (prefs.contains("stateSchema") || !prefs.getAll().isEmpty()) return;
        SharedPreferences old = context.getSharedPreferences(LEGACY_V1_PREFS, Context.MODE_PRIVATE);
        Map<String, ?> source = old.getAll();
        if (source.isEmpty()) return;

        SharedPreferences.Editor e = prefs.edit();
        for (Map.Entry<String, ?> entry : source.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();
            if (value instanceof String) e.putString(key, (String) value);
            else if (value instanceof Integer) e.putInt(key, (Integer) value);
            else if (value instanceof Long) e.putLong(key, (Long) value);
            else if (value instanceof Float) e.putFloat(key, (Float) value);
            else if (value instanceof Boolean) e.putBoolean(key, (Boolean) value);
            else if (value instanceof Set) {
                @SuppressWarnings("unchecked")
                Set<String> set = (Set<String>) value;
                e.putStringSet(key, new HashSet<>(set));
            }
        }
        e.putInt("stateSchema", STATE_SCHEMA);
        e.commit();
    }

    private void load() {
        masterVolume = clamp(prefs.getFloat("masterVolume", -6f), -70f, 6f);
        bassVolume = clamp(prefs.getFloat("bassVolume", 2f), -70f, 6f);
        bassCutoff = clamp(prefs.getFloat("bassCutoff", 80f), 20f, 250f);
        page = clampInt(prefs.getInt("page", 0), 0, 2);
        theme = clampInt(prefs.getInt("theme", 0), 0, 2);
        selectedChannel = clampInt(prefs.getInt("selectedChannel", 0), 0, CHANNELS - 1);
        selectedBand = clampInt(prefs.getInt("selectedBand", 3), 0, BANDS - 1);
        presetName = prefs.getString("presetName", "");

        for (int ch = 0; ch < CHANNELS; ch++) {
            float cvMin = ch == 2 ? -70f : -12f;
            float cvMax = ch == 2 ? 6f : 12f;
            channelVolume[ch] = clamp(prefs.getFloat("channelVolume_" + ch, DEFAULT_CHANNEL_VOL[ch]), cvMin, cvMax);
            for (int b = 0; b < BANDS; b++) {
                eqFreq[ch][b] = clamp(prefs.getFloat(key("freq", ch, b), DEFAULT_FREQS[b]), 20f, 20000f);
                eqQ[ch][b] = clamp(prefs.getFloat(key("q", ch, b), 1f), 0.1f, 10f);
                float defaultGain = ch == 0 ? DEFAULT_EQ_GAIN[b] : 0f;
                eqGain[ch][b] = clamp(prefs.getFloat(key("gain", ch, b), defaultGain), -12f, 12f);
            }
        }
        // V44: CH3 output volume is the verified BassVolume/ID8 scalar. Keep the
        // duplicate Mix-page control as a mirror, never as a second local truth.
        channelVolume[2] = bassVolume;
    }

    private void migrateSinglePresetIfNeeded() {
        Set<String> names = getPresetNameSet();
        if (!names.isEmpty()) return;

        String legacyData = prefs.getString("lastPresetData", null);
        if (legacyData == null || legacyData.isEmpty()) return;

        String legacyName = cleanPresetName(prefs.getString("lastPresetName", prefs.getString("presetName", "Preset")));
        names.add(legacyName);
        presetName = legacyName;
        prefs.edit()
                .putStringSet(PRESET_NAMES, names)
                .putString(presetKey(legacyName), legacyData)
                .putString("presetName", legacyName)
                .putInt("stateSchema", STATE_SCHEMA)
                .commit();
    }

    private void normalizePresetSelection() {
        String[] names = getPresetNames();
        if (names.length == 0) {
            presetName = "";
            prefs.edit().putString("presetName", "").apply();
            return;
        }
        for (String name : names) {
            if (name.equals(presetName)) return;
        }
        presetName = names[0];
        prefs.edit().putString("presetName", presetName).apply();
    }

    public void setPage(int value) {
        page = clampInt(value, 0, 2);
        queueInt("page", page);
    }

    public void setTheme(int value) {
        theme = clampInt(value, 0, 2);
        queueInt("theme", theme);
    }

    public void setSelectedChannel(int value) {
        selectedChannel = clampInt(value, 0, CHANNELS - 1);
        queueInt("selectedChannel", selectedChannel);
    }

    public void setSelectedBand(int value) {
        selectedBand = clampInt(value, 0, BANDS - 1);
        queueInt("selectedBand", selectedBand);
    }

    public void setMasterVolume(float value) {
        masterVolume = clamp(value, -70f, 6f);
        queueFloat("masterVolume", masterVolume);
    }

    public void setBassVolume(float value) {
        bassVolume = clamp(value, -70f, 6f);
        channelVolume[2] = bassVolume;
        queueFloat("bassVolume", bassVolume);
        queueFloat("channelVolume_2", channelVolume[2]);
    }

    public void setBassCutoff(float value) {
        bassCutoff = clamp(value, 20f, 250f);
        queueFloat("bassCutoff", bassCutoff);
    }

    public void setChannelVolume(int ch, float value) {
        if (ch < 0 || ch >= CHANNELS) return;
        channelVolume[ch] = ch == 2 ? clamp(value, -70f, 6f) : clamp(value, -12f, 12f);
        queueFloat("channelVolume_" + ch, channelVolume[ch]);
        if (ch == 2) {
            bassVolume = channelVolume[2];
            queueFloat("bassVolume", bassVolume);
        }
    }

    public void resetGlobal() {
        // Flush older coalesced slider writes first so they cannot overwrite the reset.
        flushPending(false);
        masterVolume = -6f;
        bassVolume = 2f;
        channelVolume[2] = bassVolume;
        bassCutoff = 80f;
        prefs.edit()
                .putFloat("masterVolume", masterVolume)
                .putFloat("bassVolume", bassVolume)
                .putFloat("channelVolume_2", channelVolume[2])
                .putFloat("bassCutoff", bassCutoff)
                .apply();
    }

    public void resetChannels() {
        // Publish all seven channel defaults together after any older queued writes.
        flushPending(false);
        SharedPreferences.Editor e = prefs.edit();
        for (int ch = 0; ch < CHANNELS; ch++) {
            channelVolume[ch] = 0f;
            e.putFloat("channelVolume_" + ch, channelVolume[ch]);
        }
        bassVolume = 0f;
        e.putFloat("bassVolume", bassVolume);
        e.apply();
    }

    public void setEqFreq(int ch, int band, float value) {
        if (!validBand(ch, band)) return;
        eqFreq[ch][band] = clamp(value, 20f, 20000f);
        queueFloat(key("freq", ch, band), eqFreq[ch][band]);
    }

    public void setEqQ(int ch, int band, float value) {
        if (!validBand(ch, band)) return;
        eqQ[ch][band] = clamp(value, 0.1f, 10f);
        queueFloat(key("q", ch, band), eqQ[ch][band]);
    }

    public void setEqGain(int ch, int band, float value) {
        if (!validBand(ch, band)) return;
        eqGain[ch][band] = clamp(value, -12f, 12f);
        queueFloat(key("gain", ch, band), eqGain[ch][band]);
    }

    public void resetEqChannel(int ch) {
        if (ch < 0 || ch >= CHANNELS) return;
        SharedPreferences.Editor e = prefs.edit();
        for (int b = 0; b < BANDS; b++) {
            eqFreq[ch][b] = DEFAULT_FREQS[b];
            eqQ[ch][b] = 1f;
            eqGain[ch][b] = 0f;
            e.putFloat(key("freq", ch, b), eqFreq[ch][b]);
            e.putFloat(key("q", ch, b), eqQ[ch][b]);
            e.putFloat(key("gain", ch, b), eqGain[ch][b]);
        }
        e.apply();
    }

    /** V37 safe local reset: flatten Gain only; preserve Frequency/Q readback state. */
    public void resetEqGainOnly(int ch) {
        if (ch < 0 || ch >= CHANNELS) return;
        SharedPreferences.Editor e = prefs.edit();
        for (int b = 0; b < BANDS; b++) {
            eqGain[ch][b] = 0f;
            e.putFloat(key("gain", ch, b), eqGain[ch][b]);
        }
        e.apply();
    }

    /** V39: mirror only hardware rows that the fresh descriptor marked Gain-writable. */
    public int resetEqGainWritableOnly(int ch, boolean[] writable) {
        if (ch < 0 || ch >= CHANNELS || writable == null || writable.length < BANDS) return 0;
        SharedPreferences.Editor e = prefs.edit();
        int changed = 0;
        for (int b = 0; b < BANDS; b++) {
            if (!writable[b]) continue;
            if (Math.abs(eqGain[ch][b]) > 0.0001f) changed++;
            eqGain[ch][b] = 0f;
            e.putFloat(key("gain", ch, b), 0f);
        }
        e.apply();
        return changed;
    }

    public void savePreset(String name) {
        String clean = cleanPresetName(name);
        Set<String> names = getPresetNameSet();
        String existing = findCaseInsensitive(names, clean);
        if (existing != null) clean = existing;
        names.add(clean);
        presetName = clean;

        String data = serializeCurrentPreset();
        prefs.edit()
                .putStringSet(PRESET_NAMES, names)
                .putString(presetKey(clean), data)
                .putString("presetName", clean)
                // Keep the old single-preset fields for downgrade/diagnostics compatibility.
                .putString("lastPresetData", data)
                .putString("lastPresetName", clean)
                .putInt("stateSchema", STATE_SCHEMA)
                .apply();
    }

    public boolean selectPreset(String name) {
        if (name == null) return false;
        Set<String> names = getPresetNameSet();
        String existing = findCaseInsensitive(names, name.trim());
        if (existing == null) return false;
        presetName = existing;
        prefs.edit().putString("presetName", existing).apply();
        return true;
    }

    public boolean loadSelectedPreset() {
        if (presetName == null || presetName.isEmpty()) return false;
        return loadPreset(presetName);
    }

    public boolean loadPreset(String name) {
        if (name == null) return false;
        Set<String> names = getPresetNameSet();
        String existing = findCaseInsensitive(names, name.trim());
        if (existing == null) return false;
        String data = prefs.getString(presetKey(existing), null);
        if (data == null || data.isEmpty()) return false;
        if (!applyPresetData(data)) return false;
        presetName = existing;
        // V23: do not schedule a full 300+ key SharedPreferences rebuild after
        // an interactive preset tap. The chosen preset name is saved cheaply now;
        // the full in-memory state is synchronously checkpointed in Activity.onStop.
        // This removes the delayed hitch that used to appear ~120 ms after selection.
        prefs.edit().putString("presetName", existing).apply();
        return true;
    }

    public boolean deletePreset(String name) {
        if (name == null) return false;
        Set<String> names = getPresetNameSet();
        String existing = findCaseInsensitive(names, name.trim());
        if (existing == null) return false;
        names.remove(existing);

        SharedPreferences.Editor e = prefs.edit()
                .remove(presetKey(existing))
                .putStringSet(PRESET_NAMES, names);

        if (existing.equals(presetName)) {
            List<String> left = new ArrayList<>(names);
            Collections.sort(left, String.CASE_INSENSITIVE_ORDER);
            presetName = left.isEmpty() ? "" : left.get(0);
            e.putString("presetName", presetName);
        }
        if (existing.equals(prefs.getString("lastPresetName", ""))) {
            e.remove("lastPresetData").remove("lastPresetName");
        }
        e.apply();
        return true;
    }

    public String[] getPresetNames() {
        List<String> names = new ArrayList<>(getPresetNameSet());
        Collections.sort(names, String.CASE_INSENSITIVE_ORDER);
        return names.toArray(new String[0]);
    }

    public boolean hasPresets() {
        return !getPresetNameSet().isEmpty();
    }

    private Set<String> getPresetNameSet() {
        Set<String> stored = prefs.getStringSet(PRESET_NAMES, null);
        return stored == null ? new HashSet<>() : new HashSet<>(stored);
    }

    private String serializeCurrentPreset() {
        StringBuilder sb = new StringBuilder(8192);
        sb.append(masterVolume).append('|')
                .append(bassVolume).append('|')
                .append(bassCutoff).append('|');
        for (float v : channelVolume) sb.append(v).append(',');
        sb.append('|');
        for (int ch = 0; ch < CHANNELS; ch++) {
            for (int b = 0; b < BANDS; b++) {
                sb.append(eqFreq[ch][b]).append(',')
                        .append(eqQ[ch][b]).append(',')
                        .append(eqGain[ch][b]).append(';');
            }
            sb.append('|');
        }
        return sb.toString();
    }

    private boolean applyPresetData(String data) {
        try {
            String[] parts = data.split("\\|", -1);
            if (parts.length < 4 + CHANNELS) return false;
            masterVolume = clamp(Float.parseFloat(parts[0]), -70f, 6f);
            bassVolume = clamp(Float.parseFloat(parts[1]), -70f, 6f);
            bassCutoff = clamp(Float.parseFloat(parts[2]), 20f, 250f);
            String[] cv = parts[3].split(",");
            for (int i = 0; i < CHANNELS && i < cv.length; i++) {
                if (!cv[i].isEmpty()) channelVolume[i] = i == 2
                        ? clamp(Float.parseFloat(cv[i]), -70f, 6f)
                        : clamp(Float.parseFloat(cv[i]), -12f, 12f);
            }
            // V44 migration rule: historical local CH3 slider data was never a verified
            // hardware mapping. BassVolume/ID8 is authoritative for CH3 output.
            channelVolume[2] = bassVolume;
            for (int ch = 0; ch < CHANNELS; ch++) {
                String[] triples = parts[4 + ch].split(";");
                for (int b = 0; b < BANDS && b < triples.length; b++) {
                    if (triples[b].isEmpty()) continue;
                    String[] t = triples[b].split(",");
                    if (t.length >= 3) {
                        eqFreq[ch][b] = clamp(Float.parseFloat(t[0]), 20f, 20000f);
                        eqQ[ch][b] = clamp(Float.parseFloat(t[1]), 0.1f, 10f);
                        eqGain[ch][b] = clamp(Float.parseFloat(t[2]), -12f, 12f);
                    }
                }
            }
            return true;
        } catch (Exception ignored) {
            return false;
        }
    }

    private SharedPreferences.Editor pendingEditor() {
        if (pendingEditor == null) pendingEditor = prefs.edit();
        return pendingEditor;
    }

    private void queueFloat(String key, float value) {
        pendingEditor().putFloat(key, value);
        schedulePendingFlush();
    }

    private void queueInt(String key, int value) {
        pendingEditor().putInt(key, value);
        schedulePendingFlush();
    }

    private void schedulePendingFlush() {
        // Throttle, do not debounce: while a slider is continuously moving we
        // still persist the newest value roughly every 120 ms.
        if (!persistFlushScheduled) {
            persistFlushScheduled = true;
            persistHandler.postDelayed(persistRunnable, PERSIST_COALESCE_MS);
        }
    }

    private void scheduleFullPersist() {
        fullPersistPending = true;
        schedulePendingFlush();
    }

    public void flushPending(boolean synchronous) {
        persistHandler.removeCallbacks(persistRunnable);
        persistFlushScheduled = false;
        if (fullPersistPending) {
            fullPersistPending = false;
            pendingEditor = null;
            persistAll(synchronous);
            return;
        }
        SharedPreferences.Editor queued = pendingEditor;
        pendingEditor = null;
        if (queued != null) {
            if (synchronous) queued.commit(); else queued.apply();
        }
    }

    public void persistAll(boolean synchronous) {
        persistHandler.removeCallbacks(persistRunnable);
        persistFlushScheduled = false;
        pendingEditor = null;
        fullPersistPending = false;
        SharedPreferences.Editor e = prefs.edit();
        e.putInt("stateSchema", STATE_SCHEMA)
                .putFloat("masterVolume", masterVolume)
                .putFloat("bassVolume", bassVolume)
                .putFloat("bassCutoff", bassCutoff)
                .putInt("page", page)
                .putInt("theme", theme)
                .putInt("selectedChannel", selectedChannel)
                .putInt("selectedBand", selectedBand)
                .putString("presetName", presetName == null ? "" : presetName);
        for (int ch = 0; ch < CHANNELS; ch++) {
            e.putFloat("channelVolume_" + ch, channelVolume[ch]);
            for (int b = 0; b < BANDS; b++) {
                e.putFloat(key("freq", ch, b), eqFreq[ch][b]);
                e.putFloat(key("q", ch, b), eqQ[ch][b]);
                e.putFloat(key("gain", ch, b), eqGain[ch][b]);
            }
        }
        if (synchronous) e.commit(); else e.apply();
    }

    public String getDisplayPresetName() {
        if (!hasPresets()) return "No presets";
        if (presetName == null || presetName.trim().isEmpty()) {
            String[] names = getPresetNames();
            return names.length == 0 ? "No presets" : names[0];
        }
        return presetName;
    }

    public static String formatHz(float hz) {
        if (hz >= 1000f) {
            float k = hz / 1000f;
            if (k >= 10f || Math.abs(k - Math.round(k)) < 0.05f) {
                return String.format(Locale.US, "%.0f kHz", k);
            }
            return String.format(Locale.US, "%.1f kHz", k);
        }
        if (hz >= 100f) return String.format(Locale.US, "%.0f Hz", hz);
        return String.format(Locale.US, "%.1f Hz", hz).replace(".0", "");
    }

    private static String cleanPresetName(String name) {
        String clean = name == null ? "" : name.trim().replace('\n', ' ').replace('\r', ' ');
        while (clean.contains("  ")) clean = clean.replace("  ", " ");
        if (clean.isEmpty() || clean.equalsIgnoreCase("No presets")) clean = "Preset";
        if (clean.length() > 48) clean = clean.substring(0, 48).trim();
        return clean;
    }

    private static String findCaseInsensitive(Set<String> names, String target) {
        if (target == null) return null;
        for (String name : names) {
            if (name.equalsIgnoreCase(target)) return name;
        }
        return null;
    }

    private static String presetKey(String name) {
        return PRESET_KEY_PREFIX + name;
    }

    private static String key(String prefix, int ch, int band) {
        return prefix + '_' + ch + '_' + band;
    }

    private static boolean validBand(int ch, int band) {
        return ch >= 0 && ch < CHANNELS && band >= 0 && band < BANDS;
    }

    private static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    private static int clampInt(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }
}
