#!/usr/bin/env python3
from pathlib import Path
import json, math, re, struct
ROOT=Path(__file__).resolve().parents[1]
BLE=(ROOT/'app/src/main/java/com/okn/dsp/BleManager.java').read_text()
PROTO=(ROOT/'app/src/main/java/com/okn/dsp/DspProtocol.java').read_text()
VIEW=(ROOT/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
STATE=(ROOT/'app/src/main/java/com/okn/dsp/DspState.java').read_text()
GRADLE=(ROOT/'app/build.gradle').read_text()
DESC=json.loads((ROOT/'Sources/ProtocolEvidence/GoloPine_DeviceDescription_REAL_20260906_204555.json').read_text())
def req(x,m):
    if not x: raise AssertionError(m)
def act(i): return next(a for a in DESC['actuators'] if int(a['ID'])==i)
def b1(i): return act(i)['UFE_TYPE_BIQUAD_CASCADE15_F'][0]
req('versionCode 1044' in GRADLE and "versionName '44.0.0'" in GRADLE,'version')
req((ROOT/'Sources/VERSION.txt').read_text().splitlines()[:3]==['OKN DSP V44','versionName=44.0.0','versionCode=1044'],'VERSION.txt')
ids=[4,5,6,14,15,16,17]
pattern=[int(b1(i)['typ']) for i in ids]
req(pattern==[17,17,3,17,17,17,17],f'band1 pattern {pattern}')
req(act(8)['name']=='BassVolume','ID8')
# V44 exact delta: one UFE partial patch of known Band1 fields.
for token in ['static byte[] encodeBand1CellGainPatch','ByteBuffer.allocate(20).order(ByteOrder.LITTLE_ENDIAN)',
              'data.putFloat(target.gain);','data.putFloat(target.r);','data.putFloat(target.b0);',
              'data.putFloat(target.b1);','data.putFloat(target.b2);',
              'eqBandOffset(1) + 20','DspProtocol.encodeBand1CellGainPatch(ch, target)']:
    req(token in PROTO or token in BLE,'missing '+token)
req('DspProtocol.encodeEqWrite(ch, 1, target)' not in re.search(r'static PendingCommand channelTrim.*?\n        \}',BLE,re.S).group(0),'trim still full record')
# Cell-gain target must preserve exact current denominator and scale only numerator.
for token in ['double ratio = Math.pow(10.0, (rounded - current.gain) / 20.0);',
              '(float)(current.b0 * ratio)','(float)(current.b1 * ratio)','(float)(current.b2 * ratio)',
              'current.a1, current.a2']:
    req(token in PROTO,'ratio/exact-preserve missing '+token)
# Release-only behavior retained; CH3 remains scalar ID8.
req('if (channel0 == 2)' in BLE and 'DspProtocol.ID_BASS_VOLUME' in BLE,'CH3 path')
req('if (s.index == 2) sendVerifiedChannelTrim(s.index);' in VIEW,'CH3 UI live path')
req('activeSlider.type == SL_CHANNEL && activeSlider.index != 2' in VIEW,'release commit')
req('pendingSlider.type == SL_CHANNEL && pendingSlider.index != 2' in VIEW,'tap commit')
# Transport / save / reset invariants.
req('private static final long CHANNEL_TRIM_MIN_GAP_MS = 380L;' in BLE,'trim gap')
req('liveWriteBusy = true;' in BLE and 'encrypted = txCipher.next(next.plain);' in BLE,'single stream')
req('sessionFault("DSP command callback timeout")' in BLE and 'sessionFault("GATT write failed " + status)' in BLE,'fail closed')
req('private static final long EQ_SHAPE_MIN_GAP_MS = 110L;' in BLE,'FQ spacing')
req('private static final long EQ_RESET_MIN_GAP_MS = 110L;' in BLE,'reset spacing')
req('encodeSaveParamsTrigger()' in PROTO and 'return encodeWrite(ID_SAVE_PARAMS, 0, new byte[0]);' in PROTO,'SaveParams changed')
req('SAVE UNCONFIRMED' in BLE and 'SAVE_POSTCHECK' in BLE and 'SAVE_PRECHECK' in BLE,'save guard')
req('channelTrimPending.isEmpty()' in BLE,'save queue idle')
# Descriptor contains only the three known scalar Volume actuators; V44 invents none.
vol=sorted(int(a['ID']) for a in DESC['actuators'] if int(a.get('type',-1))==2000 and 'Volume' in a.get('name',''))
req(vol==[2,3,8],f'volume scalar IDs {vol}')
# Math proof from captured CH1 Band1: changing G by -6 dB is uniform numerator scaling.
r=b1(4); oldg=float(r['G']); newg=-6.0; ratio=10**((newg-oldg)/20)
newnum=[float(r[k])*ratio for k in ('B0','B1','B2')]
req(all(math.isfinite(v) for v in newnum),'finite numerator')
req(float(r['A1'])==-1.511861 and float(r['A2'])==0.520317,'captured denominator changed')
print('V44_CHANNEL_TRIM_PASS','band1Pattern='+','.join(map(str,pattern)),'patchOffset=20','patchLen=20','G(-6)ratio=%.12f'%ratio,'A1A2=untouched','CH3=ID8')
