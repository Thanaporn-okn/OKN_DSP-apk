#!/usr/bin/env python3
from pathlib import Path
import hashlib, json, re

ROOT = Path(__file__).resolve().parents[1]
BLE = ROOT / 'app/src/main/java/com/okn/dsp/BleManager.java'
DSP = ROOT / 'app/src/main/java/com/okn/dsp/DspProtocol.java'
VIEW = ROOT / 'app/src/main/java/com/okn/dsp/DspView.java'
STATE = ROOT / 'app/src/main/java/com/okn/dsp/DspState.java'
GRADLE = ROOT / 'app/build.gradle'
DESC = ROOT / 'Sources/ProtocolEvidence/GoloPine_DeviceDescription_REAL_20260906_204555.json'
ble, dsp, view, state, gradle = [p.read_text() for p in (BLE, DSP, VIEW, STATE, GRADLE)]

def method(text, marker):
    i = text.index(marker); b = text.index('{', i); depth = 0
    for j in range(b, len(text)):
        if text[j] == '{': depth += 1
        elif text[j] == '}':
            depth -= 1
            if depth == 0: return text[i:j+1]
    raise AssertionError('unclosed method ' + marker)

def sha(s): return hashlib.sha256(s.encode()).hexdigest()
def req(cond, msg):
    if not cond: raise AssertionError(msg)

req("versionCode 1043" in gradle and "versionName '43.0.0'" in gradle, 'V43 version mismatch')
req('BACKGROUND_POLL_CADENCE_MS = 1900L' in ble, 'V42 idle-poll protection missing')
req('EQ_GAIN_UI_SEND_GAP_MS = 140L' in view and 'EQ_SHAPE_UI_SEND_GAP_MS = 180L' in view, 'V42 EQ pacing missing')
req('static final double SAMPLE_RATE = 44100.0;' in dsp, 'DSP sample-rate model changed')

# Bass Volume: direct UI dB range and ID8-only extension.
req('"Bass Volume", "BASS", pink, state.bassVolume' in view, 'direct Bass Volume row missing')
req('0f, 100f, SL_BASS' in view, 'Bass Volume UI is not 0..100 dB')
req('bassLevelFromDb' not in view and 'bassDbFromLevel' not in view, 'old 0-100 remapping still present')
req('float nextDb = roundTo(v, 1f);' in view, 'Bass Volume is not written as direct dB')
req('bassVolume = clamp(value, -70f, 100f);' in state, 'Bass Volume state cap is not +100 dB')
req('bassVolume = 0f;' in state, 'Reset Global Bass Volume does not start at 0 dB')
sanitize = method(dsp, '    static float sanitizeScalar(')
req(re.search(r'case ID_BASS_VOLUME:.*?lo = -70f; hi = 100f;', sanitize, re.S) is not None, 'ID8 transmit range is not -70..+100 dB')
req(re.search(r'case ID_MASTER_VOLUME:\s*case ID_REMIND_SOUND:\s*lo = -70f; hi = 6f;', sanitize, re.S) is not None, 'Master/reminder range changed unexpectedly')

# Bass Boost: protocol descriptor may still know ID10, but UI/state/outbound global controls must not.
req('SL_BASS_BOOST' not in view, 'Bass Boost slider type still exists')
req('ID_BASS_BOOST' not in view, 'DspView still reads/writes Bass Boost')
req('bassBoost' not in state and 'BassBoost' not in state, 'Bass Boost still stored in DspState')
req('static final int ID_BASS_BOOST = 10;' in dsp, 'verified ID10 descriptor constant removed')
req('case ID_BASS_BOOST:' in sanitize, 'ID10 descriptor validation support removed')

# EQ CH order is explicit and follows the descriptor actuator map.
req('EQ_CHANNEL_DISPLAY_ORDER = {0, 1, 2, 3, 4, 5, 6};' in view, 'explicit CH1..CH7 display order missing')
req('static final int[] EQ_ACTUATORS = {4, 5, 6, 14, 15, 16, 17};' in dsp, 'EQ actuator map changed')
for token in ('"Left Channel"', '"Right Channel"', '"Bass Channel"', '"4th Channel • i2sout0L"', '"7th Channel • i2sout1R"'):
    req(token in view, 'descriptor-derived channel label missing: ' + token)
req('Front Left' not in view and 'Rear Left' not in view and 'Subwoofer' not in view and 'Aux"' not in method(view, '    private String channelPositionName('), 'guessed EQ physical labels remain')

raw = json.loads(DESC.read_text())
eq = [a for a in raw['actuators'] if a['ID'] in (4,5,6,14,15,16,17)]
req([a['ID'] for a in eq] == [4,5,6,14,15,16,17], 'descriptor EQ channel order mismatch')
req(eq[0]['name'] == 'BiquadCascadeLeftChannel' and eq[1]['name'] == 'BiquadCascadeRightChannel' and eq[2]['name'] == 'BiquadCascadeBassChannel', 'descriptor CH1/2/3 names mismatch')

# Frozen writer/filter methods remain unchanged from V42/V41 safety baseline.
expected = {
'BleManager.setEqRealtime':'f4f738c886298e476dad58135a5d29b36937aaa7dbf7eabe7853dc8d9e761c9a',
'BleManager.setEqShapeRealtime':'e702693eccb788da71d156db94dc21824f1dacab20d19e1d89aaedceb94a6110',
'BleManager.scheduleEqRealtimePump':'a05ea21d9f11980fff095c6053ec81ccd5c7ba5d7a725ff2854f3f2a87bf6db6',
'BleManager.scheduleEqShapePump':'97a5c9080071ec5bce70999d2c7a122ad2e2a77d494a94f1040fd90662c4e26e',
'BleManager.sendScheduledControl':'8c39c0643084615777997900f428e3c32971bdd5e2afa0d768c04c4dbfedf777',
'BleManager.writeNoResponse':'e6895bee7c3f2d12c2531d7d48346559d6b00a4c227b38ecfc63f2ce2a9d9256',
'BleManager.resetEqSafe':'eab920cc4b25b018c9e263f1a43bf4391569119663db101954a2661803864d18',
'DspProtocol.peakingFromCurrent':'18f6cb0577c711ea817c8441f4b3b2fc91a4a5d5bae0d61051926074858b95ae',
'DspProtocol.peakingShapeFromCurrent':'e3f8d840e116bc3d32bad459db3883867f8afc62a87c8553131397ee133e4e86',
'DspProtocol.firstBandGainFromCurrent':'89f089d8d8bc6bfd54074e35e949fa393719d64d3884fc8ce133b99bc100ddee',
'DspProtocol.encodeEqWrite':'9de90148f2e6f390f9144ffc8f6c029a00ca6276bdeb8696aa319609573001e5',
}
checks = [
('BleManager.setEqRealtime', ble, '    void setEqRealtime('),
('BleManager.setEqShapeRealtime', ble, '    void setEqShapeRealtime('),
('BleManager.scheduleEqRealtimePump', ble, '    private void scheduleEqRealtimePump('),
('BleManager.scheduleEqShapePump', ble, '    private void scheduleEqShapePump('),
('BleManager.sendScheduledControl', ble, '    private void sendScheduledControl('),
('BleManager.writeNoResponse', ble, '    private boolean writeNoResponse('),
('BleManager.resetEqSafe', ble, '    int resetEqSafe('),
('DspProtocol.peakingFromCurrent', dsp, '    static EqBand peakingFromCurrent('),
('DspProtocol.peakingShapeFromCurrent', dsp, '    static EqBand peakingShapeFromCurrent('),
('DspProtocol.firstBandGainFromCurrent', dsp, '    static EqBand firstBandGainFromCurrent('),
('DspProtocol.encodeEqWrite', dsp, '    static byte[] encodeEqWrite('),
]
for name, text, marker in checks:
    body = method(text, marker)
    if name in ('BleManager.setEqRealtime','BleManager.setEqShapeRealtime','BleManager.resetEqSafe'):
        body = body.replace(' || saveActive', '')
    req(sha(body) == expected[name], name + ' changed unexpectedly')

print('V43 controls/EQ-channel validation: PASS')
print('versionName=43.0.0 versionCode=1043')
print('EQ channel actuator order=4,5,6,14,15,16,17')
print('Bass Volume UI=0..+100 dB direct; ID10 BassBoost UI/write=removed')
print('Frozen EQ writer/filter hashes: PASS')
