from pathlib import Path
import sys
root = Path(__file__).resolve().parents[1]
view = (root / 'app/src/main/java/com/okn/dsp/DspView.java').read_text()
proto = (root / 'app/src/main/java/com/okn/dsp/DspProtocol.java').read_text()
desc = (root / 'Sources/ProtocolEvidence/GoloPine_DeviceDescription_REAL_20260906_204555.json').read_text()
checks = {
    'verified_eq_order': 'static final int[] EQ_ACTUATORS = {4, 5, 6, 14, 15, 16, 17};' in proto,
    'descriptor_id6_bass': '"ID": 6' in desc and '"name": "BiquadCascadeBassChannel"' in desc,
    'v44_ch3_label': '"Bass / Subwoofer"' in view and '"I2S0 Left"' in view and '"I2S1 Right"' in view,
    'v44_direct_slider': 'SL_BASS_CHANNEL_GAIN = 8' in view and '"Bass/Sub DSP Gain"' in view,
    'v44_direct_state': 'state.eqGain[2][0]' in view and 'state.setEqGain(2, 0, next)' in view,
    'v44_direct_writer': 'sendVerifiedEqGain(2, 0);' in view,
    'safe_first_band_writer': 'firstBandGainFromCurrent(current, gainDb)' in (root / 'app/src/main/java/com/okn/dsp/BleManager.java').read_text(),
    'gain_range': '-12f, 12f, SL_BASS_CHANNEL_GAIN' in view,
    'legacy_fake_sub_label_removed': '"Center", "Subwoofer", "Aux"' not in view,
    'channel_volume_warning_retained': 'hardware mapping not verified' in view,
}
failed = [k for k,v in checks.items() if not v]
for k,v in checks.items(): print(('PASS' if v else 'FAIL'), k)
if failed:
    print('V44 validation failed:', ', '.join(failed), file=sys.stderr)
    sys.exit(1)
print('V44 bass mapping validation PASS')
