plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
kotlin {
    jvmToolchain(17)
}

android {
    namespace = "com.okn.dsp"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.okn.dsp"
        minSdk = 26
        targetSdk = 35
        versionCode = 90
        versionName = "5.21.0-v90-reference-ui-rebuild"
    }
    signingConfigs {
        create("stableDebug") {
            storeFile = file("okn_dsp_stable_debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("stableDebug")
        }
    }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
}
