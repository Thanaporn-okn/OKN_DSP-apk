package com.okn.dsp

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import com.okn.dsp.protocol.EqBand48
import kotlin.math.ln

/** V90 visual-only EQ curve used by the supplied OKN_DSP reference UI. */
class EqCurveView(context: Context) : View(context) {
    private var bands: List<EqBand48?> = emptyList()
    private var accent: Int = Color.CYAN
    private var editor = false
    private val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#123044"); strokeWidth = 1f }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.5f }
    private val point = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#7192A8"); textSize = 20f }

    fun setCurve(values: List<EqBand48?>, accentColor: Int, editorMode: Boolean) {
        bands = values
        accent = accentColor
        editor = editorMode
        line.color = accent
        point.color = accent
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat().coerceAtLeast(1f)
        val h = height.toFloat().coerceAtLeast(1f)
        canvas.drawColor(Color.parseColor("#03101A"))
        val left = if (editor) 42f else 8f
        val right = w - 8f
        val top = 8f
        val bottom = h - if (editor) 28f else 8f
        for (i in 0..6) {
            val y = top + (bottom - top) * i / 6f
            canvas.drawLine(left, y, right, y, grid)
        }
        for (i in 0..8) {
            val x = left + (right - left) * i / 8f
            canvas.drawLine(x, top, x, bottom, grid)
        }
        if (editor) {
            canvas.drawText("+12", 2f, top + 12f, text)
            canvas.drawText("0", 18f, (top + bottom) / 2f + 6f, text)
            canvas.drawText("-12", 2f, bottom, text)
            canvas.drawText("20", left, h - 5f, text)
            canvas.drawText("1k", left + (right-left)*0.56f, h - 5f, text)
            canvas.drawText("20k", right - 42f, h - 5f, text)
        }
        val actual = bands.filterNotNull().filter { it.frequency > 0f && it.frequency.isFinite() && it.boostDb.isFinite() }.sortedBy { it.frequency }
        if (actual.isEmpty()) return
        fun xFor(f: Float): Float {
            val lo = ln(20.0)
            val hi = ln(20000.0)
            val t = ((ln(f.toDouble().coerceIn(20.0, 20000.0)) - lo) / (hi - lo)).toFloat()
            return left + (right - left) * t
        }
        fun yFor(db: Float): Float {
            val t = ((12f - db.coerceIn(-12f, 12f)) / 24f)
            return top + (bottom - top) * t
        }
        val path = Path()
        actual.forEachIndexed { index, b ->
            val x = xFor(b.frequency)
            val y = yFor(b.boostDb)
            if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        canvas.drawPath(path, line)
        if (editor) actual.forEach { b -> canvas.drawCircle(xFor(b.frequency), yFor(b.boostDb), 5.5f, point) }
    }
}
