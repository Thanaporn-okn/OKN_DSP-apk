package com.okn.dsp

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/** V90 reference UI launcher over the frozen V88 qualified control core. */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startActivity(Intent(this, UnifiedControlActivity::class.java))
        finish()
    }
}
