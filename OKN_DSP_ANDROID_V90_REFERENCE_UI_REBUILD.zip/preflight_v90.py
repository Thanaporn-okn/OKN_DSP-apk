#!/usr/bin/env python3
from pathlib import Path
import hashlib, re

root = Path(__file__).resolve().parent

def req(rel):
    p = root / rel
    assert p.is_file(), f"missing {rel}"
    return p

def txt(rel):
    return req(rel).read_text(encoding='utf-8', errors='replace')

def has(rel, marker):
    assert marker in txt(rel), f"missing marker {marker!r} in {rel}"

def sha(rel, expected):
    actual = hashlib.sha256(req(rel).read_bytes()).hexdigest()
    assert actual == expected, f"hash mismatch {rel}: {actual}"

def combined_hash(paths):
    h = hashlib.sha256()
    for p in sorted(paths, key=lambda x: x.relative_to(root).as_posix()):
        rel = p.relative_to(root).as_posix()
        h.update(rel.encode() + b'\0' + p.read_bytes() + b'\0')
    return h.hexdigest()

U = 'app/src/main/java/com/okn/dsp/UnifiedControlActivity.kt'
CURVE = 'app/src/main/java/com/okn/dsp/EqCurveView.kt'
G = 'app/build.gradle.kts'
M = 'app/src/main/java/com/okn/dsp/MainActivity.kt'
WG = 'app/src/main/java/com/okn/dsp/protocol/WriteGate.kt'
SC = 'app/src/main/java/com/okn/dsp/protocol/VerifiedScalarControls.kt'
EQ = 'app/src/main/java/com/okn/dsp/protocol/LiveEqPolicy.kt'
STYLE = 'app/src/main/res/values/styles.xml'
KEY = 'app/okn_dsp_stable_debug.keystore'
README = 'README_V90.txt'
PLAN = 'evidence/OKN_DSP_V90_REFERENCE_UI_REBUILD_PLAN.txt'
PLANJ = 'evidence/OKN_DSP_V90_REFERENCE_UI_REBUILD_PLAN.json'
REF = 'evidence/OKN_DSP_V90_REFERENCE_UI_MASTER.png'

for f in [U,CURVE,G,M,WG,SC,EQ,STYLE,KEY,README,PLAN,PLANJ,REF]:
    req(f)

# Version / identity.
has(G, 'applicationId = "com.okn.dsp"')
has(G, 'versionCode = 90')
has(G, 'versionName = "5.21.0-v90-reference-ui-rebuild"')
has(M, 'V90 reference UI launcher over the frozen V88 qualified control core')

# Reference UI structure and dark theme.
for marker in [
    'V90_REFERENCE_UI_START',
    'productionSectionTitle("Global Controls")',
    'productionSectionTitle("Channel EQ Overview")',
    'productionSectionTitle("Sensors & System")',
    'text = "▣  Save to Device • Locked"',
    'Triple("⌂", "Home", 0)',
    'Triple("◌", "Global", 1)',
    'Triple("▥", "EQ", 2)',
    'Triple("◉", "Sensors", 3)',
    'Triple("•••", "More", 4)',
    'private fun renderHome()',
    'private fun showEqGainDialog(',
    'EqCurveView(this)',
    'V90_TREBLEBOOST_ID11_UI_HOLD',
    'c.id != 11',
]:
    has(U, marker)
has(STYLE, 'Theme.Material3.DayNight.NoActionBar')
has(STYLE, 'android:windowLightStatusBar">false')
has(CURVE, 'class EqCurveView(context: Context) : View(context)')

# Frozen production protocol + transport byte-for-byte.
protocol_files = list((root/'app/src/main/java/com/okn/dsp/protocol').glob('*.kt'))
transport_files = list((root/'app/src/main/java/com/okn/dsp/transport').glob('*.kt'))
combo = combined_hash(protocol_files + transport_files)
assert combo == 'f897e05f77e7f4e631d591c29a6d758ef355c7b4fba693e63dabe0572cb8552b', combo

# Stable signing identity unchanged.
sha(KEY, 'ba1c52f2607c09953c52fdd79c5f72026aaf0adb8aa44bcba277f7d9b49d9511')

# Verified write scope unchanged.
wg = txt(WG)
assert 'const val enabled: Boolean = false' in wg
assert 'const val unifiedVerifiedScalarWritesEnabled: Boolean = true' in wg
assert 'const val unifiedVerifiedEqWritesEnabled: Boolean = true' in wg
sc = txt(SC)
ids = [int(x) for x in re.findall(r'VerifiedScalarControl\((\d+),', sc)]
assert ids == [2,3,8,9,10,13,11], ids
has(EQ, 'b.type == EqBandCodec.PEAKING_TYPE')
has(EQ, 'const val MIN_BOOST_DB = -12.0f')
has(EQ, 'const val MAX_BOOST_DB = 12.0f')

# Core V88 safety paths retained in activity.
u = txt(U)
for marker in [
    'V88_ALL_STATUS_DISCONNECT_FAIL_CLOSED',
    'V88_LIFECYCLE_DESTROY_FAIL_CLOSED',
    'V88_SESSION_HEALTH_GATE_RESULT',
    'SaveParamsPolicy.encodeTrigger()',
    'UfeCodec.encodeFloat32Write(id, target)',
    'UfeCodec.encodeFloat32Write(id, original)',
    'LiveEqPolicy.encodeWrite(ch, band1, target)',
    'LiveEqPolicy.encodeRestore(ch, band1, original)',
    'private fun failClosedDisconnectedAllStatus(callbackGatt: BluetoothGatt, statusCode: Int)',
]:
    assert marker in u, marker

# ID11 hold occurs before scalar writer gate/pipeline.
confirm = u[u.index('    private fun confirmScalarWrite('):u.index('    private fun beginScalarPreflight(')]
assert confirm.index('if (c.id == 11)') < confirm.index('WriteGate.unifiedVerifiedScalarWritesEnabled')
assert 'writeSent=false saveSent=false' in confirm

# ARM-before-write ordering retained.
section = u[u.index('    private fun writeNoResponse('):u.index('    private fun record(kind: String, text: String) {')]
a = section.index('gattWriteTickets.addLast(kind)')
b = section.index('V88_UNIFIED_GATT_TICKET_PREPARED')
c = section.index('if (purpose != null) armGattActionTimeout(purpose)')
d = section.index('g.writeCharacteristic(ch, bytes, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE)')
assert a < b < c < d, (a,b,c,d)

# Structural sanity.
assert u.count('class UnifiedControlActivity : Activity()') == 1
assert u.count('override fun onDestroy()') == 1
assert u.count('private fun renderAll()') == 1
assert u.count('private fun renderHome()') == 1
assert u.count('private fun renderScalars()') == 1
assert u.count('private fun renderSensors()') == 1
assert u.count('private fun renderEq()') == 1
assert u.count('private fun failClosedDisconnectedAllStatus(callbackGatt: BluetoothGatt, statusCode: Int)') == 1

print('V90 PREFLIGHT PASS')
print('versionCode=90')
print('versionName=5.21.0-v90-reference-ui-rebuild')
print('protocolTransportCombinedSha256=' + combo)
print('keystoreSha256=ba1c52f2607c09953c52fdd79c5f72026aaf0adb8aa44bcba277f7d9b49d9511')
print('writerScope=scalar[2,3,8,9,10,13,11]+safePeakingEq+manualSave;generic=false')
print('id11UiWriteHold=true')
print('ui=reference-ui-rebuild')
