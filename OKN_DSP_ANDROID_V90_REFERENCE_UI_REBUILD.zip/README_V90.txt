OKN DSP V90 — REFERENCE UI REBUILD
==================================

Purpose
- New Android source release requested explicitly by the user.
- Rebuild the production-facing app UI to follow the supplied OKN_DSP master reference image.
- Preserve the frozen V88-qualified DSP protocol, transport, signing identity and writer safety boundaries.

Version
- versionCode: 90
- versionName: 5.21.0-v90-reference-ui-rebuild

UI scope implemented
- Home / Dashboard
- Global Controls (7 verified controls)
- Channel EQ Overview (7 channels)
- EQ Editor (15 bands/channel)
- Sensors & System
- Manual guarded SaveParams card
- More page for connection and diagnostic tools
- Dark navy / cyan visual language from the supplied reference image

Safety scope preserved
- Scalar allow-list remains IDs 2,3,8,9,10,13,11.
- EQ writes remain restricted to verified PEAKING type=12 bands only.
- Sensors remain read-only.
- SaveParams remains manual and guarded; no automatic save.
- Preset / Delay / unknown actuator writes remain locked.
- Generic write surface remains disabled.
- V88 health gate, reconnect/watchdog, stale-GATT isolation, all-status disconnect fail-closed and lifecycle fail-closed paths remain in source.

TrebleBoost ID11 incident hold
- The UI still shows the verified TrebleBoost value/range so the operator can see current DSP state.
- V90 blocks user-initiated ID11 writes in the production UI while the audible-transient incident remains unresolved.
- No ramp/slew/smoothing or alternate payload was invented.
- Do not Save as a way to investigate the incident.

Build / qualification status
- Packaged source preflight must pass before GitHub build.
- GitHub Actions performs Android build and signer-certificate verification.
- First V90 real-DSP qualification must begin READ-ONLY and confirm 7 scalars + 105 EQ bands + 4 sensors + Health Gate before any permitted write test.
