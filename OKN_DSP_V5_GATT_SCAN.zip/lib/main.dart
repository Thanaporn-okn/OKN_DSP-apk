import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() => runApp(const OknDspApp());

class OknDspApp extends StatelessWidget {
  const OknDspApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'OKN DSP',
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.blue),
    home: const HomePage(),
  );
}

class DeviceInfo {
  final String name, address;
  final int rssi;
  const DeviceInfo(this.name, this.address, this.rssi);
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  static const method = MethodChannel('okn_dsp/methods');
  static const events = EventChannel('okn_dsp/events');
  StreamSubscription? sub;
  final devices = <DeviceInfo>[];
  String status = 'พร้อมค้นหา Bluetooth';
  String gatt = '';
  String rx = '';
  bool scanning = false;

  @override
  void initState() {
    super.initState();
    sub = events.receiveBroadcastStream().listen((e) {
      if (!mounted || e is! Map) return;
      final type = e['type']?.toString() ?? '';
      if (type == 'device') {
        final d = DeviceInfo(
          e['name']?.toString() ?? 'ไม่ทราบชื่อ',
          e['address']?.toString() ?? '',
          int.tryParse(e['rssi']?.toString() ?? '') ?? 0,
        );
        setState(() {
          if (!devices.any((x) => x.address == d.address)) devices.add(d);
        });
      } else if (type == 'status') {
        setState(() => status = e['message']?.toString() ?? '');
      } else if (type == 'gatt') {
        setState(() => gatt = e['text']?.toString() ?? '');
      } else if (type == 'rx') {
        setState(() => rx = e['data']?.toString() ?? '');
      }
    });
  }

  @override
  void dispose() {
    sub?.cancel();
    super.dispose();
  }

  Future<void> scan() async {
    setState(() { devices.clear(); gatt = ''; rx = ''; status = 'กำลังค้นหา BLE...'; scanning = true; });
    try { await method.invokeMethod('scan'); }
    catch (e) { setState(() => status = 'เริ่มค้นหาไม่ได้: $e'); }
    await Future<void>.delayed(const Duration(seconds: 8));
    if (mounted) setState(() => scanning = false);
  }

  Future<void> connect(DeviceInfo d) async {
    setState(() => status = 'กำลังเชื่อมต่อ ${d.name}...');
    try { await method.invokeMethod('connect', {'address': d.address}); }
    catch (e) { setState(() => status = 'เชื่อมต่อไม่ได้: $e'); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('OKN DSP Controller'),
      actions: [IconButton(onPressed: scanning ? null : scan, icon: const Icon(Icons.bluetooth_searching))],
    ),
    body: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Card(child: Padding(
          padding: const EdgeInsets.all(16),
          child: Text(
            'Bluetooth ของบอร์ด\n'
            'ชื่อที่บอร์ดแสดง > ใช้สำหรับ Media / เล่นเพลง\n'
            'ชื่อที่บอร์ดแสดง > ใช้สำหรับ ควบคุม DSP\n\n$status',
            style: const TextStyle(fontSize: 17),
          ),
        )),
        if (gatt.isNotEmpty) ...[
          const SizedBox(height: 8),
          Card(child: Padding(
            padding: const EdgeInsets.all(12),
            child: SizedBox(height: 330, child: SingleChildScrollView(child: Text(gatt, style: const TextStyle(fontSize: 12)))),
          )),
        ],
        if (rx.isNotEmpty) Text('RX: $rx'),
        const SizedBox(height: 8),
        const Text('ชื่อที่บอร์ดแสดง', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        Expanded(child: devices.isEmpty
          ? const Center(child: Text('กด Bluetooth ด้านบนเพื่อค้นหา'))
          : ListView.builder(
              itemCount: devices.length,
              itemBuilder: (_, i) {
                final d = devices[i];
                return Card(child: ListTile(
                  leading: const Icon(Icons.bluetooth),
                  title: Text(d.name),
                  subtitle: Text('${d.address}\nRSSI ${d.rssi} dBm'),
                  isThreeLine: true,
                  trailing: ElevatedButton(onPressed: () => connect(d), child: const Text('เชื่อมต่อ')),
                ));
              },
            )),
        const Text('โหมดนี้อ่าน GATT อย่างเดียว ยังไม่ส่งคำสั่งไปยัง DSP', textAlign: TextAlign.center),
      ]),
    ),
  );
}
