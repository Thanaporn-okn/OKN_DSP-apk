OKN DSP ANDROID V31 — PRE-AUTH RANDKEY DECODER LAB

Purpose
- Continue directly from V30 same-session authentication evidence.
- Keep all verified UFE / EQ48 / post-auth AES-CFB8 behavior.
- Add an offline pre-auth RandKey decoder lab without enabling DSP writes.

Confirmed input evidence
- Four exact auth response32 <-> official-app RandKey pairs.
- 20:45:55 is a same-session pair with:
  auth response32 = D024E38C00000000420DA6E8FDDF06895D514A274A2181DEB2F457CA70A60EC1
  RandKey        = 0168DEEB916838D752E0D696BB3655E6
  next TX 4B     = 5DFCB7E5
  post-auth AES-CFB8 decrypt -> 661C0624
- encryptedTail[0] XOR RandKey[0] = 0x5C in all four paired sessions.

V31 new work
- Computes all encryptedTail[i] XOR RandKey[i] invariants across 4 sessions.
- Confirms only byte[0] is invariant; a simple fixed 16-byte XOR mask is rejected.
- Runs a bounded AES-CFB8 candidate sweep using visible values:
  ZERO16, ONE16, fixed AUTH request16, UNIQUE_ID x2, fixed response[8..15] x2,
  Type/Version x4, plus MD5 and SHA-256[:16] derivatives.
- Candidate acceptance rule is strict: 16/16 RandKey bytes across all 4 sessions.
- The sweep is evidence/rejection only. It does not guess a key and never enables WriteGate.

Next reverse target
- Recover the real pre-auth AES secret / IV / KDF from the Flutter AOT path around:
  "Error in authentication response data length, Exit"
  ", RandKey="
  "Sent Device Type and software version authentication request data"
  "cfb8" / "CFB-8"

Safety
- WriteGate.enabled remains false.
- PRE-AUTH DECODER LAB is offline only and transmits no BLE packets.

Build
- Preferred: upload only OKN_DSP_ANDROID_V31_PREAUTH_DECODER_LAB.zip to the repo.
- Let build-android-auto-latest.yml build automatically.
- Use the separate V31 one-file workflow only as a backup.
