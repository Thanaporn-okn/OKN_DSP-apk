package com.okn.dsp.protocol

import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * V31 offline-only pre-auth decoder research.
 *
 * This code deliberately does NOT transmit BLE data and does NOT enable WriteGate.
 * It uses the four already paired auth response32 -> official-app RandKey vectors to:
 *  1) identify bytewise invariants,
 *  2) reject simple XOR-mask explanations,
 *  3) sweep a bounded set of visible/obvious AES-CFB8 key+IV derivations.
 *
 * A candidate is accepted only if it reproduces all 16 RandKey bytes in all paired sessions.
 */
data class PreAuthCandidateResult(
    val name: String,
    val byteMatches: Int,
    val exactSessions: Int,
    val firstByteMatches: Int,
)

object PreAuthDecoderLab {
    private val authRequest16 = ByteCodec.hexToBytes("631C062443FD3844558001F3EDA0CCF8")
    private val uniqueId8 = ByteCodec.hexToBytes(AuthVectorLab.UNIQUE_ID_HEX)
    private val fixed8 = ByteCodec.hexToBytes(AuthVectorLab.FIXED_8_15_HEX)
    private val typeVersion4 = ByteCodec.hexToBytes("D024E38C")

    private fun repeatTo16(src: ByteArray): ByteArray = ByteArray(16) { src[it % src.size] }
    private fun md5(src: ByteArray): ByteArray = MessageDigest.getInstance("MD5").digest(src)
    private fun sha16(src: ByteArray): ByteArray = MessageDigest.getInstance("SHA-256").digest(src).copyOfRange(0, 16)

    private fun baseMaterials(): LinkedHashMap<String, ByteArray> = linkedMapOf(
        "ZERO16" to ByteArray(16),
        "ONE16" to ByteArray(16) { 0x01 },
        "AUTH_REQUEST16" to authRequest16.copyOf(),
        "UNIQUE_ID_X2" to repeatTo16(uniqueId8),
        "FIXED8_X2" to repeatTo16(fixed8),
        "TYPE_VERSION_X4" to repeatTo16(typeVersion4),
    )

    private fun candidateMaterials(): LinkedHashMap<String, ByteArray> {
        val out = linkedMapOf<String, ByteArray>()
        val base = baseMaterials()
        base.forEach { (name, bytes) -> out[name] = bytes }
        base.forEach { (name, bytes) -> out["MD5($name)"] = md5(bytes) }
        base.forEach { (name, bytes) -> out["SHA256($name)[:16]"] = sha16(bytes) }
        return out
    }

    /** byte indexes where encryptedTail[i] XOR RandKey[i] is identical in every paired session. */
    fun invariantXorPositions(): Map<Int, Int> {
        val parsed = AuthVectorLab.pairedVectors.map { v ->
            AuthResponseCodec.parse32(ByteCodec.hexToBytes(v.response32Hex)).encryptedRandKey to
                ByteCodec.hexToBytes(v.randKeyHex)
        }
        val out = linkedMapOf<Int, Int>()
        for (i in 0 until 16) {
            val values = parsed.map { (cipher, key) ->
                (cipher[i].toInt() xor key[i].toInt()) and 0xff
            }.distinct()
            if (values.size == 1) out[i] = values.first()
        }
        return out
    }

    private fun decryptCfb8(key: ByteArray, iv: ByteArray, cipherText: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/CFB8/NoPadding")
        c.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), IvParameterSpec(iv))
        return c.doFinal(cipherText)
    }

    /**
     * Bounded research sweep. These are only obvious values visible in our captures/static metadata.
     * No result from this function is trusted unless exactSessions == pairedVectors.size.
     */
    fun sweepCandidates(): List<PreAuthCandidateResult> {
        val materials = candidateMaterials()
        val results = ArrayList<PreAuthCandidateResult>(materials.size * materials.size)
        for ((keyName, key) in materials) {
            for ((ivName, iv) in materials) {
                var byteMatches = 0
                var exactSessions = 0
                var firstByteMatches = 0
                for (v in AuthVectorLab.pairedVectors) {
                    val header = AuthResponseCodec.parse32(ByteCodec.hexToBytes(v.response32Hex))
                    val expected = ByteCodec.hexToBytes(v.randKeyHex)
                    val decoded = decryptCfb8(key, iv, header.encryptedRandKey)
                    var exact = true
                    for (i in 0 until 16) {
                        if (decoded[i] == expected[i]) byteMatches++ else exact = false
                    }
                    if (decoded[0] == expected[0]) firstByteMatches++
                    if (exact) exactSessions++
                }
                results += PreAuthCandidateResult(
                    name = "KEY=$keyName IV=$ivName",
                    byteMatches = byteMatches,
                    exactSessions = exactSessions,
                    firstByteMatches = firstByteMatches,
                )
            }
        }
        return results.sortedWith(
            compareByDescending<PreAuthCandidateResult> { it.exactSessions }
                .thenByDescending { it.byteMatches }
                .thenByDescending { it.firstByteMatches }
                .thenBy { it.name }
        )
    }

    fun report(): List<String> = buildList {
        add("PRE-AUTH DECODER LAB • OFFLINE ONLY • paired=${AuthVectorLab.pairedVectors.size}")
        val inv = invariantXorPositions()
        add("XOR invariant positions = " + if (inv.isEmpty()) "none" else inv.entries.joinToString { "byte[${it.key}]=%02X".format(it.value) })
        add("Interpretation: only byte[0]=0x5C is invariant; a fixed 16-byte XOR mask is rejected.")

        val sweep = sweepCandidates()
        val exact = sweep.filter { it.exactSessions == AuthVectorLab.pairedVectors.size }
        add("AES-CFB8 visible-value candidate pairs tested=${sweep.size}")
        if (exact.isEmpty()) {
            add("EXACT DECODER: none • obvious key/IV and MD5/SHA256 derivations are rejected")
        } else {
            exact.forEach { add("EXACT CANDIDATE ${it.name}") }
        }
        sweep.take(5).forEachIndexed { idx, r ->
            add("TOP${idx + 1} ${r.name} • byteMatch=${r.byteMatches}/64 • firstByte=${r.firstByteMatches}/4 • exactSessions=${r.exactSessions}/4")
        }
        val byte0Only = sweep.firstOrNull { it.firstByteMatches == 4 && it.byteMatches == 4 }
        if (byte0Only != null) {
            add("NOTE: ${byte0Only.name} reproduces only byte0 in 4/4 sessions (${byte0Only.byteMatches}/64 total); this proves byte0 alone is insufficient and is NOT a decoder.")
        }
        add("NEXT TARGET: recover the real fixed pre-auth AES secret/IV/KDF from the 250401 reference app AOT path that prints ', RandKey='.")
        add("LIVE WRITE LOCKED • no BLE packet was transmitted by this lab")
    }
}
