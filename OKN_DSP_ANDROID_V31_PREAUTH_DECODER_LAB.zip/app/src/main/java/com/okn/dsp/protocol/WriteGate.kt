package com.okn.dsp.protocol

/**
 * V31 live write gate.
 * UFE serializer + EQ48 + post-auth AES-CFB8 are verified. V31 also rejects naive fixed-key/IV
 * candidates offline, but the real pre-auth secret/derivation is not recovered. Keep false.
 */
object WriteGate {
    const val enabled: Boolean = false
}
