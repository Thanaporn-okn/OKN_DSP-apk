# OKN DSP Android BLE Logger v0.5.0

Mobile-first Android BLE logger for the OKN DSP project.

## Build on GitHub from a phone
1. Upload this ZIP to the root of your GitHub repository.
2. Upload the separate `OKN_DSP_build_workflow_V0.5.yml` to `.github/workflows/build-apk.yml`.
3. The workflow has both `push` and `workflow_dispatch` triggers. Adding the workflow file to `main` should start a build automatically, and the **Run workflow** button should also be available.
4. Open **Actions → Build OKN DSP APK**.
5. Open the successful run and download the `OKN-DSP-v0.5.0-debug` artifact.

The workflow automatically finds `OKN_DSP_Android_BLE_Logger_V0.5.zip` in the repository, extracts it, and builds the APK. No manual file editing is required.

## Safety
DSP WRITE operations remain disabled. This version is for BLE discovery, GATT discovery, notifications, and packet logging only.
