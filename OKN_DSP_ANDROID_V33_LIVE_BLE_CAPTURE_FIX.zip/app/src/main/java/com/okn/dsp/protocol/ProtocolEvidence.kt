package com.okn.dsp.protocol

/** V29 evidence state. Live write remains blocked by the unverified pre-auth RandKey decrypt key/IV/derivation. */
data class ProtocolEvidence(
    val ufeSerializerVerified: Boolean = true,
    val actuatorMappingVerified: Boolean = true,
    val eq48SerializerVerified: Boolean = true,
    val aesCfb8Verified: Boolean = true,
    val txIvVerified: Boolean = true,
    val continuousTxStateVerified: Boolean = true,
    val currentSessionRandKeyExtractionVerified: Boolean = false,
) {
    val liveWriteReady: Boolean
        get() = ufeSerializerVerified && actuatorMappingVerified && eq48SerializerVerified &&
            aesCfb8Verified && txIvVerified && continuousTxStateVerified &&
            currentSessionRandKeyExtractionVerified

    fun missingRequirements(): List<String> = buildList {
        if (!ufeSerializerVerified) add("UFE serializer")
        if (!actuatorMappingVerified) add("actuator mapping")
        if (!eq48SerializerVerified) add("EQ48 serializer")
        if (!aesCfb8Verified) add("AES-CFB8")
        if (!txIvVerified) add("TX IV")
        if (!continuousTxStateVerified) add("continuous TX cipher state")
        if (!currentSessionRandKeyExtractionVerified) add("RandKey extraction from 32B auth response")
    }
}
