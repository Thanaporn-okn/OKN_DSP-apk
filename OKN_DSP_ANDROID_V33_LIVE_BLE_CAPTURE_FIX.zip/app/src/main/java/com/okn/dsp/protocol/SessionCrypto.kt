package com.okn.dsp.protocol

import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Verified TX application crypto for a single authenticated session.
 * Key = 16-byte RandKey, AES-CFB8, IV=01 repeated 16 bytes, continuous stream state.
 * Do NOT instantiate for live control until RandKey has been derived from the current auth response.
 */
class SessionTxCipher(randKey: ByteArray) {
    init { require(randKey.size == 16) { "RandKey must be 16 bytes" } }

    private val cipher: Cipher = Cipher.getInstance("AES/CFB8/NoPadding").apply {
        init(
            Cipher.ENCRYPT_MODE,
            SecretKeySpec(randKey.copyOf(), "AES"),
            IvParameterSpec(ByteArray(16) { 0x01 })
        )
    }

    /** Uses update(), not doFinal(), so CFB8 state remains continuous across packets. */
    fun encryptNext(plain: ByteArray): ByteArray = cipher.update(plain) ?: byteArrayOf()
}

object SessionCryptoFacts {
    val DEVICE_DESCRIPTION_REQUEST: ByteArray = byteArrayOf(0x66, 0x1c, 0x06, 0x24)
    const val AUTH_RANDKEY_EXTRACTION_VERIFIED = false
}


/**
 * Evidence/self-test helper for the first post-auth packet only.
 * The first encrypted TX packet starts from the verified IV=01×16 state.
 * This is NOT a pre-auth RandKey decoder and does not enable live writes.
 */
object SessionCryptoEvidence {
    fun decryptFirstPostAuthPacket(randKey: ByteArray, cipherText: ByteArray): ByteArray {
        require(randKey.size == 16) { "RandKey must be 16 bytes" }
        val cipher = Cipher.getInstance("AES/CFB8/NoPadding").apply {
            init(
                Cipher.DECRYPT_MODE,
                SecretKeySpec(randKey.copyOf(), "AES"),
                IvParameterSpec(ByteArray(16) { 0x01 })
            )
        }
        return cipher.update(cipherText) ?: byteArrayOf()
    }
}
