OKN DSP V33 — LIVE BLE CAPTURE FIX

Purpose
- Fix the V32 evidence export where only the SESSION header could be saved when GATT callback messages were UI-only.
- Persist every important local GATT callback into captureLines and an internal append-only backup.
- Add RX/TX/META counters so the user can verify capture health before saving.
- Add CAPTURE HEALTH CHECK: reads GAP Device Name (2A00) to prove RX_READ callback capture.
- Add AUTH RESPONSE CAPTURE — SEND 16B ONLY: replays only the known 16-byte startup/auth request to AB01, waits for a 32-byte AB02 response, and deliberately does NOT send the 4-byte follow-up or any DSP parameter command.
- Add QUICK SAVE TO DOWNLOADS/OKN_DSP using MediaStore on Android 10+.

Expected test
1. SCAN DSP -> TAP TO CONNECT.
2. Wait until CONNECTED and CAPTURE META counter increases.
3. Press CAPTURE HEALTH CHECK. RX should increase after RX_READ.
4. Press CAPTURE AUTH RESPONSE — SEND 16B ONLY and confirm.
5. Wait for status AUTH RESPONSE 32B CAPTURED.
6. QUICK SAVE CAPTURE TO DOWNLOADS.
7. Upload OKN_DSP_V33_CAPTURE_*.txt for analysis.

Safety
- DSP parameter write remains locked.
- The V33 auth probe sends only the exact known 16-byte startup/auth request from the reference capture.
- It does not send the 4-byte follow-up, Gain/EQ/Delay writes, or actuator writes.
