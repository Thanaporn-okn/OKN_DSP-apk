plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace="com.okn.dsp"
    compileSdk=35

    defaultConfig {
        applicationId="com.okn.dsp"
        minSdk=26
        targetSdk=35
        versionCode=71
        versionName="0.7.1"
    }

    compileOptions {
        sourceCompatibility=JavaVersion.VERSION_17
        targetCompatibility=JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget="17"
    }
}
