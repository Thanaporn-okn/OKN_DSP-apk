package com.okn.dsp

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.widget.*

class MainActivity: Activity(){
 override fun onCreate(b:Bundle?){
  super.onCreate(b)
  val l=LinearLayout(this)
  l.orientation=LinearLayout.VERTICAL
  l.setPadding(20,20,20,20)
  l.setBackgroundColor(Color.BLACK)

  val t=TextView(this)
  t.text="🔵 Connected\nBP1048P4 7CH DSP\nFW:1.2.6\n\nMaster Volume"
  t.textSize=22f
  t.setTextColor(Color.WHITE)
  l.addView(t)

  val channels=arrayOf("CH1 Front L","CH2 Front R","CH3 SUB","CH4 Rear L","CH5 Rear R","CH6 AUX L","CH7 AUX R")
  for(c in channels){
   val x=TextView(this)
   x.text=c+"\n━━━━━━━━\nMute"
   x.textSize=18f
   x.setTextColor(Color.WHITE)
   l.addView(x)
  }
  setContentView(l)
 }
}
