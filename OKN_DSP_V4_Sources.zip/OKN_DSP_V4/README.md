# OKN DSP V4 — Phase 1 Compile Fix

V4 is a new version created from V3 after the GitHub Actions build error. It keeps the same Android application ID and stable signing key so it can update earlier OKN DSP versions while preserving saved state.

## V4 fix
- Fixes `DspView.java` compile error: `variable gap is already defined in method drawEq(Canvas,float)`.
- The preset action-button spacing variable is now named `actionGap`, avoiding the earlier `gap` variable used for channel chips.
- Keeps the V3 UI changes: `Gain Band`, multiple named presets, preset picker, Load, and Delete with confirmation.
- Keeps theme, slider values, EQ state, selected page/channel/band, and presets persistent across app restarts.
- Phase 2 DSP transport remains intentionally unimplemented until the real DSP protocol/control data is supplied.

Build input: `OKN_DSP_V4_Sources.zip` using `OKN_DSP_AutoBuild.yml`.
