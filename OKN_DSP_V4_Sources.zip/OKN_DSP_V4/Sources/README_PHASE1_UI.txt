OKN_DSP Version 3 - Phase 1 UI

This version focuses on matching the supplied four-screen visual reference using native Canvas drawing only.
The reference image is NOT copied into the app as a background or UI bitmap.

Screens:
- Home: device status, vector DSP chassis, source selector, quick actions, sound banner
- Mix: master/bass sliders plus Bass Cutoff/Bass Boost/Middle Boost/Treble Boost rotary controls
- Eq: seven channel tabs, interactive 15-band response, Frequency/Gain/Q controls, output level
- Crossover: response graph, four filter blocks, slopes, delay/time alignment and units

Interaction:
- UI redraws immediately during drag/touch.
- Phase 1 contains simulated/local UI state only.
- Real DSP/BLE protocol transport is reserved for Phase 2.

Install/update note:
V1/V2 GitHub debug builds could be signed by different temporary runner keys. Android will reject an in-place update when signatures differ.
V3 introduced a stable DEVELOPMENT signing key; V4 preserves the same key so V3 -> V4 -> later development builds can update in place.
If moving from V1/V2 to V3/V4 and Android reports an incompatible update, uninstall the older V1/V2 app once. V3 and later preserve the same development key.
For Phase 3 release builds, replace the development key with a private release key stored in GitHub Secrets; do not use this development key for production distribution.
