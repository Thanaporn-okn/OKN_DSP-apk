OKN_DSP V4 - PHASE 1

This version is a build-fix release following the V3 GitHub Actions compiler failure.
UI scope remains Phase 1 only. No real DSP/BLE protocol commands are introduced.

Build fix:
- Correct checked JSONException handling in DspPresetStore JSON serialization helpers.

Project rules retained:
- UI is drawn programmatically; the uploaded reference image is not used as a screen background.
- Full-screen phone/tablet layout.
- Interactive UI values and graphs update immediately in the local UI model.
- Source SHA256 manifest remains in Sources/SHA256SUMS.txt.
- Any new build/runtime error after V4 must create V5 rather than overwrite V4.
