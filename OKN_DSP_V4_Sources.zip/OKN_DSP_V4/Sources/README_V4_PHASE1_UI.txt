OKN_DSP V4 — Phase 1 UI refinement

This version continues from the stable V3 startup base.
UI is rendered from Android Canvas/vector primitives. The uploaded reference image is NOT used as a background.

V4 changes:
- Forces Android sans-serif/sans-serif-medium families to avoid Samsung custom handwriting font substitution.
- Refines the settings/about modal proportions.
- Smooths the 15-band EQ response line while keeping all 15 draggable points exact.
- Retains event-driven redraw for immediate controls without a permanent render loop.
- Preserves responsive full-screen Home / Mix / Eq / Crossover pages.
- Real DSP/BLE transport remains intentionally disabled until Phase 2 data is supplied.
