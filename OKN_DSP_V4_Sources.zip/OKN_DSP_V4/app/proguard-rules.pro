# V2 intentionally keeps all classes unobfuscated for easier BLE diagnostics.
