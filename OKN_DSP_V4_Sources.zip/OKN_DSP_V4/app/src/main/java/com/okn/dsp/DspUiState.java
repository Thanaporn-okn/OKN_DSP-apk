package com.okn.dsp;

import java.util.Arrays;

/**
 * Phase 1 local UI state only. No BLE/DSP transport is used yet.
 * Phase 2 will bind these values to the real DSP protocol.
 */
public final class DspUiState {
    public int page = 0;
    public boolean connected = true;
    public int inputSource = 0;

    public float masterDb = -6f;
    public float bassDb = 0f;
    public float bassCutoffHz = 80f;
    public float bassBoostDb = 4f;
    public float middleBoostDb = 2f;
    public float trebleBoostDb = 3f;

    public int eqChannel = 0;
    public int selectedBand = 4;
    public final float[][] eqGainDb = new float[7][15];
    public final float[][] eqFrequencyHz = new float[7][15];
    public final float[][] eqQ = new float[7][15];
    public final float[] outputDb = new float[7];

    // SUB, MID, HIGH, FULL
    public final float[] crossoverLowHz = {80f, 80f, 3000f, 20f};
    public final float[] crossoverHighHz = {80f, 3000f, 3000f, 20000f};
    public final int[] crossoverSlopeDb = {12, 24, 24, 12};
    // 0=Low Pass, 1=Band Pass, 2=High Pass, 3=Bypass
    public final int[] crossoverMode = {0, 1, 2, 3};
    public final float[] delayMs = {2.50f, 1.20f, 0f, 0.80f};
    public boolean linkLR = true;
    public boolean magnitudeView = true;
    // 0=ms, 1=cm, 2=in
    public int delayUnit = 0;

    private int savedInputSource;
    private float savedMasterDb;
    private float savedBassDb;
    private float savedBassCutoffHz;
    private float savedBassBoostDb;
    private float savedMiddleBoostDb;
    private float savedTrebleBoostDb;
    private int savedEqChannel;
    private int savedSelectedBand;
    private final float[][] savedEqGainDb = new float[7][15];
    private final float[][] savedEqFrequencyHz = new float[7][15];
    private final float[][] savedEqQ = new float[7][15];
    private final float[] savedOutputDb = new float[7];
    private final float[] savedCrossoverLowHz = new float[4];
    private final float[] savedCrossoverHighHz = new float[4];
    private final int[] savedCrossoverSlopeDb = new int[4];
    private final int[] savedCrossoverMode = new int[4];
    private final float[] savedDelayMs = new float[4];
    private boolean savedLinkLR;
    private boolean savedMagnitudeView;
    private int savedDelayUnit;
    public boolean hasSavedPreset = false;

    public DspUiState() {
        float[] baseFrequencies = {
                20f, 40f, 80f, 160f, 315f, 630f, 1000f, 1600f,
                2500f, 4000f, 6300f, 8000f, 10000f, 12500f, 20000f
        };
        float[] demoCurve = {
                -2f, 1f, 5f, 3f, 1f, 2f, 5f, 1f, -1f, 2f, 5f, 3f, 0.5f, -1f, -3f
        };
        for (int ch = 0; ch < 7; ch++) {
            for (int b = 0; b < 15; b++) {
                eqFrequencyHz[ch][b] = baseFrequencies[b];
                eqQ[ch][b] = 1.2f;
                eqGainDb[ch][b] = demoCurve[b] * (ch == 0 ? 1f : 0.55f);
            }
            outputDb[ch] = 0f;
        }
    }

    /** Saves the complete user-editable Phase-1 DSP UI preset in memory. */
    public void savePreset() {
        savedInputSource = inputSource;
        savedMasterDb = masterDb;
        savedBassDb = bassDb;
        savedBassCutoffHz = bassCutoffHz;
        savedBassBoostDb = bassBoostDb;
        savedMiddleBoostDb = middleBoostDb;
        savedTrebleBoostDb = trebleBoostDb;
        savedEqChannel = eqChannel;
        savedSelectedBand = selectedBand;

        for (int ch = 0; ch < 7; ch++) {
            System.arraycopy(eqGainDb[ch], 0, savedEqGainDb[ch], 0, 15);
            System.arraycopy(eqFrequencyHz[ch], 0, savedEqFrequencyHz[ch], 0, 15);
            System.arraycopy(eqQ[ch], 0, savedEqQ[ch], 0, 15);
        }
        System.arraycopy(outputDb, 0, savedOutputDb, 0, 7);
        System.arraycopy(crossoverLowHz, 0, savedCrossoverLowHz, 0, 4);
        System.arraycopy(crossoverHighHz, 0, savedCrossoverHighHz, 0, 4);
        System.arraycopy(crossoverSlopeDb, 0, savedCrossoverSlopeDb, 0, 4);
        System.arraycopy(crossoverMode, 0, savedCrossoverMode, 0, 4);
        System.arraycopy(delayMs, 0, savedDelayMs, 0, 4);
        savedLinkLR = linkLR;
        savedMagnitudeView = magnitudeView;
        savedDelayUnit = delayUnit;
        hasSavedPreset = true;
    }

    /** Restores the complete user-editable Phase-1 DSP UI preset from memory. */
    public boolean loadPreset() {
        if (!hasSavedPreset) return false;

        inputSource = savedInputSource;
        masterDb = savedMasterDb;
        bassDb = savedBassDb;
        bassCutoffHz = savedBassCutoffHz;
        bassBoostDb = savedBassBoostDb;
        middleBoostDb = savedMiddleBoostDb;
        trebleBoostDb = savedTrebleBoostDb;
        eqChannel = clampInt(savedEqChannel, 0, 6);
        selectedBand = clampInt(savedSelectedBand, 0, 14);

        for (int ch = 0; ch < 7; ch++) {
            System.arraycopy(savedEqGainDb[ch], 0, eqGainDb[ch], 0, 15);
            System.arraycopy(savedEqFrequencyHz[ch], 0, eqFrequencyHz[ch], 0, 15);
            System.arraycopy(savedEqQ[ch], 0, eqQ[ch], 0, 15);
        }
        System.arraycopy(savedOutputDb, 0, outputDb, 0, 7);
        System.arraycopy(savedCrossoverLowHz, 0, crossoverLowHz, 0, 4);
        System.arraycopy(savedCrossoverHighHz, 0, crossoverHighHz, 0, 4);
        System.arraycopy(savedCrossoverSlopeDb, 0, crossoverSlopeDb, 0, 4);
        System.arraycopy(savedCrossoverMode, 0, crossoverMode, 0, 4);
        System.arraycopy(savedDelayMs, 0, delayMs, 0, 4);
        linkLR = savedLinkLR;
        magnitudeView = savedMagnitudeView;
        delayUnit = clampInt(savedDelayUnit, 0, 2);
        return true;
    }

    /** Loads the crossover values visible in the original Phase-1 reference UI. */
    public void applyReferenceCrossoverPreset() {
        crossoverLowHz[0] = 80f;
        crossoverHighHz[0] = 80f;
        crossoverSlopeDb[0] = 12;
        crossoverMode[0] = 0;

        crossoverLowHz[1] = 80f;
        crossoverHighHz[1] = 3000f;
        crossoverSlopeDb[1] = 24;
        crossoverMode[1] = 1;

        crossoverLowHz[2] = 3000f;
        crossoverHighHz[2] = 3000f;
        crossoverSlopeDb[2] = 24;
        crossoverMode[2] = 2;

        crossoverLowHz[3] = 20f;
        crossoverHighHz[3] = 20000f;
        crossoverSlopeDb[3] = 12;
        crossoverMode[3] = 3;
    }

    public void resetEqChannel(int channel) {
        Arrays.fill(eqGainDb[channel], 0f);
        Arrays.fill(eqQ[channel], 1.2f);
    }

    public static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    public static int clampInt(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }
}
