package com.okn.dsp;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Phase-1 persistent preset store.
 * Stores only UI/DSP parameter values; no BLE transport or protocol data is used here.
 */
final class DspPresetStore {
    private static final String PREFS = "okn_dsp_phase1";
    private static final String KEY_PRESET = "full_preset_v4";

    private DspPresetStore() {}

    static boolean save(Context context, DspUiState state) {
        try {
            JSONObject root = new JSONObject();
            root.put("schema", 4);
            root.put("inputSource", state.inputSource);
            root.put("masterDb", state.masterDb);
            root.put("bassDb", state.bassDb);
            root.put("bassCutoffHz", state.bassCutoffHz);
            root.put("bassBoostDb", state.bassBoostDb);
            root.put("middleBoostDb", state.middleBoostDb);
            root.put("trebleBoostDb", state.trebleBoostDb);
            root.put("eqChannel", state.eqChannel);
            root.put("selectedBand", state.selectedBand);
            root.put("eqGainDb", to2dFloatArray(state.eqGainDb));
            root.put("eqFrequencyHz", to2dFloatArray(state.eqFrequencyHz));
            root.put("eqQ", to2dFloatArray(state.eqQ));
            root.put("outputDb", toFloatArray(state.outputDb));
            root.put("crossoverLowHz", toFloatArray(state.crossoverLowHz));
            root.put("crossoverHighHz", toFloatArray(state.crossoverHighHz));
            root.put("crossoverSlopeDb", toIntArray(state.crossoverSlopeDb));
            root.put("crossoverMode", toIntArray(state.crossoverMode));
            root.put("delayMs", toFloatArray(state.delayMs));
            root.put("linkLR", state.linkLR);
            root.put("magnitudeView", state.magnitudeView);
            root.put("delayUnit", state.delayUnit);

            SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            return prefs.edit().putString(KEY_PRESET, root.toString()).commit();
        } catch (Throwable ignored) {
            return false;
        }
    }

    static boolean load(Context context, DspUiState state) {
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            String raw = prefs.getString(KEY_PRESET, null);
            if (raw == null || raw.trim().isEmpty()) return false;

            JSONObject root = new JSONObject(raw);
            state.inputSource = DspUiState.clampInt(root.optInt("inputSource", state.inputSource), 0, 3);
            state.masterDb = DspUiState.clamp((float) root.optDouble("masterDb", state.masterDb), -60f, 0f);
            state.bassDb = DspUiState.clamp((float) root.optDouble("bassDb", state.bassDb), -20f, 20f);
            state.bassCutoffHz = DspUiState.clamp((float) root.optDouble("bassCutoffHz", state.bassCutoffHz), 20f, 300f);
            state.bassBoostDb = DspUiState.clamp((float) root.optDouble("bassBoostDb", state.bassBoostDb), -12f, 12f);
            state.middleBoostDb = DspUiState.clamp((float) root.optDouble("middleBoostDb", state.middleBoostDb), -12f, 12f);
            state.trebleBoostDb = DspUiState.clamp((float) root.optDouble("trebleBoostDb", state.trebleBoostDb), -12f, 12f);
            state.eqChannel = DspUiState.clampInt(root.optInt("eqChannel", state.eqChannel), 0, 6);
            state.selectedBand = DspUiState.clampInt(root.optInt("selectedBand", state.selectedBand), 0, 14);

            read2dFloatArray(root.optJSONArray("eqGainDb"), state.eqGainDb, -12f, 12f);
            read2dFloatArray(root.optJSONArray("eqFrequencyHz"), state.eqFrequencyHz, 20f, 20000f);
            read2dFloatArray(root.optJSONArray("eqQ"), state.eqQ, 0.1f, 10f);
            readFloatArray(root.optJSONArray("outputDb"), state.outputDb, -60f, 12f);
            readFloatArray(root.optJSONArray("crossoverLowHz"), state.crossoverLowHz, 20f, 20000f);
            readFloatArray(root.optJSONArray("crossoverHighHz"), state.crossoverHighHz, 20f, 20000f);
            readIntArray(root.optJSONArray("crossoverSlopeDb"), state.crossoverSlopeDb, 12, 36);
            readIntArray(root.optJSONArray("crossoverMode"), state.crossoverMode, 0, 3);
            readFloatArray(root.optJSONArray("delayMs"), state.delayMs, 0f, 20f);
            state.linkLR = root.optBoolean("linkLR", state.linkLR);
            state.magnitudeView = root.optBoolean("magnitudeView", state.magnitudeView);
            state.delayUnit = DspUiState.clampInt(root.optInt("delayUnit", state.delayUnit), 0, 2);

            // Keep the in-memory snapshot synchronized with the successfully loaded disk preset.
            state.savePreset();
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static JSONArray toFloatArray(float[] values) throws JSONException {
        JSONArray a = new JSONArray();
        for (float value : values) a.put(value);
        return a;
    }

    private static JSONArray toIntArray(int[] values) {
        JSONArray a = new JSONArray();
        for (int value : values) a.put(value);
        return a;
    }

    private static JSONArray to2dFloatArray(float[][] values) throws JSONException {
        JSONArray outer = new JSONArray();
        for (float[] row : values) outer.put(toFloatArray(row));
        return outer;
    }

    private static void readFloatArray(JSONArray source, float[] target, float min, float max) {
        if (source == null) return;
        int count = Math.min(source.length(), target.length);
        for (int i = 0; i < count; i++) {
            Object value = source.opt(i);
            if (value instanceof Number) {
                target[i] = DspUiState.clamp(((Number) value).floatValue(), min, max);
            }
        }
    }

    private static void readIntArray(JSONArray source, int[] target, int min, int max) {
        if (source == null) return;
        int count = Math.min(source.length(), target.length);
        for (int i = 0; i < count; i++) {
            Object value = source.opt(i);
            if (value instanceof Number) {
                target[i] = DspUiState.clampInt(((Number) value).intValue(), min, max);
            }
        }
    }

    private static void read2dFloatArray(JSONArray source, float[][] target, float min, float max) {
        if (source == null) return;
        int rows = Math.min(source.length(), target.length);
        for (int r = 0; r < rows; r++) {
            readFloatArray(source.optJSONArray(r), target[r], min, max);
        }
    }
}
