package com.okn.dsp;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import java.util.UUID;

final class BleManager {
    interface Listener {
        void onBleStatus(String status, String deviceName, boolean connected);
        void onBleMessage(String message);
    }

    static final UUID KNOWN_AB01 = UUID.fromString("0000ab01-0000-1000-8000-00805f9b34fb");
    private static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

    private final Context context;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final BluetoothAdapter adapter;
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic ab01;
    private boolean scanning;
    private boolean connected;
    private String deviceName = "OKN-DSP_7CH";

    BleManager(Context context, Listener listener) {
        this.context = context.getApplicationContext();
        this.listener = listener;
        BluetoothAdapter found = null;
        try {
            BluetoothManager manager = (BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE);
            found = manager == null ? null : manager.getAdapter();
        } catch (RuntimeException ignored) {
        }
        adapter = found;
    }

    boolean isConnected() {
        return connected;
    }

    void startScan() {
        if (!hasPermissions()) {
            postStatus("รอสิทธิ์ Bluetooth", deviceName, false);
            return;
        }
        if (adapter == null) {
            postStatus("ไม่พบ Bluetooth", deviceName, false);
            return;
        }
        if (!adapter.isEnabled()) {
            postStatus("กรุณาเปิด Bluetooth", deviceName, false);
            return;
        }
        if (connected) {
            postStatus("เชื่อมต่อแล้ว", deviceName, true);
            return;
        }
        try {
            scanner = adapter.getBluetoothLeScanner();
            if (scanner == null) {
                postStatus("สแกน BLE ไม่ได้", deviceName, false);
                return;
            }
            if (scanning) scanner.stopScan(scanCallback);
            scanning = true;
            postStatus("กำลังค้นหา...", deviceName, false);
            scanner.startScan(scanCallback);
            main.postDelayed(this::stopScan, 10000);
        } catch (SecurityException e) {
            postStatus("สิทธิ์ Bluetooth ไม่ครบ", deviceName, false);
        } catch (RuntimeException e) {
            scanning = false;
            postStatus("เริ่ม BLE ไม่สำเร็จ", deviceName, false);
            postMessage("BLE error: " + e.getClass().getSimpleName());
        }
    }

    void stopScan() {
        if (!scanning || scanner == null || !hasPermissions()) return;
        try {
            scanner.stopScan(scanCallback);
        } catch (SecurityException ignored) {
        }
        scanning = false;
    }

    void readKnownCharacteristic() {
        if (!connected || gatt == null) {
            postMessage("ยังไม่ได้เชื่อมต่อ DSP");
            startScan();
            return;
        }
        if (ab01 == null) {
            postMessage("เชื่อมต่อแล้ว แต่ยังไม่พบ characteristic AB01");
            return;
        }
        int props = ab01.getProperties();
        if ((props & BluetoothGattCharacteristic.PROPERTY_READ) == 0) {
            postMessage("AB01 ไม่รองรับ READ บนอุปกรณ์นี้");
            return;
        }
        try {
            boolean started = gatt.readCharacteristic(ab01);
            postMessage(started ? "กำลังอ่านค่าจาก AB01" : "เริ่มอ่าน AB01 ไม่สำเร็จ");
        } catch (SecurityException e) {
            postMessage("อ่าน BLE ไม่ได้: สิทธิ์ไม่ครบ");
        }
    }

    void close() {
        stopScan();
        if (gatt != null) {
            try {
                gatt.close();
            } catch (Exception ignored) {
            }
            gatt = null;
        }
        connected = false;
    }

    private boolean hasPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            return context.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                    && context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            if (result == null || result.getDevice() == null) return;
            String name = null;
            try {
                if (result.getScanRecord() != null) name = result.getScanRecord().getDeviceName();
                if (name == null) name = result.getDevice().getName();
            } catch (SecurityException ignored) {
            }
            if (name == null) return;
            String upper = name.toUpperCase();
            if (!(upper.contains("OKN") || upper.contains("DSP"))) return;
            deviceName = name;
            stopScan();
            postStatus("กำลังเชื่อมต่อ...", deviceName, false);
            try {
                gatt = result.getDevice().connectGatt(context, false, gattCallback, BluetoothDevice.TRANSPORT_LE);
            } catch (SecurityException e) {
                postStatus("เชื่อมต่อไม่ได้: สิทธิ์ไม่ครบ", deviceName, false);
            } catch (RuntimeException e) {
                postStatus("เชื่อมต่อไม่ได้", deviceName, false);
                postMessage("connectGatt error: " + e.getClass().getSimpleName());
            }
        }

        @Override
        public void onScanFailed(int errorCode) {
            scanning = false;
            postStatus("สแกน BLE ล้มเหลว " + errorCode, deviceName, false);
        }
    };

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                connected = true;
                postStatus("เชื่อมต่อแล้ว", deviceName, true);
                try {
                    g.discoverServices();
                } catch (SecurityException e) {
                    postMessage("ค้นหา GATT services ไม่ได้: สิทธิ์ไม่ครบ");
                }
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                connected = false;
                ab01 = null;
                postStatus("ตัดการเชื่อมต่อ", deviceName, false);
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt g, int status) {
            ab01 = null;
            int writableCount = 0;
            for (BluetoothGattService service : g.getServices()) {
                for (BluetoothGattCharacteristic c : service.getCharacteristics()) {
                    if (KNOWN_AB01.equals(c.getUuid())) ab01 = c;
                    int p = c.getProperties();
                    if ((p & BluetoothGattCharacteristic.PROPERTY_WRITE) != 0 ||
                            (p & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0) {
                        writableCount++;
                    }
                }
            }
            if (ab01 != null) {
                postMessage("พบ AB01 แล้ว • writable characteristics=" + writableCount);
                enableNotifyIfAvailable(g, ab01);
                if ((ab01.getProperties() & BluetoothGattCharacteristic.PROPERTY_READ) != 0) {
                    try { g.readCharacteristic(ab01); } catch (SecurityException ignored) {}
                }
            } else {
                postMessage("ไม่พบ AB01 • writable characteristics=" + writableCount);
            }
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt g, BluetoothGattCharacteristic characteristic, int status) {
            if (!KNOWN_AB01.equals(characteristic.getUuid())) return;
            byte[] value = characteristic.getValue();
            postMessage("AB01 RX len=" + (value == null ? 0 : value.length) + " hex=" + hex(value));
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic characteristic) {
            if (!KNOWN_AB01.equals(characteristic.getUuid())) return;
            byte[] value = characteristic.getValue();
            postMessage("AB01 notify len=" + (value == null ? 0 : value.length) + " hex=" + hex(value));
        }
    };

    private void enableNotifyIfAvailable(BluetoothGatt g, BluetoothGattCharacteristic c) {
        int p = c.getProperties();
        if ((p & (BluetoothGattCharacteristic.PROPERTY_NOTIFY | BluetoothGattCharacteristic.PROPERTY_INDICATE)) == 0) return;
        try {
            g.setCharacteristicNotification(c, true);
            BluetoothGattDescriptor d = c.getDescriptor(CCCD);
            if (d != null) {
                d.setValue((p & BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0
                        ? BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
                        : BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                g.writeDescriptor(d);
            }
        } catch (SecurityException ignored) {
        }
    }

    private String hex(byte[] data) {
        if (data == null || data.length == 0) return "";
        StringBuilder sb = new StringBuilder();
        for (byte b : data) sb.append(String.format("%02X", b));
        return sb.toString();
    }

    private void postStatus(String status, String name, boolean isConnected) {
        main.post(() -> listener.onBleStatus(status, name, isConnected));
    }

    private void postMessage(String message) {
        main.post(() -> listener.onBleMessage(message));
    }
}
