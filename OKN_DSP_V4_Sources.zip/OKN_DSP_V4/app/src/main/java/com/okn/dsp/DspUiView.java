package com.okn.dsp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * OKN_DSP V3 / Phase 1
 *
 * UI is rendered from code with Canvas primitives. No screenshot/photo is used as a
 * background. All Phase-1 controls update local state immediately on touch and the
 * graphs are redrawn in the same frame via invalidate().
 */
public final class DspUiView extends View {
    private static final float BASE_W = 1080f;
    private static final float BASE_H = 1920f;

    private static final int BG_TOP = Color.rgb(2, 9, 25);
    private static final int BG_BOTTOM = Color.rgb(1, 22, 43);
    private static final int CARD = Color.rgb(5, 42, 72);
    private static final int CARD_DEEP = Color.rgb(4, 25, 49);
    private static final int BORDER = Color.rgb(17, 86, 135);
    private static final int TEXT = Color.rgb(238, 247, 255);
    private static final int MUTED = Color.rgb(155, 184, 216);
    private static final int BLUE = Color.rgb(20, 148, 255);
    private static final int CYAN = Color.rgb(0, 226, 255);
    private static final int GREEN = Color.rgb(0, 239, 178);
    private static final int PURPLE = Color.rgb(176, 55, 255);
    private static final int ORANGE = Color.rgb(255, 174, 43);
    private static final int PINK = Color.rgb(238, 50, 225);
    private static final int RED = Color.rgb(255, 74, 90);

    private static final int A_NAV = 1;
    private static final int A_CONNECTION = 2;
    private static final int A_INPUT = 3;
    private static final int A_QUICK = 4;
    private static final int A_MIX_MASTER = 10;
    private static final int A_MIX_BASS = 11;
    private static final int A_MIX_CUTOFF = 12;
    private static final int A_MIX_BASS_BOOST = 13;
    private static final int A_MIX_MIDDLE = 14;
    private static final int A_MIX_TREBLE = 15;
    private static final int A_EQ_CHANNEL = 20;
    private static final int A_EQ_SAVE = 21;
    private static final int A_EQ_LOAD = 22;
    private static final int A_EQ_MORE = 23;
    private static final int A_EQ_GRAPH = 24;
    private static final int A_EQ_FREQ = 25;
    private static final int A_EQ_GAIN = 26;
    private static final int A_EQ_Q = 27;
    private static final int A_EQ_OUTPUT = 28;
    private static final int A_EQ_MINUS = 29;
    private static final int A_EQ_PLUS = 30;
    private static final int A_X_PRESET = 40;
    private static final int A_X_VIEW = 41;
    private static final int A_X_FILTER = 42;
    private static final int A_X_LOW = 43;
    private static final int A_X_HIGH = 44;
    private static final int A_X_SLOPE = 45;
    private static final int A_X_LINK = 46;
    private static final int A_X_DELAY = 47;
    private static final int A_X_RESET = 48;
    private static final int A_X_AUTO = 49;
    private static final int A_X_DELAY_UNIT = 50;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final DspUiState state = new DspUiState();
    private final List<TouchRegion> regions = new ArrayList<>();

    private TouchRegion activeRegion;
    private float downX;
    private float downY;
    private String banner = "";
    private long bannerUntil = 0L;

    private final String[] pages = {"Home", "Mix", "Eq", "Crossover"};
    private final String[] channelTop = {"Ch 1", "Ch 2", "Ch 3", "Ch 4", "Ch 5", "Ch 6", "Ch 7"};
    private final String[] channelBottom = {"FL", "FR", "C", "RL", "RR", "SUB", "AUX"};
    private final String[] crossoverNames = {"SUB", "MID", "HIGH", "FULL"};
    private final int[] crossoverColors = {PURPLE, BLUE, GREEN, ORANGE};

    public DspUiView(Context context) {
        super(context);
        // V3: software Canvas path avoids vendor GPU/renderer instability on some devices.
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        setFocusable(true);
        setClickable(true);
        setBackgroundColor(BG_TOP);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        Throwable renderFailure = null;
        int saveCount = canvas.save();
        try {
            float sx = Math.max(1f, getWidth()) / BASE_W;
            float sy = Math.max(1f, getHeight()) / BASE_H;
            canvas.scale(sx, sy);
            regions.clear();

            drawBackground(canvas);
            drawHeader(canvas);
            if (state.page == 0) drawHome(canvas);
            else if (state.page == 1) drawMix(canvas);
            else if (state.page == 2) drawEq(canvas);
            else drawCrossover(canvas);
            drawBottomNav(canvas);
            drawBanner(canvas);
        } catch (Throwable error) {
            renderFailure = error;
        } finally {
            canvas.restoreToCount(saveCount);
        }

        if (renderFailure != null) {
            drawRenderRecovery(canvas, renderFailure);
        }
    }

    private void drawRenderRecovery(Canvas canvas, Throwable error) {
        // Deliberately use a fresh Paint and only basic Canvas calls here so recovery
        // does not depend on the normal UI drawing helpers that may have failed.
        Paint recovery = new Paint(Paint.ANTI_ALIAS_FLAG);
        recovery.setStyle(Paint.Style.FILL);
        recovery.setColor(Color.rgb(2, 9, 25));
        canvas.drawRect(0, 0, Math.max(1, getWidth()), Math.max(1, getHeight()), recovery);

        recovery.setColor(Color.WHITE);
        recovery.setTextAlign(Paint.Align.CENTER);
        recovery.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        recovery.setTextSize(Math.max(34f, Math.min(getWidth(), getHeight()) * 0.055f));
        canvas.drawText("OKN_DSP V3", getWidth() / 2f, getHeight() * 0.40f, recovery);

        recovery.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
        recovery.setTextSize(Math.max(24f, Math.min(getWidth(), getHeight()) * 0.038f));
        canvas.drawText("UI render recovery active", getWidth() / 2f, getHeight() * 0.48f, recovery);
        canvas.drawText(error.getClass().getSimpleName(), getWidth() / 2f, getHeight() * 0.54f, recovery);
    }

    private void drawBackground(Canvas c) {
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0, 0, 0, BASE_H, BG_TOP, BG_BOTTOM, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, BASE_W, BASE_H, p);
        p.setShader(null);

        p.setColor(Color.argb(80, 0, 151, 255));
        p.setShader(new RadialGradient(840, 160, 420, Color.argb(75, 0, 126, 255), Color.TRANSPARENT, Shader.TileMode.CLAMP));
        c.drawCircle(840, 160, 420, p);
        p.setShader(null);

        // Subtle grid to make the whole app feel like audio hardware UI.
        p.setStrokeWidth(1f);
        p.setColor(Color.argb(18, 68, 165, 226));
        for (float x = 0; x <= BASE_W; x += 60) c.drawLine(x, 0, x, BASE_H, p);
        for (float y = 0; y <= BASE_H; y += 60) c.drawLine(0, y, BASE_W, y, p);
    }

    private void drawHeader(Canvas c) {
        text(c, "OKN", 58, 54, 64, TEXT, Typeface.BOLD, Paint.Align.LEFT);
        text(c, "_DSP", 205, 54, 64, BLUE, Typeface.BOLD, Paint.Align.LEFT);
        letterSpacedText(c, "SOUND IN HIGHER DEFINITION", 59, 103, 22, MUTED, 9);

        // Gear icon built from primitives.
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(5);
        p.setColor(TEXT);
        c.drawCircle(1015, 54, 23, p);
        c.drawCircle(1015, 54, 8, p);
        for (int i = 0; i < 8; i++) {
            double a = i * Math.PI / 4.0;
            float x1 = 1015 + (float) Math.cos(a) * 26;
            float y1 = 54 + (float) Math.sin(a) * 26;
            float x2 = 1015 + (float) Math.cos(a) * 34;
            float y2 = 54 + (float) Math.sin(a) * 34;
            c.drawLine(x1, y1, x2, y2, p);
        }
        p.setStyle(Paint.Style.FILL);
        addRegion(A_QUICK, 2, new RectF(970, 12, 1060, 96));

        RectF chip = new RectF(775, 96, 1027, 157);
        roundedCard(c, chip, Color.argb(105, 3, 42, 67), state.connected ? Color.argb(130, 0, 225, 166) : Color.argb(150, 255, 74, 90), 28, 2);
        p.setColor(state.connected ? GREEN : RED);
        c.drawCircle(809, 126, 13, p);
        text(c, state.connected ? "Connected" : "Disconnected", 846, 135, 25, state.connected ? GREEN : RED, Typeface.BOLD, Paint.Align.LEFT);
        addRegion(A_CONNECTION, 0, chip);
    }

    private void drawHome(Canvas c) {
        drawMountains(c);

        RectF device = new RectF(40, 300, 1040, 980);
        roundedCard(c, device, Color.argb(210, 5, 42, 72), Color.rgb(20, 100, 170), 28, 2);
        letterSpacedText(c, "DSP DEVICE", 72, 346, 19, MUTED, 4);
        text(c, "OKN DSP-8 Pro", 72, 405, 48, TEXT, Typeface.BOLD, Paint.Align.LEFT);
        text(c, "8-Channel Digital Signal Processor", 72, 449, 26, MUTED, Typeface.NORMAL, Paint.Align.LEFT);

        drawDspDevice(c, 78, 520, 520, 360);
        drawDeviceStatus(c, 690, 525);

        RectF input = new RectF(40, 1000, 1040, 1235);
        roundedCard(c, input, Color.argb(205, 4, 36, 63), BORDER, 26, 2);
        letterSpacedText(c, "INPUT SOURCE", 73, 1042, 18, MUTED, 4);
        String[] source = {"Bluetooth", "AUX", "Optical", "USB"};
        String[] icons = {"B", "A", "O", "U"};
        float startX = 66;
        for (int i = 0; i < 4; i++) {
            RectF r = new RectF(startX + i * 245, 1070, startX + i * 245 + 216, 1208);
            boolean selected = state.inputSource == i;
            roundedCard(c, r, selected ? Color.argb(170, 0, 95, 180) : Color.argb(145, 11, 40, 68), selected ? BLUE : Color.rgb(32, 73, 112), 18, selected ? 4 : 2);
            circleIcon(c, r.centerX(), 1108, 25, selected ? CYAN : MUTED, icons[i]);
            text(c, source[i], r.centerX(), 1180, 24, selected ? TEXT : MUTED, selected ? Typeface.BOLD : Typeface.NORMAL, Paint.Align.CENTER);
            addRegion(A_INPUT, i, r);
        }

        RectF quick = new RectF(40, 1255, 1040, 1615);
        roundedCard(c, quick, Color.argb(205, 4, 36, 63), BORDER, 26, 2);
        letterSpacedText(c, "QUICK ACTIONS", 73, 1297, 18, MUTED, 4);
        String[] qTitle = {"Load Preset", "Save Preset", "Device Settings", "About Device"};
        String[] qSub = {"Recall saved setup", "Save current setup", "Advanced options", "Info & support"};
        int[] qColor = {PURPLE, BLUE, GREEN, ORANGE};
        for (int i = 0; i < 4; i++) {
            int col = i % 2;
            int row = i / 2;
            float x = 64 + col * 496;
            float y = 1325 + row * 130;
            RectF r = new RectF(x, y, x + 468, y + 112);
            roundedCard(c, r, Color.argb(140, qColor[i] == ORANGE ? 80 : 10, 35, 60), Color.argb(170, Color.red(qColor[i]), Color.green(qColor[i]), Color.blue(qColor[i])), 18, 2);
            circleIcon(c, x + 55, y + 55, 34, qColor[i], i == 0 ? "L" : i == 1 ? "S" : i == 2 ? "D" : "i");
            text(c, qTitle[i], x + 107, y + 46, 25, TEXT, Typeface.BOLD, Paint.Align.LEFT);
            text(c, qSub[i], x + 107, y + 78, 19, MUTED, Typeface.NORMAL, Paint.Align.LEFT);
            text(c, ">", x + 430, y + 68, 31, MUTED, Typeface.NORMAL, Paint.Align.CENTER);
            addRegion(A_QUICK, i, r);
        }

        RectF premium = new RectF(40, 1638, 1040, 1736);
        roundedCard(c, premium, Color.argb(120, 5, 50, 92), Color.argb(150, 24, 128, 255), 24, 2);
        drawWaveform(c, 72, 1660, 230, 56, CYAN, 26);
        drawWaveform(c, 772, 1660, 230, 56, BLUE, 26);
        text(c, "Premium Sound Experience", 540, 1687, 23, TEXT, Typeface.BOLD, Paint.Align.CENTER);
        text(c, "Precision Audio. In Your Hands.", 540, 1716, 18, MUTED, Typeface.NORMAL, Paint.Align.CENTER);
    }

    private void drawMountains(Canvas c) {
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0, 175, 0, 345, Color.argb(150, 4, 28, 66), Color.argb(230, 0, 12, 31), Shader.TileMode.CLAMP));
        path.reset();
        path.moveTo(0, 290);
        path.lineTo(110, 245);
        path.lineTo(205, 282);
        path.lineTo(335, 205);
        path.lineTo(450, 276);
        path.lineTo(575, 185);
        path.lineTo(672, 258);
        path.lineTo(778, 203);
        path.lineTo(900, 279);
        path.lineTo(1080, 215);
        path.lineTo(1080, 340);
        path.lineTo(0, 340);
        path.close();
        c.drawPath(path, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(3);
        p.setColor(Color.argb(130, 34, 125, 212));
        c.drawPath(path, p);
        p.setStyle(Paint.Style.FILL);
        text(c, "Hear", 812, 234, 30, TEXT, Typeface.ITALIC, Paint.Align.LEFT);
        text(c, "More", 846, 276, 31, TEXT, Typeface.ITALIC, Paint.Align.LEFT);
        text(c, "Feel More", 805, 319, 31, TEXT, Typeface.ITALIC, Paint.Align.LEFT);
    }

    private void drawDspDevice(Canvas c, float x, float y, float w, float h) {
        float topH = 72;
        // top plate
        p.setColor(Color.rgb(25, 31, 42));
        path.reset();
        path.moveTo(x + 48, y);
        path.lineTo(x + w - 20, y + 18);
        path.lineTo(x + w - 92, y + topH);
        path.lineTo(x, y + 47);
        path.close();
        c.drawPath(path, p);
        // face
        p.setColor(Color.rgb(12, 16, 24));
        path.reset();
        path.moveTo(x, y + 47);
        path.lineTo(x + w - 92, y + topH);
        path.lineTo(x + w - 92, y + h - 37);
        path.lineTo(x, y + h);
        path.close();
        c.drawPath(path, p);
        // side
        p.setColor(Color.rgb(21, 25, 34));
        path.reset();
        path.moveTo(x + w - 92, y + topH);
        path.lineTo(x + w - 20, y + 18);
        path.lineTo(x + w, y + h - 92);
        path.lineTo(x + w - 92, y + h - 37);
        path.close();
        c.drawPath(path, p);
        p.setStrokeWidth(3);
        p.setStyle(Paint.Style.STROKE);
        p.setColor(Color.rgb(65, 76, 92));
        c.drawPath(path, p);
        p.setStyle(Paint.Style.FILL);

        text(c, "OKN_DSP", x + 260, y + 45, 24, Color.rgb(205, 214, 225), Typeface.BOLD, Paint.Align.CENTER);
        p.setColor(BLUE);
        c.drawRoundRect(new RectF(x + 275, y + h - 120, x + 420, y + h - 105), 8, 8, p);
        text(c, "DSP-8 PRO", x + w - 165, y + h - 100, 18, MUTED, Typeface.BOLD, Paint.Align.CENTER);
        // side vents
        p.setColor(Color.rgb(40, 45, 57));
        for (int i = 0; i < 7; i++) c.drawRoundRect(new RectF(x + w - 78 + i * 4, y + 100 + i * 28, x + w - 62 + i * 4, y + 117 + i * 28), 3, 3, p);
    }

    private void drawDeviceStatus(Canvas c, float x, float y) {
        String[] a = {state.connected ? "Connected" : "Disconnected", "Excellent", "100%", "v1.0.0", "OKN-8P-0001"};
        String[] b = {"Ready for audio control", "Signal Strength", "Battery", "Firmware UI", "Device ID"};
        int[] colors = {BLUE, GREEN, GREEN, GREEN, CYAN};
        String[] icons = {"B", "S", "P", "C", "i"};
        for (int i = 0; i < 5; i++) {
            float yy = y + i * 86;
            circleIcon(c, x, yy, 31, colors[i], icons[i]);
            text(c, a[i], x + 62, yy - 5, 25, i == 0 && !state.connected ? RED : colors[i], Typeface.BOLD, Paint.Align.LEFT);
            text(c, b[i], x + 62, yy + 27, 18, MUTED, Typeface.NORMAL, Paint.Align.LEFT);
        }
    }

    private void drawMix(Canvas c) {
        pageTitle(c, "Mix", "Real-time mixing and tone control", 205);
        drawAudioBars(c, 785, 210, 230, 62, BLUE);
        letterSpacedText(c, "LIVE AUDIO CONTROL", 803, 290, 13, MUTED, 3);

        RectF master = new RectF(40, 330, 1040, 575);
        roundedCard(c, master, Color.argb(190, 4, 39, 71), BORDER, 27, 2);
        circleIcon(c, 120, 398, 45, PURPLE, "V");
        text(c, "Master Volume", 195, 389, 32, TEXT, Typeface.BOLD, Paint.Align.LEFT);
        text(c, "Control overall output level", 195, 430, 22, MUTED, Typeface.NORMAL, Paint.Align.LEFT);
        valuePill(c, 875, 366, 130, 63, fmtDb(state.masterDb), PURPLE);
        RectF ms = new RectF(80, 480, 1000, 540);
        drawSlider(c, ms, state.masterDb, -60, 0, PURPLE, "-60 dB", "0 dB", A_MIX_MASTER, 0);

        RectF bass = new RectF(40, 598, 1040, 810);
        roundedCard(c, bass, Color.argb(190, 4, 39, 71), BORDER, 27, 2);
        circleIcon(c, 120, 656, 45, CYAN, "V");
        text(c, "Bass Volume", 195, 649, 32, TEXT, Typeface.BOLD, Paint.Align.LEFT);
        text(c, "Adjust bass channel level", 195, 690, 22, MUTED, Typeface.NORMAL, Paint.Align.LEFT);
        valuePill(c, 875, 623, 130, 63, fmtDb(state.bassDb), CYAN);
        RectF bs = new RectF(80, 724, 1000, 780);
        drawSlider(c, bs, state.bassDb, -20, 20, CYAN, "-20 dB", "+20 dB", A_MIX_BASS, 0);

        drawKnobCard(c, new RectF(40, 832, 522, 1240), "Bass Cutoff", "Low-pass filter cutoff", state.bassCutoffHz, 20, 300, GREEN, "Hz", A_MIX_CUTOFF);
        drawKnobCard(c, new RectF(558, 832, 1040, 1240), "Bass Boost", "Boost low frequencies", state.bassBoostDb, -12, 12, PURPLE, "dB", A_MIX_BASS_BOOST);
        drawKnobCard(c, new RectF(40, 1260, 522, 1678), "Middle Boost", "Boost mid frequencies", state.middleBoostDb, -12, 12, BLUE, "dB", A_MIX_MIDDLE);
        drawKnobCard(c, new RectF(558, 1260, 1040, 1678), "Treble Boost", "Boost high frequencies", state.trebleBoostDb, -12, 12, ORANGE, "dB", A_MIX_TREBLE);
    }

    private void drawKnobCard(Canvas c, RectF r, String title, String sub, float value, float min, float max, int color, String unit, int action) {
        roundedCard(c, r, Color.argb(190, 4, 39, 71), BORDER, 27, 2);
        circleIcon(c, r.left + 64, r.top + 60, 34, color, action == A_MIX_CUTOFF ? "F" : "M");
        text(c, title, r.left + 120, r.top + 53, 27, TEXT, Typeface.BOLD, Paint.Align.LEFT);
        text(c, sub, r.left + 120, r.top + 89, 19, MUTED, Typeface.NORMAL, Paint.Align.LEFT);
        String v = unit.equals("Hz") ? String.format(Locale.US, "%.0f Hz", value) : fmtDb(value);
        valuePill(c, r.right - 158, r.top + 25, 125, 56, v, color);

        float cx = r.centerX();
        float cy = r.top + 238;
        float radius = 104;
        drawKnob(c, cx, cy, radius, value, min, max, color);
        text(c, unit.equals("Hz") ? "20 Hz" : "-12 dB", r.left + 42, r.bottom - 43, 18, MUTED, Typeface.NORMAL, Paint.Align.LEFT);
        text(c, unit.equals("Hz") ? "300 Hz" : "+12 dB", r.right - 42, r.bottom - 43, 18, MUTED, Typeface.NORMAL, Paint.Align.RIGHT);
        addRegion(action, 0, new RectF(cx - 135, cy - 135, cx + 135, cy + 135));
    }

    private void drawEq(Canvas c) {
        pageTitle(c, "Eq", "SHAPE YOUR SOUND", 220);
        RectF save = new RectF(458, 205, 664, 274);
        RectF load = new RectF(680, 205, 892, 274);
        RectF more = new RectF(914, 205, 1008, 274);
        smallButton(c, save, "+  Save Preset", GREEN, A_EQ_SAVE, 0);
        smallButton(c, load, "Load Preset", PURPLE, A_EQ_LOAD, 0);
        smallButton(c, more, "...", MUTED, A_EQ_MORE, 0);

        float tabX = 42;
        for (int i = 0; i < 7; i++) {
            RectF r = new RectF(tabX + i * 145, 305, tabX + i * 145 + 128, 410);
            boolean sel = state.eqChannel == i;
            roundedCard(c, r, sel ? Color.argb(180, 0, 85, 160) : Color.argb(155, 6, 34, 59), sel ? BLUE : Color.rgb(26, 70, 109), 15, sel ? 4 : 2);
            text(c, channelTop[i], r.centerX(), r.top + 38, 20, sel ? TEXT : MUTED, Typeface.BOLD, Paint.Align.CENTER);
            text(c, channelBottom[i], r.centerX(), r.top + 77, 24, sel ? TEXT : MUTED, Typeface.BOLD, Paint.Align.CENTER);
            addRegion(A_EQ_CHANNEL, i, r);
        }

        RectF graphCard = new RectF(40, 430, 1040, 975);
        roundedCard(c, graphCard, Color.argb(185, 4, 39, 71), BORDER, 25, 2);
        text(c, "15 Band Equalizer", 67, 478, 29, TEXT, Typeface.BOLD, Paint.Align.LEFT);
        RectF graph = new RectF(90, 515, 1000, 920);
        drawEqGraph(c, graph);
        addRegion(A_EQ_GRAPH, 0, graph);

        RectF controls = new RectF(40, 995, 1040, 1390);
        roundedCard(c, controls, Color.argb(190, 4, 39, 71), BORDER, 25, 2);
        text(c, "Band Controls", 65, 1043, 28, TEXT, Typeface.BOLD, Paint.Align.LEFT);
        text(c, "Band " + (state.selectedBand + 1) + " of 15", 825, 1043, 18, MUTED, Typeface.NORMAL, Paint.Align.LEFT);
        text(c, "<", 955, 1048, 30, MUTED, Typeface.BOLD, Paint.Align.CENTER);
        text(c, ">", 1002, 1048, 30, MUTED, Typeface.BOLD, Paint.Align.CENTER);
        addRegion(A_EQ_MINUS, 10, new RectF(930, 1010, 978, 1068));
        addRegion(A_EQ_PLUS, 10, new RectF(980, 1010, 1028, 1068));

        int ch = state.eqChannel;
        int b = state.selectedBand;
        float[] values = {state.eqFrequencyHz[ch][b], state.eqGainDb[ch][b], state.eqQ[ch][b]};
        String[] labels = {"Frequency", "Gain", "Q (Quality Factor)"};
        String[] valueLabels = {formatFreq(values[0]), fmtDb(values[1]), String.format(Locale.US, "%.1f", values[2])};
        int[] colors = {BLUE, GREEN, PURPLE};
        float[] mins = {20, -12, 0.1f};
        float[] maxs = {20000, 12, 10};
        int[] actions = {A_EQ_FREQ, A_EQ_GAIN, A_EQ_Q};
        for (int i = 0; i < 3; i++) {
            float x = 62 + i * 328;
            RectF block = new RectF(x, 1085, x + 300, 1360);
            roundedCard(c, block, Color.argb(110, 4, 32, 58), Color.rgb(20, 72, 112), 18, 1.5f);
            circleIcon(c, x + 52, 1133, 32, colors[i], i == 0 ? "F" : i == 1 ? "G" : "Q");
            text(c, labels[i], x + 102, 1127, i == 2 ? 17 : 20, MUTED, Typeface.NORMAL, Paint.Align.LEFT);
            text(c, valueLabels[i], x + 102, 1162, 29, TEXT, Typeface.BOLD, Paint.Align.LEFT);
            RectF s = new RectF(x + 40, 1198, x + 260, 1256);
            drawSlider(c, s, values[i], mins[i], maxs[i], colors[i], i == 0 ? "20 Hz" : i == 1 ? "-12 dB" : "0.1", i == 0 ? "20 kHz" : i == 1 ? "+12 dB" : "10.0", actions[i], 0);
            RectF minus = new RectF(x + 22, 1283, x + 82, 1342);
            RectF plus = new RectF(x + 218, 1283, x + 278, 1342);
            circleButton(c, minus, "−", MUTED);
            circleButton(c, plus, "+", MUTED);
            addRegion(A_EQ_MINUS, i, minus);
            addRegion(A_EQ_PLUS, i, plus);
        }

        RectF output = new RectF(40, 1415, 1040, 1638);
        roundedCard(c, output, Color.argb(190, 4, 39, 71), BORDER, 25, 2);
        circleIcon(c, 112, 1494, 39, BLUE, "V");
        text(c, "Output Level - " + channelTop[ch] + " [" + channelBottom[ch] + "]", 178, 1481, 25, TEXT, Typeface.BOLD, Paint.Align.LEFT);
        valuePill(c, 875, 1450, 130, 55, fmtDb(state.outputDb[ch]), CYAN);
        RectF os = new RectF(145, 1540, 995, 1600);
        drawSlider(c, os, state.outputDb[ch], -60, 12, BLUE, "-60 dB", "+12 dB", A_EQ_OUTPUT, 0);
    }

    private void drawEqGraph(Canvas c, RectF g) {
        // Grid
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.argb(100, 1, 20, 38));
        c.drawRect(g, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.4f);
        p.setColor(Color.argb(65, 69, 148, 208));
        for (int i = 0; i <= 10; i++) {
            float x = g.left + i * g.width() / 10f;
            c.drawLine(x, g.top, x, g.bottom, p);
        }
        for (int i = 0; i <= 8; i++) {
            float y = g.top + i * g.height() / 8f;
            c.drawLine(g.left, y, g.right, y, p);
        }
        p.setColor(Color.argb(130, 115, 190, 245));
        c.drawLine(g.left, gainToY(g, 0), g.right, gainToY(g, 0), p);
        p.setStyle(Paint.Style.FILL);

        text(c, "+12", g.left - 18, g.top + 10, 16, MUTED, Typeface.NORMAL, Paint.Align.RIGHT);
        text(c, "+6", g.left - 18, g.top + g.height() * .25f + 5, 16, MUTED, Typeface.NORMAL, Paint.Align.RIGHT);
        text(c, "0", g.left - 18, g.centerY() + 5, 16, MUTED, Typeface.NORMAL, Paint.Align.RIGHT);
        text(c, "-6", g.left - 18, g.top + g.height() * .75f + 5, 16, MUTED, Typeface.NORMAL, Paint.Align.RIGHT);
        text(c, "-12", g.left - 18, g.bottom + 5, 16, MUTED, Typeface.NORMAL, Paint.Align.RIGHT);
        text(c, "dB", g.left - 18, g.centerY() - 21, 16, MUTED, Typeface.BOLD, Paint.Align.RIGHT);

        String[] fx = {"20", "40", "80", "160", "315", "630", "1k", "2.5k", "5k", "10k", "20k"};
        float[] ff = {20, 40, 80, 160, 315, 630, 1000, 2500, 5000, 10000, 20000};
        for (int i = 0; i < ff.length; i++) {
            float x = freqToX(g, ff[i]);
            text(c, fx[i], x, g.bottom + 31, 15, MUTED, Typeface.NORMAL, Paint.Align.CENTER);
        }
        text(c, "Frequency (Hz)", g.centerX(), g.bottom + 62, 16, MUTED, Typeface.NORMAL, Paint.Align.CENTER);

        int ch = state.eqChannel;
        path.reset();
        for (int i = 0; i < 15; i++) {
            float x = freqToX(g, state.eqFrequencyHz[ch][i]);
            float y = gainToY(g, state.eqGainDb[ch][i]);
            if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
        }
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(7f);
        p.setShader(new LinearGradient(g.left, 0, g.right, 0, new int[]{BLUE, CYAN, GREEN, ORANGE, PINK, PURPLE}, null, Shader.TileMode.CLAMP));
        c.drawPath(path, p);
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < 15; i++) {
            float x = freqToX(g, state.eqFrequencyHz[ch][i]);
            float y = gainToY(g, state.eqGainDb[ch][i]);
            int color = gradientBandColor(i);
            p.setColor(Color.argb(i == state.selectedBand ? 80 : 40, Color.red(color), Color.green(color), Color.blue(color)));
            c.drawCircle(x, y, i == state.selectedBand ? 22 : 16, p);
            p.setColor(color);
            c.drawCircle(x, y, i == state.selectedBand ? 12 : 9, p);
            if (i == state.selectedBand) {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(3);
                p.setColor(TEXT);
                c.drawCircle(x, y, 18, p);
                p.setStyle(Paint.Style.FILL);
            }
        }
    }

    private void drawCrossover(Canvas c) {
        pageTitle(c, "Crossover", "Configure crossover filters and time alignment for each channel.", 205);
        RectF preset = new RectF(775, 195, 1020, 266);
        smallButton(c, preset, "Crossover Preset  >", MUTED, A_X_PRESET, 0);

        RectF graphCard = new RectF(40, 295, 1040, 745);
        roundedCard(c, graphCard, Color.argb(190, 4, 39, 71), BORDER, 25, 2);
        letterSpacedText(c, "CROSSOVER RESPONSE", 70, 338, 17, MUTED, 3);
        text(c, "View", 648, 337, 15, MUTED, Typeface.NORMAL, Paint.Align.LEFT);
        RectF mag = new RectF(715, 305, 868, 355);
        RectF phase = new RectF(870, 305, 1006, 355);
        chipButton(c, mag, "Magnitude", state.magnitudeView, BLUE);
        chipButton(c, phase, "Phase", !state.magnitudeView, BLUE);
        addRegion(A_X_VIEW, 0, mag);
        addRegion(A_X_VIEW, 1, phase);
        drawCrossoverGraph(c, new RectF(100, 375, 1005, 665));
        for (int i = 0; i < 4; i++) {
            p.setColor(crossoverColors[i]);
            c.drawCircle(130 + i * 235, 705, 11, p);
            text(c, crossoverNames[i], 155 + i * 235, 711, 18, MUTED, Typeface.BOLD, Paint.Align.LEFT);
        }

        RectF settings = new RectF(40, 765, 1040, 1302);
        roundedCard(c, settings, Color.argb(190, 4, 39, 71), BORDER, 25, 2);
        letterSpacedText(c, "CROSSOVER SETTINGS", 66, 807, 17, MUTED, 3);
        text(c, "Link L/R", 845, 807, 17, MUTED, Typeface.NORMAL, Paint.Align.RIGHT);
        RectF link = new RectF(875, 780, 1018, 830);
        drawToggle(c, link, state.linkLR, BLUE);
        addRegion(A_X_LINK, 0, link);

        for (int i = 0; i < 4; i++) {
            float x = 55 + i * 246;
            RectF r = new RectF(x, 842, x + 225, 1278);
            drawCrossoverCard(c, r, i);
        }

        RectF delay = new RectF(40, 1322, 1040, 1635);
        roundedCard(c, delay, Color.argb(190, 4, 39, 71), BORDER, 25, 2);
        letterSpacedText(c, "CHANNEL DELAY / TIME ALIGNMENT", 65, 1363, 16, MUTED, 3);
        RectF ms = new RectF(726, 1334, 821, 1380);
        RectF cm = new RectF(825, 1334, 921, 1380);
        RectF in = new RectF(925, 1334, 1018, 1380);
        chipButton(c, ms, "ms", state.delayUnit == 0, BLUE);
        chipButton(c, cm, "cm", state.delayUnit == 1, BLUE);
        chipButton(c, in, "in", state.delayUnit == 2, BLUE);
        addRegion(A_X_DELAY_UNIT, 0, ms);
        addRegion(A_X_DELAY_UNIT, 1, cm);
        addRegion(A_X_DELAY_UNIT, 2, in);

        for (int i = 0; i < 4; i++) {
            float x = 58 + i * 244;
            drawDelayBlock(c, x, 1402, i);
        }
        RectF reset = new RectF(65, 1568, 335, 1618);
        RectF auto = new RectF(762, 1568, 1014, 1618);
        smallButton(c, reset, "Reset Delays", MUTED, A_X_RESET, 0);
        smallButton(c, auto, "Auto Align", CYAN, A_X_AUTO, 0);
    }

    private void drawCrossoverGraph(Canvas c, RectF g) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.argb(110, 0, 16, 33));
        c.drawRect(g, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.4f);
        p.setColor(Color.argb(70, 65, 144, 205));
        for (int i = 0; i <= 10; i++) {
            float x = g.left + i * g.width() / 10f;
            c.drawLine(x, g.top, x, g.bottom, p);
        }
        for (int i = 0; i <= 6; i++) {
            float y = g.top + i * g.height() / 6f;
            c.drawLine(g.left, y, g.right, y, p);
        }
        p.setStyle(Paint.Style.FILL);
        String[] xs = {"20", "50", "100", "500", "1k", "5k", "10k", "20k"};
        float[] xf = {20, 50, 100, 500, 1000, 5000, 10000, 20000};
        for (int i = 0; i < xf.length; i++) {
            text(c, xs[i], freqToX(g, xf[i]), g.bottom + 28, 14, MUTED, Typeface.NORMAL, Paint.Align.CENTER);
        }
        text(c, "Frequency (Hz)", g.centerX(), g.bottom + 56, 15, MUTED, Typeface.NORMAL, Paint.Align.CENTER);
        if (state.magnitudeView) {
            text(c, "+12", g.left - 15, g.top + 8, 14, MUTED, Typeface.NORMAL, Paint.Align.RIGHT);
            text(c, "0", g.left - 15, g.top + 74, 14, MUTED, Typeface.NORMAL, Paint.Align.RIGHT);
            text(c, "-12", g.left - 15, g.top + 150, 14, MUTED, Typeface.NORMAL, Paint.Align.RIGHT);
            text(c, "-24", g.left - 15, g.bottom - 3, 14, MUTED, Typeface.NORMAL, Paint.Align.RIGHT);
            text(c, "dB", g.left - 15, g.centerY(), 14, MUTED, Typeface.BOLD, Paint.Align.RIGHT);
        } else {
            text(c, "+180°", g.left - 15, g.top + 8, 14, MUTED, Typeface.NORMAL, Paint.Align.RIGHT);
            text(c, "+90°", g.left - 15, g.top + g.height() * .25f + 5, 14, MUTED, Typeface.NORMAL, Paint.Align.RIGHT);
            text(c, "0°", g.left - 15, g.centerY() + 5, 14, MUTED, Typeface.NORMAL, Paint.Align.RIGHT);
            text(c, "-90°", g.left - 15, g.top + g.height() * .75f + 5, 14, MUTED, Typeface.NORMAL, Paint.Align.RIGHT);
            text(c, "-180°", g.left - 15, g.bottom - 3, 14, MUTED, Typeface.NORMAL, Paint.Align.RIGHT);
        }

        // UI-only response curves, derived live from the cutoff values.
        for (int band = 0; band < 4; band++) {
            path.reset();
            for (int step = 0; step <= 180; step++) {
                float t = step / 180f;
                float logF = (float) (Math.log10(20) + t * (Math.log10(20000) - Math.log10(20)));
                float f = (float) Math.pow(10, logF);
                float x = g.left + t * g.width();
                float y;
                if (state.magnitudeView) {
                    int mode = state.crossoverMode[band];
                    float db;
                    if (mode == 0) {
                        db = lowPassUiDb(f, state.crossoverHighHz[band], state.crossoverSlopeDb[band]);
                    } else if (mode == 1) {
                        db = lowPassUiDb(f, state.crossoverHighHz[band], state.crossoverSlopeDb[band])
                                + highPassUiDb(f, state.crossoverLowHz[band], state.crossoverSlopeDb[band]);
                    } else if (mode == 2) {
                        db = highPassUiDb(f, state.crossoverLowHz[band], state.crossoverSlopeDb[band]);
                    } else {
                        db = 0f;
                    }
                    db = DspUiState.clamp(db, -36f, 12f);
                    y = g.top + (12f - db) / 48f * g.height();
                } else {
                    float phase = DspUiState.clamp(phaseUiDegrees(band, f), -180f, 180f);
                    y = g.top + (180f - phase) / 360f * g.height();
                }
                if (step == 0) path.moveTo(x, y); else path.lineTo(x, y);
            }
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(5.5f);
            p.setColor(crossoverColors[band]);
            c.drawPath(path, p);
            p.setStyle(Paint.Style.FILL);
        }
    }

    private float lowPassUiDb(float f, float fc, int slope) {
        if (f <= fc) return 0f;
        float oct = (float) (Math.log(f / fc) / Math.log(2));
        return -Math.abs(oct) * slope;
    }

    private float highPassUiDb(float f, float fc, int slope) {
        if (f >= fc) return 0f;
        float oct = (float) (Math.log(fc / f) / Math.log(2));
        return -Math.abs(oct) * slope;
    }

    private float phaseUiDegrees(int band, float f) {
        int mode = state.crossoverMode[band];
        if (mode == 3) return 0f;
        float low = Math.max(20f, state.crossoverLowHz[band]);
        float high = Math.max(low + 1f, state.crossoverHighHz[band]);
        float lp = (float) (-90.0 * (2.0 / Math.PI) * Math.atan(f / high));
        float hp = (float) (90.0 * (2.0 / Math.PI) * Math.atan(low / Math.max(1f, f)));
        if (mode == 0) return lp;
        if (mode == 1) return hp + lp;
        return hp;
    }

    private String filterName(int mode) {
        return new String[]{"Low Pass", "Band Pass", "High Pass", "Bypass"}[Math.max(0, Math.min(3, mode))];
    }

    private void drawCrossoverCard(Canvas c, RectF r, int i) {
        int color = crossoverColors[i];
        roundedCard(c, r, Color.argb(130, 4, 32, 58), Color.rgb(18, 72, 111), 15, 1.5f);
        p.setColor(color);
        c.drawCircle(r.left + 23, r.top + 26, 11, p);
        text(c, crossoverNames[i], r.left + 43, r.top + 33, 19, color, Typeface.BOLD, Paint.Align.LEFT);

        String filter = filterName(state.crossoverMode[i]);
        RectF filterBox = new RectF(r.left + 12, r.top + 50, r.right - 12, r.top + 103);
        roundedCard(c, filterBox, Color.argb(160, 4, 28, 52), Color.rgb(30, 75, 111), 10, 1.3f);
        text(c, filter, filterBox.left + 14, filterBox.centerY() + 7, 17, TEXT, Typeface.NORMAL, Paint.Align.LEFT);
        text(c, "v", filterBox.right - 14, filterBox.centerY() + 7, 16, MUTED, Typeface.BOLD, Paint.Align.RIGHT);
        addRegion(A_X_FILTER, i, filterBox);

        RectF slopeBox = new RectF(r.left + 12, r.top + 112, r.right - 12, r.top + 163);
        roundedCard(c, slopeBox, Color.argb(160, 4, 28, 52), Color.rgb(30, 75, 111), 10, 1.3f);
        text(c, state.crossoverSlopeDb[i] + " dB/oct", slopeBox.left + 14, slopeBox.centerY() + 7, 16, TEXT, Typeface.NORMAL, Paint.Align.LEFT);
        text(c, "v", slopeBox.right - 14, slopeBox.centerY() + 7, 16, MUTED, Typeface.BOLD, Paint.Align.RIGHT);
        addRegion(A_X_SLOPE, i, slopeBox);

        int mode = state.crossoverMode[i];
        if (mode == 0) {
            text(c, formatFreq(state.crossoverHighHz[i]), r.centerX(), r.top + 201, 24, TEXT, Typeface.BOLD, Paint.Align.CENTER);
            RectF cutoff = new RectF(r.left + 20, r.top + 216, r.right - 20, r.top + 272);
            drawSlider(c, cutoff, state.crossoverHighHz[i], 20, 20000, color, "20 Hz", "20 kHz", A_X_HIGH, i);
        } else if (mode == 1) {
            text(c, formatFreq(state.crossoverLowHz[i]) + " - " + formatFreq(state.crossoverHighHz[i]), r.centerX(), r.top + 201, 20, TEXT, Typeface.BOLD, Paint.Align.CENTER);
            RectF low = new RectF(r.left + 20, r.top + 216, r.right - 20, r.top + 266);
            RectF high = new RectF(r.left + 20, r.top + 270, r.right - 20, r.top + 320);
            drawSlider(c, low, state.crossoverLowHz[i], 20, 20000, color, "20 Hz", "20 kHz", A_X_LOW, i);
            drawSlider(c, high, state.crossoverHighHz[i], 20, 20000, color, "20 Hz", "20 kHz", A_X_HIGH, i);
        } else if (mode == 2) {
            text(c, formatFreq(state.crossoverLowHz[i]), r.centerX(), r.top + 201, 24, TEXT, Typeface.BOLD, Paint.Align.CENTER);
            RectF cutoff = new RectF(r.left + 20, r.top + 216, r.right - 20, r.top + 272);
            drawSlider(c, cutoff, state.crossoverLowHz[i], 20, 20000, color, "20 Hz", "20 kHz", A_X_LOW, i);
        } else {
            text(c, "Full Range", r.centerX(), r.top + 201, 22, TEXT, Typeface.BOLD, Paint.Align.CENTER);
            p.setStrokeWidth(4);
            p.setColor(Color.argb(190, Color.red(color), Color.green(color), Color.blue(color)));
            c.drawLine(r.left + 25, r.top + 250, r.right - 25, r.top + 250, p);
        }

        text(c, "Slope", r.left + 18, r.bottom - 88, 16, MUTED, Typeface.NORMAL, Paint.Align.LEFT);
        float x = r.left + 18;
        int[] slopes = {12, 24, 36};
        for (int s = 0; s < 3; s++) {
            RectF b = new RectF(x + s * 64, r.bottom - 72, x + s * 64 + 56, r.bottom - 27);
            boolean active = state.crossoverSlopeDb[i] == slopes[s];
            roundedCard(c, b, active ? Color.argb(160, Color.red(color), Color.green(color), Color.blue(color)) : Color.argb(120, 4, 28, 52), active ? color : Color.rgb(30, 75, 111), 8, active ? 2 : 1);
            text(c, slopes[s] + "", b.centerX(), b.centerY() + 6, 13, active ? TEXT : MUTED, Typeface.BOLD, Paint.Align.CENTER);
            addRegion(A_X_SLOPE, 100 + i * 10 + s, b);
        }
    }

    private void drawDelayBlock(Canvas c, float x, float y, int i) {
        int color = crossoverColors[i];
        p.setColor(color);
        c.drawCircle(x + 12, y + 10, 9, p);
        text(c, crossoverNames[i], x + 32, y + 17, 17, color, Typeface.BOLD, Paint.Align.LEFT);

        float msValue = state.delayMs[i];
        float cmValue = msValue * 34.3f;
        float inchValue = cmValue / 2.54f;
        String primary;
        String leftLabel;
        String rightLabel;
        String secondary;
        if (state.delayUnit == 1) {
            primary = String.format(Locale.US, "%.1f cm", cmValue);
            leftLabel = "0 cm";
            rightLabel = "686 cm";
            secondary = String.format(Locale.US, "%.2f ms", msValue);
        } else if (state.delayUnit == 2) {
            primary = String.format(Locale.US, "%.1f in", inchValue);
            leftLabel = "0 in";
            rightLabel = "270 in";
            secondary = String.format(Locale.US, "%.2f ms", msValue);
        } else {
            primary = String.format(Locale.US, "%.2f ms", msValue);
            leftLabel = "0.00";
            rightLabel = "20.00";
            secondary = String.format(Locale.US, "%.1f cm", cmValue);
        }

        text(c, primary, x + 10, y + 54, 20, TEXT, Typeface.BOLD, Paint.Align.LEFT);
        RectF slider = new RectF(x + 5, y + 66, x + 210, y + 111);
        drawSlider(c, slider, msValue, 0, 20, color, leftLabel, rightLabel, A_X_DELAY, i);
        text(c, secondary, x + 109, y + 137, 15, MUTED, Typeface.NORMAL, Paint.Align.CENTER);
    }

    private void drawBottomNav(Canvas c) {
        RectF bar = new RectF(0, 1750, 1080, 1920);
        p.setShader(new LinearGradient(0, 1750, 0, 1920, Color.argb(245, 4, 36, 66), Color.argb(255, 2, 17, 34), Shader.TileMode.CLAMP));
        p.setStyle(Paint.Style.FILL);
        c.drawRoundRect(new RectF(-20, 1742, 1100, 1940), 58, 58, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2);
        p.setColor(Color.rgb(15, 75, 119));
        c.drawRoundRect(new RectF(-20, 1742, 1100, 1940), 58, 58, p);
        p.setStyle(Paint.Style.FILL);

        for (int i = 0; i < 4; i++) {
            float cx = 138 + i * 268;
            int col = state.page == i ? BLUE : Color.rgb(166, 197, 237);
            drawNavIcon(c, i, cx, 1806, col);
            text(c, pages[i], cx, 1878, 24, col, state.page == i ? Typeface.BOLD : Typeface.NORMAL, Paint.Align.CENTER);
            if (state.page == i) {
                p.setColor(BLUE);
                c.drawRoundRect(new RectF(cx - 58, 1900, cx + 58, 1906), 4, 4, p);
            }
            addRegion(A_NAV, i, new RectF(i * 270, 1745, (i + 1) * 270, 1920));
        }
    }

    private void drawNavIcon(Canvas c, int i, float x, float y, int color) {
        p.setColor(color);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(7);
        if (i == 0) {
            path.reset();
            path.moveTo(x - 28, y + 8);
            path.lineTo(x, y - 18);
            path.lineTo(x + 28, y + 8);
            path.lineTo(x + 28, y + 38);
            path.lineTo(x + 8, y + 38);
            path.lineTo(x + 8, y + 12);
            path.lineTo(x - 8, y + 12);
            path.lineTo(x - 8, y + 38);
            path.lineTo(x - 28, y + 38);
            path.close();
            c.drawPath(path, p);
        } else if (i == 1) {
            for (int k = -1; k <= 1; k++) {
                float xx = x + k * 25;
                c.drawLine(xx, y - 24, xx, y + 38, p);
                c.drawCircle(xx, y + (k == 0 ? -2 : k < 0 ? 18 : -12), 8, p);
            }
        } else if (i == 2) {
            c.drawLine(x - 26, y + 37, x - 26, y + 8, p);
            c.drawLine(x, y + 37, x, y - 23, p);
            c.drawLine(x + 26, y + 37, x + 26, y - 3, p);
        } else {
            path.reset();
            path.moveTo(x - 35, y - 22);
            path.cubicTo(x - 5, y - 22, x - 7, y + 36, x + 35, y + 36);
            c.drawPath(path, p);
            path.reset();
            path.moveTo(x - 35, y + 36);
            path.cubicTo(x - 7, y + 36, x - 5, y - 22, x + 35, y - 22);
            c.drawPath(path, p);
        }
        p.setStyle(Paint.Style.FILL);
    }

    private void pageTitle(Canvas c, String title, String subtitle, float y) {
        text(c, title, 46, y, 52, TEXT, Typeface.BOLD, Paint.Align.LEFT);
        text(c, subtitle, 46, y + 48, subtitle.equals(subtitle.toUpperCase(Locale.US)) ? 18 : 23, MUTED, Typeface.NORMAL, Paint.Align.LEFT);
    }

    private void drawAudioBars(Canvas c, float x, float y, float w, float h, int color) {
        p.setColor(color);
        int n = 18;
        for (int i = 0; i < n; i++) {
            float bh = 13 + (float) Math.abs(Math.sin(i * .78)) * (h - 13);
            float xx = x + i * (w / n);
            c.drawRoundRect(new RectF(xx, y + h - bh, xx + 6, y + h), 3, 3, p);
        }
    }

    private void drawWaveform(Canvas c, float x, float y, float w, float h, int color, int n) {
        p.setColor(Color.argb(170, Color.red(color), Color.green(color), Color.blue(color)));
        p.setStrokeWidth(3);
        for (int i = 0; i < n; i++) {
            float amp = (float) ((.25 + .75 * Math.abs(Math.sin(i * .76 + 1.2))) * h / 2f);
            float xx = x + i * w / (n - 1f);
            c.drawLine(xx, y + h / 2f - amp, xx, y + h / 2f + amp, p);
        }
    }

    private void drawSlider(Canvas c, RectF r, float value, float min, float max, int color, String leftLabel, String rightLabel, int action, int index) {
        float trackY = r.top + 17;
        float left = r.left + 8;
        float right = r.right - 8;
        boolean logarithmic = action == A_EQ_FREQ || action == A_X_LOW || action == A_X_HIGH;
        float norm;
        if (logarithmic && min > 0f && max > min) {
            double lo = Math.log10(min);
            double hi = Math.log10(max);
            norm = (float) ((Math.log10(Math.max(min, value)) - lo) / (hi - lo));
        } else {
            norm = (value - min) / (max - min);
        }
        norm = DspUiState.clamp(norm, 0, 1);
        float knobX = left + norm * (right - left);

        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(10);
        p.setColor(Color.rgb(26, 69, 102));
        c.drawLine(left, trackY, right, trackY, p);
        p.setColor(color);
        c.drawLine(left, trackY, knobX, trackY, p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.argb(45, Color.red(color), Color.green(color), Color.blue(color)));
        c.drawCircle(knobX, trackY, 27, p);
        p.setColor(TEXT);
        c.drawCircle(knobX, trackY, 16, p);
        p.setColor(color);
        c.drawCircle(knobX, trackY, 10, p);
        p.setStrokeCap(Paint.Cap.BUTT);

        text(c, leftLabel, r.left, r.bottom - 1, 15, MUTED, Typeface.NORMAL, Paint.Align.LEFT);
        text(c, rightLabel, r.right, r.bottom - 1, 15, MUTED, Typeface.NORMAL, Paint.Align.RIGHT);
        addRegion(action, index, new RectF(r.left, r.top - 18, r.right, r.bottom + 12));
    }

    private void drawKnob(Canvas c, float cx, float cy, float radius, float value, float min, float max, int color) {
        float norm = DspUiState.clamp((value - min) / (max - min), 0, 1);
        float start = 135f;
        float sweep = 270f;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(14);
        p.setColor(Color.rgb(28, 65, 93));
        RectF arc = new RectF(cx - radius, cy - radius, cx + radius, cy + radius);
        c.drawArc(arc, start, sweep, false, p);
        p.setColor(color);
        c.drawArc(arc, start, sweep * norm, false, p);
        p.setStyle(Paint.Style.FILL);
        p.setShader(new RadialGradient(cx - radius * .25f, cy - radius * .25f, radius * 1.2f, Color.rgb(36, 54, 72), Color.rgb(5, 14, 24), Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, radius - 25, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(3);
        p.setColor(Color.rgb(52, 84, 111));
        c.drawCircle(cx, cy, radius - 25, p);
        float angle = (float) Math.toRadians(start + sweep * norm);
        float px = cx + (float) Math.cos(angle) * (radius - 45);
        float py = cy + (float) Math.sin(angle) * (radius - 45);
        p.setStyle(Paint.Style.FILL);
        p.setColor(TEXT);
        c.drawCircle(px, py, 10, p);
        p.setColor(color);
        c.drawCircle(px, py, 6, p);
    }

    private void drawToggle(Canvas c, RectF r, boolean on, int color) {
        p.setColor(on ? Color.argb(210, Color.red(color), Color.green(color), Color.blue(color)) : Color.rgb(27, 55, 78));
        c.drawRoundRect(r, r.height() / 2, r.height() / 2, p);
        p.setColor(TEXT);
        float cx = on ? r.right - r.height() / 2 : r.left + r.height() / 2;
        c.drawCircle(cx, r.centerY(), r.height() * .37f, p);
    }

    private void chipButton(Canvas c, RectF r, String text, boolean selected, int color) {
        roundedCard(c, r, selected ? Color.argb(180, 0, 84, 159) : Color.argb(110, 4, 31, 54), selected ? color : Color.rgb(27, 68, 101), 13, selected ? 2 : 1);
        text(c, text, r.centerX(), r.centerY() + 5, 15, selected ? TEXT : MUTED, selected ? Typeface.BOLD : Typeface.NORMAL, Paint.Align.CENTER);
    }

    private void smallButton(Canvas c, RectF r, String label, int color, int action, int index) {
        roundedCard(c, r, Color.argb(150, 4, 34, 60), Color.argb(180, Color.red(color), Color.green(color), Color.blue(color)), 16, 1.8f);
        text(c, label, r.centerX(), r.centerY() + 7, 18, TEXT, Typeface.BOLD, Paint.Align.CENTER);
        addRegion(action, index, r);
    }

    private void circleButton(Canvas c, RectF r, String label, int color) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2);
        p.setColor(Color.rgb(39, 82, 117));
        c.drawCircle(r.centerX(), r.centerY(), Math.min(r.width(), r.height()) / 2 - 4, p);
        p.setStyle(Paint.Style.FILL);
        text(c, label, r.centerX(), r.centerY() + 9, 29, color, Typeface.BOLD, Paint.Align.CENTER);
    }

    private void valuePill(Canvas c, float x, float y, float w, float h, String value, int color) {
        RectF r = new RectF(x, y, x + w, y + h);
        roundedCard(c, r, Color.argb(125, 4, 29, 52), Color.argb(200, Color.red(color), Color.green(color), Color.blue(color)), 14, 2);
        text(c, value, r.centerX(), r.centerY() + 8, 20, color, Typeface.BOLD, Paint.Align.CENTER);
    }

    private void circleIcon(Canvas c, float x, float y, float radius, int color, String glyph) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.argb(45, Color.red(color), Color.green(color), Color.blue(color)));
        c.drawCircle(x, y, radius + 8, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2.5f);
        p.setColor(Color.argb(205, Color.red(color), Color.green(color), Color.blue(color)));
        c.drawCircle(x, y, radius + 7, p);
        p.setStyle(Paint.Style.FILL);
        text(c, glyph, x, y + radius * .33f, radius * .92f, color, Typeface.BOLD, Paint.Align.CENTER);
    }

    private void roundedCard(Canvas c, RectF r, int fill, int stroke, float radius, float strokeWidth) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(fill);
        c.drawRoundRect(r, radius, radius, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(strokeWidth);
        p.setColor(stroke);
        c.drawRoundRect(r, radius, radius, p);
        p.setStyle(Paint.Style.FILL);
    }

    private void text(Canvas c, String s, float x, float y, float size, int color, int style, Paint.Align align) {
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        p.setTextSize(size);
        p.setTypeface(Typeface.create(Typeface.DEFAULT, style));
        p.setTextAlign(align);
        c.drawText(s, x, y, p);
    }

    private void letterSpacedText(Canvas c, String s, float x, float y, float size, int color, float spacing) {
        p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
        p.setTextSize(size);
        p.setColor(color);
        p.setTextAlign(Paint.Align.LEFT);
        float px = x;
        for (int i = 0; i < s.length(); i++) {
            String ch = String.valueOf(s.charAt(i));
            c.drawText(ch, px, y, p);
            px += p.measureText(ch) + spacing;
        }
    }

    private int gradientBandColor(int i) {
        float t = i / 14f;
        if (t < .25f) return blend(BLUE, CYAN, t / .25f);
        if (t < .5f) return blend(CYAN, GREEN, (t - .25f) / .25f);
        if (t < .75f) return blend(GREEN, ORANGE, (t - .5f) / .25f);
        return blend(ORANGE, PURPLE, (t - .75f) / .25f);
    }

    private int blend(int a, int b, float t) {
        int r = (int) (Color.red(a) + (Color.red(b) - Color.red(a)) * t);
        int g = (int) (Color.green(a) + (Color.green(b) - Color.green(a)) * t);
        int bl = (int) (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t);
        return Color.rgb(r, g, bl);
    }

    private float freqToX(RectF r, float f) {
        float minLog = (float) Math.log10(20f);
        float maxLog = (float) Math.log10(20000f);
        float v = ((float) Math.log10(DspUiState.clamp(f, 20, 20000)) - minLog) / (maxLog - minLog);
        return r.left + v * r.width();
    }

    private float xToFreq(RectF r, float x) {
        float t = DspUiState.clamp((x - r.left) / r.width(), 0, 1);
        float log = (float) (Math.log10(20f) + t * (Math.log10(20000f) - Math.log10(20f)));
        return (float) Math.pow(10, log);
    }

    private float gainToY(RectF r, float db) {
        return r.top + (12f - DspUiState.clamp(db, -12, 12)) / 24f * r.height();
    }

    private float yToGain(RectF r, float y) {
        float t = DspUiState.clamp((y - r.top) / r.height(), 0, 1);
        return 12f - t * 24f;
    }

    private String fmtDb(float v) {
        return String.format(Locale.US, "%+.1f dB", v);
    }

    private String formatFreq(float f) {
        if (f >= 1000f) {
            float k = f / 1000f;
            if (k >= 10 || Math.abs(k - Math.round(k)) < .05f) return String.format(Locale.US, "%.0f kHz", k);
            return String.format(Locale.US, "%.1f kHz", k);
        }
        return String.format(Locale.US, "%.0f Hz", f);
    }

    private void drawBanner(Canvas c) {
        if (banner.isEmpty() || System.currentTimeMillis() > bannerUntil) return;
        RectF r = new RectF(285, 160, 795, 222);
        roundedCard(c, r, Color.argb(230, 4, 42, 73), Color.argb(210, 0, 226, 255), 20, 2);
        text(c, banner, r.centerX(), r.centerY() + 8, 20, TEXT, Typeface.BOLD, Paint.Align.CENTER);
        postInvalidateDelayed(120);
    }

    private void announce(String message) {
        banner = message;
        bannerUntil = System.currentTimeMillis() + 1300;
        invalidate();
    }

    private void saveFullPreset() {
        state.savePreset();
        DspPresetStore.save(getContext(), state);
    }

    private boolean loadFullPreset() {
        if (DspPresetStore.load(getContext(), state)) return true;
        return state.loadPreset();
    }

    private void addRegion(int action, int index, RectF r) {
        regions.add(new TouchRegion(action, index, new RectF(r)));
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX() * BASE_W / Math.max(1f, getWidth());
        float y = event.getY() * BASE_H / Math.max(1f, getHeight());

        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = x;
                downY = y;
                activeRegion = findRegion(x, y);
                if (activeRegion != null) {
                    performTouch(activeRegion, x, y, true);
                    getParent().requestDisallowInterceptTouchEvent(true);
                    return true;
                }
                break;
            case MotionEvent.ACTION_MOVE:
                if (activeRegion != null) {
                    performTouch(activeRegion, x, y, false);
                    return true;
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (activeRegion != null) {
                    performTouch(activeRegion, x, y, false);
                    activeRegion = null;
                    getParent().requestDisallowInterceptTouchEvent(false);
                    performClick();
                    return true;
                }
                break;
            default:
                break;
        }
        return true;
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    private TouchRegion findRegion(float x, float y) {
        for (int i = regions.size() - 1; i >= 0; i--) {
            TouchRegion r = regions.get(i);
            if (r.rect.contains(x, y)) return r;
        }
        return null;
    }

    private void performTouch(TouchRegion r, float x, float y, boolean isDown) {
        switch (r.action) {
            case A_NAV:
                if (isDown) state.page = r.index;
                break;
            case A_CONNECTION:
                if (isDown) {
                    state.connected = !state.connected;
                    announce(state.connected ? "UI demo: Connected" : "UI demo: Disconnected");
                }
                break;
            case A_INPUT:
                if (isDown) {
                    state.inputSource = r.index;
                    announce("Input: " + new String[]{"Bluetooth", "AUX", "Optical", "USB"}[r.index]);
                }
                break;
            case A_QUICK:
                if (isDown) {
                    if (r.index == 0) {
                        announce(loadFullPreset() ? "Preset loaded" : "No saved preset yet");
                    } else if (r.index == 1) {
                        saveFullPreset();
                        announce("Preset saved");
                    } else if (r.index == 2) {
                        announce("Device Settings • Phase 1");
                    } else {
                        announce("OKN_DSP V3 • Phase 1");
                    }
                }
                break;
            case A_MIX_MASTER:
                state.masterDb = valueFromSlider(r.rect, x, -60, 0);
                break;
            case A_MIX_BASS:
                state.bassDb = valueFromSlider(r.rect, x, -20, 20);
                break;
            case A_MIX_CUTOFF:
                state.bassCutoffHz = valueFromSlider(r.rect, x, 20, 300);
                break;
            case A_MIX_BASS_BOOST:
                state.bassBoostDb = valueFromSlider(r.rect, x, -12, 12);
                break;
            case A_MIX_MIDDLE:
                state.middleBoostDb = valueFromSlider(r.rect, x, -12, 12);
                break;
            case A_MIX_TREBLE:
                state.trebleBoostDb = valueFromSlider(r.rect, x, -12, 12);
                break;
            case A_EQ_CHANNEL:
                if (isDown) state.eqChannel = r.index;
                break;
            case A_EQ_SAVE:
                if (isDown) {
                    saveFullPreset();
                    announce("Preset saved");
                }
                break;
            case A_EQ_LOAD:
                if (isDown) announce(loadFullPreset() ? "Preset loaded" : "No saved preset yet");
                break;
            case A_EQ_MORE:
                if (isDown) {
                    state.resetEqChannel(state.eqChannel);
                    announce("EQ channel reset");
                }
                break;
            case A_EQ_GRAPH:
                updateEqFromGraph(r.rect, x, y, isDown);
                break;
            case A_EQ_FREQ:
                state.eqFrequencyHz[state.eqChannel][state.selectedBand] = logValueFromSlider(r.rect, x, 20, 20000);
                break;
            case A_EQ_GAIN:
                state.eqGainDb[state.eqChannel][state.selectedBand] = valueFromSlider(r.rect, x, -12, 12);
                break;
            case A_EQ_Q:
                state.eqQ[state.eqChannel][state.selectedBand] = valueFromSlider(r.rect, x, .1f, 10f);
                break;
            case A_EQ_OUTPUT:
                state.outputDb[state.eqChannel] = valueFromSlider(r.rect, x, -60, 12);
                break;
            case A_EQ_MINUS:
                if (isDown) adjustEqByButton(r.index, -1);
                break;
            case A_EQ_PLUS:
                if (isDown) adjustEqByButton(r.index, +1);
                break;
            case A_X_PRESET:
                if (isDown) {
                    state.applyReferenceCrossoverPreset();
                    announce("Reference crossover preset loaded");
                }
                break;
            case A_X_VIEW:
                if (isDown) state.magnitudeView = r.index == 0;
                break;
            case A_X_FILTER:
                if (isDown) {
                    state.crossoverMode[r.index] = (state.crossoverMode[r.index] + 1) % 4;
                    if (state.crossoverMode[r.index] == 1
                            && state.crossoverLowHz[r.index] >= state.crossoverHighHz[r.index]) {
                        float center = DspUiState.clamp(state.crossoverHighHz[r.index], 40f, 10000f);
                        state.crossoverLowHz[r.index] = Math.max(20f, center / 2f);
                        state.crossoverHighHz[r.index] = Math.min(20000f, center * 2f);
                    }
                    announce(crossoverNames[r.index] + ": " + filterName(state.crossoverMode[r.index]));
                }
                break;
            case A_X_LOW:
                updateCrossoverLow(r.index, r.rect, x);
                break;
            case A_X_HIGH:
                updateCrossoverHigh(r.index, r.rect, x);
                break;
            case A_X_SLOPE:
                if (isDown) updateSlope(r.index);
                break;
            case A_X_LINK:
                if (isDown) state.linkLR = !state.linkLR;
                break;
            case A_X_DELAY_UNIT:
                if (isDown) state.delayUnit = DspUiState.clampInt(r.index, 0, 2);
                break;
            case A_X_DELAY:
                state.delayMs[r.index] = valueFromSlider(r.rect, x, 0, 20);
                break;
            case A_X_RESET:
                if (isDown) {
                    for (int i = 0; i < state.delayMs.length; i++) state.delayMs[i] = 0f;
                    announce("All delays reset");
                }
                break;
            case A_X_AUTO:
                if (isDown) {
                    state.delayMs[0] = 2.50f;
                    state.delayMs[1] = 1.20f;
                    state.delayMs[2] = 0f;
                    state.delayMs[3] = .80f;
                    announce("Auto Align preview applied");
                }
                break;
            default:
                break;
        }
        invalidate();
    }

    private float valueFromSlider(RectF r, float x, float min, float max) {
        float t = DspUiState.clamp((x - r.left) / Math.max(1, r.width()), 0, 1);
        return min + t * (max - min);
    }

    private float logValueFromSlider(RectF r, float x, float min, float max) {
        float t = DspUiState.clamp((x - r.left) / Math.max(1, r.width()), 0, 1);
        double log = Math.log10(min) + t * (Math.log10(max) - Math.log10(min));
        return (float) Math.pow(10, log);
    }

    private void updateEqFromGraph(RectF g, float x, float y, boolean isDown) {
        int ch = state.eqChannel;
        if (isDown) {
            int nearest = 0;
            float best = Float.MAX_VALUE;
            for (int i = 0; i < 15; i++) {
                float px = freqToX(g, state.eqFrequencyHz[ch][i]);
                float py = gainToY(g, state.eqGainDb[ch][i]);
                float d = (px - x) * (px - x) + (py - y) * (py - y);
                if (d < best) {
                    best = d;
                    nearest = i;
                }
            }
            state.selectedBand = nearest;
        }
        int b = state.selectedBand;
        state.eqFrequencyHz[ch][b] = xToFreq(g, x);
        state.eqGainDb[ch][b] = yToGain(g, y);
    }

    private void adjustEqByButton(int index, int direction) {
        int ch = state.eqChannel;
        int b = state.selectedBand;
        if (index == 10) {
            state.selectedBand = Math.max(0, Math.min(14, state.selectedBand + direction));
            return;
        }
        if (index == 0) {
            float f = state.eqFrequencyHz[ch][b];
            state.eqFrequencyHz[ch][b] = DspUiState.clamp(f * (direction > 0 ? 1.08f : .92f), 20, 20000);
        } else if (index == 1) {
            state.eqGainDb[ch][b] = DspUiState.clamp(state.eqGainDb[ch][b] + direction * .5f, -12, 12);
        } else if (index == 2) {
            state.eqQ[ch][b] = DspUiState.clamp(state.eqQ[ch][b] + direction * .1f, .1f, 10f);
        }
    }

    private void updateCrossoverLow(int index, RectF r, float x) {
        float value = logValueFromSlider(r, x, 20, 20000);
        if (state.crossoverMode[index] == 1) {
            value = Math.min(value, Math.max(20f, state.crossoverHighHz[index] / 1.02f));
        }
        state.crossoverLowHz[index] = DspUiState.clamp(value, 20, 20000);
    }

    private void updateCrossoverHigh(int index, RectF r, float x) {
        float value = logValueFromSlider(r, x, 20, 20000);
        if (state.crossoverMode[index] == 1) {
            value = Math.max(value, Math.min(20000f, state.crossoverLowHz[index] * 1.02f));
        }
        state.crossoverHighHz[index] = DspUiState.clamp(value, 20, 20000);
    }

    private void updateSlope(int encoded) {
        if (encoded >= 100) {
            int value = encoded - 100;
            int card = value / 10;
            int slopeIndex = value % 10;
            if (card >= 0 && card < 4 && slopeIndex >= 0 && slopeIndex < 3) {
                state.crossoverSlopeDb[card] = new int[]{12, 24, 36}[slopeIndex];
            }
        } else {
            int card = encoded;
            int cur = state.crossoverSlopeDb[card];
            state.crossoverSlopeDb[card] = cur == 12 ? 24 : cur == 24 ? 36 : 12;
        }
    }

    private static final class TouchRegion {
        final int action;
        final int index;
        final RectF rect;

        TouchRegion(int action, int index, RectF rect) {
            this.action = action;
            this.index = index;
            this.rect = rect;
        }
    }
}
