package com.okn.dsp;

import android.graphics.Typeface;

import java.io.File;

/**
 * Uses the Android system's bundled Roboto files directly when available so
 * Samsung/user-selected system fonts do not alter the DSP UI typography.
 * No font binary is bundled with the application.
 */
public final class AppFonts {
    private static final String[] REGULAR_PATHS = {
            "/system/fonts/Roboto-Regular.ttf",
            "/system/fonts/RobotoStatic-Regular.ttf",
            "/product/fonts/Roboto-Regular.ttf"
    };
    private static final String[] MEDIUM_PATHS = {
            "/system/fonts/Roboto-Medium.ttf",
            "/system/fonts/RobotoStatic-Medium.ttf",
            "/product/fonts/Roboto-Medium.ttf"
    };
    private static final String[] BOLD_PATHS = {
            "/system/fonts/Roboto-Bold.ttf",
            "/system/fonts/RobotoStatic-Bold.ttf",
            "/product/fonts/Roboto-Bold.ttf"
    };

    public static final Typeface REGULAR = load(REGULAR_PATHS, "sans-serif", Typeface.NORMAL);
    public static final Typeface MEDIUM = load(MEDIUM_PATHS, "sans-serif-medium", Typeface.NORMAL);
    public static final Typeface BOLD = load(BOLD_PATHS, "sans-serif", Typeface.BOLD);

    private AppFonts() {}

    private static Typeface load(String[] paths, String fallbackFamily, int fallbackStyle) {
        for (String path : paths) {
            try {
                File file = new File(path);
                if (file.isFile() && file.canRead()) {
                    return Typeface.createFromFile(file);
                }
            } catch (RuntimeException ignored) {
                // Try the next system path, then use the Android family fallback.
            }
        }
        return Typeface.create(fallbackFamily, fallbackStyle);
    }
}
