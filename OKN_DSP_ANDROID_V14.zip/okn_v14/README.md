# OKN DSP Controller V14

ฐาน: OKN_DSP_ANDROID_V13 + ชุดข้อมูล GoloPine/DSTech ที่อัปโหลด

## สิ่งที่เพิ่มใน V14
- หน้า DSP Control UI
- ระดับเสียงหลัก
- ระดับเสียงเบส
- จุดตัดเสียงเบส (normalized UI; ยังไม่อ้างว่าเป็น Hz จนกว่าจะ map protocol)
- Bass Boost / MiddleBoost / Treble Boost รวมทุกช่อง
- Gain CH1–CH7 แยกอิสระ และ SeekBar เปิดให้กด/ลากจริง
- BLE scan/connect/read/notify capture
- ขอ MTU 247 เพื่อรองรับ capture ขนาดใหญ่ที่เคยพบ 235B
- รองรับ AB00/AB01/AB02/AB03 และ legacy 40af UUID profile

## ข้อมูลโปรโตคอลที่ยืนยันแล้ว
- Service: 0000ab00-0000-1000-8000-00805f9b34fb
- Write characteristic: 0000ab01-0000-1000-8000-00805f9b34fb
- Notify: 0000ab02 / 0000ab03
- UFE WRITE_ACTUATOR: 0x57
- UFE READ_SENSOR_ACTUATOR: 0x58
- UFE READ_SENSOR_ACTUATOR_JSON: 0x59
- UFE READ_SENSOR_ACTUATOR_BULK: 0x63
- UFE RESPONSE_READ_SENSOR_ACTUATOR_BULK: 0x64
- UFE CONTINUE_BULK_SEND: 0x82

## Safety / current protocol state
V14 intentionally DOES NOT send DSP parameter writes. Exact UFE framing, authentication, integrity/encryption behavior, actuator IDs and device-specific DSP address map are not fully verified in the uploaded evidence. Sliders persist UI values and log them as WRITE=LOCKED.

This prevents guessed bytes from being sent to the DSP while allowing the UI and BLE evidence-gathering path to progress.
