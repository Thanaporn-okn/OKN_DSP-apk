package com.okn.dsp

enum class DspParameter(
    val displayName: String,
    val scope: String,
    val mappingVerified: Boolean
) {
    MASTER_VOLUME("ระดับเสียงหลัก", "ALL", false),
    BASS_LEVEL("ระดับเสียงเบส", "BASS", false),
    BASS_CROSSOVER("จุดตัดเสียงเบส", "BASS", false),
    BASS_BOOST("Bass Boost", "ALL", false),
    MIDDLE_BOOST("MiddleBoost", "ALL", false),
    TREBLE_BOOST("Treble Boost", "ALL", false),
    CH1_GAIN("Gain CH1", "CH1", false),
    CH2_GAIN("Gain CH2", "CH2", false),
    CH3_GAIN("Gain CH3", "CH3", false),
    CH4_GAIN("Gain CH4", "CH4", false),
    CH5_GAIN("Gain CH5", "CH5", false),
    CH6_GAIN("Gain CH6", "CH6", false),
    CH7_GAIN("Gain CH7", "CH7", false)
}

data class DspUiValue(
    val parameter: DspParameter,
    val normalized: Int
)
