#include "okn_protocol.h"
#include <string.h>

static float read_f32_le(const uint8_t *p) {
    uint32_t u = ((uint32_t)p[0]) | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
    float f;
    memcpy(&f, &u, sizeof(f));
    return f;
}

uint16_t okn_crc16_ccitt(const uint8_t *data, size_t len) {
    uint16_t crc = 0xFFFFu;
    for (size_t i = 0; i < len; ++i) {
        crc ^= (uint16_t)data[i] << 8;
        for (unsigned b = 0; b < 8; ++b)
            crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
    }
    return crc;
}

okn_status_t okn_protocol_apply(okn_dsp_state_t *state, const uint8_t *p, size_t len) {
    if (!state || !p || len < 8u) return OKN_ERR_ARG;
    if (p[0] != OKN_PROTO_MAGIC0 || p[1] != OKN_PROTO_MAGIC1 || p[2] != OKN_PROTO_VERSION) return OKN_ERR_FORMAT;
    const uint8_t cmd = p[3];
    const uint16_t plen = (uint16_t)p[4] | ((uint16_t)p[5] << 8);
    if (plen > OKN_PROTO_MAX_PAYLOAD || len != (size_t)(6u + plen + 2u)) return OKN_ERR_FORMAT;
    const uint16_t got_crc = (uint16_t)p[len - 2] | ((uint16_t)p[len - 1] << 8);
    if (okn_crc16_ccitt(p, len - 2) != got_crc) return OKN_ERR_CRC;
    const uint8_t *d = &p[6];

    switch (cmd) {
        case OKN_CMD_PING:
            return plen == 0u ? OKN_OK : OKN_ERR_FORMAT;
        case OKN_CMD_SET_MASTER_GAIN:
            return plen == 4u ? okn_set_master_gain(state, read_f32_le(d)) : OKN_ERR_FORMAT;
        case OKN_CMD_SET_CH_GAIN:
            return plen == 5u ? okn_set_channel_gain(state, d[0], read_f32_le(&d[1])) : OKN_ERR_FORMAT;
        case OKN_CMD_SET_CH_MUTE:
            return plen == 2u ? okn_set_channel_mute(state, d[0], d[1] != 0u) : OKN_ERR_FORMAT;
        case OKN_CMD_SET_CH_PHASE:
            return plen == 2u ? okn_set_channel_phase(state, d[0], d[1] != 0u) : OKN_ERR_FORMAT;
        case OKN_CMD_SET_CH_DELAY:
            return plen == 5u ? okn_set_channel_delay(state, d[0], read_f32_le(&d[1])) : OKN_ERR_FORMAT;
        default:
            return OKN_ERR_UNSUPPORTED;
    }
}
