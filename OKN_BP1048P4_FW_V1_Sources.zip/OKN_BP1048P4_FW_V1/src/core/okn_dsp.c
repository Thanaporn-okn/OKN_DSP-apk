#include "okn_dsp.h"
#include <math.h>
#include <string.h>

static int valid_channel(unsigned channel) { return channel < OKN_CHANNELS; }
static int gain_in_range(float db) { return db >= OKN_GAIN_MIN_DB && db <= OKN_GAIN_MAX_DB; }

void okn_dsp_init(okn_dsp_state_t *state) {
    if (!state) return;
    memset(state, 0, sizeof(*state));
    for (unsigned c = 0; c < OKN_CHANNELS; ++c) {
        state->ch[c].hpf.q = 0.70710678f;
        state->ch[c].lpf.q = 0.70710678f;
        for (unsigned b = 0; b < OKN_PEQ_BANDS; ++b) {
            state->ch[c].peq[b].type = OKN_FILTER_PEQ;
            state->ch[c].peq[b].freq_hz = 1000.0f;
            state->ch[c].peq[b].q = 1.0f;
        }
    }
}

okn_status_t okn_set_master_gain(okn_dsp_state_t *state, float db) {
    if (!state) return OKN_ERR_ARG;
    if (!gain_in_range(db)) return OKN_ERR_RANGE;
    state->master_gain_db = db;
    return OKN_OK;
}

okn_status_t okn_set_channel_gain(okn_dsp_state_t *state, unsigned channel, float db) {
    if (!state || !valid_channel(channel)) return OKN_ERR_ARG;
    if (!gain_in_range(db)) return OKN_ERR_RANGE;
    state->ch[channel].gain_db = db;
    return OKN_OK;
}

okn_status_t okn_set_channel_mute(okn_dsp_state_t *state, unsigned channel, bool mute) {
    if (!state || !valid_channel(channel)) return OKN_ERR_ARG;
    state->ch[channel].mute = mute;
    return OKN_OK;
}

okn_status_t okn_set_channel_phase(okn_dsp_state_t *state, unsigned channel, bool invert) {
    if (!state || !valid_channel(channel)) return OKN_ERR_ARG;
    state->ch[channel].phase_invert = invert;
    return OKN_OK;
}

okn_status_t okn_set_channel_delay(okn_dsp_state_t *state, unsigned channel, float ms) {
    if (!state || !valid_channel(channel)) return OKN_ERR_ARG;
    if (ms < 0.0f || ms > OKN_DELAY_MAX_MS) return OKN_ERR_RANGE;
    state->ch[channel].delay_ms = ms;
    return OKN_OK;
}

float okn_db_to_linear(float db) {
    return powf(10.0f, db / 20.0f);
}

float okn_effective_channel_linear_gain(const okn_dsp_state_t *state, unsigned channel) {
    if (!state || !valid_channel(channel)) return 0.0f;
    const okn_channel_state_t *ch = &state->ch[channel];
    if (ch->mute) return 0.0f;
    float g = okn_db_to_linear(state->master_gain_db + ch->gain_db);
    return ch->phase_invert ? -g : g;
}
