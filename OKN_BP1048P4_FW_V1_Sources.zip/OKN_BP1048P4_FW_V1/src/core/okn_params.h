#ifndef OKN_PARAMS_H
#define OKN_PARAMS_H

#include <stdbool.h>
#include <stdint.h>

#define OKN_CHANNELS 7u
#define OKN_PEQ_BANDS 15u
#define OKN_GAIN_MIN_DB (-60.0f)
#define OKN_GAIN_MAX_DB (12.0f)
#define OKN_DELAY_MAX_MS (50.0f)

typedef enum {
    OKN_FILTER_BYPASS = 0,
    OKN_FILTER_PEQ = 1,
    OKN_FILTER_LOW_SHELF = 2,
    OKN_FILTER_HIGH_SHELF = 3,
    OKN_FILTER_NOTCH = 4
} okn_filter_type_t;

typedef struct {
    bool enabled;
    okn_filter_type_t type;
    float freq_hz;
    float gain_db;
    float q;
} okn_peq_band_t;

typedef struct {
    bool enabled;
    float freq_hz;
    float q;
} okn_crossover_t;

typedef struct {
    float gain_db;
    bool mute;
    bool phase_invert;
    float delay_ms;
    okn_crossover_t hpf;
    okn_crossover_t lpf;
    okn_peq_band_t peq[OKN_PEQ_BANDS];
} okn_channel_state_t;

typedef struct {
    float master_gain_db;
    okn_channel_state_t ch[OKN_CHANNELS];
} okn_dsp_state_t;

#endif
