#ifndef OKN_PROTOCOL_H
#define OKN_PROTOCOL_H

#include "okn_dsp.h"
#include <stddef.h>
#include <stdint.h>

#define OKN_PROTO_MAGIC0 0x4Fu /* O */
#define OKN_PROTO_MAGIC1 0x4Bu /* K */
#define OKN_PROTO_VERSION 0x01u
#define OKN_PROTO_MAX_PAYLOAD 32u

typedef enum {
    OKN_CMD_PING = 0x01,
    OKN_CMD_SET_MASTER_GAIN = 0x10,
    OKN_CMD_SET_CH_GAIN = 0x11,
    OKN_CMD_SET_CH_MUTE = 0x12,
    OKN_CMD_SET_CH_PHASE = 0x13,
    OKN_CMD_SET_CH_DELAY = 0x14
} okn_command_t;

uint16_t okn_crc16_ccitt(const uint8_t *data, size_t len);
okn_status_t okn_protocol_apply(okn_dsp_state_t *state, const uint8_t *packet, size_t len);

#endif
