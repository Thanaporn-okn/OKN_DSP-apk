#include "core/okn_dsp.h"
#include "hal/bp1048p4_hal.h"
#include <stdio.h>

int main(void) {
    okn_dsp_state_t state;
    okn_dsp_init(&state);
    okn_set_channel_gain(&state, 0, -3.0f);
    printf("OKN_BP1048P4_FW_V1 host demo\n");
    printf("CH1 effective gain = %.6f\n", okn_effective_channel_linear_gain(&state, 0));
    printf("BP1048P4 HAL init status = %d (expected locked until SDK port)\n", bp1048p4_hal_get()->platform_init());
    return 0;
}
