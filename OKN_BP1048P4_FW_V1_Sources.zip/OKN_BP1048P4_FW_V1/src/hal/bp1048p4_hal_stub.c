#include "bp1048p4_hal.h"

static int locked_init(void) { return OKN_ERR_HAL_LOCKED; }
static int locked_audio(void) { return OKN_ERR_HAL_LOCKED; }
static int locked_apply(const okn_dsp_state_t *state) { (void)state; return OKN_ERR_HAL_LOCKED; }
static int locked_notify(const uint8_t *data, size_t len) { (void)data; (void)len; return OKN_ERR_HAL_LOCKED; }

static const bp1048p4_hal_t HAL = {
    .platform_init = locked_init,
    .audio_start = locked_audio,
    .apply_state = locked_apply,
    .ble_notify = locked_notify,
};

const bp1048p4_hal_t *bp1048p4_hal_get(void) { return &HAL; }
