#include "../src/core/okn_dsp.h"
#include "../src/core/okn_protocol.h"
#include <assert.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

static void write_f32_le(uint8_t *p, float f) {
    uint32_t u; memcpy(&u, &f, sizeof(u));
    p[0]=(uint8_t)u; p[1]=(uint8_t)(u>>8); p[2]=(uint8_t)(u>>16); p[3]=(uint8_t)(u>>24);
}

static size_t make_set_gain(uint8_t *p, uint8_t ch, float db) {
    p[0]='O'; p[1]='K'; p[2]=1; p[3]=OKN_CMD_SET_CH_GAIN; p[4]=5; p[5]=0; p[6]=ch; write_f32_le(&p[7], db);
    uint16_t crc = okn_crc16_ccitt(p, 11); p[11]=(uint8_t)crc; p[12]=(uint8_t)(crc>>8); return 13;
}

int main(void) {
    okn_dsp_state_t s; okn_dsp_init(&s);
    assert(OKN_CHANNELS == 7u);
    assert(okn_set_channel_gain(&s, 0, -6.0f) == OKN_OK);
    assert(okn_set_channel_gain(&s, 7, -6.0f) == OKN_ERR_ARG);
    assert(okn_set_channel_gain(&s, 1, 20.0f) == OKN_ERR_RANGE);
    assert(okn_set_channel_delay(&s, 6, 50.0f) == OKN_OK);
    assert(okn_set_channel_delay(&s, 6, 50.1f) == OKN_ERR_RANGE);
    assert(fabsf(okn_effective_channel_linear_gain(&s, 0) - 0.5011872f) < 0.0001f);
    assert(okn_set_channel_phase(&s, 0, true) == OKN_OK);
    assert(okn_effective_channel_linear_gain(&s, 0) < 0.0f);
    assert(okn_set_channel_mute(&s, 0, true) == OKN_OK);
    assert(okn_effective_channel_linear_gain(&s, 0) == 0.0f);

    uint8_t pkt[32]; size_t n = make_set_gain(pkt, 2, -9.5f);
    assert(okn_protocol_apply(&s, pkt, n) == OKN_OK);
    assert(fabsf(s.ch[2].gain_db - (-9.5f)) < 0.0001f);
    pkt[n-1] ^= 1u;
    assert(okn_protocol_apply(&s, pkt, n) == OKN_ERR_CRC);
    puts("ALL TESTS PASS");
    return 0;
}
