# OKN Control Protocol V1

This is a new protocol for the replacement firmware. It is not claimed to match GoloPine UFE.

Packet framing:

- Byte 0: `0x4F` (`O`)
- Byte 1: `0x4B` (`K`)
- Byte 2: version = `0x01`
- Byte 3: command
- Byte 4..5: payload length, uint16 little-endian
- Byte 6..N: payload
- Final 2 bytes: CRC-16/CCITT, little-endian, over all previous bytes

Channel numbering is zero-based on wire: 0..6 = CH1..CH7.

Commands implemented in V1:

- `0x01` PING
- `0x10` SET_MASTER_GAIN: float32 dB
- `0x11` SET_CH_GAIN: channel u8 + float32 dB
- `0x12` SET_CH_MUTE: channel u8 + bool u8
- `0x13` SET_CH_PHASE: channel u8 + bool u8
- `0x14` SET_CH_DELAY: channel u8 + float32 milliseconds

Persistence is intentionally absent in V1. No automatic save exists.
