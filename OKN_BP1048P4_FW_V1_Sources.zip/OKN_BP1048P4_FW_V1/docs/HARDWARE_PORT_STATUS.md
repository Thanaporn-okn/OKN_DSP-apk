# BP1048P4 hardware-port status — V1

## Confirmed project-side facts

- Target project: GoloPine 7-channel board using BP1048P4.
- Runtime goal is wireless/BLE.
- Existing GoloPine BLE service observed in prior reverse engineering: AB00 service, AB01 write, AB02 notify, AB03 secondary notify.
- The new clean-room firmware does not need to preserve the legacy GoloPine packet format; OKN protocol V1 is defined separately.

## Not permitted to guess

- SDP/debug pins
- boot/strap pins
- internal flash map
- interrupt vector addresses
- BLE stack API
- I2S/DAC/ADC pin mux
- board codec/DAC routing
- GoloPine FPC connector pinout
- vendor DSP effect IDs/addresses

## Port gate

Replace `src/hal/bp1048p4_hal_stub.c` only after obtaining authentic BP1048P4 SDK headers/examples or equivalent board evidence. Until then every hardware call returns `OKN_ERR_HAL_LOCKED`.
