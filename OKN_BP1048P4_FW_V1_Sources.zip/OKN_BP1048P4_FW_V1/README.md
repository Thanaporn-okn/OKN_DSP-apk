# OKN_BP1048P4_FW_V1

Clean-room firmware foundation for the GoloPine/BP1048P4 7-channel DSP project.

## Safety status

This V1 is **NOT hardware-flashable yet**. It deliberately contains no guessed BP1048P4 register addresses, bootloader packets, flash commands, GPIO numbers, or vendor SDK calls.

The portable DSP/control core builds and tests on a normal GCC host. The BP1048P4 hardware abstraction layer (HAL) is fail-closed until an authentic BP1048P4 SDK/toolchain and the board hardware map are available.

## Implemented in V1

- Seven independent output-channel states (CH1..CH7)
- Gain in dB with bounded conversion to linear gain
- Per-channel mute
- Per-channel 0/180 degree phase inversion
- 15 PEQ state slots per channel
- HPF/LPF state model
- Per-channel delay state model
- Master gain state
- Versioned OKN control protocol parser independent of GoloPine's legacy UFE protocol
- CRC-16/CCITT packet validation
- No SaveParams and no legacy unknown actuator/DSP writes
- Abstract BLE transport and audio/DSP HAL interfaces
- Host-side validation executable and tests

## What is intentionally missing

- BP1048P4 vendor startup code/linker script
- BP1048P4 Bluetooth stack calls
- BP1048P4 flash/debug implementation
- GoloPine PCB pin map / clock / codec routing
- Actual realtime audio hook into the vendor DSP pipeline

These items must come from evidence or the genuine SDK; they will not be guessed.

## Host validation

```sh
make test
make demo
```

## Version namespaces

Android app versions and firmware versions are separate. This package starts the new firmware line at `OKN_BP1048P4_FW_V1`.
