#!/usr/bin/env python3
from pathlib import Path
import re, sys
root = Path(__file__).resolve().parents[1]
# Block common patterns that would indicate someone added raw MMIO/register guesses to V1.
patterns = [
    re.compile(r'\*\s*\(\s*volatile\s+(?:unsigned|u?int\d*_t).*?\*\s*\)\s*0x[0-9a-fA-F]+'),
    re.compile(r'\bREG(?:ISTER)?_[A-Z0-9_]+\s*=\s*0x[0-9a-fA-F]+'),
]
violations=[]
for path in list((root/'src').rglob('*.c')) + list((root/'src').rglob('*.h')):
    text=path.read_text(errors='ignore')
    for rx in patterns:
        if rx.search(text): violations.append((path, rx.pattern))
if violations:
    for p,pat in violations: print('BLOCKED guessed HW access:', p, pat)
    sys.exit(1)
print('PASS: no raw guessed BP1048P4 MMIO/register access detected')
