package com.okn.dsp.protocol

/**
 * Evidence gate for all DSP actuator writes.
 * Keep false until packet framing, authentication/encryption, integrity,
 * actuator IDs/addresses and coefficient serialization are independently verified.
 */
object WriteGate {
    const val enabled: Boolean = false
}
