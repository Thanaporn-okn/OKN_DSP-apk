OKN DSP ANDROID V26 — REAL CONTROL MAP + CLEAN CAPTURE

Confirmed app behavior used in V26:
1) Master Volume = global all channels
2) Connection alert volume = optional; omitted from OKN target controls
3) Bass Volume = independent bass block
4) Bass Cutoff frequency = paired with Bass Volume
5) Bass Boost = global all channels
6) MiddleBoost = global all channels
7) Treble Boost = global all channels
8) 15-band EQ = independent for CH1..CH7

V26 changes:
- Removed unsupported Mute and Delay UI.
- Removed guessed per-channel Gain/Xover/Mixer UI.
- Added real-control map page.
- Kept 15-band EQ per CH as LOCAL TARGET only.
- Evidence Lab disables periodic GATT reads.
- Added MARK EQ CH1 / MARK EQ CH2 / MARK GLOBAL / MARK BASS.
- Marker attempts one safe Device Name (2A00) READ so HCI has a timestamp landmark.
- Added AB02 large-burst detector (e.g. 194+127, 197+124).
- Disabled startup-probe button because the captured 4-byte follow-up varies by session.
- DSP parameter writes remain locked.

Next capture target:
MARK EQ CH1 -> adjust same EQ band +1 step in official app -> wait 5s
MARK EQ CH2 -> adjust same EQ band +1 step -> wait 5s
MARK EQ CH1 -> adjust same band +1 step again -> wait 5s
Then export HCI snoop + V26 capture.
