# Android APK client

This directory contains a small Android WebView client for the Facebook Marketplace & Groups Product Tracker web frontend.

## GitHub Actions build

The workflow is located at:

`.github/workflows/Build_APK.yml`

It builds an installable debug-signed APK named:

`FacebookProductTracker.apk`

The APK is uploaded directly to the GitHub Actions run as an artifact.

## Configure the web URL

Recommended: create a GitHub Repository Variable:

- Name: `WEB_APP_URL`
- Value: `https://your-deployed-tracker.example.com`

Path in GitHub:

`Settings -> Secrets and variables -> Actions -> Variables -> New repository variable`

If `WEB_APP_URL` is not set, the app asks for the web URL on first launch. Long-press anywhere in the WebView to change the URL later.

Production deployments should use HTTPS. Plain HTTP is only enabled for `localhost` and Android Emulator host `10.0.2.2`.

## Local build

Requires JDK 17, Android SDK 35, Build Tools 35.0.0, and Gradle 8.11.1.

```bash
gradle -p android clean assembleDebug
```

Output:

`android/app/build/outputs/apk/debug/app-debug.apk`
