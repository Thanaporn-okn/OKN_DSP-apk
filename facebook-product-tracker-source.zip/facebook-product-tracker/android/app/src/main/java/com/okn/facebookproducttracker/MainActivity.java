package com.okn.facebookproducttracker;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.SafeBrowsingResponse;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.util.Locale;

public final class MainActivity extends Activity {
    private static final String PREFS = "tracker_prefs";
    private static final String KEY_WEB_URL = "web_app_url";

    private WebView webView;
    private ProgressBar progressBar;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        buildUi();
        configureWebView();

        String initialUrl = prefs.getString(KEY_WEB_URL, "");
        if (initialUrl == null || initialUrl.isBlank()) {
            initialUrl = BuildConfig.WEB_APP_URL;
        }

        if (isHttpUrl(initialUrl)) {
            saveAndLoad(initialUrl);
        } else {
            showUrlDialog(false);
        }
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        webView = new WebView(this);
        progressBar = new ProgressBar(this);

        root.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        FrameLayout.LayoutParams progressParams = new FrameLayout.LayoutParams(56, 56);
        progressParams.gravity = Gravity.CENTER;
        root.addView(progressBar, progressParams);
        setContentView(root);

        webView.setOnLongClickListener(v -> {
            showUrlDialog(true);
            return true;
        });
    }

    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WebView.enableSlowWholeDocumentDraw();
            settings.setSafeBrowsingEnabled(true);
        }

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, false);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleNavigation(request.getUrl());
            }

            @Override
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleNavigation(Uri.parse(url));
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                progressBar.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progressBar.setVisibility(View.GONE);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(MainActivity.this,
                            "โหลดหน้าเว็บไม่สำเร็จ: " + error.getDescription(),
                            Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onSafeBrowsingHit(
                    WebView view,
                    WebResourceRequest request,
                    int threatType,
                    SafeBrowsingResponse callback
            ) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                    callback.backToSafety(true);
                }
            }
        });
    }

    private boolean handleNavigation(Uri uri) {
        String scheme = uri.getScheme();
        if (scheme == null) return true;

        if (!scheme.equalsIgnoreCase("http") && !scheme.equalsIgnoreCase("https")) {
            openExternal(uri);
            return true;
        }

        String host = uri.getHost();
        if (host != null) {
            String normalized = host.toLowerCase(Locale.ROOT);
            if (normalized.equals("facebook.com")
                    || normalized.endsWith(".facebook.com")
                    || normalized.equals("fb.com")
                    || normalized.endsWith(".fb.com")) {
                openExternal(uri);
                return true;
            }
        }

        return false;
    }

    private void openExternal(Uri uri) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (ActivityNotFoundException ex) {
            Toast.makeText(this, "ไม่พบแอปที่เปิดลิงก์นี้ได้", Toast.LENGTH_SHORT).show();
        }
    }

    private void showUrlDialog(boolean allowCancel) {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        String current = prefs.getString(KEY_WEB_URL, BuildConfig.WEB_APP_URL);
        input.setText(current == null ? "" : current);
        input.setHint("https://tracker.example.com");

        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle(R.string.configure_title)
                .setMessage(R.string.configure_message)
                .setView(input)
                .setPositiveButton(R.string.save, null);

        if (allowCancel) {
            builder.setNegativeButton(R.string.cancel, null);
        } else {
            builder.setCancelable(false);
        }

        AlertDialog dialog = builder.create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(v -> {
                    String candidate = input.getText().toString().trim();
                    if (!isHttpUrl(candidate)) {
                        input.setError(getString(R.string.invalid_url));
                        return;
                    }
                    saveAndLoad(candidate);
                    dialog.dismiss();
                }));
        dialog.show();
    }

    private void saveAndLoad(String url) {
        prefs.edit().putString(KEY_WEB_URL, url).apply();
        webView.loadUrl(url);
    }

    private boolean isHttpUrl(String value) {
        if (value == null || value.isBlank()) return false;
        Uri uri = Uri.parse(value.trim());
        String scheme = uri.getScheme();
        return uri.getHost() != null
                && ("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme));
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.setWebViewClient(null);
            webView.destroy();
        }
        super.onDestroy();
    }
}
