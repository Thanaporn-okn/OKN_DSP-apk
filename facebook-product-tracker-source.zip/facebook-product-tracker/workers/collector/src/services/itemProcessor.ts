import { Prisma, prisma } from "@tracker/database";
import type { ItemDto, SourceType } from "@tracker/shared";
import { createHash } from "node:crypto";
import type { RawCollectedItem } from "../collectors/types.js";

export interface ProcessContext {
  sourceType: SourceType;
  sourceName: string;
  sourceId: string | null;
}

export interface ProcessResult {
  item: ItemDto | null;
  duplicate: boolean;
}

const nullable = <T>(value: T | null | undefined): T | null => value ?? null;

function fingerprint(raw: RawCollectedItem): string {
  const normalizedTitle = raw.title.toLocaleLowerCase().replace(/\s+/g, " ").trim();
  const seller = raw.sellerName?.toLocaleLowerCase().trim() ?? "";
  const postedDay = raw.postedAt?.slice(0, 10) ?? "";
  const value = [normalizedTitle, raw.price ?? "", seller, postedDay, raw.imageUrl ?? ""].join("|");
  return createHash("sha256").update(value).digest("hex");
}

function toDto(item: {
  id: string;
  externalId: string;
  title: string;
  description: string | null;
  price: Prisma.Decimal | null;
  currency: string;
  imageUrl: string | null;
  locationName: string | null;
  latitude: Prisma.Decimal | null;
  longitude: Prisma.Decimal | null;
  sourceType: SourceType;
  sourceName: string | null;
  sourceId: string | null;
  sellerName: string | null;
  postUrl: string | null;
  postedAt: Date | null;
  detectedAt: Date;
  createdAt: Date;
}): ItemDto {
  return {
    id: item.id,
    externalId: item.externalId,
    title: item.title,
    description: item.description,
    price: item.price === null ? null : item.price.toNumber(),
    currency: item.currency,
    imageUrl: item.imageUrl,
    locationName: item.locationName,
    latitude: item.latitude === null ? null : item.latitude.toNumber(),
    longitude: item.longitude === null ? null : item.longitude.toNumber(),
    sourceType: item.sourceType,
    sourceName: item.sourceName,
    sourceId: item.sourceId,
    sellerName: item.sellerName,
    postUrl: item.postUrl,
    postedAt: item.postedAt?.toISOString() ?? null,
    detectedAt: item.detectedAt.toISOString(),
    createdAt: item.createdAt.toISOString(),
  };
}

export class ItemProcessor {
  async process(raw: RawCollectedItem, context: ProcessContext): Promise<ProcessResult> {
    const hash = fingerprint(raw);
    const postedAt = raw.postedAt ? new Date(raw.postedAt) : null;
    const exact = await prisma.item.findFirst({
      where: {
        OR: [
          { sourceType: context.sourceType, externalId: raw.externalId },
          ...(raw.postUrl ? [{ postUrl: raw.postUrl }] : []),
        ],
      },
      select: { id: true },
    });
    if (exact) return { item: null, duplicate: true };

    const since = new Date(Date.now() - 48 * 60 * 60 * 1000);
    const secondary = await prisma.item.findFirst({
      where: {
        sourceType: context.sourceType,
        fingerprint: hash,
        detectedAt: { gte: since },
      },
      select: { id: true },
    });
    if (secondary) return { item: null, duplicate: true };

    try {
      const created = await prisma.item.create({
        data: {
          externalId: raw.externalId,
          title: raw.title.trim(),
          description: nullable(raw.description),
          price: raw.price ?? null,
          currency: raw.currency,
          imageUrl: nullable(raw.imageUrl),
          locationName: nullable(raw.locationName),
          latitude: raw.latitude ?? null,
          longitude: raw.longitude ?? null,
          sourceType: context.sourceType,
          sourceName: context.sourceName,
          sourceId: context.sourceId,
          sellerName: nullable(raw.sellerName),
          postUrl: nullable(raw.postUrl),
          postedAt,
          detectedAt: new Date(),
          fingerprint: hash,
        },
      });
      return { item: toDto(created), duplicate: false };
    } catch (error) {
      if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === "P2002") {
        return { item: null, duplicate: true };
      }
      throw error;
    }
  }
}
