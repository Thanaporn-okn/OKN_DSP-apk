import { closeDatabase, prisma } from "@tracker/database";
import type { ItemDto } from "@tracker/shared";
import { Queue, Worker, type Job } from "bullmq";
import IORedis from "ioredis";
import { createCollectors } from "./collectors/factory.js";
import { ProviderHttpError } from "./collectors/authorizedHttp.js";
import { env } from "./config.js";
import { logger } from "./logger.js";
import { ItemProcessor } from "./services/itemProcessor.js";

const QUEUE_NAME = "collection";
const EVENT_CHANNEL = "tracker:item:new";

type CollectionJob =
  | { kind: "search"; id: string }
  | { kind: "group"; id: string };

const queueRedis = new IORedis(env.REDIS_URL, { maxRetriesPerRequest: null });
const workerRedis = new IORedis(env.REDIS_URL, { maxRetriesPerRequest: null });
const publisher = new IORedis(env.REDIS_URL, { maxRetriesPerRequest: null });
const queue = new Queue<CollectionJob>(QUEUE_NAME, { connection: queueRedis });
const collectors = createCollectors();
const processor = new ItemProcessor();

function passesPrice(price: number | null | undefined, min: number | null, max: number | null): boolean {
  if (price == null) return min == null && max == null;
  if (min != null && price < min) return false;
  if (max != null && price > max) return false;
  return true;
}

function passesKeywords(title: string, description: string | null | undefined, keywords: string[]): boolean {
  if (keywords.length === 0) return true;
  const haystack = `${title} ${description ?? ""}`.toLocaleLowerCase();
  return keywords.some((keyword) => haystack.includes(keyword.toLocaleLowerCase()));
}

function classifyCollectorError(error: unknown): string {
  if (error instanceof ProviderHttpError) {
    if (error.status === 401 || error.status === 403) return "collector.authorization_expired";
    if (error.status === 429) return "collector.rate_limited";
    if (error.status >= 500) return "collector.provider_unavailable";
  }
  if (error instanceof Error && error.name === "AbortError") return "collector.timeout";
  return "collector.failed";
}

async function publish(item: ItemDto): Promise<void> {
  await publisher.publish(EVENT_CHANNEL, JSON.stringify(item));
}

async function runSearch(id: string): Promise<void> {
  const config = await prisma.trackedSearch.findUnique({ where: { id } });
  if (!config || !config.enabled) return;
  const started = Date.now();
  const run = await prisma.collectorRun.create({
    data: { collector: "marketplace", status: "RUNNING", trackedSearchId: id },
  });
  logger.info({ event: "collector.started", collector: "marketplace", trackedSearchId: id, runId: run.id });

  try {
    const items = await collectors.marketplace.collect({
      keyword: config.keyword,
      latitude: config.latitude?.toNumber() ?? null,
      longitude: config.longitude?.toNumber() ?? null,
      radiusKm: config.radiusKm,
      minPrice: config.minPrice?.toNumber() ?? null,
      maxPrice: config.maxPrice?.toNumber() ?? null,
      category: config.category,
      sort: config.sort,
    });
    let inserted = 0;
    let duplicates = 0;
    for (const raw of items) {
      if (!passesPrice(raw.price, config.minPrice?.toNumber() ?? null, config.maxPrice?.toNumber() ?? null)) continue;
      const result = await processor.process(raw, {
        sourceType: "MARKETPLACE",
        sourceName: "Facebook Marketplace",
        sourceId: null,
      });
      if (result.duplicate) duplicates += 1;
      if (result.item) {
        inserted += 1;
        await publish(result.item);
      }
    }
    const durationMs = Date.now() - started;
    await prisma.collectorRun.update({
      where: { id: run.id },
      data: { status: "COMPLETED", itemsFound: items.length, newItems: inserted, duplicates, completedAt: new Date(), durationMs },
    });
    logger.info({ event: "collector.completed", collector: "marketplace", itemsFound: items.length, newItems: inserted, duplicates, durationMs });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    await prisma.collectorRun.update({
      where: { id: run.id },
      data: { status: "FAILED", completedAt: new Date(), durationMs: Date.now() - started, errorMessage: message },
    });
    const event = classifyCollectorError(error);
    await prisma.collectorError.create({ data: { runId: run.id, event, message } });
    logger.error({ err: error, event, collector: "marketplace", trackedSearchId: id });
    throw error;
  }
}

async function runGroup(id: string): Promise<void> {
  const config = await prisma.trackedGroup.findUnique({ where: { id } });
  if (!config || !config.enabled) return;
  const started = Date.now();
  const run = await prisma.collectorRun.create({
    data: { collector: "facebook-group", status: "RUNNING", trackedGroupId: id },
  });
  logger.info({ event: "collector.started", collector: "facebook-group", trackedGroupId: id, runId: run.id });

  try {
    const items = await collectors.group.collect({
      facebookGroupId: config.facebookGroupId,
      facebookGroupUrl: config.facebookGroupUrl,
      keywords: config.keywords,
      minPrice: config.minPrice?.toNumber() ?? null,
      maxPrice: config.maxPrice?.toNumber() ?? null,
    });
    let inserted = 0;
    let duplicates = 0;
    for (const raw of items) {
      if (!passesPrice(raw.price, config.minPrice?.toNumber() ?? null, config.maxPrice?.toNumber() ?? null)) continue;
      if (!passesKeywords(raw.title, raw.description, config.keywords)) continue;
      const result = await processor.process(raw, {
        sourceType: "GROUP",
        sourceName: config.name,
        sourceId: config.facebookGroupId,
      });
      if (result.duplicate) duplicates += 1;
      if (result.item) {
        inserted += 1;
        await publish(result.item);
      }
    }
    const durationMs = Date.now() - started;
    await prisma.collectorRun.update({
      where: { id: run.id },
      data: { status: "COMPLETED", itemsFound: items.length, newItems: inserted, duplicates, completedAt: new Date(), durationMs },
    });
    logger.info({ event: "collector.completed", collector: "facebook-group", itemsFound: items.length, newItems: inserted, duplicates, durationMs });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    await prisma.collectorRun.update({
      where: { id: run.id },
      data: { status: "FAILED", completedAt: new Date(), durationMs: Date.now() - started, errorMessage: message },
    });
    const event = classifyCollectorError(error);
    await prisma.collectorError.create({ data: { runId: run.id, event, message } });
    logger.error({ err: error, event, collector: "facebook-group", trackedGroupId: id });
    throw error;
  }
}

const worker = new Worker<CollectionJob>(
  QUEUE_NAME,
  async (job: Job<CollectionJob>) => {
    if (job.data.kind === "search") await runSearch(job.data.id);
    else await runGroup(job.data.id);
  },
  {
    connection: workerRedis,
    concurrency: env.COLLECTOR_CONCURRENCY,
    limiter: { max: Math.max(env.COLLECTOR_CONCURRENCY * 2, 4), duration: 10_000 },
  },
);

worker.on("failed", (job, error) => logger.error({ err: error, event: "job.failed", jobId: job?.id }));
worker.on("completed", (job) => logger.info({ event: "job.completed", jobId: job.id }));

async function scheduleDueJobs(): Promise<void> {
  const now = Date.now();
  const [searches, groups] = await Promise.all([
    prisma.trackedSearch.findMany({ where: { enabled: true } }),
    prisma.trackedGroup.findMany({ where: { enabled: true } }),
  ]);

  for (const search of searches) {
    const due = !search.lastRunAt || now - search.lastRunAt.getTime() >= search.refreshIntervalSeconds * 1000;
    if (!due) continue;
    const bucket = Math.floor(now / (search.refreshIntervalSeconds * 1000));
    await queue.add("marketplace", { kind: "search", id: search.id }, {
      jobId: `search-${search.id}-${bucket}`,
      attempts: 5,
      backoff: { type: "exponential", delay: 5000 },
      removeOnComplete: { age: 3600, count: 1000 },
      removeOnFail: { age: 7 * 86400, count: 5000 },
    });
    await prisma.trackedSearch.update({ where: { id: search.id }, data: { lastRunAt: new Date() } });
  }

  for (const group of groups) {
    const due = !group.lastRunAt || now - group.lastRunAt.getTime() >= group.refreshIntervalSeconds * 1000;
    if (!due) continue;
    const bucket = Math.floor(now / (group.refreshIntervalSeconds * 1000));
    await queue.add("facebook-group", { kind: "group", id: group.id }, {
      jobId: `group-${group.id}-${bucket}`,
      attempts: 5,
      backoff: { type: "exponential", delay: 5000 },
      removeOnComplete: { age: 3600, count: 1000 },
      removeOnFail: { age: 7 * 86400, count: 5000 },
    });
    await prisma.trackedGroup.update({ where: { id: group.id }, data: { lastRunAt: new Date() } });
  }
}

let stopping = false;
async function schedulerLoop(): Promise<void> {
  while (!stopping) {
    try {
      await scheduleDueJobs();
    } catch (error) {
      logger.error({ err: error, event: "scheduler.failed" });
    }
    await new Promise((resolve) => setTimeout(resolve, env.SCHEDULER_POLL_MS));
  }
}

logger.info({ event: "worker.started", collectorMode: env.COLLECTOR_MODE, concurrency: env.COLLECTOR_CONCURRENCY });
void schedulerLoop();

async function shutdown(signal: string): Promise<void> {
  if (stopping) return;
  stopping = true;
  logger.info({ event: "worker.shutdown", signal });
  await Promise.allSettled([worker.close(), queue.close(), publisher.quit(), queueRedis.quit(), workerRedis.quit(), closeDatabase()]);
  process.exit(0);
}

process.on("SIGTERM", () => void shutdown("SIGTERM"));
process.on("SIGINT", () => void shutdown("SIGINT"));
