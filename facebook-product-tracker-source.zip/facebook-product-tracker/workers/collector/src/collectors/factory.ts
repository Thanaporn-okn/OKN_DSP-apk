import { env } from "../config.js";
import {
  AuthorizedHttpGroupCollector,
  AuthorizedHttpMarketplaceCollector,
  DisabledGroupCollector,
  DisabledMarketplaceCollector,
} from "./authorizedHttp.js";

export function createCollectors() {
  if (env.COLLECTOR_MODE === "authorized-http") {
    return {
      marketplace: new AuthorizedHttpMarketplaceCollector(),
      group: new AuthorizedHttpGroupCollector(),
    };
  }
  return {
    marketplace: new DisabledMarketplaceCollector(),
    group: new DisabledGroupCollector(),
  };
}
