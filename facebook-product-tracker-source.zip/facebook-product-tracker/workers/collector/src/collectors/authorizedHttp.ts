import { env } from "../config.js";
import { providerResponseSchema } from "./types.js";
import type {
  FacebookGroupCollector,
  GroupCollectionInput,
  MarketplaceCollectionInput,
  MarketplaceCollector,
  RawCollectedItem,
} from "./types.js";

export class ProviderHttpError extends Error {
  constructor(public readonly status: number, message: string) { super(message); this.name = "ProviderHttpError"; }
}

async function postAuthorized<T>(url: string, token: string | undefined, payload: T): Promise<RawCollectedItem[]> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), env.COLLECTOR_TIMEOUT_MS);
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        ...(token ? { authorization: `Bearer ${token}` } : {}),
      },
      body: JSON.stringify(payload),
      signal: controller.signal,
    });
    if (!response.ok) {
      const text = await response.text();
      throw new ProviderHttpError(response.status, `Authorized provider returned ${response.status}: ${text.slice(0, 300)}`);
    }
    return providerResponseSchema.parse(await response.json()).items;
  } finally {
    clearTimeout(timer);
  }
}

export class AuthorizedHttpMarketplaceCollector implements MarketplaceCollector {
  async collect(input: MarketplaceCollectionInput): Promise<RawCollectedItem[]> {
    if (!env.MARKETPLACE_PROVIDER_URL) throw new Error("MARKETPLACE_PROVIDER_URL is not configured");
    return postAuthorized(env.MARKETPLACE_PROVIDER_URL, env.MARKETPLACE_PROVIDER_TOKEN, input);
  }
}

export class AuthorizedHttpGroupCollector implements FacebookGroupCollector {
  async collect(input: GroupCollectionInput): Promise<RawCollectedItem[]> {
    if (!env.GROUPS_PROVIDER_URL) throw new Error("GROUPS_PROVIDER_URL is not configured");
    return postAuthorized(env.GROUPS_PROVIDER_URL, env.GROUPS_PROVIDER_TOKEN, input);
  }
}

export class DisabledMarketplaceCollector implements MarketplaceCollector {
  async collect(): Promise<RawCollectedItem[]> { return []; }
}

export class DisabledGroupCollector implements FacebookGroupCollector {
  async collect(): Promise<RawCollectedItem[]> { return []; }
}
