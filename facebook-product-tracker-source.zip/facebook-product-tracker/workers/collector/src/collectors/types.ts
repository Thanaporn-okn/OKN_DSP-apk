import { z } from "zod";

export const rawCollectedItemSchema = z.object({
  externalId: z.string().min(1),
  title: z.string().min(1),
  description: z.string().nullable().optional(),
  price: z.number().nonnegative().nullable().optional(),
  currency: z.string().min(1).max(8).default("THB"),
  imageUrl: z.string().url().nullable().optional(),
  locationName: z.string().nullable().optional(),
  latitude: z.number().min(-90).max(90).nullable().optional(),
  longitude: z.number().min(-180).max(180).nullable().optional(),
  sellerName: z.string().nullable().optional(),
  postUrl: z.string().url().nullable().optional(),
  postedAt: z.string().datetime().nullable().optional(),
});
export type RawCollectedItem = z.infer<typeof rawCollectedItemSchema>;

export const providerResponseSchema = z.object({
  items: z.array(rawCollectedItemSchema).max(1000),
});

export interface MarketplaceCollectionInput {
  keyword: string;
  latitude: number | null;
  longitude: number | null;
  radiusKm: number | null;
  minPrice: number | null;
  maxPrice: number | null;
  category: string | null;
  sort: string | null;
}

export interface GroupCollectionInput {
  facebookGroupId: string;
  facebookGroupUrl: string;
  keywords: string[];
  minPrice: number | null;
  maxPrice: number | null;
}

export interface MarketplaceCollector {
  collect(input: MarketplaceCollectionInput): Promise<RawCollectedItem[]>;
}

export interface FacebookGroupCollector {
  collect(input: GroupCollectionInput): Promise<RawCollectedItem[]>;
}
