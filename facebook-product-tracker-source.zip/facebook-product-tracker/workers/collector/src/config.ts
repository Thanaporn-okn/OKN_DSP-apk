import "dotenv/config";
import { z } from "zod";

const schema = z.object({
  DATABASE_URL: z.string().min(1),
  REDIS_URL: z.string().min(1),
  LOG_LEVEL: z.string().default("info"),
  COLLECTOR_MODE: z.enum(["disabled", "authorized-http"]).default("disabled"),
  COLLECTOR_TIMEOUT_MS: z.coerce.number().int().min(1000).max(120000).default(30000),
  COLLECTOR_CONCURRENCY: z.coerce.number().int().min(1).max(32).default(4),
  SCHEDULER_POLL_MS: z.coerce.number().int().min(5000).max(60000).default(15000),
  MARKETPLACE_PROVIDER_URL: z.string().url().optional().or(z.literal("")),
  MARKETPLACE_PROVIDER_TOKEN: z.string().optional(),
  GROUPS_PROVIDER_URL: z.string().url().optional().or(z.literal("")),
  GROUPS_PROVIDER_TOKEN: z.string().optional(),
});

export const env = schema.parse(process.env);
