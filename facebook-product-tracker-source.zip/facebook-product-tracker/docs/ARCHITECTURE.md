# Architecture & Design

## 1. System Architecture Diagram

```mermaid
flowchart TB
  B[Browser] -->|HTTPS REST| W[Next.js Web]
  B <-->|Socket.IO| API[Express API]
  W -->|REST| API
  API --> DB[(PostgreSQL + PostGIS)]
  API -->|subscribe tracker:item:new| R[(Redis)]
  SCH[Scheduler loop] -->|enqueue due jobs| Q[BullMQ Queue]
  Q --> WRK[Collector Worker]
  WRK --> MC[MarketplaceCollector]
  WRK --> GC[FacebookGroupCollector]
  MC --> AUTH[Authorized Provider / Official API]
  GC --> AUTH
  WRK --> PROC[Normalize + Validate + Deduplicate]
  PROC --> DB
  PROC -->|publish committed item| R
  R --> API
  API -->|item:new| B
```

## 2. Component Diagram

```mermaid
flowchart LR
  subgraph Web
    LIVE[/live]
    ITEMS[/items]
    RQ[React Query]
    SC[Socket.IO Client]
    LIVE --> RQ
    LIVE --> SC
    ITEMS --> RQ
  end

  subgraph API
    ROUTES[Routes]
    SVC[Services]
    REPO[Repositories]
    RTS[Realtime Service]
    MW[Validation/Auth/Rate Limit/Error]
    ROUTES --> SVC --> REPO
    MW --> ROUTES
  end

  subgraph Worker
    SCHED[Scheduler]
    QUEUE[BullMQ]
    COL[Collector Interfaces]
    NORM[Item Processor]
    SCHED --> QUEUE --> COL --> NORM
  end

  REPO --> PG[(Postgres/PostGIS)]
  NORM --> PG
  NORM --> REDIS[(Redis Pub/Sub)]
  REDIS --> RTS
  SC <--> RTS
```

## 3. Data Flow Diagram

```mermaid
sequenceDiagram
  participant S as Scheduler
  participant Q as BullMQ
  participant W as Worker
  participant C as Authorized Collector
  participant P as ItemProcessor
  participant D as PostgreSQL
  participant R as Redis Pub/Sub
  participant A as API Socket.IO
  participant U as Browser

  S->>Q: enqueue due collection job
  Q->>W: deliver job
  W->>C: collect(search/group config)
  C-->>W: RawCollectedItem[]
  loop each item
    W->>P: normalize/validate/dedupe
    P->>D: exact + secondary duplicate check
    P->>D: INSERT item
    D-->>P: committed row
    P-->>W: ItemDto
    W->>R: publish tracker:item:new
    R->>A: item payload
    A->>U: item:new
  end
  W->>D: update collector_run metrics
```

## 4. Service Responsibilities

### Next.js Web
- `/live`: initial REST fetch + realtime insert into React Query cache.
- `/items`: search/filter/sort/pagination.
- Responsive card grid: 1 column mobile, 2 tablet, 4 desktop.
- Socket connection state: Live / Reconnecting / Offline.

### Express API
- Public read endpoints for item browsing.
- Bearer-protected mutation endpoints for tracked searches/groups.
- Zod input validation, Helmet, CORS, request rate limiting, structured request/error logs.
- PostgreSQL repository uses parameterized SQL for PostGIS/full-text search.
- Redis subscriber bridges worker events into Socket.IO.

### Scheduler + BullMQ
- Polls enabled tracking configs.
- Enqueues only due configs using deterministic job IDs per time bucket.
- Jobs use retries and exponential backoff.

### Collector Worker
- Never executes as part of an HTTP request.
- Loads tracking config from DB at execution time.
- Calls a replaceable collector implementation.
- Persists collector run/error telemetry.
- Gracefully drains worker/queue/connections on SIGTERM/SIGINT.

### Collector Interfaces
- `MarketplaceCollector`
- `FacebookGroupCollector`
- Default modes:
  - `disabled`: safe local boot with no external data access.
  - `authorized-http`: POST to an organization-controlled authorized provider/API.
- Future Playwright/Puppeteer implementations plug into the same interfaces and must use only authorized access/session flows.

### Item Processor
- Normalizes nullable fields and dates.
- Computes SHA-256 secondary fingerprint from normalized title/price/seller/post day/image.
- Exact checks: `(source_type, external_id)` and `post_url`.
- Secondary check: source + fingerprint within a short recent window.
- Database unique constraints remain the final race-safe protection.
- Publishes realtime event only after successful insert.

### PostgreSQL/PostGIS
- Source of truth for listings and tracking configs.
- GiST geography index supports 10/25/50/100km radius search via `ST_DWithin`.
- GIN full-text index covers title/description/seller/source.
- B-tree indexes support newest/price/source filters.

## 5. Scaling Path

For tens of thousands to low millions of items, the provided indexes and paginated queries are a reasonable baseline. At larger scale:

1. Move deep pagination to cursor/keyset pagination.
2. Partition `items` by month/quarter on `detected_at` if retention is long.
3. Use DB lease/advisory lock scheduler claiming when running multiple scheduler replicas.
4. Separate Redis queue and pub/sub clusters if workloads diverge.
5. Add OpenTelemetry/Prometheus metrics and alerting.
6. Add retention/archival policies for collector telemetry.
