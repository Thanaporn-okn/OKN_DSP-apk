FROM node:24-alpine AS build
WORKDIR /app
RUN corepack enable
COPY . .
RUN pnpm install --no-frozen-lockfile
RUN DATABASE_URL=postgresql://x:x@localhost:5432/x pnpm --filter @tracker/database generate
RUN pnpm --filter @tracker/shared build && pnpm --filter @tracker/database build && pnpm --filter @tracker/collector-worker build
CMD ["node", "workers/collector/dist/main.js"]
