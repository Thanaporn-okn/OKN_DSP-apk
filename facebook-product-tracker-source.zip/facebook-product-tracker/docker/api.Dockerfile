FROM node:24-alpine AS build
WORKDIR /app
RUN corepack enable
COPY . .
RUN pnpm install --no-frozen-lockfile
RUN DATABASE_URL=postgresql://x:x@localhost:5432/x pnpm --filter @tracker/database generate
RUN pnpm --filter @tracker/shared build && pnpm --filter @tracker/database build && pnpm --filter @tracker/api build
EXPOSE 4000
CMD ["node", "apps/api/dist/server.js"]
