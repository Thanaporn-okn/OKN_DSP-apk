FROM node:24-alpine AS build
WORKDIR /app
RUN corepack enable
COPY . .
RUN pnpm install --no-frozen-lockfile
ARG NEXT_PUBLIC_API_URL=http://localhost:4000
ENV NEXT_PUBLIC_API_URL=$NEXT_PUBLIC_API_URL
RUN pnpm --filter @tracker/shared build && pnpm --filter @tracker/web build
EXPOSE 3000
CMD ["pnpm", "--filter", "@tracker/web", "start"]
