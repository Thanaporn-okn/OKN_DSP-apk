# Facebook Marketplace & Groups Product Tracker

Production-oriented starter monorepo for collecting, normalizing, storing, searching, deduplicating, and streaming product listings from **authorized** Facebook/Meta data sources.

> This repository intentionally does not implement CAPTCHA bypass, access-control bypass, stealth automation, or cookie extraction. Connect collectors only to an official API, an authorized account/session workflow, or an organization-controlled provider that is allowed to access the requested data.

## Architecture

```text
Browser
  │
  ├── REST ───────────────────────────────┐
  └── Socket.IO                           │
             ▼                            ▼
       Next.js Web  ◄────────────── Express API
                                      │       ▲
                                      │       │ Redis Pub/Sub item:new
                                      ▼       │
                                 PostgreSQL   │
                                 + PostGIS    │
                                      ▲       │
                                      │       │
Scheduler → BullMQ/Redis → Collector Worker ─┘
                         │
                         ├── MarketplaceCollector
                         └── FacebookGroupCollector
```

### Data flow

1. Scheduler reads enabled `tracked_searches` and `tracked_groups` and enqueues due jobs.
2. BullMQ gives the job to a Worker with retry + exponential backoff.
3. Collector calls an authorized provider/API and receives raw listings.
4. `ItemProcessor` normalizes fields and computes a secondary fingerprint.
5. Exact duplicate checks use `source_type + external_id` and `post_url`; a short-window fingerprint check reduces secondary duplicates.
6. PostgreSQL unique constraints provide race-safe duplicate protection.
7. On successful insert the Worker publishes the normalized item to Redis channel `tracker:item:new`.
8. API subscribes and emits Socket.IO event `item:new`.
9. `/live` inserts the item into React Query cache without a browser refresh.
10. `/items` searches persisted data with indexed filters and PostGIS `ST_DWithin` radius search.

## Components

- `apps/web` — Next.js 16 + React + TypeScript + Tailwind + TanStack Query + Socket.IO client.
- `apps/api` — Express 5 REST API, validation, auth for mutation endpoints, rate limiting, logging, Socket.IO.
- `workers/collector` — scheduler, BullMQ worker, collectors, normalization, duplicate detection, Redis publish.
- `packages/database` — Prisma 7 schema/client and PostgreSQL/PostGIS migration.
- `packages/shared` — shared Zod schemas, DTOs, API query types, realtime event names.

## Why Node.js + Express

The frontend is already TypeScript. Keeping API and workers on TypeScript allows shared runtime schemas and DTOs, one package manager, one build pipeline, and fewer serialization mismatches. Express 5 is small and predictable for REST, while BullMQ/Socket.IO/Prisma have mature Node integrations.

## Why Socket.IO

This product needs live connection status, automatic reconnect, and room/event semantics. SSE would be simpler for strictly one-way delivery, but Socket.IO gives reconnect behavior and connection lifecycle signals used by the Live UI while still keeping the event contract small (`item:new`).

## Database

Important constraints/indexes:

- Unique: `(source_type, external_id)`
- Unique: `post_url`
- B-tree: `posted_at DESC`, `detected_at DESC`, `price`, `(source_type, source_id)`
- GIN: full-text expression over title/description/seller/source
- GiST: `geo geography(Point,4326)` for radius search
- Trigger keeps `geo` synchronized with latitude/longitude

Core tables:

- `items`
- `tracked_searches`
- `tracked_groups`
- `collector_runs`
- `collector_errors`

## Requirements

- Docker + Docker Compose (recommended), or
- Node.js 24, pnpm 10, PostgreSQL 17 + PostGIS, Redis 7+

## Quick start with Docker

```bash
docker compose up --build
```

This boots in safe development mode with collectors disabled. To configure authorized collection or override secrets, copy `.env.example` to `.env` (or export the variables in your shell) before starting Compose. Change `ADMIN_API_TOKEN` before exposing the service beyond local development.

Open:

- Web: http://localhost:3000
- API health: http://localhost:4000/health

`migrate` is a one-shot Compose service. API and Worker wait for migrations to complete.

## Local development without containerizing Node

Start infrastructure:

```bash
docker compose up -d postgres redis
cp .env.example .env
corepack enable
pnpm install
pnpm db:generate
pnpm db:migrate
pnpm bootstrap
pnpm dev
```

## Environment variables

See `.env.example`.

Key variables:

| Variable | Purpose |
|---|---|
| `DATABASE_URL` | PostgreSQL connection string |
| `REDIS_URL` | BullMQ + Pub/Sub Redis |
| `ADMIN_API_TOKEN` | Bearer token for Search/Group mutations |
| `WEB_ORIGIN` | CORS/Socket.IO allowed web origin |
| `NEXT_PUBLIC_API_URL` | Browser-visible API base URL |
| `COLLECTOR_MODE` | `disabled` or `authorized-http` |
| `MARKETPLACE_PROVIDER_URL` | Authorized marketplace provider endpoint |
| `GROUPS_PROVIDER_URL` | Authorized group provider endpoint |
| `*_PROVIDER_TOKEN` | Server-side provider credential; never sent to browser |

## Authorized collector contract

With `COLLECTOR_MODE=authorized-http`, the worker sends JSON via `POST` to the configured provider URL. The provider should return:

```json
{
  "items": [
    {
      "externalId": "123",
      "title": "iPhone 16 Pro Max 256GB",
      "description": "...",
      "price": 32900,
      "currency": "THB",
      "imageUrl": "https://...",
      "locationName": "Bangkok",
      "latitude": 13.7563,
      "longitude": 100.5018,
      "sellerName": "Seller",
      "postUrl": "https://www.facebook.com/...",
      "postedAt": "2026-09-17T08:00:00.000Z"
    }
  ]
}
```

Marketplace request body contains keyword/location/radius/price/category/sort. Group request body contains group ID/URL, keyword filters, and price filters.

To use Playwright/Puppeteer later, implement the `MarketplaceCollector` / `FacebookGroupCollector` interfaces without changing the worker, DB, API, or frontend. Only use a session and automation flow that your organization is authorized to use and that complies with platform terms.

## REST API

### Items

```text
GET /api/items
GET /api/items/search
GET /api/items/latest?limit=30
GET /api/items/:id
```

Example:

```text
GET /api/items?search=iphone&location=Bangkok&minPrice=10000&maxPrice=40000&sort=newest&page=1&limit=30
```

Radius query requires all three values:

```text
GET /api/items?latitude=13.7563&longitude=100.5018&radiusKm=50&page=1&limit=30
```

### Tracked searches

```text
GET    /api/searches
POST   /api/searches
PUT    /api/searches/:id
DELETE /api/searches/:id
```

### Tracked groups

```text
GET    /api/groups
POST   /api/groups
PUT    /api/groups/:id
DELETE /api/groups/:id
```

All `/api/searches` and `/api/groups` management calls require:

```text
Authorization: Bearer <ADMIN_API_TOKEN>
```

Example tracked search:

```json
{
  "name": "iPhone Bangkok",
  "keyword": "iPhone 16 Pro Max",
  "latitude": 13.7563,
  "longitude": 100.5018,
  "radiusKm": 50,
  "minPrice": 10000,
  "maxPrice": 50000,
  "enabled": true,
  "refreshIntervalSeconds": 300
}
```

Example group:

```json
{
  "name": "กลุ่มซื้อขายมือถือ",
  "facebookGroupId": "xxxxxxxx",
  "facebookGroupUrl": "https://www.facebook.com/groups/xxxxxxxx",
  "enabled": true,
  "refreshIntervalSeconds": 300,
  "keywords": ["iphone", "16 pro"],
  "minPrice": 10000,
  "maxPrice": 50000
}
```

## Realtime API

Socket.IO event:

```text
item:new
```

The payload is the same `ItemDto` used by REST and React Query.

## Running worker separately

```bash
pnpm --filter @tracker/collector-worker dev
# production build
pnpm --filter @tracker/collector-worker build
pnpm --filter @tracker/collector-worker start
```

## Database migration

Development:

```bash
pnpm db:migrate
```

Production/deployment:

```bash
pnpm db:deploy
```

The initial migration enables PostGIS, creates all tables/indexes/constraints, and creates the geo synchronization trigger.

## Production notes

- Put API/Web behind TLS reverse proxy/load balancer.
- Replace the example admin token with a long random secret or integrate OIDC/JWT/RBAC.
- Use a managed PostgreSQL with PostGIS and backups/PITR.
- Use Redis persistence/HA according to your queue durability requirements.
- Run multiple Worker replicas for throughput. For very large numbers of tracked configurations, move scheduler claiming into a DB advisory-lock/lease pattern.
- Separate collector credentials by environment and provider; rotate them independently of user-facing auth.
- Add metrics (Prometheus/OpenTelemetry), dead-letter inspection, alerting for session expiry/rate limiting, and retention policies for `collector_runs`/`collector_errors`.
- For millions of items, consider time partitioning by `detected_at`, keyset pagination for deep result sets, and dedicated PostgreSQL full-text/trigram indexes based on actual query patterns.

## Project structure

```text
facebook-product-tracker/
├─ apps/
│  ├─ api/
│  │  └─ src/
│  │     ├─ config/
│  │     ├─ middleware/
│  │     ├─ repositories/
│  │     ├─ routes/
│  │     ├─ services/
│  │     └─ realtime/
│  └─ web/
│     ├─ app/live/
│     ├─ app/items/
│     ├─ components/
│     └─ lib/
├─ packages/
│  ├─ database/
│  │  ├─ prisma/schema.prisma
│  │  ├─ prisma/migrations/
│  │  └─ src/
│  └─ shared/
├─ workers/
│  └─ collector/
│     └─ src/
│        ├─ collectors/
│        └─ services/
├─ docker/
├─ docker-compose.yml
├─ .env.example
└─ README.md
```

## Detailed diagrams

See `docs/ARCHITECTURE.md` for System Architecture, Component Diagram, Data Flow sequence, service responsibilities, and scaling path.

## Android APK

An Android WebView client is included under `android/`.
GitHub Actions workflow: `.github/workflows/Build_APK.yml`.

Set the optional repository variable `WEB_APP_URL` to the deployed Next.js URL. If omitted, the APK asks for the URL on first launch.

Run the workflow from **Actions -> Build Android APK -> Run workflow**. The output artifact is `FacebookProductTracker.apk`.
