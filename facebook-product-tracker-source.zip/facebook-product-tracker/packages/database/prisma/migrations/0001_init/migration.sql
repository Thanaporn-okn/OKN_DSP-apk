CREATE EXTENSION IF NOT EXISTS postgis;

CREATE TYPE "SourceType" AS ENUM ('MARKETPLACE', 'GROUP');
CREATE TYPE "CollectorRunStatus" AS ENUM ('RUNNING', 'COMPLETED', 'FAILED');

CREATE TABLE "items" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "external_id" TEXT NOT NULL,
  "title" TEXT NOT NULL,
  "description" TEXT,
  "price" DECIMAL(14,2),
  "currency" VARCHAR(8) NOT NULL DEFAULT 'THB',
  "image_url" TEXT,
  "location_name" TEXT,
  "latitude" DECIMAL(9,6),
  "longitude" DECIMAL(9,6),
  "geo" geography(Point,4326),
  "source_type" "SourceType" NOT NULL,
  "source_name" TEXT,
  "source_id" TEXT,
  "seller_name" TEXT,
  "post_url" TEXT,
  "fingerprint" VARCHAR(64),
  "posted_at" TIMESTAMPTZ(3),
  "detected_at" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "created_at" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "items_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "items_post_url_key" ON "items"("post_url");
CREATE UNIQUE INDEX "items_source_external_id_key" ON "items"("source_type", "external_id");
CREATE INDEX "items_posted_at_idx" ON "items"("posted_at" DESC);
CREATE INDEX "items_detected_at_idx" ON "items"("detected_at" DESC);
CREATE INDEX "items_price_idx" ON "items"("price");
CREATE INDEX "items_source_idx" ON "items"("source_type", "source_id");
CREATE INDEX "items_fingerprint_detected_idx" ON "items"("fingerprint", "detected_at");
CREATE INDEX "items_geo_gist_idx" ON "items" USING GIST ("geo");
CREATE INDEX "items_search_fts_idx" ON "items" USING GIN (
  to_tsvector('simple', coalesce("title", '') || ' ' || coalesce("description", '') || ' ' || coalesce("seller_name", '') || ' ' || coalesce("source_name", ''))
);

CREATE OR REPLACE FUNCTION sync_item_geo() RETURNS trigger AS $$
BEGIN
  IF NEW.longitude IS NOT NULL AND NEW.latitude IS NOT NULL THEN
    NEW.geo := ST_SetSRID(ST_MakePoint(NEW.longitude::double precision, NEW.latitude::double precision), 4326)::geography;
  ELSE
    NEW.geo := NULL;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER items_sync_geo
BEFORE INSERT OR UPDATE OF latitude, longitude ON "items"
FOR EACH ROW EXECUTE FUNCTION sync_item_geo();

CREATE TABLE "tracked_searches" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "name" TEXT NOT NULL,
  "keyword" TEXT NOT NULL,
  "latitude" DECIMAL(9,6),
  "longitude" DECIMAL(9,6),
  "radius_km" INTEGER,
  "min_price" DECIMAL(14,2),
  "max_price" DECIMAL(14,2),
  "category" TEXT,
  "sort" TEXT,
  "enabled" BOOLEAN NOT NULL DEFAULT true,
  "refresh_interval_seconds" INTEGER NOT NULL DEFAULT 300,
  "last_run_at" TIMESTAMPTZ(3),
  "created_at" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "tracked_searches_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "tracked_searches_schedule_idx" ON "tracked_searches"("enabled", "last_run_at");

CREATE TABLE "tracked_groups" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "name" TEXT NOT NULL,
  "facebook_group_id" TEXT NOT NULL,
  "facebook_group_url" TEXT NOT NULL,
  "enabled" BOOLEAN NOT NULL DEFAULT true,
  "refresh_interval_seconds" INTEGER NOT NULL DEFAULT 300,
  "keywords" TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
  "min_price" DECIMAL(14,2),
  "max_price" DECIMAL(14,2),
  "last_run_at" TIMESTAMPTZ(3),
  "created_at" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "tracked_groups_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "tracked_groups_facebook_group_id_key" ON "tracked_groups"("facebook_group_id");
CREATE INDEX "tracked_groups_schedule_idx" ON "tracked_groups"("enabled", "last_run_at");

CREATE TABLE "collector_runs" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "collector" TEXT NOT NULL,
  "status" "CollectorRunStatus" NOT NULL,
  "tracked_search_id" UUID,
  "tracked_group_id" UUID,
  "items_found" INTEGER NOT NULL DEFAULT 0,
  "new_items" INTEGER NOT NULL DEFAULT 0,
  "duplicates" INTEGER NOT NULL DEFAULT 0,
  "started_at" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "completed_at" TIMESTAMPTZ(3),
  "duration_ms" INTEGER,
  "error_message" TEXT,
  CONSTRAINT "collector_runs_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "collector_runs_tracked_search_fkey" FOREIGN KEY ("tracked_search_id") REFERENCES "tracked_searches"("id") ON DELETE SET NULL,
  CONSTRAINT "collector_runs_tracked_group_fkey" FOREIGN KEY ("tracked_group_id") REFERENCES "tracked_groups"("id") ON DELETE SET NULL
);
CREATE INDEX "collector_runs_started_idx" ON "collector_runs"("started_at" DESC);

CREATE TABLE "collector_errors" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "run_id" UUID,
  "event" TEXT NOT NULL,
  "message" TEXT NOT NULL,
  "details" JSONB,
  "created_at" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "collector_errors_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "collector_errors_run_fkey" FOREIGN KEY ("run_id") REFERENCES "collector_runs"("id") ON DELETE SET NULL
);
CREATE INDEX "collector_errors_created_idx" ON "collector_errors"("created_at" DESC);
