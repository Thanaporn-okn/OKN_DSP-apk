import { z } from "zod";

export const sourceTypeSchema = z.enum(["MARKETPLACE", "GROUP"]);
export type SourceType = z.infer<typeof sourceTypeSchema>;

export const sortSchema = z.enum([
  "newest",
  "oldest",
  "price_asc",
  "price_desc",
  "recently_detected",
]);
export type ItemSort = z.infer<typeof sortSchema>;

export const itemDtoSchema = z.object({
  id: z.string().uuid(),
  externalId: z.string(),
  title: z.string(),
  description: z.string().nullable(),
  price: z.number().nullable(),
  currency: z.string(),
  imageUrl: z.string().nullable(),
  locationName: z.string().nullable(),
  latitude: z.number().nullable(),
  longitude: z.number().nullable(),
  sourceType: sourceTypeSchema,
  sourceName: z.string().nullable(),
  sourceId: z.string().nullable(),
  sellerName: z.string().nullable(),
  postUrl: z.string().nullable(),
  postedAt: z.string().datetime().nullable(),
  detectedAt: z.string().datetime(),
  createdAt: z.string().datetime(),
});
export type ItemDto = z.infer<typeof itemDtoSchema>;

export const itemQuerySchema = z.object({
  search: z.string().trim().max(200).optional(),
  location: z.string().trim().max(200).optional(),
  latitude: z.coerce.number().min(-90).max(90).optional(),
  longitude: z.coerce.number().min(-180).max(180).optional(),
  radiusKm: z.coerce.number().positive().max(500).optional(),
  minPrice: z.coerce.number().nonnegative().optional(),
  maxPrice: z.coerce.number().nonnegative().optional(),
  source: sourceTypeSchema.optional(),
  sourceId: z.string().trim().max(255).optional(),
  dateFrom: z.coerce.date().optional(),
  dateTo: z.coerce.date().optional(),
  sort: sortSchema.default("newest"),
  page: z.coerce.number().int().positive().default(1),
  limit: z.coerce.number().int().positive().max(100).default(30),
}).superRefine((value, ctx) => {
  const geo = [value.latitude, value.longitude, value.radiusKm];
  const provided = geo.filter((v) => v !== undefined).length;
  if (provided !== 0 && provided !== 3) {
    ctx.addIssue({ code: "custom", message: "latitude, longitude and radiusKm must be provided together" });
  }
  if (value.minPrice !== undefined && value.maxPrice !== undefined && value.minPrice > value.maxPrice) {
    ctx.addIssue({ code: "custom", message: "minPrice cannot exceed maxPrice" });
  }
});
export type ItemQuery = z.infer<typeof itemQuerySchema>;

export const trackedSearchInputSchema = z.object({
  name: z.string().trim().min(1).max(120),
  keyword: z.string().trim().min(1).max(200),
  latitude: z.number().min(-90).max(90).nullable().optional(),
  longitude: z.number().min(-180).max(180).nullable().optional(),
  radiusKm: z.number().int().positive().max(500).nullable().optional(),
  minPrice: z.number().nonnegative().nullable().optional(),
  maxPrice: z.number().nonnegative().nullable().optional(),
  category: z.string().trim().max(100).nullable().optional(),
  sort: z.string().trim().max(50).nullable().optional(),
  enabled: z.boolean().default(true),
  refreshIntervalSeconds: z.number().int().min(30).max(86400).default(300),
});
export type TrackedSearchInput = z.infer<typeof trackedSearchInputSchema>;

export const trackedGroupInputSchema = z.object({
  name: z.string().trim().min(1).max(120),
  facebookGroupId: z.string().trim().min(1).max(255),
  facebookGroupUrl: z.string().url(),
  enabled: z.boolean().default(true),
  refreshIntervalSeconds: z.number().int().min(30).max(86400).default(300),
  keywords: z.array(z.string().trim().min(1).max(100)).max(50).default([]),
  minPrice: z.number().nonnegative().nullable().optional(),
  maxPrice: z.number().nonnegative().nullable().optional(),
});
export type TrackedGroupInput = z.infer<typeof trackedGroupInputSchema>;

export interface PaginatedItems {
  data: ItemDto[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

export const REALTIME_EVENTS = {
  ITEM_NEW: "item:new",
} as const;
