import type { ItemDto, PaginatedItems } from "@tracker/shared";

export const API_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:4000";

async function getJson<T>(path: string): Promise<T> {
  const response = await fetch(`${API_URL}${path}`);
  if (!response.ok) throw new Error(`API request failed: ${response.status}`);
  return response.json() as Promise<T>;
}

export async function getLatestItems(): Promise<ItemDto[]> {
  const payload = await getJson<{ data: ItemDto[] }>("/api/items/latest?limit=60");
  return payload.data;
}

export function searchItems(params: URLSearchParams): Promise<PaginatedItems> {
  return getJson<PaginatedItems>(`/api/items?${params.toString()}`);
}
