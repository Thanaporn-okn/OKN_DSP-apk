"use client";

import { useQuery, useQueryClient } from "@tanstack/react-query";
import type { ItemDto } from "@tracker/shared";
import { REALTIME_EVENTS } from "@tracker/shared";
import { useEffect, useState } from "react";
import { io } from "socket.io-client";
import { ProductCard } from "../../components/ProductCard";
import { RealtimeStatus, type ConnectionState } from "../../components/RealtimeStatus";
import { API_URL, getLatestItems } from "../../lib/api";

export default function LivePage() {
  const queryClient = useQueryClient();
  const [status, setStatus] = useState<ConnectionState>("reconnecting");
  const { data = [], isLoading, error } = useQuery({ queryKey: ["latest-items"], queryFn: getLatestItems });

  useEffect(() => {
    const socket = io(API_URL, { transports: ["websocket", "polling"], reconnection: true });
    socket.on("connect", () => setStatus("live"));
    socket.on("disconnect", () => setStatus("offline"));
    socket.io.on("reconnect_attempt", () => setStatus("reconnecting"));
    socket.on(REALTIME_EVENTS.ITEM_NEW, (item: ItemDto) => {
      queryClient.setQueryData<ItemDto[]>(["latest-items"], (current = []) => [item, ...current.filter((x) => x.id !== item.id)].slice(0, 100));
    });
    return () => { socket.disconnect(); };
  }, [queryClient]);

  return (
    <main className="mx-auto max-w-7xl px-4 py-6">
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div><h1 className="text-2xl font-bold">Real-time Latest Items</h1><p className="mt-1 text-sm text-slate-400">รายการใหม่จะเพิ่มเข้าหน้านี้อัตโนมัติหลังบันทึกฐานข้อมูลสำเร็จ</p></div>
        <RealtimeStatus state={status} />
      </div>
      {isLoading && <p className="text-slate-400">Loading…</p>}
      {error && <p className="text-rose-400">โหลดข้อมูลไม่สำเร็จ</p>}
      {!isLoading && data.length === 0 && <div className="rounded-2xl border border-dashed border-slate-700 p-10 text-center text-slate-500">ยังไม่มีรายการสินค้า</div>}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
        {data.map((item) => <ProductCard key={item.id} item={item} />)}
      </div>
    </main>
  );
}
