"use client";

import { keepPreviousData, useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { ItemFilters, initialFilters, type FilterState } from "../../components/ItemFilters";
import { Pagination } from "../../components/Pagination";
import { ProductCard } from "../../components/ProductCard";
import { searchItems } from "../../lib/api";

function toParams(filters: FilterState, page: number): URLSearchParams {
  const params = new URLSearchParams({ page: String(page), limit: "30", sort: filters.sort });
  for (const key of ["search", "location", "latitude", "longitude", "radiusKm", "minPrice", "maxPrice", "source", "sourceId"] as const) {
    if (filters[key]) params.set(key, filters[key]);
  }
  if (filters.dateFrom) params.set("dateFrom", new Date(`${filters.dateFrom}T00:00:00`).toISOString());
  if (filters.dateTo) params.set("dateTo", new Date(`${filters.dateTo}T23:59:59.999`).toISOString());
  return params;
}

export default function ItemsPage() {
  const [draft, setDraft] = useState(initialFilters);
  const [filters, setFilters] = useState(initialFilters);
  const [page, setPage] = useState(1);
  const params = useMemo(() => toParams(filters, page), [filters, page]);
  const { data, isLoading, error } = useQuery({
    queryKey: ["items", params.toString()],
    queryFn: () => searchItems(params),
    placeholderData: keepPreviousData,
  });

  return (
    <main className="mx-auto max-w-7xl px-4 py-6">
      <div className="mb-5"><h1 className="text-2xl font-bold">Recently Listed Database</h1><p className="mt-1 text-sm text-slate-400">ค้นหา กรอง เรียง และค้นหารัศมีด้วย PostGIS</p></div>
      <ItemFilters value={draft} onChange={setDraft} onApply={() => { setFilters(draft); setPage(1); }} />
      <div className="mb-4 text-sm text-slate-400">{data ? `${data.pagination.total.toLocaleString()} items` : ""}</div>
      {isLoading && <p className="text-slate-400">Loading…</p>}
      {error && <p className="text-rose-400">ค้นหาข้อมูลไม่สำเร็จ</p>}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
        {data?.data.map((item) => <ProductCard key={item.id} item={item} />)}
      </div>
      {data && <Pagination page={data.pagination.page} totalPages={data.pagination.totalPages} onPage={setPage} />}
    </main>
  );
}
