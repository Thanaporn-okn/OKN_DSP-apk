import type { Metadata } from "next";
import Link from "next/link";
import "./globals.css";
import { Providers } from "./providers";

export const metadata: Metadata = {
  title: "Facebook Product Tracker",
  description: "Track authorized Marketplace and Facebook Group listings",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="th">
      <body>
        <Providers>
          <header className="sticky top-0 z-40 border-b border-slate-800 bg-slate-950/90 backdrop-blur">
            <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3">
              <Link href="/live" className="font-semibold tracking-tight">Facebook Product Tracker</Link>
              <nav className="flex gap-2 text-sm">
                <Link href="/live" className="rounded-lg px-3 py-2 hover:bg-slate-800">Live</Link>
                <Link href="/items" className="rounded-lg px-3 py-2 hover:bg-slate-800">Database</Link>
              </nav>
            </div>
          </header>
          {children}
        </Providers>
      </body>
    </html>
  );
}
