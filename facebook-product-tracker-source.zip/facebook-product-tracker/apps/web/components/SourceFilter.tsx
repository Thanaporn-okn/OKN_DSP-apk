"use client";

export function SourceFilter({ source, sourceId, className, onChange }: { source: string; sourceId: string; className?: string; onChange: (key: "source" | "sourceId", value: string) => void }) {
  return <>
    <select className={className} value={source} onChange={(e) => onChange("source", e.target.value)}><option value="">All sources</option><option value="MARKETPLACE">Marketplace</option><option value="GROUP">Facebook Group</option></select>
    <input className={className} placeholder="Group / source ID" value={sourceId} onChange={(e) => onChange("sourceId", e.target.value)} />
  </>;
}
