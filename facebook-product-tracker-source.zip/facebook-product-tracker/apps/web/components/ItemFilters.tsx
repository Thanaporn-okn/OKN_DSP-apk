"use client";

import { LocationFilter } from "./LocationFilter";
import { PriceFilter } from "./PriceFilter";
import { SearchBar } from "./SearchBar";
import { SortDropdown } from "./SortDropdown";
import { SourceFilter } from "./SourceFilter";

export interface FilterState {
  search: string;
  location: string;
  latitude: string;
  longitude: string;
  radiusKm: string;
  minPrice: string;
  maxPrice: string;
  source: string;
  sourceId: string;
  dateFrom: string;
  dateTo: string;
  sort: string;
}

export const initialFilters: FilterState = {
  search: "", location: "", latitude: "", longitude: "", radiusKm: "",
  minPrice: "", maxPrice: "", source: "", sourceId: "", dateFrom: "", dateTo: "", sort: "newest",
};

export function ItemFilters({ value, onChange, onApply }: { value: FilterState; onChange: (next: FilterState) => void; onApply: () => void }) {
  const set = (key: keyof FilterState, input: string) => onChange({ ...value, [key]: input });
  const field = "rounded-xl border border-slate-700 bg-slate-900 px-3 py-2 text-sm placeholder:text-slate-600 focus:border-blue-500";

  return (
    <form className="mb-5 grid grid-cols-1 gap-3 rounded-2xl border border-slate-800 bg-slate-900/60 p-4 md:grid-cols-2 xl:grid-cols-4" onSubmit={(event) => { event.preventDefault(); onApply(); }}>
      <div className="xl:col-span-2"><SearchBar className={`${field} w-full`} value={value.search} onChange={(next) => set("search", next)} /></div>
      <LocationFilter className={field} location={value.location} latitude={value.latitude} longitude={value.longitude} radiusKm={value.radiusKm} onChange={set} />
      <PriceFilter className={field} minPrice={value.minPrice} maxPrice={value.maxPrice} onChange={set} />
      <SourceFilter className={field} source={value.source} sourceId={value.sourceId} onChange={set} />
      <SortDropdown className={field} value={value.sort} onChange={(next) => set("sort", next)} />
      <div className="grid grid-cols-2 gap-2"><input className={field} type="date" value={value.dateFrom} onChange={(e) => set("dateFrom", e.target.value)} /><input className={field} type="date" value={value.dateTo} onChange={(e) => set("dateTo", e.target.value)} /></div>
      <button type="submit" className="rounded-xl bg-blue-600 px-4 py-2 text-sm font-medium hover:bg-blue-500">Apply filters</button>
      <button type="button" onClick={() => onChange(initialFilters)} className="rounded-xl border border-slate-700 px-4 py-2 text-sm hover:bg-slate-800">Reset</button>
    </form>
  );
}
