"use client";

export function SearchBar({ value, onChange, className }: { value: string; onChange: (value: string) => void; className?: string }) {
  return <input className={className} placeholder="Search title, description, seller, source…" value={value} onChange={(event) => onChange(event.target.value)} />;
}
