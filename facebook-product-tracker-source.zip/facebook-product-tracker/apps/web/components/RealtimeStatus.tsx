"use client";

export type ConnectionState = "live" | "reconnecting" | "offline";

export function RealtimeStatus({ state }: { state: ConnectionState }) {
  const label = state === "live" ? "Live" : state === "reconnecting" ? "Reconnecting" : "Offline";
  const dot = state === "live" ? "bg-emerald-400" : state === "reconnecting" ? "bg-amber-400 animate-pulse" : "bg-rose-500";
  return <div className="inline-flex items-center gap-2 rounded-full border border-slate-800 bg-slate-900 px-3 py-1.5 text-sm"><span className={`h-2.5 w-2.5 rounded-full ${dot}`} />{label}</div>;
}
