"use client";

export function SortDropdown({ value, className, onChange }: { value: string; className?: string; onChange: (value: string) => void }) {
  return <select className={className} value={value} onChange={(e) => onChange(e.target.value)}><option value="newest">Newest</option><option value="oldest">Oldest</option><option value="price_asc">Price Low → High</option><option value="price_desc">Price High → Low</option><option value="recently_detected">Recently Detected</option></select>;
}
