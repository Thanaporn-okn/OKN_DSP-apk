"use client";

export function Pagination({ page, totalPages, onPage }: { page: number; totalPages: number; onPage: (page: number) => void }) {
  if (totalPages <= 1) return null;
  return (
    <div className="mt-6 flex items-center justify-center gap-3">
      <button disabled={page <= 1} onClick={() => onPage(page - 1)} className="rounded-lg border border-slate-700 px-3 py-2 text-sm disabled:opacity-40">Previous</button>
      <span className="text-sm text-slate-400">Page {page} / {totalPages}</span>
      <button disabled={page >= totalPages} onClick={() => onPage(page + 1)} className="rounded-lg border border-slate-700 px-3 py-2 text-sm disabled:opacity-40">Next</button>
    </div>
  );
}
