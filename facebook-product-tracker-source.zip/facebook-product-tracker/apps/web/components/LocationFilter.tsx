"use client";

interface Props {
  location: string;
  latitude: string;
  longitude: string;
  radiusKm: string;
  className?: string;
  onChange: (key: "location" | "latitude" | "longitude" | "radiusKm", value: string) => void;
}

export function LocationFilter({ location, latitude, longitude, radiusKm, className, onChange }: Props) {
  return <>
    <input className={className} placeholder="Location name" value={location} onChange={(e) => onChange("location", e.target.value)} />
    <input className={className} type="number" step="any" placeholder="Latitude" value={latitude} onChange={(e) => onChange("latitude", e.target.value)} />
    <input className={className} type="number" step="any" placeholder="Longitude" value={longitude} onChange={(e) => onChange("longitude", e.target.value)} />
    <select className={className} value={radiusKm} onChange={(e) => onChange("radiusKm", e.target.value)}>
      <option value="">Radius</option><option value="10">10 km</option><option value="25">25 km</option><option value="50">50 km</option><option value="100">100 km</option>
    </select>
  </>;
}
