"use client";

export function PriceFilter({ minPrice, maxPrice, className, onChange }: { minPrice: string; maxPrice: string; className?: string; onChange: (key: "minPrice" | "maxPrice", value: string) => void }) {
  return <>
    <input className={className} type="number" min="0" placeholder="Min price" value={minPrice} onChange={(e) => onChange("minPrice", e.target.value)} />
    <input className={className} type="number" min="0" placeholder="Max price" value={maxPrice} onChange={(e) => onChange("maxPrice", e.target.value)} />
  </>;
}
