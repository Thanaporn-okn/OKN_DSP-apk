"use client";

import type { ItemDto } from "@tracker/shared";
import { Clock3, ExternalLink, MapPin, Store, Users } from "lucide-react";

function money(value: number | null, currency: string): string {
  if (value === null) return "ไม่ระบุราคา";
  return new Intl.NumberFormat("th-TH", { style: "currency", currency, maximumFractionDigits: 0 }).format(value);
}

function time(value: string | null): string {
  if (!value) return "ไม่ระบุเวลาโพสต์";
  return new Intl.DateTimeFormat("th-TH", { dateStyle: "medium", timeStyle: "short" }).format(new Date(value));
}

export function ProductCard({ item }: { item: ItemDto }) {
  return (
    <article className="overflow-hidden rounded-2xl border border-slate-800 bg-slate-900 shadow-sm">
      <div className="aspect-[4/3] bg-slate-800">
        {item.imageUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={item.imageUrl} alt={item.title} loading="lazy" className="h-full w-full object-cover" />
        ) : <div className="flex h-full items-center justify-center text-sm text-slate-500">No image</div>}
      </div>
      <div className="space-y-3 p-4">
        <div>
          <h2 className="line-clamp-2 min-h-12 font-semibold text-white">{item.title}</h2>
          <div className="mt-1 text-xl font-bold text-emerald-400">{money(item.price, item.currency)}</div>
        </div>
        <div className="space-y-1.5 text-sm text-slate-400">
          <div className="flex items-center gap-2"><MapPin size={15} />{item.locationName ?? "Unknown location"}</div>
          <div className="flex items-center gap-2">
            {item.sourceType === "GROUP" ? <Users size={15} /> : <Store size={15} />}
            {item.sourceName ?? item.sourceType}
          </div>
          <div className="flex items-center gap-2"><Clock3 size={15} />โพสต์: {time(item.postedAt)}</div>
          <div className="text-xs text-slate-500">ตรวจพบ: {time(item.detectedAt)}</div>
        </div>
        {item.postUrl ? (
          <a href={item.postUrl} target="_blank" rel="noreferrer noopener" className="flex items-center justify-center gap-2 rounded-xl bg-blue-600 px-3 py-2.5 text-sm font-medium hover:bg-blue-500">
            View Facebook Post <ExternalLink size={15} />
          </a>
        ) : <div className="rounded-xl bg-slate-800 px-3 py-2.5 text-center text-sm text-slate-500">No source URL</div>}
      </div>
    </article>
  );
}
