import { closeDatabase } from "@tracker/database";
import cors from "cors";
import express from "express";
import rateLimit from "express-rate-limit";
import helmet from "helmet";
import { createServer } from "node:http";
import pinoHttp from "pino-http";
import { env } from "./config/env.js";
import { logger } from "./logger.js";
import { errorHandler, notFound } from "./middleware/error.js";
import { redisSubscriber } from "./queue/redis.js";
import groupsRouter from "./routes/groups.js";
import itemsRouter from "./routes/items.js";
import searchesRouter from "./routes/searches.js";
import { createRealtimeServer } from "./realtime/server.js";

const app = express();
app.disable("x-powered-by");
app.use(helmet());
app.use(cors({ origin: env.WEB_ORIGIN, credentials: false }));
app.use(express.json({ limit: "1mb" }));
app.use(pinoHttp({ logger }));
app.use(rateLimit({ windowMs: 60_000, limit: 300, standardHeaders: "draft-8", legacyHeaders: false }));

app.get("/health", (_req, res) => res.json({ ok: true, service: "api" }));
app.use("/api/items", itemsRouter);
app.use("/api/searches", searchesRouter);
app.use("/api/groups", groupsRouter);
app.use(notFound);
app.use(errorHandler);

const httpServer = createServer(app);
const io = await createRealtimeServer(httpServer);

httpServer.listen(env.API_PORT, "0.0.0.0", () => {
  logger.info({ event: "api.started", port: env.API_PORT });
});

async function shutdown(signal: string): Promise<void> {
  logger.info({ event: "api.shutdown", signal });
  io.close();
  httpServer.close(async () => {
    await Promise.allSettled([redisSubscriber.quit(), closeDatabase()]);
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 10_000).unref();
}

process.on("SIGTERM", () => void shutdown("SIGTERM"));
process.on("SIGINT", () => void shutdown("SIGINT"));
