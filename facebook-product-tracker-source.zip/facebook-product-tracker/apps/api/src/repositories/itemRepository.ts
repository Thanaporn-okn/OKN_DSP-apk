import { prisma, sqlPool } from "@tracker/database";
import type { ItemDto, ItemQuery, PaginatedItems } from "@tracker/shared";

interface ItemRow {
  id: string;
  external_id: string;
  title: string;
  description: string | null;
  price: string | null;
  currency: string;
  image_url: string | null;
  location_name: string | null;
  latitude: string | null;
  longitude: string | null;
  source_type: "MARKETPLACE" | "GROUP";
  source_name: string | null;
  source_id: string | null;
  seller_name: string | null;
  post_url: string | null;
  posted_at: Date | null;
  detected_at: Date;
  created_at: Date;
}

const toDto = (row: ItemRow): ItemDto => ({
  id: row.id,
  externalId: row.external_id,
  title: row.title,
  description: row.description,
  price: row.price === null ? null : Number(row.price),
  currency: row.currency,
  imageUrl: row.image_url,
  locationName: row.location_name,
  latitude: row.latitude === null ? null : Number(row.latitude),
  longitude: row.longitude === null ? null : Number(row.longitude),
  sourceType: row.source_type,
  sourceName: row.source_name,
  sourceId: row.source_id,
  sellerName: row.seller_name,
  postUrl: row.post_url,
  postedAt: row.posted_at?.toISOString() ?? null,
  detectedAt: row.detected_at.toISOString(),
  createdAt: row.created_at.toISOString(),
});

function buildWhere(query: ItemQuery): { sql: string; params: unknown[] } {
  const clauses: string[] = [];
  const params: unknown[] = [];
  const add = (value: unknown): string => {
    params.push(value);
    return `$${params.length}`;
  };

  if (query.search) {
    const p = add(query.search);
    clauses.push(`to_tsvector('simple', coalesce(title,'') || ' ' || coalesce(description,'') || ' ' || coalesce(seller_name,'') || ' ' || coalesce(source_name,'')) @@ plainto_tsquery('simple', ${p})`);
  }
  if (query.location) {
    const p = add(`%${query.location}%`);
    clauses.push(`location_name ILIKE ${p}`);
  }
  if (query.minPrice !== undefined) clauses.push(`price >= ${add(query.minPrice)}`);
  if (query.maxPrice !== undefined) clauses.push(`price <= ${add(query.maxPrice)}`);
  if (query.source) clauses.push(`source_type = ${add(query.source)}::"SourceType"`);
  if (query.sourceId) clauses.push(`source_id = ${add(query.sourceId)}`);
  if (query.dateFrom) clauses.push(`coalesce(posted_at, detected_at) >= ${add(query.dateFrom)}::timestamptz`);
  if (query.dateTo) clauses.push(`coalesce(posted_at, detected_at) <= ${add(query.dateTo)}::timestamptz`);
  if (query.latitude !== undefined && query.longitude !== undefined && query.radiusKm !== undefined) {
    const lon = add(query.longitude);
    const lat = add(query.latitude);
    const meters = add(query.radiusKm * 1000);
    clauses.push(`geo IS NOT NULL AND ST_DWithin(geo, ST_SetSRID(ST_MakePoint(${lon}, ${lat}), 4326)::geography, ${meters})`);
  }

  return { sql: clauses.length ? `WHERE ${clauses.join(" AND ")}` : "", params };
}

function orderBy(sort: ItemQuery["sort"]): string {
  switch (sort) {
    case "oldest": return "ORDER BY posted_at ASC NULLS LAST, detected_at ASC";
    case "price_asc": return "ORDER BY price ASC NULLS LAST, detected_at DESC";
    case "price_desc": return "ORDER BY price DESC NULLS LAST, detected_at DESC";
    case "recently_detected": return "ORDER BY detected_at DESC";
    case "newest":
    default: return "ORDER BY posted_at DESC NULLS LAST, detected_at DESC";
  }
}

const selectColumns = `
  id, external_id, title, description, price::text, currency, image_url,
  location_name, latitude::text, longitude::text, source_type, source_name,
  source_id, seller_name, post_url, posted_at, detected_at, created_at
`;

export class ItemRepository {
  async findById(id: string): Promise<ItemDto | null> {
    const result = await sqlPool.query<ItemRow>(`SELECT ${selectColumns} FROM items WHERE id = $1::uuid LIMIT 1`, [id]);
    return result.rows[0] ? toDto(result.rows[0]) : null;
  }

  async latest(limit = 30): Promise<ItemDto[]> {
    const result = await sqlPool.query<ItemRow>(`SELECT ${selectColumns} FROM items ORDER BY detected_at DESC LIMIT $1`, [limit]);
    return result.rows.map(toDto);
  }

  async search(query: ItemQuery): Promise<PaginatedItems> {
    const { sql, params } = buildWhere(query);
    const offset = (query.page - 1) * query.limit;
    const listParams = [...params, query.limit, offset];
    const listSql = `SELECT ${selectColumns} FROM items ${sql} ${orderBy(query.sort)} LIMIT $${params.length + 1} OFFSET $${params.length + 2}`;
    const countSql = `SELECT count(*)::int AS total FROM items ${sql}`;

    const [itemsResult, countResult] = await Promise.all([
      sqlPool.query<ItemRow>(listSql, listParams),
      sqlPool.query<{ total: number }>(countSql, params),
    ]);

    const total = countResult.rows[0]?.total ?? 0;
    return {
      data: itemsResult.rows.map(toDto),
      pagination: {
        page: query.page,
        limit: query.limit,
        total,
        totalPages: Math.ceil(total / query.limit),
      },
    };
  }

  async removeAllForDevelopment(): Promise<void> {
    if (process.env.NODE_ENV === "production") throw new Error("disabled in production");
    await prisma.item.deleteMany();
  }
}
