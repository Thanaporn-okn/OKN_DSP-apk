import type { ErrorRequestHandler, RequestHandler } from "express";
import { ZodError } from "zod";
import { logger } from "../logger.js";

export const notFound: RequestHandler = (_req, res) => {
  res.status(404).json({ error: "not_found" });
};

export const errorHandler: ErrorRequestHandler = (error, req, res, _next) => {
  if (error instanceof ZodError) {
    res.status(400).json({ error: "validation_error", details: error.issues });
    return;
  }

  logger.error({ err: error, method: req.method, path: req.path }, "request.failed");
  res.status(500).json({ error: "internal_server_error" });
};
