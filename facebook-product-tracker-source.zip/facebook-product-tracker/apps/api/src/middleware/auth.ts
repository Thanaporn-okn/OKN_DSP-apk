import type { RequestHandler } from "express";
import { env } from "../config/env.js";

export const requireAdmin: RequestHandler = (req, res, next) => {
  const authorization = req.header("authorization");
  if (authorization !== `Bearer ${env.ADMIN_API_TOKEN}`) {
    res.status(401).json({ error: "unauthorized" });
    return;
  }
  next();
};
