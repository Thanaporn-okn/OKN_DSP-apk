import { itemQuerySchema } from "@tracker/shared";
import type { ItemQuery } from "@tracker/shared";
import { ItemRepository } from "../repositories/itemRepository.js";

export class ItemService {
  constructor(private readonly repository = new ItemRepository()) {}

  parseQuery(input: unknown): ItemQuery {
    return itemQuerySchema.parse(input);
  }

  search(input: unknown) {
    return this.repository.search(this.parseQuery(input));
  }

  latest(limit: number) {
    return this.repository.latest(Math.min(Math.max(limit, 1), 100));
  }

  getById(id: string) {
    return this.repository.findById(id);
  }
}
