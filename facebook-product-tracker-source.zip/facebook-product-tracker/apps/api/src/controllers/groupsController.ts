import { prisma } from "@tracker/database";
import { trackedGroupInputSchema } from "@tracker/shared";
import type { Request, Response } from "express";
import { z } from "zod";

const idSchema = z.string().uuid();

export async function listGroups(_req: Request, res: Response): Promise<void> {
  res.json({ data: await prisma.trackedGroup.findMany({ orderBy: { createdAt: "desc" } }) });
}

export async function createGroup(req: Request, res: Response): Promise<void> {
  const input = trackedGroupInputSchema.parse(req.body);
  const row = await prisma.trackedGroup.create({ data: input });
  res.status(201).json({ data: row });
}

export async function updateGroup(req: Request, res: Response): Promise<void> {
  const id = idSchema.parse(req.params.id);
  const input = trackedGroupInputSchema.partial().parse(req.body);
  const row = await prisma.trackedGroup.update({ where: { id }, data: input });
  res.json({ data: row });
}

export async function deleteGroup(req: Request, res: Response): Promise<void> {
  const id = idSchema.parse(req.params.id);
  await prisma.trackedGroup.delete({ where: { id } });
  res.status(204).end();
}
