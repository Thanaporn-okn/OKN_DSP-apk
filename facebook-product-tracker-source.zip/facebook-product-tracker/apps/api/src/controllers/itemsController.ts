import type { Request, Response } from "express";
import { z } from "zod";
import { ItemService } from "../services/itemService.js";

const service = new ItemService();

export async function listItems(req: Request, res: Response): Promise<void> {
  res.json(await service.search(req.query));
}

export async function latestItems(req: Request, res: Response): Promise<void> {
  const limit = z.coerce.number().int().positive().max(100).default(30).parse(req.query.limit);
  res.json({ data: await service.latest(limit) });
}

export async function getItem(req: Request, res: Response): Promise<void> {
  const id = z.string().uuid().parse(req.params.id);
  const item = await service.getById(id);
  if (!item) {
    res.status(404).json({ error: "item_not_found" });
    return;
  }
  res.json({ data: item });
}
