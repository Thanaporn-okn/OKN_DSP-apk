import { prisma } from "@tracker/database";
import { trackedSearchInputSchema } from "@tracker/shared";
import type { Request, Response } from "express";
import { z } from "zod";

const idSchema = z.string().uuid();

export async function listSearches(_req: Request, res: Response): Promise<void> {
  res.json({ data: await prisma.trackedSearch.findMany({ orderBy: { createdAt: "desc" } }) });
}

export async function createSearch(req: Request, res: Response): Promise<void> {
  const input = trackedSearchInputSchema.parse(req.body);
  const row = await prisma.trackedSearch.create({ data: input });
  res.status(201).json({ data: row });
}

export async function updateSearch(req: Request, res: Response): Promise<void> {
  const id = idSchema.parse(req.params.id);
  const input = trackedSearchInputSchema.partial().parse(req.body);
  const row = await prisma.trackedSearch.update({ where: { id }, data: input });
  res.json({ data: row });
}

export async function deleteSearch(req: Request, res: Response): Promise<void> {
  const id = idSchema.parse(req.params.id);
  await prisma.trackedSearch.delete({ where: { id } });
  res.status(204).end();
}
