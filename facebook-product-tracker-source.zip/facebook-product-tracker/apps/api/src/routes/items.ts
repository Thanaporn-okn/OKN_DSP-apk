import { Router } from "express";
import { getItem, latestItems, listItems } from "../controllers/itemsController.js";
import { asyncHandler } from "../utils/asyncHandler.js";

const router = Router();

router.get("/", asyncHandler(listItems));
router.get("/search", asyncHandler(listItems));
router.get("/latest", asyncHandler(latestItems));
router.get("/:id", asyncHandler(getItem));

export default router;
