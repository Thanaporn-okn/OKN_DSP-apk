import { Router } from "express";
import { createSearch, deleteSearch, listSearches, updateSearch } from "../controllers/searchesController.js";
import { requireAdmin } from "../middleware/auth.js";
import { asyncHandler } from "../utils/asyncHandler.js";

const router = Router();
router.use(requireAdmin);
router.get("/", asyncHandler(listSearches));
router.post("/", asyncHandler(createSearch));
router.put("/:id", asyncHandler(updateSearch));
router.delete("/:id", asyncHandler(deleteSearch));

export default router;
