import { Router } from "express";
import { createGroup, deleteGroup, listGroups, updateGroup } from "../controllers/groupsController.js";
import { requireAdmin } from "../middleware/auth.js";
import { asyncHandler } from "../utils/asyncHandler.js";

const router = Router();
router.use(requireAdmin);
router.get("/", asyncHandler(listGroups));
router.post("/", asyncHandler(createGroup));
router.put("/:id", asyncHandler(updateGroup));
router.delete("/:id", asyncHandler(deleteGroup));

export default router;
