import IORedis from "ioredis";
import { env } from "../config/env.js";

export const redisSubscriber = new IORedis(env.REDIS_URL, {
  maxRetriesPerRequest: null,
  enableReadyCheck: true,
});
