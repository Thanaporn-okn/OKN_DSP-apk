import { REALTIME_EVENTS, itemDtoSchema } from "@tracker/shared";
import type { Server as HttpServer } from "node:http";
import { Server } from "socket.io";
import { env } from "../config/env.js";
import { logger } from "../logger.js";
import { redisSubscriber } from "../queue/redis.js";

const CHANNEL = "tracker:item:new";

export async function createRealtimeServer(httpServer: HttpServer): Promise<Server> {
  const io = new Server(httpServer, {
    cors: { origin: env.WEB_ORIGIN, methods: ["GET", "POST"] },
    transports: ["websocket", "polling"],
  });

  io.on("connection", (socket) => {
    logger.info({ event: "realtime.connected", socketId: socket.id });
    socket.on("disconnect", (reason) => logger.info({ event: "realtime.disconnected", socketId: socket.id, reason }));
  });

  redisSubscriber.on("message", (channel, payload) => {
    if (channel !== CHANNEL) return;
    try {
      const item = itemDtoSchema.parse(JSON.parse(payload));
      io.emit(REALTIME_EVENTS.ITEM_NEW, item);
    } catch (error) {
      logger.error({ err: error, event: "realtime.invalid_payload" });
    }
  });

  await redisSubscriber.subscribe(CHANNEL);
  return io;
}
