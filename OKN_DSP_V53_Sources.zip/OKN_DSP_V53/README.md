# OKN DSP V53 — BP1048P4 USB IF3 No-Claim Descriptor Probe

V53 follows the real-board V46–V52 USB evidence. V49 and V51 proved that HID IF4 accepts a 256-byte Output Report, but IF4 `GET_REPORT(Input)` produced no response for either a Generic ACP catalog query or the already hardware-proven BLE UFE authentication request. V52 then showed that Android could not claim IF3 with `force=false`.

V53 therefore sends **zero host-to-device payload bytes** and does not claim or detach IF3. It identifies IF3 from its exact HID report descriptor using endpoint-0 standard control IN only.

## What V53 reads

The physical board reports HID IF3 with one interrupt-IN endpoint `0x81`, max packet 64 bytes, and a 33-byte HID report descriptor in the cached configuration descriptor. V53:
1. requests normal Android USB permission;
2. does **not** call `claimInterface()` at all;
3. reads cached raw USB descriptors locally and derives IF3's advertised report-descriptor length;
4. issues exactly one standard `GET_DESCRIPTOR(report)` device-to-host control request (`0x81 / 0x06 / 0x2200 / wIndex=3`);
5. classifies the exact returned descriptor as keyboard / consumer-media / vendor HID only when the bytes support that conclusion;
6. stops.

## Safety

V53 contains no HID `SET_REPORT`, no HID `GET_REPORT`, no interrupt/bulk transfer, no ACP frame, no UFE authentication frame, no Device Description request, and no actuator/gain/EQ/biquad/effect/SaveParams write in the USB probe. `force=true` is not used. CH1/2/4/5/6/7 output sliders remain fail-closed; CH3/ID8 remains unchanged.
