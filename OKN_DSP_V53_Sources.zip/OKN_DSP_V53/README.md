# OKN DSP V53

V53 removes the remaining Mix-control latency. Master Volume (ID2), Bass Volume (ID8), and Bass Cutoff (ID9) use a latest-value, serialized 55 ms transport lane instead of the inherited 380 ms scheduler. Bass readback is performed only after release, so verification no longer stalls dragging. Band EQ and the V51 Master/Bass relationship are unchanged.
