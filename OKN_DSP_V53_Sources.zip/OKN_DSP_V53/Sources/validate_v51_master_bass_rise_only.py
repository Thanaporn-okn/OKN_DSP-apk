from pathlib import Path
root = Path(__file__).resolve().parents[1]
view = (root/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
state = (root/'app/src/main/java/com/okn/dsp/DspState.java').read_text()
proto = (root/'app/src/main/java/com/okn/dsp/DspProtocol.java').read_text()
gradle = (root/'app/build.gradle').read_text()
readme = (root/'README.md').read_text()

def req(cond, msg):
    if not cond:
        raise SystemExit('V51 validation failed: ' + msg)

req('versionCode 1051' in gradle, 'versionCode')
req("versionName '51.0.0'" in gradle, 'versionName')
req('float masterDelta = next - previousMaster;' in view, 'master delta missing')
req('if (masterDelta > 0f)' in view, 'positive-only link missing')
req('linkedBass = clamp(previousBass + masterDelta, -70f, 70f);' in view, 'Master-up Bass link missing')
req('float linkedBass = previousBass;' in view, 'Master-down Bass hold missing')
req('sendVerifiedScalar(DspProtocol.ID_MASTER_VOLUME, state.masterVolume);' in view, 'Master ID2 write missing')
req('sendVerifiedScalar(DspProtocol.ID_BASS_VOLUME, state.bassVolume);' in view, 'Bass ID8 reassert missing')
req('verifyBassAfterMaster(state.bassVolume)' in view, 'ID8 readback missing')
req('previousBass - (next - previousMaster)' not in view, 'old inverse compensation still present')
req('bassVolume = clamp(value, -70f, 70f);' in state, 'ID8 auto headroom missing')
req('case ID_BASS_VOLUME:' in proto and 'lo = -70f; hi = 70f;' in proto, 'ID8 protocol range missing')
req('drawMixSliderRow(c, left, right, y, "Bass Volume"' in view and ', -70f, 24f, SL_BASS' in view, 'manual Bass UI range changed')
req('Master DOWN  -> BassVolume ID8 must NOT decrease.' in view, 'required down behavior comment missing')
req('Master UP    -> BassVolume ID8 increases' in view, 'required up behavior comment missing')
req('Band EQ' in readme and 'does not change' in readme, 'scope documentation missing')
print('PASS V51 Master-down Bass hold / Master-up Bass rise-only ID8 link')
