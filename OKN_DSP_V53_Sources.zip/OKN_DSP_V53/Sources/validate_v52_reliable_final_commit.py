#!/usr/bin/env python3
from pathlib import Path
import re, sys
root=Path(__file__).resolve().parent.parent
ble=(root/'app/src/main/java/com/okn/dsp/BleManager.java').read_text()
view=(root/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
build=(root/'app/build.gradle').read_text()

def req(ok,msg):
    print(('PASS ' if ok else 'FAIL ')+msg)
    if not ok: sys.exit(1)
req('versionCode 1052' in build and "versionName '52.0.0'" in build, 'V52 version')
req('FINAL_SCALAR_MIN_GAP_MS = 120L' in ble, '120 ms final scalar gap')
req('finalScalarPending' in ble and 'scheduleFinalScalarPump' in ble, 'final scalar lane exists')
req('Intentionally no-op' not in ble, 'old no-op flush removed')
req('pending.remove(key);' in ble and 'finalScalarPending.put(key, PendingCommand.scalar(actuatorId, safe));' in ble, 'slow duplicate removed and latest final retained')
req('flushSliderFinalHardware(activeSlider);' in view, 'drag ACTION_UP final commit')
req('flushSliderFinalHardware(pendingSlider);' in view, 'tap final commit')
req('ble.flushScalarRealtime(DspProtocol.ID_MASTER_VOLUME);' in view, 'Master ID2 final commit')
req('ble.flushScalarRealtime(DspProtocol.ID_BASS_VOLUME);' in view, 'Bass ID8 final commit')
req('ble.flushScalarRealtime(DspProtocol.ID_BASS_CUTOFF);' in view, 'Cutoff ID9 final commit')
# Master must remain ID2 then ID8 in helper body.
m=re.search(r'if \(slider\.type == SL_MASTER\) \{(.*?)\} else if', view, re.S)
req(m is not None and m.group(1).find('ID_MASTER_VOLUME') < m.group(1).find('ID_BASS_VOLUME'), 'Master then Bass final ordering')
req('sendScheduledControl(next);' in ble and 'liveWriteBusy = true;' in ble, 'serialized existing writer retained')
req('scheduleBassReadback(cmd.scalarValue);' in ble, 'Bass readback retained')
req('Master DOWN  -> BassVolume ID8 must NOT decrease.' in view and 'Master UP    -> BassVolume ID8 increases' in view, 'V51 rise-only behavior retained')
req('Bass/Sub DSP Gain' not in view, 'no Bass EQ compensation UI')
print('V52_RELIABLE_FINAL_SCALAR_COMMIT_STATIC_PASS')
