#!/usr/bin/env python3
from pathlib import Path
root = Path(__file__).resolve().parents[1]
view = (root/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
state = (root/'app/src/main/java/com/okn/dsp/DspState.java').read_text()
proto = (root/'app/src/main/java/com/okn/dsp/DspProtocol.java').read_text()
ble = (root/'app/src/main/java/com/okn/dsp/BleManager.java').read_text()
gradle = (root/'app/build.gradle').read_text()
readme = (root/'README.md').read_text()
checks = {
    'version_code_1050': 'versionCode 1050' in gradle,
    'version_name_50': "versionName '50.0.0'" in gradle,
    'manual_bass_ui_still_plus24': '-70f, 24f, SL_BASS, -1' in view,
    'state_compensation_headroom_plus70': 'bassVolume = clamp(value, -70f, 70f);' in state,
    'state_load_plus70': 'prefs.getFloat("bassVolume", 2f), -70f, 70f' in state,
    'state_preset_plus70': 'Float.parseFloat(parts[1]), -70f, 70f' in state,
    'protocol_id8_plus70': 'lo = -70f; hi = 70f; break;' in proto,
    'inverse_master_delta_formula': 'previousBass - (next - previousMaster)' in view,
    'master_write_present': 'sendVerifiedScalar(DspProtocol.ID_MASTER_VOLUME, state.masterVolume);' in view,
    'id8_write_present': 'sendVerifiedScalar(DspProtocol.ID_BASS_VOLUME, state.bassVolume);' in view,
    'id8_readback_after_master': 'verifyBassAfterMaster(state.bassVolume)' in view,
    'firmware_clamp_24_detected': 'boolean clampAt24' in ble,
    'readme_no_band_eq': 'does not use Bass EQ gain' in readme,
    'eq_order_ch3_bass': 'Ch3 Bass/Subwoofer' in readme,
}
failed=[k for k,v in checks.items() if not v]
for k,v in checks.items(): print(('PASS' if v else 'FAIL'), k)
if failed:
    raise SystemExit('V50 validation failed: ' + ', '.join(failed))
print('PASS V50 master-linked BassVolume ID8 compensation')
