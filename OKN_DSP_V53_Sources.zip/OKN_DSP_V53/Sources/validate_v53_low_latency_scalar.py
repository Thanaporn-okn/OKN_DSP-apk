from pathlib import Path
root = Path(__file__).resolve().parents[1]
view = (root/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
ble = (root/'app/src/main/java/com/okn/dsp/BleManager.java').read_text()
gradle = (root/'app/build.gradle').read_text()
checks = {
    'versionCode 1053': 'versionCode 1053' in gradle,
    "versionName '53.0.0'": "versionName '53.0.0'" in gradle,
    'V53 sync label': 'V53 DSP SYNC' in view and 'V53 SYNCED' in ble,
    '55 ms fast scalar gap': 'FINAL_SCALAR_MIN_GAP_MS = 55L' in ble,
    '220 ms release readback': 'BASS_VERIFY_SETTLE_MS = 220L' in ble,
    'Mix IDs routed fast': 'actuatorId == DspProtocol.ID_MASTER_VOLUME' in ble and 'actuatorId == DspProtocol.ID_BASS_VOLUME' in ble and 'actuatorId == DspProtocol.ID_BASS_CUTOFF' in ble,
    'fast lane schedules immediately': 'finalScalarPending.put(key, PendingCommand.scalar(actuatorId, safe));\n            scheduleFinalScalarPump(0L);' in ble,
    'per-drag bass readback removed': 'no automatic per-drag readback here' in ble,
    'release ID8 readback retained': 'if (actuatorId == DspProtocol.ID_BASS_VOLUME) scheduleBassReadback(safe);' in ble,
    'Master priority in fast lane': 'if (finalScalarPending.containsKey(masterKey))' in ble,
    'Master down / Bass hold': 'if (masterDelta > 0f)' in view,
    'no master-motion verify readback': 'ble.verifyBassAfterMaster(state.bassVolume);' not in view,
    'Bass UI remains +24': 'state.bassVolume,\n                String.format(Locale.US, "%+.1f dB", state.bassVolume).replace("+", "+"), -70f, 24f' in view,
}
failed=[k for k,v in checks.items() if not v]
for k,v in checks.items(): print(('PASS' if v else 'FAIL'), k)
if failed: raise SystemExit('V53 validator failed: '+', '.join(failed))
print('V53 LOW-LATENCY SCALAR VALIDATOR: PASS')
