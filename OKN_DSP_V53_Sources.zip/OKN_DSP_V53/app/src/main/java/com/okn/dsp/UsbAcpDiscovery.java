package com.okn.dsp;

import android.content.Context;
import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * V53 zero-TX IF3 descriptor probe for the real OKN BP1048P4 board.
 *
 * V52 observed IF3 cannot be claimed with force=false. V53 deliberately does NOT
 * detach/force-claim IF3. It opens the USB device only long enough to issue a
 * standard device-to-host GET_DESCRIPTOR(Report) request on endpoint 0.
 *
 * Host-to-device payload bytes = 0. No HID SET_REPORT, no HID GET_REPORT, no
 * interrupt transfer, no ACP/UFE frame, no actuator/gain/EQ/effect/SaveParams write.
 */
public final class UsbAcpDiscovery {
    public static final int TARGET_VID = 0x6324;
    public static final int TARGET_PID = 0x1719;
    public static final int TARGET_INTERFACE = 3;

    private static final int USB_RECIP_INTERFACE = 0x01;
    private static final int USB_REQ_GET_DESCRIPTOR = 0x06;
    private static final int HID_DT_REPORT = 0x22;
    private static final int HID_DT_HID = 0x21;
    private static final int USB_DT_INTERFACE = 0x04;
    private static final int IO_TIMEOUT_MS = 1200;

    private UsbAcpDiscovery() {}

    public static UsbDevice findTarget(Context context) {
        UsbManager manager = (UsbManager) context.getSystemService(Context.USB_SERVICE);
        if (manager == null) return null;
        Map<String, UsbDevice> map = manager.getDeviceList();
        if (map == null || map.isEmpty()) return null;
        UsbDevice pid1719Fallback = null;
        for (UsbDevice d : map.values()) {
            if (d == null) continue;
            if (d.getVendorId() == TARGET_VID && d.getProductId() == TARGET_PID && hasTargetHidInterface(d)) return d;
            if (d.getProductId() == TARGET_PID && hasTargetHidInterface(d)) pid1719Fallback = d;
        }
        return pid1719Fallback;
    }

    public static String summary(Context context) {
        UsbManager manager = (UsbManager) context.getSystemService(Context.USB_SERVICE);
        if (manager == null) return "UsbManager unavailable";
        UsbDevice d = findTarget(context);
        if (d == null) return "target 0x6324:0x1719 IF3 not detected";
        return String.format(Locale.US, "%04X:%04X IF3 descriptor-only permission=%s",
                d.getVendorId(), d.getProductId(), manager.hasPermission(d) ? "yes" : "no");
    }

    public static String buildEnumerationReport(Context context) {
        UsbManager manager = (UsbManager) context.getSystemService(Context.USB_SERVICE);
        StringBuilder out = new StringBuilder(3072);
        out.append("OKN DSP V53 — USB IF3 descriptor-only discovery\n")
                .append("SAFETY: USB OUT=0; SET_REPORT=0; GET_REPORT=0; ACP/UFE TX=0; DSP writes=0.\n\n");
        if (manager == null) return out.append("UsbManager unavailable on this device.").toString();
        Map<String, UsbDevice> map = manager.getDeviceList();
        if (map == null || map.isEmpty()) return out.append("No USB device detected.\n").toString();
        List<String> keys = new ArrayList<>(map.keySet());
        Collections.sort(keys);
        out.append("Detected devices: ").append(keys.size()).append("\n\n");
        int n=0;
        for (String key: keys) {
            UsbDevice d=map.get(key); if (d==null) continue; n++;
            out.append('#').append(n).append(' ')
                    .append(String.format(Locale.US,"VID=%04X PID=%04X",d.getVendorId(),d.getProductId()))
                    .append(" ifaces=").append(d.getInterfaceCount())
                    .append(" permission=").append(manager.hasPermission(d)?"yes":"no")
                    .append(isExactTarget(d)?"  <V53 TARGET>":(isTransportCandidate(d)?"  <candidate>":""))
                    .append('\n');
            appendInterfaces(out,d); out.append('\n');
        }
        return out.toString();
    }

    /** Requires Android USB permission. Standard IN request only; IF3 is never claimed. */
    public static String buildIf3DescriptorProbe(Context context, UsbDevice requestedDevice) {
        UsbManager manager = (UsbManager) context.getSystemService(Context.USB_SERVICE);
        StringBuilder out = new StringBuilder(12288);
        out.append("OKN DSP V53 — IF3 HID DESCRIPTOR-ONLY probe\n")
                .append("SAFETY: USB OUT=0; SET_REPORT=0; GET_REPORT=0; ACP/UFE TX=0; DSP writes=0; SaveParams=0.\n")
                .append("IF3 claim is intentionally SKIPPED; force=true is forbidden. Only standard GET_DESCRIPTOR(report) IN is issued.\n\n");
        if (manager == null) return out.append("UsbManager unavailable.").toString();
        UsbDevice d = requestedDevice != null ? requestedDevice : findTarget(context);
        if (d == null) return out.append("Target 0x6324:0x1719 IF3 HID not detected.").toString();
        out.append(String.format(Locale.US,"Target VID=%04X PID=%04X interfaces=%d\n",d.getVendorId(),d.getProductId(),d.getInterfaceCount()));
        if (d.getProductId()!=TARGET_PID || !hasTargetHidInterface(d)) return out.append("FAIL-CLOSED: PID/IF3 mismatch.\n").toString();
        if (!manager.hasPermission(d)) return out.append("USB permission=no. No device connection opened.\n").toString();
        out.append("USB permission=yes\n");
        UsbInterface hid=findInterface(d,TARGET_INTERFACE);
        if (hid==null || hid.getInterfaceClass()!=UsbConstants.USB_CLASS_HID) return out.append("FAIL-CLOSED: IF3 missing/not HID.\n").toString();
        out.append("IF3 class=HID sub=").append(hid.getInterfaceSubclass())
                .append(" proto=").append(hid.getInterfaceProtocol())
                .append(" endpoints=").append(hid.getEndpointCount()).append('\n');
        for (int e=0; e<hid.getEndpointCount(); e++) {
            UsbEndpoint ep=hid.getEndpoint(e);
            out.append(String.format(Locale.US,"  EP 0x%02X %s type=%d maxPacket=%d interval=%d\n",
                    ep.getAddress(), ep.getDirection()==UsbConstants.USB_DIR_IN?"IN":"OUT",
                    ep.getType(), ep.getMaxPacketSize(), ep.getInterval()));
        }
        out.append("claim IF3 = SKIPPED intentionally (V52 force=false failed; force=true remains forbidden)\n");

        UsbDeviceConnection conn=manager.openDevice(d);
        if (conn==null) return out.append("openDevice failed. No control request issued.\n").toString();
        try {
            byte[] raw=conn.getRawDescriptors();
            int hidReportLen=findHidReportLength(raw,TARGET_INTERFACE);
            out.append("\n[1] Cached/raw descriptor metadata\n")
                    .append("rawLength=").append(raw==null?0:raw.length).append('\n')
                    .append("IF3 HID reported reportLen=").append(hidReportLen>0?Integer.toString(hidReportLen):"UNKNOWN").append('\n');
            if(hidReportLen<=0 || hidReportLen>512) {
                return out.append("FAIL-CLOSED: could not derive a sane IF3 report length from cached raw descriptors.\n")
                        .append("V53 COMPLETE: host-to-device payload bytes=0.\n").toString();
            }

            byte[] desc=new byte[hidReportLen];
            int got=conn.controlTransfer(
                    UsbConstants.USB_DIR_IN | UsbConstants.USB_TYPE_STANDARD | USB_RECIP_INTERFACE,
                    USB_REQ_GET_DESCRIPTOR, HID_DT_REPORT<<8, TARGET_INTERFACE,
                    desc, desc.length, IO_TIMEOUT_MS);
            out.append("\n[2] Standard IF3 HID report-descriptor GET without interface claim\n")
                    .append("bmRequestType=0x81 bRequest=0x06 wValue=0x2200 wIndex=3 wLength=").append(hidReportLen).append('\n')
                    .append("GET_DESCRIPTOR(report) result=").append(got).append('\n');
            if(got>0) {
                out.append("if3ReportDescriptor=").append(hex(desc,got)).append('\n');
                appendDescriptorHints(out,desc,got);
            } else {
                out.append("No report descriptor returned without claim. V53 will NOT force-detach the system HID driver.\n");
            }
            out.append("\nV53 COMPLETE: USB OUT=0; SET_REPORT=0; GET_REPORT=0; ACP/UFE TX=0; DSP state unchanged.\n")
                    .append("Copy this full report. The IF3 report descriptor will classify IF3 without detaching its driver.");
            return out.toString();
        } catch (RuntimeException e) {
            return out.append("\nProbe exception: ").append(e.getClass().getSimpleName())
                    .append("\nV53 remains zero-TX and never force-claims IF3.\n").toString();
        } finally {
            conn.close();
        }
    }

    private static int findHidReportLength(byte[] raw,int targetInterface) {
        if(raw==null) return -1;
        int currentIf=-1;
        for(int p=0; p+1<raw.length;) {
            int len=raw[p]&0xFF;
            int type=raw[p+1]&0xFF;
            if(len<2 || p+len>raw.length) break;
            if(type==USB_DT_INTERFACE && len>=9) currentIf=raw[p+2]&0xFF;
            else if(type==HID_DT_HID && currentIf==targetInterface && len>=9) {
                int numDesc=raw[p+5]&0xFF;
                int q=p+6;
                for(int i=0;i<numDesc && q+2<p+len;i++,q+=3) {
                    int childType=raw[q]&0xFF;
                    int childLen=(raw[q+1]&0xFF)|((raw[q+2]&0xFF)<<8);
                    if(childType==HID_DT_REPORT) return childLen;
                }
            }
            p+=len;
        }
        return -1;
    }

    private static void appendDescriptorHints(StringBuilder out, byte[] d, int len) {
        boolean genericDesktop = contains(d,len,new byte[]{0x05,0x01}) || contains(d,len,new byte[]{0x06,0x01,0x00});
        boolean keyboardUsage = contains(d,len,new byte[]{0x09,0x06});
        boolean keyboardPage = contains(d,len,new byte[]{0x05,0x07}) || contains(d,len,new byte[]{0x06,0x07,0x00});
        boolean consumerPage = contains(d,len,new byte[]{0x05,0x0C}) || contains(d,len,new byte[]{0x06,0x0C,0x00});
        boolean vendorFF00 = contains(d,len,new byte[]{0x06,0x00,(byte)0xFF});
        boolean vendorFF = contains(d,len,new byte[]{0x05,(byte)0xFF});
        out.append("descriptorHints: genericDesktop=").append(genericDesktop?"YES":"NO")
                .append(" keyboardUsage=").append(keyboardUsage?"YES":"NO")
                .append(" keyboardPage=").append(keyboardPage?"YES":"NO")
                .append(" consumerPage=").append(consumerPage?"YES":"NO")
                .append(" vendorPage=").append((vendorFF00||vendorFF)?"YES":"NO").append('\n');
        if((genericDesktop&&keyboardUsage)||keyboardPage) out.append("classificationHint=KEYBOARD/HID input candidate\n");
        else if(consumerPage) out.append("classificationHint=CONSUMER/MEDIA HID candidate\n");
        else if(vendorFF00||vendorFF) out.append("classificationHint=VENDOR HID candidate\n");
        else out.append("classificationHint=UNCLASSIFIED; use exact descriptor bytes only\n");
    }

    private static boolean contains(byte[] h,int len,byte[] n){
        if(h==null||n==null||n.length==0) return false;
        int lim=Math.min(len,h.length)-n.length;
        for(int i=0;i<=lim;i++){boolean ok=true;for(int j=0;j<n.length;j++)if(h[i+j]!=n[j]){ok=false;break;}if(ok)return true;}
        return false;
    }
    private static boolean isExactTarget(UsbDevice d){return d!=null&&d.getVendorId()==TARGET_VID&&d.getProductId()==TARGET_PID&&hasTargetHidInterface(d);}
    private static boolean isTransportCandidate(UsbDevice d){return d!=null&&d.getProductId()==TARGET_PID&&hasTargetHidInterface(d);}
    private static boolean hasTargetHidInterface(UsbDevice d){UsbInterface i=findInterface(d,TARGET_INTERFACE);return i!=null&&i.getInterfaceClass()==UsbConstants.USB_CLASS_HID;}
    private static UsbInterface findInterface(UsbDevice d,int id){if(d==null)return null;for(int i=0;i<d.getInterfaceCount();i++){UsbInterface ui=d.getInterface(i);if(ui!=null&&ui.getId()==id)return ui;}return null;}
    private static void appendInterfaces(StringBuilder out,UsbDevice d){
        for(int i=0;i<d.getInterfaceCount();i++){UsbInterface ui=d.getInterface(i);out.append("  IF ").append(ui.getId()).append(" class=").append(ui.getInterfaceClass()).append(" sub=").append(ui.getInterfaceSubclass()).append(" proto=").append(ui.getInterfaceProtocol()).append(" eps=").append(ui.getEndpointCount());if(ui.getInterfaceClass()==UsbConstants.USB_CLASS_HID)out.append(" HID");out.append('\n');for(int e=0;e<ui.getEndpointCount();e++){UsbEndpoint ep=ui.getEndpoint(e);out.append(String.format(Locale.US,"    EP 0x%02X %s type=%d maxPacket=%d interval=%d\n",ep.getAddress(),ep.getDirection()==UsbConstants.USB_DIR_IN?"IN":"OUT",ep.getType(),ep.getMaxPacketSize(),ep.getInterval()));}}
    }
    private static String hex(byte[] b,int len){if(b==null||len<=0)return "";int n=Math.min(len,b.length);StringBuilder s=new StringBuilder(n*2);for(int i=0;i<n;i++)s.append(String.format(Locale.US,"%02X",b[i]&0xFF));return s.toString();}
}
