# OKN DSP Android V14 — Controlled Event Analysis

V14 continues passive BLE research for the GoloPine DSP. It connects, discovers GATT, subscribes to AB02/AB03 notifications, reads AB01 once when readable, and records notification traffic.

New in V14:
- Controlled baseline window (5 seconds)
- Manual controlled-event marker
- Baseline/event length-rate comparison
- Payload reuse comparison
- Position stability statistics for 10/13-byte notifications
- Explicit READ/DISCOVERY/CAPTURE ONLY policy

No guessed DSP/UFE writes are transmitted.
