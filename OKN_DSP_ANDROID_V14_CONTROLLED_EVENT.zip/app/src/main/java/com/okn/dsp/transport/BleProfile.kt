package com.okn.dsp.transport

import java.util.UUID

object BleProfile {
    const val DEVICE_NAME = "GoloPineDSPAudioTurning"

    // Profile A: UUIDs previously observed in the app/bundle.
    val UUID_0001 = UUID.fromString("40af0001-9479-43f6-ae95-c45fb2afb9d2")
    val UUID_0002 = UUID.fromString("40af0002-9479-43f6-ae95-c45fb2afb9d2")
    val UUID_0003 = UUID.fromString("40af0003-9479-43f6-ae95-c45fb2afb9d2")

    // Profile B: directly observed in the 250401 HCI/GATT capture.
    val AB00_SERVICE = UUID.fromString("0000ab00-0000-1000-8000-00805f9b34fb")
    val AB01_WRITE = UUID.fromString("0000ab01-0000-1000-8000-00805f9b34fb")
    val AB02_NOTIFY = UUID.fromString("0000ab02-0000-1000-8000-00805f9b34fb")
    val AB03_NOTIFY = UUID.fromString("0000ab03-0000-1000-8000-00805f9b34fb")
}
