#!/usr/bin/env python3
from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[1]
m=json.loads((root/"evidence_manifest.json").read_text())
errors=[]
if m.get("schema")!=3: errors.append("evidence schema must be 3")
if m.get("project_version")!=11: errors.append("project_version must be 11")
if m.get("target")!="BP1048P4" or m.get("board")!="GoloPine 7CH": errors.append("target/board mismatch")
if m.get("policy")!="FAIL_CLOSED_NO_INFERENCE": errors.append("policy mismatch")
if m.get("hardware_authorized") is not False: errors.append("hardware_authorized must be false")
req=m.get("required_exact_evidence",{})
if any(bool(v) for v in req.values()): errors.append("V11 exact evidence flags must all remain false")
prov=m.get("provenance",{})
if prov.get("previous_source_sha256")!="ea45641781cf9431aeab7303c30ba5b79a134721cce0f33b99ded6b0eb725e6f": errors.append("V10 source provenance mismatch")
if prov.get("validation_zip_sha256")!="1a10372cc810985a8f8916df52371414037b8e738c76ed1b50e75cca8a40a394": errors.append("V10 validation provenance mismatch")
for ob in m.get("observations",[]):
    if ob.get("authorizes") not in ([],None): errors.append("observations may not authorize hardware in V11")
if errors:
    [print("BLOCKED:",e) for e in errors]; sys.exit(1)
print("PASS: V11 evidence manifest is internally consistent and non-authorizing")
