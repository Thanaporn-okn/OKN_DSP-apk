#!/usr/bin/env python3
from pathlib import Path
import argparse, json, sys
from flash_policy import evaluate
root=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser(description="Non-executing flash preflight. Never emits programmer commands.")
p.add_argument("--expect-locked",action="store_true")
a=p.parse_args()
t=json.loads((root/"target_port_manifest.json").read_text())
s=json.loads((root/"flash_session_manifest.json").read_text())
r=evaluate(t,s)
print("FLASH_SESSION="+("READY" if r["generic_ready"] else "BLOCKED"))
print("MOBILE_FLASH="+("READY" if r["mobile_ready"] else "BLOCKED"))
for k in r["target_missing"]: print("target:"+k+"=BLOCKED")
for k in r["session_missing"]: print("session:"+k+"=BLOCKED")
if a.expect_locked and (r["generic_ready"] or r["mobile_ready"]):
    print("ERROR: locked V11 unexpectedly became flash-ready")
    sys.exit(1)
