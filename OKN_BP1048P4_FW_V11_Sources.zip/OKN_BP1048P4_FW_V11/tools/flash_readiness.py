#!/usr/bin/env python3
from pathlib import Path
import argparse,json,sys
root=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser(); p.add_argument("--expect-locked",action="store_true"); a=p.parse_args()
m=json.loads((root/"target_port_manifest.json").read_text()); ev=m.get("evidence",{})
required=[
"exact_bp1048p4_sdk","exact_chip_identity","exact_golopine_board_identity",
"startup","linker_memory_map","flash_programmer","programmer_transport",
"image_layout","image_format","recovery_path","power_safety",
"original_firmware_backup_readback","post_flash_readback_verify","board_pin_map"]
missing=[k for k in required if not bool(ev.get(k))]
ready=not missing and bool(m.get("hardware_flashable"))
mobile=ready and bool(ev.get("android_host_transport")) and bool(m.get("mobile_flashable"))
print("FLASH_READINESS="+("READY" if ready else "LOCKED"))
print("MOBILE_FLASH_READINESS="+("READY" if mobile else "LOCKED"))
print("TARGET="+str(m.get("target"))); print("BOARD="+str(m.get("board")))
for k in required+["android_host_transport"]: print(f"{k}={'PASS' if bool(ev.get(k)) else 'BLOCKED'}")
if a.expect_locked and (ready or mobile):
    print("ERROR: V11 must not become flash-ready without a reviewed exact-target evidence transition."); sys.exit(1)
