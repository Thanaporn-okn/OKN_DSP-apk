# OKN_BP1048P4_FW_V11

Portable clean-room control/DSP firmware architecture for the GoloPine 7CH
target using BP1048P4 as the intended chip. Hardware access remains fail-closed.

V11 is a memory-readiness release. V10 GitHub Actions validation was accepted
with source SHA `ea45641781cf9431aeab7303c30ba5b79a134721cce0f33b99ded6b0eb725e6f` and validation ZIP SHA `1a10372cc810985a8f8916df52371414037b8e738c76ed1b50e75cca8a40a394`.

The reference 7-channel / 50 ms delay memory is no longer embedded inside
`okn_audio_engine_t`. Delay storage is now a **caller-owned external arena**.
A non-zero delay request without a correctly sized arena fails closed with
`OKN_ERR_BUFFER`. This lets a future authenticated BP1048P4 linker/memory map
choose legal placement instead of this portable project guessing a RAM bank.

Reference delay requirement at the current project ceiling:
- 48 kHz
- 50 ms
- 2401 float samples per channel including guard stride
- 7 channels
- 16807 float samples / 67228 bytes for 32-bit float

Those numbers describe the OKN reference implementation only. V11 does **not**
claim that BP1048P4 has sufficient RAM or that any particular RAM address/bank
is valid. `resource_requirements.json` and `verify_resource_gate.py` keep exact
target RAM capacity, arena placement and persistence workspace authorization
locked until verified target evidence exists.

V10 control-plane fixes are preserved: GET_INFO reports the actual firmware
version from the shared version header, and application command failures are
encoded in negative ACKs without aborting stream transport.

Run `make verify`, `make test`, and `make demo`.
This release remains `hardware_flashable=false` and `mobile_flashable=false`
and intentionally ships no target `.bin`.
