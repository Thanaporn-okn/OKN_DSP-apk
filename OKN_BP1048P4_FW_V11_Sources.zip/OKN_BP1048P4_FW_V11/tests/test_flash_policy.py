#!/usr/bin/env python3
from pathlib import Path
import copy,json,sys
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/"tools"))
from flash_policy import evaluate, GENERIC_TARGET_REQ, SESSION_REQ
t=json.loads((root/"target_port_manifest.json").read_text())
s=json.loads((root/"flash_session_manifest.json").read_text())
r=evaluate(t,s)
assert not r["generic_ready"] and not r["mobile_ready"]
assert "exact_bp1048p4_sdk" in r["target_missing"]
assert "original_firmware_backup_readback" in r["target_missing"]
# Synthetic proof-only unit case: the evaluator can become READY only when every
# required field and explicit authorization is true. No hardware command is run.
t2=copy.deepcopy(t); s2=copy.deepcopy(s)
for k in GENERIC_TARGET_REQ: t2["evidence"][k]=True
t2["evidence"]["android_host_transport"]=True
t2["hardware_flashable"]=True; t2["mobile_flashable"]=True
for k in SESSION_REQ: s2["preflight"][k]=True
s2["preflight"]["android_host_transport"]=True
s2["execution_authorized"]=True
r2=evaluate(t2,s2)
assert r2["generic_ready"] and r2["mobile_ready"]
t2["evidence"]["exact_golopine_board_identity"]=False
assert not evaluate(t2,s2)["generic_ready"]
t2["evidence"]["exact_golopine_board_identity"]=True
s2["preflight"]["backup_hash_verified"]=False
assert not evaluate(t2,s2)["generic_ready"]
print("ALL V11 FLASH POLICY TESTS PASS")
