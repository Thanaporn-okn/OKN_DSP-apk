# OKN DSP Android Controller V1

สร้างจาก `DSP_APP_RESEARCH_BUNDLE_V1.zip`

## สถานะ
- Android app สำหรับมือถือ
- BLE scan หา `GoloPineDSPAudioTurning`
- ใช้ UUID ที่ค้นพบใน bundle
- โหมดนี้เป็น READ/DISCOVERY เท่านั้น
- ปิดการ WRITE DSP ไว้จนกว่าจะยืนยัน packet framing, checksum/CRC, authentication/encryption และ actuator paths จาก capture จริง

## Build บนมือถือผ่าน GitHub
1. สร้าง repository ใหม่บน GitHub
2. อัปโหลดไฟล์ ZIP นี้แล้วแตกไฟล์ให้โครงสร้าง `app/`, `build.gradle.kts`, `.github/` อยู่ที่ root
3. ไปที่ Actions
4. เลือก `Build Android APK`
5. กด `Run workflow`
6. เมื่อเสร็จ เปิด run นั้น แล้วดาวน์โหลด artifact `OKN-DSP-debug-apk`

หมายเหตุ: Android Studio ไม่จำเป็นต้องใช้บนมือถือ เพราะ GitHub Actions เป็นตัว build APK ให้


Build fix: Kotlin JVM toolchain is pinned to JDK 17 to match Android Java compilation.
\n\nV1.2 crash fix: BLE scanner now obtains BluetoothAdapter from BluetoothManager and checks Bluetooth/scanner availability before scanning.\n
V2 BLE Discovery:
- Scan and select the discovered DSP.
- Connect over BLE.
- Discover and display all GATT services, characteristics, properties and descriptors.
- Logs notification packets if the device sends them.
- Does not write DSP commands and does not enable notifications automatically.

V3 BLE Packet Logger:
- Automatically subscribes to NOTIFY/INDICATE characteristics after GATT discovery using the standard CCCD mechanism.
- Logs incoming notification bytes as HEX (up to 64 bytes per notification).
- Does not send UFE/DSP actuator commands.
- Use captured HEX sequences to identify framing, length, command IDs and checksum in the next research step.

V4 protocol observation:
- Queues CCCD notification subscriptions sequentially to avoid GATT_BUSY when AB02/AB03 are enabled back-to-back.
- Performs standard GATT READ only on readable characteristics and logs returned bytes as HEX.
- No DSP/UFE actuator write is performed.
- This build is intended to obtain the first real byte samples for protocol analysis.
