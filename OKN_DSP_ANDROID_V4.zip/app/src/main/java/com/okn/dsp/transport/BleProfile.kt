package com.okn.dsp.transport

object BleProfile {
    const val DEVICE_NAME = "GoloPineDSPAudioTurning"
    val UUID_0001 = java.util.UUID.fromString("40af0001-9479-43f6-ae95-c45fb2afb9d2")
    val UUID_0002 = java.util.UUID.fromString("40af0002-9479-43f6-ae95-c45fb2afb9d2")
    val UUID_0003 = java.util.UUID.fromString("40af0003-9479-43f6-ae95-c45fb2afb9d2")
}
