package com.okn.dsp.transport

interface DspTransport {
    suspend fun connect(): Boolean
    suspend fun disconnect()
    suspend fun write(bytes: ByteArray)
    fun setNotificationHandler(handler: (ByteArray) -> Unit)
}
