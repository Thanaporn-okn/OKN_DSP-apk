package com.okn.dsp.protocol

data class UfePacket(val command: Int, val payload: ByteArray)

class UfeCodec {
    // IMPORTANT: exact UFE framing/checksum/encryption is NOT confirmed by the research bundle.
    // Keep encoding disabled until packet captures verify the frame format.
    fun encode(p: UfePacket): ByteArray =
        error("UFE framing not verified; write disabled")

    fun decode(b: ByteArray): UfePacket =
        error("UFE framing not verified")
}
