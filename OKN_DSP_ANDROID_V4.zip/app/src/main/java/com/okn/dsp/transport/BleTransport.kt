package com.okn.dsp.transport

import android.annotation.SuppressLint
import android.bluetooth.*
import android.content.Context
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import java.util.UUID

@SuppressLint("MissingPermission")
class BleTransport(private val context: Context) : DspTransport {
    private val manager = context.getSystemService(BluetoothManager::class.java)
    private val adapter get() = manager?.adapter
    private var gatt: BluetoothGatt? = null
    private var notifyHandler: ((ByteArray) -> Unit)? = null
    private var notifyCharacteristic: BluetoothGattCharacteristic? = null
    private var writeCharacteristic: BluetoothGattCharacteristic? = null

    override fun setNotificationHandler(handler: (ByteArray) -> Unit) {
        notifyHandler = handler
    }

    suspend fun connect(device: BluetoothDevice): Boolean =
        suspendCancellableCoroutine { cont ->
            val callback = object : BluetoothGattCallback() {
                override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
                    if (newState == BluetoothProfile.STATE_CONNECTED) {
                        g.discoverServices()
                    } else if (cont.isActive) cont.resume(false)
                }
                override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
                    if (status != BluetoothGatt.GATT_SUCCESS) {
                        if (cont.isActive) cont.resume(false)
                        return
                    }
                    val all = g.services.flatMap { it.characteristics }
                    notifyCharacteristic = all.firstOrNull { it.uuid == BleProfile.UUID_0002 }
                    writeCharacteristic = all.firstOrNull { it.uuid == BleProfile.UUID_0003 }
                        ?: all.firstOrNull { it.properties and BluetoothGattCharacteristic.PROPERTY_WRITE != 0 ||
                                             it.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0 }
                    notifyCharacteristic?.let { ch ->
                        g.setCharacteristicNotification(ch, true)
                    }
                    if (cont.isActive) cont.resume(true)
                }
                override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray) {
                    notifyHandler?.invoke(value)
                }
            }
            gatt = device.connectGatt(context, false, callback)
            cont.invokeOnCancellation { gatt?.close(); gatt = null }
        }

    override suspend fun connect(): Boolean = false

    override suspend fun disconnect() {
        gatt?.disconnect()
        gatt?.close()
        gatt = null
    }

    override suspend fun write(bytes: ByteArray) {
        // Deliberately blocked: protocol framing/command IDs/CRC/authentication are not verified.
        error("DSP write is disabled until protocol capture verification")
    }

    fun connectedGatt(): Boolean = gatt != null
}
