Reference screens supplied by the user and used for the V3 Compose layout:
01_HOME.png
02_EQ.png
03_CROSSOVER.png
04_DELAY.png
05_OUTPUT.png

The app recreates the structure as interactive Compose controls; the screenshots are not used as static screen backgrounds.
