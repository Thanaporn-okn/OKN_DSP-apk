# OKN_DSP V3 UI layout pass

V3 restructures the Compose UI around the five uploaded reference screens.

- Header: waveform logo, DSP title, connection pill, settings control.
- Non-home pages: seven equal-width CH1-CH7 selectors visible at once.
- Home: six reference-style parameter strips with icon, labels, live slider, scale and value box; source/preset/status lower cards.
- EQ: title + channel/reset controls in the same header row, graph, three band page selectors, live band table and preset area.
- Crossover: title + magnitude/reset controls in the same row, graph, labeled HPF/LPF controls and advanced settings.
- Delay: title + ms/cm + sync controls in the same row, car sound-position view, reference cards and seven delay strips with scales.
- Output: title + mute/reset controls in the same row, output overview + master level and seven live channel strips.
- Responsive behavior: compact sizing below 390dp, wider layout up to 820dp, scrollable content with fixed bottom navigation.

All sliders, tabs, switches, drop-down selectors and action buttons update Compose state immediately. BLE command bytes remain unwired until confirmed protocol frames are available; V3 does not invent DSP commands.
