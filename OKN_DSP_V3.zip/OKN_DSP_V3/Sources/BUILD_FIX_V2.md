# OKN_DSP V2 — Build Fix

## GitHub Actions error fixed

V1 failed at Kotlin compilation with:

`Ui.kt:425:131 No value passed for parameter 'onSelect'.`

Cause: `DropdownSelector` has a required `onSelect` function parameter followed by optional parameters. The V1 call used a trailing lambda, which Kotlin bound to the last function-typed parameter (`directValue`) instead of the required `onSelect` parameter.

V2 fixes the EQ channel selector call by naming the argument explicitly:

`onSelect = { ... }`

Version increment:
- versionCode: 2
- versionName: 1.0.1-v2
- project name: OKN_DSP_V2

No DSP protocol bytes were invented or changed in this build fix.
