# OKN_DSP V2: no custom ProGuard rules yet.
