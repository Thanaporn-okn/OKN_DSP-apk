# Phase 1 intentionally has no shrinking rules.
