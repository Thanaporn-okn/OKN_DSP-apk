package com.okn.dsp

import android.content.Context
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.roundToInt

private val SamsungBlue = Color(0xFF1677FF)
private val Bg = Color(0xFFF6F8FC)
private val Card = Color.White
private val TextMain = Color(0xFF10131A)
private val TextMuted = Color(0xFF71809A)
private val Green = Color(0xFF32C85C)
private val Orange = Color(0xFFFF921D)
private val Purple = Color(0xFF7B61FF)
private val Cyan = Color(0xFF10BED0)
private val Pink = Color(0xFFEF5575)
private val Divider = Color(0xFFE8EDF5)

private val AppColors = lightColorScheme(
    primary = SamsungBlue,
    background = Bg,
    surface = Card,
    onBackground = TextMain,
    onSurface = TextMain
)

private enum class Tab(val title: String) { HOME("Home"), MIX("Mix"), EQ("Eq") }

private data class EqBand(var frequency: Float, var q: Float, var gain: Float)
private class ChannelEq(initialBands: List<EqBand>, initialVolume: Float = 0f) {
    val bands = mutableStateListOf<EqBand>().apply { addAll(initialBands) }
    var volume by mutableFloatStateOf(initialVolume)
}

private fun defaultBands(): List<EqBand> = listOf(
    20f, 31.5f, 50f, 80f, 125f, 200f, 315f, 500f, 800f,
    1250f, 2000f, 3150f, 5000f, 8000f, 16000f
).map { EqBand(it, 1f, 0f) }

private class UiState(context: Context) {
    var currentTab by mutableStateOf(Tab.HOME)
    var bluetoothConnected by mutableStateOf(false)
    var dspConnected by mutableStateOf(false)
    var masterVolume by mutableFloatStateOf(-6f)
    var bassVolume by mutableFloatStateOf(0f)
    var bassCutoff by mutableFloatStateOf(80f)
    val channelVolumes = mutableStateListOf(-3f, -6f, -2f, -8f, 0f, -4f, -10f)
    var selectedChannel by mutableIntStateOf(0)
    var selectedBand by mutableIntStateOf(0)
    val eqChannels = List(7) { ChannelEq(defaultBands()) }
    var presetName by mutableStateOf("")
    var presetRefresh by mutableIntStateOf(0)
    var audioInputIndex by mutableIntStateOf(0)
    var amplifierLinked by mutableStateOf(false)
    var showVersionDetails by mutableStateOf(false)
    private val prefs = context.getSharedPreferences("okn_dsp_v3_presets", Context.MODE_PRIVATE)

    val presets: List<String>
        get() = prefs.all.keys.sorted()

    fun setChannelVolume(index: Int, value: Float) {
        channelVolumes[index] = value.coerceIn(-60f, 12f)
    }

    fun updateBand(channel: Int, band: Int, frequency: Float? = null, q: Float? = null, gain: Float? = null) {
        val old = eqChannels[channel].bands[band]
        eqChannels[channel].bands[band] = EqBand(
            frequency = (frequency ?: old.frequency).coerceIn(20f, 20000f),
            q = (q ?: old.q).coerceIn(0.1f, 10f),
            gain = (gain ?: old.gain).coerceIn(-12f, 12f)
        )
    }

    fun resetEq(channel: Int) {
        eqChannels[channel].bands.clear()
        eqChannels[channel].bands.addAll(defaultBands())
        selectedBand = 0
    }

    fun savePreset(name: String): Boolean {
        val clean = name.trim()
        if (clean.isEmpty()) return false
        val payload = buildString {
            append("M=").append(masterVolume).append('|')
            append("BV=").append(bassVolume).append('|')
            append("BC=").append(bassCutoff).append('|')
            append("CV=").append(channelVolumes.joinToString(",")).append('|')
            eqChannels.forEachIndexed { ci, ch ->
                append("C").append(ci).append('=')
                append(ch.volume).append(';')
                append(ch.bands.joinToString(";") { "${it.frequency},${it.q},${it.gain}" })
                append('|')
            }
        }
        prefs.edit().putString(clean, payload).apply()
        presetRefresh++
        return true
    }

    fun loadPreset(name: String): Boolean {
        val payload = prefs.getString(name, null) ?: return false
        return runCatching {
            val parts = payload.split('|').filter { it.contains('=') }.associate {
                it.substringBefore('=') to it.substringAfter('=')
            }
            masterVolume = parts.getValue("M").toFloat()
            bassVolume = parts.getValue("BV").toFloat()
            bassCutoff = parts.getValue("BC").toFloat()
            val cvs = parts.getValue("CV").split(',').map { it.toFloat() }
            cvs.take(7).forEachIndexed { i, v -> channelVolumes[i] = v }
            repeat(7) { ci ->
                val c = parts.getValue("C$ci").split(';')
                eqChannels[ci].volume = c.first().toFloat()
                c.drop(1).take(15).forEachIndexed { bi, row ->
                    val x = row.split(',')
                    eqChannels[ci].bands[bi] = EqBand(x[0].toFloat(), x[1].toFloat(), x[2].toFloat())
                }
            }
            true
        }.getOrDefault(false)
    }

    fun deletePreset(name: String) {
        prefs.edit().remove(name).apply()
        presetRefresh++
    }
}

@Composable
fun OknDspApp() {
    val context = LocalContext.current
    val state = remember { UiState(context) }
    MaterialTheme(colorScheme = AppColors) {
        Scaffold(
            containerColor = Bg,
            bottomBar = { BottomNavigation(state.currentTab) { state.currentTab = it } }
        ) { padding ->
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                val tablet = maxWidth >= 720.dp
                when (state.currentTab) {
                    Tab.HOME -> HomeScreen(state, tablet)
                    Tab.MIX -> MixScreen(state, tablet)
                    Tab.EQ -> EqScreen(state, tablet)
                }
            }
        }
    }
}

@Composable
private fun ScreenHeader(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 16.dp)) {
        Text(title, fontSize = 38.sp, fontWeight = FontWeight.ExtraBold, color = TextMain)
        Text(subtitle, fontSize = 16.sp, color = TextMuted)
    }
}

@Composable
private fun HomeScreen(state: UiState, tablet: Boolean) {
    val both = state.bluetoothConnected && state.dspConnected
    val pad = if (tablet) 36.dp else 20.dp
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = pad, end = pad, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { ScreenHeader("OKN DSP", "DSP Controller • Phase 1 UI") }
        item {
            StatusHero(
                ready = both,
                onClick = {
                    val target = !both
                    state.bluetoothConnected = target
                    state.dspConnected = target
                }
            )
        }
        item { Text("Connection & Status", fontSize = 24.sp, fontWeight = FontWeight.Bold) }
        item { ResponsiveStatusGrid(tablet, state) }
        item {
            ElevatedCard(
                onClick = { state.currentTab = Tab.MIX },
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = Card),
                elevation = CardDefaults.elevatedCardElevation(defaultElevation = 1.dp)
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(22.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Equalizer, null, tint = SamsungBlue, modifier = Modifier.size(34.dp))
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Quick Control", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("Open Mix controls", color = TextMuted)
                    }
                    Icon(Icons.Default.ChevronRight, null, tint = TextMuted)
                }
            }
        }
    }
}

@Composable
private fun ResponsiveStatusGrid(tablet: Boolean, state: UiState) {
    val cards: List<@Composable () -> Unit> = listOf(
        {
            StatusCard(
                Icons.Default.Bluetooth, SamsungBlue, "Bluetooth",
                if (state.bluetoothConnected) "Phone connected" else "Tap to connect",
                state.bluetoothConnected
            ) { state.bluetoothConnected = !state.bluetoothConnected }
        },
        {
            StatusCard(
                Icons.Default.Memory, Purple, "DSP Device",
                if (state.dspConnected) "OKN DSP • UI simulation" else "No device connected",
                state.dspConnected
            ) { state.dspConnected = !state.dspConnected }
        },
        {
            val inputs = listOf("AUX", "Bluetooth", "USB")
            StatusCard(
                Icons.Default.GraphicEq, Orange, "Audio Input",
                "${inputs[state.audioInputIndex]} (Simulation)", true
            ) { state.audioInputIndex = (state.audioInputIndex + 1) % inputs.size }
        },
        {
            StatusCard(
                Icons.Default.Speaker, Pink, "Amplifier Link",
                if (state.amplifierLinked) "Linked (Simulation)" else "Tap to simulate link",
                state.amplifierLinked
            ) { state.amplifierLinked = !state.amplifierLinked }
        },
        { StatusCard(Icons.Default.Save, Cyan, "Preset Storage", "Local UI presets", true) { state.currentTab = Tab.EQ } },
        {
            StatusCard(
                Icons.Default.SystemUpdate, Purple, "Version",
                if (state.showVersionDetails) "V3 • Phase 1 • UI only" else "3.0.0 • Phase 1",
                true
            ) { state.showVersionDetails = !state.showVersionDetails }
        }
    )
    if (!tablet) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) { cards.forEach { it() } }
    } else {
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                cards.filterIndexed { i, _ -> i % 2 == 0 }.forEach { it() }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                cards.filterIndexed { i, _ -> i % 2 == 1 }.forEach { it() }
            }
        }
    }
}

@Composable
private fun StatusHero(ready: Boolean, onClick: () -> Unit) {
    val c by animateColorAsState(if (ready) Color(0xFFE9FBEF) else Color(0xFFFFF4E8), label = "hero")
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        onClick = onClick,
        shape = RoundedCornerShape(30.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = c)
    ) {
        Row(Modifier.padding(24.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = CircleShape, color = if (ready) Green else Orange, modifier = Modifier.size(68.dp)) {
                Icon(
                    if (ready) Icons.Default.Check else Icons.Default.PowerSettingsNew,
                    null,
                    tint = Color.White,
                    modifier = Modifier.padding(18.dp)
                )
            }
            Spacer(Modifier.width(18.dp))
            Column(Modifier.weight(1f)) {
                Text("SYSTEM STATUS", color = TextMuted, fontSize = 13.sp)
                Text(if (ready) "System Ready" else "Tap to Connect", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Text(if (ready) "UI connections are active." else "Phase 1 uses simulated connection state.", color = TextMuted)
            }
        }
    }
}

@Composable
private fun StatusCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconColor: Color,
    title: String,
    detail: String,
    active: Boolean,
    onClick: () -> Unit
) {
    ElevatedCard(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = Card),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 1.dp)
    ) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = CircleShape, color = iconColor.copy(alpha = .12f), modifier = Modifier.size(52.dp)) {
                Icon(icon, null, tint = iconColor, modifier = Modifier.padding(13.dp))
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Text(detail, fontSize = 14.sp, color = TextMuted)
            }
            Box(Modifier.size(10.dp).background(if (active) Green else Color(0xFFB7C0CF), CircleShape))
        }
    }
}

@Composable
private fun MixScreen(state: UiState, tablet: Boolean) {
    val pad = if (tablet) 36.dp else 20.dp
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Mix", "Channel and bass controls")
        if (tablet) {
            Row(
                Modifier.fillMaxSize().padding(horizontal = pad),
                horizontalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    SectionCard("Global") {
                        ControlSlider("Master Volume", state.masterVolume, -60f, 12f, "dB", Icons.Default.VolumeUp) { state.masterVolume = it }
                        ControlSlider("Bass Volume", state.bassVolume, -60f, 12f, "dB", Icons.Default.GraphicEq) { state.bassVolume = it }
                        ControlSlider("Bass Cutoff", state.bassCutoff, 20f, 200f, "Hz", Icons.Default.FilterAlt) { state.bassCutoff = it }
                    }
                }
                Column(Modifier.weight(1.25f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    SectionCard("Channels") {
                        repeat(7) { i ->
                            ControlSlider("Volume Ch${i + 1}", state.channelVolumes[i], -60f, 12f, "dB", Icons.Default.Speaker) {
                                state.setChannelVolume(i, it)
                            }
                        }
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = pad, end = pad, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    SectionCard("Global") {
                        ControlSlider("Master Volume", state.masterVolume, -60f, 12f, "dB", Icons.Default.VolumeUp) { state.masterVolume = it }
                        ControlSlider("Bass Volume", state.bassVolume, -60f, 12f, "dB", Icons.Default.GraphicEq) { state.bassVolume = it }
                        ControlSlider("Bass Cutoff", state.bassCutoff, 20f, 200f, "Hz", Icons.Default.FilterAlt) { state.bassCutoff = it }
                    }
                }
                item {
                    SectionCard("Channels") {
                        repeat(7) { i ->
                            ControlSlider("Volume Ch${i + 1}", state.channelVolumes[i], -60f, 12f, "dB", Icons.Default.Speaker) {
                                state.setChannelVolume(i, it)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = Card),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(2.dp))
            content()
        }
    }
}

@Composable
private fun ControlSlider(
    label: String,
    value: Float,
    min: Float,
    max: Float,
    unit: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onChange: (Float) -> Unit
) {
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = CircleShape, color = SamsungBlue.copy(alpha = .10f), modifier = Modifier.size(42.dp)) {
                Icon(icon, null, tint = SamsungBlue, modifier = Modifier.padding(10.dp))
            }
            Spacer(Modifier.width(12.dp))
            Text(label, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, modifier = Modifier.weight(1f))
            NumericField(value, min, max, unit, onChange)
        }
        Slider(
            value = value.coerceIn(min, max),
            onValueChange = onChange,
            valueRange = min..max,
            modifier = Modifier.fillMaxWidth()
        )
        HorizontalDivider(color = Divider)
    }
}

@Composable
private fun NumericField(value: Float, min: Float, max: Float, unit: String, onChange: (Float) -> Unit) {
    var text by remember { mutableStateOf(formatNumber(value)) }
    LaunchedEffect(value) {
        val parsed = text.toFloatOrNull()
        if (parsed == null || kotlin.math.abs(parsed - value) > 0.051f) text = formatNumber(value)
    }
    OutlinedTextField(
        value = text,
        onValueChange = { raw ->
            val filtered = raw.filter { it.isDigit() || it == '-' || it == '.' }.take(8)
            text = filtered
            filtered.toFloatOrNull()?.let { onChange(it.coerceIn(min, max)) }
        },
        singleLine = true,
        suffix = { Text(unit, fontSize = 12.sp) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = Modifier.width(112.dp),
        shape = RoundedCornerShape(16.dp)
    )
}

private fun formatNumber(v: Float): String = if (kotlin.math.abs(v - v.roundToInt()) < 0.001f) v.roundToInt().toString() else "%.1f".format(v)

@Composable
private fun EqScreen(state: UiState, tablet: Boolean) {
    val pad = if (tablet) 36.dp else 20.dp
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Eq", "15-band equalizer • 7 channels")
        ChannelTabs(state.selectedChannel) { state.selectedChannel = it }
        if (tablet) {
            Row(
                Modifier.fillMaxSize().padding(horizontal = pad),
                horizontalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Column(Modifier.weight(1.25f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    EqGraphCard(state)
                    PresetCard(state)
                    Spacer(Modifier.height(24.dp))
                }
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    BandControlCard(state)
                    Spacer(Modifier.height(24.dp))
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = pad, end = pad, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item { EqGraphCard(state) }
                item { BandControlCard(state) }
                item { PresetCard(state) }
            }
        }
    }
}

@Composable
private fun ChannelTabs(selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        repeat(7) { i ->
            FilterChip(
                selected = selected == i,
                onClick = { onSelect(i) },
                label = { Text("Ch${i + 1}") },
                leadingIcon = if (selected == i) {{ Icon(Icons.Default.Check, null, Modifier.size(16.dp)) }} else null
            )
        }
    }
}

@Composable
private fun EqGraphCard(state: UiState) {
    val channel = state.eqChannels[state.selectedChannel]
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = Card),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Channel ${state.selectedChannel + 1}", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Text("Drag a point or use the controls below", color = TextMuted, fontSize = 13.sp)
                }
                TextButton(onClick = { state.resetEq(state.selectedChannel) }) {
                    Icon(Icons.Default.RestartAlt, null)
                    Spacer(Modifier.width(4.dp))
                    Text("Reset EQ")
                }
            }
            Spacer(Modifier.height(10.dp))
            EqGraph(
                bands = channel.bands,
                selected = state.selectedBand,
                onSelect = { state.selectedBand = it },
                onDrag = { index, f, g ->
                    state.selectedBand = index
                    state.updateBand(state.selectedChannel, index, frequency = f, gain = g)
                }
            )
        }
    }
}

@Composable
private fun EqGraph(
    bands: List<EqBand>,
    selected: Int,
    onSelect: (Int) -> Unit,
    onDrag: (Int, Float, Float) -> Unit
) {
    val grid = Color(0xFFE7ECF3)
    Box(
        Modifier
            .fillMaxWidth()
            .height(280.dp)
            .background(Color(0xFFFBFCFF), RoundedCornerShape(22.dp))
            .border(1.dp, Divider, RoundedCornerShape(22.dp))
    ) {
        Canvas(
            Modifier
                .fillMaxSize()
                .padding(12.dp)
                .pointerInput(bands) {
                    var dragIndex = selected
                    detectDragGestures(
                        onDragStart = { pos ->
                            val w = size.width.toFloat()
                            val h = size.height.toFloat()
                            dragIndex = bands.indices.minByOrNull { i ->
                                val p = bandToPoint(bands[i], w, h)
                                (p.x - pos.x) * (p.x - pos.x) + (p.y - pos.y) * (p.y - pos.y)
                            } ?: 0
                            onSelect(dragIndex)
                        },
                        onDrag = { change, _ ->
                            change.consume()
                            val x = change.position.x.coerceIn(0f, size.width.toFloat())
                            val y = change.position.y.coerceIn(0f, size.height.toFloat())
                            val f = xToFrequency(x, size.width.toFloat())
                            val g = yToGain(y, size.height.toFloat())
                            onDrag(dragIndex, f, g)
                        }
                    )
                }
        ) {
            val w = size.width
            val h = size.height
            repeat(7) { i ->
                val y = h * i / 6f
                drawLine(grid, Offset(0f, y), Offset(w, y), strokeWidth = 1f)
            }
            repeat(8) { i ->
                val x = w * i / 7f
                drawLine(grid, Offset(x, 0f), Offset(x, h), strokeWidth = 1f)
            }
            val path = Path()
            bands.forEachIndexed { i, b ->
                val p = bandToPoint(b, w, h)
                if (i == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y)
            }
            drawPath(path, SamsungBlue, style = Stroke(width = 4f, cap = StrokeCap.Round))
            bands.forEachIndexed { i, b ->
                val p = bandToPoint(b, w, h)
                drawCircle(if (i == selected) Color.White else SamsungBlue, if (i == selected) 12f else 8f, p)
                if (i == selected) {
                    drawCircle(SamsungBlue, 8f, p)
                    drawCircle(SamsungBlue.copy(alpha = .12f), 24f, p)
                }
            }
        }
        Text("+12", Modifier.align(Alignment.TopStart).padding(6.dp), color = TextMuted, fontSize = 10.sp)
        Text("0", Modifier.align(Alignment.CenterStart).padding(6.dp), color = TextMuted, fontSize = 10.sp)
        Text("-12", Modifier.align(Alignment.BottomStart).padding(6.dp), color = TextMuted, fontSize = 10.sp)
        Text("20 Hz", Modifier.align(Alignment.BottomStart).padding(start = 34.dp, bottom = 4.dp), color = TextMuted, fontSize = 10.sp)
        Text("20 kHz", Modifier.align(Alignment.BottomEnd).padding(8.dp), color = TextMuted, fontSize = 10.sp)
    }
}

private fun bandToPoint(band: EqBand, width: Float, height: Float): Offset {
    val x = ((log10(band.frequency.coerceIn(20f, 20000f)) - log10(20f)) / (log10(20000f) - log10(20f))) * width
    val y = ((12f - band.gain.coerceIn(-12f, 12f)) / 24f) * height
    return Offset(x, y)
}

private fun xToFrequency(x: Float, width: Float): Float {
    val t = if (width <= 0f) 0f else (x / width).coerceIn(0f, 1f)
    return (10.0.pow(log10(20.0) + t * (log10(20000.0) - log10(20.0)))).toFloat()
}

private fun yToGain(y: Float, height: Float): Float = if (height <= 0f) 0f else 12f - (y / height).coerceIn(0f, 1f) * 24f

private fun freqToSlider(freq: Float): Float = ((log10(freq.coerceIn(20f, 20000f)) - log10(20f)) / (log10(20000f) - log10(20f))).coerceIn(0f, 1f)
private fun sliderToFreq(t: Float): Float = (10.0.pow(log10(20.0) + t * (log10(20000.0) - log10(20.0)))).toFloat()

@Composable
private fun BandControlCard(state: UiState) {
    val channel = state.eqChannels[state.selectedChannel]
    val band = channel.bands[state.selectedBand]
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = Card),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = RoundedCornerShape(18.dp), color = SamsungBlue.copy(alpha = .10f)) {
                    Text("${state.selectedBand + 1}", Modifier.padding(horizontal = 18.dp, vertical = 12.dp), color = SamsungBlue, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Band ${state.selectedBand + 1}", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Text("Adjust selected band", color = TextMuted)
                }
                IconButton(onClick = { state.selectedBand = (state.selectedBand + 14) % 15 }) { Icon(Icons.Default.ChevronLeft, "Previous band") }
                IconButton(onClick = { state.selectedBand = (state.selectedBand + 1) % 15 }) { Icon(Icons.Default.ChevronRight, "Next band") }
            }
            ParameterSlider("Frequency", freqToSlider(band.frequency), 0f, 1f, "${band.frequency.roundToInt()} Hz") {
                state.updateBand(state.selectedChannel, state.selectedBand, frequency = sliderToFreq(it))
            }
            ParameterSlider("Q (Quality Factor)", band.q, .1f, 10f, "%.2f".format(band.q)) {
                state.updateBand(state.selectedChannel, state.selectedBand, q = it)
            }
            ParameterSlider("Gain", band.gain, -12f, 12f, "${formatNumber(band.gain)} dB") {
                state.updateBand(state.selectedChannel, state.selectedBand, gain = it)
            }
            ParameterSlider("Ch Volume", channel.volume, -60f, 12f, "${formatNumber(channel.volume)} dB") {
                channel.volume = it
            }
        }
    }
}

@Composable
private fun ParameterSlider(label: String, value: Float, min: Float, max: Float, valueText: String, onChange: (Float) -> Unit) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            Surface(shape = RoundedCornerShape(12.dp), color = Color(0xFFF1F4F8)) {
                Text(valueText, Modifier.padding(horizontal = 12.dp, vertical = 7.dp), fontSize = 13.sp)
            }
        }
        Slider(value = value.coerceIn(min, max), onValueChange = onChange, valueRange = min..max)
    }
}

@Composable
private fun PresetCard(state: UiState) {
    var expanded by remember { mutableStateOf(false) }
    var selectedPreset by remember(state.presetRefresh) { mutableStateOf(state.presets.firstOrNull().orEmpty()) }
    var message by remember { mutableStateOf("") }
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = Card),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Save, null, tint = Cyan)
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("Presets", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Save and load Phase 1 UI values", color = TextMuted, fontSize = 13.sp)
                }
            }
            OutlinedTextField(
                value = state.presetName,
                onValueChange = { state.presetName = it.take(40) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("Preset name") },
                shape = RoundedCornerShape(16.dp)
            )
            Button(
                onClick = {
                    message = if (state.savePreset(state.presetName)) {
                        selectedPreset = state.presetName.trim()
                        "Preset saved"
                    } else "Enter a preset name"
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Default.Save, null)
                Spacer(Modifier.width(8.dp))
                Text("Save Preset")
            }
            Box {
                OutlinedButton(
                    onClick = { expanded = true },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(if (selectedPreset.isBlank()) "Select saved preset" else selectedPreset, modifier = Modifier.weight(1f))
                    Icon(Icons.Default.ArrowDropDown, null)
                }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    state.presets.forEach { name ->
                        DropdownMenuItem(text = { Text(name) }, onClick = { selectedPreset = name; expanded = false })
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    enabled = selectedPreset.isNotBlank(),
                    onClick = { message = if (state.loadPreset(selectedPreset)) "Preset loaded" else "Preset not found" },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp)
                ) { Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(6.dp)); Text("Load") }
                OutlinedButton(
                    enabled = selectedPreset.isNotBlank(),
                    onClick = {
                        state.deletePreset(selectedPreset)
                        selectedPreset = state.presets.firstOrNull().orEmpty()
                        message = "Preset deleted"
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp)
                ) { Icon(Icons.Default.Delete, null); Spacer(Modifier.width(6.dp)); Text("Delete") }
            }
            if (message.isNotBlank()) Text(message, color = SamsungBlue, fontSize = 13.sp)
        }
    }
}

@Composable
private fun BottomNavigation(selected: Tab, onSelect: (Tab) -> Unit) {
    NavigationBar(containerColor = Color.White, tonalElevation = 2.dp) {
        Tab.entries.forEach { tab ->
            val icon = when (tab) {
                Tab.HOME -> Icons.Default.Home
                Tab.MIX -> Icons.Default.Tune
                Tab.EQ -> Icons.Default.Equalizer
            }
            NavigationBarItem(
                selected = selected == tab,
                onClick = { onSelect(tab) },
                icon = { Icon(icon, tab.title) },
                label = { Text(tab.title) }
            )
        }
    }
}
