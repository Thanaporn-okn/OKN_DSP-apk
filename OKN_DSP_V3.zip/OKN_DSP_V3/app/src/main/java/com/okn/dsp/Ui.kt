package com.okn.dsp

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.CallSplit
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speaker
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

private val BgTop = Color(0xFF00101E)
private val BgBottom = Color(0xFF000812)
private val Panel = Color(0xE6061B2B)
private val Panel2 = Color(0xE80A2438)
private val StrokeBlue = Color(0xFF0A5D98)
private val Cyan = Color(0xFF08DFFF)
private val Blue = Color(0xFF0A78FF)
private val Green = Color(0xFF00ED76)
private val Magenta = Color(0xFFFF35F2)
private val Pink = Color(0xFFFF3E7A)
private val Orange = Color(0xFFFF9D24)
private val Yellow = Color(0xFFFFDA30)
private val TextPrimary = Color(0xFFF1F7FF)
private val TextSecondary = Color(0xFF98C6EE)
private val Track = Color(0xFF244B6D)
private val Purple = Color(0xFFB334FF)

private val ChannelColors = listOf(
    Color(0xFF1AA8FF), Color(0xFF11E5F4), Color(0xFF12EB65),
    Color(0xFFFFD934), Color(0xFFFF9429), Color(0xFFFF3B66), Color(0xFFD738FF)
)

@Composable
fun OKNDspApp(vm: DspViewModel, bleState: BleUiState, onConnectionClick: () -> Unit) {
    val s = vm.state
    var showSettings by remember { mutableStateOf(false) }

    MaterialTheme {
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(BgTop, BgBottom)))
        ) {
            val contentWidth = if (maxWidth > 820.dp) 820.dp else maxWidth
            Column(
                modifier = Modifier
                    .width(contentWidth)
                    .fillMaxHeight()
                    .align(Alignment.TopCenter)
                    .padding(horizontal = if (maxWidth < 380.dp) 7.dp else 10.dp, vertical = 7.dp)
            ) {
                AppHeader(
                    home = s.currentScreen == DspScreen.HOME,
                    bleState = bleState,
                    onConnectionClick = onConnectionClick,
                    onSettings = { showSettings = true }
                )
                if (s.currentScreen != DspScreen.HOME) {
                    Spacer(Modifier.height(8.dp))
                    ChannelTabs(s.selectedChannel, s.channels, vm::selectChannel)
                }
                Spacer(Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                ) {
                    when (s.currentScreen) {
                        DspScreen.HOME -> HomeScreen(vm, bleState)
                        DspScreen.EQ -> EqScreen(vm)
                        DspScreen.CROSSOVER -> CrossoverScreen(vm)
                        DspScreen.DELAY -> DelayScreen(vm)
                        DspScreen.OUTPUT -> OutputScreen(vm)
                    }
                }
                Spacer(Modifier.height(8.dp))
                BottomNav(s.currentScreen, vm::setScreen)
            }
        }
    }

    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("OKN_DSP V3", color = TextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("BLE: ${bleState.status}", color = TextSecondary)
                    Text("Known characteristic: 0000AB01-0000-1000-8000-00805F9B34FB", color = TextSecondary, fontSize = 12.sp)
                    Text(
                        if (bleState.characteristicFound) "AB01 found • writable=${bleState.characteristicWritable}" else "AB01 not discovered yet",
                        color = if (bleState.characteristicFound) Green else TextSecondary,
                        fontSize = 12.sp
                    )
                    if (bleState.lastRxHex.isNotBlank()) Text("RX: ${bleState.lastRxHex}", color = Cyan, fontSize = 11.sp)
                    Text("DSP command byte mapping is intentionally not guessed; confirmed frames can be wired to the BLE writer.", color = TextSecondary, fontSize = 11.sp)
                }
            },
            confirmButton = {
                Button(onClick = { showSettings = false }, colors = ButtonDefaults.buttonColors(containerColor = Blue)) {
                    Text("ปิด")
                }
            },
            containerColor = Color(0xFF061C2D)
        )
    }
}

@Composable
private fun WaveLogo(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val centerY = size.height / 2f
        val xs = listOf(.14f, .32f, .50f, .68f, .86f)
        val heights = listOf(.48f, .72f, .94f, .68f, .45f)
        xs.forEachIndexed { index, x ->
            val h = size.height * heights[index]
            drawLine(
                color = Cyan,
                start = Offset(size.width * x, centerY - h / 2f),
                end = Offset(size.width * x, centerY + h / 2f),
                strokeWidth = 5.dp.toPx(),
                cap = StrokeCap.Round
            )
        }
    }
}

@Composable
private fun AppHeader(home: Boolean, bleState: BleUiState, onConnectionClick: () -> Unit, onSettings: () -> Unit) {
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val compact = maxWidth < 390.dp
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(if (compact) 6.dp else 9.dp)
        ) {
            WaveLogo(Modifier.size(if (compact) 42.dp else 50.dp, if (compact) 48.dp else 58.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    if (home) "OKN_DSP" else "DSP Control",
                    color = TextPrimary,
                    fontSize = if (compact) 21.sp else 27.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
                Text("Professional Audio Processor", color = TextSecondary, fontSize = if (compact) 9.sp else 11.sp, maxLines = 1)
            }
            ConnectionPill(bleState, onConnectionClick, compact)
            Icon(
                Icons.Default.Settings,
                contentDescription = "Settings",
                tint = Color(0xFFD5EBFF),
                modifier = Modifier
                    .size(if (compact) 31.dp else 36.dp)
                    .clickable(onClick = onSettings)
                    .padding(2.dp)
            )
        }
    }
}

@Composable
private fun ConnectionPill(state: BleUiState, onClick: () -> Unit, compact: Boolean = false) {
    val dot = if (state.connected) Green else if (state.scanning) Yellow else Color(0xFF6D8AA5)
    Row(
        modifier = Modifier
            .width(if (compact) 104.dp else 130.dp)
            .clip(RoundedCornerShape(12.dp))
            .border(1.dp, StrokeBlue, RoundedCornerShape(12.dp))
            .background(Brush.verticalGradient(listOf(Color(0xCC09253B), Color(0xCC06182A))))
            .clickable(onClick = onClick)
            .padding(horizontal = if (compact) 7.dp else 10.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(if (compact) 5.dp else 7.dp)
    ) {
        Box(Modifier.size(if (compact) 9.dp else 11.dp).background(dot, CircleShape))
        Column(Modifier.weight(1f)) {
            Text(
                if (state.connected) "Connected" else state.status,
                color = if (state.connected) Green else TextPrimary,
                fontSize = if (compact) 8.sp else 10.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1
            )
            Text(state.deviceName.ifBlank { "DSP-7900" }, color = TextSecondary, fontSize = if (compact) 7.sp else 9.sp, maxLines = 1)
        }
        Text("›", color = TextSecondary, fontSize = if (compact) 18.sp else 22.sp)
    }
}

@Composable
private fun ChannelTabs(selected: Int, channels: List<ChannelState>, onSelect: (Int) -> Unit) {
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val compact = maxWidth < 390.dp
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(if (compact) 3.dp else 5.dp)
        ) {
            channels.forEachIndexed { index, channel ->
                val active = index == selected
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(7.dp))
                        .background(
                            if (active) Brush.verticalGradient(listOf(Color(0xFF096DFF), Color(0xFF09DFFC)))
                            else Brush.verticalGradient(listOf(Color(0xFF0B2940), Color(0xFF071928)))
                        )
                        .border(1.dp, if (active) Cyan else StrokeBlue, RoundedCornerShape(7.dp))
                        .clickable { onSelect(index) }
                        .padding(vertical = if (compact) 6.dp else 8.dp, horizontal = 1.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(channel.shortName, color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = if (compact) 8.sp else 10.sp, maxLines = 1)
                    Text(channel.name, color = if (active) TextPrimary else Color(0xFFD3DDE8), fontSize = if (compact) 7.sp else 8.sp, maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun BottomNav(current: DspScreen, onSelect: (DspScreen) -> Unit) {
    val items = listOf(
        Triple(DspScreen.HOME, "Home", Icons.Default.Home),
        Triple(DspScreen.EQ, "EQ", Icons.Default.GraphicEq),
        Triple(DspScreen.CROSSOVER, "Crossover", Icons.Default.CallSplit),
        Triple(DspScreen.DELAY, "Delay", Icons.Default.Timer),
        Triple(DspScreen.OUTPUT, "Output", Icons.Default.Equalizer)
    )
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .border(1.dp, StrokeBlue, RoundedCornerShape(12.dp))
            .background(Brush.verticalGradient(listOf(Color(0xF20A2234), Color(0xF2041422))))
            .padding(3.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        items.forEach { (screen, title, icon) ->
            val active = screen == current
            Column(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(9.dp))
                    .background(
                        if (active) Brush.verticalGradient(listOf(Color(0xFF0A5BEA), Color(0xFF0B7DFF)))
                        else Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent))
                    )
                    .border(if (active) 1.dp else 0.dp, if (active) Color(0xFF0BBEFF) else Color.Transparent, RoundedCornerShape(9.dp))
                    .clickable { onSelect(screen) }
                    .padding(vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(icon, title, tint = if (active) Cyan else Color(0xFFB8D5F1), modifier = Modifier.size(25.dp))
                Text(title, color = if (active) TextPrimary else TextSecondary, fontSize = 9.sp, maxLines = 1)
            }
        }
    }
}

@Composable
private fun NeonPanel(modifier: Modifier = Modifier, accent: Color = StrokeBlue, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Brush.verticalGradient(listOf(Panel2, Panel)))
            .border(1.dp, accent.copy(alpha = 0.8f), RoundedCornerShape(14.dp))
            .padding(12.dp),
        content = content
    )
}

@Composable
private fun SectionTitle(icon: ImageVector, accent: Color, title: String, thai: String, trailing: @Composable (() -> Unit)? = null) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
        Box(
            Modifier.size(48.dp).clip(CircleShape).border(2.dp, accent, CircleShape).background(accent.copy(alpha = 0.08f)),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = accent, modifier = Modifier.size(28.dp)) }
        Column(Modifier.weight(1f)) {
            Text(title, color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(thai, color = TextSecondary, fontSize = 11.sp)
        }
        trailing?.invoke()
    }
}

@Composable
private fun HomeScreen(vm: DspViewModel, bleState: BleUiState) {
    val s = vm.state
    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        ParameterCard(Icons.Default.VolumeUp, Blue, "Master Volume", "ปรับระดับเสียงรวม", s.masterVolumeDb, -60f..12f, "dB", vm::setMasterVolume)
        ParameterCard(Icons.Default.Album, Cyan, "Bass Volume", "ปรับระดับเสียงเบส", s.bassVolumeDb, -12f..12f, "dB", vm::setBassVolume)
        ParameterCard(Icons.Default.CallSplit, Magenta, "Bass Cutoff", "ตั้งค่าความถี่ตัดเบส", s.bassCutoffHz, 20f..500f, "Hz", vm::setBassCutoff, decimals = 0)
        ParameterCard(Icons.Default.Equalizer, Pink, "Bass Boost", "เพิ่มความหนักแน่นของเบส", s.bassBoostDb, -10f..12f, "dB", vm::setBassBoost)
        ParameterCard(Icons.Default.GraphicEq, Blue, "Middle Boost", "เพิ่มความชัดเจนย่านกลาง", s.middleBoostDb, -12f..12f, "dB", vm::setMiddleBoost)
        ParameterCard(Icons.Default.AutoAwesome, Magenta, "Treble Boost", "เพิ่มความใสย่านแหลม", s.trebleBoostDb, -12f..12f, "dB", vm::setTrebleBoost)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                NeonPanel {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.MusicNote, null, tint = Cyan, modifier = Modifier.size(32.dp))
                        Column { Text("Audio Source", color = TextPrimary, fontWeight = FontWeight.Bold); Text("แหล่งสัญญาณเสียง", color = TextSecondary, fontSize = 10.sp) }
                    }
                    Spacer(Modifier.height(8.dp))
                    DropdownSelector(s.audioSource, listOf("High Level (Speaker)", "Low Level (RCA)", "Bluetooth"), vm::setAudioSource)
                }
                NeonPanel {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.Tune, null, tint = Blue, modifier = Modifier.size(32.dp))
                        Column { Text("System Preset", color = TextPrimary, fontWeight = FontWeight.Bold); Text("พรีเซ็ตระบบ", color = TextSecondary, fontSize = 10.sp) }
                    }
                    Spacer(Modifier.height(8.dp))
                    DropdownSelector(s.systemPreset, listOf("Flat", "Driver", "Passenger", "Bass", "Vocal"), vm::setSystemPreset)
                }
            }
            NeonPanel(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Memory, null, tint = Blue, modifier = Modifier.size(32.dp))
                    Column { Text("Device Status", color = TextPrimary, fontWeight = FontWeight.Bold); Text("สถานะอุปกรณ์", color = TextSecondary, fontSize = 10.sp) }
                }
                Spacer(Modifier.height(8.dp))
                StatusRow(Icons.Default.Bluetooth, "Connection", bleState.status, if (bleState.connected) Green else Cyan)
                StatusRow(Icons.Default.BatteryChargingFull, "Voltage", "-- V", Green)
                StatusRow(Icons.Default.Thermostat, "Temperature", "-- °C", Cyan)
                StatusRow(Icons.Default.CheckCircle, "System", "Normal", Green)
            }
        }
    }
}

@Composable
private fun ParameterCard(
    icon: ImageVector,
    accent: Color,
    title: String,
    thai: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    unit: String,
    onChange: (Float) -> Unit,
    decimals: Int = 1
) {
    NeonPanel {
        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val compact = maxWidth < 390.dp
            val tickLabels = when (title) {
                "Master Volume" -> listOf("-60", "-40", "-20", "0", "+12")
                "Bass Cutoff" -> listOf("20", "50", "100", "200", "500")
                "Bass Boost" -> listOf("-10", "-6", "0", "+6", "+12")
                else -> listOf("-12", "-6", "0", "+6", "+12")
            }
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(if (compact) 6.dp else 9.dp)
            ) {
                Box(
                    Modifier
                        .size(if (compact) 50.dp else 60.dp)
                        .clip(CircleShape)
                        .border(2.dp, accent, CircleShape)
                        .background(Brush.radialGradient(listOf(accent.copy(alpha = .22f), Color.Transparent))),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, null, tint = accent, modifier = Modifier.size(if (compact) 27.dp else 32.dp))
                }
                Column(Modifier.width(if (compact) 88.dp else 112.dp)) {
                    Text(title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = if (compact) 13.sp else 16.sp, maxLines = 1)
                    Text(thai, color = TextSecondary, fontSize = if (compact) 8.sp else 10.sp, maxLines = 1)
                }
                Column(Modifier.weight(1f)) {
                    Slider(
                        value = value,
                        onValueChange = onChange,
                        valueRange = range,
                        colors = neonSliderColors(accent),
                        modifier = Modifier.height(32.dp)
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        tickLabels.forEach { Text(it, color = TextSecondary, fontSize = if (compact) 7.sp else 8.sp) }
                    }
                }
                Box(
                    Modifier
                        .width(if (compact) 62.dp else 76.dp)
                        .clip(RoundedCornerShape(9.dp))
                        .border(1.dp, Color(0xFF315B82), RoundedCornerShape(9.dp))
                        .background(Color(0x66040F1C))
                        .padding(horizontal = 4.dp, vertical = if (compact) 9.dp else 11.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("${formatValue(value, decimals)} $unit", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = if (compact) 10.sp else 13.sp, maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun StatusRow(icon: ImageVector, label: String, value: String, accent: Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = accent, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(7.dp))
        Text(label, color = TextSecondary, fontSize = 10.sp, modifier = Modifier.weight(1f))
        Text(value, color = if (value == "Normal") Green else TextPrimary, fontSize = 10.sp)
    }
    HorizontalDivider(color = StrokeBlue.copy(alpha = 0.35f))
}

@Composable
private fun EqScreen(vm: DspViewModel) {
    val s = vm.state
    var manage by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val pageStart = s.eqPage * 6
    val pageEnd = min(pageStart + if (s.eqPage < 2) 6 else 3, s.eqBands.size)

    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        NeonPanel {
            BoxWithConstraints(Modifier.fillMaxWidth()) {
                val compact = maxWidth < 390.dp
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.size(if (compact) 45.dp else 52.dp), contentAlignment = Alignment.Center) {
                        WaveLogo(Modifier.fillMaxSize())
                    }
                    Column(Modifier.weight(1f)) {
                        Text("Parametric EQ", color = TextPrimary, fontSize = if (compact) 18.sp else 21.sp, fontWeight = FontWeight.Bold)
                        Text("ปรับแต่งความถี่เสียงอย่างละเอียด", color = TextSecondary, fontSize = if (compact) 8.sp else 10.sp)
                    }
                    Box(Modifier.width(if (compact) 105.dp else 132.dp)) {
                        DropdownSelector(
                            value = "${s.channels[s.selectedChannel].shortName} - ${s.channels[s.selectedChannel].name}",
                            options = s.channels.map { "${it.shortName} - ${it.name}" },
                            onSelect = { v -> vm.selectChannel(s.channels.indexOfFirst { "${it.shortName} - ${it.name}" == v }.coerceAtLeast(0)) },
                            compact = true
                        )
                    }
                    OutlinedButton(
                        onClick = vm::resetEq,
                        border = BorderStroke(1.dp, StrokeBlue),
                        modifier = Modifier.height(42.dp)
                    ) {
                        Icon(Icons.Default.Refresh, null, tint = TextPrimary, modifier = Modifier.size(17.dp))
                        if (!compact) { Spacer(Modifier.width(4.dp)); Text("รีเซ็ต EQ", color = TextPrimary, fontSize = 9.sp) }
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            EqGraph(s.eqBands)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.fillMaxWidth()) {
            listOf("Bands 1 - 6", "Bands 7 - 12", "Bands 13 - 15").forEachIndexed { i, title ->
                TabButton(title, s.eqPage == i, Modifier.weight(1f)) { vm.setEqPage(i) }
            }
        }

        NeonPanel {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("#", color = TextPrimary, fontSize = 9.sp, modifier = Modifier.width(24.dp))
                Text("Type", color = TextPrimary, fontSize = 9.sp, modifier = Modifier.weight(1.1f))
                Text("Frequency", color = TextPrimary, fontSize = 9.sp, modifier = Modifier.weight(1.1f))
                Text("Gain", color = TextPrimary, fontSize = 9.sp, modifier = Modifier.weight(1f))
                Text("Q", color = TextPrimary, fontSize = 9.sp, modifier = Modifier.weight(0.8f))
                Text("Power", color = TextPrimary, fontSize = 9.sp, modifier = Modifier.width(48.dp), textAlign = TextAlign.Center)
            }
            Spacer(Modifier.height(6.dp))
            (pageStart until pageEnd).forEach { index ->
                EqBandRow(index, s.eqBands[index], vm)
                if (index != pageEnd - 1) HorizontalDivider(color = StrokeBlue.copy(alpha = 0.35f), modifier = Modifier.padding(vertical = 4.dp))
            }
        }

        NeonPanel {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(
                    Modifier.size(44.dp).clip(RoundedCornerShape(9.dp)).border(1.dp, StrokeBlue, RoundedCornerShape(9.dp)).background(Color(0x440A78FF)),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.Save, null, tint = Cyan, modifier = Modifier.size(25.dp)) }
                Column(Modifier.weight(1f)) {
                    Text("Preset", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("ชุดค่าที่ใช้งานอยู่", color = TextSecondary, fontSize = 9.sp)
                    DropdownSelector(s.presetName, listOf("Custom 1", "Custom 2", "Custom 3", "Daily", "SQ"), vm::setPresetName, compact = true)
                }
                Button(
                    onClick = { Toast.makeText(context, if (vm.savePreset()) "บันทึก ${s.presetName} แล้ว" else "บันทึกไม่สำเร็จ", Toast.LENGTH_SHORT).show() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0A466D)),
                    modifier = Modifier.height(48.dp)
                ) { Icon(Icons.Default.Save, null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(3.dp)); Text("Save", fontSize = 9.sp) }
                OutlinedButton(onClick = { manage = true }, border = BorderStroke(1.dp, StrokeBlue), modifier = Modifier.height(48.dp)) {
                    Text("Manage", color = TextPrimary, fontSize = 9.sp)
                }
            }
        }
    }

    if (manage) {
        val names = vm.savedPresetNames()
        AlertDialog(
            onDismissRequest = { manage = false },
            title = { Text("Preset Manager", color = TextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (names.isEmpty()) Text("ยังไม่มีพรีเซ็ตที่บันทึก", color = TextSecondary)
                    names.forEach { name ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(name, color = TextPrimary, modifier = Modifier.weight(1f))
                            OutlinedButton(onClick = { vm.loadPreset(name); manage = false }, border = BorderStroke(1.dp, StrokeBlue)) { Text("Load", color = Cyan) }
                            Spacer(Modifier.width(4.dp))
                            Icon(Icons.Default.Close, "Delete", tint = Pink, modifier = Modifier.clickable { vm.deletePreset(name) }.padding(6.dp))
                        }
                    }
                }
            },
            confirmButton = { Button(onClick = { manage = false }, colors = ButtonDefaults.buttonColors(containerColor = Blue)) { Text("ปิด") } },
            containerColor = Color(0xFF061C2D)
        )
    }
}

@Composable
private fun EqBandRow(index: Int, band: EqBand, vm: DspViewModel) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(Modifier.width(24.dp), contentAlignment = Alignment.CenterStart) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(9.dp).background(ChannelColors[index % ChannelColors.size], CircleShape))
                Text("${index + 1}", color = TextPrimary, fontSize = 9.sp, modifier = Modifier.padding(start = 2.dp))
            }
        }
        Box(Modifier.weight(1.1f)) { DropdownSelector(band.type, listOf("PEQ", "Low Shelf", "High Shelf"), { vm.updateEqBand(index) { it.copy(type = bandType(it.type, band.type)) } }, compact = true, directValue = { new -> vm.updateEqBand(index) { it.copy(type = new) } }) }
        StepperField(formatFrequency(band.frequencyHz), Modifier.weight(1.1f), { vm.updateEqBand(index) { it.copy(frequencyHz = (it.frequencyHz / 1.12f).coerceAtLeast(20f)) } }, { vm.updateEqBand(index) { it.copy(frequencyHz = (it.frequencyHz * 1.12f).coerceAtMost(20000f)) } })
        StepperField("${formatValue(band.gainDb, 1)} dB", Modifier.weight(1f), { vm.updateEqBand(index) { it.copy(gainDb = (it.gainDb - 0.5f).coerceAtLeast(-12f)) } }, { vm.updateEqBand(index) { it.copy(gainDb = (it.gainDb + 0.5f).coerceAtMost(12f)) } })
        StepperField(formatValue(band.q, 2), Modifier.weight(0.8f), { vm.updateEqBand(index) { it.copy(q = (it.q - 0.1f).coerceAtLeast(0.3f)) } }, { vm.updateEqBand(index) { it.copy(q = (it.q + 0.1f).coerceAtMost(10f)) } })
        Switch(
            checked = band.enabled,
            onCheckedChange = { vm.updateEqBand(index) { b -> b.copy(enabled = !b.enabled) } },
            modifier = Modifier.width(48.dp),
            colors = neonSwitchColors(Cyan)
        )
    }
}

// Kept separate to avoid accidental mutation when a menu is rapidly tapped.
private fun bandType(current: String, fallback: String): String = if (current.isNotBlank()) current else fallback

@Composable
private fun StepperField(text: String, modifier: Modifier = Modifier, onMinus: () -> Unit, onPlus: () -> Unit) {
    Row(
        modifier = modifier.clip(RoundedCornerShape(7.dp)).border(1.dp, StrokeBlue, RoundedCornerShape(7.dp)).padding(vertical = 6.dp, horizontal = 3.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text("‹", color = TextSecondary, fontSize = 15.sp, modifier = Modifier.clickable(onClick = onMinus).padding(horizontal = 2.dp))
        Text(text, color = TextPrimary, fontSize = 8.sp, maxLines = 1)
        Text("›", color = TextSecondary, fontSize = 15.sp, modifier = Modifier.clickable(onClick = onPlus).padding(horizontal = 2.dp))
    }
}

@Composable
private fun EqGraph(bands: List<EqBand>) {
    Canvas(
        modifier = Modifier.fillMaxWidth().height(210.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF031525)).border(1.dp, StrokeBlue.copy(alpha = 0.7f), RoundedCornerShape(8.dp))
    ) {
        val left = 30.dp.toPx(); val right = size.width - 12.dp.toPx(); val top = 14.dp.toPx(); val bottom = size.height - 24.dp.toPx()
        repeat(7) { i ->
            val y = top + (bottom - top) * i / 6f
            drawLine(Color(0xFF19405A).copy(alpha = 0.5f), Offset(left, y), Offset(right, y), 1f)
        }
        repeat(10) { i ->
            val x = left + (right - left) * i / 9f
            drawLine(Color(0xFF19405A).copy(alpha = 0.35f), Offset(x, top), Offset(x, bottom), 1f)
        }
        val points = bands.filter { it.enabled }.take(15).map { b ->
            val x = left + logX(b.frequencyHz) * (right - left)
            val y = bottom - ((b.gainDb + 12f) / 24f) * (bottom - top)
            Offset(x, y)
        }.sortedBy { it.x }
        if (points.size >= 2) {
            val p = Path().apply {
                moveTo(points.first().x, points.first().y)
                for (i in 1 until points.size) {
                    val prev = points[i - 1]; val cur = points[i]
                    val mid = (prev.x + cur.x) / 2f
                    cubicTo(mid, prev.y, mid, cur.y, cur.x, cur.y)
                }
            }
            drawPath(p, Cyan, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round))
        }
        points.forEachIndexed { i, pt ->
            val c = ChannelColors[i % ChannelColors.size]
            drawCircle(c.copy(alpha = 0.18f), 13.dp.toPx(), pt)
            drawCircle(c, 5.dp.toPx(), pt)
            drawCircle(TextPrimary, 6.dp.toPx(), pt, style = Stroke(1.5.dp.toPx()))
        }
    }
}

@Composable
private fun CrossoverScreen(vm: DspViewModel) {
    val s = vm.state
    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        NeonPanel {
            BoxWithConstraints(Modifier.fillMaxWidth()) {
                val compact = maxWidth < 390.dp
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        Modifier.size(if (compact) 52.dp else 62.dp).clip(CircleShape).border(2.dp, Magenta, CircleShape).background(Magenta.copy(alpha = .08f)),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.CallSplit, null, tint = Magenta, modifier = Modifier.size(if (compact) 29.dp else 34.dp)) }
                    Column(Modifier.weight(1f)) {
                        Text("Crossover", color = TextPrimary, fontSize = if (compact) 19.sp else 23.sp, fontWeight = FontWeight.Bold)
                        Text("ตั้งค่าการแบ่งความถี่", color = TextSecondary, fontSize = if (compact) 8.sp else 10.sp)
                    }
                    Box(Modifier.width(if (compact) 92.dp else 112.dp)) {
                        DropdownSelector(s.crossoverView, listOf("Magnitude", "Phase"), vm::setCrossoverView, compact = true)
                    }
                    OutlinedButton(onClick = vm::resetCrossover, border = BorderStroke(1.dp, StrokeBlue), modifier = Modifier.height(42.dp)) {
                        Icon(Icons.Default.Refresh, null, tint = TextPrimary, modifier = Modifier.size(17.dp))
                        if (!compact) { Spacer(Modifier.width(3.dp)); Text("Reset", color = TextPrimary, fontSize = 9.sp) }
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            CrossoverGraph(s.hpf.frequencyHz, s.lpf.frequencyHz)
        }
        FilterPanel("High Pass Filter (HPF)", "กรองความถี่ต่ำออก", Cyan, s.hpf, vm::setHpf)
        FilterPanel("Low Pass Filter (LPF)", "กรองความถี่สูงออก", Magenta, s.lpf, vm::setLpf)
        NeonPanel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(35.dp).clip(RoundedCornerShape(8.dp)).background(Color(0x440A78FF)).border(1.dp, StrokeBlue, RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Settings, null, tint = Cyan, modifier = Modifier.size(23.dp))
                }
                Spacer(Modifier.width(8.dp))
                Column { Text("Advanced Settings", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp); Text("ตั้งค่าขั้นสูง", color = TextSecondary, fontSize = 9.sp) }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                SmallSetting("Phase", "${s.phaseDegrees}°", Modifier.weight(1f), { vm.setPhase(if (s.phaseDegrees <= 0) 180 else s.phaseDegrees - 10) }, { vm.setPhase(if (s.phaseDegrees >= 180) 0 else s.phaseDegrees + 10) })
                SmallSetting("Polarity", s.polarity, Modifier.weight(1f), { vm.setPolarity(if (s.polarity == "Normal") "Invert" else "Normal") }, { vm.setPolarity(if (s.polarity == "Normal") "Invert" else "Normal") })
                Column(Modifier.weight(0.9f).clip(RoundedCornerShape(8.dp)).border(1.dp, StrokeBlue, RoundedCornerShape(8.dp)).padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Link L/R", color = TextSecondary, fontSize = 9.sp)
                    Switch(checked = s.linkLR, onCheckedChange = vm::setLinkLR, colors = neonSwitchColors(Cyan))
                }
                Column(Modifier.weight(1.1f).clip(RoundedCornerShape(8.dp)).border(1.dp, StrokeBlue, RoundedCornerShape(8.dp)).padding(6.dp)) {
                    Text("Output Mode", color = TextSecondary, fontSize = 8.sp)
                    DropdownSelector(s.outputMode, listOf("Stereo", "Mono", "2-Way", "3-Way"), vm::setOutputMode, compact = true)
                }
            }
        }
    }
}

@Composable
private fun FilterPanel(title: String, thai: String, accent: Color, filter: FilterState, onChange: (FilterState) -> Unit) {
    NeonPanel(accent = accent.copy(alpha = 0.55f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(48.dp).clip(CircleShape).border(2.dp, accent, CircleShape).background(accent.copy(alpha = .07f)),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Default.CallSplit, null, tint = accent, modifier = Modifier.size(28.dp)) }
            Spacer(Modifier.width(9.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(thai, color = TextSecondary, fontSize = 9.sp)
            }
            Text("Bypass", color = TextSecondary, fontSize = 10.sp)
            Spacer(Modifier.width(5.dp))
            Switch(checked = filter.bypass, onCheckedChange = { onChange(filter.copy(bypass = it)) }, colors = neonSwitchColors(accent))
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
            LabeledDropdown("Type", filter.type, listOf("Linkwitz-Riley", "Butterworth", "Bessel"), Modifier.weight(1f)) { onChange(filter.copy(type = it)) }
            LabeledDropdown("Frequency", formatFrequency(filter.frequencyHz), frequencyOptions(), Modifier.weight(1f)) { v -> onChange(filter.copy(frequencyHz = parseFrequency(v))) }
            LabeledDropdown("Slope", "${filter.slopeDbOct} dB/Oct", listOf("6 dB/Oct", "12 dB/Oct", "18 dB/Oct", "24 dB/Oct", "36 dB/Oct", "48 dB/Oct"), Modifier.weight(1f)) { v -> onChange(filter.copy(slopeDbOct = v.substringBefore(" ").toInt())) }
        }
    }
}

@Composable
private fun CrossoverGraph(hpf: Float, lpf: Float) {
    Canvas(
        modifier = Modifier.fillMaxWidth().height(200.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF031525)).border(1.dp, StrokeBlue.copy(alpha = 0.7f), RoundedCornerShape(8.dp))
    ) {
        val left = 28.dp.toPx(); val right = size.width - 12.dp.toPx(); val top = 12.dp.toPx(); val bottom = size.height - 22.dp.toPx(); val center = (top + bottom) / 2f
        repeat(7) { i -> val y = top + (bottom - top) * i / 6f; drawLine(Color(0xFF1A405A).copy(alpha = 0.45f), Offset(left, y), Offset(right, y), 1f) }
        repeat(10) { i -> val x = left + (right - left) * i / 9f; drawLine(Color(0xFF1A405A).copy(alpha = 0.35f), Offset(x, top), Offset(x, bottom), 1f) }
        val hpx = left + logX(hpf) * (right - left)
        val lpx = left + logX(lpf) * (right - left)
        val hp = Path().apply { moveTo(left, bottom); cubicTo(hpx * 0.78f, bottom, hpx * 0.86f, center, hpx, center); lineTo(right, center) }
        val lp = Path().apply { moveTo(left, center); lineTo(lpx, center); cubicTo(lpx * 1.12f, center, lpx * 1.23f, bottom, right, bottom) }
        drawPath(hp, Cyan, style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
        drawPath(lp, Magenta, style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
        drawCircle(Cyan, 5.dp.toPx(), Offset(hpx, center)); drawCircle(TextPrimary, 7.dp.toPx(), Offset(hpx, center), style = Stroke(1.5.dp.toPx()))
        drawCircle(Magenta, 5.dp.toPx(), Offset(lpx, center)); drawCircle(TextPrimary, 7.dp.toPx(), Offset(lpx, center), style = Stroke(1.5.dp.toPx()))
    }
}

@Composable
private fun DelayScreen(vm: DspViewModel) {
    val s = vm.state
    val minDelay = s.channels.minOfOrNull { it.delayMs } ?: 0f
    val maxDelay = s.channels.maxOfOrNull { it.delayMs } ?: 0f
    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        NeonPanel {
            BoxWithConstraints(Modifier.fillMaxWidth()) {
                val compact = maxWidth < 390.dp
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    Box(Modifier.size(if (compact) 48.dp else 55.dp).clip(CircleShape).border(2.dp, Green, CircleShape).background(Green.copy(alpha = .07f)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Timer, null, tint = Green, modifier = Modifier.size(if (compact) 27.dp else 31.dp))
                    }
                    Column(Modifier.weight(1f)) {
                        Text("Delay", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = if (compact) 18.sp else 21.sp)
                        Text("ตั้งค่าหน่วงเวลาเพื่อการจัดตำแหน่งเสียง", color = TextSecondary, fontSize = if (compact) 8.sp else 9.sp, maxLines = 1)
                    }
                    Row(Modifier.width(if (compact) 78.dp else 92.dp).clip(RoundedCornerShape(8.dp)).border(1.dp, StrokeBlue, RoundedCornerShape(8.dp))) {
                        UnitButton("ms", s.delayUnit == "ms", Modifier.weight(1f)) { vm.setDelayUnit("ms") }
                        UnitButton("cm", s.delayUnit == "cm", Modifier.weight(1f)) { vm.setDelayUnit("cm") }
                    }
                    OutlinedButton(onClick = vm::syncDelays, border = BorderStroke(1.dp, StrokeBlue), modifier = Modifier.height(40.dp)) {
                        Icon(Icons.Default.Refresh, null, tint = TextPrimary, modifier = Modifier.size(17.dp))
                        if (!compact) { Spacer(Modifier.width(3.dp)); Text("ซิงค์ทุกช่อง", color = TextPrimary, fontSize = 8.sp) }
                    }
                }
            }
            Spacer(Modifier.height(9.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                CarDelayView(s.channels, Modifier.weight(1.22f).height(270.dp))
                Column(Modifier.weight(0.92f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    NeonPanel {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Album, null, tint = Cyan, modifier = Modifier.size(22.dp)); Spacer(Modifier.width(5.dp))
                            Column { Text("Seat Preset", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp); Text("ตำแหน่งการฟัง", color = TextSecondary, fontSize = 8.sp) }
                        }
                        Spacer(Modifier.height(6.dp))
                        DropdownSelector(s.seatPreset, listOf("Driver (Left)", "Passenger (Right)", "Front Center", "All Seats"), vm::setSeatPreset, compact = true)
                    }
                    NeonPanel {
                        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Tune, null, tint = Cyan, modifier = Modifier.size(21.dp)); Spacer(Modifier.width(5.dp)); Text("Distance Reference", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 11.sp) }
                        Text("อ้างอิงระยะทางเสียง", color = TextSecondary, fontSize = 8.sp)
                        Spacer(Modifier.height(5.dp))
                        Text("Speed of Sound (20°C)", color = TextSecondary, fontSize = 8.sp)
                        Text("343 m/s (34.3 cm/ms)", color = TextPrimary, fontSize = 9.sp)
                    }
                    NeonPanel {
                        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Equalizer, null, tint = Cyan, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(5.dp)); Text("Total Delay Range", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 11.sp) }
                        Text("ช่วงหน่วงเวลาทั้งหมด", color = TextSecondary, fontSize = 8.sp)
                        Spacer(Modifier.height(5.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column { Text("${formatValue(minDelay,2)} ms", color = TextPrimary, fontSize = 9.sp); Text("น้อยที่สุด", color = TextSecondary, fontSize = 7.sp) }
                            Column(horizontalAlignment = Alignment.End) { Text("${formatValue(maxDelay,2)} ms", color = TextPrimary, fontSize = 9.sp); Text("มากที่สุด", color = TextSecondary, fontSize = 7.sp) }
                        }
                    }
                }
            }
        }
        s.channels.forEachIndexed { i, c -> DelayChannelRow(i, c, s.delayUnit, vm) }
    }
}

@Composable
private fun CarDelayView(channels: List<ChannelState>, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width; val h = size.height
        val carLeft = w * .18f; val carTop = h * .08f; val carW = w * .64f; val carH = h * .84f
        drawRoundRect(Color(0xFF063052), topLeft = Offset(carLeft, carTop), size = Size(carW, carH), cornerRadius = androidx.compose.ui.geometry.CornerRadius(36f, 36f), style = Stroke(2.dp.toPx()))
        drawRoundRect(Color(0xFF0B5B90).copy(alpha = .2f), topLeft = Offset(carLeft + 8, carTop + 8), size = Size(carW - 16, carH - 16), cornerRadius = androidx.compose.ui.geometry.CornerRadius(30f, 30f))
        val seats = listOf(Offset(w*.38f,h*.33f), Offset(w*.62f,h*.33f), Offset(w*.38f,h*.62f), Offset(w*.62f,h*.62f))
        seats.forEach { p -> drawRoundRect(Color(0xFF0A5590), Offset(p.x-20,p.y-30), Size(40f,60f), androidx.compose.ui.geometry.CornerRadius(12f,12f), style = Stroke(2.dp.toPx())) }
        val pts = listOf(Offset(w*.18f,h*.34f), Offset(w*.82f,h*.34f), Offset(w*.18f,h*.68f), Offset(w*.82f,h*.68f), Offset(w*.50f,h*.12f), Offset(w*.50f,h*.87f), Offset(w*.50f,h*.74f))
        pts.forEachIndexed { i, p ->
            val c = ChannelColors[i]
            drawCircle(c.copy(alpha=.15f), 23.dp.toPx(), p)
            drawCircle(c, 8.dp.toPx(), p)
            drawCircle(TextPrimary, 10.dp.toPx(), p, style = Stroke(1.5.dp.toPx()))
        }
    }
}

@Composable
private fun DelayChannelRow(index: Int, c: ChannelState, unit: String, vm: DspViewModel) {
    NeonPanel {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            Box(Modifier.size(16.dp).background(ChannelColors[index], CircleShape))
            Column(Modifier.width(58.dp)) {
                Text(c.shortName, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                Text(c.name, color = TextSecondary, fontSize = 8.sp)
            }
            Column(Modifier.weight(1f)) {
                Slider(value = c.delayMs, onValueChange = { vm.setDelay(index, it) }, valueRange = 0f..10f, colors = neonSliderColors(ChannelColors[index]), modifier = Modifier.height(31.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    listOf("0", "2", "4", "6", "8", "10").forEach { Text(it, color = TextSecondary, fontSize = 7.sp) }
                }
            }
            Box(Modifier.width(76.dp).clip(RoundedCornerShape(8.dp)).border(1.dp, StrokeBlue, RoundedCornerShape(8.dp)).padding(vertical = 7.dp), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    if (unit == "ms") {
                        Text("${formatValue(c.delayMs, 2)} ms", color = TextPrimary, fontSize = 9.sp)
                        Text("${formatValue(c.delayMs * 34.3f, 1)} cm", color = TextSecondary, fontSize = 8.sp)
                    } else {
                        Text("${formatValue(c.delayMs * 34.3f, 1)} cm", color = TextPrimary, fontSize = 9.sp)
                        Text("${formatValue(c.delayMs, 2)} ms", color = TextSecondary, fontSize = 8.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun OutputScreen(vm: DspViewModel) {
    val s = vm.state
    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        NeonPanel(accent = Orange.copy(alpha = .6f)) {
            BoxWithConstraints(Modifier.fillMaxWidth()) {
                val compact = maxWidth < 390.dp
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    Box(Modifier.size(if (compact) 49.dp else 58.dp).clip(CircleShape).border(2.dp, Orange, CircleShape).background(Orange.copy(alpha = .08f)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.VolumeUp, null, tint = Orange, modifier = Modifier.size(if (compact) 27.dp else 31.dp))
                    }
                    Column(Modifier.weight(1f)) {
                        Text("Output", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = if (compact) 19.sp else 22.sp)
                        Text("ปรับระดับเอาต์พุตแต่ละช่อง", color = TextSecondary, fontSize = if (compact) 8.sp else 9.sp, maxLines = 1)
                    }
                    OutlinedButton(onClick = vm::allMuteOff, border = BorderStroke(1.dp, StrokeBlue), modifier = Modifier.height(40.dp)) {
                        Icon(Icons.Default.VolumeOff, null, tint = TextPrimary, modifier = Modifier.size(17.dp))
                        if (!compact) { Spacer(Modifier.width(3.dp)); Text("All Mute Off", color = TextPrimary, fontSize = 8.sp) }
                    }
                    OutlinedButton(onClick = vm::resetLevels, border = BorderStroke(1.dp, StrokeBlue), modifier = Modifier.height(40.dp)) {
                        Icon(Icons.Default.Refresh, null, tint = TextPrimary, modifier = Modifier.size(17.dp))
                        if (!compact) { Spacer(Modifier.width(3.dp)); Text("Reset Levels", color = TextPrimary, fontSize = 8.sp) }
                    }
                }
            }
            Spacer(Modifier.height(9.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                NeonPanel(Modifier.weight(1.42f)) {
                    Text("Output Level Overview", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    MeterOverview(s.channels)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                        s.channels.forEach { c -> Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(c.shortName, color = TextPrimary, fontSize = 7.sp); Text(c.name, color = TextSecondary, fontSize = 6.sp) } }
                    }
                }
                NeonPanel(Modifier.weight(.88f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Master Output", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 10.sp, modifier = Modifier.weight(1f))
                        Box(Modifier.clip(RoundedCornerShape(7.dp)).border(1.dp, StrokeBlue, RoundedCornerShape(7.dp)).padding(horizontal = 6.dp, vertical = 6.dp)) {
                            Text("${formatValue(s.masterOutputDb, 1)} dB", color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(Modifier.height(5.dp))
                    Slider(value = s.masterOutputDb, onValueChange = vm::setMasterOutput, valueRange = -60f..12f, colors = neonSliderColors(Cyan), modifier = Modifier.height(32.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        listOf("-60", "-40", "-20", "0", "+12").forEach { Text(it, color = TextSecondary, fontSize = 7.sp) }
                    }
                }
            }
        }
        s.channels.forEachIndexed { index, c -> OutputChannelRow(index, c, vm) }
    }
}

@Composable
private fun MeterOverview(channels: List<ChannelState>) {
    Canvas(Modifier.fillMaxWidth().height(90.dp)) {
        val gap = size.width / channels.size
        channels.forEachIndexed { i, c ->
            val level = ((c.outputDb + 60f) / 72f).coerceIn(0f, 1f)
            val x = gap * i + gap * .5f
            val base = size.height - 14.dp.toPx()
            val barH = (size.height - 20.dp.toPx()) * level
            for (n in 0 until 9) {
                val segY = base - n * 7.dp.toPx()
                val active = n / 9f <= level
                drawRoundRect(if (active) ChannelColors[i] else Color(0xFF133349), Offset(x - 7.dp.toPx(), segY), Size(14.dp.toPx(), 4.dp.toPx()), androidx.compose.ui.geometry.CornerRadius(2f,2f))
            }
        }
    }
}

@Composable
private fun OutputChannelRow(index: Int, c: ChannelState, vm: DspViewModel) {
    NeonPanel {
        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val compact = maxWidth < 390.dp
            if (!compact) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Box(Modifier.size(34.dp).clip(CircleShape).border(2.dp, ChannelColors[index], CircleShape).background(ChannelColors[index].copy(alpha = .08f)), contentAlignment = Alignment.Center) {
                        Text("${index + 1}", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    Column(Modifier.width(54.dp)) { Text(c.shortName, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 10.sp); Text(c.name, color = TextSecondary, fontSize = 8.sp) }
                    Column(Modifier.weight(1f)) {
                        Slider(value = c.outputDb, onValueChange = { vm.setOutput(index, it) }, valueRange = -60f..12f, colors = neonSliderColors(ChannelColors[index]), modifier = Modifier.height(30.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { listOf("-60", "-40", "-20", "0", "+12").forEach { Text(it, color = TextSecondary, fontSize = 6.sp) } }
                    }
                    Box(Modifier.width(54.dp).clip(RoundedCornerShape(7.dp)).border(1.dp, StrokeBlue, RoundedCornerShape(7.dp)).padding(vertical = 7.dp), contentAlignment = Alignment.Center) { Text("${formatValue(c.outputDb, 1)} dB", color = TextPrimary, fontSize = 8.sp) }
                    IconToggle(Icons.Default.VolumeOff, "Mute", c.muted, Pink) { vm.toggleMute(index) }
                    IconToggle(Icons.Default.Headphones, "Solo", c.solo, Cyan) { vm.toggleSolo(index) }
                    IconToggle(Icons.Default.Refresh, "Phase", c.phaseInverted, Purple) { vm.togglePhase(index) }
                    if (index < 2) IconToggle(Icons.Default.Link, "Link", c.linked, Cyan) { vm.toggleLink(index) }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Box(Modifier.size(31.dp).clip(CircleShape).border(2.dp, ChannelColors[index], CircleShape), contentAlignment = Alignment.Center) { Text("${index + 1}", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 10.sp) }
                        Column(Modifier.weight(1f)) { Text("${c.shortName}  ${c.name}", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 9.sp) }
                        Box(Modifier.width(57.dp).clip(RoundedCornerShape(7.dp)).border(1.dp, StrokeBlue, RoundedCornerShape(7.dp)).padding(vertical = 6.dp), contentAlignment = Alignment.Center) { Text("${formatValue(c.outputDb, 1)} dB", color = TextPrimary, fontSize = 8.sp) }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        Column(Modifier.weight(1f)) {
                            Slider(value = c.outputDb, onValueChange = { vm.setOutput(index, it) }, valueRange = -60f..12f, colors = neonSliderColors(ChannelColors[index]), modifier = Modifier.height(29.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { listOf("-60", "-20", "0", "+12").forEach { Text(it, color = TextSecondary, fontSize = 6.sp) } }
                        }
                        IconToggle(Icons.Default.VolumeOff, "Mute", c.muted, Pink) { vm.toggleMute(index) }
                        IconToggle(Icons.Default.Headphones, "Solo", c.solo, Cyan) { vm.toggleSolo(index) }
                        IconToggle(Icons.Default.Refresh, "Phase", c.phaseInverted, Purple) { vm.togglePhase(index) }
                        if (index < 2) IconToggle(Icons.Default.Link, "Link", c.linked, Cyan) { vm.toggleLink(index) }
                    }
                }
            }
        }
    }
}

@Composable
private fun IconToggle(icon: ImageVector, label: String, active: Boolean, accent: Color, onClick: () -> Unit) {
    Column(
        modifier = Modifier.width(43.dp).clip(RoundedCornerShape(7.dp)).border(1.dp, if (active) accent else StrokeBlue, RoundedCornerShape(7.dp)).background(if (active) accent.copy(alpha=.12f) else Color.Transparent).clickable(onClick = onClick).padding(vertical = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = if (active) accent else TextPrimary, modifier = Modifier.size(16.dp))
        Text(label, color = if (active) accent else TextSecondary, fontSize = 7.sp)
    }
}


@Composable
private fun LabeledDropdown(
    label: String,
    value: String,
    options: List<String>,
    modifier: Modifier = Modifier,
    onSelect: (String) -> Unit
) {
    Column(modifier.clip(RoundedCornerShape(8.dp)).border(1.dp, StrokeBlue, RoundedCornerShape(8.dp)).padding(6.dp)) {
        Text(label, color = TextSecondary, fontSize = 8.sp)
        Spacer(Modifier.height(2.dp))
        DropdownSelector(value, options, onSelect, compact = true)
    }
}

@Composable
private fun SmallSetting(label: String, value: String, modifier: Modifier, onMinus: () -> Unit, onPlus: () -> Unit) {
    Column(modifier.clip(RoundedCornerShape(8.dp)).border(1.dp, StrokeBlue, RoundedCornerShape(8.dp)).padding(6.dp)) {
        Text(label, color = TextSecondary, fontSize = 9.sp)
        StepperField(value, Modifier.fillMaxWidth(), onMinus, onPlus)
    }
}

@Composable
private fun UnitButton(text: String, active: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(modifier.background(if (active) Blue else Color.Transparent).clickable(onClick = onClick).padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
        Text(text, color = if (active) TextPrimary else TextSecondary, fontWeight = if (active) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
private fun TabButton(text: String, active: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier.clip(RoundedCornerShape(8.dp)).background(if (active) Brush.verticalGradient(listOf(Blue, Cyan.copy(alpha = .8f))) else Brush.verticalGradient(listOf(Color(0xFF0A2538), Color(0xFF071A28)))).border(1.dp, if (active) Cyan else StrokeBlue, RoundedCornerShape(8.dp)).clickable(onClick = onClick).padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = TextPrimary, fontSize = 11.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Normal) }
}

@Composable
private fun DropdownSelector(
    value: String,
    options: List<String>,
    onSelect: (String) -> Unit,
    compact: Boolean = false,
    directValue: ((String) -> Unit)? = null
) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        Row(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).border(1.dp, StrokeBlue, RoundedCornerShape(8.dp)).clickable { expanded = true }.padding(horizontal = 9.dp, vertical = if (compact) 7.dp else 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(value, color = TextPrimary, fontSize = if (compact) 9.sp else 11.sp, maxLines = 1, modifier = Modifier.weight(1f))
            Text("⌄", color = TextSecondary, fontSize = 13.sp)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }, containerColor = Color(0xFF092337)) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option, color = TextPrimary, fontSize = 11.sp) },
                    onClick = {
                        expanded = false
                        if (directValue != null) directValue(option) else onSelect(option)
                    }
                )
            }
        }
    }
}

@Composable
private fun neonSliderColors(accent: Color) = SliderDefaults.colors(
    thumbColor = TextPrimary,
    activeTrackColor = accent,
    inactiveTrackColor = Track,
    activeTickColor = accent,
    inactiveTickColor = TextSecondary.copy(alpha = .45f)
)

@Composable
private fun neonSwitchColors(accent: Color) = SwitchDefaults.colors(
    checkedThumbColor = TextPrimary,
    checkedTrackColor = accent,
    uncheckedThumbColor = TextPrimary,
    uncheckedTrackColor = Color(0xFF273E5A),
    uncheckedBorderColor = StrokeBlue
)

private fun formatValue(v: Float, decimals: Int): String = String.format(Locale.US, "%.${decimals}f", v)
private fun formatTick(v: Float): String = if (v >= 100f) v.toInt().toString() else String.format(Locale.US, "%.0f", v)
private fun logX(freq: Float): Float = (ln(freq.coerceIn(20f, 20000f) / 20f) / ln(1000f)).coerceIn(0f, 1f)
private fun formatFrequency(v: Float): String = if (v >= 1000f) String.format(Locale.US, "%.1f kHz", v / 1000f) else "${v.toInt()} Hz"
private fun parseFrequency(v: String): Float = if (v.contains("kHz")) v.substringBefore(" ").toFloat() * 1000f else v.substringBefore(" ").toFloat()
private fun frequencyOptions(): List<String> = listOf(20f, 25f, 31.5f, 40f, 50f, 63f, 80f, 100f, 125f, 160f, 200f, 250f, 315f, 400f, 500f, 630f, 800f, 1000f, 1250f, 1600f, 2000f, 2500f, 3150f, 4000f, 5000f, 6300f, 8000f, 10000f, 12500f, 16000f, 20000f).map(::formatFrequency)
