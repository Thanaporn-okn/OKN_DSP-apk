# OKN_DSP V3

Android native application (Kotlin + Jetpack Compose) based on the five uploaded OKN_DSP UI reference screens.

## V3 UI restructure

- Rebuilt the visible layout hierarchy to track the uploaded Home, EQ, Crossover, Delay and Output screens more closely.
- Header now uses a native waveform mark, DSP title, connection pill and settings control.
- CH1-CH7 selectors are equal-width and visible together on DSP pages.
- Home parameter rows now follow the reference structure: neon icon, title/subtitle, live slider + scale, value box.
- EQ places channel/reset controls in the title row and keeps the graph, three band groups, live parameter table and preset section.
- Crossover places view/reset controls in the title row and adds labeled Type/Frequency/Slope containers for HPF/LPF.
- Delay places unit/sync controls in the title row, retains the car layout, derives min/max delay from current values, and adds scale labels to each channel slider.
- Output places All Mute Off/Reset controls in the title row, retains overview/master output, and uses responsive channel controls.
- Compact responsive mode below 390dp; full-width layout scales up to an 820dp content area for larger phones/tablets.
- Content scrolls when required while bottom navigation remains fixed.

## Interaction

Every tab, button, switch, dropdown and slider changes Compose UI state immediately. Local preset Save/Load/Delete remains functional.

## BLE status

BLE scan/connect and discovery of characteristic `0000ab01-0000-1000-8000-00805f9b34fb` remain enabled. Confirmed command bytes for physical DSP gain/EQ/crossover/delay/output control are still not available, so V3 does not invent or transmit guessed protocol frames.

## Version policy

This package is V3 (`versionCode 3`, `versionName 1.0.2-v3`). Future build/runtime errors or implementation changes must be issued as V4, V5, and so on; previous versions are not overwritten.
