# OKN BP1048P4 Phase3 TRUE7CH — R26

R26 เป็นรอบ **offline flashboot transport reverse** ต่อจาก R25 โดยไม่มี hardware command ใหม่

อ่านหลักก่อน:
- `docs/R26_FLASHBOOT_OFFLINE_REVERSE_TH.md`
- `docs/R26_FLASHBOOT_TRANSPORT_EVIDENCE.txt`
- `config/R26_FLASHBOOT_OFFLINE_STATE.json`
- `config/R26_FLASHBOOT_COMMAND_RISK.json`

ผลหลัก:
- พบหลักฐานแรงว่า PC flashboot หลัง jump-to-0 อยู่ใน USB Mass Storage Bulk-Only Transport family (`USBC`/CBW) และมี custom command table 8 ตัว
- blacklist คำสั่งที่เป็น erase/write ได้แล้ว
- `upinfo`/`cxxx` ยังไม่พิสูจน์ว่า read-only จึงห้าม live probe
- ยังไม่มี production flash map/recovery proof และยังไม่สร้าง `.mva`

Android probe ใน source นี้ยังคง functionality แบบ R25 READ-ONLY เดิมและ relabel เป็น R26 เพื่อ continuity เท่านั้น **R26 ไม่ต้องติดตั้ง APK ใหม่** เพราะไม่มี hardware probe ใหม่ที่ควรทำ

ใช้ workflow `.github/workflows/OKN_BP1048P4_ANDROID_AUTO.yml` ตัวเดิมได้หากต้องการ verify/build source แต่ไม่จำเป็นต้องรันบนบอร์ดสำหรับ R26.
