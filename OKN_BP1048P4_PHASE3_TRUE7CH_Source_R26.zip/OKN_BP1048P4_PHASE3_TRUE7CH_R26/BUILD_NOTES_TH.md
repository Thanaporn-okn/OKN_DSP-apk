# BUILD NOTES — R26

R26 ไม่เพิ่ม hardware action. Android module ถูก relabel เป็น R26 แต่ยังทำเฉพาะ Bluetooth discovery/SDP/GATT UUID enumeration แบบเดิมจาก R25.

Host/offline verification ที่ต้องผ่าน:
1. TRUE7CH host tests เดิม
2. R25 read-only guard เดิม
3. R26 flashboot offline inspector ต้อง reconstruct 65536 bytes และ SHA256 reference ตรง
4. R26 safety guard ต้องยืนยันว่าไม่มี code ใหม่สำหรับ USB transport/OBEX/flash write

AUTO GitHub Actions workflow เดิมใช้ได้; ไม่ต้องเปลี่ยน workflow ตามเลข revision.
