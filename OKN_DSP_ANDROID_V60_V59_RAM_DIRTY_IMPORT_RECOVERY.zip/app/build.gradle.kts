plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
kotlin {
    jvmToolchain(17)
}

android {
    namespace = "com.okn.dsp"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.okn.dsp"
        minSdk = 26
        targetSdk = 35
        versionCode = 60
        versionName = "4.2.0-v60-v59-ram-dirty-import-recovery"
    }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
}
