# OKN DSP Android V18 — Session Evidence Gate

V18 adds a conservative evidence validator on top of V17 multi-session correlation.

- BLE discovery/read/notify only.
- DSP actuator WRITE remains hard-disabled.
- Counts RX_READ/RX_NOTIFY and AB02/AB03 notifications.
- Detects AB01 empty reads as read evidence, not a protocol frame.
- Separates notification presence from event-attribution evidence.
- Does not infer command fields, checksum, encryption, parameter meaning, or write frames.

The gate reports INSUFFICIENT_EVENT_EVIDENCE when a session contains only an AB01 empty read and no RX_NOTIFY.
