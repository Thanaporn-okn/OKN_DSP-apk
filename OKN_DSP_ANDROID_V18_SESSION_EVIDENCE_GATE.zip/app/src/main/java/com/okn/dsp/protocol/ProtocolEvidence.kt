package com.okn.dsp.protocol

/** Evidence gate: no protocol write is permitted unless every wire-level requirement is proven. */
data class ProtocolEvidence(
    val framingVerified: Boolean = false,
    val integrityVerified: Boolean = false,
    val encryptionVerified: Boolean = false,
    val actuatorMappingVerified: Boolean = false,
    val serializerVerified: Boolean = false,
) {
    val writeEnabled: Boolean
        get() = framingVerified && integrityVerified && encryptionVerified &&
                actuatorMappingVerified && serializerVerified

    fun missingRequirements(): List<String> = buildList {
        if (!framingVerified) add("UFE framing")
        if (!integrityVerified) add("integrity/check")
        if (!encryptionVerified) add("encryption/key derivation")
        if (!actuatorMappingVerified) add("actuator mapping")
        if (!serializerVerified) add("EQ/actuator serializer")
    }
}
