package com.okn.dsp.protocol

import com.okn.dsp.protocol.ByteCodec.toHex

/**
 * Authentication evidence only. This class never transmits BLE data.
 * Three historical sessions contain a raw 32-byte auth response + official-app RandKey.
 * The latest 2026-09-06 20:08 session contributes a log-confirmed RandKey but its btsnoop
 * begins after auth, so that session is intentionally NOT treated as a paired vector.
 */
data class AuthVector(
    val label: String,
    val response32Hex: String,
    val randKeyHex: String,
    val encryptedDeviceDescriptionRequestHex: String,
)

data class AuthVectorCheck(
    val label: String,
    val typeId: Int,
    val versionId: Int,
    val field4to7Hex: String,
    val fixed8Hex: String,
    val encryptedRandKeyHex: String,
    val randKeyHex: String,
    val firstXor: Int,
    val requestCipherMatches: Boolean,
)

object AuthVectorLab {
    const val UNIQUE_ID_HEX = "060708080D07405C"
    const val FIXED_8_15_HEX = "420DA6E8FDDF0689"
    const val LATEST_LOG_ONLY_RANDKEY = "1099DB843E2A033FF3707888A3AF066C"

    val pairedVectors = listOf(
        AuthVector(
            "19:21:34",
            "D024E38C13000000420DA6E8FDDF0689DD5F38C36C27E4BF3BFDA166FD82E8CB",
            "81162308EBF817D62C083CD5250A2D4D",
            "AC6B6C12",
        ),
        AuthVector(
            "18:29:45",
            "D024E38C13000000420DA6E8FDDF068970287AA5C063B592A366D2CBED42EAFF",
            "2CDB9100B0162F6D82285C9706EFABB3",
            "B596F744",
        ),
        AuthVector(
            "16:15:33",
            "D024E38C00000000420DA6E8FDDF0689AD155C32009F94B47BFE6DCB239E1492",
            "F10BAF44D02D73219FCD0D7D67BFF712",
            "4B4D249B",
        ),
    )

    fun check(vector: AuthVector): AuthVectorCheck {
        val raw = ByteCodec.hexToBytes(vector.response32Hex)
        val h = AuthResponseCodec.parse32(raw)
        val key = ByteCodec.hexToBytes(vector.randKeyHex)
        val cipher = SessionTxCipher(key).encryptNext(SessionCryptoFacts.DEVICE_DESCRIPTION_REQUEST)
        return AuthVectorCheck(
            label = vector.label,
            typeId = h.typeId,
            versionId = h.versionId,
            field4to7Hex = h.field4to7.toHex(),
            fixed8Hex = h.fixed8.toHex(),
            encryptedRandKeyHex = h.encryptedRandKey.toHex(),
            randKeyHex = vector.randKeyHex,
            firstXor = (h.encryptedRandKey[0].toInt() xor key[0].toInt()) and 0xff,
            requestCipherMatches = cipher.toHex() == vector.encryptedDeviceDescriptionRequestHex,
        )
    }

    fun report(): List<String> = buildList {
        add("AUTH VECTOR LAB • paired=${pairedVectors.size}")
        pairedVectors.forEach { v ->
            val c = check(v)
            add("${c.label} • Type=${c.typeId} Ver=${c.versionId} f4-7=${c.field4to7Hex} fixed8=${c.fixed8Hex}")
            add("${c.label} • encTail=${c.encryptedRandKeyHex} RandKey=${c.randKeyHex}")
            add("${c.label} • C0 xor K0=%02X • device-desc request=%s".format(c.firstXor, if (c.requestCipherMatches) "PASS" else "FAIL"))
        }
        val xorValues = pairedVectors.map { check(it).firstXor }.distinct()
        add("C0 xor RandKey[0] across 3 paired sessions = ${xorValues.joinToString { "%02X".format(it) }}")
        add("Latest official-app log only • Type=53284 Ver=58252 UUID=$UNIQUE_ID_HEX RandKey=$LATEST_LOG_ONLY_RANDKEY")
        add("Latest btsnoop begins after authentication; latest RandKey is NOT promoted to a paired auth vector")
        add("LIVE WRITE LOCKED • pre-auth decrypt key/IV/derivation still not verified")
    }
}
