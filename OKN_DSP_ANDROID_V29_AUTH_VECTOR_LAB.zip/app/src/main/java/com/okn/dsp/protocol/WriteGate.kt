package com.okn.dsp.protocol

/**
 * V29 live write gate.
 * UFE serializer + EQ48 + AES-CFB8 TX path are verified, but a standalone session still
 * cannot derive the current RandKey from the 32-byte authentication response. Keep false.
 */
object WriteGate {
    const val enabled: Boolean = false
}
