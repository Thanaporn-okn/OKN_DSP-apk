OKN DSP ANDROID V29 — AUTH VECTOR LAB

Purpose
- Keep all V28 verified UFE / EQ48 / post-auth AES-CFB8 behavior.
- Promote three historical 32-byte authentication response + official-app RandKey pairs into executable self-test vectors.
- Record latest official-app log-only RandKey without falsely treating it as a paired vector, because that bugreport's btsnoop starts after auth.
- Keep LIVE WRITE disabled until the pre-auth RandKey decrypt key/IV/derivation is independently verified.

Verified auth observations
- TypeID = 53284 (0xD024)
- VersionID = 58252 (0xE38C)
- response bytes 8..15 = 420DA6E8FDDF0689 in all paired captures
- response bytes 16..31 vary per session and correspond to protected RandKey material
- for 3 paired sessions: response[16] XOR RandKey[0] = 0x5C
- each recovered RandKey reproduces the captured encrypted device-description request under the already verified post-auth AES-CFB8 model

Latest bugreport 2026-09-06 20:08
- official app logged UUID uniqueID 060708080D07405C
- official app logged RandKey 1099DB843E2A033FF3707888A3AF066C
- btsnoop starts after the authentication exchange, so no same-session raw response32 is available in that file

Safety
WriteGate stays false. V29 does not guess or transmit a DSP parameter command.
