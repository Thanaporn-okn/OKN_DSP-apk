# OKN DSP V13 — AB01 → AB02 → AB03 Test

V13 is a clean build payload for the OKN DSP reverse-engineering test.

Known from captured data:
- Service: 0000AB00-0000-1000-8000-00805F9B34FB
- AB01: READ / WRITE
- AB02: NOTIFY
- AB03: NOTIFY
- observed TX: 16 bytes
- observed RX: 32 bytes
- observed bulk: 18,252 bytes = 77×235 + 157

V13 test flow:
1. Connect to the real DSP BLE device.
2. Discover GATT.
3. Enable AB02 Notify.
4. Enable AB03 Notify.
5. READ AB01.
6. Capture raw AB02/AB03 RX.
7. Export/copy all captured data.

No guessed DSP control payload is sent.
