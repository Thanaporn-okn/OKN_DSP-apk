import 'package:flutter/material.dart';

import 'core/theme/app_theme.dart';
import 'features/dsp/screens/dsp_shell.dart';

class OknDspApp extends StatelessWidget {
  const OknDspApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'OKN_DSP',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark,
      home: const DspShell(),
    );
  }
}
