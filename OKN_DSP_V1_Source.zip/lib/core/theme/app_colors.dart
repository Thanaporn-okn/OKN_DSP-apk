import 'package:flutter/material.dart';

abstract final class AppColors {
  static const background = Color(0xFF080D1A);
  static const panel = Color(0xA60B1A2F);
  static const panelStrong = Color(0xE6102036);
  static const border = Color(0xFF124E78);
  static const cyan = Color(0xFF00F0FF);
  static const blue = Color(0xFF008CFF);
  static const pink = Color(0xFFFF007F);
  static const purple = Color(0xFF8A2BE2);
  static const orange = Color(0xFFFF8C00);
  static const yellow = Color(0xFFFFD700);
  static const green = Color(0xFF00FF78);
  static const text = Color(0xFFF4F8FF);
  static const muted = Color(0xFF9BC4E8);
  static const track = Color(0xFF173B60);

  static const channelColors = <Color>[
    Color(0xFF14C7FF),
    Color(0xFFFF9B24),
    Color(0xFF00E86C),
    Color(0xFFFF4FC3),
    Color(0xFFF0F2F4),
    Color(0xFFA73EFF),
    Color(0xFF00E5FF),
  ];

  static const eqColors = <Color>[
    Color(0xFFFF3257),
    Color(0xFFFF9A22),
    Color(0xFFFFE600),
    Color(0xFF00F06B),
    Color(0xFF00E8F0),
    Color(0xFFB63BFF),
    Color(0xFF3B8CFF),
    Color(0xFFFF4FC3),
    Color(0xFF2DE2A6),
    Color(0xFFFFB32D),
    Color(0xFF7C6CFF),
    Color(0xFFFF6E6E),
    Color(0xFF00D5FF),
    Color(0xFF73FF52),
    Color(0xFFFF49A8),
  ];
}
