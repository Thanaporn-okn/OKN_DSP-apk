import 'package:flutter/material.dart';

import 'app_colors.dart';

abstract final class AppTheme {
  static ThemeData get dark {
    final base = ThemeData.dark(useMaterial3: true);
    return base.copyWith(
      scaffoldBackgroundColor: AppColors.background,
      colorScheme: const ColorScheme.dark(
        primary: AppColors.cyan,
        secondary: AppColors.pink,
        surface: AppColors.panelStrong,
      ),
      textTheme: base.textTheme.apply(
        bodyColor: AppColors.text,
        displayColor: AppColors.text,
      ),
      dividerColor: AppColors.border.withValues(alpha: .45),
      dropdownMenuTheme: DropdownMenuThemeData(
        textStyle: const TextStyle(color: AppColors.text),
        menuStyle: MenuStyle(
          backgroundColor: WidgetStateProperty.all(AppColors.panelStrong),
          side: WidgetStateProperty.all(const BorderSide(color: AppColors.border)),
        ),
      ),
    );
  }
}
