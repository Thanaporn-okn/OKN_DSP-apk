import 'dart:math' as math;

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/dsp_state.dart';
import '../services/dsp_transport.dart';

final dspTransportProvider = Provider<DspTransport>((ref) => MockDspTransport());
final dspProvider = StateNotifierProvider<DspController, DspState>((ref) {
  return DspController(ref.read(dspTransportProvider));
});

class DspController extends StateNotifier<DspState> {
  final DspTransport transport;
  DspController(this.transport) : super(DspState.initial());

  Future<void> _send(String key, num value, {int? channel}) => transport.sendParameter(key, value, channel: channel);

  void selectPage(int value) => state = state.copyWith(page: value);
  void selectChannel(int value) => state = state.copyWith(channel: value.clamp(0, 6).toInt());
  void setConnected(bool value) => state = state.copyWith(connected: value);

  void setMasterVolume(double value) { state = state.copyWith(masterVolume: value); _send('masterVolume', value); }
  void setBassVolume(double value) { state = state.copyWith(bassVolume: value); _send('bassVolume', value); }
  void setBassCutoff(double value) { state = state.copyWith(bassCutoff: value); _send('bassCutoff', value); }
  void setBassBoost(double value) { state = state.copyWith(bassBoost: value); _send('bassBoost', value); }
  void setMiddleBoost(double value) { state = state.copyWith(middleBoost: value); _send('middleBoost', value); }
  void setTrebleBoost(double value) { state = state.copyWith(trebleBoost: value); _send('trebleBoost', value); }
  void setAudioSource(String value) => state = state.copyWith(audioSource: value);
  void setSystemPreset(String value) => state = state.copyWith(systemPreset: value);
  void setBandPage(int value) => state = state.copyWith(bandPage: value.clamp(0, 2).toInt());

  void updateEqBand(int index, {String? type, double? frequency, double? gain, double? q, bool? enabled}) {
    final all = state.eqByChannel.map((e) => List<EqBand>.from(e)).toList();
    final old = all[state.channel][index];
    final next = old.copyWith(type: type, frequency: frequency, gain: gain, q: q, enabled: enabled);
    all[state.channel][index] = next;
    state = state.copyWith(eqByChannel: all);
    if (frequency != null) _send('eqFrequency', next.frequency, channel: state.channel);
    if (gain != null) _send('eqGain', next.gain, channel: state.channel);
    if (q != null) _send('eqQ', next.q, channel: state.channel);
  }

  void resetEq() {
    final fresh = DspState.initial().eqByChannel[state.channel];
    final all = state.eqByChannel.map((e) => List<EqBand>.from(e)).toList();
    all[state.channel] = List<EqBand>.from(fresh);
    state = state.copyWith(eqByChannel: all);
  }

  void setHpf({String? type, double? frequency, int? slope, bool? bypass}) {
    state = state.copyWith(hpf: state.hpf.copyWith(type: type, frequency: frequency, slope: slope, bypass: bypass));
  }
  void setLpf({String? type, double? frequency, int? slope, bool? bypass}) {
    state = state.copyWith(lpf: state.lpf.copyWith(type: type, frequency: frequency, slope: slope, bypass: bypass));
  }
  void resetCrossover() => state = state.copyWith(hpf: DspState.initial().hpf, lpf: DspState.initial().lpf);
  void setPhase(int value) => state = state.copyWith(phaseDegrees: value);
  void setPolarity(bool normal) => state = state.copyWith(polarityNormal: normal);
  void setLinkLR(bool value) => state = state.copyWith(linkLR: value);
  void setOutputMode(String value) => state = state.copyWith(outputMode: value);
  void setDelayUnit(bool inMs) => state = state.copyWith(delayInMs: inMs);
  void setSeatPreset(String value) => state = state.copyWith(seatPreset: value);
  void setDelay(int channel, double value) {
    final list = List<double>.from(state.delaysMs); list[channel] = value.clamp(0, 10).toDouble();
    state = state.copyWith(delaysMs: list); _send('delayMs', list[channel], channel: channel);
  }
  void syncDelays() {
    final mean = state.delaysMs.reduce((a, b) => a + b) / state.delaysMs.length;
    state = state.copyWith(delaysMs: List<double>.filled(7, mean));
  }

  void setMasterOutput(double value) { state = state.copyWith(masterOutput: value); _send('masterOutput', value); }
  void setOutputGain(int channel, double value) {
    final list = List<OutputChannel>.from(state.outputs); list[channel] = list[channel].copyWith(gain: value);
    state = state.copyWith(outputs: list); _send('outputGain', value, channel: channel);
  }
  void toggleOutput(int channel, String field) {
    final list = List<OutputChannel>.from(state.outputs);
    final o = list[channel];
    list[channel] = switch (field) {
      'mute' => o.copyWith(mute: !o.mute),
      'solo' => o.copyWith(solo: !o.solo),
      'phase' => o.copyWith(phase: !o.phase),
      'link' => o.copyWith(link: !o.link),
      _ => o,
    };
    state = state.copyWith(outputs: list);
  }
  void allMuteOff() => state = state.copyWith(outputs: state.outputs.map((o) => o.copyWith(mute: false)).toList());
  void resetOutputLevels() => state = state.copyWith(masterOutput: -1, outputs: DspState.initial().outputs);

  static double msToCm(double ms) => ms * 34.3;
  static double normalizedLogFrequency(double hz) => (math.log(hz / 20) / math.log(1000)).clamp(0.0, 1.0).toDouble();
  static double frequencyFromNormalized(double x) => (20 * math.pow(1000, x.clamp(0, 1))).toDouble();
}
