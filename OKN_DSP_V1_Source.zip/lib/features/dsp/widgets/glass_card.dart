import 'dart:ui';

import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';

class GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color glowColor;
  final double radius;
  final VoidCallback? onTap;

  const GlassCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.glowColor = AppColors.blue,
    this.radius = 18,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final body = ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(radius),
            border: Border.all(color: glowColor.withValues(alpha: .35)),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [AppColors.panel.withValues(alpha: .92), AppColors.panel.withValues(alpha: .68)],
            ),
            boxShadow: [BoxShadow(color: glowColor.withValues(alpha: .10), blurRadius: 22, spreadRadius: -8)],
          ),
          child: child,
        ),
      ),
    );
    if (onTap == null) return body;
    return InkWell(borderRadius: BorderRadius.circular(radius), onTap: onTap, child: body);
  }
}
