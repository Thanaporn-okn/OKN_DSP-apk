import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';

class SectionTitle extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String title;
  final String subtitle;
  final List<Widget> actions;

  const SectionTitle({super.key, required this.icon, required this.color, required this.title, required this.subtitle, this.actions = const []});

  @override
  Widget build(BuildContext context) {
    return Wrap(
      alignment: WrapAlignment.spaceBetween,
      crossAxisAlignment: WrapCrossAlignment.center,
      spacing: 16,
      runSpacing: 12,
      children: [
        Row(mainAxisSize: MainAxisSize.min, children: [
          Container(
            width: 72,
            height: 72,
            decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: color, width: 3), boxShadow: [BoxShadow(color: color.withValues(alpha: .45), blurRadius: 24)]),
            child: Icon(icon, color: color, size: 38),
          ),
          const SizedBox(width: 18),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: AppColors.text)),
            Text(subtitle, style: const TextStyle(fontSize: 15, color: AppColors.muted)),
          ]),
        ]),
        if (actions.isNotEmpty) Wrap(spacing: 10, runSpacing: 10, children: actions),
      ],
    );
  }
}
