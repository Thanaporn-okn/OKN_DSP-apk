import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';

class NeonSlider extends StatelessWidget {
  final double value;
  final double min;
  final double max;
  final ValueChanged<double> onChanged;
  final Color color;
  final int? divisions;

  const NeonSlider({
    super.key,
    required this.value,
    required this.min,
    required this.max,
    required this.onChanged,
    this.color = AppColors.cyan,
    this.divisions,
  });

  @override
  Widget build(BuildContext context) {
    return SliderTheme(
      data: SliderTheme.of(context).copyWith(
        trackHeight: 9,
        trackShape: GradientSliderTrackShape(color),
        thumbShape: NeonThumbShape(color),
        overlayShape: const RoundSliderOverlayShape(overlayRadius: 24),
        overlayColor: color.withValues(alpha: .15),
      ),
      child: Slider(value: value.clamp(min, max).toDouble(), min: min, max: max, divisions: divisions, onChanged: onChanged),
    );
  }
}

class GradientSliderTrackShape extends RoundedRectSliderTrackShape {
  final Color color;
  const GradientSliderTrackShape(this.color);

  @override
  void paint(
    PaintingContext context,
    Offset offset, {
    required RenderBox parentBox,
    required SliderThemeData sliderTheme,
    required Animation<double> enableAnimation,
    required TextDirection textDirection,
    required Offset thumbCenter,
    Offset? secondaryOffset,
    bool isDiscrete = false,
    bool isEnabled = false,
  }) {
    final rect = getPreferredRect(parentBox: parentBox, offset: offset, sliderTheme: sliderTheme, isEnabled: isEnabled, isDiscrete: isDiscrete);
    final radius = Radius.circular(rect.height / 2);
    final canvas = context.canvas;
    canvas.drawRRect(RRect.fromRectAndRadius(rect, radius), Paint()..color = AppColors.track);
    final active = Rect.fromLTRB(rect.left, rect.top, thumbCenter.dx.clamp(rect.left, rect.right).toDouble(), rect.bottom);
    if (active.width > 0) {
      final paint = Paint()
        ..shader = LinearGradient(colors: [color, AppColors.cyan, Colors.white.withValues(alpha: .75)]).createShader(active)
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, 5);
      canvas.drawRRect(RRect.fromRectAndRadius(active, radius), paint);
      paint.maskFilter = null;
      canvas.drawRRect(RRect.fromRectAndRadius(active, radius), paint);
    }
  }
}

class NeonThumbShape extends SliderComponentShape {
  final Color color;
  const NeonThumbShape(this.color);
  @override
  Size getPreferredSize(bool isEnabled, bool isDiscrete) => const Size(28, 28);

  @override
  void paint(PaintingContext context, Offset center, {required Animation<double> activationAnimation, required Animation<double> enableAnimation, required bool isDiscrete, required TextPainter labelPainter, required RenderBox parentBox, required SliderThemeData sliderTheme, required TextDirection textDirection, required double value, required double textScaleFactor, required Size sizeWithOverflow}) {
    final canvas = context.canvas;
    canvas.drawCircle(center, 18, Paint()..color = color.withValues(alpha: .18)..maskFilter = MaskFilter.blur(BlurStyle.normal, 9));
    canvas.drawCircle(center, 13, Paint()..color = Colors.white);
    canvas.drawCircle(center, 13, Paint()..style = PaintingStyle.stroke..strokeWidth = 2..color = color.withValues(alpha: .75));
  }
}
