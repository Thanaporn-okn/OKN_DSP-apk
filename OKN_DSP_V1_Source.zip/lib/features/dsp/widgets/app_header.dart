import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_colors.dart';
import '../state/dsp_controller.dart';
import 'glass_card.dart';

class AppHeader extends ConsumerWidget {
  const AppHeader({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(dspProvider);
    final compact = MediaQuery.sizeOf(context).width < 600;
    final title = state.page == 0 ? 'OKN_DSP' : 'DSP Control';
    return Row(children: [
      _Logo(compact: compact),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: compact ? 24 : 32, fontWeight: FontWeight.w800, letterSpacing: .3)),
        if (!compact) const Text('Professional Audio Processor', style: TextStyle(color: AppColors.muted)),
      ])),
      GlassCard(
        radius: 14,
        padding: EdgeInsets.symmetric(horizontal: compact ? 10 : 14, vertical: 8),
        child: Row(children: [
          Container(width: 14, height: 14, decoration: BoxDecoration(color: state.connected ? AppColors.green : AppColors.pink, shape: BoxShape.circle, boxShadow: [BoxShadow(color: (state.connected ? AppColors.green : AppColors.pink).withValues(alpha: .55), blurRadius: 12)])),
          const SizedBox(width: 9),
          if (!compact) Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(state.connected ? 'Connected' : 'Disconnected', style: TextStyle(color: state.connected ? AppColors.green : AppColors.pink, fontWeight: FontWeight.w700)),
            const Text('DSP-7900', style: TextStyle(color: AppColors.muted, fontSize: 12)),
          ]),
          const SizedBox(width: 6),
          const Icon(Icons.chevron_right, color: AppColors.muted),
        ]),
      ),
      const SizedBox(width: 8),
      IconButton(
        onPressed: () => _settings(context, ref),
        icon: const Icon(Icons.settings_outlined, color: AppColors.text, size: 30),
      ),
    ]);
  }

  void _settings(BuildContext context, WidgetRef ref) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.panelStrong,
      showDragHandle: true,
      builder: (context) => Consumer(builder: (context, sheetRef, _) {
        final connected = sheetRef.watch(dspProvider.select((s) => s.connected));
        return Padding(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 30),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const ListTile(leading: Icon(Icons.graphic_eq, color: AppColors.cyan), title: Text('OKN_DSP'), subtitle: Text('Version V1 • 1.0.0+1')),
            SwitchListTile(
              value: connected,
              activeThumbColor: AppColors.cyan,
              title: const Text('DSP connection status'),
              subtitle: const Text('Demo transport in V1'),
              onChanged: sheetRef.read(dspProvider.notifier).setConnected,
            ),
            const ListTile(leading: Icon(Icons.bluetooth, color: AppColors.muted), title: Text('Hardware protocol'), subtitle: Text('Transport interface ready; verified DSP command packets still required.')),
          ]),
        );
      }),
    );
  }
}

class _Logo extends StatelessWidget {
  final bool compact;
  const _Logo({required this.compact});
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: compact ? 48 : 64,
      height: 56,
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, crossAxisAlignment: CrossAxisAlignment.center, children: List.generate(5, (i) {
        final heights = [24.0, 38.0, 52.0, 38.0, 24.0];
        return Container(width: 5, height: heights[i], decoration: BoxDecoration(color: AppColors.cyan, borderRadius: BorderRadius.circular(6), boxShadow: [BoxShadow(color: AppColors.cyan.withValues(alpha: .7), blurRadius: 10)]));
      })),
    );
  }
}
