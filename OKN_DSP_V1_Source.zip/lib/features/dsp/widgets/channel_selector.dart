import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_colors.dart';
import '../state/dsp_controller.dart';

const channelNames = ['Front L', 'Front R', 'Rear L', 'Rear R', 'Center', 'Sub L', 'Sub R'];

class ChannelSelector extends ConsumerWidget {
  const ChannelSelector({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final selected = ref.watch(dspProvider.select((s) => s.channel));
    return LayoutBuilder(builder: (context, c) {
      return SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: List.generate(7, (i) {
            final active = i == selected;
            return Padding(
              padding: EdgeInsets.only(right: i == 6 ? 0 : 8),
              child: InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: () => ref.read(dspProvider.notifier).selectChannel(i),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  width: c.maxWidth >= 760 ? (c.maxWidth - 48) / 7 : 104,
                  padding: const EdgeInsets.symmetric(vertical: 11),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: active ? AppColors.cyan : AppColors.border),
                    gradient: active ? const LinearGradient(colors: [AppColors.blue, AppColors.cyan]) : null,
                    color: active ? null : AppColors.panelStrong,
                    boxShadow: active ? [BoxShadow(color: AppColors.cyan.withValues(alpha: .32), blurRadius: 16)] : null,
                  ),
                  child: Column(children: [
                    Text('CH${i + 1}', style: TextStyle(fontWeight: FontWeight.w800, color: active ? Colors.white : AppColors.text)),
                    const SizedBox(height: 2),
                    Text(channelNames[i], style: TextStyle(fontSize: 12, color: active ? Colors.white : AppColors.muted)),
                  ]),
                ),
              ),
            );
          }),
        ),
      );
    });
  }
}
