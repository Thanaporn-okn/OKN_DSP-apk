abstract interface class DspTransport {
  Future<void> sendParameter(String parameter, num value, {int? channel});
}

class MockDspTransport implements DspTransport {
  @override
  Future<void> sendParameter(String parameter, num value, {int? channel}) async {
    // V1 deliberately performs no hardware write. Replace with verified DSP protocol transport.
  }
}
