import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_colors.dart';
import '../models/dsp_state.dart';
import '../state/dsp_controller.dart';
import '../widgets/channel_selector.dart';
import '../widgets/glass_card.dart';
import '../widgets/section_title.dart';

class EqScreen extends ConsumerWidget {
  const EqScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(dspProvider);
    final ctrl = ref.read(dspProvider.notifier);
    final bands = s.eqByChannel[s.channel];
    final start = s.bandPage == 0 ? 0 : s.bandPage == 1 ? 6 : 12;
    final end = s.bandPage == 0 ? 6 : s.bandPage == 1 ? 12 : 15;
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(children: [
        const ChannelSelector(),
        const SizedBox(height: 14),
        GlassCard(child: Column(children: [
          SectionTitle(icon: Icons.multiline_chart, color: AppColors.cyan, title: 'Parametric EQ', subtitle: 'ปรับแต่งความถี่เสียงอย่างละเอียด', actions: [
            OutlinedButton.icon(onPressed: ctrl.resetEq, icon: const Icon(Icons.refresh), label: const Text('รีเซ็ต EQ')),
          ]),
          const SizedBox(height: 16),
          SizedBox(height: 300, child: _EqChart(bands: bands, onChanged: (index, f, g) => ctrl.updateEqBand(index, frequency: f, gain: g))),
        ])),
        const SizedBox(height: 12),
        Row(children: List.generate(3, (i) => Expanded(child: Padding(padding: EdgeInsets.only(right: i == 2 ? 0 : 7), child: _BandTab(label: ['Bands 1 - 6', 'Bands 7 - 12', 'Bands 13 - 15'][i], active: s.bandPage == i, onTap: () => ctrl.setBandPage(i)))))),
        const SizedBox(height: 10),
        GlassCard(child: Column(children: [
          const _BandHeader(),
          const Divider(),
          for (var i = start; i < end; i++) _BandRow(band: bands[i], color: AppColors.eqColors[i], onUpdate: ({String? type, double? frequency, double? gain, double? q, bool? enabled}) => ctrl.updateEqBand(i, type: type, frequency: frequency, gain: gain, q: q, enabled: enabled)),
        ])),
        const SizedBox(height: 12),
        GlassCard(child: LayoutBuilder(builder: (context, c) {
          return Wrap(alignment: WrapAlignment.spaceBetween, crossAxisAlignment: WrapCrossAlignment.center, spacing: 12, runSpacing: 12, children: [
            SizedBox(width: c.maxWidth > 650 ? 280 : c.maxWidth, child: const ListTile(contentPadding: EdgeInsets.zero, leading: Icon(Icons.folder_open, color: AppColors.cyan, size: 38), title: Text('Preset', style: TextStyle(fontWeight: FontWeight.w800)), subtitle: Text('ชุดค่าที่ใช้งานอยู่\nCustom 1'))),
            FilledButton.tonalIcon(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('บันทึก Preset: Custom 1 แล้ว'))), icon: const Icon(Icons.save), label: const Text('Save')),
            OutlinedButton.icon(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Preset Manager พร้อมใช้งาน'))), icon: const Icon(Icons.description_outlined), label: const Text('Manage')),
          ]);
        })),
        const SizedBox(height: 12),
      ]),
    );
  }
}

class _BandTab extends StatelessWidget {
  final String label; final bool active; final VoidCallback onTap;
  const _BandTab({required this.label, required this.active, required this.onTap});
  @override
  Widget build(BuildContext context) => InkWell(onTap: onTap, borderRadius: BorderRadius.circular(12), child: AnimatedContainer(duration: const Duration(milliseconds: 160), height: 54, alignment: Alignment.center, decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), border: Border.all(color: active ? AppColors.cyan : AppColors.border), gradient: active ? const LinearGradient(colors: [AppColors.blue, AppColors.cyan]) : null, color: active ? null : AppColors.panelStrong, boxShadow: active ? [BoxShadow(color: AppColors.cyan.withValues(alpha: .25), blurRadius: 16)] : null), child: Text(label, style: TextStyle(fontWeight: FontWeight.w700, color: active ? Colors.white : AppColors.text))));
}

class _BandHeader extends StatelessWidget {
  const _BandHeader();
  @override
  Widget build(BuildContext context) => const Row(children: [SizedBox(width: 52, child: Text('#')), Expanded(flex: 2, child: Text('Type')), Expanded(flex: 2, child: Text('Frequency')), Expanded(flex: 2, child: Text('Gain')), Expanded(flex: 2, child: Text('Q')), SizedBox(width: 64, child: Text('Power', textAlign: TextAlign.center))]);
}

class _BandRow extends StatelessWidget {
  final EqBand band; final Color color; final void Function({String? type, double? frequency, double? gain, double? q, bool? enabled}) onUpdate;
  const _BandRow({required this.band, required this.color, required this.onUpdate});

  @override
  Widget build(BuildContext context) {
    Widget step(String text, VoidCallback minus, VoidCallback plus) => Container(height: 44, margin: const EdgeInsets.symmetric(horizontal: 3, vertical: 5), decoration: BoxDecoration(border: Border.all(color: AppColors.border), borderRadius: BorderRadius.circular(10), color: AppColors.background.withValues(alpha: .32)), child: Row(children: [IconButton(padding: EdgeInsets.zero, visualDensity: VisualDensity.compact, onPressed: minus, icon: const Icon(Icons.chevron_left, size: 20)), Expanded(child: Text(text, textAlign: TextAlign.center, style: const TextStyle(fontSize: 13))), IconButton(padding: EdgeInsets.zero, visualDensity: VisualDensity.compact, onPressed: plus, icon: const Icon(Icons.chevron_right, size: 20))]));
    return LayoutBuilder(builder: (context, c) {
      if (c.maxWidth < 620) {
        return Container(margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(10), decoration: BoxDecoration(border: Border.all(color: AppColors.border.withValues(alpha: .7)), borderRadius: BorderRadius.circular(12)), child: Column(children: [
          Row(children: [Container(width: 18, height: 18, decoration: BoxDecoration(color: color, shape: BoxShape.circle, boxShadow: [BoxShadow(color: color, blurRadius: 9)])), const SizedBox(width: 8), Text('${band.index + 1}', style: const TextStyle(fontWeight: FontWeight.w800)), const Spacer(), Switch(value: band.enabled, onChanged: (v) => onUpdate(enabled: v), activeThumbColor: AppColors.cyan)]),
          DropdownButtonFormField<String>(value: band.type, decoration: const InputDecoration(labelText: 'Type', isDense: true), items: const ['PEQ', 'Low Shelf', 'High Shelf'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) { if (v != null) onUpdate(type: v); }),
          Row(children: [Expanded(child: step(_freq(band.frequency), () => onUpdate(frequency: (band.frequency / 1.12).clamp(20, 20000).toDouble()), () => onUpdate(frequency: (band.frequency * 1.12).clamp(20, 20000).toDouble()))), Expanded(child: step('${band.gain.toStringAsFixed(1)} dB', () => onUpdate(gain: (band.gain - .5).clamp(-12, 12).toDouble()), () => onUpdate(gain: (band.gain + .5).clamp(-12, 12).toDouble()))), Expanded(child: step(band.q.toStringAsFixed(2), () => onUpdate(q: (band.q - .1).clamp(.3, 10).toDouble()), () => onUpdate(q: (band.q + .1).clamp(.3, 10).toDouble())))]),
        ]));
      }
      return Row(children: [
        SizedBox(width: 52, child: Row(children: [Container(width: 18, height: 18, decoration: BoxDecoration(color: color, shape: BoxShape.circle, boxShadow: [BoxShadow(color: color, blurRadius: 9)])), const SizedBox(width: 6), Text('${band.index + 1}')])),
        Expanded(flex: 2, child: Padding(padding: const EdgeInsets.symmetric(horizontal: 3), child: DropdownButtonFormField<String>(value: band.type, isExpanded: true, decoration: const InputDecoration(isDense: true, border: OutlineInputBorder()), items: const ['PEQ', 'Low Shelf', 'High Shelf'].map((v) => DropdownMenuItem(value: v, child: Text(v, overflow: TextOverflow.ellipsis))).toList(), onChanged: (v) { if (v != null) onUpdate(type: v); }))),
        Expanded(flex: 2, child: step(_freq(band.frequency), () => onUpdate(frequency: (band.frequency / 1.12).clamp(20, 20000).toDouble()), () => onUpdate(frequency: (band.frequency * 1.12).clamp(20, 20000).toDouble()))),
        Expanded(flex: 2, child: step('${band.gain.toStringAsFixed(1)} dB', () => onUpdate(gain: (band.gain - .5).clamp(-12, 12).toDouble()), () => onUpdate(gain: (band.gain + .5).clamp(-12, 12).toDouble()))),
        Expanded(flex: 2, child: step(band.q.toStringAsFixed(2), () => onUpdate(q: (band.q - .1).clamp(.3, 10).toDouble()), () => onUpdate(q: (band.q + .1).clamp(.3, 10).toDouble()))),
        SizedBox(width: 64, child: Switch(value: band.enabled, onChanged: (v) => onUpdate(enabled: v), activeThumbColor: AppColors.cyan)),
      ]);
    });
  }

  static String _freq(double f) => f >= 1000 ? '${(f / 1000).toStringAsFixed(f >= 10000 ? 1 : 2)} kHz' : '${f.round()} Hz';
}

class _EqChart extends StatefulWidget {
  final List<EqBand> bands;
  final void Function(int index, double frequency, double gain) onChanged;
  const _EqChart({required this.bands, required this.onChanged});
  @override
  State<_EqChart> createState() => _EqChartState();
}

class _EqChartState extends State<_EqChart> {
  int? active;
  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, c) {
      final size = Size(c.maxWidth, c.maxHeight);
      return GestureDetector(
        behavior: HitTestBehavior.opaque,
        onPanStart: (d) => active = _nearest(d.localPosition, size),
        onPanUpdate: (d) {
          if (active == null) return;
          final x = (d.localPosition.dx / size.width).clamp(0.0, 1.0).toDouble();
          final y = (d.localPosition.dy / size.height).clamp(0.0, 1.0).toDouble();
          widget.onChanged(active!, DspController.frequencyFromNormalized(x), 12 - y * 24);
        },
        onPanEnd: (_) => active = null,
        child: CustomPaint(painter: _EqPainter(widget.bands), size: Size.infinite),
      );
    });
  }
  int _nearest(Offset p, Size size) {
    var best = 0; var dist = double.infinity;
    for (var i = 0; i < widget.bands.length; i++) {
      final b = widget.bands[i];
      final x = DspController.normalizedLogFrequency(b.frequency) * size.width;
      final y = (12 - b.gain) / 24 * size.height;
      final d = (Offset(x, y) - p).distanceSquared;
      if (d < dist) { dist = d; best = i; }
    }
    return best;
  }
}

class _EqPainter extends CustomPainter {
  final List<EqBand> bands;
  _EqPainter(this.bands);
  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()..color = AppColors.border.withValues(alpha: .28)..strokeWidth = 1;
    for (var i = 0; i <= 12; i++) canvas.drawLine(Offset(size.width * i / 12, 0), Offset(size.width * i / 12, size.height), grid);
    for (var i = 0; i <= 6; i++) canvas.drawLine(Offset(0, size.height * i / 6), Offset(size.width, size.height * i / 6), grid);
    final ordered = bands.where((b) => b.enabled).toList()..sort((a,b) => a.frequency.compareTo(b.frequency));
    if (ordered.isEmpty) return;
    final points = ordered.map((b) => Offset(DspController.normalizedLogFrequency(b.frequency) * size.width, (12 - b.gain) / 24 * size.height)).toList();
    final path = Path()..moveTo(points.first.dx, points.first.dy);
    for (var i = 1; i < points.length; i++) {
      final p0 = points[i - 1]; final p1 = points[i]; final mid = Offset((p0.dx + p1.dx) / 2, (p0.dy + p1.dy) / 2);
      path.quadraticBezierTo(p0.dx, p0.dy, mid.dx, mid.dy);
    }
    path.lineTo(points.last.dx, points.last.dy);
    final glow = Paint()..style = PaintingStyle.stroke..strokeWidth = 7..color = AppColors.cyan.withValues(alpha: .20)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8);
    canvas.drawPath(path, glow);
    canvas.drawPath(path, Paint()..style = PaintingStyle.stroke..strokeWidth = 3..color = AppColors.cyan);
    for (final b in bands) {
      if (!b.enabled) continue;
      final i = b.index.clamp(0, AppColors.eqColors.length - 1).toInt(); final color = AppColors.eqColors[i];
      final p = Offset(DspController.normalizedLogFrequency(b.frequency) * size.width, (12 - b.gain) / 24 * size.height);
      canvas.drawCircle(p, 13, Paint()..color = color.withValues(alpha: .22)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8));
      canvas.drawCircle(p, 8, Paint()..color = color);
      canvas.drawCircle(p, 8, Paint()..style = PaintingStyle.stroke..strokeWidth = 2..color = Colors.white);
    }
  }
  @override bool shouldRepaint(covariant _EqPainter oldDelegate) => true;
}
