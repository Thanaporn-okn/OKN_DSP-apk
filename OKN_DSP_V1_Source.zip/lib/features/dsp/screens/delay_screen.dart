import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_colors.dart';
import '../state/dsp_controller.dart';
import '../widgets/channel_selector.dart';
import '../widgets/glass_card.dart';
import '../widgets/neon_slider.dart';
import '../widgets/section_title.dart';

class DelayScreen extends ConsumerWidget {
  const DelayScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(dspProvider); final c = ref.read(dspProvider.notifier);
    final maxDelay = s.delaysMs.reduce((a,b)=>a>b?a:b);
    return SingleChildScrollView(padding: const EdgeInsets.symmetric(horizontal: 16), child: Column(children: [
      const ChannelSelector(), const SizedBox(height: 14),
      GlassCard(child: Column(children: [
        SectionTitle(icon: Icons.schedule, color: AppColors.green, title: 'Delay', subtitle: 'ตั้งค่าหน่วงเวลาเพื่อการจัดตำแหน่งเสียง', actions: [
          SegmentedButton<bool>(segments: const [ButtonSegment(value: true, label: Text('ms')), ButtonSegment(value: false, label: Text('cm'))], selected: {s.delayInMs}, onSelectionChanged: (v)=>c.setDelayUnit(v.first)),
          OutlinedButton.icon(onPressed: c.syncDelays, icon: const Icon(Icons.sync), label: const Text('ซิงค์ทุกช่อง')),
        ]),
        const SizedBox(height: 12),
        LayoutBuilder(builder:(context,box){final wide=box.maxWidth>720; final car= SizedBox(height: 360, child: CustomPaint(painter: _CarPainter(s.delaysMs), size: Size.infinite)); final info=Column(children:[
          _InfoCard(icon: Icons.event_seat, title:'Seat Preset', child: DropdownButtonFormField<String>(value:s.seatPreset, decoration:const InputDecoration(isDense:true,border:OutlineInputBorder()), dropdownColor:AppColors.panelStrong, items:const ['Driver (Left)','Passenger (Right)','Center'].map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(), onChanged:(v){if(v!=null)c.setSeatPreset(v);})),
          const SizedBox(height:10), const _InfoCard(icon:Icons.straighten,title:'Distance Reference',child:Text('Speed of Sound (20°C)\n343 m/s (34.3 cm/ms)',style:TextStyle(color:AppColors.muted))),
          const SizedBox(height:10), _InfoCard(icon:Icons.bar_chart,title:'Total Delay Range',child:Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[const Text('0.00 ms\nน้อยที่สุด'),Text('${maxDelay.toStringAsFixed(2)} ms\nมากที่สุด',textAlign:TextAlign.end)])),
        ]);
        return wide?Row(crossAxisAlignment:CrossAxisAlignment.start,children:[Expanded(flex:3,child:car),const SizedBox(width:14),Expanded(flex:2,child:info)]):Column(children:[car,const SizedBox(height:12),info]);}),
      ])),
      const SizedBox(height:12),
      for(var i=0;i<7;i++) Padding(padding:const EdgeInsets.only(bottom:10),child:_DelayRow(index:i,value:s.delaysMs[i],inMs:s.delayInMs,onChanged:(v)=>c.setDelay(i,v))),
      const SizedBox(height:4),
    ]));
  }
}

class _InfoCard extends StatelessWidget {final IconData icon;final String title;final Widget child;const _InfoCard({required this.icon,required this.title,required this.child});@override Widget build(BuildContext context)=>Container(width:double.infinity,padding:const EdgeInsets.all(12),decoration:BoxDecoration(border:Border.all(color:AppColors.border),borderRadius:BorderRadius.circular(12),color:AppColors.background.withValues(alpha:.32)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[Icon(icon,color:AppColors.cyan),const SizedBox(width:8),Text(title,style:const TextStyle(fontWeight:FontWeight.w800))]),const SizedBox(height:8),child]));}

class _DelayRow extends StatelessWidget {final int index;final double value;final bool inMs;final ValueChanged<double> onChanged;const _DelayRow({required this.index,required this.value,required this.inMs,required this.onChanged});@override Widget build(BuildContext context){final color=AppColors.channelColors[index];final cm=DspController.msToCm(value);return GlassCard(glowColor:color,padding:const EdgeInsets.symmetric(horizontal:14,vertical:10),child:LayoutBuilder(builder:(context,c){return Row(children:[Container(width:28,height:28,decoration:BoxDecoration(color:color,shape:BoxShape.circle,boxShadow:[BoxShadow(color:color.withValues(alpha:.45),blurRadius:12)])),const SizedBox(width:12),SizedBox(width:c.maxWidth<600?72:100,child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('CH${index+1}',style:const TextStyle(fontWeight:FontWeight.w800)),Text(channelNames[index],style:const TextStyle(color:AppColors.muted,fontSize:12))])),Expanded(child:NeonSlider(value:value,min:0,max:10,color:color,onChanged:onChanged)),const SizedBox(width:8),SizedBox(width:95,child:Text(inMs?'${value.toStringAsFixed(2)} ms\n${cm.toStringAsFixed(1)} cm':'${cm.toStringAsFixed(1)} cm\n${value.toStringAsFixed(2)} ms',textAlign:TextAlign.end,style:const TextStyle(fontWeight:FontWeight.w700)))]);}));}}

class _CarPainter extends CustomPainter {final List<double> delays;_CarPainter(this.delays);@override void paint(Canvas canvas,Size size){final w=size.width,h=size.height;final center=Offset(w/2,h/2);final car=RRect.fromRectAndRadius(Rect.fromCenter(center:center,width:w*.46,height:h*.86),Radius.circular(w*.15));final glow=Paint()..style=PaintingStyle.stroke..strokeWidth=7..color=AppColors.blue.withValues(alpha:.2)..maskFilter=const MaskFilter.blur(BlurStyle.normal,10);canvas.drawRRect(car,glow);canvas.drawRRect(car,Paint()..style=PaintingStyle.stroke..strokeWidth=2.2..color=AppColors.blue.withValues(alpha:.8));
    final seats=[Offset(w*.43,h*.38),Offset(w*.57,h*.38),Offset(w*.43,h*.62),Offset(w*.57,h*.62)];for(final p in seats){canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center:p,width:w*.10,height:h*.17),const Radius.circular(18)),Paint()..color=AppColors.blue.withValues(alpha:.18));canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center:p,width:w*.10,height:h*.17),const Radius.circular(18)),Paint()..style=PaintingStyle.stroke..color=AppColors.blue.withValues(alpha:.55));}
    final pts=[Offset(w*.25,h*.33),Offset(w*.75,h*.33),Offset(w*.24,h*.67),Offset(w*.76,h*.67),Offset(w*.5,h*.18),Offset(w*.5,h*.82),Offset(w*.5,h*.68)];for(var i=0;i<7;i++){final p=pts[i];final color=AppColors.channelColors[i];canvas.drawCircle(p,20,Paint()..color=color.withValues(alpha:.18)..maskFilter=const MaskFilter.blur(BlurStyle.normal,9));canvas.drawCircle(p,10,Paint()..color=color);canvas.drawCircle(p,10,Paint()..style=PaintingStyle.stroke..strokeWidth=3..color=Colors.white.withValues(alpha:.8));final tp=TextPainter(text:TextSpan(text:'${delays[i].toStringAsFixed(2)} ms',style:const TextStyle(color:AppColors.text,fontSize:12,fontWeight:FontWeight.w700)),textDirection:TextDirection.ltr)..layout();var pos=Offset(p.dx-tp.width/2,p.dy-34);if(i<4)pos=Offset(i.isEven?p.dx-tp.width-18:p.dx+18,p.dy-tp.height/2);tp.paint(canvas,pos);}}
  @override bool shouldRepaint(covariant _CarPainter oldDelegate)=>true;}
