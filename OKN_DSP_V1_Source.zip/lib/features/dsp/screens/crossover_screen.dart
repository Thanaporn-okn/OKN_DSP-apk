import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_colors.dart';
import '../models/dsp_state.dart';
import '../state/dsp_controller.dart';
import '../widgets/channel_selector.dart';
import '../widgets/glass_card.dart';
import '../widgets/section_title.dart';

class CrossoverScreen extends ConsumerWidget {
  const CrossoverScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(dspProvider); final c = ref.read(dspProvider.notifier);
    return SingleChildScrollView(padding: const EdgeInsets.symmetric(horizontal: 16), child: Column(children: [
      const ChannelSelector(), const SizedBox(height: 14),
      GlassCard(child: Column(children: [
        SectionTitle(icon: Icons.call_split_rounded, color: AppColors.pink, title: 'Crossover', subtitle: 'ตั้งค่าการแบ่งความถี่', actions: [OutlinedButton.icon(onPressed: c.resetCrossover, icon: const Icon(Icons.refresh), label: const Text('Reset'))]),
        const SizedBox(height: 16),
        SizedBox(height: 260, child: CustomPaint(painter: _CrossPainter(s.hpf, s.lpf), size: Size.infinite)),
        const SizedBox(height: 8),
        const Row(mainAxisAlignment: MainAxisAlignment.end, children: [Icon(Icons.circle, color: AppColors.cyan, size: 12), SizedBox(width: 5), Text('High Pass (HPF)', style: TextStyle(color: AppColors.muted)), SizedBox(width: 16), Icon(Icons.circle, color: AppColors.pink, size: 12), SizedBox(width: 5), Text('Low Pass (LPF)', style: TextStyle(color: AppColors.muted))]),
      ])),
      const SizedBox(height: 12),
      _FilterCard(title: 'High Pass Filter (HPF)', subtitle: 'กรองความถี่ต่ำออก', color: AppColors.cyan, icon: Icons.show_chart, state: s.hpf, onBypass: (v) => c.setHpf(bypass: v), onType: (v) => c.setHpf(type: v), onFrequency: (v) => c.setHpf(frequency: v), onSlope: (v) => c.setHpf(slope: v)),
      const SizedBox(height: 12),
      _FilterCard(title: 'Low Pass Filter (LPF)', subtitle: 'กรองความถี่สูงออก', color: AppColors.pink, icon: Icons.trending_down, state: s.lpf, onBypass: (v) => c.setLpf(bypass: v), onType: (v) => c.setLpf(type: v), onFrequency: (v) => c.setLpf(frequency: v), onSlope: (v) => c.setLpf(slope: v)),
      const SizedBox(height: 12),
      GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Row(children: [Icon(Icons.settings_suggest, color: AppColors.cyan), SizedBox(width: 8), Text('Advanced Settings', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800))]),
        const SizedBox(height: 12),
        Wrap(spacing: 10, runSpacing: 10, children: [
          _SmallControl(label: 'Phase', child: DropdownButton<int>(value: s.phaseDegrees, dropdownColor: AppColors.panelStrong, underline: const SizedBox(), items: const [0,90,180,270].map((v) => DropdownMenuItem(value: v, child: Text('$v°'))).toList(), onChanged: (v) { if (v != null) c.setPhase(v); })),
          _SmallControl(label: 'Polarity', child: DropdownButton<bool>(value: s.polarityNormal, dropdownColor: AppColors.panelStrong, underline: const SizedBox(), items: const [DropdownMenuItem(value: true, child: Text('Normal')), DropdownMenuItem(value: false, child: Text('Invert'))], onChanged: (v) { if (v != null) c.setPolarity(v); })),
          _SmallControl(label: 'Link L/R', child: Switch(value: s.linkLR, onChanged: c.setLinkLR, activeThumbColor: AppColors.cyan)),
          _SmallControl(label: 'Output Mode', child: DropdownButton<String>(value: s.outputMode, dropdownColor: AppColors.panelStrong, underline: const SizedBox(), items: const ['Stereo','Mono'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) { if (v != null) c.setOutputMode(v); })),
        ]),
      ])),
      const SizedBox(height: 12),
    ]));
  }
}

class _FilterCard extends StatelessWidget {
  final String title, subtitle; final Color color; final IconData icon; final FilterState state; final ValueChanged<bool> onBypass; final ValueChanged<String> onType; final ValueChanged<double> onFrequency; final ValueChanged<int> onSlope;
  const _FilterCard({required this.title, required this.subtitle, required this.color, required this.icon, required this.state, required this.onBypass, required this.onType, required this.onFrequency, required this.onSlope});
  @override
  Widget build(BuildContext context) => GlassCard(glowColor: color, child: Column(children: [
    Row(children: [Container(width: 60, height: 60, decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: color, width: 3), boxShadow: [BoxShadow(color: color.withValues(alpha: .38), blurRadius: 18)]), child: Icon(icon, color: color, size: 34)), const SizedBox(width: 14), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)), Text(subtitle, style: const TextStyle(color: AppColors.muted))])), const Text('Bypass'), const SizedBox(width: 6), Switch(value: state.bypass, onChanged: onBypass, activeThumbColor: color)]),
    const SizedBox(height: 12),
    Wrap(spacing: 10, runSpacing: 10, children: [
      _Drop<String>(label: 'Type', value: state.type, values: const ['Linkwitz-Riley','Butterworth','Bessel'], fmt: (v) => v, onChanged: onType),
      _Drop<double>(label: 'Frequency', value: state.frequency, values: const [50,63,80,100,125,160,200,250,500,800,1000,1250,2000,5000,10000], fmt: (v) => v >= 1000 ? '${(v/1000).toStringAsFixed(1)} kHz' : '${v.round()} Hz', onChanged: onFrequency),
      _Drop<int>(label: 'Slope', value: state.slope, values: const [6,12,18,24,36,48], fmt: (v) => '$v dB/Oct', onChanged: onSlope),
    ]),
  ]));
}

class _Drop<T> extends StatelessWidget {
  final String label; final T value; final List<T> values; final String Function(T) fmt; final ValueChanged<T> onChanged;
  const _Drop({required this.label, required this.value, required this.values, required this.fmt, required this.onChanged});
  @override
  Widget build(BuildContext context) => SizedBox(width: 230, child: DropdownButtonFormField<T>(value: value, decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()), dropdownColor: AppColors.panelStrong, items: values.map((v) => DropdownMenuItem(value: v, child: Text(fmt(v)))).toList(), onChanged: (v) { if (v != null) onChanged(v); }));
}

class _SmallControl extends StatelessWidget {
  final String label; final Widget child; const _SmallControl({required this.label, required this.child});
  @override
  Widget build(BuildContext context) => Container(width: 190, padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8), decoration: BoxDecoration(border: Border.all(color: AppColors.border), borderRadius: BorderRadius.circular(12), color: AppColors.background.withValues(alpha: .3)), child: Row(children: [Expanded(child: Text(label, style: const TextStyle(color: AppColors.muted))), child]));
}

class _CrossPainter extends CustomPainter {
  final FilterState hpf, lpf; _CrossPainter(this.hpf, this.lpf);
  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()..color = AppColors.border.withValues(alpha: .25)..strokeWidth = 1;
    for (var i=0;i<=12;i++) canvas.drawLine(Offset(size.width*i/12,0), Offset(size.width*i/12,size.height), grid);
    for (var i=0;i<=6;i++) canvas.drawLine(Offset(0,size.height*i/6), Offset(size.width,size.height*i/6), grid);
    Path build(bool high) {
      final p = Path();
      for (var i=0;i<=180;i++) {
        final x=i/180; final f=20*math.pow(1000,x); final cutoff=high?hpf.frequency:lpf.frequency; final slope=(high?hpf.slope:lpf.slope).toDouble();
        final ratio=high ? (f/cutoff) : (cutoff/f); final db = ratio >= 1 ? 0.0 : (slope * (math.log(ratio)/math.ln2)).clamp(-30.0,0.0).toDouble();
        final y=((0-db)/30*size.height*.88 + size.height*.08).toDouble();
        if(i==0) p.moveTo(x*size.width,y); else p.lineTo(x*size.width,y);
      }
      return p;
    }
    void draw(Path p, Color color){canvas.drawPath(p,Paint()..style=PaintingStyle.stroke..strokeWidth=8..color=color.withValues(alpha:.18)..maskFilter=const MaskFilter.blur(BlurStyle.normal,8)); canvas.drawPath(p,Paint()..style=PaintingStyle.stroke..strokeWidth=3..color=color);}
    if(!hpf.bypass) draw(build(true),AppColors.cyan); if(!lpf.bypass) draw(build(false),AppColors.pink);
  }
  @override bool shouldRepaint(covariant _CrossPainter oldDelegate)=>true;
}
