import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_colors.dart';
import '../models/dsp_state.dart';
import '../state/dsp_controller.dart';
import '../widgets/channel_selector.dart';
import '../widgets/glass_card.dart';
import '../widgets/neon_slider.dart';
import '../widgets/section_title.dart';

class OutputScreen extends ConsumerWidget {
  const OutputScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s=ref.watch(dspProvider);final c=ref.read(dspProvider.notifier);
    return SingleChildScrollView(padding:const EdgeInsets.symmetric(horizontal:16),child:Column(children:[
      const ChannelSelector(),const SizedBox(height:14),
      GlassCard(child:Column(children:[
        SectionTitle(icon:Icons.volume_up_rounded,color:AppColors.orange,title:'Output',subtitle:'ปรับระดับเอาต์พุตแต่ละช่อง',actions:[OutlinedButton.icon(onPressed:c.allMuteOff,icon:const Icon(Icons.volume_off),label:const Text('All Mute Off')),OutlinedButton.icon(onPressed:c.resetOutputLevels,icon:const Icon(Icons.refresh),label:const Text('Reset Levels'))]),
        const SizedBox(height:14),
        LayoutBuilder(builder:(context,box){final meter=Container(padding:const EdgeInsets.all(12),decoration:BoxDecoration(border:Border.all(color:AppColors.border),borderRadius:BorderRadius.circular(14)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Output Level Overview',style:TextStyle(fontWeight:FontWeight.w700)),const SizedBox(height:8),SizedBox(height:150,child:_VuMeters(outputs:s.outputs))]));final master=Container(padding:const EdgeInsets.all(12),decoration:BoxDecoration(border:Border.all(color:AppColors.border),borderRadius:BorderRadius.circular(14)),child:Column(children:[Row(children:[const Expanded(child:Text('Master Output',style:TextStyle(fontWeight:FontWeight.w700))),Text('${s.masterOutput.toStringAsFixed(1)} dB',style:const TextStyle(fontWeight:FontWeight.w800))]),NeonSlider(value:s.masterOutput,min:-60,max:12,color:AppColors.cyan,onChanged:c.setMasterOutput)]));return box.maxWidth>700?Row(crossAxisAlignment:CrossAxisAlignment.start,children:[Expanded(flex:3,child:meter),const SizedBox(width:12),Expanded(flex:2,child:master)]):Column(children:[meter,const SizedBox(height:10),master]);}),
      ])),const SizedBox(height:12),
      for(var i=0;i<7;i++) Padding(padding:const EdgeInsets.only(bottom:10),child:_OutputRow(index:i,output:s.outputs[i],onGain:(v)=>c.setOutputGain(i,v),onToggle:(field)=>c.toggleOutput(i,field))),
      const SizedBox(height:4),
    ]));
  }
}

class _OutputRow extends StatelessWidget {final int index;final OutputChannel output;final ValueChanged<double> onGain;final ValueChanged<String> onToggle;const _OutputRow({required this.index,required this.output,required this.onGain,required this.onToggle});@override Widget build(BuildContext context){final color=AppColors.channelColors[index];Widget button(IconData icon,String label,String field,bool active)=>InkWell(onTap:()=>onToggle(field),borderRadius:BorderRadius.circular(10),child:Container(width:58,height:58,decoration:BoxDecoration(borderRadius:BorderRadius.circular(10),border:Border.all(color:active?AppColors.cyan:AppColors.border),color:active?AppColors.blue.withValues(alpha:.20):AppColors.background.withValues(alpha:.2),boxShadow:active?[BoxShadow(color:AppColors.cyan.withValues(alpha:.25),blurRadius:12)]:null),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Icon(icon,size:22,color:active?AppColors.cyan:AppColors.muted),Text(label,style:TextStyle(fontSize:10,color:active?AppColors.cyan:AppColors.muted))])));return GlassCard(glowColor:color,padding:const EdgeInsets.symmetric(horizontal:12,vertical:10),child:LayoutBuilder(builder:(context,c){final lead=Row(children:[Container(width:46,height:46,alignment:Alignment.center,decoration:BoxDecoration(shape:BoxShape.circle,border:Border.all(color:color,width:3),boxShadow:[BoxShadow(color:color.withValues(alpha:.35),blurRadius:14)]),child:Text('${index+1}',style:const TextStyle(fontSize:20,fontWeight:FontWeight.w800))),const SizedBox(width:10),SizedBox(width:78,child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('CH${index+1}',style:const TextStyle(fontWeight:FontWeight.w800)),Text(channelNames[index],style:const TextStyle(color:AppColors.muted,fontSize:12))]))]);final controls=Wrap(spacing:6,runSpacing:6,children:[button(Icons.volume_off,'Mute','mute',output.mute),button(Icons.headphones,'Solo','solo',output.solo),button(Icons.do_not_disturb_on_outlined,'Phase','phase',output.phase),if(index<2)button(Icons.link,'Link','link',output.link)]);if(c.maxWidth<720){return Column(children:[Row(children:[lead,Expanded(child:NeonSlider(value:output.gain,min:-60,max:12,color:color,onChanged:onGain)),SizedBox(width:76,child:Text('${output.gain.toStringAsFixed(1)} dB',textAlign:TextAlign.end,style:const TextStyle(fontWeight:FontWeight.w800)))]),const SizedBox(height:8),Align(alignment:Alignment.centerRight,child:controls)]);}return Row(children:[lead,Expanded(child:NeonSlider(value:output.gain,min:-60,max:12,color:color,onChanged:onGain)),SizedBox(width:82,child:Text('${output.gain.toStringAsFixed(1)} dB',textAlign:TextAlign.center,style:const TextStyle(fontWeight:FontWeight.w800))),const SizedBox(width:8),controls]);}));}}

class _VuMeters extends StatelessWidget {
  final List<OutputChannel> outputs;
  const _VuMeters({required this.outputs});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: List.generate(7, (i) {
        final color = AppColors.channelColors[i];
        final normalized = ((outputs[i].gain + 60) / 72).clamp(.05, 1.0).toDouble();
        return Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Expanded(
                  child: LayoutBuilder(
                    builder: (context, b) => Align(
                      alignment: Alignment.bottomCenter,
                      child: Container(
                        width: 20,
                        height: b.maxHeight * normalized,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          gradient: LinearGradient(
                            begin: Alignment.bottomCenter,
                            end: Alignment.topCenter,
                            colors: [color, color.withValues(alpha: .38)],
                          ),
                          boxShadow: [BoxShadow(color: color.withValues(alpha: .28), blurRadius: 8)],
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 5),
                Text('CH${i + 1}', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700)),
              ],
            ),
          ),
        );
      }),
    );
  }
}
