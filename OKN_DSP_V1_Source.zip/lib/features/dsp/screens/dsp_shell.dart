import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_colors.dart';
import '../state/dsp_controller.dart';
import '../widgets/app_header.dart';
import 'crossover_screen.dart';
import 'delay_screen.dart';
import 'eq_screen.dart';
import 'home_screen.dart';
import 'output_screen.dart';

class DspShell extends ConsumerWidget {
  const DspShell({super.key});

  static const pages = [HomeScreen(), EqScreen(), CrossoverScreen(), DelayScreen(), OutputScreen()];
  static const icons = [Icons.home_rounded, Icons.multiline_chart, Icons.call_split_rounded, Icons.schedule_rounded, Icons.bar_chart_rounded];
  static const labels = ['Home', 'EQ', 'Crossover', 'Delay', 'Output'];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final page = ref.watch(dspProvider.select((s) => s.page));
    final top = MediaQuery.paddingOf(context).top;
    final bottom = MediaQuery.paddingOf(context).bottom;
    return Scaffold(
      body: DecoratedBox(
        decoration: const BoxDecoration(
          gradient: RadialGradient(center: Alignment(-.7, -.9), radius: 1.3, colors: [Color(0xFF0A2740), AppColors.background], stops: [0, .58]),
        ),
        child: Padding(
          padding: EdgeInsets.only(top: top + 8, bottom: bottom + 8),
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 1080),
              child: Column(children: [
                const Padding(padding: EdgeInsets.symmetric(horizontal: 16), child: AppHeader()),
                const SizedBox(height: 12),
                Expanded(child: IndexedStack(index: page, children: pages)),
                const SizedBox(height: 8),
                Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: _BottomNav(selected: page)),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}

class _BottomNav extends ConsumerWidget {
  final int selected;
  const _BottomNav({required this.selected});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Container(
      height: 76,
      decoration: BoxDecoration(color: AppColors.panelStrong.withValues(alpha: .86), borderRadius: BorderRadius.circular(18), border: Border.all(color: AppColors.border), boxShadow: [BoxShadow(color: AppColors.blue.withValues(alpha: .12), blurRadius: 18)]),
      child: Row(children: List.generate(5, (i) {
        final active = selected == i;
        return Expanded(child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () => ref.read(dspProvider.notifier).selectPage(i),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            margin: const EdgeInsets.all(5),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              gradient: active ? const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF075BAE), Color(0xFF005CFF)]) : null,
              boxShadow: active ? [BoxShadow(color: AppColors.blue.withValues(alpha: .45), blurRadius: 18)] : null,
            ),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(DspShell.icons[i], color: active ? AppColors.cyan : AppColors.muted, size: 28),
              const SizedBox(height: 4),
              Text(DspShell.labels[i], style: TextStyle(color: active ? Colors.white : AppColors.muted, fontWeight: active ? FontWeight.w700 : FontWeight.w500, fontSize: 12)),
            ]),
          ),
        ));
      })),
    );
  }
}
