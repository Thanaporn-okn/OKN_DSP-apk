import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_colors.dart';
import '../state/dsp_controller.dart';
import '../widgets/glass_card.dart';
import '../widgets/neon_slider.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(dspProvider);
    final c = ref.read(dspProvider.notifier);
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(children: [
        _AudioSlider(icon: Icons.volume_up_rounded, color: AppColors.blue, title: 'Master Volume', subtitle: 'ปรับระดับเสียงรวม', value: s.masterVolume, min: -60, max: 12, unit: 'dB', onChanged: c.setMasterVolume),
        _AudioSlider(icon: Icons.album_outlined, color: AppColors.cyan, title: 'Bass Volume', subtitle: 'ปรับระดับเสียงเบส', value: s.bassVolume, min: -12, max: 12, unit: 'dB', onChanged: c.setBassVolume),
        _AudioSlider(icon: Icons.call_split_rounded, color: AppColors.purple, title: 'Bass Cutoff', subtitle: 'ตั้งค่าความถี่ตัดเบส', value: s.bassCutoff, min: 20, max: 500, unit: 'Hz', onChanged: c.setBassCutoff, decimals: 0),
        _AudioSlider(icon: Icons.equalizer_rounded, color: AppColors.pink, title: 'Bass Boost', subtitle: 'เพิ่มความหนักแน่นของเบส', value: s.bassBoost, min: -10, max: 12, unit: 'dB', onChanged: c.setBassBoost),
        _AudioSlider(icon: Icons.multiline_chart, color: AppColors.blue, title: 'Middle Boost', subtitle: 'เพิ่มความชัดเจนย่านกลาง', value: s.middleBoost, min: -12, max: 12, unit: 'dB', onChanged: c.setMiddleBoost),
        _AudioSlider(icon: Icons.auto_awesome, color: AppColors.purple, title: 'Treble Boost', subtitle: 'เพิ่มความใสย่านแหลม', value: s.trebleBoost, min: -12, max: 12, unit: 'dB', onChanged: c.setTrebleBoost),
        const SizedBox(height: 4),
        LayoutBuilder(builder: (context, box) {
          final wide = box.maxWidth >= 700;
          final left = Column(children: [
            _SelectCard(icon: Icons.music_note, title: 'Audio Source', subtitle: 'แหล่งสัญญาณเสียง', value: s.audioSource, values: const ['High Level (Speaker)', 'Low Level (RCA)', 'Bluetooth'], onChanged: c.setAudioSource),
            const SizedBox(height: 12),
            _SelectCard(icon: Icons.menu, title: 'System Preset', subtitle: 'พรีเซ็ตระบบ', value: s.systemPreset, values: const ['Flat', 'Custom 1', 'Custom 2'], onChanged: c.setSystemPreset),
          ]);
          final status = const _StatusCard();
          return wide ? Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(child: left), const SizedBox(width: 12), const Expanded(child: _StatusCard())]) : Column(children: [left, const SizedBox(height: 12), status]);
        }),
        const SizedBox(height: 12),
      ]),
    );
  }
}

class _AudioSlider extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String title;
  final String subtitle;
  final double value;
  final double min;
  final double max;
  final String unit;
  final ValueChanged<double> onChanged;
  final int decimals;
  const _AudioSlider({required this.icon, required this.color, required this.title, required this.subtitle, required this.value, required this.min, required this.max, required this.unit, required this.onChanged, this.decimals = 1});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: GlassCard(
        glowColor: color,
        child: LayoutBuilder(builder: (context, c) {
          final compact = c.maxWidth < 560;
          final lead = Row(mainAxisSize: MainAxisSize.min, children: [
            Container(width: 62, height: 62, decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: color, width: 3), boxShadow: [BoxShadow(color: color.withValues(alpha: .35), blurRadius: 18)]), child: Icon(icon, color: color, size: 34)),
            const SizedBox(width: 14),
            SizedBox(width: compact ? 150 : 190, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)), const SizedBox(height: 3), Text(subtitle, style: const TextStyle(color: AppColors.muted))])),
          ]);
          final slider = Expanded(child: NeonSlider(value: value, min: min, max: max, color: color, onChanged: onChanged));
          final valueBox = Container(width: 108, padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8), decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border), color: AppColors.background.withValues(alpha: .35)), child: Text('${value.toStringAsFixed(decimals)} $unit', textAlign: TextAlign.center, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)));
          if (!compact) return Row(children: [lead, const SizedBox(width: 12), slider, const SizedBox(width: 12), valueBox]);
          return Column(children: [Row(children: [Expanded(child: lead), valueBox]), const SizedBox(height: 8), Row(children: [slider])]);
        }),
      ),
    );
  }
}

class _SelectCard extends StatelessWidget {
  final IconData icon; final String title; final String subtitle; final String value; final List<String> values; final ValueChanged<String> onChanged;
  const _SelectCard({required this.icon, required this.title, required this.subtitle, required this.value, required this.values, required this.onChanged});
  @override
  Widget build(BuildContext context) => GlassCard(child: Row(children: [
    Container(width: 54, height: 54, decoration: BoxDecoration(color: AppColors.blue.withValues(alpha: .16), borderRadius: BorderRadius.circular(14), border: Border.all(color: AppColors.blue)), child: Icon(icon, color: AppColors.cyan, size: 30)),
    const SizedBox(width: 12),
    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)), Text(subtitle, style: const TextStyle(color: AppColors.muted)), const SizedBox(height: 8), DropdownButtonFormField<String>(value: value, decoration: const InputDecoration(isDense: true, border: OutlineInputBorder()), dropdownColor: AppColors.panelStrong, items: values.map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) { if (v != null) onChanged(v); })]))
  ]));
}

class _StatusCard extends ConsumerWidget {
  const _StatusCard();
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final connected = ref.watch(dspProvider.select((s) => s.connected));
    Widget row(IconData icon, String label, String value, Color color) => Padding(padding: const EdgeInsets.symmetric(vertical: 9), child: Row(children: [Icon(icon, color: color), const SizedBox(width: 10), Expanded(child: Text(label, style: const TextStyle(color: AppColors.muted))), Text(value, style: TextStyle(color: color, fontWeight: FontWeight.w600))]));
    return GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Row(children: [Icon(Icons.memory, color: AppColors.cyan, size: 30), SizedBox(width: 10), Text('Device Status', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800))]),
      const Divider(height: 24),
      row(Icons.circle, 'Connected', connected ? 'DSP-7900' : 'Offline', connected ? AppColors.green : AppColors.pink),
      row(Icons.battery_charging_full, 'Voltage', '13.6 V', AppColors.cyan),
      row(Icons.device_thermostat, 'Temperature', '42 °C', AppColors.cyan),
      row(Icons.check_circle_outline, 'System', 'Normal', AppColors.green),
    ]));
  }
}
