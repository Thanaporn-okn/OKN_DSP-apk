import 'package:flutter/material.dart';

@immutable
class EqBand {
  final int index;
  final String type;
  final double frequency;
  final double gain;
  final double q;
  final bool enabled;

  const EqBand({
    required this.index,
    required this.type,
    required this.frequency,
    required this.gain,
    required this.q,
    required this.enabled,
  });

  EqBand copyWith({String? type, double? frequency, double? gain, double? q, bool? enabled}) => EqBand(
        index: index,
        type: type ?? this.type,
        frequency: frequency ?? this.frequency,
        gain: gain ?? this.gain,
        q: q ?? this.q,
        enabled: enabled ?? this.enabled,
      );
}

@immutable
class FilterState {
  final String type;
  final double frequency;
  final int slope;
  final bool bypass;

  const FilterState({required this.type, required this.frequency, required this.slope, required this.bypass});

  FilterState copyWith({String? type, double? frequency, int? slope, bool? bypass}) => FilterState(
        type: type ?? this.type,
        frequency: frequency ?? this.frequency,
        slope: slope ?? this.slope,
        bypass: bypass ?? this.bypass,
      );
}

@immutable
class OutputChannel {
  final double gain;
  final bool mute;
  final bool solo;
  final bool phase;
  final bool link;

  const OutputChannel({required this.gain, this.mute = false, this.solo = false, this.phase = false, this.link = false});

  OutputChannel copyWith({double? gain, bool? mute, bool? solo, bool? phase, bool? link}) => OutputChannel(
        gain: gain ?? this.gain,
        mute: mute ?? this.mute,
        solo: solo ?? this.solo,
        phase: phase ?? this.phase,
        link: link ?? this.link,
      );
}

@immutable
class DspState {
  final int page;
  final int channel;
  final bool connected;
  final double masterVolume;
  final double bassVolume;
  final double bassCutoff;
  final double bassBoost;
  final double middleBoost;
  final double trebleBoost;
  final String audioSource;
  final String systemPreset;
  final List<List<EqBand>> eqByChannel;
  final int bandPage;
  final FilterState hpf;
  final FilterState lpf;
  final int phaseDegrees;
  final bool polarityNormal;
  final bool linkLR;
  final String outputMode;
  final bool delayInMs;
  final String seatPreset;
  final List<double> delaysMs;
  final double masterOutput;
  final List<OutputChannel> outputs;

  const DspState({
    required this.page,
    required this.channel,
    required this.connected,
    required this.masterVolume,
    required this.bassVolume,
    required this.bassCutoff,
    required this.bassBoost,
    required this.middleBoost,
    required this.trebleBoost,
    required this.audioSource,
    required this.systemPreset,
    required this.eqByChannel,
    required this.bandPage,
    required this.hpf,
    required this.lpf,
    required this.phaseDegrees,
    required this.polarityNormal,
    required this.linkLR,
    required this.outputMode,
    required this.delayInMs,
    required this.seatPreset,
    required this.delaysMs,
    required this.masterOutput,
    required this.outputs,
  });

  factory DspState.initial() {
    final seed = <EqBand>[
      const EqBand(index: 0, type: 'PEQ', frequency: 32, gain: -3, q: .70, enabled: true),
      const EqBand(index: 1, type: 'Low Shelf', frequency: 100, gain: 2.5, q: 1, enabled: true),
      const EqBand(index: 2, type: 'PEQ', frequency: 200, gain: 6, q: 1.2, enabled: true),
      const EqBand(index: 3, type: 'PEQ', frequency: 500, gain: -4, q: 1, enabled: true),
      const EqBand(index: 4, type: 'PEQ', frequency: 2000, gain: 3, q: 1, enabled: true),
      const EqBand(index: 5, type: 'High Shelf', frequency: 10000, gain: -2, q: .70, enabled: true),
      const EqBand(index: 6, type: 'PEQ', frequency: 12500, gain: 1.5, q: 1, enabled: true),
      const EqBand(index: 7, type: 'PEQ', frequency: 16000, gain: 0, q: 1, enabled: true),
      const EqBand(index: 8, type: 'PEQ', frequency: 63, gain: 0, q: 1, enabled: true),
      const EqBand(index: 9, type: 'PEQ', frequency: 125, gain: 0, q: 1, enabled: true),
      const EqBand(index: 10, type: 'PEQ', frequency: 250, gain: 0, q: 1, enabled: true),
      const EqBand(index: 11, type: 'PEQ', frequency: 1000, gain: 0, q: 1, enabled: true),
      const EqBand(index: 12, type: 'PEQ', frequency: 4000, gain: 0, q: 1, enabled: true),
      const EqBand(index: 13, type: 'PEQ', frequency: 8000, gain: 0, q: 1, enabled: true),
      const EqBand(index: 14, type: 'PEQ', frequency: 20000, gain: 0, q: 1, enabled: true),
    ];
    return DspState(
      page: 0,
      channel: 0,
      connected: true,
      masterVolume: -3,
      bassVolume: 4,
      bassCutoff: 100,
      bassBoost: 3,
      middleBoost: -2,
      trebleBoost: 1,
      audioSource: 'High Level (Speaker)',
      systemPreset: 'Flat',
      eqByChannel: List.generate(7, (_) => List<EqBand>.from(seed)),
      bandPage: 0,
      hpf: const FilterState(type: 'Linkwitz-Riley', frequency: 100, slope: 24, bypass: false),
      lpf: const FilterState(type: 'Linkwitz-Riley', frequency: 1000, slope: 24, bypass: false),
      phaseDegrees: 0,
      polarityNormal: true,
      linkLR: true,
      outputMode: 'Stereo',
      delayInMs: true,
      seatPreset: 'Driver (Left)',
      delaysMs: const [0, 1.25, 2.60, 2.30, .80, 3.10, 1.90],
      masterOutput: -1,
      outputs: const [
        OutputChannel(gain: -3, link: true),
        OutputChannel(gain: -2.5, link: true),
        OutputChannel(gain: -4),
        OutputChannel(gain: -1),
        OutputChannel(gain: -2),
        OutputChannel(gain: -3.5),
        OutputChannel(gain: -4.5),
      ],
    );
  }

  DspState copyWith({
    int? page,
    int? channel,
    bool? connected,
    double? masterVolume,
    double? bassVolume,
    double? bassCutoff,
    double? bassBoost,
    double? middleBoost,
    double? trebleBoost,
    String? audioSource,
    String? systemPreset,
    List<List<EqBand>>? eqByChannel,
    int? bandPage,
    FilterState? hpf,
    FilterState? lpf,
    int? phaseDegrees,
    bool? polarityNormal,
    bool? linkLR,
    String? outputMode,
    bool? delayInMs,
    String? seatPreset,
    List<double>? delaysMs,
    double? masterOutput,
    List<OutputChannel>? outputs,
  }) => DspState(
        page: page ?? this.page,
        channel: channel ?? this.channel,
        connected: connected ?? this.connected,
        masterVolume: masterVolume ?? this.masterVolume,
        bassVolume: bassVolume ?? this.bassVolume,
        bassCutoff: bassCutoff ?? this.bassCutoff,
        bassBoost: bassBoost ?? this.bassBoost,
        middleBoost: middleBoost ?? this.middleBoost,
        trebleBoost: trebleBoost ?? this.trebleBoost,
        audioSource: audioSource ?? this.audioSource,
        systemPreset: systemPreset ?? this.systemPreset,
        eqByChannel: eqByChannel ?? this.eqByChannel,
        bandPage: bandPage ?? this.bandPage,
        hpf: hpf ?? this.hpf,
        lpf: lpf ?? this.lpf,
        phaseDegrees: phaseDegrees ?? this.phaseDegrees,
        polarityNormal: polarityNormal ?? this.polarityNormal,
        linkLR: linkLR ?? this.linkLR,
        outputMode: outputMode ?? this.outputMode,
        delayInMs: delayInMs ?? this.delayInMs,
        seatPreset: seatPreset ?? this.seatPreset,
        delaysMs: delaysMs ?? this.delaysMs,
        masterOutput: masterOutput ?? this.masterOutput,
        outputs: outputs ?? this.outputs,
      );
}
