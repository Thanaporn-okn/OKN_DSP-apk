# OKN_DSP V1

Flutter UI implementation for an OKN_DSP / DSP Control 7-channel audio processor.

## Included
- Responsive cyberpunk dark UI for Home, EQ, Crossover, Delay and Output.
- Riverpod state management.
- Reusable glass cards, neon controls and gradient sliders.
- Interactive EQ graph with draggable band nodes.
- HPF/LPF crossover graph and controls.
- Time-alignment controls in ms/cm with a top-view car visualization.
- Output gain, VU meters, mute, solo, phase and link controls.
- Clean folder separation for screens, widgets, models, state and transport service.

## Hardware integration boundary
The UI/state layer is complete and interactive. Real DSP BLE writes are intentionally isolated behind `DspTransport` and are not fabricated in V1 because the exact DSP service/write characteristic and command packet format are not defined in the supplied specification. Replace `MockDspTransport` with the verified BLE implementation once the protocol is captured.

## Build
The companion GitHub Actions workflow can build directly from the source ZIP. It creates Android platform scaffolding using the current stable Flutter SDK, runs `flutter pub get`, `flutter analyze`, and builds a release APK.
