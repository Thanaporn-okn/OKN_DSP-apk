# OKN BP1048P4 Phase3 TRUE7CH — R27

R27 เป็นรอบ **offline flashboot HID reverse** ต่อจาก R26 ไม่มี hardware command ใหม่.

อ่านหลักก่อน:
- `docs/R27_FLASHBOOT_HID_OFFLINE_REVERSE_TH.md`
- `docs/R27_R26_TRANSPORT_CORRECTION_TH.md`
- `docs/R27_HID_TRANSPORT_EVIDENCE.txt`
- `config/R27_FLASHBOOT_HID_STATE.json`
- `config/R27_FLASHBOOT_HID_RISK.json`

ผลสำคัญ:
- แก้ข้อสรุป R26: updater ASCII command ไม่ได้พิสูจน์ว่าเดินผ่าน MSC BOT/CDB; R27 พิสูจน์ transport เป็น USB HID class control Data reports 256 bytes.
- `upinfo` ไม่ใช่ read/version query แต่เป็น completion/finalization command ที่มี MMIO side effects.
- `cxxx` เป็น metadata/state/ACK command และมี MMIO side effects; ไม่ใช่ strict read-only.
- 6 command อื่นเข้า erase/program/update path โดยตรง.
- ดังนั้นไม่มี safe live identity/version command ใน command set นี้ และ hardware flashboot probe ยังคง BLOCKED.

Android module ถูก relabel เป็น R27 เพื่อ continuity เท่านั้นและยังเป็น Bluetooth READ-ONLY probe เดิม **ไม่จำเป็นต้องติดตั้ง R27 APK**.

AUTO workflow ใน source ใช้ stable signing secret `OKN_ANDROID_DEBUG_KEYSTORE_B64`; ถ้าตั้ง secret ไว้แล้ว build รุ่นต่อ ๆ ไปจะใช้ signing key เดิม.
