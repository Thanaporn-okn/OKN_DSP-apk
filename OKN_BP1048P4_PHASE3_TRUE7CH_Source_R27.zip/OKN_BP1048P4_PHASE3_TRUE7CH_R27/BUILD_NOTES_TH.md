# BUILD NOTES — R27

R27 ไม่เพิ่ม hardware action. งานใหม่ทั้งหมดเป็น offline disassembly/verifier.

Host/offline verification ต้องผ่าน:
1. TRUE7CH host tests เดิม
2. R25 Bluetooth READ-ONLY guard เดิม
3. R26 reconstruction guard เดิม (เก็บเป็น historical checkpoint)
4. `r27_flashboot_hid_reverse.py` ต้องยืนยัน SHA 64 KiB เดิม, HID SET_REPORT/GET_REPORT constants, 256-byte report shape, และ side effects ของ `upinfo`/`cxxx`
5. R27 fail-closed guard ต้องยืนยัน `proven_live_read_command=null`, `hardware_action_allowed=false`, และ Android ไม่มี USB/RFCOMM/GATT-write implementation

R26 BOT updater inference ถูก supersede โดย R27; อย่าใช้ R26 BOT/CDB framing สร้าง live probe.

AUTO GitHub Actions workflow ตัวเดิมใช้ได้และมี stable signing. R27 ไม่จำเป็นต้อง build/install APK เพราะไม่มี live probe ใหม่.
