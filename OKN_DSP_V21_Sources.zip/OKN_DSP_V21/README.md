# OKN DSP V21 — Phase 1

V21 is built from V19 and keeps the accepted V14/V16 visual design. It targets the remaining non-smooth gesture behavior reported on the physical Samsung device.

## V21 smoothness fix

The previous custom view claimed slider touches immediately and manually followed each MotionEvent for vertical movement. Because Mix/EQ contain many sliders, a normal vertical swipe frequently landed on a slider and felt sticky or jerky. V21 waits for movement direction before assigning the gesture: vertical motion becomes scrolling, horizontal motion becomes slider control. Android `OverScroller` + `VelocityTracker` now provide kinetic/fling scrolling after finger release.

The EQ graph also caches its response curve and reuses it while the EQ state is unchanged, removing repeated heavy logarithm/exponential calculations during scrolling.

- versionName: 21.0.0
- versionCode: 1020
- Base UI: V14/V16 lineage
- Phase: 1 performance hardening


V21 focus: top-right Theme picker smoothness. The Theme picker is now drawn inside DspView on the same hardware-accelerated Canvas instead of opening a separate Dialog/Window. Theme/system-bar updates are split across vsync frames to avoid Samsung WindowManager/compositor hitching.
