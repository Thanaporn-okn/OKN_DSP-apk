OKN_DSP V20 — Q Factor responsive EQ graph

Runtime basis: V19. Hardware BLE/protocol/writer behavior is intentionally unchanged.

Fix:
- V19 Q Factor writes worked on the real DSP, but the upper graph was drawn only from Gain points.
- V20 renders the visible 15-band curve from the current Gain + Q for every band.
- Higher Q -> narrower visible bell/peak.
- Lower Q -> wider visible bell/peak.
- Centre frequency and gain control point remain fixed when Q changes; this is correct Q behavior.
- Graph refresh happens immediately while the Q slider moves.

Scope:
- CH1..CH7
- Bands 1..15
- ISO presentation centres remain 25,40,63,100,160,250,400,630,1k,1.6k,2.5k,4k,6.3k,10k,16k Hz.
- V19 native filter-aware writer and 380 ms latest-target scheduler remain unchanged.
