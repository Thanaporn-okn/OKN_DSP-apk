OKN_DSP V18 — 15-BAND GRAPHIC EQ STANDARD FREQUENCY ORDER

User-reported V17 UI issue:
- all DSP controls and all 15 EQ sliders were functional, including Band 1,
- but the frequency captions under the 15 Graphic-EQ faders were the live DSP record
  frequencies and therefore appeared out of order / non-standard across channels.

V18 correction:
- Graphic-EQ display/order is fixed for every CH1..CH7 to the standard 15 centre frequencies:
  25, 40, 63, 100, 160, 250, 400, 630, 1000, 1600, 2500, 4000, 6300, 10000, 16000 Hz.
- Graph node X positions use the same fixed sequence.
- Band detail caption uses the same fixed sequence.
- Band numbers 1..15 therefore map left-to-right to 25 Hz..16 kHz consistently on every channel.

Safety / regression boundary:
- V17's real DSP record mapping and filter-aware Band-1 write path are preserved.
- No actuator IDs, offsets, BLE/auth/AES framing, scheduler cadence, scalar behavior,
  filter type, live DSP Frequency, live Q, or write serializer was changed.
- Only UI Graphic-EQ presentation/order changed.
- No auto SaveParams.
