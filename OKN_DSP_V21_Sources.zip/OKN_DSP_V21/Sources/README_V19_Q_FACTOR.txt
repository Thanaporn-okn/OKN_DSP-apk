OKN_DSP V19 — 15-Band Q Factor control

User requirement:
- Q Factor must be adjustable on every EQ band for every CH1-CH7.
- Original app supports this behavior.

V19 behavior:
- Keeps V18 standard 15-band display order: 25,40,63,100,160,250,400,630,1k,1.6k,2.5k,4k,6.3k,10k,16k Hz.
- Select any band, then use the Q Factor slider at the bottom of the 15-band card.
- Q range uses the already-enforced safe writer bounds 0.05..20.00.
- Q is rounded to 0.01 and sent through the same latest-target 380 ms scheduler.
- PEAKING type12: rebuild coefficients using real DSP frequency + requested Gain + Q.
- Band1 Tone Control type17: preserve native type/F/F2/B/G/R and store requested Q; Tone Control coefficient math remains native and does not invent a PEAKING conversion.
- Band1 General Low-pass type3: rebuild low-pass coefficients using real DSP frequency + requested Gain + Q.
- Full 48-byte record write remains unchanged.
- No auto SaveParams.
- Signing/applicationId unchanged.
