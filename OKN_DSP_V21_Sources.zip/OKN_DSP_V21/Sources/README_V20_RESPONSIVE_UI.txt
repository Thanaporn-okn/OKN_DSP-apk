OKN_DSP V20 - Phase 1 responsive UI fix

Observed in the supplied runtime video: V19 used independent X/Y Canvas scaling, so a tall phone stretched circles, text, cards and controls vertically.

V20 changes:
- One uniform render scale for both X and Y.
- Responsive section spacing absorbs extra height on tall phones instead of stretching components.
- Bottom navigation remains at the bottom because the final section absorbs the accumulated responsive spacing.
- Touch coordinates use the same inverse responsive section mapping, so sliders/buttons remain aligned with what is drawn.
- Full physical display is filled with the native dark background; wider tablets receive centered content without distorting it.
- Typography uses sans-serif consistently.
- Home feature icons and route-card icons were redrawn to better match the supplied reference UI.
- The DSP unit is a decorative crop from the user-supplied reference artwork only; no full-screen reference screenshot is rendered behind controls.
- Phase 1 remains local UI only; no real DSP writer is enabled.
