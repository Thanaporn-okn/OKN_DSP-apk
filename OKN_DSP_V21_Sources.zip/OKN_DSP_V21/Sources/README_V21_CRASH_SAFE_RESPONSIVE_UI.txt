OKN_DSP V21 - PHASE 1 CRASH-SAFE RESPONSIVE UI

Goal
- Fix the V20 launch crash report while keeping the anti-stretch responsive layout.
- Preserve the supplied OKN_DSP visual direction as closely as possible in the native UI.

Rendering model
- Design coordinate system: 864 x 1536.
- One uniform scale factor is applied to X and Y.
- No independent vertical scale is applied, so circles stay circular and text/cards do
  not become tall or squashed.
- The main page is drawn once.
- On tall displays, extra height becomes background space and the bottom navigation is
  moved to the actual bottom of the screen.
- On tablets/wider displays, the UI remains centered horizontally with its aspect ratio
  preserved.

Stability changes
- Removed V20 repeated full-page section rendering.
- Removed forced software layer.
- Added safe bitmap decode, frame render guard, touch guard and Activity startup guard.

Interactive Phase 1 controls
- Home Master Volume and quick presets.
- Mix Master/Bass/Cutoff/Bass Boost/Middle Boost/Treble Boost.
- EQ: 7 channels, 15 bands, Frequency/Gain/Q, channel output and local presets.
- Crossover: HPF, LPF, slope, delay, phase/polarity and link filters.
- Values update immediately while touching/dragging; Phase 2 will bind these controls
  to the real DSP protocol.
