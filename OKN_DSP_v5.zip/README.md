# OKN_DSP v5

UI is locked to the supplied OKN_DSP reference screens.

v5 changes:
- Keeps Home and EQ visual structure from the supplied images.
- Completes Home preset save/load controls below the scroll fold.
- Completes EQ channel selector CH1-CH7 and Copy EQ / Paste EQ / Save Preset controls.
- Stores independent 7-band EQ values for all 7 channels.
- Adds real Android BLE scan/connect/discover state handling.
- Uses the proven characteristic UUID 0000ab01-0000-1000-8000-00805f9b34fb and discovers it dynamically across services.
- Does NOT invent DSP command bytes; UI values are not transmitted until the real write protocol is decoded.

Target: Android 8.0+ (minSdk 26), compile/target SDK 35.
