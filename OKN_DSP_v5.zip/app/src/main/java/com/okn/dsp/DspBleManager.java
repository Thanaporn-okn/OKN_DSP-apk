package com.okn.dsp;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.util.List;
import java.util.Locale;
import java.util.UUID;

/**
 * BLE transport foundation for OKN_DSP v5.
 *
 * Known fact from captured DSP traffic:
 * characteristic UUID = 0000ab01-0000-1000-8000-00805f9b34fb
 *
 * v5 deliberately does not invent DSP command bytes. It scans, connects,
 * discovers the real GATT profile and locates AB01 dynamically across services.
 */
public final class DspBleManager {
    public enum State { DISCONNECTED, SCANNING, CONNECTING, DISCOVERING, READY, ERROR }

    public interface Listener {
        void onBleStateChanged(State state, String deviceName, String detail);
        void onCharacteristicData(UUID characteristic, byte[] data);
    }

    public static final UUID AB01_UUID = UUID.fromString("0000ab01-0000-1000-8000-00805f9b34fb");
    private static final UUID CCCD_UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    private static final String TAG = "OKN_DSP_BLE";
    private static final long SCAN_TIMEOUT_MS = 12000L;

    private final Context appContext;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final BluetoothAdapter adapter;

    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic ab01;
    private State state = State.DISCONNECTED;
    private String deviceName = "OKN-DSP";

    public DspBleManager(Context context, Listener listener) {
        this.appContext = context.getApplicationContext();
        this.listener = listener;
        BluetoothManager manager = (BluetoothManager) appContext.getSystemService(Context.BLUETOOTH_SERVICE);
        this.adapter = manager == null ? null : manager.getAdapter();
    }

    public boolean isBluetoothAvailable() {
        return adapter != null;
    }

    public boolean isBluetoothEnabled() {
        return adapter != null && adapter.isEnabled();
    }

    public State getState() {
        return state;
    }

    public void connect() {
        if (adapter == null) {
            update(State.ERROR, deviceName, "Bluetooth not available");
            return;
        }
        if (!hasScanPermission() || !hasConnectPermission()) {
            update(State.ERROR, deviceName, "Bluetooth permission required");
            return;
        }
        if (!adapter.isEnabled()) {
            update(State.ERROR, deviceName, "Bluetooth is off");
            return;
        }

        disconnectInternal(false);
        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) {
            update(State.ERROR, deviceName, "BLE scanner unavailable");
            return;
        }

        update(State.SCANNING, deviceName, "Scanning for OKN-DSP");
        try {
            scanner.startScan(scanCallback);
            main.removeCallbacks(scanTimeout);
            main.postDelayed(scanTimeout, SCAN_TIMEOUT_MS);
        } catch (SecurityException e) {
            update(State.ERROR, deviceName, "Bluetooth permission denied");
        } catch (Throwable t) {
            Log.e(TAG, "startScan failed", t);
            update(State.ERROR, deviceName, "Unable to start BLE scan");
        }
    }

    public void disconnect() {
        disconnectInternal(true);
    }

    public void close() {
        main.removeCallbacksAndMessages(null);
        stopScan();
        if (gatt != null) {
            try { gatt.close(); } catch (Throwable ignored) { }
        }
        gatt = null;
        ab01 = null;
        state = State.DISCONNECTED;
    }

    public boolean hasKnownCharacteristic() {
        return ab01 != null;
    }

    /**
     * Raw write support is exposed only for later protocol work. v5 does not call it,
     * because the DSP command format has not yet been proven from captured traffic.
     */
    public boolean writeKnownCharacteristic(byte[] data) {
        if (gatt == null || ab01 == null || data == null || !hasConnectPermission()) return false;
        int props = ab01.getProperties();
        boolean canWrite = (props & BluetoothGattCharacteristic.PROPERTY_WRITE) != 0
                || (props & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0;
        if (!canWrite) return false;
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                int writeType = (props & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0
                        ? BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                        : BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT;
                return gatt.writeCharacteristic(ab01, data, writeType) == 0;
            }
            ab01.setValue(data);
            ab01.setWriteType((props & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0
                    ? BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                    : BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
            return gatt.writeCharacteristic(ab01);
        } catch (SecurityException e) {
            return false;
        }
    }

    private final Runnable scanTimeout = new Runnable() {
        @Override public void run() {
            if (state == State.SCANNING) {
                stopScan();
                update(State.ERROR, deviceName, "OKN-DSP not found");
            }
        }
    };

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            if (result == null || result.getDevice() == null || state != State.SCANNING) return;
            String name = null;
            if (result.getScanRecord() != null) name = result.getScanRecord().getDeviceName();
            if ((name == null || name.trim().isEmpty()) && hasConnectPermission()) {
                try { name = result.getDevice().getName(); } catch (SecurityException ignored) { }
            }
            if (!isTargetName(name)) return;
            deviceName = name == null ? "OKN-DSP" : name;
            stopScan();
            connectGatt(result.getDevice());
        }

        @Override
        public void onScanFailed(int errorCode) {
            update(State.ERROR, deviceName, "BLE scan error " + errorCode);
        }
    };

    private boolean isTargetName(String name) {
        if (name == null) return false;
        String normalized = name.trim().toUpperCase(Locale.ROOT).replace('_', '-');
        return normalized.equals("OKN-DSP") || normalized.equals("OKNDSP");
    }

    private void connectGatt(BluetoothDevice device) {
        if (!hasConnectPermission()) {
            update(State.ERROR, deviceName, "Bluetooth connect permission required");
            return;
        }
        update(State.CONNECTING, deviceName, "Connecting");
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                gatt = device.connectGatt(appContext, false, gattCallback, BluetoothDevice.TRANSPORT_LE);
            } else {
                gatt = device.connectGatt(appContext, false, gattCallback);
            }
        } catch (SecurityException e) {
            update(State.ERROR, deviceName, "Bluetooth permission denied");
        } catch (Throwable t) {
            Log.e(TAG, "connectGatt failed", t);
            update(State.ERROR, deviceName, "GATT connection failed");
        }
    }

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt bluetoothGatt, int status, int newState) {
            if (newState == android.bluetooth.BluetoothProfile.STATE_CONNECTED && status == BluetoothGatt.GATT_SUCCESS) {
                update(State.DISCOVERING, deviceName, "Discovering services");
                try {
                    if (hasConnectPermission()) bluetoothGatt.discoverServices();
                } catch (SecurityException e) {
                    update(State.ERROR, deviceName, "Bluetooth permission denied");
                }
            } else if (newState == android.bluetooth.BluetoothProfile.STATE_DISCONNECTED) {
                ab01 = null;
                try { bluetoothGatt.close(); } catch (Throwable ignored) { }
                if (gatt == bluetoothGatt) gatt = null;
                if (state != State.DISCONNECTED) update(State.DISCONNECTED, deviceName, "Disconnected");
            } else if (status != BluetoothGatt.GATT_SUCCESS) {
                update(State.ERROR, deviceName, "GATT status " + status);
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt bluetoothGatt, int status) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                update(State.ERROR, deviceName, "Service discovery failed " + status);
                return;
            }
            BluetoothGattCharacteristic found = null;
            List<BluetoothGattService> services = bluetoothGatt.getServices();
            for (BluetoothGattService service : services) {
                Log.i(TAG, "SERVICE " + service.getUuid());
                for (BluetoothGattCharacteristic characteristic : service.getCharacteristics()) {
                    Log.i(TAG, "  CHAR " + characteristic.getUuid() + " props=0x" + Integer.toHexString(characteristic.getProperties()));
                    if (AB01_UUID.equals(characteristic.getUuid())) found = characteristic;
                }
            }
            ab01 = found;
            if (ab01 == null) {
                update(State.ERROR, deviceName, "Connected, but AB01 was not found");
                return;
            }
            enableNotificationsIfSupported(bluetoothGatt, ab01);
            update(State.READY, deviceName, "AB01 ready");
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt bluetoothGatt, BluetoothGattCharacteristic characteristic) {
            byte[] value = characteristic == null ? null : characteristic.getValue();
            dispatchData(characteristic, value);
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt bluetoothGatt, BluetoothGattCharacteristic characteristic, byte[] value) {
            dispatchData(characteristic, value);
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt bluetoothGatt, BluetoothGattCharacteristic characteristic, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS && characteristic != null) {
                dispatchData(characteristic, characteristic.getValue());
            }
        }
    };

    private void dispatchData(BluetoothGattCharacteristic characteristic, byte[] value) {
        if (characteristic == null || listener == null) return;
        byte[] safe = value == null ? new byte[0] : value.clone();
        listener.onCharacteristicData(characteristic.getUuid(), safe);
    }

    private void enableNotificationsIfSupported(BluetoothGatt bluetoothGatt, BluetoothGattCharacteristic characteristic) {
        int props = characteristic.getProperties();
        boolean notify = (props & BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0;
        boolean indicate = (props & BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0;
        if (!notify && !indicate) return;
        if (!hasConnectPermission()) return;
        try {
            bluetoothGatt.setCharacteristicNotification(characteristic, true);
            BluetoothGattDescriptor descriptor = characteristic.getDescriptor(CCCD_UUID);
            if (descriptor == null) return;
            byte[] value = indicate ? BluetoothGattDescriptor.ENABLE_INDICATION_VALUE : BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE;
            if (Build.VERSION.SDK_INT >= 33) {
                bluetoothGatt.writeDescriptor(descriptor, value);
            } else {
                descriptor.setValue(value);
                bluetoothGatt.writeDescriptor(descriptor);
            }
        } catch (SecurityException ignored) { }
    }

    private void disconnectInternal(boolean notify) {
        main.removeCallbacks(scanTimeout);
        stopScan();
        ab01 = null;
        if (gatt != null) {
            try {
                if (hasConnectPermission()) gatt.disconnect();
            } catch (SecurityException ignored) { }
            try { gatt.close(); } catch (Throwable ignored) { }
            gatt = null;
        }
        if (notify) update(State.DISCONNECTED, deviceName, "Disconnected");
        else state = State.DISCONNECTED;
    }

    private void stopScan() {
        main.removeCallbacks(scanTimeout);
        if (scanner != null && hasScanPermission()) {
            try { scanner.stopScan(scanCallback); } catch (SecurityException ignored) { }
        }
        scanner = null;
    }

    private boolean hasScanPermission() {
        if (Build.VERSION.SDK_INT >= 31) {
            return appContext.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED;
        }
        if (Build.VERSION.SDK_INT >= 23) {
            return appContext.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    private boolean hasConnectPermission() {
        if (Build.VERSION.SDK_INT >= 31) {
            return appContext.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    private void update(final State newState, final String name, final String detail) {
        state = newState;
        Log.i(TAG, newState + " " + detail);
        if (listener != null) {
            main.post(new Runnable() {
                @Override public void run() {
                    listener.onBleStateChanged(newState, name, detail);
                }
            });
        }
    }
}
