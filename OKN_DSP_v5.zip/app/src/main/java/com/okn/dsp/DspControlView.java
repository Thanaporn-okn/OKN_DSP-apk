package com.okn.dsp;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import java.util.Locale;

/**
 * OKN_DSP v5
 * UI remains locked to the supplied reference screens.
 * v5 completes the lower Home/EQ controls and connects the UI to the real BLE state layer.
 */
public class DspControlView extends View {
    private static final float VW = 554f;
    private static final float REFERENCE_H = 1536f;
    private static final float NAV_H = 118f;
    private static final float HOME_CONTENT_BOTTOM = 1575f;
    private static final float EQ_CONTENT_BOTTOM = 1655f;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Typeface uiRegular = Typeface.create("sans-serif-rounded", Typeface.NORMAL);
    private final Typeface uiBold = Typeface.create("sans-serif-rounded", Typeface.BOLD);
    private final SharedPreferences prefs;

    private int page = 0; // 0 Home, 1 EQ
    private int activeHomeSlider = -1;
    private int activeEqBand = -1;
    private float viewportH = REFERENCE_H;
    private float homeScroll = 0f;
    private float eqScroll = 0f;
    private float lastTouchY = 0f;
    private boolean scrollGesture = false;
    private DspBleManager.State connectionState = DspBleManager.State.DISCONNECTED;
    private String connectedDeviceName = "OKN-DSP";
    private ConnectionActions connectionActions;
    private int activePreset = 0;
    private int activeChannel = 0;

    private float master = -6f;
    private float bass = 0f;
    private float cutoff = 80f;
    private float bassBoost = 4f;
    private float midBoost = 2f;
    private float trebleBoost = 3f;
    private final float[][] channelEq = new float[7][7];
    private float[] eqGain = channelEq[0];
    private final float[] copiedEq = new float[7];
    private boolean hasCopiedEq = false;
    private final float[] userHomePreset = new float[6];
    private boolean hasUserHomePreset = false;

    private static final String[] CHANNEL_LABELS = {
            "CH1 : Front Left", "CH2 : Front Right", "CH3 : Rear Left",
            "CH4 : Rear Right", "CH5 : Center", "CH6 : Sub", "CH7 : AUX"
    };
    private static final String[] CHANNEL_SHORT = {"FL", "FR", "RL", "RR", "CEN", "SUB", "AUX"};

    public interface ConnectionActions {
        void onConnectRequested();
        void onDisconnectRequested();
    }

    private final int bg = Color.rgb(0, 18, 31);
    private final int panel = Color.rgb(2, 32, 50);
    private final int panelDark = Color.rgb(1, 24, 39);
    private final int border = Color.rgb(29, 76, 105);
    private final int cyan = Color.rgb(0, 159, 255);
    private final int white = Color.rgb(238, 245, 255);
    private final int muted = Color.rgb(177, 195, 222);
    private final int rail = Color.rgb(31, 67, 92);
    private final int green = Color.rgb(76, 242, 75);

    private final int[] bandColors = {
            Color.rgb(255, 69, 72),
            Color.rgb(255, 157, 29),
            Color.rgb(255, 204, 42),
            Color.rgb(89, 235, 50),
            Color.rgb(4, 192, 231),
            Color.rgb(141, 67, 235),
            Color.rgb(242, 84, 153)
    };

    public DspControlView(Context context) {
        super(context);
        setFocusable(true);
        setClickable(true);
        p.setTypeface(uiRegular);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        prefs = context.getSharedPreferences("okn_dsp", Context.MODE_PRIVATE);
        float[] initial = {-3f, 0f, 4f, -2f, -4f, 2f, 0f};
        System.arraycopy(initial, 0, channelEq[0], 0, initial.length);
        loadState();
    }

    public void setConnectionActions(ConnectionActions actions) {
        this.connectionActions = actions;
    }

    public void setConnectionState(DspBleManager.State state, String deviceName) {
        connectionState = state == null ? DspBleManager.State.DISCONNECTED : state;
        if (deviceName != null && !deviceName.trim().isEmpty()) connectedDeviceName = deviceName;
        invalidate();
    }

    private void loadState() {
        master = prefs.getFloat("master", master);
        bass = prefs.getFloat("bass", bass);
        cutoff = prefs.getFloat("cutoff", cutoff);
        bassBoost = prefs.getFloat("bassBoost", bassBoost);
        midBoost = prefs.getFloat("midBoost", midBoost);
        trebleBoost = prefs.getFloat("trebleBoost", trebleBoost);
        activePreset = prefs.getInt("preset", 0);
        activeChannel = Math.max(0, Math.min(6, prefs.getInt("activeChannel", 0)));
        for (int ch = 0; ch < 7; ch++) {
            for (int i = 0; i < 7; i++) {
                float fallback = (ch == 0) ? channelEq[ch][i] : 0f;
                if (ch == 0 && prefs.contains("eq" + i)) fallback = prefs.getFloat("eq" + i, fallback);
                channelEq[ch][i] = prefs.getFloat("eq_" + ch + "_" + i, fallback);
            }
        }
        eqGain = channelEq[activeChannel];
        hasUserHomePreset = prefs.getBoolean("hasUserHomePreset", false);
        if (hasUserHomePreset) {
            for (int i = 0; i < userHomePreset.length; i++) {
                userHomePreset[i] = prefs.getFloat("homePreset" + i, 0f);
            }
        }
    }

    private void saveState() {
        SharedPreferences.Editor e = prefs.edit()
                .putFloat("master", master)
                .putFloat("bass", bass)
                .putFloat("cutoff", cutoff)
                .putFloat("bassBoost", bassBoost)
                .putFloat("midBoost", midBoost)
                .putFloat("trebleBoost", trebleBoost)
                .putInt("preset", activePreset)
                .putInt("activeChannel", activeChannel)
                .putBoolean("hasUserHomePreset", hasUserHomePreset);
        for (int ch = 0; ch < 7; ch++) {
            for (int i = 0; i < 7; i++) e.putFloat("eq_" + ch + "_" + i, channelEq[ch][i]);
        }
        for (int i = 0; i < userHomePreset.length; i++) e.putFloat("homePreset" + i, userHomePreset[i]);
        e.apply();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (getWidth() <= 0 || getHeight() <= 0) return;

        int root = canvas.save();
        try {
            float scale = getWidth() / VW;
            if (scale <= 0f) return;
            viewportH = getHeight() / scale;
            if (page == 0) homeScroll = clamp(homeScroll, 0f, maxScrollForPage(0));
            else eqScroll = clamp(eqScroll, 0f, maxScrollForPage(1));

            canvas.scale(scale, scale);
            drawBackground(canvas);

            float navTop = getNavTop();
            int clipped = canvas.save();
            canvas.clipRect(0, 0, VW, navTop);
            canvas.translate(0, -(page == 0 ? homeScroll : eqScroll));
            if (page == 0) drawHome(canvas); else drawEq(canvas);
            canvas.restoreToCount(clipped);

            drawBottomNav(canvas, page);
        } catch (Throwable ignored) {
            try { canvas.restoreToCount(root); } catch (Throwable ignored2) { }
            canvas.drawColor(bg);
            Paint safe = new Paint(Paint.ANTI_ALIAS_FLAG);
            safe.setColor(Color.WHITE);
            safe.setTextSize(34f);
            safe.setTypeface(Typeface.DEFAULT_BOLD);
            canvas.drawText("OKN_DSP", 34f, 70f, safe);
            safe.setTextSize(18f);
            safe.setTypeface(Typeface.DEFAULT);
            canvas.drawText("UI recovery mode", 34f, 108f, safe);
            return;
        }
        canvas.restoreToCount(root);
    }

    private float getNavTop() {
        return Math.max(0f, viewportH - NAV_H);
    }

    private float maxScrollForPage(int which) {
        float bottom = which == 0 ? HOME_CONTENT_BOTTOM : EQ_CONTENT_BOTTOM;
        return Math.max(0f, bottom - getNavTop() + 10f);
    }

    private float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private void drawBackground(Canvas c) {
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0, 0, VW, Math.max(viewportH, 900f),
                Color.rgb(0, 35, 59), Color.rgb(0, 11, 20), Shader.TileMode.CLAMP));
        c.drawRect(0, 0, VW, viewportH, p);
        p.setShader(null);

        p.setColor(Color.argb(30, 0, 126, 220));
        c.drawCircle(24, 43, 206, p);
        p.setColor(Color.argb(22, 0, 124, 214));
        c.drawCircle(520, 425, 210, p);
        p.setColor(Color.argb(17, 36, 93, 165));
        c.drawCircle(488, 1160, 230, p);
    }

    private void drawHeader(Canvas c) {
        // Logo waveform closely matching the reference.
        float x = 42f, cy = 57f;
        float[] h = {33, 57, 77, 55, 32};
        stroke.setColor(cyan);
        stroke.setStrokeWidth(6f);
        for (int i = 0; i < h.length; i++) {
            float xx = x + i * 14.5f;
            c.drawLine(xx, cy - h[i] / 2f, xx, cy + h[i] / 2f, stroke);
        }

        text(c, "OKN_", 120, 61, 27, white, Paint.Align.LEFT, false);
        text(c, "DSP", 214, 61, 28, Color.rgb(16, 126, 255), Paint.Align.LEFT, false);
        text(c, "DIGITAL SIGNAL PROCESSOR", 120, 86, 10.5f, Color.rgb(179, 193, 220), Paint.Align.LEFT, false);

        round(c, 347, 29, 482, 92, 16, Color.rgb(3, 32, 49), border, 1.2f);
        boolean ready = connectionState == DspBleManager.State.READY;
        boolean busy = connectionState == DspBleManager.State.SCANNING
                || connectionState == DspBleManager.State.CONNECTING
                || connectionState == DspBleManager.State.DISCOVERING;
        stroke.setColor(ready ? green : (busy ? cyan : muted));
        stroke.setStrokeWidth(2.2f);
        c.drawCircle(374, 59, 11, stroke);
        c.drawLine(374, 48, 374, 70, stroke);
        c.drawLine(367, 52, 381, 66, stroke);
        c.drawLine(381, 52, 367, 66, stroke);
        String status = ready ? "เชื่อมต่อแล้ว" : (busy ? "กำลังเชื่อมต่อ" :
                (connectionState == DspBleManager.State.ERROR ? "เชื่อมต่อไม่สำเร็จ" : "ยังไม่เชื่อมต่อ"));
        text(c, status, 396, 56, status.length() > 16 ? 12.5f : 14f, white, Paint.Align.LEFT, true);
        text(c, connectedDeviceName, 396, 77, 11, muted, Paint.Align.LEFT, false);

        drawGear(c, 516, 60, Color.rgb(231, 239, 252));
    }

    private void drawHome(Canvas c) {
        drawHeader(c);
        drawDeviceCard(c);

        sliderCard(c, 17, 235, 541, 405, "Master Volume", "ระดับเสียงรวม",
                master, -60, 20, String.format(Locale.US, "%.1f dB", master), cyan,
                new String[]{"-60", "-40", "-20", "0", "+20"});
        drawSpeakerIcon(c, 72, 320, cyan);

        sliderCard(c, 17, 418, 541, 588, "Bass Volume", "ระดับเสียงเบส",
                bass, -60, 20, String.format(Locale.US, "%.1f dB", bass), cyan,
                new String[]{"-60", "-40", "-20", "0", "+20"});
        drawBassIcon(c, 72, 503, cyan);

        sliderCard(c, 17, 601, 541, 772, "Bass Cutoff", "ความถี่ตัดเบส (Low Pass)",
                cutoff, 20, 500, String.format(Locale.US, "%.0f Hz", cutoff), Color.rgb(6, 224, 196),
                new String[]{"20", "50", "100", "200", "500"});
        drawWaveIcon(c, 72, 687, cyan);

        sliderCard(c, 17, 785, 541, 955, "Bass Boost", "เพิ่มเสียงเบส",
                bassBoost, -12, 12, String.format(Locale.US, "%.1f dB", bassBoost), Color.rgb(255, 173, 30),
                new String[]{"-12", "-6", "0", "+6", "+12"});
        drawBarsIcon(c, 72, 870, Color.rgb(255, 178, 43));

        sliderCard(c, 17, 968, 541, 1138, "Middle Boost", "เพิ่มเสียงกลาง",
                midBoost, -12, 12, String.format(Locale.US, "%.1f dB", midBoost), Color.rgb(139, 58, 234),
                new String[]{"-12", "-6", "0", "+6", "+12"});
        drawBarsIcon(c, 72, 1053, Color.rgb(142, 61, 236));

        sliderCard(c, 17, 1152, 541, 1322, "Treble Boost", "เพิ่มเสียงแหลม",
                trebleBoost, -12, 12, String.format(Locale.US, "%.1f dB", trebleBoost), Color.rgb(239, 83, 157),
                new String[]{"-12", "-6", "0", "+6", "+12"});
        drawBarsIcon(c, 72, 1237, Color.rgb(241, 83, 158));

        drawPresetCard(c);
        drawHomePresetActions(c);
    }

    private void drawDeviceCard(Canvas c) {
        round(c, 17, 117, 541, 219, 17, Color.rgb(2, 31, 49), border, 1.2f);
        round(c, 34, 131, 108, 204, 14, Color.rgb(5, 43, 72), Color.rgb(18, 76, 116), 1f);
        drawDeviceIcon(c, 71, 167, Color.rgb(112, 151, 255));

        text(c, "DSP 7 Channel", 123, 164, 20, white, Paint.Align.LEFT, false);
        text(c, "Professional Audio Processing", 123, 191, 13.5f, muted, Paint.Align.LEFT, false);

        round(c, 341, 138, 529, 198, 12, Color.rgb(2, 27, 43), Color.rgb(0, 119, 217), 1.3f);
        drawLinkIcon(c, 368, 168, cyan);
        String buttonText;
        if (connectionState == DspBleManager.State.READY) buttonText = "ยกเลิกการเชื่อมต่อ";
        else if (connectionState == DspBleManager.State.SCANNING) buttonText = "กำลังค้นหา DSP";
        else if (connectionState == DspBleManager.State.CONNECTING || connectionState == DspBleManager.State.DISCOVERING) buttonText = "กำลังเชื่อมต่อ";
        else buttonText = "เชื่อมต่อ DSP";
        text(c, buttonText, 392, 174, 13.5f, white, Paint.Align.LEFT, false);
    }

    private void sliderCard(Canvas c, float l, float t, float r, float b, String title, String subtitle,
                            float value, float min, float max, String valueText, int accent, String[] ticks) {
        round(c, l, t, r, b, 16, panel, border, 1.05f);
        text(c, title, 130, t + 43, 19.5f, white, Paint.Align.LEFT, false);
        text(c, subtitle, 130, t + 69, 13.5f, muted, Paint.Align.LEFT, false);

        round(c, 413, t + 22, 526, t + 73, 13, panelDark, Color.rgb(48, 92, 123), 1f);
        text(c, valueText, 517, t + 55, 17.5f, white, Paint.Align.RIGHT, false);

        float x1 = 130, x2 = 490, y = t + 104;
        p.setStyle(Paint.Style.FILL);
        p.setColor(rail);
        c.drawRoundRect(new RectF(x1, y - 7.5f, x2, y + 7.5f), 8, 8, p);

        float ratio = clamp((value - min) / (max - min), 0f, 1f);
        float knobX = x1 + ratio * (x2 - x1);
        p.setColor(accent);
        c.drawRoundRect(new RectF(x1, y - 7.5f, knobX, y + 7.5f), 8, 8, p);

        p.setColor(Color.rgb(239, 245, 253));
        c.drawCircle(knobX, y, 16, p);

        float[] tickXs = {130, 219, 308, 397, 486};
        for (int i = 0; i < 5; i++) {
            stroke.setColor(Color.rgb(94, 122, 150));
            stroke.setStrokeWidth(1f);
            c.drawLine(tickXs[i], y + 20, tickXs[i], y + 29, stroke);
            text(c, ticks[i], tickXs[i], y + 51, 12.5f, muted, Paint.Align.CENTER, false);
        }
    }

    private void drawPresetCard(Canvas c) {
        round(c, 17, 1336, 541, 1458, 15, Color.rgb(2, 30, 47), border, 1.1f);
        text(c, "พรีเซ็ตด่วน", 34, 1365, 15, white, Paint.Align.LEFT, false);
        String[] names = {"Flat", "Pop", "Rock", "Jazz", "Vocal"};
        float gap = 10f;
        float l = 33f;
        float total = 488f;
        float w = (total - 4f * gap) / 5f;
        for (int i = 0; i < 5; i++) {
            float x1 = l + i * (w + gap);
            float x2 = x1 + w;
            boolean selected = i == activePreset;
            round(c, x1, 1378, x2, 1432, 10,
                    selected ? Color.rgb(0, 132, 250) : Color.rgb(3, 29, 46),
                    selected ? Color.rgb(54, 181, 255) : border, 1f);
            text(c, names[i], (x1 + x2) / 2f, 1411, 14, white, Paint.Align.CENTER, false);
        }
    }

    private void drawHomePresetActions(Canvas c) {
        round(c, 24, 1472, 267, 1545, 12, Color.rgb(2, 29, 45), border, 1f);
        drawSaveIcon(c, 66, 1508, white);
        text(c, "บันทึกพรีเซ็ต", 143, 1514, 14, white, Paint.Align.CENTER, false);
        round(c, 287, 1472, 530, 1545, 12, Color.rgb(2, 29, 45), border, 1f);
        drawFolderIcon(c, 329, 1508, white);
        text(c, "โหลดพรีเซ็ต", 409, 1514, 14, white, Paint.Align.CENTER, false);
    }

    private void drawEq(Canvas c) {
        drawHeader(c);
        drawTopTabs(c);

        text(c, "กราฟ EQ", 30, 339, 20, white, Paint.Align.LEFT, true);
        round(c, 137, 303, 457, 360, 11, Color.rgb(2, 29, 45), Color.rgb(39, 88, 121), 1.1f);
        text(c, "(" + CHANNEL_LABELS[activeChannel] + ")", 158, 339, 15.5f, white, Paint.Align.LEFT, false);
        drawChevron(c, 439, 331, muted);
        round(c, 492, 303, 542, 360, 10, Color.rgb(2, 29, 45), Color.rgb(39, 88, 121), 1.1f);
        text(c, "Reset", 517, 339, 13.5f, white, Paint.Align.CENTER, false);

        drawEqGraph(c);
        drawEqBandCards(c);
        drawChannelSelector(c);
        drawEqActions(c);
    }

    private void drawTopTabs(Canvas c) {
        round(c, 19, 143, 543, 264, 18, Color.rgb(2, 31, 49), border, 1.1f);
        String[] labels = {"หน้าแรก", "EQ", "Delay", "Crossover", "Output"};
        float[] cx = {68, 171, 284, 390, 502};
        float[] splits = {118, 226, 337, 447};
        round(c, 119, 147, 225, 261, 14, Color.rgb(0, 139, 255), Color.rgb(0, 160, 255), 1f);
        for (int i = 0; i < 5; i++) {
            int color = i == 1 ? white : Color.rgb(191, 210, 249);
            if (i == 0) drawHomeIcon(c, cx[i], 190, color);
            else if (i == 1) drawMiniBars(c, cx[i], 189, color);
            else if (i == 2) drawClockIcon(c, cx[i], 189, color);
            else if (i == 3) drawCrossIcon(c, cx[i], 189, color);
            else drawSpeakerSmall(c, cx[i], 189, color);
            text(c, labels[i], cx[i], 236, i == 3 ? 12.5f : 14, color, Paint.Align.CENTER, false);
            if (i < 4) {
                stroke.setColor(Color.rgb(19, 57, 78));
                stroke.setStrokeWidth(1f);
                c.drawLine(splits[i], 164, splits[i], 244, stroke);
            }
        }
    }

    private void drawEqGraph(Canvas c) {
        float l = 65f, t = 376f, r = 542f, b = 695f;
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.rgb(1, 24, 38));
        c.drawRect(l, t, r, b, p);
        stroke.setColor(Color.rgb(48, 92, 118));
        stroke.setStrokeWidth(1.1f);
        c.drawRect(l, t, r, b, stroke);

        for (int i = 0; i <= 10; i++) {
            stroke.setColor(Color.argb(75, 47, 91, 117));
            stroke.setStrokeWidth(0.8f);
            float x = l + (r - l) * i / 10f;
            c.drawLine(x, t, x, b, stroke);
        }
        for (int i = 0; i <= 8; i++) {
            stroke.setColor(Color.argb(65, 47, 91, 117));
            float y = t + (b - t) * i / 8f;
            c.drawLine(l, y, r, y, stroke);
        }

        String[] yl = {"+12", "+6", "0", "-6", "-12"};
        for (int i = 0; i < yl.length; i++) {
            text(c, yl[i], 54, t + (b - t) * i / 4f + 5, 11.5f, muted, Paint.Align.RIGHT, false);
        }
        String[] xl = {"20", "50", "100", "200", "500", "1K", "2K", "5K", "10K", "20K"};
        for (int i = 0; i < xl.length; i++) {
            text(c, xl[i], l + (r - l) * i / 9f, b + 32, 11.5f, muted, Paint.Align.CENTER, false);
        }

        float[] px = {117, 183, 255, 340, 408, 474, 516};
        float startY = gainToGraphY(-3.0f, t, b);
        Path curve = new Path();
        curve.moveTo(l, gainToGraphY(-2.1f, t, b));
        curve.cubicTo(88, startY + 10, 99, startY, px[0], startY);
        for (int i = 0; i < px.length - 1; i++) {
            float x0 = px[i], y0 = gainToGraphY(eqGain[i], t, b);
            float x1 = px[i + 1], y1 = gainToGraphY(eqGain[i + 1], t, b);
            float dx = (x1 - x0) / 2.3f;
            curve.cubicTo(x0 + dx, y0, x1 - dx, y1, x1, y1);
        }
        curve.cubicTo(529, gainToGraphY(eqGain[6], t, b), 535, gainToGraphY(0.5f, t, b), r, gainToGraphY(0.8f, t, b));

        Path fill = new Path(curve);
        fill.lineTo(r, b);
        fill.lineTo(l, b);
        fill.close();
        p.setShader(new LinearGradient(0, t, 0, b,
                Color.argb(82, 0, 143, 241), Color.argb(0, 0, 143, 241), Shader.TileMode.CLAMP));
        p.setStyle(Paint.Style.FILL);
        c.drawPath(fill, p);
        p.setShader(null);

        stroke.setColor(cyan);
        stroke.setStrokeWidth(3.5f);
        c.drawPath(curve, stroke);

        for (int i = 0; i < 7; i++) {
            float y = gainToGraphY(eqGain[i], t, b);
            p.setColor(bandColors[i]);
            c.drawCircle(px[i], y, 10f, p);
            stroke.setColor(white);
            stroke.setStrokeWidth(1.5f);
            c.drawCircle(px[i], y, 10f, stroke);
        }
    }

    private float gainToGraphY(float gain, float t, float b) {
        return t + (12f - clamp(gain, -12f, 12f)) / 24f * (b - t);
    }

    private void drawEqBandCards(Canvas c) {
        float top = 771f;
        float bottom = 1414f;
        float l0 = 23f;
        float gap = 5f;
        float totalW = 512f;
        float cardW = (totalW - gap * 6f) / 7f;
        String[] freq = {"50 Hz", "100 Hz", "500 Hz", "1.0 kHz", "2.0 kHz", "5.0 kHz", "10.0 kHz"};

        for (int i = 0; i < 7; i++) {
            float l = l0 + i * (cardW + gap);
            float r = l + cardW;
            float cx = (l + r) / 2f;
            round(c, l, top, r, bottom, 10, Color.rgb(2, 29, 45), Color.rgb(33, 77, 105), 1f);

            p.setColor(bandColors[i]);
            c.drawCircle(cx, 807, 9.5f, p);
            text(c, String.valueOf(i + 1), cx, 853, 14, bandColors[i], Paint.Align.CENTER, false);

            round(c, l + 8, 865, r - 8, 913, 9, Color.rgb(2, 22, 36), Color.rgb(38, 76, 100), 0.9f);
            text(c, freq[i], cx, 896, 10.5f, white, Paint.Align.CENTER, false);

            round(c, l + 8, 922, r - 8, 975, 9, Color.rgb(2, 22, 36), Color.rgb(38, 76, 100), 0.9f);
            text(c, String.format(Locale.US, "%.1f", eqGain[i]), cx, 955, 13.5f, white, Paint.Align.CENTER, false);
            text(c, "dB", cx, 1003, 12, muted, Paint.Align.CENTER, false);

            round(c, l + 8, 1022, r - 8, 1070, 9, Color.rgb(2, 22, 36), Color.rgb(38, 76, 100), 0.9f);
            text(c, "1.0", cx, 1053, 12.5f, white, Paint.Align.CENTER, false);

            float y1 = 1118, y2 = 1329;
            p.setColor(rail);
            c.drawRoundRect(new RectF(cx - 5.5f, y1, cx + 5.5f, y2), 7, 7, p);
            float knobY = gainToSliderY(eqGain[i], y1, y2);
            p.setColor(bandColors[i]);
            c.drawRoundRect(new RectF(cx - 5.5f, knobY, cx + 5.5f, y2), 7, 7, p);
            p.setColor(Color.rgb(238, 245, 253));
            c.drawCircle(cx, knobY, 14.5f, p);

            text(c, "+12", r - 6, y1 + 7, 9.5f, muted, Paint.Align.RIGHT, false);
            text(c, "0", r - 6, (y1 + y2) / 2f + 4, 9.5f, muted, Paint.Align.RIGHT, false);
            text(c, "-12", r - 6, y2 + 3, 9.5f, muted, Paint.Align.RIGHT, false);

            round(c, l + 8, 1357, r - 8, 1404, 8, Color.rgb(2, 22, 36), Color.rgb(38, 76, 100), 0.9f);
            drawBellIcon(c, cx, 1382, white);
        }
    }

    private void drawChannelSelector(Canvas c) {
        round(c, 17, 1428, 541, 1548, 14, Color.rgb(2, 30, 47), border, 1.1f);
        text(c, "เลือกช่องสัญญาณ", 31, 1456, 15, white, Paint.Align.LEFT, false);
        float l0 = 29f, gap = 6f, totalW = 500f;
        float w = (totalW - gap * 6f) / 7f;
        for (int i = 0; i < 7; i++) {
            float l = l0 + i * (w + gap), r = l + w, cx = (l + r) / 2f;
            boolean selected = i == activeChannel;
            round(c, l, 1468, r, 1535, 9,
                    selected ? Color.rgb(0, 137, 250) : Color.rgb(2, 25, 41),
                    selected ? Color.rgb(63, 182, 255) : border, 1f);
            text(c, "CH" + (i + 1), cx, 1495, 11.5f, white, Paint.Align.CENTER, false);
            text(c, CHANNEL_SHORT[i], cx, 1521, 11f, muted, Paint.Align.CENTER, false);
        }
    }

    private void drawEqActions(Canvas c) {
        float l = 20f, gap = 8f, totalW = 514f, w = (totalW - gap * 2f) / 3f;
        String[] labels = {"คัดลอก EQ", "วาง EQ", "บันทึกพรีเซ็ต"};
        for (int i = 0; i < 3; i++) {
            float x1 = l + i * (w + gap), x2 = x1 + w;
            round(c, x1, 1564, x2, 1638, 11, Color.rgb(2, 29, 45), border, 1f);
            if (i == 0) drawCopyIcon(c, x1 + 28, 1601, white);
            else if (i == 1) drawPasteIcon(c, x1 + 28, 1601, white);
            else drawSaveIcon(c, x1 + 28, 1601, white);
            text(c, labels[i], x1 + w * 0.60f, 1608, 12.5f, white, Paint.Align.CENTER, false);
        }
    }

    private float gainToSliderY(float gain, float top, float bottom) {
        return top + (12f - clamp(gain, -12f, 12f)) / 24f * (bottom - top);
    }

    private void drawBottomNav(Canvas c, int selectedPage) {
        float top = getNavTop();
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.rgb(0, 18, 31));
        c.drawRect(0, top, VW, viewportH, p);
        stroke.setColor(Color.rgb(21, 59, 82));
        stroke.setStrokeWidth(1f);
        c.drawLine(0, top, VW, top, stroke);

        float iconY = top + 39;
        float labelY = top + 84;
        float[] cx = {97, 277, 458};
        String[] labels = {"หน้าแรก", "EQ", "เพิ่มเติม"};
        for (int i = 0; i < 3; i++) {
            boolean selected = (selectedPage == 0 && i == 0) || (selectedPage == 1 && i == 1);
            int col = selected ? cyan : Color.rgb(193, 208, 241);
            if (i == 0) drawHomeIcon(c, cx[i], iconY, col);
            else if (i == 1) drawMiniBars(c, cx[i], iconY, col);
            else drawDots(c, cx[i], iconY - 3, col);
            text(c, labels[i], cx[i], labelY, 14, col, Paint.Align.CENTER, false);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (getWidth() <= 0 || getHeight() <= 0) return true;
        float scale = getWidth() / VW;
        if (scale <= 0f) return true;
        viewportH = getHeight() / scale;

        float x = e.getX() / scale;
        float screenY = e.getY() / scale;
        float scroll = page == 0 ? homeScroll : eqScroll;
        float y = screenY + scroll;
        float navTop = getNavTop();

        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                activeHomeSlider = -1;
                activeEqBand = -1;
                scrollGesture = false;
                lastTouchY = screenY;

                if (screenY >= navTop) {
                    if (x < VW / 3f) page = 0;
                    else if (x < VW * 2f / 3f) page = 1;
                    invalidate();
                    return true;
                }

                if (page == 0) {
                    if (y >= 138 && y <= 198 && x >= 335) {
                        if (connectionActions != null) {
                            if (connectionState == DspBleManager.State.READY
                                    || connectionState == DspBleManager.State.CONNECTING
                                    || connectionState == DspBleManager.State.DISCOVERING
                                    || connectionState == DspBleManager.State.SCANNING) {
                                connectionActions.onDisconnectRequested();
                            } else {
                                connectionActions.onConnectRequested();
                            }
                        }
                        return true;
                    }
                    int preset = presetAt(x, y);
                    if (preset >= 0) {
                        applyPreset(preset);
                        saveState();
                        invalidate();
                        return true;
                    }
                    if (y >= 1472 && y <= 1545) {
                        if (x >= 24 && x <= 267) saveUserHomePreset();
                        else if (x >= 287 && x <= 530) loadUserHomePreset();
                        return true;
                    }
                    int idx = homeSliderAt(y);
                    if (idx >= 0 && x >= 115 && x <= 505) {
                        activeHomeSlider = idx;
                        updateHomeSlider(idx, x);
                        return true;
                    }
                } else {
                    if (y >= 143 && y <= 264 && x < 118) {
                        page = 0;
                        invalidate();
                        return true;
                    }
                    if (y >= 303 && y <= 360 && x >= 137 && x <= 457) {
                        selectChannel((activeChannel + 1) % 7);
                        return true;
                    }
                    if (y >= 303 && y <= 360 && x >= 486) {
                        for (int i = 0; i < eqGain.length; i++) eqGain[i] = 0f;
                        activePreset = -1;
                        saveState();
                        invalidate();
                        return true;
                    }
                    int ch = channelAt(x, y);
                    if (ch >= 0) {
                        selectChannel(ch);
                        return true;
                    }
                    int action = eqActionAt(x, y);
                    if (action >= 0) {
                        runEqAction(action);
                        return true;
                    }
                    int band = eqBandAt(x, y);
                    if (band >= 0) {
                        activeEqBand = band;
                        updateEqBand(band, y);
                        return true;
                    }
                }

                scrollGesture = true;
                return true;

            case MotionEvent.ACTION_MOVE:
                if (activeHomeSlider >= 0) {
                    updateHomeSlider(activeHomeSlider, x);
                    return true;
                }
                if (activeEqBand >= 0) {
                    float currentY = screenY + (page == 0 ? homeScroll : eqScroll);
                    updateEqBand(activeEqBand, currentY);
                    return true;
                }
                if (scrollGesture) {
                    float delta = lastTouchY - screenY;
                    if (page == 0) homeScroll = clamp(homeScroll + delta, 0f, maxScrollForPage(0));
                    else eqScroll = clamp(eqScroll + delta, 0f, maxScrollForPage(1));
                    lastTouchY = screenY;
                    invalidate();
                    return true;
                }
                break;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (activeHomeSlider >= 0 || activeEqBand >= 0) saveState();
                activeHomeSlider = -1;
                activeEqBand = -1;
                scrollGesture = false;
                performClick();
                return true;
        }
        return true;
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    private int homeSliderAt(float y) {
        float[] centers = {339, 522, 705, 889, 1072, 1256};
        for (int i = 0; i < centers.length; i++) {
            if (Math.abs(y - centers[i]) <= 38f) return i;
        }
        return -1;
    }

    private void updateHomeSlider(int i, float x) {
        float ratio = clamp((x - 130f) / (490f - 130f), 0f, 1f);
        switch (i) {
            case 0: master = -60f + ratio * 80f; break;
            case 1: bass = -60f + ratio * 80f; break;
            case 2: cutoff = 20f + ratio * 480f; break;
            case 3: bassBoost = -12f + ratio * 24f; break;
            case 4: midBoost = -12f + ratio * 24f; break;
            case 5: trebleBoost = -12f + ratio * 24f; break;
            default: break;
        }
        activePreset = -1;
        invalidate();
    }

    private int presetAt(float x, float y) {
        if (y < 1370 || y > 1442) return -1;
        float gap = 10f, l = 33f, total = 488f;
        float w = (total - 4f * gap) / 5f;
        for (int i = 0; i < 5; i++) {
            float x1 = l + i * (w + gap);
            if (x >= x1 && x <= x1 + w) return i;
        }
        return -1;
    }

    private void applyPreset(int preset) {
        activePreset = preset;
        // Reference-friendly demo values. BLE mapping will be added separately.
        float[][] values = {
                {0, 0, 0, 0, 0, 0, 0},
                {-1, 2, 3, 2, 0, 1, 2},
                {3, 2, 1, -1, -1, 2, 3},
                {2, 1, 0, 2, 1, 3, 2},
                {-2, -1, 1, 3, 3, 1, 0}
        };
        System.arraycopy(values[preset], 0, eqGain, 0, 7);
        if (preset == 0) {
            bassBoost = 0f; midBoost = 0f; trebleBoost = 0f;
        } else if (preset == 1) {
            bassBoost = 2f; midBoost = 1f; trebleBoost = 2f;
        } else if (preset == 2) {
            bassBoost = 4f; midBoost = 1f; trebleBoost = 3f;
        } else if (preset == 3) {
            bassBoost = 2f; midBoost = 3f; trebleBoost = 2f;
        } else {
            bassBoost = 0f; midBoost = 4f; trebleBoost = 2f;
        }
    }

    private int eqBandAt(float x, float y) {
        if (y < 1095 || y > 1345) return -1;
        float l0 = 23f, gap = 5f, totalW = 512f;
        float cardW = (totalW - gap * 6f) / 7f;
        for (int i = 0; i < 7; i++) {
            float l = l0 + i * (cardW + gap);
            if (x >= l && x <= l + cardW) return i;
        }
        return -1;
    }

    private void updateEqBand(int i, float y) {
        float top = 1118f, bottom = 1329f;
        float ratio = clamp((y - top) / (bottom - top), 0f, 1f);
        eqGain[i] = 12f - ratio * 24f;
        activePreset = -1;
        invalidate();
    }

    private int channelAt(float x, float y) {
        if (y < 1468 || y > 1535) return -1;
        float l0 = 29f, gap = 6f, totalW = 500f;
        float w = (totalW - gap * 6f) / 7f;
        for (int i = 0; i < 7; i++) {
            float l = l0 + i * (w + gap);
            if (x >= l && x <= l + w) return i;
        }
        return -1;
    }

    private void selectChannel(int channel) {
        activeChannel = Math.max(0, Math.min(6, channel));
        eqGain = channelEq[activeChannel];
        activePreset = -1;
        saveState();
        invalidate();
    }

    private int eqActionAt(float x, float y) {
        if (y < 1564 || y > 1638) return -1;
        float l = 20f, gap = 8f, totalW = 514f, w = (totalW - gap * 2f) / 3f;
        for (int i = 0; i < 3; i++) {
            float x1 = l + i * (w + gap);
            if (x >= x1 && x <= x1 + w) return i;
        }
        return -1;
    }

    private void runEqAction(int action) {
        if (action == 0) {
            System.arraycopy(eqGain, 0, copiedEq, 0, 7);
            hasCopiedEq = true;
            toast("คัดลอก EQ " + (activeChannel + 1) + " แล้ว");
        } else if (action == 1) {
            if (!hasCopiedEq) {
                toast("ยังไม่มี EQ ที่คัดลอก");
                return;
            }
            System.arraycopy(copiedEq, 0, eqGain, 0, 7);
            activePreset = -1;
            saveState();
            invalidate();
            toast("วาง EQ ไปยัง CH" + (activeChannel + 1) + " แล้ว");
        } else {
            saveState();
            toast("บันทึกพรีเซ็ต EQ แล้ว");
        }
    }

    private void saveUserHomePreset() {
        userHomePreset[0] = master;
        userHomePreset[1] = bass;
        userHomePreset[2] = cutoff;
        userHomePreset[3] = bassBoost;
        userHomePreset[4] = midBoost;
        userHomePreset[5] = trebleBoost;
        hasUserHomePreset = true;
        saveState();
        toast("บันทึกพรีเซ็ตแล้ว");
    }

    private void loadUserHomePreset() {
        if (!hasUserHomePreset) {
            toast("ยังไม่มีพรีเซ็ตที่บันทึก");
            return;
        }
        master = userHomePreset[0];
        bass = userHomePreset[1];
        cutoff = userHomePreset[2];
        bassBoost = userHomePreset[3];
        midBoost = userHomePreset[4];
        trebleBoost = userHomePreset[5];
        activePreset = -1;
        saveState();
        invalidate();
        toast("โหลดพรีเซ็ตแล้ว");
    }

    private void toast(String message) {
        Toast.makeText(getContext(), message, Toast.LENGTH_SHORT).show();
    }

    private void drawSaveIcon(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(2.2f);
        c.drawRoundRect(new RectF(cx - 13, cy - 15, cx + 13, cy + 15), 2, 2, stroke);
        c.drawRect(cx - 7, cy - 13, cx + 6, cy - 4, stroke);
        c.drawCircle(cx, cy + 7, 4, stroke);
    }

    private void drawFolderIcon(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(2.2f);
        Path q = new Path();
        q.moveTo(cx - 15, cy - 10); q.lineTo(cx - 3, cy - 10); q.lineTo(cx + 2, cy - 5);
        q.lineTo(cx + 15, cy - 5); q.lineTo(cx + 15, cy + 12); q.lineTo(cx - 15, cy + 12); q.close();
        c.drawPath(q, stroke);
    }

    private void drawCopyIcon(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(2f);
        c.drawRoundRect(new RectF(cx - 12, cy - 12, cx + 7, cy + 11), 2, 2, stroke);
        c.drawRoundRect(new RectF(cx - 6, cy - 7, cx + 13, cy + 16), 2, 2, stroke);
    }

    private void drawPasteIcon(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(2f);
        c.drawRoundRect(new RectF(cx - 12, cy - 10, cx + 12, cy + 15), 2, 2, stroke);
        c.drawRoundRect(new RectF(cx - 6, cy - 16, cx + 6, cy - 7), 2, 2, stroke);
    }

    private void round(Canvas c, float l, float t, float r, float b, float radius, int fill, int line, float sw) {
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        p.setColor(fill);
        c.drawRoundRect(new RectF(l, t, r, b), radius, radius, p);
        if (sw > 0f) {
            stroke.setColor(line);
            stroke.setStrokeWidth(sw);
            c.drawRoundRect(new RectF(l, t, r, b), radius, radius, stroke);
        }
    }

    private void text(Canvas c, String s, float x, float y, float size, int color, Paint.Align align, boolean bold) {
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        p.setTextSize(size);
        p.setTextAlign(align);
        p.setTypeface(bold ? uiBold : uiRegular);
        c.drawText(s, x, y, p);
    }

    private void drawChevron(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(2f);
        c.drawLine(cx - 8, cy - 4, cx, cy + 4, stroke);
        c.drawLine(cx, cy + 4, cx + 8, cy - 4, stroke);
    }

    private void drawGear(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(4f);
        c.drawCircle(cx, cy, 11, stroke);
        c.drawCircle(cx, cy, 3.5f, stroke);
        for (int i = 0; i < 8; i++) {
            double a = Math.PI * 2 * i / 8.0;
            float x1 = cx + (float) Math.cos(a) * 14;
            float y1 = cy + (float) Math.sin(a) * 14;
            float x2 = cx + (float) Math.cos(a) * 19;
            float y2 = cy + (float) Math.sin(a) * 19;
            c.drawLine(x1, y1, x2, y2, stroke);
        }
    }

    private void drawDeviceIcon(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(2.6f);
        c.drawRoundRect(new RectF(cx - 17, cy - 24, cx + 17, cy + 24), 4, 4, stroke);
        c.drawCircle(cx, cy + 7, 9, stroke);
        c.drawCircle(cx, cy + 7, 3, stroke);
        c.drawCircle(cx + 9, cy - 15, 2.5f, stroke);
    }

    private void drawSpeakerIcon(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(4f);
        Path q = new Path();
        q.moveTo(cx - 27, cy - 10); q.lineTo(cx - 14, cy - 10); q.lineTo(cx + 2, cy - 25);
        q.lineTo(cx + 2, cy + 25); q.lineTo(cx - 14, cy + 10); q.lineTo(cx - 27, cy + 10); q.close();
        c.drawPath(q, stroke);
        c.drawArc(new RectF(cx, cy - 20, cx + 30, cy + 20), -54, 108, false, stroke);
        c.drawArc(new RectF(cx, cy - 31, cx + 45, cy + 31), -49, 98, false, stroke);
    }

    private void drawSpeakerSmall(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(2.5f);
        Path q = new Path();
        q.moveTo(cx - 13, cy - 5); q.lineTo(cx - 6, cy - 5); q.lineTo(cx + 2, cy - 14);
        q.lineTo(cx + 2, cy + 14); q.lineTo(cx - 6, cy + 5); q.lineTo(cx - 13, cy + 5); q.close();
        c.drawPath(q, stroke);
        c.drawArc(new RectF(cx, cy - 12, cx + 18, cy + 12), -55, 110, false, stroke);
    }

    private void drawBassIcon(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(3.5f);
        c.drawCircle(cx, cy, 25, stroke);
        c.drawCircle(cx, cy, 13, stroke);
        c.drawArc(new RectF(cx - 21, cy - 37, cx + 21, cy - 7), 203, 134, false, stroke);
        c.drawArc(new RectF(cx - 21, cy + 7, cx + 21, cy + 37), 23, 134, false, stroke);
    }

    private void drawWaveIcon(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(3.5f);
        Path q = new Path();
        q.moveTo(cx - 29, cy); q.lineTo(cx - 21, cy); q.lineTo(cx - 15, cy - 17);
        q.lineTo(cx - 8, cy + 19); q.lineTo(cx, cy - 28); q.lineTo(cx + 8, cy + 25);
        q.lineTo(cx + 15, cy - 13); q.lineTo(cx + 22, cy + 5); q.lineTo(cx + 30, cy + 5);
        c.drawPath(q, stroke);
    }

    private void drawBarsIcon(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(6f);
        float[] hs = {22, 42, 58, 39, 21};
        for (int i = 0; i < hs.length; i++) {
            float xx = cx - 25 + i * 12.5f;
            c.drawLine(xx, cy - hs[i] / 2f, xx, cy + hs[i] / 2f, stroke);
        }
    }

    private void drawMiniBars(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(2.8f);
        float[] hs = {13, 26, 38, 26, 13};
        for (int i = 0; i < hs.length; i++) {
            float xx = cx - 13 + i * 6.5f;
            c.drawLine(xx, cy - hs[i] / 2f, xx, cy + hs[i] / 2f, stroke);
        }
    }

    private void drawHomeIcon(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(3.1f);
        Path q = new Path();
        q.moveTo(cx - 16, cy); q.lineTo(cx, cy - 15); q.lineTo(cx + 16, cy);
        q.moveTo(cx - 12, cy - 2); q.lineTo(cx - 12, cy + 15); q.lineTo(cx + 12, cy + 15); q.lineTo(cx + 12, cy - 2);
        c.drawPath(q, stroke);
    }

    private void drawClockIcon(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(2.7f);
        c.drawCircle(cx, cy, 15, stroke);
        c.drawLine(cx, cy, cx, cy - 9, stroke);
        c.drawLine(cx, cy, cx + 8, cy + 4, stroke);
    }

    private void drawCrossIcon(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(2.8f);
        c.drawLine(cx - 15, cy - 10, cx + 15, cy + 10, stroke);
        c.drawLine(cx - 15, cy + 10, cx + 15, cy - 10, stroke);
        p.setColor(color);
        c.drawCircle(cx - 15, cy - 10, 3.3f, p);
        c.drawCircle(cx + 15, cy - 10, 3.3f, p);
    }

    private void drawDots(Canvas c, float cx, float cy, int color) {
        p.setColor(color);
        for (int i = -1; i <= 1; i++) c.drawCircle(cx + i * 12, cy, 3.6f, p);
    }

    private void drawLinkIcon(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(2.8f);
        c.drawArc(new RectF(cx - 12, cy - 8, cx + 2, cy + 8), 70, 220, false, stroke);
        c.drawArc(new RectF(cx - 2, cy - 8, cx + 12, cy + 8), 250, 220, false, stroke);
    }

    private void drawBellIcon(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(2.5f);
        Path q = new Path();
        q.moveTo(cx - 14, cy + 8);
        q.cubicTo(cx - 7, cy + 8, cx - 7, cy - 13, cx, cy - 13);
        q.cubicTo(cx + 7, cy - 13, cx + 7, cy + 8, cx + 14, cy + 8);
        c.drawPath(q, stroke);
        c.drawArc(new RectF(cx - 6, cy + 4, cx + 6, cy + 14), 20, 140, false, stroke);
    }
}
