package com.okn.dsp;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class MainActivity extends Activity implements DspControlView.ConnectionActions, DspBleManager.Listener {
    private static final int REQ_BLE_PERMISSIONS = 1001;
    private static final int REQ_ENABLE_BLUETOOTH = 1002;

    private DspControlView dspView;
    private DspBleManager bleManager;
    private boolean connectAfterPermission = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(Color.rgb(0, 16, 27));
        getWindow().setNavigationBarColor(Color.rgb(0, 16, 27));

        dspView = new DspControlView(this);
        dspView.setConnectionActions(this);
        setContentView(dspView);

        bleManager = new DspBleManager(this, this);
        dspView.setConnectionState(DspBleManager.State.DISCONNECTED, "OKN-DSP");
        applyFullscreen();
    }

    private void applyFullscreen() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applyFullscreen();
    }

    @Override
    public void onConnectRequested() {
        if (bleManager == null || !bleManager.isBluetoothAvailable()) {
            Toast.makeText(this, "อุปกรณ์นี้ไม่รองรับ Bluetooth", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!hasRequiredBlePermissions()) {
            connectAfterPermission = true;
            requestRequiredBlePermissions();
            return;
        }
        if (!bleManager.isBluetoothEnabled()) {
            connectAfterPermission = true;
            try {
                startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQ_ENABLE_BLUETOOTH);
            } catch (Throwable t) {
                Toast.makeText(this, "กรุณาเปิด Bluetooth", Toast.LENGTH_SHORT).show();
            }
            return;
        }
        bleManager.connect();
    }

    @Override
    public void onDisconnectRequested() {
        connectAfterPermission = false;
        if (bleManager != null) bleManager.disconnect();
    }

    @Override
    public void onBleStateChanged(DspBleManager.State state, String deviceName, String detail) {
        dspView.setConnectionState(state, deviceName);
        if (state == DspBleManager.State.ERROR && detail != null) {
            Toast.makeText(this, detail, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onCharacteristicData(UUID characteristic, byte[] data) {
        // Captured RX data is intentionally not decoded yet. v5 only proves transport/profile access.
    }

    private boolean hasRequiredBlePermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        if (Build.VERSION.SDK_INT >= 23) {
            return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    private void requestRequiredBlePermissions() {
        List<String> permissions = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 31) {
            permissions.add(Manifest.permission.BLUETOOTH_SCAN);
            permissions.add(Manifest.permission.BLUETOOTH_CONNECT);
        } else if (Build.VERSION.SDK_INT >= 23) {
            permissions.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if (!permissions.isEmpty()) {
            requestPermissions(permissions.toArray(new String[0]), REQ_BLE_PERMISSIONS);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_BLE_PERMISSIONS) return;
        boolean granted = true;
        for (int result : grantResults) {
            if (result != PackageManager.PERMISSION_GRANTED) {
                granted = false;
                break;
            }
        }
        if (granted && connectAfterPermission) {
            connectAfterPermission = false;
            onConnectRequested();
        } else if (!granted) {
            connectAfterPermission = false;
            Toast.makeText(this, "ต้องอนุญาต Bluetooth เพื่อเชื่อมต่อ DSP", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_ENABLE_BLUETOOTH && connectAfterPermission) {
            connectAfterPermission = false;
            if (bleManager != null && bleManager.isBluetoothEnabled()) bleManager.connect();
        }
    }

    @Override
    protected void onDestroy() {
        if (bleManager != null) bleManager.close();
        super.onDestroy();
    }
}
