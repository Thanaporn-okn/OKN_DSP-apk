# OKN BP1048P4 Phase3 TRUE7CH R12

R12 เพิ่ม Android InputDevice classifier/passive event watch เพื่อพิสูจน์ว่า IF3 ที่ Android kernel ถืออยู่ ถูก expose เข้าสู่ Android input framework หรือไม่ โดยไม่ claim/detach IF3 และไม่ส่ง USB OUT ใด ๆ

- TRUE 7CH gain core เดิม ไม่ใช้ EQ ทำ Gain
- USB qualification เดิมแบบ read-only
- Android InputDevice VID/PID/source/descriptor/motion-range metadata
- Passive KeyEvent/MotionEvent logger เฉพาะ VID/PID 6324:1719
- ไม่มี SET_REPORT / class OUT / endpoint OUT / force detach / erase / program
