# R12 Build Notes

เป้าหมาย: แยกให้ชัดว่า IF3 EP81 ที่ claim(force=false) ไม่ได้ ถูก Android kernel HID driver map เป็น Android InputDevice หรือไม่

ขั้นใช้:
1. READ-ONLY USB SCAN + QUALIFY
2. READ ANDROID INPUT DEVICES + PASSIVE WATCH
3. ถ้าพบ TARGET INPUT ให้คงหน้าแอปไว้ แล้วหมุน/กด control บนบอร์ดตามปกติ 1-2 ครั้งเพื่อดูว่ามี KeyEvent/MotionEvent หรือไม่ (ไม่มี USB OUT จากแอป)

ถ้า exact VID/PID ไม่ปรากฏใน InputDevice API จะหยุดเส้นทาง Android input-framework และไปแกะ Windows/vendor transport แบบ static/capture ต่อแทนการ force-detach ซ้ำ
