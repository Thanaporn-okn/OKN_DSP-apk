OKN_DSP V96 — FRESH STRUCTURE / VERIFIED-SCOPE REFERENCE UI / REAL-TIME
=======================================================================

PURPOSE
- New Android app structure: one direct launcher Activity (MainActivity). The former launcher -> UnifiedControlActivity trampoline is removed.
- UI scope follows the supplied OKN_DSP five-screen reference image only: Home, Global, EQ, Sensors, More.
- Existing verified BLE/auth/protocol primitives are retained unchanged rather than guessing new DSP packets.

V96 CONNECTION HARDENING
- BLE scan and tap-to-connect.
- Connection, scan, GATT callback, CCCD subscription, MTU/service-discovery and automatic session-start paths are guarded so a Java/Kotlin exception in a BLE callback fails closed instead of intentionally finishing the launcher Activity.
- After AB02 notification setup succeeds, AUTH/session startup runs automatically; no START confirmation is required.
- Direct MainActivity remains the launcher, so there is no finished trampoline Activity underneath the active DSP screen.

REAL-TIME VERIFIED CONTROL
- Verified scalar IDs exactly: 2,3,8,9,10,13,11.
- MasterVolume ID2 is linked to Android STREAM_MUSIC and physical phone Volume +/- while the Activity is active.
- 7 channels x 15 EQ rows are displayed.
- Frequency / Q / Gain sliders write continuously only when the live descriptor identifies a verified PEAKING type=12 record.
- Non-PEAKING and unknown hardware controls are visible/read-only or not exposed; no guessed packet is sent.
- Link All mirrors only corresponding verified-writable PEAKING rows.
- Real-time transport uses latest-target-wins coalescing, exactly one GATT write in flight, and a 38 ms minimum pacing interval.
- TrebleBoost ID11 uses callback-driven bounded slew: maximum 0.5 dB per step, nominal 48 ms between successful steps.

PERSISTENCE
- Every verified scalar and editable PEAKING EQ movement is saved locally immediately.
- On a later successful connection/auth/descriptor Health Gate, remembered verified values replay automatically to the DSP.
- App rotation rebuilds only the UI and keeps the active BLE/auth session objects.

SAVEPARAMS
- Manual one-tap guarded SaveParams only.
- Exact verified trigger: 570000000700000000 (actuator ID7).
- SaveParams is NEVER emitted automatically by local persistence/reconnect replay.

UI REFERENCE
- evidence/OKN_DSP_V96_UI_REFERENCE.png is the exact supplied reference image used for V96 static validation.

BUILD
- GitHub Actions workflow: build-okn-dsp-v96.yml (delivered separately).
- JDK 17, Android SDK 35, Build Tools 35.0.0, Gradle 8.9.
- Debug APK is signed with the stable project debug keystore so upgrades keep the same signing identity.

VALIDATION BOUNDARY
- Protocol JVM self-test passes for verified UFE/AES-CFB8/EQ vectors.
- V96 preflight statically validates reference UI markers, direct launcher structure, realtime queue/persistence/volume-key/Treble protections, verified write allow-lists, frozen protocol hashes and signing key hash.
- The GitHub Actions build is the authoritative full Android compile/sign path in this delivery.
- A software build cannot truthfully guarantee zero acoustic pop/stutter on every physical DSP/phone/radio condition. The code includes pacing, single-inflight writes, coalescing and Treble slew specifically to minimize discontinuities; final no-pop/no-stutter qualification must still be tested on the target physical DSP.
