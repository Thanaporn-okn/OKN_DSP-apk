#!/usr/bin/env python3
from pathlib import Path
import hashlib, re

root = Path(__file__).resolve().parent

def req(rel):
    p = root / rel
    assert p.is_file(), f"missing {rel}"
    return p

def txt(rel):
    return req(rel).read_text(encoding="utf-8", errors="replace")

def sha(rel, expected):
    actual = hashlib.sha256(req(rel).read_bytes()).hexdigest()
    assert actual == expected, f"hash mismatch {rel}: {actual} != {expected}"

def balanced_kotlin(text):
    stack=[]; state='code'; quote=''; i=0; pairs={')':'(',']':'[','}':'{'}
    while i < len(text):
        c=text[i]; n=text[i+1] if i+1<len(text) else ''
        if state=='line':
            if c=='\n': state='code'
        elif state=='block':
            if c=='*' and n=='/': state='code'; i+=1
        elif state=='string':
            if c=='\\': i+=1
            elif c==quote: state='code'
        elif state=='triple':
            if text.startswith('"""',i): state='code'; i+=2
        else:
            if c=='/' and n=='/': state='line'; i+=1
            elif c=='/' and n=='*': state='block'; i+=1
            elif text.startswith('"""',i): state='triple'; i+=2
            elif c in ('"',"'"): state='string'; quote=c
            elif c in '([{': stack.append(c)
            elif c in ')]}':
                assert stack and stack[-1]==pairs[c], f"unbalanced token at {i}"
                stack.pop()
        i+=1
    assert not stack, f"unclosed tokens {stack[-10:]}"

MAIN='app/src/main/java/com/okn/dsp/MainActivity.kt'
G='app/build.gradle.kts'
M='app/src/main/AndroidManifest.xml'
REF='evidence/OKN_DSP_V96_UI_REFERENCE.png'
KEY='app/okn_dsp_stable_debug.keystore'
for f in [MAIN,G,M,REF,KEY,'README_V96.txt']:
    req(f)

# Fresh structure: direct launcher MainActivity only; no activity trampoline/proof screens.
assert 'versionCode = 96' in txt(G)
assert 'versionName = "7.0.0-v96-fresh-structure-reference-realtime"' in txt(G)
manifest=txt(M)
assert manifest.count('<activity') == 1, 'V96 must have one Activity only'
assert 'android:name=".MainActivity"' in manifest
assert 'android:screenOrientation="fullSensor"' in manifest
assert 'android:configChanges="orientation|screenSize|smallestScreenSize|keyboardHidden"' in manifest
assert 'android.permission.BLUETOOTH_SCAN' in manifest and 'android.permission.BLUETOOTH_CONNECT' in manifest
activity_files=sorted(x.name for x in (root/'app/src/main/java/com/okn/dsp').glob('*Activity.kt'))
assert activity_files == ['MainActivity.kt'], f'legacy Activity files leaked: {activity_files}'
sha(REF,'6f5f2eab24de53cd7460abd79e76b04382edd8c62eb7c1e317bbd1bdbfb5b2b0')
sha(KEY,'ba1c52f2607c09953c52fdd79c5f72026aaf0adb8aa44bcba277f7d9b49d9511')

u=txt(MAIN)
assert 'class MainActivity : Activity()' in u
assert 'startActivity(Intent(' not in u
assert 'finish()' not in u, 'direct launcher must not finish itself as a trampoline'
assert 'AlertDialog' not in u, 'V96 operator controls must not require confirmation dialogs'

# Five-screen exact verified-scope UI markers.
for marker in [
    'V96_FRESH_STRUCTURE_UI_START',
    'Scan Bluetooth / สแกนอุปกรณ์', 'แตะเพื่อเชื่อมต่อ',
    'Health Gate PASS', 'Master Volume', 'Channels (7)', 'Link All',
    'Global Controls', 'Channel EQ Overview', 'EQ Editor • 15 bands',
    'PEAKING (Editable)', 'Other Types (Read-only)',
    'Sensors & System', 'SaveParams (Guarded)', 'Save to Device',
    'Home', 'Global', 'EQ', 'Sensors', 'More',
]:
    assert marker in u, marker
sel=u[u.index('private fun selectProductionTab'):u.index('private fun buildUi')]
assert 'tab.coerceIn(0, 4)' in sel
for visible in ['homeSection','globalSection','eqSection','systemSection','moreSection']:
    assert visible in sel
for forbidden in ['crossoverSection','delaySection','mixerSection','presetSection','settingsReferenceSection']:
    assert forbidden not in u, f'non-reference UI scope leaked: {forbidden}'
for fake in ['reference_delay_','reference_ch_gain_','reference_ch_mute_','reference_phase_180_','reference_preset_']:
    assert fake not in u, f'local-only fake control leaked: {fake}'

# Scan -> tap connect + automatic authenticated startup, with crash/fail-closed guards.
for marker in [
    'private fun startScan()', 'private val scanCallback', 'safeConnect(d, name ?: "DSP"',
    'private fun safeConnect(', 'V96_CONNECT_GUARD_CAUGHT', 'V96_CONNECT_GATT_EXCEPTION',
    'private inline fun guardGattCallback', 'V96_GATT_CALLBACK_ERROR',
    'private inline fun guardScanCallback', 'V96_SCAN_CALLBACK_ERROR', 'onScanFailed(errorCode: Int)',
    'private fun safeStartSession(source: String)', 'V96_AUTO_SESSION_ERROR',
    'safeStartSession("cccd-ready")', 'subscribeAb02(g, ab02!!)',
]:
    assert marker in u, marker

# Realtime queue / no-stutter shaping.
for marker in [
    'sealed class LiveCommand', 'private val liveMinIntervalMs = 38L',
    'liveQueue[cmd.key] = cmd', 'if (liveInFlight != null || liveQueue.isEmpty()) return',
    'onLiveGattResult', 'V93_REALTIME_STREAM_FAIL_CLOSED',
    'trebleSlewStepDb = 0.5f', 'trebleSlewIntervalMs = 48L',
    'scheduleTrebleSafeSlew(trebleSlewIntervalMs)',
]:
    assert marker in u, marker

# Immediate local persistence + reconnect replay.
for marker in [
    'persistScalarLocal', 'persistEqLocal', 'restoreLocalSnapshotToConnectedDsp',
    'app-reopen-restore', 'uiSnapshotInitializedKey', 'seedLocalSnapshotFromDsp',
]:
    assert marker in u, marker

# MasterVolume <-> Android media volume, including physical phone keys and Global slider.
for marker in [
    'override fun dispatchKeyEvent(event: KeyEvent)', 'KeyEvent.KEYCODE_VOLUME_UP',
    'KeyEvent.KEYCODE_VOLUME_DOWN', 'AudioManager.STREAM_MUSIC',
    'masterDbFromSystemVolume', 'syncSystemVolumeFromMaster',
    'if (c.id == 2) syncSystemVolumeFromMaster(value)',
    'queueScalarRealtime(2, mapped, "phone-volume-key")',
]:
    assert marker in u, marker

# EQ continuous Frequency/Q/Gain + Link All through verified policy only.
for marker in [
    'queueEqRealtime(selectedChannel,eqEditingBand,f,q,gain,"eq-editor")',
    'uiPrefs().getBoolean("link_all_eq",false)',
    'LiveEqPolicy.isWritable(other)',
    'queueEqRealtime(ch,eqEditingBand,f,q,gain,"eq-link-all")',
    'Frequency  20 Hz — 20 kHz', 'Q  0.05 — 20', 'Gain  -12 — +12 dB',
]:
    assert marker in u, marker

# Rotation keeps connection/session objects and only rebuilds UI.
for marker in [
    'override fun onConfigurationChanged(newConfig: Configuration)', 'buildUi()',
    'V96_ORIENTATION_REBUILD', 'keepGatt=${gatt != null}',
]:
    assert marker in u, marker

# SaveParams remains explicit/manual one-tap guarded; never automatic.
assert 'noConfirmationDialog=true' in u
assert 'beginPermanentSavePrecheck()' in u
sp=txt('app/src/main/java/com/okn/dsp/protocol/SaveParamsPolicy.kt')
assert '570000000700000000"' in sp

# Frozen verified writer boundary.
sc=txt('app/src/main/java/com/okn/dsp/protocol/VerifiedScalarControls.kt')
ids=[int(x) for x in re.findall(r'VerifiedScalarControl\((\d+),',sc)]
assert ids==[2,3,8,9,10,13,11], ids
wg=txt('app/src/main/java/com/okn/dsp/protocol/WriteGate.kt')
assert 'const val enabled: Boolean = false' in wg
assert 'const val unifiedVerifiedScalarWritesEnabled: Boolean = true' in wg
assert 'const val unifiedVerifiedEqWritesEnabled: Boolean = true' in wg
lep=txt('app/src/main/java/com/okn/dsp/protocol/LiveEqPolicy.kt')
assert 'b.type == EqBandCodec.PEAKING_TYPE' in lep
assert 'MIN_FREQUENCY_HZ = 20.0f' in lep and 'MAX_FREQUENCY_HZ = 20000.0f' in lep
assert 'MIN_Q = 0.05f' in lep and 'MAX_Q = 20.0f' in lep

# BLE profile exact UUIDs.
bp=txt('app/src/main/java/com/okn/dsp/transport/BleProfile.kt')
for uuid in [
    '0000ab00-0000-1000-8000-00805f9b34fb',
    '0000ab01-0000-1000-8000-00805f9b34fb',
    '0000ab02-0000-1000-8000-00805f9b34fb',
    '0000ab03-0000-1000-8000-00805f9b34fb',
]: assert uuid in bp
assert '631C062443FD3844558001F3EDA0CCF8' in u

# Frozen verified protocol/transport hashes.
protocol_hashes={
"ConfirmedDspMap.kt":"6e68295f194dd0b0f70d0b83b9ba2324a9a2a8eaf2350b5d5a821f838ae2c66d",
"UfeCodec.kt":"b47f66afec8fd3383581c30b2dc1ad9ad41e3b7089f427f0b094e91581588c34",
"ProtocolSelfTest.kt":"8e1ea8beda03c2b90679a1af0a142a823be23e93481b124b981df768b0a9a0be",
"AuthSessionAnalyzer.kt":"63c8e8afcbc0fb5a2400a8e620932af72bec4d695463c8ed86b0c6bd5d507f7d",
"WriteGate.kt":"8aa82bb069dd64dc2d1274801f1f4420a764f52670246e9c813b0723531be472",
"ControlledCapture.kt":"0359e28b230618edfec7ed90d4f9a9cc116ce58f684ba640758ba22812e88776",
"ByteCodec.kt":"04843cec90b69886607d98a0aabf0ad81812fc8d25df913c5b1847a10fd7a3ae",
"EqBandCodec.kt":"4f033a406e363b2418af9b39fa2e42a13674b09f9de2bb7acf1eb6ff1918cd58",
"VerifiedScalarControls.kt":"4c096b001523704dcb6aa36496dd17263d6df84a0a1fee20c2fc40d60e898f6b",
"SessionCrypto.kt":"bae330efd6e9beb628b287e43e36bd98d80b3f9b4d1c014f65c63ef16efa586e",
"UfeConstants.kt":"e64de468c11d80ea052b97c9298a0a8a7f8cc49362f5bd06193d2c7c6d0108aa",
"SaveParamsPolicy.kt":"88005dba77d2b84597f5bd5e23eaaacec7d25b59dc0f38b8affbde2d2cfbeb85",
"SevenChannelEqMapPolicy.kt":"6dde7ec82e42f974fe5bde040447a6ba089a3795ed930164c2622f280fd39da4",
"FinalEqWriteRestorePolicy.kt":"41468a2f9b40511efe2e0384683eed42c60ee765222b5b4bb138b85e962180d7"
}
for name,h in protocol_hashes.items(): sha('app/src/main/java/com/okn/dsp/protocol/'+name,h)
transport_hashes={
"BleProfile.kt":"52f25f92e0dd5059417a894e0da7e58ea73de4505661e9b25e62e51e73d314a0",
"BleTransport.kt":"d44d661d0abe0e6dd7f3202011a97bab0de8f5e306ff70a1430ad02c9ccfc09b",
"DspTransport.kt":"1e2a2a54c2e31323da4bbc6f9efab01c2fdd2c2f2c9ebc8ee9d6f3e0ea1b6750"
}
for name,h in transport_hashes.items(): sha('app/src/main/java/com/okn/dsp/transport/'+name,h)

assert u.count('class MainActivity : Activity()')==1
assert u.count('override fun onDestroy()')==1
assert u.count('override fun onConfigurationChanged(newConfig: Configuration)')==1
balanced_kotlin(u)

print('V96 PREFLIGHT PASS')
print('structure=single direct MainActivity; no launcher trampoline; legacy mock-control pages removed')
print('ui=exact supplied five-screen verified-scope reference markers')
print('bluetooth=scan + tap connect + guarded GATT callbacks + automatic auth/session')
print('realtime=7 verified scalars + PEAKING F/Q/Gain; latest-target-wins; one-inflight; >=38ms')
print('master=app <-> Android STREAM_MUSIC <-> phone Volume +/- <-> verified ID2')
print('treble=ID11 callback-driven <=0.5dB step / 48ms nominal')
print('persistence=immediate local + automatic verified replay after fresh Health Gate')
print('saveParams=manual guarded one tap; exact trigger; never automatic')
print('unknown/non-PEAKING hardware writes=locked; no guessed packets')
