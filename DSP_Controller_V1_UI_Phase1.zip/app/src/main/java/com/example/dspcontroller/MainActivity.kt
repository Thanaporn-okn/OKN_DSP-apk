package com.example.dspcontroller

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.widget.*

class MainActivity: Activity(){
 override fun onCreate(b:Bundle?){
  super.onCreate(b)

  val root=LinearLayout(this)
  root.orientation=LinearLayout.VERTICAL
  root.setBackgroundColor(Color.rgb(10,14,20))

  fun text(s:String,size:Float):TextView{
   return TextView(this).apply{
    text=s
    textSize=size
    setTextColor(Color.WHITE)
    setPadding(20,15,20,15)
   }
  }

  root.addView(text("🔵 Connected\nBP1048P4 7CH DSP\nFW: 1.2.6",18f))
  root.addView(text("🔊 Master Volume     -12.5 dB     🔇 Mute",20f))
  root.addView(text("Preset: User 1        💾 Save DSP     📂 Read DSP",16f))

  val channels=arrayOf(
   "CH1\nFront L\n-2.0 dB",
   "CH2\nFront R\n-2.0 dB",
   "CH3\nSUB\n-5.0 dB",
   "CH4\nRear L\n-3.0 dB",
   "CH5\nRear R\n-3.0 dB",
   "CH6\nAUX L\n-6.0 dB",
   "CH7\nAUX R\n-6.0 dB"
  )

  channels.forEach{
   val bar=SeekBar(this)
   bar.max=60
   bar.progress=40
   root.addView(text(it,16f))
   root.addView(bar)
   root.addView(Button(this).apply{text="Mute"})
  }

  root.addView(text("🏠 MAIN     EQ     CROSSOVER     DELAY     MIXER     PRESET     SETTINGS",15f))
  setContentView(root)
 }
}
