package com.okn.dsp;

import android.content.Context;
import android.os.Build;
import android.view.InputDevice;
import android.view.KeyEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * V54 Android-framework InputDevice classifier.
 *
 * This class intentionally performs no USB I/O at all. V52 showed IF3 could not
 * be claimed with force=false and V53 showed its report descriptor cannot be
 * fetched without claim. V54 asks Android's already-bound input stack how it
 * classified devices with the board VID/PID instead of detaching any driver.
 */
public final class UsbAcpDiscovery {
    public static final int TARGET_VID = 0x6324;
    public static final int TARGET_PID = 0x1719;

    private UsbAcpDiscovery() {}

    public static String summary(Context context) {
        int matches = findMatchingInputDevices().size();
        return String.format(Locale.US, "%04X:%04X Android InputDevice matches=%d", TARGET_VID, TARGET_PID, matches);
    }

    public static String buildInputDeviceReport(Context context) {
        StringBuilder out = new StringBuilder(8192);
        out.append("OKN DSP V54 — Android InputDevice IF3 classifier\n")
                .append("SAFETY: USB open=0; USB permission request=0; claim=0; controlTransfer=0; bulk/interrupt transfer=0; USB OUT=0; ACP/UFE TX=0; DSP writes=0; SaveParams=0.\n")
                .append("This probe reads Android framework metadata only. It does not detach or communicate with the USB interfaces.\n\n");

        List<InputDevice> matches = findMatchingInputDevices();
        int[] allIds = InputDevice.getDeviceIds();
        out.append("Android InputDevice count=").append(allIds == null ? 0 : allIds.length).append('\n');
        out.append(String.format(Locale.US, "Target VID=%04X PID=%04X matchingInputDevices=%d\n\n", TARGET_VID, TARGET_PID, matches.size()));

        if (matches.isEmpty()) {
            out.append("RESULT: no Android InputDevice exposes the target VID/PID.\n")
                    .append("Interpretation: IF3 may still be owned by a kernel/system HID path that is not surfaced as an app-visible InputDevice, or VID/PID metadata may not be propagated.\n\n")
                    .append("External/non-virtual InputDevice inventory:\n");
            if (allIds != null) {
                for (int id : allIds) {
                    InputDevice d = InputDevice.getDevice(id);
                    if (d == null || d.isVirtual()) continue;
                    appendDeviceSummary(out, d, false);
                }
            }
        } else {
            int n=0;
            for (InputDevice d : matches) {
                out.append("[MATCH ").append(++n).append("]\n");
                appendDeviceSummary(out, d, true);
                appendKeyCapabilityProbe(out, d);
                out.append('\n');
            }
            out.append("classificationHint=").append(classificationHint(matches)).append('\n');
        }

        out.append("\nV54 COMPLETE: Android framework metadata only; USB/DSP state unchanged.\n")
                .append("Copy this full report for the IF3 ownership/classification decision.");
        return out.toString();
    }

    private static List<InputDevice> findMatchingInputDevices() {
        List<InputDevice> result = new ArrayList<>();
        int[] ids = InputDevice.getDeviceIds();
        if (ids == null) return result;
        for (int id : ids) {
            InputDevice d = InputDevice.getDevice(id);
            if (d == null) continue;
            if (d.getVendorId() == TARGET_VID && d.getProductId() == TARGET_PID) result.add(d);
        }
        return result;
    }

    private static void appendDeviceSummary(StringBuilder out, InputDevice d, boolean detailed) {
        out.append("id=").append(d.getId())
                .append(String.format(Locale.US, " vid=%04X pid=%04X", d.getVendorId(), d.getProductId()))
                .append(" name=").append(safe(d.getName()))
                .append(" sources=").append(String.format(Locale.US,"0x%08X",d.getSources()))
                .append(" sourcesDecoded=").append(decodeSources(d))
                .append(" keyboardType=").append(keyboardTypeName(d.getKeyboardType()))
                .append(" virtual=").append(d.isVirtual());
        if (Build.VERSION.SDK_INT >= 27) out.append(" enabled=").append(d.isEnabled());
        if (Build.VERSION.SDK_INT >= 29) out.append(" external=").append(d.isExternal());
        out.append('\n');
        if (detailed) {
            out.append("descriptor=").append(safe(d.getDescriptor())).append('\n')
                    .append("controllerNumber=").append(d.getControllerNumber()).append('\n')
                    .append("hasMicrophone=").append(d.hasMicrophone()).append('\n')
                    .append("motionRanges=").append(d.getMotionRanges()==null?0:d.getMotionRanges().size()).append('\n');
        }
    }

    private static void appendKeyCapabilityProbe(StringBuilder out, InputDevice d) {
        int[] keys = new int[] {
                KeyEvent.KEYCODE_VOLUME_UP,
                KeyEvent.KEYCODE_VOLUME_DOWN,
                KeyEvent.KEYCODE_VOLUME_MUTE,
                KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
                KeyEvent.KEYCODE_MEDIA_PLAY,
                KeyEvent.KEYCODE_MEDIA_PAUSE,
                KeyEvent.KEYCODE_MEDIA_NEXT,
                KeyEvent.KEYCODE_MEDIA_PREVIOUS,
                KeyEvent.KEYCODE_MEDIA_STOP,
                KeyEvent.KEYCODE_HEADSETHOOK,
                KeyEvent.KEYCODE_MUTE
        };
        String[] names = new String[] {
                "VOLUME_UP","VOLUME_DOWN","VOLUME_MUTE","MEDIA_PLAY_PAUSE","MEDIA_PLAY","MEDIA_PAUSE",
                "MEDIA_NEXT","MEDIA_PREVIOUS","MEDIA_STOP","HEADSETHOOK","MUTE"
        };
        boolean[] present;
        try { present = d.hasKeys(keys); }
        catch (RuntimeException e) {
            out.append("keyCapabilities=unavailable:").append(e.getClass().getSimpleName()).append('\n');
            return;
        }
        out.append("keyCapabilities=");
        boolean any=false;
        for (int i=0;i<names.length && i<present.length;i++) {
            if (!present[i]) continue;
            if (any) out.append(',');
            out.append(names[i]); any=true;
        }
        if (!any) out.append("none-of-probed-media-volume-keys");
        out.append('\n');
    }

    private static String classificationHint(List<InputDevice> matches) {
        boolean keyboard=false, gamepad=false, joystick=false, mouse=false, touch=false, mediaButtons=false;
        for (InputDevice d : matches) {
            keyboard |= d.supportsSource(InputDevice.SOURCE_KEYBOARD);
            gamepad |= d.supportsSource(InputDevice.SOURCE_GAMEPAD);
            joystick |= d.supportsSource(InputDevice.SOURCE_JOYSTICK);
            mouse |= d.supportsSource(InputDevice.SOURCE_MOUSE);
            touch |= d.supportsSource(InputDevice.SOURCE_TOUCHSCREEN) || d.supportsSource(InputDevice.SOURCE_TOUCHPAD);
            try {
                boolean[] b=d.hasKeys(KeyEvent.KEYCODE_VOLUME_UP,KeyEvent.KEYCODE_VOLUME_DOWN,KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
                        KeyEvent.KEYCODE_MEDIA_NEXT,KeyEvent.KEYCODE_MEDIA_PREVIOUS,KeyEvent.KEYCODE_HEADSETHOOK);
                for(boolean x:b) mediaButtons|=x;
            } catch (RuntimeException ignored) { }
        }
        if (mediaButtons && keyboard) return "BUTTON_OR_MEDIA_HID";
        if (keyboard) return "KEYBOARD_OR_BUTTON_HID";
        if (gamepad || joystick) return "GAME_CONTROLLER_HID";
        if (mouse || touch) return "POINTER_HID";
        return "APP_VISIBLE_INPUT_DEVICE_BUT_CLASS_UNRESOLVED";
    }

    private static String decodeSources(InputDevice d) {
        List<String> v=new ArrayList<>();
        if(d.supportsSource(InputDevice.SOURCE_KEYBOARD)) v.add("KEYBOARD");
        if(d.supportsSource(InputDevice.SOURCE_DPAD)) v.add("DPAD");
        if(d.supportsSource(InputDevice.SOURCE_GAMEPAD)) v.add("GAMEPAD");
        if(d.supportsSource(InputDevice.SOURCE_JOYSTICK)) v.add("JOYSTICK");
        if(d.supportsSource(InputDevice.SOURCE_MOUSE)) v.add("MOUSE");
        if(d.supportsSource(InputDevice.SOURCE_TOUCHSCREEN)) v.add("TOUCHSCREEN");
        if(Build.VERSION.SDK_INT>=18 && d.supportsSource(InputDevice.SOURCE_TOUCHPAD)) v.add("TOUCHPAD");
        return v.isEmpty()?"NONE/OTHER":join(v);
    }

    private static String keyboardTypeName(int t) {
        if(t==InputDevice.KEYBOARD_TYPE_ALPHABETIC) return "ALPHABETIC";
        if(t==InputDevice.KEYBOARD_TYPE_NON_ALPHABETIC) return "NON_ALPHABETIC";
        return "NONE";
    }

    private static String join(List<String> a) {
        StringBuilder b=new StringBuilder();
        for(String s:a){ if(b.length()>0)b.append('|'); b.append(s); }
        return b.toString();
    }
    private static String safe(String s){ return s==null?"<null>":s.replace('\n',' ').replace('\r',' '); }
}
