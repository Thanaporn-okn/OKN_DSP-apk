# OKN DSP V54

V54 removes the remaining Master-control lag seen in video 37840.

- Master dragging transmits only Master Volume actuator ID2 through the low-latency lane.
- Bass Volume actuator ID8 no longer competes with every Master MotionEvent.
- The Master/Bass rule is evaluated once when the Master gesture ends:
  - Master decreases: Bass Volume does not decrease.
  - Master increases: Bass Volume increases by the positive NET Master change for that gesture.
- Linked Bass is committed once after the final Master value, then ID8 readback verifies the DSP value.
- Realtime scalar minimum spacing is reduced from 55 ms to 35 ms while writes remain serialized.
- Manual Bass Volume, Band EQ, channel mapping, Safe Reset and Save/Restore behavior are otherwise unchanged.
