# OKN DSP V54 — Android InputDevice IF3 Classifier

V52 proved Android would not claim HID IF3 with `force=false`. V53 then proved a standard `GET_DESCRIPTOR(report)` on IF3 returns `-1` when the interface is left owned by the system. V54 therefore performs **no USB I/O at all**. Instead it asks Android's already-bound `InputDevice` framework how devices with the board identity `VID 0x6324 / PID 0x1719` are classified.

## What V54 reads

V54 enumerates Android `InputDevice` objects and, for exact VID/PID matches, records name, stable descriptor, source bitfield, decoded source classes, keyboard type, external/virtual/enabled flags, controller number, microphone flag, motion-range count, and support for common volume/media key codes. Android documents `getVendorId()`, `getProductId()`, `getSources()`, `getKeyboardType()` and `hasKeys()` as metadata/capability queries on input devices.

## Safety

V54 does not request USB permission, open a `UsbDeviceConnection`, claim or detach an interface, issue `controlTransfer`, `bulkTransfer`, `UsbRequest`, HID SET/GET reports, ACP/UFE frames, Device Description requests, actuator/gain/EQ/biquad/effect writes, or SaveParams. CH1/2/4/5/6/7 output sliders remain fail-closed; CH3/ID8 remains unchanged.
