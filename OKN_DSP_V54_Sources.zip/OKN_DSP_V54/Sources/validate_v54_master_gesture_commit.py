from pathlib import Path

root = Path(__file__).resolve().parents[1]
view = (root / 'app/src/main/java/com/okn/dsp/DspView.java').read_text()
ble = (root / 'app/src/main/java/com/okn/dsp/BleManager.java').read_text()
gradle = (root / 'app/build.gradle').read_text()


def req(ok, msg):
    if not ok:
        raise SystemExit('FAIL: ' + msg)
    print('PASS:', msg)

req('versionCode 1054' in gradle and "versionName '54.0.0'" in gradle, 'V54 package version')
req('masterLinkGestureActive' in view and 'masterLinkGestureStartDb' in view and 'bassLinkGestureStartDb' in view,
    'Master gesture baseline fields')
req('positiveNetMasterDelta = Math.max(0f, state.masterVolume - masterLinkGestureStartDb)' in view,
    'Bass link uses positive NET Master gesture delta')
req('linkedBass = clamp(bassLinkGestureStartDb + positiveNetMasterDelta, -70f, 70f)' in view,
    'ID8 auto headroom retained')
req('sendVerifiedScalar(DspProtocol.ID_MASTER_VOLUME, state.masterVolume);' in view,
    'Master realtime write retained')

master_start = view.index('if (s.type == SL_MASTER) {')
master_end = view.index('} else if (s.type == SL_BASS)', master_start)
master_block = view[master_start:master_end]
req('ID_BASS_VOLUME' not in master_block, 'Master drag sends no ID8 per MotionEvent')
req('finishMasterBassGestureLink();' in view and
    'sendVerifiedScalar(DspProtocol.ID_BASS_VOLUME, state.bassVolume);' in view,
    'Bass ID8 committed after gesture')
req('ble.flushScalarRealtime(DspProtocol.ID_MASTER_VOLUME);' in view and
    'ble.flushScalarRealtime(DspProtocol.ID_BASS_VOLUME);' in view,
    'Final ID2 then ID8 flush retained')
req('FINAL_SCALAR_MIN_GAP_MS = 35L' in ble, '35 ms serialized scalar lane')
req('Bass/Sub DSP Gain' not in view, 'No Band-EQ bass compensation UI')
req('V54 DSP SYNC' in view and 'V54 SYNCED' in ble, 'V54 runtime labels')
print('V54 validator OK')
