package com.okn.heavymarket.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val HeavyNavy = Color(0xFF082A4A)
val HeavyNavyDeep = Color(0xFF061D34)
val HeavyBlue = Color(0xFF1269E8)
val HeavyYellow = Color(0xFFFFC928)
val HeavyRed = Color(0xFFE53935)
val HeavySurface = Color(0xFFF6F8FB)
val HeavyText = Color(0xFF132238)
val HeavyMuted = Color(0xFF64748B)

private val LightColors = lightColorScheme(
    primary = HeavyBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDCE9FF),
    onPrimaryContainer = HeavyNavyDeep,
    secondary = HeavyNavy,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE7EEF6),
    onSecondaryContainer = HeavyNavyDeep,
    tertiary = HeavyYellow,
    onTertiary = HeavyNavyDeep,
    tertiaryContainer = Color(0xFFFFF2BF),
    onTertiaryContainer = HeavyNavyDeep,
    background = HeavySurface,
    onBackground = HeavyText,
    surface = Color.White,
    onSurface = HeavyText,
    surfaceVariant = Color(0xFFF0F3F7),
    onSurfaceVariant = HeavyMuted,
    outline = Color(0xFFD3DBE5),
    error = HeavyRed
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF7DB1FF),
    onPrimary = Color(0xFF002F65),
    primaryContainer = Color(0xFF0D4F99),
    onPrimaryContainer = Color(0xFFD7E7FF),
    secondary = Color(0xFFAAC7E8),
    onSecondary = HeavyNavyDeep,
    secondaryContainer = Color(0xFF15324C),
    onSecondaryContainer = Color(0xFFD7E8FA),
    tertiary = HeavyYellow,
    onTertiary = HeavyNavyDeep,
    tertiaryContainer = Color(0xFF5A4700),
    onTertiaryContainer = Color(0xFFFFE88C),
    background = Color(0xFF07131F),
    onBackground = Color(0xFFE7EDF5),
    surface = Color(0xFF0D1A27),
    onSurface = Color(0xFFE7EDF5),
    surfaceVariant = Color(0xFF172535),
    onSurfaceVariant = Color(0xFFBBC7D4),
    outline = Color(0xFF3D4B59),
    error = Color(0xFFFF8A80)
)

private val HeavyTypography = Typography(
    headlineLarge = TextStyle(fontSize = 30.sp, fontWeight = FontWeight.Bold),
    headlineMedium = TextStyle(fontSize = 24.sp, fontWeight = FontWeight.Bold),
    headlineSmall = TextStyle(fontSize = 21.sp, fontWeight = FontWeight.Bold),
    titleLarge = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.Bold),
    titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 16.sp),
    bodyMedium = TextStyle(fontSize = 14.sp),
    bodySmall = TextStyle(fontSize = 12.sp),
    labelLarge = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.SemiBold),
    labelMedium = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Medium),
    labelSmall = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Medium)
)

private val HeavyShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(30.dp)
)

@Composable
fun HeavyMarketTheme(forceDark: Boolean? = null, content: @Composable () -> Unit) {
    val dark = forceDark ?: isSystemInDarkTheme()
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        typography = HeavyTypography,
        shapes = HeavyShapes,
        content = content
    )
}
