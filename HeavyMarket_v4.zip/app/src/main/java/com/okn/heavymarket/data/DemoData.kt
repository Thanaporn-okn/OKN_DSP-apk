package com.okn.heavymarket.data

import com.okn.heavymarket.data.local.ProductEntity
import com.okn.heavymarket.domain.Deduplicator

object DemoData {
    private val now = System.currentTimeMillis()

    fun products(): List<ProductEntity> = listOf(
        item(
            id = "demo-hino",
            title = "Hino 6 ล้อ FC ปี 2018",
            desc = "ขาย Hino 6 ล้อ มือสอง พร้อมใช้ เจ้าของขายเอง เครื่องดี ช่วงล่างแน่น เอกสารพร้อมโอน",
            price = 650_000,
            category = "รถหกล้อ",
            province = "ขอนแก่น",
            brand = "Hino",
            model = "FC",
            year = 2018,
            minutesAgo = 25,
            image = "https://commons.wikimedia.org/wiki/Special:FilePath/2019%20Hino%20500%20Dominator%20FC9J%20Box%20Truck%20FC9JE1A-CXAHF.jpg?width=1200",
            seller = "สมชาย วงศ์ดี",
            group = "ตลาดรถบรรทุกมือสอง"
        ),
        item(
            id = "demo-komatsu",
            title = "Komatsu PC200-8 รถขุด",
            desc = "ขายด่วน Komatsu PC200-8 ชั่วโมงทำงาน 8,900 ชม. ระบบไฮดรอลิกดี พร้อมลงงาน",
            price = 1_200_000,
            category = "รถขุด",
            province = "นครราชสีมา",
            brand = "Komatsu",
            model = "PC200-8",
            year = 2015,
            minutesAgo = 80,
            image = "https://upload.wikimedia.org/wikipedia/commons/f/f4/Komatsu_PC200-8_Hydraulic_Excavator_-Rakhu_Bhagawati%2CMyagdi-0462.jpg",
            hours = "8,900 ชม.",
            seller = "ร้านเครื่องจักรโคราช",
            group = "ซื้อขายรถแม็คโครและเครื่องจักร"
        ),
        item(
            id = "demo-kubota",
            title = "Kubota M7040 รถไถ",
            desc = "รถไถ Kubota มือสอง พร้อมใช้งาน ระบบปกติ ยางสภาพดี เหมาะงานไร่และงานสวน",
            price = 295_000,
            category = "รถไถ",
            province = "อุดรธานี",
            brand = "Kubota",
            model = "M7040",
            year = 2017,
            minutesAgo = 130,
            image = "https://commons.wikimedia.org/wiki/Special:FilePath/Kubota%20M7-173%20Premium%20KVT%205D410071%202023%2009%2006%20JM.jpg?width=1200",
            seller = "เกษตรมือสองอีสาน",
            group = "ตลาดรถไถและอุปกรณ์เกษตร"
        ),
        item(
            id = "demo-isuzu",
            title = "Isuzu NPR 6 ล้อ ตู้แห้ง",
            desc = "ขาย Isuzu NPR ตู้แห้ง สภาพพร้อมวิ่ง ภายในตู้สะอาด เอกสารครบ พร้อมโอน",
            price = 790_000,
            category = "รถหกล้อ",
            province = "กรุงเทพมหานคร",
            brand = "Isuzu",
            model = "NPR",
            year = 2020,
            minutesAgo = 190,
            image = "https://commons.wikimedia.org/wiki/Special:FilePath/2024%20Isuzu%20NPR-HD%20Box%20Truck%20in%20Mineral%20White%2C%20front%20left%2C%202026-05-09.jpg?width=1200",
            seller = "NPR Truck Center",
            group = "รถบรรทุกมือสองทั่วไทย"
        ),
        item(
            id = "demo-cat",
            title = "CAT 320D Excavator",
            desc = "CAT 320D รถขุดมือสอง เครื่องแน่น ระบบปั๊มดี พร้อมทดลองงานและตรวจสภาพ",
            price = 1_650_000,
            category = "รถขุด",
            province = "ชลบุรี",
            brand = "CAT",
            model = "320D",
            year = 2014,
            minutesAgo = 245,
            image = "https://commons.wikimedia.org/wiki/Special:FilePath/Caterpillar%20320D%20p1.JPG?width=1200",
            hours = "10,200 ชม.",
            seller = "Eastern Heavy Machine",
            group = "ตลาดเครื่องจักรหนัก"
        ),
        item(
            id = "demo-dump",
            title = "รถดั้ม 10 ล้อ พร้อมใช้งาน",
            desc = "ขายรถดั้ม 10 ล้อ กระบะดั้มแข็งแรง ช่วงล่างแน่น เหมาะงานดินและงานก่อสร้าง",
            price = 980_000,
            category = "รถดั้ม",
            province = "สระบุรี",
            brand = "Hino",
            model = "Ranger",
            year = 2016,
            minutesAgo = 320,
            image = "https://commons.wikimedia.org/wiki/Special:FilePath/Customized%20Hino%20Ranger%20Dump%20Trucks%20For%20Sale%20in%20Thailand%2001.jpg?width=1200",
            seller = "สระบุรีทรัคมือสอง",
            group = "ซื้อขายรถดั้มทั่วประเทศ"
        )
    )

    private fun item(
        id: String,
        title: String,
        desc: String,
        price: Long,
        category: String,
        province: String,
        brand: String,
        model: String,
        year: Int,
        minutesAgo: Int,
        image: String,
        hours: String? = null,
        seller: String,
        group: String
    ): ProductEntity {
        val url = "https://example.com/demo/$id"
        return ProductEntity(
            id = id,
            title = title,
            description = desc,
            price = price,
            category = category,
            location = province,
            province = province,
            postedAt = now - minutesAgo * 60_000L,
            sourceId = "demo",
            sourceName = "ข้อมูลตัวอย่าง",
            sourceType = "DEMO",
            groupOrPageName = group,
            sellerId = "seller-$id",
            sellerName = seller,
            brand = brand,
            model = model,
            year = year,
            mileageOrHours = hours,
            imageUrls = image,
            originalUrl = url,
            classification = "SALE",
            classificationScore = 5.0,
            normalizedHash = Deduplicator.normalizedHash(title, desc, price, url),
            isDemo = true
        )
    }
}
