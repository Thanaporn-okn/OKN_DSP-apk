# Changelog

## v4 — 2026-09-20

- ปรับ UI จริงของแอปให้เป็น Heavy Market design system โทนน้ำเงินเข้ม + เหลือง แทน Material 3 ค่าเริ่มต้น
- เพิ่ม Splash screen พร้อมแบรนด์ Heavy Market และซ่อน Bottom Navigation ใน Splash/Product Detail
- ปรับหน้า “ล่าสุด” ให้มี branded header, search, category icon strip, demo warning แบบกระชับ และ product card ใหม่
- ปรับราคาจากรูปแบบ currency ที่มีทศนิยม เช่น `฿650,000.00` เป็น `฿650,000`
- เพิ่ม Favorite จากหน้า feed/Marketplace โดยตรง และแสดงสถานะหัวใจตาม Room favorites
- ปรับ Marketplace เป็น grid/list สองคอลัมน์แบบการ์ดสินค้า, recent search/recently viewed และ saved-search action
- ปรับ Product Detail เป็น hero image + overlay back/favorite/share, ราคาเด่น, seller card, specs และ related products
- ปรับ Settings/Groups/Saved ให้ใช้ visual language เดียวกันและลดความแน่นของ UI
- เปลี่ยน Demo image URLs ให้ตรงประเภทรถ/เครื่องจักรมากขึ้น และเพิ่ม `DEMO_IMAGE_CREDITS.md`
- เปลี่ยน launcher icon เป็นพื้นน้ำเงินเข้ม + รถสีเหลืองให้ตรงแบรนด์
- คง SDK fix จาก v3: `compileSdk = 37`, `compileSdkMinor = 2`, `targetSdk = 36` และ workflow ติดตั้ง `platforms;android-37.2` อัตโนมัติ

## v3 — 2026-09-20

- แก้ `checkDebugAarMetadata` ที่เกิดจาก AndroidX/Compose รุ่นปัจจุบันต้อง compile against API 37 ขึ้นไป
- ใช้ Android 17 minor SDK แบบใหม่: `compileSdk = 37` + `compileSdkMinor = 2` ขณะที่คง `targetSdk = 36` เพื่อไม่เปลี่ยน runtime opt-in โดยไม่จำเป็น
- Workflow อ่านทั้ง `compileSdk` และ `compileSdkMinor` แล้วติดตั้งแพ็กเกจ SDK แบบเต็ม เช่น `platforms;android-37.2` แทน `platforms;android-37` ที่ไม่มีใน repository รุ่นปัจจุบัน
- Workflow ตรวจรายการ stable packages จาก `sdkmanager --list --channel=0` ก่อนติดตั้ง และแสดงรายการ API ที่พบถ้าแพ็กเกจที่โปรเจกต์ต้องการไม่มี
- Build Tools ไม่ hard-code เป็น 36.0.0 อีกต่อไป; workflow เลือกรุ่น stable สูงสุดที่ตรงกับ compile SDK โดยอัตโนมัติ
- คงการเลือก Source ZIP เวอร์ชันใหม่สุด, auto version, unit tests, Debug APK และ optional signed Release APK

## v2 — 2026-09-20

- แก้ GitHub Actions ล้มที่ `platforms;android-37` โดยย้ายแอปไปใช้ Android 16 stable (`compileSdk = 36`, `targetSdk = 36`).
- Workflow ไม่ hard-code platform API อีกต่อไป แต่ตรวจ `compileSdk` จาก `app/build.gradle(.kts)` แล้วติดตั้ง SDK ที่ตรงกับโปรเจกต์อัตโนมัติ.
- ตรึง Android Command-line Tools revision 15859902 เพื่อหลีกเลี่ยง `sdkmanager` รุ่นเก่าที่ preinstalled บน runner.
- คงระบบเลือก ZIP เวอร์ชันใหม่สุด, auto version จาก GitHub Run Number, Unit Test, Debug APK และ optional signed Release APK.

## v1 — 2026-09-20

- สร้าง Native Android app ด้วย Kotlin, Jetpack Compose, Material 3, MVVM, Repository, Coroutines/Flow และ Hilt
- เพิ่ม Room database พร้อม Product, Source, GroupSource, Seller, Favorite, SavedSearch, SearchHistory, RecentlyViewed, SyncState, Category, KeywordRule และ PostClassification
- เพิ่ม Unified SALE Feed, Pull-to-refresh, incremental/infinite display, search/filter/sort และ offline cache
- เพิ่ม Groups fallback: Group URL list, search, Favorite, sync flag, Android Share-to-App และ Import URL/text
- เพิ่ม Marketplace-style screen: grid/list, search history, recently viewed, saved items/search, filters และ related products
- เพิ่ม Product Detail พร้อม seller/source/group fields, Favorite, Share, Open Original และ Report Incorrect Data
- เพิ่ม Rule-based `PostClassifier` สำหรับ SALE/RENTAL/WANTED/SERVICE/OTHER
- เพิ่ม `PriceParser` รองรับ 650,000 / 650000 / 650k / 6.5 แสน / 1.2 ล้าน / ฿
- เพิ่ม Include/Exclude keyword rules ที่ถูกนำไปใช้ตอน import/classify
- เพิ่ม normalized SHA-256 dedup + URL canonicalization + similarity scoring
- เพิ่ม natural-language price search เช่น `รถไถไม่เกิน 300000`
- เพิ่ม Saved Search notification ผ่าน WorkManager และ `lastNotifiedAt` ป้องกันแจ้งซ้ำ
- เพิ่ม DataStore สำหรับ Dark Mode / Notification settings
- เพิ่ม Retrofit/OkHttp API contract, Thai API error mapper และ WebSocket realtime client
- เพิ่ม Node.js + TypeScript backend reference พร้อม auth hook, normalization, classification, deduplication, pagination, saved searches, source adapters และ realtime events
- เพิ่ม Facebook Groups/Marketplace unavailable adapters โดยไม่สร้าง fake endpoint; Page provider ปิดไว้จนได้รับ Meta permissions/features จริง
- เพิ่ม GitHub Actions สำหรับ test + Debug APK, non-interactive SDK install, automatic versioning, artifact verification/upload และ optional signed Release
- ใช้ AGP 9.4.0 built-in Kotlin + Compose compiler plugin, KSP 2.3.10, Room 2.8.5, AndroidX Hilt 1.4.0
- เพิ่ม repository-local Gradle bootstrap สำหรับ Gradle 9.6.1 พร้อมตรวจ official distribution SHA-256
- เพิ่ม `BUILD_VALIDATION.md` ระบุผลตรวจจริงและข้อจำกัด environment โดยไม่อ้าง APK build สำเร็จเกินจริง
