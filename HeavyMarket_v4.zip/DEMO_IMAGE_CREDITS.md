# Demo image credits

Heavy Market v4 uses remote demo images to make the sample feed visually match the vehicle/machinery category. They are not Facebook images and are not bundled as user data.

Sources:
- Wikimedia Commons — `2019 Hino 500 Dominator FC9J Box Truck FC9JE1A-CXAHF.jpg`
- Wikimedia Commons — `Komatsu PC200-8 Hydraulic Excavator -Rakhu Bhagawati,Myagdi-0462.jpg`
- Wikimedia Commons — `Kubota M7-173 Premium KVT 5D410071 2023 09 06 JM.jpg`
- Wikimedia Commons — `2024 Isuzu NPR-HD Box Truck in Mineral White, front left, 2026-05-09.jpg`
- Wikimedia Commons — `Caterpillar 320D p1.JPG`
- Wikimedia Commons — `Customized Hino Ranger Dump Trucks For Sale in Thailand 01.jpg`

Each file remains subject to the license shown on its corresponding Wikimedia Commons file page. Production providers should supply the listing's own authorized image URLs.
