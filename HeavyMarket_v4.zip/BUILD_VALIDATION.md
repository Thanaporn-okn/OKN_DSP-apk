# BUILD VALIDATION — Heavy Market v4

วันที่ตรวจ: 2026-09-20

## สิ่งที่เปลี่ยนใน v4

v4 ต่อจาก v3 โดยไม่ย้อน SDK fix: ใช้ `compileSdk = 37`, `compileSdkMinor = 2`, `targetSdk = 36`, `minSdk = 26` และ GitHub Actions จะอ่านค่า major/minor จาก Gradle เพื่อขอติดตั้ง `platforms;android-37.2` อัตโนมัติ

รอบนี้เน้นปรับ UI จริงจาก APK ที่ผู้ใช้ส่งมา: Theme, Splash, Feed, Marketplace, Product Detail, Favorites, Settings, Bottom Navigation, ราคา และ Demo images

## ตรวจแล้วใน environment นี้

- Kotlin domain files compile สำเร็จด้วย annotation stubs เฉพาะ `javax.inject` เพื่อไม่ต้องพึ่ง Hilt/Android jars (`DOMAIN_COMPILE_OK`)
- Domain behavior smoke test ผ่าน (`DOMAIN_BEHAVIOR_OK`) สำหรับ PriceParser, SearchQueryParser และ SALE classifier
- ตรวจ Kotlin source ที่แก้ใหม่ว่า delimiter/วงเล็บสมดุล
- ใช้ `kotlinc` parse `AppUi.kt` / `Theme.kt`; ไม่พบ syntax error ก่อน unresolved Android/Compose symbols ซึ่งเป็นข้อจำกัดจากไม่มี Android classpath
- ตรวจ Android XML หลักด้วย XML parser
- ตรวจ GitHub Actions YAML ด้วย YAML parser
- ตรวจว่า workflow และ root `android-build.yml` เป็นไฟล์เดียวกัน
- ตรวจ wrapper JAR เปิดได้ และ shell syntax ของ `gradlew` ผ่าน
- ตรวจ backend TypeScript syntax/transpile ตามเครื่องมือที่มี
- ตรวจ ZIP หลังสร้างด้วย `unzip -t`

## ข้อจำกัดการตรวจ

container นี้ไม่มี Android SDK/Gradle dependency cache ครบ และไม่มี outbound network สำหรับดาวน์โหลด Android/Compose dependencies จึงไม่อ้างว่า APK v4 build สำเร็จในเครื่องนี้

GitHub Actions จะเป็น full build test จริงด้วย:

```bash
./gradlew --no-daemon clean testDebugUnitTest assembleDebug --stacktrace
```

เมื่อ build สำเร็จ workflow จะค้นหา APK ใน `app/build/outputs/apk/debug` และ upload Artifact โดยตั้งเวอร์ชันจาก GitHub Run Number อัตโนมัติ
