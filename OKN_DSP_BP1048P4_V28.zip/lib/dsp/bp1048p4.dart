// V28 DSP command interface
