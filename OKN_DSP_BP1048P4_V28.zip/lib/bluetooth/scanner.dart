// V28 Bluetooth Scanner
// Device discovery layer
