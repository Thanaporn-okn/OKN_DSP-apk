// V28 BP1048P4 TX RX packet handler
