// V28 Connect Disconnect handler
