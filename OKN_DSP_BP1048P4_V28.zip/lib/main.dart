import 'package:flutter/material.dart';

void main()=>runApp(const App());

class App extends StatelessWidget{
 const App({super.key});
 Widget build(BuildContext c)=>MaterialApp(
 debugShowCheckedModeBanner:false,
 theme:ThemeData.dark(),
 home:const Home());
}

class Home extends StatelessWidget{
 const Home({super.key});
 Widget build(BuildContext c)=>Scaffold(
 appBar:AppBar(title:const Text('OKN_DSP BP1048P4 V28')),
 body:ListView(padding:const EdgeInsets.all(20),children:const[
 Text('Bluetooth Scanner',
 style:TextStyle(fontSize:28,color:Colors.cyan)),
 SizedBox(height:20),
 Text('Scan Device\n'
 'Device List\n'
 'Connect / Disconnect\n'
 'Connection Status\n'
 'TX Command Queue\n'
 'RX Data Buffer\n'
 'HEX TX RX Monitor\n'
 'BP1048P4 Packet Handler',
 style:TextStyle(fontSize:18))
 ]));
}
