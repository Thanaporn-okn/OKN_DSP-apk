OKN DSP ANDROID V30 — SAME-SESSION AUTH VECTOR

Purpose
- Keep all verified UFE / EQ48 / post-auth AES-CFB8 behavior from V28/V29.
- Add the first clean same-session authentication proof from DOC-20260906-WA0007.zip.
- Keep LIVE WRITE disabled until the current RandKey can be independently derived from auth response32.

New same-session evidence (20:45:55)
- Auth request AB01 / 16B:
  631C062443FD3844558001F3EDA0CCF8
- Auth response AB02 / 32B:
  D024E38C00000000420DA6E8FDDF06895D514A274A2181DEB2F457CA70A60EC1
- Official-app runtime RandKey in the same session:
  0168DEEB916838D752E0D696BB3655E6
- Next encrypted AB01 request / 4B:
  5DFCB7E5
- AES-CFB8, key=RandKey, IV=01 repeated 16 bytes decrypts that 4B to:
  661C0624
- Device-description decode then succeeds in the official app (length 18150).

Auth vector status
- 4 exact response32 ↔ RandKey ↔ encrypted request pairs are now executable self-test vectors.
- response bytes 8..15 remain 420DA6E8FDDF0689.
- response[16] XOR RandKey[0] = 0x5C across all 4 paired vectors.
- Full XOR masks vary, which is consistent with a stateful transform but does not reveal the pre-auth secret/key by itself.

Safety
- WriteGate.enabled remains false.
- V30 does not guess or transmit DSP parameter commands.
- The remaining blocker is the independent pre-auth RandKey transform/key/IV/KDF.

Build
- Preferred: upload only OKN_DSP_ANDROID_V30_SAME_SESSION_AUTH_VECTOR.zip to the repo.
- Let .github/workflows/build-android-auto-latest.yml build it automatically.
- Do not start a second manual workflow unless the auto workflow fails.
