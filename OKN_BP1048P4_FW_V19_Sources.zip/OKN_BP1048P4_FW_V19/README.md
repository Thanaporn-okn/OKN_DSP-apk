# OKN_BP1048P4_FW_V19

V19 is the mobile-flash transaction-contract release built on the V18 content-bound
port-integration plan. The portable DSP/control core remains Protocol V2 at the wire
level: firmware version 19, protocol version 2. The wire frame remains Protocol V2.

## What V19 adds

V19 adds `mobile_flash_transaction.json` plus a non-executing verifier/reference
implementation. The transaction is SHA256-bound to both `port_integration_plan.json`
and `flash_session_manifest.json`, so a readiness change makes an old transaction
stale instead of silently carrying forward.

Before a future Android USB-OTG or verified vendor-OTA executor can even be armed,
the transaction contract requires a real original-firmware backup file and a real
candidate image file with hashes recomputed from disk, plus the already established
exact-target, board, programmer, image-format, recovery, power-safety, readback,
memory, and Android-host gates.

The required abstract order is:

`PREFLIGHT -> BACKUP_ORIGINAL -> VERIFY_BACKUP_HASH -> VERIFY_IMAGE_HASH -> ARM_EXTERNAL_EXECUTOR -> EXTERNAL_PROGRAM -> EXTERNAL_READBACK -> VERIFY_READBACK -> COMPLETE`

This is an ordering contract only. V19 intentionally contains **no destructive
executor**, no programmer command, no bootloader packet, no pin sequence, no target
address, and no flashable `.bin`/`.img` artifact. The shipped transaction is LOCKED.

## Safety status

- Exact BP1048P4 + GoloPine hardware port: LOCKED
- Hardware flashable: NO
- Android/mobile flashable: NO
- Destructive executor implemented: NO
- Unknown BP1048P4/GoloPine writes: NONE
- Unknown programmer/bootloader packets: NONE
- Legacy GoloPine SaveParams: NOT USED

Run `make host-test` for the full fail-closed validation suite.

See `docs/MOBILE_FLASH_TRANSACTION_V19.md`, `docs/PORT_INTEGRATION_PLAN_V18.md`,
`docs/QUALIFICATION_BUNDLE_V17.md`, and `docs/MOBILE_FLASH_GUARD_V10.md`.
