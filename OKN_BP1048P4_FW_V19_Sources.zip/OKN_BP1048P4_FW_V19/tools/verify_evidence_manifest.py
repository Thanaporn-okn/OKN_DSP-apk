#!/usr/bin/env python3
from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'evidence_manifest.json').read_text())
errors=[]
if m.get('schema')!=4: errors.append('evidence schema must be 4')
if m.get('project_version')!=19: errors.append('project_version must be 19')
if m.get('target')!='BP1048P4' or m.get('board')!='GoloPine 7CH': errors.append('target/board mismatch')
if m.get('policy')!='FAIL_CLOSED_NO_INFERENCE': errors.append('policy mismatch')
if m.get('hardware_authorized') is not False: errors.append('hardware_authorized must be false')
req=m.get('required_exact_evidence',{})
if any(bool(v) for v in req.values()): errors.append('V19 exact evidence flags must all remain false')
prov=m.get('provenance',{})
if prov.get('previous_source_sha256')!='3974dba9cf12dfacc24dec509a8b97ccd246b8ad6a2074565c0707834fd2d3f1': errors.append('V18 source provenance mismatch')
if prov.get('validation_zip_sha256')!='d9be5f1391f4b39f5004a6ce58ece20059a6be35c174875e308c40876aa2e887': errors.append('V18 validation provenance mismatch')
if not any(o.get('id')=='v18-ci-validation' for o in m.get('observations',[])): errors.append('V18 CI observation missing')
for ob in m.get('observations',[]):
    if ob.get('authorizes') not in ([],None): errors.append('observations may not authorize hardware in V19')
if errors:
    [print('BLOCKED:',e) for e in errors]; sys.exit(1)
print('PASS: V19 evidence manifest is internally consistent and non-authorizing')
