#!/usr/bin/env python3
"""V19 content-bound qualification evidence bundle verifier.

This tool never authorizes hardware. It only proves that a manifest entry is
bound to a concrete regular file inside the declared bundle root and that the
file's SHA256 matches the manifest. Review/classification are preserved as
metadata for the target qualification policy to consume separately.
"""
from __future__ import annotations
from pathlib import Path
import argparse, hashlib, json, re, sys

SHA256_RE = re.compile(r"^[0-9a-f]{64}$")

class BundleError(ValueError):
    pass

def _sha256(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024), b''):
            h.update(b)
    return h.hexdigest()

def verify_bundle(manifest: dict, project_root: Path) -> dict:
    errors=[]
    if manifest.get('schema') != 1: errors.append('bundle schema must be 1')
    if manifest.get('project_version') != 19: errors.append('bundle project_version must be 19')
    if manifest.get('target') != 'BP1048P4' or manifest.get('board') != 'GoloPine 7CH': errors.append('bundle target/board mismatch')
    if manifest.get('policy') != 'CONTENT_BOUND_HASH_VERIFIED_REVIEW_REQUIRED': errors.append('bundle policy mismatch')
    root_rel=manifest.get('bundle_root')
    if not isinstance(root_rel,str) or not root_rel or Path(root_rel).is_absolute() or '..' in Path(root_rel).parts:
        errors.append('bundle_root must be a safe relative path')
        bundle_root=project_root/'qualification_evidence'
    else:
        bundle_root=(project_root/root_rel).resolve()
    project_resolved=project_root.resolve()
    try:
        bundle_root.relative_to(project_resolved)
    except ValueError:
        errors.append('bundle_root escapes project root')
    artifacts=manifest.get('artifacts')
    if not isinstance(artifacts,list):
        errors.append('artifacts must be a list'); artifacts=[]
    seen_ids=set(); index={}
    for i,a in enumerate(artifacts):
        prefix=f'artifacts[{i}]'
        if not isinstance(a,dict): errors.append(prefix+' must be object'); continue
        aid=a.get('id')
        if not isinstance(aid,str) or not aid.strip(): errors.append(prefix+'.id missing'); continue
        if aid in seen_ids: errors.append(prefix+'.id duplicate: '+aid); continue
        seen_ids.add(aid)
        rel=a.get('path')
        if not isinstance(rel,str) or not rel or Path(rel).is_absolute() or '..' in Path(rel).parts:
            errors.append(prefix+'.path must be safe relative path'); continue
        declared=str(a.get('sha256') or '').lower()
        if not SHA256_RE.fullmatch(declared): errors.append(prefix+'.sha256 invalid'); continue
        if not str(a.get('source') or '').strip(): errors.append(prefix+'.source missing')
        classes=a.get('classifications')
        if not isinstance(classes,list) or not classes or any(not isinstance(x,str) or not x for x in classes):
            errors.append(prefix+'.classifications invalid')
        p=(bundle_root/rel)
        # Refuse symlinks at the leaf and at any existing parent below bundle_root.
        cur=p
        while True:
            if cur.exists() and cur.is_symlink():
                errors.append(prefix+'.path may not use symlinks'); break
            if cur == bundle_root or cur.parent == cur: break
            cur=cur.parent
        resolved=p.resolve(strict=False)
        try: resolved.relative_to(bundle_root)
        except ValueError:
            errors.append(prefix+'.path escapes bundle root'); continue
        if not p.exists() or not p.is_file():
            errors.append(prefix+'.file missing/not regular'); continue
        actual=_sha256(p)
        if actual != declared:
            errors.append(prefix+'.sha256 mismatch'); continue
        if a.get('reviewed') is not True:
            # A hash can be valid while review remains incomplete. Keep it out of the
            # verified index so no qualification claim can bind to it.
            continue
        index[aid]={
            'id':aid,
            'path':rel,
            'sha256':actual,
            'source':a.get('source'),
            'classifications':tuple(classes or ()),
            'reviewed':True,
        }
    return {'ok':not errors,'errors':errors,'verified_index':index,'bundle_root':str(bundle_root)}

def load_and_verify(manifest_path: Path, project_root: Path|None=None) -> dict:
    project_root=(project_root or manifest_path.parent).resolve()
    m=json.loads(manifest_path.read_text())
    return verify_bundle(m, project_root)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--manifest',default='qualification_bundle_manifest.json')
    ap.add_argument('--expect-empty',action='store_true')
    a=ap.parse_args()
    mp=Path(a.manifest).resolve(); result=load_and_verify(mp,mp.parent)
    for e in result['errors']: print('BLOCKED:',e)
    print('QUALIFICATION_BUNDLE_VERIFIED_ARTIFACTS='+str(len(result['verified_index'])))
    if not result['ok']: return 1
    if a.expect_empty and result['verified_index']:
        print('ERROR: shipped V19 bundle must remain empty/locked'); return 1
    print('PASS: V19 qualification evidence bundle is content-bound and hash-verified')
    return 0
if __name__=='__main__': raise SystemExit(main())
