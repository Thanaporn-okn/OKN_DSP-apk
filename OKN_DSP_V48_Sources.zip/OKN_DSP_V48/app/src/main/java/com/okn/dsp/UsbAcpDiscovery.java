package com.okn.dsp;

import android.content.Context;
import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * V48 USB/HID transport qualification for the real OKN BP1048P4 board.
 *
 * Hardware evidence from V46:
 *   VID 0x6324, PID 0x1719, HID interface 4, no interrupt endpoints.
 *
 * V48 is fail-closed and READ-ONLY:
 *   - may open the Android UsbDevice after explicit USB permission;
 *   - never uses HID SET_REPORT;
 *   - never sends ACP/UFE frames;
 *   - never writes an actuator or SaveParams;
 *   - never force-detaches a kernel driver;
 *   - only issues IN control requests: HID report descriptor and GET_REPORT.
 */
public final class UsbAcpDiscovery {
    public static final int TARGET_VID = 0x6324;
    public static final int TARGET_PID = 0x1719;
    public static final int TARGET_INTERFACE = 4;
    public static final int GENERIC_REPORT_SIZE = 256;

    private static final int USB_RECIP_INTERFACE = 0x01; // bmRequestType recipient: interface
    private static final int USB_REQ_GET_DESCRIPTOR = 0x06;
    private static final int HID_REQ_GET_REPORT = 0x01;
    private static final int HID_DT_REPORT = 0x22;
    private static final int HID_REPORT_TYPE_INPUT = 0x01;
    private static final int IO_TIMEOUT_MS = 1000;

    private UsbAcpDiscovery() {}

    public static UsbDevice findTarget(Context context) {
        UsbManager manager = (UsbManager) context.getSystemService(Context.USB_SERVICE);
        if (manager == null) return null;
        Map<String, UsbDevice> map = manager.getDeviceList();
        if (map == null || map.isEmpty()) return null;

        UsbDevice pid1719Fallback = null;
        for (UsbDevice d : map.values()) {
            if (d == null) continue;
            if (d.getVendorId() == TARGET_VID && d.getProductId() == TARGET_PID && hasTargetHidInterface(d)) {
                return d;
            }
            if (d.getProductId() == TARGET_PID && hasTargetHidInterface(d)) pid1719Fallback = d;
        }
        return pid1719Fallback;
    }

    public static String summary(Context context) {
        UsbManager manager = (UsbManager) context.getSystemService(Context.USB_SERVICE);
        if (manager == null) return "UsbManager unavailable";
        UsbDevice d = findTarget(context);
        if (d == null) return "target 0x6324:0x1719 IF4 not detected";
        return String.format(Locale.US, "%04X:%04X IF4 HID permission=%s",
                d.getVendorId(), d.getProductId(), manager.hasPermission(d) ? "yes" : "no");
    }

    public static String buildEnumerationReport(Context context) {
        UsbManager manager = (UsbManager) context.getSystemService(Context.USB_SERVICE);
        StringBuilder out = new StringBuilder(3072);
        out.append("OKN DSP V48 — USB/HID READ-ONLY qualification\n")
                .append("No SET_REPORT. No ACP/UFE write. No actuator write. No SaveParams.\n\n");
        if (manager == null) return out.append("UsbManager unavailable on this device.").toString();

        Map<String, UsbDevice> map = manager.getDeviceList();
        if (map == null || map.isEmpty()) {
            return out.append("No USB device detected.\n")
                    .append("Connect the powered DSP through USB host/OTG and scan again.")
                    .toString();
        }

        List<String> keys = new ArrayList<>(map.keySet());
        Collections.sort(keys);
        out.append("Detected devices: ").append(keys.size()).append("\n\n");
        int n = 0;
        for (String key : keys) {
            UsbDevice d = map.get(key);
            if (d == null) continue;
            n++;
            out.append('#').append(n).append(' ')
                    .append(String.format(Locale.US, "VID=%04X PID=%04X", d.getVendorId(), d.getProductId()))
                    .append(" devClass=").append(d.getDeviceClass())
                    .append(" ifaces=").append(d.getInterfaceCount())
                    .append(" permission=").append(manager.hasPermission(d) ? "yes" : "no")
                    .append(isExactTarget(d) ? "  <V48 TARGET>" : (isTransportCandidate(d) ? "  <candidate>" : ""))
                    .append('\n');
            appendInterfaces(out, d);
            out.append('\n');
        }
        return out.toString();
    }

    /**
     * Requires Android USB permission. This method performs only USB IN control requests.
     * It intentionally does not use SET_REPORT and does not place any ACP/UFE frame on the wire.
     */
    public static String buildReadOnlyHidProbe(Context context, UsbDevice requestedDevice) {
        UsbManager manager = (UsbManager) context.getSystemService(Context.USB_SERVICE);
        StringBuilder out = new StringBuilder(8192);
        out.append("OKN DSP V48 — IF4 HID READ-ONLY probe\n")
                .append("SAFETY: GET-only. SET_REPORT=0. ACP/UFE TX frames=0. DSP writes=0. SaveParams=0.\n\n");
        if (manager == null) return out.append("UsbManager unavailable.").toString();

        UsbDevice d = requestedDevice != null ? requestedDevice : findTarget(context);
        if (d == null) return out.append("Target 0x6324:0x1719 IF4 HID not detected.").toString();
        out.append(String.format(Locale.US, "Target VID=%04X PID=%04X interfaces=%d\n",
                d.getVendorId(), d.getProductId(), d.getInterfaceCount()));
        out.append("Profile match: PID 0x1719 + HID IF4; V46 board VID is 0x6324.\n");

        if (!manager.hasPermission(d)) {
            return out.append("USB permission=no. No device connection opened.\n").toString();
        }
        out.append("USB permission=yes\n");

        UsbInterface hid = findInterface(d, TARGET_INTERFACE);
        if (hid == null || hid.getInterfaceClass() != UsbConstants.USB_CLASS_HID) {
            return out.append("FAIL-CLOSED: interface 4 is missing or not HID. No control request sent.\n").toString();
        }
        out.append("IF4 class=HID sub=").append(hid.getInterfaceSubclass())
                .append(" proto=").append(hid.getInterfaceProtocol())
                .append(" endpoints=").append(hid.getEndpointCount()).append('\n');

        UsbDeviceConnection conn = manager.openDevice(d);
        if (conn == null) return out.append("openDevice failed. No USB transfer sent.\n").toString();

        boolean claimed = false;
        try {
            byte[] raw = conn.getRawDescriptors();
            out.append("\n[1] Android raw descriptors (cached/local API)\n");
            if (raw == null || raw.length == 0) {
                out.append("rawDescriptors unavailable\n");
            } else {
                out.append("rawLength=").append(raw.length).append('\n');
                appendDescriptorSummary(out, raw);
                out.append("rawPrefix=").append(hex(raw, Math.min(raw.length, 192))).append('\n');
            }

            // Never force-detach an Android/kernel HID driver in this diagnostic build.
            claimed = conn.claimInterface(hid, false);
            out.append("\nclaim IF4 force=false => ").append(claimed ? "OK" : "FAILED")
                    .append(" (force=true is intentionally forbidden)\n");
            if (!claimed) {
                out.append("FAIL-CLOSED: class-specific GET_REPORT skipped because IF4 was not claimed.\n")
                        .append("No SET_REPORT or ACP/UFE command was sent.\n");
                return out.toString();
            }

            out.append("\n[2] Standard HID report-descriptor GET (IN only)\n");
            byte[] reportDescriptor = new byte[512];
            int reportLen = conn.controlTransfer(
                    UsbConstants.USB_DIR_IN | UsbConstants.USB_TYPE_STANDARD | USB_RECIP_INTERFACE,
                    USB_REQ_GET_DESCRIPTOR,
                    HID_DT_REPORT << 8,
                    TARGET_INTERFACE,
                    reportDescriptor,
                    reportDescriptor.length,
                    IO_TIMEOUT_MS);
            out.append("GET_DESCRIPTOR(report) result=").append(reportLen).append('\n');
            if (reportLen > 0) {
                out.append("reportDescriptor=").append(hex(reportDescriptor, Math.min(reportLen, 384))).append('\n');
            } else {
                out.append("No report descriptor returned.\n");
            }

            out.append("\n[3] HID GET_REPORT cached baseline (IN only; no preceding SET_REPORT)\n");
            byte[] input = new byte[GENERIC_REPORT_SIZE];
            int inputLen = conn.controlTransfer(
                    UsbConstants.USB_DIR_IN | UsbConstants.USB_TYPE_CLASS | USB_RECIP_INTERFACE,
                    HID_REQ_GET_REPORT,
                    HID_REPORT_TYPE_INPUT << 8,
                    TARGET_INTERFACE,
                    input,
                    input.length,
                    IO_TIMEOUT_MS);
            out.append("GET_REPORT result=").append(inputLen)
                    .append(" requested=").append(GENERIC_REPORT_SIZE).append('\n');
            if (inputLen > 0) {
                out.append("inputReport=").append(hex(input, Math.min(inputLen, 384))).append('\n');
                if (inputLen >= 4 && (input[0] & 0xFF) == 0xA5 && (input[1] & 0xFF) == 0x5A) {
                    out.append("ACP-like A5 5A framing observed in cached input report.\n");
                } else {
                    out.append("No A5 5A ACP framing asserted from this cached baseline.\n");
                }
            } else {
                out.append("No cached input report returned. This is not a write failure.\n");
            }

            out.append("\nV48 COMPLETE: SET_REPORT=0; ACP/UFE TX=0; DSP state unchanged by this diagnostic.\n")
                    .append("Copy this full report for the next protocol decision.");
            return out.toString();
        } catch (RuntimeException e) {
            out.append("\nProbe exception: ").append(e.getClass().getSimpleName()).append('\n')
                    .append("Still no SET_REPORT/ACP/UFE write path exists in V48.\n");
            return out.toString();
        } finally {
            if (claimed) {
                try { conn.releaseInterface(hid); } catch (RuntimeException ignored) { }
            }
            conn.close();
        }
    }

    private static void appendInterfaces(StringBuilder out, UsbDevice d) {
        for (int i = 0; i < d.getInterfaceCount(); i++) {
            UsbInterface f = d.getInterface(i);
            out.append("  IF ").append(f.getId())
                    .append(" class=").append(f.getInterfaceClass())
                    .append(" sub=").append(f.getInterfaceSubclass())
                    .append(" proto=").append(f.getInterfaceProtocol())
                    .append(" eps=").append(f.getEndpointCount());
            if (f.getInterfaceClass() == UsbConstants.USB_CLASS_HID) out.append(" HID");
            if (f.getInterfaceClass() == UsbConstants.USB_CLASS_VENDOR_SPEC) out.append(" VENDOR");
            out.append('\n');
            for (int e = 0; e < f.getEndpointCount(); e++) {
                UsbEndpoint ep = f.getEndpoint(e);
                out.append("    EP ").append(String.format(Locale.US, "0x%02X", ep.getAddress()))
                        .append(' ')
                        .append(ep.getDirection() == UsbConstants.USB_DIR_IN ? "IN" : "OUT")
                        .append(" type=").append(ep.getType())
                        .append(" maxPacket=").append(ep.getMaxPacketSize())
                        .append('\n');
            }
        }
    }

    private static void appendDescriptorSummary(StringBuilder out, byte[] raw) {
        int p = 0;
        int currentIf = -1;
        while (p + 2 <= raw.length) {
            int len = raw[p] & 0xFF;
            int type = raw[p + 1] & 0xFF;
            if (len < 2 || p + len > raw.length) {
                out.append("  malformed descriptor at ").append(p).append(" len=").append(len).append('\n');
                break;
            }
            if (type == 0x04 && len >= 9) {
                currentIf = raw[p + 2] & 0xFF;
                int alt = raw[p + 3] & 0xFF;
                int eps = raw[p + 4] & 0xFF;
                int cls = raw[p + 5] & 0xFF;
                out.append("  IF descriptor id=").append(currentIf)
                        .append(" alt=").append(alt).append(" eps=").append(eps)
                        .append(" class=").append(cls).append('\n');
            } else if (type == 0x21 && len >= 9) {
                int reportType = raw[p + 6] & 0xFF;
                int reportLen = (raw[p + 7] & 0xFF) | ((raw[p + 8] & 0xFF) << 8);
                out.append("  HID descriptor on IF").append(currentIf)
                        .append(" childType=0x").append(String.format(Locale.US, "%02X", reportType))
                        .append(" reportLen=").append(reportLen).append('\n');
            } else if (type == 0x05 && len >= 7) {
                int addr = raw[p + 2] & 0xFF;
                int attr = raw[p + 3] & 0x03;
                int max = (raw[p + 4] & 0xFF) | ((raw[p + 5] & 0xFF) << 8);
                out.append("  EP descriptor IF").append(currentIf)
                        .append(" addr=0x").append(String.format(Locale.US, "%02X", addr))
                        .append(" type=").append(attr).append(" maxPacket=").append(max).append('\n');
            }
            p += len;
        }
    }

    private static UsbInterface findInterface(UsbDevice d, int id) {
        for (int i = 0; i < d.getInterfaceCount(); i++) {
            UsbInterface f = d.getInterface(i);
            if (f.getId() == id) return f;
        }
        return null;
    }

    private static boolean hasTargetHidInterface(UsbDevice d) {
        UsbInterface f = findInterface(d, TARGET_INTERFACE);
        return f != null && f.getInterfaceClass() == UsbConstants.USB_CLASS_HID;
    }

    private static boolean isExactTarget(UsbDevice d) {
        return d.getVendorId() == TARGET_VID && d.getProductId() == TARGET_PID && hasTargetHidInterface(d);
    }

    private static boolean isTransportCandidate(UsbDevice d) {
        if (d.getProductId() == TARGET_PID && hasTargetHidInterface(d)) return true;
        for (int i = 0; i < d.getInterfaceCount(); i++) {
            int cls = d.getInterface(i).getInterfaceClass();
            if (cls == UsbConstants.USB_CLASS_HID || cls == UsbConstants.USB_CLASS_VENDOR_SPEC) return true;
        }
        return false;
    }

    private static String hex(byte[] data, int length) {
        if (data == null || length <= 0) return "";
        int n = Math.min(length, data.length);
        StringBuilder s = new StringBuilder(n * 2);
        for (int i = 0; i < n; i++) s.append(String.format(Locale.US, "%02X", data[i] & 0xFF));
        return s.toString();
    }
}
