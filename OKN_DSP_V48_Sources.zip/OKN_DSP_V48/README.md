# OKN DSP V48 — BP1048P4 USB/HID Read-Only Qualification

V48 follows the real V45 hardware result: even a 12-byte B0/B1/B2-only biquad update still produced an audible click. Therefore CH1/CH2/CH4/CH5/CH6/CH7 output-volume writes remain disabled. CH3 continues to use the hardware-qualified BassVolume scalar ID8.

## Real V46 hardware discovery

The user's board enumerated as:

- VID `0x6324`
- PID `0x1719`
- 7 USB interfaces
- HID interface 3 with interrupt IN endpoint `0x81` / 64 bytes
- HID interface 4 with **no interrupt endpoints**

The V46 report prints VID/PID in hexadecimal (`%04X`).

An independent BP10/BP1048 Generic ACP implementation uses PID `0x1719`, HID interface 4 and a 256-byte HID report through control transfers. Its reference VID is different (`0x8888`), so V48 does not assume vendor equivalence; it qualifies the real `0x6324:0x1719` board before any ACP request is transmitted.

## V48 probe safety

The Mix page button is `USB HID READ-ONLY PROBE`. After Android USB permission is granted, V48:

1. opens only the detected `0x6324:0x1719` device (fallback requires PID `0x1719` + HID IF4),
2. reads Android raw USB descriptors,
3. claims IF4 with `force=false` only,
4. performs a standard HID report-descriptor **IN** request,
5. performs one 256-byte HID `GET_REPORT` **IN** request to inspect the cached baseline,
6. releases IF4 and closes the device.

V48 contains no HID `SET_REPORT`, no ACP/UFE transmit frame, no actuator write, no biquad output-volume write, and no SaveParams path in this diagnostic. If IF4 cannot be claimed without forcing, V48 stops before the class-specific read.

The GET_REPORT baseline can be empty or stale because no request frame precedes it. The goal is transport qualification, not DSP-state interpretation.

See `Sources/V48_USB_HID_READONLY_QUALIFICATION.txt`.
