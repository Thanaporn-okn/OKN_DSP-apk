# OKN DSP V48

V48 is based on the validated V47 build and changes **only the Bass Volume controller maximum** to match the latest real-board test.

## V48 audio change
- Bass Volume stays on the existing UFE scalar actuator **ID 8 / BassVolume**.
- Controller range is **`0..+40 dB`**.
- The upper limit is reduced from V47's `+74 dB` UI range because the latest real-board test found the effective adjustment reaches its full useful level at about **`+40 dB`**.
- Default/Reset Bass Volume remains `+2 dB`.
- Master Volume remains `-70..+6 dB`.
- **BassBoost ID10 is not used or repurposed.**
- **No EQ actuator mapping, EQ gain/F/Q range, coefficient formula, 48-byte EQ writer, EQ cadence, or Safe Reset behavior is changed.**
- Save DSP / SaveParams ID7 behavior is unchanged.

The stock device descriptor in `Sources/ProtocolEvidence/` is kept unchanged. V48 changes only the Android controller's allowed BassVolume ID8 range; it does not rewrite the board descriptor.

## Build
GitHub Actions workflow: `.github/workflows/OKN_DSP_AutoBuild.yml`. It auto-selects the newest packaged source/repo tree, validates SHA256 + DSP safety invariants, installs Android SDK packages/licenses, builds the signed Release APK and uploads APK + SHA256.
