# OKN DSP V48 — Correct EQ Channel Order

V48 keeps the verified V47 BassVolume ID8 path unchanged (-70..+24 dB, 0.5 dB steps, DSP readback) and corrects only the EQ channel presentation so the UI follows the real device descriptor.

Verified EQ order from the supplied device description:

- Ch1 — Left (`BiquadCascadeLeftChannel`, actuator ID4)
- Ch2 — Right (`BiquadCascadeRightChannel`, actuator ID5)
- Ch3 — Bass / Subwoofer (`BiquadCascadeBassChannel`, actuator ID6)
- Ch4 — 4th Channel (`BiquadCascade4thChannel`, actuator ID14)
- Ch5 — 5th Channel (`BiquadCascade5thChannel`, actuator ID15)
- Ch6 — 6th Channel (`BiquadCascade6thChannel`, actuator ID16)
- Ch7 — 7th Channel (`BiquadCascade7thChannel`, actuator ID17)

No EQ actuator order is changed: `EQ_ACTUATORS` remains `{4, 5, 6, 14, 15, 16, 17}`. No Bass Volume, Master Volume, EQ packet encoding, or save/restore behavior is changed by V48.
