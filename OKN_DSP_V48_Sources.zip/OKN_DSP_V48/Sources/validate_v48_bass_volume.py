#!/usr/bin/env python3
from pathlib import Path
import hashlib

root = Path(__file__).resolve().parents[1]
ble = (root/'app/src/main/java/com/okn/dsp/BleManager.java').read_text()
view = (root/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
proto = (root/'app/src/main/java/com/okn/dsp/DspProtocol.java').read_text()
state = (root/'app/src/main/java/com/okn/dsp/DspState.java').read_text()
gradle = (root/'app/build.gradle').read_text()

def method(text, marker):
    i = text.index(marker)
    b = text.index('{', i)
    depth = 0
    for j in range(b, len(text)):
        if text[j] == '{': depth += 1
        elif text[j] == '}':
            depth -= 1
            if depth == 0: return text[i:j+1]
    raise AssertionError('unclosed method ' + marker)

def sha(s):
    return hashlib.sha256(s.encode()).hexdigest()

rt_enqueue = method(ble, '    private void enqueueEqLatest(')
sh_enqueue = method(ble, '    private void enqueueEqShapeLatest(')
rt_pump = method(ble, '    private void scheduleEqRealtimePump(')
sh_pump = method(ble, '    private void scheduleEqShapePump(')
guard = method(ble, '    private boolean isHiFiAudioGuardActive(')

checks = {
    'V48 version': "versionCode 1048" in gradle and "versionName '48.0.0'" in gradle,
    'verified EQ mapping': 'static final int[] EQ_ACTUATORS = {4, 5, 6, 14, 15, 16, 17};' in proto,
    'V44 8s audio guard retained': 'AUDIO_GUARD_HOLD_MS = 8000L' in ble and '(now - lastMusicActiveUptimeMs) < AUDIO_GUARD_HOLD_MS' in guard,
    'normal scheduler remains 380ms': 'ORIGINAL_COMMAND_CADENCE_MS = 380L' in ble,
    'no-music gain lane remains 45ms': 'EQ_REALTIME_MIN_GAP_MS = 45L' in ble,
    'no-music shape lane remains 110ms': 'EQ_SHAPE_MIN_GAP_MS = 110L' in ble,
    'music EQ settle is 380ms': 'EQ_INTERACTIVE_MUSIC_SETTLE_MS = 380L' in ble,
    'music EQ min gap is 380ms': 'EQ_INTERACTIVE_MUSIC_MIN_GAP_MS = 380L' in ble,
    'gain enqueue stamps newest interaction': 'lastEqInteractiveTargetUptimeMs = SystemClock.uptimeMillis();' in rt_enqueue,
    'shape enqueue stamps newest interaction': 'lastEqInteractiveTargetUptimeMs = SystemClock.uptimeMillis();' in sh_enqueue,
    'gain pump waits trailing edge': 'EQ_INTERACTIVE_MUSIC_SETTLE_MS' in rt_pump and '- (now - lastEqInteractiveTargetUptimeMs)' in rt_pump,
    'gain pump music-spaces writes': 'musicGuardActive ? EQ_INTERACTIVE_MUSIC_MIN_GAP_MS : EQ_REALTIME_MIN_GAP_MS' in rt_pump,
    'shape pump waits trailing edge': 'EQ_INTERACTIVE_MUSIC_SETTLE_MS' in sh_pump and '- (now - lastEqInteractiveTargetUptimeMs)' in sh_pump,
    'shape pump music-spaces writes': 'musicGuardActive ? EQ_INTERACTIVE_MUSIC_MIN_GAP_MS : EQ_SHAPE_MIN_GAP_MS' in sh_pump,
    'reset no-music baseline remains 110ms': 'EQ_RESET_MIN_GAP_MS = 110L' in ble,
    'reset music cadence remains 380ms': 'EQ_RESET_MUSIC_MIN_GAP_MS = 380L' in ble,
    'reset bypasses interactive settle': '!eqResetActive && musicGuardActive' in rt_pump,
    'no CH fake slider': 'SL_CHANNEL' not in view,
    'CH gain remains locked': 'GAIN LOCKED' in view,
    'SaveParams remains manual ID7': 'static final int ID_SAVE_PARAMS = 7;' in proto and 'void requestPersistentSave()' in ble,
    'BassVolume remains ID8': 'static final int ID_BASS_VOLUME = 8;' in proto,
    'BassBoost remains separate ID10': 'static final int ID_BASS_BOOST = 10;' in proto,
    'Bass effective max is +40 only': 'static final float BASS_VOLUME_EXTENDED_MAX_DB = 40f;' in proto,
    'Bass min is 0 dB': 'static final float BASS_VOLUME_MIN_DB = 0f;' in proto,
    'Master remains +6 max': 'case ID_MASTER_VOLUME:' in proto and 'case ID_REMIND_SOUND:' in proto and 'lo = -70f; hi = 6f; break;' in proto,
    'ID8 sanitizer uses extended range': 'case ID_BASS_VOLUME:' in proto and 'lo = BASS_VOLUME_MIN_DB; hi = BASS_VOLUME_EXTENDED_MAX_DB; break;' in proto,
    'state loads extended Bass range': 'prefs.getFloat("bassVolume", 2f), DspProtocol.BASS_VOLUME_MIN_DB, DspProtocol.BASS_VOLUME_EXTENDED_MAX_DB' in state,
    'state setter uses extended Bass range': 'bassVolume = clamp(value, DspProtocol.BASS_VOLUME_MIN_DB, DspProtocol.BASS_VOLUME_EXTENDED_MAX_DB);' in state,
    'preset restore uses extended Bass range': 'Float.parseFloat(parts[1]), DspProtocol.BASS_VOLUME_MIN_DB, DspProtocol.BASS_VOLUME_EXTENDED_MAX_DB' in state,
    'Bass UI uses extended ID8 range': 'DspProtocol.BASS_VOLUME_MIN_DB, DspProtocol.BASS_VOLUME_EXTENDED_MAX_DB, SL_BASS, -1' in view,
    'Bass UI sends ID8': 'sendVerifiedScalar(DspProtocol.ID_BASS_VOLUME, state.bassVolume);' in view,
    'Bass UI never sends ID10': 'sendVerifiedScalar(DspProtocol.ID_BASS_BOOST' not in view,
}

# V48 preserves V47/V46/V45 EQ behavior. Freeze the verified target builders,
# transport writer, reset body, and coefficient/packet encoders to their V44 values.
expected = {
    'BleManager.setEqRealtime':'f4f738c886298e476dad58135a5d29b36937aaa7dbf7eabe7853dc8d9e761c9a',
    'BleManager.setEqShapeRealtime':'e702693eccb788da71d156db94dc21824f1dacab20d19e1d89aaedceb94a6110',
    'BleManager.sendScheduledControl':'8c39c0643084615777997900f428e3c32971bdd5e2afa0d768c04c4dbfedf777',
    'BleManager.writeNoResponse':'e6895bee7c3f2d12c2531d7d48346559d6b00a4c227b38ecfc63f2ce2a9d9256',
    'BleManager.resetEqSafe':'eab920cc4b25b018c9e263f1a43bf4391569119663db101954a2661803864d18',
    'DspProtocol.peakingFromCurrent':'18f6cb0577c711ea817c8441f4b3b2fc91a4a5d5bae0d61051926074858b95ae',
    'DspProtocol.peakingShapeFromCurrent':'e3f8d840e116bc3d32bad459db3883867f8afc62a87c8553131397ee133e4e86',
    'DspProtocol.firstBandGainFromCurrent':'89f089d8d8bc6bfd54074e35e949fa393719d64d3884fc8ce133b99bc100ddee',
    'DspProtocol.encodeEqWrite':'9de90148f2e6f390f9144ffc8f6c029a00ca6276bdeb8696aa319609573001e5',
}
for name, text, marker in [
    ('BleManager.setEqRealtime', ble, '    void setEqRealtime('),
    ('BleManager.setEqShapeRealtime', ble, '    void setEqShapeRealtime('),
    ('BleManager.sendScheduledControl', ble, '    private void sendScheduledControl('),
    ('BleManager.writeNoResponse', ble, '    private boolean writeNoResponse('),
    ('BleManager.resetEqSafe', ble, '    int resetEqSafe('),
    ('DspProtocol.peakingFromCurrent', proto, '    static EqBand peakingFromCurrent('),
    ('DspProtocol.peakingShapeFromCurrent', proto, '    static EqBand peakingShapeFromCurrent('),
    ('DspProtocol.firstBandGainFromCurrent', proto, '    static EqBand firstBandGainFromCurrent('),
    ('DspProtocol.encodeEqWrite', proto, '    static byte[] encodeEqWrite('),
]:
    body = method(text, marker)
    if name in ('BleManager.setEqRealtime','BleManager.setEqShapeRealtime','BleManager.resetEqSafe'):
        body = body.replace(' || saveActive', '')
    checks['frozen '+name] = sha(body) == expected[name]

failed = [k for k,v in checks.items() if not v]
for k,v in checks.items():
    print(('PASS' if v else 'FAIL'), k)
if failed:
    raise SystemExit('V48 validation failed: ' + ', '.join(failed))
print('V48_BASS_VOLUME_ID8_0_TO_40_PASS')
