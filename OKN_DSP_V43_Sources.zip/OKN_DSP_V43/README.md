# OKN DSP V43

Package base: **V41 guarded Save/Restore**, inheriting **V40 real-hardware stable (user-tested normal)** behavior.

V40 adds **automatic DSP readback/synchronization** without changing the V39 hardware writer. After initial connection, reconnect, or manual refresh, the authenticated fresh Device Description is treated as the authoritative snapshot. The UI is updated with current Master/Bass/BassCutoff and all 7 x 15 EQ Frequency/Q/Gain values, writable locks are rebuilt, then the synchronized state is checkpointed locally.

Safety boundary: readback callbacks do not echo values back to the DSP; no new actuator mapping or packet format is introduced; SaveParams is never automatic; V38 safe-PEQ gating and V39 Gain-only Safe Reset remain unchanged.

Version: **43.0.0** (`versionCode 1043`)


## V43 radio-quiet audio fix

V43 removes the last recurring BLE traffic that V42 still generated while idle:

- After authenticated Device Description sync, **no periodic sensor polls are sent at all**.
- The 380 ms scalar scheduler is retained for user controls, but an idle scheduler tick performs no GATT/BLE operation.
- The steady-state GATT connection requests **LOW_POWER** priority after sync to reduce BLE airtime/coexistence pressure while music is playing.
- Manual Refresh/Restore remain available and perform explicit authenticated readback only when requested.
- EQ Gain remains 45 ms, Frequency/Q remains 110 ms, Safe Reset remains 110 ms; EQ math and packet formats are unchanged.

This is a more aggressive follow-up to V42 for hardware that still stutters with a 1.52-second background poll.


## V41 guarded persistent save
See `Sources/V41_GUARDED_SAVE_RESTORE.txt`. V41 is based only on V40 and adds a manual-only verified SaveParams transaction plus readback-only Restore.
