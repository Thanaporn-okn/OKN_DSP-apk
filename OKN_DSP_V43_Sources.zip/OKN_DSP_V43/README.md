# OKN DSP V43

V43 keeps the V42 guarded TRUE CH1–CH7 Volume implementation unchanged and fixes the release/build infrastructure so it no longer depends on version-named validators. `Sources/validate_release.py` now derives the release number from `Sources/VERSION.txt`; the reusable GitHub Actions workflow always calls that stable validator entry point.

**EQ safety:** no EQ runtime source was modified for V43. Channel Volume still requires exact custom-firmware actuators IDs 22..28 / Channel1Volume..Channel7Volume; stock firmware stays LOCKED/fail-closed.

# OKN DSP V42

V42 adds guarded TRUE CH1–CH7 volume −/+ controls without using or modifying EQ as channel gain.
On stock firmware the controls stay LOCKED because the stock Device Description has no dedicated channel-volume actuators.
When OKN custom firmware exposes the exact seven FLOAT32 actuators IDs 22..28 / Channel1Volume..Channel7Volume, the controls become active automatically.

# OKN DSP V41

Base: **V40 real-hardware stable (user-tested normal)**.

V40 adds **automatic DSP readback/synchronization** without changing the V39 hardware writer. After initial connection, reconnect, or manual refresh, the authenticated fresh Device Description is treated as the authoritative snapshot. The UI is updated with current Master/Bass/BassCutoff and all 7 x 15 EQ Frequency/Q/Gain values, writable locks are rebuilt, then the synchronized state is checkpointed locally.

Safety boundary: readback callbacks do not echo values back to the DSP; no new actuator mapping or packet format is introduced; SaveParams is never automatic; V38 safe-PEQ gating and V39 Gain-only Safe Reset remain unchanged.

Version: **41.0.0** (`versionCode 1041`)


## V41 guarded persistent save
See `Sources/V41_GUARDED_SAVE_RESTORE.txt`. V41 is based only on V40 and adds a manual-only verified SaveParams transaction plus readback-only Restore.
