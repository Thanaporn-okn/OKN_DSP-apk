# OKN DSP V43

V43 fixes the audible stutter found during the first real-DSP V42 Channel 1 volume test. The hardware result is important: **CH1 Band1.G really changes channel output level and the EQ tone does not change.** Therefore the mapping is retained.

The V42 problem was transport behavior, not the mapping: CH1/2/4/5/6/7 were sending full 48-byte Band1 records as fast as the 45 ms EQ-Gain lane while the finger moved. V43 keeps the UI responsive but commits **one final non-CH3 channel-volume record on finger release/tap**, and channel-trim records use a conservative **>=380 ms** cadence matching the original-app control scheduler evidence. CH3 continues to use the proven **ID8 BassVolume** scalar path.

No new actuator IDs or packet formats are introduced. V41 guarded Save/Restore, V40 readback, V39 Safe Reset, V38 strict-safe PEQ 55/55 and the existing F/Q/Gain Band writers remain in place.

Version: **43.0.0** (`versionCode 1043`)

Current proof/test notes:
- `Sources/V43_CHANNEL_TRIM_STUTTER_FIX.txt`
- `Sources/V43_VALIDATION_PROOF.txt`
- `Sources/V43_REAL_DSP_TEST_PLAN.txt`
- `Sources/validate_v43_channel_trim.py`

V43 is a real-DSP test candidate. V41 remains the safe rollback baseline until V43 is confirmed smooth on hardware.
