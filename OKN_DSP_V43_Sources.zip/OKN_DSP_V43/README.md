# OKN DSP V43

V43 is the anti-pop / smooth-response update for **Out Volume Ch1-Ch7** based on the real-hardware V42 test video.

- **CH3:** remains on the hardware-confirmed `BassVolume` actuator **ID8**.
- **CH1, CH2, CH4, CH5, CH6, CH7:** keep the V42 descriptor-derived first EQ record `G` (cell-gain) carrier on EQ actuators 4, 5, 14, 15, 16, 17. No new actuator ID is invented.
- V42 could jump tens of dB in one 48-byte biquad write because it sent only the newest target every 380 ms. V43 replaces that direct jump with a dedicated serialized ramp.
- Each non-CH3 hardware write advances by **at most 1 dB** from the last successfully confirmed DSP value and uses the already proven **45 ms** full-record pacing.
- The latest touch value wins. A fast swipe no longer causes one large coefficient jump; the hardware catches up smoothly after the finger moves.
- Out Volume uses the BassVolume descriptor range **-70 dB to +6 dB** and now follows its **1 dB increment** (`incmt=1`).
- The first EQ record still preserves live F/F2/Q/B/R and filter type; only `G` plus the matching numerator coefficients change.
- EQ Gain/F/Q, guarded Save/Restore, authenticated readback, and the V38/V39 safety gates stay intact.

Important qualification boundary: CH3/ID8 is hardware-confirmed. The `G` carrier for CH1/2/4/5/6/7 is descriptor/math-grounded and V42 hardware testing showed that it changes output level, but V43's anti-pop ramp still needs a fresh real-DSP listening test.

See `Sources/V43_ANTI_POP_OUT_VOLUME.txt`.
