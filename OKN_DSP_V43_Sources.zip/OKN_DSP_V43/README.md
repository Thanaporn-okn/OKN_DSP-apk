# OKN DSP V43

Base: **V42 audio-stability controls + V41 guarded Save/Restore + V40 real-hardware stable DSP writer**.

V43 keeps the V42 BLE/audio coexistence changes and updates the controls requested from real-device testing.

## EQ channel order
The EQ page now follows the real descriptor order exactly: **CH1=ID4 Left, CH2=ID5 Right, CH3=ID6 Bass, CH4=ID14, CH5=ID15, CH6=ID16, CH7=ID17**. The previous guessed speaker-position names are removed. Each selected channel shows its real actuator ID and descriptor-derived channel name.

Band navigation remains sorted by actual readback frequency while writes still target the original hardware band slot. EQ actuator IDs, 15-band record format, filter math, Gain/Frequency/Q limits and safe-row gate are unchanged.

## Bass Volume
`Bass Volume` is now a direct **0 dB to +100 dB** slider for actuator **ID8**; there is no 0–100 level remapping. Negative ID8 readback down to -70 dB is still accepted so the app can display the device's existing state before the user moves the slider.

The supplied descriptor advertises ID8 as -70..+6 dB, but this V43 range intentionally follows the user's real-device test that values above +6 dB are accepted. Master Volume remains limited to -70..+6 dB and EQ Gain remains -12..+12 dB. Very high positive gain can cause clipping or stress downstream audio hardware.

## No Bass Boost control
The added Bass Boost UI has been removed. V43 does not write BassBoost ID10 from Mix/Reset Global. ID10 is retained only in the underlying descriptor inventory/readback path so the existing complete-DSP validation can still verify all seven scalar actuators.

## Audio stability / fidelity
V42's reduced idle BLE polling, GATT overlap guard and throttled/finalized EQ writes remain in place. This project is still a BLE controller for an external DSP rather than an Android PCM decoder/player; the filter model remains at the verified 44.1 kHz sample rate.

Version: **43.0.0** (`versionCode 1043`)

See `Sources/V43_EQ_CHANNEL_BASS_VOLUME.txt` and run `Sources/validate_v43_controls.py` for the V43 static checks.
