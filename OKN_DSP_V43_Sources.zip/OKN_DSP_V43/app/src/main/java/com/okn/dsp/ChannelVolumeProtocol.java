package com.okn.dsp;

/**
 * V42 dedicated output-channel volume protocol for OKN custom firmware only.
 *
 * This namespace is intentionally separate from the stock EQ actuators. The writer
 * is enabled only after the live Device Description exposes all seven exact
 * Channel1Volume..Channel7Volume FLOAT32 actuators.
 */
final class ChannelVolumeProtocol {
    static final int CHANNELS = 7;
    static final int[] IDS = {22, 23, 24, 25, 26, 27, 28};
    static final float MIN_DB = -70f;
    static final float MAX_DB = 6f;
    static final float STEP_DB = 0.5f;

    private ChannelVolumeProtocol() {}

    static int actuatorId(int channel0) {
        if (channel0 < 0 || channel0 >= CHANNELS) return -1;
        return IDS[channel0];
    }

    static String actuatorName(int channel0) {
        return channel0 >= 0 && channel0 < CHANNELS ? "Channel" + (channel0 + 1) + "Volume" : "";
    }

    static int channelForActuator(int id, String name, int type, boolean hasFloat32) {
        if (type != DspProtocol.TYPE_FLOAT32 || !hasFloat32 || name == null) return -1;
        for (int ch = 0; ch < CHANNELS; ch++) {
            if (id == IDS[ch] && actuatorName(ch).equals(name)) return ch;
        }
        return -1;
    }

    static float sanitize(float value) {
        if (!Float.isFinite(value) || value < MIN_DB || value > MAX_DB) return Float.NaN;
        return Math.round(value / STEP_DB) * STEP_DB;
    }

    static byte[] encodeWrite(int channel0, float value) {
        int id = actuatorId(channel0);
        float safe = sanitize(value);
        if (id < 0 || !Float.isFinite(safe)) throw new IllegalArgumentException("channel volume");
        return DspProtocol.encodeFloatWrite(id, safe);
    }
}
