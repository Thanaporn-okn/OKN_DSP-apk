#!/usr/bin/env python3
from pathlib import Path
import re, sys

ROOT = Path(__file__).resolve().parents[1]
BLE = ROOT / 'app/src/main/java/com/okn/dsp/BleManager.java'
GRADLE = ROOT / 'app/build.gradle'
ble = BLE.read_text()
gradle = GRADLE.read_text()

def method(text, marker):
    i = text.index(marker); b = text.index('{', i); depth = 0
    for j in range(b, len(text)):
        if text[j] == '{': depth += 1
        elif text[j] == '}':
            depth -= 1
            if depth == 0: return text[i:j+1]
    raise AssertionError('unclosed method ' + marker)

def req(cond, msg):
    if not cond:
        print('FAIL:', msg)
        sys.exit(1)

req('versionCode 1043' in gradle and "versionName '43.0.0'" in gradle, 'V43 version mismatch')
req('ORIGINAL_COMMAND_CADENCE_MS = 380L' in ble, 'scalar cadence changed')
req('EQ_REALTIME_MIN_GAP_MS = 45L' in ble, 'Gain cadence changed')
req('EQ_SHAPE_MIN_GAP_MS = 110L' in ble, 'F/Q cadence changed')
req('EQ_RESET_MIN_GAP_MS = 110L' in ble, 'Reset cadence changed')
req('IDLE_POLL_CADENCE_MS' not in ble, 'legacy idle poll cadence still present')
req('ORIGINAL_POLL_IDS' not in ble and 'ORIGINAL_POLL_LENGTHS' not in ble, 'legacy poll tables still present')
req('"POLL_"' not in ble, 'poll write label still reachable')

tick = method(ble, '    private void originalCommandSchedulerTick(')
req('DspProtocol.encodeRead' not in tick, 'idle scheduler still encodes sensor reads')
req('writeNoResponse' not in tick, 'idle scheduler still writes a background GATT packet')
req('Manual Refresh/Restore' in tick, 'radio-quiet rationale missing')

load = method(ble, '    private void loadDescriptor(')
req('CONNECTION_PRIORITY_LOW_POWER' in load, 'steady-state LOW_POWER priority missing')

# Startup remains BALANCED for auth/descriptor reliability.
conn = method(ble, '        @Override public void onConnectionStateChange(')
req('CONNECTION_PRIORITY_BALANCED' in conn, 'startup BALANCED priority changed')

# Read path must still exist for manual refresh/restore and descriptor synchronization.
req('DspProtocol.DEVICE_DESCRIPTION_REQUEST' in ble, 'descriptor read request removed')
req('requestDspRefresh' in ble and 'requestVerifiedRestore' in ble, 'manual readback controls removed')

print('V43_RADIO_QUIET_STATIC_PASS')
print('idlePolls=OFF steadyPriority=LOW_POWER scalarMs=380 gainMs=45 shapeMs=110 resetMs=110')
