#!/usr/bin/env python3
from pathlib import Path
import hashlib, re, sys

ROOT = Path(__file__).resolve().parents[1]
BLE = ROOT / 'app/src/main/java/com/okn/dsp/BleManager.java'
GRADLE = ROOT / 'app/build.gradle'
ble = BLE.read_text()
gradle = GRADLE.read_text()

def method(text, marker):
    i = text.index(marker); b = text.index('{', i); depth = 0
    for j in range(b, len(text)):
        if text[j] == '{': depth += 1
        elif text[j] == '}':
            depth -= 1
            if depth == 0: return text[i:j+1]
    raise AssertionError('unclosed method ' + marker)

def req(cond, msg):
    if not cond:
        print('FAIL:', msg)
        sys.exit(1)

def sha(s): return hashlib.sha256(s.encode()).hexdigest()

req("versionCode 1042" in gradle and "versionName '42.0.0'" in gradle, 'V42 version mismatch')
req('IDLE_POLL_CADENCE_MS = ORIGINAL_COMMAND_CADENCE_MS * 4L' in ble, 'idle poll throttle missing')
req('ORIGINAL_COMMAND_CADENCE_MS = 380L' in ble, 'scalar scheduler cadence changed')
req('EQ_REALTIME_MIN_GAP_MS = 45L' in ble, 'Gain cadence changed')
req('EQ_SHAPE_MIN_GAP_MS = 110L' in ble, 'F/Q cadence changed')
req('EQ_RESET_MIN_GAP_MS = 110L' in ble, 'Safe Reset cadence changed')
req('private static final int[] ORIGINAL_POLL_IDS = {19, 20, 0, 21};' in ble, 'poll IDs/order changed')
req('private static final int[] ORIGINAL_POLL_LENGTHS = {1, 1, 4, 4};' in ble, 'poll lengths changed')

tick = method(ble, '    private void originalCommandSchedulerTick(')
req('now - lastIdlePollUptimeMs < IDLE_POLL_CADENCE_MS' in tick, 'idle poll throttle not applied in scheduler')
req('liveWriteBusy = true;' in tick and 'liveInflight = null;' in tick, 'poll does not acquire shared transport gate')
req('writeNoResponse(encrypted, label, null)' in tick, 'poll write path changed unexpectedly')
req(tick.index('writeNoResponse(encrypted, label, null)') < tick.index('originalPollIndex = (originalPollIndex + 1)'), 'poll index advances before accepted GATT write')
req('DSP sensor poll callback timeout' in tick, 'poll callback timeout missing')

result = method(ble, '    private void handleWriteResult(')
req('ticket.label.startsWith("POLL_")' in result, 'poll callback branch missing')
req('cancelLiveTimeout();' in result, 'poll timeout not cancelled')
req('liveWriteBusy = false;' in result, 'poll shared transport gate not released')
req('scheduleEqRealtimePump(0L)' in result, 'pending Gain queue not resumed after poll')
req('scheduleEqShapePump(0L)' in result, 'pending F/Q queue not resumed after poll')

# Frozen V41 writer methods remain byte-for-byte at their qualified bodies.
expected = {
'BleManager.scheduleEqRealtimePump':'a05ea21d9f11980fff095c6053ec81ccd5c7ba5d7a725ff2854f3f2a87bf6db6',
'BleManager.scheduleEqShapePump':'97a5c9080071ec5bce70999d2c7a122ad2e2a77d494a94f1040fd90662c4e26e',
'BleManager.sendScheduledControl':'8c39c0643084615777997900f428e3c32971bdd5e2afa0d768c04c4dbfedf777',
'BleManager.writeNoResponse':'e6895bee7c3f2d12c2531d7d48346559d6b00a4c227b38ecfc63f2ce2a9d9256',
}
checks = [
('BleManager.scheduleEqRealtimePump', '    private void scheduleEqRealtimePump('),
('BleManager.scheduleEqShapePump', '    private void scheduleEqShapePump('),
('BleManager.sendScheduledControl', '    private void sendScheduledControl('),
('BleManager.writeNoResponse', '    private boolean writeNoResponse('),
]
for name, marker in checks:
    req(sha(method(ble, marker)) == expected[name], name + ' changed')

print('V42_AUDIO_STABILITY_STATIC_PASS')
print('idlePollMs=1520 scalarSchedulerMs=380 gainMs=45 shapeMs=110 resetMs=110')
