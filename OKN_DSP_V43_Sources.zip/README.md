# OKN DSP V43

Base: **V42 verified Out Volume mapping + V41 guarded Save/Restore/readback**.

V43 keeps the real seven-channel Out Volume mapping from V42: channel cascade actuator IDs `4,5,6,14,15,16,17`, first-record offset `0`, native `G` (cell gain), 48-byte full-record write. No ChannelVolume actuator is invented.

The hardware test of V42 proved that the mapping changes real output level, but repeated first-record writes while a finger was dragging caused audible level pumping/ripple. V43 therefore changes only the touch policy: the slider and dB value preview continuously on-screen, but the DSP receives **one final Out Volume write when the finger is released**. A tap also commits once immediately. The existing latest-wins queue and >=120 ms safe pacing remain as a transport guard for the final write and reset operations.

DSP readback remains authoritative on connect/reconnect/refresh. CH3 Band1 and Out Volume Ch3 intentionally mirror the same native General Low-pass `G` field. V38 safe-PEQ gating, V39 Safe Reset EQ, V40 readback, and V41 guarded Save/Restore remain unchanged.

Version: **43.0.0** (`versionCode 1043`).
