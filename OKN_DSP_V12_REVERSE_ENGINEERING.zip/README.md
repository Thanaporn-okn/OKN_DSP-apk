# OKN DSP V12 Reverse Engineering Lab

V12 วิเคราะห์จากข้อมูลที่รวบรวมได้จริง

ยืนยัน:
- Service AB00
- AB01 READ/WRITE
- AB02/AB03 NOTIFY
- TX 16 bytes, RX 32 bytes ที่พบ
- bulk notification 18,252 bytes = 77×235 + 157

ยังไม่ยืนยัน:
opcode/header, checksum/MAC, encryption/key, coefficient format,
endianness, coefficient order, bytes/stage, padding, address formula,
และ cascade=channel

V12 ทำ:
- scan/connect อุปกรณ์จริง
- discover GATT
- เปิด AB02/AB03 Notify
- READ AB01
- capture raw packets
- copy ผลเพื่อวิเคราะห์

ไม่มีการส่ง payload ควบคุม DSP ที่ยังไม่พิสูจน์
