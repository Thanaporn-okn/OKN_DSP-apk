

## V19 controlled-capture guard
The Android lab now models BASELINE / SINGLE_PARAMETER_DIFF / REPEAT_SESSION explicitly.
A parameter-diff record is accepted only when device, firmware, official-app version, raw capture reference, and distinct old/new values are present. This is evidence bookkeeping only; it does not decode or transmit DSP packets.
