# วิธีสร้าง APK ด้วยมือถือ

1. สร้าง GitHub repository ใหม่ เช่น `OKN-DSP-V24`.
2. แตก ZIP นี้ในมือถือ แล้วอัปโหลดไฟล์ทั้งหมดจากรากโปรเจกต์ขึ้น repository.
3. ตรวจว่ามีโฟลเดอร์ `.github/workflows/` และไฟล์ `build-android.yml`.
4. เปิดแท็บ **Actions** ใน GitHub.
5. เลือก **Build Android APK**.
6. กด **Run workflow**.
7. เมื่อ build สำเร็จ เปิดงานรอบนั้นแล้วดาวน์โหลด artifact ชื่อ `OKN-DSP-V24-controller-debug-apk`.
8. แตก artifact จะได้ `app-debug.apk` สำหรับติดตั้งใน Android.

หมายเหตุ: V24 เชื่อม BLE และรับข้อมูลได้ แต่ยังไม่ส่ง Gain/EQ/Delay ไป DSP เพราะคำสั่ง write จริงยังไม่ผ่าน evidence gate.
