# OKN DSP V20 — Reference Profile / Evidence Gate

## Purpose
V20 adds provenance control so protocol observations from different GoloPine app/firmware profiles cannot be silently merged.

## Official-source finding
GoloPine's official 7-channel DSP page lists an Android Audio Turning release marked **Latest 1Apr2026**.
Official page:
https://golodsp.com/7%E9%80%9A%E9%81%93%E9%9F%B3%E9%A2%91%E5%89%8D%E7%BA%A7/

The linked artifact is:
https://golodsp.com/wp-content/uploads/2026/05/golopine_audio_turning_release_2026-04-01.apk_.zip

The 2026-04-01 binary is NOT available in the working evidence bundle yet, therefore no SHA-256 or protocol claims are assigned to it.

## Existing 250401 profile
Reference APK SHA-256:
`b1700436077aa0dcebf3fd8bc509a7a377c2eb9b62c9cb96980a5fe0bbd0fddb`

## Evidence rule
- 250401 and 2026-04-01 are separate profiles until the actual binary/capture proves equivalence.
- Never combine UUIDs, authentication observations, packet layouts, actuator IDs, or serializer findings across profiles without an explicit match.
- Unknown artifact hash is represented as null, not guessed.
- UFE/DSP write remains disabled.

## Current hard gate
Writes require independently verified:
1. UFE framing
2. integrity/check mechanism
3. encryption/key derivation
4. actuator mapping
5. EQ/actuator serializer
