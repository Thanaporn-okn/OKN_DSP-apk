# Protocol Evidence Manifest V21

## Purpose
V21 adds timestamp-based TX/RX correlation to the passive evidence lab.

## New analysis
- Parse capture timestamps and packet lengths.
- Separate TX_* and RX_* records.
- Count RX packets occurring within 10, 50, 200, and 1000 ms after each TX.
- Show first-following-RX candidates with delta time and byte prefixes.
- Preserve the rule that temporal proximity is correlation evidence only, not semantic packet mapping.

## Confirmed evidence retained
- AB00 service / AB01 write / AB02 and AB03 notification roles for the observed profile.
- 16B -> 32B -> 4B -> 18,252B observed sequence.
- UFE IDs are static-analysis identifiers, not wire-layout proof.

## Still unproven
- Exact UFE framing and field order.
- Encryption mode/key derivation/integrity.
- Device descriptor plaintext on the wire.
- Actuator IDs/paths for CH1-CH7.
- SigmaDSP coefficient byte order/scaling.

## Write policy
DSP/UFE actuator writes remain disabled.
