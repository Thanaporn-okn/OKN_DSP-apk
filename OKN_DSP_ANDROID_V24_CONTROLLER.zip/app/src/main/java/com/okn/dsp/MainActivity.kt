package com.okn.dsp

import android.Manifest
import android.app.Activity
import android.bluetooth.*
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import com.okn.dsp.protocol.WriteGate
import com.okn.dsp.transport.BleProfile
import java.util.UUID
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private enum class Page { MAIN, EQ, XOVER, DELAY, MIXER, PRESET }

    private data class ChannelState(
        var gainTenths: Int = 0,
        var mute: Boolean = false,
        var phase180: Boolean = false,
        var delayHundredthsMs: Int = 0,
        var hpfHz: Int = 20,
        var lpfHz: Int = 20000,
        val eqTenths: IntArray = IntArray(15)
    )

    private val channels = Array(7) { ChannelState() }
    private val eqFreqs = intArrayOf(25, 40, 63, 100, 160, 250, 400, 630, 1000, 1600, 2500, 4000, 6300, 10000, 16000)
    private var selectedChannel = 0
    private var page = Page.MAIN
    private var pendingChanges = 0

    private lateinit var root: LinearLayout
    private lateinit var body: LinearLayout
    private lateinit var status: TextView
    private lateinit var channelSpinner: Spinner
    private lateinit var deviceList: LinearLayout

    private val handler = Handler(Looper.getMainLooper())
    private val found = LinkedHashMap<String, BluetoothDevice>()
    private var scanner: BluetoothLeScanner? = null
    private var gatt: BluetoothGatt? = null
    private var rxPackets = 0
    private var connectedName: String? = null
    private val subscribed = mutableSetOf<UUID>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadLastState()
        buildUi()
        requestBlePermissions()
    }

    override fun onDestroy() {
        super.onDestroy()
        try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
        try { gatt?.close() } catch (_: Exception) {}
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 20, 22, 28)
        }

        root.addView(TextView(this).apply {
            text = "OKN DSP 7CH Controller — V24"
            textSize = 23f
        })

        status = TextView(this).apply {
            text = safeStatusText("DISCONNECTED")
            textSize = 14f
            setPadding(0, 8, 0, 10)
        }
        root.addView(status)

        val connectRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        connectRow.addView(Button(this).apply {
            text = "SCAN / CONNECT DSP"
            setOnClickListener { startScan() }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        connectRow.addView(Button(this).apply {
            text = "EVIDENCE LAB"
            setOnClickListener { startActivity(Intent(this@MainActivity, EvidenceLabActivity::class.java)) }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(connectRow)

        deviceList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(deviceList)

        val channelRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        channelRow.addView(TextView(this).apply {
            text = "CHANNEL  "
            textSize = 16f
        })
        channelSpinner = Spinner(this)
        val names = (1..7).map { "CH$it" }
        channelSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        channelSpinner.setSelection(selectedChannel)
        channelSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedChannel = position
                renderPage()
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
        }
        channelRow.addView(channelSpinner, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(channelRow)

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(
            "MAIN" to Page.MAIN,
            "EQ" to Page.EQ,
            "XOVER" to Page.XOVER,
            "DELAY" to Page.DELAY,
            "MIXER" to Page.MIXER,
            "PRESET" to Page.PRESET
        ).forEach { (label, target) ->
            tabs.addView(Button(this).apply {
                text = label
                setOnClickListener { page = target; renderPage() }
            })
        }
        root.addView(HorizontalScrollView(this).apply { addView(tabs) })

        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 12, 0, 12)
        }
        root.addView(body)

        root.addView(TextView(this).apply {
            text = "ความปลอดภัย: ตอนนี้ปุ่ม/สไลเดอร์เก็บค่าในแอปก่อน ยังไม่ส่งคำสั่ง Gain/EQ/Delay ไป DSP จนกว่าจะยืนยัน framing + authentication/encryption + actuator mapping จาก capture จริง"
            textSize = 12f
        })

        setContentView(ScrollView(this).apply { addView(root) })
        renderPage()
    }

    private fun renderPage() {
        if (!::body.isInitialized) return
        body.removeAllViews()
        val ch = channels[selectedChannel]
        body.addView(TextView(this).apply {
            text = "CH${selectedChannel + 1} • ${page.name}"
            textSize = 20f
            setPadding(0, 4, 0, 8)
        })
        when (page) {
            Page.MAIN -> renderMain(ch)
            Page.EQ -> renderEq(ch)
            Page.XOVER -> renderXover(ch)
            Page.DELAY -> renderDelay(ch)
            Page.MIXER -> renderMixer()
            Page.PRESET -> renderPresets()
        }
    }

    private fun renderMain(ch: ChannelState) {
        val gainLabel = valueLabel("GAIN", ch.gainTenths / 10.0, "dB")
        body.addView(gainLabel)
        body.addView(SeekBar(this).apply {
            max = 720
            progress = ch.gainTenths + 600
            setOnSeekBarChangeListener(simpleSeek { p ->
                ch.gainTenths = p - 600
                gainLabel.text = valueText("GAIN", ch.gainTenths / 10.0, "dB")
                changed()
            })
        })

        body.addView(Switch(this).apply {
            text = "MUTE"
            isChecked = ch.mute
            setOnCheckedChangeListener { _, v -> ch.mute = v; changed() }
        })
        body.addView(Switch(this).apply {
            text = "PHASE 180°"
            isChecked = ch.phase180
            setOnCheckedChangeListener { _, v -> ch.phase180 = v; changed() }
        })

        body.addView(TextView(this).apply {
            text = "LOCAL TARGET: Gain ${fmt(ch.gainTenths / 10.0)} dB • ${if (ch.mute) "MUTE" else "ON"} • Phase ${if (ch.phase180) "180°" else "0°"}"
            setPadding(0, 12, 0, 4)
        })
    }

    private fun renderEq(ch: ChannelState) {
        body.addView(Button(this).apply {
            text = "FLAT EQ (LOCAL)"
            setOnClickListener {
                ch.eqTenths.fill(0)
                changed()
                renderPage()
            }
        })
        eqFreqs.forEachIndexed { i, freq ->
            val label = TextView(this).apply {
                text = "${formatFreq(freq)}   ${fmt(ch.eqTenths[i] / 10.0)} dB"
                textSize = 14f
            }
            body.addView(label)
            body.addView(SeekBar(this).apply {
                max = 240
                progress = ch.eqTenths[i] + 120
                setOnSeekBarChangeListener(simpleSeek { p ->
                    ch.eqTenths[i] = p - 120
                    label.text = "${formatFreq(freq)}   ${fmt(ch.eqTenths[i] / 10.0)} dB"
                    changed()
                })
            })
        }
    }

    private fun renderXover(ch: ChannelState) {
        val hpfLabel = TextView(this).apply { text = "HPF  ${ch.hpfHz} Hz"; textSize = 16f }
        body.addView(hpfLabel)
        body.addView(SeekBar(this).apply {
            max = 1000
            progress = logProgress(ch.hpfHz, 20, 500)
            setOnSeekBarChangeListener(simpleSeek { p ->
                ch.hpfHz = logValue(p, 20, 500)
                if (ch.hpfHz >= ch.lpfHz) ch.hpfHz = (ch.lpfHz - 1).coerceAtLeast(20)
                hpfLabel.text = "HPF  ${ch.hpfHz} Hz"
                changed()
            })
        })

        val lpfLabel = TextView(this).apply { text = "LPF  ${formatFreq(ch.lpfHz)}"; textSize = 16f }
        body.addView(lpfLabel)
        body.addView(SeekBar(this).apply {
            max = 1000
            progress = logProgress(ch.lpfHz, 500, 20000)
            setOnSeekBarChangeListener(simpleSeek { p ->
                ch.lpfHz = logValue(p, 500, 20000)
                if (ch.lpfHz <= ch.hpfHz) ch.lpfHz = (ch.hpfHz + 1).coerceAtMost(20000)
                lpfLabel.text = "LPF  ${formatFreq(ch.lpfHz)}"
                changed()
            })
        })

        body.addView(TextView(this).apply {
            text = "Filter slope/type จะผูกเพิ่มทันทีเมื่อ Device Description/actuator ของเฟิร์มแวร์จริงถูก decode"
            setPadding(0, 10, 0, 0)
        })
    }

    private fun renderDelay(ch: ChannelState) {
        val label = valueLabel("DELAY", ch.delayHundredthsMs / 100.0, "ms")
        body.addView(label)
        body.addView(SeekBar(this).apply {
            max = 2000
            progress = ch.delayHundredthsMs
            setOnSeekBarChangeListener(simpleSeek { p ->
                ch.delayHundredthsMs = p
                label.text = valueText("DELAY", ch.delayHundredthsMs / 100.0, "ms")
                changed()
            })
        })
        body.addView(TextView(this).apply {
            val cm = ch.delayHundredthsMs / 100.0 * 34.3
            text = "ระยะเทียบเท่าโดยประมาณ ${fmt(cm)} cm"
        })
    }

    private fun renderMixer() {
        channels.forEachIndexed { i, ch ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val label = TextView(this).apply {
                text = "CH${i + 1}  ${fmt(ch.gainTenths / 10.0)} dB"
                minWidth = 230
            }
            row.addView(label)
            row.addView(Switch(this).apply {
                text = "M"
                isChecked = ch.mute
                setOnCheckedChangeListener { _, v -> ch.mute = v; changed() }
            })
            body.addView(row)
            body.addView(SeekBar(this).apply {
                max = 720
                progress = ch.gainTenths + 600
                setOnSeekBarChangeListener(simpleSeek { p ->
                    ch.gainTenths = p - 600
                    label.text = "CH${i + 1}  ${fmt(ch.gainTenths / 10.0)} dB"
                    changed()
                })
            })
        }
    }

    private fun renderPresets() {
        body.addView(TextView(this).apply {
            text = "Preset ใน V24 เก็บค่าบนมือถือก่อน (LOCAL)"
            textSize = 16f
        })
        for (slot in 1..6) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(Button(this).apply {
                text = "LOAD P$slot"
                setOnClickListener {
                    if (loadPreset(slot)) {
                        Toast.makeText(this@MainActivity, "Loaded local P$slot", Toast.LENGTH_SHORT).show()
                        renderPage()
                    } else Toast.makeText(this@MainActivity, "P$slot is empty", Toast.LENGTH_SHORT).show()
                }
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(Button(this).apply {
                text = "SAVE P$slot"
                setOnClickListener {
                    savePreset(slot)
                    Toast.makeText(this@MainActivity, "Saved local P$slot", Toast.LENGTH_SHORT).show()
                }
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            body.addView(row)
        }
    }

    private fun changed() {
        pendingChanges++
        saveLastState()
        status.text = safeStatusText(connectedName?.let { "CONNECTED $it" } ?: "DISCONNECTED")
    }

    private fun safeStatusText(connection: String): String {
        val mode = if (WriteGate.enabled) "WRITE ENABLED" else "SAFE MODE • WRITE LOCKED"
        return "$connection • RX=$rxPackets • pending(local)=$pendingChanges\n$mode"
    }

    private fun simpleSeek(block: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
            if (fromUser) block(progress)
        }
        override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
        override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
    }

    private fun valueLabel(name: String, value: Double, unit: String) = TextView(this).apply {
        text = valueText(name, value, unit)
        textSize = 17f
    }

    private fun valueText(name: String, value: Double, unit: String) = "$name  ${fmt(value)} $unit"
    private fun fmt(v: Double) = String.format(java.util.Locale.US, "%.2f", v)
    private fun formatFreq(v: Int) = if (v >= 1000) "${fmt(v / 1000.0)} kHz" else "$v Hz"

    private fun logValue(progress: Int, min: Int, max: Int): Int {
        val t = progress.coerceIn(0, 1000) / 1000.0
        return exp(ln(min.toDouble()) + t * (ln(max.toDouble()) - ln(min.toDouble()))).roundToInt().coerceIn(min, max)
    }

    private fun logProgress(value: Int, min: Int, max: Int): Int {
        val v = value.coerceIn(min, max).toDouble()
        return (((ln(v) - ln(min.toDouble())) / (ln(max.toDouble()) - ln(min.toDouble()))) * 1000.0).roundToInt().coerceIn(0, 1000)
    }

    private fun saveLastState() {
        getSharedPreferences("okn_dsp_v24", MODE_PRIVATE).edit().putString("last", serialize()).apply()
    }

    private fun loadLastState() {
        val s = getSharedPreferences("okn_dsp_v24", MODE_PRIVATE).getString("last", null) ?: return
        deserialize(s)
    }

    private fun savePreset(slot: Int) {
        getSharedPreferences("okn_dsp_v24", MODE_PRIVATE).edit().putString("preset_$slot", serialize()).apply()
    }

    private fun loadPreset(slot: Int): Boolean {
        val s = getSharedPreferences("okn_dsp_v24", MODE_PRIVATE).getString("preset_$slot", null) ?: return false
        deserialize(s)
        saveLastState()
        return true
    }

    private fun serialize(): String = channels.joinToString(";") { ch ->
        listOf(
            ch.gainTenths,
            if (ch.mute) 1 else 0,
            if (ch.phase180) 1 else 0,
            ch.delayHundredthsMs,
            ch.hpfHz,
            ch.lpfHz,
            ch.eqTenths.joinToString(":")
        ).joinToString(",")
    }

    private fun deserialize(s: String) {
        val parts = s.split(";")
        for (i in 0 until minOf(7, parts.size)) {
            val fields = parts[i].split(",")
            if (fields.size < 7) continue
            val ch = channels[i]
            ch.gainTenths = fields[0].toIntOrNull()?.coerceIn(-600, 120) ?: ch.gainTenths
            ch.mute = fields[1] == "1"
            ch.phase180 = fields[2] == "1"
            ch.delayHundredthsMs = fields[3].toIntOrNull()?.coerceIn(0, 2000) ?: ch.delayHundredthsMs
            ch.hpfHz = fields[4].toIntOrNull()?.coerceIn(20, 500) ?: ch.hpfHz
            ch.lpfHz = fields[5].toIntOrNull()?.coerceIn(500, 20000) ?: ch.lpfHz
            fields[6].split(":").take(15).forEachIndexed { j, v ->
                ch.eqTenths[j] = v.toIntOrNull()?.coerceIn(-120, 120) ?: ch.eqTenths[j]
            }
        }
    }

    private fun requestBlePermissions() {
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT), 100)
        }
    }

    private fun hasBlePermission(): Boolean =
        android.os.Build.VERSION.SDK_INT < 31 ||
            (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
             checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED)

    private fun startScan() {
        if (!hasBlePermission()) {
            requestBlePermissions()
            Toast.makeText(this, "อนุญาต Bluetooth แล้วกด Scan อีกครั้ง", Toast.LENGTH_SHORT).show()
            return
        }
        val manager = getSystemService(BluetoothManager::class.java)
        val adapter = manager?.adapter
        if (adapter == null || !adapter.isEnabled) {
            Toast.makeText(this, "กรุณาเปิด Bluetooth", Toast.LENGTH_SHORT).show()
            return
        }
        found.clear()
        deviceList.removeAllViews()
        status.text = safeStatusText("SCANNING")
        scanner = adapter.bluetoothLeScanner
        try { scanner?.startScan(scanCallback) }
        catch (_: SecurityException) { return }
        handler.postDelayed({
            try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
            status.text = safeStatusText(if (connectedName != null) "CONNECTED $connectedName" else "SCAN FINISHED")
        }, 10000)
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            val name = result.scanRecord?.deviceName ?: try { device.name } catch (_: SecurityException) { null }
            val relevant = name?.contains("GOLOPINE", true) == true || name?.contains("DSP", true) == true
            if (!relevant || found.containsKey(device.address)) return
            found[device.address] = device
            runOnUiThread {
                deviceList.addView(Button(this@MainActivity).apply {
                    text = "${name ?: "DSP"}  •  ${device.address}\nแตะเพื่อเชื่อมต่อ"
                    setOnClickListener { connect(device, name ?: "DSP") }
                })
            }
        }

        override fun onScanFailed(errorCode: Int) {
            runOnUiThread { status.text = safeStatusText("SCAN ERROR $errorCode") }
        }
    }

    private fun connect(device: BluetoothDevice, name: String) {
        if (!hasBlePermission()) return
        try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
        try { gatt?.close() } catch (_: Exception) {}
        status.text = safeStatusText("CONNECTING $name")
        try {
            gatt = device.connectGatt(this, false, object : BluetoothGattCallback() {
                override fun onConnectionStateChange(g: BluetoothGatt, statusCode: Int, newState: Int) {
                    if (newState == BluetoothProfile.STATE_CONNECTED) {
                        connectedName = name
                        runOnUiThread { status.text = safeStatusText("CONNECTED $name • DISCOVERING") }
                        try { g.discoverServices() } catch (_: SecurityException) {}
                    } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                        connectedName = null
                        runOnUiThread { status.text = safeStatusText("DISCONNECTED") }
                    }
                }

                override fun onServicesDiscovered(g: BluetoothGatt, statusCode: Int) {
                    if (statusCode != BluetoothGatt.GATT_SUCCESS) return
                    val service = g.getService(BleProfile.AB00_SERVICE)
                    val notifyChars = listOfNotNull(
                        service?.getCharacteristic(BleProfile.AB02_NOTIFY),
                        service?.getCharacteristic(BleProfile.AB03_NOTIFY)
                    )
                    runOnUiThread {
                        status.text = safeStatusText("CONNECTED $name • AB00=${if (service != null) "OK" else "NOT FOUND"}")
                    }
                    notifyChars.forEachIndexed { index, ch -> handler.postDelayed({ subscribe(g, ch) }, (index * 700).toLong()) }
                }

                override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
                    rxPackets++
                    runOnUiThread { status.text = safeStatusText("CONNECTED $name • RX ${characteristic.uuid.toString().take(8)} ${value.size}B") }
                }

                @Suppress("DEPRECATION")
                override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
                    rxPackets++
                    runOnUiThread { status.text = safeStatusText("CONNECTED $name • RX ${characteristic.uuid.toString().take(8)}") }
                }
            }, BluetoothDevice.TRANSPORT_LE)
        } catch (_: SecurityException) {
            status.text = safeStatusText("PERMISSION ERROR")
        }
    }

    private fun subscribe(g: BluetoothGatt, ch: BluetoothGattCharacteristic) {
        if (!hasBlePermission() || subscribed.contains(ch.uuid)) return
        try {
            if (!g.setCharacteristicNotification(ch, true)) return
            val cccd = ch.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")) ?: return
            val bytes = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                if (g.writeDescriptor(cccd, bytes) == BluetoothGatt.GATT_SUCCESS) subscribed.add(ch.uuid)
            } else {
                @Suppress("DEPRECATION")
                cccd.value = bytes
                @Suppress("DEPRECATION")
                if (g.writeDescriptor(cccd)) subscribed.add(ch.uuid)
            }
        } catch (_: Exception) {}
    }
}
