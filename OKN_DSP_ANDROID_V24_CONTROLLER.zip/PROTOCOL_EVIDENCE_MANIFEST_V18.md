# OKN DSP V19 — Protocol Evidence Manifest

Purpose: record only experimentally observed evidence for the GoloPine/BP1048P4 protocol. No guessed packet framing, key, cipher mode, checksum, actuator ID, or SigmaDSP byte order.

## Required evidence classes
- RAW_BTSNOOP: original Android Bluetooth HCI snoop/btsnoop file.
- OFFICIAL_APP_VERSION: exact official GoloPine APK version used for the capture.
- DEVICE_PROFILE: device name, firmware/software version, hardware version if exposed.
- GATT_PROFILE: service/characteristic UUIDs, handles, properties, CCCD writes.
- SESSION_BASELINE: connect/authenticate/read-description with no DSP parameter change.
- SINGLE_PARAMETER_DIFF: exactly one known UI parameter changed in the official app; capture before and after.
- REPEAT_SESSION: same controlled action repeated in a new session.

## Acceptance rules
1. Preserve original capture bytes; never normalize away timestamps, handles, directions, or packet boundaries.
2. Pair every parameter-diff capture with a baseline capture from the same device and firmware.
3. Record the exact UI action and old/new value.
4. Do not infer semantic fields from position alone.
5. A write packet is considered identified only when the same semantic change is reproduced across controlled sessions and can be cross-checked against the official application's behavior.
6. Encryption/key claims require correlation with the actual packet-processing path or independently reproducible cryptographic evidence.

## Current evidence status
- AB00/AB01/AB02/AB03 transport profile: confirmed in the existing captured session.
- AB01 value handle 0x0006: confirmed main TX/control path.
- AB02 value handle 0x0008: confirmed main notification path.
- 16-byte initial write, 32-byte response, 4-byte follow-up, and 18,252-byte bulk transfer: observed.
- Exact application framing: unproven.
- Exact authentication/key derivation: unproven.
- Exact actuator IDs/CH1–CH7 mapping: unproven.
- Exact SigmaDSP coefficient serialization: unproven.
- DSP writes in OKN app: disabled.

## Capture record template
SESSION_ID=
DEVICE=
FIRMWARE=
OFFICIAL_APP=
ACTION=
OLD_VALUE=
NEW_VALUE=
TIMESTAMP_START=
TIMESTAMP_END=
RAW_CAPTURE_FILE=
NOTES=
