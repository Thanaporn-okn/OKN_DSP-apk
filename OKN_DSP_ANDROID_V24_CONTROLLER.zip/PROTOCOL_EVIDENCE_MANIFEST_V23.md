# Protocol Evidence Manifest V23

V23 extends the V22 controlled A/B byte differential lab with a stability report.

## Evidence rules
- Compare only valid timestamped TX records with matching kind and length.
- Report byte-position change counts across aligned A/B records.
- A position changing in every comparable pair is reported as alwaysChanged, but is NOT assigned semantic meaning.
- Localized/repeated changes are candidates for controlled parameter evidence only.
- Independent repeated sessions are required before promoting a byte pattern to parameter-varying evidence.
- No guessed UFE framing, checksum, encryption mode, actuator mapping, or DSP write is enabled.

## Confirmed transport
- Service: 0000ab00-0000-1000-8000-00805f9b34fb
- TX: 0000ab01-0000-1000-8000-00805f9b34fb / value handle 0x0006
- RX: 0000ab02-0000-1000-8000-00805f9b34fb / value handle 0x0008
- Secondary RX: 0000ab03-0000-1000-8000-00805f9b34fb / value handle 0x000B

## Status
Write path remains hard-disabled until framing, encryption/integrity, serializer, and actuator mapping are independently verified.
