OKN_DSP — CLEAN V1 REBUILD
==========================

Identity
- App label: OKN_DSP
- applicationId: com.okn.dsp
- versionCode: 1
- versionName: 1.0.0-v1
- Android: minSdk 26 / targetSdk 35
- UI master: evidence/OKN_DSP_V1_UI_MASTER_REFERENCE.png

V1 architecture reset
- OknDspApplication owns one process-scoped DspRuntime.
- MainActivity is only the UI/permission/dialog bridge; Activity recreation never owns GATT.
- ReferenceDspUi is a new UI shell derived from the supplied two-phone reference only.
- Global and EQ controls send commands only through DspRepository -> verified policy -> realtime queue -> BLE transport.
- No UI view writes BluetoothGatt directly.

Verified hardware retained from prior qualification
- BLE AB00 service / AB01 write / AB02 notify; AB03 observed secondary notify.
- Auth16 + RandKey + AES-CFB8 continuous TX/RX session.
- Scalars IDs 2,3,8,9,10,13,11 only.
- EQ actuators CH1..CH7 = 4,5,6,14,15,16,17.
- 15 records/channel, 48 bytes/record; only PEAKING type=12 write-enabled.
- SaveParams ID7 exact 570000000700000000, manual guarded only.
- Generic/unknown writes disabled.

Realtime behavior
- optimistic UI follows finger continuously.
- one GATT write in flight.
- realtime latest-target-wins coalescing.
- 38 ms minimum queue pacing; 2.5 s callback timeout/fail-closed.
- scalar target ramp; TrebleBoost ID11 <= 0.5 dB per callback-confirmed step, nominal 48 ms.
- EQ Frequency/Q/Gain uses callback-gated interpolation and full 48-byte verified record writes.
- MasterVolume ID2 syncs bidirectionally with Android STREAM_MUSIC and physical Volume +/-.

Persistence
- every scalar/EQ movement updates in-memory state immediately and schedules local persistent state (60 ms latest-state debounce).
- app restart renders remembered verified targets.
- after reconnect, a fresh authenticated Device Description + Health Gate is required before automatic ramped replay.
- hardware SaveParams is NOT automatically emitted.
- app-local Save Preset / Load Preset is implemented and replays only verified controls.

Reference UI
- Header: OKN_DSP / DIGITAL SOUND PROCESSOR / BLE status.
- DSP-7CH device card and local preset selector.
- top function tabs: Global, EQ, Channel, Crossover, Delay, Output.
- Global: Master Volume, Bass Volume, Bass Cutoff, Bass Boost, Middle Boost, Treble Boost; touch knobs + sliders; Reset / Save Preset / Load Preset.
- EQ: Graphic EQ / Parametric EQ, real response graph, draggable verified PEAKING points, 10 graphic faders, 15-band parametric selection, Frequency/Q/Gain, Flat/Reset/Copy/Paste.
- portrait and landscape use the same state/session and scrolling layout.

Safety boundary
Crossover, Delay and unverified channel/output packet families remain visibly locked. This is intentional: V1 does not claim a DSP write exists unless the real packet/actuator mapping was already verified.

Install note
This clean rebuild resets Android versionCode to 1 while keeping applicationId com.okn.dsp. If a previous OKN_DSP build with a higher versionCode is installed, Android may reject it as a downgrade. Uninstall the previous OKN_DSP first before installing this V1 APK. Local app data from the old package will also be removed by uninstall unless backed up separately.
