package com.okn.dsp.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.view.MotionEvent
import android.view.View
import com.okn.dsp.protocol.EqBand48
import com.okn.dsp.protocol.EqBandCodec
import com.okn.dsp.protocol.LiveEqPolicy
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sin

/**
 * Real verified EQ graph. Writable points are PEAKING type=12 only.
 * Dragging a point changes Frequency + Gain continuously; Q remains the current band Q.
 */
class RealtimeEqGraphView(context: Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val fill = Path()
    private var bands: List<EqBand48?> = List(15) { null }
    private var selectedBand = 1
    private var draggingBand = -1
    private var onSelect: ((Int) -> Unit)? = null
    private var onDrag: ((Int, Float, Float) -> Unit)? = null

    fun bind(newBands: List<EqBand48?>, selected: Int) {
        bands = List(15) { i -> newBands.getOrNull(i) }
        selectedBand = selected.coerceIn(1,15)
        invalidate()
    }

    fun setCallbacks(onSelect: (Int) -> Unit, onDrag: (Int, Float, Float) -> Unit) {
        this.onSelect = onSelect
        this.onDrag = onDrag
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val desired = context.dp(250)
        setMeasuredDimension(w, resolveSize(desired, heightMeasureSpec))
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val left = context.dp(34).toFloat()
        val top = context.dp(18).toFloat()
        val right = width-context.dp(10).toFloat()
        val bottom = height-context.dp(28).toFloat()
        if (right <= left || bottom <= top) return

        p.style = Paint.Style.FILL
        p.color = Color.rgb(5,18,26)
        c.drawRoundRect(RectF(0f,0f,width.toFloat(),height.toFloat()), context.dp(10).toFloat(), context.dp(10).toFloat(), p)

        p.strokeWidth = 1f
        p.style = Paint.Style.STROKE
        p.color = Color.rgb(22,47,61)
        val gt = floatArrayOf(12f,6f,0f,-6f,-12f)
        gt.forEach { g ->
            val y = gainToY(g,top,bottom)
            c.drawLine(left,y,right,y,p)
            p.style = Paint.Style.FILL; p.color = OknColors.MUTED; p.textSize=context.resources.displayMetrics.scaledDensity*9f; p.textAlign=Paint.Align.RIGHT
            c.drawText(if(g>0) "+${g.toInt()}" else g.toInt().toString(), left-context.dp(5), y+context.dp(3), p)
            p.style=Paint.Style.STROKE; p.color=Color.rgb(22,47,61)
        }
        val ft = floatArrayOf(20f,50f,100f,200f,500f,1000f,2000f,5000f,10000f,20000f)
        ft.forEach { f ->
            val x=freqToX(f,left,right); c.drawLine(x,top,x,bottom,p)
            p.style=Paint.Style.FILL; p.color=OknColors.MUTED; p.textSize=context.resources.displayMetrics.scaledDensity*8f; p.textAlign=Paint.Align.CENTER
            val label=if(f>=1000f) "${(f/1000f).toInt()}K" else f.toInt().toString()
            c.drawText(label,x,bottom+context.dp(15),p)
            p.style=Paint.Style.STROKE; p.color=Color.rgb(22,47,61)
        }

        val available=bands.filterNotNull()
        if(available.isNotEmpty()) {
            path.reset(); fill.reset()
            val samples=220
            var firstY=0f
            for(i in 0 until samples) {
                val t=i/(samples-1f)
                val freq=20.0*1000.0.pow(t.toDouble())
                val db=available.sumOf { biquadDb(it,freq) }.coerceIn(-12.0,12.0)
                val x=left+(right-left)*t
                val y=gainToY(db.toFloat(),top,bottom)
                if(i==0) { path.moveTo(x,y); fill.moveTo(x,bottom); fill.lineTo(x,y); firstY=y }
                else { path.lineTo(x,y); fill.lineTo(x,y) }
            }
            fill.lineTo(right,bottom); fill.close()
            p.style=Paint.Style.FILL
            p.shader=LinearGradient(0f,top,0f,bottom,Color.argb(85,22,153,255),Color.argb(6,22,153,255),Shader.TileMode.CLAMP)
            c.drawPath(fill,p); p.shader=null
            p.style=Paint.Style.STROKE; p.strokeWidth=context.dp(2).toFloat(); p.color=OknColors.CYAN
            c.drawPath(path,p)
        }

        bands.forEachIndexed { idx,b ->
            if(b==null || !LiveEqPolicy.isWritable(b)) return@forEachIndexed
            val x=freqToX(b.frequency.coerceIn(20f,20000f),left,right)
            val y=gainToY(b.boostDb.coerceIn(-12f,12f),top,bottom)
            val selected=(idx+1)==selectedBand
            p.style=Paint.Style.FILL; p.color=Color.WHITE
            c.drawCircle(x,y,context.dp(if(selected)6 else 5).toFloat(),p)
            p.style=Paint.Style.STROKE; p.strokeWidth=context.dp(2).toFloat(); p.color=OknColors.CYAN
            c.drawCircle(x,y,context.dp(if(selected)9 else 7).toFloat(),p)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val left=context.dp(34).toFloat(); val top=context.dp(18).toFloat(); val right=width-context.dp(10).toFloat(); val bottom=height-context.dp(28).toFloat()
        when(event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                var best=-1; var bestD=Float.MAX_VALUE
                bands.forEachIndexed { i,b ->
                    if(b==null || !LiveEqPolicy.isWritable(b)) return@forEachIndexed
                    val x=freqToX(b.frequency.coerceIn(20f,20000f),left,right); val y=gainToY(b.boostDb.coerceIn(-12f,12f),top,bottom)
                    val d=hypot(event.x-x,event.y-y)
                    if(d<bestD){bestD=d;best=i+1}
                }
                if(best>0 && bestD<=context.dp(30)) {
                    draggingBand=best; selectedBand=best; onSelect?.invoke(best); parent?.requestDisallowInterceptTouchEvent(true); invalidate(); return true
                }
                return false
            }
            MotionEvent.ACTION_MOVE -> {
                val band=draggingBand
                if(band>0) {
                    val f=xToFreq(event.x,left,right)
                    val g=yToGain(event.y,top,bottom)
                    onDrag?.invoke(band,f,g)
                    return true
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if(draggingBand>0) { draggingBand=-1; parent?.requestDisallowInterceptTouchEvent(false); performClick(); return true }
            }
        }
        return super.onTouchEvent(event)
    }
    override fun performClick(): Boolean = super.performClick()

    private fun freqToX(freq:Float,left:Float,right:Float):Float {
        val t=(ln(freq/20f)/ln(1000f)).coerceIn(0f,1f); return left+(right-left)*t
    }
    private fun xToFreq(x:Float,left:Float,right:Float):Float {
        val t=((x-left)/(right-left)).coerceIn(0f,1f); return (20.0*1000.0.pow(t.toDouble())).toFloat().coerceIn(20f,20000f)
    }
    private fun gainToY(db:Float,top:Float,bottom:Float):Float { val t=((12f-db)/24f).coerceIn(0f,1f); return top+(bottom-top)*t }
    private fun yToGain(y:Float,top:Float,bottom:Float):Float { val t=((y-top)/(bottom-top)).coerceIn(0f,1f); return (12f-24f*t).coerceIn(-12f,12f) }

    private fun biquadDb(b: EqBand48, freq: Double): Double {
        if(!listOf(b.b0,b.b1,b.b2,b.a1,b.a2).all{it.isFinite()}) return 0.0
        val w=2.0*Math.PI*freq/EqBandCodec.SAMPLE_RATE_HZ
        val c1=cos(w); val s1=sin(w); val c2=cos(2*w); val s2=sin(2*w)
        val nr=b.b0+b.b1*c1+b.b2*c2; val ni=-b.b1*s1-b.b2*s2
        val dr=1.0+b.a1*c1+b.a2*c2; val di=-b.a1*s1-b.a2*s2
        val n2=nr*nr+ni*ni; val d2=dr*dr+di*di
        return if(n2<=1e-18||d2<=1e-18)0.0 else 10.0*log10(n2/d2)
    }
}
