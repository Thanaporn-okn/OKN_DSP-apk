package com.okn.dsp.ui

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Space
import android.widget.TextView
import com.okn.dsp.protocol.LiveEqPolicy
import com.okn.dsp.protocol.VerifiedScalarControls
import com.okn.dsp.state.ConnectionState
import com.okn.dsp.state.DspState
import com.okn.dsp.state.DspStateStore
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt

interface DspUiActions {
    fun scanConnect()
    fun showMainMenu()
    fun scalarChanged(id: Int, value: Float)
    fun channelSelected(channel: Int)
    fun bandSelected(band: Int)
    fun eqChanged(channel: Int, band: Int, frequency: Float, q: Float, gain: Float)
    fun resetGlobal()
    fun savePreset()
    fun loadPreset()
    fun flatEq()
    fun copyEq()
    fun pasteEq()
    fun reconnect()
    fun disconnect()
    fun refresh()
    fun saveParams()
    fun showLogs()
}

data class UiSnapshot(val tab: Int = 0, val parametricMode: Boolean = false)

private data class ControlHolder(val id:Int,val knob:KnobView,val value:TextView,val seek:SeekBar)
private data class EqFaderSlot(var band:Int,val top:TextView,val fader:VerticalFader,val bottom:TextView)

/**
 * V1 master UI. Layout is intentionally derived only from the supplied two-screen reference:
 * OKN_DSP header -> DSP-7CH/preset card -> six function tabs -> dark blue control cards.
 */
class ReferenceDspUi(
    private val context: Context,
    private val store: DspStateStore,
    private val actions: DspUiActions,
    initial: UiSnapshot = UiSnapshot(),
) {
    val view: View
    private val host = FrameLayout(context)
    private val tabBoxes = mutableListOf<LinearLayout>()
    private val statusText = context.txt("Disconnected", 10, OknColors.MUTED)
    private val statusDot = context.txt("●", 12, OknColors.MUTED, true, Gravity.CENTER)
    private val headerStatus = context.txt("Disconnected", 10, OknColors.MUTED)
    private val presetText = context.txt("Preset 1\nCustom", 11, OknColors.TEXT, true)
    private var state: DspState = store.value()
    private var tab = initial.tab.coerceIn(0,5)
    private var unsubscribe: (() -> Unit)? = null

    private val global = GlobalPanel()
    private val eq = EqPanel(initial.parametricMode)
    private val channel = ChannelPanel()
    private val crossover = LockedPanel("Crossover", "Hardware crossover write mapping is not verified yet.")
    private val delay = LockedPanel("Delay", "Hardware delay write mapping is not verified yet.")
    private val output = OutputPanel()

    init {
        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(OknColors.BG)
            addView(buildHeader(), LinearLayout.LayoutParams(-1, context.dp(67)))
            addView(buildDeviceCard(), LinearLayout.LayoutParams(-1, context.dp(83)).apply {
                leftMargin=context.dp(12); rightMargin=context.dp(12); bottomMargin=context.dp(5)
            })
            addView(buildTabs(), LinearLayout.LayoutParams(-1, context.dp(72)))
            addView(host, LinearLayout.LayoutParams(-1, 0, 1f).apply { leftMargin=context.dp(12); rightMargin=context.dp(12) })
            addView(buildFooter(), LinearLayout.LayoutParams(-1, context.dp(34)))
            addView(buildBottomNav(), LinearLayout.LayoutParams(-1, context.dp(58)))
        }
        view = root
        selectTab(tab)
        unsubscribe = store.subscribe { s -> state=s; bind(s) }
    }

    fun dispose() { unsubscribe?.invoke(); unsubscribe=null }
    fun snapshot(): UiSnapshot = UiSnapshot(tab, eq.parametricMode)
    fun setPresetLabel(name:String) { presetText.text = "$name\nCustom" }

    private fun buildHeader(): View = context.row().apply {
        setPadding(context.dp(12), context.dp(6), context.dp(12), 0)
        addView(context.txt("☰", 31, OknColors.TEXT, false, Gravity.CENTER).apply {
            setOnClickListener { actions.showMainMenu() }; isClickable=true
        }, LinearLayout.LayoutParams(context.dp(48), -1))
        addView(LinearLayout(context).apply {
            orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER
            addView(context.txt("OKN_DSP", 26, OknColors.TEXT, true, Gravity.CENTER).apply { setTypeface(typeface, Typeface.BOLD_ITALIC) })
            addView(context.txt("DIGITAL  SOUND  PROCESSOR", 8, OknColors.MUTED, false, Gravity.CENTER))
        }, LinearLayout.LayoutParams(0,-1,1f))
        addView(context.row().apply {
            gravity=Gravity.CENTER
            addView(context.txt("ᛒ", 24, OknColors.CYAN, true, Gravity.CENTER), LinearLayout.LayoutParams(context.dp(31),-1))
            addView(LinearLayout(context).apply {
                orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER_VERTICAL
                addView(context.row().apply { addView(statusDot, LinearLayout.LayoutParams(context.dp(15),-2)); addView(headerStatus) })
                addView(context.txt("tap to scan", 8, OknColors.MUTED))
            })
            setOnClickListener { actions.scanConnect() }; isClickable=true
        }, LinearLayout.LayoutParams(context.dp(118),-1))
    }

    private fun buildDeviceCard(): View = context.card(9,8).apply {
        orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL
        addView(context.txt("▣", 31, Color.rgb(105,201,255), true, Gravity.CENTER).apply {
            background=rounded(Color.rgb(10,45,61),context.dp(9).toFloat())
        }, LinearLayout.LayoutParams(context.dp(62),context.dp(58)))
        addView(LinearLayout(context).apply {
            orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER_VERTICAL
            addView(context.txt("DSP-7CH", 14, OknColors.TEXT, true))
            addView(context.txt("7 Channel Audio Processor", 10, OknColors.MUTED))
        }, LinearLayout.LayoutParams(0,-1,1f).apply { leftMargin=context.dp(10) })
        addView(LinearLayout(context).apply {
            orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER_VERTICAL
            background=rounded(Color.rgb(5,23,32),context.dp(8).toFloat(),OknColors.BORDER,context.dp(1))
            setPadding(context.dp(10),context.dp(6),context.dp(10),context.dp(6))
            addView(presetText, LinearLayout.LayoutParams(context.dp(120),-2))
            setOnClickListener { actions.loadPreset() }; isClickable=true
        }, LinearLayout.LayoutParams(context.dp(137),context.dp(58)))
    }

    private fun buildTabs(): View = context.row().apply {
        setPadding(context.dp(7),0,context.dp(7),0)
        val items=listOf("⌂" to "Global","▥" to "EQ","◖" to "Channel","⤨" to "Crossover","◷" to "Delay","⚙" to "Output")
        items.forEachIndexed { index,(icon,label) ->
            val iconV=context.txt(icon,20,OknColors.MUTED,true,Gravity.CENTER).apply{tag="icon"}
            val labelV=context.txt(label,9,OknColors.MUTED,false,Gravity.CENTER).apply{tag="label"}
            val line=View(context).apply{tag="line";setBackgroundColor(Color.TRANSPARENT)}
            val box=LinearLayout(context).apply {
                orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER
                addView(iconV,LinearLayout.LayoutParams(-1,context.dp(31)))
                addView(labelV,LinearLayout.LayoutParams(-1,context.dp(24)))
                addView(line,LinearLayout.LayoutParams(-1,context.dp(3)).apply{leftMargin=context.dp(6);rightMargin=context.dp(6)})
                setOnClickListener{selectTab(index)};isClickable=true
            }
            tabBoxes+=box
            addView(box,LinearLayout.LayoutParams(0,-1,1f))
        }
    }

    private fun buildFooter(): View = context.row().apply {
        setPadding(context.dp(10),0,context.dp(10),0)
        addView(context.txt("OKN_DSP v1.0.0",9,OknColors.MUTED),LinearLayout.LayoutParams(0,-1,1f))
        addView(context.row().apply { addView(context.txt("●",11,OknColors.GREEN,true,Gravity.CENTER),LinearLayout.LayoutParams(context.dp(18),-1));addView(statusText) })
    }

    private fun buildBottomNav(): View = context.row().apply {
        setBackgroundColor(Color.rgb(3,14,21))
        fun nav(icon:String,label:String,index:Int):View=LinearLayout(context).apply{
            orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER
            addView(context.txt(icon,22,OknColors.MUTED,true,Gravity.CENTER),LinearLayout.LayoutParams(-1,context.dp(31)))
            addView(context.txt(label,9,OknColors.MUTED,false,Gravity.CENTER))
            setOnClickListener{selectTab(index)};isClickable=true
        }
        addView(nav("⌂","Home",0),LinearLayout.LayoutParams(0,-1,1f))
        addView(nav("⌁","Live",1),LinearLayout.LayoutParams(0,-1,1f))
        addView(nav("⚙","Settings",5),LinearLayout.LayoutParams(0,-1,1f))
    }

    private fun selectTab(index:Int) {
        tab=index.coerceIn(0,5)
        val screen: Panel = when(tab){0->global;1->eq;2->channel;3->crossover;4->delay;else->output}
        host.removeAllViews(); host.addView(screen.view,FrameLayout.LayoutParams(-1,-1)); screen.bind(state)
        tabBoxes.forEachIndexed { i,b ->
            val active=i==tab
            b.findViewWithTag<TextView>("icon").setTextColor(if(active)OknColors.CYAN else OknColors.MUTED)
            b.findViewWithTag<TextView>("label").apply{setTextColor(if(active)OknColors.CYAN else OknColors.MUTED);setTypeface(typeface,if(active)Typeface.BOLD else Typeface.NORMAL)}
            b.findViewWithTag<View>("line").setBackgroundColor(if(active)OknColors.CYAN else Color.TRANSPARENT)
        }
    }

    private fun bind(s:DspState) {
        val connected=s.connection==ConnectionState.CONNECTED && s.healthGatePass
        val text=when(s.connection){
            ConnectionState.SCANNING->"Scanning"
            ConnectionState.CONNECTING,ConnectionState.RECONNECTING->"Connecting"
            ConnectionState.DISCOVERING->"Discovering"
            ConnectionState.AUTHENTICATING->"Auth"
            ConnectionState.SYNCHRONIZING->"Sync"
            ConnectionState.CONNECTED->if(s.healthGatePass)"Connected" else "Verifying"
            ConnectionState.FAILED->"Error"
            else->"Disconnected"
        }
        headerStatus.text=text; statusText.text=text
        statusDot.setTextColor(if(connected)OknColors.GREEN else if(s.connection==ConnectionState.FAILED)OknColors.RED else OknColors.MUTED)
        global.bind(s);eq.bind(s);channel.bind(s);crossover.bind(s);delay.bind(s);output.bind(s)
    }

    private interface Panel { val view:View; fun bind(s:DspState) }

    private inner class GlobalPanel:Panel {
        private val root=LinearLayout(context).apply{orientation=LinearLayout.VERTICAL;setPadding(0,context.dp(3),0,context.dp(10))}
        override val view:View=ScrollView(context).apply{isFillViewport=true;addView(root,ViewGroup.LayoutParams(-1,-2))}
        private val holders=linkedMapOf<Int,ControlHolder>()
        private val visibleIds=listOf(2,8,9,10,13,11)
        init {
            root.addView(context.row().apply {
                addView(context.txt("☷",28,OknColors.CYAN,true,Gravity.CENTER),LinearLayout.LayoutParams(context.dp(51),context.dp(52)))
                addView(LinearLayout(context).apply{orientation=LinearLayout.VERTICAL;addView(context.txt("Global Controls",20,OknColors.TEXT,true));addView(context.txt("Adjust overall sound character",11,OknColors.MUTED))},LinearLayout.LayoutParams(0,-2,1f))
            },LinearLayout.LayoutParams(-1,context.dp(62)))
            visibleIds.forEach { id -> addControl(id) }
            root.addView(context.row().apply {
                addView(context.button("↻  Reset"){actions.resetGlobal()},LinearLayout.LayoutParams(0,context.dp(48),1f))
                addView(context.button("▣  Save Preset"){actions.savePreset()},LinearLayout.LayoutParams(0,context.dp(48),1f).apply{leftMargin=context.dp(8)})
                addView(context.button("▰  Load Preset"){actions.loadPreset()},LinearLayout.LayoutParams(0,context.dp(48),1f).apply{leftMargin=context.dp(8)})
            },LinearLayout.LayoutParams(-1,context.dp(58)).apply{topMargin=context.dp(5)})
        }
        private fun addControl(id:Int) {
            val c=VerifiedScalarControls.byId(id)?:return
            val label=when(id){2->"Master Volume";8->"Bass Volume";9->"Bass Cutoff";10->"Bass Boost";13->"Middle Boost";11->"Treble Boost";else->c.name}
            val knob=KnobView(context).apply{configure(c.min,c.max,c.min){v->actions.scalarChanged(id,roundValue(id,v))}}
            val value=context.txt("--",12,OknColors.TEXT,true,Gravity.END)
            val seek=context.seek(c.min,c.max,c.min){v->actions.scalarChanged(id,roundValue(id,v))}
            val row=context.card(10,7).apply {
                orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
                addView(knob,LinearLayout.LayoutParams(context.dp(75),context.dp(75)))
                addView(LinearLayout(context).apply {
                    orientation=LinearLayout.VERTICAL
                    addView(context.row().apply{addView(context.txt(label,12,OknColors.TEXT,true),LinearLayout.LayoutParams(0,context.dp(26),1f));addView(value,LinearLayout.LayoutParams(context.dp(84),context.dp(26)))})
                    addView(seek,LinearLayout.LayoutParams(-1,context.dp(36)))
                    addView(context.row().apply{addView(context.txt(formatMin(c.min,c.unit),8,OknColors.MUTED),LinearLayout.LayoutParams(0,-2,1f));addView(context.txt(formatMax(c.max,c.unit),8,OknColors.MUTED,false,Gravity.END),LinearLayout.LayoutParams(0,-2,1f))})
                },LinearLayout.LayoutParams(0,-1,1f).apply{leftMargin=context.dp(4)})
                addView(context.txt(if(id==2)"◖" else "⌁",21,OknColors.TEXT,true,Gravity.CENTER).apply{background=rounded(Color.rgb(10,38,52),context.dp(8).toFloat(),OknColors.BORDER,context.dp(1))},LinearLayout.LayoutParams(context.dp(49),context.dp(49)).apply{leftMargin=context.dp(7)})
            }
            root.addView(row,LinearLayout.LayoutParams(-1,context.dp(91)).apply{bottomMargin=context.dp(7)})
            holders[id]=ControlHolder(id,knob,value,seek)
        }
        override fun bind(s:DspState){
            holders.values.forEach { h -> s.scalars[h.id]?.let { v->h.knob.bindValue(v);h.seek.bindValue(v);h.value.text=formatValue(h.id,v) } ?: run { h.value.text="--" } }
        }
    }

    private inner class EqPanel(startParametric:Boolean):Panel {
        var parametricMode:Boolean=startParametric; private set
        private val root=LinearLayout(context).apply{orientation=LinearLayout.VERTICAL;setPadding(0,context.dp(4),0,context.dp(10))}
        override val view:View=ScrollView(context).apply{isFillViewport=true;addView(root,ViewGroup.LayoutParams(-1,-2))}
        private val graph=RealtimeEqGraphView(context)
        private val graphicContainer=LinearLayout(context).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.BOTTOM}
        private val parametricContainer=LinearLayout(context).apply{orientation=LinearLayout.VERTICAL}
        private val modeGraphic=context.button("Graphic EQ",!startParametric){setMode(false)}
        private val modeParam=context.button("Parametric EQ",startParametric){setMode(true)}
        private val channelButtons=mutableListOf<TextView>()
        private val bandButtons=mutableListOf<TextView>()
        private val freqValue=context.txt("-- Hz",11,OknColors.TEXT,true,Gravity.END)
        private val qValue=context.txt("--",11,OknColors.TEXT,true,Gravity.END)
        private val gainValue=context.txt("-- dB",11,OknColors.TEXT,true,Gravity.END)
        private val freqSeek=SeekBar(context).apply{max=1000;progressTintList=android.content.res.ColorStateList.valueOf(OknColors.CYAN);thumbTintList=android.content.res.ColorStateList.valueOf(OknColors.WHITE);progressBackgroundTintList=android.content.res.ColorStateList.valueOf(OknColors.TRACK)}
        private val qSeek=context.seek(.05f,20f,1f){v->changeSelected(q=v)}
        private val gainSeek=context.seek(-12f,12f,0f){v->changeSelected(gain=(v*10f).roundToInt()/10f)}
        private val faders=mutableListOf<EqFaderSlot>()
        private var latest:DspState=state

        init {
            root.addView(context.card(10,9).apply {
                orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
                addView(context.txt("▥",32,OknColors.CYAN,true,Gravity.CENTER),LinearLayout.LayoutParams(context.dp(58),context.dp(55)))
                addView(LinearLayout(context).apply{orientation=LinearLayout.VERTICAL;addView(context.txt("Equalizer",20,OknColors.TEXT,true));addView(context.txt("Fine tune your sound\nwith precision",10,OknColors.MUTED))},LinearLayout.LayoutParams(0,-2,1f))
                addView(context.row().apply { addView(modeGraphic,LinearLayout.LayoutParams(context.dp(108),context.dp(44)));addView(modeParam,LinearLayout.LayoutParams(context.dp(108),context.dp(44)).apply{leftMargin=context.dp(4)}) },LinearLayout.LayoutParams(context.dp(224),context.dp(48)))
            },LinearLayout.LayoutParams(-1,context.dp(73)).apply{bottomMargin=context.dp(7)})
            root.addView(buildChannelRow(),LinearLayout.LayoutParams(-1,context.dp(43)).apply{bottomMargin=context.dp(6)})
            graph.setCallbacks(
                onSelect={band->actions.bandSelected(band)},
                onDrag={band,f,g->val ch=latest.selectedChannel;val b=latest.eq.getOrNull(ch-1)?.getOrNull(band-1);if(b!=null&&LiveEqPolicy.isWritable(b))actions.eqChanged(ch,band,f,b.q,(g*10f).roundToInt()/10f)}
            )
            root.addView(graph,LinearLayout.LayoutParams(-1,context.dp(250)).apply{bottomMargin=context.dp(8)})
            root.addView(buildGraphic(),LinearLayout.LayoutParams(-1,context.dp(270)))
            root.addView(parametricContainer,LinearLayout.LayoutParams(-1,-2))
            buildParametric()
            root.addView(context.row().apply {
                addView(context.button("—  Flat"){actions.flatEq()},LinearLayout.LayoutParams(0,context.dp(48),1f))
                addView(context.button("↻  Reset"){actions.flatEq()},LinearLayout.LayoutParams(0,context.dp(48),1f).apply{leftMargin=context.dp(7)})
                addView(context.button("▣  Copy"){actions.copyEq()},LinearLayout.LayoutParams(0,context.dp(48),1f).apply{leftMargin=context.dp(7)})
                addView(context.button("▱  Paste"){actions.pasteEq()},LinearLayout.LayoutParams(0,context.dp(48),1f).apply{leftMargin=context.dp(7)})
            },LinearLayout.LayoutParams(-1,context.dp(59)).apply{topMargin=context.dp(6)})
            freqSeek.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{
                override fun onProgressChanged(seekBar:SeekBar?,progress:Int,fromUser:Boolean){if(fromUser){val f=(20.0*1000.0.pow(progress/1000.0)).toFloat();changeSelected(freq=f)}}
                override fun onStartTrackingTouch(seekBar:SeekBar?)=Unit
                override fun onStopTrackingTouch(seekBar:SeekBar?)=Unit
            })
            setMode(startParametric)
        }

        private fun buildChannelRow():View=HorizontalScrollView(context).apply{
            isHorizontalScrollBarEnabled=false
            addView(context.row().apply{
                for(ch in 1..7){val b=context.txt("CH$ch",10,OknColors.MUTED,true,Gravity.CENTER).apply{background=rounded(OknColors.CARD2,context.dp(8).toFloat(),OknColors.BORDER,context.dp(1));setOnClickListener{actions.channelSelected(ch)};isClickable=true};channelButtons+=b;addView(b,LinearLayout.LayoutParams(context.dp(61),context.dp(36)).apply{rightMargin=context.dp(5)})}
            },ViewGroup.LayoutParams(-2,-1))
        }

        private fun buildGraphic():View=HorizontalScrollView(context).apply{
            isHorizontalScrollBarEnabled=false;background=rounded(Color.rgb(5,20,28),context.dp(10).toFloat(),OknColors.BORDER,context.dp(1));setPadding(context.dp(8),context.dp(5),context.dp(8),context.dp(5))
            repeat(10){
                val top=context.txt("0",9,OknColors.TEXT,false,Gravity.CENTER)
                val f=VerticalFader(context)
                val bottom=context.txt("--",8,OknColors.MUTED,false,Gravity.CENTER)
                val slot=EqFaderSlot(-1,top,f,bottom);f.configure(0f,false){g->val b=slot.band;if(b>0){val ch=latest.selectedChannel;val row=latest.eq.getOrNull(ch-1)?.getOrNull(b-1);if(row!=null&&LiveEqPolicy.isWritable(row))actions.eqChanged(ch,b,row.frequency,row.q,g)}};faders+=slot
                graphicContainer.addView(LinearLayout(context).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;addView(top,LinearLayout.LayoutParams(context.dp(46),context.dp(24)));addView(f,LinearLayout.LayoutParams(context.dp(46),context.dp(205)));addView(bottom,LinearLayout.LayoutParams(context.dp(46),context.dp(26)))},LinearLayout.LayoutParams(context.dp(49),-1))
            }
            addView(graphicContainer,ViewGroup.LayoutParams(-2,-1))
        }

        private fun buildParametric(){
            parametricContainer.background=rounded(Color.rgb(5,20,28),context.dp(10).toFloat(),OknColors.BORDER,context.dp(1));parametricContainer.setPadding(context.dp(10),context.dp(8),context.dp(10),context.dp(10))
            parametricContainer.addView(HorizontalScrollView(context).apply{isHorizontalScrollBarEnabled=false;addView(context.row().apply{for(band in 1..15){val b=context.txt(band.toString(),9,OknColors.MUTED,true,Gravity.CENTER).apply{background=rounded(OknColors.CARD2,context.dp(8).toFloat(),OknColors.BORDER,context.dp(1));setOnClickListener{actions.bandSelected(band)};isClickable=true};bandButtons+=b;addView(b,LinearLayout.LayoutParams(context.dp(39),context.dp(34)).apply{rightMargin=context.dp(4)})}},ViewGroup.LayoutParams(-2,-1))},LinearLayout.LayoutParams(-1,context.dp(39)))
            fun row(label:String,value:TextView,seek:SeekBar):View=context.row().apply{addView(context.txt(label,11,OknColors.TEXT,true),LinearLayout.LayoutParams(context.dp(76),context.dp(40)));addView(seek,LinearLayout.LayoutParams(0,context.dp(40),1f));addView(value,LinearLayout.LayoutParams(context.dp(82),context.dp(40)))}
            parametricContainer.addView(row("Frequency",freqValue,freqSeek));parametricContainer.addView(row("Q",qValue,qSeek));parametricContainer.addView(row("Gain",gainValue,gainSeek))
        }

        private fun setMode(parametric:Boolean){
            parametricMode=parametric
            modeGraphic.background=rounded(if(!parametric)OknColors.CYAN else OknColors.CARD2,context.dp(9).toFloat(),if(!parametric)OknColors.CYAN_BRIGHT else OknColors.BORDER,context.dp(1));modeGraphic.setTextColor(if(!parametric)OknColors.WHITE else OknColors.MUTED)
            modeParam.background=rounded(if(parametric)OknColors.CYAN else OknColors.CARD2,context.dp(9).toFloat(),if(parametric)OknColors.CYAN_BRIGHT else OknColors.BORDER,context.dp(1));modeParam.setTextColor(if(parametric)OknColors.WHITE else OknColors.MUTED)
            graphicContainer.parent?.let{(it as? View)?.visibility=if(parametric)View.GONE else View.VISIBLE}
            parametricContainer.visibility=if(parametric)View.VISIBLE else View.GONE
        }

        private fun changeSelected(freq:Float?=null,q:Float?=null,gain:Float?=null){
            val ch=latest.selectedChannel;val band=latest.selectedEqBand;val b=latest.eq.getOrNull(ch-1)?.getOrNull(band-1)?:return;if(!LiveEqPolicy.isWritable(b))return
            actions.eqChanged(ch,band,freq?:b.frequency,q?:b.q,gain?:b.boostDb)
        }

        override fun bind(s:DspState){
            latest=s;val ch=s.selectedChannel;val selected=s.selectedEqBand;val bands=s.eq.getOrNull(ch-1)?:emptyList();graph.bind(bands,selected)
            channelButtons.forEachIndexed{i,b->val active=i+1==ch;b.setTextColor(if(active)OknColors.WHITE else OknColors.MUTED);b.background=rounded(if(active)OknColors.CYAN else OknColors.CARD2,context.dp(8).toFloat(),if(active)OknColors.CYAN else OknColors.BORDER,context.dp(1))}
            bandButtons.forEachIndexed{i,b->val row=bands.getOrNull(i);val writable=row!=null&&LiveEqPolicy.isWritable(row);val active=i+1==selected;b.setTextColor(if(active)OknColors.WHITE else if(writable)OknColors.CYAN else OknColors.MUTED);b.alpha=if(writable)1f else .42f;b.background=rounded(if(active)OknColors.CYAN else OknColors.CARD2,context.dp(8).toFloat(),if(active)OknColors.CYAN else OknColors.BORDER,context.dp(1))}
            val mapping=graphicMapping(bands)
            faders.forEachIndexed{i,slot->val band=mapping.getOrNull(i)?:-1;slot.band=band;val row=if(band>0)bands.getOrNull(band-1) else null;val writable=row!=null&&LiveEqPolicy.isWritable(row);slot.fader.bindValue(row?.boostDb?:0f,writable);slot.top.text=if(row!=null)String.format(Locale.US,"%+.0f",row.boostDb) else "--";slot.bottom.text=if(row!=null)freqShort(row.frequency) else "--"}
            val selectedRow=bands.getOrNull(selected-1)
            if(selectedRow!=null&&LiveEqPolicy.isWritable(selectedRow)){
                freqValue.text=String.format(Locale.US,"%.0f Hz",selectedRow.frequency);qValue.text=String.format(Locale.US,"%.2f",selectedRow.q);gainValue.text=String.format(Locale.US,"%+.1f dB",selectedRow.boostDb)
                val t=(ln((selectedRow.frequency/20f).coerceIn(1f,1000f))/ln(1000f)).coerceIn(0f,1f);freqSeek.progress=(t*1000f).roundToInt();qSeek.bindValue(selectedRow.q);gainSeek.bindValue(selectedRow.boostDb)
            } else {freqValue.text="LOCKED";qValue.text="--";gainValue.text="--"}
        }

        private fun graphicMapping(rows:List<com.okn.dsp.protocol.EqBand48?>):List<Int>{
            val candidates=rows.mapIndexedNotNull{i,b->if(b!=null&&LiveEqPolicy.isWritable(b))i+1 else null}.toMutableSet();val refs=floatArrayOf(20f,50f,100f,200f,500f,1000f,2000f,5000f,10000f,20000f);val out=mutableListOf<Int>()
            refs.forEach{ref->val best=candidates.minByOrNull{band->val f=rows[band-1]!!.frequency;abs(ln((f/ref).coerceAtLeast(.0001f)))};if(best!=null){out+=best;candidates.remove(best)}};return out
        }
    }

    private inner class ChannelPanel:Panel {
        private val root=LinearLayout(context).apply{orientation=LinearLayout.VERTICAL;setPadding(0,context.dp(4),0,context.dp(10))}
        override val view:View=ScrollView(context).apply{addView(root,ViewGroup.LayoutParams(-1,-2))}
        private val boxes=mutableListOf<TextView>()
        init{
            root.addView(context.row().apply{addView(context.txt("◖",30,OknColors.CYAN,true,Gravity.CENTER),LinearLayout.LayoutParams(context.dp(55),context.dp(58)));addView(LinearLayout(context).apply{orientation=LinearLayout.VERTICAL;addView(context.txt("Channel",20,OknColors.TEXT,true));addView(context.txt("Select a channel for verified realtime EQ",11,OknColors.MUTED))},LinearLayout.LayoutParams(0,-2,1f))})
            val names=listOf("Front L","Front R","SUB","Rear L","Rear R","AUX L","AUX R")
            for(ch in 1..7){val box=context.txt("CH$ch     ${names[ch-1]}                         Open EQ  ›",13,OknColors.TEXT,true).apply{background=rounded(OknColors.CARD,context.dp(11).toFloat(),OknColors.BORDER,context.dp(1));setPadding(context.dp(14),0,context.dp(14),0);setOnClickListener{actions.channelSelected(ch);selectTab(1)};isClickable=true};boxes+=box;root.addView(box,LinearLayout.LayoutParams(-1,context.dp(61)).apply{bottomMargin=context.dp(7)})}
            root.addView(context.txt("Only verified PEAKING EQ writes are exposed in V1. Channel level/mute/phase packets are intentionally not guessed.",10,OknColors.MUTED).apply{setPadding(context.dp(8),context.dp(5),context.dp(8),context.dp(5))})
        }
        override fun bind(s:DspState){boxes.forEachIndexed{i,b->val active=i+1==s.selectedChannel;b.background=rounded(if(active)Color.rgb(8,45,64) else OknColors.CARD,context.dp(11).toFloat(),if(active)OknColors.CYAN else OknColors.BORDER,context.dp(1))}}
    }

    private inner class LockedPanel(private val title:String,private val message:String):Panel {
        private val root=context.card().apply{gravity=Gravity.CENTER;addView(context.txt("🔒",36,OknColors.CYAN,true,Gravity.CENTER),LinearLayout.LayoutParams(-1,context.dp(62)));addView(context.txt(title,22,OknColors.TEXT,true,Gravity.CENTER));addView(context.txt(message,12,OknColors.MUTED,false,Gravity.CENTER).apply{setPadding(context.dp(12),context.dp(10),context.dp(12),0)});addView(context.txt("No mock slider and no guessed DSP packet is enabled on this page.",10,OknColors.MUTED,false,Gravity.CENTER).apply{setPadding(context.dp(12),context.dp(8),context.dp(12),0)})}
        override val view:View=LinearLayout(context).apply{gravity=Gravity.CENTER;addView(root,LinearLayout.LayoutParams(-1,-2))}
        override fun bind(s:DspState)=Unit
    }

    private inner class OutputPanel:Panel {
        private val root=LinearLayout(context).apply{orientation=LinearLayout.VERTICAL;setPadding(0,context.dp(4),0,context.dp(10))}
        override val view:View=ScrollView(context).apply{addView(root,ViewGroup.LayoutParams(-1,-2))}
        private val connection=context.txt("Disconnected",12,OknColors.MUTED,true)
        private val gate=context.txt("Health Gate --",12,OknColors.MUTED,true)
        private val error=context.txt("No active error",10,OknColors.MUTED)
        init{
            root.addView(context.row().apply{addView(context.txt("⚙",29,OknColors.CYAN,true,Gravity.CENTER),LinearLayout.LayoutParams(context.dp(55),context.dp(58)));addView(LinearLayout(context).apply{orientation=LinearLayout.VERTICAL;addView(context.txt("Output / System",20,OknColors.TEXT,true));addView(context.txt("Connection and verified persistence controls",11,OknColors.MUTED))},LinearLayout.LayoutParams(0,-2,1f))})
            root.addView(context.card().apply{addView(context.txt("DSP Session",14,OknColors.TEXT,true));addView(connection,LinearLayout.LayoutParams(-1,context.dp(28)));addView(gate,LinearLayout.LayoutParams(-1,context.dp(28)));addView(error,LinearLayout.LayoutParams(-1,-2))},LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=context.dp(8)})
            root.addView(context.row().apply{addView(context.button("Reconnect"){actions.reconnect()},LinearLayout.LayoutParams(0,context.dp(48),1f));addView(context.button("Refresh"){actions.refresh()},LinearLayout.LayoutParams(0,context.dp(48),1f).apply{leftMargin=context.dp(7)});addView(context.button("Disconnect"){actions.disconnect()},LinearLayout.LayoutParams(0,context.dp(48),1f).apply{leftMargin=context.dp(7)})},LinearLayout.LayoutParams(-1,context.dp(56)))
            root.addView(context.button("Save current verified parameters to DSP (manual SaveParams)"){actions.saveParams()},LinearLayout.LayoutParams(-1,context.dp(50)).apply{topMargin=context.dp(5)})
            root.addView(context.button("Open Debug Log"){actions.showLogs()},LinearLayout.LayoutParams(-1,context.dp(50)).apply{topMargin=context.dp(7)})
            root.addView(context.card().apply{addView(context.txt("Verified hardware boundary",13,OknColors.GREEN,true));addView(context.txt("✓ Global scalar IDs 2,3,8,9,10,13,11\n✓ EQ CH1..CH7 actuator IDs 4,5,6,14,15,16,17\n✓ PEAKING type=12 full 48-byte records\n✓ One-inflight realtime queue\n✓ TrebleBoost callback-gated ≤0.5 dB slew\n\n🔒 Crossover / Delay / unknown Output writes remain locked until captured and verified.",10,OknColors.TEXT).apply{setPadding(0,context.dp(7),0,0)})},LinearLayout.LayoutParams(-1,-2).apply{topMargin=context.dp(9)})
        }
        override fun bind(s:DspState){connection.text="${s.connection}: ${s.connectionMessage}";connection.setTextColor(if(s.connection==ConnectionState.CONNECTED)OknColors.GREEN else OknColors.CYAN);gate.text=if(s.healthGatePass)"Health Gate PASS" else "Health Gate not ready";gate.setTextColor(if(s.healthGatePass)OknColors.GREEN else OknColors.MUTED);error.text=s.lastError?:"No active error";error.setTextColor(if(s.lastError!=null)OknColors.RED else OknColors.MUTED)}
    }

    private fun roundValue(id:Int,v:Float):Float=if(id==9)v.roundToInt().toFloat() else (v*10f).roundToInt()/10f
    private fun formatValue(id:Int,v:Float):String=if(id==9)String.format(Locale.US,"%.0f Hz",v) else String.format(Locale.US,"%.1f dB",v)
    private fun formatMin(v:Float,unit:String)=if(unit=="Hz")v.toInt().toString() else if(v==v.toInt().toFloat())v.toInt().toString() else v.toString()
    private fun formatMax(v:Float,unit:String)=if(unit=="Hz")v.toInt().toString() else if(v>0)"+${v.toInt()}" else v.toInt().toString()
    private fun freqShort(f:Float):String=if(f>=1000f){val k=f/1000f;if(abs(k-k.roundToInt())<.05f)"${k.roundToInt()}K" else String.format(Locale.US,"%.1fK",k)}else f.roundToInt().toString()
}
