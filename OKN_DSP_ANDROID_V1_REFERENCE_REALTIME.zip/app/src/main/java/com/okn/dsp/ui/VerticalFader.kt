package com.okn.dsp.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import kotlin.math.roundToInt

/** Reference-style vertical EQ fader, continuously emitting gain while the finger moves. */
class VerticalFader(context: Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var value = 0f
    private var enabledForDsp = false
    private var onChange: ((Float) -> Unit)? = null

    fun configure(value: Float, enabled: Boolean, onChange: (Float) -> Unit) {
        this.value = value.coerceIn(-12f,12f)
        enabledForDsp = enabled
        this.onChange = onChange
        invalidate()
    }

    fun bindValue(v: Float, enabled: Boolean = enabledForDsp) {
        value = v.coerceIn(-12f,12f)
        enabledForDsp = enabled
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(resolveSize(context.dp(45), widthMeasureSpec), resolveSize(context.dp(205), heightMeasureSpec))
    }

    private fun yFor(v: Float): Float {
        val top = context.dp(20).toFloat()
        val bottom = height-context.dp(18).toFloat()
        val t = ((12f-v)/24f).coerceIn(0f,1f)
        return top+(bottom-top)*t
    }

    private fun valueFor(y: Float): Float {
        val top = context.dp(20).toFloat()
        val bottom = height-context.dp(18).toFloat()
        val t = ((y-top)/(bottom-top)).coerceIn(0f,1f)
        return 12f-24f*t
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val x = width/2f
        val top = context.dp(20).toFloat()
        val bottom = height-context.dp(18).toFloat()
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = context.dp(8).toFloat()
        p.color = Color.rgb(24,43,55)
        c.drawLine(x,top,x,bottom,p)
        val y = yFor(value)
        p.strokeWidth = context.dp(5).toFloat()
        p.color = if(enabledForDsp) OknColors.CYAN else Color.rgb(65,79,88)
        c.drawLine(x,bottom,x,y,p)
        p.style = Paint.Style.FILL
        p.color = if(enabledForDsp) Color.WHITE else Color.rgb(135,145,152)
        c.drawCircle(x,y,context.dp(7).toFloat(),p)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!enabledForDsp) return false
        when(event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val v = valueFor(event.y)
                if (kotlin.math.abs(v-value) >= 0.03f) {
                    value = (v*10f).roundToInt()/10f
                    invalidate()
                    onChange?.invoke(value)
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                performClick(); return true
            }
        }
        return super.onTouchEvent(event)
    }
    override fun performClick(): Boolean = super.performClick()
}
