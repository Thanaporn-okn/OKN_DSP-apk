#!/usr/bin/env python3
from pathlib import Path
import hashlib, re, sys, xml.etree.ElementTree as ET

R=Path(__file__).resolve().parent
checks=[]
def need(ok,msg):
    checks.append((ok,msg))
    if not ok: print('FAIL:',msg)

def text(rel): return (R/rel).read_text(encoding='utf-8')

build=text('app/build.gradle.kts')
need('applicationId = "com.okn.dsp"' in build,'applicationId com.okn.dsp')
need('versionCode = 1' in build,'versionCode 1')
need('versionName = "1.0.0-v1"' in build,'versionName 1.0.0-v1')
need('compileSdk = 35' in build and 'targetSdk = 35' in build,'Android 35 baseline')

manifest=R/'app/src/main/AndroidManifest.xml'
ET.parse(manifest)
m=manifest.read_text(encoding='utf-8')
need('android:name=".OknDspApplication"' in m,'process-scoped Application registered')
need('android:configChanges="orientation|screenSize|smallestScreenSize|keyboardHidden"' in m,'orientation session-preservation config')

ble=text('app/src/main/java/com/okn/dsp/ble/BleProfile.kt')
for u in ('0000ab00-0000-1000-8000-00805f9b34fb','0000ab01-0000-1000-8000-00805f9b34fb','0000ab02-0000-1000-8000-00805f9b34fb'):
    need(u in ble,f'BLE verified UUID {u[:8]}')

scalars=text('app/src/main/java/com/okn/dsp/protocol/VerifiedScalarControls.kt')
for token in ('VerifiedScalarControl(2,','VerifiedScalarControl(3,','VerifiedScalarControl(8,','VerifiedScalarControl(9,','VerifiedScalarControl(10,','VerifiedScalarControl(13,','VerifiedScalarControl(11,'):
    need(token in scalars,f'scalar allow-list {token}')

emap=text('app/src/main/java/com/okn/dsp/protocol/ConfirmedDspMap.kt')
need('intArrayOf(4, 5, 6, 14, 15, 16, 17)' in emap,'7-channel EQ actuator map')
need('EQ_BAND_COUNT = 15' in emap and 'EQ_BAND_BYTES = 48' in emap,'15x48 EQ record geometry')

save=text('app/src/main/java/com/okn/dsp/protocol/SaveParamsPolicy.kt')
need('570000000700000000' in save,'exact SaveParams vector self-check')
wg=text('app/src/main/java/com/okn/dsp/protocol/WriteGate.kt')
need('enabled: Boolean = false' in wg,'generic write gate locked')

queue=text('app/src/main/java/com/okn/dsp/queue/RealtimeCommandQueue.kt')
need('minPacingMs: Long = 38L' in queue,'38ms realtime pacing')
need('writeTimeoutMs = 2500L' in queue,'2.5s GATT callback timeout')
ramp=text('app/src/main/java/com/okn/dsp/smoothing/ScalarRampController.kt')
need('id == 11 -> 0.5f' in ramp and 'if (id == 11) 48L' in ramp,'TrebleBoost <=0.5dB / 48ms callback-gated profile')

runtime=text('app/src/main/java/com/okn/dsp/core/DspRuntime.kt')
app=text('app/src/main/java/com/okn/dsp/OknDspApplication.kt')
need('class DspRuntime' in runtime and 'runtime = DspRuntime(this)' in app,'new process-scoped V1 runtime')

ui=text('app/src/main/java/com/okn/dsp/ui/ReferenceDspUi.kt')
for label in ('Global Controls','Graphic EQ','Parametric EQ','Crossover','Delay','Output','Save Preset','Load Preset'):
    need(label in ui,f'reference UI element: {label}')
need('RealtimeEqGraphView' in ui and 'VerticalFader' in ui and 'KnobView' in ui,'realtime custom UI controls wired')

prefs=text('app/src/main/java/com/okn/dsp/persistence/DspPreferences.kt')
need('okn_dsp_v1_local_state' in prefs,'V1 persistent state namespace')
need('debounceMs: Long = 60L' in prefs,'latest-state local persistence debounce')

ref=R/'evidence/OKN_DSP_V1_UI_MASTER_REFERENCE.png'
need(ref.is_file(),'UI master evidence embedded')
if ref.is_file():
    print('UI_REFERENCE_SHA256',hashlib.sha256(ref.read_bytes()).hexdigest())

# Parser-level structural guard: braces / XML / required files.
kt=list((R/'app/src/main/java').rglob('*.kt'))
need(len(kt)>=25,f'Kotlin source set present ({len(kt)} files)')
for p in kt:
    s=p.read_text(encoding='utf-8')
    need(s.count('{')==s.count('}'),f'balanced Kotlin braces {p.relative_to(R)}')

fails=[m for ok,m in checks if not ok]
print(f'PREFLIGHT checks={len(checks)} pass={len(checks)-len(fails)} fail={len(fails)}')
if fails: sys.exit(1)
print('PREFLIGHT V1 PASS')
