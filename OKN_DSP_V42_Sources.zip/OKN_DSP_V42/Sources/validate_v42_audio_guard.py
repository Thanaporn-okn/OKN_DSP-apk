#!/usr/bin/env python3
from pathlib import Path
import hashlib, re, sys

ROOT = Path(__file__).resolve().parents[1]
BLE = ROOT / 'app/src/main/java/com/okn/dsp/BleManager.java'
DSP = ROOT / 'app/src/main/java/com/okn/dsp/DspProtocol.java'
VIEW = ROOT / 'app/src/main/java/com/okn/dsp/DspView.java'
GRADLE = ROOT / 'app/build.gradle'
ble = BLE.read_text()
dsp = DSP.read_text()
view = VIEW.read_text()
gradle = GRADLE.read_text()

def req(cond, msg):
    if not cond:
        print('FAIL:', msg)
        sys.exit(1)

def method(text, marker):
    i = text.index(marker)
    b = text.index('{', i)
    depth = 0
    for j in range(b, len(text)):
        if text[j] == '{': depth += 1
        elif text[j] == '}':
            depth -= 1
            if depth == 0: return text[i:j+1]
    raise AssertionError('unclosed method ' + marker)

req("versionCode 1042" in gradle and "versionName '42.0.0'" in gradle, 'V42 version mismatch')

# V41 persistent-save / restore guarantees retained.
req('static final int ID_SAVE_PARAMS = 7;' in dsp, 'SaveParams ID7 missing')
req('encodeWrite(ID_SAVE_PARAMS, 0, new byte[0])' in method(dsp, '    static byte[] encodeSaveParamsTrigger('), 'SaveParams serializer changed')
req('startDescriptorRequest("SAVE_PRECHECK")' in ble, 'fresh save precheck missing')
req('startDescriptorRequest("SAVE_POSTCHECK")' in ble, 'fresh save postcheck missing')
req('requestVerifiedRestore()' in ble and 'startDescriptorRequest("RESTORE")' in ble, 'readback-only restore missing')
req('safePeakingRows == EXPECTED_SAFE_PEAKING_ROWS' in ble, '55-row PEQ gate missing')
req('boolean eqOk = eqCount == 105;' in ble, '105/105 EQ health gate missing')
req('SAVE UNCONFIRMED' in ble and 'DO NOT RETRY automatically' in ble, 'save fail-closed warning missing')
req('writeTickets.isEmpty()' in ble, 'clean GATT save boundary missing')

# DspProtocol and coefficient builders must remain V41-identical.
req(hashlib.sha256(DSP.read_bytes()).hexdigest() == 'e0b3af39fa0de56812600801765d6d544fd3f093ae8f37d043e3bf99e41c5b46', 'DspProtocol changed from V41')
expected_methods = {
    'peakingFromCurrent': '18f6cb0577c711ea817c8441f4b3b2fc91a4a5d5bae0d61051926074858b95ae',
    'peakingShapeFromCurrent': 'e3f8d840e116bc3d32bad459db3883867f8afc62a87c8553131397ee133e4e86',
    'firstBandGainFromCurrent': '89f089d8d8bc6bfd54074e35e949fa393719d64d3884fc8ce133b99bc100ddee',
    'encodeEqWrite': '9de90148f2e6f390f9144ffc8f6c029a00ca6276bdeb8696aa319609573001e5',
}
for name, expected in expected_methods.items():
    body = method(dsp, '    static ' + ('byte[] ' if name == 'encodeEqWrite' else 'EqBand ') + name + '(')
    req(hashlib.sha256(body.encode()).hexdigest() == expected, name + ' changed')

# Normal proven timing remains present.
req('ORIGINAL_COMMAND_CADENCE_MS = 380L' in ble, 'normal 380 ms scheduler changed')
req('EQ_REALTIME_MIN_GAP_MS = 45L' in ble, 'normal Gain 45 ms changed')
req('EQ_SHAPE_MIN_GAP_MS = 110L' in ble, 'normal F/Q 110 ms changed')
req('EQ_RESET_MIN_GAP_MS = 110L' in ble, 'normal Reset 110 ms changed')
req('DspProtocol.peakingFromCurrent(current, 0f)' in ble, 'Gain-only reset target changed')

# V42 Hi-Fi coexistence guard.
checks = {
    'audio_callback': 'AudioManager.AudioPlaybackCallback' in ble and 'registerAudioPlaybackCallback' in ble,
    'media_usage': 'AudioAttributes.USAGE_MEDIA' in ble and 'AudioAttributes.USAGE_GAME' in ble,
    'low_power': 'BluetoothGatt.CONNECTION_PRIORITY_LOW_POWER' in ble,
    'balanced_interactive': 'BluetoothGatt.CONNECTION_PRIORITY_BALANCED' in ble and 'holdInteractiveBlePriority()' in ble,
    'sensor_5000': 'AUDIO_GUARD_SENSOR_POLL_MS = 5000L' in ble,
    'quiet_1200': 'AUDIO_GUARD_POST_CONTROL_QUIET_MS = 1200L' in ble,
    'gain_90': 'AUDIO_GUARD_EQ_GAIN_MIN_GAP_MS = 90L' in ble,
    'shape_180': 'AUDIO_GUARD_EQ_SHAPE_MIN_GAP_MS = 180L' in ble,
    'reset_180': 'AUDIO_GUARD_EQ_RESET_MIN_GAP_MS = 180L' in ble,
    'dynamic_gain_gap': 'long minGap = eqGainMinGapMs();' in ble,
    'dynamic_shape_gap': 'long shapeGap = eqShapeMinGapMs();' in ble,
    'poll_rate_limit': 'now - lastSensorPollUptimeMs < AUDIO_GUARD_SENSOR_POLL_MS' in ble,
    'post_write_quiet': 'now - lastControlWriteUptimeMs < AUDIO_GUARD_POST_CONTROL_QUIET_MS' in ble,
    'unregister': 'unregisterAudioPlaybackCallback' in ble,
    'ui_v42': 'V42 DSP SYNC' in view,
}
for k, v in checks.items(): req(v, k)

# The verified poll packet IDs/lengths are unchanged.
req('ORIGINAL_POLL_IDS = {19, 20, 0, 21}' in ble, 'poll IDs changed')
req('ORIGINAL_POLL_LENGTHS = {1, 1, 4, 4}' in ble, 'poll lengths changed')

# Poll throttling must occur only after user/scalar queues are handled.
sched = method(ble, '    private void originalCommandSchedulerTick(')
req(sched.index('if (next != null)') < sched.index('AUDIO_GUARD_SENSOR_POLL_MS'), 'media guard blocks user scalar writes')
req(sched.index('!eqRealtimePending.isEmpty()') < sched.index('AUDIO_GUARD_SENSOR_POLL_MS'), 'media guard blocks EQ priority')

print('V42_AUDIO_HIFI_GUARD_STATIC_PASS')
print('versionName=42.0.0 versionCode=1042')
print('normal: poll/scalar=380ms gain=45ms fq=110ms reset=110ms')
print('media: sensorPoll=5000ms quiet=1200ms gain=90ms fq=180ms reset=180ms')
print('DspProtocol V41 hash: PASS')
