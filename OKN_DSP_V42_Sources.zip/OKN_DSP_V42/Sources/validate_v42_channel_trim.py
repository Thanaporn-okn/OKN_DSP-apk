#!/usr/bin/env python3
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DESC = ROOT / 'Sources' / 'ProtocolEvidence' / 'GoloPine_DeviceDescription_REAL_20260906_204555.json'
PROTO = ROOT / 'app' / 'src' / 'main' / 'java' / 'com' / 'okn' / 'dsp' / 'DspProtocol.java'
BLE = ROOT / 'app' / 'src' / 'main' / 'java' / 'com' / 'okn' / 'dsp' / 'BleManager.java'
VIEW = ROOT / 'app' / 'src' / 'main' / 'java' / 'com' / 'okn' / 'dsp' / 'DspView.java'
GRADLE = ROOT / 'app' / 'build.gradle'

EQ_IDS = [4, 5, 6, 14, 15, 16, 17]
ANCHOR_BAND0 = 1  # hardware band 2
FS = 44100.0


def peaking(f, q, boost):
    a = 10.0 ** (boost / 40.0)
    w0 = 2.0 * math.pi * f / FS
    alpha = math.sin(w0) / (2.0 * q)
    a0 = 1.0 + alpha / a
    return (
        (1.0 + alpha * a) / a0,
        (-2.0 * math.cos(w0)) / a0,
        (1.0 - alpha * a) / a0,
        (-2.0 * math.cos(w0)) / a0,
        (1.0 - alpha / a) / a0,
    )


def close(a, b, tol=2e-6):
    return abs(a - b) <= tol * max(1.0, abs(a), abs(b))


def main():
    obj = json.loads(DESC.read_text(encoding='utf-8'))
    by_id = {a.get('ID'): a for a in obj.get('actuators', [])}

    checked = 0
    for actuator_id in EQ_IDS:
        actuator = by_id.get(actuator_id)
        assert actuator is not None, f'missing EQ actuator {actuator_id}'
        rows = actuator.get('UFE_TYPE_BIQUAD_CASCADE15_F')
        assert isinstance(rows, list) and len(rows) == 15, f'bad cascade {actuator_id}'
        row = rows[ANCHOR_BAND0]
        assert row.get('typ') == 12, f'anchor not PEAKING on ID {actuator_id}'
        assert abs(float(row.get('R', 999))) <= 1e-6, f'anchor R not safe on ID {actuator_id}'
        assert abs(float(row.get('G', 999))) <= 1e-6, f'factory anchor G not 0 on ID {actuator_id}'
        base = peaking(float(row['F']), float(row['Q']), float(row['B']))
        current = tuple(float(row[k]) for k in ('B0', 'B1', 'B2', 'A1', 'A2'))
        assert all(close(a, b) for a, b in zip(current, base)), f'anchor coefficients mismatch ID {actuator_id}'

        for trim_db in (-12.0, -6.0, 0.0, 6.0, 12.0):
            linear = 10.0 ** (trim_db / 20.0)
            scaled = (base[0] * linear, base[1] * linear, base[2] * linear, base[3], base[4])
            # Denominator is unchanged; numerator shares one constant ratio => all-frequency gain.
            assert close(scaled[3], base[3]) and close(scaled[4], base[4])
            ratios = [scaled[i] / base[i] for i in range(3) if abs(base[i]) > 1e-9]
            assert ratios and max(ratios) - min(ratios) < 1e-10
            assert abs(20.0 * math.log10(ratios[0]) - trim_db) < 1e-8
        checked += 1

    proto = PROTO.read_text(encoding='utf-8')
    ble = BLE.read_text(encoding='utf-8')
    view = VIEW.read_text(encoding='utf-8')
    gradle = GRADLE.read_text(encoding='utf-8')
    assert "versionCode 1042" in gradle and "versionName '42.0.0'" in gradle, 'V42 version mismatch'
    required_proto = [
        'CHANNEL_TRIM_BAND0 = 1',
        'withPeakingCellGain',
        'channelTrimFromCurrent',
        'inferChannelTrimDb',
        'ID_SAVE_PARAMS = 7',
        'encodeSaveParamsTrigger',
    ]
    required_ble = [
        'setChannelTrimRealtime',
        'applyChannelTrimOverlay',
        'listener.onChannelTrimValue',
        'DspProtocol.CHANNEL_TRIM_BAND0',
        'void requestPersistentSave()',
        'startDescriptorRequest("SAVE_PRECHECK")',
        'startDescriptorRequest("SAVE_POSTCHECK")',
        'requestVerifiedRestore()',
    ]
    required_view = [
        'sendVerifiedChannelTrim',
        'ble.setChannelTrimRealtime',
        'CH1–CH7 output trim reset to 0 dB on DSP',
    ]
    for token in required_proto:
        assert token in proto, f'missing DspProtocol hook: {token}'
    for token in required_ble:
        assert token in ble, f'missing BleManager hook: {token}'
    for token in required_view:
        assert token in view, f'missing DspView hook: {token}'

    print(f'V42 channel-trim validation PASS: {checked}/7 anchor rows verified; ±12 dB overlay math and source hooks OK')


if __name__ == '__main__':
    main()
