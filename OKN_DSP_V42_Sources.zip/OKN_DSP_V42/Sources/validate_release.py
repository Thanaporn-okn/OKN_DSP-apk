#!/usr/bin/env python3
from pathlib import Path
import hashlib, json, re

ROOT = Path(__file__).resolve().parents[1]
BLE = ROOT / 'app/src/main/java/com/okn/dsp/BleManager.java'
DSP = ROOT / 'app/src/main/java/com/okn/dsp/DspProtocol.java'
VIEW = ROOT / 'app/src/main/java/com/okn/dsp/DspView.java'
STATE = ROOT / 'app/src/main/java/com/okn/dsp/DspState.java'
CV = ROOT / 'app/src/main/java/com/okn/dsp/ChannelVolumeProtocol.java'
GRADLE = ROOT / 'app/build.gradle'
STOCK = ROOT / 'Sources/ProtocolEvidence/GoloPine_DeviceDescription_REAL_20260906_204555.json'

ble = BLE.read_text(encoding='utf-8')
dsp = DSP.read_text(encoding='utf-8')
view = VIEW.read_text(encoding='utf-8')
state = STATE.read_text(encoding='utf-8')
cv = CV.read_text(encoding='utf-8')
gradle = GRADLE.read_text(encoding='utf-8')

def req(cond, msg):
    if not cond:
        raise AssertionError(msg)

def method(text, marker):
    i = text.index(marker)
    b = text.index('{', i)
    depth = 0
    for j in range(b, len(text)):
        if text[j] == '{': depth += 1
        elif text[j] == '}':
            depth -= 1
            if depth == 0:
                return text[i:j+1]
    raise AssertionError('unclosed method: ' + marker)

def sha(s):
    return hashlib.sha256(s.encode('utf-8')).hexdigest()

req('versionCode 1042' in gradle and "versionName '42.0.0'" in gradle, 'V42 version mismatch')
req('static final int[] IDS = {22, 23, 24, 25, 26, 27, 28};' in cv, 'dedicated CH IDs mismatch')
req('MIN_DB = -70f' in cv and 'MAX_DB = 6f' in cv and 'STEP_DB = 0.5f' in cv, 'CH volume range/step mismatch')
req('ChannelVolumeProtocol.channelForActuator' in ble, 'live descriptor capability gate missing')
req('channelVolumeCount == ChannelVolumeProtocol.CHANNELS' in ble, 'all-seven capability gate missing')
req('!channelVolumeAvailable' in method(ble, '    void setChannelVolumeRealtime('), 'writer is not fail-closed')
req('PendingCommand.channelVolume(channel0, safe)' in ble, 'dedicated writer not queued')
req('chMinus' in view and 'chPlus' in view and 'ChannelVolumeProtocol.STEP_DB' in view, '+/- UI missing')
req('channelVolume[ch] = clamp(value, -70f, 6f);' in state, 'state range mismatch')

# Dedicated CH namespace must never overlap the stock EQ actuator IDs.
eq_ids = {4, 5, 6, 14, 15, 16, 17}
ch_ids = {22, 23, 24, 25, 26, 27, 28}
req(eq_ids.isdisjoint(ch_ids), 'CH IDs overlap EQ IDs')
for eqid in sorted(eq_ids):
    req(not re.search(r'\b' + str(eqid) + r'\b', cv), f'EQ actuator ID {eqid} leaked into ChannelVolumeProtocol')

# The real stock descriptor must stay fail-closed: it does not contain the custom seven.
obj = json.loads(STOCK.read_text(encoding='utf-8'))
acts = obj.get('actuators', [])
stock_pairs = {(int(a.get('ID', -1)), str(a.get('name', ''))) for a in acts if isinstance(a, dict)}
for ch, aid in enumerate(range(22, 29), 1):
    req((aid, f'Channel{ch}Volume') not in stock_pairs, f'stock unexpectedly exposes Channel{ch}Volume')

# Frozen EQ writer/filter methods from trusted V40/V41 must remain identical.
expected = {
    'BleManager.setEqRealtime':'f4f738c886298e476dad58135a5d29b36937aaa7dbf7eabe7853dc8d9e761c9a',
    'BleManager.setEqShapeRealtime':'e702693eccb788da71d156db94dc21824f1dacab20d19e1d89aaedceb94a6110',
    'BleManager.scheduleEqRealtimePump':'a05ea21d9f11980fff095c6053ec81ccd5c7ba5d7a725ff2854f3f2a87bf6db6',
    'BleManager.scheduleEqShapePump':'97a5c9080071ec5bce70999d2c7a122ad2e2a77d494a94f1040fd90662c4e26e',
    'BleManager.sendScheduledControl':'8c39c0643084615777997900f428e3c32971bdd5e2afa0d768c04c4dbfedf777',
    'BleManager.writeNoResponse':'e6895bee7c3f2d12c2531d7d48346559d6b00a4c227b38ecfc63f2ce2a9d9256',
    'BleManager.resetEqSafe':'eab920cc4b25b018c9e263f1a43bf4391569119663db101954a2661803864d18',
    'DspProtocol.peakingFromCurrent':'18f6cb0577c711ea817c8441f4b3b2fc91a4a5d5bae0d61051926074858b95ae',
    'DspProtocol.peakingShapeFromCurrent':'e3f8d840e116bc3d32bad459db3883867f8afc62a87c8553131397ee133e4e86',
    'DspProtocol.firstBandGainFromCurrent':'89f089d8d8bc6bfd54074e35e949fa393719d64d3884fc8ce133b99bc100ddee',
    'DspProtocol.encodeEqWrite':'9de90148f2e6f390f9144ffc8f6c029a00ca6276bdeb8696aa319609573001e5',
}
checks = [
    ('BleManager.setEqRealtime', ble, '    void setEqRealtime('),
    ('BleManager.setEqShapeRealtime', ble, '    void setEqShapeRealtime('),
    ('BleManager.scheduleEqRealtimePump', ble, '    private void scheduleEqRealtimePump('),
    ('BleManager.scheduleEqShapePump', ble, '    private void scheduleEqShapePump('),
    ('BleManager.sendScheduledControl', ble, '    private void sendScheduledControl('),
    ('BleManager.writeNoResponse', ble, '    private boolean writeNoResponse('),
    ('BleManager.resetEqSafe', ble, '    int resetEqSafe('),
    ('DspProtocol.peakingFromCurrent', dsp, '    static EqBand peakingFromCurrent('),
    ('DspProtocol.peakingShapeFromCurrent', dsp, '    static EqBand peakingShapeFromCurrent('),
    ('DspProtocol.firstBandGainFromCurrent', dsp, '    static EqBand firstBandGainFromCurrent('),
    ('DspProtocol.encodeEqWrite', dsp, '    static byte[] encodeEqWrite('),
]
for name, text, marker in checks:
    body = method(text, marker)
    if name in ('BleManager.setEqRealtime', 'BleManager.setEqShapeRealtime', 'BleManager.resetEqSafe'):
        body = body.replace(' || saveActive', '')
    req(sha(body) == expected[name], name + ' changed: EQ freeze violated')

print('V42 release validation: PASS')
print('CH Volume: IDs 22..28, -70..+6 dB, step 0.5 dB, all-seven descriptor gate')
print('Stock descriptor: fail-closed PASS')
print('Frozen EQ writer/filter hashes: PASS')
