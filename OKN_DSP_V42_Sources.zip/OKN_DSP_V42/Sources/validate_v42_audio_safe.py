#!/usr/bin/env python3
from pathlib import Path
import hashlib, re, sys

ROOT = Path(__file__).resolve().parents[1]
BLE = ROOT / 'app/src/main/java/com/okn/dsp/BleManager.java'
DSP = ROOT / 'app/src/main/java/com/okn/dsp/DspProtocol.java'
VIEW = ROOT / 'app/src/main/java/com/okn/dsp/DspView.java'
GRADLE = ROOT / 'app/build.gradle'
ble = BLE.read_text()
dsp = DSP.read_text()
view = VIEW.read_text()
gradle = GRADLE.read_text()

def method(text, marker):
    i = text.index(marker); b = text.index('{', i); depth = 0
    for j in range(b, len(text)):
        if text[j] == '{': depth += 1
        elif text[j] == '}':
            depth -= 1
            if depth == 0: return text[i:j+1]
    raise AssertionError('unclosed method ' + marker)

def sha_text(s): return hashlib.sha256(s.encode()).hexdigest()
def req(cond, msg):
    if not cond: raise AssertionError(msg)

req("versionCode 1042" in gradle and "versionName '42.0.0'" in gradle, 'V42 version mismatch')
req('EQ_REALTIME_MIN_GAP_MS = 90L' in ble, 'V42 EQ audio-safe pacing missing')
req('LIVE_WRITE_TIMEOUT_MS = 3000L' in ble, 'V42 callback tolerance missing')
req('AUDIO_SAFE_IDLE_PRIORITY_DELAY_MS = 1200L' in ble, 'idle-priority delay missing')
req('RECONNECT_BACKOFF_MIN_MS = 2500L' in ble and 'RECONNECT_BACKOFF_MAX_MS = 12000L' in ble, 'reconnect backoff bounds missing')
req('BluetoothGatt.CONNECTION_PRIORITY_LOW_POWER' in ble, 'idle LOW_POWER request missing')
req('BluetoothGatt.CONNECTION_PRIORITY_BALANCED' in ble, 'active BALANCED request missing')
req('scheduleReconnect();' in method(ble, '    private void sessionFault('), 'sessionFault does not use backoff reconnect')
req('main.postDelayed(this::startScan, 900L)' not in ble, 'old 900 ms reconnect loop remains')
req('main.postDelayed(BleManager.this::startScan, 1500L)' not in ble, 'old 1500 ms reconnect loop remains')
req('ORIGINAL_COMMAND_CADENCE_MS = 380L' in ble, 'official scalar/poll cadence changed')
req('EQ_SHAPE_MIN_GAP_MS = 110L' in ble, 'F/Q cadence changed')
req('EQ_RESET_MIN_GAP_MS = 110L' in ble, 'Safe Reset cadence changed')
req('private static final int[] ORIGINAL_POLL_IDS = {19, 20, 0, 21};' in ble, 'poll IDs changed')
req('private static final int[] ORIGINAL_POLL_LENGTHS = {1, 1, 4, 4};' in ble, 'poll lengths changed')
req('BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE' in ble, 'verified ATT write type changed')

# DspProtocol must be byte-for-byte V41 to prove no packet/address/coefficient edits.
req(hashlib.sha256(DSP.read_bytes()).hexdigest() == 'e0b3af39fa0de56812600801765d6d544fd3f093ae8f37d043e3bf99e41c5b46',
    'DspProtocol.java differs from V41 frozen bytes')

# Critical transport serializer/write methods remain byte-for-byte at method level.
expected = {
    'BleManager.sendScheduledControl':'8c39c0643084615777997900f428e3c32971bdd5e2afa0d768c04c4dbfedf777',
    'BleManager.writeNoResponse':'e6895bee7c3f2d12c2531d7d48346559d6b00a4c227b38ecfc63f2ce2a9d9256',
    'DspProtocol.peakingFromCurrent':'18f6cb0577c711ea817c8441f4b3b2fc91a4a5d5bae0d61051926074858b95ae',
    'DspProtocol.peakingShapeFromCurrent':'e3f8d840e116bc3d32bad459db3883867f8afc62a87c8553131397ee133e4e86',
    'DspProtocol.firstBandGainFromCurrent':'89f089d8d8bc6bfd54074e35e949fa393719d64d3884fc8ce133b99bc100ddee',
    'DspProtocol.encodeEqWrite':'9de90148f2e6f390f9144ffc8f6c029a00ca6276bdeb8696aa319609573001e5',
}
checks = [
    ('BleManager.sendScheduledControl', ble, '    private void sendScheduledControl('),
    ('BleManager.writeNoResponse', ble, '    private boolean writeNoResponse('),
    ('DspProtocol.peakingFromCurrent', dsp, '    static EqBand peakingFromCurrent('),
    ('DspProtocol.peakingShapeFromCurrent', dsp, '    static EqBand peakingShapeFromCurrent('),
    ('DspProtocol.firstBandGainFromCurrent', dsp, '    static EqBand firstBandGainFromCurrent('),
    ('DspProtocol.encodeEqWrite', dsp, '    static byte[] encodeEqWrite('),
]
for name, text, marker in checks:
    req(sha_text(method(text, marker)) == expected[name], name + ' changed from V41')

# V38/V39/V40/V41 safety features must still be visible.
req('safePeakingRows == EXPECTED_SAFE_PEAKING_ROWS' in ble, 'strict-safe 55-row gate missing')
req('DspProtocol.peakingFromCurrent(current, 0f)' in ble, 'Gain-only Safe Reset target changed')
req('startDescriptorRequest("SAVE_PRECHECK")' in ble and 'startDescriptorRequest("SAVE_POSTCHECK")' in ble, 'V41 guarded save checks missing')
req('requestVerifiedRestore()' in ble and 'startDescriptorRequest("RESTORE")' in ble, 'readback-only restore missing')
req(view.count('requestPersistentSave()') == 1, 'unexpected SaveParams caller count')
req('V42 AUDIO-SAFE DSP SYNC' in view, 'V42 UI diagnostic missing')

# This codebase is a controller, not an Android PCM engine. Do not fake Hi-Res claims in code.
all_java = '\n'.join(p.read_text(errors='ignore') for p in (ROOT/'app/src/main/java').rglob('*.java'))
for forbidden in ('AudioTrack', 'AudioRecord', 'MediaPlayer', 'ENCODING_PCM_24BIT'):
    req(forbidden not in all_java, 'unexpected PCM-engine claim/path: ' + forbidden)

print('V42 audio-safe transport validation: PASS')
print('versionName=42.0.0 versionCode=1042')
print('DspProtocol V41 frozen SHA256: PASS')
print('packet/address/filter serializers frozen: PASS')
print('EQ Gain gap=90ms, live timeout=3000ms, reconnect backoff=2500..12000ms')
