# OKN DSP V42

Base: **V41 guarded Save/Restore + verified DSP readback**.

V42 turns the seven **Out Volume Ch1-Ch7** sliders into real DSP controls without inventing new actuator IDs. The real device descriptor exposes output cascades on actuator IDs `4,5,6,14,15,16,17`; V42 uses the native `G` (cell gain) field in the first 48-byte biquad record of each cascade. Frequency/Q/bass/treble metadata and denominator coefficients remain preserved.

The output-gain lane is latest-value-wins and paced at **120 ms minimum** to reduce BLE backlog and audible stutter while dragging. DSP readback remains authoritative on connect/reconnect/refresh, so the Out Volume sliders are synchronized from the real `G` values. CH3 Band1 is the device's General Low-pass `G` field, so its EQ Gain display and Out Volume Ch3 intentionally mirror the same hardware field.

No standalone ChannelVolume actuator is claimed. SaveParams ID7, V38 safe-PEQ gating, V39 safe reset, V40 readback, and V41 guarded Save/Restore remain in place.

Version: **42.0.0** (`versionCode 1042`).
