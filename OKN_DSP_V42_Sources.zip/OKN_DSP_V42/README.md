# OKN DSP V42

Base: **V41 guarded Save/Restore** and the existing real-device BLE/UFE protocol stack.

## V42: CH1–CH7 volume now controls the real DSP

V41 already showed seven channel-volume sliders, but they were local UI values only. V42 makes those sliders transmit real hardware changes while avoiding any guessed actuator ID.

The captured Device Description does **not** expose separate CH1..CH7 FLOAT32 volume actuators. It does expose seven 15-stage biquad cascades (actuator IDs 4, 5, 6, 14, 15, 16, 17). Hardware band 2 is a verified active PEAKING row on all seven channels. V42 uses that row's cell gain as an all-frequency output trim: `G` stores the dB trim and `B0/B1/B2` are scaled by `10^(G/20)`, preserving F/Q/Boost and A1/A2.

- CH1..CH7 trim range: **-12.0 dB to +12.0 dB**
- Slider step: **0.5 dB**
- Fresh DSP readback restores the real trim value to the UI.
- EQ edits on the anchor row preserve the channel trim.
- Safe Reset EQ preserves the channel trim.
- Older UI-only channel values migrate to **0 dB** so an update cannot replay fake levels into hardware.
- Persistent DSP save is still manual: use **Save DSP** after the desired levels are set.

Positive channel trim can increase clipping risk. Start around 0 dB and increase only when needed.

See `Sources/V42_CHANNEL_TRIM.txt` and run `python3 Sources/validate_v42_channel_trim.py` for the packaged validation.

Version: **42.0.0** (`versionCode 1042`)
