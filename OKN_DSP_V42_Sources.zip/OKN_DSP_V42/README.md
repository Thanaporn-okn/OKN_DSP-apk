# OKN DSP V42

V42 is based on **V41** and keeps the verified BLE/UFE writer, guarded SaveParams flow, and DSP readback synchronization.

## What V42 changes

- **Hi-Fi Audio Guard:** while Android reports active music playback, the controller reduces only passive BLE sensor-poll traffic by 50%. Interactive Master/Bass/EQ writes keep the existing verified cadence. This is intended to reduce 2.4 GHz BLE/A2DP contention without touching PCM audio.
- **CH page corrected:** `CH1 → EQ ID4`, `CH2 → ID5`, `CH3 → ID6`, `CH4 → ID14`, `CH5 → ID15`, `CH6 → ID16`, `CH7 → ID17`.
- **No fake channel volume:** the stock descriptor has no independent CH1–CH7 gain actuator, so each CH row shows `GAIN LOCKED` and tapping a row opens the matching EQ channel.
- **EQ labels corrected:** unverified `Front/Rear/Center/Sub/Aux` speaker names are removed; the selected channel shows its verified EQ actuator ID.

## Hi-Fi / Hi-Res boundary

This Android app is a **DSP controller, not the music renderer**. It does not decode, buffer, resample, or change PCM bit depth/sample rate. Therefore V42 does not claim to turn the stock board into High-Resolution Audio. If a ~1 second repeat/stutter remains when the controller is closed or disconnected, the fault is in the board/Bluetooth audio/firmware path and must be fixed in flashable BP1048P4 firmware once a safe backup/recovery path exists.

Version: **42.0.0** (`versionCode 1042`).
