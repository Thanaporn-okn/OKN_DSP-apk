# OKN DSP V42

Base: **V41 guarded Save/Restore**, with V40 real-hardware stable readback and the V38/V39 safe EQ boundaries retained.

V42 targets Bluetooth audio coexistence problems reported while music is playing: audible delay, dropouts/chopping, and short repeated-audio events. The app is a BLE DSP controller rather than a music player, so the fix reduces controller traffic instead of adding a second audio renderer.

## V42 audio coexistence
- Detect active media using Android `AudioManager.isMusicActive()`; no audio-recording permission is added.
- Pause automatic 380 ms sensor polling during active music while keeping explicit DSP controls available.
- Keep latest-value-wins EQ coalescing, but pace active-music writes more conservatively: 90 ms Gain and 160 ms Frequency/Q / Safe Reset.
- Request BLE `CONNECTION_PRIORITY_LOW_POWER` for the large Device Description transfer when music is active, then return to `BALANCED` after descriptor validation.
- Keep the proven idle/no-music timing and all existing DSP packet formats / filter builders unchanged.

## Hi-Fi / Hi-Res scope
V42 does **not** add a decoder, resampler, `AudioTrack`, `MediaPlayer` or `ExoPlayer`, so it does not force the music through an extra Android PCM processing path. This preserves the source player's native output path. Actual Hi-Res capability (sample rate, bit depth, codec and lossless behavior) is determined by the player, Android audio route / Bluetooth codec, DSP firmware/sample rate, DAC and amplifier hardware.

Version: **42.0.0** (`versionCode 1042`).

## Guarded persistent save
V41 manual-only verified SaveParams and readback-only Restore are retained. See `Sources/V41_GUARDED_SAVE_RESTORE.txt`.
