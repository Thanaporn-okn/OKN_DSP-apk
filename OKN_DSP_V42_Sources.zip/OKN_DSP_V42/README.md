# OKN DSP V42

Base: **V41 hardware-tested stable**, including guarded SaveParams persistence across DSP power-cycle/reconnect.

V42 connects the existing **Volume Ch1..Ch7** Mix controls to real DSP paths without inventing unknown actuator IDs. CH3 uses the already verified **ID8 BassVolume** scalar. CH1/2/4/5/6/7 use the **Band1 `G` cell-gain field** of their already verified channel cascade actuators (`4,5,14,15,16,17`). The real type17 filter math applies `10^(G/20)` equally to all numerator coefficients, giving a broadband trim while preserving the EQ shape.

V42 is fail-closed: channel trim unlocks only after fresh descriptor/health validation and the exact captured Band1 type pattern `17,17,3,17,17,17,17`. Full-record collision handling prevents Band1 EQ boost (`B`) and channel trim (`G`) from restoring stale values. V41 Save/Restore, V40 readback, V39 Safe Reset and V38 safe-PEQ 55/55 behavior remain in place.

**Important:** V42 static/protocol proof is complete, but the new CH1/2/4/5/6/7 `Band1.G` output-trim behavior still requires cautious real-DSP qualification before V42 is promoted to the stable baseline.

Version: **42.0.0** (`versionCode 1042`)

See:
- `Sources/V42_CHANNEL_OUTPUT_TRIM.txt`
- `Sources/V42_VALIDATION_PROOF.txt`
- `Sources/validate_v42_channel_trim.py`
