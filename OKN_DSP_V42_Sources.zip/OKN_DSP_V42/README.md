# OKN DSP V42

Base: **V41 guarded Save/Restore**, with V40/V39/V38 verified DSP safety behavior retained.

V42 targets music playback delay, stutter/dropout, and short repeated-buffer symptoms that can occur while the BLE controller is active. The app is a BLE DSP controller and does **not** decode or render the music stream itself, so V42 does not falsely force a Hi-Res sample rate/bit depth. Instead it adds an automatic **Hi-Fi coexistence guard** that reduces background BLE/DSP traffic whenever Android reports active media playback.

During media playback, background sensor reads are reduced, EQ writes are paced more conservatively, and the GATT connection uses low-power priority while idle. During a real user edit it temporarily returns to balanced priority for responsive control. When playback stops, the original verified controller cadence returns automatically.

Version: **42.0.0** (`versionCode 1042`)

## Retained safety

V38 strict-safe PEQ gating, V39 Gain-only Safe Reset, V40 authoritative DSP readback, and V41 guarded manual SaveParams/readback-only Restore remain in place. No actuator ID, UFE packet structure, AES-CFB8 stream ordering, or DspProtocol EQ coefficient formula is changed.

See `Sources/V42_AUDIO_HIFI_GUARD.txt` and `Sources/V42_VALIDATION_PROOF.txt`.
