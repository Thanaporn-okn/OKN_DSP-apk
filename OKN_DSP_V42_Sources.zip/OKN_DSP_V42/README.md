# OKN DSP V42

Base: **V41 guarded Save/Restore**.

V42 targets the reported Bluetooth-audio symptom where playback can stutter/drop or repeat roughly one second while the controller is active. It changes only the Android BLE transport policy: the verified DSP protocol bytes, actuator IDs, addresses, AES-CFB8 stream framing, filter builders, SaveParams transaction, and readback rules are not changed.

Audio-safe changes:
- EQ Gain latest-value pacing relaxed from 45 ms to **90 ms** to cut BLE burst pressure while keeping interactive response.
- Live-write callback timeout increased from 1.5 s to **3.0 s** before the encrypted stream is declared uncertain.
- A healthy idle BLE link requests Android `CONNECTION_PRIORITY_LOW_POWER`; active control/readback/save temporarily requests `BALANCED`.
- Uncertain/disconnected sessions use capped reconnect backoff **2.5 s → 5 s → 10 s → 12 s** instead of repeatedly scanning again after ~0.9–1.5 s.
- Official scalar/sensor cadence remains **380 ms**; F/Q and Safe Reset remain **110 ms**.

## Hi-Fi / Hi-Res boundary

This Android app does **not** carry PCM audio and has no decoder/resampler or verified actuator for sample-rate/bit-depth selection. The real input exposed by the current UI is AUX (Analog). V42 therefore preserves fidelity by minimizing controller-side interference and by leaving verified DSP coefficient/data precision unchanged; it does not falsely advertise 24-bit/96 kHz, 192 kHz, or another Hi-Res format that the supplied hardware evidence does not prove.

Version: **42.0.0** (`versionCode 1042`)
