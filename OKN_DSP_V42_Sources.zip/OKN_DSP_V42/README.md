# OKN DSP V42

V42 adds **Out Volume Ch1-Ch7** control to the V41 guarded Save/Restore base. CH3 is hardware-confirmed through BassVolume ID8; CH1/2/4/5/6/7 use a descriptor-derived cell-gain mapping that still requires real-DSP qualification.

- **CH3:** uses the hardware-confirmed `BassVolume` actuator **ID8**.
- **CH1, CH2, CH4, CH5, CH6, CH7:** use the first native EQ record's **`G` (cell gain)** field on EQ actuators 4, 5, 14, 15, 16, 17. This is grounded in the real descriptor/filter equations but is not yet hardware-qualified.
- No unverified standalone volume actuator IDs are invented.
- The first record keeps its live filter type and F/F2/Q/B/R metadata; only cell gain is changed and coefficients are rebuilt.
- Out Volume commands use the conservative 380 ms serialized scheduler, and DSP readback becomes authoritative after connect/refresh/restore.
- UI range: **-70 dB to +6 dB**.

See `Sources/V42_OUT_VOLUME_MAPPING.txt` for the protocol mapping and safety rules.
