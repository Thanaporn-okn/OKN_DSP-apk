OKN DSP Controller V5.5 ROOT FIX

Important:
Upload the CONTENTS of this ZIP directly to repository root.

Root must contain:
android/
lib/
pubspec.yaml
.github/

Fix:
- No nested folder
- Flutter root detected
- Android build ready
