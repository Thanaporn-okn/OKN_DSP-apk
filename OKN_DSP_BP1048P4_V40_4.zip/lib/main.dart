import 'package:flutter/material.dart';

void main(){
 runApp(const OKNDSP());
}

class OKNDSP extends StatelessWidget{
 const OKNDSP({super.key});

 @override
 Widget build(BuildContext context){
  return MaterialApp(
   debugShowCheckedModeBanner:false,
   theme:ThemeData.dark(),
   home:Scaffold(
    appBar:AppBar(
     title:const Text('OKN_DSP BP1048P4 V40.4')
    ),
    body:const Padding(
     padding:EdgeInsets.all(20),
     child:Column(
      crossAxisAlignment:CrossAxisAlignment.start,
      children:[
       Text('NO FLUTTER DEMO',
        style:TextStyle(fontSize:28,color:Colors.cyan)),
       SizedBox(height:20),
       Text('Bluetooth DSP Controller'),
       Text('Scan Device'),
       Text('Connect / Disconnect'),
       Text('CH1-CH7 DSP Mixer'),
       Text('Volume EQ Delay'),
       Text('HPF LPF Crossover'),
       Text('BP1048P4 Command'),
       Text('TX RX HEX Monitor'),
      ],
     ),
    ),
   ),
  );
 }
}
