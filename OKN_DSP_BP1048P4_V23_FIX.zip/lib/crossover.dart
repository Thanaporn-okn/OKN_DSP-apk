// V23 HPF LPF Delay control
