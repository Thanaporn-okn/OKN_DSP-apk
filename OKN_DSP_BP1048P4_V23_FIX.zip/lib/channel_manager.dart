// V23 CH1-CH7 manager
