// V23 DSP read write command layer
