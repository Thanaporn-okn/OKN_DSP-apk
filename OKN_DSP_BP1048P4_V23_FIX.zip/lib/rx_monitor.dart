// V23 RX data monitor
