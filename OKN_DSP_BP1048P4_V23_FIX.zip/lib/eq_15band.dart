// V23 15 band EQ per channel
