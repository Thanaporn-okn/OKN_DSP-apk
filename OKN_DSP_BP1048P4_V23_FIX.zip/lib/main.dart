import 'package:flutter/material.dart';

void main()=>runApp(const OKNDSP());

class OKNDSP extends StatelessWidget{
 const OKNDSP({super.key});
 @override
 Widget build(BuildContext context){
  return MaterialApp(
   debugShowCheckedModeBanner:false,
   theme:ThemeData.dark(),
   home:const Home(),
  );
 }
}

class Home extends StatelessWidget{
 const Home({super.key});
 @override
 Widget build(BuildContext context){
  return Scaffold(
   backgroundColor:const Color(0xff101018),
   appBar:AppBar(title:const Text('OKN_DSP BP1048P4 V23')),
   body:const Center(
    child:Text(
     'DSP Read / Write\n'
     '15 Band EQ CH1-CH7\n'
     'Delay HPF LPF\n'
     'Save / Load Preset\n'
     'RX Data Monitor',
     textAlign:TextAlign.center,
     style:TextStyle(color:Colors.cyan,fontSize:24),
    ),
   ),
  );
 }
}
