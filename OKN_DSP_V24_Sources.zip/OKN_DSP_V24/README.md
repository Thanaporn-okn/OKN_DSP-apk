# OKN DSP V24 — Phase 1

V24 is built from V23 and fixes the touch-layer bug shown in the 30937 test video: tapping the magnifying-glass Search icon or the three-dot Theme button could accidentally change the EQ channel when a scrolled channel-chip hit target overlapped the fixed header.

## V24 touch isolation fix

- Search and the three-dot Theme button have exclusive ownership of the fixed header area.
- Hidden/scrolled EQ channel chips are ignored outside the visible content viewport.
- Bottom Home / Mix / Eq navigation remains isolated from content controls.
- Theme, Saved Presets and Delete overlays keep their full-screen modal touch ownership.
- No visual redesign; V23 appearance and behavior are retained.

- versionName: 24.0.0
- versionCode: 1024
- Base: V23
- Phase: 1 touch-layer hardening
