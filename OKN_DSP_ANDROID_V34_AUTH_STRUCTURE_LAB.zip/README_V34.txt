OKN DSP V34 — MULTI-SESSION AUTH STRUCTURE LAB

Purpose
- Continue from the confirmed V33 BLE capture path.
- Parse 32-byte AB02 authentication responses from live/imported captures.
- Compare byte stability across multiple sessions without deriving or guessing any secret.
- Keep LIVE DSP parameter writes locked.

New in V34
- AUTH STRUCTURE REPORT (READ-ONLY) button.
- AuthSessionAnalyzer.kt compares known evidence + live/imported response32 records.
- Reports stable and variable byte ranges, f4-7 variants, unique 16-byte tails, and pairwise tail bit distances.
- Adds the latest V33 capture response observed at 23:01:43 as an unpaired response sample.

Current evidence model
- bytes 0..3: stable in the current evidence set.
- bytes 8..15: stable in the current evidence set.
- bytes 4..7: session-varying.
- bytes 16..31: session-varying 16-byte tail.

Safety
- No fixed key / IV / KDF is guessed.
- No RandKey decryption is attempted by this analyzer.
- Existing auth probe remains limited to the previously captured 16-byte startup request and does not send the 4-byte follow-up.
- Gain/EQ/Delay/actuator live writes remain locked.
