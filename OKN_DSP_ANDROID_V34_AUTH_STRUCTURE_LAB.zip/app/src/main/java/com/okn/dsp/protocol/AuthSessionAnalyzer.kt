package com.okn.dsp.protocol

import com.okn.dsp.protocol.ByteCodec.toHex

/**
 * Read-only authentication structure analyzer.
 *
 * It parses already captured 32-byte AB02 authentication responses and compares
 * byte positions across sessions. It does not derive keys, decrypt RandKey, or
 * transmit BLE data.
 */
data class ObservedAuthResponse(
    val label: String,
    val response32: ByteArray,
)

data class AuthStructureReport(
    val sessionCount: Int,
    val stableRanges: List<String>,
    val variableRanges: List<String>,
    val typeVersionHex: String?,
    val fixed8Hex: String?,
    val tailPairwiseBitDistances: List<Int>,
    val lines: List<String>,
)

object AuthSessionAnalyzer {
    private val hexRx = Regex("\\bRX_NOTIFY\\b.*?len=32.*?hex=([0-9A-Fa-f]{64})")

    // Previously paired evidence plus the newest V33 read-only capture.
    // The newest sample is intentionally UNPAIRED: no RandKey is assumed.
    val evidence = listOf(
        ObservedAuthResponse("20:45:55", ByteCodec.hexToBytes("D024E38C00000000420DA6E8FDDF06895D514A274A2181DEB2F457CA70A60EC1")),
        ObservedAuthResponse("19:21:34", ByteCodec.hexToBytes("D024E38C13000000420DA6E8FDDF0689DD5F38C36C27E4BF3BFDA166FD82E8CB")),
        ObservedAuthResponse("18:29:45", ByteCodec.hexToBytes("D024E38C13000000420DA6E8FDDF068970287AA5C063B592A366D2CBED42EAFF")),
        ObservedAuthResponse("16:15:33", ByteCodec.hexToBytes("D024E38C00000000420DA6E8FDDF0689AD155C32009F94B47BFE6DCB239E1492")),
        ObservedAuthResponse("23:01:43 V33 capture", ByteCodec.hexToBytes("D024E38C68BF14F7420DA6E8FDDF06899FB544B3B382FD229794660D2D0B5C59")),
    )

    fun extractFromCapture(lines: List<String>, labelPrefix: String = "capture"): List<ObservedAuthResponse> {
        var index = 0
        return lines.mapNotNull { line ->
            val m = hexRx.find(line) ?: return@mapNotNull null
            val bytes = ByteCodec.hexToBytes(m.groupValues[1])
            if (bytes.size != 32) return@mapNotNull null
            index += 1
            ObservedAuthResponse("$labelPrefix#$index", bytes)
        }
    }

    fun analyze(extra: List<ObservedAuthResponse> = emptyList()): AuthStructureReport {
        val all = (evidence + extra)
            .distinctBy { it.response32.toHex() }
            .filter { it.response32.size == 32 }

        if (all.isEmpty()) {
            return AuthStructureReport(0, emptyList(), emptyList(), null, null, emptyList(), listOf("No 32-byte auth responses available"))
        }

        val stable = BooleanArray(32) { i -> all.map { it.response32[i] }.distinct().size == 1 }
        val stableRanges = contiguousRanges(stable, true)
        val variableRanges = contiguousRanges(stable, false)
        val tails = all.map { it.response32.copyOfRange(16, 32) }
        val distances = mutableListOf<Int>()
        for (i in tails.indices) for (j in i + 1 until tails.size) distances += bitDistance(tails[i], tails[j])

        val lines = buildList {
            add("AUTH STRUCTURE LAB • unique response32=${all.size}")
            add("stable byte ranges=${stableRanges.joinToString()}")
            add("variable byte ranges=${variableRanges.joinToString()}")
            add("bytes[0..3]=${all.first().response32.copyOfRange(0, 4).toHex()} (stable across current evidence)")
            add("bytes[8..15]=${all.first().response32.copyOfRange(8, 16).toHex()} (stable across current evidence)")
            add("bytes[4..7] variants=${all.map { it.response32.copyOfRange(4, 8).toHex() }.distinct().joinToString()}")
            add("tail[16..31] unique=${tails.map { it.toHex() }.distinct().size}/${tails.size}")
            if (distances.isNotEmpty()) {
                add("tail pairwise bit distance min=${distances.minOrNull()} max=${distances.maxOrNull()} avg=${"%.1f".format(distances.average())}")
            }
            all.forEach {
                val h = AuthResponseCodec.parse32(it.response32)
                add("${it.label}: type=${h.typeId} version=${h.versionId} f4-7=${h.field4to7.toHex()} fixed8=${h.fixed8.toHex()} tail=${h.encryptedRandKey.toHex()}")
            }
            add("READ-ONLY RESULT: structure/stability only; no fixed-key, IV, KDF, or RandKey decryption is assumed")
        }

        return AuthStructureReport(
            sessionCount = all.size,
            stableRanges = stableRanges,
            variableRanges = variableRanges,
            typeVersionHex = all.first().response32.copyOfRange(0, 4).toHex(),
            fixed8Hex = all.first().response32.copyOfRange(8, 16).toHex(),
            tailPairwiseBitDistances = distances,
            lines = lines,
        )
    }

    private fun contiguousRanges(flags: BooleanArray, wanted: Boolean): List<String> {
        val out = mutableListOf<String>()
        var i = 0
        while (i < flags.size) {
            if (flags[i] != wanted) { i++; continue }
            val start = i
            while (i + 1 < flags.size && flags[i + 1] == wanted) i++
            out += if (start == i) "$start" else "$start-$i"
            i++
        }
        return out
    }

    private fun bitDistance(a: ByteArray, b: ByteArray): Int {
        require(a.size == b.size)
        var total = 0
        for (i in a.indices) total += Integer.bitCount((a[i].toInt() xor b[i].toInt()) and 0xff)
        return total
    }
}
