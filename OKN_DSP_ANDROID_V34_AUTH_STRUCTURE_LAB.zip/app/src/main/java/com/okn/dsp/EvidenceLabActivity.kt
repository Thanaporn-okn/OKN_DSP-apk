package com.okn.dsp

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.widget.*
import android.content.Intent
import android.content.ContentValues
import android.content.ActivityNotFoundException
import android.net.Uri
import android.provider.OpenableColumns
import android.provider.MediaStore
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.core.app.ActivityCompat
import com.okn.dsp.transport.BleProfile
import com.okn.dsp.protocol.ProtocolSelfTest
import com.okn.dsp.protocol.AuthVectorLab
import com.okn.dsp.protocol.AuthSessionAnalyzer
import java.util.UUID

class EvidenceLabActivity : Activity() {
    private lateinit var log: TextView
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val found = LinkedHashMap<String, BluetoothDevice>()
    private var scanner: BluetoothLeScanner? = null
    private var gatt: BluetoothGatt? = null
    private val notifyQueue = ArrayDeque<BluetoothGattCharacteristic>()
    private var descriptorWriteInProgress = false
    private val logLines = StringBuilder()
    private val captureLines = mutableListOf<String>()
    private var rxCount = 0
    private var txCount = 0
    private var metaCount = 0
    private lateinit var captureStatus: TextView
    private val internalCaptureFileName = "OKN_DSP_V34_LAST_CAPTURE.txt"
    private var packetNo = 0
    private var sessionNo = 0
    private val ts = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    private val OPEN_CAPTURE = 200
    private val CREATE_CAPTURE = 201
    private var importedA: List<String>? = null
    private var importedB: List<String>? = null

    // V25: startup-sequence probe based on the exact AB01/AB02 traffic captured
    // from the 250401 reference app. This is NOT an actuator/Gain/EQ write path.
    private lateinit var probeButton: Button
    private var ab01Write: BluetoothGattCharacteristic? = null
    private var probeStage = 0
    private var probeBulkBytes = 0
    private var probeBulkPackets = 0
    private var discoveredProfile = "UNKNOWN"
    private var markerRead: BluetoothGattCharacteristic? = null
    private var burstStartMs = 0L
    private var burstLastMs = 0L
    private var burstBytes = 0
    private val burstParts = mutableListOf<Int>()
    private val finishBurstRunnable = Runnable { finishLargeBurst() }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        buildUi()
        requestBlePermissions()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }

        val title = TextView(this).apply {
            text = "OKN DSP Controller\nV34 MULTI-SESSION AUTH STRUCTURE LAB"
            textSize = 22f
        }

        status = TextView(this).apply {
            text = "LIVE WRITE LOCKED — V34 READ-ONLY AUTH ANALYZER ARMED"
            textSize = 15f
        }

        val scan = Button(this).apply {
            text = "SCAN DSP"
            setOnClickListener { startScan() }
        }

        probeButton = Button(this).apply {
            text = "CAPTURE AUTH RESPONSE — SEND 16B ONLY"
            isEnabled = false
            setOnClickListener { confirmAuth16Probe() }
        }

        captureStatus = TextView(this).apply {
            text = "CAPTURE: RX=0 • TX=0 • META=0 • AUTO-BACKUP=ON"
            textSize = 13f
        }

        val markerRow1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val markEq1 = Button(this).apply {
            text = "MARK EQ CH1"
            setOnClickListener { markEvent("EQ_CH1") }
        }
        val markEq2 = Button(this).apply {
            text = "MARK EQ CH2"
            setOnClickListener { markEvent("EQ_CH2") }
        }
        markerRow1.addView(markEq1, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        markerRow1.addView(markEq2, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val markerRow2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val markGlobal = Button(this).apply {
            text = "MARK GLOBAL"
            setOnClickListener { markEvent("GLOBAL_CONTROL") }
        }
        val markBass = Button(this).apply {
            text = "MARK BASS"
            setOnClickListener { markEvent("BASS_CONTROL") }
        }
        markerRow2.addView(markGlobal, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        markerRow2.addView(markBass, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val selfTest = Button(this).apply {
            text = "RUN VERIFIED PROTOCOL SELF-TEST"
            setOnClickListener {
                append("=== V34 PROTOCOL SELF-TEST ===")
                ProtocolSelfTest.run().forEach { append(it) }
                append("LIVE WRITE remains locked: same-session vector is verified, but pre-auth RandKey transform/key/IV is not independently derived")
            }
        }

        val authVectors = Button(this).apply {
            text = "RUN AUTH VECTOR LAB"
            setOnClickListener {
                append("=== V34 SAME-SESSION AUTH VECTOR LAB ===")
                AuthVectorLab.report().forEach { append(it) }
            }
        }

        val authStructure = Button(this).apply {
            text = "AUTH STRUCTURE REPORT (READ-ONLY)"
            setOnClickListener {
                append("=== V34 MULTI-SESSION AUTH STRUCTURE REPORT ===")
                val current = AuthSessionAnalyzer.extractFromCapture(synchronized(captureLines) { captureLines.toList() }, "live")
                val imported = buildList {
                    importedA?.let { addAll(AuthSessionAnalyzer.extractFromCapture(it, "importA")) }
                    importedB?.let { addAll(AuthSessionAnalyzer.extractFromCapture(it, "importB")) }
                }
                AuthSessionAnalyzer.analyze(current + imported).lines.forEach { append(it) }
            }
        }

        val quickSave = Button(this).apply {
            text = "QUICK SAVE CAPTURE TO DOWNLOADS"
            setOnClickListener { quickSaveCaptureToDownloads() }
        }

        val save = Button(this).apply {
            text = "SAVE CAPTURE AS..."
            setOnClickListener { saveCaptureFile() }
        }

        val health = Button(this).apply {
            text = "CAPTURE HEALTH CHECK"
            setOnClickListener { runCaptureHealthCheck() }
        }

        val share = Button(this).apply {
            text = "SHARE CAPTURE"
            setOnClickListener { shareCapture() }
        }

        val copy = Button(this).apply {
            text = "COPY CAPTURE TO CLIPBOARD"
            setOnClickListener { copyCaptureToClipboard() }
        }

        val analyze = Button(this).apply {
            text = "ANALYZE CAPTURE"
            setOnClickListener { analyzeCapture() }
        }

        val importBtn = Button(this).apply {
            text = "IMPORT CAPTURE"
            setOnClickListener { openCaptureFile() }
        }

        val correlate = Button(this).apply {
            text = "CORRELATE TX/RX"
            setOnClickListener { analyzeTemporalCorrelation() }
        }

        val diff = Button(this).apply {
            text = "DIFF A/B BYTES"
            setOnClickListener { analyzeControlledByteDiff() }
        }

        val stability = Button(this).apply {
            text = "STABILITY REPORT"
            setOnClickListener { analyzeControlledStability() }
        }

        val clear = Button(this).apply {
            text = "CLEAR LOG"
            setOnClickListener {
                logLines.clear()
                captureLines.clear()
                rxCount = 0
                txCount = 0
                metaCount = 0
                try { deleteFile(internalCaptureFileName) } catch (_: Exception) {}
                updateCaptureStatus()
                importedA = null
                importedB = null
                log.text = "Log:\n"
            }
        }

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        log = TextView(this).apply {
            text = "Log:\n"
            textSize = 13f
        }

        root.addView(title)
        root.addView(status)
        root.addView(captureStatus)
        root.addView(scan)
        root.addView(probeButton)
        root.addView(markerRow1)
        root.addView(markerRow2)
        root.addView(TextView(this).apply {
            text = "V34 READ-ONLY: เพิ่มตัวเปรียบเทียบ auth response 32B หลาย session. หลักฐานปัจจุบันพบ bytes 0..3 และ 8..15 คงที่ในชุดตัวอย่าง ขณะที่ 4..7 และ 16..31 เปลี่ยนตาม session. ไม่เดา fixed key/IV/KDF และ LIVE WRITE ยังล็อกอยู่."
            textSize = 12f
        })
        root.addView(selfTest)
        root.addView(authVectors)
        root.addView(authStructure)
        root.addView(health)
        root.addView(quickSave)
        root.addView(save)
        root.addView(share)
        root.addView(copy)
        root.addView(analyze)
        root.addView(importBtn)
        root.addView(correlate)
        root.addView(diff)
        root.addView(stability)
        root.addView(clear)
        root.addView(list)
        root.addView(log)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun requestBlePermissions() {
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT
                ),
                100
            )
        }
    }

    private fun startScan() {
        if (!hasBlePermission()) {
            append("Bluetooth permission not granted")
            return
        }

        val manager = getSystemService(BluetoothManager::class.java)
        val adapter = manager?.adapter
        if (adapter == null) {
            append("Bluetooth adapter not available")
            return
        }
        if (!adapter.isEnabled) {
            append("Bluetooth is OFF — turn Bluetooth ON and scan again")
            return
        }

        scanner = adapter.bluetoothLeScanner
        if (scanner == null) {
            append("BLE scanner not available")
            return
        }

        found.clear()
        list.removeAllViews()
        append("Scanning for LE-GOLOPINE DSP ...")

        try {
            scanner?.startScan(callback)
        } catch (_: SecurityException) {
            append("Bluetooth permission denied")
            return
        }

        handler.postDelayed({
            try { scanner?.stopScan(callback) } catch (_: Exception) {}
            append("Scan finished")
        }, 10000)
    }

    private fun hasBlePermission(): Boolean =
        android.os.Build.VERSION.SDK_INT < 31 ||
        (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
         checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED)

    private val callback = object : ScanCallback() {
        override fun onScanResult(type: Int, result: ScanResult) {
            val device = result.device
            val name = result.scanRecord?.deviceName
                ?: try { device.name } catch (_: SecurityException) { null }

            if (name?.contains("GOLOPINE", true) == true ||
                name?.contains("DSP", true) == true) {
                if (!found.containsKey(device.address)) {
                    found[device.address] = device
                    runOnUiThread {
                        val b = Button(this@EvidenceLabActivity).apply {
                            text = "${name ?: "DSP"}\n${device.address}\nTAP TO CONNECT"
                            setOnClickListener { connect(device, name ?: "DSP") }
                        }
                        list.addView(b)
                    }
                }
            }
        }

        override fun onScanFailed(errorCode: Int) {
            append("BLE scan failed: $errorCode")
        }
    }

    private fun connect(device: BluetoothDevice, name: String) {
        sessionNo += 1
        packetNo = 0
        rxCount = 0
        txCount = 0
        metaCount = 0
        recordCaptureLine("=== SESSION #$sessionNo START ${ts.format(Date())} ===")
        captureMeta("CAPTURE_ARMED name=$name address=${device.address}", "local")
        if (!hasBlePermission()) {
            append("Bluetooth permission not granted")
            return
        }

        try {
            gatt?.close()
            gatt = null
            notifyQueue.clear()
            readableQueue.clear()
            descriptorWriteInProgress = false
            ab01Write = null
            probeStage = 0
            probeBulkBytes = 0
            probeBulkPackets = 0
            discoveredProfile = "UNKNOWN"
            markerRead = null
            burstParts.clear()
            burstBytes = 0
            handler.removeCallbacks(finishBurstRunnable)
            runOnUiThread { if (::probeButton.isInitialized) probeButton.isEnabled = false }
            status.text = "CONNECTING — $name"
            append("Connecting to $name ${device.address} ...")
            gatt = device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
        } catch (_: SecurityException) {
            append("Bluetooth permission denied")
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, statusCode: Int, newState: Int) {
            captureMeta("GATT_STATE status=$statusCode newState=$newState", "gatt")
            append("GATT state=$newState status=$statusCode")
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                status.text = "CONNECTED — discovering GATT"
                append("Connected — requesting MTU 247 then discovering services")
                try {
                    g.requestConnectionPriority(BluetoothGatt.CONNECTION_PRIORITY_HIGH)
                    g.requestMtu(247)
                } catch (_: Exception) {}
                handler.postDelayed({
                    try { g.discoverServices() }
                    catch (_: SecurityException) { append("Service discovery permission denied") }
                }, 350)
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                status.text = "DISCONNECTED"
                append("Disconnected")
            }
        }

        override fun onMtuChanged(g: BluetoothGatt, mtu: Int, statusCode: Int) {
            captureMeta("MTU_CHANGED mtu=$mtu status=$statusCode", "gatt")
            append("MTU changed: mtu=$mtu status=$statusCode (ATT notification payload may be mtu-3)")
        }

        override fun onServicesDiscovered(g: BluetoothGatt, statusCode: Int) {
            captureMeta("SERVICES_DISCOVERED status=$statusCode count=${g.services.size}", "gatt")
            append("Services discovered: status=$statusCode")
            if (statusCode != BluetoothGatt.GATT_SUCCESS) return

            notifyQueue.clear()

            val abService = g.services.firstOrNull { it.uuid == BleProfile.AB00_SERVICE }
            val uuid128Service = g.services.firstOrNull { it.uuid == BleProfile.UUID_0001 }
            discoveredProfile = when {
                abService != null -> "AB00/AB01/AB02/AB03"
                uuid128Service != null -> "40AF-128BIT"
                else -> "GENERIC-GATT"
            }
            ab01Write = abService?.getCharacteristic(BleProfile.AB01_WRITE)
            markerRead = g.getService(UUID.fromString("00001800-0000-1000-8000-00805f9b34fb"))
                ?.getCharacteristic(UUID.fromString("00002a00-0000-1000-8000-00805f9b34fb"))
            val preferredNotify = abService?.characteristics?.filter { it.uuid == BleProfile.AB02_NOTIFY || it.uuid == BleProfile.AB03_NOTIFY } ?: emptyList()
            captureMeta("PROFILE=$discoveredProfile AB01_WRITE=${ab01Write != null} HCI_MARKER_2A00=${markerRead != null}", "gatt")
            append("PROFILE=$discoveredProfile AB01_WRITE=${ab01Write != null} HCI_MARKER_2A00=${markerRead != null}")
            runOnUiThread {
                status.text = "CONNECTED — profile=$discoveredProfile"
                probeButton.isEnabled = (discoveredProfile == "AB00/AB01/AB02/AB03" && ab01Write != null)
            }

            g.services.forEachIndexed { si, service ->
                captureMeta("SERVICE[$si] ${service.uuid}", "gatt")
                append("SERVICE[$si] ${service.uuid}")
                service.characteristics.forEachIndexed { ci, ch ->
                    val props = properties(ch)
                    captureMeta("CHAR[$ci] props=$props", ch.uuid.toString())
                    append("  CHAR[$ci] ${ch.uuid} [$props]")
                    ch.descriptors.forEach { d ->
                        append("    DESC ${d.uuid}")
                    }

                    if (preferredNotify.isNotEmpty()) {
                        if (preferredNotify.any { it.uuid == ch.uuid }) notifyQueue.addLast(ch)
                    } else if ((ch.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0 ||
                        (ch.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) {
                        notifyQueue.addLast(ch)
                    }
                }
            }

            captureMeta("NOTIFY_TARGETS count=${notifyQueue.size}", "gatt")
            append("NOTIFY TARGETS=${notifyQueue.size} (AB02/AB03 preferred when present)")
            processNextNotificationSubscription(g)

            append("V34 CLEAN CAPTURE: automatic characteristic reads disabled")
        }

        override fun onDescriptorWrite(
            g: BluetoothGatt,
            descriptor: BluetoothGattDescriptor,
            statusCode: Int
        ) {
            captureMeta("CCCD_WRITE status=$statusCode", descriptor.uuid.toString())
            append("CCCD WRITE ${descriptor.uuid} status=$statusCode")
            descriptorWriteInProgress = false
            handler.postDelayed({ processNextNotificationSubscription(g) }, 250)
        }

        override fun onCharacteristicChanged(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            value: ByteArray
        ) {
            capture("RX_NOTIFY", characteristic.uuid.toString(), value)
            detectLargeBurst(characteristic, value)
            handleStartupProbeNotification(g, characteristic, value)
        }

        @Suppress("DEPRECATION")
        override fun onCharacteristicChanged(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic
        ) {
            if (android.os.Build.VERSION.SDK_INT < 33) {
                val value = characteristic.value ?: byteArrayOf()
                capture("RX_NOTIFY", characteristic.uuid.toString(), value, "legacy-callback")
                detectLargeBurst(characteristic, value)
                handleStartupProbeNotification(g, characteristic, value)
            }
        }

        override fun onCharacteristicWrite(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            statusCode: Int
        ) {
            captureMeta("TX_WRITE_RESULT status=$statusCode", characteristic.uuid.toString())
        }

        override fun onCharacteristicRead(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            value: ByteArray,
            statusCode: Int
        ) {
            capture("RX_READ", characteristic.uuid.toString(), value, "status=$statusCode")
        }

        @Suppress("DEPRECATION")
        override fun onCharacteristicRead(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            statusCode: Int
        ) {
            capture("RX_READ", characteristic.uuid.toString(), characteristic.value ?: byteArrayOf(), "status=$statusCode")
        }
    }

    private fun markEvent(label: String) {
        val now = ts.format(Date())
        val n = synchronized(captureLines) { packetNo += 1; packetNo }
        val line = "$now\t#$n\tMARK\t$label"
        synchronized(captureLines) { captureLines.add(line) }
        append("=== $line ===")

        val g = gatt
        val ch = markerRead
        if (g != null && ch != null && hasBlePermission()) {
            captureMeta("HCI_MARK_READ_REQUEST $label", ch.uuid.toString())
            try {
                g.readCharacteristic(ch)
            } catch (e: Exception) {
                append("HCI MARK read error=${e.message}")
            }
        } else {
            append("MARK saved locally; 2A00 HCI marker unavailable")
        }
    }

    private fun detectLargeBurst(ch: BluetoothGattCharacteristic, value: ByteArray) {
        if (ch.uuid != BleProfile.AB02_NOTIFY || value.size < 100) return
        val now = android.os.SystemClock.elapsedRealtime()
        if (burstParts.isNotEmpty() && now - burstLastMs > 1200L) finishLargeBurst()
        if (burstParts.isEmpty()) {
            burstStartMs = now
            burstBytes = 0
        }
        burstParts.add(value.size)
        burstBytes += value.size
        burstLastMs = now
        handler.removeCallbacks(finishBurstRunnable)
        handler.postDelayed(finishBurstRunnable, 900L)
    }

    private fun finishLargeBurst() {
        if (burstParts.isEmpty()) return
        val duration = (burstLastMs - burstStartMs).coerceAtLeast(0L)
        val parts = burstParts.joinToString("+")
        captureMeta("BURST AB02 parts=$parts total=$burstBytes durationMs=$duration", BleProfile.AB02_NOTIFY.toString())
        burstParts.clear()
        burstBytes = 0
        burstStartMs = 0L
        burstLastMs = 0L
    }

    private var readableQueue = ArrayDeque<BluetoothGattCharacteristic>()

    private fun readNextReadable(g: BluetoothGatt) {
        if (!hasBlePermission()) return
        if (readableQueue.isEmpty()) {
            readableQueue.addAll(
                g.services.flatMap { it.characteristics }
                    .filter { it.properties and BluetoothGattCharacteristic.PROPERTY_READ != 0 }
            )
        }
        val ch = readableQueue.removeFirstOrNull() ?: return
        append("READ REQUEST ${shortUuid(ch.uuid)}")
        try {
            g.readCharacteristic(ch)
        } catch (_: Exception) {
            handler.postDelayed({ readNextReadable(g) }, 300)
        }
    }

    private fun processNextNotificationSubscription(g: BluetoothGatt) {
        if (descriptorWriteInProgress) return
        val ch = notifyQueue.removeFirstOrNull() ?: return
        subscribeToNotifications(g, ch)
    }

    private fun subscribeToNotifications(g: BluetoothGatt, ch: BluetoothGattCharacteristic) {
        if (!hasBlePermission()) return

        try {
            val localOk = g.setCharacteristicNotification(ch, true)
            captureMeta("SUBSCRIBE_LOCAL ok=$localOk", ch.uuid.toString())
            append("SUBSCRIBE ${shortUuid(ch.uuid)} local=$localOk")

            val cccd = ch.getDescriptor(
                UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
            )

            if (cccd == null) {
                append("  CCCD NOT FOUND")
                handler.postDelayed({ processNextNotificationSubscription(g) }, 250)
                return
            }

            val value =
                if ((ch.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0)
                    BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
                else
                    BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE

            descriptorWriteInProgress = true

            if (android.os.Build.VERSION.SDK_INT >= 33) {
                val rc = g.writeDescriptor(cccd, value)
                captureMeta("CCCD_REQUEST rc=$rc", ch.uuid.toString())
                append("  CCCD REQUEST rc=$rc")
                if (rc != BluetoothGatt.GATT_SUCCESS) {
                    descriptorWriteInProgress = false
                    handler.postDelayed({ processNextNotificationSubscription(g) }, 500)
                }
            } else {
                @Suppress("DEPRECATION")
                cccd.value = value
                @Suppress("DEPRECATION")
                val ok = g.writeDescriptor(cccd)
                captureMeta("CCCD_REQUEST ok=$ok", ch.uuid.toString())
                append("  CCCD REQUEST ok=$ok")
                if (!ok) {
                    descriptorWriteInProgress = false
                    handler.postDelayed({ processNextNotificationSubscription(g) }, 500)
                }
            }
        } catch (_: SecurityException) {
            append("  CCCD permission denied")
            descriptorWriteInProgress = false
        } catch (e: Exception) {
            append("  CCCD error=${e.message}")
            descriptorWriteInProgress = false
        }
    }

    private fun runCaptureHealthCheck() {
        val g = gatt
        val ch = markerRead
        if (g == null || ch == null || !hasBlePermission()) {
            captureMeta("HEALTH_CHECK_BLOCKED connected=${g != null} markerRead=${ch != null}", "local")
            append("HEALTH CHECK BLOCKED: connect DSP first; 2A00 readable marker must exist")
            return
        }
        captureMeta("HEALTH_READ_REQUEST", ch.uuid.toString())
        try {
            val ok = g.readCharacteristic(ch)
            captureMeta("HEALTH_READ_QUEUED ok=$ok", ch.uuid.toString())
            append("HEALTH CHECK queued — expect RX_READ in capture")
        } catch (e: Exception) {
            captureMeta("HEALTH_READ_ERROR ${e.javaClass.simpleName}: ${e.message}", ch.uuid.toString())
        }
    }

    private fun confirmAuth16Probe() {
        if (discoveredProfile != "AB00/AB01/AB02/AB03" || ab01Write == null || gatt == null) {
            append("AUTH16 BLOCKED: AB00/AB01 profile not connected")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Capture fresh 32B auth response")
            .setMessage("V34 จะ replay เฉพาะ startup/auth request 16 bytes ที่จับจากแอปทางการไป AB01 เพื่อขอ response 32B เท่านั้น จะไม่ส่ง 4B follow-up และไม่ส่ง DSP parameter write")
            .setNegativeButton("ยกเลิก", null)
            .setPositiveButton("ส่ง 16B") { _, _ -> startAuth16Probe() }
            .show()
    }

    private fun startAuth16Probe() {
        val g = gatt ?: return
        val ch = ab01Write ?: return
        probeStage = 10
        captureMeta("AUTH16_PROBE_START", ch.uuid.toString())
        if (!writeNoResponse(g, ch, startupProbe16, "TX_AUTH16_ONLY")) {
            probeStage = 0
            captureMeta("AUTH16_PROBE_QUEUE_FAILED", ch.uuid.toString())
        } else {
            runOnUiThread { status.text = "AUTH16 SENT — waiting for RX 32B" }
            handler.postDelayed({
                if (probeStage == 10) {
                    captureMeta("AUTH16_TIMEOUT_NO_32B", BleProfile.AB02_NOTIFY.toString())
                    probeStage = 0
                    runOnUiThread { status.text = "AUTH16 TIMEOUT — capture saved for analysis" }
                }
            }, 5000L)
        }
    }

    private val startupProbe16 = byteArrayOf(
        0x63, 0x1C, 0x06, 0x24, 0x43, 0xFD.toByte(), 0x38, 0x44,
        0x55, 0x80.toByte(), 0x01, 0xF3.toByte(), 0xED.toByte(), 0xA0.toByte(), 0xCC.toByte(), 0xF8.toByte()
    )
    private val startupProbe4 = byteArrayOf(0x9E.toByte(), 0xF5.toByte(), 0xA7.toByte(), 0x6D)

    private fun confirmStartupProbe() {
        if (discoveredProfile != "AB00/AB01/AB02/AB03" || ab01Write == null || gatt == null) {
            append("PROBE BLOCKED: AB00/AB01 profile not connected")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Startup probe 250401")
            .setMessage("ส่ง startup 16B จาก capture จริงไป AB01 แล้วรอ AB02 32B ก่อนส่ง 4B ต่อเนื่อง การเขียนค่าพารามิเตอร์ DSP (Gain/EQ/Delay) ยังปิดอยู่")
            .setNegativeButton("ยกเลิก", null)
            .setPositiveButton("เริ่ม Probe") { _, _ -> startStartupProbe() }
            .show()
    }

    private fun startStartupProbe() {
        val g = gatt ?: return
        val ch = ab01Write ?: return
        probeStage = 1
        probeBulkBytes = 0
        probeBulkPackets = 0
        append("=== V34 STARTUP PROBE BLOCKED LEGACY PATH ===")
        append("Expected reference sequence: TX16 -> RX32 -> TX4 -> bulk 18252B candidate")
        if (!writeNoResponse(g, ch, startupProbe16, "TX_STARTUP_16")) {
            probeStage = 0
            append("PROBE: first write could not be queued")
        } else {
            runOnUiThread { status.text = "PROBE — waiting for 32B AB02 response" }
        }
    }

    private fun handleStartupProbeNotification(g: BluetoothGatt, ch: BluetoothGattCharacteristic, value: ByteArray) {
        if (probeStage == 0 || ch.uuid != BleProfile.AB02_NOTIFY) return
        if (probeStage == 10) {
            if (value.size == 32) {
                captureMeta("AUTH_RESPONSE32_CAPTURED no-follow-up", ch.uuid.toString())
                probeStage = 0
                runOnUiThread { status.text = "AUTH RESPONSE 32B CAPTURED — no 4B sent" }
            }
            return
        }
        when (probeStage) {
            1 -> {
                if (value.size == 32) {
                    append("PROBE: matched 32B startup response; scheduling captured 4B follow-up")
                    probeStage = 2
                    handler.postDelayed({
                        val w = ab01Write
                        if (w != null && writeNoResponse(g, w, startupProbe4, "TX_STARTUP_4")) {
                            probeStage = 3
                            runOnUiThread { status.text = "PROBE — collecting bulk notifications" }
                        } else {
                            probeStage = 0
                            append("PROBE: 4B follow-up write failed")
                        }
                    }, 120)
                }
            }
            3 -> {
                if (value.size == 235 || value.size == 157) {
                    probeBulkPackets += 1
                    probeBulkBytes += value.size
                    runOnUiThread { status.text = "PROBE BULK — $probeBulkPackets packets / $probeBulkBytes bytes" }
                    if (value.size == 157 || probeBulkBytes >= 18252) {
                        append("PROBE BULK candidate complete: packets=$probeBulkPackets bytes=$probeBulkBytes")
                        append(if (probeBulkBytes == 18252) "MATCH: exact 250401 reference bulk length 18,252B" else "NOTE: bulk length differs from 250401 reference")
                        probeStage = 4
                        runOnUiThread { status.text = "PROBE COMPLETE — bulk=$probeBulkBytes B" }
                    }
                }
            }
        }
    }

    private fun writeNoResponse(g: BluetoothGatt, ch: BluetoothGattCharacteristic, bytes: ByteArray, kind: String): Boolean {
        if (!hasBlePermission()) return false
        if ((ch.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) == 0 &&
            (ch.properties and BluetoothGattCharacteristic.PROPERTY_WRITE) == 0) {
            append("$kind BLOCKED: characteristic is not writable")
            return false
        }
        return try {
            capture(kind, ch.uuid.toString(), bytes, "reference-capture replay")
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                val writeType = if ((ch.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0)
                    BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE else BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                val rc = g.writeCharacteristic(ch, bytes, writeType)
                append("$kind queued rc=$rc")
                rc == BluetoothGatt.GATT_SUCCESS
            } else {
                @Suppress("DEPRECATION")
                ch.writeType = if ((ch.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0)
                    BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE else BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                @Suppress("DEPRECATION")
                ch.value = bytes
                @Suppress("DEPRECATION")
                val ok = g.writeCharacteristic(ch)
                append("$kind queued ok=$ok")
                ok
            }
        } catch (e: Exception) {
            append("$kind ERROR=${e.message}")
            false
        }
    }

    private fun properties(ch: BluetoothGattCharacteristic): String {
        val p = mutableListOf<String>()
        if (ch.properties and BluetoothGattCharacteristic.PROPERTY_READ != 0) p.add("READ")
        if (ch.properties and BluetoothGattCharacteristic.PROPERTY_WRITE != 0) p.add("WRITE")
        if (ch.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0) p.add("WRITE_NR")
        if (ch.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0) p.add("NOTIFY")
        if (ch.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0) p.add("INDICATE")
        return p.joinToString(",")
    }

    private fun shortUuid(uuid: UUID): String = uuid.toString()

    private fun ByteArray.toHex(): String =
        take(128).joinToString(" ") { "%02X".format(it.toInt() and 0xFF) }

    private fun recordCaptureLine(line: String) {
        synchronized(captureLines) { captureLines.add(line) }
        try {
            openFileOutput(internalCaptureFileName, android.content.Context.MODE_APPEND).bufferedWriter().use {
                it.append(line).append('\n')
            }
        } catch (_: Exception) {}
        updateCaptureStatus()
    }

    private fun updateCaptureStatus() {
        if (!::captureStatus.isInitialized) return
        runOnUiThread {
            captureStatus.text = "CAPTURE: RX=$rxCount • TX=$txCount • META=$metaCount • lines=${synchronized(captureLines) { captureLines.size }} • AUTO-BACKUP=ON"
        }
    }

    private fun captureMeta(kind: String, uuid: String) {
        val n = synchronized(captureLines) { packetNo += 1; packetNo }
        metaCount += 1
        val line = "${ts.format(Date())}\t#$n\tMETA\t$kind\t$uuid"
        recordCaptureLine(line)
        append(line)
    }

    private fun capture(kind: String, uuid: String, bytes: ByteArray, extra: String = "") {
        val n = synchronized(captureLines) { packetNo += 1; packetNo }
        if (kind.startsWith("RX_")) rxCount += 1
        if (kind.startsWith("TX_")) txCount += 1
        val line = "${ts.format(Date())}\t#$n\t$kind\t$uuid\tlen=${bytes.size}\t$extra\thex=${bytes.joinToString("") { "%02X".format(it.toInt() and 0xFF) }}"
        recordCaptureLine(line)
        append(line)
    }


    private fun openCaptureFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "text/plain"
            addCategory(Intent.CATEGORY_OPENABLE)
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        try { startActivityForResult(intent, OPEN_CAPTURE) }
        catch (e: Exception) { append("IMPORT ERROR=${e.message}") }
    }

    @Deprecated("Activity result API retained for phone-only compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        if (requestCode == CREATE_CAPTURE) {
            val uri = data.data ?: run { append("SAVE ERROR: no destination selected"); return }
            try {
                val body = captureBody()
                contentResolver.openOutputStream(uri, "wt")?.use { out -> out.write(body.toByteArray(Charsets.UTF_8)) }
                    ?: throw IllegalStateException("Cannot open output stream")
                append("CAPTURE SAVED: lines=${body.lineSequence().count()} bytes=${body.toByteArray(Charsets.UTF_8).size}")
                Toast.makeText(this, "Capture saved", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                append("SAVE ERROR=${e.javaClass.simpleName}: ${e.message}")
                Toast.makeText(this, "Save failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
            return
        }
        if (requestCode != OPEN_CAPTURE) return
        try {
            val uris = mutableListOf<Uri>()
            data.data?.let { uris.add(it) }
            data.clipData?.let { clip -> for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri) }
            val unique = uris.distinct().take(2)
            if (unique.isEmpty()) return
            val imported = unique.map { uri ->
                contentResolver.openInputStream(uri)?.use { input -> BufferedReader(InputStreamReader(input)).readLines() } ?: emptyList()
            }
            if (imported.size == 1) {
                importedA = imported[0]
                append("IMPORTED SESSION A: ${imported[0].size} lines")
            } else {
                importedA = imported[0]
                importedB = imported[1]
                append("IMPORTED A=${imported[0].size} lines, B=${imported[1].size} lines")
                analyzeDifferential(imported[0], imported[1])
            }
        } catch (e: Exception) { append("IMPORT ERROR=${e.message}") }
    }

    private fun payload(line: String): ByteArray? {
        val h = line.substringAfter("hex=", "").trim().takeIf { it.isNotBlank() } ?: return null
        if (h.length % 2 != 0 || !h.all { it in "0123456789abcdefABCDEF" }) return null
        return ByteArray(h.length / 2) { i -> h.substring(i * 2, i * 2 + 2).toInt(16).toByte() }
    }

    private fun captureRecords(lines: List<String>, len: Int? = null, kindPrefix: String? = null): List<ByteArray> =
        lines.filter { line ->
            (len == null || Regex("\\blen=$len\\b").containsMatchIn(line)) &&
            (kindPrefix == null || line.contains("\t$kindPrefix\t"))
        }.mapNotNull { payload(it) }

    private fun sha256Hex(bytes: ByteArray): String {
        val md = java.security.MessageDigest.getInstance("SHA-256")
        return md.digest(bytes).joinToString("") { "%02X".format(it.toInt() and 0xFF) }
    }

    private fun evidenceQuality(lines: List<String>, label: String) {
        val valid = lines.mapNotNull { line ->
            val len = Regex("\\blen=(\\d+)").find(line)?.groupValues?.get(1)?.toIntOrNull()
            val hex = line.substringAfter("hex=", "").trim()
            if (len != null && hex.length == len * 2 && hex.all { it in "0123456789abcdefABCDEF" }) Pair(len, hex) else null
        }
        append("[$label] validHexRecords=${valid.size}/${lines.size}")
        val byLen = valid.groupingBy { it.first }.eachCount()
        append("[$label] validatedLengths=" + byLen.entries.sortedBy { it.key }.joinToString { "${it.key}B:${it.value}" })
        val bad = lines.size - valid.size
        if (bad > 0) append("[$label] WARNING malformed/incomplete records=$bad")
    }

    private fun analyzeDifferential(a: List<String>, b: List<String>) {
        append("=== V17 CROSS-SESSION EVIDENCE DIFFERENTIAL ===")
        evidenceQuality(a, "A")
        evidenceQuality(b, "B")
        compareClass("9B", captureRecords(a, 9), captureRecords(b, 9))
        compareClass("13B", captureRecords(a, 13), captureRecords(b, 13))
        compareClass("16B", captureRecords(a, 16), captureRecords(b, 16))
        compareClass("32B", captureRecords(a, 32), captureRecords(b, 32))
        val aBulk = captureRecords(a, 235) + captureRecords(a, 157)
        val bBulk = captureRecords(b, 235) + captureRecords(b, 157)
        append("BULK A=${aBulk.sumOf { it.size }}B B=${bBulk.sumOf { it.size }}B")
        if (aBulk.isNotEmpty()) bulkStructure("A", aBulk)
        if (bBulk.isNotEmpty()) bulkStructure("B", bBulk)
        if (aBulk.isNotEmpty() && bBulk.isNotEmpty()) {
            append("BULK SHA256 A=${sha256Hex(aBulk.fold(ByteArray(0)) { acc, x -> acc + x })}")
            append("BULK SHA256 B=${sha256Hex(bBulk.fold(ByteArray(0)) { acc, x -> acc + x })}")
        }
        append("RULE: differing bytes are candidates only; no field meaning/key/checksum is claimed")
        append("EVIDENCE CLASSIFICATION: stable/session-varying/parameter-varying separation requires controlled captures")
    }

    private fun compareClass(label: String, a: List<ByteArray>, b: List<ByteArray>) {
        append("[$label] A=${a.size} B=${b.size}")
        if (a.isEmpty() || b.isEmpty()) return
        val n = minOf(a.size, b.size)
        val diffCounts = IntArray(label.removeSuffix("B").toInt())
        var exact = 0
        for (i in 0 until n) {
            if (a[i].contentEquals(b[i])) exact++
            for (j in diffCounts.indices) if (a[i][j] != b[i][j]) diffCounts[j]++
        }
        append("[$label] aligned=$n exact=$exact/${n} differing-per-position=" + diffCounts.mapIndexed { i,c -> "$i:$c" }.joinToString(","))
        append("[$label] NOTE alignment is capture-order only; position != field until independently proven")
        append("[$label] Aunique=${a.map { it.toHexFull() }.toSet().size} Bunique=${b.map { it.toHexFull() }.toSet().size}")
    }

    private fun bulkStructure(label: String, chunks: List<ByteArray>) {
        val stream = chunks.fold(ByteArray(0)) { acc, x -> acc + x }
        append("BULK $label chunks=${chunks.size} reassembled=${stream.size}B")
        if (stream.isNotEmpty()) {
            append("BULK $label first64=${stream.take(64).joinToString("") { "%02X".format(it.toInt() and 0xFF) }}")
            val zeros = stream.count { it.toInt() == 0 }
            append("BULK $label zeroBytes=$zeros/${stream.size}")
        }
    }

    private fun ByteArray.toHexFull(): String = joinToString("") { "%02X".format(it.toInt() and 0xFF) }

    private data class TimedRecord(
        val index: Int,
        val timeMs: Long,
        val kind: String,
        val uuid: String,
        val len: Int,
        val bytes: ByteArray
    )

    private fun parseTimedRecord(line: String, index: Int): TimedRecord? {
        val time = Regex("^(\\d{2}):(\\d{2}):(\\d{2})\\.(\\d{3})\\t").find(line) ?: return null
        val h = time.groupValues[1].toLong()
        val m = time.groupValues[2].toLong()
        val sec = time.groupValues[3].toLong()
        val ms = time.groupValues[4].toLong()
        val t = (((h * 60 + m) * 60 + sec) * 1000 + ms)
        val parts = line.split('\t')
        if (parts.size < 4) return null
        val kind = parts.getOrNull(2) ?: return null
        val uuid = parts.getOrNull(3) ?: return null
        val len = Regex("\\blen=(\\d+)\\b").find(line)?.groupValues?.get(1)?.toIntOrNull() ?: return null
        val bytes = payload(line) ?: return null
        if (bytes.size != len) return null
        return TimedRecord(index, t, kind, uuid, len, bytes)
    }

    private fun analyzeTemporalCorrelation() {
        val lines = synchronized(captureLines) { captureLines.toList() }
        if (lines.isEmpty()) { append("CORRELATION: CAPTURE EMPTY"); return }
        val records = lines.mapIndexedNotNull { i, line -> parseTimedRecord(line, i) }
        append("=== V21 TX/RX TEMPORAL CORRELATION ===")
        append("validTimedRecords=${records.size}/${lines.size}")
        if (records.isEmpty()) return

        val tx = records.filter { it.kind.startsWith("TX_") }
        val rx = records.filter { it.kind.startsWith("RX_") }
        append("TX=${tx.size} RX=${rx.size}")

        fun hexPrefix(b: ByteArray, n: Int = 8): String = b.take(n).joinToString("") { "%02X".format(it.toInt() and 0xFF) }
        val windows = listOf(10L, 50L, 200L, 1000L)
        for (w in windows) {
            var matched = 0
            for (t in tx) if (rx.any { it.timeMs >= t.timeMs && it.timeMs - t.timeMs <= w }) matched++
            append("TX->RX within ${w}ms: $matched/${tx.size}")
        }

        for (t in tx.take(40)) {
            val r = rx.firstOrNull { it.timeMs >= t.timeMs }
            if (r != null) {
                append("TX#${t.index} ${t.kind} ${t.len}B -> RX#${r.index} ${r.kind} ${r.len}B dt=${r.timeMs-t.timeMs}ms tx=${hexPrefix(t.bytes)} rx=${hexPrefix(r.bytes)}")
            }
        }

        val txByLen = tx.groupingBy { it.len }.eachCount().toSortedMap()
        val rxByLen = rx.groupingBy { it.len }.eachCount().toSortedMap()
        append("TX length histogram=" + txByLen.entries.joinToString { "${it.key}B:${it.value}" })
        append("RX length histogram=" + rxByLen.entries.joinToString { "${it.key}B:${it.value}" })
        append("RULE: temporal proximity is correlation evidence only; it does not assign protocol fields or meanings")
        append("RULE: first RX after TX is not assumed to be the semantic response")
    }

    private fun analyzeControlledByteDiff() {
        val a = importedA
        val b = importedB
        if (a == null || b == null) {
            append("DIFF A/B: requires two imported captures (A and B)")
            return
        }
        val ra = a.mapIndexedNotNull { i, line -> parseTimedRecord(line, i) }
            .filter { it.kind.startsWith("TX_") }
        val rb = b.mapIndexedNotNull { i, line -> parseTimedRecord(line, i) }
            .filter { it.kind.startsWith("TX_") }
        append("=== V22 CONTROLLED BYTE DIFFERENTIAL ===")
        append("A valid TX=${ra.size}; B valid TX=${rb.size}")
        val groupsA = ra.groupBy { it.kind to it.len }
        val groupsB = rb.groupBy { it.kind to it.len }
        val keys = (groupsA.keys + groupsB.keys).toSortedSet(compareBy<Pair<String,Int>>({it.first},{it.second}))
        var comparable = 0
        var totalDiff = 0
        for (key in keys) {
            val ga = groupsA[key].orEmpty()
            val gb = groupsB[key].orEmpty()
            val n = minOf(ga.size, gb.size)
            if (n == 0) continue
            var same = 0
            val posDiff = IntArray(key.second)
            var byteComparisons = 0L
            for (i in 0 until n) {
                val x = ga[i].bytes
                val y = gb[i].bytes
                if (x.contentEquals(y)) same++
                for (j in 0 until minOf(x.size, y.size)) {
                    byteComparisons++
                    if (x[j] != y[j]) { posDiff[j]++; totalDiff++ }
                }
            }
            comparable += n
            append("GROUP ${key.first}/${key.second}B pairs=$n identical=$same/${n} byteComparisons=$byteComparisons")
            val active = mutableListOf<String>()
            for (idx in posDiff.indices) {
                val c = posDiff[idx]
                if (c > 0) active.add("${idx}:${c}")
            }
            if (active.isNotEmpty()) append("  differing byte positions=count: " + active.joinToString(" "))
        }
        append("COMPARABLE TX RECORD PAIRS=$comparable totalByteDifferences=$totalDiff")
        append("RULE: ordinal pairing within same kind+length is only a controlled alignment heuristic; it does NOT prove field semantics")
        append("RULE: a parameter meaning is accepted only when repeated controlled captures reproduce the same localized change")
        append("RULE: no decrypt, checksum inference, actuator mapping, or DSP write is performed")
    }

    private fun analyzeControlledStability() {
        val a = importedA
        val b = importedB
        if (a == null || b == null) {
            append("STABILITY: requires two imported captures (A and B)")
            return
        }
        val ra = a.mapIndexedNotNull { i, line -> parseTimedRecord(line, i) }.filter { it.kind.startsWith("TX_") }
        val rb = b.mapIndexedNotNull { i, line -> parseTimedRecord(line, i) }.filter { it.kind.startsWith("TX_") }
        append("=== V23 CONTROLLED STABILITY REPORT ===")
        append("A valid TX=${ra.size}; B valid TX=${rb.size}")
        val groupsA = ra.groupBy { it.kind to it.len }
        val groupsB = rb.groupBy { it.kind to it.len }
        val keys = (groupsA.keys + groupsB.keys).toSortedSet(compareBy<Pair<String,Int>>({it.first},{it.second}))
        for (key in keys) {
            val ga = groupsA[key].orEmpty()
            val gb = groupsB[key].orEmpty()
            val n = minOf(ga.size, gb.size)
            if (n == 0) continue
            val changed = IntArray(key.second)
            var identical = 0
            for (i in 0 until n) {
                val x = ga[i].bytes
                val y = gb[i].bytes
                if (x.contentEquals(y)) identical++
                for (j in 0 until key.second) if (x[j] != y[j]) changed[j]++
            }
            val active = changed.withIndex().filter { it.value > 0 }
            val always = active.filter { it.value == n }.map { it.index }
            append("GROUP ${key.first}/${key.second}B pairs=$n identical=$identical")
            append("  changedPositions=" + active.joinToString(" ") { "${it.index}:${it.value}/$n" }.ifBlank { "none" })
            append("  alwaysChangedPositions=" + always.joinToString(",").ifBlank { "none" })
            append("  RULE: repeated localized change is controlled-difference evidence only; it is NOT a field/command assignment")
        }
        append("STABILITY RULE: promote parameter-varying evidence only after the same controlled UI change repeats in independent sessions")
        append("STABILITY RULE: session-wide/randomized changes are not promoted to DSP fields")
        append("STABILITY RULE: no decrypt, checksum inference, actuator mapping, or DSP write")
    }

    private fun captureBody(): String {
        val memory = synchronized(captureLines) { captureLines.joinToString("\n") }
        if (memory.isNotBlank()) return memory
        return try { openFileInput(internalCaptureFileName).bufferedReader().use { it.readText() } } catch (_: Exception) { "" }
    }

    private fun quickSaveCaptureToDownloads() {
        val body = captureBody()
        if (body.isBlank()) {
            append("CAPTURE EMPTY — connect/capture first")
            Toast.makeText(this, "Capture is empty", Toast.LENGTH_LONG).show()
            return
        }
        if (android.os.Build.VERSION.SDK_INT < 29) {
            saveCaptureFile()
            return
        }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val name = "OKN_DSP_V34_CAPTURE_${stamp}.txt"
        try {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, "text/plain")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/OKN_DSP")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("MediaStore insert failed")
            contentResolver.openOutputStream(uri, "w")?.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                ?: throw IllegalStateException("Cannot open Downloads output")
            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
            append("QUICK SAVE OK: Downloads/OKN_DSP/$name lines=${body.lineSequence().count()}")
            Toast.makeText(this, "Saved to Downloads/OKN_DSP", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            append("QUICK SAVE ERROR=${e.javaClass.simpleName}: ${e.message}; opening Save As")
            saveCaptureFile()
        }
    }

    private fun saveCaptureFile() {
        val body = synchronized(captureLines) { captureLines.joinToString("\n") }
        if (body.isBlank()) {
            append("CAPTURE EMPTY — connect/capture first")
            Toast.makeText(this, "Capture is empty", Toast.LENGTH_LONG).show()
            return
        }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            type = "text/plain"
            addCategory(Intent.CATEGORY_OPENABLE)
            putExtra(Intent.EXTRA_TITLE, "OKN_DSP_V34_CAPTURE_${stamp}.txt")
        }
        try {
            startActivityForResult(intent, CREATE_CAPTURE)
            append("SAVE PICKER OPEN: captureLines=${synchronized(captureLines) { captureLines.size }}")
        } catch (e: Exception) {
            append("SAVE PICKER ERROR=${e.javaClass.simpleName}: ${e.message}")
            Toast.makeText(this, "Cannot open save dialog", Toast.LENGTH_LONG).show()
        }
    }

    private fun copyCaptureToClipboard() {
        val body = synchronized(captureLines) { captureLines.joinToString("\n") }
        if (body.isBlank()) { append("CAPTURE EMPTY"); return }
        val cm = getSystemService(android.content.ClipboardManager::class.java)
        cm.setPrimaryClip(android.content.ClipData.newPlainText("OKN DSP capture", body))
        append("CAPTURE COPIED TO CLIPBOARD: lines=${synchronized(captureLines) { captureLines.size }}")
        Toast.makeText(this, "Capture copied", Toast.LENGTH_LONG).show()
    }

    private fun shareCapture() {
        val body = synchronized(captureLines) { captureLines.joinToString("\n") }
        if (body.isBlank()) { append("CAPTURE EMPTY"); return }
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "OKN DSP V34 BLE evidence capture")
            putExtra(Intent.EXTRA_TEXT, body)
        }
        startActivity(Intent.createChooser(intent, "Export DSP capture"))
    }


    private fun analyzeCapture() {
        val lines = synchronized(captureLines) { captureLines.toList() }
        if (lines.isEmpty()) { append("ANALYSIS: CAPTURE EMPTY"); return }
        val lens = linkedMapOf<Int, Int>()
        val tx = mutableListOf<String>()
        val rx = mutableListOf<String>()
        for (line in lines) {
            val len = Regex("\\blen=(\\d+)").find(line)?.groupValues?.get(1)?.toIntOrNull()
            if (len != null) lens[len] = (lens[len] ?: 0) + 1
            when {
                "\tTX_" in line -> tx.add(line)
                "\tRX_" in line -> rx.add(line)
            }
        }
        append("=== CAPTURE ANALYSIS V34 ===")
        append("records=${lines.size} sessions=$sessionNo")
        append("length histogram=${lens.entries.sortedBy { it.key }.joinToString { "${it.key}B:${it.value}" }}")
        append("TX records=${tx.size} RX records=${rx.size}")
        val repeated9 = lines.filter { Regex("\\blen=9\\b").containsMatchIn(it) }
        val repeated13 = lines.filter { Regex("\\blen=13\\b").containsMatchIn(it) }
        append("9B records=${repeated9.size}; 13B records=${repeated13.size}")
        if (repeated9.isNotEmpty()) append("9B unique=${uniquePayloads(repeated9)}")
        if (repeated13.isNotEmpty()) append("13B unique=${uniquePayloads(repeated13)}")
        val bulk235 = lines.count { Regex("\\blen=235\\b").containsMatchIn(it) }
        val bulk157 = lines.count { Regex("\\blen=157\\b").containsMatchIn(it) }
        if (bulk235 > 0 || bulk157 > 0) append("bulk candidates: 235B=$bulk235 157B=$bulk157 total=${bulk235*235 + bulk157*157}B")
        append("NOTE: statistical analysis only; no guessed decrypt/write performed")
    }

    private fun uniquePayloads(lines: List<String>): Int {
        return lines.mapNotNull { line ->
            line.substringAfter("hex=", "").takeIf { it.isNotBlank() }
        }.toSet().size
    }

    private fun append(message: String) {
        runOnUiThread {
            logLines.append(message).append('\n')
            log.text = "Log:\n$logLines"
        }
    }

    override fun onDestroy() {
        if (sessionNo > 0) captureMeta("ACTIVITY_DESTROY", "local")
        try { scanner?.stopScan(callback) } catch (_: Exception) {}
        try { gatt?.close() } catch (_: Exception) {}
        gatt = null
        super.onDestroy()
    }
}
