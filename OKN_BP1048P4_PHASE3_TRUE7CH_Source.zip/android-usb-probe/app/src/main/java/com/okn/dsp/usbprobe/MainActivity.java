package com.okn.dsp.usbprobe;

import android.app.*;
import android.os.*;
import android.content.*;
import android.hardware.usb.*;
import android.widget.*;
import java.util.*;

public final class MainActivity extends Activity {
    private static final int TARGET_VID=0x18B4, TARGET_PID=0x06B7;
    private static final String ACTION_USB_PERMISSION="com.okn.dsp.usbprobe.USB_PERMISSION";
    private UsbManager usb; private TextView log; private UsbDevice selected;

    private final BroadcastReceiver receiver=new BroadcastReceiver(){
        @Override public void onReceive(Context c,Intent i){
            if(!ACTION_USB_PERMISSION.equals(i.getAction()))return;
            UsbDevice d=i.getParcelableExtra(UsbManager.EXTRA_DEVICE);
            if(i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED,false)&&d!=null){selected=d; probeReadOnly(d);} else add("USB permission denied");
        }
    };

    @Override public void onCreate(Bundle b){super.onCreate(b);usb=(UsbManager)getSystemService(USB_SERVICE);buildUi();
        IntentFilter f=new IntentFilter(ACTION_USB_PERMISSION);
        if(Build.VERSION.SDK_INT>=33)registerReceiver(receiver,f,RECEIVER_NOT_EXPORTED);else registerReceiver(receiver,f);
    }
    @Override protected void onDestroy(){super.onDestroy();unregisterReceiver(receiver);}

    private void buildUi(){LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(28,28,28,28);
        TextView t=new TextView(this);t.setText("OKN BP1048P4 USB-C Read-Only Probe\nNo firmware write / no erase");t.setTextSize(20);
        Button scan=new Button(this);scan.setText("Scan + read Feature report");log=new TextView(this);ScrollView sv=new ScrollView(this);sv.addView(log);
        root.addView(t);root.addView(scan);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);scan.setOnClickListener(v->scan());}

    private void scan(){Map<String,UsbDevice> m=usb.getDeviceList();add("USB devices: "+m.size());selected=null;
        for(UsbDevice d:m.values()){add(String.format(Locale.US,"VID=%04X PID=%04X interfaces=%d",d.getVendorId(),d.getProductId(),d.getInterfaceCount()));dumpInterfaces(d);
            if(d.getVendorId()==TARGET_VID&&d.getProductId()==TARGET_PID)selected=d;}
        if(selected==null){add("Target 18B4:06B7 not found");return;} requestOrProbe(selected);}

    private void dumpInterfaces(UsbDevice d){for(int i=0;i<d.getInterfaceCount();i++){UsbInterface ui=d.getInterface(i);add("  IF"+ui.getId()+" class="+ui.getInterfaceClass()+" sub="+ui.getInterfaceSubclass()+" proto="+ui.getInterfaceProtocol()+" ep="+ui.getEndpointCount());
        for(int e=0;e<ui.getEndpointCount();e++){UsbEndpoint ep=ui.getEndpoint(e);add("    EP addr=0x"+Integer.toHexString(ep.getAddress())+" dir="+(ep.getDirection()==UsbConstants.USB_DIR_IN?"IN":"OUT")+" type="+ep.getType()+" max="+ep.getMaxPacketSize());}}}

    private void requestOrProbe(UsbDevice d){if(usb.hasPermission(d)){probeReadOnly(d);return;}int flags=PendingIntent.FLAG_UPDATE_CURRENT|(Build.VERSION.SDK_INT>=31?PendingIntent.FLAG_MUTABLE:0);
        PendingIntent pi=PendingIntent.getBroadcast(this,0,new Intent(ACTION_USB_PERMISSION).setPackage(getPackageName()),flags);usb.requestPermission(d,pi);}

    private void probeReadOnly(UsbDevice d){new Thread(()->{UsbDeviceConnection c=usb.openDevice(d);if(c==null){ui("openDevice failed");return;}try{
        UsbInterface hid=null;for(int i=0;i<d.getInterfaceCount();i++){UsbInterface x=d.getInterface(i);if(x.getInterfaceClass()==UsbConstants.USB_CLASS_HID){if(x.getId()==4){hid=x;break;}if(hid==null)hid=x;}}
        if(hid==null){ui("No HID interface");return;}if(!c.claimInterface(hid,true)){ui("claim HID failed");return;}
        byte[] feature=new byte[8];
        // HID GET_REPORT: bmRequestType 0xA1, bRequest 0x01, wValue=(Feature=3)<<8 | ReportID=0.
        int n=c.controlTransfer(0xA1,0x01,0x0300,hid.getId(),feature,feature.length,1500);
        ui("GET_REPORT Feature IF"+hid.getId()+" => "+n+" bytes: "+hex(feature,n));
        ui("READ-ONLY complete. No SET_REPORT / erase / firmware write was sent.");
        c.releaseInterface(hid);
    }finally{c.close();}},"okn-usb-readonly").start();}

    private static String hex(byte[] b,int n){if(n<=0)return "<none>";StringBuilder s=new StringBuilder();for(int i=0;i<n&&i<b.length;i++){if(i>0)s.append(' ');s.append(String.format(Locale.US,"%02X",b[i]&255));}return s.toString();}
    private void add(String s){log.append(s+"\n");}
    private void ui(String s){runOnUiThread(()->add(s));}
}
