# OKN BP1048P4 Phase3 — TRUE 7CH Gain / Source Only
วันที่: 2026-09-18

เป้าหมายของชุดนี้คือ **เฟิร์มแวร์ใหม่ของเราเอง** สำหรับบอร์ด GoloPine/MVSilicon BP1048P4 โดยวางระดับเสียง CH1..CH7 เป็น gain stage แยกจาก EQ โดยเด็ดขาด

## กฎที่บังคับใน Phase3
- **ห้ามใช้ EQ/Biquad gain เป็น Channel Volume**
- CH1..CH7 ใช้ gain stage ของ PCM output แยก 7 ช่อง หลัง EQ/crossover และก่อนส่งออก DAC/I2S
- UFE actuator ใหม่ของ OKN ใช้ ID **22..28** เท่านั้น และจะมีผลเฉพาะเมื่อรัน firmware OKN ที่ประกาศ capability ตรงกัน
- แอปต้อง fail-closed: ห้ามส่ง ID22..28 ไป stock GoloPine firmware
- ส่วน first-flash/erase/bootloader ของ stock board ยัง **ปิด** จนกว่าจะยืนยัน boot/update transport, flash map และ recovery

## สิ่งที่ source นี้ทำได้จริง
- true gain DSP core 7 ช่อง (Q2.14, 0.5 dB, -70..+6 dB)
- saturation 16-bit และ independent CH processing
- UFE write/read สำหรับ Channel1Volume..Channel7Volume
- logical 7-output topology: DAC0 L/R, Bass mono, I2S0 L/R, I2S1 L/R
- capability manifest และ Device Description actuator extension
- Android USB-C **read-only probe** สำหรับ Samsung S25+; อ่าน USB descriptor/Feature report โดยไม่ส่ง erase/write/update
- host tests + GitHub Actions workflow

## สิ่งที่ยังไม่ใช่
ชุดนี้ **ไม่ใช่ .bin พร้อมแฟลช** เพราะยังไม่มีหลักฐานเพียงพอสำหรับ exact GoloPine linker/flash/bank map, bootloader image format, first-install USB protocol และ recovery path. `firmware/port/` จึงไม่มี flash writer และไม่มี hard-coded flash address.

เมื่อ mapping ของ audio callback ถูกยืนยัน ให้เรียก `okn_gain7_process_topology()` ที่จุด **post-EQ/post-crossover, pre-output-sink**. นี่เป็น gain stage จริง ไม่แก้ coefficient ของ EQ.
