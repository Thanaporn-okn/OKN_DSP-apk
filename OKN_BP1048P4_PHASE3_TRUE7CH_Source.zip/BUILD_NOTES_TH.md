# Build notes

Host test:
```bash
bash tests/run_host_tests.sh
```

Android read-only USB probe:
```bash
gradle -p android-usb-probe :app:assembleDebug
```

ไม่มี target BP1048P4 `.bin` build command ใน Phase3 เพราะ exact board toolchain/linker/startup/image packaging ยังไม่ถูกยืนยัน. การใส่ generic linker เพื่อให้ได้ `.bin` หลอก ๆ จะขัดกับ safety gate ของโครงการ.
