import 'package:flutter/material.dart';

void main()=>runApp(const OKNDSP());

class OKNDSP extends StatelessWidget{
 const OKNDSP({super.key});
 @override
 Widget build(BuildContext c)=>MaterialApp(
 home:Scaffold(
 appBar:AppBar(title:const Text('OKN_DSP BP1048P4 V38')),
 body:const Padding(
 padding:EdgeInsets.all(20),
 child:Text('Android V2 Embedding Clean Build\n\nBluetooth DSP Controller\nBP1048P4 Command Layer\nCH1-CH7 Ready',
 style:TextStyle(fontSize:22))))
 );
}
