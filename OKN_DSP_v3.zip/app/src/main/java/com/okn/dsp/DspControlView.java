package com.okn.dsp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

import java.util.Locale;

/**
 * OKN_DSP v3
 * Custom-drawn UI based strictly on the supplied reference image.
 * No external UI framework or image overlay is used.
 */
public class DspControlView extends View {
    private static final float VW = 512f;
    private static final float VH = 1536f;
    private static final float NAV_H = 108f;
    private static final float HOME_CONTENT_BOTTOM = 1428f;
    private static final float EQ_CONTENT_BOTTOM = 1367f;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();

    private int page = 0; // 0=Home, 1=EQ
    private int activeSlider = -1;
    private int activeEqBand = -1;

    // v3: preserve the reference UI proportions on every phone.
    // The design is scaled uniformly from the 512 px reference width and the
    // long page is scrolled vertically instead of being stretched to screen height.
    private float viewportH = VH;
    private float homeScroll = 0f;
    private float eqScroll = 0f;
    private float lastTouchY = 0f;
    private boolean scrollGesture = false;

    private float master = -6f;
    private float bass = 0f;
    private float cutoff = 80f;
    private float bassBoost = 4f;
    private float midBoost = 2f;
    private float trebleBoost = 3f;
    private final float[] eqGain = {-3f, 0f, 4f, -2f, -4f, 2f, 0f};

    private final int bg = Color.rgb(0, 14, 24);
    private final int panel = Color.rgb(4, 29, 46);
    private final int panel2 = Color.rgb(5, 35, 56);
    private final int border = Color.rgb(27, 79, 112);
    private final int cyan = Color.rgb(0, 151, 255);
    private final int cyan2 = Color.rgb(0, 103, 255);
    private final int white = Color.rgb(240, 246, 255);
    private final int muted = Color.rgb(175, 195, 225);
    private final int rail = Color.rgb(31, 65, 90);
    private final int green = Color.rgb(46, 240, 73);

    private final int[] bandColors = {
            Color.rgb(255, 63, 63),
            Color.rgb(255, 156, 29),
            Color.rgb(255, 208, 43),
            Color.rgb(93, 235, 56),
            Color.rgb(0, 197, 241),
            Color.rgb(146, 68, 238),
            Color.rgb(246, 93, 167)
    };

    public DspControlView(Context context) {
        super(context);
        p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeJoin(Paint.Join.ROUND);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (getWidth() <= 0 || getHeight() <= 0) return;
        int save = canvas.save();
        try {
            // Important: use ONE scale factor. v2 used separate X/Y scaling, which
            // distorted the UI on modern tall phones. v3 keeps the reference ratio
            // and uses vertical scrolling for the long content.
            float scale = getWidth() / VW;
            if (scale <= 0f) return;
            viewportH = getHeight() / scale;

            if (page == 0) homeScroll = clamp(homeScroll, 0f, maxScrollForPage(0));
            else eqScroll = clamp(eqScroll, 0f, maxScrollForPage(1));

            canvas.scale(scale, scale);
            drawBackground(canvas);

            float navTop = getNavTop();
            int contentSave = canvas.save();
            canvas.clipRect(0f, 0f, VW, navTop);
            canvas.translate(0f, -(page == 0 ? homeScroll : eqScroll));
            if (page == 0) drawHome(canvas); else drawEq(canvas);
            canvas.restoreToCount(contentSave);

            // Navigation remains fixed and easy to reach while the page scrolls.
            drawBottomNav(canvas, page == 0 ? 0 : 1);
        } catch (Throwable ignored) {
            // Never let a drawing failure close the app.
            canvas.restoreToCount(save);
            canvas.drawColor(Color.rgb(0, 16, 27));
            Paint safe = new Paint(Paint.ANTI_ALIAS_FLAG);
            safe.setColor(Color.WHITE);
            safe.setTextSize(34f);
            safe.setTypeface(Typeface.DEFAULT_BOLD);
            canvas.drawText("OKN_DSP", 36f, 72f, safe);
            safe.setTextSize(20f);
            safe.setTypeface(Typeface.DEFAULT);
            canvas.drawText("UI render recovery mode", 36f, 112f, safe);
            return;
        }
        canvas.restoreToCount(save);
    }

    private float getNavTop() {
        return Math.max(0f, viewportH - NAV_H);
    }

    private float maxScrollForPage(int whichPage) {
        float contentBottom = whichPage == 0 ? HOME_CONTENT_BOTTOM : EQ_CONTENT_BOTTOM;
        return Math.max(0f, contentBottom - getNavTop() + 16f);
    }

    private float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private void drawBackground(Canvas c) {
        p.setStyle(Paint.Style.FILL);
        float bgH = Math.max(viewportH, 720f);
        p.setShader(new LinearGradient(0, 0, VW, bgH,
                Color.rgb(0, 25, 43), Color.rgb(0, 9, 17), Shader.TileMode.CLAMP));
        c.drawRect(0, 0, VW, viewportH, p);
        p.setShader(null);

        p.setColor(Color.argb(40, 0, 132, 255));
        c.drawCircle(60, 40, 150, p);
        p.setColor(Color.argb(24, 0, 132, 255));
        c.drawCircle(470, 330, 230, p);
    }

    private void drawHeader(Canvas c) {
        // waveform logo
        float x = 34, cy = 54;
        float[] h = {20, 40, 62, 45, 25};
        stroke.setColor(cyan);
        stroke.setStrokeWidth(6f);
        for (int i = 0; i < h.length; i++) {
            float xx = x + i * 13;
            c.drawLine(xx, cy - h[i] / 2, xx, cy + h[i] / 2, stroke);
        }
        p.setTypeface(Typeface.create("sans", Typeface.BOLD_ITALIC));
        text(c, "OKN_", 110, 55, 29, white, Paint.Align.LEFT, true);
        text(c, "DSP", 198, 55, 29, Color.rgb(0, 128, 255), Paint.Align.LEFT, true);
        p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
        text(c, "DIGITAL SIGNAL PROCESSOR", 110, 79, 11, Color.rgb(164, 183, 221), Paint.Align.LEFT, false);

        // connection card
        round(c, 320, 27, 443, 88, 14, Color.rgb(3, 29, 44), border, 1.2f);
        stroke.setColor(Color.rgb(86, 240, 90));
        stroke.setStrokeWidth(2.2f);
        c.drawCircle(344, 57, 10, stroke);
        c.drawLine(344, 47, 344, 67, stroke);
        c.drawLine(337, 51, 351, 63, stroke);
        c.drawLine(351, 51, 337, 63, stroke);
        text(c, "เชื่อมต่อแล้ว", 365, 54, 15, white, Paint.Align.LEFT, true);
        text(c, "OKN-DSP", 365, 74, 12, muted, Paint.Align.LEFT, false);

        // gear simplified
        stroke.setColor(Color.rgb(223, 235, 255));
        stroke.setStrokeWidth(4);
        c.drawCircle(474, 57, 10, stroke);
        c.drawCircle(474, 57, 3, stroke);
        for (int i = 0; i < 8; i++) {
            double a = Math.PI * 2 * i / 8;
            float x1 = 474 + (float)Math.cos(a) * 13;
            float y1 = 57 + (float)Math.sin(a) * 13;
            float x2 = 474 + (float)Math.cos(a) * 17;
            float y2 = 57 + (float)Math.sin(a) * 17;
            c.drawLine(x1, y1, x2, y2, stroke);
        }
    }

    private void drawHome(Canvas c) {
        drawHeader(c);
        drawDeviceCard(c);

        sliderCard(c, 16, 216, 498, 372, "Master Volume", "ระดับเสียงรวม", 0,
                master, -60, 20, String.format(Locale.US, "%.1f dB", master), cyan,
                new String[]{"-60", "-40", "-20", "0", "+20"});
        drawSpeakerIcon(c, 67, 287, cyan);

        sliderCard(c, 16, 385, 498, 541, "Bass Volume", "ระดับเสียงเบส", 1,
                bass, -60, 20, String.format(Locale.US, "%.1f dB", bass), cyan,
                new String[]{"-60", "-40", "-20", "0", "+20"});
        drawBassIcon(c, 67, 457, cyan);

        sliderCard(c, 16, 554, 498, 710, "Bass Cutoff", "ความถี่ตัดเบส (Low Pass)", 2,
                cutoff, 20, 500, String.format(Locale.US, "%.0f Hz", cutoff), Color.rgb(0, 226, 192),
                new String[]{"20", "50", "100", "200", "500"});
        drawWaveIcon(c, 67, 625, cyan);

        sliderCard(c, 16, 723, 498, 879, "Bass Boost", "เพิ่มเสียงเบส", 3,
                bassBoost, -12, 12, String.format(Locale.US, "%.1f dB", bassBoost), Color.rgb(255, 174, 25),
                new String[]{"-12", "-6", "0", "+6", "+12"});
        drawBarsIcon(c, 67, 794, Color.rgb(255, 180, 48));

        sliderCard(c, 16, 892, 498, 1048, "Middle Boost", "เพิ่มเสียงกลาง", 4,
                midBoost, -12, 12, String.format(Locale.US, "%.1f dB", midBoost), Color.rgb(137, 57, 234),
                new String[]{"-12", "-6", "0", "+6", "+12"});
        drawBarsIcon(c, 67, 963, Color.rgb(142, 67, 236));

        sliderCard(c, 16, 1061, 498, 1217, "Treble Boost", "เพิ่มเสียงแหลม", 5,
                trebleBoost, -12, 12, String.format(Locale.US, "%.1f dB", trebleBoost), Color.rgb(244, 87, 164),
                new String[]{"-12", "-6", "0", "+6", "+12"});
        drawBarsIcon(c, 67, 1132, Color.rgb(246, 89, 165));

        // preset card
        round(c, 16, 1230, 498, 1329, 14, Color.rgb(3, 28, 45), border, 1.1f);
        text(c, "พรีเซ็ตด่วน", 32, 1255, 15, white, Paint.Align.LEFT, true);
        String[] presets = {"Flat", "Pop", "Rock", "Jazz", "Vocal"};
        for (int i = 0; i < 5; i++) {
            float x1 = 31 + i * 92;
            float x2 = x1 + 82;
            int fill = i == 0 ? Color.rgb(0, 123, 246) : Color.rgb(4, 30, 48);
            int bd = i == 0 ? Color.rgb(55, 180, 255) : border;
            round(c, x1, 1268, x2, 1315, 10, fill, bd, 1.1f);
            text(c, presets[i], (x1+x2)/2, 1297, 14, white, Paint.Align.CENTER, false);
        }

        // save/load buttons
        round(c, 24, 1342, 247, 1407, 10, Color.rgb(3, 28, 45), border, 1.2f);
        drawSaveIcon(c, 86, 1373, muted);
        text(c, "บันทึกพรีเซ็ต", 121, 1379, 16, white, Paint.Align.LEFT, false);
        round(c, 264, 1342, 488, 1407, 10, Color.rgb(3, 28, 45), border, 1.2f);
        drawFolderIcon(c, 327, 1373, muted);
        text(c, "โหลดพรีเซ็ต", 365, 1379, 16, white, Paint.Align.LEFT, false);

    }

    private void drawDeviceCard(Canvas c) {
        round(c, 16, 108, 498, 201, 15, Color.rgb(3, 29, 45), border, 1.1f);
        round(c, 31, 121, 100, 188, 13, Color.rgb(5, 40, 70), Color.rgb(7, 67, 111), 1f);
        // device icon
        stroke.setColor(Color.rgb(119, 155, 255));
        stroke.setStrokeWidth(2.8f);
        c.drawRoundRect(new RectF(49, 135, 78, 175), 4, 4, stroke);
        c.drawCircle(64, 159, 8, stroke);
        c.drawCircle(64, 159, 3, stroke);
        c.drawCircle(70, 141, 2.5f, stroke);

        text(c, "DSP 7 Channel", 114, 151, 20, white, Paint.Align.LEFT, true);
        text(c, "Professional Audio Processing", 114, 177, 14, muted, Paint.Align.LEFT, false);

        round(c, 315, 127, 487, 182, 12, Color.rgb(2, 28, 45), Color.rgb(0, 108, 200), 1.2f);
        drawLinkIcon(c, 339, 155, cyan);
        text(c, "ยกเลิกการเชื่อมต่อ", 360, 161, 14, white, Paint.Align.LEFT, false);
    }

    private void sliderCard(Canvas c, float l, float t, float r, float b, String title, String subtitle,
                            int idx, float value, float min, float max, String valueText, int accent,
                            String[] ticks) {
        round(c, l, t, r, b, 14, Color.rgb(3, 29, 46), border, 1f);
        text(c, title, 119, t + 39, 19, white, Paint.Align.LEFT, true);
        text(c, subtitle, 119, t + 65, 14, muted, Paint.Align.LEFT, false);
        round(c, 381, t + 21, 484, t + 67, 12, Color.rgb(2, 23, 39), Color.rgb(49, 94, 129), 1.1f);
        text(c, valueText, 475, t + 51, 18, white, Paint.Align.RIGHT, true);

        float x1 = 120, x2 = 452, y = t + 96;
        p.setStyle(Paint.Style.FILL);
        p.setColor(rail);
        c.drawRoundRect(new RectF(x1, y-7, x2, y+7), 8, 8, p);
        float ratio = (value - min) / (max - min);
        ratio = Math.max(0, Math.min(1, ratio));
        float knobX = x1 + ratio * (x2 - x1);
        if (knobX > x1 + 0.5f) {
            p.setShader(new LinearGradient(x1, y, knobX, y, accent, accent, Shader.TileMode.CLAMP));
            c.drawRoundRect(new RectF(x1, y-7, knobX, y+7), 8, 8, p);
            p.setShader(null);
        } else {
            p.setShader(null);
        }
        p.setColor(Color.rgb(238, 244, 253));
        c.drawCircle(knobX, y, 15, p);
        p.setColor(Color.argb(80, 255, 255, 255));
        c.drawCircle(knobX - 4, y - 5, 4, p);

        float[] tickXs = {120, 202, 284, 366, 448};
        for (int i=0;i<5;i++) {
            stroke.setColor(Color.rgb(84, 111, 143));
            stroke.setStrokeWidth(1.2f);
            c.drawLine(tickXs[i], y+18, tickXs[i], y+25, stroke);
            text(c, ticks[i], tickXs[i], y+47, 13, muted, Paint.Align.CENTER, false);
        }
    }

    private void drawEq(Canvas c) {
        drawHeader(c);
        drawTopTabs(c);

        // EQ graph section
        text(c, "กราฟ EQ", 28, 257, 20, white, Paint.Align.LEFT, true);
        round(c, 126, 229, 840/2f, 273, 9, Color.rgb(3, 27, 45), Color.rgb(38, 87, 123), 1.1f);
        text(c, "(CH1 : Front Left)", 144, 257, 15, white, Paint.Align.LEFT, false);
        // dropdown chevron
        stroke.setColor(muted); stroke.setStrokeWidth(1.8f);
        c.drawLine(400, 248, 407, 255, stroke); c.drawLine(407, 255, 414, 248, stroke);
        round(c, 906/2f, 229, 997/2f, 273, 9, Color.rgb(3,27,45), Color.rgb(38,87,123), 1.1f);
        text(c, "Reset", 476, 258, 15, white, Paint.Align.CENTER, false);

        drawEqGraph(c);
        drawEqBandCards(c);
        drawChannelSelector(c);
        drawEqActions(c);
    }

    private void drawTopTabs(Canvas c) {
        round(c, 16, 108, 498, 200, 15, Color.rgb(3, 29, 45), border, 1f);
        String[] tabs = {"หน้าแรก", "EQ", "Delay", "Crossover", "Output"};
        float[] cx = {61, 159, 260, 357, 460};
        for (int i=0;i<5;i++) {
            if (i==1) round(c, 112, 112, 207, 198, 12, Color.rgb(0, 126, 255), Color.rgb(0, 150, 255), 1f);
            int col = i==1 ? white : Color.rgb(190, 211, 255);
            if (i==0) drawHomeIcon(c, cx[i], 142, col);
            if (i==1) drawMiniBars(c, cx[i], 143, col);
            if (i==2) drawClockIcon(c, cx[i], 143, col);
            if (i==3) drawCrossIcon(c, cx[i], 143, col);
            if (i==4) drawSpeakerSmall(c, cx[i], 143, col);
            text(c, tabs[i], cx[i], 181, i==3?13:14, col, Paint.Align.CENTER, false);
            if (i<4) {
                stroke.setColor(Color.rgb(17, 55, 78)); stroke.setStrokeWidth(1);
                c.drawLine((cx[i]+cx[i+1])/2, 124, (cx[i]+cx[i+1])/2, 185, stroke);
            }
        }
    }

    private void drawEqGraph(Canvas c) {
        float l=60f, t=285, r=499f, b=526;
        round(c, l, t, r, b, 3, Color.rgb(2,22,35), Color.rgb(36,84,116), 1.1f);
        // grid
        stroke.setStrokeWidth(0.8f);
        for (int i=0;i<=10;i++) {
            stroke.setColor(Color.argb(80, 47, 92, 119));
            float x=l+(r-l)*i/10f;
            c.drawLine(x,t,x,b,stroke);
        }
        for (int i=0;i<=8;i++) {
            stroke.setColor(Color.argb(72, 47, 92, 119));
            float y=t+(b-t)*i/8f;
            c.drawLine(l,y,r,y,stroke);
        }
        String[] ylabels={"+12","+6","0","-6","-12"};
        for (int i=0;i<5;i++) text(c,ylabels[i],50f,t+(b-t)*i/4f+5,12,muted,Paint.Align.RIGHT,false);
        String[] xs={"20","50","100","200","500","1K","2K","5K","10K","20K"};
        for (int i=0;i<10;i++) text(c,xs[i],l+(r-l)*i/9f,b+26,12,muted,Paint.Align.CENTER,false);

        float[] px={107f,168f,235f,313f,376f,436f,475f};
        float[] gy={-3,0,4,-2,-4,2,0};
        float mid=(t+b)/2f;
        // curve fill
        Path curve=new Path();
        curve.moveTo(l, mid+22);
        curve.cubicTo(px[0]-22, mid+35, px[0]-15, gainToY(eqGain[0],t,b), px[0], gainToY(eqGain[0],t,b));
        for(int i=0;i<px.length-1;i++) {
            float x0=px[i], y0=gainToY(eqGain[i],t,b), x1=px[i+1], y1=gainToY(eqGain[i+1],t,b);
            float dx=(x1-x0)/2.2f;
            curve.cubicTo(x0+dx,y0,x1-dx,y1,x1,y1);
        }
        curve.cubicTo(r-25,gainToY(eqGain[6],t,b),r-14,mid-10,r,mid-12);
        Path fill=new Path(curve);
        fill.lineTo(r,b); fill.lineTo(l,b); fill.close();
        p.setShader(new LinearGradient(0,t,0,b,Color.argb(80,0,153,255),Color.argb(0,0,153,255),Shader.TileMode.CLAMP));
        p.setStyle(Paint.Style.FILL); c.drawPath(fill,p); p.setShader(null);
        stroke.setColor(Color.rgb(0, 161, 255)); stroke.setStrokeWidth(3.4f); c.drawPath(curve,stroke);
        for(int i=0;i<7;i++) {
            p.setColor(bandColors[i]); c.drawCircle(px[i], gainToY(eqGain[i],t,b), 8.5f,p);
            stroke.setColor(white); stroke.setStrokeWidth(1.6f); c.drawCircle(px[i],gainToY(eqGain[i],t,b),8.5f,stroke);
        }
    }

    private float gainToY(float gain, float t, float b) {
        return t + (12f-gain)/24f*(b-t);
    }

    private void drawEqBandCards(Canvas c) {
        float cardTop=584, cardBottom=1080;
        float gap=5;
        float totalW=470;
        float cardW=(totalW-gap*6)/7f;
        String[] freq={"50 Hz","100 Hz","500 Hz","1.0 kHz","2.0 kHz","5.0 kHz","10.0 kHz"};
        for(int i=0;i<7;i++) {
            float l=21+i*(cardW+gap), r=l+cardW, cx=(l+r)/2;
            round(c,l,cardTop,r,cardBottom,10,Color.rgb(3,27,43),Color.rgb(33,77,106),1f);
            p.setColor(bandColors[i]); c.drawCircle(cx,611,8.5f,p);
            text(c,String.valueOf(i+1),cx,646,14,bandColors[i],Paint.Align.CENTER,true);
            round(c,l+7,655,r-7,691,8,Color.rgb(1,20,34),Color.rgb(39,77,102),0.9f);
            text(c,freq[i],cx,679,11,white,Paint.Align.CENTER,false);
            round(c,l+7,699,r-7,738,8,Color.rgb(1,20,34),Color.rgb(39,77,102),0.9f);
            text(c,String.format(Locale.US,"%.1f",eqGain[i]),cx,725,14,white,Paint.Align.CENTER,true);
            text(c,"dB",cx,758,12,muted,Paint.Align.CENTER,false);
            round(c,l+7,775,r-7,811,8,Color.rgb(1,20,34),Color.rgb(39,77,102),0.9f);
            text(c,"1.0",cx,799,13,white,Paint.Align.CENTER,false);

            // vertical slider
            float y1=846,y2=1007;
            p.setColor(rail); c.drawRoundRect(new RectF(cx-5,y1,cx+5,y2),6,6,p);
            float knobY=gainToSlider(eqGain[i],y1,y2);
            if (knobY < y2 - 0.5f) {
                p.setShader(new LinearGradient(cx,y2,cx,knobY,bandColors[i],bandColors[i],Shader.TileMode.CLAMP));
                c.drawRoundRect(new RectF(cx-5,knobY,cx+5,y2),6,6,p);
                p.setShader(null);
            } else {
                p.setShader(null);
            }
            p.setColor(Color.rgb(238,244,253)); c.drawCircle(cx,knobY,10.5f,p);
            text(c,"+12",r-7,854,10,muted,Paint.Align.RIGHT,false);
            text(c,"0",r-7,927,10,muted,Paint.Align.RIGHT,false);
            text(c,"-12",r-7,1007,10,muted,Paint.Align.RIGHT,false);
            round(c,l+7,1028,r-7,1067,8,Color.rgb(2,24,39),Color.rgb(32,74,103),0.9f);
            drawBellIcon(c,cx,1048,white);
        }
    }

    private float gainToSlider(float gain,float top,float bottom) {
        return top+(12f-gain)/24f*(bottom-top);
    }

    private void drawChannelSelector(Canvas c) {
        round(c,16,1103,498,1247,14,Color.rgb(3,29,45),border,1f);
        text(c,"เลือกช่องสัญญาณ",29,1131,16,white,Paint.Align.LEFT,true);
        String[] a={"CH1\nFL","CH2\nFR","CH3\nRL","CH4\nRR","CH5\nCEN","CH6\nSUB","CH7\nAUX"};
        float gap=8, w=(456-gap*6)/7f;
        for(int i=0;i<7;i++) {
            float l=27+i*(w+gap),r=l+w;
            int fill=i==0?Color.rgb(0,126,255):Color.rgb(3,26,43);
            int bd=i==0?Color.rgb(42,183,255):Color.rgb(38,75,101);
            round(c,l,1150,r,1232,10,fill,bd,1f);
            String[] lines=a[i].split("\\n");
            text(c,lines[0],(l+r)/2,1183,13,white,Paint.Align.CENTER,false);
            text(c,lines[1],(l+r)/2,1210,13,white,Paint.Align.CENTER,false);
        }
    }

    private void drawEqActions(Canvas c) {
        round(c,16,1261,498,1367,13,Color.rgb(3,29,45),border,1f);
        float gap=8,w=(452-gap*2)/3f;
        String[] labels={"คัดลอก EQ","วาง EQ","บันทึกเป็นพรีเซ็ต"};
        for(int i=0;i<3;i++) {
            float l=30+i*(w+gap),r=l+w;
            round(c,l,1272,r,1352,9,Color.rgb(3,27,43),Color.rgb(38,78,105),1f);
            if(i==0) drawCopyIcon(c,l+28,1309,muted);
            if(i==1) drawPasteIcon(c,l+28,1309,muted);
            if(i==2) drawSaveIcon(c,l+28,1309,muted);
            text(c,labels[i],l+53,1317,i==2?13:14,white,Paint.Align.LEFT,false);
        }
    }

    private void drawBottomNav(Canvas c, int selected) {
        float navTop = getNavTop();
        float iconY = navTop + 44f;
        float labelY = navTop + 84f;

        p.setColor(Color.argb(242, 0, 16, 28));
        c.drawRect(0, navTop, VW, viewportH, p);
        stroke.setColor(Color.rgb(17, 49, 72)); stroke.setStrokeWidth(1.1f);
        c.drawLine(0, navTop, VW, navTop, stroke);
        float[] cx={89,256,422};
        String[] labels={"หน้าแรก","EQ","เพิ่มเติม"};
        for(int i=0;i<3;i++) {
            int col=i==selected?Color.rgb(0,154,255):Color.rgb(190,205,240);
            if(i==0) drawHomeIcon(c,cx[i],iconY,col);
            if(i==1) drawMiniBars(c,cx[i],iconY-1f,col);
            if(i==2) drawDots(c,cx[i],iconY-4f,col);
            text(c,labels[i],cx[i],labelY,15,col,Paint.Align.CENTER,false);
        }
    }

    // ----------------------- Touch handling -----------------------
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (getWidth() <= 0 || getHeight() <= 0) return true;
        float scale = getWidth() / VW;
        if (scale <= 0f) return true;
        viewportH = getHeight() / scale;

        float x = e.getX() / scale;
        float screenY = e.getY() / scale;
        float navTop = getNavTop();
        float scroll = page == 0 ? homeScroll : eqScroll;
        float contentY = screenY + scroll;

        if(e.getAction()==MotionEvent.ACTION_DOWN) {
            activeSlider = -1;
            activeEqBand = -1;
            scrollGesture = false;
            lastTouchY = screenY;

            // Bottom navigation is fixed, so its hit area never moves with content.
            if(screenY >= navTop) {
                if(x < 170) {
                    page = 0;
                    invalidate();
                    return true;
                }
                if(x < 340) {
                    page = 1;
                    invalidate();
                    return true;
                }
                return true;
            }

            if(page==0) {
                int s=homeSliderAt(contentY);
                if(s>=0 && x>=105 && x<=470) {
                    activeSlider=s;
                    updateHomeSlider(s,x);
                    return true;
                }
            } else {
                int b=eqBandAt(x,contentY);
                if(b>=0) {
                    activeEqBand=b;
                    updateEqBand(b,contentY);
                    return true;
                }
                if(contentY>=108 && contentY<=200 && x<110) {
                    page=0;
                    invalidate();
                    return true;
                }
            }

            // Dragging anywhere that is not a slider scrolls the long reference page.
            scrollGesture = true;
            return true;
        } else if(e.getAction()==MotionEvent.ACTION_MOVE) {
            if(activeSlider>=0) {
                updateHomeSlider(activeSlider,x);
                return true;
            }
            if(activeEqBand>=0) {
                float currentContentY = screenY + (page == 0 ? homeScroll : eqScroll);
                updateEqBand(activeEqBand,currentContentY);
                return true;
            }
            if(scrollGesture) {
                float delta = lastTouchY - screenY;
                if(page==0) homeScroll = clamp(homeScroll + delta, 0f, maxScrollForPage(0));
                else eqScroll = clamp(eqScroll + delta, 0f, maxScrollForPage(1));
                lastTouchY = screenY;
                invalidate();
                return true;
            }
        } else if(e.getAction()==MotionEvent.ACTION_UP || e.getAction()==MotionEvent.ACTION_CANCEL) {
            activeSlider=-1;
            activeEqBand=-1;
            scrollGesture=false;
        }
        return true;
    }

    private int homeSliderAt(float y) {
        float[] ys={312,481,650,819,988,1157};
        for(int i=0;i<ys.length;i++) if(Math.abs(y-ys[i])<35) return i;
        return -1;
    }

    private void updateHomeSlider(int i,float x) {
        float ratio=(x-120f)/(452f-120f); ratio=Math.max(0,Math.min(1,ratio));
        switch(i) {
            case 0: master=-60+ratio*80; break;
            case 1: bass=-60+ratio*80; break;
            case 2: cutoff=20+ratio*480; break;
            case 3: bassBoost=-12+ratio*24; break;
            case 4: midBoost=-12+ratio*24; break;
            case 5: trebleBoost=-12+ratio*24; break;
        }
        invalidate();
    }

    private int eqBandAt(float x,float y) {
        if(y<830 || y>1020) return -1;
        float gap=5,totalW=470,cardW=(totalW-gap*6)/7f;
        for(int i=0;i<7;i++) {
            float l=21+i*(cardW+gap),r=l+cardW;
            if(x>=l&&x<=r) return i;
        }
        return -1;
    }

    private void updateEqBand(int i,float y) {
        float top=846,bottom=1007;
        float ratio=(y-top)/(bottom-top); ratio=Math.max(0,Math.min(1,ratio));
        eqGain[i]=12-ratio*24;
        invalidate();
    }

    // ----------------------- Drawing helpers -----------------------
    private void round(Canvas c,float l,float t,float r,float b,float rad,int fill,int line,float sw) {
        p.setStyle(Paint.Style.FILL); p.setColor(fill); c.drawRoundRect(new RectF(l,t,r,b),rad,rad,p);
        if(sw>0) { stroke.setColor(line); stroke.setStrokeWidth(sw); c.drawRoundRect(new RectF(l,t,r,b),rad,rad,stroke); }
    }

    private void text(Canvas c,String s,float x,float y,float size,int color,Paint.Align align,boolean bold) {
        p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(color); p.setTextSize(size); p.setTextAlign(align);
        p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));
        c.drawText(s,x,y,p);
    }

    private void drawSpeakerIcon(Canvas c,float cx,float cy,int color) {
        stroke.setColor(color); stroke.setStrokeWidth(4); stroke.setStyle(Paint.Style.STROKE);
        Path q=new Path(); q.moveTo(cx-24,cy-9); q.lineTo(cx-13,cy-9); q.lineTo(cx+2,cy-23); q.lineTo(cx+2,cy+23); q.lineTo(cx-13,cy+9); q.lineTo(cx-24,cy+9); q.close(); c.drawPath(q,stroke);
        c.drawArc(new RectF(cx-2,cy-18,cx+26,cy+18),-55,110,false,stroke);
        c.drawArc(new RectF(cx-3,cy-28,cx+40,cy+28),-50,100,false,stroke);
    }

    private void drawSpeakerSmall(Canvas c,float cx,float cy,int color){
        stroke.setColor(color);stroke.setStrokeWidth(2.4f);Path q=new Path();q.moveTo(cx-12,cy-5);q.lineTo(cx-6,cy-5);q.lineTo(cx+2,cy-13);q.lineTo(cx+2,cy+13);q.lineTo(cx-6,cy+5);q.lineTo(cx-12,cy+5);q.close();c.drawPath(q,stroke);c.drawArc(new RectF(cx,cy-11,cx+17,cy+11),-55,110,false,stroke);
    }

    private void drawBassIcon(Canvas c,float cx,float cy,int color) {
        stroke.setColor(color); stroke.setStrokeWidth(3.5f);
        c.drawCircle(cx,cy,26,stroke); c.drawCircle(cx,cy,13,stroke);
        c.drawArc(new RectF(cx-18,cy-36,cx+18,cy-5),200,140,false,stroke);
        c.drawArc(new RectF(cx-18,cy+5,cx+18,cy+36),20,140,false,stroke);
    }

    private void drawWaveIcon(Canvas c,float cx,float cy,int color){
        stroke.setColor(color);stroke.setStrokeWidth(3.4f);Path q=new Path();q.moveTo(cx-27,cy);q.lineTo(cx-20,cy);q.lineTo(cx-15,cy-16);q.lineTo(cx-8,cy+18);q.lineTo(cx,cy-27);q.lineTo(cx+7,cy+24);q.lineTo(cx+14,cy-12);q.lineTo(cx+20,cy+5);q.lineTo(cx+28,cy+5);c.drawPath(q,stroke);
    }

    private void drawBarsIcon(Canvas c,float cx,float cy,int color){
        stroke.setColor(color);stroke.setStrokeWidth(6);float[] hs={20,40,58,35,17};for(int i=0;i<5;i++){float xx=cx-24+i*12;c.drawLine(xx,cy-hs[i]/2,xx,cy+hs[i]/2,stroke);}
    }
    private void drawMiniBars(Canvas c,float cx,float cy,int color){
        stroke.setColor(color);stroke.setStrokeWidth(2.5f);float[] hs={11,22,30,20,9};for(int i=0;i<5;i++){float xx=cx-12+i*6;c.drawLine(xx,cy-hs[i]/2,xx,cy+hs[i]/2,stroke);}
    }
    private void drawHomeIcon(Canvas c,float cx,float cy,int color){
        stroke.setColor(color);stroke.setStrokeWidth(3);Path q=new Path();q.moveTo(cx-14,cy);q.lineTo(cx,cy-13);q.lineTo(cx+14,cy);q.moveTo(cx-10,cy-2);q.lineTo(cx-10,cy+13);q.lineTo(cx+10,cy+13);q.lineTo(cx+10,cy-2);c.drawPath(q,stroke);
    }
    private void drawClockIcon(Canvas c,float cx,float cy,int color){stroke.setColor(color);stroke.setStrokeWidth(2.5f);c.drawCircle(cx,cy,13,stroke);c.drawLine(cx,cy,cx,cy-8,stroke);c.drawLine(cx,cy,cx+7,cy+4,stroke);}
    private void drawCrossIcon(Canvas c,float cx,float cy,int color){stroke.setColor(color);stroke.setStrokeWidth(2.7f);c.drawLine(cx-13,cy-9,cx+13,cy+9,stroke);c.drawLine(cx-13,cy+9,cx+13,cy-9,stroke);c.drawCircle(cx-13,cy-9,2.5f,stroke);c.drawCircle(cx+13,cy-9,2.5f,stroke);}
    private void drawDots(Canvas c,float cx,float cy,int color){p.setColor(color);for(int i=-1;i<=1;i++)c.drawCircle(cx+i*11,cy,3,p);}
    private void drawLinkIcon(Canvas c,float cx,float cy,int color){stroke.setColor(color);stroke.setStrokeWidth(2.5f);c.drawArc(new RectF(cx-11,cy-7,cx+2,cy+7),70,220,false,stroke);c.drawArc(new RectF(cx-2,cy-7,cx+11,cy+7),250,220,false,stroke);}
    private void drawSaveIcon(Canvas c,float cx,float cy,int color){stroke.setColor(color);stroke.setStrokeWidth(2.3f);c.drawRoundRect(new RectF(cx-12,cy-13,cx+12,cy+13),2,2,stroke);c.drawRect(cx-7,cy-10,cx+5,cy-2,stroke);c.drawCircle(cx,cy+6,4,stroke);}
    private void drawFolderIcon(Canvas c,float cx,float cy,int color){stroke.setColor(color);stroke.setStrokeWidth(2.3f);Path q=new Path();q.moveTo(cx-14,cy-9);q.lineTo(cx-4,cy-9);q.lineTo(cx,cy-5);q.lineTo(cx+15,cy-5);q.lineTo(cx+15,cy+10);q.lineTo(cx-14,cy+10);q.close();c.drawPath(q,stroke);}
    private void drawBellIcon(Canvas c,float cx,float cy,int color){stroke.setColor(color);stroke.setStrokeWidth(2.2f);Path q=new Path();q.moveTo(cx-13,cy+6);q.cubicTo(cx-7,cy+6,cx-7,cy-11,cx,cy-11);q.cubicTo(cx+7,cy-11,cx+7,cy+6,cx+13,cy+6);c.drawPath(q,stroke);}
    private void drawCopyIcon(Canvas c,float cx,float cy,int color){stroke.setColor(color);stroke.setStrokeWidth(2.2f);c.drawRoundRect(new RectF(cx-10,cy-12,cx+5,cy+7),2,2,stroke);c.drawRoundRect(new RectF(cx-3,cy-5,cx+12,cy+14),2,2,stroke);}
    private void drawPasteIcon(Canvas c,float cx,float cy,int color){stroke.setColor(color);stroke.setStrokeWidth(2.2f);c.drawRoundRect(new RectF(cx-10,cy-9,cx+11,cy+13),2,2,stroke);c.drawRoundRect(new RectF(cx-6,cy-14,cx+6,cy-7),2,2,stroke);}
}
