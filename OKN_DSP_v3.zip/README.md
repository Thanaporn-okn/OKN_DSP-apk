# OKN_DSP v3

Responsive-proportion UI update for the clean OKN_DSP restart.

## v3 scope
- Keeps the visual structure, colors, sections, labels, Home page and EQ page based on the supplied reference image.
- Fixes the main proportion issue from v2: X and Y are no longer stretched independently.
- Uses one width-based scale factor so circles, icons, text, cards and controls keep their intended proportions on tall Android phones.
- Adds vertical scrolling for the long reference layout instead of squeezing the whole page into one screen.
- Keeps the bottom navigation fixed on screen for easier Home/EQ switching while scrolling.
- Slider hit areas remain large and easy to drag.
- EQ vertical sliders remain directly draggable while the rest of the EQ page can scroll.
- Retains the v2 launch/render recovery guard.
- DSP/BLE commands are still intentionally not connected at this UI stage.

## Android build
- Package: `com.okn.dsp`
- Min SDK: 26
- Target/Compile SDK: 35
- Java: 17
- Android Gradle Plugin: 8.6.1
- Version code: 3
- Version name: `1.0-v3`
