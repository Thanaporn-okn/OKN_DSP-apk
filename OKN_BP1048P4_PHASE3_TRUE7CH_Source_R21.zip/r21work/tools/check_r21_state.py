#!/usr/bin/env python3
import json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
d=json.loads((root/'config/DIRECT_USBC_BOOT55_SAME_ADDRESS_STATE_R21.json').read_text())
p=d['r21_probe']
assert p['strict_normal_descriptor_gate']
assert p['strict_if4_hid_report_gate']
assert p['requires_clean_feature_first_byte_00']
assert p['one_shot_per_app_launch']
assert p['set_report_payload_hex']=='55 DE AD BE EF 00 00 00'
assert p['post_ack_raw_descriptor_snapshots_ms']==[150,700,2500]
assert p['post_ack_only_standard_get_descriptor'] is True
for k in ['aa_command','endpoint_out','bulk_transfer','mva_transfer','flash_read','flash_write','erase','program','commit']:
    assert p[k] is False, k
print('R21 state policy: PASS')
