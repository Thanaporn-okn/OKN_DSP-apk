#!/usr/bin/env python3
"""Read-only/offline firmware container fingerprint helper.

This tool never opens USB, never modifies the input file, and intentionally does
not implement a GoloPine writer/packer. It reports only objective fingerprints.
"""
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path


def inspect(path: Path) -> dict:
    data = path.read_bytes()
    head = data[:64]
    kind = "unknown"
    note = "No supported format is assumed."
    if head.startswith(b"MVO\x12"):
        kind = "MVO12-marker"
        note = "Older-family marker only; layout is not inferred."
    elif head.startswith(b"MV") and len(head) >= 5:
        kind = "MV-prefix"
        note = "MV prefix detected; chip/generation fields are reported only, not trusted as GoloPine format."
    out = {
        "path": str(path),
        "size": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "first_64_hex": head.hex(" "),
        "fingerprint_kind": kind,
        "note": note,
        "contains_MVB1X_ascii": b"MVB1X" in data,
        "contains_MVUB_ascii": b"MVUB" in data,
    }
    if kind == "MV-prefix" and len(data) >= 5:
        out["raw_chip_byte"] = data[2]
        out["raw_generation_byte"] = data[3]
        out["raw_record_count_byte"] = data[4]
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("image", type=Path)
    args = ap.parse_args()
    print(json.dumps(inspect(args.image), indent=2, ensure_ascii=False))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
