#!/usr/bin/env python3
import json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
d=json.loads((root/'config/DIRECT_USBC_FLASHBOOT_PROBE_STATE_R19.json').read_text(encoding='utf-8'))
u=d['usb_probe']
assert u['android_usb_host'] is True
assert u['standard_descriptor_control_in_only'] is True
assert u['passive_enumeration_watch'] is True
for k in ['claim_interface','bulk_transfer','interrupt_transfer','endpoint_out','set_report','feature_report','vendor_command','aa_arm','acp_command','flash_read','flash_write','erase','program']:
    assert u[k] is False, k
print('R19 fail-closed policy: PASS')
