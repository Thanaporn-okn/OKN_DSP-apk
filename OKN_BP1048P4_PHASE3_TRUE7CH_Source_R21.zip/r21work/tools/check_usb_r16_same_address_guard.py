#!/usr/bin/env python3
from pathlib import Path
p=Path(__file__).resolve().parents[1]/"android-usb-probe/app/src/main/java/com/okn/dsp/usbprobe/MainActivity.java"
s=p.read_text(encoding="utf-8")
required=[
    'arm[0]=(byte)0xAA;',
    'controlTransfer(0x21,0x09,0x0300,x4.getId(),arm,arm.length,1500)',
    'controlTransfer(0xA1,0x01,0x0300,x4.getId(),trigger,trigger.length,1500)',
    'controlTransfer(0x80,0x06,0x0100,0,dd,dd.length,700)',
    'controlTransfer(0x81,0x06,0x2200,0,rd0,rd0.length,700)',
    'controlTransfer(0x81,0x06,0x2200,4,rd4,rd4.length,700)',
    'flashbootAttemptedThisProcess',
    'PUBLIC_SDK_FLASHBOOT_DEVICE_DESC',
    'PUBLIC_SDK_FLASHBOOT_REPORT',
    'CLASSIFICATION: NORMAL-APP-LIKE',
]
for x in required:
    assert x in s, f"missing R16 guard/flow: {x}"
for forbidden in [
    '.bulkTransfer(', '.claimInterface(', '.releaseInterface(',
    'chipErase', 'sectorErase', 'flashWrite', 'programFlash', 'commitFlash',
    'FirmwarePayload', 'sendFirmware', 'eraseAllFlash'
]:
    assert forbidden not in s, f"forbidden write/program path present: {forbidden}"
assert s.count('controlTransfer(0x21,0x09,0x0300,x4.getId(),arm,arm.length,1500)') == 1
assert s.count('arm[0]=(byte)0xAA;') == 1
# Unknown-candidate inspector must not use class GET_REPORT.
segment=s[s.index('private void probeCandidateReadOnly'):s.index('private void scanAndroidInputDevices')]
assert 'controlTransfer(0xA1,0x01' not in segment
print('R16 same-address USB safety guard: PASS')
