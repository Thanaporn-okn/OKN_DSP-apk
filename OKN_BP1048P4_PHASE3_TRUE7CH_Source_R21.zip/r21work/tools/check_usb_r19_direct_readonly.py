#!/usr/bin/env python3
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'android-usb-probe/app/src/main/java/com/okn/dsp/usbprobe/MainActivity.java'
s=p.read_text(encoding='utf-8')
required=[
 'TARGET_NORMAL_VID = 0x6324', 'TARGET_NORMAL_PID = 0x1719',
 'PUBLIC_FLASHBOOT_VID = 0x0000', 'PUBLIC_FLASHBOOT_PID = 0x2244',
 '12 01 10 01 00 00 00 40 00 00 44 22 00 01 00 00 00 01',
 '06 00 FF 0A 55 AA A1 01',
 'controlTransfer(0x80, 0x06, 0x0100, 0, dd, dd.length, 1500)',
 'controlTransfer(0x80,0x06,0x0200,0,cfg,cfg.length,1500)',
 'controlTransfer(0x81,0x06,0x2200,x.getId(),rd,rd.length,1500)',
 'WATCH ENUMERATION 30s',
 'NO AA, NO Feature SET_REPORT, NO endpoint OUT'
]
for x in required:
    assert x in s, f'missing R19 read-only flow: {x}'
for forbidden in [
 '.bulkTransfer(', '.claimInterface(', '.releaseInterface(', '.requestWait(', '.queue(',
 'controlTransfer(0x21', 'controlTransfer(0x01', 'controlTransfer(0x00,',
 'Request[0] = 0xAA', 'SET_REPORT FEATURE AA', 'A5 5A 00 00 16',
 'chipErase(', 'sectorErase(', 'flashWrite(', 'programFlash(', 'commitFlash(',
 'writeMemory(', 'readMemory(', 'sdpWrite(', 'jtagWrite('
]:
    assert forbidden not in s, f'forbidden R19 operation present: {forbidden}'
# Every actual controlTransfer call in Java must be an IN GET_DESCRIPTOR request.
for line in s.splitlines():
    if 'controlTransfer(' in line and not line.lstrip().startswith('//'):
        assert '0x80,0x06' in line or '0x80, 0x06' in line or '0x81,0x06' in line, line
print('R19 direct USB-C descriptor-only guard: PASS')
