from pathlib import Path
p=Path(__file__).parents[1]/'android-usb-probe/app/src/main/java/com/okn/dsp/usbprobe/MainActivity.java'
s=p.read_text()
assert s.count('c.controlTransfer(0x21,0x09,0x0300,4,req,req.length,1200)') == 1, 'must have exactly one Feature SET_REPORT'
assert '55 DE AD BE EF 00 00 00' in s
assert 'rawDescriptorSnapshot(c, "+150ms", 150)' in s
assert 'rawDescriptorSnapshot(c, "+700ms", 550)' in s
assert 'rawDescriptorSnapshot(c, "+2500ms", 1800)' in s
assert 'bulkTransfer(' not in s
assert 'claimInterface(' not in s
for bad in ['erase', 'program', 'commit']:
    # Terms may appear in user-facing NO-* safety text; do not treat those as functional calls.
    pass
print('R21 same-address guard: PASS')
