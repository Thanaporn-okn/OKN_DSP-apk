#!/usr/bin/env python3
import json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
d=json.loads((root/'config/FLASHBOOT_RESEARCH_STATE_R16.json').read_text(encoding='utf-8'))
assert d['verified_normal_board']['verified_on_samsung_s25_plus'] is True
assert d['verified_normal_board']['power_cycle_recovery_verified'] is True
assert d['r15_real_board_observation']['android_reenumeration_observed'] is False
assert d['r16_scope']['manual_feature_aa_boot_entry'] is True
assert d['r16_scope']['max_aa_attempts_per_app_process'] == 1
assert d['r16_scope']['same_address_discriminator'] is True
assert d['r16_scope']['unknown_candidate_class_get_report'] is False
for k in ['automatic_boot_entry','firmware_payload','endpoint_out','erase','program','commit']:
    assert d['r16_scope'][k] is False, k
assert d['public_sdk_cross_family_reference']['production_identity_asserted'] is False
for k in ['bootloader_vid_pid_observed','bootloader_interfaces_observed','bootloader_read_only_identity_observed','exact_flashboot_wire_protocol','exact_image_format','exact_flash_layout','stock_backup_available','recovery_verified','enable_flash_write','enable_erase','enable_commit']:
    assert d['production_gate'][k] is False, k
print('R16 fail-closed flash policy: PASS')
