from pathlib import Path
root=Path(__file__).resolve().parents[1]
code=[root/'firmware/src/okn_gain7.c',root/'firmware/src/okn_ufe_gain7.c',root/'firmware/include/okn_gain7.h',root/'firmware/include/okn_ufe_gain7.h']
for p in code:
    s=p.read_text(encoding='utf-8').lower()
    for forbidden in ('biquad','audioeffecteq','eq_params','speaker_eq'):
        if forbidden in s:
            raise SystemExit(f'FAIL: forbidden EQ channel-gain coupling token {forbidden!r} in {p}')
# EQ actuator IDs are deliberately absent from the gain namespace.
h=(root/'firmware/include/okn_ufe_gain7.h').read_text(encoding='utf-8')
for n in range(22,29):
    if f'{n}u' not in h: raise SystemExit(f'FAIL: missing true gain ID {n}')
print('No-EQ-gain guard: PASS')
