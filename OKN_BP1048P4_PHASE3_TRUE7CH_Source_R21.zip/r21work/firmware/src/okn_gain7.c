#include "okn_gain7.h"

/* Q2.14 linear amplitude table, generated from 10^(dB/20).
   Index 0=-70 dB, 140=0 dB, 152=+6 dB. No EQ coefficient is touched. */
static const uint16_t k_gain_q14[OKN_GAIN7_TABLE_COUNT] = {
    5, 5, 6, 6, 7, 7, 7, 8, 8, 9, 9, 10,
    10, 11, 12, 12, 13, 14, 15, 15, 16, 17, 18, 19,
    21, 22, 23, 25, 26, 28, 29, 31, 33, 35, 37, 39,
    41, 44, 46, 49, 52, 55, 58, 62, 65, 69, 73, 78,
    82, 87, 92, 98, 103, 110, 116, 123, 130, 138, 146, 155,
    164, 174, 184, 195, 206, 218, 231, 245, 260, 275, 291, 309,
    327, 346, 367, 389, 412, 436, 462, 489, 518, 549, 581, 616,
    652, 691, 732, 775, 821, 870, 921, 976, 1034, 1095, 1160, 1229,
    1301, 1379, 1460, 1547, 1638, 1735, 1838, 1947, 2063, 2185, 2314, 2451,
    2597, 2751, 2914, 3086, 3269, 3463, 3668, 3885, 4115, 4359, 4618, 4891,
    5181, 5488, 5813, 6158, 6523, 6909, 7318, 7752, 8211, 8698, 9213, 9759,
    10338, 10950, 11599, 12286, 13014, 13785, 14602, 15467, 16384, 17355, 18383, 19472,
    20626, 21848, 23143, 24514, 25967, 27506, 29135, 30862, 32690,
};

static int16_t sat16(int32_t v)
{
    if (v > 32767) return 32767;
    if (v < -32768) return -32768;
    return (int16_t)v;
}

static uint8_t quantize_index(float db)
{
    float clamped = db;
    int idx;
    if (!(clamped == clamped)) return OKN_GAIN7_ZERO_DB_INDEX; /* NaN */
    if (clamped < OKN_GAIN7_MIN_DB) clamped = OKN_GAIN7_MIN_DB;
    if (clamped > OKN_GAIN7_MAX_DB) clamped = OKN_GAIN7_MAX_DB;
    idx = (int)(((clamped - OKN_GAIN7_MIN_DB) * 2.0f) + 0.5f);
    if (idx < 0) idx = 0;
    if (idx >= (int)OKN_GAIN7_TABLE_COUNT) idx = (int)OKN_GAIN7_TABLE_COUNT - 1;
    return (uint8_t)idx;
}

void okn_gain7_init(okn_gain7_state_t *s)
{
    uint8_t i;
    if (!s) return;
    for (i=0; i<OKN_GAIN7_CHANNELS; ++i) s->index[i] = OKN_GAIN7_ZERO_DB_INDEX;
}

bool okn_gain7_set_db(okn_gain7_state_t *s, uint8_t ch0, float db)
{
    if (!s || ch0 >= OKN_GAIN7_CHANNELS || !(db == db)) return false;
    s->index[ch0] = quantize_index(db);
    return true;
}

bool okn_gain7_step(okn_gain7_state_t *s, uint8_t ch0, int direction)
{
    int idx;
    if (!s || ch0 >= OKN_GAIN7_CHANNELS || direction == 0) return false;
    idx = (int)s->index[ch0] + (direction > 0 ? 1 : -1);
    if (idx < 0) idx = 0;
    if (idx >= (int)OKN_GAIN7_TABLE_COUNT) idx = (int)OKN_GAIN7_TABLE_COUNT - 1;
    s->index[ch0] = (uint8_t)idx;
    return true;
}

float okn_gain7_get_db(const okn_gain7_state_t *s, uint8_t ch0)
{
    if (!s || ch0 >= OKN_GAIN7_CHANNELS) return 0.0f;
    return OKN_GAIN7_MIN_DB + ((float)s->index[ch0] * 0.5f);
}

uint16_t okn_gain7_get_q14(const okn_gain7_state_t *s, uint8_t ch0)
{
    if (!s || ch0 >= OKN_GAIN7_CHANNELS) return 16384u;
    return k_gain_q14[s->index[ch0]];
}

void okn_gain7_process_mono(const okn_gain7_state_t *s, uint8_t ch0, int16_t *pcm, size_t samples)
{
    size_t i; uint16_t g;
    if (!s || !pcm || ch0 >= OKN_GAIN7_CHANNELS) return;
    g = okn_gain7_get_q14(s, ch0);
    if (g == 16384u) return;
    for (i=0; i<samples; ++i) {
        int32_t y = ((int32_t)pcm[i] * (int32_t)g + 8192) >> 14;
        pcm[i] = sat16(y);
    }
}

void okn_gain7_process_interleaved(const okn_gain7_state_t *s, uint8_t ch0, int16_t *pcm, size_t frames, uint8_t lane, uint8_t lanes)
{
    size_t i; uint16_t g;
    if (!s || !pcm || ch0 >= OKN_GAIN7_CHANNELS || lanes == 0u || lane >= lanes) return;
    g = okn_gain7_get_q14(s, ch0);
    if (g == 16384u) return;
    for (i=0; i<frames; ++i) {
        size_t pos = i * lanes + lane;
        int32_t y = ((int32_t)pcm[pos] * (int32_t)g + 8192) >> 14;
        pcm[pos] = sat16(y);
    }
}

void okn_gain7_process_topology(const okn_gain7_state_t *s, const okn_gain7_topology_t *io)
{
    if (!s || !io) return;
    if (io->main_lr) {
        okn_gain7_process_interleaved(s,0,io->main_lr,io->frames,0,2);
        okn_gain7_process_interleaved(s,1,io->main_lr,io->frames,1,2);
    }
    if (io->bass_mono) okn_gain7_process_mono(s,2,io->bass_mono,io->frames);
    if (io->i2s0_lr) {
        okn_gain7_process_interleaved(s,3,io->i2s0_lr,io->frames,0,2);
        okn_gain7_process_interleaved(s,4,io->i2s0_lr,io->frames,1,2);
    }
    if (io->i2s1_lr) {
        okn_gain7_process_interleaved(s,5,io->i2s1_lr,io->frames,0,2);
        okn_gain7_process_interleaved(s,6,io->i2s1_lr,io->frames,1,2);
    }
}
