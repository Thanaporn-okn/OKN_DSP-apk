#include "okn_ufe_gain7.h"
#include <string.h>

static uint16_t r16be(const uint8_t *p){return (uint16_t)(((uint16_t)p[0]<<8)|p[1]);}
static uint32_t r32be(const uint8_t *p){return ((uint32_t)p[0]<<24)|((uint32_t)p[1]<<16)|((uint32_t)p[2]<<8)|p[3];}
static void w16be(uint8_t *p,uint16_t v){p[0]=(uint8_t)(v>>8);p[1]=(uint8_t)v;}
static void w32be(uint8_t *p,uint32_t v){p[0]=(uint8_t)(v>>24);p[1]=(uint8_t)(v>>16);p[2]=(uint8_t)(v>>8);p[3]=(uint8_t)v;}
static float rf32le(const uint8_t *p){uint32_t u=(uint32_t)p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);float f;memcpy(&f,&u,4);return f;}
static void wf32le(uint8_t *p,float f){uint32_t u;memcpy(&u,&f,4);p[0]=(uint8_t)u;p[1]=(uint8_t)(u>>8);p[2]=(uint8_t)(u>>16);p[3]=(uint8_t)(u>>24);}

int okn_ufe_gain7_ch_from_id(uint32_t id)
{
    if(id<OKN_UFE_ID_CH1_VOLUME||id>OKN_UFE_ID_CH7_VOLUME)return -1;
    return (int)(id-OKN_UFE_ID_CH1_VOLUME);
}

bool okn_ufe_gain7_write(okn_gain7_state_t *s,const uint8_t *p,size_t n)
{
    uint32_t id; uint16_t off,len; int ch;
    if(!s||!p||n!=13u||p[0]!=OKN_UFE_WRITE)return false;
    id=r32be(p+1);off=r16be(p+5);len=r16be(p+7);ch=okn_ufe_gain7_ch_from_id(id);
    if(ch<0||off!=0u||len!=4u)return false;
    return okn_gain7_set_db(s,(uint8_t)ch,rf32le(p+9));
}

size_t okn_ufe_gain7_read(const okn_gain7_state_t *s,const uint8_t *req,size_t n,uint8_t *out,size_t cap)
{
    uint32_t id; uint16_t off,len; int ch;
    if(!s||!req||!out||n!=9u||cap<13u||req[0]!=OKN_UFE_READ)return 0;
    id=r32be(req+1);off=r16be(req+5);len=r16be(req+7);ch=okn_ufe_gain7_ch_from_id(id);
    if(ch<0||off!=0u||len!=4u)return 0;
    out[0]=OKN_UFE_READ_RESPONSE;w32be(out+1,id);w16be(out+5,0);w16be(out+7,4);wf32le(out+9,okn_gain7_get_db(s,(uint8_t)ch));
    return 13u;
}
