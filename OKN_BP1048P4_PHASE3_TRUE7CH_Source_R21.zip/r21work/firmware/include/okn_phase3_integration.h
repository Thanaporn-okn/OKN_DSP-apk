#ifndef OKN_PHASE3_INTEGRATION_H
#define OKN_PHASE3_INTEGRATION_H
#include "okn_gain7.h"

/* Call from the real board audio callback only after exact buffers are identified.
   Do not place this before EQ/crossover. */
static inline void okn_phase3_post_dsp_pre_sink(okn_gain7_state_t *gain,
                                                int16_t *main_lr,
                                                int16_t *bass_mono,
                                                int16_t *i2s0_lr,
                                                int16_t *i2s1_lr,
                                                size_t frames)
{
    okn_gain7_topology_t io = { main_lr, bass_mono, i2s0_lr, i2s1_lr, frames };
    okn_gain7_process_topology(gain, &io);
}
#endif
