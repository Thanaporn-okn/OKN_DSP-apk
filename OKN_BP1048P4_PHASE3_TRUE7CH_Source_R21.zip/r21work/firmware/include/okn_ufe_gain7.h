#ifndef OKN_UFE_GAIN7_H
#define OKN_UFE_GAIN7_H
#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
#include "okn_gain7.h"

#define OKN_UFE_WRITE 0x57u
#define OKN_UFE_READ 0x58u
#define OKN_UFE_READ_RESPONSE 0x60u
#define OKN_UFE_ID_CH1_VOLUME 22u
#define OKN_UFE_ID_CH2_VOLUME 23u
#define OKN_UFE_ID_CH3_VOLUME 24u
#define OKN_UFE_ID_CH4_VOLUME 25u
#define OKN_UFE_ID_CH5_VOLUME 26u
#define OKN_UFE_ID_CH6_VOLUME 27u
#define OKN_UFE_ID_CH7_VOLUME 28u

int okn_ufe_gain7_ch_from_id(uint32_t id);
bool okn_ufe_gain7_write(okn_gain7_state_t *s, const uint8_t *p, size_t n);
size_t okn_ufe_gain7_read(const okn_gain7_state_t *s, const uint8_t *req, size_t n, uint8_t *out, size_t cap);
#endif
