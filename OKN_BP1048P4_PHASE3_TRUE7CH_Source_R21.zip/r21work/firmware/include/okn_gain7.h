#ifndef OKN_GAIN7_H
#define OKN_GAIN7_H

#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

#define OKN_GAIN7_CHANNELS 7u
#define OKN_GAIN7_MIN_DB (-70.0f)
#define OKN_GAIN7_MAX_DB (6.0f)
#define OKN_GAIN7_STEP_DB (0.5f)
#define OKN_GAIN7_TABLE_COUNT 153u
#define OKN_GAIN7_ZERO_DB_INDEX 140u

typedef struct {
    uint8_t index[OKN_GAIN7_CHANNELS]; /* 0=-70 dB, 140=0 dB, 152=+6 dB */
} okn_gain7_state_t;

typedef struct {
    int16_t *main_lr;   /* interleaved stereo: CH1=L, CH2=R */
    int16_t *bass_mono; /* mono: CH3 */
    int16_t *i2s0_lr;   /* interleaved stereo: CH4=L, CH5=R */
    int16_t *i2s1_lr;   /* interleaved stereo: CH6=L, CH7=R */
    size_t frames;
} okn_gain7_topology_t;

void okn_gain7_init(okn_gain7_state_t *s);
bool okn_gain7_set_db(okn_gain7_state_t *s, uint8_t ch0, float db);
bool okn_gain7_step(okn_gain7_state_t *s, uint8_t ch0, int direction);
float okn_gain7_get_db(const okn_gain7_state_t *s, uint8_t ch0);
uint16_t okn_gain7_get_q14(const okn_gain7_state_t *s, uint8_t ch0);
void okn_gain7_process_mono(const okn_gain7_state_t *s, uint8_t ch0, int16_t *pcm, size_t samples);
void okn_gain7_process_interleaved(const okn_gain7_state_t *s, uint8_t ch0, int16_t *pcm, size_t frames, uint8_t lane, uint8_t lanes);
void okn_gain7_process_topology(const okn_gain7_state_t *s, const okn_gain7_topology_t *io);

#ifdef __cplusplus
}
#endif
#endif
