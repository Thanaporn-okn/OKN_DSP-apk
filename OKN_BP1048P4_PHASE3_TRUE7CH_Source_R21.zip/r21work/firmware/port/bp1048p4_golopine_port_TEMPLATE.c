/*
 * TEMPLATE ONLY — no addresses/registers are guessed here.
 *
 * Expected logical mapping for the clean-room design:
 *   main_lr   => CH1/CH2
 *   bass_mono => CH3
 *   i2s0_lr   => CH4/CH5
 *   i2s1_lr   => CH6/CH7
 *
 * Integration point must be post-EQ/post-crossover and immediately before
 * the final DAC/I2S sink write. Obtain the actual pointers from the exact
 * BP1048P4 project/audio callback before enabling this file.
 */
#include "okn_phase3_integration.h"

#if defined(OKN_EXACT_GOLOPINE_AUDIO_PORT_VERIFIED)
#error "Replace TEMPLATE with a reviewed exact board port before enabling."
#endif
