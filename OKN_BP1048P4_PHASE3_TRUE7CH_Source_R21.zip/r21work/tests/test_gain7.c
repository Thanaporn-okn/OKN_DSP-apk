#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "okn_gain7.h"
#include "okn_ufe_gain7.h"

static void f32le(uint8_t *p,float f){uint32_t u;memcpy(&u,&f,4);p[0]=(uint8_t)u;p[1]=(uint8_t)(u>>8);p[2]=(uint8_t)(u>>16);p[3]=(uint8_t)(u>>24);}

int main(void)
{
    okn_gain7_state_t s; okn_gain7_init(&s);
    assert(okn_gain7_get_db(&s,0)==0.0f);

    int16_t a[4]={10000,-10000,30000,-30000};
    okn_gain7_process_mono(&s,0,a,4);
    assert(a[0]==10000 && a[1]==-10000);

    assert(okn_gain7_set_db(&s,0,-6.0f));
    int16_t b[2]={10000,-10000}; okn_gain7_process_mono(&s,0,b,2);
    assert(b[0]>4900 && b[0]<5120); assert(b[1]<-4900 && b[1]>-5120);

    assert(okn_gain7_set_db(&s,0,6.0f));
    int16_t c[2]={30000,-30000}; okn_gain7_process_mono(&s,0,c,2);
    assert(c[0]==32767 && c[1]==-32768);

    /* independent stereo lanes */
    okn_gain7_init(&s); okn_gain7_set_db(&s,0,-6.0f); okn_gain7_set_db(&s,1,0.0f);
    int16_t lr[4]={10000,10000,10000,10000};
    okn_gain7_process_interleaved(&s,0,lr,2,0,2); okn_gain7_process_interleaved(&s,1,lr,2,1,2);
    assert(lr[0]<5200 && lr[1]==10000 && lr[2]<5200 && lr[3]==10000);

    /* UFE CH1 write ID22 -6.0 dB */
    uint8_t wr[13]={0x57,0,0,0,22,0,0,0,4,0,0,0,0}; f32le(wr+9,-6.0f);
    assert(okn_ufe_gain7_write(&s,wr,sizeof(wr))); assert(okn_gain7_get_db(&s,0)==-6.0f);
    uint8_t rr[9]={0x58,0,0,0,22,0,0,0,4}, out[13];
    assert(okn_ufe_gain7_read(&s,rr,sizeof(rr),out,sizeof(out))==13u); assert(out[0]==0x60 && out[4]==22);

    /* stock EQ IDs must not resolve as channel volume */
    assert(okn_ufe_gain7_ch_from_id(4)<0); assert(okn_ufe_gain7_ch_from_id(5)<0); assert(okn_ufe_gain7_ch_from_id(6)<0);
    assert(okn_ufe_gain7_ch_from_id(14)<0); assert(okn_ufe_gain7_ch_from_id(17)<0);

    printf("Phase3 TRUE7CH tests: PASS\n");
    return 0;
}
