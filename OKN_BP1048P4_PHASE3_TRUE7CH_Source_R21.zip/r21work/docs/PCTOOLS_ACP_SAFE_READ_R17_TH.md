# R17 — PCTools / ACP Safe Read Probe

## เหตุผลที่เปลี่ยนจาก R16

R16 พิสูจน์บนบอร์ดจริงว่า HID Feature SET_REPORT `AA` ถูกยอมรับ เพราะ Feature GET_REPORT เปลี่ยน byte แรกจาก `00` เป็น `55` แต่ raw USB descriptor ที่ T+150 ms, 700 ms และ 2500 ms ยังคงเป็น normal application `6324:1719`, 7 interfaces และ IF4 report descriptor เดิม จึงไม่มีหลักฐานของ flashboot handoff.

R17 จึงไม่ส่ง `AA` ซ้ำ และไม่ส่งคำสั่ง upgrade/erase/program ใด ๆ

## หลักฐาน protocol ใหม่

เอกสารสาธารณะของ MVSILICON เรื่อง firmware/user application protocol ระบุ USB HID frame รูปแบบ `A5 5A CTRL LEN BODY 16` และระบุว่า `LEN=0` เป็นคำขออ่านสำหรับ control ที่รองรับ. เอกสารเดียวกันมี control `0x11` สำหรับ MV_AP82xx_BP10xx_PC_Tools เพื่ออ่าน firmware type/version, และ `0xFF` สำหรับอ่านสถานะ encryption. Public BP10X SDK ยังแสดงว่า USB HID Output report ถูกส่งเข้า parser ของ protocol นี้และ Input report ใช้คืนคำตอบ.

## สิ่งที่ R17 อนุญาต

R17 allowlist มีเพียงสาม query:

- `A5 5A 00 00 16` — firmware info
- `A5 5A 11 00 16` — PCTools burn/version info
- `A5 5A FF 00 16` — encryption state

แต่ละ frame ถูก zero-pad เป็น HID Output report 256 bytes แล้วอ่านกลับด้วย HID Input GET_REPORT. ตัว parser ยอมรับ reply เฉพาะเมื่อ `A5 5A`, CTRL ตรงกับ request, length อยู่ในขอบเขต และลงท้าย `16`; report เก่าหรือ CTRL ไม่ตรงจะถูกทิ้งเพื่อกัน cached-report false positive.

## สิ่งที่ถูกบล็อก

ไม่มี Feature `AA`, ไม่มี `0xFE`, ไม่มี `0xFD`, ไม่มี parameter payload, ไม่มี bulk/endpoint OUT, ไม่มี erase, program, commit หรือ firmware image.

แม้ R17 จะมี USB OUT control transfer แต่ semantic payload เป็น query `LEN=0` เท่านั้น จึงเรียกว่า safe read probe ไม่ใช่ zero-OUT probe แบบ R14/R16.

## เป้าหมายของการทดลอง

ถ้า `0x11` ตอบ เราจะได้หลักฐานว่าฟิร์มแวร์ production เปิด PCTools compatibility path อยู่จริงและได้ firmware type/version ที่ใช้จับคู่ flashboot/PCTools generation ต่อไป. ถ้า `0xFF` ตอบ จะช่วยบอกว่าการ backup/อ่านข้อมูลอาจติด encryption gate หรือไม่. ถ้าทั้งสามไม่ตอบ เราจะหยุดและกลับไป static-analysis ของ production/GoloPine runtime โดยไม่เพิ่ม write command.
