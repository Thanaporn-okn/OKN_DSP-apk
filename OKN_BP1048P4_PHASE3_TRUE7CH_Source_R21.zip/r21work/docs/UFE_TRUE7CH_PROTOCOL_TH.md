# UFE TRUE 7CH contract — firmware OKN ใหม่

IDs นี้เป็น namespace ของ firmware OKN ใหม่ ไม่ใช่ actuator ที่ค้นพบใน stock firmware.

| Channel | ID | Name | Type | Range | Step |
|---|---:|---|---:|---:|---:|
| CH1 | 22 | Channel1Volume | FLOAT32/2000 | -70..+6 dB | 0.5 dB |
| CH2 | 23 | Channel2Volume | FLOAT32/2000 | -70..+6 dB | 0.5 dB |
| CH3 | 24 | Channel3Volume | FLOAT32/2000 | -70..+6 dB | 0.5 dB |
| CH4 | 25 | Channel4Volume | FLOAT32/2000 | -70..+6 dB | 0.5 dB |
| CH5 | 26 | Channel5Volume | FLOAT32/2000 | -70..+6 dB | 0.5 dB |
| CH6 | 27 | Channel6Volume | FLOAT32/2000 | -70..+6 dB | 0.5 dB |
| CH7 | 28 | Channel7Volume | FLOAT32/2000 | -70..+6 dB | 0.5 dB |

Write plaintext:
`57 [ID:u32BE] 00 00 00 04 [float32LE dB]`

Read request:
`58 [ID:u32BE] 00 00 00 04`

Read response:
`60 [ID:u32BE] 00 00 00 04 [float32LE dB]`

ตัวอย่าง CH1 = -6.0 dB:
- ID22 = `00 00 00 16`
- float32LE(-6.0) = `00 00 C0 C0`
- plaintext = `57 00 00 00 16 00 00 00 04 00 00 C0 C0`

ปุ่ม `+` เพิ่ม 0.5 dB และปุ่ม `-` ลด 0.5 dB ในแอป จากนั้นส่งค่าใหม่ทั้ง float32. Firmware จะ clamp อยู่ใน -70..+6 dB และ quantize เป็น 0.5 dB.

## Fail-closed rule
แอปห้ามเปิดปุ่ม CH1..CH7 จนกว่าจะอ่าน Device Description/capability แล้วพบ:
- product `OKN-DSP-P4-7CH`
- `true_channel_gain=true`
- IDs 22..28 ชื่อและ range ตรงกันครบ

จึงไม่มีโอกาสนำ ID ใหม่ไปยิงใส่ stock GoloPine firmware โดยเดา.
