# สถาปัตยกรรมเสียง Phase3

เส้นทางที่ต้องการ:

`Source -> routing/crossover -> PEQ -> DRC(optional) -> OKN TRUE CH GAIN -> physical output sink`

TRUE CH GAIN ต้องทำกับ sample PCM โดยตรงหรือ dedicated vendor gain unit เท่านั้น ห้ามแก้ `Biquad`/EQ gain เพื่อทำหน้าที่ volume.

Logical output topology ที่ใช้ใน core:

| CH | Logical sink |
|---|---|
| CH1 | Main/DAC0 Left |
| CH2 | Main/DAC0 Right |
| CH3 | Bass mono |
| CH4 | I2S0 Left |
| CH5 | I2S0 Right |
| CH6 | I2S1 Left |
| CH7 | I2S1 Right |

`okn_gain7_process_topology()` รับ pointer ของ buffer ที่ board port ส่งเข้ามา จึงไม่มีการเดา register/address ของบอร์ดจริง. ถ้า sink ใดยังไม่ถูกยืนยัน อย่าผูก pointer ให้มันจนกว่าจะ trace audio callback ได้.

Public MVSilicon SDK มีแนวคิด `GainControlUnit`/pregain และ DAC digital volume แยกจาก EQ ซึ่งสนับสนุนแนวทาง dedicated gain stage แต่ชื่อ sink/register ของ generic SDK **ไม่ใช่หลักฐานว่า exact GoloPine board ใช้ mapping เดียวกัน**.
