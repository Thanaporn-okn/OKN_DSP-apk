# Flashboot Same-Address Discriminator — R16

## ข้อเท็จจริงจากบอร์ดจริง

R15 บน Samsung S25+ ยืนยันว่า Feature SET_REPORT `AA` สำเร็จ 8 bytes และ Feature GET_REPORT ถัดมาตอบ `55 01 00 03 04 00 08 00` แต่ Android ไม่รายงาน USB detach/attach หรือ candidate ใหม่ในช่วง 20 วินาที หลัง power-cycle บอร์ดกลับ normal mode และ Feature baseline เป็น `00 01 00 03 04 00 08 00` อีกครั้ง

## หลักฐานจาก public BP10X SDK

Source path `flash_boot.c` ฝัง `flash_data[65536]`. ใน binary reference พบ descriptor block ที่ประกอบด้วย HID report descriptor, configuration descriptor และ device descriptor. Device descriptor reference ตีความได้เป็น VID `0000`, PID `2244`; HID report ใช้ Usage Page `FF00`, Usage bytes `55 AA`, และ Feature count 1.

นี่เป็น **cross-family reference** เท่านั้น ไม่ใช่การยืนยันว่า production JMDSTECH firmware ใช้ค่าเดียวกัน

## วิธี R16

หลัง exact normal gate และ manual confirmation R16 ทำ AA + one Feature GET_REPORT เช่นเดิม จากนั้นไม่มี class command หรือ OUT เพิ่มอีก ใช้ standard USB GET_DESCRIPTOR แบบ IN-only อ่าน device descriptor และ HID report descriptor ที่ interface index 0 และ 4 ที่ T+150/700/2500 ms พร้อม monitor Android device list 20 วินาที

ผลจะถูกจัดเป็น:

- `NORMAL-APP-LIKE` — raw device descriptor ตรง baseline และ IF4 report descriptor ยังตรง normal production descriptor
- `PUBLIC-SDK-FLASHBOOT-LIKE` — raw descriptor ตรง public SDK reference อย่างน้อยหนึ่งส่วน
- `UNKNOWN/CHANGED` — หยุดและเก็บ log ก่อน power-cycle

R16 ไม่มี erase/program/commit/payload.
