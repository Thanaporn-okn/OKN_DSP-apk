# Samsung S25+ — R15 Bootloader Discovery

## ก่อนเริ่ม
- ใช้ไฟบอร์ดที่นิ่งและสาย USB-C ที่ทดสอบกับ R14 แล้ว
- R15 ต้องเห็น normal board `6324:1719` และทุก exact gate PASS ก่อนปุ่ม Enter Flashboot จะเปิด

## ขั้นตอนบนมือถือ
1. กด `2) READ-ONLY NORMAL USB SCAN + EXACT GATE`
2. ต้องเห็น `R15 NORMAL PREFLIGHT: PASS`
3. กด `5) ENTER FLASHBOOT ONCE ...`
4. อ่าน dialog แล้วกด `ENTER FLASHBOOT` เพียงครั้งเดียว
5. รอ re-enumeration watch 20 วินาที
6. ถ้าพบ `RE-ENUMERATED CANDIDATE DETECTED` ให้กด `6) INSPECT ...` แล้วคัดลอก log ทั้งหมด
7. ถ้าไม่พบ candidate ห้ามกด AA ซ้ำ ให้ power-cycle บอร์ดหนึ่งครั้ง แล้วกดปุ่ม 2 เพื่อยืนยันว่ากลับ normal mode

## ขอบเขต
R15 เปลี่ยนเฉพาะ running mode เพื่อค้นหา bootloader. ไม่มีคำสั่ง erase/program/commit และไม่มี firmware payload.
