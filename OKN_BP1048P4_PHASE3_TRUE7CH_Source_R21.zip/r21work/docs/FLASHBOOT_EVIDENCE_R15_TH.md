# Flashboot evidence state — R15

## Production board evidence verified on 2026-09-18
Normal-mode board on Samsung S25+:
`6324:1719`, JMDSTECH, DSTech DSP ComboDigitalArchitect, 7 interfaces.
IF4 report descriptor is exact FF00/55AA with 256-byte Input, 256-byte Output and 8-byte Feature. Feature baseline is exact `00 01 00 03 04 00 08 00`.

## Family SDK evidence used only for boot-mode discovery
The BP10X family SDK path accepts a Feature SET_REPORT whose first data byte is `AA` as an unconditional PC-upgrade arm. A following Feature GET_REPORT can perform the handoff to the flashboot path at address zero.

R15 uses that evidence only to discover the post-handoff USB identity. It does not assume any flash command, flash layout, image record, CRC, write address, or recovery behavior.
