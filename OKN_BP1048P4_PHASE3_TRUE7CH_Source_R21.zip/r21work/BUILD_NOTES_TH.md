R21 สร้างต่อจาก R20 โดยเพิ่ม same-address raw descriptor snapshots หลัง 0x55 ACK ที่ +150/+700/+2500ms
ไม่มี flash write/erase/program/MVA payload
ใช้ workflow OKN_BP1048P4_AUTO.yml เดิมได้
