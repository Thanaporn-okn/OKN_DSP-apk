# R21 — Direct USB-C 0x55 Same-Address Descriptor Probe

เป้าหมาย: ตรวจช่องว่างที่ R20 ยังตอบไม่ได้ว่า หลัง normal app รับ 0x55 และ GET_REPORT trigger แล้ว flashboot อาจเข้ามาแทนที่ "โดยไม่เกิด USB detach/re-enumeration" หรือไม่

R21 ทำ state-changing action เพียงชุดเดียวเหมือน R20:
- Feature SET_REPORT 8 bytes: `55 DE AD BE EF 00 00 00`
- Feature GET_REPORT 8 bytes เพื่อ trigger gate

หลังจากนั้น R21 ส่งเฉพาะ **standard GET_DESCRIPTOR (IN)** ที่ +150ms, +700ms, +2500ms เพื่ออ่าน Device/Config/HID report descriptor และเทียบกับ normal-app fingerprint กับ public BP10X flashboot fingerprint

R21 ไม่มี MVA, erase, program, flash payload, endpoint OUT, bulkTransfer หรือคำสั่ง commit ใด ๆ

## วิธีใช้
1. Power-cycle บอร์ดก่อนเริ่ม
2. กด 2) SCAN
3. กด 3) INSPECT และยืนยัน `EXACT-KNOWN-NORMAL-APP`
4. กด 7) เพียงครั้งเดียว แล้วเลือก RUN ONCE
5. รอจน log จบ `R21 POST55 DONE`
6. กด 8) COPY WHOLE LOG แล้วส่ง log ทั้งหมด

ถ้ามี `PUBLIC FLASHBOOT ... MATCH`, descriptor เปลี่ยน, หรือ control read ล้มเหลว/USB detach ให้หยุดและส่ง log ก่อนทำอย่างอื่น
