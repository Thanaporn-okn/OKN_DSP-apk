# OKN DSP V4

Bluetooth names are NOT hard-coded.

The app displays the actual Bluetooth name advertised by the board and uses the two roles:
- ชื่อที่บอร์ดแสดง > ใช้สำหรับ Media / เล่นเพลง
- ชื่อที่บอร์ดแสดง > ใช้สำหรับ ควบคุม DSP

The app uses Android BLE directly. It does not use flutter_blue_plus.

The DSP command protocol is intentionally not guessed. After connection, the app discovers GATT Service/Write/Notify characteristics and can send a small test frame. The actual BP1048P4 DSP protocol can be added after the board's protocol/UUID is known.
