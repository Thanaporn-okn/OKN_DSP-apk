package com.okn.okn_dsp

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel
import java.util.UUID

class MainActivity : FlutterActivity() {
    private val methodName = "okn_dsp/methods"
    private val eventName = "okn_dsp/events"
    private val permissionCode = 4101

    private var sink: EventChannel.EventSink? = null
    private var scanner: BluetoothLeScanner? = null
    private var scanCallback: ScanCallback? = null
    private var gatt: BluetoothGatt? = null
    private var writeChar: BluetoothGattCharacteristic? = null

    override fun configureFlutterEngine(engine: FlutterEngine) {
        super.configureFlutterEngine(engine)

        EventChannel(engine.dartExecutor.binaryMessenger, eventName)
            .setStreamHandler(object : EventChannel.StreamHandler {
                override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
                    sink = events
                }
                override fun onCancel(arguments: Any?) {
                    sink = null
                }
            })

        MethodChannel(engine.dartExecutor.binaryMessenger, methodName)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "startScan" -> {
                        withBluetoothPermission { startScan() }
                        result.success(true)
                    }
                    "stopScan" -> {
                        stopScan()
                        result.success(true)
                    }
                    "connect" -> {
                        val address = call.argument<String>("address")
                        if (address.isNullOrBlank()) {
                            result.error("ADDRESS", "Bluetooth address is empty", null)
                        } else {
                            withBluetoothPermission { connect(address) }
                            result.success(true)
                        }
                    }
                    "disconnect" -> {
                        disconnect()
                        result.success(true)
                    }
                    "writeHex" -> result.success(writeHex(call.argument<String>("hex") ?: ""))
                    else -> result.notImplemented()
                }
            }
    }

    private fun emit(map: Map<String, Any?>) {
        runOnUiThread { sink?.success(map) }
    }

    private fun withBluetoothPermission(action: () -> Unit) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            action()
            return
        }
        val missing = arrayOf(
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_CONNECT
        ).filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) {
            action()
        } else {
            pendingAction = action
            requestPermissions(missing.toTypedArray(), permissionCode)
        }
    }

    private var pendingAction: (() -> Unit)? = null

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionCode &&
            grantResults.isNotEmpty() &&
            grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
            pendingAction?.invoke()
        } else {
            emit(mapOf("type" to "status", "message" to "ต้องอนุญาต Bluetooth ก่อน"))
        }
        pendingAction = null
    }

    private fun adapter(): BluetoothAdapter? {
        val manager = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
        return manager.adapter
    }

    private fun startScan() {
        stopScan()
        val a = adapter()
        if (a == null) {
            emit(mapOf("type" to "status", "message" to "เครื่องไม่รองรับ Bluetooth"))
            return
        }
        if (!a.isEnabled) {
            emit(mapOf("type" to "status", "message" to "กรุณาเปิด Bluetooth"))
            return
        }
        scanner = a.bluetoothLeScanner
        if (scanner == null) {
            emit(mapOf("type" to "status", "message" to "BLE Scanner ใช้งานไม่ได้"))
            return
        }

        scanCallback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val d = result.device
                val name = try {
                    result.scanRecord?.deviceName ?: d.name ?: ""
                } catch (_: SecurityException) { "" }

                emit(mapOf(
                    "type" to "scan",
                    "name" to name,
                    "address" to d.address,
                    "rssi" to result.rssi
                ))
            }

            override fun onScanFailed(errorCode: Int) {
                emit(mapOf(
                    "type" to "status",
                    "message" to "BLE scan failed: $errorCode"
                ))
            }
        }

        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build()
        scanner?.startScan(null, settings, scanCallback)
        emit(mapOf(
            "type" to "status",
            "message" to "กำลังค้นหาและแสดงชื่อที่บอร์ดประกาศ..."
        ))
    }

    private fun stopScan() {
        try {
            if (scanner != null && scanCallback != null) {
                scanner?.stopScan(scanCallback)
            }
        } catch (_: Exception) {}
        scanner = null
        scanCallback = null
    }

    private fun connect(address: String) {
        stopScan()
        disconnect()
        val d = try {
            adapter()?.getRemoteDevice(address)
        } catch (_: Exception) {
            null
        }
        if (d == null) {
            emit(mapOf("type" to "status", "message" to "ไม่พบอุปกรณ์"))
            return
        }
        emit(mapOf("type" to "status", "message" to "กำลังเชื่อมต่อ..."))
        gatt = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            d.connectGatt(this, false, callback, BluetoothDevice.TRANSPORT_LE)
        } else {
            d.connectGatt(this, false, callback)
        }
    }

    private val callback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                gatt = g
                emit(mapOf("type" to "connected", "address" to g.device.address))
                g.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                emit(mapOf("type" to "disconnected"))
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            var service: BluetoothGattService? = null
            var write: BluetoothGattCharacteristic? = null
            var notify: BluetoothGattCharacteristic? = null

            for (s in g.services) {
                for (c in s.characteristics) {
                    val p = c.properties
                    if (write == null &&
                        (p and BluetoothGattCharacteristic.PROPERTY_WRITE != 0 ||
                         p and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0)) {
                        service = s
                        write = c
                    }
                    if (notify == null &&
                        (p and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0 ||
                         p and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0)) {
                        if (service == null) service = s
                        notify = c
                    }
                }
            }
            writeChar = write

            if (notify != null) {
                try {
                    g.setCharacteristicNotification(notify, true)
                    val desc = notify.getDescriptor(
                        UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
                    )
                    if (desc != null) {
                        desc.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                        g.writeDescriptor(desc)
                    }
                } catch (_: Exception) {}
            }

            emit(mapOf(
                "type" to "characteristics",
                "service" to (service?.uuid?.toString() ?: ""),
                "write" to (write?.uuid?.toString() ?: ""),
                "notify" to (notify?.uuid?.toString() ?: "")
            ))
        }

        override fun onCharacteristicChanged(
            g: BluetoothGatt, c: BluetoothGattCharacteristic
        ) {
            val bytes = c.value ?: byteArrayOf()
            emit(mapOf(
                "type" to "rx",
                "uuid" to c.uuid.toString(),
                "hex" to bytes.joinToString(" ") { "%02X".format(it) }
            ))
        }
    }

    private fun writeHex(hex: String): Boolean {
        val g = gatt ?: return false
        val c = writeChar ?: return false
        val clean = hex.replace("0x", "", true).replace(Regex("[^0-9A-Fa-f]"), "")
        if (clean.isEmpty() || clean.length % 2 != 0) return false

        val data = ByteArray(clean.length / 2)
        for (i in data.indices) {
            data[i] = clean.substring(i * 2, i * 2 + 2).toInt(16).toByte()
        }

        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                g.writeCharacteristic(
                    c, data, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                ) == android.bluetooth.BluetoothStatusCodes.SUCCESS
            } else {
                c.writeType = if (
                    c.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0
                ) BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                else BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                c.value = data
                g.writeCharacteristic(c)
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun disconnect() {
        try { gatt?.disconnect() } catch (_: Exception) {}
        try { gatt?.close() } catch (_: Exception) {}
        gatt = null
        writeChar = null
    }

    override fun onDestroy() {
        stopScan()
        disconnect()
        super.onDestroy()
    }
}
