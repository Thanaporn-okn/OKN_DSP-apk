import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() => runApp(const OknDspApp());

class OknDspApp extends StatelessWidget {
  const OknDspApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'OKN DSP',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class DeviceInfo {
  final String name;
  final String address;
  final int rssi;
  const DeviceInfo(this.name, this.address, this.rssi);

  factory DeviceInfo.fromMap(Map<dynamic, dynamic> m) {
    return DeviceInfo(
      (m['name'] ?? '').toString(),
      (m['address'] ?? '').toString(),
      int.tryParse((m['rssi'] ?? -127).toString()) ?? -127,
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  static const method = MethodChannel('okn_dsp/methods');
  static const events = EventChannel('okn_dsp/events');

  StreamSubscription? sub;
  final List<DeviceInfo> devices = [];
  String status = 'พร้อมใช้งาน';
  String? connected;
  String service = '';
  String write = '';
  String notify = '';
  String rx = '';
  bool scanning = false;

  @override
  void initState() {
    super.initState();
    sub = events.receiveBroadcastStream().listen((e) {
      if (e is! Map) return;
      final type = e['type']?.toString();
      setState(() {
        switch (type) {
          case 'scan':
            final d = DeviceInfo.fromMap(e);
            if (d.address.isEmpty) return;
            final i = devices.indexWhere((x) => x.address == d.address);
            if (i >= 0) {
              devices[i] = d;
            } else {
              devices.add(d);
            }
            devices.sort((a, b) => b.rssi.compareTo(a.rssi));
            break;
          case 'status':
            status = e['message']?.toString() ?? '';
            break;
          case 'connected':
            connected = e['address']?.toString();
            status = 'เชื่อมต่อแล้ว';
            break;
          case 'disconnected':
            connected = null;
            service = write = notify = '';
            status = 'ตัดการเชื่อมต่อแล้ว';
            break;
          case 'characteristics':
            service = e['service']?.toString() ?? '';
            write = e['write']?.toString() ?? '';
            notify = e['notify']?.toString() ?? '';
            status = 'พบช่องสื่อสารของบอร์ดแล้ว';
            break;
          case 'rx':
            rx = e['hex']?.toString() ?? '';
            break;
        }
      });
    }, onError: (e) {
      setState(() => status = 'Bluetooth error: $e');
    });
  }

  @override
  void dispose() {
    sub?.cancel();
    super.dispose();
  }

  Future<void> scan() async {
    setState(() {
      devices.clear();
      scanning = true;
      status = 'กำลังค้นหาอุปกรณ์ Bluetooth ที่บอร์ดแสดง...';
    });
    try {
      await method.invokeMethod('startScan');
    } catch (e) {
      setState(() => status = 'เริ่มค้นหาไม่ได้: $e');
    }
  }

  Future<void> stop() async {
    await method.invokeMethod('stopScan');
    setState(() {
      scanning = false;
      status = 'หยุดค้นหาแล้ว';
    });
  }

  Future<void> connect(DeviceInfo d) async {
    setState(() => status = 'กำลังเชื่อมต่อ ${d.name.isEmpty ? d.address : d.name}...');
    try {
      await method.invokeMethod('connect', {'address': d.address});
    } catch (e) {
      setState(() => status = 'เชื่อมต่อไม่ได้: $e');
    }
  }

  Future<void> disconnect() async {
    await method.invokeMethod('disconnect');
  }

  Future<void> sendTest() async {
    final ok = await method.invokeMethod<bool>('writeHex', {'hex': '01 00'});
    setState(() => status = ok == true ? 'ส่งข้อมูลทดสอบแล้ว' : 'ยังส่งไม่ได้ (ยังไม่พบ Write Characteristic)');
  }

  String purpose(String name) {
    final n = name.toLowerCase();
    // The app does NOT force a Bluetooth name.
    // These labels describe the two roles shown by the board.
    if (n.contains('media') || n.contains('audio') || n.contains('music')) {
      return 'ใช้สำหรับ Media / เล่นเพลง';
    }
    return 'ใช้สำหรับ ควบคุม DSP (เลือกอุปกรณ์ที่เป็นช่องควบคุมของบอร์ด)';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('OKN DSP Controller'),
        actions: [
          IconButton(
            onPressed: scanning ? stop : scan,
            icon: Icon(scanning ? Icons.stop : Icons.bluetooth_searching),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Bluetooth ของบอร์ด',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  const Text('ชื่อที่บอร์ดแสดง > ใช้สำหรับ Media / เล่นเพลง'),
                  const Text('ชื่อที่บอร์ดแสดง > ใช้สำหรับ ควบคุม DSP'),
                  const SizedBox(height: 12),
                  Text(status),
                ],
              ),
            ),
          ),
          if (connected != null) ...[
            const SizedBox(height: 12),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('การเชื่อมต่อ DSP',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    Text('Address: $connected'),
                    Text('Service: ${service.isEmpty ? "-" : service}'),
                    Text('Write: ${write.isEmpty ? "-" : write}'),
                    Text('Notify: ${notify.isEmpty ? "-" : notify}'),
                    Text('RX: ${rx.isEmpty ? "-" : rx}'),
                    const SizedBox(height: 12),
                    Row(children: [
                      Expanded(
                        child: FilledButton(
                          onPressed: sendTest,
                          child: const Text('ทดสอบส่ง'),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: OutlinedButton(
                          onPressed: disconnect,
                          child: const Text('ตัดการเชื่อมต่อ'),
                        ),
                      ),
                    ]),
                  ],
                ),
              ),
            ),
          ],
          const SizedBox(height: 12),
          Text('ชื่อที่บอร์ดแสดง',
              style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          if (devices.isEmpty)
            const Card(
              child: Padding(
                padding: EdgeInsets.all(18),
                child: Text('กดปุ่ม Bluetooth ด้านบนเพื่อค้นหา'),
              ),
            ),
          ...devices.map((d) => Card(
                child: ListTile(
                  leading: const Icon(Icons.bluetooth),
                  title: Text(d.name.isEmpty ? '(บอร์ดไม่ส่งชื่อ)' : d.name),
                  subtitle: Text(
                    '${d.address}\nRSSI ${d.rssi} dBm\n${purpose(d.name)}',
                  ),
                  isThreeLine: true,
                  trailing: FilledButton(
                    onPressed: () => connect(d),
                    child: const Text('เชื่อมต่อ'),
                  ),
                ),
              )),
        ],
      ),
    );
  }
}
