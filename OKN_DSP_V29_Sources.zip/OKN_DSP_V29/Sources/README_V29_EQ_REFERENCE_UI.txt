OKN_DSP V29 — PARAMETRIC EQ REFERENCE UI
========================================

AUTHORITATIVE BASE
- Built directly from runtime-confirmed OKN_DSP V28.
- V28 itself is based directly on the user-selected V17 authoritative baseline.
- BLE/auth/AES/UFE writer, V17 Band1 filter-aware handling, and V28 EQ fast lane are unchanged.

USER UI REQUIREMENT
- Replace the EQ page with the supplied reference image UI_REFERENCE_EQ_V29.png.
- Adapt the structure to the real device rather than inventing unsupported DSP controls.

V29 EQ STRUCTURE
- Header: Parametric EQ + connected device state.
- CH1..CH7 tabs always visible at the top.
- Large 20 Hz–20 kHz / ±12 dB response graph.
- Real 15-band device topology is retained.
- Six band rows are visible per bank for readability: Bands 1–6, 7–12, 13–15.
- Bank navigation does not change the DSP mapping; it only changes which real records are visible.
- Each row shows real Band number, real DSP frequency, current gain, current Q, and a truthful filter label:
  Band1 = Native (V17 special filter-aware path), Bands2–15 = Peak when writable, otherwise RO.
- Gain remains the only realtime editable band parameter in the V28 hardware writer.
- Frequency/Q/Type are displayed from the live descriptor and remain read-only in V29.
- Band power/bypass icon is rendered to match the reference but remains hardware-locked because its packet is unverified.
- Preset area visually follows the supplied reference. Flat uses the existing V28 reset behavior; other named preset buttons remain locked until exact curves are supplied/verified.

REALTIME BEHAVIOR PRESERVED
- First EQ target dispatched immediately when AB01 is safe/free.
- Continuous gain movement coalesced latest-target-wins at ~120 ms minimum pacing.
- One live write in flight.
- No packet backlog.
- No frequency remap, no filter-type conversion, no automatic SaveParams.

SAFETY
- UI-only restructuring must not change DSP coefficient formulas or packet byte layout.
- Unsupported controls report that hardware write is locked instead of pretending to work.
