# OKN DSP V29 — Phase 1

Base: **V28**, which is the accepted V25 codebase rebased after V26/V27 were rejected.

## V29 changes

- Adds **Reset Global** to the Mix > Global card.
- Reset Global restores Master Volume **-6 dB**, Bass Volume **+2 dB**, and Bass Cutoff **80 Hz**.
- Adds **Reset Channels** to the Mix > Channels card.
- Reset Channels restores Ch1–Ch7 to **-3, -6, -2, -8, 0, -4, -10 dB**.
- Reset values update the UI immediately and are persisted automatically.
- Existing V28/V25 touch isolation, smooth overlays, preset manager, theme handling, safe-area behavior, EQ behavior, and red/pink accents remain unchanged.

versionName: 29.0.0
versionCode: 1029
Phase: 1
