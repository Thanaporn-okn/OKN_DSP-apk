# OKN_DSP V29 — Phase 1 UI

This package rebuilds the OKN_DSP interface with Flutter widgets and CustomPainter. The uploaded reference image is **not** bundled and is **not** used as a background.

Implemented UI:
- Edge-to-edge responsive layout for phones and tablets.
- Home, Mix, Eq and Crossover pages with persistent bottom navigation.
- Mix sliders update their displayed values immediately while dragging.
- EQ: 15 bands × 7 channels, draggable gain graph, per-band Q/Frequency/Gain controls, output gain, and in-session preset Save/Load.
- Crossover: type selection, per-channel mode/frequency and per-channel delay controls.
- Settings button and Home connection card are interactive in this Phase 1 prototype.

Phase boundary:
- Phase 1 contains UI state only.
- BLE/DSP protocol commands are intentionally not sent yet. Phase 2 will connect these UI values to the real DSP data/protocol supplied later.

Build:
1. Place `OKN_DSP_V29_Sources.zip` at the repository root.
2. Place `build-okn-dsp.yml` at `.github/workflows/build-okn-dsp.yml` once.
3. Every push of a new `OKN_DSP_V*_Sources.zip` automatically runs GitHub Actions and produces a release APK artifact.

Integrity:
- `Sources/SHA256SUMS.txt` is verified by the workflow before Android generation/build.
