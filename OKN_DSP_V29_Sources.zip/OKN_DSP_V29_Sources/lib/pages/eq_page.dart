import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../widgets/common.dart';

class EqPage extends StatefulWidget {
  final VoidCallback onBack;

  const EqPage({super.key, required this.onBack});

  @override
  State<EqPage> createState() => _EqPageState();
}

class _EqPageState extends State<EqPage> {
  static const int bandCount = 15;
  static const int channelCount = 7;

  int preset = 1;
  int channel = 0;
  int selectedBand = 3;

  late List<List<double>> gains;
  late List<List<double>> qs;
  late List<List<double>> freqs;
  late List<double> outputGain;

  final Map<int, _EqSnapshot> savedPresets = {};

  @override
  void initState() {
    super.initState();
    gains = List.generate(channelCount, (ch) {
      const shape = [-2.0, -1.0, 0.0, 3.5, 1.0, 3.0, .5, -1.0, -2.0, -3.0, -1.5, -.2, 2.0, 3.5, 1.0];
      return List.generate(bandCount, (i) => (shape[i] - ch * .15).clamp(-12.0, 12.0).toDouble());
    });
    qs = List.generate(channelCount, (_) => List.filled(bandCount, 1.2));
    const baseFreqs = [20.0, 31.0, 50.0, 80.0, 125.0, 200.0, 315.0, 500.0, 800.0, 1250.0, 2000.0, 3150.0, 5000.0, 10000.0, 20000.0];
    freqs = List.generate(channelCount, (_) => List<double>.from(baseFreqs));
    outputGain = [0, -1, -2, 0, 1, 0, -1];
  }

  void _savePreset() {
    savedPresets[preset] = _EqSnapshot(
      gains: gains.map((e) => List<double>.from(e)).toList(),
      qs: qs.map((e) => List<double>.from(e)).toList(),
      freqs: freqs.map((e) => List<double>.from(e)).toList(),
      outputGain: List<double>.from(outputGain),
    );
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Preset $preset saved in this Phase 1 session.')),
    );
  }

  void _loadPreset() {
    final snap = savedPresets[preset];
    if (snap == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Preset $preset has not been saved yet.')),
      );
      return;
    }
    setState(() {
      gains = snap.gains.map((e) => List<double>.from(e)).toList();
      qs = snap.qs.map((e) => List<double>.from(e)).toList();
      freqs = snap.freqs.map((e) => List<double>.from(e)).toList();
      outputGain = List<double>.from(snap.outputGain);
    });
  }

  void _updateGraph(Offset local, Size size) {
    if (size.width <= 0 || size.height <= 0) return;
    final idx = ((local.dx / size.width) * (bandCount - 1)).round().clamp(0, bandCount - 1).toInt();
    final normalizedY = (local.dy / size.height).clamp(0.0, 1.0).toDouble();
    final gain = (12 - normalizedY * 24).clamp(-12.0, 12.0).toDouble();
    setState(() {
      selectedBand = idx;
      gains[channel][idx] = gain;
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: false,
      child: ResponsiveCenter(
        maxWidth: 1060,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const StatusHeader(),
              const SizedBox(height: 18),
              PageTitle(title: 'Eq', subtitle: '15 Band 7 Channel', onBack: widget.onBack),
              const SizedBox(height: 16),
              _presetBar(),
              const SizedBox(height: 10),
              _graphPanel(),
              const SizedBox(height: 10),
              _channelPanel(),
              const SizedBox(height: 10),
              _bandPanel(),
              const SizedBox(height: 10),
              _parameterPanel(),
              const SizedBox(height: 10),
              _outputPanel(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _presetBar() {
    return LayoutBuilder(
      builder: (context, constraints) {
        final compact = constraints.maxWidth < 540;
        final dropdown = GlassPanel(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<int>(
              isExpanded: true,
              value: preset,
              dropdownColor: const Color(0xFF0B2444),
              items: [1, 2, 3, 4]
                  .map((p) => DropdownMenuItem(value: p, child: Text('Preset $p')))
                  .toList(),
              onChanged: (value) => value == null ? null : setState(() => preset = value),
            ),
          ),
        );
        final buttons = Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _loadPreset,
                icon: const Icon(Icons.file_upload_outlined),
                label: const Text('Load'),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _savePreset,
                icon: const Icon(Icons.save_outlined),
                label: const Text('Save'),
              ),
            ),
          ],
        );
        if (compact) {
          return Column(
            children: [
              SizedBox(width: double.infinity, child: dropdown),
              const SizedBox(height: 8),
              buttons,
            ],
          );
        }
        return Row(
          children: [
            Expanded(flex: 2, child: dropdown),
            const SizedBox(width: 10),
            Expanded(flex: 2, child: buttons),
          ],
        );
      },
    );
  }

  Widget _graphPanel() {
    return GlassPanel(
      padding: const EdgeInsets.fromLTRB(8, 14, 8, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Row(
              children: [
                Text('CH${channel + 1}', style: const TextStyle(fontWeight: FontWeight.w800)),
                const Spacer(),
                Text('Drag graph • Band ${selectedBand + 1}', style: const TextStyle(color: kTextSoft, fontSize: 12)),
              ],
            ),
          ),
          const SizedBox(height: 8),
          AspectRatio(
            aspectRatio: 2.3,
            child: LayoutBuilder(
              builder: (context, constraints) {
                final size = Size(constraints.maxWidth, constraints.maxHeight);
                return GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onPanDown: (d) => _updateGraph(d.localPosition, size),
                  onPanUpdate: (d) => _updateGraph(d.localPosition, size),
                  child: CustomPaint(
                    painter: _EqGraphPainter(
                      values: gains[channel],
                      selectedBand: selectedBand,
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _channelPanel() {
    return GlassPanel(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Channel', style: TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: List.generate(channelCount, (i) {
                final selected = channel == i;
                return Padding(
                  padding: const EdgeInsets.only(right: 7),
                  child: ChoiceChip(
                    label: Text('CH${i + 1}'),
                    selected: selected,
                    onSelected: (_) => setState(() => channel = i),
                    selectedColor: kBlue,
                    backgroundColor: const Color(0xFF102A4D),
                    side: BorderSide(color: selected ? kCyan : Colors.white10),
                  ),
                );
              }),
            ),
          ),
        ],
      ),
    );
  }

  Widget _bandPanel() {
    return GlassPanel(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('EQ Band', style: TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: List.generate(bandCount, (i) {
                final selected = selectedBand == i;
                return Padding(
                  padding: const EdgeInsets.only(right: 6),
                  child: ChoiceChip(
                    label: Text('${i + 1}'),
                    selected: selected,
                    onSelected: (_) => setState(() => selectedBand = i),
                    selectedColor: kPurple,
                    backgroundColor: const Color(0xFF102A4D),
                    side: BorderSide(color: selected ? kPink : Colors.white10),
                  ),
                );
              }),
            ),
          ),
        ],
      ),
    );
  }

  Widget _parameterPanel() {
    final q = qs[channel][selectedBand];
    final f = freqs[channel][selectedBand];
    final g = gains[channel][selectedBand];
    return GlassPanel(
      padding: const EdgeInsets.all(12),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final wide = constraints.maxWidth >= 760;
          final width = wide ? (constraints.maxWidth - 16) / 3 : constraints.maxWidth;
          return Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _param(width, 'Q (Quality Factor)', q.toStringAsFixed(2), q, .1, 10, kBlue, (v) => setState(() => qs[channel][selectedBand] = v)),
              _param(width, 'Frequency', formatHz(f), hzToSlider(f), 0, 1, kGreen, (v) => setState(() => freqs[channel][selectedBand] = sliderToHz(v))),
              _param(width, 'Gain', '${g >= 0 ? '+' : ''}${g.toStringAsFixed(1)} dB', g, -12, 12, kPink, (v) => setState(() => gains[channel][selectedBand] = v)),
            ],
          );
        },
      ),
    );
  }

  Widget _param(double width, String label, String valueText, double value, double min, double max, Color color, ValueChanged<double> onChanged) {
    return SizedBox(
      width: width,
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: const Color(0x66142E51),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Colors.white10),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: const TextStyle(color: kTextSoft, fontSize: 12)),
            const SizedBox(height: 6),
            Center(child: Text(valueText, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18))),
            AccentSlider(value: value, min: min, max: max, color: color, onChanged: onChanged),
          ],
        ),
      ),
    );
  }

  Widget _outputPanel() {
    return GlassPanel(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Output Channel', style: TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: List.generate(channelCount, (i) {
                final colors = [kBlue, kPurple, kPink, const Color(0xFF9F8CFF), kGreen, kCyan, const Color(0xFF84A5FF)];
                final color = colors[i];
                return Container(
                  width: 116,
                  margin: const EdgeInsets.only(right: 8),
                  padding: const EdgeInsets.all(9),
                  decoration: BoxDecoration(
                    color: i == channel ? const Color(0xAA0E4D92) : const Color(0x77112745),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: i == channel ? kBlue : Colors.white10),
                  ),
                  child: Column(
                    children: [
                      Text('CH${i + 1}', style: const TextStyle(fontWeight: FontWeight.w700)),
                      AccentSlider(
                        value: outputGain[i],
                        min: -12,
                        max: 12,
                        color: color,
                        onChanged: (v) => setState(() => outputGain[i] = v),
                      ),
                      Text('${outputGain[i] >= 0 ? '+' : ''}${outputGain[i].toStringAsFixed(1)} dB', style: const TextStyle(fontSize: 11)),
                    ],
                  ),
                );
              }),
            ),
          ),
        ],
      ),
    );
  }
}

class _EqSnapshot {
  final List<List<double>> gains;
  final List<List<double>> qs;
  final List<List<double>> freqs;
  final List<double> outputGain;

  _EqSnapshot({required this.gains, required this.qs, required this.freqs, required this.outputGain});
}

class _EqGraphPainter extends CustomPainter {
  final List<double> values;
  final int selectedBand;

  const _EqGraphPainter({required this.values, required this.selectedBand});

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    canvas.drawRRect(
      RRect.fromRectAndRadius(rect, const Radius.circular(12)),
      Paint()..color = const Color(0xAA06182E),
    );

    final grid = Paint()..color = const Color(0x253D79A8)..strokeWidth = 1;
    for (var i = 0; i <= 8; i++) {
      final y = size.height * i / 8;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
    for (var i = 0; i < values.length; i++) {
      final x = size.width * i / (values.length - 1);
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }

    final zeroY = size.height / 2;
    canvas.drawLine(
      Offset(0, zeroY),
      Offset(size.width, zeroY),
      Paint()..color = Colors.white24..strokeWidth = 1.2,
    );

    final path = Path();
    for (var i = 0; i < values.length; i++) {
      final x = size.width * i / (values.length - 1);
      final y = ((12 - values[i]) / 24) * size.height;
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }
    final linePaint = Paint()
      ..shader = const LinearGradient(colors: [kPink, kYellow, kGreen, kCyan, kPurple, kPink]).createShader(rect)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.8
      ..strokeJoin = StrokeJoin.round;
    canvas.drawPath(path, linePaint);

    for (var i = 0; i < values.length; i++) {
      final x = size.width * i / (values.length - 1);
      final y = ((12 - values[i]) / 24) * size.height;
      final t = i / math.max(1, values.length - 1);
      final color = HSVColor.fromAHSV(1, 330 * t, .85, 1).toColor();
      canvas.drawCircle(Offset(x, y), i == selectedBand ? 7 : 5, Paint()..color = color);
      if (i == selectedBand) {
        canvas.drawCircle(
          Offset(x, y),
          11,
          Paint()
            ..color = color.withOpacity(.25)
            ..style = PaintingStyle.fill,
        );
      }
    }
  }

  @override
  bool shouldRepaint(covariant _EqGraphPainter oldDelegate) => true;
}
