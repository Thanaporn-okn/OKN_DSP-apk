import 'package:flutter/material.dart';

import '../widgets/common.dart';

class MixPage extends StatefulWidget {
  final VoidCallback onBack;

  const MixPage({super.key, required this.onBack});

  @override
  State<MixPage> createState() => _MixPageState();
}

class _MixPageState extends State<MixPage> {
  double master = -6;
  double bass = 2;
  double cutoff = 80;
  double bassBoost = 4;
  double middleBoost = 2;
  double trebleBoost = 3;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: false,
      child: ResponsiveCenter(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const StatusHeader(),
              const SizedBox(height: 18),
              PageTitle(title: 'Mix', subtitle: 'Real-time Adjustment', onBack: widget.onBack),
              const SizedBox(height: 16),
              LayoutBuilder(
                builder: (context, constraints) {
                  final twoCols = constraints.maxWidth >= 760;
                  final width = twoCols ? (constraints.maxWidth - 14) / 2 : constraints.maxWidth;
                  return Wrap(
                    spacing: 14,
                    runSpacing: 11,
                    children: [
                      _control(width, 'Master Volume', Icons.volume_up_rounded, master, -60, 12, kCyan, (v) => setState(() => master = v)),
                      _control(width, 'Bass Volume', Icons.music_note_rounded, bass, -12, 12, kGreen, (v) => setState(() => bass = v)),
                      _control(width, 'Bass Cutoff', Icons.call_split_rounded, cutoff, 20, 250, kYellow, (v) => setState(() => cutoff = v), hz: true),
                      _control(width, 'Bass Boost', Icons.graphic_eq_rounded, bassBoost, -12, 12, kPink, (v) => setState(() => bassBoost = v)),
                      _control(width, 'Middle Boost', Icons.tune_rounded, middleBoost, -12, 12, kPurple, (v) => setState(() => middleBoost = v)),
                      _control(width, 'Treble Boost', Icons.audiotrack_rounded, trebleBoost, -12, 12, const Color(0xFF16E5D7), (v) => setState(() => trebleBoost = v)),
                    ],
                  );
                },
              ),
              const SizedBox(height: 18),
              const GlassPanel(
                child: Row(
                  children: [
                    Icon(Icons.bolt_rounded, color: kCyan),
                    SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'Phase 1: values update immediately in the UI. DSP/BLE commands are intentionally disabled until Phase 2 protocol data is supplied.',
                        style: TextStyle(color: kTextSoft, height: 1.35),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _control(
    double width,
    String label,
    IconData icon,
    double value,
    double min,
    double max,
    Color color,
    ValueChanged<double> onChanged, {
    bool hz = false,
  }) {
    final shown = hz ? '${value.round()} Hz' : '${value >= 0 ? '+' : ''}${value.toStringAsFixed(1)} dB';
    return SizedBox(
      width: width,
      child: GlassPanel(
        padding: const EdgeInsets.fromLTRB(14, 10, 14, 10),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: color.withOpacity(.18),
                shape: BoxShape.circle,
                border: Border.all(color: color.withOpacity(.28)),
              ),
              child: Icon(icon, color: color),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14))),
                      Text(shown, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                    ],
                  ),
                  AccentSlider(value: value, min: min, max: max, onChanged: onChanged, color: color),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
