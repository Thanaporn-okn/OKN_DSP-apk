import 'package:flutter/material.dart';

import '../widgets/common.dart';

class CrossoverPage extends StatefulWidget {
  final VoidCallback onBack;

  const CrossoverPage({super.key, required this.onBack});

  @override
  State<CrossoverPage> createState() => _CrossoverPageState();
}

class _CrossoverPageState extends State<CrossoverPage> {
  static const modes = ['Full Range', 'HPF', 'LPF', 'BP', 'OFF'];
  static const quickTypes = ['LPF', 'HPF', 'BP', 'OFF'];

  String quickType = 'LPF';
  final List<String> channelModes = ['Full Range', 'HPF', 'HPF', 'LPF', 'HPF', 'LPF', 'Full Range'];
  final List<double> frequencies = [20, 80, 100, 3500, 120, 8000, 20];
  final List<double> delays = [0, .3, .6, 1.2, 1.0, .5, 0];

  final channelColors = const [kBlue, kGreen, Color(0xFFFFC313), Color(0xFFFF315E), kPurple, Color(0xFF05E0CA), Color(0xFF8EA0FF)];

  void _applyQuick(String type) {
    setState(() {
      quickType = type;
      for (var i = 0; i < channelModes.length; i++) {
        channelModes[i] = type == 'OFF' ? 'OFF' : type;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: false,
      child: ResponsiveCenter(
        maxWidth: 1060,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const StatusHeader(),
              const SizedBox(height: 18),
              PageTitle(title: 'Crossover', subtitle: 'Real-time Adjustment', onBack: widget.onBack),
              const SizedBox(height: 16),
              _typePanel(),
              const SizedBox(height: 10),
              _crossoverPanel(),
              const SizedBox(height: 10),
              _delayPanel(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _typePanel() {
    return GlassPanel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Crossover Type', style: TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          Row(
            children: List.generate(quickTypes.length, (i) {
              final type = quickTypes[i];
              final selected = quickType == type;
              return Expanded(
                child: Padding(
                  padding: EdgeInsets.only(right: i == quickTypes.length - 1 ? 0 : 8),
                  child: FilledButton(
                    style: FilledButton.styleFrom(
                      backgroundColor: selected ? kBlue : const Color(0xFF10294A),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    onPressed: () => _applyQuick(type),
                    child: Text(type),
                  ),
                ),
              );
            }),
          ),
        ],
      ),
    );
  }

  Widget _crossoverPanel() {
    return GlassPanel(
      padding: const EdgeInsets.all(10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(4, 2, 4, 8),
            child: Text('Crossover', style: TextStyle(fontWeight: FontWeight.w800)),
          ),
          ...List.generate(7, _channelRow),
        ],
      ),
    );
  }

  Widget _channelRow(int i) {
    final color = channelColors[i];
    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 7),
      decoration: BoxDecoration(
        color: const Color(0x55112948),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white10),
      ),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final compact = constraints.maxWidth < 600;
          final mode = SizedBox(
            width: compact ? 124 : 150,
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: channelModes[i],
                isExpanded: true,
                dropdownColor: const Color(0xFF0D2949),
                items: modes.map((m) => DropdownMenuItem(value: m, child: Text(m, style: const TextStyle(fontSize: 12)))).toList(),
                onChanged: (value) => value == null ? null : setState(() => channelModes[i] = value),
              ),
            ),
          );
          final slider = Expanded(
            child: AccentSlider(
              value: hzToSlider(frequencies[i]).clamp(0.0, 1.0).toDouble(),
              min: 0,
              max: 1,
              color: color,
              onChanged: (v) => setState(() => frequencies[i] = sliderToHz(v)),
            ),
          );
          return Row(
            children: [
              Container(width: 11, height: 11, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
              const SizedBox(width: 7),
              SizedBox(width: 42, child: Text('CH${i + 1}', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12))),
              mode,
              SizedBox(width: compact ? 2 : 10),
              slider,
              SizedBox(
                width: compact ? 68 : 82,
                child: Text(formatHz(frequencies[i]), textAlign: TextAlign.right, style: const TextStyle(fontSize: 12)),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _delayPanel() {
    return GlassPanel(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Delay', style: TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: List.generate(7, (i) {
                final color = channelColors[i];
                return Container(
                  width: 105,
                  height: 190,
                  margin: const EdgeInsets.only(right: 8),
                  padding: const EdgeInsets.fromLTRB(8, 10, 8, 8),
                  decoration: BoxDecoration(
                    color: const Color(0x66112948),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Colors.white10),
                  ),
                  child: Column(
                    children: [
                      Text('CH${i + 1}', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
                      const SizedBox(height: 2),
                      Text('${delays[i].toStringAsFixed(1)} ms', style: const TextStyle(fontSize: 11, color: kTextSoft)),
                      Expanded(
                        child: RotatedBox(
                          quarterTurns: 3,
                          child: AccentSlider(
                            value: delays[i],
                            min: 0,
                            max: 10,
                            color: color,
                            onChanged: (v) => setState(() => delays[i] = v),
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              }),
            ),
          ),
        ],
      ),
    );
  }
}
