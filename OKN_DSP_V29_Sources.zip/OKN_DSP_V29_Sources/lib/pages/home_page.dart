import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../widgets/common.dart';

class HomePage extends StatefulWidget {
  final ValueChanged<int> onNavigate;

  const HomePage({super.key, required this.onNavigate});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool _connected = true;

  void _showSettings() {
    showModalBottomSheet<void>(
      context: context,
      useSafeArea: true,
      backgroundColor: const Color(0xFF07172F),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
      ),
      builder: (context) => Padding(
        padding: const EdgeInsets.fromLTRB(22, 18, 22, 28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.settings_rounded, color: kCyan),
                SizedBox(width: 10),
                Text('UI Settings', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
              ],
            ),
            const SizedBox(height: 16),
            SwitchListTile.adaptive(
              contentPadding: EdgeInsets.zero,
              value: _connected,
              activeColor: kGreen,
              title: const Text('Connection status demo'),
              subtitle: const Text('Phase 1 only — no DSP command is sent.'),
              onChanged: (value) {
                setState(() => _connected = value);
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        const Positioned.fill(child: CustomPaint(painter: _HomeBackdropPainter())),
        SafeArea(
          bottom: false,
          child: ResponsiveCenter(
            padding: const EdgeInsets.fromLTRB(24, 12, 24, 118),
            child: LayoutBuilder(
              builder: (context, constraints) {
                final wide = constraints.maxWidth >= 720;
                final logoSize = wide ? 255.0 : math.min(220.0, constraints.maxWidth * .56);
                return SingleChildScrollView(
                  child: ConstrainedBox(
                    constraints: BoxConstraints(minHeight: MediaQuery.sizeOf(context).height - 150),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            const Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'OKN_DSP',
                                    style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900, letterSpacing: .4),
                                  ),
                                  Text('Smart Sound  Better Life', style: TextStyle(color: kTextSoft, fontSize: 13)),
                                ],
                              ),
                            ),
                            IconButton(
                              tooltip: 'Settings',
                              onPressed: _showSettings,
                              icon: const Icon(Icons.settings_rounded, color: Colors.white, size: 28),
                            ),
                          ],
                        ),
                        const SizedBox(height: 28),
                        ConstrainedBox(
                          constraints: BoxConstraints(maxWidth: wide ? 560 : 430),
                          child: GlassPanel(
                            onTap: () => setState(() => _connected = !_connected),
                            borderRadius: BorderRadius.circular(42),
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                            gradient: const LinearGradient(
                              colors: [Color(0xE90B3763), Color(0xD5074E66)],
                              begin: Alignment.centerLeft,
                              end: Alignment.centerRight,
                            ),
                            child: Row(
                              children: [
                                Container(
                                  width: 54,
                                  height: 54,
                                  decoration: const BoxDecoration(
                                    gradient: LinearGradient(colors: [kBlue, kCyan]),
                                    shape: BoxShape.circle,
                                  ),
                                  child: const Icon(Icons.bluetooth_rounded, size: 32),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          Container(
                                            width: 10,
                                            height: 10,
                                            decoration: BoxDecoration(
                                              color: _connected ? kGreen : Colors.orange,
                                              shape: BoxShape.circle,
                                            ),
                                          ),
                                          const SizedBox(width: 7),
                                          Text(
                                            _connected ? 'Connected' : 'Demo disconnected',
                                            style: TextStyle(
                                              color: _connected ? kGreen : Colors.orange,
                                              fontWeight: FontWeight.w700,
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 3),
                                      const Text('OKN_DSP-001', style: TextStyle(color: kTextSoft, fontSize: 12)),
                                    ],
                                  ),
                                ),
                                const Icon(Icons.signal_cellular_alt_rounded, color: kGreen, size: 24),
                                const SizedBox(width: 13),
                                Container(width: 1, height: 40, color: Colors.white24),
                                const SizedBox(width: 13),
                                const Column(
                                  children: [
                                    Icon(Icons.battery_5_bar_rounded, color: kGreen, size: 25),
                                    SizedBox(height: 2),
                                    Text('12.5V', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                        SizedBox(height: wide ? 54 : 38),
                        GestureDetector(
                          onTap: () => widget.onNavigate(1),
                          child: Container(
                            width: logoSize,
                            height: logoSize,
                            padding: const EdgeInsets.all(8),
                            decoration: const BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: SweepGradient(colors: [kCyan, kBlue, kPurple, kPink, kCyan]),
                            ),
                            child: Container(
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: const RadialGradient(
                                  colors: [Color(0xFF143E6B), Color(0xFF031329)],
                                  radius: .95,
                                ),
                                border: Border.all(color: Colors.white24),
                                boxShadow: const [BoxShadow(color: Color(0x5500D8FF), blurRadius: 28)],
                              ),
                              child: const Center(
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text('OKN', style: TextStyle(fontSize: 48, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
                                    Text('DSP', style: TextStyle(fontSize: 31, fontWeight: FontWeight.w400, letterSpacing: 3.5)),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 25),
                        const Text(
                          'Digital Signal Processor',
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, letterSpacing: .5),
                        ),
                        const SizedBox(height: 3),
                        const Text('For Your Perfect Sound', style: TextStyle(color: kTextSoft, fontSize: 12)),
                        const SizedBox(height: 24),
                        SizedBox(
                          height: 78,
                          width: wide ? 500 : 320,
                          child: const CustomPaint(painter: _WaveformPainter()),
                        ),
                        const SizedBox(height: 20),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 6),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            color: Colors.black12,
                            border: Border.all(color: Colors.white24),
                          ),
                          child: const Text('v29.0.0', style: TextStyle(color: kTextSoft, fontSize: 11)),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ),
      ],
    );
  }
}

class _HomeBackdropPainter extends CustomPainter {
  const _HomeBackdropPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final base = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color(0xFF0876E7), Color(0xFF0B4DD2), Color(0xFF08225A), Color(0xFF041429)],
      ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, base);

    final p1 = Path()
      ..moveTo(0, size.height * .36)
      ..cubicTo(size.width * .25, size.height * .47, size.width * .42, size.height * .28, size.width, size.height * .17)
      ..lineTo(size.width, size.height * .48)
      ..cubicTo(size.width * .65, size.height * .39, size.width * .35, size.height * .61, 0, size.height * .52)
      ..close();
    canvas.drawPath(
      p1,
      Paint()
        ..shader = const LinearGradient(
          colors: [Color(0xAA9D21FF), Color(0x2200D8FF)],
        ).createShader(Offset.zero & size),
    );

    final p2 = Path()
      ..moveTo(0, size.height * .62)
      ..cubicTo(size.width * .35, size.height * .52, size.width * .62, size.height * .64, size.width, size.height * .45)
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();
    canvas.drawPath(
      p2,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0x552B18D9), Color(0xAA041429)],
        ).createShader(Offset.zero & size),
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _WaveformPainter extends CustomPainter {
  const _WaveformPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.height / 2;
    final bars = 38;
    for (var i = 0; i < bars; i++) {
      final x = i * size.width / (bars - 1);
      final norm = i / (bars - 1);
      final envelope = .22 + .78 * (math.sin(norm * math.pi * 3).abs() * .72 + .28);
      final h = envelope * size.height * .72;
      final color = Color.lerp(kBlue, kPink, norm)!;
      final paint = Paint()
        ..color = color
        ..strokeWidth = i % 3 == 0 ? 5 : 3
        ..strokeCap = StrokeCap.round;
      canvas.drawLine(Offset(x, center - h / 2), Offset(x, center + h / 2), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
