import 'dart:math' as math;

import 'package:flutter/material.dart';

const Color kPanel = Color(0xB3152D50);
const Color kPanelBorder = Color(0x663D6A9E);
const Color kTextSoft = Color(0xFFB9C9E5);
const Color kCyan = Color(0xFF00D8FF);
const Color kBlue = Color(0xFF1688FF);
const Color kPurple = Color(0xFF8A4CFF);
const Color kPink = Color(0xFFFF4BB2);
const Color kGreen = Color(0xFF22E88A);
const Color kYellow = Color(0xFFFFBE3B);

class ResponsiveCenter extends StatelessWidget {
  final Widget child;
  final double maxWidth;
  final EdgeInsets padding;

  const ResponsiveCenter({
    super.key,
    required this.child,
    this.maxWidth = 980,
    this.padding = const EdgeInsets.fromLTRB(18, 10, 18, 118),
  });

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.topCenter,
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: maxWidth),
        child: Padding(padding: padding, child: child),
      ),
    );
  }
}

class GlassPanel extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final BorderRadius borderRadius;
  final Gradient? gradient;
  final VoidCallback? onTap;

  const GlassPanel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(14),
    this.borderRadius = const BorderRadius.all(Radius.circular(18)),
    this.gradient,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final content = Container(
      padding: padding,
      decoration: BoxDecoration(
        borderRadius: borderRadius,
        gradient: gradient,
        color: gradient == null ? kPanel : null,
        border: Border.all(color: kPanelBorder),
        boxShadow: const [
          BoxShadow(
            color: Color(0x33000000),
            blurRadius: 16,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: child,
    );
    if (onTap == null) return content;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: borderRadius,
        onTap: onTap,
        child: content,
      ),
    );
  }
}

class StatusHeader extends StatelessWidget {
  final bool connected;

  const StatusHeader({super.key, this.connected = true});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        const Expanded(
          child: Text(
            'OKN_DSP',
            maxLines: 1,
            overflow: TextOverflow.fade,
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.w900,
              letterSpacing: .4,
              color: Colors.white,
            ),
          ),
        ),
        Container(
          width: 9,
          height: 9,
          decoration: BoxDecoration(
            color: connected ? kGreen : Colors.orange,
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: (connected ? kGreen : Colors.orange).withOpacity(.55),
                blurRadius: 10,
              ),
            ],
          ),
        ),
        const SizedBox(width: 6),
        Text(
          connected ? 'Connected' : 'Demo',
          style: TextStyle(
            color: connected ? kGreen : Colors.orange,
            fontSize: 12,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(width: 14),
        const Icon(Icons.signal_cellular_alt_rounded, size: 21),
        const SizedBox(width: 10),
        const Text(
          '12.5V',
          style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12),
        ),
      ],
    );
  }
}

class PageTitle extends StatelessWidget {
  final String title;
  final String subtitle;
  final VoidCallback onBack;

  const PageTitle({
    super.key,
    required this.title,
    required this.subtitle,
    required this.onBack,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        IconButton(
          tooltip: 'Home',
          onPressed: onBack,
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: kCyan),
        ),
        const SizedBox(width: 4),
        Expanded(
          child: Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 26,
                    height: 1,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  subtitle,
                  style: const TextStyle(color: kTextSoft, fontSize: 13),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class AccentSlider extends StatelessWidget {
  final double value;
  final double min;
  final double max;
  final ValueChanged<double> onChanged;
  final Color color;
  final int? divisions;

  const AccentSlider({
    super.key,
    required this.value,
    required this.min,
    required this.max,
    required this.onChanged,
    required this.color,
    this.divisions,
  });

  @override
  Widget build(BuildContext context) {
    return SliderTheme(
      data: SliderTheme.of(context).copyWith(
        activeTrackColor: color,
        inactiveTrackColor: const Color(0xFF071A31),
        thumbColor: Colors.white,
        overlayColor: color.withOpacity(.14),
        trackHeight: 8,
        thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 9),
        overlayShape: const RoundSliderOverlayShape(overlayRadius: 18),
      ),
      child: Slider(
        value: value.clamp(min, max).toDouble(),
        min: min,
        max: max,
        divisions: divisions,
        onChanged: onChanged,
      ),
    );
  }
}

class OknBottomNav extends StatelessWidget {
  final int index;
  final ValueChanged<int> onChanged;

  const OknBottomNav({
    super.key,
    required this.index,
    required this.onChanged,
  });

  static const items = <(IconData, String)>[
    (Icons.home_rounded, 'Home'),
    (Icons.tune_rounded, 'Mix'),
    (Icons.equalizer_rounded, 'Eq'),
    (Icons.multiline_chart_rounded, 'Crossover'),
  ];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      minimum: const EdgeInsets.fromLTRB(10, 0, 10, 8),
      child: Container(
        height: 84,
        decoration: BoxDecoration(
          color: const Color(0xEE07172F),
          borderRadius: const BorderRadius.all(Radius.circular(28)),
          border: Border.all(color: const Color(0x665B7EB0)),
          boxShadow: const [
            BoxShadow(color: Color(0x66000000), blurRadius: 24, offset: Offset(0, 12)),
          ],
        ),
        child: Row(
          children: List.generate(items.length, (i) {
            final selected = i == index;
            return Expanded(
              child: Semantics(
                button: true,
                selected: selected,
                label: items[i].$2,
                child: InkWell(
                  borderRadius: BorderRadius.circular(24),
                  onTap: () => onChanged(i),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 180),
                    margin: const EdgeInsets.all(5),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(22),
                      gradient: selected
                          ? const LinearGradient(
                              colors: [Color(0x55268DFF), Color(0x66793CFF)],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            )
                          : null,
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          items[i].$1,
                          color: selected ? (i == 2 || i == 3 ? kPink : kCyan) : kTextSoft,
                          size: 27,
                        ),
                        const SizedBox(height: 4),
                        Text(
                          items[i].$2,
                          style: TextStyle(
                            color: selected ? Colors.white : kTextSoft,
                            fontSize: 12,
                            fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            );
          }),
        ),
      ),
    );
  }
}

String formatHz(double hz) {
  if (hz >= 1000) {
    final value = hz / 1000;
    return '${value >= 10 ? value.toStringAsFixed(0) : value.toStringAsFixed(1)} kHz';
  }
  return '${hz.round()} Hz';
}

double sliderToHz(double t) => 20 * math.pow(1000, t).toDouble();

double hzToSlider(double hz) => math.log(hz / 20) / math.log(1000);
