import 'package:flutter/material.dart';

import 'pages/crossover_page.dart';
import 'pages/eq_page.dart';
import 'pages/home_page.dart';
import 'pages/mix_page.dart';
import 'widgets/common.dart';

class OknShell extends StatefulWidget {
  const OknShell({super.key});

  @override
  State<OknShell> createState() => _OknShellState();
}

class _OknShellState extends State<OknShell> {
  int _index = 0;

  void _go(int index) {
    if (_index == index) return;
    setState(() => _index = index);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: DecoratedBox(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFF061A35),
              Color(0xFF041225),
              Color(0xFF07172D),
            ],
          ),
        ),
        child: IndexedStack(
          index: _index,
          children: [
            HomePage(onNavigate: _go),
            MixPage(onBack: () => _go(0)),
            EqPage(onBack: () => _go(0)),
            CrossoverPage(onBack: () => _go(0)),
          ],
        ),
      ),
      bottomNavigationBar: OknBottomNav(
        index: _index,
        onChanged: _go,
      ),
    );
  }
}
