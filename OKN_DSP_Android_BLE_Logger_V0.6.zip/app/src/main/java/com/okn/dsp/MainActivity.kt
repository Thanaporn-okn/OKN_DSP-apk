package com.okn.dsp

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.core.app.ActivityCompat
import com.okn.dsp.transport.BleDspTransport
import java.util.Locale
import java.util.UUID

class MainActivity : Activity(), BleDspTransport.Listener {
    private lateinit var transport: BleDspTransport
    private lateinit var devices: LinearLayout
    private lateinit var logView: TextView
    private lateinit var status: TextView
    private val seen = mutableSetOf<String>()

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        transport = BleDspTransport(this, this)
        requestBlePermissions()
        buildUi()
    }

    private fun requestBlePermissions() {
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT), 10)
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 11)
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 20, 20, 20) }
        status = TextView(this).apply { text = "OKN DSP • Disconnected"; textSize = 20f }
        root.addView(status)

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun addButton(label: String, action: () -> Unit) {
            buttons.addView(Button(this).apply { text = label; setOnClickListener { action() } }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        addButton("SCAN") { seen.clear(); devices.removeAllViews(); transport.startScan() }
        addButton("STOP") { transport.stopScan() }
        addButton("CLEAR") { logView.text = "" }
        root.addView(buttons)

        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun addTool(label: String, action: () -> Unit) {
            tools.addView(Button(this).apply { text = label; setOnClickListener { action() } }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        addTool("DISCONNECT") { transport.disconnect() }
        addTool("COPY") { copyLog() }
        addTool("SHARE") { shareLog() }
        root.addView(tools)

        root.addView(TextView(this).apply { text = "BLE devices"; textSize = 16f })
        devices = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(devices) }, LinearLayout.LayoutParams(-1, 0, 1.2f))

        root.addView(TextView(this).apply { text = "Packet / GATT log • READ + discovery only"; textSize = 16f })
        logView = TextView(this).apply { textSize = 12f; setTextIsSelectable(true) }
        root.addView(ScrollView(this).apply { addView(logView) }, LinearLayout.LayoutParams(-1, 0, 1.4f))
        setContentView(root)

        onLog("Known UUID candidates:")
        BleDspTransport.SERVICE_UUIDS.forEach { onLog("  $it") }
        onLog("Notifications are enabled when CCCD is available.")
        onLog("WRITE commands are disabled until UFE framing/CRC is verified.")
    }

    override fun onDeviceFound(device: BluetoothDevice, rssi: Int) {
        val key = device.address ?: return
        if (!seen.add(key)) return
        val name = try { device.name } catch (_: SecurityException) { null }
        runOnUiThread {
            val b = Button(this).apply {
                text = "${name ?: "(no name)"}\n$key  RSSI $rssi"
                setOnClickListener { transport.connect(device) }
            }
            devices.addView(b)
        }
    }

    override fun onConnected(device: BluetoothDevice) {
        runOnUiThread { status.text = "OKN DSP • Connected ${device.address}" }
        onLog("Connected: ${device.address}")
    }

    override fun onDisconnected() {
        runOnUiThread { status.text = "OKN DSP • Disconnected" }
        onLog("Disconnected")
    }

    override fun onServices(services: List<android.bluetooth.BluetoothGattService>) {
        onLog("Service count=${services.size}")
        services.forEach { s ->
            onLog("SERVICE ${s.uuid}")
            s.characteristics.forEach { c ->
                onLog("  -> ${c.uuid} props=${c.properties}")
            }
        }
    }

    override fun onNotification(service: UUID, characteristic: UUID, value: ByteArray) {
        val hex = value.joinToString(" ") { String.format(Locale.US, "%02X", it.toInt() and 0xFF) }
        onLog("RX $service / $characteristic  len=${value.size}  $hex")
    }

    override fun onLog(line: String) {
        runOnUiThread {
            logView.append("$line\n")
            val max = 200_000
            if (logView.text.length > max) logView.text = logView.text.takeLast(max)
        }
    }

    private fun copyLog() {
        val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("OKN DSP log", logView.text.toString()))
        Toast.makeText(this, "Log copied", Toast.LENGTH_SHORT).show()
    }

    private fun shareLog() {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "OKN DSP BLE capture")
            putExtra(Intent.EXTRA_TEXT, logView.text.toString())
        }
        startActivity(Intent.createChooser(intent, "Send DSP log"))
    }

    override fun onDestroy() { transport.close(); super.onDestroy() }
}
