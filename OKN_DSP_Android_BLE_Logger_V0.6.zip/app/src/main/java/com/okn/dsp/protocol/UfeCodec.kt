package com.okn.dsp.protocol
data class UfePacket(val command:Int,val payload:ByteArray)
class UfeCodec {
 fun encode(p:UfePacket):ByteArray=error("UFE framing not yet verified")
 fun decode(b:ByteArray):UfePacket=error("UFE framing not yet verified")
}