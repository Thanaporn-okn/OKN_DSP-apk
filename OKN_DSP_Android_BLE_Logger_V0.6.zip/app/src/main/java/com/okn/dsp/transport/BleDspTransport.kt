package com.okn.dsp.transport

import android.Manifest
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import java.util.UUID

class BleDspTransport(private val context: Context, private val listener: Listener) {
    interface Listener {
        fun onLog(line: String)
        fun onDeviceFound(device: BluetoothDevice, rssi: Int)
        fun onConnected(device: BluetoothDevice)
        fun onDisconnected()
        fun onServices(services: List<BluetoothGattService>)
        fun onNotification(service: UUID, characteristic: UUID, value: ByteArray)
    }

    companion object {
        val SERVICE_UUIDS = listOf(
            UUID.fromString("40af0001-9479-43f6-ae95-c45fb2afb9d2"),
            UUID.fromString("40af0002-9479-43f6-ae95-c45fb2afb9d2"),
            UUID.fromString("40af0003-9479-43f6-ae95-c45fb2afb9d2")
        )
        private val CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    }

    private val adapter: BluetoothAdapter? =
        (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    private var scanner: BluetoothLeScanner? = null
    private var gatt: BluetoothGatt? = null
    private val handler = Handler(Looper.getMainLooper())

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            listener.onDeviceFound(result.device, result.rssi)
        }
        override fun onScanFailed(errorCode: Int) { listener.onLog("Scan failed: $errorCode") }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            listener.onLog("GATT state=$newState status=$status")
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                listener.onConnected(g.device)
                if (hasConnectPermission()) g.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                listener.onDisconnected()
                g.close()
                if (gatt === g) gatt = null
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            listener.onLog("Services discovered status=$status")
            listener.onServices(g.services)
            var enabled = 0
            g.services.forEach { service ->
                service.characteristics.forEach { c ->
                    listener.onLog("CHAR ${service.uuid} / ${c.uuid} props=${c.properties}")
                    val canNotify = (c.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0
                    val canIndicate = (c.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0
                    if (canNotify || canIndicate) {
                        if (hasConnectPermission() && g.setCharacteristicNotification(c, true)) {
                            val d = c.getDescriptor(CCCD)
                            if (d != null) {
                                d.value = if (canNotify) BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                                else BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
                                if (g.writeDescriptor(d)) enabled++
                            }
                        }
                    }
                }
            }
            listener.onLog("Notification setup requested for $enabled characteristic(s)")
        }

        @Suppress("DEPRECATION")
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            listener.onNotification(c.service.uuid, c.uuid, c.value ?: byteArrayOf())
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray) {
            listener.onNotification(c.service.uuid, c.uuid, value)
        }

        override fun onDescriptorWrite(g: BluetoothGatt, descriptor: BluetoothGattDescriptor, status: Int) {
            listener.onLog("CCCD ${descriptor.characteristic.uuid} write status=$status")
        }
    }

    fun startScan() {
        if (!hasScanPermission()) { listener.onLog("Bluetooth scan permission required"); return }
        if (adapter?.isEnabled != true) { listener.onLog("Bluetooth is OFF — turn Bluetooth on first"); return }
        scanner = adapter.bluetoothLeScanner
        scanner?.startScan(scanCallback)
        listener.onLog("BLE scan started — looking for GoloPineDSPAudioTurning")
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ stopScan() }, 12_000)
    }

    fun stopScan() {
        if (hasScanPermission()) scanner?.stopScan(scanCallback)
        scanner = null
        listener.onLog("BLE scan stopped")
    }

    fun connect(device: BluetoothDevice) {
        if (!hasConnectPermission()) { listener.onLog("Bluetooth connect permission required"); return }
        stopScan()
        listener.onLog("Connecting to ${device.address}")
        gatt?.close()
        gatt = device.connectGatt(context, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
    }

    fun disconnect() {
        if (hasConnectPermission()) gatt?.disconnect()
        gatt?.close()
        gatt = null
    }

    fun close() { handler.removeCallbacksAndMessages(null); stopScan(); disconnect() }
    private fun hasScanPermission() = ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
    private fun hasConnectPermission() = ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
}
