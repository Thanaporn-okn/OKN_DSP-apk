# OKN DSP Android BLE Logger V0.6.0

Mobile-first BLE logger for the OKN DSP research project.

## Build
Use the separate GitHub Actions workflow supplied with this release.
It supports `workflow_dispatch` and builds a debug APK as an Artifact.

## V0.6 fix
Java/Kotlin JVM target alignment is explicitly set to Java 17 to avoid the
common Gradle/AGP Kotlin JVM-target mismatch that can stop `assembleDebug`.

WRITE commands remain disabled until the UFE framing/CRC is verified from real captures.
