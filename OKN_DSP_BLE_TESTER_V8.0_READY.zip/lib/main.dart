import 'package:flutter/material.dart';

void main() {
  runApp(const OKNDSPTester());
}

class OKNDSPTester extends StatelessWidget {
  const OKNDSPTester({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),
      home: const TesterPage(),
    );
  }
}

class TesterPage extends StatefulWidget {
  const TesterPage({super.key});

  @override
  State<TesterPage> createState() => _TesterPageState();
}

class _TesterPageState extends State<TesterPage> {
  final log = <String>[];
  final cmd = TextEditingController();

  void addLog(String s) {
    setState(() => log.add(s));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('OKN DSP BLE TESTER V8.0')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            ElevatedButton(
              onPressed: () => addLog('BLE Scan started'),
              child: const Text('SCAN BLE'),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: cmd,
              decoration: const InputDecoration(
                labelText: 'HEX COMMAND (AB01 WRITE)'
              ),
            ),
            ElevatedButton(
              onPressed: () => addLog('TX: ${cmd.text}'),
              child: const Text('SEND'),
            ),
            const Divider(),
            Expanded(
              child: ListView(
                children: log.map((e) => Text(e)).toList(),
              ),
            )
          ],
        ),
      ),
    );
  }
}
