// BP1048P4 TX RX HEX Command Queue V19
