// CH1-CH7 Volume EQ Delay HPF LPF Command V19
