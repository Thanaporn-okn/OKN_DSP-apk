OKN DSP V97 — STABLE EXPLICIT CONNECT
=====================================
Base: V96 verified-scope realtime UI / frozen DSP protocol.

Evidence from user recording 27426.mp4:
- Scan discovers LE-GoloPine_DSP_A correctly.
- The scanned row remains visible but the attempted tap does not transition the UI to CONNECTING.
- V97 changes only the scan/connect UI handoff; DSP packets, crypto, UUIDs and writer gates remain unchanged.

V97 fix:
- Stop BLE scan immediately after first compatible DSP is found.
- Store that result as a stable scan candidate.
- Render a large dedicated "CONNECT DSP / เชื่อมต่อทันที" button.
- The connect button is not stored inside the dynamic scan-result list.
- On tap, update the button immediately, record V97_CONNECT_BUTTON_TAP, then post connect() 80 ms later so Android finishes the click gesture before the Home UI is rebuilt.
- Keep automatic GATT discovery -> AB02 subscribe -> Auth -> Device Description -> Health Gate -> READY flow.
- Scan failure is visible via onScanFailed.

Frozen verified write scope is unchanged:
- Scalars [2,3,8,9,10,13,11]
- EQ safe PEAKING type=12 only
- Sensors read-only
- SaveParams manual guarded only
- Generic/preset/delay/unknown writes locked
