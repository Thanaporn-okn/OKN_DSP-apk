OKN_DSP V95 — VERIFIED SCOPE UI / REAL-TIME / PERSISTENT
========================================================
VersionCode: 95
VersionName: 6.4.0-v95-verified-scope-ui-realtime-persistent

Purpose
-------
Rebuild the Android operator UI to the supplied five-screen OKN_DSP reference while retaining the proven BLE/auth/protocol core and stable signing lineage.

Reference UI
------------
evidence/OKN_DSP_V95_UI_REFERENCE.png
SHA256: 6f5f2eab24de53cd7460abd79e76b04382edd8c62eb7c1e317bbd1bdbfb5b2b0

Visible V95 operator flow
-------------------------
- Home / Dashboard
  - Bluetooth Scan
  - tap result to Connect
  - automatic Auth + Device Description + current-session Health Gate
  - DSP card / Health Gate / Session + System summary
  - MasterVolume realtime slider
  - 7 channel cards -> direct EQ editor
  - Link All EQ toggle
- Global
  - exactly 7 verified scalar controls
  - direct realtime slider writes, no confirmation dialog
- EQ
  - 7 channel overview cards
  - 15 bands/channel
  - PEAKING type=12 rows editable in realtime: Frequency / Q / Gain
  - other live descriptor types remain read-only
  - optional Link All safely mirrors only to PEAKING rows that are writable on the other channels
- Sensors
  - 4 verified read-only sensors
  - manual guarded SaveParams button
- More
  - connection/reconnect/status/policy information only; no unverified DSP writes

Realtime / persistence behavior
-------------------------------
- one BLE write in flight
- latest-target-wins coalescing
- minimum 38 ms send pacing
- every accepted slider movement is immediately stored in SharedPreferences
- after a fresh reconnect Health Gate, remembered verified scalar/EQ values are replayed automatically
- MasterVolume ID2 is synchronized with Android STREAM_MUSIC both directions
- physical phone Volume +/- changes map directly to MasterVolume ID2
- TrebleBoost ID11 uses callback-driven bounded slew: <=0.5 dB step, 48 ms nominal interval
- portrait/landscape rebuild changes only the view tree and keeps current GATT/session objects alive

Verified hardware writer boundary
---------------------------------
Scalars: [2,3,8,9,10,13,11]
EQ channels: [4,5,6,14,15,16,17]
EQ record: 48 bytes/band; PEAKING type=12 only; Fs=44100
Sensors: IDs 19,20,0,21 read-only
SaveParams: ID7 exact plaintext 570000000700000000, manual guarded only
Generic writes: disabled
Unknown/preset/delay/crossover/output/mute/phase hardware writes: not exposed; no guessed packets

Qualification
-------------
Static source/preflight validation is included. GitHub Actions is the authoritative Android build/sign path. Real target-DSP acoustic/no-stutter qualification remains a physical hardware test and is not claimed by this source package alone.
