OKN DSP V96 — CONNECT RUNTIME VISIBILITY HARDENING
==================================================
Base: V95 verified-scope UI / realtime / persistent build.

Purpose:
- Fix the runtime UX failure shown in the user's screen recording: after Scan finds the DSP,
  selecting the device gave no visible connection progress because the legacy status TextView
  is hidden by the reference UI.
- Preserve the exact five-tab reference visual language while showing connection state in the
  existing connection card.
- Keep the verified BLE protocol, crypto, scalar/EQ writer boundary, stable signing, and
  no-guessed-packet policy unchanged.

V96 connection state shown in the Home connection card:
DISCONNECTED -> SCANNING -> DEVICE_FOUND -> CONNECTING -> DISCOVERING ->
SUBSCRIBING -> AUTHENTICATING -> LOADING -> READY, or ERROR.

Runtime hardening:
- Immediate toast + visible CONNECTING state after tapping a scanned DSP.
- Scan/Connect exceptions are caught and displayed instead of silently returning.
- GATT service/CCCD/Auth/descriptor stages are visible.
- 15 s fail-closed connection watchdog remains active.
- Health Gate PASS is the only READY state.

Verified writer scope remains:
- Scalars IDs [2,3,8,9,10,13,11].
- EQ only safe PEAKING type=12 full 48-byte records.
- Sensors read-only.
- SaveParams manual guarded only.
- Generic/preset/delay/unknown writes locked.

No DSP packet, UUID, crypto key, actuator, or write payload was guessed or expanded in V96.
