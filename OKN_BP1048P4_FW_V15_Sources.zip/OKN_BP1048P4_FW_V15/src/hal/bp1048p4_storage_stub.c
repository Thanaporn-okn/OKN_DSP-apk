#include "bp1048p4_storage.h"

static int locked_read(unsigned slot, uint8_t *out, size_t cap, size_t *out_len) {
    (void)slot; (void)out; (void)cap;
    if (out_len) *out_len=0u;
    return OKN_ERR_HAL_LOCKED;
}
static int locked_write(unsigned slot, const uint8_t *data, size_t len) {
    (void)slot; (void)data; (void)len;
    return OKN_ERR_HAL_LOCKED;
}

static const okn_storage_io_t STORAGE = {
    .read_slot=locked_read,
    .write_slot=locked_write,
};

const okn_storage_io_t *bp1048p4_storage_get(void) { return &STORAGE; }
