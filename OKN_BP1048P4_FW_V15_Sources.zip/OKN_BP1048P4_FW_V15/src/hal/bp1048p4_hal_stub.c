#include "bp1048p4_port_contract.h"

static int locked_init(void) { return OKN_ERR_HAL_LOCKED; }
static int locked_mute(bool enable) { (void)enable; return OKN_ERR_HAL_LOCKED; }
static int locked_audio(void) { return OKN_ERR_HAL_LOCKED; }
static int locked_master(float db) { (void)db; return OKN_ERR_HAL_LOCKED; }
static int locked_channel(unsigned channel, const okn_channel_state_t *state) {
    (void)channel; (void)state; return OKN_ERR_HAL_LOCKED;
}
static int locked_notify(const uint8_t *data, size_t len) {
    (void)data; (void)len; return OKN_ERR_HAL_LOCKED;
}

static const bp1048p4_hal_t HAL = {
    .platform_init = locked_init,
    .set_output_safety_mute = locked_mute,
    .audio_start = locked_audio,
    .apply_master_gain = locked_master,
    .apply_channel_state = locked_channel,
    .ble_notify = locked_notify,
};

/* The public MVsB1 SDK is useful family evidence, but V6 deliberately does not
 * mark it as P4/board evidence. Hardware stays locked until the exact target is
 * independently verified. */
static const bp1048p4_port_evidence_t EVIDENCE = {
    .magic = BP1048P4_PORT_EVIDENCE_MAGIC,
    .abi_version = BP1048P4_PORT_ABI_VERSION,
    .bp1048p4_target_verified = false,
    .board_profile_verified = false,
    .platform_init_verified = false,
    .platform_init_output_safe_verified = false,
    .output_safety_mute_verified = false,
    .audio_path_verified = false,
    .ble_path_verified = false,
    .storage_path_verified = false,
};

const bp1048p4_hal_t *bp1048p4_hal_get(void) { return &HAL; }
const bp1048p4_port_evidence_t *bp1048p4_port_evidence_get(void) { return &EVIDENCE; }
