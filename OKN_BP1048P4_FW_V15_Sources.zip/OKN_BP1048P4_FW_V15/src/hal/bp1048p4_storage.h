#ifndef BP1048P4_STORAGE_H
#define BP1048P4_STORAGE_H

#include "../persist/okn_persistence.h"

/* Storage stays locked until a verified BP1048P4 SDK/board flash or NVM API is known.
 * No guessed flash page, address, erase command or vendor call is allowed here. */
const okn_storage_io_t *bp1048p4_storage_get(void);

#endif
