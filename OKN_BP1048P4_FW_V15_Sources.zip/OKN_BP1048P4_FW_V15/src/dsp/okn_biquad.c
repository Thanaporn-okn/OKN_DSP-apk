#include "okn_biquad.h"
#include <math.h>

#define OKN_PI_F 3.14159265358979323846f

void okn_biquad_identity(okn_biquad_coeff_t *c) {
    if (!c) return;
    c->b0 = 1.0f; c->b1 = 0.0f; c->b2 = 0.0f;
    c->a1 = 0.0f; c->a2 = 0.0f;
}

void okn_biquad_reset(okn_biquad_mem_t *m) {
    if (!m) return;
    m->z1 = 0.0f; m->z2 = 0.0f;
}

static okn_status_t normalize(float b0, float b1, float b2,
                              float a0, float a1, float a2,
                              okn_biquad_coeff_t *out) {
    if (!out || !isfinite(a0) || fabsf(a0) < 1.0e-20f) return OKN_ERR_RANGE;
    const float inv = 1.0f / a0;
    out->b0 = b0 * inv; out->b1 = b1 * inv; out->b2 = b2 * inv;
    out->a1 = a1 * inv; out->a2 = a2 * inv;
    if (!isfinite(out->b0) || !isfinite(out->b1) || !isfinite(out->b2) ||
        !isfinite(out->a1) || !isfinite(out->a2)) return OKN_ERR_RANGE;
    return OKN_OK;
}

okn_status_t okn_biquad_design(okn_biquad_kind_t kind, float fs,
                               float freq, float gain_db, float q,
                               okn_biquad_coeff_t *out) {
    if (!out || !isfinite(fs) || !isfinite(freq) || !isfinite(gain_db) || !isfinite(q)) return OKN_ERR_ARG;
    if (kind == OKN_BIQUAD_BYPASS) { okn_biquad_identity(out); return OKN_OK; }
    if (fs <= 0.0f || freq <= 0.0f || freq >= fs * 0.5f || q <= 0.0f) return OKN_ERR_RANGE;

    const float w0 = 2.0f * OKN_PI_F * freq / fs;
    const float cw = cosf(w0), sw = sinf(w0);
    const float alpha_q = sw / (2.0f * q);
    float b0, b1, b2, a0, a1, a2;

    switch (kind) {
        case OKN_BIQUAD_PEQ: {
            const float A = powf(10.0f, gain_db / 40.0f);
            b0 = 1.0f + alpha_q * A; b1 = -2.0f * cw; b2 = 1.0f - alpha_q * A;
            a0 = 1.0f + alpha_q / A; a1 = -2.0f * cw; a2 = 1.0f - alpha_q / A;
            break;
        }
        case OKN_BIQUAD_NOTCH:
            b0 = 1.0f; b1 = -2.0f * cw; b2 = 1.0f;
            a0 = 1.0f + alpha_q; a1 = -2.0f * cw; a2 = 1.0f - alpha_q;
            break;
        case OKN_BIQUAD_HPF:
            b0 = (1.0f + cw) * 0.5f; b1 = -(1.0f + cw); b2 = (1.0f + cw) * 0.5f;
            a0 = 1.0f + alpha_q; a1 = -2.0f * cw; a2 = 1.0f - alpha_q;
            break;
        case OKN_BIQUAD_LPF:
            b0 = (1.0f - cw) * 0.5f; b1 = 1.0f - cw; b2 = (1.0f - cw) * 0.5f;
            a0 = 1.0f + alpha_q; a1 = -2.0f * cw; a2 = 1.0f - alpha_q;
            break;
        case OKN_BIQUAD_LOW_SHELF:
        case OKN_BIQUAD_HIGH_SHELF: {
            /* OKN-native shelf semantics: q is the RBJ shelf slope S (>0). This
             * defines our replacement firmware behavior; it is not a claim about
             * GoloPine/BP1048P4 vendor coefficient semantics. */
            const float A = powf(10.0f, gain_db / 40.0f);
            const float term = (A + 1.0f / A) * (1.0f / q - 1.0f) + 2.0f;
            if (!(term > 0.0f) || !isfinite(term)) return OKN_ERR_RANGE;
            const float alpha = 0.5f * sw * sqrtf(term);
            const float beta = 2.0f * sqrtf(A) * alpha;
            if (kind == OKN_BIQUAD_LOW_SHELF) {
                b0 = A * ((A + 1.0f) - (A - 1.0f) * cw + beta);
                b1 = 2.0f * A * ((A - 1.0f) - (A + 1.0f) * cw);
                b2 = A * ((A + 1.0f) - (A - 1.0f) * cw - beta);
                a0 = (A + 1.0f) + (A - 1.0f) * cw + beta;
                a1 = -2.0f * ((A - 1.0f) + (A + 1.0f) * cw);
                a2 = (A + 1.0f) + (A - 1.0f) * cw - beta;
            } else {
                b0 = A * ((A + 1.0f) + (A - 1.0f) * cw + beta);
                b1 = -2.0f * A * ((A - 1.0f) + (A + 1.0f) * cw);
                b2 = A * ((A + 1.0f) + (A - 1.0f) * cw - beta);
                a0 = (A + 1.0f) - (A - 1.0f) * cw + beta;
                a1 = 2.0f * ((A - 1.0f) - (A + 1.0f) * cw);
                a2 = (A + 1.0f) - (A - 1.0f) * cw - beta;
            }
            break;
        }
        default:
            return OKN_ERR_UNSUPPORTED;
    }
    return normalize(b0, b1, b2, a0, a1, a2, out);
}

float okn_biquad_process(const okn_biquad_coeff_t *c, okn_biquad_mem_t *m, float x) {
    if (!c || !m) return 0.0f;
    const float y = c->b0 * x + m->z1;
    m->z1 = c->b1 * x - c->a1 * y + m->z2;
    m->z2 = c->b2 * x - c->a2 * y;
    return y;
}
