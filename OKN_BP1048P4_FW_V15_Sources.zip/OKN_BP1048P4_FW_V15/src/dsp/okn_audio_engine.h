#ifndef OKN_AUDIO_ENGINE_H
#define OKN_AUDIO_ENGINE_H

#include "okn_biquad.h"
#include "../core/okn_params.h"
#include <stddef.h>
#include <stdint.h>

#define OKN_AUDIO_REF_MAX_SAMPLE_RATE_HZ 48000u
#define OKN_AUDIO_REF_MAX_DELAY_SAMPLES ((OKN_AUDIO_REF_MAX_SAMPLE_RATE_HZ * 50u) / 1000u)
#define OKN_AUDIO_REF_DELAY_STRIDE_SAMPLES (OKN_AUDIO_REF_MAX_DELAY_SAMPLES + 1u)
#define OKN_AUDIO_REF_DELAY_ARENA_SAMPLES ((size_t)OKN_CHANNELS * (size_t)OKN_AUDIO_REF_DELAY_STRIDE_SAMPLES)
#define OKN_AUDIO_REF_DELAY_ARENA_BYTES (OKN_AUDIO_REF_DELAY_ARENA_SAMPLES * sizeof(float))

typedef struct {
    okn_biquad_coeff_t hpf, lpf;
    okn_biquad_coeff_t peq[OKN_PEQ_BANDS];
    okn_biquad_mem_t hpf_mem, lpf_mem;
    okn_biquad_mem_t peq_mem[OKN_PEQ_BANDS];
    float gain_linear;
    uint32_t delay_samples;
    uint32_t delay_pos;
    float *delay_line;
    uint32_t delay_capacity;
} okn_audio_lane_t;

typedef struct {
    uint32_t sample_rate_hz;
    uint32_t prepared_revision;
    float *delay_arena;
    size_t delay_arena_samples;
    okn_audio_lane_t lane[OKN_CHANNELS];
} okn_audio_engine_t;

/*
 * V13 deliberately keeps delay storage outside okn_audio_engine_t.
 * This lets the future exact BP1048P4 port place the arena using an
 * authenticated linker/memory map instead of baking a RAM-placement guess
 * into the portable core.
 */
size_t okn_audio_engine_required_delay_arena_samples(void);

okn_status_t okn_audio_engine_init(okn_audio_engine_t *engine, uint32_t sample_rate_hz);
okn_status_t okn_audio_engine_init_with_delay_arena(okn_audio_engine_t *engine,
                                                     uint32_t sample_rate_hz,
                                                     float *delay_arena,
                                                     size_t delay_arena_samples);
okn_status_t okn_audio_engine_bind_delay_arena(okn_audio_engine_t *engine,
                                                float *delay_arena,
                                                size_t delay_arena_samples);

okn_status_t okn_audio_engine_prepare(okn_audio_engine_t *engine,
                                      const okn_dsp_state_t *state,
                                      uint32_t revision);
void okn_audio_engine_reset_history(okn_audio_engine_t *engine);
void okn_audio_engine_process_frame(okn_audio_engine_t *engine,
                                    const float in[OKN_CHANNELS],
                                    float out[OKN_CHANNELS]);

#endif
