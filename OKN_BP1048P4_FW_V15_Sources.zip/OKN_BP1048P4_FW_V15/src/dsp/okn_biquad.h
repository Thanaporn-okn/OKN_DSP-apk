#ifndef OKN_BIQUAD_H
#define OKN_BIQUAD_H

#include "../core/okn_dsp.h"

typedef enum {
    OKN_BIQUAD_BYPASS = 0,
    OKN_BIQUAD_PEQ,
    OKN_BIQUAD_LOW_SHELF,
    OKN_BIQUAD_HIGH_SHELF,
    OKN_BIQUAD_NOTCH,
    OKN_BIQUAD_HPF,
    OKN_BIQUAD_LPF
} okn_biquad_kind_t;

typedef struct {
    float b0, b1, b2;
    float a1, a2;
} okn_biquad_coeff_t;

typedef struct {
    float z1, z2;
} okn_biquad_mem_t;

void okn_biquad_identity(okn_biquad_coeff_t *c);
void okn_biquad_reset(okn_biquad_mem_t *m);
okn_status_t okn_biquad_design(okn_biquad_kind_t kind, float sample_rate_hz,
                               float freq_hz, float gain_db, float q_or_slope,
                               okn_biquad_coeff_t *out);
float okn_biquad_process(const okn_biquad_coeff_t *c, okn_biquad_mem_t *m, float x);

#endif
