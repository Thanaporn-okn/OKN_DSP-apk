\
#include "okn_protocol.h"
#include <string.h>

static float read_f32_le(const uint8_t *p) {
    uint32_t u = ((uint32_t)p[0]) | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
    float f;
    memcpy(&f, &u, sizeof(f));
    return f;
}

static void write_u16_le(uint8_t *p, uint16_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); }
static void write_u32_le(uint8_t *p, uint32_t v) {
    p[0]=(uint8_t)v; p[1]=(uint8_t)(v>>8); p[2]=(uint8_t)(v>>16); p[3]=(uint8_t)(v>>24);
}
static void write_f32_le(uint8_t *p, float f) {
    uint32_t u;
    memcpy(&u, &f, sizeof(u));
    write_u32_le(p, u);
}

uint16_t okn_crc16_ccitt(const uint8_t *data, size_t len) {
    uint16_t crc = 0xFFFFu;
    for (size_t i = 0; i < len; ++i) {
        crc ^= (uint16_t)data[i] << 8;
        for (unsigned b = 0; b < 8; ++b)
            crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
    }
    return crc;
}

static okn_status_t validate_packet(const uint8_t *p, size_t len, uint8_t *cmd, uint16_t *plen) {
    if (!p || !cmd || !plen || len < 8u) return OKN_ERR_ARG;
    if (p[0] != OKN_PROTO_MAGIC0 || p[1] != OKN_PROTO_MAGIC1 || p[2] != OKN_PROTO_VERSION) return OKN_ERR_FORMAT;
    *cmd = p[3];
    *plen = (uint16_t)p[4] | ((uint16_t)p[5] << 8);
    if (*plen > OKN_PROTO_MAX_PAYLOAD || len != (size_t)(6u + *plen + 2u)) return OKN_ERR_FORMAT;
    const uint16_t got_crc = (uint16_t)p[len - 2] | ((uint16_t)p[len - 1] << 8);
    return okn_crc16_ccitt(p, len - 2u) == got_crc ? OKN_OK : OKN_ERR_CRC;
}

static okn_status_t make_packet(uint8_t cmd, const uint8_t *payload, uint16_t plen,
                                uint8_t *out, size_t cap, size_t *out_len) {
    if (!out || !out_len || (plen && !payload)) return OKN_ERR_ARG;
    *out_len = 0u;
    const size_t n = (size_t)plen + 8u;
    if (cap < n || plen > OKN_PROTO_MAX_PAYLOAD) return OKN_ERR_BUFFER;
    out[0]=OKN_PROTO_MAGIC0; out[1]=OKN_PROTO_MAGIC1; out[2]=OKN_PROTO_VERSION; out[3]=cmd;
    write_u16_le(&out[4], plen);
    if (plen) memcpy(&out[6], payload, plen);
    const uint16_t crc = okn_crc16_ccitt(out, 6u + plen);
    write_u16_le(&out[6u + plen], crc);
    *out_len = n;
    return OKN_OK;
}

static okn_status_t mutate(okn_controller_t *ctl, uint8_t cmd, const uint8_t *d, uint16_t plen) {
    unsigned ch;
    if (!ctl) return OKN_ERR_ARG;
    switch (cmd) {
        case OKN_CMD_SET_MASTER_GAIN:
            if (plen != 4u) return OKN_ERR_FORMAT;
            return okn_controller_set_master_gain(ctl, read_f32_le(d));
        case OKN_CMD_SET_CH_GAIN:
            if (plen != 5u) return OKN_ERR_FORMAT;
            return okn_controller_set_channel_gain(ctl, d[0], read_f32_le(&d[1]));
        case OKN_CMD_SET_CH_MUTE:
            if (plen != 2u || d[1] > 1u) return OKN_ERR_FORMAT;
            return okn_controller_set_channel_mute(ctl, d[0], d[1] != 0u);
        case OKN_CMD_SET_CH_PHASE:
            if (plen != 2u || d[1] > 1u) return OKN_ERR_FORMAT;
            return okn_controller_set_channel_phase(ctl, d[0], d[1] != 0u);
        case OKN_CMD_SET_CH_DELAY:
            if (plen != 5u) return OKN_ERR_FORMAT;
            return okn_controller_set_channel_delay(ctl, d[0], read_f32_le(&d[1]));
        case OKN_CMD_SET_PEQ:
            if (plen != 16u || d[2] > 1u) return OKN_ERR_FORMAT;
            ch = d[0];
            return okn_controller_set_peq_band(ctl, ch, d[1], d[2] != 0u,
                                               (okn_filter_type_t)d[3],
                                               read_f32_le(&d[4]), read_f32_le(&d[8]),
                                               read_f32_le(&d[12]));
        case OKN_CMD_SET_HPF:
        case OKN_CMD_SET_LPF:
            if (plen != 10u || d[1] > 1u) return OKN_ERR_FORMAT;
            ch = d[0];
            return (cmd == OKN_CMD_SET_HPF)
                ? okn_controller_set_hpf(ctl, ch, d[1] != 0u, read_f32_le(&d[2]), read_f32_le(&d[6]))
                : okn_controller_set_lpf(ctl, ch, d[1] != 0u, read_f32_le(&d[2]), read_f32_le(&d[6]));
        default:
            return OKN_ERR_UNSUPPORTED;
    }
}

static okn_status_t evaluate_command(okn_controller_t *ctl, uint8_t cmd,
                                     const uint8_t *d, uint16_t plen) {
    if (!ctl) return OKN_ERR_ARG;
    switch (cmd) {
        case OKN_CMD_PING:
        case OKN_CMD_GET_INFO:
        case OKN_CMD_GET_MASTER_STATE:
        case OKN_CMD_GET_CAPABILITIES:
            return plen == 0u ? OKN_OK : OKN_ERR_FORMAT;
        case OKN_CMD_GET_CHANNEL_STATE:
            return (plen == 1u && d[0] < OKN_CHANNELS) ? OKN_OK : OKN_ERR_FORMAT;
        case OKN_CMD_GET_PEQ_STATE:
            return (plen == 2u && d[0] < OKN_CHANNELS && d[1] < OKN_PEQ_BANDS)
                ? OKN_OK : OKN_ERR_FORMAT;
        default:
            return mutate(ctl, cmd, d, plen);
    }
}

okn_status_t okn_protocol_apply(okn_controller_t *ctl, const uint8_t *p, size_t len) {
    uint8_t cmd=0u; uint16_t plen=0u;
    const okn_status_t valid = validate_packet(p, len, &cmd, &plen);
    if (valid != OKN_OK) return valid;
    return evaluate_command(ctl, cmd, &p[6], plen);
}

static okn_status_t encode_ack(uint8_t cmd, okn_status_t command_status,
                               const okn_controller_t *ctl,
                               uint8_t *response, size_t cap, size_t *response_len) {
    uint8_t ack[7];
    ack[0] = cmd;
    write_u16_le(&ack[1], (uint16_t)(int16_t)command_status);
    write_u32_le(&ack[3], ctl ? ctl->revision : 0u);
    return make_packet(OKN_CMD_ACK, ack, sizeof(ack), response, cap, response_len);
}

okn_protocol_result_t okn_protocol_execute_ex(okn_controller_t *ctl,
                                              const uint8_t *p, size_t len,
                                              uint8_t *response, size_t cap) {
    okn_protocol_result_t result;
    result.transport_status = OKN_OK;
    result.command_status = OKN_OK;
    result.response_len = 0u;
    result.command_evaluated = false;

    if (!ctl || !response) {
        result.transport_status = OKN_ERR_ARG;
        return result;
    }

    uint8_t cmd=0u; uint16_t plen=0u;
    const okn_status_t valid = validate_packet(p, len, &cmd, &plen);
    if (valid != OKN_OK) {
        result.transport_status = valid;
        return result;
    }

    result.command_evaluated = true;
    result.command_status = evaluate_command(ctl, cmd, &p[6], plen);

    if (result.command_status != OKN_OK) {
        result.transport_status = encode_ack(cmd, result.command_status, ctl,
                                             response, cap, &result.response_len);
        return result;
    }

    if (cmd == OKN_CMD_GET_INFO) {
        uint8_t info[10];
        write_u16_le(&info[0], OKN_FW_VERSION);
        info[2] = OKN_PROTO_VERSION;
        info[3] = (uint8_t)OKN_CHANNELS;
        info[4] = (uint8_t)OKN_PEQ_BANDS;
        info[5] = 0u; /* hardware-ready flag: 0 until authentic HAL is integrated */
        write_u32_le(&info[6], ctl->revision);
        result.transport_status = make_packet(OKN_CMD_INFO, info, sizeof(info),
                                              response, cap, &result.response_len);
        return result;
    }

    if (cmd == OKN_CMD_GET_CAPABILITIES) {
        uint8_t d[OKN_CAPABILITIES_PAYLOAD_LEN];
        memset(d, 0, sizeof(d));
        d[0] = OKN_CAPABILITIES_SCHEMA;
        d[1] = (uint8_t)OKN_CHANNELS;
        d[2] = (uint8_t)OKN_PEQ_BANDS;
        d[3] = OKN_PROTO_VERSION;
        write_u16_le(&d[4], OKN_FW_VERSION);
        write_u16_le(&d[6], 50u); /* portable reference max delay, not a target HW claim */
        write_u16_le(&d[8], OKN_PROTO_MAX_PAYLOAD);
        write_u16_le(&d[10], (uint16_t)(OKN_PROTO_MAX_PAYLOAD + 8u));
        write_u32_le(&d[12], OKN_CAPABILITIES_FEATURES);
        d[16] = 1u; /* single outstanding request required */
        d[17] = 1u; /* retry cache depth */
        d[18] = 0u; /* hardware_ready: locked until exact target+board evidence */
        d[19] = 0u; /* hardware_flashable */
        d[20] = 0u; /* mobile_flashable */
        d[21] = 0u; /* reserved */
        write_u32_le(&d[22], ctl->revision);
        result.transport_status = make_packet(OKN_CMD_CAPABILITIES, d, sizeof(d),
                                              response, cap, &result.response_len);
        return result;
    }

    if (cmd == OKN_CMD_GET_MASTER_STATE) {
        uint8_t d[8];
        write_f32_le(&d[0], ctl->state.master_gain_db);
        write_u32_le(&d[4], ctl->revision);
        result.transport_status = make_packet(OKN_CMD_MASTER_STATE, d, sizeof(d),
                                              response, cap, &result.response_len);
        return result;
    }

    if (cmd == OKN_CMD_GET_CHANNEL_STATE) {
        const unsigned ch = p[6];
        const okn_channel_state_t *c = &ctl->state.ch[ch];
        uint8_t d[29];
        d[0] = (uint8_t)ch;
        write_f32_le(&d[1], c->gain_db);
        d[5] = c->mute ? 1u : 0u;
        d[6] = c->phase_invert ? 1u : 0u;
        write_f32_le(&d[7], c->delay_ms);
        d[11] = c->hpf.enabled ? 1u : 0u;
        write_f32_le(&d[12], c->hpf.freq_hz);
        write_f32_le(&d[16], c->hpf.q);
        d[20] = c->lpf.enabled ? 1u : 0u;
        write_f32_le(&d[21], c->lpf.freq_hz);
        write_f32_le(&d[25], c->lpf.q);
        result.transport_status = make_packet(OKN_CMD_CHANNEL_STATE, d, sizeof(d),
                                              response, cap, &result.response_len);
        return result;
    }

    if (cmd == OKN_CMD_GET_PEQ_STATE) {
        const unsigned ch = p[6], band = p[7];
        const okn_peq_band_t *q = &ctl->state.ch[ch].peq[band];
        uint8_t d[16];
        d[0] = (uint8_t)ch;
        d[1] = (uint8_t)band;
        d[2] = q->enabled ? 1u : 0u;
        d[3] = (uint8_t)q->type;
        write_f32_le(&d[4], q->freq_hz);
        write_f32_le(&d[8], q->gain_db);
        write_f32_le(&d[12], q->q);
        result.transport_status = make_packet(OKN_CMD_PEQ_STATE, d, sizeof(d),
                                              response, cap, &result.response_len);
        return result;
    }

    result.transport_status = encode_ack(cmd, result.command_status, ctl,
                                         response, cap, &result.response_len);
    return result;
}

okn_status_t okn_protocol_execute(okn_controller_t *ctl, const uint8_t *p, size_t len,
                                  uint8_t *response, size_t cap, size_t *response_len) {
    if (!response_len) return OKN_ERR_ARG;
    const okn_protocol_result_t result = okn_protocol_execute_ex(ctl, p, len, response, cap);
    *response_len = result.response_len;
    return result.transport_status;
}
