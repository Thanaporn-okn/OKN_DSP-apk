#include "okn_controller.h"
#include <string.h>

void okn_controller_init(okn_controller_t *ctl) {
    if (!ctl) return;
    memset(ctl, 0, sizeof(*ctl));
    okn_dsp_init(&ctl->state);
}

void okn_controller_mark_all_dirty(okn_controller_t *ctl) {
    if (!ctl) return;
    ctl->master_dirty = true;
    ctl->channel_dirty_mask = (uint8_t)((1u << OKN_CHANNELS) - 1u);
}

void okn_controller_clear_dirty(okn_controller_t *ctl) {
    if (!ctl) return;
    ctl->master_dirty = false;
    ctl->channel_dirty_mask = 0u;
}

void okn_controller_touch_master(okn_controller_t *ctl) {
    if (!ctl) return;
    ctl->master_dirty = true;
    ++ctl->revision;
}

void okn_controller_touch_channel(okn_controller_t *ctl, unsigned channel) {
    if (!ctl || channel >= OKN_CHANNELS) return;
    ctl->channel_dirty_mask |= (uint8_t)(1u << channel);
    ++ctl->revision;
}

okn_status_t okn_controller_set_master_gain(okn_controller_t *ctl, float db) {
    if (!ctl) return OKN_ERR_ARG;
    const okn_status_t rc = okn_set_master_gain(&ctl->state, db);
    if (rc == OKN_OK) okn_controller_touch_master(ctl);
    return rc;
}

okn_status_t okn_controller_set_channel_gain(okn_controller_t *ctl, unsigned channel, float db) {
    if (!ctl) return OKN_ERR_ARG;
    const okn_status_t rc = okn_set_channel_gain(&ctl->state, channel, db);
    if (rc == OKN_OK) okn_controller_touch_channel(ctl, channel);
    return rc;
}

okn_status_t okn_controller_set_channel_mute(okn_controller_t *ctl, unsigned channel, bool mute) {
    if (!ctl) return OKN_ERR_ARG;
    const okn_status_t rc = okn_set_channel_mute(&ctl->state, channel, mute);
    if (rc == OKN_OK) okn_controller_touch_channel(ctl, channel);
    return rc;
}

okn_status_t okn_controller_set_channel_phase(okn_controller_t *ctl, unsigned channel, bool invert) {
    if (!ctl) return OKN_ERR_ARG;
    const okn_status_t rc = okn_set_channel_phase(&ctl->state, channel, invert);
    if (rc == OKN_OK) okn_controller_touch_channel(ctl, channel);
    return rc;
}

okn_status_t okn_controller_set_channel_delay(okn_controller_t *ctl, unsigned channel, float ms) {
    if (!ctl) return OKN_ERR_ARG;
    const okn_status_t rc = okn_set_channel_delay(&ctl->state, channel, ms);
    if (rc == OKN_OK) okn_controller_touch_channel(ctl, channel);
    return rc;
}

okn_status_t okn_controller_set_peq_band(okn_controller_t *ctl, unsigned channel, unsigned band,
                                         bool enabled, okn_filter_type_t type,
                                         float freq_hz, float gain_db, float q) {
    if (!ctl) return OKN_ERR_ARG;
    const okn_status_t rc = okn_set_peq_band(&ctl->state, channel, band, enabled, type,
                                             freq_hz, gain_db, q);
    if (rc == OKN_OK) okn_controller_touch_channel(ctl, channel);
    return rc;
}

okn_status_t okn_controller_set_hpf(okn_controller_t *ctl, unsigned channel, bool enabled,
                                    float freq_hz, float q) {
    if (!ctl) return OKN_ERR_ARG;
    const okn_status_t rc = okn_set_hpf(&ctl->state, channel, enabled, freq_hz, q);
    if (rc == OKN_OK) okn_controller_touch_channel(ctl, channel);
    return rc;
}

okn_status_t okn_controller_set_lpf(okn_controller_t *ctl, unsigned channel, bool enabled,
                                    float freq_hz, float q) {
    if (!ctl) return OKN_ERR_ARG;
    const okn_status_t rc = okn_set_lpf(&ctl->state, channel, enabled, freq_hz, q);
    if (rc == OKN_OK) okn_controller_touch_channel(ctl, channel);
    return rc;
}
