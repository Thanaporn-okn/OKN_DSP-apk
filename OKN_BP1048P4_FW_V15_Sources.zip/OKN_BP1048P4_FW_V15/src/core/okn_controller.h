#ifndef OKN_CONTROLLER_H
#define OKN_CONTROLLER_H

#include "okn_dsp.h"
#include <stdbool.h>
#include <stdint.h>

typedef struct {
    okn_dsp_state_t state;
    uint32_t revision;
    bool master_dirty;
    uint8_t channel_dirty_mask;
} okn_controller_t;

void okn_controller_init(okn_controller_t *ctl);
void okn_controller_mark_all_dirty(okn_controller_t *ctl);
void okn_controller_clear_dirty(okn_controller_t *ctl);
void okn_controller_touch_master(okn_controller_t *ctl);
void okn_controller_touch_channel(okn_controller_t *ctl, unsigned channel);

/*
 * V13 mutation boundary.
 * These APIs are the only mutation entry points used by the control protocol.
 * A successful mutation updates DSP state + dirty state + revision together.
 * Rejected values leave state/dirty/revision unchanged.
 *
 * Low-level okn_set_* DSP functions remain available as portable primitives
 * for initialization/tests, but protocol/runtime callers should prefer these.
 */
okn_status_t okn_controller_set_master_gain(okn_controller_t *ctl, float db);
okn_status_t okn_controller_set_channel_gain(okn_controller_t *ctl, unsigned channel, float db);
okn_status_t okn_controller_set_channel_mute(okn_controller_t *ctl, unsigned channel, bool mute);
okn_status_t okn_controller_set_channel_phase(okn_controller_t *ctl, unsigned channel, bool invert);
okn_status_t okn_controller_set_channel_delay(okn_controller_t *ctl, unsigned channel, float ms);
okn_status_t okn_controller_set_peq_band(okn_controller_t *ctl, unsigned channel, unsigned band,
                                         bool enabled, okn_filter_type_t type,
                                         float freq_hz, float gain_db, float q);
okn_status_t okn_controller_set_hpf(okn_controller_t *ctl, unsigned channel, bool enabled,
                                    float freq_hz, float q);
okn_status_t okn_controller_set_lpf(okn_controller_t *ctl, unsigned channel, bool enabled,
                                    float freq_hz, float q);

#endif
