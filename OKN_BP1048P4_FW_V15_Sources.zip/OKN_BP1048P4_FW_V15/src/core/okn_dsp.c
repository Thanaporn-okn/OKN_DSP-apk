#include "okn_dsp.h"
#include <math.h>
#include <string.h>

static int finitef_ok(float x) { return isfinite(x); }
static int valid_channel(unsigned channel) { return channel < OKN_CHANNELS; }
static int valid_band(unsigned band) { return band < OKN_PEQ_BANDS; }
static int in_range(float x, float lo, float hi) { return finitef_ok(x) && x >= lo && x <= hi; }
static int valid_filter(okn_filter_type_t type) {
    return type >= OKN_FILTER_BYPASS && type <= OKN_FILTER_NOTCH;
}

void okn_dsp_init(okn_dsp_state_t *state) {
    if (!state) return;
    memset(state, 0, sizeof(*state));
    for (unsigned c = 0; c < OKN_CHANNELS; ++c) {
        state->ch[c].hpf.freq_hz = 20.0f;
        state->ch[c].hpf.q = 0.70710678f;
        state->ch[c].lpf.freq_hz = 20000.0f;
        state->ch[c].lpf.q = 0.70710678f;
        for (unsigned b = 0; b < OKN_PEQ_BANDS; ++b) {
            state->ch[c].peq[b].type = OKN_FILTER_PEQ;
            state->ch[c].peq[b].freq_hz = 1000.0f;
            state->ch[c].peq[b].q = 1.0f;
        }
    }
}

okn_status_t okn_set_master_gain(okn_dsp_state_t *state, float db) {
    if (!state) return OKN_ERR_ARG;
    if (!in_range(db, OKN_GAIN_MIN_DB, OKN_GAIN_MAX_DB)) return OKN_ERR_RANGE;
    state->master_gain_db = db;
    return OKN_OK;
}

okn_status_t okn_set_channel_gain(okn_dsp_state_t *state, unsigned channel, float db) {
    if (!state || !valid_channel(channel)) return OKN_ERR_ARG;
    if (!in_range(db, OKN_GAIN_MIN_DB, OKN_GAIN_MAX_DB)) return OKN_ERR_RANGE;
    state->ch[channel].gain_db = db;
    return OKN_OK;
}

okn_status_t okn_set_channel_mute(okn_dsp_state_t *state, unsigned channel, bool mute) {
    if (!state || !valid_channel(channel)) return OKN_ERR_ARG;
    state->ch[channel].mute = mute;
    return OKN_OK;
}

okn_status_t okn_set_channel_phase(okn_dsp_state_t *state, unsigned channel, bool invert) {
    if (!state || !valid_channel(channel)) return OKN_ERR_ARG;
    state->ch[channel].phase_invert = invert;
    return OKN_OK;
}

okn_status_t okn_set_channel_delay(okn_dsp_state_t *state, unsigned channel, float ms) {
    if (!state || !valid_channel(channel)) return OKN_ERR_ARG;
    if (!in_range(ms, 0.0f, OKN_DELAY_MAX_MS)) return OKN_ERR_RANGE;
    state->ch[channel].delay_ms = ms;
    return OKN_OK;
}

okn_status_t okn_set_peq_band(okn_dsp_state_t *state, unsigned channel, unsigned band,
                              bool enabled, okn_filter_type_t type,
                              float freq_hz, float gain_db, float q) {
    if (!state || !valid_channel(channel) || !valid_band(band)) return OKN_ERR_ARG;
    if (!valid_filter(type)) return OKN_ERR_ARG;
    if (!in_range(freq_hz, OKN_FREQ_MIN_HZ, OKN_FREQ_MAX_HZ) ||
        !in_range(gain_db, OKN_PEQ_GAIN_MIN_DB, OKN_PEQ_GAIN_MAX_DB) ||
        !in_range(q, OKN_Q_MIN, OKN_Q_MAX)) return OKN_ERR_RANGE;
    okn_peq_band_t *p = &state->ch[channel].peq[band];
    p->enabled = enabled;
    p->type = type;
    p->freq_hz = freq_hz;
    p->gain_db = gain_db;
    p->q = q;
    return OKN_OK;
}

static okn_status_t set_xover(okn_dsp_state_t *state, unsigned channel, bool enabled,
                              float freq_hz, float q, bool highpass) {
    if (!state || !valid_channel(channel)) return OKN_ERR_ARG;
    if (!in_range(freq_hz, OKN_FREQ_MIN_HZ, OKN_FREQ_MAX_HZ) ||
        !in_range(q, OKN_Q_MIN, OKN_Q_MAX)) return OKN_ERR_RANGE;
    okn_crossover_t *x = highpass ? &state->ch[channel].hpf : &state->ch[channel].lpf;
    x->enabled = enabled;
    x->freq_hz = freq_hz;
    x->q = q;
    return OKN_OK;
}

okn_status_t okn_set_hpf(okn_dsp_state_t *state, unsigned channel, bool enabled, float freq_hz, float q) {
    return set_xover(state, channel, enabled, freq_hz, q, true);
}

okn_status_t okn_set_lpf(okn_dsp_state_t *state, unsigned channel, bool enabled, float freq_hz, float q) {
    return set_xover(state, channel, enabled, freq_hz, q, false);
}

okn_status_t okn_validate_state(const okn_dsp_state_t *state) {
    if (!state) return OKN_ERR_ARG;
    if (!in_range(state->master_gain_db, OKN_GAIN_MIN_DB, OKN_GAIN_MAX_DB)) return OKN_ERR_RANGE;
    for (unsigned c = 0; c < OKN_CHANNELS; ++c) {
        const okn_channel_state_t *ch = &state->ch[c];
        if (!in_range(ch->gain_db, OKN_GAIN_MIN_DB, OKN_GAIN_MAX_DB) ||
            !in_range(ch->delay_ms, 0.0f, OKN_DELAY_MAX_MS)) return OKN_ERR_RANGE;
        if (!in_range(ch->hpf.freq_hz, OKN_FREQ_MIN_HZ, OKN_FREQ_MAX_HZ) ||
            !in_range(ch->hpf.q, OKN_Q_MIN, OKN_Q_MAX) ||
            !in_range(ch->lpf.freq_hz, OKN_FREQ_MIN_HZ, OKN_FREQ_MAX_HZ) ||
            !in_range(ch->lpf.q, OKN_Q_MIN, OKN_Q_MAX)) return OKN_ERR_RANGE;
        for (unsigned b = 0; b < OKN_PEQ_BANDS; ++b) {
            const okn_peq_band_t *p = &ch->peq[b];
            if (!valid_filter(p->type) ||
                !in_range(p->freq_hz, OKN_FREQ_MIN_HZ, OKN_FREQ_MAX_HZ) ||
                !in_range(p->gain_db, OKN_PEQ_GAIN_MIN_DB, OKN_PEQ_GAIN_MAX_DB) ||
                !in_range(p->q, OKN_Q_MIN, OKN_Q_MAX)) return OKN_ERR_RANGE;
        }
    }
    return OKN_OK;
}

float okn_db_to_linear(float db) { return powf(10.0f, db / 20.0f); }

float okn_effective_channel_linear_gain(const okn_dsp_state_t *state, unsigned channel) {
    if (!state || !valid_channel(channel)) return 0.0f;
    const okn_channel_state_t *ch = &state->ch[channel];
    if (ch->mute) return 0.0f;
    const float g = okn_db_to_linear(state->master_gain_db + ch->gain_db);
    return ch->phase_invert ? -g : g;
}
