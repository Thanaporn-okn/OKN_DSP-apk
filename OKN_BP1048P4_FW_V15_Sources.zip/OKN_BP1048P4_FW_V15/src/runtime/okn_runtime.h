#ifndef OKN_RUNTIME_H
#define OKN_RUNTIME_H

#include "../core/okn_controller.h"
#include "../hal/bp1048p4_hal.h"
#include "../hal/bp1048p4_port_contract.h"
#include "../persist/okn_persistence.h"

typedef enum {
    OKN_BOOT_RESET = 0,
    OKN_BOOT_STATE_READY,
    OKN_BOOT_PLATFORM_READY,
    OKN_BOOT_FAILSAFE_MUTED,
    OKN_BOOT_AUDIO_STARTED,
    OKN_BOOT_STATE_APPLIED,
    OKN_BOOT_RUNNING,
    OKN_BOOT_FAILED
} okn_boot_stage_t;

typedef struct {
    okn_boot_stage_t stage;
    okn_status_t restore_status;
    uint32_t generation;
    unsigned slot;
    int restored;
    int failsafe_mute_asserted;
} okn_boot_report_t;

/* Apply only dirty state. A failed write remains dirty so callers can fail closed
 * or retry only after transport/platform health is re-established. */
okn_status_t okn_runtime_apply_dirty(okn_controller_t *ctl, const bp1048p4_hal_t *hal);

/* Boot starts from safe defaults. A valid persisted image may replace defaults.
 * Invalid/corrupt/absent storage never mutates the controller away from defaults. */
okn_status_t okn_runtime_restore_or_defaults(okn_controller_t *ctl,
                                             const okn_storage_io_t *storage,
                                             uint32_t *generation,
                                             unsigned *slot,
                                             int *restored);
okn_status_t okn_runtime_save_verified(const okn_controller_t *ctl,
                                       const okn_storage_io_t *storage,
                                       uint32_t *generation,
                                       unsigned *slot);

/* Verified-hardware boot gate. It refuses to touch a target until the exact P4
 * and board port contract is marked verified. Once enabled, outputs remain under
 * a safety mute through audio start and full-state apply. Any failure after mute
 * assertion re-asserts mute before returning. */
okn_status_t okn_runtime_boot_safe(okn_controller_t *ctl,
                                   const bp1048p4_hal_t *hal,
                                   const bp1048p4_port_evidence_t *evidence,
                                   const okn_storage_io_t *storage,
                                   okn_boot_report_t *report);

#endif
