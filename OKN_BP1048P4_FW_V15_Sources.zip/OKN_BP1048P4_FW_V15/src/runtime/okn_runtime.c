#include "okn_runtime.h"
#include <string.h>

static okn_status_t hal_status(int rc) {
    if (rc == OKN_OK) return OKN_OK;
    return rc == OKN_ERR_HAL_LOCKED ? OKN_ERR_HAL_LOCKED : OKN_ERR_HAL;
}

okn_status_t okn_runtime_apply_dirty(okn_controller_t *ctl, const bp1048p4_hal_t *hal) {
    if (!ctl || !hal || !hal->apply_master_gain || !hal->apply_channel_state) return OKN_ERR_ARG;
    if (okn_validate_state(&ctl->state) != OKN_OK) return OKN_ERR_RANGE;

    if (ctl->master_dirty) {
        const okn_status_t rc = hal_status(hal->apply_master_gain(ctl->state.master_gain_db));
        if (rc != OKN_OK) return rc;
        ctl->master_dirty = false;
    }

    for (unsigned c = 0; c < OKN_CHANNELS; ++c) {
        const uint8_t bit = (uint8_t)(1u << c);
        if ((ctl->channel_dirty_mask & bit) == 0u) continue;
        const okn_status_t rc = hal_status(hal->apply_channel_state(c, &ctl->state.ch[c]));
        if (rc != OKN_OK) return rc;
        ctl->channel_dirty_mask &= (uint8_t)~bit;
    }
    return OKN_OK;
}

okn_status_t okn_runtime_restore_or_defaults(okn_controller_t *ctl,
                                             const okn_storage_io_t *storage,
                                             uint32_t *generation,
                                             unsigned *slot,
                                             int *restored) {
    if (!ctl || !storage || !generation || !slot || !restored) return OKN_ERR_ARG;
    okn_controller_init(ctl);
    *generation=0u; *slot=0u; *restored=0;

    okn_dsp_state_t loaded;
    uint32_t g=0u; unsigned s=0u;
    const okn_status_t rc=okn_persist_load_latest(storage,&loaded,&g,&s);
    if (rc != OKN_OK) return rc;

    ctl->state=loaded;
    ctl->revision=g;
    okn_controller_mark_all_dirty(ctl);
    *generation=g; *slot=s; *restored=1;
    return OKN_OK;
}

okn_status_t okn_runtime_save_verified(const okn_controller_t *ctl,
                                       const okn_storage_io_t *storage,
                                       uint32_t *generation,
                                       unsigned *slot) {
    if (!ctl || !storage || !generation || !slot) return OKN_ERR_ARG;
    if (okn_validate_state(&ctl->state) != OKN_OK) return OKN_ERR_RANGE;
    return okn_persist_save_next(storage,&ctl->state,generation,slot);
}

okn_status_t okn_runtime_boot_safe(okn_controller_t *ctl,
                                   const bp1048p4_hal_t *hal,
                                   const bp1048p4_port_evidence_t *evidence,
                                   const okn_storage_io_t *storage,
                                   okn_boot_report_t *report) {
    if (!ctl || !hal || !evidence || !report) return OKN_ERR_ARG;
    memset(report, 0, sizeof(*report));
    report->stage = OKN_BOOT_RESET;

    okn_status_t rc = bp1048p4_hal_validate_contract(hal, evidence);
    if (rc != OKN_OK) {
        report->stage = OKN_BOOT_FAILED;
        return rc;
    }

    okn_controller_init(ctl);
    report->restore_status = OKN_OK;
    if (storage) {
        uint32_t generation=0u; unsigned slot=0u; int restored=0;
        rc = okn_runtime_restore_or_defaults(ctl, storage, &generation, &slot, &restored);
        report->restore_status = rc;
        report->generation = generation;
        report->slot = slot;
        report->restored = restored;
        if (rc != OKN_OK) {
            /* restore_or_defaults already leaves ctl at safe project defaults */
            okn_controller_init(ctl);
        }
    }
    okn_controller_mark_all_dirty(ctl);
    report->stage = OKN_BOOT_STATE_READY;

    rc = hal_status(hal->platform_init());
    if (rc != OKN_OK) { report->stage = OKN_BOOT_FAILED; return rc; }
    report->stage = OKN_BOOT_PLATFORM_READY;

    rc = hal_status(hal->set_output_safety_mute(true));
    if (rc != OKN_OK) { report->stage = OKN_BOOT_FAILED; return rc; }
    report->failsafe_mute_asserted = 1;
    report->stage = OKN_BOOT_FAILSAFE_MUTED;

    rc = hal_status(hal->audio_start());
    if (rc != OKN_OK) goto fail_muted;
    report->stage = OKN_BOOT_AUDIO_STARTED;

    rc = okn_runtime_apply_dirty(ctl, hal);
    if (rc != OKN_OK) goto fail_muted;
    report->stage = OKN_BOOT_STATE_APPLIED;

    rc = hal_status(hal->set_output_safety_mute(false));
    if (rc != OKN_OK) goto fail_muted;
    report->failsafe_mute_asserted = 0;
    report->stage = OKN_BOOT_RUNNING;
    return OKN_OK;

fail_muted:
    (void)hal->set_output_safety_mute(true);
    report->failsafe_mute_asserted = 1;
    report->stage = OKN_BOOT_FAILED;
    return rc;
}
