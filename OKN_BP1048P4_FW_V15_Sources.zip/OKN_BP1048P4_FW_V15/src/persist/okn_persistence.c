#include "okn_persistence.h"
#include <string.h>

#define M0 ((uint8_t)'O')
#define M1 ((uint8_t)'K')
#define M2 ((uint8_t)'N')
#define M3 ((uint8_t)'S')

static void wr16(uint8_t *p, uint16_t v) {
    p[0]=(uint8_t)v; p[1]=(uint8_t)(v>>8);
}
static void wr32(uint8_t *p, uint32_t v) {
    p[0]=(uint8_t)v; p[1]=(uint8_t)(v>>8); p[2]=(uint8_t)(v>>16); p[3]=(uint8_t)(v>>24);
}
static uint16_t rd16(const uint8_t *p) {
    return (uint16_t)p[0] | ((uint16_t)p[1] << 8);
}
static uint32_t rd32(const uint8_t *p) {
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}
static void wrf(uint8_t *p, float v) {
    uint32_t u;
    memcpy(&u, &v, sizeof(u));
    wr32(p, u);
}
static float rdf(const uint8_t *p) {
    const uint32_t u = rd32(p);
    float v;
    memcpy(&v, &u, sizeof(v));
    return v;
}

uint32_t okn_crc32_ieee(const uint8_t *data, size_t len) {
    uint32_t crc = 0xFFFFFFFFu;
    if (!data && len) return 0u;
    for (size_t i=0; i<len; ++i) {
        crc ^= data[i];
        for (unsigned b=0; b<8u; ++b)
            crc = (crc & 1u) ? ((crc >> 1) ^ 0xEDB88320u) : (crc >> 1);
    }
    return ~crc;
}

static size_t encode_payload(const okn_dsp_state_t *s, uint8_t *p) {
    size_t n=0u;
    wrf(&p[n], s->master_gain_db); n+=4u;
    for (unsigned c=0; c<OKN_CHANNELS; ++c) {
        const okn_channel_state_t *ch=&s->ch[c];
        wrf(&p[n], ch->gain_db); n+=4u;
        p[n++]=ch->mute ? 1u : 0u;
        p[n++]=ch->phase_invert ? 1u : 0u;
        wrf(&p[n], ch->delay_ms); n+=4u;

        p[n++]=ch->hpf.enabled ? 1u : 0u;
        wrf(&p[n], ch->hpf.freq_hz); n+=4u;
        wrf(&p[n], ch->hpf.q); n+=4u;

        p[n++]=ch->lpf.enabled ? 1u : 0u;
        wrf(&p[n], ch->lpf.freq_hz); n+=4u;
        wrf(&p[n], ch->lpf.q); n+=4u;

        for (unsigned b=0; b<OKN_PEQ_BANDS; ++b) {
            const okn_peq_band_t *q=&ch->peq[b];
            p[n++]=q->enabled ? 1u : 0u;
            p[n++]=(uint8_t)q->type;
            wrf(&p[n], q->freq_hz); n+=4u;
            wrf(&p[n], q->gain_db); n+=4u;
            wrf(&p[n], q->q); n+=4u;
        }
    }
    return n;
}

static okn_status_t decode_payload(const uint8_t *p, size_t len, okn_dsp_state_t *s) {
    if (!p || !s || len != OKN_PERSIST_PAYLOAD_SIZE) return OKN_ERR_FORMAT;
    size_t n=0u;
    memset(s, 0, sizeof(*s));
    s->master_gain_db=rdf(&p[n]); n+=4u;
    for (unsigned c=0; c<OKN_CHANNELS; ++c) {
        okn_channel_state_t *ch=&s->ch[c];
        ch->gain_db=rdf(&p[n]); n+=4u;
        if (p[n] > 1u || p[n+1u] > 1u) return OKN_ERR_FORMAT;
        ch->mute=p[n++] != 0u;
        ch->phase_invert=p[n++] != 0u;
        ch->delay_ms=rdf(&p[n]); n+=4u;

        if (p[n] > 1u) return OKN_ERR_FORMAT;
        ch->hpf.enabled=p[n++] != 0u;
        ch->hpf.freq_hz=rdf(&p[n]); n+=4u;
        ch->hpf.q=rdf(&p[n]); n+=4u;

        if (p[n] > 1u) return OKN_ERR_FORMAT;
        ch->lpf.enabled=p[n++] != 0u;
        ch->lpf.freq_hz=rdf(&p[n]); n+=4u;
        ch->lpf.q=rdf(&p[n]); n+=4u;

        for (unsigned b=0; b<OKN_PEQ_BANDS; ++b) {
            okn_peq_band_t *q=&ch->peq[b];
            if (p[n] > 1u) return OKN_ERR_FORMAT;
            q->enabled=p[n++] != 0u;
            q->type=(okn_filter_type_t)p[n++];
            q->freq_hz=rdf(&p[n]); n+=4u;
            q->gain_db=rdf(&p[n]); n+=4u;
            q->q=rdf(&p[n]); n+=4u;
        }
    }
    if (n != len) return OKN_ERR_FORMAT;
    return okn_validate_state(s);
}

okn_status_t okn_persist_encode(const okn_dsp_state_t *state, uint32_t generation,
                                uint8_t *out, size_t cap, size_t *out_len) {
    if (!state || !out || !out_len) return OKN_ERR_ARG;
    if (cap < OKN_PERSIST_IMAGE_SIZE) return OKN_ERR_BUFFER;
    if (okn_validate_state(state) != OKN_OK) return OKN_ERR_RANGE;

    out[0]=M0; out[1]=M1; out[2]=M2; out[3]=M3;
    wr16(&out[4], OKN_PERSIST_SCHEMA);
    wr16(&out[6], 0u);
    wr32(&out[8], generation);
    wr32(&out[12], OKN_PERSIST_PAYLOAD_SIZE);
    const size_t n=encode_payload(state, &out[OKN_PERSIST_HEADER_SIZE]);
    if (n != OKN_PERSIST_PAYLOAD_SIZE) return OKN_ERR_FORMAT;
    wr32(&out[16], okn_crc32_ieee(&out[OKN_PERSIST_HEADER_SIZE], n));
    *out_len=OKN_PERSIST_IMAGE_SIZE;
    return OKN_OK;
}

okn_status_t okn_persist_decode(const uint8_t *image, size_t len,
                                okn_dsp_state_t *state, uint32_t *generation) {
    if (!image || !state || !generation) return OKN_ERR_ARG;
    if (len != OKN_PERSIST_IMAGE_SIZE) return OKN_ERR_FORMAT;
    if (image[0]!=M0 || image[1]!=M1 || image[2]!=M2 || image[3]!=M3) return OKN_ERR_STATE_SCHEMA;
    if (rd16(&image[4]) != OKN_PERSIST_SCHEMA || rd16(&image[6]) != 0u) return OKN_ERR_STATE_SCHEMA;
    if (rd32(&image[12]) != OKN_PERSIST_PAYLOAD_SIZE) return OKN_ERR_STATE_SCHEMA;
    const uint32_t expected=rd32(&image[16]);
    const uint32_t actual=okn_crc32_ieee(&image[OKN_PERSIST_HEADER_SIZE], OKN_PERSIST_PAYLOAD_SIZE);
    if (expected != actual) return OKN_ERR_STATE_CRC;

    okn_dsp_state_t tmp;
    const okn_status_t rc=decode_payload(&image[OKN_PERSIST_HEADER_SIZE], OKN_PERSIST_PAYLOAD_SIZE, &tmp);
    if (rc != OKN_OK) return rc;
    *state=tmp;
    *generation=rd32(&image[8]);
    return OKN_OK;
}

static int generation_newer(uint32_t a, uint32_t b) {
    return (int32_t)(a - b) > 0;
}

okn_status_t okn_persist_load_latest(const okn_storage_io_t *io,
                                     okn_dsp_state_t *state,
                                     uint32_t *generation,
                                     unsigned *slot) {
    if (!io || !io->read_slot || !state || !generation || !slot) return OKN_ERR_ARG;
    uint8_t buf[OKN_PERSIST_IMAGE_SIZE];
    okn_dsp_state_t candidate[OKN_PERSIST_SLOT_COUNT];
    uint32_t gen[OKN_PERSIST_SLOT_COUNT]={0u,0u};
    int valid[OKN_PERSIST_SLOT_COUNT]={0,0};

    for (unsigned s=0; s<OKN_PERSIST_SLOT_COUNT; ++s) {
        size_t n=0u;
        if (io->read_slot(s, buf, sizeof(buf), &n) != OKN_OK) continue;
        uint32_t g=0u;
        if (okn_persist_decode(buf, n, &candidate[s], &g) == OKN_OK) {
            valid[s]=1; gen[s]=g;
        }
    }
    if (!valid[0] && !valid[1]) return OKN_ERR_STORAGE;
    unsigned chosen;
    if (valid[0] && valid[1]) chosen=generation_newer(gen[1],gen[0]) ? 1u : 0u;
    else chosen=valid[1] ? 1u : 0u;

    *state=candidate[chosen];
    *generation=gen[chosen];
    *slot=chosen;
    return OKN_OK;
}

okn_status_t okn_persist_save_next(const okn_storage_io_t *io,
                                   const okn_dsp_state_t *state,
                                   uint32_t *generation,
                                   unsigned *slot) {
    if (!io || !io->read_slot || !io->write_slot || !state || !generation || !slot) return OKN_ERR_ARG;
    if (okn_validate_state(state) != OKN_OK) return OKN_ERR_RANGE;

    okn_dsp_state_t prev;
    uint32_t oldgen=0u;
    unsigned oldslot=1u;
    const okn_status_t lr=okn_persist_load_latest(io,&prev,&oldgen,&oldslot);
    if (lr != OKN_OK && lr != OKN_ERR_STORAGE) return lr;

    const uint32_t newgen=(lr == OKN_OK) ? (oldgen + 1u) : 1u;
    const unsigned target=(lr == OKN_OK) ? (oldslot ^ 1u) : 0u;

    uint8_t image[OKN_PERSIST_IMAGE_SIZE];
    size_t image_len=0u;
    okn_status_t rc=okn_persist_encode(state,newgen,image,sizeof(image),&image_len);
    if (rc != OKN_OK) return rc;
    if (io->write_slot(target,image,image_len) != OKN_OK) return OKN_ERR_STORAGE;

    uint8_t verify[OKN_PERSIST_IMAGE_SIZE];
    size_t verify_len=0u;
    if (io->read_slot(target,verify,sizeof(verify),&verify_len) != OKN_OK) return OKN_ERR_STORAGE;
    if (verify_len != image_len || memcmp(verify,image,image_len) != 0) return OKN_ERR_STORAGE;

    okn_dsp_state_t check;
    uint32_t checkgen=0u;
    rc=okn_persist_decode(verify,verify_len,&check,&checkgen);
    if (rc != OKN_OK || checkgen != newgen) return OKN_ERR_STORAGE;

    *generation=newgen;
    *slot=target;
    return OKN_OK;
}
