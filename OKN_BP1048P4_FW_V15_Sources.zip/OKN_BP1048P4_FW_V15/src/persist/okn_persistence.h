#ifndef OKN_PERSISTENCE_H
#define OKN_PERSISTENCE_H

#include "../core/okn_dsp.h"
#include <stddef.h>
#include <stdint.h>

#define OKN_PERSIST_SCHEMA 1u
#define OKN_PERSIST_SLOT_COUNT 2u
#define OKN_PERSIST_HEADER_SIZE 20u
#define OKN_PERSIST_PAYLOAD_SIZE 1670u
#define OKN_PERSIST_IMAGE_SIZE (OKN_PERSIST_HEADER_SIZE + OKN_PERSIST_PAYLOAD_SIZE)

typedef struct {
    int (*read_slot)(unsigned slot, uint8_t *out, size_t cap, size_t *out_len);
    int (*write_slot)(unsigned slot, const uint8_t *data, size_t len);
} okn_storage_io_t;

uint32_t okn_crc32_ieee(const uint8_t *data, size_t len);

okn_status_t okn_persist_encode(const okn_dsp_state_t *state, uint32_t generation,
                                uint8_t *out, size_t cap, size_t *out_len);
okn_status_t okn_persist_decode(const uint8_t *image, size_t len,
                                okn_dsp_state_t *state, uint32_t *generation);

okn_status_t okn_persist_load_latest(const okn_storage_io_t *io,
                                     okn_dsp_state_t *state,
                                     uint32_t *generation,
                                     unsigned *slot);
okn_status_t okn_persist_save_next(const okn_storage_io_t *io,
                                   const okn_dsp_state_t *state,
                                   uint32_t *generation,
                                   unsigned *slot);

#endif
