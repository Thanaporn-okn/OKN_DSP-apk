#include "okn_stream.h"
#include <string.h>

static void drop_prefix(okn_stream_t *s, size_t n) {
    if (n >= s->len) {
        s->dropped_bytes += (uint32_t)s->len;
        s->len = 0u;
        return;
    }
    memmove(s->buf, s->buf + n, s->len - n);
    s->len -= n;
    s->dropped_bytes += (uint32_t)n;
}

void okn_stream_init(okn_stream_t *s) {
    if (!s) return;
    memset(s, 0, sizeof(*s));
}

void okn_stream_reset_partial(okn_stream_t *s) {
    if (!s) return;
    if (s->len != 0u) drop_prefix(s, s->len);
    s->partial_idle_ms = 0u;
}

okn_status_t okn_stream_note_idle(okn_stream_t *s,
                                  uint32_t elapsed_ms,
                                  uint32_t timeout_ms) {
    if (!s || timeout_ms == 0u) return OKN_ERR_ARG;
    if (s->len == 0u) {
        s->partial_idle_ms = 0u;
        return OKN_OK;
    }

    const uint64_t total = (uint64_t)s->partial_idle_ms + (uint64_t)elapsed_ms;
    if (total >= (uint64_t)timeout_ms) {
        okn_stream_reset_partial(s);
        ++s->timeout_resets;
        return OKN_OK;
    }
    s->partial_idle_ms = (uint32_t)total;
    return OKN_OK;
}

static okn_status_t drain(okn_stream_t *s, okn_stream_frame_cb cb, void *user) {
    for (;;) {
        while (s->len >= 2u && (s->buf[0] != OKN_PROTO_MAGIC0 || s->buf[1] != OKN_PROTO_MAGIC1)) {
            drop_prefix(s, 1u);
        }
        if (s->len < 6u) return OKN_OK;

        if (s->buf[2] != OKN_PROTO_VERSION) {
            ++s->format_errors;
            drop_prefix(s, 1u);
            continue;
        }

        const uint16_t plen = (uint16_t)s->buf[4] | ((uint16_t)s->buf[5] << 8);
        if (plen > OKN_PROTO_MAX_PAYLOAD) {
            ++s->format_errors;
            drop_prefix(s, 1u);
            continue;
        }

        const size_t frame_len = 8u + (size_t)plen;
        if (s->len < frame_len) return OKN_OK;

        const uint16_t got = (uint16_t)s->buf[frame_len - 2u] |
                             ((uint16_t)s->buf[frame_len - 1u] << 8);
        const uint16_t want = okn_crc16_ccitt(s->buf, frame_len - 2u);
        if (got != want) {
            ++s->crc_errors;
            drop_prefix(s, 1u);
            continue;
        }

        okn_status_t rc = cb ? cb(user, s->buf, frame_len) : OKN_OK;
        if (rc != OKN_OK) return rc;

        ++s->frames_ok;
        memmove(s->buf, s->buf + frame_len, s->len - frame_len);
        s->len -= frame_len;
    }
}

okn_status_t okn_stream_feed(okn_stream_t *s,
                             const uint8_t *data, size_t len,
                             okn_stream_frame_cb cb, void *user) {
    if (!s || (len && !data)) return OKN_ERR_ARG;

    /* Any newly received byte restarts the transport-owned idle budget. */
    if (len != 0u) s->partial_idle_ms = 0u;

    while (len) {
        if (s->len == OKN_STREAM_BUFFER_CAP) {
            /* A valid frame can never require this much buffering. Fail closed and
             * resync one byte at a time instead of overwriting unread data. */
            ++s->format_errors;
            drop_prefix(s, 1u);
        }
        const size_t room = OKN_STREAM_BUFFER_CAP - s->len;
        const size_t n = len < room ? len : room;
        memcpy(s->buf + s->len, data, n);
        s->len += n;
        data += n;
        len -= n;

        const okn_status_t rc = drain(s, cb, user);
        if (rc != OKN_OK) return rc;
    }
    const okn_status_t rc = drain(s, cb, user);
    if (s->len == 0u) s->partial_idle_ms = 0u;
    return rc;
}
