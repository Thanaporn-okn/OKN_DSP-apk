# V12 CONTROL-PLANE INTEGRITY

V12 tightens the portable command path before any target-specific BLE or
BP1048P4 hardware binding is permitted.

## Atomic controller mutation boundary

Protocol writes now call `okn_controller_set_*` APIs. Each successful call
updates the DSP state, the corresponding dirty flag, and the monotonic
controller revision as one logical operation. Rejected values update none of
those fields.

The low-level `okn_set_*` functions remain portable DSP primitives and are not
removed, but the wire protocol no longer pairs a low-level write with a
separate manual `okn_controller_touch_*` call.

## Transport result versus command result

`okn_protocol_execute_ex()` returns `okn_protocol_result_t`:

- `transport_status`: framing / CRC / response-encoding status.
- `command_status`: application command result for a validated frame.
- `command_evaluated`: false when framing/CRC rejected the frame.
- `response_len`: encoded response bytes.

For a valid frame with an invalid command value, transport remains `OKN_OK`,
the command error is carried in a negative ACK, and later stream frames are not
discarded. Invalid CRC/framing never reaches the command layer.

## Hardware scope

This is still host-only architecture. V12 adds no BP1048P4 registers, flash
addresses, boot pins, programmer packets, GATT bindings, or vendor calls.
Hardware/mobile flashing remains locked.
