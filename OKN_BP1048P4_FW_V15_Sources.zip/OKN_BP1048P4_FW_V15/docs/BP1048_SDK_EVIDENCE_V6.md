# BP1048 SDK evidence used by V6

Public family-level evidence located during V6 research:

- Public repository: `leadercxn/bp1048_sdk_v0.1.12`
- Repository description: `MVsB1_BT_Audio_SDK_v0.1.12`
- Top-level source contains `BT_Audio_APP`, `MVsB1_Base_SDK`, and `develop_lib`.
- The SDK includes an Andes/NDS32-oriented linker script in the FreeRTOS demo,
  with `_start` as entry and NDS32-specific sections.
- MVSilicon's BP1048B2 datasheet publicly describes Eclipse/GCC, C development,
  FreeRTOS support, debugger/programmer/Flash Burner Lite programming and an
  internal bootloader with dual-bank upgrade support.

## What this proves
It proves that a real public BP1048-family software-development path exists and
that the family uses an Andes/NDS32-style toolchain in this SDK snapshot.

## What it does NOT prove
It does **not** prove that BP1048P4 on the GoloPine 7CH board has the same startup,
linker map, flash layout, pinmux, DAC routing, BLE API, clock tree or programmer
configuration as the B1/B2-oriented material. V6 therefore keeps all target
hardware gates false until P4/board-specific evidence is obtained.

No vendor source is copied into OKN V6. The project uses only an adapter contract
so a verified vendor SDK can be connected later without contaminating the clean
portable DSP core.
