# V14 CONTROL SESSION / RETRY IDEMPOTENCE

V14 keeps wire protocol version 2 unchanged and adds a portable session layer
for the future Android BLE/USB adapter.

The transport contract is **one outstanding request at a time**. The session
remembers the immediately previous valid request and the exact encoded response.
If the host retries that exact byte sequence because an ACK/notification was
lost, the response is replayed from cache and the command is not evaluated a
second time. This prevents duplicate SET operations from advancing controller
revision/dirty metadata twice.

The cache also protects a mutating request when the local response buffer is too
small: the command executes once into an internal maximum-sized response buffer,
the response is retained, and a later retry can retrieve it without reapplying
the mutation.

This mechanism is not an authentication or general replay-security feature. It
only covers the last request in the current connection/session. A real Android
adapter must serialize requests and call `okn_control_session_reset()` when the
BLE/USB session disconnects or is re-established.

No BP1048P4 MMIO, GATT API, programmer packet, timeout, flash address, or board
routing value is introduced by this layer.
