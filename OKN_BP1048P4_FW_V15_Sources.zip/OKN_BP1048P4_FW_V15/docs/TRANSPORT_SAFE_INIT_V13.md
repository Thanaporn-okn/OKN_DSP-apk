# V13 TRANSPORT + SAFE-INIT INTEGRITY

## Partial-frame recovery

`okn_stream_note_idle(stream, elapsed_ms, timeout_ms)` is transport agnostic.
The BLE/USB adapter owns the clock and timeout policy. V13 only accumulates the
reported idle time while bytes are buffered. On timeout it discards the stale
partial bytes, increments `timeout_resets`, and returns to a clean parser state.

`okn_stream_reset_partial()` is the explicit connection/session reset path.
It discards buffered partial/noise bytes without touching DSP/controller state.

No BLE connection interval, MTU, timer peripheral, or BP1048P4 timing value is
assumed by this portable implementation.

## Safe platform initialization

`bp1048p4_port_evidence_t` ABI 2 adds
`platform_init_output_safe_verified`. A real port must prove that
`platform_init()` leaves physical outputs muted, disabled, or otherwise safe
until `set_output_safety_mute(true)` executes. The validation gate runs before
any HAL callback; missing evidence returns `OKN_ERR_HAL_LOCKED` without calling
`platform_init()`.

The public B1-family SDK does not satisfy this GoloPine/P4 board-specific proof.
The shipped evidence remains false.
