# V4 persistence model

V4 introduces an OKN-owned state image so preset/parameter persistence can be
defined before the BP1048P4 nonvolatile-storage API is known.

Image layout:
- magic `OKNS`
- schema version = 1
- generation counter
- deterministic payload length
- CRC-32/IEEE of payload
- deterministic serialized DSP state

Two logical slots are used. Saving writes the inactive/older slot and verifies
the bytes by reading them back. Loading validates both slots and selects the
newer valid generation. If the newest slot is corrupt, the older valid slot is
used. If neither is valid, runtime initialization remains at safe defaults.

This describes replacement-firmware behavior only. It makes no claim about the
original GoloPine flash layout or BP1048P4 erase/program granularity.

The platform-specific mapping of slot 0/1 to actual NVM is intentionally absent
until verified vendor SDK or board information exists.
