# BLE-safe stream layer (V5)

V5 adds a transport-independent byte-stream reassembler around OKN Protocol V2.

It is designed for transports such as BLE notifications/writes where one protocol
frame may be split across multiple transport chunks, or several frames may arrive
in one chunk.

Properties:
- does not assume a BLE MTU
- accepts partial and concatenated protocol frames
- resynchronizes on `OK` protocol magic after noise/corruption
- rejects oversized payloads
- CRC16 is checked before a frame reaches the command executor
- corrupt frames are not applied
- counters expose delivered frames, dropped bytes, CRC failures and format failures

This is a portable parser only. It does **not** claim or guess the GoloPine BLE stack,
GATT table, UART bridge, BP1048P4 radio API, interrupt, DMA or vendor SDK calls.

V5 also adds readback commands for the OKN protocol:
- GET_MASTER_STATE
- GET_CHANNEL_STATE
- GET_PEQ_STATE

These are project-defined OKN commands, not reconstructed GoloPine commands.
