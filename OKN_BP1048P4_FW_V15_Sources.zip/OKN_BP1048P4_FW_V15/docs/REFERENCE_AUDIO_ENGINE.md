# V3 portable reference audio engine

Purpose: provide deterministic, host-testable DSP behavior before the real BP1048P4 hardware port exists.

Signal order per reference lane:

`input -> HPF -> 15 x PEQ -> LPF -> gain/mute/phase -> delay -> output`

Current reference ceiling is 48 kHz and 50 ms delay, matching the project control-domain delay limit. This ceiling is a portable test implementation limit, not a statement about BP1048P4 capability.

The seven lanes are deliberately independent. The actual GoloPine input-to-output routing is still unknown and is not encoded here.

Shelf filters use the RBJ shelf formula with the stored `q` field interpreted as shelf slope `S`. That is an OKN-native firmware definition and must not be confused with the original GoloPine firmware's semantics.
