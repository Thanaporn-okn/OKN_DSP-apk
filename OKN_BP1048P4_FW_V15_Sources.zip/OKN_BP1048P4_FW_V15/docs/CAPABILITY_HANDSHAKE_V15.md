# V15 CAPABILITY HANDSHAKE

V15 keeps the existing Protocol V2 frame format and adds two command IDs:

- `0x06 GET_CAPABILITIES` request, zero-length payload
- `0x76 CAPABILITIES` response

The capability payload schema is `1` and is encoded field-by-field in
little-endian form; no C struct layout is placed on the wire.

Payload bytes:

| Offset | Size | Field |
|---:|---:|---|
| 0 | 1 | capability schema |
| 1 | 1 | channels |
| 2 | 1 | PEQ bands/channel |
| 3 | 1 | protocol version |
| 4 | 2 | firmware version |
| 6 | 2 | portable reference max delay ms |
| 8 | 2 | max protocol payload bytes |
| 10 | 2 | max protocol frame bytes |
| 12 | 4 | feature bitmap |
| 16 | 1 | single-outstanding-request required |
| 17 | 1 | retry-cache depth |
| 18 | 1 | hardware ready |
| 19 | 1 | hardware flashable |
| 20 | 1 | mobile flashable |
| 21 | 1 | reserved, zero |
| 22 | 4 | controller revision |

Feature bits:

- bit 0 readback state
- bit 1 atomic mutation
- bit 2 negative ACK
- bit 3 idempotent immediate-retry cache
- bit 4 stream idle reset
- bit 5 external delay arena
- bit 6 A/B persistence model
- bit 7 safe-boot evidence gate
- bit 8 flash fail-closed policy
- bit 9 capability query
- bit 10 exact-board evidence required

The three hardware readiness bytes remain zero in V15. They MUST NOT be used
to infer that the public B1 SDK or BP1048B2 family documentation applies to
BP1048P4/GoloPine.

Compatibility rule: clients may first issue `GET_INFO`. Older Protocol V2
firmware that does not implement `GET_CAPABILITIES` will return the existing
negative ACK/unsupported status. V15-capable clients should then fall back to
their older compatibility path rather than assuming features.
