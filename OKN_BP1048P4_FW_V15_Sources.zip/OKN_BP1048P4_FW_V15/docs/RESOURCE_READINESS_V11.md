# V11 RESOURCE / MEMORY READINESS

V11 removes the 7-channel delay-line array from `okn_audio_engine_t`.

The portable reference engine now requires a caller-owned delay arena when
non-zero delay is used:

- maximum reference sample rate: 48 kHz
- maximum project-defined delay: 50 ms
- stride per channel: 2401 float samples
- channels: 7
- total reference arena: 16807 float samples = 67228 bytes when float is 32-bit

This is a **portable reference requirement**, not a statement about BP1048P4
RAM capacity. The exact target linker map, RAM banks, stack budget and legal
placement are still unverified.

`okn_audio_engine_prepare()` fails closed with `OKN_ERR_BUFFER` when a
non-zero delay is requested without a bound arena. A future authenticated
BP1048P4 board port must decide where this arena lives or replace the
reference delay implementation with a verified vendor/target implementation.

Persistence still uses temporary work buffers internally. V11 records that
the target persistence workspace strategy remains unverified; target stack/RAM
fit must be proven before hardware authorization.
