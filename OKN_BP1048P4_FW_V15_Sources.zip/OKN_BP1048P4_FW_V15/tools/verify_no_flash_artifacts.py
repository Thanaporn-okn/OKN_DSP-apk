#!/usr/bin/env python3
from pathlib import Path
import json, sys
root = Path(__file__).resolve().parents[1]
m = json.loads((root / 'firmware_manifest.json').read_text())
blocked_suffixes = {'.bin','.hex','.elf','.axf','.img','.fw'}
found=[]
for p in root.rglob('*'):
    if p.is_file() and p.suffix.lower() in blocked_suffixes:
        found.append(str(p.relative_to(root)))
if m.get('hardware_flashable') is False and found:
    print('BLOCKED: locked source tree contains firmware-like artifacts:')
    for x in found: print(' -', x)
    sys.exit(1)
print('PASS: no flashable artifact is shipped while hardware_flashable=false')
