#!/usr/bin/env python3
from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[1]
m=json.loads((root/"evidence_manifest.json").read_text())
errors=[]
if m.get("schema")!=4: errors.append("evidence schema must be 4")
if m.get("project_version")!=15: errors.append("project_version must be 15")
if m.get("target")!="BP1048P4" or m.get("board")!="GoloPine 7CH": errors.append("target/board mismatch")
if m.get("policy")!="FAIL_CLOSED_NO_INFERENCE": errors.append("policy mismatch")
if m.get("hardware_authorized") is not False: errors.append("hardware_authorized must be false")
req=m.get("required_exact_evidence",{})
if any(bool(v) for v in req.values()): errors.append("V15 exact evidence flags must all remain false")
prov=m.get("provenance",{})
if prov.get("previous_source_sha256")!="f04c2a9cd752ce3c69de663da17e066ec9bdbd552e8e70e20fd61cfb55fff60a": errors.append("V14 source provenance mismatch")
if prov.get("validation_zip_sha256")!="dc9c19f3a2e9648440e6ae29b2693c18cf6404dbc274ddc05efcffac4bb726dc": errors.append("V14 validation provenance mismatch")
for ob in m.get("observations",[]):
    if ob.get("authorizes") not in ([],None): errors.append("observations may not authorize hardware in V15")
if errors:
    [print("BLOCKED:",e) for e in errors]; sys.exit(1)
print("PASS: V15 evidence manifest is internally consistent and non-authorizing")
