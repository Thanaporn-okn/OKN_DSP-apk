#!/usr/bin/env python3
"""Inventory a user-supplied vendor artifact without inferring hardware facts.

Usage: python3 tools/evidence_inventory.py PATH [PATH ...]
Prints JSON with file names, sizes and SHA256 values only. It intentionally does
not mark any BP1048P4/GoloPine evidence field as verified.
"""
from pathlib import Path
import hashlib, json, sys

def digest(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()

if len(sys.argv) < 2:
    print('usage: evidence_inventory.py PATH [PATH ...]', file=sys.stderr)
    sys.exit(2)
items=[]
for arg in sys.argv[1:]:
    p=Path(arg)
    if not p.exists() or not p.is_file():
        print(f'not a regular file: {p}', file=sys.stderr); sys.exit(2)
    items.append({'path':p.name,'size':p.stat().st_size,'sha256':digest(p)})
print(json.dumps({'schema':1,'classification':'UNREVIEWED_INPUT','authorizes':[], 'files':items}, indent=2))
