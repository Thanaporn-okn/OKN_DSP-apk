#!/usr/bin/env python3
from pathlib import Path
import re, sys
root=Path(__file__).resolve().parents[1]
patterns=[
 re.compile(r'\*\s*\(\s*volatile\s+(?:unsigned|u?int\d*_t).*?\*\s*\)\s*0x[0-9a-fA-F]+'),
 re.compile(r'\bREG(?:ISTER)?_[A-Z0-9_]+\s*=\s*0x[0-9a-fA-F]+'),
 re.compile(r'\b(?:FLASH|BOOT|GPIO|I2S|DAC|ADC)_[A-Z0-9_]*(?:ADDR|BASE|PIN)\s+0x[0-9a-fA-F]+'),
]
viol=[]
for path in list((root/'src').rglob('*.c'))+list((root/'src').rglob('*.h')):
 text=path.read_text(errors='ignore')
 for rx in patterns:
  if rx.search(text): viol.append((path,rx.pattern))
if viol:
 for p,pat in viol: print('BLOCKED guessed HW access:',p,pat)
 sys.exit(1)
print('PASS: no raw guessed BP1048P4 MMIO/register/boot-pin access detected')
