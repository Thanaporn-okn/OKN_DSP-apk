#!/usr/bin/env python3
"""Inventory a vendor SDK/programmer bundle without authorizing it.
This tool hashes files and reports candidate text markers only. A marker hit is
NOT proof of BP1048P4 compatibility and never modifies target_port_manifest.json.
"""
from pathlib import Path
import argparse, hashlib, json

parser=argparse.ArgumentParser()
parser.add_argument('path')
parser.add_argument('--output', default='vendor_evidence_inventory.json')
a=parser.parse_args()
base=Path(a.path)
markers=[b'BP1048P4',b'Flash Burner',b'AndeSight',b'linker',b'startup',b'bootloader',b'programmer']
records=[]
paths=[base] if base.is_file() else sorted(p for p in base.rglob('*') if p.is_file())
for p in paths:
    data=p.read_bytes()
    hits=[]
    sample=data[:2_000_000]
    for m in markers:
        if m.lower() in sample.lower(): hits.append(m.decode())
    records.append({'path':str(p.relative_to(base.parent if base.is_file() else base)),
                    'size':len(data),'sha256':hashlib.sha256(data).hexdigest(),
                    'candidate_markers':hits})
out={'classification':'CANDIDATE_ONLY_NO_AUTHORIZATION','input':str(base),'files':records}
Path(a.output).write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print(f'WROTE {a.output} ({len(records)} files); classification=CANDIDATE_ONLY_NO_AUTHORIZATION')
