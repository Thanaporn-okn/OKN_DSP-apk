#!/usr/bin/env python3
GENERIC_TARGET_REQ = [
    "exact_bp1048p4_sdk","exact_chip_identity","exact_golopine_board_identity",
    "startup","linker_memory_map","flash_programmer","programmer_transport",
    "image_layout","image_format","recovery_path","power_safety",
    "original_firmware_backup_readback","post_flash_readback_verify","board_pin_map",
    "exact_ram_capacity","delay_arena_placement","persistence_workspace_strategy"
]
SESSION_REQ = [
    "exact_target","exact_board","verified_programmer_transport",
    "verified_image_layout_and_format","verified_recovery_path","verified_power_safety",
    "original_firmware_backup_readback","backup_hash_verified","post_flash_readback_verify",
    "exact_ram_capacity","delay_arena_placement","persistence_workspace_strategy"
]

def evaluate(target, session):
    ev=target.get("evidence",{})
    pf=session.get("preflight",{})
    target_missing=[k for k in GENERIC_TARGET_REQ if not bool(ev.get(k))]
    session_missing=[k for k in SESSION_REQ if not bool(pf.get(k))]
    generic=(not target_missing and not session_missing and
             bool(target.get("hardware_flashable")) and bool(session.get("execution_authorized")))
    mobile_missing=list(target_missing)+list(session_missing)
    if not bool(ev.get("android_host_transport")): mobile_missing.append("target:android_host_transport")
    if not bool(pf.get("android_host_transport")): mobile_missing.append("session:android_host_transport")
    mobile=(generic and not mobile_missing and bool(target.get("mobile_flashable")))
    return {"generic_ready":generic,"mobile_ready":mobile,
            "target_missing":target_missing,"session_missing":session_missing,
            "mobile_missing":mobile_missing}
