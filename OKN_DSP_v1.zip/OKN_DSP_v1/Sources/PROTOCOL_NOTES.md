# OKN_DSP v1 protocol notes

## Verified data currently available
- BLE UUID observed in captured logs: `0000ab01-0000-1000-8000-00805f9b34fb`.
- Captured reads reported `RX_READ`, `len=0`, `mode=IDLE`, `status=0` with empty payloads.

## Safety rule used in v1
No DSP write packet format has been verified from the supplied captures. The application therefore does **not** fabricate command bytes. UI state changes immediately and BLE scan/connect/service discovery are active, but parameter writes are gated by two encoder methods that currently return `null`:
- `_encodeVerifiedPacket`
- `_encodeVerifiedEqPacket`

When a real control capture is available (before/after changing a known DSP parameter), only those encoder methods need to be filled with the verified packet format.
