# OKN_DSP v1

Clean restart of the OKN_DSP Android app.

## v1 scope
- UI structure follows the supplied reference image.
- Home screen: Master Volume, Bass Volume, Bass Cutoff, Bass Boost, Middle Boost, Treble Boost, preset area, save/load controls.
- EQ screen: EQ graph, 7 bands, 7 channel selector, copy/paste/save controls.
- Home/EQ bottom navigation works.
- Sliders and EQ band controls are touch-interactive.
- DSP/BLE hardware commands are intentionally not connected in v1; this version establishes the UI foundation first.

## Android build
- Package: `com.okn.dsp`
- Min SDK: 26
- Target/Compile SDK: 35
- Java: 17
- Android Gradle Plugin: 8.6.1
- Version code: 1
- Version name: `1.0-v1`
