# OKN_DSP v1 - no custom ProGuard rules required yet.
