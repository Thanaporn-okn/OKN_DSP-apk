OKN_DSP V1.0.3 BUILD FIX

Fixed:
- Full Android project structure
- Root Gradle files
- App module
- Manifest
- MainActivity

Purpose:
Pass GitHub Actions build stage before adding BLE/DSP features.