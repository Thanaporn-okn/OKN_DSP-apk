# OKN DSP V51 — BP1048P4 USB/HID UFE Authentication Bridge Probe

V51 follows the real-board V46–V50 USB evidence and the previously proven BLE UFE authentication evidence.

## What V50 proved

The physical 0x6324:0x1719 board exposes HID interface 4 with vendor Usage Page 0xFF00 / Usage 0x55AA, 256-byte Input, 256-byte Output and an 8-byte Feature report. V50 read the Feature report as `0001000304000800` with zero host-to-device traffic.

An independent MVSilicon-style device dump uses the exact same 36-byte HID report descriptor and returns `0001000303000800` on interface 3. Because the only changing byte follows the interface number, V51 treats this Feature payload as fixed transport metadata rather than an authentication key/state and does not issue SET_FEATURE.

## Why V51 exists

V49 showed that a Generic BP10 ACP catalog frame was accepted as a 256-byte Output Report but produced no Input reply. The GoloPine protocol evidence instead shows a UFE session layer shared above BLE/USB/HID/Serial, with authentication before Device Description.

The exact 16-byte UFE authentication request is already hardware-proven on this same DSP over BLE:

`631C062443FD3844558001F3EDA0CCF8`

V51 tests only whether IF4 transports that same UFE authentication request.

## V51 probe

The Mix-page button is `USB UFE AUTH (1 TX)`.

After permission and a non-forcing IF4 claim, V51:
1. re-validates the 36-byte vendor HID descriptor;
2. performs a baseline Input GET_REPORT and stops if a cached report already exists;
3. sends exactly one 256-byte HID Output Report whose first 16 bytes are the proven UFE auth request and whose remaining 240 bytes are zero;
4. performs Input GET_REPORT only, looking for the already-proven UFE authentication response prefix `D024E38C`;
5. stops even if authentication succeeds. It does not request Device Description in V51.

## Safety

V51 has no actuator, gain, EQ, biquad, effect-node or SaveParams write in the USB probe. It has no ACP `A5 5A` frame. There is no SET_REPORT retry path and no Device Description request. `claimInterface(..., false)` remains mandatory. CH1/2/4/5/6/7 output sliders remain fail-closed; CH3/ID8 remains unchanged.
