# OKN DSP V51

V51 changes only the Master/Bass link logic. It does not use Band EQ.

Required behavior:
- Lower Master Volume (ID2): Bass Volume (ID8) does not decrease. V51 rewrites/verifies the current ID8 target after Master settles.
- Raise Master Volume (ID2): Bass Volume (ID8) increases by the same positive dB delta, 1:1.
- Manual Bass Volume remains -70..+24 dB. Automatic Master-up linking may use ID8 above +24 dB, up to the existing +70 dB safety envelope, and DSP readback remains authoritative.

Only ID2 and ID8 are involved. V51 does not change Bass EQ gain, Ch3 EQ, cutoff, channel volume, or EQ channel mapping.

EQ order remains: Ch1 Left, Ch2 Right, Ch3 Bass/Subwoofer, Ch4 4th, Ch5 5th, Ch6 6th, Ch7 7th.
