import 'package:flutter/material.dart';

void main()=>runApp(const OKNDSP());

class OKNDSP extends StatelessWidget{
 const OKNDSP({super.key});
 @override
 Widget build(BuildContext c)=>MaterialApp(
 debugShowCheckedModeBanner:false,
 theme:ThemeData.dark(useMaterial3:true),
 home:const DSPPage());
}

class DSPPage extends StatelessWidget{
 const DSPPage({super.key});

 final names=[
 'CH1\nFront L','CH2\nFront R','CH3\nSUB',
 'CH4\nRear L','CH5\nRear R','CH6\nAUX L','CH7\nAUX R'];

 @override
 Widget build(BuildContext c){
 return Scaffold(
 backgroundColor:const Color(0xff090d12),
 body:SafeArea(
 child:Column(children:[
  top(),
  const SizedBox(height:8),
  Expanded(child:Row(
   children:names.map((e)=>Expanded(
    child:ChannelCard(name:e))).toList())),
  bottom()
 ])));
 }

 Widget top()=>Container(
 margin:const EdgeInsets.all(10),
 padding:const EdgeInsets.all(12),
 decoration:BoxDecoration(
 color:const Color(0xff1d232d),
 borderRadius:BorderRadius.circular(15)),
 child:Row(children:[
 const Icon(Icons.bluetooth,color:Colors.cyan,size:32),
 const SizedBox(width:10),
 const Expanded(child:Text(
 'Connected\nBP1048P4 7CH DSP\nFW:1.2.6')),
 Column(children:[
 ElevatedButton(onPressed:null,child:const Text('Save DSP')),
 ElevatedButton(onPressed:null,child:const Text('Read DSP'))
 ])
 ]));

 Widget bottom()=>Container(
 height:55,
 alignment:Alignment.center,
 color:const Color(0xff151a20),
 child:const Text(
 '⌂ MAIN   EQ   CROSSOVER   DELAY   MIXER   PRESET   SETTINGS',
 style:TextStyle(color:Colors.cyan,fontSize:14)));

}

class ChannelCard extends StatelessWidget{
 final String name;
 const ChannelCard({super.key,required this.name});

 @override
 Widget build(BuildContext c){
 return Container(
 margin:const EdgeInsets.all(4),
 decoration:BoxDecoration(
 color:const Color(0xff171d25),
 borderRadius:BorderRadius.circular(12)),
 child:Column(children:[
 Container(height:4,color:Colors.cyan),
 Padding(
 padding:const EdgeInsets.all(8),
 child:Text(name,textAlign:TextAlign.center)),
 const Text('-2.0 dB'),
 Expanded(child:Row(
 children:[
 const RotatedBox(
 quarterTurns:3,
 child:Slider(value:.75,onChanged:null)),
 const Column(
 mainAxisAlignment:MainAxisAlignment.center,
 children:[
 Text('6'),Text('0'),Text('-6'),
 Text('-12'),Text('-18'),
 Text('-30'),Text('-60')
 ])
 ])),
 ElevatedButton(
 onPressed:null,
 child:const Text('Mute'))
 ]));
 }
}
