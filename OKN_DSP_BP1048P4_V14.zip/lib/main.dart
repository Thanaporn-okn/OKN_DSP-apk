import 'package:flutter/material.dart';

void main() => runApp(const OKNDSPV14());

class OKNDSPV14 extends StatelessWidget {
  const OKNDSPV14({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: const Color(0xff121018),
        body: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              const Text(
                'OKN_DSP BP1048P4 V14',
                style: TextStyle(color: Colors.cyan, fontSize: 28),
              ),
              const SizedBox(height: 20),
              const Text(
                'Channel Mixer CH1-CH7\n'
                'Volume / EQ / Delay / HPF / LPF\n'
                'BP1048P4 Command System\n'
                'TX RX Log Ready',
                style: TextStyle(color: Colors.white, fontSize: 18),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
