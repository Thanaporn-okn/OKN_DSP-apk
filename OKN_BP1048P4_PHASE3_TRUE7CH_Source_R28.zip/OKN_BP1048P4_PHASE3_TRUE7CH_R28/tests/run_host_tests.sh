#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
BIN="${TMPDIR:-/tmp}/okn_r28_test_gain7_$$"
trap 'rm -f "$BIN"' EXIT

cc -std=c11 -Wall -Wextra -Werror -pedantic \
  -I"$ROOT/firmware/include" \
  "$ROOT/firmware/src/okn_gain7.c" \
  "$ROOT/firmware/src/okn_ufe_gain7.c" \
  "$ROOT/tests/test_gain7.c" -o "$BIN"
"$BIN"
python3 "$ROOT/tools/check_no_eq_gain.py"
python3 "$ROOT/tools/test_mva_inspect.py"
python3 "$ROOT/tools/reverse_r25_sdk_evidence.py"
python3 "$ROOT/tools/check_r25_readonly.py"
python3 "$ROOT/tools/r26_flashboot_offline_inspect.py" "$ROOT/sdk_evidence/r23_reverse/flash_boot.c" --json >/dev/null
python3 "$ROOT/tools/check_r26_offline_guard.py"
python3 "$ROOT/tools/r27_flashboot_hid_reverse.py" "$ROOT/sdk_evidence/r23_reverse/flash_boot.c" --json >/dev/null
python3 "$ROOT/tools/check_r27_offline_guard.py"

python3 "$ROOT/tools/r28_mva_recovery_offline.py" "$ROOT/sdk_evidence/r23_reverse/flash_boot.c" --usb-request-c "$ROOT/sdk_evidence/r23_reverse/otg_device_standard_request.c" --upgrade-c "$ROOT/sdk_evidence/r23_reverse/upgrade.c" --flash-config-h "$ROOT/sdk_evidence/r23_reverse/flash_config.h" --json >/dev/null
python3 "$ROOT/tools/test_r28_mva_inspect.py"
python3 "$ROOT/tools/check_r28_offline_guard.py"

echo "R28 host/safety tests: PASS"
