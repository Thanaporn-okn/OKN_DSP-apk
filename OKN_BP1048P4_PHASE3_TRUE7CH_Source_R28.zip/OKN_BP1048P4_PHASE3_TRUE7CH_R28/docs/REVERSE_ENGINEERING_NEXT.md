# Next after R28

R29 offline targets:
1. Decode the 1,520-byte package-03 helper blob and determine whether it contains any flash READ/readback primitive with a real host transport.
2. Resolve exact code-image metadata writes around offsets 0xA4/0xBC/0xCC..0xD3/0xE4..0xEB and distinguish CRC/size/version fields.
3. Search current normal runtime + ROM API for a host-exposed non-destructive identity or arbitrary flash-read path that does not arm/reset/update.
4. Keep stock backup/recovery gate closed unless full 4 MiB readback can be repeated and SHA256 matched.

Do not convert the recovered MVA framing into a live writer. Packet format knowledge is not recovery proof.
