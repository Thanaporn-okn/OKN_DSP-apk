# BUILD NOTES — R28

R28 ไม่เพิ่ม hardware action. งานใหม่ทั้งหมดเป็น offline MVA/package/recovery analysis.

Host/safety verification ต้องผ่าน:
1. TRUE7CH host tests เดิม
2. R25 Bluetooth READ-ONLY guard
3. R26/R27 historical offline guards
4. `r28_mva_recovery_offline.py` ต้องยืนยัน reference flashboot SHA, MVA signature/record framing, maker layout, CRC16/XMODEM, normal Feature semantics และ reference P4 map
5. `test_r28_mva_inspect.py` ต้องพิสูจน์ parser/CRC แบบ offline และไม่แก้ input
6. R28 guard ต้องคง `stock_backup_obtained=false`, `proven_live_identity_or_readback_command=null`, `live_probe_allowed=false`
7. Android ต้องไม่มี USB/RFCOMM/GATT write/file-picker updater code

AUTO GitHub Actions stable-signing workflow เดิมใช้ได้. R28 ไม่จำเป็นต้อง build/install APK เพราะไม่มี live probe ใหม่.
