# OKN BP1048P4 Phase3 TRUE7CH — R28

R28 เป็นรอบ **offline MVA/package/recovery reverse** ต่อจาก R27 ไม่มี hardware command ใหม่.

อ่านหลักก่อน:
- `docs/R28_MVA_RECOVERY_OFFLINE_REVERSE_TH.md`
- `docs/R28_NORMAL_APP_FEATURE_REPORT_TH.md`
- `docs/R28_MVA_PACKAGE_FORMAT_EVIDENCE.txt`
- `config/R28_MVA_RECOVERY_STATE.json`
- `config/R28_MVA_RECOVERY_RISK.json`

ผลใหม่:
- พิสูจน์ MVA header `4D 56 B1 58` + record count byte.
- record framing = `ID:u8 + length:u32 little-endian + payload`.
- แยก record 02/03/04/05 ได้ถึงระดับ target offset + payload; record 01 ยังไม่เดาความหมาย.
- package checksum helper คือ CRC-16/XMODEM poly 0x1021 init 0; maker append ช่อง checksum 4 bytes.
- normal-app Feature GET 8 bytes ไม่ใช่ identity/version; มันคืน Setup packet buffer และหลัง arm reference source สามารถเรียก `start_up_grate()`.
- ยังไม่มี full-flash readback/stock backup/recovery image และยังไม่มี safe live identity/readback command.

`tools/r28_mva_recovery_offline.py` เป็น inspector/verifier แบบอ่านไฟล์เท่านั้น ไม่มี USB/Bluetooth และไม่มี packer.

Android module relabel เป็น R28 เพื่อ continuity/stable signing เท่านั้น ไม่มี USB updater path ใหม่ และ **ไม่จำเป็นต้องติดตั้ง R28 APK**.
