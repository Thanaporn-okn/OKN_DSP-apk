# OKN BP1048P4 Phase3 TRUE7CH Source R6

R6 ต่อจาก R5 โดยยังคง TRUE7CH gain core แยกจาก EQ.

USB ส่วนใหม่:
- ขั้น 1 เป็น read-only qualification เหมือน R5
- ต้องตรง VID/PID 0x6324:0x1719
- ต้องตรง IF4 report descriptor 36 bytes ที่วัดจากบอร์ดจริง
- ต้องตรง Feature 8 bytes: 00 01 00 03 04 00 08 00
- จึงจะเปิดปุ่มขั้น 2
- ขั้น 2 ส่ง OUT report ได้เพียงหนึ่งแบบ: `A5 5A 00 00 16` + zero padding ถึง 256 bytes
- packet นี้ map กับ Control 0x00 (version/info query) ใน public BP1048-family SDK; ไม่มี payload และไม่ใช่ DSP parameter write
- หลังส่งหนึ่งครั้ง อ่าน INPUT report 256 bytes แล้วหยุด

R6 ไม่มี UFE 0x57, ไม่มี EQ/actuator write, ไม่มี SaveParams, ไม่มี erase/program/flash/reboot-to-bootloader.

หมายเหตุ: exact GoloPine firmware ยังไม่ถือว่าพิสูจน์ว่าเหมือน public SDK 100%; ปุ่ม query จึง fail-closed ด้วย exact USB descriptor/feature gates.
