#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cc -std=c11 -Wall -Wextra -Werror -pedantic \
  -I"$ROOT/firmware/include" \
  "$ROOT/firmware/src/okn_gain7.c" \
  "$ROOT/firmware/src/okn_ufe_gain7.c" \
  "$ROOT/tests/test_gain7.c" -o "$ROOT/tests/test_gain7"
"$ROOT/tests/test_gain7"
python3 "$ROOT/tools/check_no_eq_gain.py"
python3 "$ROOT/tools/check_usb_r6_query_guard.py"
