from pathlib import Path
p=Path(__file__).resolve().parents[1]/"android-usb-probe/app/src/main/java/com/okn/dsp/usbprobe/MainActivity.java"
s=p.read_text()
assert s.count("0x21,       // host-to-device | class | interface") == 1
assert s.count("0x09,       // HID SET_REPORT") == 1
assert "out[0]=(byte)0xA5" in s and "out[1]=0x5A" in s and "out[2]=0x00" in s and "out[3]=0x00" in s and "out[4]=0x16" in s
for bad in ["0x57", "SaveParams", "eraseCommand", "programCommand", "rebootToBootloader", "bulkTransfer("]:
    assert bad not in s, bad
assert "EXPECTED_IF4_REPORT" in s and "EXPECTED_FEATURE" in s
assert "OBSERVED_VID = 0x6324" in s and "OBSERVED_PID = 0x1719" in s
print("R6 guarded-version-query USB safety: PASS")
