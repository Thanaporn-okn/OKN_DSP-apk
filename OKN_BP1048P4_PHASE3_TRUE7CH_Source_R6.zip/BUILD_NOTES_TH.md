# R6 Build Notes

เหตุผลที่เพิ่ม one-shot version query:
- บอร์ดจริงยืนยัน IF4 HID vendor report: INPUT 256 / OUTPUT 256 / FEATURE 8
- public BP1048-family SDK ใช้ USB HID สำหรับ online tuning, รับ packet ผ่าน HIDUsb_Rx -> UsbLoadAudioMode
- parser family SDK ใช้ frame `A5 5A | control | length | payload | 16`
- Control 0x00 ไม่มี payloadและเรียก version response; response family SDK = `A5 5A 00 07 ... 16`

R6 อนุญาตเพียง query 0x00 หนึ่งครั้ง หลัง exact board gates ผ่าน.
ไม่อนุญาตคำสั่งอื่นและไม่มี firmware flash path.
