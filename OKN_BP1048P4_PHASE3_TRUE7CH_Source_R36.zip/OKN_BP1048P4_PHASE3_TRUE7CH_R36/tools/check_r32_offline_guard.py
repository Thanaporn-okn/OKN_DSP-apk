#!/usr/bin/env python3
import ast,json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=json.loads((ROOT/'config/R32_PROTECTED_UFE_RESPONSE_STATE.json').read_text())
r=json.loads((ROOT/'config/R32_PROTECTED_UFE_RESPONSE_RISK.json').read_text())
assert s['revision']=='R32' and s['mode']=='OFFLINE_ONLY'
assert s['device_io'] is False and s['live_probe'] is False
assert s['protected_runtime_recovery']['protected_method_records']==1823
assert s['protected_runtime_recovery']['stream_consumed_exactly'] is True
assert s['protected_runtime_recovery']['stream_end']=='0x946DF'
assert s['hid_runtime_path']['managed_send_chain']==['HIDInterface.Send','Hid.Write','HidD_SetOutputReport']
assert s['hid_runtime_path']['managed_receive_chain'][:3]==['HIDInterface.HidRead','Hid.Read','HidD_GetInputReport']
d=s['ufe_response_dispatch']
assert d['selector']=='response[0] - 0x60'
assert set(d['switch_cases'])=={'0x60','0x61','0x62','0x63','0x64'}
assert d['0x82']=='separate continue-bulk handling'
assert d['flash_api_calls_in_recovered_dispatch']==0
assert d['arbitrary_flash_address_source_found'] is False
assert s['assessment']['hidden_windows_ufe_flash_readback_found'] is False
assert s['assessment']['safe_stock_backup_path_found'] is False
assert s['assessment']['flash_gate']=='CLOSED'
assert s['assessment']['hardware_action_authorized'] is False
joined=' '.join(r['blocked_actions']).lower()
for term in ['.mva','obex put','0x55/0xaa','0x00/0x11','erase/program/commit/apply/reset','hardware probe']:
    assert term in joined, term
# Source checkpoint must not contain proprietary EXE or private stable signing key.
for p in ROOT.rglob('*'):
    if not p.is_file(): continue
    n=p.name.lower()
    assert not n.endswith('.exe'), p
    assert 'private_okn_android_stable_debug_key' not in n, p
# R32 recovery code must be offline-only: no device/network modules or subprocess transport tools.
tool=ROOT/'tools/r32_recover_protected_runtime.py'
tree=ast.parse(tool.read_text())
imports=set()
for node in ast.walk(tree):
    if isinstance(node,(ast.Import,ast.ImportFrom)):
        if isinstance(node,ast.Import): imports.update(x.name.split('.')[0] for x in node.names)
        elif node.module: imports.add(node.module.split('.')[0])
for banned in {'usb','serial','hid','bleak','bluetooth','socket','requests','subprocess'}:
    assert banned not in imports, (banned,imports)
text=(ROOT/'windows/r32/protected_il/06000795_FBL3HEmTva.il.txt').read_text(errors='replace')
assert 'ldc.i4.s           96' in text and 'switch             [IL_0C30, IL_09F5, IL_0D3A, IL_09F5, IL_10DD]' in text
assert 'ldc.i4             130' in text
assert 'SensorActuatorDataBinaryConverter::ParseBinary' in text
assert 'SensorActuatorDataBinaryConverter::ParseFifoBinary' in text
for forbidden in ['SpiFlashRead','SpiFlashErase','SpiFlashWrite']:
    assert forbidden not in text
hidread=(ROOT/'windows/r32/protected_il/06000460_Read.il.txt').read_text()
hidwrite=(ROOT/'windows/r32/protected_il/06000461_Write.il.txt').read_text()
assert 'Hid::Hl8q09gqNT' in hidread  # P/Invoke -> HidD_GetInputReport per verified import map
assert 'Hid::HLvqy7J7nC' in hidwrite # P/Invoke -> HidD_SetOutputReport per verified import map
print('R32 offline guard: PASS')
