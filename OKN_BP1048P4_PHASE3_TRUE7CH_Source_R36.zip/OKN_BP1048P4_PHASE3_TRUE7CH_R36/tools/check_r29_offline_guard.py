#!/usr/bin/env python3
from pathlib import Path
import json, subprocess, sys
root=Path(__file__).resolve().parents[1]
state=root/'config/R29_HELPER_READBACK_STATE.json'
risk=root/'config/R29_HELPER_READBACK_RISK.json'
report=root/'docs/R29_PACKAGE03_READBACK_OFFLINE_REVERSE_TH.md'
evidence=root/'docs/R29_PACKAGE03_PARSER_EVIDENCE.txt'
helper_ev=root/'sdk_evidence/r29_helper_readback/helper03_fingerprint.txt'
parser_ev=root/'sdk_evidence/r29_helper_readback/package03_id3_disassembly.txt'
read_ev=root/'sdk_evidence/r29_helper_readback/internal_spiflashread_evidence.txt'
for p in (state,risk,report,evidence,helper_ev,parser_ev,read_ev):
    if not p.is_file(): raise SystemExit(f'R29 FAIL missing {p}')
s=json.loads(state.read_text())
r=json.loads(risk.read_text())
if s.get('revision')!='R29' or s.get('mode')!='OFFLINE_ONLY' or s.get('device_io') is not False:
    raise SystemExit('R29 FAIL state not offline')
if s.get('reference_flashboot_size')!=65536 or s.get('reference_flashboot_sha256')!='cd0e4e03f7072abd48fea2aeb5a54d9360b65acb1bd4d1b37734438cbe5f47c6':
    raise SystemExit('R29 FAIL reference flashboot mismatch')
h=s['package03_helper']
if h.get('length')!=1520 or h.get('sha256')!='db8f68feedf48671b863fbc3269cfa2dfce180f6a21a65fe6152cee239c43c12':
    raise SystemExit('R29 FAIL helper fingerprint')
if h.get('classification')!='opaque/high-entropy helper payload; exact encoding/compression/encryption is not proven':
    raise SystemExit('R29 FAIL helper overclaim/changed classification')
p=s['mva_parser_dispatch']
if p.get('id3_handler')!='0x41D8' or p.get('id3_payload_processing_call_proven') is not False or p.get('id3_helper_execution_or_copy_proven') is not False:
    raise SystemExit('R29 FAIL package03 parser state')
if p['id_to_handler']!={'1':'0x41BC','2':'0x41FE','3':'0x41D8','4':'0x43B4','5':'0x4440'}:
    raise SystemExit('R29 FAIL parser dispatch map')
rd=s['internal_flash_read']
if rd.get('internal_spi_flash_read_exists') is not True or rd.get('host_exposed_arbitrary_flash_read_proven') is not False:
    raise SystemExit('R29 FAIL flash-read exposure state')
if rd.get('normal_usb_request_spiflashread_call_count')!=0 or rd.get('upgrade_source_spiflashread_call_count')!=0:
    raise SystemExit('R29 FAIL unexpected normal USB/upgrade read exposure evidence')
rec=s['recovery_assessment']
for k in ('stock_backup_obtained','stock_full_flash_readback_path_proven','package03_is_host_readback_helper_proven','internal_read_is_exposed_to_host','production_layout_proven','live_flash_action_allowed'):
    if rec.get(k) is not False: raise SystemExit(f'R29 FAIL recovery gate {k}')
if s.get('live_probe_allowed') is not False or s.get('proven_live_identity_or_readback_command') is not None:
    raise SystemExit('R29 FAIL live probe unexpectedly enabled')
if r.get('hardware_action_allowed') is not False or r.get('live_probe_allowed') is not False or r.get('stock_backup_obtained') is not False:
    raise SystemExit('R29 FAIL risk policy')

# Android remains Bluetooth discovery only; R29 adds no USB/readback/update path.
java=(root/'android-bt-probe/app/src/main/java/com/okn/dsp/btprobe/MainActivity.java').read_text()
manifest=(root/'android-bt-probe/app/src/main/AndroidManifest.xml').read_text()
scan=java+'\n'+manifest
for tok in ['android.hardware.usb','UsbManager','UsbDevice','controlTransfer(','bulkTransfer(',
            'import android.bluetooth.BluetoothSocket;','createRfcommSocket','writeCharacteristic(',
            'writeDescriptor(','ACTION_OPEN_DOCUMENT','ACTION_GET_CONTENT']:
    if tok in scan: raise SystemExit(f'R29 FAIL forbidden Android hardware token: {tok}')

# R29 tool itself is offline only and must not create/write MVA or open transports.
tool=(root/'tools/r29_helper_readback_offline.py').read_text()
for tok in ['UsbManager','pyusb','serial.Serial','socket.socket','BluetoothSocket','createRfcommSocket','def pack_mva','def build_mva','controlTransfer(','bulkTransfer(']:
    if tok in tool: raise SystemExit(f'R29 FAIL offline tool forbidden token: {tok}')

proc=subprocess.run([
    sys.executable,str(root/'tools/r29_helper_readback_offline.py'),
    str(root/'sdk_evidence/r23_reverse/flash_boot.c'),
    '--bt-obex-upgrade-c',str(root/'sdk_evidence/r25_current_sdk/bt_obex_upgrade.c'),
    '--usb-request-c',str(root/'sdk_evidence/r23_reverse/otg_device_standard_request.c'),
    '--upgrade-c',str(root/'sdk_evidence/r23_reverse/upgrade.c'),
    '--json'
],capture_output=True,text=True,check=True)
now=json.loads(proc.stdout)
if now != s:
    raise SystemExit('R29 FAIL deterministic verifier output changed')
print('R29 offline/helper/readback guard: PASS')
print('- package03 helper fingerprint reproduced')
print('- ID3 parser handler skips by framed length; no helper execution/copy proven')
print('- internal SpiFlashRead exists, but host arbitrary readback remains NOT proven')
print('- stock backup/live probe remain BLOCKED')
