#!/usr/bin/env python3
"""R28 offline MVA/package/recovery verifier for the BP1048P4 reference SDK.

STRICTLY OFFLINE.  This program only reads local files.  It does not contain
USB/Bluetooth transport code, does not create MVA packages, and never modifies
an input image.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from r26_flashboot_offline_inspect import reconstruct  # type: ignore
from nds32lite import decode_one  # type: ignore

REF_SHA = "cd0e4e03f7072abd48fea2aeb5a54d9360b65acb1bd4d1b37734438cbe5f47c6"
MVA_SIG = b"MV\xB1X"

# Reference flashboot offsets recovered in R28.
CRC_FUNC = 0x3F36
CRC_TABLE = 0xC214
PARSER = 0x4150
MAKER = 0x5A78
MAKER_TEMPLATE = 0xD464
HELPER_BLOB = 0xCE74
HELPER_BLOB_LEN = 1520


def crc16_xmodem(data: bytes, init: int = 0) -> int:
    """CRC algorithm implemented by reference helper @0x3F36.

    poly=0x1021, init supplied by caller. The package maker supplies init=0.
    """
    crc = init & 0xFFFF
    for x in data:
        crc ^= x << 8
        for _ in range(8):
            if crc & 0x8000:
                crc = ((crc << 1) ^ 0x1021) & 0xFFFF
            else:
                crc = (crc << 1) & 0xFFFF
    return crc


def u32le(b: bytes) -> int:
    return int.from_bytes(b, "little")


def parse_mva_bytes(data: bytes) -> dict:
    """Parse only the framing proven by the R28 reference parser/maker.

    This is an inspector, not a packer. It never emits a firmware container.
    """
    out = {
        "size": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "signature_ok": False,
        "record_count": None,
        "records": [],
        "trailer": None,
        "parse_complete": False,
    }
    if len(data) < 5:
        out["error"] = "shorter than 5-byte header"
        return out
    out["signature_hex"] = data[:4].hex(" ")
    out["signature_ok"] = data[:4] == MVA_SIG
    out["record_count"] = data[4]
    if not out["signature_ok"]:
        out["error"] = "signature is not 4D 56 B1 58"
        return out

    pos = 5
    recs = []
    for index in range(data[4]):
        if pos + 5 > len(data):
            out["error"] = f"record {index}: truncated ID/length"
            return out
        rid = data[pos]
        n = u32le(data[pos + 1:pos + 5])
        payload_start = pos + 5
        payload_end = payload_start + n
        if payload_end > len(data):
            out["error"] = f"record {index}: payload length exceeds file"
            return out
        rec = {
            "index": index,
            "id": rid,
            "record_offset": pos,
            "payload_length": n,
            "payload_offset": payload_start,
            "end_offset": payload_end,
        }
        if rid in (2, 3, 4, 5) and n >= 4:
            rec["target_offset_le32"] = u32le(data[payload_start:payload_start + 4])
            rec["data_length_after_offset"] = n - 4
        if rid == 1:
            rec["known_role"] = "metadata/preamble payload; exact semantic meaning not proven"
        elif rid == 2:
            rec["known_role"] = "code image record: 4-byte target offset + code bytes"
        elif rid == 3:
            rec["known_role"] = "helper record: 4-byte target offset + bundled helper blob"
        elif rid == 4:
            rec["known_role"] = "constant-data record: 4-byte target offset + data"
        elif rid == 5:
            rec["known_role"] = "config-data record: 4-byte target offset + data"
        else:
            rec["known_role"] = "unknown/unsupported record id"
        recs.append(rec)
        pos = payload_end
    out["records"] = recs

    remain = len(data) - pos
    if remain == 4:
        trailer_word = u32le(data[pos:pos+4])
        calc = crc16_xmodem(data[:pos], 0)
        out["trailer"] = {
            "offset": pos,
            "raw_hex": data[pos:pos+4].hex(" "),
            "word_le32": trailer_word,
            "crc16_xmodem_calculated": calc,
            "low16_matches": (trailer_word & 0xFFFF) == calc,
            "upper16": trailer_word >> 16,
            "note": "reference maker appends a 4-byte word after CRC16/XMODEM calculation; low 16 bits are the proven CRC value",
        }
        out["parse_complete"] = True
    elif remain == 0:
        out["trailer"] = {"present": False, "note": "records consume whole input; reference maker normally appends 4 bytes"}
        out["parse_complete"] = True
    else:
        out["error"] = f"{remain} trailing bytes after declared records; expected reference-maker 4-byte trailer"
    return out


def parse_mva_file(path: Path) -> dict:
    before = path.stat()
    data = path.read_bytes()
    out = parse_mva_bytes(data)
    after = path.stat()
    out["path"] = str(path)
    out["input_unchanged"] = (before.st_size == after.st_size and before.st_mtime_ns == after.st_mtime_ns)
    return out


def dec_check(buf: bytes, pc: int, mnem: str, frag: str) -> str:
    ins = decode_one(buf, pc)
    if ins is None or ins.mnem != mnem or frag not in ins.ops:
        got = "none" if ins is None else f"{ins.mnem} {ins.ops}"
        raise SystemExit(f"R28 FAIL instruction @0x{pc:04X}: {got}; expected {mnem} / {frag}")
    return str(ins)


def decode_text(path: Path) -> str:
    raw = path.read_bytes()
    for enc in ("utf-8", "gb18030", "latin1"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            pass
    return raw.decode("latin1", errors="replace")


def reference_evidence(flash_boot_c: Path, usb_req_c: Path | None = None,
                       upgrade_c: Path | None = None, flash_config_h: Path | None = None) -> dict:
    b = reconstruct(flash_boot_c)
    sha = hashlib.sha256(b).hexdigest()
    if sha != REF_SHA:
        raise SystemExit(f"R28 FAIL reference flashboot SHA changed: {sha}")

    # Parser header/maker framing checks.
    checks = [
        dec_check(b, 0x46B2, "bnec", "r0,#77"),   # M
        dec_check(b, 0x46BA, "bnec", "r0,#86"),   # V
        dec_check(b, 0x46C2, "bnec", "r0,#177"),  # B1 binary chip byte
        dec_check(b, 0x46CA, "beqc", "r0,#88"),   # X
        dec_check(b, 0x4158, "movi55", "r1,#4"),   # seek to count byte
        dec_check(b, 0x4176, "movi55", "r1,#5"),   # first record starts at offset 5
        dec_check(b, 0x5AB0, "movi55", "r0,#3"),   # package 03 id
        dec_check(b, 0x5AB6, "movi", "r0,#1524"), # package 03 payload length
        dec_check(b, 0x5AE0, "movi", "r1,#52852"),# helper source 0xCE74
        dec_check(b, 0x5AE4, "movi", "r2,#1520"), # helper bytes
        dec_check(b, 0x5AF4, "movi55", "r0,#2"),  # package 02 id
        dec_check(b, 0x5B98, "movi", "r1,#164"),  # first fast-CRC span
        dec_check(b, 0x5C3C, "movi55", "r2,#0"),  # final package CRC init=0
        dec_check(b, 0x5C3E, "jal", "0x3F36"),    # final package CRC helper
    ]

    template = b[MAKER_TEMPLATE:MAKER_TEMPLATE+13]
    expected_template = bytes.fromhex("4D 56 B1 58 03 01 03 00 00 00 35 BA 69")
    if template != expected_template:
        raise SystemExit(f"R28 FAIL maker template changed: {template.hex()}")

    # CRC table is standard CRC-16/CCITT table in little-endian storage.
    table_first = [int.from_bytes(b[CRC_TABLE+i:CRC_TABLE+i+2], "little") for i in range(0, 8, 2)]
    if table_first != [0x0000, 0x1021, 0x2042, 0x3063]:
        raise SystemExit(f"R28 FAIL CRC table mismatch: {table_first}")
    if crc16_xmodem(b"123456789") != 0x31C3:
        raise SystemExit("R28 FAIL CRC16/XMODEM self-test")

    helper_sha = hashlib.sha256(b[HELPER_BLOB:HELPER_BLOB+HELPER_BLOB_LEN]).hexdigest()

    # Maker layout from exact constants/copy destinations.
    default_layout = {
        "header": {"offset":0, "bytes_hex":"4d 56 b1 58", "record_count":3},
        "record_01": {"record_offset":5, "id":1, "payload_length":3, "payload_hex":"35 ba 69", "role":"exact role not proven"},
        "record_03": {"record_offset":13, "id":3, "payload_length":1524, "target_offset":0,
                      "helper_blob_length":HELPER_BLOB_LEN, "helper_blob_flashboot_offset":"0xCE74",
                      "helper_blob_sha256":helper_sha},
        "record_02": {"record_offset":1542, "id":2,
                      "payload_length_formula":"code_length + 4", "target_offset":0,
                      "code_data_offset":1551},
        "trailer": {"offset_formula":"code_length + 1551", "size":4,
                    "total_size_formula":"code_length + 1555",
                    "checksum":"CRC-16/XMODEM poly 0x1021 init 0 over bytes before trailer; helper result stored as a 4-byte word"},
    }

    # Source-code metadata/FastCRC exclusions recovered from maker call sequence.
    code_metadata = {
        "code_length_field": {
            "offsets_hex":["0xE0","0xE1","0xE2","0xE3"],
            "meaning":"0xE0..0xE2 = 24-bit little-endian code length; 0xE3 = additive byte check",
            "check":"(byte[E0] + byte[E1] + byte[E2]) & 0xFF == byte[E3]",
        },
        "code_magic": {"offset":"0xC0", "little_endian_value":"0xB0BEBDC9"},
        "fast_crc_included_ranges":["0x0000..0x00A3","0x00A8..0x00BB","0x00C0..0x00CB","0x00D4..0x00E3","0x00EC..code_length-1"],
        "fast_crc_excluded_ranges":["0x00A4..0x00A7","0x00BC..0x00BF","0x00CC..0x00D3","0x00E4..0x00EB"],
        "warning":"exact purpose of every excluded metadata field is not fully decoded; do not synthesize a production image from this alone",
    }

    usb_feature = None
    if usb_req_c:
        txt = decode_text(usb_req_c)
        required = [
            "else if((Setup[3] == 0x03)&&(Setup[0] == 0xA1))",
            "Setup[0] = 0x55;",
            "start_up_grate(AppResourceUsbDevice);",
            "Setup[0] = 0;",
            "else if((Setup[3] == 0x03)&&(Setup[0] == 0x21))",
            "if(Request[0] == 0x55)",
            "else if(Request[0] == 0xAA)",
        ]
        missing=[x for x in required if x not in txt]
        if missing:
            raise SystemExit("R28 FAIL normal-app Feature source mismatch: "+repr(missing))
        usb_feature = {
            "safe_identity_query": False,
            "get_feature_unarmed":"sets Setup[0]=0 and returns bytes from the USB Setup packet buffer; not firmware identity/version data",
            "get_feature_armed":"sets Setup[0]=0x55, returns Setup bytes, then reference source calls start_up_grate(AppResourceUsbDevice)",
            "set_feature_0x55":"compares Request+1[4] against memory at 0x10000+0xB8 and arms pc_upgrade when different",
            "set_feature_0xAA":"arms pc_upgrade unconditionally",
            "r28_conclusion":"Feature GET is not a safe identity/readback primitive; after an armed state it is a transition trigger in the reference source",
        }

    status_api = None
    if upgrade_c:
        txt=decode_text(upgrade_c)
        if "uint8_t Report_Error_Code(void)" not in txt or "return SREG_FLASH_BOOT_FLAGE.ERROR_CODE;" not in txt:
            raise SystemExit("R28 FAIL Report_Error_Code source mismatch")
        status_api = {
            "Report_Error_Code":"internal one-byte flashboot status getter from memory-mapped flag",
            "read_side_effect":"none in getter itself",
            "transport_exposure":"not exposed by the inspected normal USB HID class request source",
            "note":"report_up_grate() is different and clears ROM user-register result bits after reading; do not treat it as read-only",
        }
        if usb_req_c and "Report_Error_Code" in decode_text(usb_req_c):
            raise SystemExit("R28 FAIL unexpected Report_Error_Code USB exposure")

    ref_map = None
    if flash_config_h:
        txt=decode_text(flash_config_h)
        for token in ["CONST_DATA_ADDR", "0x198000", "USER_DATA_ADDR", "0x1F0000 + 0x200000", "BT_CONFIG_ADDR", "0x1FF000 + 0x200000"]:
            if token not in txt:
                raise SystemExit(f"R28 FAIL flash_config token missing: {token}")
        ref_map = {
            "scope":"REFERENCE_SDK_ONLY_NOT_PRODUCTION_BOARD_PROOF",
            "CODE_ADDR":"0x000000",
            "CONST_DATA_ADDR":"0x198000",
            "AUDIO_EFFECT_ADDR":"0x3C8000",
            "FLASHFS_ADDR":"0x3D0000",
            "USER_DATA_ADDR":"0x3F0000",
            "BP_DATA_ADDR":"0x3F3000",
            "BT_DATA_ADDR":"0x3FB000",
            "USER_CONFIG_ADDR":"0x3FE000",
            "BT_CONFIG_ADDR":"0x3FF000",
        }

    return {
        "revision":"R28",
        "mode":"OFFLINE_ONLY",
        "device_io":False,
        "reference_flashboot_size":len(b),
        "reference_flashboot_sha256":sha,
        "mva_framing":{
            "header_signature_hex":"4D 56 B1 58",
            "header_interpretation":"'M','V', binary chip byte 0xB1, 'X'",
            "record_count_offset":4,
            "first_record_offset":5,
            "record_shape":"id:u8 + payload_length:u32 little-endian + payload[payload_length]",
            "record_ids":{
                "1":"metadata/preamble; exact payload meaning not proven",
                "2":"code image: target_offset_le32 + code bytes",
                "3":"bundled helper: target_offset_le32 + helper bytes",
                "4":"constant data: target_offset_le32 + data",
                "5":"config data: target_offset_le32 + data",
            },
            "reference_maker_default_layout":default_layout,
            "package_trailer":"4 bytes appended after the declared records; reference maker computes CRC16/XMODEM over all preceding package bytes and stores the helper result as a word",
        },
        "crc":{
            "algorithm":"CRC-16/XMODEM",
            "poly":"0x1021",
            "init":"0x0000",
            "xorout":"0x0000",
            "check_123456789":"0x31C3",
            "table_offset":"0xC214",
            "function_offset":"0x3F36",
        },
        "code_metadata":code_metadata,
        "normal_app_feature_report":usb_feature,
        "internal_upgrade_status":status_api,
        "reference_p4_flash_map":ref_map,
        "recovery_assessment":{
            "stock_backup_obtained":False,
            "stock_full_flash_readback_path_proven":False,
            "mva_is_backup_readback_format":False,
            "reason":"the recovered MVA flow packages host/source image sections for validation/programming; no command in the recovered flashboot HID set returns arbitrary stock flash contents",
            "production_layout_proven":False,
            "live_flash_action_allowed":False,
        },
        "live_probe_allowed":False,
        "proven_live_identity_or_readback_command":None,
        "blocked_actions":["Feature 0x55/0xAA", "flashboot command send", "cxxx", "upinfo", "chiperas", "bootdat", "codedata", "constdat", "cnfgdat", "btupdat", "erase/program/commit/apply/reset"],
        "decoded_reference_checks":checks,
    }


def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument("flash_boot_c", type=Path)
    ap.add_argument("--usb-request-c", type=Path)
    ap.add_argument("--upgrade-c", type=Path)
    ap.add_argument("--flash-config-h", type=Path)
    ap.add_argument("--image", type=Path, help="optional local MVA-like file to inspect; read-only")
    ap.add_argument("--json", action="store_true")
    a=ap.parse_args()
    out=reference_evidence(a.flash_boot_c,a.usb_request_c,a.upgrade_c,a.flash_config_h)
    if a.image:
        out["image_inspection"] = parse_mva_file(a.image)
    if a.json:
        print(json.dumps(out,indent=2,ensure_ascii=False))
    else:
        print("R28 OFFLINE MVA / RECOVERY REVERSE")
        print("MVA framing: MV B1 X + count; records=id:u8,len:u32le,payload")
        print("Package checksum: CRC-16/XMODEM poly 0x1021 init 0, stored in 4-byte trailer word")
        print("Normal-app Feature GET: NOT identity/version; armed GET can trigger boot transition")
        print("Stock full-flash readback: NOT PROVEN")
        print("Live probe: BLOCKED")
        if a.image:
            print(json.dumps(out["image_inspection"],indent=2,ensure_ascii=False))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
