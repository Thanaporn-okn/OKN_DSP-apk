#!/usr/bin/env python3
from pathlib import Path
import re, subprocess

root = Path(__file__).resolve().parents[1]
e = root / "sdk_evidence/r25_current_sdk"
req = ["bt_config.h", "bt_app_func.c", "bt_obex_app.c", "bt_stack_api.h", "bt_obex_upgrade.c", "ble_app_func.c", "obex_sdp.o", "obex.o", "obex_app.o", "bt_stack_api.o"]
for name in req:
    if not (e/name).is_file():
        raise SystemExit(f"missing SDK evidence: {name}")

bt_config=(e/'bt_config.h').read_text(errors='replace')
bt_app=(e/'bt_app_func.c').read_text(errors='replace')
obex_app=(e/'bt_obex_app.c').read_text(errors='replace')
upgrade=(e/'bt_obex_upgrade.c').read_text(errors='replace')
ble=(e/'ble_app_func.c').read_text(errors='replace')
stack_h=(e/'bt_stack_api.h').read_text(errors='replace')

checks = {
    'BT_OBEX_SUPPORT disabled in reference': bool(re.search(r'#define\s+BT_OBEX_SUPPORT\s+DISABLE', bt_config)),
    'MVA flag commented in reference': bool(re.search(r'//\s*#define\s+MVA_BT_OBEX_UPDATE_FUNC_SUPPORT', bt_config)),
    'OBEX profile bit 0x0020': bool(re.search(r'BT_PROFILE_SUPPORTED_OBEX\s+0x0020', stack_h)),
    'GetSupportProfiles adds OBEX profile': 'profiles |= BT_PROFILE_SUPPORTED_OBEX' in bt_app,
    'OBEX callback registered when enabled': 'ObexAppCallbackRegister(BtObexCallback)' in bt_app,
    'MVA callback routes to ObexUpdateProc': 'ObexUpdateProc(param)' in obex_app,
    'MVA LENGTH can arm erase worker': 'case BT_OBEX_LENGTH' in upgrade and 'obex_start = 1' in upgrade,
    'worker erases staging block': 'SpiFlashErase(BLOCK_ERASE, FLASH_MVA_UPDATE_START_OFFSET/65536, 1)' in upgrade,
    'BLE address byte0 rule': 'ble_LocalDeviceAddr[0] = btStackConfigParams->ble_LocalDeviceAddr[0]|0xc0' in bt_app,
    'BLE address byte4 rule': 'ble_LocalDeviceAddr[4] += 0x60' in bt_app,
    'AB00 advertised': '0x03, 0x03, 0x00, 0xab' in ble,
    'AB01 profile declared': 'CHARACTERISTIC-AB01-READ | WRITE | WRITE_WITHOUT_RESPONSE' in ble,
    'AB02 notify declared': 'CHARACTERISTIC-AB02-NOTIFY' in ble,
    'AB03 notify declared': 'CHARACTERISTIC-AB03-NOTIFY' in ble,
    'AB00 source has no ObexUpdateProc reference': 'ObexUpdateProc' not in ble,
}
for label, ok in checks.items():
    if not ok: raise SystemExit(f"R25 SDK evidence FAIL: {label}")
    print(f"PASS: {label}")

def out(*cmd):
    return subprocess.check_output(cmd, text=True, stderr=subprocess.STDOUT)

s = out('strings','-a',str(e/'obex_sdp.o'))
if 'Object Push' not in s:
    raise SystemExit('R25 SDK evidence FAIL: Object Push string absent from obex_sdp.o')

dump = out('objdump','-s','-j','.rodata.ObexClassId',str(e/'obex_sdp.o')).lower().replace(' ','')
# SDP sequence + UUID16 0x1105 appears as bytes 35 03 19 11 05.
if '3503191105' not in dump:
    raise SystemExit('R25 SDK evidence FAIL: 0x1105 class id bytes absent from obex_sdp.o')

rel_obex = out('objdump','-r',str(e/'obex.o'))
rel_app = out('objdump','-r',str(e/'obex_app.o'))
rel_stack = out('objdump','-r',str(e/'bt_stack_api.o'))
for label, text, token in [
    ('ObexAppInit -> BTStackInitObex', rel_app, 'BTStackInitObex'),
    ('BTStackInitObex -> ObexRegisterSdpService', rel_obex, 'ObexRegisterSdpService'),
    ('BTStackRunInit -> ObexAppInit', rel_stack, 'ObexAppInit'),
]:
    if token not in text: raise SystemExit(f'R25 SDK evidence FAIL: {label}')
    print(f'PASS: {label}')

classic='63:57:DC:10:68:0E'
b=[int(x,16) for x in classic.split(':')]
b[0]|=0xC0; b[4]=(b[4]+0x60)&0xff
calc=':'.join(f'{x:02X}' for x in b)
expected='E3:57:DC:10:C8:0E'
if calc != expected: raise SystemExit(f'R25 SDK evidence FAIL: address transform {calc} != {expected}')
print(f'PASS: live SDK address transform {classic} -> {calc}')
print('R25 offline SDK evidence chain: PASS')
