#!/usr/bin/env python3
"""R33 offline flash-read/readback gate analysis for BP1048P4 reference flashboot.

FILE-ONLY / OFFLINE. No USB, BLE, HID, serial, socket, subprocess, or device I/O.
The goal is to decide whether the already-recovered internal flash-read primitive
is exposed to the proven 256-byte HID updater response path as arbitrary bytes.
"""
from __future__ import annotations
import argparse, hashlib, json, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))
from r26_flashboot_offline_inspect import reconstruct  # type: ignore
from nds32lite import disasm  # type: ignore

REF_SHA = "cd0e4e03f7072abd48fea2aeb5a54d9360b65acb1bd4d1b37734438cbe5f47c6"
READ_PRIMITIVE = 0x0F9C
WRITE_PRIMITIVE = 0x1204
ERASE_WRAPPER = 0x44F0
PROGRAM_VERIFY_WRAPPER = 0x45EE
HID_RESPONSE_WRAPPER = 0x4BF6
HID_CONTROL_SEND = 0x9436
MEMCMP = 0xACDC

HANDLERS = {
    "cxxx": (0x4C8A, 0x50B2),
    "chiperas": (0x50B2, 0x517C),
    "bootdat": (0x517C, 0x52D4),
    "codedata": (0x52D4, 0x5406),
    "constdat": (0x5406, 0x550A),
    "cnfgdat": (0x550A, 0x560E),
    "btupdat": (0x560E, 0x575E),
    "upinfo": (0x575E, 0x57BE),
}
EXPECTED_READ_CALLERS = [
    0x435E,0x4388,0x460A,0x4932,0x4A4C,0x4B5E,0x5276,0x53BE,0x565C,0x571E,
    0x5860,0x5886,0x5898,0x58AA,0x58BC,0x58CE,0x58E0,0x58F2,0x5CAE,
]
EXPECTED_RESPONSE_CALLERS = [
    0x5022,0x5154,0x51F8,0x5218,0x5296,0x52B6,0x5360,0x53FA,
    0x5498,0x54FE,0x559C,0x5602,0x5746,0x5756,
]

def calls_to(buf: bytes, target: int) -> list[int]:
    return [i.pc for i in disasm(buf,0,len(buf)) if i.mnem == "jal" and i.target == target]

def calls_in(buf: bytes, start: int, end: int) -> list[int]:
    return [i.target for i in disasm(buf,start,end) if i.mnem == "jal" and i.target is not None]

def handler_for(pc: int) -> str | None:
    for name,(s,e) in HANDLERS.items():
        if s <= pc < e:
            return name
    return None

def main() -> None:
    ap=argparse.ArgumentParser()
    ap.add_argument("flash_boot_c", type=Path)
    ap.add_argument("--flash-config-h", type=Path, required=True)
    ap.add_argument("--json", action="store_true")
    a=ap.parse_args()
    b=reconstruct(a.flash_boot_c)
    sha=hashlib.sha256(b).hexdigest()
    if sha != REF_SHA:
        raise SystemExit(f"R33 FAIL reference flashboot SHA changed: {sha}")

    read_callers=calls_to(b,READ_PRIMITIVE)
    response_callers=calls_to(b,HID_RESPONSE_WRAPPER)
    control_send_callers=calls_to(b,HID_CONTROL_SEND)
    if read_callers != EXPECTED_READ_CALLERS:
        raise SystemExit(f"R33 FAIL internal read callers changed: {[hex(x) for x in read_callers]}")
    if response_callers != EXPECTED_RESPONSE_CALLERS:
        raise SystemExit(f"R33 FAIL HID response callers changed: {[hex(x) for x in response_callers]}")
    if control_send_callers != [0x2A7E,0x2AE4,0x4C36]:
        raise SystemExit(f"R33 FAIL HID control-send callers changed: {[hex(x) for x in control_send_callers]}")

    # The write wrapper is behaviorally pinned as program -> readback -> memcmp verification.
    verify_calls=calls_in(b,PROGRAM_VERIFY_WRAPPER,0x4626)
    seq=[x for x in verify_calls if x in (WRITE_PRIMITIVE,READ_PRIMITIVE,MEMCMP)]
    if seq != [WRITE_PRIMITIVE,READ_PRIMITIVE,MEMCMP]:
        raise SystemExit(f"R33 FAIL write/read/verify sequence changed: {[hex(x) for x in seq]}")

    # Every updater response-wrapper call is inside one of the eight known command handlers.
    outside=[pc for pc in response_callers if handler_for(pc) is None]
    if outside:
        raise SystemExit(f"R33 FAIL hidden response call outside known handlers: {[hex(x) for x in outside]}")

    per_handler={}
    for name,(s,e) in HANDLERS.items():
        per_handler[name]={
            "direct_internal_read_calls":[f"0x{x:04X}" for x in read_callers if s <= x < e],
            "hid_response_calls":[f"0x{x:04X}" for x in response_callers if s <= x < e],
            "calls_erase_wrapper":ERASE_WRAPPER in calls_in(b,s,e),
            "calls_program_verify_wrapper":PROGRAM_VERIFY_WRAPPER in calls_in(b,s,e),
        }

    # Reference image embeds the compiled BP1048P4 layout constants, not only source comments.
    embedded={
        "CONST_DATA_ADDR": int.from_bytes(b[0xB0:0xB4],"little"),
        "USER_DATA_ADDR": int.from_bytes(b[0xB4:0xB8],"little"),
        "AUDIO_EFFECT_ADDR": int.from_bytes(b[0xD8:0xDC],"little"),
    }
    expected_embedded={"CONST_DATA_ADDR":0x198000,"USER_DATA_ADDR":0x3F0000,"AUDIO_EFFECT_ADDR":0x3C8000}
    if embedded != expected_embedded:
        raise SystemExit(f"R33 FAIL embedded reference map changed: {embedded}")
    fc=a.flash_config_h.read_text(errors="replace")
    for token in [
        "AUDIO_EFFECT_ADDR  \t\t0x1C8000 + 0x200000",
        "USER_DATA_ADDR       0x1F0000 + 0x200000",
        "BT_CONFIG_ADDR       (0x1FF000 + 0x200000)",
    ]:
        if token not in fc:
            # whitespace differs across SDK dumps; check normalized fragments below.
            pass
    compact=" ".join(fc.replace("\t"," ").split())
    for frag in ["0x1C8000 + 0x200000","0x1F0000 + 0x200000","0x1FF000 + 0x200000"]:
        if frag not in compact:
            raise SystemExit("R33 FAIL flash_config reference mapping fragment missing: "+frag)

    host_read_exposure=[]
    for pc in read_callers:
        h=handler_for(pc)
        if h:
            host_read_exposure.append({"read_call":f"0x{pc:04X}","handler":h,"note":"internal read in updater flow; no distinct read command"})

    out={
        "revision":"R33",
        "mode":"OFFLINE_ONLY",
        "device_io":False,
        "reference_flashboot":{"size":len(b),"sha256":sha},
        "reference_internal_flash_read":{
            "address":"0x0F9C",
            "caller_count":len(read_callers),
            "callers":[f"0x{x:04X}" for x in read_callers],
            "behavioral_anchor":"0x45EE calls 0x1204 then 0x0F9C then memcmp (0xACDC), proving program/readback/verify behavior in the reference image",
        },
        "host_hid_response_surface":{
            "response_wrapper":"0x4BF6",
            "response_wrapper_caller_count":len(response_callers),
            "response_wrapper_callers":[f"0x{x:04X}" for x in response_callers],
            "all_response_wrapper_callers_inside_known_8_handlers":True,
            "hidden_response_wrapper_caller_outside_known_handlers":False,
            "control_send_0x9436_callers":[f"0x{x:04X}" for x in control_send_callers],
        },
        "handlers":per_handler,
        "reference_layout":{
            "source_scope":"reference BP1048P4 SDK build only",
            "embedded_header":{k:f"0x{v:06X}" for k,v in embedded.items()},
            "source_macros":{
                "CODE_ADDR":"0x000000","CONST_DATA_ADDR":"0x198000",
                "AUDIO_EFFECT_ADDR":"0x3C8000","FLASHFS_ADDR":"0x3D0000",
                "USER_DATA_ADDR":"0x3F0000","BP_DATA_ADDR":"0x3F3000",
                "BT_DATA_ADDR":"0x3FB000","USER_CONFIG_ADDR":"0x3FE000","BT_CONFIG_ADDR":"0x3FF000",
            },
            "reference_address_span_requires_at_least":"0x400000 bytes (4 MiB address space)",
            "production_board_layout_proven":False,
        },
        "assessment":{
            "internal_flash_read_primitive_proven_in_reference":True,
            "arbitrary_flash_bytes_routed_to_proven_hid_response_path":False,
            "separate_safe_flash_read_command_found":False,
            "safe_stock_backup_path_found":False,
            "production_flash_layout_proven":False,
            "flash_gate":"CLOSED",
            "hardware_action_authorized":False,
            "scope_limit":"Static proof covers the recovered reference flashboot + current SDK evidence. It does not claim the production board image is identical.",
        },
        "blocked_actions":["hardware probe","Feature 0x55/0xAA","ACP 0x00/0x11",".mva/OBEX PUT","erase/program/commit/apply/reset"],
    }
    if a.json:
        print(json.dumps(out,ensure_ascii=False,indent=2))
    else:
        print("R33 OFFLINE FLASH READBACK GATE")
        print(f"reference flashboot: {sha}")
        print(f"internal read primitive 0x0F9C callers: {len(read_callers)}")
        print(f"HID response wrapper 0x4BF6 callers: {len(response_callers)}; all in known 8 updater handlers")
        print("arbitrary flash -> HID readback path: NOT FOUND")
        print("production layout: NOT PROVEN")
        print("FLASH_GATE=CLOSED")

if __name__ == "__main__":
    main()
