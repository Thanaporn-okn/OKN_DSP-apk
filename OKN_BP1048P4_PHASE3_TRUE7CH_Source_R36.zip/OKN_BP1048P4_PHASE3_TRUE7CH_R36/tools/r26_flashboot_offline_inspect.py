#!/usr/bin/env python3
"""R26 offline-only inspector for the BP1048P4 reference flashboot C array.

NO DEVICE I/O. NO USB. NO OBEX. NO FLASH WRITES.
The script reconstructs the 64 KiB reference image in memory from flash_boot.c
using the SDK configuration values, then extracts static evidence only.
"""
from __future__ import annotations
import argparse, ast, hashlib, json, re, struct
from pathlib import Path

MACROS = {
    "CONST_DATA_ADDR": 0x198000,
    "USER_DATA_ADDR": 0x3F0000,
    "AUDIO_EFFECT_ADDR": 0x3C8000,
    "BOOT_UART_CONFIG": 0x36,
    "JUDGEMENT_STANDARD": 0x55,
    "UP_PORT": 0x0D,
}
COMMANDS = ["chiperas", "upinfo", "btupdat", "cnfgdat", "constdat", "codedata", "bootdat", "cxxx"]
DANGEROUS = {"chiperas", "btupdat", "cnfgdat", "constdat", "codedata", "bootdat"}
UNKNOWN = {"upinfo", "cxxx"}

class SafeEval(ast.NodeVisitor):
    ALLOWED_BIN = {ast.BitAnd, ast.BitOr, ast.LShift, ast.RShift, ast.Add, ast.Sub}
    ALLOWED_UNARY = {ast.UAdd, ast.USub, ast.Invert}
    def visit_Expression(self, node): self.visit(node.body)
    def visit_Constant(self, node):
        if not isinstance(node.value, int): raise ValueError("non-int constant")
    def visit_Name(self, node):
        if node.id not in MACROS: raise ValueError(f"unknown name {node.id}")
    def visit_BinOp(self, node):
        if type(node.op) not in self.ALLOWED_BIN: raise ValueError("operator blocked")
        self.visit(node.left); self.visit(node.right)
    def visit_UnaryOp(self, node):
        if type(node.op) not in self.ALLOWED_UNARY: raise ValueError("unary operator blocked")
        self.visit(node.operand)
    def generic_visit(self, node):
        if isinstance(node, (ast.Load,)): return
        raise ValueError(f"syntax blocked: {type(node).__name__}")

def safe_eval(expr: str) -> int:
    tree = ast.parse(expr, mode="eval")
    SafeEval().visit(tree)
    return int(eval(compile(tree, "<flash_boot.c>", "eval"), {"__builtins__": {}}, MACROS))

def reconstruct(path: Path) -> bytes:
    text = path.read_text(errors="replace")
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.S)
    m = re.search(r"flash_data\s*\[\s*65536\s*\]\s*=\s*\{(.*?)\}\s*;", text, re.S)
    if not m: raise SystemExit("flash_data[65536] initializer not found")
    body = re.sub(r"//.*", "", m.group(1))
    vals=[]
    for raw in body.split(','):
        token=raw.strip()
        if not token: continue
        v=safe_eval(token)
        if not 0 <= v <= 0xFF: raise SystemExit(f"byte out of range: {token} -> {v}")
        vals.append(v)
    if len(vals) != 65536: raise SystemExit(f"expected 65536 bytes, got {len(vals)}")
    return bytes(vals)

def cstr(buf: bytes, off: int) -> str:
    end=buf.find(b"\0", off)
    if end < 0: end=len(buf)
    return buf[off:end].decode("ascii", errors="replace")

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("flash_boot_c", type=Path)
    ap.add_argument("--json", action="store_true")
    args=ap.parse_args()
    b=reconstruct(args.flash_boot_c)
    sha=hashlib.sha256(b).hexdigest()
    def exact_cstring_offset(s: str) -> int:
        needle=s.encode()+b"\0"
        pos=0
        candidates=[]
        while True:
            i=b.find(needle,pos)
            if i<0: break
            # Prefer a real C-string boundary (start of image or previous byte NUL).
            if i==0 or b[i-1]==0:
                candidates.append(i)
            pos=i+1
        if not candidates:
            return -1
        # Command table strings are grouped together around 0xCBE8; choose the
        # highest boundary match to avoid the diagnostic literal cmd_cxxx.
        return max(candidates)
    hits={s: exact_cstring_offset(s) for s in COMMANDS}
    table_off=None
    ptrs=[]
    # Find a run of 8 little-endian pointers to the command strings.
    expected=[hits[s] for s in COMMANDS]
    pattern=b''.join(struct.pack('<I', x) for x in expected)
    table_off=b.find(pattern)
    if table_off >= 0:
        ptrs=[struct.unpack_from('<I', b, table_off+4*i)[0] for i in range(8)]
    usbc=b.find(b'USBC')
    mvb=b.find(b'MVB1X')
    out={
        "mode":"OFFLINE_ONLY",
        "device_io":False,
        "size":len(b),
        "sha256":sha,
        "reference_config":MACROS,
        "config_bytes_0x100_0x103":b[0x100:0x104].hex().upper(),
        "usbc_offset":usbc,
        "mvb1x_literal_offset":mvb,
        "command_table_offset":table_off,
        "commands":[{"name":s,"string_offset":hits[s],"classification":("DESTRUCTIVE_OR_WRITE" if s in DANGEROUS else "UNPROVEN_DO_NOT_PROBE")} for s in COMMANDS],
        "command_table_pointers":ptrs,
        "transport_inference":"USB Mass Storage Bulk-Only Transport / CBW-style evidence; custom ASCII CDB command set. Exact production behavior remains unproven.",
        "live_probe_allowed":False,
        "live_probe_reason":"No proven non-destructive flashboot entry path; 0x55/0xAA boot-entry probes are explicitly blocked, and upinfo/cxxx side effects are not proven absent.",
    }
    if args.json:
        print(json.dumps(out, indent=2, ensure_ascii=False))
    else:
        print("R26 OFFLINE ONLY")
        print(f"size={len(b)} sha256={sha}")
        print(f"config[0x100:0x104]={b[0x100:0x104].hex(' ').upper()}")
        print(f"USBC offset=0x{usbc:X}" if usbc>=0 else "USBC not found")
        print(f"command table offset=0x{table_off:X}" if table_off>=0 else "command table not found")
        for x in out['commands']:
            print(f"  {x['name']:8s} @0x{x['string_offset']:04X}  {x['classification']}")
        print("LIVE PROBE: BLOCKED")

if __name__ == '__main__': main()
