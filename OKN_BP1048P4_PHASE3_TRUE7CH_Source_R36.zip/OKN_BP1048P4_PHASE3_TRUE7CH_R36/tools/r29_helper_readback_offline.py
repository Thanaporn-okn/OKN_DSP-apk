#!/usr/bin/env python3
"""R29 offline helper/readback analysis for BP1048P4 reference evidence.

STRICTLY OFFLINE. Reads only local source/evidence files. It does not implement
USB, Bluetooth, OBEX, MVA transfer, flash erase/program/commit, or any live
hardware transport.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from r26_flashboot_offline_inspect import reconstruct  # type: ignore
from nds32lite import decode_one  # type: ignore

REF_SHA = "cd0e4e03f7072abd48fea2aeb5a54d9360b65acb1bd4d1b37734438cbe5f47c6"
HELPER_OFF = 0xCE74
HELPER_LEN = 1520
HELPER_SHA = "db8f68feedf48671b863fbc3269cfa2dfce180f6a21a65fe6152cee239c43c12"
PARSER_JT = 0x41A8
PARSER_ID3 = 0x41D8


def entropy(data: bytes) -> float:
    if not data:
        return 0.0
    counts = [0] * 256
    for x in data:
        counts[x] += 1
    n = len(data)
    return -sum((c/n) * math.log2(c/n) for c in counts if c)


def printable_runs(data: bytes, min_len: int = 4) -> list[str]:
    runs=[]
    cur=[]
    for x in data:
        if 0x20 <= x <= 0x7e:
            cur.append(chr(x))
        else:
            if len(cur) >= min_len:
                runs.append(''.join(cur))
            cur=[]
    if len(cur) >= min_len:
        runs.append(''.join(cur))
    return runs


def ins_text(buf: bytes, pc: int) -> str:
    ins=decode_one(buf,pc)
    if ins is None:
        raise SystemExit(f"R29 FAIL decode @0x{pc:04X}")
    return str(ins)


def require_ins(buf: bytes, pc: int, mnem: str, fragment: str='') -> str:
    ins=decode_one(buf,pc)
    if ins is None or ins.mnem != mnem or (fragment and fragment not in ins.ops):
        got='none' if ins is None else f'{ins.mnem} {ins.ops}'
        raise SystemExit(f'R29 FAIL instruction @0x{pc:04X}: {got}; expected {mnem} {fragment}')
    return str(ins)


def source_read_evidence(bt_obex_upgrade_c: Path | None,
                         usb_request_c: Path | None,
                         upgrade_c: Path | None) -> dict:
    out={
        'internal_spi_flash_read_exists': False,
        'obex_source_spiflashread_call_count': 0,
        'normal_usb_request_spiflashread_call_count': 0,
        'upgrade_source_spiflashread_call_count': 0,
        'host_exposed_arbitrary_flash_read_proven': False,
        'interpretation': 'No live host readback command proven.',
    }
    if bt_obex_upgrade_c and bt_obex_upgrade_c.is_file():
        txt=bt_obex_upgrade_c.read_text(errors='replace')
        n=len(re.findall(r'\bSpiFlashRead\s*\(',txt))
        out['obex_source_spiflashread_call_count']=n
        out['internal_spi_flash_read_exists']=n > 0
        out['obex_read_roles']=[
            'MVA staging CRC verification',
            'read-after-write verification using memcmp',
        ] if n else []
        # Require the two known contexts before stating this role.
        out['obex_crc_context_present']='MvaCrcCheck' in txt and 'CRC16(Tmp,1,Crc16)' in txt
        out['obex_read_after_write_context_present']='SpiFlashWrite(write_addr' in txt and 'memcmp(opp_update_buf,obex_fifo_temp' in txt
    if usb_request_c and usb_request_c.is_file():
        txt=usb_request_c.read_text(errors='replace')
        out['normal_usb_request_spiflashread_call_count']=len(re.findall(r'\bSpiFlashRead\s*\(',txt))
    if upgrade_c and upgrade_c.is_file():
        txt=upgrade_c.read_text(errors='replace')
        out['upgrade_source_spiflashread_call_count']=len(re.findall(r'\bSpiFlashRead\s*\(',txt))
    return out


def analyze(flash_boot_c: Path,
            bt_obex_upgrade_c: Path | None = None,
            usb_request_c: Path | None = None,
            upgrade_c: Path | None = None) -> dict:
    b=reconstruct(flash_boot_c)
    sha=hashlib.sha256(b).hexdigest()
    if len(b) != 65536 or sha != REF_SHA:
        raise SystemExit(f'R29 FAIL reference flashboot mismatch len={len(b)} sha={sha}')

    helper=b[HELPER_OFF:HELPER_OFF+HELPER_LEN]
    hsha=hashlib.sha256(helper).hexdigest()
    if len(helper) != HELPER_LEN or hsha != HELPER_SHA:
        raise SystemExit(f'R29 FAIL helper mismatch len={len(helper)} sha={hsha}')

    # Parser dispatch table: IDs 1..5. This is deterministic reference evidence.
    dispatch=[]
    for i in range(5):
        dispatch.append(int.from_bytes(b[PARSER_JT+4*i:PARSER_JT+4*i+4],'little'))
    expected=[0x41BC,0x41FE,0x41D8,0x43B4,0x4440]
    if dispatch != expected:
        raise SystemExit(f'R29 FAIL parser dispatch changed: {dispatch}')

    checks=[
        require_ins(b,0x41DA,'movi','#50380'), # "03PKG offset:%lu"
        require_ins(b,0x41DE,'jal','0xAD70'),
        require_ins(b,0x41EC,'movi','#50400'), # "FlashLen:%lu"
        require_ins(b,0x41F0,'jal','0xAD70'),
        require_ins(b,0x41F4,'add45','r6,r9'),
        require_ins(b,0x41F6,'addi45','r6,#5'),
        require_ins(b,0x41F8,'subi45','r8,#1'),
        require_ins(b,0x41FA,'j','0x44C8'),
    ]

    # String evidence in the embedded flashboot. Absence is supporting, not sole proof.
    strings={
        '03PKG_count': b.count(b'03PKG'),
        '03PKG_end_count': b.count(b'03PKG end'),
        '03_end_count': b.count(b'03 end'),
        '02_end_count': b.count(b'02 end'),
        '04PKG_end_count': b.count(b'04PKG end'),
        '05PKG_end_count': b.count(b'05PKG end'),
    }

    runs=printable_runs(helper,4)
    known_magic=[]
    magics={
        'ELF': b'\x7fELF',
        'PE_MZ': b'MZ',
        'gzip': b'\x1f\x8b',
        'zip': b'PK\x03\x04',
        'xz': b'\xfd7zXZ\x00',
        'bzip2': b'BZh',
    }
    for name,magic in magics.items():
        if helper.startswith(magic): known_magic.append(name)

    read_ev=source_read_evidence(bt_obex_upgrade_c,usb_request_c,upgrade_c)

    result={
        'revision':'R29',
        'mode':'OFFLINE_ONLY',
        'device_io':False,
        'reference_flashboot_size':len(b),
        'reference_flashboot_sha256':sha,
        'package03_helper':{
            'flashboot_offset':'0xCE74',
            'length':HELPER_LEN,
            'sha256':hsha,
            'first_32_bytes_hex':helper[:32].hex(' '),
            'shannon_entropy_bits_per_byte':round(entropy(helper),6),
            'distinct_byte_values':len(set(helper)),
            'zero_byte_count':helper.count(0),
            'ff_byte_count':helper.count(0xff),
            'printable_run_count_min4':len(runs),
            'longest_printable_run':max((len(x) for x in runs), default=0),
            'recognized_file_magic_at_start':known_magic,
            'classification':'opaque/high-entropy helper payload; exact encoding/compression/encryption is not proven',
            'not_proven_as':'direct NDS32 executable image or flash readback helper',
        },
        'mva_parser_dispatch':{
            'table_offset':'0x41A8',
            'id_to_handler':{str(i+1):f'0x{x:04X}' for i,x in enumerate(dispatch)},
            'id3_handler':'0x41D8',
            'id3_behavior':'logs record offset/length, advances parser offset by payload_length + 5, decrements remaining record count, rejoins parser loop',
            'id3_payload_processing_call_proven':False,
            'id3_helper_execution_or_copy_proven':False,
            'id3_direct_crc_validation_proven':False,
            'evidence_checks':checks,
            'supporting_strings':strings,
            'conclusion':'Package 03 is carried by the maker but the inspected on-device MVA parser does not expose it as a readback helper; this path skips past the record after parsing its framing.',
        },
        'internal_flash_read':read_ev,
        'metadata_progress':{
            'proven_from_R28':['code magic @0xC0 = 0xB0BEBDC9','24-bit code length @0xE0..0xE2 + additive check @0xE3','FastCRC included/excluded ranges'],
            'new_exact_field_mapping_in_R29':False,
            'unresolved_ranges':['0xA4..0xA7','0xBC..0xBF','0xCC..0xD3','0xE4..0xEB'],
            'note':'R29 found no additional evidence sufficient to assign exact production semantics to every excluded metadata field.',
        },
        'recovery_assessment':{
            'stock_backup_obtained':False,
            'stock_full_flash_readback_path_proven':False,
            'package03_is_host_readback_helper_proven':False,
            'internal_spi_flash_read_primitive_exists':read_ev['internal_spi_flash_read_exists'],
            'internal_read_is_exposed_to_host':False,
            'production_layout_proven':False,
            'live_flash_action_allowed':False,
        },
        'live_probe_allowed':False,
        'proven_live_identity_or_readback_command':None,
        'blocked_actions':['Feature 0x55/0xAA','USB flashboot commands','OBEX PUT/.mva transfer','GATT OTA writes/subscriptions','erase/program/commit/apply/reset'],
    }
    return result


def main() -> None:
    ap=argparse.ArgumentParser()
    ap.add_argument('flash_boot_c',type=Path)
    ap.add_argument('--bt-obex-upgrade-c',type=Path)
    ap.add_argument('--usb-request-c',type=Path)
    ap.add_argument('--upgrade-c',type=Path)
    ap.add_argument('--json',action='store_true')
    args=ap.parse_args()
    out=analyze(args.flash_boot_c,args.bt_obex_upgrade_c,args.usb_request_c,args.upgrade_c)
    if args.json:
        print(json.dumps(out,indent=2,ensure_ascii=False))
    else:
        h=out['package03_helper']
        p=out['mva_parser_dispatch']
        r=out['internal_flash_read']
        print('R29 offline helper/readback analysis')
        print('helper sha256:',h['sha256'])
        print('helper entropy:',h['shannon_entropy_bits_per_byte'])
        print('ID3 handler:',p['id3_handler'])
        print('ID3 helper processing proven:',p['id3_payload_processing_call_proven'])
        print('internal SpiFlashRead exists:',r['internal_spi_flash_read_exists'])
        print('host arbitrary readback proven:',r['host_exposed_arbitrary_flash_read_proven'])
        print('live probe allowed:',out['live_probe_allowed'])


if __name__=='__main__':
    main()
