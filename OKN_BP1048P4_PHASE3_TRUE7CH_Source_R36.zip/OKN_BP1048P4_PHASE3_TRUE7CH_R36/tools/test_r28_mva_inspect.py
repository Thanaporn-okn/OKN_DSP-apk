#!/usr/bin/env python3
from pathlib import Path
import importlib.util, tempfile
p=Path(__file__).with_name('r28_mva_recovery_offline.py')
spec=importlib.util.spec_from_file_location('r28',p)
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
# Synthetic bytes exist only in memory/temp for parser testing; this is NOT a production package generator.
body=(b'MV\xB1X'+bytes([2])+
      bytes([1])+(3).to_bytes(4,'little')+bytes.fromhex('35 ba 69')+
      bytes([4])+(8).to_bytes(4,'little')+(0x198000).to_bytes(4,'little')+b'abcd')
crc=m.crc16_xmodem(body)
data=body+crc.to_bytes(4,'little')
r=m.parse_mva_bytes(data)
assert r['signature_ok'] is True and r['record_count']==2 and r['parse_complete'] is True
assert r['records'][0]['id']==1 and r['records'][1]['id']==4
assert r['records'][1]['target_offset_le32']==0x198000
assert r['trailer']['low16_matches'] is True
assert m.crc16_xmodem(b'123456789')==0x31C3
bad=m.parse_mva_bytes(b'NOPE'+bytes([0]))
assert bad['signature_ok'] is False
with tempfile.TemporaryDirectory() as td:
    f=Path(td)/'sample_container.bin'; f.write_bytes(data); before=f.read_bytes(); rr=m.parse_mva_file(f)
    assert rr['input_unchanged'] is True and f.read_bytes()==before
print('R28 offline MVA framing/CRC inspector tests: PASS')
