#!/usr/bin/env python3
import ast,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=json.loads((ROOT/'config/R34_VENDOR_WINDOWS_2025_STATE.json').read_text())
r=json.loads((ROOT/'config/R34_VENDOR_WINDOWS_2025_RISK.json').read_text())
assert s['revision']=='R34' and s['mode']=='OFFLINE_ONLY' and s['device_io'] is False
assert s['windows_2025_size']==3300864
assert s['windows_2025_sha256']=='fde7b0f61ec62ffb6bcda5a921128f531bca84939b6f1f95c8ab2f14c453d1f9'
assert s['windows_2025_protected_resource_size']==605569
assert s['windows_2025_protected_resource_sha256']=='71667130e0f1dbafbe9087428b061862bf9895e173859bdb6984fb7b05ca0e43'
assert s['native_import_sets_identical'] is True
assert s['ufe_command_sets_identical'] is True
assert s['hidden_backup_keyword_candidate_found'] is False
assert s['vendor_dataset_entry_count']==54 and s['vendor_dataset_firmware_image_candidate_count']==0
assert s['additional_safe_stock_backup_command_proven'] is False
assert s['additional_arbitrary_flash_readback_proven'] is False
assert s['production_flash_layout_proven'] is False
assert s['flash_gate']=='CLOSED' and s['hardware_action_authorized'] is False
blocked=' '.join(r['blocked_actions']).lower()
for term in ['hardware probe','0x55/0xaa','0x00/0x11','.mva','obex put','erase','program','commit','apply','reset']:
    assert term in blocked, term
# Analyzer must be file-only; no live IO/process execution libraries.
tool=ROOT/'tools/r34_vendor_windows_2025_compare.py'
tree=ast.parse(tool.read_text())
imports=set()
for n in ast.walk(tree):
    if isinstance(n,ast.Import): imports.update(a.name.split('.')[0] for a in n.names)
    elif isinstance(n,ast.ImportFrom) and n.module: imports.add(n.module.split('.')[0])
for banned in {'ctypes','usb','serial','hid','hidapi','socket','requests','urllib','http','bluetooth','bleak','subprocess'}:
    assert banned not in imports,(banned,imports)
# Source checkpoint must not redistribute vendor executable/resource or private keys.
for p in ROOT.rglob('*'):
    if not p.is_file(): continue
    low=p.name.lower()
    assert not low.endswith('.exe'), p
    assert 'windows2025_protected_resource' not in low, p
    assert 'private_okn_android_stable_debug_key' not in low, p
report=(ROOT/'docs/R34_VENDOR_WINDOWS_2025_OFFLINE_REVERSE_TH.md').read_text()
for marker in ['605,569','UFE command set','54','FLASH_GATE=CLOSED','ไม่พิสูจน์']:
    assert marker in report, marker
print('R34 vendor Windows 2025 offline guard: PASS')
