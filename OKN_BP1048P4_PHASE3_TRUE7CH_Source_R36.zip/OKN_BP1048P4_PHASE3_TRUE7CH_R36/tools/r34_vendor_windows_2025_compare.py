#!/usr/bin/env python3
"""Offline-only comparison of verified vendor Windows 2025 and 2026 tuning clients.

Reads local EXE/ZIP files only. It never opens HID/USB/BLE/serial/socket transports,
never runs either EXE, and never emits device packets.
"""
from __future__ import annotations
import argparse, hashlib, json, re, struct, zipfile
from pathlib import Path
from dotnet_meta import DotNet

EXPECTED = {
    "2025": (3300864, "fde7b0f61ec62ffb6bcda5a921128f531bca84939b6f1f95c8ab2f14c453d1f9"),
    "2026": (3307008, "3ca54171c53f7badd963ffe6851b8b3e2faf8aee8ba2afcb7040990e22ae09b2"),
}
BACKUP_TERMS = ("backup","dump","upload","export","readflash","flashread","read flash","firmware dump","stock backup")
FLASH_TERMS = ("firmware","upgrade","bootloader","erase","program","commit","recovery")
FIRMWARE_EXT = re.compile(r"\.(?:bin|img|hex|mva|fw|rom|ota|dfu)$", re.I)


def sha256(p: Path) -> str:
    h=hashlib.sha256()
    with p.open("rb") as f:
        for c in iter(lambda:f.read(1<<20), b""):
            h.update(c)
    return h.hexdigest()


def verify(label: str, p: Path):
    size=p.stat().st_size; digest=sha256(p)
    if (size,digest) != EXPECTED[label]:
        raise SystemExit(f"{label} identity mismatch: size={size} sha256={digest}")
    return {"size":size,"sha256":digest}


def implmap(d: DotNet):
    mods=d.tables.get(26,[]); out=[]
    for r in d.tables.get(28,[]):
        tid,rid=d.coded_decode("MemberForwarded",r["MemberForwarded"])
        if tid != 6: continue
        dll=d.s(mods[r["ImportScope"]-1]["Name"]) if r["ImportScope"] else ""
        out.append((dll,d.s(r["ImportName"])))
    return sorted(out)


def ufe_constants(d: DotNet):
    out={}
    for c in d.tables.get(11,[]):
        tid,rid=d.coded_decode("HasConstant",c["Parent"])
        if tid != 4: continue
        name=d.field_name(rid)
        if "UFEHeader::" not in name: continue
        b=d.blob(c["Value"]); val=int.from_bytes(b,"little") if b else None
        out[name.split("::")[-1]]=val
    return out


def resources(d: DotNet):
    base=d.rva2off(d.res_rva); out=[]
    for r in d.tables.get(40,[]):
        o=base+r["Offset"]; n=struct.unpack_from("<I",d.b,o)[0]; blob=d.b[o+4:o+4+n]
        out.append({"name":d.s(r["Name"]),"offset":r["Offset"],"length":n,"sha256":hashlib.sha256(blob).hexdigest()})
    return out


def printable_hits(data: bytes, terms):
    hits=[]
    pats=[(t,t.encode("ascii")) for t in terms]
    low=data.lower()
    for term,pat in pats:
        pos=0
        while True:
            i=low.find(pat.lower(),pos)
            if i<0: break
            hits.append({"term":term,"offset":i})
            pos=i+1
    return hits


def method_names(d: DotNet):
    return [d.method_name(i) for i in range(1,len(d.tables.get(6,[]))+1)]


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--exe2025",required=True,type=Path)
    ap.add_argument("--exe2026",required=True,type=Path)
    ap.add_argument("--dataset-zip",type=Path)
    ap.add_argument("--out",required=True,type=Path)
    ns=ap.parse_args(); ns.out.parent.mkdir(parents=True,exist_ok=True)
    ids={"2025":verify("2025",ns.exe2025),"2026":verify("2026",ns.exe2026)}
    d25,d26=DotNet(str(ns.exe2025)),DotNet(str(ns.exe2026))
    m25,m26=method_names(d25),method_names(d26)
    names25="\n".join(m25).lower()
    strings25=ns.exe2025.read_bytes()
    backup_hits=printable_hits(strings25,BACKUP_TERMS)
    flash_hits=printable_hits(strings25,FLASH_TERMS)
    dataset=None
    if ns.dataset_zip:
        with zipfile.ZipFile(ns.dataset_zip) as z:
            names=z.namelist()
            suspicious=[n for n in names if FIRMWARE_EXT.search(n) or re.search(r"firmware|factory|recovery|bootloader",n,re.I)]
        dataset={"entries":len(names),"firmware_or_recovery_candidates":suspicious}
    result={
      "mode":"OFFLINE_ONLY","device_io":False,"vendor_executed":False,
      "identity":ids,
      "metadata":{
        "2025":{"methods":len(d25.tables.get(6,[])),"types":len(d25.tables.get(2,[])),"fields":len(d25.tables.get(4,[])),"resources":resources(d25)},
        "2026":{"methods":len(d26.tables.get(6,[])),"types":len(d26.tables.get(2,[])),"fields":len(d26.tables.get(4,[])),"resources":resources(d26)},
      },
      "native_imports_identical": implmap(d25)==implmap(d26),
      "native_imports_2025": implmap(d25),
      "ufe_constants_identical": ufe_constants(d25)==ufe_constants(d26),
      "ufe_constants": ufe_constants(d25),
      "named_backup_readback_method_hits_2025":[t for t in BACKUP_TERMS if t in names25],
      "raw_backup_readback_string_hits_2025":backup_hits,
      "raw_flash_related_string_hits_2025":flash_hits,
      "dataset":dataset,
      "conclusion":{
        "distinct_2025_protected_resource":True,
        "additional_safe_stock_backup_command_proven":False,
        "additional_arbitrary_flash_readback_proven":False,
        "production_firmware_image_found_in_dataset": bool(dataset and dataset["firmware_or_recovery_candidates"]),
        "production_flash_layout_proven":False,
        "flash_gate":"CLOSED"
      }
    }
    ns.out.write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding="utf-8")
    print(json.dumps(result["conclusion"],ensure_ascii=False))

if __name__=="__main__": main()
