#!/usr/bin/env python3
"""R32 offline-only protected-runtime recovery for the verified Windows 2026 build.

Reads a local copy of the 607,967-byte protected resource and Windows EXE.
Never opens a device, USB/HID/BLE/serial/socket interface, and never emits device packets.
"""
from __future__ import annotations
import argparse, hashlib, json, struct
from pathlib import Path
from dotnet_meta import DotNet
from il_disasm import disasm

RESOURCE_SIZE = 607_967
RESOURCE_SHA256 = "a46885bb2f09a600f6f16e6206f49d304ca829d441c5077b360b25ac8e6a33aa"
EXE_SIZE = 3_307_008
EXE_SHA256 = "3ca54171c53f7badd963ffe6851b8b3e2faf8aee8ba2afcb7040990e22ae09b2"
KEY = bytes.fromhex("e2fd910c997ebec231334c9e084780418a42a068d0554a0ee526b8f7d6c844b3")
XOR64 = 0x000000003800CD0D
PATCH_PAIRS = 1208
EXPECTED_RECORDS = 1823
MASK = 0xFFFFFFFF
TARGETS = [0x06000460,0x06000461,0x0600048C,0x06000496,0x0600049A,0x06000795,0x060007E0]

def u(x:int)->int: return x & MASK

def next_state(s:int)->int:
    l64=330109516; l11=725701736; l74=7651480; l75=1474240118; l89=s
    l75=u(l75-l11)
    l64=u(658242601 ^ 1092075823 ^ 1441417454)
    l11=u(l11-l75)
    l30=l74 & 0x55555555; l86=l74 & 0xAAAAAAAA
    l30=u((l30>>1)|((l86<<1)&MASK)); l30=u(l30^l75)
    l74=u((l74<<11)|(l74>>21))
    l89=u(l89+l75); l89=u(l89 ^ ((l89<<6)&MASK)); l89=u(l89+l11)
    l89=u(l89^(l89>>11)); l89=u(l89+l74); l89=u(l89 ^ ((l89<<1)&MASK)); l89=u(l89+l89)
    tmp=u((u(l64<<16)+l11)^l11)
    l89=u(tmp-l89)
    return u(s+l89)

def sha256_bytes(b:bytes)->str: return hashlib.sha256(b).hexdigest()

def recover(src:bytes)->bytes:
    if len(src) != RESOURCE_SIZE or sha256_bytes(src) != RESOURCE_SHA256:
        raise SystemExit("resource identity mismatch")
    full, rem = divmod(len(src),4)
    out=bytearray(len(src)); state=0; nkw=len(KEY)//4
    for i in range(full):
        kw=struct.unpack_from('<I',KEY,(i%nkw)*4)[0]
        state=u(state+kw)
        if i==full-1 and rem: break
        data=struct.unpack_from('<I',src,i*4)[0]
        state=next_state(state)
        out[i*4:i*4+4]=u(state^data).to_bytes(4,'little')
    if rem:
        i=full-1; kw=struct.unpack_from('<I',KEY,(i%nkw)*4)[0]
        state=u(state+kw); partial=int.from_bytes(src[-rem:],'little'); state=next_state(state)
        out[i*4:i*4+rem]=u(state^partial).to_bytes(4,'little')[:rem]
    stage2=bytearray(out)
    for j in range(len(stage2)//8):
        struct.pack_into('<Q',stage2,j*8,struct.unpack_from('<Q',stage2,j*8)[0]^XOR64)
    return bytes(stage2)

def parse_records(b:bytes):
    header=struct.unpack_from('<6I',b,0)
    if header != (0x0600091C,0x00017725,0x000006DB,0x0005F0C1,0x000004B8,0):
        raise SystemExit(f"decoded header mismatch: {[hex(x) for x in header]}")
    pos=24+PATCH_PAIRS*8
    cap=struct.unpack_from('<I',b,pos)[0]; pos+=4
    if cap != 0x71F: raise SystemExit(f"capacity mismatch: 0x{cap:X}")
    recs={}; rows=[]
    idx=0
    while pos < len(b)-1:
        start=pos
        if pos+12>len(b): raise SystemExit("truncated record header")
        key,marker,n=struct.unpack_from('<III',b,pos); pos+=12
        if n>len(b)-pos: raise SystemExit(f"record {idx} overruns stream")
        blob=b[pos:pos+n]; pos+=n
        recs[key]=(idx,marker,blob,start); rows.append((idx,key,marker,n,start)); idx+=1
    if idx != EXPECTED_RECORDS or pos != len(b):
        raise SystemExit(f"parser mismatch records={idx} end={pos} len={len(b)}")
    return cap,recs,rows

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--resource',required=True,type=Path)
    ap.add_argument('--exe',required=True,type=Path)
    ap.add_argument('--outdir',required=True,type=Path)
    ns=ap.parse_args(); ns.outdir.mkdir(parents=True,exist_ok=True)
    exe=ns.exe.read_bytes()
    if len(exe)!=EXE_SIZE or sha256_bytes(exe)!=EXE_SHA256: raise SystemExit('EXE identity mismatch')
    stage2=recover(ns.resource.read_bytes()); cap,recs,rows=parse_records(stage2)
    d=DotNet(str(ns.exe)); dumpdir=ns.outdir/'protected_il'; dumpdir.mkdir(exist_ok=True)
    target_info=[]
    for tok in TARGETS:
        rid=tok&0xffffff; row=d.tables[6][rid-1]; mb=d.method_body(rid); key=row['RVA']+mb['header']; name=d.method_name(rid)
        idx,marker,blob,start=recs[key]
        lines=[f'; {tok:08X} {name} key=0x{key:X} record={idx} marker=0x{marker:X} len={len(blob)}']
        for off,n,v in disasm(blob,d): lines.append(f'IL_{off:04X}: {n:18} {v}')
        fn=f'{tok:08X}_{name.split("::")[-1].replace(".","_")}.il.txt'; (dumpdir/fn).write_text('\n'.join(lines),encoding='utf-8')
        target_info.append({'token':f'0x{tok:08X}','name':name,'key':f'0x{key:X}','record':idx,'length':len(blob)})
    (ns.outdir/'records.tsv').write_text('\n'.join(f'{i}\t0x{k:08X}\t0x{m:08X}\t{n}\t0x{s:X}' for i,k,m,n,s in rows)+'\n',encoding='utf-8')
    result={'resource_sha256':RESOURCE_SHA256,'exe_sha256':EXE_SHA256,'header':[f'0x{x:08X}' for x in struct.unpack_from('<6I',stage2,0)],'raw_capacity':cap,'hashtable_capacity':cap+1,'records':len(rows),'parser_end':len(stage2),'targets':target_info,'device_io':False}
    (ns.outdir/'r32_recovery.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2))
if __name__=='__main__': main()
