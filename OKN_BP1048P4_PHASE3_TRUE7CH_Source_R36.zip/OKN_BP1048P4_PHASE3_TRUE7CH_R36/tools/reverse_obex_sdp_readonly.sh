#!/usr/bin/env bash
set -euo pipefail

# Offline-only helper. Usage:
#   tools/reverse_obex_sdp_readonly.sh /path/to/libBtStack.a
LIB="${1:-}"
if [[ -z "$LIB" || ! -f "$LIB" ]]; then
  echo "usage: $0 /path/to/libBtStack.a" >&2
  exit 2
fi

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
cd "$TMP"
ar x "$LIB" obex_sdp.o

echo "lib SHA256: $(sha256sum "$LIB" | awk '{print $1}')"
echo "obex_sdp.o SHA256: $(sha256sum obex_sdp.o | awk '{print $1}')"
echo
strings -a obex_sdp.o | grep -E -i 'Object Push|obex|sdp' || true
echo
readelf -s obex_sdp.o | grep -E 'Obex(ClassId|ServiceName|ProtoDescList|ProfileDescList|SupportedFormats|SdpAttributes|BrowseGroup)|ObexRegister' || true
echo
objdump -s obex_sdp.o | sed -n '/Contents of section .rodata.ObexServiceName:/,/Contents of section .comment:/p'
