#!/usr/bin/env python3
from pathlib import Path
import ast, json
root=Path(__file__).resolve().parents[1]
state=json.loads((root/'config/R31_WINDOWS_RUNTIME_READBACK_STATE.json').read_text())
risk=json.loads((root/'config/R31_WINDOWS_RUNTIME_READBACK_RISK.json').read_text())
inv=json.loads((root/'windows/r31/r31_inventory.json').read_text())

if state.get('revision')!='R31' or state.get('mode')!='OFFLINE_ONLY' or state.get('device_io') is not False:
    raise SystemExit('R31 FAIL state/offline gate')
if risk.get('hardware_action_allowed') is not False:
    raise SystemExit('R31 FAIL hardware gate')
if state['readback_assessment']['flash_gate']!='CLOSED':
    raise SystemExit('R31 FAIL flash gate')
for k in ('safe_stock_backup_path_found','host_facing_arbitrary_flash_read_command_found','production_flash_layout_proven','read_only_hardware_probe_authorized'):
    if state['readback_assessment'][k] is not False:
        raise SystemExit('R31 FAIL readback gate '+k)
if inv['target']['sha256'] != '3ca54171c53f7badd963ffe6851b8b3e2faf8aee8ba2afcb7040990e22ae09b2':
    raise SystemExit('R31 FAIL target hash evidence')
imports={(x['dll'].lower(),x['native']) for x in inv['pinvoke_imports']}
for required in [('hid.dll','HidD_GetInputReport'),('hid.dll','HidD_SetOutputReport'),('hid.dll','HidD_SetFeature'),('kernel32.dll','ReadFile'),('kernel32.dll','WriteFile')]:
    if required not in imports:
        raise SystemExit('R31 FAIL missing import '+repr(required))
constants={x['hex']:x['field'].split('::')[-1] for x in inv['ufe_header_constants']}
expected={
 '0x57':'UFE_WRITE_ACTUATOR_COMMAND','0x58':'UFE_READ_SENSOR_ACTUATOR_COMMAND',
 '0x59':'UFE_READ_SENSOR_ACTUATOR_JSON_COMMAND','0x60':'UFE_RESPONSE_READ_SENSOR_ACTUATOR_COMMAND',
 '0x61':'UFE_READ_SENSOR_FIFO_COMMAND','0x62':'UFE_RESPONSE_FIFO_SENSOR',
 '0x63':'UFE_READ_SENSOR_ACTUATOR_BULK_COMMAND','0x64':'UFE_RESPONSE_READ_SENSOR_ACTUATOR_BULK_COMMAND',
 '0x82':'UFE_CONTINUE_BULK_SEND'}
if constants != expected:
    raise SystemExit('R31 FAIL UFE constants')

# New R31 executable tooling must remain file-only/offline. Evidence text may name device APIs,
# but scripts may not import libraries that can access hardware or network.
for rel in ['tools/dotnet_meta.py','tools/il_disasm.py','tools/r31_windows_runtime_offline.py']:
    p=root/rel
    tree=ast.parse(p.read_text(),filename=str(p))
    imported=[]
    for n in ast.walk(tree):
        if isinstance(n,ast.Import): imported += [a.name.split('.')[0] for a in n.names]
        elif isinstance(n,ast.ImportFrom) and n.module: imported.append(n.module.split('.')[0])
    banned={'ctypes','usb','serial','hid','hidapi','socket','requests','urllib','http','bluetooth','bleak'}
    bad=sorted(set(imported)&banned)
    if bad: raise SystemExit(f'R31 FAIL live-I/O import in {rel}: {bad}')

# Checkpoint source must not contain the proprietary EXE or private signing key backup.
for p in root.rglob('*'):
    if not p.is_file(): continue
    low=p.name.lower()
    if low.endswith('.exe'):
        raise SystemExit('R31 FAIL EXE redistributed: '+str(p))
    if 'private_okn_android_stable_debug_key' in low:
        raise SystemExit('R31 FAIL private key redistributed: '+str(p))

report=(root/'docs/R31_WINDOWS_RUNTIME_READBACK_OFFLINE_REVERSE_TH.md').read_text()
for token in ['arbitrary flash readback command','flash gate: **CLOSED**','ไม่มี packet destructive แบบ runnable']:
    if token not in report:
        raise SystemExit('R31 FAIL report marker '+token)
print('R31 offline Windows-runtime/readback guard: PASS')
print('- exact 2026 EXE hash-derived evidence is pinned')
print('- native HID receive/send surfaces classified without device I/O')
print('- UFE 0x57/58/59/60/61/62/63/64/82 constants validated')
print('- no safe stock backup/arbitrary flash readback is claimed')
print('- source contains no EXE/private signing key and no live-I/O imports')
print('- flash gate remains CLOSED')
