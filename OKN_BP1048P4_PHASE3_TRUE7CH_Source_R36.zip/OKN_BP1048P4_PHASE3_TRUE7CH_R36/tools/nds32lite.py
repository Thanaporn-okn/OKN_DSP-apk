from dataclasses import dataclass
from pathlib import Path

REG=[f'r{i}' for i in range(32)]
REG[26]='p0';REG[27]='p1';REG[28]='fp';REG[29]='gp';REG[30]='lp';REG[31]='sp'
R45=[0,1,2,3,4,5,6,7,8,9,10,11,16,17,18,19]
def sext(v,b):
    s=1<<(b-1); return (v^s)-s
@dataclass
class Ins:
    pc:int; size:int; raw:bytes; mnem:str; ops:str=''; target:int|None=None
    def __str__(self):
        hx=self.raw.hex().upper().ljust(8)
        tar=f' -> 0x{self.target:04X}' if self.target is not None else ''
        return f'{self.pc:04X}: {hx} {self.mnem:10} {self.ops}{tar}'

def dec16(h,pc):
    rt5=(h>>5)&31; ra5=h&31; rt4=R45[(h>>5)&15]; rt3=(h>>6)&7; ra3=(h>>3)&7; rb3=h&7; rt38=(h>>8)&7
    # exact/specific before broad patterns
    if h==0x83ff: return 'ifret16','',None
    if (h&0xffe0)==0xdd80:
        return 'ret5', '' if ra5==30 else REG[ra5], None
    if (h&0xffe0)==0xdd00: return 'jr5',REG[ra5],None
    if (h&0xffe0)==0xdd20: return 'jral5',REG[ra5],None
    if (h&0xffe0)==0xdda0: return 'add5.pc',REG[ra5],None
    if (h&0xff80)==0xfc00:
        re=(h>>5)&3; imm=(h&31)<<3; return 'push25',f're={re},#{imm}',None
    if (h&0xff80)==0xfc80:
        re=(h>>5)&3; imm=(h&31)<<3; return 'pop25',f're={re},#{imm}',None
    # special short jump (SEG10_1) before broad Dxxx branch patterns
    if (h&0xff00)==0xd500:
        imm=sext(h&0xff,8)<<1; return 'j8',f'0x{pc+imm:04X}',pc+imm
    # branches high nibble
    top=h&0xf800
    if top in (0xc000,0xc800,0xd000,0xd800):
        m={0xc000:'beqz38',0xc800:'bnez38',0xd000:'beqs38',0xd800:'bnes38'}[top]
        imm=sext(h&0xff,8)<<1; return m,f'{REG[rt38]},0x{pc+imm:04X}',pc+imm
    if (h&0xff00)==0xe800:
        imm=sext(h&0xff,8)<<1; return 'beqzs8',f'0x{pc+imm:04X}',pc+imm
    if (h&0xff00)==0xe900:
        imm=sext(h&0xff,8)<<1; return 'bnezs8',f'0x{pc+imm:04X}',pc+imm
    if (h&0xfe00)==0xec00:
        imm=sext(h&0x3ff,10); return 'addi10.sp',f'#{imm}',None
    if (h&0xff00)==0xf000:
        imm=(h&0x7f)<<2; return 'lwi37.sp',f'{REG[rt38]},[sp+{imm}]',None
    if (h&0xff00)==0xf080:
        imm=(h&0x7f)<<2; return 'swi37.sp',f'{REG[rt38]},[sp+{imm}]',None
    if (h&0xff00)==0xf800:
        imm=(h&0x1ff)<<1; return 'ifcall9',f'#{imm}',None
    if (h&0xfe00)==0xfa00:
        pi=(h&31)+16; return 'movpi45',f'{REG[rt4]},#{pi}',None
    if (h&0xff00)==0xfd00:
        # approximate extended regs
        return 'movd44',f'0x{h:04x}',None
    # BFMI333 exact lower bits
    if (h&0xfe00)==0x9600:
        sub=h&7; names=['zeb33','zeh33','seb33','seh33','xlsb33','x11b33','bmski33','fexti33']
        return names[sub],f'{REG[rt3]},{REG[ra3] if sub<6 else (h>>3)&7}',None
    if (h&0xfe00)==0xfe00 and (h&7)>=2:
        names={2:'neg33',3:'not33',4:'mul33',5:'xor33',6:'and33',7:'or33'}
        return names.get(h&7,'misc33'),f'{REG[rt3]},{REG[ra3]}',None
    # 0x8000-0xb7ff by base bits
    base=h&0xfe00
    if base==0x8000: return 'mov55',f'{REG[rt5]},{REG[ra5]}',None
    if base==0x8400: return 'movi55',f'{REG[rt5]},#{sext(h&31,5)}',None
    if base==0x8800: return 'add45',f'{REG[rt4]},{REG[ra5]}',None
    if base==0x8a00: return 'sub45',f'{REG[rt4]},{REG[ra5]}',None
    if base==0x8c00: return 'addi45',f'{REG[rt4]},#{h&31}',None
    if base==0x8e00: return 'subi45',f'{REG[rt4]},#{h&31}',None
    if base==0x9000: return 'srai45',f'{REG[rt4]},#{h&31}',None
    if base==0x9200: return ('nop16','',None) if (h&0x1ff)==0 else ('srli45',f'{REG[rt4]},#{h&31}',None)
    if base==0x9400: return 'slli333',f'{REG[rt3]},{REG[ra3]},#{h&7}',None
    if base==0x9800: return 'add333',f'{REG[rt3]},{REG[ra3]},{REG[rb3]}',None
    if base==0x9a00: return 'sub333',f'{REG[rt3]},{REG[ra3]},{REG[rb3]}',None
    if base==0x9c00: return 'addi333',f'{REG[rt3]},{REG[ra3]},#{h&7}',None
    if base==0x9e00: return 'subi333',f'{REG[rt3]},{REG[ra3]},#{h&7}',None
    if base==0xa000: return 'lwi333',f'{REG[rt3]},[{REG[ra3]}+{(h&7)<<2}]',None
    if base==0xa200: return 'lwi333.bi',f'{REG[rt3]},[{REG[ra3]}],{(h&7)<<2}',None
    if base==0xa400: return 'lhi333',f'{REG[rt3]},[{REG[ra3]}+{(h&7)<<1}]',None
    if base==0xa600: return 'lbi333',f'{REG[rt3]},[{REG[ra3]}+{h&7}]',None
    if base==0xa800: return 'swi333',f'{REG[rt3]},[{REG[ra3]}+{(h&7)<<2}]',None
    if base==0xaa00: return 'swi333.bi',f'{REG[rt3]},[{REG[ra3]}],{(h&7)<<2}',None
    if base==0xac00: return 'shi333',f'{REG[rt3]},[{REG[ra3]}+{(h&7)<<1}]',None
    if base==0xae00: return 'sbi333',f'{REG[rt3]},[{REG[ra3]}+{h&7}]',None
    if (h&0xfe00)==0xb000: return 'addri36.sp',f'{REG[rt3]},#{(h&0x3f)<<2}',None
    if (h&0xfe00)==0xb400: return 'lwi450',f'{REG[rt4]},[{REG[ra5]}]',None
    if (h&0xfe00)==0xb600: return 'swi450',f'{REG[rt4]},[{REG[ra5]}]',None
    if (h&0xff80)==0xb800: return 'lwi37',f'{REG[rt38]},[fp+{(h&0x7f)<<2}]',None
    if (h&0xff80)==0xb880: return 'swi37',f'{REG[rt38]},[fp+{(h&0x7f)<<2}]',None
    if (h&0xfe00)==0xe000: return 'slts45',f'{REG[rt4]},{REG[ra5]}',None
    if (h&0xfe00)==0xe200: return 'slt45',f'{REG[rt4]},{REG[ra5]}',None
    if (h&0xfe00)==0xe400: return 'sltsi45',f'{REG[rt4]},#{h&31}',None
    if (h&0xfe00)==0xe600: return 'slti45',f'{REG[rt4]},#{h&31}',None
    return '.hword',f'0x{h:04X}',None

def dec32(w,pc):
    op=(w>>25)&0x3f; rt=(w>>20)&31; ra=(w>>15)&31; rb=(w>>10)&31; rd=(w>>5)&31
    i15=w&0x7fff
    load_names={0:'lbi',1:'lhi',2:'lwi',3:'ldi',4:'lbi.bi',5:'lhi.bi',6:'lwi.bi',7:'ldi.bi',8:'sbi',9:'shi',10:'swi',11:'sdi',12:'sbi.bi',13:'shi.bi',14:'swi.bi',15:'sdi.bi',16:'lbsi',17:'lhsi',18:'lwsi',20:'lbsi.bi',21:'lhsi.bi',22:'lwsi.bi'}
    if op in load_names:
        name=load_names[op]; shift=0
        if 'hi' in name: shift=1
        elif 'wi' in name or 'si' in name and name.startswith('lw'): shift=2
        imm=sext(i15,15)<<shift
        if '.bi' in name: return name,f'{REG[rt]},[{REG[ra]}],{imm}',None
        return name,f'{REG[rt]},[{REG[ra]}{imm:+d}]',None
    if op==0x1c:
        sub=w&0x3f; names={0:'lb',1:'lh',2:'lw',3:'ld',4:'lb.bi',5:'lh.bi',6:'lw.bi',7:'ld.bi',8:'sb',9:'sh',10:'sw',11:'sd',12:'sb.bi',13:'sh.bi',14:'sw.bi',15:'sd.bi',16:'lbs',17:'lhs',24:'llw',25:'scw',0x20:'lbup',0x22:'lwup',0x28:'sbup',0x2a:'swup'}
        name=names.get(sub,f'mem.{sub:x}'); sv=(w>>8)&3
        return name,f'{REG[rt]},[{REG[ra]}+{REG[rb]}<<{sv}]',None
    if op==0x20:
        sub=w&31; names={0:'add',1:'sub',2:'and',3:'xor',4:'or',5:'nor',6:'slt',7:'slts',8:'slli',9:'srli',10:'srai',11:'rotri',12:'sll',13:'srl',14:'sra',15:'rotr',16:'seb',17:'seh',18:'bitc',19:'zeh',20:'wsbh',24:'sva',25:'svs',26:'cmovz',27:'cmovn'}
        name=names.get(sub,f'alu1.{sub:x}')
        if sub in (8,9,10,11): return name,f'{REG[rt]},{REG[ra]},#{rb}',None
        return name,f'{REG[rt]},{REG[ra]},{REG[rb]}',None
    if op==0x21:
        sub=w&0x3f; names={0:'max',1:'min',2:'ave',3:'abs',4:'clips',5:'clip',6:'clo',7:'clz',8:'bset',9:'bclr',10:'btgl',11:'btst',12:'bse',13:'bsp',14:'ffb',15:'ffmism',0x10:'add.sc',0x11:'sub.sc',0x12:'add.wc',0x13:'sub.wc',0x18:'kadd',0x19:'ksub',0x1a:'kslra',0x20:'mfusr',0x21:'mtusr',0x24:'mul',0x28:'mults64',0x29:'mult64',0x2a:'madds64',0x2b:'madd64',0x2c:'msubs64',0x2d:'msub64',0x2e:'divs',0x2f:'div'}
        return names.get(sub,f'alu2.{sub:x}'),f'{REG[rt]},{REG[ra]},{REG[rb]}',None
    if op==0x22: return 'movi',f'{REG[rt]},#{sext(w&0xfffff,20)}',None
    if op==0x23: return 'sethi',f'{REG[rt]},#0x{w&0xfffff:X}',None
    if op==0x24:
        imm=sext(w&0xffffff,24)<<1; target=pc+imm; return ('jal' if (w>>24)&1 else 'j'),f'0x{target:04X}',target
    if op==0x25:
        sub=w&31; names={0:'jr',1:'jral',2:'jrnez',3:'jralnez'}; name=names.get(sub,f'jreg.{sub}')
        return name,f'{REG[rt]},{REG[rb]}' if sub in (1,3) else REG[rb],None
    if op==0x26:
        imm=sext(w&0x3fff,14)<<1; target=pc+imm; name='bne' if (w>>14)&1 else 'beq'; return name,f'{REG[rt]},{REG[ra]},0x{target:04X}',target
    if op==0x27:
        sub=(w>>16)&0xf; names={0:'ifcall',2:'beqz',3:'bnez',4:'bgez',5:'bltz',6:'bgtz',7:'blez',12:'bgezal',13:'bltzal'}; name=names.get(sub,f'br2.{sub:x}'); imm=sext(w&0xffff,16)<<1; target=pc+imm; return name,f'{REG[rt]},0x{target:04X}',target
    if op in (0x28,0x29,0x2a,0x2b,0x2c,0x2e,0x2f,0x33):
        names={0x28:'addi',0x29:'subri',0x2a:'andi',0x2b:'xori',0x2c:'ori',0x2e:'slti',0x2f:'sltsi',0x33:'bitci'}; name=names[op]
        imm=(w&0x7fff) if op in (0x2a,0x2b,0x2c,0x33) else sext(w&0x7fff,15)
        return name,f'{REG[rt]},{REG[ra]},#{imm}',None
    if op==0x2d:
        # BR3: compare register against signed 11-bit immediate, PC-relative disp8*2
        # Encoding verified from flashboot setup checks (0x21/0x09/0x02) and update status (0x6F/0x6B).
        sub=(w>>19)&1; name='bnec' if sub else 'beqc'; cmpimm=sext((w>>8)&0x7ff,11); imm8=sext(w&0xff,8)<<1; target=pc+imm8
        return name,f'{REG[rt]},#{cmpimm},0x{target:04X}',target
    if op==0x32:
        sub=w&31; names={0:'standby',1:'cctl',2:'mfsr',3:'mtsr',4:'iret',5:'trap',6:'teqz',7:'tnez',8:'dsb',9:'isb',10:'break',11:'syscall',12:'msync',13:'isync',14:'tlbop'}
        return names.get(sub,f'misc.{sub:x}'),f'0x{w:08X}',None
    # gp relatives
    if op==0x17:
        # LBGP variants; imm signed 19 possibly
        return 'lbgp',f'{REG[rt]},gp-rel',None
    if op==0x1e:
        return 'hwgp',f'{REG[rt]},gp-rel',None
    if op==0x1f:
        return 'sbgp/addi.gp',f'{REG[rt]},gp-rel',None
    return f'op{op:02x}',f'0x{w:08X}',None

def decode_one(b,pc):
    if pc+2>len(b): return None
    h=int.from_bytes(b[pc:pc+2],'big')
    if h&0x8000:
        m,o,t=dec16(h,pc); return Ins(pc,2,b[pc:pc+2],m,o,t)
    if pc+4>len(b): return Ins(pc,2,b[pc:pc+2],'.trunc','')
    w=int.from_bytes(b[pc:pc+4],'big'); m,o,t=dec32(w,pc); return Ins(pc,4,b[pc:pc+4],m,o,t)

def disasm(b,start,end=None,maxn=None):
    if end is None:end=len(b)
    pc=start;n=0
    while pc<end and (maxn is None or n<maxn):
        ins=decode_one(b,pc)
        if not ins:break
        yield ins;pc+=ins.size;n+=1

if __name__=='__main__':
 import argparse
 ap=argparse.ArgumentParser();ap.add_argument('bin');ap.add_argument('--start',type=lambda s:int(s,0),default=0);ap.add_argument('--end',type=lambda s:int(s,0));ap.add_argument('--count',type=int)
 a=ap.parse_args();b=Path(a.bin).read_bytes()
 for x in disasm(b,a.start,a.end,a.count):print(x)
