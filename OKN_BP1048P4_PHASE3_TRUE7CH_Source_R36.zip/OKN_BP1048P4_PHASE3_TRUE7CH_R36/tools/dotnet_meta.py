#!/usr/bin/env python3
import struct,sys,json
from pathlib import Path

TABLE_NAMES={
0:'Module',1:'TypeRef',2:'TypeDef',3:'FieldPtr',4:'Field',5:'MethodPtr',6:'MethodDef',7:'ParamPtr',8:'Param',9:'InterfaceImpl',10:'MemberRef',11:'Constant',12:'CustomAttribute',13:'FieldMarshal',14:'DeclSecurity',15:'ClassLayout',16:'FieldLayout',17:'StandAloneSig',18:'EventMap',19:'EventPtr',20:'Event',21:'PropertyMap',22:'PropertyPtr',23:'Property',24:'MethodSemantics',25:'MethodImpl',26:'ModuleRef',27:'TypeSpec',28:'ImplMap',29:'FieldRVA',30:'ENCLog',31:'ENCMap',32:'Assembly',33:'AssemblyProcessor',34:'AssemblyOS',35:'AssemblyRef',36:'AssemblyRefProcessor',37:'AssemblyRefOS',38:'File',39:'ExportedType',40:'ManifestResource',41:'NestedClass',42:'GenericParam',43:'MethodSpec',44:'GenericParamConstraint'}

SCHEMAS={
0:[('Generation','u2'),('Name','str'),('Mvid','guid'),('EncId','guid'),('EncBaseId','guid')],
1:[('ResolutionScope','coded:ResolutionScope'),('TypeName','str'),('TypeNamespace','str')],
2:[('Flags','u4'),('TypeName','str'),('TypeNamespace','str'),('Extends','coded:TypeDefOrRef'),('FieldList','idx:Field'),('MethodList','idx:MethodDef')],
3:[('Field','idx:Field')],
4:[('Flags','u2'),('Name','str'),('Signature','blob')],
5:[('Method','idx:MethodDef')],
6:[('RVA','u4'),('ImplFlags','u2'),('Flags','u2'),('Name','str'),('Signature','blob'),('ParamList','idx:Param')],
7:[('Param','idx:Param')],
8:[('Flags','u2'),('Sequence','u2'),('Name','str')],
9:[('Class','idx:TypeDef'),('Interface','coded:TypeDefOrRef')],
10:[('Class','coded:MemberRefParent'),('Name','str'),('Signature','blob')],
11:[('Type','u2'),('Parent','coded:HasConstant'),('Value','blob')],
12:[('Parent','coded:HasCustomAttribute'),('Type','coded:CustomAttributeType'),('Value','blob')],
13:[('Parent','coded:HasFieldMarshal'),('NativeType','blob')],
14:[('Action','u2'),('Parent','coded:HasDeclSecurity'),('PermissionSet','blob')],
15:[('PackingSize','u2'),('ClassSize','u4'),('Parent','idx:TypeDef')],
16:[('Offset','u4'),('Field','idx:Field')],
17:[('Signature','blob')],
18:[('Parent','idx:TypeDef'),('EventList','idx:Event')],
19:[('Event','idx:Event')],
20:[('EventFlags','u2'),('Name','str'),('EventType','coded:TypeDefOrRef')],
21:[('Parent','idx:TypeDef'),('PropertyList','idx:Property')],
22:[('Property','idx:Property')],
23:[('Flags','u2'),('Name','str'),('Type','blob')],
24:[('Semantics','u2'),('Method','idx:MethodDef'),('Association','coded:HasSemantics')],
25:[('Class','idx:TypeDef'),('MethodBody','coded:MethodDefOrRef'),('MethodDeclaration','coded:MethodDefOrRef')],
26:[('Name','str')],
27:[('Signature','blob')],
28:[('MappingFlags','u2'),('MemberForwarded','coded:MemberForwarded'),('ImportName','str'),('ImportScope','idx:ModuleRef')],
29:[('RVA','u4'),('Field','idx:Field')],
30:[('Token','u4'),('FuncCode','u4')],
31:[('Token','u4')],
32:[('HashAlgId','u4'),('MajorVersion','u2'),('MinorVersion','u2'),('BuildNumber','u2'),('RevisionNumber','u2'),('Flags','u4'),('PublicKey','blob'),('Name','str'),('Culture','str')],
33:[('Processor','u4')],
34:[('OSPlatformId','u4'),('OSMajorVersion','u4'),('OSMinorVersion','u4')],
35:[('MajorVersion','u2'),('MinorVersion','u2'),('BuildNumber','u2'),('RevisionNumber','u2'),('Flags','u4'),('PublicKeyOrToken','blob'),('Name','str'),('Culture','str'),('HashValue','blob')],
36:[('Processor','u4'),('AssemblyRef','idx:AssemblyRef')],
37:[('OSPlatformId','u4'),('OSMajorVersion','u4'),('OSMinorVersion','u4'),('AssemblyRef','idx:AssemblyRef')],
38:[('Flags','u4'),('Name','str'),('HashValue','blob')],
39:[('Flags','u4'),('TypeDefId','u4'),('TypeName','str'),('TypeNamespace','str'),('Implementation','coded:Implementation')],
40:[('Offset','u4'),('Flags','u4'),('Name','str'),('Implementation','coded:Implementation')],
41:[('NestedClass','idx:TypeDef'),('EnclosingClass','idx:TypeDef')],
42:[('Number','u2'),('Flags','u2'),('Owner','coded:TypeOrMethodDef'),('Name','str')],
43:[('Method','coded:MethodDefOrRef'),('Instantiation','blob')],
44:[('Owner','idx:GenericParam'),('Constraint','coded:TypeDefOrRef')],
}
CODED={
'TypeDefOrRef':([2,1,27],2),
'HasConstant':([4,8,23],2),
'HasCustomAttribute':([6,4,1,2,8,9,10,0,14,23,20,17,26,27,32,35,38,39,40,42,44,43],5),
'HasFieldMarshal':([4,8],1),
'HasDeclSecurity':([2,6,32],2),
'MemberRefParent':([2,1,26,6,27],3),
'HasSemantics':([20,23],1),
'MethodDefOrRef':([6,10],1),
'MemberForwarded':([4,6],1),
'Implementation':([38,35,39],2),
'CustomAttributeType':([None,None,6,10,None],3),
'ResolutionScope':([0,26,35,1],2),
'TypeOrMethodDef':([2,6],1),
}

def u16(b,o):return struct.unpack_from('<H',b,o)[0]
def u32(b,o):return struct.unpack_from('<I',b,o)[0]
def u64(b,o):return struct.unpack_from('<Q',b,o)[0]

class DotNet:
 def __init__(self,path):
  self.path=Path(path); self.b=self.path.read_bytes(); self.sections=[]; self.parse_pe(); self.parse_md()
 def rva2off(self,rva):
  for va,vs,rawsz,rawptr,name in self.sections:
   if va <= rva < va+max(vs,rawsz): return rawptr+(rva-va)
  if rva < self.size_headers:return rva
  raise KeyError(hex(rva))
 def parse_pe(self):
  b=self.b; pe=u32(b,0x3c); assert b[pe:pe+4]==b'PE\0\0'; coff=pe+4
  nsec=u16(b,coff+2); optsz=u16(b,coff+16); opt=coff+20
  magic=u16(b,opt); dd=opt+(96 if magic==0x10b else 112)
  self.size_headers=u32(b,opt+60)
  cli_rva=u32(b,dd+14*8); cli_sz=u32(b,dd+14*8+4)
  sh=opt+optsz
  for i in range(nsec):
   o=sh+i*40; name=b[o:o+8].split(b'\0')[0].decode('latin1'); vs=u32(b,o+8); va=u32(b,o+12); rawsz=u32(b,o+16); rawptr=u32(b,o+20)
   self.sections.append((va,vs,rawsz,rawptr,name))
  cli=self.rva2off(cli_rva); self.cli_rva=cli_rva; self.md_rva=u32(b,cli+8); self.md_size=u32(b,cli+12); self.res_rva=u32(b,cli+24); self.res_size=u32(b,cli+28)
 def parse_md(self):
  b=self.b;o=self.rva2off(self.md_rva); assert b[o:o+4]==b'BSJB'; verlen=u32(b,o+12); p=o+16+verlen; p=(p+3)&~3; flags=u16(b,p); ns=u16(b,p+2);p+=4
  self.streams={}
  for _ in range(ns):
   off=u32(b,p); sz=u32(b,p+4); p+=8; z=b.index(0,p); name=b[p:z].decode('ascii'); p=(z+4)&~3; self.streams[name]=(o+off,sz)
  self.str_base=self.streams['#Strings'][0]; self.blob_base=self.streams['#Blob'][0]; self.guid_base=self.streams['#GUID'][0]
  tb=self.streams.get('#~',self.streams.get('#-'))[0]; p=tb+4; self.major=b[p];self.minor=b[p+1];self.heap_sizes=b[p+2];p+=4
  valid=u64(b,p); sortedmask=u64(b,p+8);p+=16
  self.rowcounts={}
  for i in range(64):
   if valid>>i &1:self.rowcounts[i]=u32(b,p);p+=4
  self.table_data=p; self.table_offsets={}; cur=p
  for tid in range(64):
   if tid in self.rowcounts:
    self.table_offsets[tid]=cur; cur += self.row_size(tid)*self.rowcounts[tid]
  self.tables={}
  for tid,n in self.rowcounts.items():
   sch=SCHEMAS.get(tid)
   if not sch: continue
   rows=[]; p=self.table_offsets[tid]
   for rid in range(1,n+1):
    row={}; q=p
    for nm,typ in sch:
     val,sz=self.read_col(typ,q);q+=sz;row[nm]=val
    row['_rid']=rid; rows.append(row); p+=self.row_size(tid)
   self.tables[tid]=rows
  # declaring types
  self.method_owner={}; tds=self.tables.get(2,[]); mc=self.rowcounts.get(6,0)
  for i,t in enumerate(tds):
   a=t['MethodList']; z=(tds[i+1]['MethodList'] if i+1<len(tds) else mc+1)
   for rid in range(a,z): self.method_owner[rid]=t['_rid']
  self.field_owner={}; fc=self.rowcounts.get(4,0)
  for i,t in enumerate(tds):
   a=t['FieldList']; z=(tds[i+1]['FieldList'] if i+1<len(tds) else fc+1)
   for rid in range(a,z):self.field_owner[rid]=t['_rid']
 def idx_size(self,tid): return 2 if self.rowcounts.get(tid,0)<65536 else 4
 def coded_size(self,name):
  tabs,bits=CODED[name]; mx=max([self.rowcounts.get(t,0) for t in tabs if t is not None] or [0]); return 2 if mx < (1<<(16-bits)) else 4
 def read_col(self,typ,o):
  if typ=='u2':return u16(self.b,o),2
  if typ=='u4':return u32(self.b,o),4
  if typ=='str':
   sz=4 if self.heap_sizes&1 else 2; ix=u32(self.b,o) if sz==4 else u16(self.b,o); return ix,sz
  if typ=='guid':
   sz=4 if self.heap_sizes&2 else 2; ix=u32(self.b,o) if sz==4 else u16(self.b,o); return ix,sz
  if typ=='blob':
   sz=4 if self.heap_sizes&4 else 2; ix=u32(self.b,o) if sz==4 else u16(self.b,o); return ix,sz
  if typ.startswith('idx:'):
   name=typ[4:]; tid=next(k for k,v in TABLE_NAMES.items() if v==name);sz=self.idx_size(tid);return (u32(self.b,o) if sz==4 else u16(self.b,o)),sz
  if typ.startswith('coded:'):
   name=typ[6:];sz=self.coded_size(name);return (u32(self.b,o) if sz==4 else u16(self.b,o)),sz
  raise KeyError(typ)
 def row_size(self,tid):
  sch=SCHEMAS.get(tid)
  if not sch: raise KeyError(f'unsupported table {tid} {TABLE_NAMES.get(tid)}')
  return sum(self.read_col(t,self.table_data)[1] for _,t in sch)
 def s(self,ix):
  if ix==0:return ''
  o=self.str_base+ix;z=self.b.index(0,o);return self.b[o:z].decode('utf-8','replace')
 def blob(self,ix):
  if ix==0:return b''
  p=self.blob_base+ix; x=self.b[p]
  if x&0x80==0:n=x;p+=1
  elif x&0xC0==0x80:n=((x&0x3f)<<8)|self.b[p+1];p+=2
  else:n=((x&0x1f)<<24)|(self.b[p+1]<<16)|(self.b[p+2]<<8)|self.b[p+3];p+=4
  return self.b[p:p+n]
 def coded_decode(self,name,v):
  tabs,bits=CODED[name];tag=v&((1<<bits)-1);rid=v>>bits;return (tabs[tag] if tag<len(tabs) else None,rid)
 def type_name(self,rid):
  if not rid:return ''
  r=self.tables[2][rid-1];ns=self.s(r['TypeNamespace']);n=self.s(r['TypeName']);return ns+'.'+n if ns else n
 def typeref_name(self,rid):
  if not rid:return ''
  r=self.tables[1][rid-1];ns=self.s(r['TypeNamespace']);n=self.s(r['TypeName']);return ns+'.'+n if ns else n
 def method_name(self,rid,full=True):
  r=self.tables[6][rid-1];n=self.s(r['Name']);own=self.method_owner.get(rid);return (self.type_name(own)+'::'+n) if full and own else n
 def field_name(self,rid,full=True):
  r=self.tables[4][rid-1];n=self.s(r['Name']);own=self.field_owner.get(rid);return (self.type_name(own)+'::'+n) if full and own else n
 def memberref_name(self,rid):
  r=self.tables[10][rid-1];n=self.s(r['Name']);tid,prid=self.coded_decode('MemberRefParent',r['Class']);owner=''
  if tid==2:owner=self.type_name(prid)
  elif tid==1:owner=self.typeref_name(prid)
  elif tid==6:owner=self.method_name(prid)
  elif tid==26:owner='ModuleRef:'+self.s(self.tables[26][prid-1]['Name'])
  elif tid==27:owner='TypeSpec'
  return owner+'::'+n if owner else n
 def token_name(self,tok):
  tid=(tok>>24)&0xff;rid=tok&0xffffff
  try:
   if tid==6:return self.method_name(rid)
   if tid==10:return self.memberref_name(rid)
   if tid==4:return self.field_name(rid)
   if tid==2:return self.type_name(rid)
   if tid==1:return self.typeref_name(rid)
   if tid==17:return 'StandAloneSig#'+str(rid)
   if tid==0x70:return 'UserString#'+hex(rid)
   if tid==43:
    r=self.tables[43][rid-1]; t,rr=self.coded_decode('MethodDefOrRef',r['Method']);base=self.method_name(rr) if t==6 else self.memberref_name(rr);return 'MethodSpec:'+base
  except Exception:pass
  return f'0x{tok:08X}'
 def method_body(self,rid):
  r=self.tables[6][rid-1];rva=r['RVA'];
  if not rva:return None
  o=self.rva2off(rva); b0=self.b[o]
  if b0&3==2:
   size=b0>>2; return {'rva':rva,'off':o,'header':1,'code_size':size,'maxstack':8,'localsig':0,'il':self.b[o+1:o+1+size]}
  if b0&3==3:
   flags_size=u16(self.b,o); hsz=((flags_size>>12)&0xf)*4; maxstack=u16(self.b,o+2);codesz=u32(self.b,o+4);localsig=u32(self.b,o+8)
   return {'rva':rva,'off':o,'header':hsz,'code_size':codesz,'maxstack':maxstack,'localsig':localsig,'il':self.b[o+hsz:o+hsz+codesz], 'flags':flags_size&0xfff}
  raise ValueError(('bad method header',rid,hex(rva),hex(b0)))

def main():
 d=DotNet(sys.argv[1]); print('tables', {TABLE_NAMES.get(k,k):v for k,v in d.rowcounts.items()}); print('streams',d.streams)
 for rid,r in enumerate(d.tables.get(6,[]),1):
  n=d.method_name(rid)
  if any(x.lower() in n.lower() for x in sys.argv[2:]) if len(sys.argv)>2 else False:
   print(f'{rid:5} 0x060{rid:05X} RVA={r["RVA"]:08X} {n}')
if __name__=='__main__':main()
