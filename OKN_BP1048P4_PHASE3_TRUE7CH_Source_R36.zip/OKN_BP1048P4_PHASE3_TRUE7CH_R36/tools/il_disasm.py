#!/usr/bin/env python3
import struct,sys
sys.path.insert(0,'/mnt/data/r31_analysis')
from dotnet_meta import DotNet
# name, operand: none,i1,u1,i2,u2,i4,i8,r4,r8,token,br1,br4,switch,var1,var2
O={
0x00:('nop','none'),0x01:('break','none'),0x02:('ldarg.0','none'),0x03:('ldarg.1','none'),0x04:('ldarg.2','none'),0x05:('ldarg.3','none'),
0x06:('ldloc.0','none'),0x07:('ldloc.1','none'),0x08:('ldloc.2','none'),0x09:('ldloc.3','none'),0x0a:('stloc.0','none'),0x0b:('stloc.1','none'),0x0c:('stloc.2','none'),0x0d:('stloc.3','none'),
0x0e:('ldarg.s','var1'),0x0f:('ldarga.s','var1'),0x10:('starg.s','var1'),0x11:('ldloc.s','var1'),0x12:('ldloca.s','var1'),0x13:('stloc.s','var1'),
0x14:('ldnull','none'),0x15:('ldc.i4.m1','none'),0x16:('ldc.i4.0','none'),0x17:('ldc.i4.1','none'),0x18:('ldc.i4.2','none'),0x19:('ldc.i4.3','none'),0x1a:('ldc.i4.4','none'),0x1b:('ldc.i4.5','none'),0x1c:('ldc.i4.6','none'),0x1d:('ldc.i4.7','none'),0x1e:('ldc.i4.8','none'),0x1f:('ldc.i4.s','i1'),0x20:('ldc.i4','i4'),0x21:('ldc.i8','i8'),0x22:('ldc.r4','r4'),0x23:('ldc.r8','r8'),
0x25:('dup','none'),0x26:('pop','none'),0x27:('jmp','token'),0x28:('call','token'),0x29:('calli','token'),0x2a:('ret','none'),
0x2b:('br.s','br1'),0x2c:('brfalse.s','br1'),0x2d:('brtrue.s','br1'),0x2e:('beq.s','br1'),0x2f:('bge.s','br1'),0x30:('bgt.s','br1'),0x31:('ble.s','br1'),0x32:('blt.s','br1'),0x33:('bne.un.s','br1'),0x34:('bge.un.s','br1'),0x35:('bgt.un.s','br1'),0x36:('ble.un.s','br1'),0x37:('blt.un.s','br1'),
0x38:('br','br4'),0x39:('brfalse','br4'),0x3a:('brtrue','br4'),0x3b:('beq','br4'),0x3c:('bge','br4'),0x3d:('bgt','br4'),0x3e:('ble','br4'),0x3f:('blt','br4'),0x40:('bne.un','br4'),0x41:('bge.un','br4'),0x42:('bgt.un','br4'),0x43:('ble.un','br4'),0x44:('blt.un','br4'),0x45:('switch','switch'),
0x46:('ldind.i1','none'),0x47:('ldind.u1','none'),0x48:('ldind.i2','none'),0x49:('ldind.u2','none'),0x4a:('ldind.i4','none'),0x4b:('ldind.u4','none'),0x4c:('ldind.i8','none'),0x4d:('ldind.i','none'),0x4e:('ldind.r4','none'),0x4f:('ldind.r8','none'),0x50:('ldind.ref','none'),0x51:('stind.ref','none'),0x52:('stind.i1','none'),0x53:('stind.i2','none'),0x54:('stind.i4','none'),0x55:('stind.i8','none'),0x56:('stind.r4','none'),0x57:('stind.r8','none'),
0x58:('add','none'),0x59:('sub','none'),0x5a:('mul','none'),0x5b:('div','none'),0x5c:('div.un','none'),0x5d:('rem','none'),0x5e:('rem.un','none'),0x5f:('and','none'),0x60:('or','none'),0x61:('xor','none'),0x62:('shl','none'),0x63:('shr','none'),0x64:('shr.un','none'),0x65:('neg','none'),0x66:('not','none'),
0x67:('conv.i1','none'),0x68:('conv.i2','none'),0x69:('conv.i4','none'),0x6a:('conv.i8','none'),0x6b:('conv.r4','none'),0x6c:('conv.r8','none'),0x6d:('conv.u4','none'),0x6e:('conv.u8','none'),0x6f:('callvirt','token'),0x70:('cpobj','token'),0x71:('ldobj','token'),0x72:('ldstr','token'),0x73:('newobj','token'),0x74:('castclass','token'),0x75:('isinst','token'),0x76:('conv.r.un','none'),
0x79:('unbox','token'),0x7a:('throw','none'),0x7b:('ldfld','token'),0x7c:('ldflda','token'),0x7d:('stfld','token'),0x7e:('ldsfld','token'),0x7f:('ldsflda','token'),0x80:('stsfld','token'),0x81:('stobj','token'),
0x82:('conv.ovf.i1.un','none'),0x83:('conv.ovf.i2.un','none'),0x84:('conv.ovf.i4.un','none'),0x85:('conv.ovf.i8.un','none'),0x86:('conv.ovf.u1.un','none'),0x87:('conv.ovf.u2.un','none'),0x88:('conv.ovf.u4.un','none'),0x89:('conv.ovf.u8.un','none'),0x8a:('conv.ovf.i.un','none'),0x8b:('conv.ovf.u.un','none'),0x8c:('box','token'),0x8d:('newarr','token'),0x8e:('ldlen','none'),0x8f:('ldelema','token'),
0x90:('ldelem.i1','none'),0x91:('ldelem.u1','none'),0x92:('ldelem.i2','none'),0x93:('ldelem.u2','none'),0x94:('ldelem.i4','none'),0x95:('ldelem.u4','none'),0x96:('ldelem.i8','none'),0x97:('ldelem.i','none'),0x98:('ldelem.r4','none'),0x99:('ldelem.r8','none'),0x9a:('ldelem.ref','none'),0x9b:('stelem.i','none'),0x9c:('stelem.i1','none'),0x9d:('stelem.i2','none'),0x9e:('stelem.i4','none'),0x9f:('stelem.i8','none'),0xa0:('stelem.r4','none'),0xa1:('stelem.r8','none'),0xa2:('stelem.ref','none'),0xa3:('ldelem','token'),0xa4:('stelem','token'),0xa5:('unbox.any','token'),
0xb3:('conv.ovf.i1','none'),0xb4:('conv.ovf.u1','none'),0xb5:('conv.ovf.i2','none'),0xb6:('conv.ovf.u2','none'),0xb7:('conv.ovf.i4','none'),0xb8:('conv.ovf.u4','none'),0xb9:('conv.ovf.i8','none'),0xba:('conv.ovf.u8','none'),
0xc2:('refanyval','token'),0xc3:('ckfinite','none'),0xc6:('mkrefany','token'),0xd0:('ldtoken','token'),0xd1:('conv.u2','none'),0xd2:('conv.u1','none'),0xd3:('conv.i','none'),0xd4:('conv.ovf.i','none'),0xd5:('conv.ovf.u','none'),0xd6:('add.ovf','none'),0xd7:('add.ovf.un','none'),0xd8:('mul.ovf','none'),0xd9:('mul.ovf.un','none'),0xda:('sub.ovf','none'),0xdb:('sub.ovf.un','none'),0xdc:('endfinally','none'),0xdd:('leave','br4'),0xde:('leave.s','br1'),0xdf:('stind.i','none'),0xe0:('conv.u','none'),
}
OF={0x00:('arglist','none'),0x01:('ceq','none'),0x02:('cgt','none'),0x03:('cgt.un','none'),0x04:('clt','none'),0x05:('clt.un','none'),0x06:('ldftn','token'),0x07:('ldvirtftn','token'),0x09:('ldarg','var2'),0x0a:('ldarga','var2'),0x0b:('starg','var2'),0x0c:('ldloc','var2'),0x0d:('ldloca','var2'),0x0e:('stloc','var2'),0x0f:('localloc','none'),0x11:('endfilter','none'),0x12:('unaligned.','u1'),0x13:('volatile.','none'),0x14:('tail.','none'),0x15:('initobj','token'),0x16:('constrained.','token'),0x17:('cpblk','none'),0x18:('initblk','none'),0x1a:('rethrow','none'),0x1c:('sizeof','token'),0x1d:('refanytype','none'),0x1e:('readonly.','none')}

def disasm(il,d=None):
 out=[];i=0; n=len(il)
 while i<n:
  start=i;op=il[i];i+=1
  if op==0xfe:
   if i>=n:out.append((start,'<trunc>',''));break
   op2=il[i];i+=1; name,ot=OF.get(op2,(f'FE_{op2:02X}','none'))
  else:name,ot=O.get(op,(f'OP_{op:02X}','none'))
  v=''
  try:
   if ot=='i1':v=struct.unpack_from('<b',il,i)[0];i+=1
   elif ot=='u1' or ot=='var1':v=il[i];i+=1
   elif ot=='i2':v=struct.unpack_from('<h',il,i)[0];i+=2
   elif ot=='u2' or ot=='var2':v=struct.unpack_from('<H',il,i)[0];i+=2
   elif ot=='i4':v=struct.unpack_from('<i',il,i)[0];i+=4
   elif ot=='i8':v=struct.unpack_from('<q',il,i)[0];i+=8
   elif ot=='r4':v=struct.unpack_from('<f',il,i)[0];i+=4
   elif ot=='r8':v=struct.unpack_from('<d',il,i)[0];i+=8
   elif ot=='token':
    tok=struct.unpack_from('<I',il,i)[0];i+=4;v=f'0x{tok:08X}'+((' '+d.token_name(tok)) if d else '')
   elif ot=='br1':
    rel=struct.unpack_from('<b',il,i)[0];i+=1;v=f'IL_{i+rel:04X}'
   elif ot=='br4':
    rel=struct.unpack_from('<i',il,i)[0];i+=4;v=f'IL_{i+rel:04X}'
   elif ot=='switch':
    c=struct.unpack_from('<I',il,i)[0];i+=4;rels=struct.unpack_from('<'+'i'*c,il,i);i+=4*c;base=i;v='['+', '.join(f'IL_{base+r:04X}' for r in rels)+']'
  except Exception as e:
   out.append((start,name,f'<truncated {e}>'));break
  out.append((start,name,str(v)))
 return out

if __name__=='__main__':
 d=DotNet(sys.argv[1]);rid=int(sys.argv[2],0)&0xffffff;body=d.method_body(rid);start=int(sys.argv[3],0) if len(sys.argv)>3 else 0;end=int(sys.argv[4],0) if len(sys.argv)>4 else len(body['il'])
 for off,n,v in disasm(body['il'],d):
  if start<=off<end:print(f'IL_{off:04X}: {n:18} {v}')
