#!/usr/bin/env python3
from pathlib import Path
import json, re
ROOT=Path(__file__).resolve().parents[1]
state=json.loads((ROOT/'config/R36_EXPERIMENTAL_GATE.json').read_text())
assert state['target']=='BP1048P4'
assert state['sacrificial_board_only'] is True
assert state['stock_reference_board_must_remain_untouched'] is True
assert state['destructive_flash_packet_in_source'] is False
assert state['vendor_executable_in_source'] is False
assert state['sdk_commit']=='8105bd864b04995d81c9f9ae77cb158259f39015'
bridge=(ROOT/'firmware/src/okn_r36_sdk_bridge.c').read_text()
assert 'AudioCoreSinkVolSet(AUDIO_DAC0_SINK_NUM' in bridge
assert '__wrap_AudioI2S0_DataSet' in bridge and '__wrap_AudioI2S1_DataSet' in bridge
assert 'I2S_WordlengthGet' in bridge and 'I2S_LENGTH_16BITS' in bridge
assert 's_i2s0_scratch' in bridge and 's_i2s1_scratch' in bridge
assert 'SpiFlashErase' not in bridge and 'SpiFlashWrite' not in bridge
# TRUE7CH must remain dedicated IDs 22..28, never stock EQ IDs.
ufe=(ROOT/'firmware/include/okn_ufe_gain7.h').read_text()
for n in range(22,29): assert f'{n}u' in ufe
for banned in ['EQ gain','Band1 volume','Tone Control volume']:
    assert banned not in bridge
# No binary firmware is shipped until an Andes target build actually succeeds.
for p in ROOT.rglob('*'):
    if p.is_file() and p.suffix.lower() in {'.exe','.dll','.apk','.mva','.img','.fw','.rom','.dfu','.elf','.adx'}:
        raise AssertionError(f'forbidden/unverified binary in R36 source checkpoint: {p}')
wf=(ROOT/'.github/workflows/R36_ANDES_TARGET_COMPILE.yml').read_text()
for required in ['8105bd864b04995d81c9f9ae77cb158259f39015','nds32le-elf-gcc','OKN_R36_VENDOR_SDK=1','enable_bp1048p4.py','check_sdk_files.py']:
    assert required in wf, required
patch=(ROOT/'experimental_r36/scripts/enable_bp1048p4.py').read_text()
assert 'CFG_CHIP_BP1048P4' in patch and 'REFUSE' in patch
print('R36 experimental firmware guard: PASS')
