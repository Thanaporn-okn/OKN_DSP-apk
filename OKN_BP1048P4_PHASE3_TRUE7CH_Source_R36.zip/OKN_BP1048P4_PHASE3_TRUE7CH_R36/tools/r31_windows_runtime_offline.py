#!/usr/bin/env python3
import argparse, hashlib, json, re, struct
from pathlib import Path
from dotnet_meta import DotNet, TABLE_NAMES
from il_disasm import disasm

EXPECTED_SIZE=3307008
EXPECTED_SHA='3ca54171c53f7badd963ffe6851b8b3e2faf8aee8ba2afcb7040990e22ae09b2'
RISK_TERMS = {
 'read_like':['read','getinputreport','getfeature','receive','received','sensor','actuator','description','status','version','info'],
 'write_like':['write','setoutputreport','setfeature','send','save','program','erase','commit','reset','upgrade','update'],
 'backup_like':['backup','dump','upload','export','readflash','flashread','read flash','firmware dump','stock backup'],
 'flash_like':['flash','firmware','boot','upgrade','update','mva','obex'],
}
FOCUS_TYPES=['Hid','HIDInterface','HardwareSerialInterface','DeviceCommunicationStream','UFEcommandBridge','WriteActuatorPeriperalCommand','ReadActuatorPeriperalCommand','HardwareCommandConverter']

def sha256(p):
 h=hashlib.sha256();
 with open(p,'rb') as f:
  for c in iter(lambda:f.read(1<<20),b''):h.update(c)
 return h.hexdigest()

def method_rows(d):
 out=[]
 for rid,r in enumerate(d.tables.get(6,[]),1):
  out.append({'rid':rid,'token':f'0x060{rid:05X}','rva':r['RVA'],'name':d.method_name(rid)})
 return out

def implmap(d):
 mods=d.tables.get(26,[]); rows=[]
 for r in d.tables.get(28,[]):
  tid,rid=d.coded_decode('MemberForwarded',r['MemberForwarded'])
  if tid==6: managed=d.method_name(rid)
  elif tid==4: managed=d.field_name(rid)
  else: managed=f'table{tid}#{rid}'
  scope=r['ImportScope']; dll=d.s(mods[scope-1]['Name']) if scope else ''
  rows.append({'managed':managed,'native':d.s(r['ImportName']),'dll':dll,'mapping_flags':r['MappingFlags']})
 return rows

def extract_strings(data,minlen=4):
 ascii_re=re.compile(rb'[\x20-\x7e]{%d,}'%minlen)
 for m in ascii_re.finditer(data):yield ('ascii',m.start(),m.group().decode('ascii','replace'))
 # utf16le basic
 pat=re.compile(rb'(?:[\x20-\x7e]\x00){%d,}'%minlen)
 for m in pat.finditer(data):yield ('utf16le',m.start(),m.group().decode('utf-16le','replace'))

def scan_calls(d, target_tokens):
 hits=[]
 for rid,r in enumerate(d.tables.get(6,[]),1):
  if not r['RVA']:continue
  try:b=d.method_body(rid)
  except Exception:continue
  if not b:continue
  for off,op,arg in disasm(b['il'],d):
   if op in ('call','callvirt','newobj','ldftn','ldvirtftn') and arg.startswith('0x'):
    tok=int(arg.split()[0],16)
    if tok in target_tokens:
     hits.append({'caller_token':f'0x060{rid:05X}','caller':d.method_name(rid),'offset':off,'opcode':op,'target_token':f'0x{tok:08X}','target':d.token_name(tok)})
 return hits

def ufe_constants(d):
 out=[]
 for c in d.tables.get(11,[]):
  tid,rid=d.coded_decode('HasConstant',c['Parent'])
  if tid!=4: continue
  name=d.field_name(rid)
  if 'UFEHeader::' not in name: continue
  b=d.blob(c['Value']); val=None
  if len(b)==1: val=b[0]
  elif len(b)==2: val=struct.unpack('<H',b)[0]
  elif len(b)==4: val=struct.unpack('<I',b)[0]
  elif len(b)==8: val=struct.unpack('<Q',b)[0]
  out.append({'field':name,'value':val,'hex':f'0x{val:02X}' if val is not None else None,'blob':b.hex()})
 return out

def main():
 ap=argparse.ArgumentParser(description='Offline-only R31 Windows runtime/HID static inventory. No device access.')
 ap.add_argument('exe'); ap.add_argument('--out',required=True)
 a=ap.parse_args(); p=Path(a.exe); out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
 data=p.read_bytes(); digest=sha256(p)
 if len(data)!=EXPECTED_SIZE or digest!=EXPECTED_SHA:raise SystemExit(f'REFUSE: unexpected target: size={len(data)} sha256={digest}')
 d=DotNet(p)
 methods=method_rows(d); im=implmap(d); ufe=ufe_constants(d)
 # focus methods
 focus=[]
 for m in methods:
  owner=m['name'].split('::',1)[0].split('.')[-1]
  if owner in FOCUS_TYPES:focus.append(m)
 # keyword methods/type names
 keys=sorted(set(sum(RISK_TERMS.values(),[])))
 candidates=[]
 for m in methods:
  low=m['name'].lower().replace('_',' ')
  terms=[k for k in keys if k in low]
  if terms:candidates.append({**m,'terms':terms})
 # strings
 sh=[]
 for enc,off,s in extract_strings(data):
  low=s.lower().replace('_',' ')
  terms=[k for k in keys if k in low]
  if terms: sh.append({'encoding':enc,'file_offset':off,'text':s[:500],'terms':terms})
 # PInvoke direct-call scan from on-disk IL. Protected methods are expected to be stubs.
 p_tokens={}
 for r in d.tables.get(28,[]):
  tid,rid=d.coded_decode('MemberForwarded',r['MemberForwarded'])
  if tid==6:p_tokens[(0x06<<24)|rid]=d.method_name(rid)
 direct=scan_calls(d,set(p_tokens))
 result={
  'target':{'name':p.name,'size':len(data),'sha256':digest,'expected_match':True},
  'metadata_counts':{TABLE_NAMES.get(k,str(k)):v for k,v in d.rowcounts.items()},
  'focus_methods':focus,
  'pinvoke_imports':im,
  'ufe_header_constants':ufe,
  'on_disk_direct_calls_to_pinvoke':direct,
  'keyword_method_candidates':candidates,
  'keyword_string_hits':sh,
  'interpretation':{
    'pinvoke_receive_is_transport_only':'HidD_GetInputReport/ReadFile presence proves receive capability, not flash-addressable readback.',
    'pinvoke_mutating_surface':'HidD_SetOutputReport/HidD_SetFeature/WriteFile are capable of sending state-changing data; unsafe absent proven dispatch semantics.',
    'protected_code_limit':'Many active managed methods are protected/stubbed on disk; absence of direct calls in raw IL cannot prove absence from restored protected IL.',
    'no_live_io':'This analyzer only reads the EXE file and writes reports.'
  }
 }
 (out/'r31_inventory.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf-8')
 with (out/'UFE_HEADER_CONSTANTS.txt').open('w',encoding='utf-8') as f:
  for x in ufe:f.write(f"{x['hex']} {x['field']}\n")
 with (out/'HID_NATIVE_IMPORT_MAP.txt').open('w',encoding='utf-8') as f:
  f.write('R31 Windows 2026 native HID/Win32 import map (offline static)\n')
  f.write(f'SHA256 {digest}\n\n')
  for x in im:f.write(f"{x['managed']} -> {x['dll']}!{x['native']}\n")
 with (out/'MANAGED_FOCUS_METHODS.txt').open('w',encoding='utf-8') as f:
  for x in focus:f.write(f"{x['token']} RVA=0x{x['rva']:08X} {x['name']}\n")
 with (out/'KEYWORD_CANDIDATES.txt').open('w',encoding='utf-8') as f:
  f.write('=== METHOD/TYPE NAMES ===\n')
  for x in candidates:f.write(f"{x['token']} RVA=0x{x['rva']:08X} terms={','.join(x['terms'])} {x['name']}\n")
  f.write('\n=== EMBEDDED STRINGS ===\n')
  for x in sh:f.write(f"0x{x['file_offset']:08X} {x['encoding']} terms={','.join(x['terms'])} {x['text']}\n")
 with (out/'RAW_IL_PINVOKE_CALLS.txt').open('w',encoding='utf-8') as f:
  f.write('Caveat: protected runtime IL is restored later; this is only on-disk IL.\n')
  for x in direct:f.write(f"{x['caller_token']} {x['caller']} IL_{x['offset']:04X} {x['opcode']} {x['target_token']} {x['target']}\n")
 print(json.dumps({'size':len(data),'sha256':digest,'pinvoke':len(im),'focus_methods':len(focus),'keyword_methods':len(candidates),'keyword_strings':len(sh),'raw_pinvoke_calls':len(direct)}))
if __name__=='__main__':main()
