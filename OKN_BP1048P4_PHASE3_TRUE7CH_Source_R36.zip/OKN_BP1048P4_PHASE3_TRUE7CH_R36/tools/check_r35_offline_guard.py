#!/usr/bin/env python3
from pathlib import Path
import json, re, sys
ROOT = Path(__file__).resolve().parents[1]
state = json.loads((ROOT/'config/R35_PRODUCTION_RECOVERY_GATE.json').read_text())
assert state['flash_gate'] == 'CLOSED'
assert state['device_io'] is False
assert state['hardware_probe'] is False
assert state['destructive_packet_generated'] is False
report = (ROOT/'docs/R35_PRODUCTION_RECOVERY_ARTIFACT_SEARCH_TH.md').read_text(errors='ignore')
for required in ['public factory image: NOT FOUND','production flash layout: NOT PROVEN','FLASH_GATE: CLOSED']:
    assert required in report, required
# Source checkpoint must not ship executable vendor binaries or private keys.
for p in ROOT.rglob('*'):
    if not p.is_file():
        continue
    low = p.name.lower()
    assert not low.endswith(('.exe','.dll','.apk','.mva','.bin','.img','.hex','.fw','.rom','.dfu')), f'forbidden binary in source: {p}'
    assert 'private' not in low or 'key' not in low, f'possible private key: {p}'
# R35 adds no live transport/import implementation.
for p in list((ROOT/'tools').glob('*.py')) + list((ROOT/'firmware').rglob('*.c')):
    txt = p.read_text(errors='ignore').lower()
    if p.name == 'check_r35_offline_guard.py':
        continue
    # Only detect newly introduced obvious live-I/O libraries; legacy evidence parsers may contain words in strings.
    assert 'import usb.core' not in txt
    assert 'import serial' not in txt
    assert 'hid.device(' not in txt
print('R35 offline production-recovery gate guard: PASS')
