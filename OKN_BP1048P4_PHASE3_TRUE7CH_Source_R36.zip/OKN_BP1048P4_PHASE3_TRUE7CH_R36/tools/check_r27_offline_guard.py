#!/usr/bin/env python3
from pathlib import Path
import json, subprocess, sys

root=Path(__file__).resolve().parents[1]
state=root/'config/R27_FLASHBOOT_HID_STATE.json'
risk=root/'config/R27_FLASHBOOT_HID_RISK.json'
report=root/'docs/R27_FLASHBOOT_HID_OFFLINE_REVERSE_TH.md'
correction=root/'docs/R27_R26_TRANSPORT_CORRECTION_TH.md'
evidence=root/'docs/R27_HID_TRANSPORT_EVIDENCE.txt'
for p in (state,risk,report,correction,evidence):
    if not p.is_file(): raise SystemExit(f'R27 FAIL missing {p}')

s=json.loads(state.read_text())
r=json.loads(risk.read_text())
if s.get('revision')!='R27' or s.get('mode')!='OFFLINE_ONLY' or s.get('device_io') is not False:
    raise SystemExit('R27 FAIL state is not offline/fail-closed')
if s.get('reference_flashboot_size')!=65536 or s.get('reference_flashboot_sha256')!='cd0e4e03f7072abd48fea2aeb5a54d9360b65acb1bd4d1b37734438cbe5f47c6':
    raise SystemExit('R27 FAIL reference flashboot mismatch')
if s.get('live_probe_allowed') is not False or s.get('proven_live_read_command') is not None:
    raise SystemExit('R27 FAIL live read unexpectedly enabled')
if s.get('updater_transport',{}).get('output_report',{}).get('payload_bytes') != 256:
    raise SystemExit('R27 FAIL HID Output payload size mismatch')
if s.get('updater_transport',{}).get('input_report',{}).get('payload_bytes') != 256:
    raise SystemExit('R27 FAIL HID Input payload size mismatch')
if s.get('updater_transport',{}).get('output_report',{}).get('bmRequestType') != '0x21':
    raise SystemExit('R27 FAIL HID SET_REPORT bmRequestType mismatch')
if s.get('updater_transport',{}).get('input_report',{}).get('bmRequestType') != '0xA1':
    raise SystemExit('R27 FAIL HID GET_REPORT bmRequestType mismatch')
if s.get('upinfo',{}).get('safe_read') is not False or s.get('cxxx',{}).get('safe_read') is not False:
    raise SystemExit('R27 FAIL upinfo/cxxx accidentally marked safe')
if not s.get('handlers',{}).get('upinfo',{}).get('calls_state_or_mmio_mutator'):
    raise SystemExit('R27 FAIL upinfo state side effect not captured')
if not s.get('handlers',{}).get('cxxx',{}).get('calls_state_or_mmio_mutator'):
    raise SystemExit('R27 FAIL cxxx state side effect not captured')
if r.get('hardware_action_allowed') is not False or r.get('proven_live_read_command') is not None:
    raise SystemExit('R27 FAIL risk policy not fail-closed')
if r.get('r26_transport_finding') != 'SUPERSEDED_ON_UPDATER_CARRIAGE':
    raise SystemExit('R27 FAIL R26 transport correction missing')

# Android remains Bluetooth-discovery only: no USB, RFCOMM data, GATT write or file-picker OTA.
java=(root/'android-bt-probe/app/src/main/java/com/okn/dsp/btprobe/MainActivity.java').read_text()
manifest=(root/'android-bt-probe/app/src/main/AndroidManifest.xml').read_text()
scan=java+'\n'+manifest
for tok in [
    'android.hardware.usb','UsbManager','UsbDevice','controlTransfer(','bulkTransfer(',
    'import android.bluetooth.BluetoothSocket;','createRfcommSocket','writeCharacteristic(',
    'writeDescriptor(','ACTION_OPEN_DOCUMENT','ACTION_GET_CONTENT'
]:
    if tok in scan: raise SystemExit(f'R27 FAIL forbidden Android hardware action token: {tok}')

# Deterministic R27 verifier must reproduce the packaged state.
proc=subprocess.run([
    sys.executable,str(root/'tools/r27_flashboot_hid_reverse.py'),
    str(root/'sdk_evidence/r23_reverse/flash_boot.c'),'--json'
],capture_output=True,text=True,check=True)
now=json.loads(proc.stdout)
for k in ('reference_flashboot_sha256','updater_transport','upinfo','cxxx','proven_live_read_command','live_probe_allowed'):
    if now.get(k) != s.get(k):
        raise SystemExit(f'R27 FAIL deterministic verifier changed field {k}')

print('R27 offline/fail-closed guard: PASS')
print('- updater transport corrected to 256-byte HID Data reports')
print('- upinfo/cxxx proven stateful and blocked')
print('- safe live identity/version command: NONE')
print('- no Android USB/RFCOMM/GATT-write implementation')
