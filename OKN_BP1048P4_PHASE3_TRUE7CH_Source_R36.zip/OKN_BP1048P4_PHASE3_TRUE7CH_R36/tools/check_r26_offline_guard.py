#!/usr/bin/env python3
from pathlib import Path
import json, subprocess, sys

root=Path(__file__).resolve().parents[1]
state=root/'config/R26_FLASHBOOT_OFFLINE_STATE.json'
risk=root/'config/R26_FLASHBOOT_COMMAND_RISK.json'
report=root/'docs/R26_FLASHBOOT_OFFLINE_REVERSE_TH.md'
transport=root/'docs/R26_FLASHBOOT_TRANSPORT_EVIDENCE.txt'
for p in (state,risk,report,transport):
    if not p.is_file(): raise SystemExit(f'R26 FAIL missing {p}')
obj=json.loads(state.read_text())
r=json.loads(risk.read_text())
if obj.get('mode')!='OFFLINE_ONLY' or obj.get('device_io') is not False or obj.get('live_probe_allowed') is not False:
    raise SystemExit('R26 FAIL offline state is not fail-closed')
if obj.get('size')!=65536 or obj.get('sha256')!='cd0e4e03f7072abd48fea2aeb5a54d9360b65acb1bd4d1b37734438cbe5f47c6':
    raise SystemExit('R26 FAIL reference flashboot reconstruction mismatch')
expected=['chiperas','upinfo','btupdat','cnfgdat','constdat','codedata','bootdat','cxxx']
if [x['name'] for x in obj.get('commands',[])] != expected:
    raise SystemExit('R26 FAIL command table mismatch')
if r.get('hardware_action_allowed') is not False or r.get('proven_live_read_command') is not None:
    raise SystemExit('R26 FAIL live command unexpectedly enabled')
# No R26-specific hardware transport implementation may be added to Android.
java=(root/'android-bt-probe/app/src/main/java/com/okn/dsp/btprobe/MainActivity.java').read_text()
for tok in ['android.hardware.usb','UsbManager','UsbDevice','controlTransfer(','bulkTransfer(','import android.bluetooth.BluetoothSocket;','createRfcommSocket','writeCharacteristic(','writeDescriptor(']:
    if tok in java: raise SystemExit(f'R26 FAIL forbidden Android hardware action token: {tok}')
# Re-run deterministic inspector against the included source.
proc=subprocess.run([sys.executable,str(root/'tools/r26_flashboot_offline_inspect.py'),str(root/'sdk_evidence/r23_reverse/flash_boot.c'),'--json'],capture_output=True,text=True,check=True)
now=json.loads(proc.stdout)
if now['sha256'] != obj['sha256'] or now['command_table_offset'] != obj['command_table_offset']:
    raise SystemExit('R26 FAIL deterministic inspector changed')
print('R26 offline/fail-closed guard: PASS')
print('- 64 KiB reference reconstruction verified')
print('- USBC/custom command table verified offline')
print('- no proven live read command; hardware_action_allowed=false')
print('- no new Android USB/RFCOMM/GATT-write implementation')
