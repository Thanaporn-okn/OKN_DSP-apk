#!/usr/bin/env python3
from pathlib import Path
import json, subprocess, sys
root=Path(__file__).resolve().parents[1]
state=root/'config/R28_MVA_RECOVERY_STATE.json'
risk=root/'config/R28_MVA_RECOVERY_RISK.json'
fmt=root/'config/R28_MVA_FORMAT_SUMMARY.json'
report=root/'docs/R28_MVA_RECOVERY_OFFLINE_REVERSE_TH.md'
feature=root/'docs/R28_NORMAL_APP_FEATURE_REPORT_TH.md'
evidence=root/'docs/R28_MVA_PACKAGE_FORMAT_EVIDENCE.txt'
for p in (state,risk,fmt,report,feature,evidence):
    if not p.is_file(): raise SystemExit(f'R28 FAIL missing {p}')
s=json.loads(state.read_text())
r=json.loads(risk.read_text())
f=json.loads(fmt.read_text())
if s.get('revision')!='R28' or s.get('mode')!='OFFLINE_ONLY' or s.get('device_io') is not False:
    raise SystemExit('R28 FAIL state not offline')
if s.get('reference_flashboot_size')!=65536 or s.get('reference_flashboot_sha256')!='cd0e4e03f7072abd48fea2aeb5a54d9360b65acb1bd4d1b37734438cbe5f47c6':
    raise SystemExit('R28 FAIL flashboot reference mismatch')
fr=s['mva_framing']
if fr.get('header_signature_hex')!='4D 56 B1 58' or fr.get('record_count_offset')!=4 or fr.get('first_record_offset')!=5:
    raise SystemExit('R28 FAIL MVA framing mismatch')
if s['crc'].get('algorithm')!='CRC-16/XMODEM' or s['crc'].get('poly')!='0x1021' or s['crc'].get('init')!='0x0000':
    raise SystemExit('R28 FAIL CRC model mismatch')
layout=fr['reference_maker_default_layout']
if layout['record_03']['record_offset']!=13 or layout['record_03']['payload_length']!=1524 or layout['record_03']['helper_blob_length']!=1520:
    raise SystemExit('R28 FAIL pkg03 layout')
if layout['record_02']['record_offset']!=1542 or layout['record_02']['code_data_offset']!=1551:
    raise SystemExit('R28 FAIL pkg02 layout')
if s['normal_app_feature_report'].get('safe_identity_query') is not False:
    raise SystemExit('R28 FAIL Feature GET accidentally treated as identity query')
if s['recovery_assessment'].get('stock_backup_obtained') is not False or s['recovery_assessment'].get('stock_full_flash_readback_path_proven') is not False:
    raise SystemExit('R28 FAIL recovery gate opened without backup')
if s.get('live_probe_allowed') is not False or s.get('proven_live_identity_or_readback_command') is not None:
    raise SystemExit('R28 FAIL live probe unexpectedly enabled')
if r.get('hardware_action_allowed') is not False or r.get('stock_backup_obtained') is not False:
    raise SystemExit('R28 FAIL risk policy')
if f.get('live_use_allowed') is not False:
    raise SystemExit('R28 FAIL format knowledge enabled live use')

# Android remains strict Bluetooth discovery only; R28 adds no USB/update path.
java=(root/'android-bt-probe/app/src/main/java/com/okn/dsp/btprobe/MainActivity.java').read_text()
manifest=(root/'android-bt-probe/app/src/main/AndroidManifest.xml').read_text()
scan=java+'\n'+manifest
for tok in ['android.hardware.usb','UsbManager','UsbDevice','controlTransfer(','bulkTransfer(',
            'import android.bluetooth.BluetoothSocket;','createRfcommSocket','writeCharacteristic(',
            'writeDescriptor(','ACTION_OPEN_DOCUMENT','ACTION_GET_CONTENT']:
    if tok in scan: raise SystemExit(f'R28 FAIL forbidden Android hardware token: {tok}')

# Offline inspector source must not contain device transport imports / packer entry points.
tool=(root/'tools/r28_mva_recovery_offline.py').read_text()
for tok in ['UsbManager','pyusb','serial.Serial','socket.socket','BluetoothSocket','obex','def pack_mva','def build_mva','write_bytes(']:
    if tok in tool: raise SystemExit(f'R28 FAIL offline tool forbidden token: {tok}')

# Deterministic verifier must reproduce packaged state.
proc=subprocess.run([
    sys.executable,str(root/'tools/r28_mva_recovery_offline.py'),
    str(root/'sdk_evidence/r23_reverse/flash_boot.c'),
    '--usb-request-c',str(root/'sdk_evidence/r23_reverse/otg_device_standard_request.c'),
    '--upgrade-c',str(root/'sdk_evidence/r23_reverse/upgrade.c'),
    '--flash-config-h',str(root/'sdk_evidence/r23_reverse/flash_config.h'),
    '--json'
],capture_output=True,text=True,check=True)
now=json.loads(proc.stdout)
for k in ('reference_flashboot_sha256','mva_framing','crc','code_metadata','normal_app_feature_report','internal_upgrade_status','reference_p4_flash_map','recovery_assessment','live_probe_allowed','proven_live_identity_or_readback_command'):
    if now.get(k)!=s.get(k): raise SystemExit(f'R28 FAIL verifier changed {k}')
print('R28 offline/package/recovery guard: PASS')
print('- exact MVA framing + CRC16/XMODEM recovered')
print('- normal Feature GET proven non-identity and unsafe after arm')
print('- stock backup/readback still NOT proven')
print('- live updater probe remains BLOCKED')
