#!/usr/bin/env python3
from pathlib import Path
import json

root = Path(__file__).resolve().parents[1]
java = root / "android-bt-probe/app/src/main/java/com/okn/dsp/btprobe/MainActivity.java"
manifest = root / "android-bt-probe/app/src/main/AndroidManifest.xml"
state = root / "config/R25_BT_OTA_CAPABILITY_STATE.json"
doc = root / "docs/R25_SDK_CORRELATION_REVERSE_TH.md"

for p in (java, manifest, state, doc):
    if not p.is_file():
        raise SystemExit(f"missing required R25 file: {p}")

src = java.read_text(encoding="utf-8")
man = manifest.read_text(encoding="utf-8")
obj = json.loads(state.read_text(encoding="utf-8"))

forbidden_java = [
    "android.hardware.usb", "UsbManager", "UsbDevice", "controlTransfer(", "bulkTransfer(",
    "import android.bluetooth.BluetoothSocket;", "createRfcommSocket", "listenUsingRfcomm",
    "getOutputStream(", "writeCharacteristic(", "readCharacteristic(",
    "setCharacteristicNotification(", "writeDescriptor(", "beginReliableWrite(",
    "executeReliableWrite(", "ACTION_OPEN_DOCUMENT", "java.io.File", "openInputStream(",
]
for token in forbidden_java:
    if token in src:
        raise SystemExit(f"R25 FAIL: forbidden active API/token found in Java: {token}")

required_java = [
    "fetchUuidsWithSdp()", "startDiscovery()", "startScan(scanCallback)", "connectGatt(",
    "discoverServices()", "sdkExpectedBleAddress", "b[0] = b[0] | 0xC0",
    "b[4] = (b[4] + 0x60) & 0xFF", "record.getBytes()", "UUID_OBJECT_PUSH",
    "UUID_UFE_SERVICE_AB00", "UUID_UFE_CHAR_AB01", "UUID_UFE_CHAR_AB02", "UUID_UFE_CHAR_AB03",
]
for token in required_java:
    if token not in src:
        raise SystemExit(f"R25 FAIL: required read-only correlation code missing: {token}")

if "android.hardware.usb.host" in man:
    raise SystemExit("R25 FAIL: USB host feature must not be present")
if "BLUETOOTH_ADVERTISE" in man:
    raise SystemExit("R25 FAIL: advertising permission is unnecessary and forbidden")
for perm in ("BLUETOOTH_SCAN", "BLUETOOTH_CONNECT"):
    if perm not in man:
        raise SystemExit(f"R25 FAIL: manifest missing {perm}")

if obj.get("revision") != "R25" or obj.get("mode") != "READ_ONLY_SDK_CORRELATION_PROBE":
    raise SystemExit("R25 FAIL: state file revision/mode mismatch")
for op in ("rfcomm_socket", "obex_connect", "obex_put", "obex_header_send", "mva_send", "erase", "program", "commit"):
    if op not in obj.get("forbidden_operations", []):
        raise SystemExit(f"R25 FAIL: state file missing forbidden op {op}")

classic = obj["live_r24_findings"]["classic_address"].upper()
ble = obj["live_r24_findings"]["ble_address"].upper()
b = [int(x, 16) for x in classic.split(":")]
b[0] |= 0xC0
b[4] = (b[4] + 0x60) & 0xFF
calc = ":".join(f"{x:02X}" for x in b)
if calc != ble:
    raise SystemExit(f"R25 FAIL: SDK address transform expected {ble} but calculated {calc}")

print("R25 read-only / SDK-correlation guard: PASS")
print(f"- live Classic->BLE transform verified: {classic} -> {calc}")
print("- no USB/RFCOMM/OBEX/file-send/GATT-value operation")
print("- SDP + passive ADV + GATT service enumeration only")
