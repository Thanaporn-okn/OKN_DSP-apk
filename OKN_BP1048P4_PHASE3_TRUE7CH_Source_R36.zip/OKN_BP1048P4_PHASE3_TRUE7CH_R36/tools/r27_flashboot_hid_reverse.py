#!/usr/bin/env python3
"""R27 offline reverse verifier for BP1048P4 reference flashboot HID updater path.

OFFLINE ONLY. This tool reconstructs and inspects the SDK flashboot image from
flash_boot.c. It has no USB/device access and cannot send an updater command.
"""
from __future__ import annotations
import argparse, hashlib, json, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))
from r26_flashboot_offline_inspect import reconstruct  # type: ignore
from nds32lite import decode_one, disasm  # type: ignore

REF_SHA = "cd0e4e03f7072abd48fea2aeb5a54d9360b65acb1bd4d1b37734438cbe5f47c6"

# Exact instruction semantics recovered from the reference image.
CHECKS = [
    (0x2BAC, "bnec", "r2,#33", "HID Output: bmRequestType 0x21"),
    (0x2BB4, "bnec", "r0,#9", "HID Output: bRequest SET_REPORT 0x09"),
    (0x2BC2, "bnec", "r0,#2", "HID Output: report type 0x02"),
    (0x4C12, "bnec", "r1,#161", "HID Input: bmRequestType 0xA1"),
    (0x4C1A, "bnec", "r1,#1", "HID Input: bRequest GET_REPORT 0x01"),
    (0x4C22, "bnec", "r1,#1", "HID Input: report type 0x01"),
    (0x4C2A, "bnec", "r7,#1", "HID Input: wLength high byte 1 => 256 bytes"),
    (0x577A, "bnec", "r0,#111", "upinfo expects status byte 'o' (0x6F)"),
    (0x5782, "bnec", "r0,#107", "upinfo expects status byte 'k' (0x6B)"),
]

HANDLERS = {
    "cxxx": (0x4C8A, 0x50B2),
    "chiperas": (0x50B2, 0x517C),
    "bootdat": (0x517C, 0x52D4),
    "codedata": (0x52D4, 0x5406),
    "constdat": (0x5406, 0x550A),
    "cnfgdat": (0x550A, 0x560E),
    "btupdat": (0x560E, 0x575E),
    "upinfo": (0x575E, 0x57BE),
}

STATE_CALLS = {0x90F4, 0x918C, 0x9140, 0x9F58}
FLASH_CALLS = {0x44F0, 0x45EE}


def calls_in(buf: bytes, start: int, end: int) -> list[int]:
    out=[]
    for ins in disasm(buf, start, end):
        if ins.mnem == "jal" and ins.target is not None:
            out.append(ins.target)
    return out


def check_instruction(buf: bytes, pc: int, mnem: str, op_fragment: str):
    ins=decode_one(buf,pc)
    if ins is None:
        raise SystemExit(f"R27 FAIL no instruction @0x{pc:04X}")
    if ins.mnem != mnem or op_fragment not in ins.ops:
        raise SystemExit(
            f"R27 FAIL instruction mismatch @0x{pc:04X}: got {ins.mnem} {ins.ops}; "
            f"expected {mnem} containing {op_fragment}"
        )
    return str(ins)


def cstr(buf: bytes, off: int) -> str:
    end=buf.find(b"\0",off)
    if end < 0: end=len(buf)
    return buf[off:end].decode("ascii",errors="replace")


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("flash_boot_c", type=Path)
    ap.add_argument("--json", action="store_true")
    args=ap.parse_args()

    b=reconstruct(args.flash_boot_c)
    sha=hashlib.sha256(b).hexdigest()
    if sha != REF_SHA:
        raise SystemExit(f"R27 FAIL reference flashboot SHA changed: {sha}")

    decoded=[]
    for pc,mn,frag,note in CHECKS:
        decoded.append({"pc":pc,"instruction":check_instruction(b,pc,mn,frag),"meaning":note})

    # Updater data path: 4 x 64-byte control-OUT receives = 256 byte report.
    out_calls=[]
    for ins in disasm(b,0x2BCE,0x2C0C):
        if ins.mnem=="jal" and ins.target==0x9490:
            out_calls.append(ins.pc)
    if len(out_calls) != 4:
        raise SystemExit(f"R27 FAIL expected four 64-byte OUT receive calls, got {len(out_calls)}")

    # Input report response sends 256 bytes through the control-IN helper.
    got_send_256=False
    insns=list(disasm(b,0x4C2E,0x4C3A))
    for i,ins in enumerate(insns):
        if ins.mnem=="movi" and "r1,#256" in ins.ops:
            if any(x.mnem=="jal" and x.target==0x9436 for x in insns[i+1:]):
                got_send_256=True
    if not got_send_256:
        raise SystemExit("R27 FAIL 256-byte HID Input send path not recovered")

    # Verify command strings and recover direct call sets.
    cmd_offsets={
        "chiperas":0xCBE8,"upinfo":0xCBF4,"btupdat":0xCBFC,"cnfgdat":0xCC04,
        "constdat":0xCC0C,"codedata":0xCC18,"bootdat":0xCC24,"cxxx":0xCC2C,
    }
    for name,off in cmd_offsets.items():
        if cstr(b,off)!=name:
            raise SystemExit(f"R27 FAIL command string mismatch @0x{off:04X}")

    handlers={}
    for name,(start,end) in HANDLERS.items():
        calls=calls_in(b,start,end)
        handlers[name]={
            "start":start,"end":end,"direct_calls":[f"0x{x:04X}" for x in sorted(set(calls))],
            "calls_flash_erase_or_program":bool(set(calls)&FLASH_CALLS),
            "calls_state_or_mmio_mutator":bool(set(calls)&STATE_CALLS),
        }

    # Stronger semantic checks for upinfo.
    up_calls=set(calls_in(b,*HANDLERS["upinfo"]))
    for target in (0x90F4,0x918C,0x9140,0x9F58):
        if target not in up_calls:
            raise SystemExit(f"R27 FAIL upinfo expected call missing: 0x{target:04X}")

    # cxxx reaches finalize MMIO helpers in its successful/status branches.
    cx_calls=set(calls_in(b,*HANDLERS["cxxx"]))
    for target in (0x90F4,0x918C,0x9140):
        if target not in cx_calls:
            raise SystemExit(f"R27 FAIL cxxx expected state-mutating call missing: 0x{target:04X}")

    usbc=b.find(b"USBC")
    if usbc != 0xE00C:
        raise SystemExit(f"R27 FAIL unexpected USBC offset: {usbc:#x}")

    out={
        "revision":"R27",
        "mode":"OFFLINE_ONLY",
        "device_io":False,
        "reference_flashboot_size":len(b),
        "reference_flashboot_sha256":sha,
        "r26_transport_correction":{
            "previous_inference":"USB MSC BOT was treated as the updater command transport because USBC/CBW code is present.",
            "corrected_inference":"Updater command ingress/egress is USB HID class control SET_REPORT/GET_REPORT with 256-byte Data reports. MSC/BOT code is co-resident UDisk functionality and does not prove updater command carriage.",
            "usbc_offset":usbc,
        },
        "updater_transport":{
            "output_report":{
                "bmRequestType":"0x21",
                "bRequest":"0x09 SET_REPORT",
                "report_type":"0x02 Output",
                "report_id":0,
                "payload_bytes":256,
                "receive_shape":"4 x 64-byte control OUT receives",
            },
            "input_report":{
                "bmRequestType":"0xA1",
                "bRequest":"0x01 GET_REPORT",
                "report_type":"0x01 Input",
                "payload_bytes":256,
            },
            "feature_report_role":"8-byte Feature report belongs to pre-flashboot PC-upgrade arming/entry path; it is not the 256-byte flashboot command payload.",
        },
        "decoded_checks":decoded,
        "command_buffer":"ASCII command names are matched at the start of the 256-byte HID Data report via recovered strlen/memcmp helpers (0xADFC/0xACDC).",
        "handlers":handlers,
        "upinfo":{
            "safe_read":False,
            "semantics":"completion/finalization state command, not identity/version read",
            "requires_status_bytes":["0x6F ('o')","0x6B ('k')"],
            "success_calls":["0x90F4","0x918C","0x9140"],
            "error_call":"0x9F58",
            "side_effect":"MMIO read-modify-write at 0x40030004; error helper writes 1 to 0x40022008",
        },
        "cxxx":{
            "safe_read":False,
            "semantics":"upgrade metadata/CRC/offset validation and state/ACK command",
            "state_calls":["0x90F4","0x918C","0x9140"],
            "status_bytes_observed":["0xFF","0x33","0x55"],
            "side_effect":"writes updater state/status and can execute MMIO state transition helpers",
        },
        "proven_live_read_command":None,
        "live_probe_allowed":False,
        "live_probe_reason":"Neither upinfo nor cxxx is read-only; other updater commands directly erase/program/update. No proven safe identity/version command exists in this reference command set.",
        "hardware_actions_blocked":[
            "Feature 0x55/0xAA boot entry","USB updater command send","chip erase","boot/code/const/config program","bt update","cxxx","upinfo","commit/apply/reset",
        ],
    }

    if args.json:
        print(json.dumps(out,indent=2,ensure_ascii=False))
    else:
        print("R27 OFFLINE HID FLASHBOOT REVERSE")
        print(f"flashboot sha256={sha}")
        print("Updater transport: HID Data reports, 256-byte Output/GET Input; NOT proven BOT carriage")
        print("upinfo: BLOCK (state/MMIO changing)")
        print("cxxx: BLOCK (metadata/state/MMIO changing)")
        print("safe live read command: NONE")
        print("hardware probe: BLOCKED")

if __name__=="__main__":
    main()
