#!/usr/bin/env python3
from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
state=json.loads((root/'config/R30_RUNTIME_HID_READBACK_STATE.json').read_text())
risk=json.loads((root/'config/R30_RUNTIME_HID_READBACK_RISK.json').read_text())
ev=(root/'sdk_evidence/r30_runtime_hid/REFERENCE_SOURCE_EVIDENCE.txt').read_text()
usb=(root/'sdk_evidence/r23_reverse/otg_device_standard_request.c').read_text(errors='ignore')
app=(root/'sdk_evidence/r23_reverse/app_config.h').read_text(errors='ignore')
if state['revision']!='R30' or state['mode']!='OFFLINE_ONLY' or state['device_io'] is not False:
    raise SystemExit('R30 FAIL state')
if state['live_probe_allowed'] is not False or risk['hardware_action_allowed'] is not False:
    raise SystemExit('R30 FAIL live/hardware gate')
h=state['normal_runtime_hid']
if (h['usage_page'],h['usage'],h['input_report_bytes'],h['output_report_bytes'],h['feature_report_bytes'],h['audio_mic_hid_data_interface']) != ('0xFF00','0x55AA',256,256,8,4):
    raise SystemExit('R30 FAIL HID fingerprint')
if not state['control_0x00']['source_level_nonmutating'] or state['control_0x00']['live_probe_allowed']:
    raise SystemExit('R30 FAIL control00')
if not state['control_0x11']['dual_use'] or state['control_0x11']['live_probe_allowed']:
    raise SystemExit('R30 FAIL control11')
fc=state['communication_c_flash_calls']
if fc != {'SpiFlashRead':2,'SpiFlashErase':1,'SpiFlashWrite':1,'read_calls_are_only_inside_user_write_helper':True,'host_exposed_arbitrary_flash_read_proven':False}:
    raise SystemExit('R30 FAIL flash call classification')
for k in ('stock_backup_obtained','stock_full_flash_readback_path_proven','normal_runtime_arbitrary_flash_readback_proven','flashboot_arbitrary_flash_readback_proven','production_layout_proven','live_flash_action_allowed'):
    if state['recovery_assessment'][k] is not False:
        raise SystemExit('R30 FAIL recovery gate '+k)
for tok in ['Setup[3] == 0x02','Setup[0] == 0x21','hid_recive_data();','Setup[3] == 0x01','Setup[0] == 0xA1','hid_send_data();','HIDUsb_Rx(Request,256)','OTG_DeviceControlSend(hid_send,256,6)']:
    if tok not in usb: raise SystemExit('R30 FAIL missing USB source token '+tok)
if 'CFG_COMMUNICATION_BY_USB' not in app: raise SystemExit('R30 FAIL USB tuning config')
for tok in ['Usage Page: FF00','Usage: 55AA','Input report count: 0x0100 = 256 bytes','Output report count: 0x0100 = 256 bytes','Feature report count: 8 bytes','AUDIO_MIC configuration maps HID data to interface 4','No separate arbitrary flash-read-to-host branch was found']:
    if tok not in ev: raise SystemExit('R30 FAIL evidence '+tok)
# Android remains free of new USB transports.
scan=(root/'android-bt-probe/app/src/main/java/com/okn/dsp/btprobe/MainActivity.java').read_text()+'\n'+(root/'android-bt-probe/app/src/main/AndroidManifest.xml').read_text()
for tok in ['android.hardware.usb','UsbManager','controlTransfer(','bulkTransfer(']:
    if tok in scan: raise SystemExit('R30 FAIL Android USB token '+tok)
print('R30 offline/runtime-HID/readback guard: PASS')
print('- SDK HID fingerprint correlates with observed IF4 FF00/55AA 256/256/8')
print('- normal tuning frame A5 5A control len payload 16 documented')
print('- control 0x11 flash reads are only inside erase/write/verify helper')
print('- arbitrary flash readback/stock backup remains NOT proven')
print('- live ACP/Feature/flash experiments remain BLOCKED')
