#!/usr/bin/env python3
import ast, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=json.loads((ROOT/'config/R33_FLASH_READBACK_GATE_STATE.json').read_text())
r=json.loads((ROOT/'config/R33_FLASH_READBACK_GATE_RISK.json').read_text())
assert s['revision']=='R33' and s['mode']=='OFFLINE_ONLY' and s['device_io'] is False
assert s['reference_internal_flash_read_primitive']=='0x0F9C'
assert s['internal_flash_read_caller_count']==19
assert s['hid_response_wrapper']=='0x4BF6' and s['hid_response_wrapper_caller_count']==14
assert s['all_hid_response_wrapper_callers_in_known_updater_handlers'] is True
assert s['hidden_hid_response_handler_found'] is False
assert s['separate_safe_arbitrary_flash_read_command_found'] is False
assert s['safe_stock_backup_path_found'] is False
assert s['production_flash_layout_proven'] is False
assert s['flash_gate']=='CLOSED' and s['hardware_action_authorized'] is False
joined=' '.join(r['blocked_actions']).lower()
for term in ['hardware probe','0x55/0xaa','0x00/0x11','.mva','obex put','erase','program','commit','apply','reset']:
    assert term in joined, term
# R33 executable analysis must stay offline/file-only.
tool=ROOT/'tools/r33_flash_readback_gate.py'
tree=ast.parse(tool.read_text())
imports=set()
for n in ast.walk(tree):
    if isinstance(n,ast.Import): imports.update(a.name.split('.')[0] for a in n.names)
    elif isinstance(n,ast.ImportFrom) and n.module: imports.add(n.module.split('.')[0])
for banned in {'ctypes','usb','serial','hid','hidapi','socket','requests','urllib','http','bluetooth','bleak','subprocess'}:
    assert banned not in imports, (banned,imports)
# Source checkpoint must not redistribute vendor executables/private keys.
for p in ROOT.rglob('*'):
    if not p.is_file(): continue
    low=p.name.lower()
    assert not low.endswith('.exe'), p
    assert 'private_okn_android_stable_debug_key' not in low, p
report=(ROOT/'docs/R33_FLASH_READBACK_GATE_OFFLINE_REVERSE_TH.md').read_text()
for marker in ['0x0F9C','14 จุดเท่านั้น','hidden ninth handler','FLASH_GATE=CLOSED','NOT PROVEN']:
    assert marker in report, marker
print('R33 offline flash-readback/recovery guard: PASS')
