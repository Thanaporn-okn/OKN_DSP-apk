นำ `firmware/include/okn_gain7.h`, `okn_ufe_gain7.h`, `okn_r36_sdk_bridge.h` และ source คู่กันเข้า BT_Audio_APP ของ SDK ที่ commit ใน SDK_PIN.txt

Target linker flags สำหรับ experimental TRUE7CH integration:
`-Wl,--wrap=AudioI2S0_DataSet -Wl,--wrap=AudioI2S1_DataSet`

Define เพิ่มเมื่อ compile bridge กับ SDK จริง:
`-DOKN_R36_VENDOR_SDK=1`

อย่าเปิด erase/program อัตโนมัติใน CI. CI มีหน้าที่ build `.adx/.bin` และตรวจ section/hash เท่านั้น.
