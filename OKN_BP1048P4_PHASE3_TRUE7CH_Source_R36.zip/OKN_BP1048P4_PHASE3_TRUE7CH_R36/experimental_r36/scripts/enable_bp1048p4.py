#!/usr/bin/env python3
from pathlib import Path
import argparse, re, subprocess
PIN='8105bd864b04995d81c9f9ae77cb158259f39015'

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('sdk_root', type=Path)
    a=ap.parse_args()
    root=a.sdk_root.resolve()
    try:
        head=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()
    except Exception as e:
        raise SystemExit(f'cannot verify SDK git commit: {e}')
    if head != PIN:
        raise SystemExit(f'REFUSE: SDK HEAD {head} != pinned {PIN}')
    p=root/'BT_Audio_APP/bt_audio_app_src/inc/app_config.h'
    s=p.read_text(encoding='utf-8',errors='strict')
    if '#define  CFG_CHIP_BP10128' not in s:
        raise SystemExit('REFUSE: expected BP10128 default line not found')
    if '//#define  CFG_CHIP_BP1048P4' not in s:
        raise SystemExit('REFUSE: expected BP1048P4 option not found')
    s=s.replace('#define  CFG_CHIP_BP10128      //128pin,开发板上用', '//#define  CFG_CHIP_BP10128      // R36: disabled; keep original reference')
    s=s.replace('//#define  CFG_CHIP_BP1048P4       //48pin,专业版本型号，主频最高:320Mhz,内置flash容量:32Mbit', '#define  CFG_CHIP_BP1048P4       // R36 sacrificial target: 48pin/320MHz/32Mbit')
    active=re.findall(r'^\s*#define\s+CFG_CHIP_[A-Za-z0-9_]+',s,re.M)
    if active != ['#define  CFG_CHIP_BP1048P4'] and not (len(active)==1 and 'CFG_CHIP_BP1048P4' in active[0]):
        raise SystemExit(f'REFUSE: expected exactly one active CFG_CHIP, got {active}')
    p.write_text(s,encoding='utf-8')
    print('R36 P4 overlay: PASS')
if __name__=='__main__': main()
