#!/usr/bin/env python3
from pathlib import Path
import argparse, hashlib
PIN_FILES={
'BT_Audio_APP/bt_audio_app_src/inc/audio_core_api.h':'df64d8f52cbad72cea9a729f1d9633e88840e1fe',
'MVsB1_Base_SDK/driver/driver_api/inc/i2s_interface.h':'670610f5249ef25c1303fd8b173fca376990e3d8',
'BT_Audio_APP/bt_audio_app_src/audio/audio_vol.c':'1c44f16417a94f8e6e42b8c98f71577f61a3ec82',
'BT_Audio_APP/nds32-ae210p.ld':'0ce6fd3e6c50d699c92400f2e9f338e05d9b7c18',
}
def git_blob_sha1(data:bytes)->str:
    return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('sdk_root',type=Path); a=ap.parse_args()
    for rel,want in PIN_FILES.items():
        p=a.sdk_root/rel; got=git_blob_sha1(p.read_bytes())
        if got!=want: raise SystemExit(f'REFUSE {rel}: blob {got} != {want}')
        print(f'PASS {rel} {got}')
if __name__=='__main__': main()
