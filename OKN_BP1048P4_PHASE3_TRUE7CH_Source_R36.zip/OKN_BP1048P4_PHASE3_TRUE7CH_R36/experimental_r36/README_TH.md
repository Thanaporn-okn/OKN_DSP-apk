# R36 Experimental BP1048P4 firmware bridge

รอบนี้เปลี่ยนจากรอ factory firmware เป็น clean-room experimental firmware สำหรับ **บอร์ดทดลองที่ยอม brick ได้เท่านั้น** และต้องเก็บบอร์ด stock อย่างน้อย 1 ตัวไว้ไม่แตะต้อง

สิ่งที่ผูกกับ public SDK จริงแล้ว:
- BP1048P4 มีตัวเลือก `CFG_CHIP_BP1048P4` (48 pin / 320 MHz max / 32 Mbit internal flash)
- Andes toolchain: NDS32 `d1088-spu`, medium code model, DSP extensions
- SDK digital sink gain ใช้ 4095 = 0 dB; setter รองรับค่าบวกที่ระดับประมาณ +6 dB
- DAC0 stereo sink ใช้ CH1=L / CH2=R
- CH3 -> DACX L/R เป็น **experimental mapping** สำหรับ sacrificial board
- I2S0 DataSet: Len คือ stereo frame count; 16-bit = Len*4 bytes
- I2S1 DataSet: Len คือ stereo frame count; 16-bit = Len*4 bytes
- CH4/5 และ CH6/7 ใช้ linker wrapping + scratch buffer จึงไม่แก้ shared source PCM และไม่แตะ EQ

ข้อจำกัดที่ยังจริง:
- ยังไม่ได้ link/produce target `.bin` ใน local container เพราะไม่มี full Andes toolchain + vendor SDK libraries ติดตั้งใน runtime นี้
- ยังไม่มีคำสั่ง flash ที่ยืนยันกับ GoloPine production bootloader
- wrapper จะปรับ I2S เฉพาะเมื่อ runtime word length = 16-bit; format อื่น passthrough
- R36 source จึงเป็น target-integration checkpoint ไม่ใช่คำสั่งให้แฟลชบอร์ดหลัก
