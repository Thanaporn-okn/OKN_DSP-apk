#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
BIN="${TMPDIR:-/tmp}/okn_r29_test_gain7_$$"
trap 'rm -f "$BIN"' EXIT

cc -std=c11 -Wall -Wextra -Werror -pedantic \
  -I"$ROOT/firmware/include" \
  "$ROOT/firmware/src/okn_gain7.c" \
  "$ROOT/firmware/src/okn_ufe_gain7.c" \
  "$ROOT/tests/test_gain7.c" -o "$BIN"
"$BIN"
python3 "$ROOT/tools/check_no_eq_gain.py"
python3 "$ROOT/tools/test_mva_inspect.py"
python3 "$ROOT/tools/reverse_r25_sdk_evidence.py"
python3 "$ROOT/tools/check_r25_readonly.py"
python3 "$ROOT/tools/r26_flashboot_offline_inspect.py" "$ROOT/sdk_evidence/r23_reverse/flash_boot.c" --json >/dev/null
python3 "$ROOT/tools/check_r26_offline_guard.py"
python3 "$ROOT/tools/r27_flashboot_hid_reverse.py" "$ROOT/sdk_evidence/r23_reverse/flash_boot.c" --json >/dev/null
python3 "$ROOT/tools/check_r27_offline_guard.py"

python3 "$ROOT/tools/r28_mva_recovery_offline.py" "$ROOT/sdk_evidence/r23_reverse/flash_boot.c" --usb-request-c "$ROOT/sdk_evidence/r23_reverse/otg_device_standard_request.c" --upgrade-c "$ROOT/sdk_evidence/r23_reverse/upgrade.c" --flash-config-h "$ROOT/sdk_evidence/r23_reverse/flash_config.h" --json >/dev/null
python3 "$ROOT/tools/test_r28_mva_inspect.py"
python3 "$ROOT/tools/check_r28_offline_guard.py"

python3 "$ROOT/tools/r29_helper_readback_offline.py" "$ROOT/sdk_evidence/r23_reverse/flash_boot.c" --bt-obex-upgrade-c "$ROOT/sdk_evidence/r25_current_sdk/bt_obex_upgrade.c" --usb-request-c "$ROOT/sdk_evidence/r23_reverse/otg_device_standard_request.c" --upgrade-c "$ROOT/sdk_evidence/r23_reverse/upgrade.c" --json >/dev/null
python3 "$ROOT/tools/check_r29_offline_guard.py"

python3 "$ROOT/tools/check_r30_offline_guard.py"
python3 "$ROOT/tools/check_r31_offline_guard.py"
python3 "$ROOT/tools/check_r32_offline_guard.py"

python3 "$ROOT/tools/r33_flash_readback_gate.py" "$ROOT/sdk_evidence/r23_reverse/flash_boot.c" --flash-config-h "$ROOT/sdk_evidence/r23_reverse/flash_config.h" --json >/dev/null
python3 "$ROOT/tools/check_r33_offline_guard.py"

python3 "$ROOT/tools/check_r34_offline_guard.py"
python3 "$ROOT/tools/check_r35_offline_guard.py"

BIN36="${TMPDIR:-/tmp}/okn_r36_bridge_$$"
cc -std=c11 -Wall -Wextra -Werror -pedantic \
  -I"$ROOT/firmware/include" \
  "$ROOT/firmware/src/okn_gain7.c" \
  "$ROOT/firmware/src/okn_ufe_gain7.c" \
  "$ROOT/firmware/src/okn_r36_sdk_bridge.c" \
  "$ROOT/tests/test_r36_bridge.c" -o "$BIN36"
"$BIN36"
rm -f "$BIN36"
python3 "$ROOT/tools/check_r36_experimental_guard.py"

echo "R36 host/safety tests: PASS"
