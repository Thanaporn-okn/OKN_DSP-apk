#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "okn_r36_sdk_bridge.h"

static void f32le(uint8_t *p,float f){uint32_t u;memcpy(&u,&f,4);p[0]=(uint8_t)u;p[1]=(uint8_t)(u>>8);p[2]=(uint8_t)(u>>16);p[3]=(uint8_t)(u>>24);}
static void set_ch(uint8_t id, float db){uint8_t p[13]={0x57,0,0,0,id,0,0,0,4,0,0,0,0};f32le(p+9,db);assert(okn_r36_ufe_write_apply(p,sizeof(p)));}

int main(void)
{
    okn_r36_init();
    assert(okn_r36_gain_q12(0)==4095u);
    set_ch(22,-6.0f);
    assert(okn_r36_gain_q12(0) >= 2040u && okn_r36_gain_q12(0) <= 2060u);
    set_ch(22,6.0f);
    assert(okn_r36_gain_q12(0) >= 8160u && okn_r36_gain_q12(0) <= 8191u);

    okn_r36_init();
    set_ch(25,-6.0f); /* CH4 only */
    set_ch(26,0.0f);  /* CH5 */
    int16_t src[8]={10000,10000,12000,12000,-10000,-10000,-12000,-12000};
    int16_t dst[8]={0};
    okn_r36_process_i2s16_copy(3,src,dst,4);
    assert(dst[0]>4900 && dst[0]<5120 && dst[1]==10000);
    assert(dst[2]>5900 && dst[2]<6150 && dst[3]==12000);
    assert(dst[4]<-4900 && dst[4]>-5120 && dst[5]==-10000);
    assert(src[0]==10000 && src[1]==10000); /* wrapper path must preserve shared source buffer */

    uint8_t rr[9]={0x58,0,0,0,25,0,0,0,4}, out[13];
    assert(okn_r36_ufe_read(rr,sizeof(rr),out,sizeof(out))==13u && out[0]==0x60 && out[4]==25);
    puts("R36 SDK bridge host tests: PASS");
    return 0;
}
