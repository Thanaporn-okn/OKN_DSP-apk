# OKN BP1048P4 TRUE7CH — R36 Experimental Firmware

R36 เริ่ม clean-room firmware สำหรับ **sacrificial board เท่านั้น** หลังผู้ขายไม่ให้ factory firmware. จุดใหม่หลักคือ SDK-bound gain bridge: DAC0 CH1/CH2, experimental DACX CH3, I2S0 CH4/CH5, I2S1 CH6/CH7; IDs 22..28 และไม่ใช้ EQ ทำ volume. ดู `docs/R36_EXPERIMENTAL_FIRMWARE_TH.md` และ workflow `.github/workflows/R36_ANDES_TARGET_COMPILE.yml`.

---

# OKN BP1048P4 Phase3 TRUE7CH — R35

R31 เป็นรอบ **offline Windows PC tuning tool/runtime HID + readback reverse** ต่อจาก R30 โดยไม่ทำ hardware probe ใหม่.

ไฟล์ใหม่หลัก:
- `docs/R31_WINDOWS_RUNTIME_READBACK_OFFLINE_REVERSE_TH.md`
- `docs/R31_WINDOWS_RUNTIME_READBACK_EVIDENCE.txt`
- `config/R31_WINDOWS_RUNTIME_READBACK_STATE.json`
- `config/R31_WINDOWS_RUNTIME_READBACK_RISK.json`
- `windows/r31/` — derived metadata/IL/static evidence
- `tools/dotnet_meta.py`
- `tools/il_disasm.py`
- `tools/r31_windows_runtime_offline.py`
- `tools/check_r31_offline_guard.py`

ผล R31:
1. ยืนยันจาก EXE ตัวจริงว่ามี native HID wrappers: GetInputReport/ReadFile และ SetOutputReport/SetFeature/WriteFile.
2. ยืนยัน UFE constants 0x57/58/59/60/61/62/63/64/82 จาก .NET Constant table โดยตรง.
3. read/query ที่พบเป็น sensor/actuator/device-description level; ยังไม่พบ arbitrary flash read-to-host.
4. static search ไม่พบ direct backup/dump/upload/export/readflash/flashread candidate.
5. frame A5 5A ... 16 ยังเป็นหลักฐานฝั่ง reference firmware จาก R30; R31 ไม่พบ direct Windows-side builder ที่เปิดเผยพอจะพิสูจน์เพิ่ม และไม่เดา packet.
6. **stock backup/readback ยังไม่พิสูจน์, production layout ยังไม่พิสูจน์, flash gate CLOSED.**

R31 ไม่มี executable Windows vendor binary และไม่มี private Android signing key ใน source ZIP; เก็บเฉพาะ derived evidence และ offline tools.

## R32 — protected Windows response path
R32 กู้ protected Windows 2026 runtime stream ได้ครบ 1,823 records และเปิด hidden UFE response dispatcher แล้ว พบว่า response 0x60/0x62/0x64 ถูก parse เข้าสู่ Sensor/Actuator/FIFO object model และ 0x82 เป็น bulk continuation; ไม่พบ arbitrary flash-read/backup primitive. `FLASH_GATE` ยังคง `CLOSED`. ดู `docs/R32_PROTECTED_UFE_RESPONSE_OFFLINE_REVERSE_TH.md`.

## R33 — flash readback / recovery gate
R33 ระบุ internal flash-read primitive ของ reference flashboot ที่ `0x0F9C` และไล่ host HID response surface ทั้ง image พบ call `0x4BF6` 14 จุดทั้งหมดอยู่ใน 8 updater handlers เดิม ไม่มี hidden read/dump handler และไม่พบ arbitrary flash bytes ถูกส่งกลับ host. Reference layout ถูกยืนยันซ้ำจากค่าที่ฝังใน compiled header แต่ production layout ยังไม่พิสูจน์ ดังนั้น `FLASH_GATE=CLOSED`. ดู `docs/R33_FLASH_READBACK_GATE_OFFLINE_REVERSE_TH.md`.

## R34
เพิ่ม offline comparison ของ vendor Windows client 27Nov2025 กับ 2026-04-08 เพื่อปิดสมมติฐานว่า client รุ่นเก่ามี hidden stock-backup/flash-read path เพิ่ม ผล: native HID surface และ UFE command family ตรงกัน, vendor dataset ไม่มี production firmware/recovery image และ `FLASH_GATE` ยัง `CLOSED`.


## R35 — production recovery artifact search
R35 ปิด public-download search สำหรับ GoloPine/DSTech 7CH BP1048P4: official site เปิดเผยเฉพาะ tuning apps/clients + manuals/videos และการค้นสาธารณะ/ชุดไฟล์ผู้ใช้ยังไม่พบ factory/recovery image หรือ production linker/map ที่ตรงบอร์ด. เพิ่มข้อความ TH/EN/ZH สำหรับขอ factory/recovery package จากผู้ขายโดยตรง. `FLASH_GATE=CLOSED` และไม่มี hardware I/O. ดู `docs/R35_PRODUCTION_RECOVERY_ARTIFACT_SEARCH_TH.md`.
