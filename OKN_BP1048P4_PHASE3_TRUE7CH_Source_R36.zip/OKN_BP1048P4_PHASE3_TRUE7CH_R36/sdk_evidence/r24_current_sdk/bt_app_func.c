///////////////////////////////////////////////////////////////////////////////
//               Mountain View Silicon Tech. Inc.
//  Copyright 2012, Mountain View Silicon Tech. Inc., Shanghai, China
//                       All rights reserved.
//  Filename: bt_app_func.c
//  maintainer: Halley
///////////////////////////////////////////////////////////////////////////////

#include "type.h"
#include "delay.h"
#include "debug.h"

#include "chip_info.h"

#include "bt_stack_api.h"
#include "bt_config.h"
#include "bt_app_interface.h"
#include "bt_manager.h"
#include "bt_app_func.h"
#include "bt_platform_interface.h"
#include "bt_ddb_flash.h"
#ifdef CFG_APP_CONFIG
#include "app_config.h"
#endif

#include "bt_a2dp_api.h"
#include "bt_avrcp_api.h"
#include "bt_obex_api.h"

#include "bt_config.h"
#include "bb_api.h"

#include "rtos_api.h"

#ifdef CFG_FUNC_AI_EN
#include "ai.h"
#endif

extern BT_CONFIGURATION_PARAMS		*btStackConfigParams;

extern uint8_t CheckMatch(uint8_t *bdAddr);

/***********************************************************************************
 * 
 **********************************************************************************/
/**
 * @brief	Get Bt Address
 * @param	device Address
 * 			mode: 1=from efuse  0=default
 * @return	
 */
extern uint8_t Efuse_ReadData(uint8_t Addr);
static bool GetBtDefaultAddr(uint8_t *devAddr)
{
	uint8_t i;
	uint32_t sum=0;
	uint32_t random_mac = 0;

	if(devAddr == NULL)
		return FALSE;

	//1.frome efuse 2-6 and sum
	{
		for(i=0;i<5;i++)
		{
			*(devAddr+i) = Efuse_ReadData(2+i);
			sum += *(devAddr+i);
		}
		*(devAddr+5) = (uint8_t)(sum&0x000000ff);

		if((*devAddr == 0)&&(*(devAddr+1) == 0)&&(*(devAddr+2) == 0)&&(*(devAddr+3) == 0)&&(*(devAddr+4) == 0))
		{
			DBG("efuse is null\n");
			//2.generate a random address
			{
				//uint8_t addr[6] = BT_ADDRESS;
				random_mac = Chip_RandomSeedGet();
				*(devAddr+2) = (uint8_t)(random_mac&0xff);
				*(devAddr+3) = (uint8_t)((random_mac>>8)&0xff);
				*(devAddr+4) = (uint8_t)((random_mac>>16)&0xff);
				*(devAddr+5) = (uint8_t)((random_mac>>24)&0xff);
			}
		}
	}

	CheckMatch(devAddr);
	
	return TRUE;
}

/***********************************************************************************
 * 
 **********************************************************************************/
uint32_t GetSupportProfiles(void)
{
	uint32_t		profiles = 0;

	
#if BT_HFP_SUPPORT == ENABLE
	profiles |= BT_PROFILE_SUPPORTED_HFP;
#endif

#if BT_A2DP_SUPPORT == ENABLE
	profiles |= BT_PROFILE_SUPPORTED_A2DP;
#endif

#if BT_AVRCP_SUPPORT == ENABLE
	profiles |= BT_PROFILE_SUPPORTED_AVRCP;
#endif

#if BT_SPP_SUPPORT == ENABLE
	profiles |= BT_PROFILE_SUPPORTED_SPP;
#endif
	
#if BT_HID_SUPPORT == ENABLE
	profiles |= BT_PROFILE_SUPPORTED_HID;
#endif
	
#if BT_MFI_SUPPORT == ENABLE
	profiles |= BT_PROFILE_SUPPORTED_MFI;
#endif
	
#if BT_OBEX_SUPPORT == ENABLE
	profiles |= BT_PROFILE_SUPPORTED_OBEX;
#endif

#if BT_PBAP_SUPPORT == ENABLE
	profiles |= BT_PROFILE_SUPPORTED_PBAP;
#endif
	return profiles;
}

/***********************************************************************************
 * 
 **********************************************************************************/
void prinfBtConfigParams(void)
{
	uint8_t i;
	DBG("**********\nLocal Device Infor:\n");

	//bluetooth name and address
	DBG("Bt Name:%s\n", btStackConfigParams->bt_LocalDeviceName);
	DBG("FlashBtAddress(NAP-UAP-LAP):");
	for(i=0;i<5;i++)
	{
		DBG("%02x:", btStackConfigParams->bt_LocalDeviceAddr[i]);
	}
	DBG("%02x\n", btStackConfigParams->bt_LocalDeviceAddr[5]);
	
	DBG("SystemBtAddress(LAP-UAP-NAP):");
	for(i=0;i<5;i++)
	{
		DBG("%02x:", btManager.btDevAddr[i]);
	}
	DBG("%02x\n", btManager.btDevAddr[5]);
	
	//ble address
	DBG("BleAddress:");
	for(i=0;i<5;i++)
	{
		DBG("%02x:", btStackConfigParams->ble_LocalDeviceAddr[i]);
	}
	DBG("%02x\n", btStackConfigParams->ble_LocalDeviceAddr[5]);

	DBG("Freq trim:0x%x\n", btStackConfigParams->bt_trimValue);
	DBG("**********\n");
}


/***********************************************************************************
 * ��flash��Load�������ò���
 **********************************************************************************/
static int8_t CheckBtAddr(uint8_t* addr)
{
	if(((addr[0]==0x00)&&(addr[1]==0x00)&&(addr[2]==0x00)&&(addr[3]==0x00)&&(addr[4]==0x00)&&(addr[5]==0x00))
			|| ((addr[0]==0xff)&&(addr[1]==0xff)&&(addr[2]==0xff)&&(addr[3]==0xff)&&(addr[4]==0xff)&&(addr[5]==0xff)))
	{
		//������ַ������Ԥ��
		BT_DBG("[DDB]:bt addr error\n");
		return -1;
	}
	else
	{
		return 0;
	}
}

static int8_t CheckBtName(uint8_t* nameString)
{
	if(((nameString[0]==0x00)&&(nameString[1]==0x00)&&(nameString[2]==0x00))
			|| ((nameString[0]==0xff)&&(nameString[1]==0xff)&&(nameString[2]==0xff)))
	{
		//�������Ʋ�����Ԥ��
		BT_DBG("[DDB]:bt name error\n");
		return -1;
	}
	else
	{
		return 0;
	}
}

static int8_t CheckBtParamHeader(uint8_t* header)
{
	if((header[0]=='M')&&(header[1]=='V')&&(header[2]=='B')&&(header[3]=='T'))
	{
		//��������header����Ԥ��
		return 0;
	}
	else
	{
		BT_DBG("[DDB]:header error\n");
		return -1;
	}
}

void LoadBtConfigurationParams(void)
{
	int8_t ret = 0;
	uint8_t paramsUpdate = 0;
	if(btStackConfigParams == NULL)
		return;

	ret = BtDdb_LoadBtConfigurationParams(btStackConfigParams);
	if(ret == -3)
	{
		//��ȡ�쳣��read again
		ret = BtDdb_LoadBtConfigurationParams(btStackConfigParams);
		if(ret == -3)
		{
			BT_DBG("bt database read error!\n");
			return;
		}
	}
	
	//BT
	ret = CheckBtAddr(btStackConfigParams->bt_LocalDeviceAddr);
	if(ret != 0)
	{
		paramsUpdate = 1;
		GetBtDefaultAddr(btStackConfigParams->bt_LocalDeviceAddr);
	}
	if(BT_MATCH_CHECK)
	{
		ret = CheckMatch(btStackConfigParams->bt_LocalDeviceAddr);
		if(ret != 0)
		{
			paramsUpdate = 1;
		}
	}
	
	//��ADDR���з������:btStackConfigParams->bt_LocalDeviceAddr(NAP-UAP-LAP)->btManager.btDevAddr(LAP-UAP-NAP)
	btManager.btDevAddr[5]=btStackConfigParams->bt_LocalDeviceAddr[0];
	btManager.btDevAddr[4]=btStackConfigParams->bt_LocalDeviceAddr[1];
	btManager.btDevAddr[3]=btStackConfigParams->bt_LocalDeviceAddr[2];
	btManager.btDevAddr[2]=btStackConfigParams->bt_LocalDeviceAddr[3];
	btManager.btDevAddr[1]=btStackConfigParams->bt_LocalDeviceAddr[4];
	btManager.btDevAddr[0]=btStackConfigParams->bt_LocalDeviceAddr[5];
	
	//BLE
	ret = CheckBtAddr(btStackConfigParams->ble_LocalDeviceAddr);
	if(ret != 0)
	{
		paramsUpdate = 1;
		
		//ble address
		//ble name:ͨ������BLE�㲥��Ϣ������(ble_app_func.c)
		memcpy(btStackConfigParams->ble_LocalDeviceAddr, btStackConfigParams->bt_LocalDeviceAddr,6);
		btStackConfigParams->ble_LocalDeviceAddr[0] = btStackConfigParams->ble_LocalDeviceAddr[0]|0xc0;
		btStackConfigParams->ble_LocalDeviceAddr[4] += 0x60;
	}
#ifdef	CFG_XIAOAI_AI_EN
	//С��Ҫ��ͬ��ַ
	{
#if 0
		int i = 0;
		for(i=0;i < 6;i++)
		{
			btStackConfigParams->ble_LocalDeviceAddr[i] = btStackConfigParams->bt_LocalDeviceAddr[5 - i];
		}
#else
		memcpy(btStackConfigParams->ble_LocalDeviceAddr, btStackConfigParams->bt_LocalDeviceAddr, 6);
#endif
	}

#endif

#if 0
	//BT name �������ư���BT_NAME
	strcpy((void *)btStackConfigParams->bt_LocalDeviceName, BT_NAME);
#else
	//BT name �������ƴ�flash�л�ȡ
	ret = CheckBtName(btStackConfigParams->bt_LocalDeviceName);
	if(ret != 0)
	{
		paramsUpdate = 1;
		strcpy((void *)btStackConfigParams->bt_LocalDeviceName, BT_NAME);
	}
#endif

#ifdef	CFG_XIAOAI_AI_EN
	strcpy((void *)btStackConfigParams->bt_LocalDeviceName, BT_NAME);
#endif
#ifdef	CFG_FUNC_AI_EN
	strcpy((void *)btStackConfigParams->bt_LocalDeviceName, BT_NAME);
#endif
	//BLE name �������ƴ�flash�л�ȡ
	ret = CheckBtName(btStackConfigParams->ble_LocalDeviceName);
	if(ret != 0)
	{
		paramsUpdate = 1;
		strcpy((void *)btStackConfigParams->ble_LocalDeviceName, BT_NAME);
	}
#ifdef	CFG_XIAOAI_AI_EN
	strcpy((void *)btStackConfigParams->ble_LocalDeviceName, BT_NAME);
#endif
#ifdef	CFG_FUNC_AI_EN
	strcpy((void *)btStackConfigParams->ble_LocalDeviceName, BT_NAME);
#endif
	//BT PARAMS
	ret = CheckBtParamHeader(btStackConfigParams->bt_ConfigHeader);
	if(ret != 0)
	{
		paramsUpdate = 1;
		
		btStackConfigParams->bt_ConfigHeader[0]='M';
		btStackConfigParams->bt_ConfigHeader[1]='V';
		btStackConfigParams->bt_ConfigHeader[2]='B';
		btStackConfigParams->bt_ConfigHeader[3]='T';
		
		//note:��ʹ��Ĭ�ϲ���ʱ��trimValueһ������Ϊ0xff������ᵼ��bb������������
		btStackConfigParams->bt_trimValue = BT_TRIM;

	#if 0
		btStackConfigParams->bt_TxPowerValue = BT_TX_POWER_LEVEL;
		
		btStackConfigParams->bt_SupportProfile = GetSupportProfiles();
		
		//simple Pairing enable
		//��simplePairing=1ʱ,pinCode��Ч;��֮��Ȼ
		btStackConfigParams->bt_simplePairingFunc = 1;
		strcpy((char*)btStackConfigParams->bt_pinCode,BT_PINCODE);
		
		//inquiry scan params
		btStackConfigParams->bt_InquiryScanInterval = BT_INQUIRYSCAN_INTERVAL;
		btStackConfigParams->bt_InquiryScanWindow = BT_INQUIRYSCAN_WINDOW;
		
		//page scan params
		btStackConfigParams->bt_PageScanInterval = BT_PAGESCAN_INTERVAL;
		btStackConfigParams->bt_PageScanWindow = BT_PAGESCAN_WINDOW;
	#endif
	}
	{
		//����Ƶƫֵ����flash�����ݣ����������ָ���bt_config.hĬ�ϲ���
		btStackConfigParams->bt_TxPowerValue = BT_TX_POWER_LEVEL;
		
		btStackConfigParams->bt_SupportProfile = GetSupportProfiles();
		
		//simple Pairing enable
		//��simplePairing=1ʱ,pinCode��Ч;��֮��Ȼ
		btStackConfigParams->bt_simplePairingFunc = BT_SIMPLEPAIRING_FLAG;
		btStackConfigParams->bt_pinCodeLen = BT_PINCODE_LEN;
		strcpy((char*)btStackConfigParams->bt_pinCode,BT_PINCODE);
		
		//inquiry scan params
		btStackConfigParams->bt_InquiryScanInterval = BT_INQUIRYSCAN_INTERVAL;
		btStackConfigParams->bt_InquiryScanWindow = BT_INQUIRYSCAN_WINDOW;
		
		//page scan params
		btStackConfigParams->bt_PageScanInterval = BT_PAGESCAN_INTERVAL;
		btStackConfigParams->bt_PageScanWindow = BT_PAGESCAN_WINDOW;
	}

	if(paramsUpdate)
	{
		BT_DBG("[DDB]:save bt params to flash\n");
		//����Ĭ�ϵ����ò�����flash����������bt_ConfigHeader��bt_trimValue
		BtDdb_InitBtConfigurationParams(btStackConfigParams);
	}
	
	#ifdef CFG_FUNC_AI_EN
	//ai_ble_set((char*)btStackConfigParams->bt_LocalDeviceName,btStackConfigParams->bt_LocalDeviceAddr,btStackConfigParams->bt_LocalDeviceAddr);
	ai_ble_set((char*)btStackConfigParams->bt_LocalDeviceName,btManager.btDevAddr,btManager.btDevAddr);
	#endif
	prinfBtConfigParams();

}

/***********************************************************************************
 * ����BB�Ĳ���
 **********************************************************************************/
void ConfigBtBbParams(BtBbParams *params)
{
	uint8_t pTxPower = BT_TX_POWER_LEVEL;
	uint8_t pPageTxPower = BT_PAGE_TX_POWER_LEVEL;
	if(params == NULL)
		return;

	memset(params, 0 ,sizeof(BtBbParams));

	params->localDevName = (uint8_t *)btStackConfigParams->bt_LocalDeviceName;

/*#ifdef	CFG_XIAOAI_AI_EN
	memcpy(params->localDevAddr, &btStackConfigParams->bt_LocalDeviceAddr[0], BT_ADDR_SIZE);
#else
	memcpy(params->localDevAddr, &lsAddr[0], BT_ADDR_SIZE);
#endif
*/
	memcpy(params->localDevAddr, btManager.btDevAddr, BT_ADDR_SIZE);

	params->freqTrim = btStackConfigParams->bt_trimValue;

	//em config
	params->em_start_addr = BB_EM_START_PARAMS; //0x40:20010000; 0x80:20020000; 0xc0:20030000 ;0x100: 0x20040000; 0x120:0x20048000

	//agc config
	params->pAgcDisable = 0; //0=auto agc;  1=close agc
	params->pAgcLevel = 1;

	//sniff config
	params->pSniffNego = 0;//1=open;  0=close
	params->pSniffDelay = 0;
	params->pSniffInterval = 0x320;//500ms
	params->pSniffAttempt = 0x01;
	params->pSniffTimeout = 0x01;

	params->bbSniffNotify = NULL;

	SetRfTxPwrMaxLevel(pTxPower, pPageTxPower);
}


/***********************************************************************************
 * ����HOST�Ĳ���
 **********************************************************************************/
void ConfigBtStackParams(BtStackParams *stackParams)
{
	uint32_t pCod = 0;
	if(stackParams == NULL)
		return ;

	memset(stackParams, 0 ,sizeof(BtStackParams));

	/* Set support profiles */
	stackParams->supportProfiles = GetSupportProfiles();

	/* Set local device name */
	stackParams->localDevName = (uint8_t *)btStackConfigParams->bt_LocalDeviceName;

	/* Set callback function */
	stackParams->callback = BtStackCallback;
	stackParams->scoCallback = NULL;//GetScoDataFromApp;

	//simple pairing
	stackParams->btSimplePairing = btStackConfigParams->bt_simplePairingFunc;
	if((btStackConfigParams->bt_pinCodeLen)&&(btStackConfigParams->bt_pinCodeLen<17))
	{
		stackParams->btPinCodeLen = btStackConfigParams->bt_pinCodeLen;
		memcpy(stackParams->btPinCode, btStackConfigParams->bt_pinCode, stackParams->btPinCodeLen);
	}
	else
	{
		BT_DBG("ERROR:pin code len %d\n", btStackConfigParams->bt_pinCodeLen);
		stackParams->btSimplePairing = 1;//�����������
	}

	//class of device
	//headset:ƻ���ֻ�����ʾ�豸�ĵ�ص���
	pCod = COD_AUDIO | COD_MAJOR_AUDIO | COD_MINOR_AUDIO_HEADSET | COD_RENDERING;
	//Note:ƻ���ֻ���BP10��HFPЭ��,����Ҫ��ͬ��ͨѶ¼�ĵ���,����Ҫ���豸��������Ϊhandsfree,��������ʾ��ص���
	//pCod = COD_AUDIO | COD_MAJOR_AUDIO | COD_MINOR_AUDIO_HANDSFREE | COD_RENDERING;

#if (BT_HID_SUPPORT == ENABLE)
	pCod |= (COD_MAJOR_PERIPHERAL | COD_MINOR_PERIPH_KEYBOARD);
#endif
	SetBtClassOfDevice(pCod);

#if BT_HFP_SUPPORT == ENABLE
	/* HFP features */
	stackParams->hfpFeatures.wbsSupport = BT_HFP_SUPPORT_WBS;
	stackParams->hfpFeatures.hfpAudioDataFormat = BT_HFP_AUDIO_DATA;
	stackParams->hfpFeatures.hfpAppCallback = BtHfpCallback;
#else
	stackParams->hfpFeatures.hfpAppCallback = NULL;
#endif
	
#if BT_A2DP_SUPPORT == ENABLE
	/* A2DP features */
	//stackParams->a2dpFeatures.a2dpAudioDataFormat = BT_A2DP_AUDIO_DATA;
#if (defined(BT_AUDIO_AAC_ENABLE) && defined(USE_AAC_DECODER))
	stackParams->a2dpFeatures.a2dpAudioDataFormat = (A2DP_AUDIO_DATA_SBC | A2DP_AUDIO_DATA_AAC);
#else
	stackParams->a2dpFeatures.a2dpAudioDataFormat = (A2DP_AUDIO_DATA_SBC);
#endif

	stackParams->a2dpFeatures.a2dpAppCallback = BtA2dpCallback;
#else
	stackParams->a2dpFeatures.a2dpAppCallback = NULL;
#endif
	
#if BT_AVRCP_SUPPORT == ENABLE
	/* AVRCP features */
	stackParams->avrcpFeatures.supportAdvanced = BT_AVRCP_ADVANCED;
#if ((BT_AVRCP_PLAYER_SETTING == ENABLE)||(BT_AVRCP_VOLUME_SYNC == ENABLE))
	stackParams->avrcpFeatures.supportTgSide = 1;
#else
	stackParams->avrcpFeatures.supportTgSide = 0;
#endif
	stackParams->avrcpFeatures.supportSongTrackInfo = BT_AVRCP_SONG_TRACK_INFOR;
	stackParams->avrcpFeatures.supportPlayStatusInfo = BT_AVRCP_SONG_PLAY_STATE;
	stackParams->avrcpFeatures.avrcpAppCallback = BtAvrcpCallback;
#else
	stackParams->avrcpFeatures.avrcpAppCallback = NULL;
#endif

#if BT_SPP_SUPPORT == ENABLE
	stackParams->SppAppFeatures.sppAppCallback = BtSppCallback;
	stackParams->SppAppFeatures.sppAppHook = BtSppHookFunc;
#else
	stackParams->SppAppFeatures.sppAppCallback = NULL;
#endif
	
#if BT_HID_SUPPORT == ENABLE
	stackParams->hidFeatures.hidAppCallback = BtHidCallback;
#else
	stackParams->hidFeatures.hidAppCallback = NULL;
#endif

#if BT_MFI_SUPPORT == ENABLE
	stackParams->mfiFeatures.mfiAppCallback = BtMfiCallback;
#else
	stackParams->mfiFeatures.mfiAppCallback = NULL;
#endif

#if BT_OBEX_SUPPORT == ENABLE
	ObexAppCallbackRegister(BtObexCallback);
#endif

#if BT_PBAP_SUPPORT == ENABLE
	PbapAppCallbackRegister(BtPbapCallback);
#endif
}

/***********************************************************************************
 * ��ʼ������HOST
 **********************************************************************************/
bool BtStackInit(void)
{
//	bool ret;
	int32_t retInit=0;

	BtStackParams	stackParams;

	memset(GetBtManager(), 0, sizeof(BT_MANAGER_ST));

	BTStatckSetPageTimeOutValue(BT_PAGE_TIMEOUT); 

	ConfigBtStackParams(&stackParams);

	retInit = BTStackRunInit(&stackParams);
	if(retInit != 0)
	{
		BT_DBG("Bt Stack Init ErrCode [%x]\n", (int)retInit);
		return FALSE;
	}

	return TRUE;
}

/***********************************************************************************
 * 
 **********************************************************************************/
void UninitBt(void)
{
	BTStackRunUninit();
}

bool BtStackUninit(void)
{
	int32_t ret=0;
	UninitBt();
	
	ret = BTStackMemFree();
	if(ret == -1)
	{
		return FALSE;
	}
	return TRUE;
}

/***********************************************************************************
 * 
 **********************************************************************************/
void BtStackRunNotify(void)
{
//	OSQueueMsgSend(MSG_NEED_BT_STACK_RUN, NULL, 0, MSGPRIO_LEVEL_HI, 0);
}


/***********************************************************************************
 * get device name (max 40bytes)
 **********************************************************************************/
uint8_t* BtDeviceNameGet(void)
{
	return &btStackConfigParams->bt_LocalDeviceName[0];
}
/***********************************************************************************
 * ���� �������Ƶ�flash
 **********************************************************************************/
int32_t BtDeviceNameSet(uint8_t* deviceName, uint8_t deviceLen)
{
	BT_CONFIGURATION_PARAMS		*btParams = NULL;
	int8_t ret=0;
	BT_DBG("device name set!\n");

	//1.����RAM
	btParams = (BT_CONFIGURATION_PARAMS*)osPortMalloc(sizeof(BT_CONFIGURATION_PARAMS));
	if(btParams == NULL)
	{
		BT_DBG("ERROR: Ram is not enough!\n");
		return -2;//RAM����
	}
	memcpy(btParams, btStackConfigParams, sizeof(BT_CONFIGURATION_PARAMS));
	
	//2.��pin code����
	memset(btStackConfigParams->bt_LocalDeviceName, 0, BT_NAME_SIZE);
	memset(btParams->bt_LocalDeviceName, 0, BT_NAME_SIZE);
	
	memcpy(btStackConfigParams->bt_LocalDeviceName, deviceName, deviceLen);
	memcpy(btParams->bt_LocalDeviceName, deviceName, deviceLen);

	//3.���������ݱ��浽flash
	BtDdb_SaveBtConfigurationParams(btParams);
	memset(btParams, 0, sizeof(BT_CONFIGURATION_PARAMS));

	//4.���´�flash�ж�ȡ���ݣ��ٴν��жԱ�
	ret = BtDdb_LoadBtConfigurationParams(btParams);
	if(ret == -3)
	{
		//��ȡ�쳣��read again
		ret = BtDdb_LoadBtConfigurationParams(btParams);
		if(ret == -3)
		{
			BT_DBG("bt database read error!\n");
			osPortFree(btParams);
			return -3;//��ȡʧ��
		}
	}

	ret = memcmp(btStackConfigParams, btParams,sizeof(BT_CONFIGURATION_PARAMS));
	if(ret == 0)
	{
		BT_DBG("save ok!\n");
		osPortFree(btParams);
		return 0;
	}
	else
	{
		BT_DBG("save NG!\n");
		osPortFree(btParams);
		return -4;//����ʧ��
	}

}

/***********************************************************************************
 * get device ble name (max 40bytes)
 **********************************************************************************/
uint8_t* BtDeviceBleNameGet(void)
{
	return &btStackConfigParams->ble_LocalDeviceName[0];
}
/***********************************************************************************
 * ���� ����BLE���Ƶ�flash
 **********************************************************************************/
int32_t BtDeviceBleNameSet(uint8_t* deviceName, uint8_t deviceLen)
{
	BT_CONFIGURATION_PARAMS		*btParams = NULL;
	int8_t ret=0;
	BT_DBG("device ble name set!\n");

	//1.����RAM
	btParams = (BT_CONFIGURATION_PARAMS*)osPortMalloc(sizeof(BT_CONFIGURATION_PARAMS));
	if(btParams == NULL)
	{
		BT_DBG("ERROR: Ram is not enough!\n");
		return -2;//RAM����
	}
	memcpy(btParams, btStackConfigParams, sizeof(BT_CONFIGURATION_PARAMS));
	
	//2.��pin code����
	memset(btStackConfigParams->ble_LocalDeviceName, 0, BT_NAME_SIZE);
	memset(btParams->ble_LocalDeviceName, 0, BT_NAME_SIZE);
	
	memcpy(btStackConfigParams->ble_LocalDeviceName, deviceName, deviceLen);
	memcpy(btParams->ble_LocalDeviceName, btStackConfigParams->ble_LocalDeviceName, deviceLen);

	//3.���������ݱ��浽flash
	BtDdb_SaveBtConfigurationParams(btParams);
	memset(btParams, 0, sizeof(BT_CONFIGURATION_PARAMS));

	//4.���´�flash�ж�ȡ���ݣ��ٴν��жԱ�
	ret = BtDdb_LoadBtConfigurationParams(btParams);
	if(ret == -3)
	{
		//��ȡ�쳣��read again
		ret = BtDdb_LoadBtConfigurationParams(btParams);
		if(ret == -3)
		{
			BT_DBG("bt database read error!\n");
			osPortFree(btParams);
			return -3;//��ȡʧ��
		}
	}

	ret = memcmp(btStackConfigParams, btParams,sizeof(BT_CONFIGURATION_PARAMS));
	if(ret == 0)
	{
		BT_DBG("save ok!\n");
		osPortFree(btParams);
		return 0;
	}
	else
	{
		BT_DBG("save NG!\n");
		osPortFree(btParams);
		return -4;//����ʧ��
	}

}

/***********************************************************************************
 * pin code get (4bytes)
 **********************************************************************************/
uint8_t* BtPinCodeGet(void)
{
	return btStackConfigParams->bt_pinCode;
}

/***********************************************************************************
 * save pin code to flash
 **********************************************************************************/
int32_t BtPinCodeSet(uint8_t *pinCode)
{
	BT_CONFIGURATION_PARAMS		*btParams = NULL;
	int8_t ret=0;
	BT_DBG("pin code set!\n");

	//1.�Ƿ����������
	if(btStackConfigParams->bt_simplePairingFunc)
		return -3;//ģʽ����

	//2.����RAM
	btParams = (BT_CONFIGURATION_PARAMS*)osPortMalloc(sizeof(BT_CONFIGURATION_PARAMS));
	if(btParams == NULL)
	{
		BT_DBG("ERROR: Ram is not enough!\n");
		return -2;//RAM����
	}
	memcpy(btParams, btStackConfigParams, sizeof(BT_CONFIGURATION_PARAMS));
	
	//3.��pin code����
	memcpy(btStackConfigParams->bt_pinCode, pinCode, 4);
	memcpy(btParams->bt_pinCode, pinCode, 4);

	//4.���������ݱ��浽flash
	BtDdb_SaveBtConfigurationParams(btParams);
	memset(btParams, 0, sizeof(BT_CONFIGURATION_PARAMS));

	//5.���´�flash�ж�ȡ���ݣ��ٴν��жԱ�
	ret = BtDdb_LoadBtConfigurationParams(btParams);
	if(ret == -3)
	{
		//��ȡ�쳣��read again
		ret = BtDdb_LoadBtConfigurationParams(btParams);
		if(ret == -3)
		{
			BT_DBG("bt database read error!\n");
			osPortFree(btParams);
			return -3;//��ȡʧ��
		}
	}

	ret = memcmp(btStackConfigParams, btParams,sizeof(BT_CONFIGURATION_PARAMS));
	if(ret == 0)
	{
		BT_DBG("save ok!\n");
		osPortFree(btParams);
		return 0;
	}
	else
	{
		BT_DBG("save NG!\n");
		osPortFree(btParams);
		return -4;//����ʧ��
	}
}

