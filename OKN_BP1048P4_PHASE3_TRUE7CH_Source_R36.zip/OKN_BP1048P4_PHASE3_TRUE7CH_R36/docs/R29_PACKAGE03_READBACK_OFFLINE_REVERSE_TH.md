# R29 — Package 03 / Flash Readback Offline Reverse

สถานะ: **OFFLINE ONLY / FAIL-CLOSED**  
ไม่มีการส่งคำสั่งไปบอร์ดจริง ไม่มี USB/Bluetooth/OBEX transport ใหม่ และไม่มี erase/program/commit/reset.

## เป้าหมาย R29

R28 พบว่า reference MVA maker ใส่ record ID `03` ที่มี payload 1,524 bytes: target offset LE32 4 bytes + helper blob 1,520 bytesจาก reference flashboot offset `0xCE74`. R29 จึงตรวจว่าบล็อกนี้เป็น readback/backup helper ที่เราสามารถใช้ดึง stock firmware กลับได้หรือไม่ และ cross-check ว่า SDK มี flash-read primitive ที่ host เรียกได้หรือไม่.

## 1. Package 03 helper fingerprint

Reference flashboot ยังคงตรง SHA256:
`cd0e4e03f7072abd48fea2aeb5a54d9360b65acb1bd4d1b37734438cbe5f47c6`

Helper blob:
- offset ใน reference flashboot: `0xCE74`
- length: `1,520` bytes
- SHA256: `db8f68feedf48671b863fbc3269cfa2dfce180f6a21a65fe6152cee239c43c12`
- entropy: `7.839943 bits/byte`
- distinct byte values: `255/256`
- zero bytes: `4`
- `0xFF`: `9`
- ไม่ขึ้นต้นด้วย magic ที่ตรวจไว้ เช่น ELF / MZ / gzip / ZIP / XZ / bzip2

ลักษณะนี้สนับสนุนว่า payload เป็น **opaque/high-entropy data**. แต่ R29 ยังไม่มีหลักฐานพอที่จะเรียกมันว่า encrypted หรือ compressed แบบใดแบบหนึ่ง และไม่ควร disassemble 1,520 bytes นี้ตรง ๆ แล้วถือว่าเป็น NDS32 executable.

## 2. จุดใหม่สำคัญ: on-device MVA parser ไม่ process helper 03

Jump table ของ parser @`0x41A8` map record IDs ดังนี้:
- ID1 -> `0x41BC`
- ID2 -> `0x41FE`
- ID3 -> `0x41D8`
- ID4 -> `0x43B4`
- ID5 -> `0x4440`

Handler ของ ID3 @`0x41D8`:
1. log `03PKG offset:%lu`
2. อ่าน/แสดง record length (`FlashLen:%lu`)
3. เพิ่ม parser offset ด้วย payload length
4. เพิ่มอีก 5 bytes สำหรับ ID+length header
5. ลด remaining-record count
6. กลับสู่ parser loop @`0x44C8`

ใน handler นี้ **ไม่พบ direct call สำหรับ copy/execute helper, ไม่พบ direct CRC validation ของ payload 03 และไม่พบ branch เข้า helper bytes**. Supporting string evidence ใน flashbootก็มี `03PKG` เพียงจุดเดียว และไม่มี `03PKG end`/`03 end`, ขณะที่มี end markers สำหรับ package 02/04/05.

ข้อสรุปที่อนุญาตได้คือ: **ใน on-device MVA validation/parser path ที่ตรวจอยู่ package 03 ถูกข้ามตาม framing หลังรู้ length; มันไม่ได้ถูกเปิดเป็น flash-read/readback helper ให้ path นี้ใช้.**

ข้อสรุปที่ยังห้าม: ห้ามบอกว่า package 03 “ไม่มีทางถูกใช้ที่อื่นเลย”. Maker ยัง bundle มันอยู่ จึงอาจเป็นข้อมูลสำหรับ PC/flashboot path อื่น แต่ยังไม่มี consumer/transport ที่พิสูจน์ได้.

## 3. SDK มี `SpiFlashRead` จริง แต่เป็น internal primitive ไม่ใช่ host readback

ใน `sdk_evidence/r25_current_sdk/bt_obex_upgrade.c` พบ `SpiFlashRead(...)` 11 จุด. บทบาทจาก source ที่เห็นชัดคือ:
- อ่าน staging area เพื่อคำนวณ MVA CRC
- read-after-write เพื่อตรวจข้อมูลที่เพิ่ง `SpiFlashWrite` แล้วด้วย `memcmp`

ดังนั้นชิป/SDK **มี primitive สำหรับอ่าน SPI flash ภายใน firmware** แน่นอน. แต่ primitive นี้ไม่ได้เท่ากับ host command.

Cross-check source ที่เรามี:
- `r23_reverse/otg_device_standard_request.c`: ไม่มี `SpiFlashRead`
- `r23_reverse/upgrade.c`: ไม่มี `SpiFlashRead`
- R27 flashboot HID command set: ไม่พบ arbitrary flash-read command ที่พิสูจน์ safe
- Package 03 ID3 parser path: ไม่ expose helper เป็น readback

จึงยัง **ไม่มี transport จาก Samsung/host ที่พิสูจน์ว่าสามารถขอ arbitrary flash bytes กลับมาแบบ read-only**.

## 4. Metadata fields

R29 คงหลักฐานที่พิสูจน์แล้วจาก R28:
- code magic @`0xC0` = LE `0xB0BEBDC9`
- code length @`0xE0..0xE2` เป็น 24-bit LE
- `0xE3` เป็น additive check byte
- FastCRC included/excluded ranges ถูก reconstruct แล้ว

แต่ R29 ยังไม่พบหลักฐานเพิ่มพอที่จะ assign exact production semantics ให้ excluded fields:
- `0xA4..0xA7`
- `0xBC..0xBF`
- `0xCC..0xD3`
- `0xE4..0xEB`

จึงคง fail-closed: ห้ามสร้าง production image จาก field guesses.

## 5. Recovery gate หลัง R29

สถานะยังเป็น:
- stock backup: **ไม่มี**
- full flash readback: **ยังไม่พิสูจน์**
- package03 เป็น host readback helper: **ไม่พิสูจน์ และ on-device parser path ไม่ process payload นี้**
- internal `SpiFlashRead`: **มี**
- host exposure ของ `SpiFlashRead`: **ไม่พบ/ไม่พิสูจน์**
- production layout: **ยังไม่พิสูจน์**
- live flash/update action: **BLOCKED**

ดังนั้น R29 ไม่มี Android hardware probe ใหม่ และไม่ต้องติดตั้ง APK ใหม่.

## 6. ขั้นถัดไปที่เหมาะสม

R30 ควรอยู่ offline ต่อและ pivot จาก package03 ไปหา **host exposure ของ internal read primitive** โดยตรง:
1. trace USB/HID/UDisk/runtime command dispatchers ที่อาจคืนข้อมูลจาก `SpiFlashRead` ไป host
2. trace PC-side updater/downloader binariesเฉพาะส่วน “read/upload/query” และแยกออกจาก erase/program flow
3. ตรวจ ROM/API symbols และ normal runtime source ว่ามี safe identity/readback route ที่ไม่ arm boot/update หรือไม่
4. ถ้าไม่มี ให้คง recovery gate ปิด และไม่ทำ live USB experiment

ข้อจำกัดเดิมยังใช้ทั้งหมด: ห้าม Feature `0x55/0xAA`, ห้าม OBEX PUT/.mva transfer, ห้าม erase/program/commit/apply/reset และไม่วนกลับไป probe เดิม.
