# R32 — Protected Windows UFE Response / HID Runtime Offline Reverse

สถานะ: **OFFLINE ONLY / FAIL-CLOSED**  
ไม่มี USB/BLE/OBEX/hardware probe และไม่มี erase/program/commit/reset ใด ๆ

## ผลใหม่ที่ได้จริง

R32 ไม่ได้วนค้น string แบบ R31 แต่กู้ protected method stream ของ Windows 2026 โดยตรงจาก resource 607,967 bytes จน parser ใช้ข้อมูลครบทั้ง stream พอดี `0x946DF` bytes และได้ protected-method records **1,823 records** ตรง checkpoint เดิม

ลำดับ protected stream ที่ยืนยันได้:
- header 6 x Int32 = `0600091C 00017725 000006DB 0005F0C1 000004B8 00000000`
- patch pairs 1,208 คู่
- capacity raw `0x71F` และ Hashtable capacity 1,824
- variable records 1,823 records
- end position = 607,967 bytes พอดี

## HID I/O path ที่กู้จาก protected IL

ได้ call edge ตรงจาก method body ที่ถูกซ่อน:

`HIDInterface.Send -> Hid.Write -> HidD_SetOutputReport`

และ receive:

`HIDInterface.HidRead -> Hid.Read -> HidD_GetInputReport -> HIDInterface.HidDataReceived -> RaiseEventDataReceived`

ดังนั้น `ReadFile/WriteFile` ที่มีอยู่ใน import surface ไม่ใช่สิ่งที่ต้องเดาว่าเป็น path หลัก: protected wrapper ของ normal `Hid.Read/Hid.Write` ที่กู้ได้เรียก Input/Output Report โดยตรง

## Hidden UFE response dispatcher

กู้ `UFEcommandBridge::FBL3HEmTva` MethodDef `0x06000795` ได้จาก protected record key `0x9C84`, blob 6,144 bytes

ตัว parser อ่าน `response[0]` แล้วทำ:

`response[0] - 0x60`

จากนั้น switch 5 ค่า:
- `0x60` -> scalar sensor/actuator response; ใช้ `SensorActuatorDataBinaryConverter.ParseBinary`
- `0x61` -> shared non-flash control path
- `0x62` -> sensor FIFO; ใช้ `ParseFifoBinary`
- `0x63` -> shared non-flash control path
- `0x64` -> bulk actuator; enumerate actuator, match `Actuator.ID`, แล้ว `ParseBinary`

อีก branch ตรวจ `response[0] == 0x82` แยกต่างหากสำหรับ bulk continuation

Device Description ใน parser เดียวกันประกอบ length จาก `response[1..3]` เป็น 24-bit value แล้วสะสม byte chunks ก่อน JSON decode

## ตรวจ hidden flash/readback

ใน protected dispatcher ที่กู้ได้:
- ไม่พบ call ไป flash API
- ไม่พบ arbitrary flash address input
- ไม่พบ firmware-image buffer/dump/export sink
- data destination ที่เห็นเป็น `Sensor`, `Actuator`, FIFO และ Device Description object model

`ReadActuatorPeriperalCommand.ToByteArray` ก็ถูกกู้แล้ว: ใช้ opcode `0x58`, `Actuator.ID` และ binary converter ของ object model ไม่ใช่ flash address serializer

## ข้อสรุป R32

Windows hidden UFE receive/response path ที่ R31 ยัง decode ไม่ครบ ตอนนี้ถูกเปิดและจำแนกได้แล้ว แต่ **ไม่พบ stock full-flash backup/readback primitive**

สถานะจึงยังเป็น:
- safe stock backup: **NOT FOUND**
- arbitrary host flash read: **NOT FOUND / NOT PROVEN**
- production flash layout: **NOT PROVEN**
- FLASH_GATE: **CLOSED**
- hardware action: **BLOCKED**

R32 ไม่สร้าง destructive packet และไม่อนุญาตให้ใช้ `.mva`, OBEX PUT, Feature 0x55/0xAA, runtime 0x00/0x11, erase/program/commit/reset หรือ hardware probe ใด ๆ
