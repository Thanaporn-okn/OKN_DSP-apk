# R28 — Normal-app Feature report conclusion

Feature report 8 bytes ของ IF4 ไม่ใช่ identity/version query. Reference source ส่ง USB Setup packet buffer กลับ โดยแก้ byte 0 เป็น 0 หรือ 0x55 ตาม `pc_upgrade`. ถ้า armed แล้ว GET Feature ยังต่อด้วย `start_up_grate(AppResourceUsbDevice)` ใน reference source.

ดังนั้น:
- baseline 8 bytes ไม่ใช่ firmware metadata
- ห้ามใช้ GET Feature หลัง arm เป็น read probe
- ห้ามทำ 0x55/0xAA ซ้ำ
- R28 ไม่เพิ่ม USB action ใด ๆ
