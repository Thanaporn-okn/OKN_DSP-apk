# R35 — Production recovery artifact search (offline + public-source verification)

วันที่ตรวจ: 2026-09-20

## เป้าหมาย
ปิดคำถามว่ามี production factory/recovery artifact ของ GoloPine 7CH / DSTech DAS84014 / BP1048P4 อยู่ในชุดไฟล์ผู้ใช้หรือเผยแพร่สาธารณะหรือไม่ ก่อนพิจารณาการเขียน flash ใด ๆ

## สิ่งที่ตรวจจากชุดไฟล์ผู้ใช้
- GoloPine_DSP_Full_Dataset และ handoff R30/R34: ไม่พบ factory `.bin`, `.img`, `.hex`, `.fw`, `.rom`, `.ota`, `.dfu` หรือ production linker/map
- Windows vendor clients 27Nov2025 และ 08Apr2026: เป็น tuning clients; R34 ไม่พบ hidden stock-backup/readflash path
- clean-room OKN firmware packages: source-only/non-flashable และไม่ใช่ factory rollback image

## สิ่งที่ยืนยันจากแหล่งสาธารณะ
หน้า official GoloPine 7-channel แสดงเฉพาะ Android tuning app, Windows tuning clients (27Nov2025 / 08Apr2026), คู่มือ และวิดีโอการใช้งาน ไม่ได้ประกาศ factory firmware/recovery image ให้ดาวน์โหลด

ลิงก์ Windows ที่หน้า official ชี้ไปยัง media uploads:
- `/wp-content/uploads/2026/02/4-27Nov2025_Windows-DSTech_AudioDSP_Client.zip`
- `/wp-content/uploads/2026/05/golopine_audio_turning_release_2026-04-08.exe_.zip`

การค้นสาธารณะด้วยคำ GoloPine / DAS84014 / BP1048P4 + firmware/recovery/upgrade ไม่พบ production factory image ที่ยืนยันว่าตรงกับบอร์ดนี้

ชุมชน diyAudio มีผู้ใช้ DAS84014/GoloPine รายงานว่าผู้ขายระบุว่า ACP Workbench ใช้ไม่ได้เพราะ protocol/firmware คนละแบบ และผู้ใช้รายอื่นยังตามหา firmware เช่นกัน; ไม่พบโพสต์ที่เผย rollback/factory image ที่พิสูจน์แล้ว

> หมายเหตุ: การค้นไม่พบไม่ใช่หลักฐานว่าไฟล์ไม่มีอยู่ในระบบภายในของผู้ขาย แต่เพียงพอที่จะปิด “public-download path” ณ checkpoint R35

## สถานะ gate หลัง R35
- public factory image: NOT FOUND
- user-owned factory image: NOT FOUND
- production linker/map: NOT FOUND
- stock full-flash backup: NOT AVAILABLE
- proven rollback package: NOT AVAILABLE
- production flash layout: NOT PROVEN
- FLASH_GATE: CLOSED

## สิ่งที่ต้องได้เพื่อเปิดทาง R36
อย่างน้อยหนึ่งชุดที่ตรงกับ exact GoloPine 7CH / DAS84014 hardware revision:
1. original/factory firmware image (`.bin/.img/.fw/.rom/.ota/.dfu` หรือ package ต้นฉบับ)
2. official upgrade/recovery package ที่มี payload + manifest/header/CRC/signature metadata
3. production linker/map + exact build configuration + bootloader version
4. programmer project/backup image ที่ผู้ขายใช้กู้บอร์ด

เมื่อได้ artifact ให้ทำ offline-only ก่อน: SHA256 -> file-format/header -> address/range -> bank/rollback -> preserve board-specific data -> build compatibility gate. ยังไม่เขียน hardware จนกว่าจะผ่านทุกข้อ
