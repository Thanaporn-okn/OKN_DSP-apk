# R26 — Reverse PC flashboot transport แบบ OFFLINE เท่านั้น

วันที่: 2026-09-19

## ขอบเขต

R26 ทำต่อจาก R25 โดยไม่ส่งคำสั่งไปบอร์ดแม้แต่คำสั่งเดียว เป้าหมายคือแยก transport หลัง `start_up_grate(AppResourceUsbDevice)` / jump-to-0, หา framing/command vocabulary, แยกส่วนที่เสี่ยงเขียน flash และตรวจว่ามี identity/version/read command ที่พิสูจน์ว่าไม่เปลี่ยน state หรือไม่

ข้อห้ามยังเดิม: ไม่ส่ง `.mva`, ไม่ OBEX PUT, ไม่ erase/program/commit/apply, ไม่ลอง Feature SET_REPORT `0x55/0xAA`, ไม่ทำ ACP `0x00/0x11` ซ้ำ และไม่เดา production flash map.

## 1. Reference flashboot 64 KiB ถูก reconstruct ได้แบบ deterministic

จาก `flash_boot.c` + macro ของ BP1048P4 reference SDK สามารถ reconstruct image 65,536 bytes ในหน่วยความจำได้ตรงกันทุกครั้ง:

- SHA256: `cd0e4e03f7072abd48fea2aeb5a54d9360b65acb1bd4d1b37734438cbe5f47c6`
- bytes ที่ offset `0x100..0x103`: `00 36 55 0D`
- `0x36` = BOOT_UART_CONFIG ของ reference build
- `0x55` = JUDGEMENT_STANDARD แบบ CRC
- `0x0D` = PCTOOL + UDisk + SD_A15/A16/A17 ใน reference config

นี่คือ **reference SDK image เท่านั้น** ไม่ใช่ production firmware dump ของบอร์ดผู้ใช้ และห้ามนำ SHA/image นี้ไปถือว่า flash ได้กับบอร์ดจริง.

## 2. Transport หลัง jump-to-0 เป็น USB Mass Storage BOT family อย่างมีหลักฐานแรง

ภายใน reference flashboot พบ literal `USBC` ที่ `0xE00C` และมีตาราง pointer คำสั่ง 8 รายการที่ `0xE04C`.

ใน source USB mass-storage ของ SDK เดียวกัน นิยาม Bulk-Only Transport เป็น:

- CBW signature `0x43425355` ซึ่งใน byte order บนสายคือ `USBC`
- CBW 31 bytes: Signature 4 + Tag 4 + DataTransferLength 4 + Flags 1 + LUN 1 + CDBLength 1 + CDB[16]
- CSW signature `0x53425355` (`USBS`)
- CSW 13 bytes: Signature 4 + Tag 4 + Residue 4 + Status 1

การที่ flashboot มี `USBC` อยู่ติดกับตารางคำสั่ง ASCII ทำให้สรุปได้ในระดับ **strong static evidence** ว่า PC flashboot ใช้ USB Mass Storage Bulk-Only Transport / CBW-family และมี custom command vocabulary ใน command block/CDB path.

อย่างไรก็ตาม R26 ยังไม่อ้างว่าเรารู้ byte layout ของ vendor CDB แต่ละคำสั่งครบ 100% เพราะ handler machine code ยังไม่ได้ decompile พร้อม symbol.

## 3. Command table ที่ recover ได้

ตารางที่ `0xE04C` ชี้ไปยัง C-string ต่อไปนี้:

| index | command | string offset | สถานะ R26 |
|---:|---|---:|---|
| 0 | `chiperas` | `0xCBE8` | BLOCK — destructive erase |
| 1 | `upinfo` | `0xCBF4` | BLOCK — semantics/side effects ยังไม่พิสูจน์ |
| 2 | `btupdat` | `0xCBFC` | BLOCK — update/write |
| 3 | `cnfgdat` | `0xCC04` | BLOCK — program/config data |
| 4 | `constdat` | `0xCC0C` | BLOCK — program const data |
| 5 | `codedata` | `0xCC18` | BLOCK — program code |
| 6 | `bootdat` | `0xCC24` | BLOCK — program boot data |
| 7 | `cxxx` | `0xCC2C` | BLOCK — metadata/CRC/offset validation; side effectsยังไม่พิสูจน์ |

คำว่า `chiperas` รวมกับ diagnostic `prepare to unlock & chip erase all` ทำให้เส้นทางนี้เป็น destructive โดยตรงและไม่ต้องทดลองกับ hardware.

`bootdat/codedata/constdat/cnfgdat` มี diagnostic คู่กับ `pc recive ... data fail`, `pc write ... data fail`, และ `... end` จึงเป็น data/program stages ไม่ใช่ read probe.

`btupdat` มี diagnostic `BT_INFO updata ok!` จึงจัดเป็น write/update.

`cxxx` แสดง/ตรวจ field เช่น `boot_len`, `boot_crc`, `code_len`, `code_crc`, `const_len`, `config_len`, `const_offset`, `config_offset`, encryption compatibility และ ACK. แม้จะดูเป็น validation command แต่ยังไม่มีหลักฐานว่าไม่มี state transition ดังนั้นยังห้าม probe.

`upinfo` เป็น candidate ที่ชื่อดูเหมือน info/status แต่ R26 ยังไม่มีหลักฐาน handler เพียงพอที่จะรับรองว่า read-only จึง **ยังห้ามส่ง**.

## 4. MVA/package structure ที่รู้เพิ่ม แต่ยังไม่ครบ

Static strings ยืนยัน:

- header/magic check: `MVA HEADER IS NOT MVB1X`
- มี package IDs `01PKG`, `02PKG`, `03PKG`, `04PKG`, `05PKG`
- metadata มีอย่างน้อย boot/code length+CRC, const/config length+offset และ encryption compatibility
- `04PKG` diagnostics เชื่อมกับ const offset/processing
- `05PKG` diagnostics เชื่อมกับ config offset/processing
- package maker diagnostics กล่าวถึง `header&01pkg`, `03pkg`, `02pkg`, Flashboot CRC/len และ ActualCode CRC/SIZE

แต่ semantic mapping ของ 01/02/03 ยังไม่พอให้สร้าง package schema ที่เชื่อถือได้ ดังนั้น R26 **ไม่สร้าง `.mva`** และไม่เดา field layout.

## 5. Reference SDK flash map — ใช้เป็น architecture evidence เท่านั้น

`flash_config.h` ของ reference BP1048P4 ระบุ:

- CODE `0x000000`
- CONST_DATA `0x198000`
- AUDIO_EFFECT `0x3C8000`
- FLASHFS `0x3D0000`
- USER_DATA `0x3F0000`
- BP_DATA `0x3F3000`
- BT_DATA `0x3FB000`
- USER_CONFIG `0x3FE000`
- BT_CONFIG `0x3FF000`

ค่าพวกนี้ **ยังไม่ใช่ proof ของ production-board layout**. ห้ามใช้เป็น address สำหรับ erase/program บนบอร์ดผู้ใช้จนกว่าจะมี production dump/official package/recovery evidence ยืนยัน.

## 6. b1_download_v1.3.exe เป็นคนละ transport

ตรวจ tool `b1_download_v1.3.exe`:

- SHA256 `7b4e8dd794914b384f0a919b97a016b6bcac1b989a375f64af55b3372a402c19`
- PE32/Cygwin
- import `socket`, `connect`, `read`, `write`
- `send_cmd(char)` ที่ VA `0x004012A0` ส่ง 1 byte ผ่าน file descriptor/socket และอ่าน ACK 2 bytes; success เมื่อ `ack[0]==cmd && ack[1]==0`

จึงเป็น legacy Flash Burner/debug-server transport ไม่ใช่หลักฐานว่า PC flashboot USB BOT ใช้ 1-byte command framing แบบเดียวกัน. R26 แยกสอง protocol นี้ออกจากกัน ไม่เอามาปะปน.

## 7. คำตอบเรื่อง safe live read command

**ยังไม่พบ command ที่พิสูจน์ได้ว่าปลอดภัยพอสำหรับ live probe.**

เหตุผลมีสองชั้น:

1. การเข้าสู่ PC flashboot ที่เรารู้จาก reference app ต้องผ่าน state-changing `0x55/0xAA -> GET_REPORT -> start_up_grate -> jump 0` ซึ่งถูกล็อกไม่ให้ทดสอบซ้ำอยู่แล้ว.
2. แม้ `upinfo` อาจเป็น info/status command แต่ handler semantics ยังไม่พิสูจน์ว่าไม่มี side effects และเราไม่มีเหตุผลให้เข้า bootloader เพื่อทดลองมัน.

ดังนั้น **R26 ไม่สร้าง Android hardware probe ใหม่** และไม่ให้ผู้ใช้กดอะไรบนบอร์ด.

## 8. Next target ที่ปลอดภัย

ทำ offline ต่อเท่านั้น:

1. disassemble/decompile handler dispatch ของคำสั่ง 8 ตัวใน 64 KiB reference flashboot โดยเฉพาะ `upinfo` และ `cxxx`;
2. recover DataTransferLength / direction / CDB bytes / ACK/CSW behavior ของแต่ละ command;
3. หา read-only identity/version path ที่ไม่ต้องเปลี่ยน boot state ถ้ามี;
4. หา production-board layout/recovery evidence จาก official updater/package/dump ก่อนแตะ flash;
5. ถ้าไม่มี non-destructive entry/read path ให้ประกาศเส้นทางนี้ว่า hardware-probe blocked แทนการเดา.

## Decision R26

- PC flashboot transport family: **identified with strong static evidence as USB MSC BOT + custom command table**.
- Destructive/write command vocabulary: **identified enough to blacklist**.
- Complete vendor command framing: **PARTIAL / not yet proven**.
- Safe live identity/version command: **NOT PROVEN**.
- Production flash layout: **NOT PROVEN**.
- Hardware test: **BLOCKED**.
