# R28 — MVA package / CRC / recovery reverse (OFFLINE ONLY)

## ขอบเขต
R28 ทำจาก SDK/flashboot ที่มีอยู่เท่านั้น ไม่เปิด USB/Bluetooth และไม่มีคำสั่งไปยังบอร์ดจริง งานนี้ต่อจาก R27 ซึ่งปิด flashboot command ทั้ง 8 ตัวว่าไม่มีคำสั่ง identity/readback ที่พิสูจน์ว่า strict read-only.

## 1. โครงสร้าง MVA ที่พิสูจน์จาก parser + maker
Reference flashboot 65,536 bytes มี SHA256:
`cd0e4e03f7072abd48fea2aeb5a54d9360b65acb1bd4d1b37734438cbe5f47c6`

Header จริงเป็น 5 bytes:
- offset 0 = `0x4D` (`M`)
- offset 1 = `0x56` (`V`)
- offset 2 = `0xB1` (chip byte แบบ binary)
- offset 3 = `0x58` (`X`)
- offset 4 = จำนวน records/packages

จึงควรเรียก signature ว่า `4D 56 B1 58` หรือ `MV + 0xB1 + X`; ข้อความ debug ใน flashboot เรียกเชิงมนุษย์ว่า `MVB1X`.

แต่ละ record มี framing ที่พิสูจน์ได้:
`[ID:u8] [payload_length:u32 little-endian] [payload...]`

ID ที่ parser รู้จัก 1..5:
- `01`: metadata/preamble; maker default ใส่ payload 3 bytes `35 BA 69` แต่ความหมาย exact ของ 3 bytes นี้ **ยังไม่พิสูจน์**
- `02`: code image; payload เริ่มด้วย target offset LE32 แล้วตามด้วย code bytes
- `03`: helper blob; payload เริ่ม target offset LE32 แล้วตามด้วย helper 1,520 bytes
- `04`: constant-data; target offset LE32 + data
- `05`: config-data; target offset LE32 + data

Default package ที่ maker สร้างมี record count=3 และ layout:
- header 0..4
- record 01 @5, length=3, payload `35 BA 69`
- record 03 @13, length=1524 = offset 4 + helper 1520; target offset=0
- record 02 @1542, length=`code_length+4`; target offset=0; code bytes เริ่ม @1551
- หลัง records มี trailer 4 bytes; total size=`code_length+1555`

## 2. CRC ของ package
ฟังก์ชัน @`0x3F36` ใช้ table @`0xC214`; entries แรกเมื่ออ่าน little-endian คือ `0000,1021,2042,3063` และ loop เป็น high-byte table CRC. Algorithm ตรงกับ **CRC-16/XMODEM**:
- polynomial `0x1021`
- init `0x0000`
- xorout `0x0000`
- check `"123456789" = 0x31C3`

Maker เรียก helper ด้วย init=0 เหนือ package bytes ก่อน trailer แล้ว append ช่อง 4 bytes สำหรับผล checksum word. CRC ที่พิสูจน์จาก helper มี 16 bits; ห้ามตีความ 16 bits บนของ trailer เพิ่มเกินหลักฐานถ้ายังไม่มีไฟล์ MVA จริงมา cross-check.

## 3. Metadata ของ code image
Maker อ่าน source image offset `0xE0..0xE3`:
- `0xE0..0xE2`: code length แบบ 24-bit little-endian
- `0xE3`: additive check byte โดย `(E0+E1+E2)&0xFF == E3`

Parser ตรวจ code magic ที่ offset `0xC0` = little-endian `0xB0BEBDC9`.

Maker คำนวณ FastCRC แบบต่อเนื่องเฉพาะช่วง:
- `0x0000..0x00A3`
- `0x00A8..0x00BB`
- `0x00C0..0x00CB`
- `0x00D4..0x00E3`
- `0x00EC..code_length-1`

จึงเว้น metadata ranges:
`0xA4..A7`, `0xBC..BF`, `0xCC..D3`, `0xE4..EB`.
ยังไม่ควรเดาความหมายทุก field หรือใช้ข้อมูลนี้สร้าง production image จน decoder ครบและมี recovery proof.

## 4. Feature report 8 bytes ของ normal app ไม่ใช่ identity/version read
จาก `otg_device_standard_request.c`:
- GET Feature (0xA1 / report type 0x03) ตอน `pc_upgrade==0` ทำ `Setup[0]=0` แล้วส่ง buffer `Setup` กลับ
- ตอน `pc_upgrade!=0` ทำ `Setup[0]=0x55`, ส่ง buffer `Setup` แล้ว reference source เรียก `start_up_grate(AppResourceUsbDevice)`
- SET Feature `0x55` เปรียบเทียบ 4 bytes กับ memory `0x10000+0xB8`; ถ้าต่างกันจึง arm
- SET Feature `0xAA` arm แบบ unconditional

ดังนั้น baseline ที่เคยอ่านได้ เช่น `00 01 00 03 04 00 08 00` เป็นรูปของ **USB setup packet buffer** ที่ byte แรกถูกแก้ ไม่ใช่ firmware identity/version/status structure. และ GET Feature หลัง arm ไม่ใช่ safe read เพราะใน reference source เป็น trigger ต่อไปยัง boot transition.

นี่เป็นเหตุผลเพิ่มว่าห้ามทำ 0x55/0xAA/GET-after-arm ซ้ำกับบอร์ดจริง.

## 5. `Report_Error_Code()` ไม่แก้ปัญหา backup/readback
ใน `upgrade.c` มี getter `Report_Error_Code()` ที่อ่าน `SREG_FLASH_BOOT_FLAGE.ERROR_CODE` โดยตัว getter เองไม่มี write แต่จากการไล่ source ชุดนี้ไม่พบว่ามันถูก expose ผ่าน HID Data/Feature request ให้ host อ่านเป็น identity หรือ flash readback. ส่วน `report_up_grate()` เป็นคนละฟังก์ชันและมีการ clear result bits หลังอ่าน จึงไม่ strict read-only.

## 6. Flash map ที่รู้ — reference เท่านั้น
`flash_config.h` ของ SDK มี BP1048P4 map ถึง 4 MiB:
- code `0x000000`
- const `0x198000`
- audio effect `0x3C8000`
- flashfs `0x3D0000`
- user data `0x3F0000`
- BP data `0x3F3000`
- BT data `0x3FB000`
- user config `0x3FE000`
- BT config `0x3FF000`

**นี่เป็น reference SDK layout ไม่ใช่ proof ว่า stock GoloPine production image ใช้ layout เดียวกันทุกส่วน.**

## 7. Backup / recovery conclusion
R28 ยังไม่มี stock backup. MVA ที่ reverse ได้เป็น **host/source image container สำหรับ validation/programming** ไม่ใช่ protocol สำหรับดึง flash กลับจากบอร์ด. Flashboot HID command set จาก R27 ก็ไม่มี arbitrary flash-read command ที่พิสูจน์ได้.

ดังนั้นตอนนี้ยังขาดครบทั้ง:
- full 4 MiB stock readback
- production layout proof
- recovery image ที่ตรวจ hash ซ้ำได้
- safe identity/readback command จาก Samsung

ผลคือ **ยังห้าม flash** และ **R28 ไม่มี live Android probe ใหม่**.

## 8. ขั้นถัดไป
R29 ควรอยู่ offline ต่อ โดยเป้าหมายเฉพาะคือ:
1. แกะ helper blob 1,520 bytes ใน package 03 ว่ารับ command/readback อะไรหรือไม่
2. ไล่ code metadata fields ที่ maker เขียนกลับ โดยเฉพาะ FastCRC/size/version fields
3. หา read primitive อื่นใน normal runtime/ROM API ที่มี host transport จริง โดยไม่ใช้คำสั่ง arm/boot/update
4. ถ้ายังไม่มี readback ให้คง flash/recovery gate ปิดไว้

ห้ามสร้าง live command จาก format ที่ R28 เพิ่งรู้เพียงเพราะ packet framing ชัดขึ้น; framing knowledge ไม่เท่ากับ recovery path.
