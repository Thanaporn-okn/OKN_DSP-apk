# R33 — Flash readback / recovery gate (OFFLINE ONLY)

R33 เดินต่อจาก R32 โดยไม่ยิงคำสั่งใด ๆ ไปที่บอร์ด เป้าหมายคือปิดคำถามที่เหลือว่า internal flash read ของ reference flashboot มีทางส่ง arbitrary flash bytes กลับ host ผ่าน HID updater หรือไม่ และแยก reference flash map ออกจาก production-board proof ให้เด็ดขาด

## ผลใหม่ที่สำคัญ

### 1. ระบุ internal flash-read primitive ใน reference image ได้แรงขึ้น
ใน reference flashboot 64 KiB, ฟังก์ชัน `0x45EE` มีลำดับเรียก `0x1204 -> 0x0F9C -> 0xACDC(memcmp)` ซึ่งเป็นรูปแบบ program -> readback -> verify ชัดเจน จึงระบุ `0x0F9C` เป็น internal flash-read primitive ของ image นี้ด้วย behavioral evidence ได้

ทั้ง image มี direct call ไป `0x0F9C` 19 จุด โดยส่วนที่อยู่ใน updater command handler ใช้ใน flow ตรวจ/verify ภายใน ไม่ใช่ command read-only แยกต่างหาก

### 2. ไล่ HID response surface ทั้ง image แล้ว
ฟังก์ชัน `0x4BF6` คือ wrapper ที่รอ HID GET_REPORT แล้วส่ง 256 bytes ผ่าน `0x9436` ตามที่ R27 กู้ไว้

R33 scan ทั้ง 64 KiB พบ call ไป `0x4BF6` **14 จุดเท่านั้น** และทั้ง 14 จุดอยู่ใน 8 updater handlers ที่รู้จักแล้ว:

| handler | response call sites |
|---|---|
| `cxxx` | `0x5022` |
| `chiperas` | `0x5154` |
| `bootdat` | `0x51F8`, `0x5218`, `0x5296`, `0x52B6` |
| `codedata` | `0x5360`, `0x53FA` |
| `constdat` | `0x5498`, `0x54FE` |
| `cnfgdat` | `0x559C`, `0x5602` |
| `btupdat` | `0x5746`, `0x5756` |
| `upinfo` | ไม่มี |

จึง **ไม่พบ hidden ninth handler** ที่ใช้ response wrapper เดียวกันเพื่อ dump/read flash

นอกจากนี้ call ไป low-level HID control send `0x9436` ทั้ง image มีเพียง `0x2A7E`, `0x2AE4`, `0x4C36`; updater response ที่พิสูจน์แล้ววิ่งผ่าน `0x4C36` เท่านั้น

### 3. Internal read ไม่ได้กลายเป็น host readback
ใน data handlers จุดที่อ่าน flash ใช้ readback/compare ภายใน แล้ว response ที่เห็นเป็น status/ACK (`0x55`, `0xFF` ฯลฯ) ไม่พบลำดับ copy arbitrary flash bytes จาก destination ของ `0x0F9C` เข้า HID response buffer เพื่อ expose ให้ host

ขอบเขตของข้อสรุปนี้คือ static recovered reference image + source evidence ที่เรามี ไม่ใช่ formal whole-program taint proof และไม่ใช่ proof ว่า production firmware เหมือน reference 100%

### 4. Reference flash map แข็งแรงขึ้น แต่ยังไม่ใช่ production layout
`flash_config.h` สำหรับ BP1048P4 ระบุ:

- CODE `0x000000`
- CONST_DATA `0x198000`
- AUDIO_EFFECT `0x3C8000`
- FLASHFS `0x3D0000`
- USER_DATA `0x3F0000`
- BP_DATA `0x3F3000`
- BT_DATA `0x3FB000`
- USER_CONFIG `0x3FE000`
- BT_CONFIG `0x3FF000`

และ compiled flashboot header เองฝังค่า `0x198000`, `0x3F0000`, `0x3C8000` ตรงกับ source macros จึงยืนยันว่า **reference build นี้ใช้ address span ถึง 4 MiB จริง** ไม่ใช่แค่ comment

แต่ยังไม่มี production dump/official artifact ที่ยืนยันว่าบอร์ดจริงใช้ layout เดียวกัน จึงยังห้ามเอา address นี้ไปเขียน/ลบจริง

## Decision R33

- internal flash read primitive ใน reference: **PROVEN (`0x0F9C`)**
- hidden updater read/dump handler: **NOT FOUND**
- arbitrary flash -> HID readback: **NOT FOUND**
- safe stock backup path: **NOT FOUND**
- production flash layout: **NOT PROVEN**
- `FLASH_GATE=CLOSED`
- hardware probe / Feature `0x55/0xAA` / ACP `0x00/0x11` / `.mva` / OBEX PUT / erase/program/commit/apply/reset: **BLOCKED**

ผลเชิงโครงการ: เส้นทาง software-only ที่มีอยู่ใน reference Windows/UFE/flashboot ถูกไล่จนไม่พบ stock full-backup primitive ที่ปลอดภัยแล้ว ถ้าจะเปิด flash gate ต่อ จำเป็นต้องมีหลักฐาน production/recovery เพิ่มจาก artifact ที่อ่านได้ offline หรือวิธี readback อิสระที่พิสูจน์ non-mutating ก่อน
