# R25 — SDK correlation / OBEX OTA reverse (READ-ONLY)

วันที่: 2026-09-19

## ผลใหม่ที่สำคัญที่สุด

R24 พบ address ของบอร์ดจริงสองฝั่ง:

- Classic: `63:57:DC:10:68:0E`
- BLE: `E3:57:DC:10:C8:0E`

ใน SDK `bt_app_func.c` มีสูตรสร้าง BLE address จาก Classic address ตรง ๆ:

- copy 6 bytes จาก BT address
- `ble[0] = ble[0] | 0xC0`
- `ble[4] += 0x60`

นำ Classic address ของบอร์ดจริงมาใช้สูตร:

`63:57:DC:10:68:0E` -> `E3:57:DC:10:C8:0E`

ตรงกับ BLE address ที่ S25+ พบ **ทุก byte** จึงเป็นหลักฐานใหม่ที่แรงว่าบอร์ดจริงใช้ Bluetooth configuration family เดียวกับ SDK ชุดนี้ และยืนยันว่า Classic/BLE ที่ R24 ตรวจคือบอร์ดตัวเดียวกัน ไม่ใช่อุปกรณ์คนละตัว

## AB00 fingerprint

SDK `ble_app_func.c` ประกาศ service/characteristic แบบนี้:

- advertise UUID16 `AB00`
- AB00 primary service
- AB01 = READ | WRITE | WRITE_WITHOUT_RESPONSE
- AB02 = NOTIFY + CCCD
- AB03 = NOTIFY + CCCD

R24 ของบอร์ดจริงพบรูปแบบเดียวกัน:

- advertise `AB00`
- GATT services = `0x1800`, `AB00`
- AB01 props `0x0E`
- AB02 props `0x10` + descriptor `0x2902`
- AB03 props `0x10` + descriptor `0x2902`

ใน SDK `ble_app_func.c` ไม่พบ cross-reference ไป `ObexUpdateProc`, OBEX, MVA upgrade, flash erase/program หรือ bank apply จาก AB00 handler ดังนั้น source ชุดนี้ไม่สนับสนุนสมมติฐานว่า AB00 เป็น OTA service ของ MVA

## OBEX compile/init chain

Reference `bt_config.h`:

- `BT_OBEX_SUPPORT = DISABLE`
- `MVA_BT_OBEX_UPDATE_FUNC_SUPPORT` ถูก comment และอยู่ภายใน `#if (BT_OBEX_SUPPORT == ENABLE)`

ถ้าเปิด `BT_OBEX_SUPPORT`:

1. `GetSupportProfiles()` เพิ่ม `BT_PROFILE_SUPPORTED_OBEX` (`0x0020`)
2. `ConfigBtStackParams()` register `BtObexCallback`
3. `BTStackRunInit()` ใน `libBtStack.a` มี path ไป `ObexAppInit`
4. `ObexAppInit` เรียก `BTStackInitObex`
5. `BTStackInitObex` เรียก `ObexRegisterSdpService`
6. `obex_sdp.o` register standard **Object Push UUID 0x1105** ชื่อ `Object Push`

`MVA_BT_OBEX_UPDATE_FUNC_SUPPORT` เป็นชั้นเพิ่มบน generic OBEX path:

- data callback ส่งเข้า `ObexUpdateProc()`
- สร้าง worker `bt_obex_upgrate`
- ไม่มี MVA-specific SDP UUID แยก

ดังนั้นใน architecture นี้ **functional MVA-over-OBEX ต้องมี generic OBEX path ก่อน** และ generic path register `0x1105`.

## เทียบกับบอร์ดจริง

R24 live Classic SDP ของ `63:57:DC:10:68:0E` พบ:

- `0x1101` SPP
- `0x110B`
- `0x110E`
- ไม่พบ `0x1105`

เมื่อรวมกับ exact Classic->BLE address transform และ exact AB00 shape match ข้างต้น หลักฐาน runtime จึงชี้แรงว่า stock firmware ของบอร์ดนี้ **ไม่ได้ expose functional MVA-over-OBEX path ตาม SDK นี้**.

ข้อจำกัด: นี่เป็น inference จาก SDK family + runtime capability ไม่ใช่ proof จาก production firmware binary dump ดังนั้นไม่ควรเขียนว่า compile flag เป็น 0 อย่างเด็ดขาด 100%.

## เหตุผลที่ห้ามทดลอง OBEX header

ใน `bt_obex_upgrade.c` เมื่อ callback ได้ `BT_OBEX_LENGTH` จะคำนวณขนาดและตั้ง `obex_start = 1` จากนั้น worker สามารถเริ่ม `SpiFlashErase(BLOCK_ERASE, FLASH_MVA_UPDATE_START_OFFSET/65536, 1)` ที่ staging offset `0x200000`.

ดังนั้นการเปิด OBEX session แล้วส่ง header เพื่อ probe ไม่ถือว่า safe read-only; R25 จะไม่ทำ.

## R25 Android ทำอะไรเพิ่มจาก R24

R25 ยังคง READ-ONLY และเพิ่มเฉพาะ:

- log raw BLE advertisement bytes
- correlate Classic/BLE address ด้วยสูตรจาก SDK
- ตรวจ AB00 characteristic property/CCCD fingerprint
- รวมผล SDP ของ Classic กับ GATT ของ BLE ที่เป็นบอร์ดเดียวกันใน summary เดียว

ยังไม่มี:

- BluetoothSocket/RFCOMM
- OBEX connect/PUT/header/body
- `.mva`
- GATT value read/write/subscribe
- USB API
- erase/program/commit/apply/reset

## Decision หลัง R25

ถ้า R25 correlation match เหมือนข้อมูล R24 ที่มีอยู่แล้ว และ 0x1105 ยัง absent ให้ปิดเส้นทาง stock OBEX OTA เป็น **not exposed by observed firmware** และไม่สุ่ม interaction เพิ่ม.

การค้น firmware update path ต่อควรกลับไปทำ offline reverse จาก evidence อื่น หรือหา signed/official updater/package/production binary evidence ที่สามารถบอก recovery/layout ได้ โดยไม่ย้อนกลับไปทำ USB AA/0x55/ACP ซ้ำ.
