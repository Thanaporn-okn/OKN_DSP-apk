# Next after R35

R36 has exactly one authorization path:
1. Intake an exact GoloPine/DSTech 7CH BP1048P4 factory/recovery artifact from the vendor/board owner.
2. Verify SHA256 and hardware revision.
3. Parse image/package header, address ranges, bank/rollback metadata, CRC/signature/encryption indicators, and board-specific preservation regions offline.
4. Keep FLASH_GATE=CLOSED until rollback compatibility is proven.
5. Only after that, bind TRUE7CH gain IDs 22..28 to exact production audio sinks and build a target image.

Do not repeat Windows 2025/2026 UFE, MVA, ACP 0x00/0x11, Feature 0x55/0xAA, OBEX PUT, erase/program/commit/reset probes.
