# R27 correction note — R26 transport inference

R26 correctly reconstructed the 64 KiB flashboot, found `USBC`, and recovered the 8 ASCII command names. However, the conclusion that those updater commands are carried as MSC BOT/CDB is superseded by R27.

R27 machine-code + source correlation proves the updater command path is:

- Host -> device: HID class `SET_REPORT`, bmRequestType `0x21`, Output report type `0x02`, 256-byte payload.
- Device -> host: HID class `GET_REPORT`, bmRequestType `0xA1`, Input report type `0x01`, 256-byte payload.
- Feature report type `0x03` remains the separate app-firmware PC-upgrade arming/entry mechanism.

The MSC/BOT `USBC` implementation remains valid evidence that UDisk support is compiled in the same flashboot image; it is **not updater-command framing evidence** after R27.
