# R31 — Windows PC Tuning Tool / Runtime Readback Offline Reverse

สถานะ: **OFFLINE ONLY / FAIL-CLOSED**  
ไม่มีการส่ง USB, BLE, OBEX, Feature report, ACP/runtime control หรือ flash command ไปยังบอร์ดจริงใน R31

## 1. ฐานข้อมูลและขอบเขต

R31 ทำต่อจาก R30 โดยไม่ย้อนทดสอบฮาร์ดแวร์เดิม ใช้ Windows executable ตัวจริง:

- `golopine_audio_turning_release_2026-04-08.exe`
- size `3,307,008` bytes
- SHA256 `3ca54171c53f7badd963ffe6851b8b3e2faf8aee8ba2afcb7040990e22ae09b2`

hash/size ตรงกับ Windows checkpoint R1-R3 เดิมทุกประการ จึงเป็น binary เดียวกับที่เคยถอด protected IL ประมาณ 1,823 methods.

R31 เขียน parser PE/.NET metadata และ IL disassembler แบบ pure Python เพื่ออ่านไฟล์เท่านั้น ไม่มี USB/HID/serial/network device I/O.

## 2. Native HID I/O path ที่ยืนยันจาก EXE ตัวจริง

`ImplMap` ของ EXE ยืนยัน wrapper ฝั่ง Windows ดังนี้:

- `HidD_GetInputReport`
- `ReadFile`
- `HidD_SetOutputReport`
- `HidD_SetFeature`
- `WriteFile`
- `CreateFile` / `CloseHandle`
- HID enumeration/capability functions (`HidD_GetHidGuid`, `HidP_GetCaps`, SetupDi* ฯลฯ)

จุดสำคัญ: การมี `HidD_GetInputReport` หรือ `ReadFile` **พิสูจน์เพียงว่าโปรแกรมรับข้อมูลจาก HID ได้** ไม่ได้พิสูจน์ว่ามีคำสั่งอ่าน flash ตาม address. ในทางกลับกัน `SetOutputReport`, `SetFeature`, `WriteFile` เป็น host-to-device send surfaces และจึงไม่ถือว่า safe สำหรับ discovery จนกว่าจะพิสูจน์ dispatch/side effect ของ command ที่เรียกใช้.

## 3. Managed transport / response nodes

Metadata ของ EXE ยืนยันคลาส/เมธอดสำคัญ:

- `Hid.Read`, `Hid.Write`, `Hid.getFeature`
- `HIDInterface.HidRead`, `HIDInterface.Send`, `HIDInterface.HidDataReceived`, `HIDInterface.RaiseEventDataReceived`
- `DeviceCommunicationStream.ReadBytes/ReadLine/Write/WriteLine` และ `raiseOnDataReceivedEvent`
- `UFEcommandBridge` มี field `communicationStream`
- `UFEcommandBridge.DecoderUFEdeviceDescriptionJSON`
- `UFEcommandBridge.DecodeUfeJSONdata`
- `SensorActuatorDataBinaryConverter.ParseBinary/ParseFifoBinary`

active bodies ของเมธอดจำนวนมากถูก JIT protection ทำให้ body ที่อยู่บนดิสก์เป็น stub/no-op; ดังนั้น R31 ไม่ใช้ raw stub เพื่อสรุป side effect. ใช้ prior R2/R3 protected-IL checkpoint เป็นฐาน continuity: R3 ยืนยันแล้วว่า active 2026 write architecture คือ UFE/device-description ไม่ใช่ legacy SigmaDSP helper.

## 4. UFE command/response dispatch ที่ยืนยันจาก EXE metadata constants

อ่าน Constant table ของ `UFEHeader` ได้ตรง ๆ:

- `0x57` — `UFE_WRITE_ACTUATOR_COMMAND`
- `0x58` — `UFE_READ_SENSOR_ACTUATOR_COMMAND`
- `0x59` — `UFE_READ_SENSOR_ACTUATOR_JSON_COMMAND`
- `0x60` — `UFE_RESPONSE_READ_SENSOR_ACTUATOR_COMMAND`
- `0x61` — `UFE_READ_SENSOR_FIFO_COMMAND`
- `0x62` — `UFE_RESPONSE_FIFO_SENSOR`
- `0x63` — `UFE_READ_SENSOR_ACTUATOR_BULK_COMMAND`
- `0x64` — `UFE_RESPONSE_READ_SENSOR_ACTUATOR_BULK_COMMAND`
- `0x82` — `UFE_CONTINUE_BULK_SEND`

กลุ่ม read/query ที่พบมี object model เป็น `Sensor`, `Actuator`, cascade/memory offset ภายใน object data และ device-description flow. **ไม่พบ primitive ที่มี semantics เป็น arbitrary SPI-flash address + length -> bytes-to-host.**

R3 เดิมยังยืนยันว่า `WriteActuatorPeriperalCommand.ToByteArray` ใช้ `0x57` และ `ReadActuatorPeriperalCommand.ToByteArray` ใช้ `0x58`; stock device description ไม่มี actuator สำหรับ independent 7CH volume.

## 5. Frame `A5 5A ... 16` — แยกหลักฐาน firmware กับ Windows ให้ชัด

R30 พิสูจน์จาก reference firmware source ว่า normal runtime HID tuning parser รับ frame:

`A5 5A <Control> <PayloadLength> <Payload...> 16`

และ firmware path คือ `HIDUsb_Rx -> UsbLoadAudioMode -> Communication_Effect_Config`.

ใน R31 ฝั่ง Windows 2026 EXE **ยังไม่พบ direct named/raw builder ของ A5/5A frame ใน metadata/string surface ที่มองเห็นได้**. เนื่องจาก active methods ถูก protected จึงห้ามสรุปว่า Windows tool ไม่มี frame นี้โดยเด็ดขาด. สิ่งที่พิสูจน์ได้คือ active 2026 UI/runtime path ที่ R3 ตามได้อยู่ใน UFE/device-description layer และ EXE มี HID transport wrapper ใต้ layer ดังกล่าว.

ดังนั้น R31 ไม่สร้าง packet A5/5A สำหรับ hardware และไม่เดา control code เพิ่ม.

## 6. ค้นหา hidden backup/upload/read-flash path

ทำ static search ทั้ง MethodDef/TypeDef naming surface และ ASCII/UTF-16 strings สำหรับ:

`backup`, `dump`, `upload`, `export`, `readflash`, `flashread`, `read flash`, `firmware dump`, `stock backup`

ผล: **0 direct candidate hit** ที่สื่อถึง host-facing stock firmware backup/readback.

พบคำทั่วไปอย่าง `Read`, `Write`, `SaveConfig`, `FirmwareRevisionString`, UFE read commands และ file/embedded-resource readers แต่ทั้งหมดมี context อื่นและไม่ใช่หลักฐาน flash dump. การไม่พบ string เพียงอย่างเดียวไม่ใช่ proof of absence เพราะ protected IL ยังมีอยู่; อย่างไรก็ตามเมื่อรวมกับ R3 active UFE path และ R30 firmware dispatcher ผลทั้งหมดไปในทิศทางเดียวกันว่าไม่มี safe arbitrary-flash readback path ที่พิสูจน์ได้ในหลักฐานปัจจุบัน.

## 7. Side-effect classification

- `ReadFile` / `HidD_GetInputReport`: receive primitive เท่านั้น — **ไม่พอ** ที่จะเปิด hardware probe
- UFE `0x58/0x59/0x61/0x63`: read/query ของ sensor/actuator/device-description — ไม่มี arbitrary flash semantics ที่พิสูจน์ได้
- UFE `0x57`: actuator write — mutating
- `HidD_SetOutputReport` / `HidD_SetFeature` / `WriteFile`: transport send surface — อาจ mutating; blocked
- reference runtime control `0x11`: dual-use และมี erase/program path — blocked
- reference runtime control `0x00`: source-level version query แต่ห้าม repeat hardware test ตาม checkpoint

## 8. ข้อสรุป R31

**ยังไม่พบ safe stock full-backup / arbitrary flash readback command ที่พิสูจน์ได้.**

สถานะหลัง R31:

- Windows native HID I/O path: **PROVEN**
- Windows active protocol family = UFE/device-description: **PROVEN จาก R3 + cross-check EXE R31**
- UFE command/response constants 0x57/58/59/60/61/62/63/64/82: **PROVEN จาก EXE Constant table**
- hidden backup/dump/upload/readflash named path: **NOT FOUND**
- arbitrary flash read-to-host: **NOT PROVEN**
- stock full backup: **NOT AVAILABLE**
- production flash layout: **NOT PROVEN**
- hardware probe: **BLOCKED**
- flash gate: **CLOSED**

ไม่มี packet destructive แบบ runnable อยู่ใน R31 checkpoint และไม่มีการแตะบอร์ดจริง.

## 9. ขั้นต่อไปที่เหมาะสมแบบ offline

ให้ลงลึกต่อที่ protected UFE receive/dispatch bodies โดยเฉพาะ `HIDInterface.HidDataReceived`, `UFEcommandBridge` receive handler/queue และ `SensorActuatorDataBinaryConverter`, เพื่อพิสูจน์ byte-level response framing ของ 0x60/0x62/0x64 และค้น data-source ที่อยู่นอก descriptor object model. เป้าหมายยังคงเป็น **software-only proof ก่อน hardware**; ถ้าไม่พบ flash-address source ก็ต้องคง gate ปิดต่อไป.
