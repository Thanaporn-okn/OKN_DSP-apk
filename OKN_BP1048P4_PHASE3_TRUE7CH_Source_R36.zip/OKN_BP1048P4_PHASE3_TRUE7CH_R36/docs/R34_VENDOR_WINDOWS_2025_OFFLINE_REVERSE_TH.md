# R34 — Reverse Windows vendor client 2025 เทียบ 2026 แบบ offline

## เป้าหมาย

รอบนี้ทำต่อจาก R33 โดยไม่ย้อนทดสอบฮาร์ดแวร์เดิม เป้าหมายคือเช็ก vendor Windows client รุ่น `27Nov2025` ซึ่งเป็น binary คนละ build กับรุ่น `2026-04-08` ว่ามี hidden updater, stock backup หรือ arbitrary flash readback ที่รุ่น 2026 ไม่มีหรือไม่

**โหมดงาน: OFFLINE 100%** — ไม่มีการเปิด USB/HID/BLE/serial, ไม่มีการรัน vendor EXE, ไม่มี packet ไปที่บอร์ด และ `FLASH_GATE=CLOSED` ตลอดรอบ

## ไฟล์ vendor ที่ยืนยันตัวตน

### Windows 2025
- ขนาด `3,300,864` bytes
- SHA256 `fde7b0f61ec62ffb6bcda5a921128f531bca84939b6f1f95c8ab2f14c453d1f9`
- .NET MethodDef `4,978`
- TypeDef `896`
- Field `2,291`
- ManifestResource `5`

มี protected resource แยกของตัวเอง:
- ขนาด `605,569` bytes
- SHA256 `71667130e0f1dbafbe9087428b061862bf9895e173859bdb6984fb7b05ca0e43`

จึงยืนยันได้ว่า 2025 ไม่ใช่การคัดลอก EXE 2026 มาเปลี่ยนชื่อ

### Windows 2026 (ฐานที่ R31–R32 วิเคราะห์แล้ว)
- ขนาด `3,307,008` bytes
- SHA256 `3ca54171c53f7badd963ffe6851b8b3e2faf8aee8ba2afcb7040990e22ae09b2`
- protected resource `607,967` bytes
- protected resource SHA256 `a46885bb2f09a600f6f16e6206f49d304ca829d441c5077b360b25ac8e6a33aa`

## ผลเทียบ native HID/Win32 surface

ชุด P/Invoke ของ 2025 และ 2026 **ตรงกันทั้งชุด 21 รายการ** รวมถึง:
- `HidD_GetInputReport`
- `HidD_SetOutputReport`
- `HidD_SetFeature`
- `ReadFile`
- `WriteFile`
- `CreateFile`
- HID descriptor/setupapi helpers

ดังนั้น 2025 ไม่มี native flash/programmer API เพิ่มขึ้นจาก 2026 ที่เห็นใน metadata

> การมี `GetInputReport`/`ReadFile` หมายถึงมี receive transport เท่านั้น ไม่ใช่หลักฐานว่ามี arbitrary flash readback

## UFE command set

ค่าคงที่ของ 2025 ตรงกับ 2026 ทุกตัว:

- `0x57` WRITE_ACTUATOR
- `0x58` READ_SENSOR_ACTUATOR
- `0x59` READ_SENSOR_ACTUATOR_JSON
- `0x60` RESPONSE_READ_SENSOR_ACTUATOR
- `0x61` READ_SENSOR_FIFO
- `0x62` RESPONSE_FIFO_SENSOR
- `0x63` READ_SENSOR_ACTUATOR_BULK
- `0x64` RESPONSE_READ_SENSOR_ACTUATOR_BULK
- `0x82` CONTINUE_BULK_SEND

นี่สนับสนุนว่า vendor client 2025 ใช้ UFE object-model transport ตระกูลเดียวกับ 2026 ไม่ได้เผย command family สำหรับ flash dump เพิ่ม

## ค้น hidden backup/update vocabulary

Static scan ทั้ง method/type metadata และ raw executable ปี 2025 ไม่พบ candidate ของ:

`backup`, `dump`, `upload`, `export`, `readflash`, `flashread`, `upgrade`, `erase`, `commit`

คำว่า `firmware` ที่พบเป็น `FirmwareRevisionString` ใน BLE/GATT metadata เท่านั้น ส่วน `boot` ที่พบเป็น HID keyboard/mouse boot report usages ไม่ใช่ bootloader updater

เมธอดหลัก `Hid::Read`, `Hid::Write`, `HIDInterface::Send`, `HIDInterface::HidDataReceived` และ UFE bridge ถูก protector ทำเป็น on-disk stubs เหมือน 2026 จึงไม่ตีความ stub ว่าเป็น implementation จริง แต่ R32 ได้เปิด protected 2026 path แล้วและปลายทางจบที่ Sensor/Actuator/FIFO/Device Description เท่านั้น

## ตรวจ vendor full dataset

ตรวจ `GoloPine_DSP_Full_Dataset` ทั้ง `54` entries แล้ว ไม่พบ:
- `.bin`
- `.img`
- `.hex`
- `.mva`
- `.fw`
- `.rom`
- `.ota`
- `.dfu`

และไม่มีชื่อที่บ่งชี้ `factory firmware`, `recovery image` หรือ `bootloader image`

## ข้อสรุป R34

1. Windows client 2025 เป็น build คนละตัวจริง แต่ **ไม่เพิ่ม UFE command family หรือ native transport สำหรับ stock backup/flash dump** เมื่อเทียบกับ 2026
2. ไม่พบ production firmware/recovery image ใน vendor dataset ที่มีอยู่
3. ยัง **ไม่พิสูจน์** arbitrary flash readback จาก host
4. ยัง **ไม่พิสูจน์** production flash layout
5. จึงยังไม่มี rollback image ที่ผ่านเกณฑ์
6. `FLASH_GATE=CLOSED`

### สิ่งที่ R34 ปิดได้

สามารถหยุดวน reverse vendor Windows 2025/2026 เพื่อหา hidden stock-backup command ได้แล้ว เว้นแต่มี vendor package ใหม่ที่มี firmware/recovery payload จริงเข้ามาเป็นหลักฐานใหม่

### Blocker ที่เหลือจริง

เป้าหมาย TRUE 7CH firmware ถูกล็อกอยู่ที่ **production recovery/rollback evidence** ไม่ใช่ EQ/UFE/Windows tuning logic อีกต่อไป การเปิด gate โดยเดา layout หรือยิง unknown write จะขัดกับ safety condition ของโปรเจกต์เอง
