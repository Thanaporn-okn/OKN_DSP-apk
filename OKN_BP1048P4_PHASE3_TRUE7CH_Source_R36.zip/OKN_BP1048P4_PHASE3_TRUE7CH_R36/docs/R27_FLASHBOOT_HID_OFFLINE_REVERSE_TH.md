# R27 — Flashboot HID transport + `upinfo` / `cxxx` semantics (OFFLINE ONLY)

วันที่: 2026-09-19

## ขอบเขต

R27 ต่อจาก R26 โดย **ไม่ส่ง USB/Bluetooth/OBEX/GATT command ไปที่บอร์ด** และไม่เข้า flashboot บน hardware เป้าหมายคือแก้ transport inference ของ R26 ด้วย machine-code evidence, แกะ `upinfo` และ `cxxx` ให้พอพิสูจน์ side effects และตัดสินว่ามีคำสั่ง identity/version/read ที่ปลอดภัยหรือไม่

ข้อห้ามยังคงเดิม: ไม่ Feature `0x55/0xAA`, ไม่ ACP `0x00/0x11`, ไม่ OBEX PUT/header/body, ไม่ `.mva`, ไม่ erase/program/commit/apply/reset และไม่เดา production flash layout.

## 1. Correction สำคัญต่อ R26: updater command transport เป็น HID Data report ไม่ใช่ BOT CDB

R26 พบ `USBC`/CBW code และ command table ใน flashboot แล้วตีความว่า updater command น่าจะวิ่งผ่าน USB Mass Storage BOT. R27 disassemble flashboot เพิ่มและ cross-check กับ SDK source แล้วพบว่า **ส่วน updater command จริงรับ/ส่งผ่าน HID class control report**.

### Host -> flashboot: HID Output report 256 bytes

ใน reference flashboot ฟังก์ชันรับ command ตรวจ USB SETUP packet ดังนี้:

- `0x2BAC`: `bmRequestType == 0x21`
- `0x2BB4`: `bRequest == 0x09` (`SET_REPORT`)
- `0x2BB8`: Report ID low byte (`Setup[2]`) ต้องเป็น `0`
- `0x2BC2`: Report Type (`Setup[3]`) ต้องเป็น `0x02` = Output report
- จากนั้นเรียก receive helper **4 ครั้ง × 64 bytes** = 256-byte command buffer

SDK source `otg_device_standard_request.c` ตรงกัน: HID_DATA interface เมื่อ `(Setup[3] == 0x02) && (Setup[0] == 0x21)` จะเรียก `hid_recive_data()` และ `HIDUsb_Rx(Request,256)`.

### Flashboot -> host: HID Input report 256 bytes

ฟังก์ชัน `0x4BF6` ตรวจ:

- `0x4C12`: `bmRequestType == 0xA1`
- `0x4C1A`: `bRequest == 0x01` (`GET_REPORT`)
- `0x4C22`: Report Type == `0x01` = Input report
- `0x4C2A`: `wLength` high byte == `1`, จึงเป็น 256 bytes
- แล้วเรียก send helper `0x9436` ด้วย length `256`

SDK sourceตรงกัน: `(Setup[3] == 0x01) && (Setup[0] == 0xA1)` -> `hid_send_data()` -> `OTG_DeviceControlSend(hid_send,256,6)`.

### บทบาทของ Feature report 8 bytes

Feature report (`Report Type 0x03`) อยู่ใน **pre-flashboot entry/arming path** ของ app firmware (`0x55/0xAA` -> GET_REPORT -> `start_up_grate(...)`). มันไม่ใช่ 256-byte command payload ของ flashboot.

ดังนั้น `USBC`/MSC/BOT ที่พบใน image ถูก reclassify เป็น **co-resident UDisk/storage-class implementation**. Reference config `UP_PORT=0x0D` เปิดทั้ง PCTOOL และ UDisk ได้ จึงสมเหตุผลที่ BOT code อยู่ใน image เดียวกัน แต่ **ห้ามใช้ BOT/CDB เป็น updater framing ต่อจาก R27**.

## 2. ASCII command อยู่ที่ต้น 256-byte HID Output report

Command handler ใช้ helper ที่ recover ได้ว่า:

- `0xADFC` = `strlen`
- `0xACDC` = `memcmp`

แต่ละ handler เอา pointer C-string เช่น `chiperas`, `upinfo`, ... หา length แล้ว `memcmp` กับต้น command buffer. จึงได้ framing ขั้นต่ำที่พิสูจน์ได้ว่า **ASCII command name เริ่มที่ report offset 0**; field เฉพาะ command อยู่ใน bytes ถัดไป.

Command vocabulary ยังเป็น 8 ตัวเดิม:

| command | handler | R27 classification |
|---|---:|---|
| `cxxx` | `0x4C8A..0x50B2` | BLOCK — metadata/state/MMIO side effects |
| `chiperas` | `0x50B2..0x517C` | BLOCK — direct erase call `0x44F0` |
| `bootdat` | `0x517C..0x52D4` | BLOCK — erase/program (`0x44F0`,`0x45EE`) |
| `codedata` | `0x52D4..0x5406` | BLOCK — erase/program (`0x44F0`,`0x45EE`) |
| `constdat` | `0x5406..0x550A` | BLOCK — erase/program (`0x44F0`,`0x45EE`) |
| `cnfgdat` | `0x550A..0x560E` | BLOCK — erase/program (`0x44F0`,`0x45EE`) |
| `btupdat` | `0x560E..0x575E` | BLOCK — update + direct erase `0x44F0` |
| `upinfo` | `0x575E..0x57BE` | BLOCK — completion/finalization + MMIO side effects |

## 3. `upinfo` ถูกปิดเป็นทาง read-only อย่างเด็ดขาด

ชื่อ `upinfo` ดูเหมือน “update info” แต่ machine code บอกว่าไม่ใช่ getter/version query.

หลัง match string `upinfo`:

- อ่าน command-buffer byte `+8` และบังคับให้เป็น `0x6F` (`'o'`)
- อ่าน byte `+9` และบังคับให้เป็น `0x6B` (`'k'`)
- success diagnostic คือ `pc upgrata ok`
- success แล้วเรียก `0x90F4`, `0x918C`, `0x9140`
- error path เรียก `0x9F58`

สาม success helpers ทำ read-modify-write ที่ MMIO `0x40030004`:

- `0x90F4`: clear mask `0x00000003`
- `0x918C`: clear mask `0x00000300`
- `0x9140`: clear mask `0x00000060`

ส่วน `0x9F58` เขียนค่า `1` ไปที่ MMIO `0x40022008`.

ดังนั้น `upinfo` เป็น **upgrade-completion/finalization state command** ที่เปลี่ยน hardware state ไม่ใช่ identity/version/read command. R27 จึงห้าม live probe โดยไม่มีข้อยกเว้น.

## 4. `cxxx` ก็ไม่ใช่ safe read

`cxxx` เป็น metadata/validation command จริง แต่ไม่ใช่ passive parser อย่างเดียว:

- parse/validate fields ที่เกี่ยวกับ boot/code length+CRC, const/config offset+length และ encryption compatibility
- เขียน status/ACK bytes ใน command buffer เช่น `0xFF`, `0x33`, `0x55`
- เรียก `0x4BF6` เพื่อส่ง 256-byte HID Input response
- บาง branch เรียก `0x90F4`, `0x918C`, `0x9140` ซึ่งเป็น MMIO state-changing helpers ชุดเดียวกับ `upinfo`

แม้ `cxxx` ไม่มี direct call ไป erase/program primitive `0x44F0/0x45EE` ใน handler นี้ แต่มี state transition ชัดเจน จึง **ไม่ผ่าน strict READ-ONLY gate**.

## 5. สถานะของคำสั่งอื่น

`chiperas`, `bootdat`, `codedata`, `constdat`, `cnfgdat`, `btupdat` ถูกปิดอยู่แล้วและ R27 ยืนยันเพิ่มจาก direct call graph:

- `0x44F0` = erase-family primitive ใน flow เหล่านี้
- `0x45EE` = program/write-family primitiveใน data stages

จึงไม่มีเหตุผลให้ทดสอบคำสั่งเหล่านี้บนบอร์ด.

## 6. Safe identity/version/read command

**ไม่พบใน command set นี้**.

หลัง R27:

- `upinfo` = stateful completion/finalization
- `cxxx` = stateful metadata validation/ACK
- 6 command ที่เหลือ = erase/program/update

ดังนั้น reference flashboot command set 8 ตัวนี้ไม่มี candidate ที่ผ่านเกณฑ์ “พิสูจน์ก่อนว่าไม่เปลี่ยน state” สำหรับ Samsung S25+ live probe.

## 7. ผลต่อ Android / hardware

R27 **ไม่เพิ่ม USB code ลง Android** และไม่สร้างปุ่ม flashboot command ใหม่. Android module ที่อยู่ใน source ถูก relabel เป็น R27 เพื่อ version continuity เท่านั้น; functionality ยังคง Bluetooth discovery/SDP/GATT UUID enumeration แบบ READ-ONLY เดิม.

ผู้ใช้ **ไม่จำเป็นต้องติดตั้ง R27 APK** เพื่อทำงาน R27 และไม่ต้องต่อ USB กับบอร์ด.

## 8. Next offline target

ขั้นต่อไปควรทำ offline ต่อ:

1. reverse package-maker / MVA metadata semantics ต่อเพื่อเข้าใจ recovery requirements โดยไม่สร้างหรือส่ง `.mva`;
2. หา independent flash readback/identity path จาก source/official updater ที่ **ไม่ต้องเข้า state-changing flashboot**;
3. หา production layout/backup/recovery proof จาก official artifact/dump ก่อน unlock hardware write;
4. ถ้าไม่มี readback/recovery path ให้คง firmware write เป็น BLOCKED แทนการเดา.

## Decision R27

- Updater command carriage: **USB HID Data class control reports, 256 bytes**.
- R26 BOT/CDB updater inference: **SUPERSEDED / corrected**; BOT is co-resident UDisk evidence.
- `upinfo`: **NOT READ-ONLY; BLOCKED**.
- `cxxx`: **NOT READ-ONLY; BLOCKED**.
- Safe identity/version/read command: **NONE PROVEN**.
- Hardware flashboot probe: **BLOCKED**.
- Erase/program/commit/apply: **BLOCKED**.
