# R24 Offline Reverse — MVSilicon Bluetooth / OBEX OTA

อัปเดต: 2026-09-19

## ข้อสรุปที่ยืนยันจาก SDK ที่แนบ

1. `BT_Audio_APP/bt_audio_app_src/inc/bt_config.h`
   - `BT_OBEX_SUPPORT` ถูกตั้งเป็น `DISABLE` ใน reference app config ทั้ง branch A2DP enabled/disabled.
   - ภายใต้ `#if (BT_OBEX_SUPPORT == ENABLE)` มีบรรทัด `//#define MVA_BT_OBEX_UPDATE_FUNC_SUPPORT` ซึ่งยังถูก comment ไว้.
   - ดังนั้น source reference ที่แนบ **ไม่ได้เปิด OBEX/MVA OTA โดย default**.

2. `MVsB1_Base_SDK/middleware/bluetooth/src/bt_app_func.c`
   - `GetSupportProfiles()` เพิ่ม `BT_PROFILE_SUPPORTED_OBEX` เฉพาะเมื่อ `BT_OBEX_SUPPORT == ENABLE`.
   - `ObexAppCallbackRegister(BtObexCallback)` ก็ถูก compile เฉพาะเมื่อ `BT_OBEX_SUPPORT == ENABLE`.

3. `MVsB1_Base_SDK/middleware/bluetooth/src/bt_obex_app.c`
   - generic OBEX callback ถูก compile เมื่อ `BT_OBEX_SUPPORT == ENABLE`.
   - `ObexUpdateProc(param)` และ `ObexUpgradeEnd()` จะถูกเรียกเพิ่มเฉพาะเมื่อ `MVA_BT_OBEX_UPDATE_FUNC_SUPPORT` ถูก define.

4. `BT_Audio_APP/bt_audio_app_src/services/bt_stack_service.c`
   - task `bt_obex_upgrate` ถูกสร้างเมื่อ `MVA_BT_OBEX_UPDATE_FUNC_SUPPORT` ถูก define.

5. `BT_Audio_APP/bt_audio_app_src/apps/bt_obex_upgrade.c`
   - staging offset = `0x200000`.
   - `BT_OBEX_LENGTH` ตั้ง `obex_start = 1` โดยไม่รอ CRC/apply.
   - task เมื่อเห็น `obex_start == 1` เรียก `SpiFlashErase(BLOCK_ERASE, FLASH_MVA_UPDATE_START_OFFSET/65536, 1)`.
   - จากนั้น BODY ถูกเขียนเข้า flash staging area.
   - เมื่อ disconnect และชื่อไฟล์ผ่าน `.mva` + CRC ผ่าน จึงเรียก `ROM_BankBUpgradeApply(1, 0x200000)` และ reset.

### Safety consequence

ห้ามใช้ OBEX PUT แม้จะตั้งใจส่งไฟล์ทดสอบเล็ก ๆ หรือ header อย่างเดียว เพราะ source แสดงว่า LENGTH event สามารถเริ่ม erase staging flash ได้แล้ว. R24 จึงไม่มี RFCOMM socket, ไม่มี OBEX session, ไม่มี file picker และไม่มี payload.

## SDP reverse จาก `libBtStack.a`

แตก `obex_sdp.o` แบบ offline จาก:
`MVsB1_Base_SDK/middleware/bluetooth/libBtStack.a`

rodata ที่ยืนยัน:

- Service name: `Object Push`
- Service Class ID: `0x1105`
- Profile descriptor UUID: `0x1105`
- Protocol sequence: L2CAP `0x0100` -> RFCOMM `0x0003` -> OBEX `0x0008`
- RFCOMM channel byte ใน object record = `0x63`

UUID ที่ Android ควรตรวจแบบ read-only ผ่าน Classic SDP:
`00001105-0000-1000-8000-00805f9b34fb`

## ขอบเขตการตีความ R24

- ถ้า SDP พบ `0x1105`: พิสูจน์ว่า stock firmware expose standard Object Push/OPP/OBEX prerequisite.
- **ยังไม่พิสูจน์** `MVA_BT_OBEX_UPDATE_FUNC_SUPPORT` เพราะ MVA handler ถูกซ่อนอยู่หลัง callback เดียวกันและไม่ได้สร้าง service UUID เฉพาะใหม่ในหลักฐาน SDK ที่พบ.
- ถ้า SDP ไม่พบ `0x1105`: reference path สำหรับ OBEX OTA ไม่ได้ถูก expose ในผล discovery รอบนั้น; แต่ยังไม่ควรสรุปว่าทุก proprietary/hidden path ไม่มีอยู่.
- BLE service `AB00` เป็น UFE/tuning path ที่ reverse ได้ก่อนหน้า ไม่ใช่หลักฐาน OBEX OTA.

## R24 Android probe

อนุญาตเฉพาะ:
- paired/cached UUID inspection
- Classic inquiry
- `BluetoothDevice.fetchUuidsWithSdp()`
- BLE scan + advertised UUID collection
- BLE `connectGatt()` -> `discoverServices()` -> enumerate UUID/properties -> disconnect

ไม่ทำ:
- USB APIs ทุกชนิด
- RFCOMM socket
- OBEX connect/PUT
- file open/send
- characteristic read/write/subscribe
- `.mva`
- erase/program/commit/apply/reset
