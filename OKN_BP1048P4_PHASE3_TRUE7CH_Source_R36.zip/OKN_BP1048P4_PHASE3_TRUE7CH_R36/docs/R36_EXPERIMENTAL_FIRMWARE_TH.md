# R36 — Experimental firmware integration สำหรับ BP1048P4

## เป้าหมาย
เริ่มสร้าง firmware ใหม่เองหลังผู้ขายไม่ให้ factory image โดยใช้บอร์ดทดลองที่ยอม brick ได้ และเก็บบอร์ด stock อย่างน้อยหนึ่งตัวไว้เป็น reference

## หลักฐาน SDK ที่ยืนยันแล้ว
Public SDK ถูก pin ที่ commit `8105bd864b04995d81c9f9ae77cb158259f39015`.
`app_config.h` มี `CFG_CHIP_BP1048P4`: 48-pin, professional, max 320 MHz, internal flash 32 Mbit. Build เดิมใช้ Andes NDS32 `d1088-spu`, medium code model และ DSP extension.

`audio_core_api.h` แสดงว่า sink เป็น stereo และมี `LeftVol/RightVol`; `audio_vol.c` ระบุว่า digital gain 4095 = 0 dB และระบบเรียก `AudioCoreSinkVolSet()` แยกซ้าย/ขวา. จึงใช้ DAC0 เป็น CH1/CH2 ได้โดยไม่แตะ EQ. CH3->DACX เป็น mapping ทดลองตาม topology ที่ reverse จาก stock และต้องตรวจบน sacrificial board.

`i2s_interface.c` ยืนยันว่า `AudioI2S0_DataSet/AudioI2S1_DataSet` รับ `Len` เป็น stereo frame count; 16-bit ส่ง `Len*4` byte และ >16-bit ส่ง `Len*8` byte. R36 จึง wrap I2S0/I2S1 และปรับ CH4/5, CH6/7 เฉพาะเมื่อ word length เป็น 16-bit. ใช้ scratch buffer 512 frames เพื่อไม่แก้ shared PCM ของ caller.

## TRUE 7CH mapping ใน R36
- CH1: DAC0 Left
- CH2: DAC0 Right
- CH3: DACX Left+Right (experimental physical mapping)
- CH4: I2S0 Left
- CH5: I2S0 Right
- CH6: I2S1 Left
- CH7: I2S1 Right

Gain IDs 22..28, range -70..+6 dB, step 0.5 dB. ไม่ใช้ EQ/Band1/Tone Control ทำ volume.

## สิ่งที่สร้างแล้ว
- `firmware/src/okn_r36_sdk_bridge.c`
- `firmware/include/okn_r36_sdk_bridge.h`
- host tests ของ gain conversion / UFE / I2S lane isolation
- GitHub Actions `R36_ANDES_TARGET_COMPILE.yml` สำหรับ compile ด้วย NDS32 จริงกับ SDK ที่ pin ไว้

## สิ่งที่ยังไม่อ้างว่าเสร็จ
Local runtime นี้ไม่มี full Andes toolchain+SDK libraries จึงยังไม่อ้างว่ามี target `.bin` ที่ link ผ่าน. Workflow จะตรวจ NDS32 ABI compile บน GitHub Actions ก่อน. Full BT_Audio_APP generated Makefile ไม่ได้อยู่ใน public repo จึงต้องสร้าง build graph ในรอบถัดไปแทนการปลอมผล build.

R36 ไม่มีคำสั่ง erase/program/flash; ยังไม่ให้ใช้กับบอร์ดหลัก.

## P4 overlay gate
`enable_bp1048p4.py` จะทำงานเฉพาะเมื่อ SDK git HEAD ตรง commit ที่ pin ไว้ และจะ refuse หาก pattern เดิมไม่ตรง. `check_sdk_files.py` ตรวจ Git blob SHA-1 ของ header/linker สำคัญก่อน patch เพื่อป้องกันการ build กับ SDK คนละ revision แบบเงียบ ๆ.
