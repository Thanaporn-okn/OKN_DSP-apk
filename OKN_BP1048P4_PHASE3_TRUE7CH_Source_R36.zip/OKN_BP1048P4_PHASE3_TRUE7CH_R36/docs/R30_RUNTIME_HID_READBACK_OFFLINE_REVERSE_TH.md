# R30 — Normal Runtime HID / Flash Readback Offline Reverse

สถานะ: **OFFLINE ONLY / FAIL-CLOSED**  
ไม่มีการส่ง USB/Bluetooth/OBEX ไปบอร์ดจริง และไม่มี erase/program/commit/reset.

## เป้าหมาย

R29 พิสูจน์ว่าชิปมี `SpiFlashRead()` ภายใน firmware แต่ยังไม่มี host-exposed arbitrary readback. R30 จึง pivot มาที่ normal-runtime USB HID tuning dispatcher โดยตรง เพื่อดูว่ามีเส้นทาง `SpiFlashRead -> HID -> host` ที่ใช้ backup stock firmware ได้หรือไม่.

## 1. HID fingerprint ของ SDK ตรงกับ runtime ที่เคยสังเกตบนบอร์ด

Reference SDK `otg_device_descriptor.h` กำหนด HID data report descriptor เป็น:
- Usage Page `0xFF00`
- Usage `0x55AA`
- Input 256 bytes
- Output 256 bytes
- Feature 8 bytes

ใน configuration `AUDIO_MIC` HID data อยู่ interface 4. Fingerprint นี้ตรงกับ runtime ที่เคยเก็บจากบอร์ด: IF4 + FF00/55AA + Input256/Output256/Feature8. จึงเป็น **strong SDK-family/runtime correlation** แต่ยังไม่ใช่ production firmware binary proof.

## 2. Transport ของ normal tuning protocol

`otg_device_standard_request.c` แยก report type ชัดเจน:
- SET_REPORT Output: `bmRequestType=0x21`, report type `0x02` -> รับ 256 bytes -> `HIDUsb_Rx(Request,256)`
- GET_REPORT Input: `bmRequestType=0xA1`, report type `0x01` -> ส่ง `hid_send` 256 bytes
- Feature report type `0x03` เป็นคนละเส้นทางและมี upgrade arm/jump logic; ยังคง BLOCKED

`communication.c` parse frame เป็น:
`A5 5A <Control> <PayloadLength> <Payload...> 16`
แล้ว dispatch ไป `Communication_Effect_Config()`.

## 3. Control 0x00 เป็น version/identity response ใน reference source

`Communication_Effect_0x00()` ทำเพียงสร้าง response:
`A5 5A 00 07 30 <effect major> <effect minor> <effect patch> <AudioLib version...> 16`

ไม่มี `SpiFlashRead`, erase หรือ program ใน handler นี้. `0x30` ถูก comment ว่า B1X. ดังนั้น **ใน reference source เท่านั้น** control 0x00 เป็น source-level non-mutating identity/version path.

แต่ R30 **ไม่เปิด live probe** เพราะ checkpoint เดิมสั่งห้าม repeat ACP CTRL 0x00/0x11 experiments และยังไม่มี production-binary equivalence proof.

## 4. Control 0x11 เป็น dual-use และมีเส้นทางเขียน flash อันตราย

`Communication_Effect_0x11()` มีสอง branch:
- ถ้า `payload[0] == 0x01`: เข้าฟังก์ชัน user-data write
- อื่น ๆ: ส่ง B1X/effect version response

write branch สร้าง 24-bit flash offset จาก payload[1..3], ใช้ payload[4] เป็น length แล้ว `MV_UserWriteData()` ทำ:
1. `SpiFlashRead(...,4096)`
2. `SpiFlashErase(SECTOR_ERASE,...)`
3. แก้ buffer
4. `SpiFlashWrite(...,4096)`
5. `SpiFlashRead(...,128)`
6. `memcmp` verify

ดังนั้นห้ามมอง `0x11` เป็น read command จากชื่อหรือจาก version branch เพราะ control เดียวกันมี erase/program path.

## 5. คำตอบเรื่อง backup/readback

ค้น reference `communication.c` แล้วพบ flash primitives เพียง 4 call sites:
- `SpiFlashRead` 2 จุด
- `SpiFlashErase` 1 จุด
- `SpiFlashWrite` 1 จุด

ทั้งหมดอยู่ใน user write helper ของ control 0x11. ไม่มี branch ที่อ่าน arbitrary flash แล้วคัดลอก `pUserData` ไป `tx_buf` เพื่อส่งกลับ host.

ดังนั้น R30 ได้ข้อสรุปที่แข็งแรงขึ้นว่า:
- normal runtime HID **มี tuning/query transport จริง**
- normal runtime source **มี internal flash read จริง**
- แต่ internal flash read ถูกใช้ประกอบ erase/write/verify
- **ยังไม่พบ arbitrary flash-read-to-host / stock backup command**

## 6. Recovery gate หลัง R30

- stock backup: **ไม่มี**
- full flash readback: **ยังไม่พิสูจน์**
- normal HID arbitrary readback: **ไม่พบใน reference source**
- flashboot arbitrary readback: **ยังไม่พบ**
- production layout: **ยังไม่พิสูจน์**
- live flash/update: **BLOCKED**

R30 จึงไม่มี Android hardware probe ใหม่ และไม่ต้องติดตั้ง APK ใหม่.

## 7. ขั้นถัดไป

R31 ควร reverse ฝั่ง PC tool / protected Windows runtime ต่อ โดยใช้ framing ที่ R30 พิสูจน์แล้วค้นหา command/query path ที่อาจไม่ได้อยู่ใน public `communication.c`, และตรวจว่ามี hidden read/upload primitive หรือไม่. หากยังไม่มี host readback ต้องคง recovery gate ปิดต่อไป.
