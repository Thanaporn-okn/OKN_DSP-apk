package com.okn.dsp.btprobe;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothClass;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;
import android.provider.Settings;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * R29: Samsung S25+ SDK fingerprint / Bluetooth OTA evidence probe.
 *
 * Safety boundary:
 * - NO USB APIs.
 * - NO RFCOMM socket.
 * - NO OBEX PUT / file transfer.
 * - NO .mva file open or send.
 * - NO GATT characteristic read/write/subscribe.
 * - NO erase/program/commit/apply/reset command.
 *
 * The only active remote operations are:
 * 1) Bluetooth discovery / BLE scan.
 * 2) Classic SDP UUID discovery via BluetoothDevice.fetchUuidsWithSdp().
 * 3) BLE GATT connection + discoverServices(), followed by disconnect/close.
 */
public final class MainActivity extends Activity {
    private static final int REQ_BT_PERMS = 2401;
    private static final long BLE_SCAN_MS = 15000L;

    // SDK reverse: libBtStack.a / obex_sdp.o advertises standard OBEX Object Push.
    private static final UUID UUID_OBJECT_PUSH = uuid16(0x1105);
    private static final UUID UUID_SERIAL_PORT = uuid16(0x1101);
    private static final UUID UUID_UFE_SERVICE_AB00 = uuid16(0xAB00);
    private static final UUID UUID_UFE_CHAR_AB01 = uuid16(0xAB01);
    private static final UUID UUID_UFE_CHAR_AB02 = uuid16(0xAB02);
    private static final UUID UUID_UFE_CHAR_AB03 = uuid16(0xAB03);
    private static final UUID UUID_CCCD_2902 = uuid16(0x2902);
    private static final String BT_BASE_SUFFIX = "-0000-1000-8000-00805f9b34fb";

    private BluetoothAdapter adapter;
    private BluetoothLeScanner bleScanner;
    private final Handler main = new Handler(Looper.getMainLooper());

    private TextView log;
    private Spinner deviceSpinner;
    private ArrayAdapter<String> spinnerAdapter;

    private final List<DeviceEntry> devices = new ArrayList<>();
    private final Map<String, DeviceEntry> byKey = new LinkedHashMap<>();
    private final Map<String, List<UUID>> advertisedUuids = new LinkedHashMap<>();
    private final Map<String, List<UUID>> classicUuids = new LinkedHashMap<>();
    private final Map<String, List<UUID>> gattServiceUuids = new LinkedHashMap<>();
    private final Map<String, String> bleLogFingerprints = new LinkedHashMap<>();
    private final Map<String, String> rawAdvHex = new LinkedHashMap<>();
    private final Map<String, Boolean> sdkAb00Shape = new LinkedHashMap<>();
    private final Set<String> sdpRequested = new LinkedHashSet<>();

    private boolean classicDiscoveryRunning;
    private boolean bleScanRunning;
    private BluetoothGatt activeGatt;

    private final BroadcastReceiver btReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                BluetoothDevice d = getBtDevice(intent);
                if (d == null) return;
                short rssi = intent.getShortExtra(BluetoothDevice.EXTRA_RSSI, Short.MIN_VALUE);
                addOrUpdateDevice(d, "CLASSIC", null);
                add("CLASSIC FOUND: " + describe(d) + (rssi == Short.MIN_VALUE ? "" : " RSSI=" + rssi));
                logBluetoothClass(d);
                return;
            }
            if (BluetoothAdapter.ACTION_DISCOVERY_STARTED.equals(action)) {
                classicDiscoveryRunning = true;
                add("Classic discovery: STARTED");
                return;
            }
            if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
                classicDiscoveryRunning = false;
                add("Classic discovery: FINISHED");
                return;
            }
            if (BluetoothDevice.ACTION_UUID.equals(action)) {
                BluetoothDevice d = getBtDevice(intent);
                if (d == null) return;
                ArrayList<UUID> uuids = parcelUuidArrayToList(intent);
                String key = deviceKey(d);
                classicUuids.put(key, uuids);
                add("=== CLASSIC SDP UUID RESULT ===");
                add("Device: " + describe(d));
                if (uuids.isEmpty()) add("UUIDs: none returned (empty can mean successful discovery with zero UUIDs; null/timeout is logged as empty by this UI).");
                for (UUID u : uuids) add("  SDP UUID " + u + "  " + uuidLabel(u));
                if (uuids.contains(UUID_OBJECT_PUSH)) {
                    add("R29 SIGNAL: Object Push 0x1105 PRESENT -> standard OPP/OBEX service is exposed.");
                    add("IMPORTANT: this proves the OBEX prerequisite only; it does NOT prove MVA_BT_OBEX_UPDATE_FUNC_SUPPORT is compiled in.");
                } else {
                    add("R29 SIGNAL: Object Push 0x1105 NOT OBSERVED in this SDP result.");
                }
                if (uuids.contains(UUID_SERIAL_PORT)) add("Note: Serial Port 0x1101 present; SDK reference enables SPP by default. This is not OTA evidence.");
                add("=== END SDP UUID RESULT ===");
            }
        }
    };

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult result) {
            BluetoothDevice d = result.getDevice();
            ScanRecord record = result.getScanRecord();
            List<UUID> serviceUuids = new ArrayList<>();
            if (record != null && record.getServiceUuids() != null) {
                for (ParcelUuid p : record.getServiceUuids()) if (p != null) serviceUuids.add(p.getUuid());
            }
            String key = deviceKey(d);
            advertisedUuids.put(key, serviceUuids);
            addOrUpdateDevice(d, "BLE", serviceUuids);

            boolean connectable = Build.VERSION.SDK_INT < 26 || result.isConnectable();
            String raw = record == null || record.getBytes() == null ? "" : hex(record.getBytes());
            rawAdvHex.put(key, raw);
            String fingerprint = serviceUuids.toString() + "|connectable=" + connectable + "|raw=" + raw;
            String prior = bleLogFingerprints.put(key, fingerprint);
            if (!fingerprint.equals(prior)) {
                StringBuilder line = new StringBuilder("BLE FOUND: ").append(describe(d))
                        .append(" RSSI=").append(result.getRssi());
                if (Build.VERSION.SDK_INT >= 26) line.append(" connectable=").append(result.isConnectable());
                add(line.toString());
                if (!serviceUuids.isEmpty()) {
                    for (UUID u : serviceUuids) add("  ADV UUID " + u + "  " + uuidLabel(u));
                }
                if (!raw.isEmpty()) add("  ADV RAW " + raw);
                if (serviceUuids.contains(UUID_UFE_SERVICE_AB00)) {
                    add("  Known GoloPine UFE service AB00 advertised (tuning/control path; NOT OTA proof).");
                }
            }
        }

        @Override public void onScanFailed(int errorCode) {
            bleScanRunning = false;
            add("BLE scan failed: errorCode=" + errorCode);
        }
    };

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            if (newState == BluetoothProfile.STATE_CONNECTED && status == BluetoothGatt.GATT_SUCCESS) {
                addUi("GATT connected read-only: " + describe(gatt.getDevice()));
                boolean started;
                try {
                    started = gatt.discoverServices();
                } catch (SecurityException se) {
                    addUi("discoverServices permission error: " + safe(se.getMessage()));
                    closeGatt(gatt);
                    return;
                }
                addUi("GATT discoverServices started=" + started + " (no characteristic read/write follows)");
                if (!started) closeGatt(gatt);
                return;
            }
            if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                addUi("GATT disconnected: status=" + status);
                closeGatt(gatt);
                return;
            }
            if (status != BluetoothGatt.GATT_SUCCESS) {
                addUi("GATT state error: status=" + status + " state=" + newState);
                closeGatt(gatt);
            }
        }

        @Override public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            addUi("=== BLE GATT SERVICE RESULT ===");
            addUi("Device: " + describe(gatt.getDevice()) + " status=" + status);
            List<UUID> servicesSeen = new ArrayList<>();
            boolean ab01Shape = false;
            boolean ab02Shape = false;
            boolean ab03Shape = false;
            if (status == BluetoothGatt.GATT_SUCCESS) {
                for (BluetoothGattService s : gatt.getServices()) {
                    UUID su = s.getUuid();
                    servicesSeen.add(su);
                    addUi("SERVICE " + su + " type=" + (s.getType() == BluetoothGattService.SERVICE_TYPE_PRIMARY ? "primary" : "secondary") + " " + uuidLabel(su));
                    for (BluetoothGattCharacteristic c : s.getCharacteristics()) {
                        addUi("  CHAR " + c.getUuid() + " props=0x" + Integer.toHexString(c.getProperties()) + " (UUID/properties only)");
                        if (su.equals(UUID_UFE_SERVICE_AB00) && c.getUuid().equals(UUID_UFE_CHAR_AB01)) {
                            int need = BluetoothGattCharacteristic.PROPERTY_READ | BluetoothGattCharacteristic.PROPERTY_WRITE | BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE;
                            ab01Shape = (c.getProperties() & need) == need;
                        }
                        boolean hasCccd = false;
                        for (BluetoothGattDescriptor d : c.getDescriptors()) {
                            addUi("    DESC " + d.getUuid() + " (UUID only)");
                            if (d.getUuid().equals(UUID_CCCD_2902)) hasCccd = true;
                        }
                        if (su.equals(UUID_UFE_SERVICE_AB00) && c.getUuid().equals(UUID_UFE_CHAR_AB02)) {
                            ab02Shape = (c.getProperties() & BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0 && hasCccd;
                        }
                        if (su.equals(UUID_UFE_SERVICE_AB00) && c.getUuid().equals(UUID_UFE_CHAR_AB03)) {
                            ab03Shape = (c.getProperties() & BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0 && hasCccd;
                        }
                    }
                }
            }
            String gattKey = deviceKey(gatt.getDevice());
            gattServiceUuids.put(gattKey, servicesSeen);
            boolean exactAb00 = servicesSeen.contains(UUID_UFE_SERVICE_AB00) && ab01Shape && ab02Shape && ab03Shape;
            sdkAb00Shape.put(gattKey, exactAb00);
            if (servicesSeen.contains(UUID_UFE_SERVICE_AB00)) {
                addUi("R29 SIGNAL: GATT service AB00 PRESENT -> known BLE UFE tuning/control service is exposed; this is not OBEX OTA proof.");
                addUi("R29 SDK FINGERPRINT: AB01 read/write/write-no-response + AB02 notify/CCCD + AB03 notify/CCCD match=" + exactAb00);
            }
            if (servicesSeen.contains(UUID_OBJECT_PUSH)) {
                addUi("Note: 0x1105 appeared in GATT UUIDs, but SDK reverse identifies OTA transport as Classic OBEX/OPP SDP; use the SDP result as the relevant signal.");
            }
            addUi("No characteristic value was read, written, subscribed, or notified by R29.");
            addUi("=== END BLE GATT SERVICE RESULT ===");
            try { gatt.disconnect(); } catch (Throwable ignored) {}
            main.postDelayed(() -> closeGatt(gatt), 500L);
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        BluetoothManager manager = (BluetoothManager) getSystemService(BLUETOOTH_SERVICE);
        adapter = manager == null ? null : manager.getAdapter();
        buildUi();
        registerBtReceiver();
        add("R29 started: " + Build.MANUFACTURER + " " + Build.MODEL + " Android SDK=" + Build.VERSION.SDK_INT);
        add("Safety mode: discovery + SDP UUIDs + GATT service UUIDs only. No USB / RFCOMM / OBEX PUT / .mva / flash operations.");
        showPermissionStatus();
    }

    @Override protected void onDestroy() {
        stopScans();
        if (activeGatt != null) closeGatt(activeGatt);
        try { unregisterReceiver(btReceiver); } catch (Throwable ignored) {}
        super.onDestroy();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(20, 20, 20, 20);

        TextView title = new TextView(this);
        title.setText("OKN BP1048P4 R29 — Bluetooth/OTA Capability Probe\nREAD-ONLY • Samsung S25+\nNo OBEX PUT • No .mva • No USB probes • No flash write");
        title.setTextSize(18f);
        root.addView(title);

        deviceSpinner = new Spinner(this);
        spinnerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, new ArrayList<>());
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        deviceSpinner.setAdapter(spinnerAdapter);
        root.addView(deviceSpinner);

        root.addView(button("1) PERMISSIONS / BT STATUS", v -> showPermissionStatus()));
        root.addView(button("2) REQUEST NEARBY DEVICES PERMISSION", v -> requestBtPermissions()));
        root.addView(button("3) LOAD PAIRED + CACHED UUIDs", v -> loadBondedDevices()));
        root.addView(button("4) CLASSIC DISCOVERY (PASSIVE)", v -> startClassicDiscovery()));
        root.addView(button("5) BLE SCAN 15s (PASSIVE)", v -> startBleScan()));
        root.addView(button("6) STOP SCANS", v -> stopScans()));
        root.addView(button("7) SELECTED: FETCH CLASSIC SDP UUIDs", v -> fetchSelectedSdp()));
        root.addView(button("8) SELECTED: DISCOVER BLE GATT UUIDs", v -> discoverSelectedGatt()));
        root.addView(button("9) R29 CAPABILITY SUMMARY", v -> showCapabilitySummary()));
        root.addView(button("10) COPY WHOLE LOG", v -> copyLog()));
        root.addView(button("CLEAR LOG", v -> log.setText("")));

        log = new TextView(this);
        log.setTextIsSelectable(true);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(log);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
    }

    private Button button(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setOnClickListener(listener);
        return b;
    }

    private void registerBtReceiver() {
        IntentFilter f = new IntentFilter();
        f.addAction(BluetoothDevice.ACTION_FOUND);
        f.addAction(BluetoothDevice.ACTION_UUID);
        f.addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED);
        f.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(btReceiver, f, Context.RECEIVER_EXPORTED);
        else registerReceiver(btReceiver, f);
    }

    private void showPermissionStatus() {
        add("=== R29 PERMISSION / BT STATUS ===");
        add("SDK=" + Build.VERSION.SDK_INT + " target=36");
        add("Bluetooth adapter present=" + (adapter != null));
        if (adapter == null) return;
        try { add("Bluetooth enabled=" + adapter.isEnabled()); } catch (SecurityException e) { add("Bluetooth enabled: permission blocked"); }
        add("BLUETOOTH_SCAN=" + granted(Manifest.permission.BLUETOOTH_SCAN));
        add("BLUETOOTH_CONNECT=" + granted(Manifest.permission.BLUETOOTH_CONNECT));
        if (Build.VERSION.SDK_INT <= 30) add("ACCESS_FINE_LOCATION=" + granted(Manifest.permission.ACCESS_FINE_LOCATION));
        add("Android Bluetooth settings intent is available from system settings if Bluetooth is off; R29 does not force-enable it.");
        add("=== END STATUS ===");
    }

    private void requestBtPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            ArrayList<String> needed = new ArrayList<>();
            if (!granted(Manifest.permission.BLUETOOTH_SCAN)) needed.add(Manifest.permission.BLUETOOTH_SCAN);
            if (!granted(Manifest.permission.BLUETOOTH_CONNECT)) needed.add(Manifest.permission.BLUETOOTH_CONNECT);
            if (needed.isEmpty()) { add("Nearby Devices permissions already granted."); return; }
            requestPermissions(needed.toArray(new String[0]), REQ_BT_PERMS);
        } else if (!granted(Manifest.permission.ACCESS_FINE_LOCATION)) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_BT_PERMS);
        } else {
            add("Legacy Bluetooth/location permissions already granted.");
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_BT_PERMS) return;
        for (int i = 0; i < permissions.length; i++) {
            add("Permission " + permissions[i] + " => " + ((i < grantResults.length && grantResults[i] == PackageManager.PERMISSION_GRANTED) ? "GRANTED" : "DENIED"));
        }
    }

    private boolean granted(String permission) {
        if (Build.VERSION.SDK_INT < 23) return true;
        return checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean readyForScan() {
        if (adapter == null) { add("BLOCKED: device has no Bluetooth adapter."); return false; }
        if (Build.VERSION.SDK_INT >= 31 && !granted(Manifest.permission.BLUETOOTH_SCAN)) { add("BLOCKED: grant Nearby Devices / BLUETOOTH_SCAN first."); return false; }
        if (Build.VERSION.SDK_INT >= 31 && !granted(Manifest.permission.BLUETOOTH_CONNECT)) { add("BLOCKED: grant Nearby Devices / BLUETOOTH_CONNECT first."); return false; }
        if (Build.VERSION.SDK_INT <= 30 && !granted(Manifest.permission.ACCESS_FINE_LOCATION)) { add("BLOCKED: legacy scan needs location permission on this Android version."); return false; }
        try {
            if (!adapter.isEnabled()) {
                add("BLOCKED: Bluetooth is OFF. Open system Bluetooth settings and enable it.");
                try { startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); } catch (Throwable ignored) {}
                return false;
            }
        } catch (SecurityException e) {
            add("BLOCKED: Bluetooth permission error: " + safe(e.getMessage()));
            return false;
        }
        return true;
    }

    private void loadBondedDevices() {
        if (!readyForScan()) return;
        add("=== BONDED / CACHED UUID SNAPSHOT ===");
        try {
            Set<BluetoothDevice> bonded = adapter.getBondedDevices();
            add("Bonded count=" + bonded.size());
            for (BluetoothDevice d : bonded) {
                addOrUpdateDevice(d, "BONDED", null);
                add("BONDED: " + describe(d));
                logBluetoothClass(d);
                ParcelUuid[] cached = d.getUuids();
                if (cached != null) {
                    ArrayList<UUID> us = new ArrayList<>();
                    for (ParcelUuid p : cached) if (p != null) us.add(p.getUuid());
                    classicUuids.put(deviceKey(d), us);
                    for (UUID u : us) add("  CACHED UUID " + u + "  " + uuidLabel(u));
                } else add("  Cached UUIDs: null");
            }
        } catch (SecurityException e) {
            add("Bonded-device read blocked: " + safe(e.getMessage()));
        }
        add("=== END BONDED SNAPSHOT ===");
    }

    private void startClassicDiscovery() {
        if (!readyForScan()) return;
        stopBleScanOnly();
        try {
            if (adapter.isDiscovering()) adapter.cancelDiscovery();
            boolean ok = adapter.startDiscovery();
            add("Classic discovery requested=" + ok + ". This performs inquiry only; R29 does not pair or open RFCOMM.");
        } catch (SecurityException e) {
            add("Classic discovery permission error: " + safe(e.getMessage()));
        }
    }

    private void startBleScan() {
        if (!readyForScan()) return;
        try {
            if (adapter.isDiscovering()) adapter.cancelDiscovery();
            classicDiscoveryRunning = false;
            bleScanner = adapter.getBluetoothLeScanner();
            if (bleScanner == null) { add("BLE scanner unavailable."); return; }
            if (bleScanRunning) { add("BLE scan already running."); return; }
            bleScanRunning = true;
            bleScanner.startScan(scanCallback);
            add("BLE scan STARTED for " + (BLE_SCAN_MS / 1000L) + "s. Advertisement UUIDs only; no connection yet.");
            main.postDelayed(() -> {
                if (bleScanRunning) {
                    stopBleScanOnly();
                    add("BLE scan auto-stopped.");
                }
            }, BLE_SCAN_MS);
        } catch (SecurityException e) {
            bleScanRunning = false;
            add("BLE scan permission error: " + safe(e.getMessage()));
        }
    }

    private void stopScans() {
        if (adapter != null) {
            try { if (adapter.isDiscovering()) adapter.cancelDiscovery(); } catch (Throwable ignored) {}
        }
        stopBleScanOnly();
        classicDiscoveryRunning = false;
        add("Scans stopped.");
    }

    private void stopBleScanOnly() {
        if (bleScanner != null && bleScanRunning) {
            try { bleScanner.stopScan(scanCallback); } catch (Throwable ignored) {}
        }
        bleScanRunning = false;
    }

    private void fetchSelectedSdp() {
        if (!readyForScan()) return;
        BluetoothDevice d = selectedDevice();
        if (d == null) { add("BLOCKED: select a discovered/paired device first."); return; }
        stopScans();
        String key = deviceKey(d);
        try {
            ParcelUuid[] cached = d.getUuids();
            add("=== CLASSIC SDP REQUEST ===");
            add("Device: " + describe(d));
            if (cached != null) for (ParcelUuid p : cached) if (p != null) add("  pre-fetch cached " + p.getUuid() + " " + uuidLabel(p.getUuid()));
            boolean started = d.fetchUuidsWithSdp();
            sdpRequested.add(key);
            add("fetchUuidsWithSdp started=" + started + ". Await ACTION_UUID broadcast.");
            add("This is service discovery only. R29 creates no BluetoothSocket and sends no OBEX object/header/body.");
        } catch (SecurityException e) {
            add("SDP permission error: " + safe(e.getMessage()));
        } catch (Throwable t) {
            add("SDP request failed: " + t.getClass().getSimpleName() + ": " + safe(t.getMessage()));
        }
    }

    private void discoverSelectedGatt() {
        if (!readyForScan()) return;
        BluetoothDevice d = selectedDevice();
        if (d == null) { add("BLOCKED: select a discovered/paired device first."); return; }
        stopScans();
        if (activeGatt != null) closeGatt(activeGatt);
        add("=== BLE GATT DISCOVERY REQUEST ===");
        add("Device: " + describe(d));
        add("Operation boundary: connect LE -> discoverServices -> enumerate UUIDs/properties -> disconnect. No value read/write/subscription.");
        try {
            activeGatt = d.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE);
            if (activeGatt == null) add("connectGatt returned null.");
        } catch (SecurityException e) {
            add("GATT permission error: " + safe(e.getMessage()));
        } catch (Throwable t) {
            add("GATT connect failed: " + t.getClass().getSimpleName() + ": " + safe(t.getMessage()));
        }
    }

    private synchronized void closeGatt(BluetoothGatt gatt) {
        if (gatt == null) return;
        try { gatt.close(); } catch (Throwable ignored) {}
        if (activeGatt == gatt) activeGatt = null;
    }

    private void showCapabilitySummary() {
        BluetoothDevice d = selectedDevice();
        add("=== R29 SDK CORRELATION / CAPABILITY SUMMARY ===");
        if (d == null) {
            add("No selected device. Discovery results collected so far=" + devices.size());
            add("Select either the Classic GoloPine entry or LE-GoloPine entry after scanning.");
            add("=== END SUMMARY ===");
            return;
        }

        String selectedKey = deviceKey(d);
        DeviceEntry classic = findClassicCounterpart(d);
        DeviceEntry ble = findBleCounterpart(d);
        String classicKey = classic == null ? null : deviceKey(classic.device);
        String bleKey = ble == null ? null : deviceKey(ble.device);

        add("Selected: " + describe(d));
        if (classic != null) add("SDK-correlated Classic: " + describe(classic.device));
        if (ble != null) add("SDK-correlated BLE: " + describe(ble.device));

        boolean addressMatch = classic != null && ble != null &&
                sdkExpectedBleAddress(deviceKey(classic.device)).equalsIgnoreCase(deviceKey(ble.device));
        add("SDK address transform match=" + addressMatch +
                " [ble[0]=bt[0]|0xC0, ble[4]=bt[4]+0x60]");

        List<UUID> adv = bleKey == null ? Collections.emptyList() : advertisedUuids.getOrDefault(bleKey, Collections.emptyList());
        List<UUID> gatt = bleKey == null ? Collections.emptyList() : gattServiceUuids.getOrDefault(bleKey, Collections.emptyList());
        List<UUID> sdp = classicKey == null ? Collections.emptyList() : classicUuids.getOrDefault(classicKey, Collections.emptyList());
        boolean sdpWasRequested = classicKey != null && sdpRequested.contains(classicKey);
        boolean ab00 = adv.contains(UUID_UFE_SERVICE_AB00) || gatt.contains(UUID_UFE_SERVICE_AB00);
        boolean exactAb00 = bleKey != null && Boolean.TRUE.equals(sdkAb00Shape.get(bleKey));

        add("BLE advertised UUID count=" + adv.size());
        add("GATT service UUID count=" + gatt.size());
        add("Known BLE UFE AB00 observed=" + ab00 + " exact SDK AB00 shape=" + exactAb00);
        if (bleKey != null && rawAdvHex.containsKey(bleKey)) add("BLE raw advertisement=" + rawAdvHex.get(bleKey));
        add("Classic SDP UUID count=" + sdp.size() + " requestMade=" + sdpWasRequested);

        if (sdp.contains(UUID_OBJECT_PUSH)) {
            add("OBEX/OPP prerequisite: PRESENT (Object Push 0x1105 observed).");
            add("MVA compile flag remains separate: 0x1105 alone would not prove MVA_BT_OBEX_UPDATE_FUNC_SUPPORT.");
            add("STOP: do not open an OBEX/RFCOMM session and do not send headers or files.");
        } else if (sdpWasRequested) {
            add("OBEX/OPP prerequisite: NOT OBSERVED (0x1105 absent from live SDP result).");
            if (addressMatch && ab00) {
                add("R29 EVIDENCE: live Classic+BLE identity matches the SDK address transform and AB00 profile family.");
                add("R29 EVIDENCE: in this SDK, functional OBEX is selected by BT_PROFILE_SUPPORTED_OBEX and BTStackInitObex registers standard Object Push 0x1105.");
                add("R29 INFERENCE: active stock MVA-over-OBEX OTA is therefore not supported by the observed runtime evidence. This is strong SDK-family evidence, not a binary dump proof.");
            } else {
                add("Interpretation: no standard Object Push service was observed; SDK-family correlation is incomplete for this selected pair.");
            }
        } else {
            add("OBEX/OPP prerequisite: NOT YET CORRELATED. Run Classic SDP on the paired Classic entry once.");
        }

        add("Vendor/unknown BLE GATT services other than AB00:");
        int count = 0;
        for (UUID u : gatt) {
            if (isUnknownOrVendor(u) && !u.equals(UUID_UFE_SERVICE_AB00)) { add("  " + u); count++; }
        }
        if (count == 0) add("  none observed");
        add("Safety boundary remains unchanged: no GATT value read/write/subscription, no RFCOMM, no OBEX PUT, no .mva, no USB, no flash operation.");
        add("=== END SUMMARY ===");
    }

    private DeviceEntry findClassicCounterpart(BluetoothDevice selected) {
        String sel = normalizeAddress(deviceKey(selected));
        for (DeviceEntry e : devices) {
            String candidate = normalizeAddress(deviceKey(e.device));
            if (candidate.equals(sel) && e.sources.contains("BONDED")) return e;
        }
        for (DeviceEntry e : devices) {
            if (!e.sources.contains("BONDED") && !classicUuids.containsKey(deviceKey(e.device))) continue;
            String expected = normalizeAddress(sdkExpectedBleAddress(deviceKey(e.device)));
            if (expected.equals(sel)) return e;
        }
        return null;
    }

    private DeviceEntry findBleCounterpart(BluetoothDevice selected) {
        String sel = normalizeAddress(deviceKey(selected));
        for (DeviceEntry e : devices) {
            String candidate = normalizeAddress(deviceKey(e.device));
            if (candidate.equals(sel) && (e.sources.contains("BLE") || advertisedUuids.containsKey(deviceKey(e.device)))) return e;
        }
        String expected = normalizeAddress(sdkExpectedBleAddress(sel));
        for (DeviceEntry e : devices) {
            String candidate = normalizeAddress(deviceKey(e.device));
            if (candidate.equals(expected) && (e.sources.contains("BLE") || advertisedUuids.containsKey(deviceKey(e.device)))) return e;
        }
        return null;
    }

    private static String sdkExpectedBleAddress(String classicAddress) {
        String n = normalizeAddress(classicAddress);
        String[] parts = n.split(":");
        if (parts.length != 6) return "";
        try {
            int[] b = new int[6];
            for (int i = 0; i < 6; i++) b[i] = Integer.parseInt(parts[i], 16);
            b[0] = b[0] | 0xC0;
            b[4] = (b[4] + 0x60) & 0xFF;
            return String.format(Locale.US, "%02X:%02X:%02X:%02X:%02X:%02X", b[0], b[1], b[2], b[3], b[4], b[5]);
        } catch (RuntimeException e) {
            return "";
        }
    }

    private static String normalizeAddress(String address) {
        return address == null ? "" : address.trim().toUpperCase(Locale.US);
    }

    private static String hex(byte[] data) {
        if (data == null) return "";
        StringBuilder out = new StringBuilder(data.length * 2);
        for (byte b : data) out.append(String.format(Locale.US, "%02X", b & 0xFF));
        return out.toString();
    }

    private void addOrUpdateDevice(BluetoothDevice d, String source, List<UUID> adv) {
        if (d == null) return;
        String key = deviceKey(d);
        DeviceEntry entry = byKey.get(key);
        if (entry == null) {
            entry = new DeviceEntry(d);
            byKey.put(key, entry);
            devices.add(entry);
        }
        entry.sources.add(source);
        if (adv != null) entry.advUuids = new ArrayList<>(adv);
        refreshSpinner();
    }

    private void refreshSpinner() {
        runOnUiThread(() -> {
            int old = deviceSpinner.getSelectedItemPosition();
            spinnerAdapter.clear();
            for (DeviceEntry e : devices) spinnerAdapter.add(e.label());
            spinnerAdapter.notifyDataSetChanged();
            if (!devices.isEmpty()) deviceSpinner.setSelection(Math.max(0, Math.min(old, devices.size() - 1)));
        });
    }

    private BluetoothDevice selectedDevice() {
        int p = deviceSpinner.getSelectedItemPosition();
        if (p < 0 || p >= devices.size()) return null;
        return devices.get(p).device;
    }

    private void logBluetoothClass(BluetoothDevice d) {
        try {
            BluetoothClass c = d.getBluetoothClass();
            add("  bluetoothClass=" + (c == null ? "null" : (c.toString() + " major=" + c.getMajorDeviceClass() + " device=" + c.getDeviceClass() + " objectTransferHint=" + c.hasService(BluetoothClass.Service.OBJECT_TRANSFER))));
        } catch (Throwable t) {
            add("  classOfDevice unavailable: " + t.getClass().getSimpleName());
        }
    }

    private String describe(BluetoothDevice d) {
        if (d == null) return "<null>";
        String name = "?";
        String address = "?";
        int type = -1;
        int bond = -1;
        try { name = safe(d.getName()); } catch (Throwable ignored) {}
        try { address = safe(d.getAddress()); } catch (Throwable ignored) {}
        try { type = d.getType(); } catch (Throwable ignored) {}
        try { bond = d.getBondState(); } catch (Throwable ignored) {}
        return "name=" + name + " addr=" + address + " type=" + typeName(type) + " bond=" + bondName(bond);
    }

    private String deviceKey(BluetoothDevice d) {
        try { return d.getAddress(); } catch (Throwable t) { return Integer.toHexString(System.identityHashCode(d)); }
    }

    private BluetoothDevice getBtDevice(Intent intent) {
        if (Build.VERSION.SDK_INT >= 33) return intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice.class);
        //noinspection deprecation
        return intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
    }

    private ArrayList<UUID> parcelUuidArrayToList(Intent intent) {
        ArrayList<UUID> out = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 33) {
            ParcelUuid[] arr = intent.getParcelableArrayExtra(BluetoothDevice.EXTRA_UUID, ParcelUuid.class);
            if (arr != null) for (ParcelUuid p : arr) if (p != null) out.add(p.getUuid());
        } else {
            //noinspection deprecation
            android.os.Parcelable[] raw = intent.getParcelableArrayExtra(BluetoothDevice.EXTRA_UUID);
            if (raw != null) for (android.os.Parcelable p : raw) if (p instanceof ParcelUuid) out.add(((ParcelUuid) p).getUuid());
        }
        return out;
    }

    private String uuidLabel(UUID u) {
        if (u == null) return "";
        if (u.equals(UUID_OBJECT_PUSH)) return "[OBEX Object Push / OPP 0x1105]";
        if (u.equals(UUID_SERIAL_PORT)) return "[Serial Port / SPP 0x1101]";
        if (u.equals(UUID_UFE_SERVICE_AB00)) return "[known GoloPine BLE UFE AB00; tuning/control, not OTA]";
        if (u.equals(UUID_UFE_CHAR_AB01)) return "[known GoloPine BLE UFE AB01 data characteristic]";
        if (u.equals(UUID_UFE_CHAR_AB02)) return "[known GoloPine BLE UFE AB02 notify characteristic]";
        if (u.equals(UUID_UFE_CHAR_AB03)) return "[known GoloPine BLE UFE AB03 notify characteristic]";
        Integer shortUuid = shortUuid(u);
        if (shortUuid != null) return String.format(Locale.US, "[Bluetooth-base short UUID 0x%04X]", shortUuid);
        return "[vendor/128-bit UUID; purpose unknown until matched to evidence]";
    }

    private boolean isUnknownOrVendor(UUID u) {
        return shortUuid(u) == null;
    }

    private static Integer shortUuid(UUID u) {
        if (u == null) return null;
        String s = u.toString().toLowerCase(Locale.US);
        if (!s.endsWith(BT_BASE_SUFFIX)) return null;
        if (!s.startsWith("0000")) return null;
        try { return Integer.parseInt(s.substring(4, 8), 16); }
        catch (RuntimeException e) { return null; }
    }

    private static UUID uuid16(int value) {
        return UUID.fromString(String.format(Locale.US, "0000%04x-0000-1000-8000-00805f9b34fb", value & 0xffff));
    }

    private static String typeName(int t) {
        switch (t) {
            case BluetoothDevice.DEVICE_TYPE_CLASSIC: return "CLASSIC";
            case BluetoothDevice.DEVICE_TYPE_LE: return "LE";
            case BluetoothDevice.DEVICE_TYPE_DUAL: return "DUAL";
            case BluetoothDevice.DEVICE_TYPE_UNKNOWN: return "UNKNOWN";
            default: return String.valueOf(t);
        }
    }

    private static String bondName(int b) {
        switch (b) {
            case BluetoothDevice.BOND_NONE: return "NONE";
            case BluetoothDevice.BOND_BONDING: return "BONDING";
            case BluetoothDevice.BOND_BONDED: return "BONDED";
            default: return String.valueOf(b);
        }
    }

    private void copyLog() {
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("OKN R29 Bluetooth capability log", log.getText()));
        add("Whole log copied to clipboard.");
    }

    private void add(String s) {
        String stamp = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(new Date());
        runOnUiThread(() -> log.append("[" + stamp + "] " + s + "\n"));
    }

    private void addUi(String s) { add(s); }

    private static String safe(String s) { return s == null ? "" : s; }

    private final class DeviceEntry {
        final BluetoothDevice device;
        final Set<String> sources = new LinkedHashSet<>();
        List<UUID> advUuids = Collections.emptyList();

        DeviceEntry(BluetoothDevice device) { this.device = device; }

        String label() {
            String name = "?";
            String address = "?";
            try { name = safe(device.getName()); } catch (Throwable ignored) {}
            try { address = safe(device.getAddress()); } catch (Throwable ignored) {}
            return sources + "  " + name + "  " + address;
        }
    }
}
