# BUILD NOTES — R29

R29 ไม่เพิ่ม hardware action. งานใหม่ทั้งหมดเป็น offline package03/helper/readback analysis.

Host/safety tests ต้องยืนยัน:
1. TRUE7CH firmware unit tests เดิมผ่าน
2. no-EQ-as-gain guard ผ่าน
3. R25 Bluetooth probe guard ผ่าน
4. R26/R27 historical offline guards ผ่าน
5. R28 MVA/recovery guard ผ่าน
6. R29 deterministic helper fingerprint + ID3 parser dispatch ตรง reference flashboot SHA
7. `SpiFlashRead` internal primitive มีได้ แต่ `host_exposed_arbitrary_flash_read_proven` ต้องเป็น false
8. `stock_backup_obtained=false`, `live_probe_allowed=false`, `proven_live_identity_or_readback_command=null`
9. Android source ต้องไม่มี USB transport, RFCOMM/OBEX send, GATT write/descriptor subscribe

AUTO GitHub Actions stable-signing workflow เดิมใช้ได้. R29 ไม่จำเป็นต้อง build/install APK เพราะไม่มี live probe ใหม่.

## R31
- ทำ offline static reverse Windows 2026 EXE ตัวจริงที่ hash ตรง checkpoint.
- เพิ่ม pure-Python PE/.NET metadata parser + IL disassembler; ไม่มี live device I/O.
- ยืนยัน native HID imports และ UFE command/response constants.
- ไม่พบ hidden backup/dump/upload/readflash path ที่พิสูจน์ได้.
- คง flash gate CLOSED; ไม่มี hardware probe/R31 APK requirement.

### R32
เพิ่ม offline protected-runtime recovery + exact response-dispatch evidence เท่านั้น ไม่มี live device I/O และไม่มี vendor EXE/private signing key ใน source checkpoint.

## R33
- เพิ่ม `tools/r33_flash_readback_gate.py` สำหรับ reconstruct/scan reference flashboot แบบ offline เท่านั้น
- pin internal read `0x0F9C`, response wrapper `0x4BF6`, call counts และ embedded reference map
- เพิ่ม fail-closed guard `check_r33_offline_guard.py`
- ไม่มี USB/BLE/HID/serial/socket device I/O และไม่มี hardware packet generator
