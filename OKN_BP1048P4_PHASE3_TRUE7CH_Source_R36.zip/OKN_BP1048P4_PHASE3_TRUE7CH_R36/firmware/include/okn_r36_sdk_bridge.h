#ifndef OKN_R36_SDK_BRIDGE_H
#define OKN_R36_SDK_BRIDGE_H

#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
#include "okn_gain7.h"
#include "okn_ufe_gain7.h"

#ifdef __cplusplus
extern "C" {
#endif

#define OKN_R36_SDK_COMMIT "8105bd864b04995d81c9f9ae77cb158259f39015"
#define OKN_R36_MAX_I2S_FRAMES 512u

typedef struct {
    okn_gain7_state_t gain;
    bool bound;
} okn_r36_ctx_t;

extern okn_r36_ctx_t g_okn_r36;

void okn_r36_init(void);
uint16_t okn_r36_gain_q12(uint8_t ch0);
bool okn_r36_ufe_write_apply(const uint8_t *p, size_t n);
size_t okn_r36_ufe_read(const uint8_t *req, size_t n, uint8_t *out, size_t cap);
void okn_r36_process_i2s16_copy(uint8_t first_ch0, const int16_t *src, int16_t *dst, size_t frames);

#ifdef OKN_R36_VENDOR_SDK
void okn_r36_apply_dac_sinks(void);
uint16_t __wrap_AudioI2S0_DataSet(void *Buf, uint16_t Len);
uint16_t __wrap_AudioI2S1_DataSet(void *Buf, uint16_t Len);
#endif

#ifdef __cplusplus
}
#endif
#endif
