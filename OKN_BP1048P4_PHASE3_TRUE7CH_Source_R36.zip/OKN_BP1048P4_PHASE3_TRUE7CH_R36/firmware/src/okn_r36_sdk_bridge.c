#include "okn_r36_sdk_bridge.h"
#include <string.h>

okn_r36_ctx_t g_okn_r36;

void okn_r36_init(void)
{
    okn_gain7_init(&g_okn_r36.gain);
    g_okn_r36.bound = true;
}

uint16_t okn_r36_gain_q12(uint8_t ch0)
{
    uint32_t q14 = okn_gain7_get_q14(&g_okn_r36.gain, ch0);
    uint32_t q12 = (q14 * 4095u + 8192u) >> 14;
    if (q12 > 8191u) q12 = 8191u;
    return (uint16_t)q12;
}

void okn_r36_process_i2s16_copy(uint8_t first_ch0, const int16_t *src, int16_t *dst, size_t frames)
{
    size_t samples;
    if (!src || !dst || frames > OKN_R36_MAX_I2S_FRAMES || first_ch0 + 1u >= OKN_GAIN7_CHANNELS) return;
    samples = frames * 2u;
    if (src != dst) memcpy(dst, src, samples * sizeof(int16_t));
    okn_gain7_process_interleaved(&g_okn_r36.gain, first_ch0, dst, frames, 0u, 2u);
    okn_gain7_process_interleaved(&g_okn_r36.gain, (uint8_t)(first_ch0 + 1u), dst, frames, 1u, 2u);
}

bool okn_r36_ufe_write_apply(const uint8_t *p, size_t n)
{
    bool ok;
    if (!g_okn_r36.bound) okn_r36_init();
    ok = okn_ufe_gain7_write(&g_okn_r36.gain, p, n);
#ifdef OKN_R36_VENDOR_SDK
    if (ok) okn_r36_apply_dac_sinks();
#endif
    return ok;
}

size_t okn_r36_ufe_read(const uint8_t *req, size_t n, uint8_t *out, size_t cap)
{
    if (!g_okn_r36.bound) okn_r36_init();
    return okn_ufe_gain7_read(&g_okn_r36.gain, req, n, out, cap);
}

#ifdef OKN_R36_VENDOR_SDK
#include "audio_core_api.h"
#include "i2s_interface.h"
#include "i2s.h"

extern uint16_t __real_AudioI2S0_DataSet(void *Buf, uint16_t Len);
extern uint16_t __real_AudioI2S1_DataSet(void *Buf, uint16_t Len);

static int16_t s_i2s0_scratch[OKN_R36_MAX_I2S_FRAMES * 2u];
static int16_t s_i2s1_scratch[OKN_R36_MAX_I2S_FRAMES * 2u];

void okn_r36_apply_dac_sinks(void)
{
    if (!g_okn_r36.bound) okn_r36_init();
    /* Stock reverse mapping: CH1=L, CH2=R on main DAC0. */
    AudioCoreSinkVolSet(AUDIO_DAC0_SINK_NUM, okn_r36_gain_q12(0), okn_r36_gain_q12(1));
#ifdef CFG_RES_AUDIO_DACX_EN
    /* Experimental mapping for sacrificial board: stock CH3=bass -> DACX, same gain on both lanes. */
    AudioCoreSinkVolSet(AUDIO_DACX_SINK_NUM, okn_r36_gain_q12(2), okn_r36_gain_q12(2));
#endif
}

static uint16_t wrap_i2s(void *buf, uint16_t frames, uint8_t first_ch0, int16_t *scratch,
                         I2S_MODULE module, uint16_t (*real_fn)(void *, uint16_t))
{
    if (!buf || frames == 0u || frames > OKN_R36_MAX_I2S_FRAMES) return real_fn(buf, frames);
    /* Source implementation proves Len is stereo frame count. Only touch the proven 16-bit format. */
    if (I2S_WordlengthGet(module) != I2S_LENGTH_16BITS) return real_fn(buf, frames);
    if (!g_okn_r36.bound) okn_r36_init();
    okn_r36_process_i2s16_copy(first_ch0, (const int16_t *)buf, scratch, frames);
    return real_fn(scratch, frames);
}

uint16_t __wrap_AudioI2S0_DataSet(void *Buf, uint16_t Len)
{
    return wrap_i2s(Buf, Len, 3u, s_i2s0_scratch, I2S0_MODULE, __real_AudioI2S0_DataSet);
}

uint16_t __wrap_AudioI2S1_DataSet(void *Buf, uint16_t Len)
{
    return wrap_i2s(Buf, Len, 5u, s_i2s1_scratch, I2S1_MODULE, __real_AudioI2S1_DataSet);
}
#endif
