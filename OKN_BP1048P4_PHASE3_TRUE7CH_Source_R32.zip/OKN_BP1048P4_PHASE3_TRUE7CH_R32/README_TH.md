# OKN BP1048P4 Phase3 TRUE7CH — R31

R31 เป็นรอบ **offline Windows PC tuning tool/runtime HID + readback reverse** ต่อจาก R30 โดยไม่ทำ hardware probe ใหม่.

ไฟล์ใหม่หลัก:
- `docs/R31_WINDOWS_RUNTIME_READBACK_OFFLINE_REVERSE_TH.md`
- `docs/R31_WINDOWS_RUNTIME_READBACK_EVIDENCE.txt`
- `config/R31_WINDOWS_RUNTIME_READBACK_STATE.json`
- `config/R31_WINDOWS_RUNTIME_READBACK_RISK.json`
- `windows/r31/` — derived metadata/IL/static evidence
- `tools/dotnet_meta.py`
- `tools/il_disasm.py`
- `tools/r31_windows_runtime_offline.py`
- `tools/check_r31_offline_guard.py`

ผล R31:
1. ยืนยันจาก EXE ตัวจริงว่ามี native HID wrappers: GetInputReport/ReadFile และ SetOutputReport/SetFeature/WriteFile.
2. ยืนยัน UFE constants 0x57/58/59/60/61/62/63/64/82 จาก .NET Constant table โดยตรง.
3. read/query ที่พบเป็น sensor/actuator/device-description level; ยังไม่พบ arbitrary flash read-to-host.
4. static search ไม่พบ direct backup/dump/upload/export/readflash/flashread candidate.
5. frame A5 5A ... 16 ยังเป็นหลักฐานฝั่ง reference firmware จาก R30; R31 ไม่พบ direct Windows-side builder ที่เปิดเผยพอจะพิสูจน์เพิ่ม และไม่เดา packet.
6. **stock backup/readback ยังไม่พิสูจน์, production layout ยังไม่พิสูจน์, flash gate CLOSED.**

R31 ไม่มี executable Windows vendor binary และไม่มี private Android signing key ใน source ZIP; เก็บเฉพาะ derived evidence และ offline tools.

## R32 — protected Windows response path
R32 กู้ protected Windows 2026 runtime stream ได้ครบ 1,823 records และเปิด hidden UFE response dispatcher แล้ว พบว่า response 0x60/0x62/0x64 ถูก parse เข้าสู่ Sensor/Actuator/FIFO object model และ 0x82 เป็น bulk continuation; ไม่พบ arbitrary flash-read/backup primitive. `FLASH_GATE` ยังคง `CLOSED`. ดู `docs/R32_PROTECTED_UFE_RESPONSE_OFFLINE_REVERSE_TH.md`.
