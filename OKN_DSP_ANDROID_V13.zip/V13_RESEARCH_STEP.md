# V13 Controlled Event Capture — Clean Build

V13 is rebuilt from the clean V10 base to avoid duplicate declarations introduced in V11/V12.

UI controls:
- SCAN DSP
- CLEAR LOG
- CAPTURE NOTIFY
- ANALYZE PACKETS
- START EVENT BASELINE
- MARK CONTROLLED EVENT

Notification records include:
- packet number
- timestamp
- UUID
- length
- TYPE-A for 10 bytes
- TYPE-B for 13 bytes
- deltaMs
- mode=BASELINE/EVENT/IDLE
- eventMs
- HEX
- fingerprint

Research procedure:
1. Connect and subscribe.
2. Press CAPTURE NOTIFY.
3. Press START EVENT BASELINE and leave the original DSP controller untouched for ~5 seconds.
4. Press MARK CONTROLLED EVENT.
5. Change exactly ONE setting in the original DSP controller (e.g. Volume +1).
6. Wait ~5 seconds.
7. Save/send the log.

Safety:
- No DSP write command is implemented.
- V13 only reads and receives notifications.
