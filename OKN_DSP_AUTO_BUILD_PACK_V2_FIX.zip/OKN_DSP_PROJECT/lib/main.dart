import 'package:flutter/material.dart';

void main()=>runApp(const OKNDSP());

class OKNDSP extends StatelessWidget{
 const OKNDSP({super.key});
 @override
 Widget build(BuildContext c)=>MaterialApp(
 debugShowCheckedModeBanner:false,
 home:Scaffold(
 backgroundColor:Colors.black,
 body:Center(
 child:Text('OKN_DSP BP1048P4 V2 FIX',
 style:TextStyle(color:Colors.cyan,fontSize:24)))))
 ;
}
