OKN_DSP V3 — RESPONSIVE UI / EASY TOUCH
========================================

Version
- applicationId: com.okn.dsp
- versionCode: 3
- versionName: 1.0.2-v3-responsive-ui

V3 UI change
- Keeps the two exact user-supplied Home/EQ images as the only visual master references.
- Stops non-uniform full-screen stretching. Each reference page is now scaled uniformly with its original aspect ratio preserved.
- Centers the reference page inside the available screen and uses the same dark-navy background for any safe margin on tall/narrow phones.
- Dynamic BLE status, scalar sliders and EQ overlays use the identical transform as the reference image, so live graphics stay aligned.
- Touch coordinates use the inverse transform including the page offsets; buttons/sliders remain aligned even when the phone aspect ratio differs from the reference.
- Home scalar slider touch height is enlarged from 76 reference pixels to 116 reference pixels for easier finger control.
- Live scalar slider track/thumb are slightly thicker/larger while preserving the supplied visual style.
- EQ graph point touch radius is enlarged from 40 to 58 reference pixels; live EQ points are slightly larger.
- Touches in the safe margins are ignored so they cannot accidentally trigger bottom navigation or other controls.

Startup baseline retained from V2
- DspRuntime remains lazy.
- Startup recovery screen remains enabled.
- MODIFY_AUDIO_SETTINGS remains declared.
- Phone-volume bridge and observer startup remain guarded.

Verified hardware boundary preserved
- BLE AB00 / AB01 write / AB02 notify / AB03 known secondary path.
- Scalar actuator IDs only: 2,3,8,9,10,13,11.
- EQ actuators CH1..CH7: 4,5,6,14,15,16,17.
- Only verified PEAKING type=12 full 48-byte EQ records are writable.
- Generic unknown, Crossover, Delay and unknown Output hardware writes remain locked.
- Manual SaveParams remains the exact guarded verified ID7 path only.

Build
- compileSdk/targetSdk 35
- minSdk 26
- JDK 17
- Gradle 8.9
- stable debug signer preserved
- Existing build-okn-dsp-v1.yml is generic and auto-runs for OKN_DSP_ANDROID_V*.zip, including V3.
