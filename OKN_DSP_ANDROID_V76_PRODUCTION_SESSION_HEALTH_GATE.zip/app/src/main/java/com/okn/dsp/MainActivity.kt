package com.okn.dsp

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/** V76 production session-health-gate launcher: open the verified DSP control UI directly. */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startActivity(Intent(this, UnifiedControlActivity::class.java))
        finish()
    }
}
