#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
from pathlib import Path

def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("apk")
    parser.add_argument("--out", default="Sources/sha256.txt")
    args = parser.parse_args()

    apk = Path(args.apk)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(f"{sha256(apk)}  {apk.name}\n", encoding="utf-8")
    print(out.read_text(encoding="utf-8").strip())

if __name__ == "__main__":
    main()
