#!/usr/bin/env python3
from __future__ import annotations

import argparse
import re
from pathlib import Path

VERSION_RE = re.compile(r"^(?P<major>\d+)\.(?P<minor>\d+)\.(?P<patch>\d+)\+(?P<build>\d+)$")

def parse(value: str):
    match = VERSION_RE.match(value.strip())
    if not match:
        raise SystemExit(f"Invalid version: {value!r}; expected MAJOR.MINOR.PATCH+BUILD")
    return tuple(int(match.group(k)) for k in ("major", "minor", "patch", "build"))

def format_version(parts):
    major, minor, patch, build = parts
    return f"{major}.{minor}.{patch}+{build}"

def read_pubspec_version(pubspec: Path) -> str:
    for line in pubspec.read_text(encoding="utf-8").splitlines():
        if line.startswith("version:"):
            return line.split(":", 1)[1].strip()
    raise SystemExit("version: not found in pubspec.yaml")

def write_pubspec_version(pubspec: Path, version: str) -> None:
    text = pubspec.read_text(encoding="utf-8")
    updated, count = re.subn(r"(?m)^version:\s*.+$", f"version: {version}", text, count=1)
    if count != 1:
        raise SystemExit("Unable to update version in pubspec.yaml")
    pubspec.write_text(updated, encoding="utf-8")

def bump(version: str, mode: str) -> str:
    major, minor, patch, build = parse(version)
    if mode == "build":
        build += 1
    elif mode == "patch-build":
        patch += 1
        build += 1
    elif mode == "patch":
        patch += 1
    else:
        raise SystemExit(f"Unsupported bump mode: {mode}")
    return format_version((major, minor, patch, build))

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=["read", "sync", "bump-build", "bump-patch", "bump-patch-build"])
    parser.add_argument("--pubspec", default="pubspec.yaml")
    parser.add_argument("--version-file", default="VERSION")
    args = parser.parse_args()

    pubspec = Path(args.pubspec)
    version_file = Path(args.version_file)

    if args.command == "read":
        print(read_pubspec_version(pubspec))
        return

    if args.command == "sync":
        version = version_file.read_text(encoding="utf-8").strip()
        parse(version)
        write_pubspec_version(pubspec, version)
        print(version)
        return

    current = version_file.read_text(encoding="utf-8").strip()
    mode = args.command.replace("bump-", "")
    new_version = bump(current, mode)
    version_file.write_text(new_version + "\n", encoding="utf-8")
    print(new_version)

if __name__ == "__main__":
    main()
