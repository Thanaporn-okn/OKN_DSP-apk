# Changelog

## 1.0.2+3
- Fixed invalid GitHub Actions YAML caused by an accidental leading backslash before `name:`.
- Workflow YAML now parses correctly.
- Keep only one active workflow file in `.github/workflows/` to avoid duplicate failed runs.

## 1.0.1+2
- Fixed GitHub Actions `flutter analyze` failure caused by Flutter's generated `test/widget_test.dart` referencing the non-existent `MyApp`.
- Added an OKN DSP widget smoke test using `OknDspApp` and `DspController`.
- Hardened CI failure handling so analyze/test/build failures produce logs and advance the patch/build version.

## 1.0.0+1
- Reset project numbering and created the production-oriented Flutter scaffold.
- Added responsive design baseline for the five supplied 9:16 UI references.
- Added central DSP state model and core calculations.
- Added CI-ready versioning and SHA-256 support scripts.
