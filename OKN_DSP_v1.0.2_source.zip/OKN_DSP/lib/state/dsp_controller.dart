import 'package:flutter/foundation.dart';

import '../core/constants/dsp_constants.dart';
import '../models/dsp_channel.dart';
import '../models/eq_band.dart';

class DspController extends ChangeNotifier {
  int _selectedPage = 0;
  int _selectedChannel = 0;

  bool connected = true;
  String deviceName = 'DSP-7900';

  double masterVolumeDb = -3.0;
  double bassVolumeDb = 4.0;
  double bassCutoffHz = 100.0;
  double bassBoostDb = 3.0;
  double middleBoostDb = -2.0;
  double trebleBoostDb = 1.0;

  String audioSource = 'High Level (Speaker)';
  String systemPreset = 'Flat';

  bool hpfBypass = false;
  bool lpfBypass = false;
  double hpfFrequencyHz = 100.0;
  double lpfFrequencyHz = 1000.0;
  double phaseDegrees = 0.0;
  bool linkedLeftRight = true;

  final List<DspChannel> channels = <DspChannel>[
    const DspChannel(id: 1, name: 'CH1', role: 'Front L', outputDb: -3.0, delayMs: 0.00, colorValue: 0xFF1B9DFF),
    const DspChannel(id: 2, name: 'CH2', role: 'Front R', outputDb: -2.5, delayMs: 1.25, colorValue: 0xFFFF9C28),
    const DspChannel(id: 3, name: 'CH3', role: 'Rear L', outputDb: -4.0, delayMs: 2.60, colorValue: 0xFF00E676),
    const DspChannel(id: 4, name: 'CH4', role: 'Rear R', outputDb: -1.0, delayMs: 2.30, colorValue: 0xFFFF4DC4),
    const DspChannel(id: 5, name: 'CH5', role: 'Center', outputDb: -2.0, delayMs: 0.80, colorValue: 0xFFF5F7FA),
    const DspChannel(id: 6, name: 'CH6', role: 'Sub L', outputDb: -3.5, delayMs: 3.10, colorValue: 0xFFB43CFF),
    const DspChannel(id: 7, name: 'CH7', role: 'Sub R', outputDb: -4.5, delayMs: 1.90, colorValue: 0xFF00D7FF),
  ];

  final List<EqBand> eqBands = <EqBand>[
    const EqBand(id: 1, type: EqFilterType.peq, frequencyHz: 32, gainDb: -3.0, q: 0.70, enabled: true),
    const EqBand(id: 2, type: EqFilterType.lowShelf, frequencyHz: 100, gainDb: 2.5, q: 1.00, enabled: true),
    const EqBand(id: 3, type: EqFilterType.peq, frequencyHz: 200, gainDb: 6.0, q: 1.20, enabled: true),
    const EqBand(id: 4, type: EqFilterType.peq, frequencyHz: 500, gainDb: -4.0, q: 1.00, enabled: true),
    const EqBand(id: 5, type: EqFilterType.peq, frequencyHz: 2000, gainDb: 3.0, q: 1.00, enabled: true),
    const EqBand(id: 6, type: EqFilterType.highShelf, frequencyHz: 10000, gainDb: -2.0, q: 0.70, enabled: true),
    const EqBand(id: 7, type: EqFilterType.peq, frequencyHz: 125, gainDb: 0.0, q: 1.00, enabled: true),
    const EqBand(id: 8, type: EqFilterType.peq, frequencyHz: 250, gainDb: 0.0, q: 1.00, enabled: true),
    const EqBand(id: 9, type: EqFilterType.peq, frequencyHz: 750, gainDb: 0.0, q: 1.00, enabled: true),
    const EqBand(id: 10, type: EqFilterType.peq, frequencyHz: 1500, gainDb: 0.0, q: 1.00, enabled: true),
    const EqBand(id: 11, type: EqFilterType.peq, frequencyHz: 3000, gainDb: 0.0, q: 1.00, enabled: true),
    const EqBand(id: 12, type: EqFilterType.peq, frequencyHz: 6000, gainDb: 0.0, q: 1.00, enabled: true),
    const EqBand(id: 13, type: EqFilterType.peq, frequencyHz: 8000, gainDb: 0.0, q: 1.00, enabled: true),
    const EqBand(id: 14, type: EqFilterType.peq, frequencyHz: 12000, gainDb: 0.0, q: 1.00, enabled: true),
    const EqBand(id: 15, type: EqFilterType.peq, frequencyHz: 16000, gainDb: 0.0, q: 1.00, enabled: true),
  ];

  int get selectedPage => _selectedPage;
  int get selectedChannel => _selectedChannel;

  void selectPage(int index) {
    if (_selectedPage == index) return;
    _selectedPage = index.clamp(0, 4).toInt();
    notifyListeners();
  }

  void selectChannel(int index) {
    if (_selectedChannel == index) return;
    _selectedChannel = index.clamp(0, DspConstants.channelCount - 1).toInt();
    notifyListeners();
  }

  void setMasterVolume(double value) {
    masterVolumeDb = value.clamp(DspConstants.minOutputDb, DspConstants.maxOutputDb).toDouble();
    notifyListeners();
  }

  void setChannelOutput(int channelIndex, double value) {
    final DspChannel current = channels[channelIndex];
    channels[channelIndex] = current.copyWith(
      outputDb: value.clamp(DspConstants.minOutputDb, DspConstants.maxOutputDb).toDouble(),
    );
    notifyListeners();
  }

  void setChannelDelayMs(int channelIndex, double value) {
    final DspChannel current = channels[channelIndex];
    channels[channelIndex] = current.copyWith(
      delayMs: value.clamp(DspConstants.minDelayMs, DspConstants.maxDelayMs).toDouble(),
    );
    notifyListeners();
  }

  double channelDelayCm(int channelIndex) {
    return msToCm(channels[channelIndex].delayMs);
  }

  static double msToCm(double ms) {
    return ms * DspConstants.speedOfSoundCmPerMs;
  }

  static double cmToMs(double cm) {
    return cm / DspConstants.speedOfSoundCmPerMs;
  }

  void updateEqBand(
    int index, {
    EqFilterType? type,
    double? frequencyHz,
    double? gainDb,
    double? q,
    bool? enabled,
  }) {
    final EqBand current = eqBands[index];
    eqBands[index] = current.copyWith(
      type: type,
      frequencyHz: frequencyHz,
      gainDb: gainDb?.clamp(DspConstants.minEqGainDb, DspConstants.maxEqGainDb).toDouble(),
      q: q,
      enabled: enabled,
    );
    notifyListeners();
  }
}
