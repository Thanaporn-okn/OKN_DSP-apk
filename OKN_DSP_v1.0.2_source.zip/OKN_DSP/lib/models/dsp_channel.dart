class DspChannel {
  const DspChannel({
    required this.id,
    required this.name,
    required this.role,
    required this.outputDb,
    required this.delayMs,
    required this.colorValue,
  });

  final int id;
  final String name;
  final String role;
  final double outputDb;
  final double delayMs;
  final int colorValue;

  DspChannel copyWith({
    double? outputDb,
    double? delayMs,
  }) {
    return DspChannel(
      id: id,
      name: name,
      role: role,
      outputDb: outputDb ?? this.outputDb,
      delayMs: delayMs ?? this.delayMs,
      colorValue: colorValue,
    );
  }
}
