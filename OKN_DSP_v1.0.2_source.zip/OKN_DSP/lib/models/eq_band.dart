enum EqFilterType {
  peq,
  lowShelf,
  highShelf,
}

class EqBand {
  const EqBand({
    required this.id,
    required this.type,
    required this.frequencyHz,
    required this.gainDb,
    required this.q,
    required this.enabled,
  });

  final int id;
  final EqFilterType type;
  final double frequencyHz;
  final double gainDb;
  final double q;
  final bool enabled;

  EqBand copyWith({
    EqFilterType? type,
    double? frequencyHz,
    double? gainDb,
    double? q,
    bool? enabled,
  }) {
    return EqBand(
      id: id,
      type: type ?? this.type,
      frequencyHz: frequencyHz ?? this.frequencyHz,
      gainDb: gainDb ?? this.gainDb,
      q: q ?? this.q,
      enabled: enabled ?? this.enabled,
    );
  }
}
