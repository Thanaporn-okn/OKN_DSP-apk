import 'package:flutter/material.dart';

import '../widgets/stage_placeholder.dart';

class DelayScreen extends StatelessWidget {
  const DelayScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const StagePlaceholder(
      title: 'Delay',
      subtitle: 'Stage 2 will reproduce image_3.png with vehicle view and ms/cm controls.',
    );
  }
}
