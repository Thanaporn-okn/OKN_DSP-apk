import 'package:flutter/material.dart';

import '../widgets/stage_placeholder.dart';

class OutputScreen extends StatelessWidget {
  const OutputScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const StagePlaceholder(
      title: 'Output',
      subtitle: 'Stage 2 will reproduce image_4.png with 7-channel output controls.',
    );
  }
}
