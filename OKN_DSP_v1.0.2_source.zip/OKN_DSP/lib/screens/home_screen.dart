import 'package:flutter/material.dart';

import '../widgets/stage_placeholder.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const StagePlaceholder(
      title: 'Home',
      subtitle: 'Stage 2 will reproduce image_0.png with all interactive controls.',
    );
  }
}
