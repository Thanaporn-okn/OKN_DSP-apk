import 'package:flutter/material.dart';

import '../widgets/stage_placeholder.dart';

class CrossoverScreen extends StatelessWidget {
  const CrossoverScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const StagePlaceholder(
      title: 'Crossover',
      subtitle: 'Stage 2 will reproduce image_2.png with HPF/LPF graph and filter controls.',
    );
  }
}
