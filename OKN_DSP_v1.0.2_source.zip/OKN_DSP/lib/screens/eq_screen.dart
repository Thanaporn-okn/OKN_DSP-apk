import 'package:flutter/material.dart';

import '../widgets/stage_placeholder.dart';

class EqScreen extends StatelessWidget {
  const EqScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const StagePlaceholder(
      title: 'Parametric EQ',
      subtitle: 'Stage 2 will reproduce image_1.png and the 15-band interactive EQ.',
    );
  }
}
