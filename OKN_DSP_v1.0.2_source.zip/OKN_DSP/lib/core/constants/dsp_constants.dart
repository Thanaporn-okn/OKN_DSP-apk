class DspConstants {
  DspConstants._();

  static const int channelCount = 7;
  static const int eqBandCount = 15;

  static const double minOutputDb = -60.0;
  static const double maxOutputDb = 12.0;
  static const double minEqGainDb = -12.0;
  static const double maxEqGainDb = 12.0;

  static const double minDelayMs = 0.0;
  static const double maxDelayMs = 10.0;

  /// Speed of sound near 20°C: 343 m/s = 34.3 cm/ms.
  static const double speedOfSoundCmPerMs = 34.3;
}
