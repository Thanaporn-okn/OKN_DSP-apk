import 'dart:math' as math;
import 'package:flutter/widgets.dart';

class AppScale {
  const AppScale._({
    required this.width,
    required this.height,
  });

  static const double designWidth = 432.0;
  static const double designHeight = 768.0;

  final double width;
  final double height;

  factory AppScale.of(BuildContext context) {
    final Size size = MediaQuery.sizeOf(context);
    return AppScale._(width: size.width, height: size.height);
  }

  double get sx => width / designWidth;
  double get sy => height / designHeight;

  /// Uniform scale keeps the 9:16 reference proportions without clipping.
  double get uniform => math.min(sx, sy);

  double w(double value) => value * sx;
  double h(double value) => value * sy;
  double u(double value) => value * uniform;

  /// Text scale is bounded so tiny phones and large tablets stay usable.
  double sp(double value) => value * uniform.clamp(0.82, 1.35);
}
