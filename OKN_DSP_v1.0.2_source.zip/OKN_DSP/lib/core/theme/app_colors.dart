import 'package:flutter/material.dart';

class AppColors {
  AppColors._();

  static const Color background = Color(0xFF020A14);
  static const Color background2 = Color(0xFF031526);
  static const Color panel = Color(0xFF06223B);
  static const Color panelSoft = Color(0xFF0A2A47);
  static const Color border = Color(0xFF0A4D82);

  static const Color cyan = Color(0xFF00D7FF);
  static const Color electricBlue = Color(0xFF168CFF);
  static const Color deepBlue = Color(0xFF0066FF);
  static const Color magenta = Color(0xFFFF3CE7);
  static const Color green = Color(0xFF00F08A);
  static const Color orange = Color(0xFFFF9C28);
  static const Color yellow = Color(0xFFFFE43B);
  static const Color red = Color(0xFFFF365C);
  static const Color purple = Color(0xFFB43CFF);

  static const Color textPrimary = Color(0xFFF5FAFF);
  static const Color textSecondary = Color(0xFF9FC7EC);
  static const Color trackOff = Color(0xFF234A70);
}
