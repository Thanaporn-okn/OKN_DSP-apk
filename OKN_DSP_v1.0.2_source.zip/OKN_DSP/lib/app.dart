import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'core/theme/app_colors.dart';
import 'core/theme/app_theme.dart';
import 'screens/crossover_screen.dart';
import 'screens/delay_screen.dart';
import 'screens/eq_screen.dart';
import 'screens/home_screen.dart';
import 'screens/output_screen.dart';
import 'state/dsp_controller.dart';

class OknDspApp extends StatelessWidget {
  const OknDspApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'OKN DSP Control',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark,
      home: const MainShell(),
    );
  }
}

class MainShell extends StatelessWidget {
  const MainShell({super.key});

  static const List<Widget> _screens = <Widget>[
    HomeScreen(),
    EqScreen(),
    CrossoverScreen(),
    DelayScreen(),
    OutputScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    final DspController controller = context.watch<DspController>();

    return Scaffold(
      body: IndexedStack(
        index: controller.selectedPage,
        children: _screens,
      ),
      bottomNavigationBar: NavigationBar(
        backgroundColor: AppColors.background2,
        indicatorColor: const Color(0x440066FF),
        selectedIndex: controller.selectedPage,
        onDestinationSelected: controller.selectPage,
        destinations: const <NavigationDestination>[
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.multiline_chart), label: 'EQ'),
          NavigationDestination(icon: Icon(Icons.filter_alt_outlined), label: 'Crossover'),
          NavigationDestination(icon: Icon(Icons.schedule), label: 'Delay'),
          NavigationDestination(icon: Icon(Icons.equalizer), label: 'Output'),
        ],
      ),
    );
  }
}
