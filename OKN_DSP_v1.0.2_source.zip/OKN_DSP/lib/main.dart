import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'app.dart';
import 'state/dsp_controller.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  runApp(
    ChangeNotifierProvider<DspController>(
      create: (_) => DspController(),
      child: const OknDspApp(),
    ),
  );
}
