import 'package:flutter_test/flutter_test.dart';
import 'package:okn_dsp/state/dsp_controller.dart';

void main() {
  test('delay conversion uses 34.3 cm per ms', () {
    expect(DspController.msToCm(1.0), closeTo(34.3, 0.0001));
    expect(DspController.cmToMs(34.3), closeTo(1.0, 0.0001));
  });

  test('master volume is clamped to DSP range', () {
    final DspController controller = DspController();
    controller.setMasterVolume(99.0);
    expect(controller.masterVolumeDb, 12.0);

    controller.setMasterVolume(-99.0);
    expect(controller.masterVolumeDb, -60.0);
  });
}
