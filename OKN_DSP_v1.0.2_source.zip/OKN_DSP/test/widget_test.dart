import 'package:flutter_test/flutter_test.dart';
import 'package:okn_dsp/app.dart';
import 'package:okn_dsp/state/dsp_controller.dart';
import 'package:provider/provider.dart';

void main() {
  testWidgets('OKN DSP app starts on Home', (WidgetTester tester) async {
    await tester.pumpWidget(
      ChangeNotifierProvider<DspController>(
        create: (_) => DspController(),
        child: const OknDspApp(),
      ),
    );

    await tester.pumpAndSettle();

    expect(find.text('Home'), findsWidgets);
  });
}
