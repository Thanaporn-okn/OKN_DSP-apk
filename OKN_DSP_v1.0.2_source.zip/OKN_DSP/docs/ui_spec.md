# UI Reference Specification

Reference canvas: 864 x 1536 px (9:16), treated as 432 x 768 logical pixels.

## image_0.png — Home
- Dark navy/black background
- Cyan/blue neon header and connection card
- Master Volume, Bass Volume, Bass Cutoff, Bass Boost, Middle Boost, Treble Boost
- Audio Source, System Preset, Device Status
- Bottom navigation: Home / EQ / Crossover / Delay / Output

## image_1.png — Parametric EQ
- CH1–CH7 channel tabs
- Parametric EQ graph
- 15 bands split into pages 1–6, 7–12, 13–15
- Band type, frequency, gain, Q and power
- Preset save/manage area

## image_2.png — Crossover
- HPF and LPF magnitude graph
- Filter type / frequency / slope
- Bypass controls
- Phase, Polarity, L/R Link and Output Mode

## image_3.png — Delay
- Vehicle/listening position visual
- ms/cm mode
- CH1–CH7 delay controls
- Conversion reference: 343 m/s at 20°C = 34.3 cm/ms

## image_4.png — Output
- Master Output
- CH1–CH7 output trims
- Mute / Solo / Phase / Link
- Output level overview meters
