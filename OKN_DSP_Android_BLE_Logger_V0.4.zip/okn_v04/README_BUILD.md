# OKN DSP Android BLE Logger v0.4.0

Mobile-first BLE diagnostic app for the DSP research bundle.

## Build from GitHub
1. Put this project in a GitHub repository.
2. Add `.github/workflows/build-apk.yml` from the separate workflow file supplied with this release.
3. Open **Actions** → **Build OKN DSP APK** → **Run workflow**.
4. Download the `OKN-DSP-v0.4.0-debug` artifact.

The app intentionally does not send DSP write commands. It discovers GATT services, enables notifications where possible, and logs RX packets as HEX for protocol validation.
