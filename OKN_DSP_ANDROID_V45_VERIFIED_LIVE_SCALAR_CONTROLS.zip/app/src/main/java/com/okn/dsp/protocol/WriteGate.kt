package com.okn.dsp.protocol

/**
 * V45 gate.
 * Generic writes remain disabled. Only the explicit verified scalar allow-list and
 * the constrained evidence proof may issue WRITE 0x57. SaveParams ID=7, EQ,
 * presets, delay and unknown actuator writes remain blocked.
 */
object WriteGate {
    const val enabled: Boolean = false
    const val controlledMasterVolumeProofEnabled: Boolean = true
    const val verifiedScalarControlsEnabled: Boolean = true
}
