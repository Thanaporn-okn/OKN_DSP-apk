OKN_DSP V102 — UI INTERACTION HARDENING

VersionCode: 102
VersionName: 9.1.0-v102-ui-interaction-hardening

Purpose
- Continue V101 complete UI refresh into real-use interaction hardening.
- Preserve the verified DSP protocol/transport/repository core byte-for-byte.

UI changes
- EQ LIVE EDIT badge is shown only when the selected PEAKING band is structurally writable AND the current session Health Gate is PASS.
- Offline but structurally writable EQ bands show OFFLINE; non-writable bands show READ ONLY.
- More screen now exposes Connect/Scan when disconnected and Manage Connection when connected.
- Live module cards are actionable: EQ opens the real EQ screen; SaveParams opens the guarded System page.
- Locked modules stay non-clickable and explicitly describe the evidence boundary.
- System SaveParams card shows pending local changes using DspState.dirtyLocal.
- Bottom navigation and actionable module cards have content descriptions.

Safety
- No new DSP packet, UUID, scalar ID, EQ actuator, crossover/delay/output/preset writer, or auto SaveParams path was added.
- Verified scalar/EQ writer boundaries remain unchanged.
