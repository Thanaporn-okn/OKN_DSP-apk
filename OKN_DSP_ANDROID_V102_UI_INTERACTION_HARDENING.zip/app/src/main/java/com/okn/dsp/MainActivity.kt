package com.okn.dsp

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.database.ContentObserver
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.KeyEvent
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.okn.dsp.app.DspViewModel
import com.okn.dsp.protocol.VerifiedScalarControls
import com.okn.dsp.smoothing.PhoneVolumeBridge
import com.okn.dsp.state.ConnectionState
import com.okn.dsp.ui.*
import kotlin.math.abs

class MainActivity : Activity(), UiActions {
    private lateinit var vm: DspViewModel
    private lateinit var ui: OknDspUi
    private lateinit var phoneVolume: PhoneVolumeBridge
    private val main = Handler(Looper.getMainLooper())
    private val scanDevices = linkedMapOf<String, Triple<BluetoothDevice, String, Int>>()
    private var scanDialog: AlertDialog? = null
    private var scanList: LinearLayout? = null
    private var autoReconnectAttempted = false
    private var ignorePhoneVolumeUntil = 0L
    private var lastMasterSeen: Float? = null

    private val volumeObserver = object : ContentObserver(main) {
        override fun onChange(selfChange: Boolean) {
            super.onChange(selfChange)
            if (System.currentTimeMillis() < ignorePhoneVolumeUntil) return
            if (!::phoneVolume.isInitialized) return
            val db = phoneVolume.masterDbFromPhone()
            val existing = vm.store.value().scalars[2]
            if (existing != null && abs(existing - db) > 0.06f) vm.dsp.setScalar(2, db, "phone-volume-observer")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = OknColors.BG
        window.navigationBarColor = OknColors.BG

        vm = DspViewModel(this)
        phoneVolume = PhoneVolumeBridge(this)
        ui = OknDspUi(this, vm.store, this)
        setContentView(ui.view)

        vm.dsp.onDeviceFound = { device, name, rssi -> main.post { onScanDevice(device, name, rssi) } }
        vm.dsp.onToast = { msg -> main.post { toast(msg) } }
        vm.dsp.onSaveFinished = { ok, msg -> main.post { toast(if (ok) "✓ $msg" else "⚠ $msg") } }

        vm.store.subscribe { s ->
            val master = s.scalars[2]
            if (master != null && master.isFinite() && lastMasterSeen?.let { abs(it - master) > .03f } != false) {
                lastMasterSeen = master
                ignorePhoneVolumeUntil = System.currentTimeMillis() + 300L
                phoneVolume.syncPhoneFromMaster(master)
            }
        }

        contentResolver.registerContentObserver(Settings.System.CONTENT_URI, true, volumeObserver)
        main.postDelayed({ tryAutoReconnect() }, 550L)
    }

    override fun onResume() {
        super.onResume()
        if (!autoReconnectAttempted) main.postDelayed({ tryAutoReconnect() }, 250L)
    }

    override fun onStop() {
        vm.dsp.flushLocal()
        super.onStop()
    }

    override fun onDestroy() {
        runCatching { contentResolver.unregisterContentObserver(volumeObserver) }
        vm.dsp.flushLocal()
        scanDialog?.dismiss()
        ui.dispose()
        if (isFinishing) vm.dsp.disconnect()
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        ui.rebuildForConfiguration()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (!ui.onBackPressed()) super.onBackPressed()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val isVolume = event.keyCode == KeyEvent.KEYCODE_VOLUME_UP || event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN
        val result = super.dispatchKeyEvent(event)
        if (isVolume && event.action == KeyEvent.ACTION_DOWN && !phoneVolume.isProgrammatic()) {
            main.postDelayed({
                if (System.currentTimeMillis() < ignorePhoneVolumeUntil) return@postDelayed
                val db = phoneVolume.masterDbFromPhone()
                vm.dsp.setScalar(2, db, "phone-volume-key")
            }, 28L)
        }
        return result
    }

    // ---------------- UI actions ----------------
    override fun scanConnect() {
        val s = vm.store.value()
        if (s.connection == ConnectionState.CONNECTED) {
            AlertDialog.Builder(this)
                .setTitle("OKN_DSP")
                .setItems(arrayOf("Scan / Connect another DSP", "Disconnect")) { _, which -> if (which == 0) startScanDialog() else vm.devices.disconnect() }
                .show()
        } else startScanDialog()
    }

    override fun disconnect() = vm.devices.disconnect()
    override fun reconnect() { if (!ensurePermissions()) return; if (!vm.devices.reconnectLast()) toast("No remembered DSP device") }
    override fun refresh() { if (!vm.devices.refresh()) toast("Refresh unavailable until authenticated and idle") }

    override fun scalarChanged(id: Int, value: Float) {
        val c = VerifiedScalarControls.byId(id) ?: return
        val stepped = if (c.unit == "Hz") value else (value * 10f).toInt() / 10f
        if (id == 2) {
            ignorePhoneVolumeUntil = System.currentTimeMillis() + 300L
            phoneVolume.syncPhoneFromMaster(stepped)
        }
        vm.dsp.setScalar(id, stepped, "ui-slider")
    }

    override fun channelSelected(channel: Int, openEditor: Boolean) = vm.dsp.selectChannel(channel)
    override fun bandSelected(band: Int) = vm.dsp.selectBand(band)
    override fun eqChanged(channel: Int, band: Int, frequency: Float, q: Float, gain: Float) = vm.dsp.setEq(channel, band, frequency, q, gain, "eq-editor")
    override fun linkAllChanged(enabled: Boolean) = vm.dsp.setLinkAll(enabled)

    override fun saveParams() {
        val s = vm.store.value()
        if (!s.healthGatePass || !s.protocolIdle || s.saveInFlight) { toast("Save blocked: device must be connected, verified and idle"); return }
        AlertDialog.Builder(this)
            .setTitle("SaveParams (Guarded)")
            .setMessage("บันทึกค่าปัจจุบันลง DSP แบบถาวร?\n\nManual only. Never automatic.\nWrite only verified parameters.\nKeep device stable during write.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save to Device") { _, _ -> if (!vm.dsp.saveParamsManual()) toast("Save could not start") }
            .show()
    }

    override fun showLogs() {
        val tv = TextView(this).apply {
            text = vm.dsp.logSnapshot().ifBlank { "No debug log yet." }
            setTextColor(OknColors.TEXT); setTextIsSelectable(true); textSize = 10f
            setPadding(dp(12), dp(10), dp(12), dp(10)); setBackgroundColor(OknColors.BG)
            typeface = android.graphics.Typeface.MONOSPACE
        }
        val sc = ScrollView(this).apply { addView(tv, ViewGroup.LayoutParams(-1,-2)) }
        AlertDialog.Builder(this).setTitle("OKN_DSP Debug Log").setView(sc).setPositiveButton("Close",null).show()
    }

    override fun resetEqViewport() = Unit

    // ---------------- BLE permissions / scan dialog ----------------
    private fun startScanDialog() {
        if (!ensurePermissions()) return
        val manager = getSystemService(android.bluetooth.BluetoothManager::class.java)
        if (manager?.adapter?.isEnabled != true) {
            runCatching { startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)) }
            toast("Please enable Bluetooth, then tap Connect again")
            return
        }
        scanDevices.clear()
        scanList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8),dp(8),dp(8),dp(8)) }
        val scroll = ScrollView(this).apply { addView(scanList, ViewGroup.LayoutParams(-1,-2)) }
        scanList?.addView(text("Scanning for DSP…",12,OknColors.MUTED,false,android.view.Gravity.CENTER).apply{pad(8,16)}, LinearLayout.LayoutParams(-1,-2))
        scanDialog?.dismiss()
        scanDialog = AlertDialog.Builder(this)
            .setTitle("Bluetooth DSP")
            .setView(scroll)
            .setNegativeButton("Cancel") { _, _ -> vm.devices.stopScan() }
            .create().also { d -> d.setOnDismissListener { vm.devices.stopScan(); scanList=null }; d.show() }
        vm.devices.scan()
    }

    private fun onScanDevice(device: BluetoothDevice, name: String, rssi: Int) {
        scanDevices[device.address] = Triple(device, name, rssi)
        val list = scanList ?: return
        list.removeAllViews()
        scanDevices.values.sortedByDescending { it.third }.forEach { (d, n, signal) ->
            val b = text("$n\n${d.address}   RSSI $signal dBm",13,OknColors.TEXT,true).apply {
                background = roundedBg(OknColors.CARD,dp(11).toFloat(),OknColors.BORDER,dp(1)); pad(12,10)
                setOnClickListener { vm.devices.stopScan(); scanDialog?.dismiss(); vm.devices.connect(d,n) }
            }
            list.addView(b, LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(7)})
        }
    }

    private fun ensurePermissions(): Boolean {
        val needed = if (Build.VERSION.SDK_INT >= 31) listOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else listOf(Manifest.permission.ACCESS_FINE_LOCATION)
        val missing = needed.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) return true
        requestPermissions(missing.toTypedArray(), REQ_BLE)
        return false
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_BLE) {
            if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) startScanDialog()
            else { vm.store.update { it.copy(connection=ConnectionState.FAILED,connectionMessage="Permission Denied",lastError="Bluetooth permission denied") }; toast("Bluetooth permission denied") }
        }
    }

    private fun tryAutoReconnect() {
        if (autoReconnectAttempted || !ensurePermissions()) return
        autoReconnectAttempted = true
        runCatching { vm.devices.reconnectLast() }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    companion object { private const val REQ_BLE = 9021 }
}
