package com.okn.dsp.ui

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Space
import android.widget.TextView
import kotlin.math.roundToInt

object OknColors {
    val BG = Color.rgb(4, 8, 15)
    val BG2 = Color.rgb(7, 13, 23)
    val CARD = Color.rgb(11, 21, 34)
    val CARD_ALT = Color.rgb(14, 27, 43)
    val SURFACE = Color.rgb(16, 31, 49)
    val SURFACE_HI = Color.rgb(19, 39, 61)
    val BORDER = Color.rgb(34, 61, 82)
    val BORDER_SOFT = Color.rgb(24, 43, 60)
    val CYAN = Color.rgb(43, 203, 255)
    val BLUE = Color.rgb(69, 130, 255)
    val TEXT = Color.rgb(244, 249, 255)
    val MUTED = Color.rgb(142, 161, 181)
    val MUTED_2 = Color.rgb(95, 116, 136)
    val GREEN = Color.rgb(67, 224, 155)
    val RED = Color.rgb(255, 92, 102)
    val YELLOW = Color.rgb(255, 208, 84)
    val PURPLE = Color.rgb(174, 106, 255)
    val PINK = Color.rgb(255, 104, 190)
    val ORANGE = Color.rgb(255, 151, 72)
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()
fun Context.sp(v: Int): Float = v * resources.displayMetrics.scaledDensity

fun roundedBg(color: Int, radius: Float, strokeColor: Int? = null, strokeWidth: Int = 1): GradientDrawable =
    GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        setColor(color)
        cornerRadius = radius
        if (strokeColor != null) setStroke(strokeWidth, strokeColor)
    }

fun View.pad(h: Int, v: Int) {
    setPadding(context.dp(h), context.dp(v), context.dp(h), context.dp(v))
}

fun Context.text(
    value: String,
    size: Int = 14,
    color: Int = OknColors.TEXT,
    bold: Boolean = false,
    gravity: Int = Gravity.START or Gravity.CENTER_VERTICAL,
): TextView = TextView(this).apply {
    text = value
    textSize = size.toFloat()
    setTextColor(color)
    this.gravity = gravity
    if (bold) setTypeface(typeface, Typeface.BOLD)
    includeFontPadding = false
}

fun Context.row(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.HORIZONTAL
    gravity = Gravity.CENTER_VERTICAL
}

fun Context.card(
    stroke: Int = OknColors.BORDER_SOFT,
    fill: Int = OknColors.CARD,
    radiusDp: Int = 18,
): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    background = roundedBg(fill, dp(radiusDp).toFloat(), stroke, dp(1))
    setPadding(dp(15), dp(14), dp(15), dp(14))
}

fun Context.softCard(): LinearLayout = card(OknColors.BORDER_SOFT, OknColors.CARD_ALT, 16)

fun View.setMargins(l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0) {
    val p = layoutParams as? ViewGroup.MarginLayoutParams ?: return
    p.setMargins(context.dp(l), context.dp(t), context.dp(r), context.dp(b))
    layoutParams = p
}

fun Context.makeSeek(min: Float, max: Float, initial: Float, onChange: (Float, Boolean) -> Unit): SeekBar =
    SeekBar(this).apply {
        this.max = 1000
        progress = (((initial - min) / (max - min)).coerceIn(0f, 1f) * 1000f).roundToInt()
        if (Build.VERSION.SDK_INT >= 21) {
            progressTintList = ColorStateList.valueOf(OknColors.CYAN)
            thumbTintList = ColorStateList.valueOf(Color.WHITE)
            progressBackgroundTintList = ColorStateList.valueOf(Color.rgb(35, 55, 72))
        }
        setPadding(0, 0, 0, 0)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, p: Int, fromUser: Boolean) {
                val v = min + (max - min) * (p / 1000f)
                onChange(v, fromUser)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
    }

fun Context.appBar(
    title: String = "OKN_DSP",
    subtitle: String = "PROFESSIONAL AUDIO CONTROL",
    back: (() -> Unit)? = null,
): LinearLayout = row().apply {
    setPadding(dp(14), dp(13), dp(14), dp(9))
    if (back != null) {
        addView(text("‹", 34, OknColors.TEXT, false, Gravity.CENTER).apply {
            background = roundedBg(OknColors.CARD_ALT, dp(14).toFloat(), OknColors.BORDER_SOFT, dp(1))
            setOnClickListener { back() }
            isClickable = true
        }, LinearLayout.LayoutParams(dp(42), dp(42)))
    }

    val brand = LinearLayout(this@appBar).apply {
        orientation = LinearLayout.VERTICAL
        gravity = if (back == null) Gravity.START else Gravity.CENTER
        val brandRow = row().apply {
            gravity = if (back == null) Gravity.START else Gravity.CENTER
            addView(text(title.substringBefore("DSP"), 21, OknColors.TEXT, true))
            if (title.contains("DSP")) addView(text("DSP", 21, OknColors.CYAN, true))
        }
        addView(brandRow)
        if (subtitle.isNotBlank()) {
            addView(text(subtitle, 9, OknColors.MUTED, true, if (back == null) Gravity.START else Gravity.CENTER).apply {
                letterSpacing = 0.08f
                setPadding(0, dp(2), 0, 0)
            })
        }
    }
    addView(brand, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
        if (back != null) leftMargin = dp(8)
    })
    if (back != null) addView(Space(this@appBar), LinearLayout.LayoutParams(dp(42), dp(42)))
}

fun Context.sectionHeader(title: String, subtitle: String? = null): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    addView(text(title, 19, OknColors.TEXT, true))
    if (!subtitle.isNullOrBlank()) {
        addView(text(subtitle, 11, OknColors.MUTED).apply { setPadding(0, dp(3), 0, 0) })
    }
}

fun Context.sectionLabel(label: String): TextView = text(label.uppercase(), 10, OknColors.MUTED, true).apply {
    letterSpacing = 0.09f
}

fun Context.neonButton(label: String, red: Boolean = false, onClick: () -> Unit): TextView =
    text(label, 13, Color.WHITE, true, Gravity.CENTER).apply {
        val accent = if (red) OknColors.RED else OknColors.CYAN
        val fill = if (red) Color.rgb(116, 34, 43) else Color.rgb(12, 93, 126)
        background = roundedBg(fill, dp(14).toFloat(), accent, dp(1))
        setPadding(dp(14), dp(12), dp(14), dp(12))
        setOnClickListener { onClick() }
        isClickable = true
        isFocusable = true
    }

fun Context.outlineButton(label: String, onClick: () -> Unit): TextView =
    text(label, 12, OknColors.TEXT, true, Gravity.CENTER).apply {
        background = roundedBg(OknColors.CARD_ALT, dp(13).toFloat(), OknColors.BORDER, dp(1))
        setPadding(dp(12), dp(10), dp(12), dp(10))
        setOnClickListener { onClick() }
        isClickable = true
        isFocusable = true
    }

fun Context.pill(label: String, accent: Int = OknColors.CYAN): TextView =
    text(label, 10, accent, true, Gravity.CENTER).apply {
        background = roundedBg(Color.argb(35, Color.red(accent), Color.green(accent), Color.blue(accent)), dp(30).toFloat(), accent, dp(1))
        setPadding(dp(9), dp(5), dp(9), dp(5))
    }

fun Context.metric(title: String, value: TextView, accent: Int = OknColors.CYAN): LinearLayout = card(OknColors.BORDER_SOFT, OknColors.CARD_ALT, 15).apply {
    setPadding(dp(11), dp(10), dp(11), dp(10))
    addView(text(title, 9, OknColors.MUTED, true))
    addView(value.apply { setTextColor(accent) }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) })
}

fun TextView.setValueText(v: String, ok: Boolean = true) {
    text = v
    setTextColor(if (ok) OknColors.CYAN else OknColors.RED)
}
