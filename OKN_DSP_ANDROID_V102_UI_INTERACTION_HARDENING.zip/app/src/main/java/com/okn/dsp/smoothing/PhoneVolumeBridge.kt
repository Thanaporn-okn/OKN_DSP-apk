package com.okn.dsp.smoothing

import android.content.Context
import android.media.AudioManager
import kotlin.math.roundToInt

/** Bidirectional STREAM_MUSIC <-> MasterVolume mapping with an explicit feedback guard. */
class PhoneVolumeBridge(context: Context) {
    private val audio = context.getSystemService(AudioManager::class.java)
    @Volatile private var programmatic = false

    fun masterDbFromPhone(): Float {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val cur = audio.getStreamVolume(AudioManager.STREAM_MUSIC).coerceIn(0, max)
        return -70f + (cur.toFloat() / max.toFloat()) * 76f
    }

    fun syncPhoneFromMaster(masterDb: Float) {
        if (programmatic) return
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val normalized = ((masterDb.coerceIn(-70f, 6f) + 70f) / 76f)
        val target = (normalized * max).roundToInt().coerceIn(0, max)
        if (audio.getStreamVolume(AudioManager.STREAM_MUSIC) == target) return
        programmatic = true
        try { audio.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0) }
        finally { programmatic = false }
    }

    fun isProgrammatic(): Boolean = programmatic
}
