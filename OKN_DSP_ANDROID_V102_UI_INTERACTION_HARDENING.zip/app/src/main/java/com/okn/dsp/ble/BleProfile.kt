package com.okn.dsp.ble

import java.util.UUID

/** UUID provenance: AB00/01/02/03 are directly observed in the 250401 HCI/GATT capture. */
object BleProfile {
    const val DEVICE_NAME = "GoloPineDSPAudioTurning"
    val AB00_SERVICE: UUID = UUID.fromString("0000ab00-0000-1000-8000-00805f9b34fb")
    val AB01_WRITE: UUID = UUID.fromString("0000ab01-0000-1000-8000-00805f9b34fb")
    val AB02_NOTIFY: UUID = UUID.fromString("0000ab02-0000-1000-8000-00805f9b34fb")
    val AB03_NOTIFY: UUID = UUID.fromString("0000ab03-0000-1000-8000-00805f9b34fb")
    val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")

    // Observed in app artifacts but exact roles remain UNVERIFIED; never used for DSP writes.
    val UNVERIFIED_40AF = listOf(
        UUID.fromString("40af0001-9479-43f6-ae95-c45fb2afb9d2"),
        UUID.fromString("40af0002-9479-43f6-ae95-c45fb2afb9d2"),
        UUID.fromString("40af0003-9479-43f6-ae95-c45fb2afb9d2"),
    )
}
