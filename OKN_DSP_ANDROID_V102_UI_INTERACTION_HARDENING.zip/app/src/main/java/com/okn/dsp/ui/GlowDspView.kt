package com.okn.dsp.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View

/** Self-drawn DSP artwork: no external/reference image is bundled in the app. */
class GlowDspView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val cyan = Color.rgb(24, 200, 255)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat().coerceAtLeast(1f)
        val h = height.toFloat().coerceAtLeast(1f)

        paint.style = Paint.Style.FILL
        paint.color = Color.rgb(2, 11, 18)
        canvas.drawRoundRect(RectF(0f, 0f, w, h), h * .12f, h * .12f, paint)

        // Cyan floor glow.
        paint.color = Color.argb(42, 24, 200, 255)
        canvas.drawOval(RectF(w * .12f, h * .64f, w * .9f, h * .92f), paint)
        paint.color = Color.argb(25, 24, 200, 255)
        canvas.drawOval(RectF(w * .03f, h * .56f, w * .98f, h * .98f), paint)

        val top = Path().apply {
            moveTo(w * .22f, h * .28f)
            lineTo(w * .75f, h * .16f)
            lineTo(w * .9f, h * .38f)
            lineTo(w * .37f, h * .52f)
            close()
        }
        paint.color = Color.rgb(16, 25, 32)
        canvas.drawPath(top, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = (w * .009f).coerceAtLeast(1f)
        paint.color = Color.argb(190, 70, 125, 150)
        canvas.drawPath(top, paint)

        val front = Path().apply {
            moveTo(w * .37f, h * .52f)
            lineTo(w * .9f, h * .38f)
            lineTo(w * .9f, h * .62f)
            lineTo(w * .37f, h * .78f)
            close()
        }
        paint.style = Paint.Style.FILL
        paint.color = Color.rgb(7, 14, 20)
        canvas.drawPath(front, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = (w * .012f).coerceAtLeast(1.2f)
        paint.color = cyan
        canvas.drawLine(w * .38f, h * .76f, w * .88f, h * .61f, paint)

        val left = Path().apply {
            moveTo(w * .22f, h * .28f)
            lineTo(w * .37f, h * .52f)
            lineTo(w * .37f, h * .78f)
            lineTo(w * .22f, h * .56f)
            close()
        }
        paint.style = Paint.Style.FILL
        paint.color = Color.rgb(10, 18, 25)
        canvas.drawPath(left, paint)

        paint.style = Paint.Style.FILL
        paint.color = Color.WHITE
        paint.textAlign = Paint.Align.CENTER
        paint.typeface = android.graphics.Typeface.DEFAULT_BOLD
        paint.textSize = (w * .095f).coerceAtMost(h * .18f)
        canvas.save()
        canvas.rotate(-13f, w * .55f, h * .34f)
        canvas.drawText("OKN_DSP", w * .55f, h * .37f, paint)
        canvas.restore()
    }
}
