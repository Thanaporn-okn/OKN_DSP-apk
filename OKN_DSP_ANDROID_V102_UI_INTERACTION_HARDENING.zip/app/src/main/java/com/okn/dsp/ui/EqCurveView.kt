package com.okn.dsp.ui

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import com.okn.dsp.protocol.EqBand48
import com.okn.dsp.protocol.EqBandCodec
import com.okn.dsp.protocol.LiveEqPolicy
import kotlin.math.*

/**
 * Real EQ state renderer. The curve is calculated from the stored biquad coefficients,
 * not from mock/sample values. Editable control points are shown only for verified
 * PEAKING(type=12) rows.
 */
class EqCurveView(context: Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var bands: List<EqBand48?> = List(15) { null }
    private var channelColor: Int = OknColors.CYAN
    private var selectedBand: Int = 1
    private var onBandTap: ((Int) -> Unit)? = null
    private var viewportResetToken = 0

    fun bind(newBands: List<EqBand48?>, color: Int, selected: Int = selectedBand) {
        bands = newBands.take(15) + List((15 - newBands.size).coerceAtLeast(0)) { null }
        channelColor = color
        selectedBand = selected.coerceIn(1, 15)
        invalidate()
    }

    fun setOnBandTap(listener: ((Int) -> Unit)?) { onBandTap = listener }
    fun resetViewport() { viewportResetToken++; invalidate() }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val h = if (MeasureSpec.getMode(heightMeasureSpec) == MeasureSpec.EXACTLY) MeasureSpec.getSize(heightMeasureSpec)
        else (w * 0.55f).toInt().coerceAtLeast(context.dp(180))
        setMeasuredDimension(w, h)
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val left = context.dp(34).toFloat()
        val top = context.dp(14).toFloat()
        val right = width - context.dp(10).toFloat()
        val bottom = height - context.dp(28).toFloat()
        if (right <= left || bottom <= top) return

        p.style = Paint.Style.FILL
        p.color = OknColors.BG2
        c.drawRoundRect(RectF(0f, 0f, width.toFloat(), height.toFloat()), context.dp(12).toFloat(), context.dp(12).toFloat(), p)

        p.strokeWidth = 1f
        p.style = Paint.Style.STROKE
        p.color = OknColors.BORDER_SOFT
        val gainTicks = floatArrayOf(12f, 6f, 0f, -6f, -12f)
        for (g in gainTicks) {
            val y = gainToY(g, top, bottom)
            c.drawLine(left, y, right, y, p)
            p.style = Paint.Style.FILL
            p.color = OknColors.MUTED
            p.textSize = context.sp(9)
            p.textAlign = Paint.Align.RIGHT
            c.drawText(if (g > 0) "+${g.toInt()}" else g.toInt().toString(), left - context.dp(5), y + context.dp(3), p)
            p.style = Paint.Style.STROKE; p.color = OknColors.BORDER_SOFT
        }

        val freqTicks = floatArrayOf(20f, 50f, 100f, 200f, 500f, 1000f, 2000f, 5000f, 10000f, 20000f)
        for (f in freqTicks) {
            val x = freqToX(f, left, right)
            c.drawLine(x, top, x, bottom, p)
            p.style = Paint.Style.FILL
            p.color = OknColors.MUTED
            p.textSize = context.sp(8)
            p.textAlign = Paint.Align.CENTER
            val label = if (f >= 1000) "${(f / 1000).toInt()}k" else f.toInt().toString()
            c.drawText(label, x, bottom + context.dp(15), p)
            p.style = Paint.Style.STROKE; p.color = OknColors.BORDER_SOFT
        }

        val available = bands.filterNotNull()
        if (available.isNotEmpty()) {
            path.reset()
            val samples = 240
            for (i in 0 until samples) {
                val t = i / (samples - 1f)
                val freq = 20.0 * (1000.0.pow(t.toDouble())) // 20 -> 20k
                val db = available.sumOf { biquadDb(it, freq) }.coerceIn(-18.0, 18.0)
                val x = left + (right - left) * t
                val y = gainToY(db.toFloat().coerceIn(-12f, 12f), top, bottom)
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            p.style = Paint.Style.STROKE
            p.strokeWidth = context.dp(5).toFloat()
            p.color = Color.argb(48, Color.red(channelColor), Color.green(channelColor), Color.blue(channelColor))
            c.drawPath(path, p)
            p.strokeWidth = context.dp(2).toFloat()
            p.color = channelColor
            c.drawPath(path, p)
        }

        // Verified writable PEAKING points only.
        bands.forEachIndexed { idx, band ->
            if (band == null || !LiveEqPolicy.isWritable(band)) return@forEachIndexed
            val x = freqToX(band.frequency.coerceIn(20f, 20000f), left, right)
            val y = gainToY(band.boostDb.coerceIn(-12f, 12f), top, bottom)
            val selected = idx + 1 == selectedBand
            p.style = Paint.Style.FILL
            p.color = if (selected) Color.WHITE else channelColor
            c.drawCircle(x, y, context.dp(if (selected) 5 else 4).toFloat(), p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = context.dp(2).toFloat()
            p.color = channelColor
            c.drawCircle(x, y, context.dp(if (selected) 8 else 6).toFloat(), p)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action != MotionEvent.ACTION_DOWN && event.action != MotionEvent.ACTION_UP) return true
        if (event.action == MotionEvent.ACTION_UP) {
            val left = context.dp(34).toFloat(); val right = width - context.dp(10).toFloat()
            val top = context.dp(14).toFloat(); val bottom = height - context.dp(28).toFloat()
            var bestBand = -1; var bestD = Float.MAX_VALUE
            bands.forEachIndexed { i, band ->
                if (band == null || !LiveEqPolicy.isWritable(band)) return@forEachIndexed
                val x = freqToX(band.frequency.coerceIn(20f, 20000f), left, right)
                val y = gainToY(band.boostDb.coerceIn(-12f, 12f), top, bottom)
                val d = hypot(event.x - x, event.y - y)
                if (d < bestD) { bestD = d; bestBand = i + 1 }
            }
            if (bestBand > 0 && bestD <= context.dp(28)) {
                selectedBand = bestBand
                invalidate()
                onBandTap?.invoke(bestBand)
            }
        }
        return true
    }

    private fun freqToX(freq: Float, left: Float, right: Float): Float {
        val t = (ln(freq / 20f) / ln(1000f)).coerceIn(0f, 1f)
        return left + (right - left) * t
    }

    private fun gainToY(db: Float, top: Float, bottom: Float): Float {
        val t = ((12f - db) / 24f).coerceIn(0f, 1f)
        return top + (bottom - top) * t
    }

    private fun biquadDb(b: EqBand48, freq: Double): Double {
        if (!listOf(b.b0,b.b1,b.b2,b.a1,b.a2).all { it.isFinite() }) return 0.0
        val w = 2.0 * Math.PI * freq / EqBandCodec.SAMPLE_RATE_HZ
        val c1 = cos(w); val s1 = sin(w); val c2 = cos(2*w); val s2 = sin(2*w)
        val nr = b.b0 + b.b1 * c1 + b.b2 * c2
        val ni = -b.b1 * s1 - b.b2 * s2
        val dr = 1.0 + b.a1 * c1 + b.a2 * c2
        val di = -b.a1 * s1 - b.a2 * s2
        val n2 = nr*nr + ni*ni
        val d2 = dr*dr + di*di
        if (n2 <= 1e-18 || d2 <= 1e-18) return 0.0
        return 10.0 * log10(n2 / d2)
    }
}
