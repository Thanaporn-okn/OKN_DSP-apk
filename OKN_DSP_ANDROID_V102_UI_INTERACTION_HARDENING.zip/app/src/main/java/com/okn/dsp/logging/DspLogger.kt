package com.okn.dsp.logging

import com.okn.dsp.BuildConfig
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicLong

/** Bounded structured log. HEX-heavy verbose lines are disabled in release builds. */
class DspLogger {
    private val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    private val seq = AtomicLong(0)
    private val lines = CopyOnWriteArrayList<String>()
    @Volatile var verbose: Boolean = BuildConfig.DEBUG

    fun log(kind: String, text: String, verboseOnly: Boolean = false) {
        if (verboseOnly && !verbose) return
        val line = "${fmt.format(Date())}\t#${seq.incrementAndGet()}\t$kind\t$text"
        lines += line
        while (lines.size > 1200) lines.removeAt(0)
    }

    fun snapshot(maxLines: Int = 300): String = lines.takeLast(maxLines).joinToString("\n")
    fun clear() = lines.clear()
}
