package com.okn.dsp.repository

import com.okn.dsp.protocol.EqBand48
import com.okn.dsp.protocol.LiveEqPolicy
import com.okn.dsp.protocol.VerifiedScalarControls
import com.okn.dsp.state.SensorValue
import org.json.JSONObject
import java.util.Locale

data class ParsedDescriptor(
    val scalars: Map<Int, Float>,
    val eq: List<List<EqBand48?>>,
    val sensors: Map<Int, SensorValue>,
    val writablePeakingCount: Int,
    val firmwareText: String?,
)

/** Parses only fields proven by the live UFE Device Description. Unknown fields are ignored. */
object DeviceDescriptionParser {
    private const val VERIFIED_EQ_CASCADE15_TYPE = 4084

    fun parse(obj: JSONObject): ParsedDescriptor {
        val scalars = linkedMapOf<Int, Float>()
        val acts = obj.optJSONArray("actuators")
        if (acts != null) {
            for (i in 0 until acts.length()) {
                val a = acts.optJSONObject(i) ?: continue
                val id = a.optInt("ID", -1)
                if (VerifiedScalarControls.allowed(id) && a.optInt("type", -1) == 2000 && a.has("UFE_TYPE_FLOAT32")) {
                    val v = a.optDouble("UFE_TYPE_FLOAT32", Double.NaN).toFloat()
                    if (v.isFinite()) scalars[id] = v
                }
            }
        }

        val eq = MutableList(7) { MutableList<EqBand48?>(15) { null } }
        var writable = 0
        for (ch in 1..7) {
            val actuator = LiveEqPolicy.actuatorForChannel(ch)
            for (band in 1..15) {
                val b = extractBand(obj, actuator, band)
                eq[ch - 1][band - 1] = b
                if (b != null && LiveEqPolicy.isWritable(b)) writable += 1
            }
        }

        val sensors = linkedMapOf<Int, SensorValue>()
        val sArr = obj.optJSONArray("sensors")
        if (sArr != null) {
            for (i in 0 until sArr.length()) {
                val s = sArr.optJSONObject(i) ?: continue
                val id = s.optInt("ID", -999)
                val name = s.optString("name", "Sensor$id")
                val raw = when {
                    s.has("UFE_TYPE_FLOAT32") -> {
                        val v = s.optDouble("UFE_TYPE_FLOAT32", Double.NaN)
                        if (v.isFinite()) String.format(Locale.US, "%.4f", v) else "NaN"
                    }
                    s.has("UFE_TYPE_BOOLEAN_INDICATE") -> s.optBoolean("UFE_TYPE_BOOLEAN_INDICATE").toString()
                    else -> "unknown"
                }
                sensors[id] = SensorValue(id, name, raw)
            }
        }

        // Firmware naming varies by firmware family. Only display it when an explicit field exists.
        val fw = sequenceOf("FirmwareVersion", "firmwareVersion", "FW", "fw")
            .mapNotNull { k -> if (obj.has(k)) obj.optString(k, null) else null }
            .firstOrNull { !it.isNullOrBlank() }

        return ParsedDescriptor(scalars, eq.map { it.toList() }, sensors, writable, fw)
    }

    private fun extractBand(obj: JSONObject, actuatorId: Int, bandIndex1: Int): EqBand48? {
        val arr = obj.optJSONArray("actuators") ?: return null
        for (i in 0 until arr.length()) {
            val a = arr.optJSONObject(i) ?: continue
            if (a.optInt("ID", -1) != actuatorId || a.optInt("type", -1) != VERIFIED_EQ_CASCADE15_TYPE) continue
            val bandArr = a.optJSONArray("UFE_TYPE_BIQUAD_CASCADE15_F") ?: return null
            val b = bandArr.optJSONObject(bandIndex1 - 1) ?: return null
            fun f(key: String) = b.optDouble(key, Double.NaN).toFloat()
            val out = EqBand48(
                type = b.optInt("typ", -1), frequency = f("F"), frequency2 = f("F2"), q = f("Q"),
                boostDb = f("B"), gain = f("G"), r = f("R"),
                b0 = f("B0"), b1 = f("B1"), b2 = f("B2"), a1 = f("A1"), a2 = f("A2")
            )
            val vals = listOf(out.frequency, out.frequency2, out.q, out.boostDb, out.gain, out.r, out.b0, out.b1, out.b2, out.a1, out.a2)
            return if (vals.all { it.isFinite() }) out else null
        }
        return null
    }
}
