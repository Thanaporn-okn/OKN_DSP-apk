package com.okn.dsp.error

/** Central user-safe error classification. Unknown errors remain recoverable and never unlock writes. */
object DspErrorHandler {
    data class Display(val title: String, val recovery: String)

    fun classify(raw: String): Display = when {
        raw.contains("permission", true) -> Display("Permission Denied", "Grant Bluetooth permission and retry.")
        raw.contains("Bluetooth Off", true) -> Display("Bluetooth Off", "Enable Bluetooth and retry.")
        raw.contains("timeout", true) -> Display("Timeout", "Reconnect the DSP; no automatic permanent save is attempted.")
        raw.contains("profile missing", true) -> Display("Unsupported Device", "Verified AB00/AB01/AB02 profile was not found.")
        raw.contains("cipher", true) || raw.contains("decrypt", true) -> Display("Protocol Session Error", "Reconnect to establish a fresh authenticated cipher stream.")
        raw.contains("write", true) -> Display("Write Failure", "Reconnect before the next DSP write.")
        else -> Display("DSP Error", "Reconnect or retry. Unverified writes remain locked.")
    }
}
