package com.okn.dsp.repository

import android.bluetooth.BluetoothDevice

/** Connection-facing facade so UI never talks to BluetoothGatt directly. */
class DeviceRepository(private val dsp: DspRepository) {
    fun scan() = dsp.startScan()
    fun stopScan() = dsp.stopScan()
    fun connect(device: BluetoothDevice, name: String) = dsp.connect(device, name)
    fun disconnect() = dsp.disconnect()
    fun reconnectLast(): Boolean = dsp.reconnectLast()
    fun refresh(): Boolean = dsp.refresh()
}
