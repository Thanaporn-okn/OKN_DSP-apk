package com.okn.dsp.persistence

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.okn.dsp.protocol.EqBand48
import com.okn.dsp.protocol.LiveEqPolicy
import com.okn.dsp.protocol.VerifiedScalarControls
import com.okn.dsp.state.DspState
import org.json.JSONObject

/** Local auto-save only. This class never emits SaveParams or any BLE command. */
class DspPreferences(context: Context) {
    // V100 keeps the V98 preference namespace intentionally so in-place upgrades retain verified local state.
    private val prefs = context.getSharedPreferences("okn_dsp_v98_local_state", Context.MODE_PRIVATE)
    private val main = Handler(Looper.getMainLooper())
    private var pending: Runnable? = null
    @Volatile private var latest: DspState? = null

    data class Snapshot(
        val scalars: Map<Int, Float>,
        val eq: Map<Pair<Int, Int>, EqBand48>,
        val selectedChannel: Int,
        val selectedBand: Int,
        val linkAll: Boolean,
        val lastAddress: String?,
        val lastName: String?,
    )

    fun schedule(state: DspState, debounceMs: Long = 180L) {
        latest = state
        pending?.let(main::removeCallbacks)
        pending = Runnable { flush() }.also { main.postDelayed(it, debounceMs) }
    }

    fun flush() {
        pending?.let(main::removeCallbacks)
        pending = null
        val s = latest ?: return
        val root = JSONObject()
        val scalar = JSONObject()
        VerifiedScalarControls.controls.forEach { c -> s.scalars[c.id]?.let { scalar.put(c.id.toString(), it.toDouble()) } }
        root.put("scalars", scalar)
        val eq = JSONObject()
        for (ch in 1..7) for (band in 1..15) {
            val b = s.eq[ch - 1][band - 1] ?: continue
            if (!LiveEqPolicy.isWritable(b)) continue
            eq.put("$ch:$band", bandToJson(b))
        }
        root.put("eq", eq)
        root.put("selectedChannel", s.selectedChannel)
        root.put("selectedBand", s.selectedEqBand)
        root.put("linkAll", s.linkAllEq)
        prefs.edit().putString("snapshot", root.toString()).apply()
    }

    fun saveLastDevice(address: String, name: String?) {
        prefs.edit().putString("lastAddress", address).putString("lastName", name ?: "DSP").apply()
    }

    fun load(): Snapshot {
        val raw = prefs.getString("snapshot", null)
        val scalars = linkedMapOf<Int, Float>()
        val eq = linkedMapOf<Pair<Int, Int>, EqBand48>()
        var selectedChannel = 1
        var selectedBand = 1
        var linkAll = false
        if (!raw.isNullOrBlank()) {
            runCatching {
                val root = JSONObject(raw)
                val so = root.optJSONObject("scalars")
                if (so != null) {
                    val keys = so.keys()
                    while (keys.hasNext()) {
                        val k = keys.next(); val id = k.toIntOrNull() ?: continue
                        val v = so.optDouble(k, Double.NaN).toFloat()
                        if (VerifiedScalarControls.sanitize(id, v) != null) scalars[id] = v
                    }
                }
                val eo = root.optJSONObject("eq")
                if (eo != null) {
                    val keys = eo.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        val p = k.split(":")
                        if (p.size != 2) continue
                        val ch = p[0].toIntOrNull() ?: continue
                        val band = p[1].toIntOrNull() ?: continue
                        val b = jsonToBand(eo.optJSONObject(k) ?: continue)
                        if (ch in 1..7 && band in 1..15 && LiveEqPolicy.isWritable(b)) eq[ch to band] = b
                    }
                }
                selectedChannel = root.optInt("selectedChannel", 1).coerceIn(1, 7)
                selectedBand = root.optInt("selectedBand", 1).coerceIn(1, 15)
                linkAll = root.optBoolean("linkAll", false)
            }
        }
        return Snapshot(
            scalars, eq, selectedChannel, selectedBand, linkAll,
            prefs.getString("lastAddress", null), prefs.getString("lastName", null)
        )
    }

    private fun bandToJson(b: EqBand48) = JSONObject().apply {
        put("typ", b.type); put("F", b.frequency); put("F2", b.frequency2); put("Q", b.q)
        put("B", b.boostDb); put("G", b.gain); put("R", b.r)
        put("B0", b.b0); put("B1", b.b1); put("B2", b.b2); put("A1", b.a1); put("A2", b.a2)
    }

    private fun jsonToBand(o: JSONObject) = EqBand48(
        type = o.optInt("typ", -1),
        frequency = o.optDouble("F", Double.NaN).toFloat(),
        frequency2 = o.optDouble("F2", Double.NaN).toFloat(),
        q = o.optDouble("Q", Double.NaN).toFloat(),
        boostDb = o.optDouble("B", Double.NaN).toFloat(),
        gain = o.optDouble("G", Double.NaN).toFloat(),
        r = o.optDouble("R", Double.NaN).toFloat(),
        b0 = o.optDouble("B0", Double.NaN).toFloat(),
        b1 = o.optDouble("B1", Double.NaN).toFloat(),
        b2 = o.optDouble("B2", Double.NaN).toFloat(),
        a1 = o.optDouble("A1", Double.NaN).toFloat(),
        a2 = o.optDouble("A2", Double.NaN).toFloat(),
    )
}
