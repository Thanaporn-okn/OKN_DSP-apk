package com.okn.dsp.protocol

/** UI metadata for the verified write surface only. Unknown IDs intentionally have no mapping. */
object ParameterMapper {
    data class Meta(val id: Int, val title: String, val thai: String, val symbol: String)
    val globals = listOf(
        Meta(2, "MasterVolume", "ระดับเสียงหลัก", "◖"),
        Meta(3, "RemindSoundVolume", "ระดับเสียงแจ้งเตือน", "♢"),
        Meta(8, "BassVolume", "ระดับเสียงเบส", "◖"),
        Meta(9, "BassCutoff", "ความถี่ตัดเบส", "▽"),
        Meta(10, "BassBoost", "เพิ่มเสียงเบส", "▥"),
        Meta(13, "MiddleBoost", "เพิ่มเสียงกลาง", "▥"),
        Meta(11, "TrebleBoost", "เพิ่มเสียงแหลม", "▥"),
    )
    private val byId = globals.associateBy { it.id }
    fun meta(id: Int): Meta? = byId[id]
    fun channelActuator(channel1: Int): Int = ConfirmedDspMap.eqActuator(channel1 - 1)
}
