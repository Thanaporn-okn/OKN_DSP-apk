package com.okn.dsp.repository

import com.okn.dsp.state.DspStateStore
import com.okn.dsp.state.SensorValue

/** Read-only sensor facade. There is deliberately no sensor write method. */
class SensorRepository(private val store: DspStateStore) {
    fun current(): Map<Int, SensorValue> = store.value().sensors
}
