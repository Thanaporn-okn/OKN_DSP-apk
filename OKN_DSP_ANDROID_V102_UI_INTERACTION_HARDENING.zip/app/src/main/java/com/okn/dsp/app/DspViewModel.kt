package com.okn.dsp.app

import android.content.Context
import com.okn.dsp.logging.DspLogger
import com.okn.dsp.persistence.DspPreferences
import com.okn.dsp.repository.DeviceRepository
import com.okn.dsp.repository.DspRepository
import com.okn.dsp.repository.SensorRepository
import com.okn.dsp.state.DspStateStore

/** Process-in-Activity ViewModel/state holder. MainActivity retains it across configChanges. */
class DspViewModel(context: Context) {
    val store = DspStateStore()
    val logger = DspLogger()
    val dsp = DspRepository(context.applicationContext, store, logger, DspPreferences(context.applicationContext))
    val devices = DeviceRepository(dsp)
    val sensors = SensorRepository(store)
}
