package com.okn.dsp.state

import android.os.Handler
import android.os.Looper
import com.okn.dsp.protocol.EqBand48
import java.util.concurrent.CopyOnWriteArrayList

/** Single source of truth shared by every screen. */
class DspStateStore(initial: DspState = DspState()) {
    private val main = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArrayList<(DspState) -> Unit>()
    @Volatile private var current: DspState = initial

    fun value(): DspState = current

    fun subscribe(listener: (DspState) -> Unit): () -> Unit {
        listeners += listener
        main.post { listener(current) }
        return { listeners -= listener }
    }

    fun update(transform: (DspState) -> DspState) {
        val next = synchronized(this) { transform(current).also { current = it } }
        if (Looper.myLooper() == Looper.getMainLooper()) notifyNow(next) else main.post { notifyNow(next) }
    }

    private fun notifyNow(state: DspState) = listeners.forEach { it(state) }

    fun setScalar(id: Int, value: Float, dirty: Boolean = true) = update { s ->
        s.copy(scalars = s.scalars.toMutableMap().apply { put(id, value) }, dirtyLocal = s.dirtyLocal || dirty)
    }

    fun setEqBand(channel1: Int, band1: Int, band: EqBand48, dirty: Boolean = true) = update { s ->
        val rows = s.eq.map { it.toMutableList() }.toMutableList()
        rows[channel1.coerceIn(1, 7) - 1][band1.coerceIn(1, 15) - 1] = band
        s.copy(eq = rows.map { it.toList() }, dirtyLocal = s.dirtyLocal || dirty)
    }

    fun selectChannel(channel1: Int) = update { it.copy(selectedChannel = channel1.coerceIn(1, 7)) }
    fun selectBand(band1: Int) = update { it.copy(selectedEqBand = band1.coerceIn(1, 15)) }
    fun setLinkAll(enabled: Boolean) = update { it.copy(linkAllEq = enabled) }
}
