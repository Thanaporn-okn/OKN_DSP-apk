package com.okn.dsp.ui

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import com.okn.dsp.state.DspState
import com.okn.dsp.state.DspStateStore

/**
 * V101 production UI shell. Presentation is replaced end-to-end while the verified DSP
 * repository/protocol/transport boundary remains unchanged.
 */
class OknDspUi(
    private val context: Context,
    private val store: DspStateStore,
    private val delegate: UiActions,
) {
    val view: View
    private val host = FrameLayout(context)
    private val navButtons = mutableListOf<LinearLayout>()
    private var tab = 0
    private var unsubscribe: (() -> Unit)? = null
    private var state = store.value()

    private lateinit var home: HomeScreen
    private lateinit var controls: GlobalScreen
    private lateinit var eq: EqScreen
    private lateinit var system: SensorsScreen
    private lateinit var more: MoreScreen

    private val actions = object : UiActions by delegate {
        override fun channelSelected(channel: Int, openEditor: Boolean) {
            delegate.channelSelected(channel, false)
            if (openEditor) {
                selectTab(2)
                eq.openEditor(channel)
            }
        }

        override fun resetEqViewport() {
            eq.resetViewport()
            delegate.resetEqViewport()
        }
    }

    init {
        rebuildScreens()
        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(OknColors.BG)
            addView(host, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(buildBottomNav(), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, context.dp(72)))
        }
        view = root
        selectTab(0)
        unsubscribe = store.subscribe { s ->
            state = s
            bindAll(s)
        }
    }

    fun dispose() {
        unsubscribe?.invoke()
        unsubscribe = null
    }

    fun onBackPressed(): Boolean {
        if (tab == 2 && eq.backToOverview()) return true
        if (tab != 0) {
            selectTab(0)
            return true
        }
        return false
    }

    fun rebuildForConfiguration() {
        val selected = tab
        val editorWasOpen = eq.isEditor()
        rebuildScreens()
        selectTab(selected)
        if (selected == 2 && editorWasOpen) eq.openEditor(state.selectedChannel)
        bindAll(state)
    }

    private fun rebuildScreens() {
        home = HomeScreen(context, actions)
        controls = GlobalScreen(context, actions)
        eq = EqScreen(context, actions)
        system = SensorsScreen(context, actions)
        more = MoreScreen(
            context = context,
            actions = actions,
            openEq = { selectTab(2) },
            openSystem = { selectTab(3) },
        )
    }

    private fun buildBottomNav(): View = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER
        setPadding(context.dp(6), context.dp(6), context.dp(6), context.dp(7))
        setBackgroundColor(Color.rgb(7, 13, 23))

        val items = listOf(
            "⌂" to "Home",
            "≡" to "Controls",
            "⌁" to "EQ",
            "◈" to "System",
            "•••" to "More",
        )

        items.forEachIndexed { index, item ->
            val box = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(context.dp(2), context.dp(3), context.dp(2), context.dp(3))
                val icon = context.text(item.first, if (index == 4) 16 else 19, OknColors.MUTED, true, Gravity.CENTER).apply { tag = "icon" }
                val label = context.text(item.second, 9, OknColors.MUTED, false, Gravity.CENTER).apply { tag = "label" }
                addView(icon, LinearLayout.LayoutParams(-1, context.dp(30)))
                addView(label, LinearLayout.LayoutParams(-1, context.dp(22)))
                setOnClickListener { selectTab(index) }
                contentDescription = "Open ${item.second}"
                isClickable = true
                isFocusable = true
            }
            navButtons += box
            addView(box, LinearLayout.LayoutParams(0, -1, 1f).apply {
                if (index > 0) leftMargin = context.dp(2)
            })
        }
    }

    fun selectTab(index: Int) {
        tab = index.coerceIn(0, 4)
        host.removeAllViews()
        val screen: BoundScreen = when (tab) {
            0 -> home
            1 -> controls
            2 -> eq
            3 -> system
            else -> more
        }
        host.addView(screen.view, FrameLayout.LayoutParams(-1, -1))

        navButtons.forEachIndexed { i, button ->
            val active = i == tab
            val icon = button.findViewWithTag<android.widget.TextView>("icon")
            val label = button.findViewWithTag<android.widget.TextView>("label")
            icon.setTextColor(if (active) OknColors.CYAN else OknColors.MUTED_2)
            label.setTextColor(if (active) OknColors.TEXT else OknColors.MUTED_2)
            label.setTypeface(label.typeface, if (active) Typeface.BOLD else Typeface.NORMAL)
            button.background = if (active) {
                roundedBg(Color.rgb(15, 35, 54), context.dp(16).toFloat(), OknColors.BORDER, context.dp(1))
            } else null
        }
        screen.bind(state)
    }

    private fun bindAll(s: DspState) {
        home.bind(s)
        controls.bind(s)
        eq.bind(s)
        system.bind(s)
        more.bind(s)
    }
}
