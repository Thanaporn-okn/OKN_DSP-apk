import com.okn.dsp.protocol.*
import kotlin.math.abs

fun main() {
    fun ByteArray.hex() = ByteCodec.run { toHex() }
    fun check(name: String, ok: Boolean) {
        if (!ok) error("FAIL: $name")
        println("PASS: $name")
    }
    val master = UfeCodec.encodeFloat32Write(ConfirmedDspMap.MASTER_VOLUME, -13.76f)
    check("MasterVolume packet vector", master.hex() == "570000000200000004F6285CC1")
    check("SaveParams exact manual trigger", SaveParamsPolicy.encodeTrigger().hex() == "570000000700000000")
    check("Verified scalar allow-list", VerifiedScalarControls.controls.map { it.id } == listOf(2,3,8,9,10,13,11))
    check("EQ actuator map", (1..7).map { LiveEqPolicy.actuatorForChannel(it) } == listOf(4,5,6,14,15,16,17))
    val captured = ByteCodec.hexToBytes("0C0000000080C7430000000052B80E408FC275410000000000000000D441833FA53FFEBF44CE763FA53FFEBFEB517D3F")
    val band = EqBandCodec.decode(captured)
    check("EQ48 captured type/F/Q", band.type == 12 && abs(band.frequency - 399f) < .001f && abs(band.q - 2.23f) < .001f)
    val write = UfeCodec.encodeWrite(4, 288, captured)
    check("EQ CH1 band7 57-byte UFE write", write.size == 57 && write.copyOfRange(0,9).hex() == "570000000401200030")
    val key = ByteCodec.hexToBytes("81162308EBF817D62C083CD5250A2D4D")
    check("Continuous session CFB8 first descriptor request", SessionTxCipher(key).encryptNext(SessionCryptoFacts.DEVICE_DESCRIPTION_REQUEST).hex() == "AC6B6C12")
    check("Generic writes locked", !WriteGate.enabled)
}
