#!/usr/bin/env python3
from pathlib import Path
import hashlib, sys
ROOT = Path(__file__).resolve().parent
def sha(rel): return hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()
def text(rel): return (ROOT/rel).read_text(errors="replace")
def need(cond,msg):
    print(("PASS: " if cond else "FAIL: ")+msg)
    if not cond: sys.exit(1)
def illegal_string_newline(src):
    NORMAL,LINE,BLOCK,STRING,RAW,CHAR=range(6); state=NORMAL; i=0
    while i < len(src):
        if state==NORMAL:
            if src.startswith("//",i): state=LINE; i+=2; continue
            if src.startswith("/*",i): state=BLOCK; i+=2; continue
            if src.startswith(chr(34)*3,i): state=RAW; i+=3; continue
            if src[i]==chr(34): state=STRING; i+=1; continue
            if src[i]==chr(39): state=CHAR; i+=1; continue
            i+=1; continue
        if state==LINE:
            if src[i]=="\n": state=NORMAL
            i+=1; continue
        if state==BLOCK:
            if src.startswith("*/",i): state=NORMAL; i+=2; continue
            i+=1; continue
        if state==RAW:
            if src.startswith(chr(34)*3,i): state=NORMAL; i+=3; continue
            i+=1; continue
        if state in (STRING,CHAR):
            if src[i]=="\n": return True
            if src[i]=="\\": i+=2; continue
            if (state==STRING and src[i]==chr(34)) or (state==CHAR and src[i]==chr(39)): state=NORMAL
            i+=1; continue
    return state==STRING
need(sha("app/okn_dsp_stable_debug.keystore") == "ba1c52f2607c09953c52fdd79c5f72026aaf0adb8aa44bcba277f7d9b49d9511", "stable signing keystore unchanged")
frozen = {
    'app/src/main/java/com/okn/dsp/MainActivity.kt': '0bf0597344f6a278bcd28ea7323aa4e364327f32e80e07480d818b4693710279',
    'app/src/main/java/com/okn/dsp/app/DspViewModel.kt': 'cacdf89b0813d00f2a1c8007b86aba7fa3a59cc5b43d1c68c070f27028a71b27',
    'app/src/main/java/com/okn/dsp/ble/BleDspManager.kt': 'f1b936be27a1a01b8b8f0ec37f7e86098e874190ec9799718bfcbe0bea7383c3',
    'app/src/main/java/com/okn/dsp/ble/BleProfile.kt': '31da8f534c01f85c9bee2cfcd413d2afcf817e3a338c137a736bab4f5c03869f',
    'app/src/main/java/com/okn/dsp/error/DspErrorHandler.kt': '6ea028759266f90d2717490dbf610eba553e1922c44fae5a553c17ff713f805f',
    'app/src/main/java/com/okn/dsp/logging/DspLogger.kt': '686417a2d77187f063dc33cdf3296036f39dabce8839df787dbfcfb81f0cb72b',
    'app/src/main/java/com/okn/dsp/persistence/DspPreferences.kt': '7b8c383aac23612db157d13eef2de069730416dbf1653963288489c25279e5c6',
    'app/src/main/java/com/okn/dsp/protocol/ByteCodec.kt': '04843cec90b69886607d98a0aabf0ad81812fc8d25df913c5b1847a10fd7a3ae',
    'app/src/main/java/com/okn/dsp/protocol/ConfirmedDspMap.kt': '6e68295f194dd0b0f70d0b83b9ba2324a9a2a8eaf2350b5d5a821f838ae2c66d',
    'app/src/main/java/com/okn/dsp/protocol/EqBandCodec.kt': '4f033a406e363b2418af9b39fa2e42a13674b09f9de2bb7acf1eb6ff1918cd58',
    'app/src/main/java/com/okn/dsp/protocol/LiveEqPolicy.kt': '4bfa2678b824e5776d332214fcce1dd6e571e3aa2157c1bfb0e61da774b52090',
    'app/src/main/java/com/okn/dsp/protocol/ParameterMapper.kt': 'a74ed15424edd72c6f4413e93fbc1de152e574b5a4c8dc7e2eb2c245ab93182a',
    'app/src/main/java/com/okn/dsp/protocol/PreAuthRandKeyDecoder.kt': '58d8a287449c849fb925070ac1f61ea26ba02875f58605fd7008439da78533ac',
    'app/src/main/java/com/okn/dsp/protocol/SaveParamsPolicy.kt': '88005dba77d2b84597f5bd5e23eaaacec7d25b59dc0f38b8affbde2d2cfbeb85',
    'app/src/main/java/com/okn/dsp/protocol/SessionCrypto.kt': 'bae330efd6e9beb628b287e43e36bd98d80b3f9b4d1c014f65c63ef16efa586e',
    'app/src/main/java/com/okn/dsp/protocol/UfeCodec.kt': 'b47f66afec8fd3383581c30b2dc1ad9ad41e3b7089f427f0b094e91581588c34',
    'app/src/main/java/com/okn/dsp/protocol/UfeConstants.kt': 'e64de468c11d80ea052b97c9298a0a8a7f8cc49362f5bd06193d2c7c6d0108aa',
    'app/src/main/java/com/okn/dsp/protocol/VerifiedScalarControls.kt': '4c096b001523704dcb6aa36496dd17263d6df84a0a1fee20c2fc40d60e898f6b',
    'app/src/main/java/com/okn/dsp/protocol/WriteGate.kt': '8aa82bb069dd64dc2d1274801f1f4420a764f52670246e9c813b0723531be472',
    'app/src/main/java/com/okn/dsp/queue/RealtimeCommandQueue.kt': '808a226f5dba17f0328634e4c9c28d121c487ceac64d2c7d6e0afc46c3c4d188',
    'app/src/main/java/com/okn/dsp/repository/DeviceDescriptionParser.kt': '6d174dbf301e8c85469786960e10597bef2f13f4bfc5f1e167ce7a81bc1e29be',
    'app/src/main/java/com/okn/dsp/repository/DeviceRepository.kt': '6fd2640d0db471d727833c7e0d243abf80c81c9de8e705374ad0b4df5013e703',
    'app/src/main/java/com/okn/dsp/repository/DspRepository.kt': '992de978d67d0ff2fa9976815a5e8222e0f584a003498ec0109304d64b787459',
    'app/src/main/java/com/okn/dsp/repository/SensorRepository.kt': 'ca3ece2a649411fe68bebb21da60b1979673eedf8aa610a1e0ff84ed28f13831',
    'app/src/main/java/com/okn/dsp/smoothing/EqSlewController.kt': '8b5e95aaaca55c05eeb6397af81e60d8205b038cdd99ffb81636ac4ca6b6dcad',
    'app/src/main/java/com/okn/dsp/smoothing/PhoneVolumeBridge.kt': '182177a12003f5501298d0f9d4458ccecd6e1d111375a4d03dd9a9258d770038',
    'app/src/main/java/com/okn/dsp/smoothing/ScalarRampController.kt': '8b7eb69d6ce8fec13558800159d714fab71a570e9decc3012aaf984f2e4f9f3b',
    'app/src/main/java/com/okn/dsp/state/DspModels.kt': '555599aadbb835c2d783fdc0c6835baf77fc95c0e7ea0fb1ccd8ddab2491a4b3',
    'app/src/main/java/com/okn/dsp/state/DspStateStore.kt': 'd43450e1aaf704385f4c7b648c2cd46c01a413763c6115804c65a0cd46d617bb',
}
for rel,expected in frozen.items(): need(sha(rel)==expected, "frozen non-UI core "+rel)
gradle=text("app/build.gradle.kts")
need("versionCode = 102" in gradle, "V102 versionCode")
need("9.1.0-v102-ui-interaction-hardening" in gradle, "V102 versionName")
screens=text("app/src/main/java/com/okn/dsp/ui/Screens.kt")
nav=text("app/src/main/java/com/okn/dsp/ui/OknDspUi.kt")
need('"LIVE EDIT"' in screens, 'EQ live edit state exists')
need('"OFFLINE"' in screens, 'EQ offline state exists')
need('"READ ONLY"' in screens, 'EQ read-only state exists')
need('val liveWritable = structurallyWritable && state.healthGatePass' in screens, 'EQ live editing requires Health Gate')
need('"Connect / Scan DSP"' in screens, 'More screen direct connect action')
need('Module("Crossover", "Hardware write locked", false)' in screens, 'Crossover stays locked')
need('Module("Delay", "Hardware write locked", false)' in screens, 'Delay stays locked')
need('Module("Mixer / Output", "Hardware write locked", false)' in screens, 'Mixer/Output stays locked')
need('Module("Presets", "Local concept only", false)' in screens, 'Preset hardware write not invented')
need('state.dirtyLocal -> "Local changes pending • tap Save to persist"' in screens, 'dirty local state visible')
need('actions.saveParams()' in screens, 'manual SaveParams UI retained')
need('actions.eqChanged(' in screens, 'verified EQ action retained')
need('actions.scalarChanged(2, v)' in screens, 'MasterVolume ID2 binding retained')
need("openEq = { selectTab(2) }" in nav and "openSystem = { selectTab(3) }" in nav, "verified live module navigation wired")
need('contentDescription = "Open ${item.second}"' in nav, "bottom navigation accessibility descriptions")
repo=text("app/src/main/java/com/okn/dsp/repository/DspRepository.kt")
need("fun saveParamsManual()" in repo and "SaveParamsPolicy.encodeTrigger()" in repo, "manual-only SaveParams repository boundary retained")
need("setEq(" in repo and "LiveEqPolicy.isWritable" in repo, "EQ write policy retained")
ble=text("app/src/main/java/com/okn/dsp/ble/BleProfile.kt")
need(all(x in ble for x in ["0000ab00-0000-1000-8000-00805f9b34fb","0000ab01-0000-1000-8000-00805f9b34fb","0000ab02-0000-1000-8000-00805f9b34fb"]), "verified AB00/AB01/AB02 BLE profile retained")
need("UNVERIFIED_40AF" in ble and "never used for DSP writes" in ble, "40af remains unverified/locked")
for kp in (ROOT/"app/src/main/java").rglob("*.kt"): need(not illegal_string_newline(kp.read_text(errors="replace")), "Kotlin string newline guard "+str(kp.relative_to(ROOT)))
need((ROOT/"evidence/OKN_DSP_V102_PROTOCOL_JVM_SMOKE.txt").exists(), "V102 protocol smoke evidence present")
need("PASS: Generic writes locked" in text("evidence/OKN_DSP_V102_PROTOCOL_JVM_SMOKE.txt"), "protocol smoke confirms generic writes locked")
print("V102 PREFLIGHT: PASS")
