OKN_DSP V101 — COMPLETE PRODUCTION UI REFRESH
==============================================

VersionCode: 101
VersionName: 9.0.0-v101-complete-production-ui-refresh
Package: com.okn.dsp

GOAL
----
Replace the complete user-facing interface with a cohesive dark professional DSP UI while preserving the verified V100 DSP/BLE/runtime core byte-for-byte.

UI CHANGES
----------
- New dark navy/graphite visual system with cyan/blue focus, softer cards, pills and clearer hierarchy.
- New 5-tab shell: Home / Controls / EQ / System / More.
- Home rebuilt around connection state, DSP artwork, explicit Connect button, Health Gate, Master Volume, live metrics and seven channel cards.
- Master Volume remains connected to verified scalar ID2 and Android phone volume sync.
- Controls page rebuilt into LEVEL / BASS / TONE groups using only the seven verified scalar writers.
- EQ overview rebuilt for seven channels with real coefficient-rendered curves.
- EQ editor rebuilt with horizontal channel selector, 15-band selector, real graph, Frequency/Gain/Q controls and explicit LIVE/LOCK status.
- System page rebuilt around Health Gate, queue state, read-only sensors and guarded manual SaveParams.
- More page rebuilt around device session controls, diagnostics and module availability.
- Crossover, Delay, Mixer/Output and Preset hardware writers are explicitly shown as LOCKED when no verified packet evidence exists.

VERIFIED WRITE BOUNDARY
-----------------------
- BLE service/write/notify: AB00 / AB01 / AB02; AB03 remains transport-side evidence where supported.
- Scalar IDs: 2, 3, 8, 9, 10, 13, 11.
- EQ actuator map CH1..CH7: 4, 5, 6, 14, 15, 16, 17.
- 15 EQ records/channel; PEAKING type=12 only writable; full 48-byte records.
- Realtime queue remains one-inflight/latest-target-wins with pacing and callback fail-closed protections.
- TrebleBoost ID11 safe-slew remains unchanged in the frozen runtime core.
- SaveParams ID7 remains explicit manual-only.
- Generic/unknown/Crossover/Delay/Preset/Output/Mute/Phase hardware writes remain locked.

BUILD
-----
Upload OKN_DSP_ANDROID_V101_COMPLETE_PRODUCTION_UI_REFRESH.zip to the repository root. The existing auto-version workflow can detect OKN_DSP_ANDROID_V*.zip and build the latest source package.

VALIDATION
----------
- UI Kotlin delimiter/string parser guard: PASS
- Kotlin parser scan: no syntax/expecting/template errors
- Protocol JVM smoke: 8/8 PASS
- Complete non-UI Kotlin runtime core: byte-identical to V100
- V101 preflight: PASS (run after packaging)
- Full Android APK build: GitHub Actions remains authoritative because this container has no Android SDK/Gradle installation.
