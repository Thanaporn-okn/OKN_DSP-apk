#!/usr/bin/env python3
from pathlib import Path
import hashlib, re, sys, xml.etree.ElementTree as ET

R=Path(__file__).resolve().parent
checks=[]
def need(ok,msg):
    checks.append((bool(ok),msg))
    if not ok: print('FAIL:',msg)
def text(rel): return (R/rel).read_text(encoding='utf-8')

build=text('app/build.gradle.kts')
need('applicationId = "com.okn.dsp"' in build,'applicationId com.okn.dsp')
need('versionCode = 2' in build,'versionCode 2')
need('versionName = "1.0.1-v2-audio-stutter-fix"' in build,'versionName V2 audio-stutter-fix')
need('compileSdk = 35' in build and 'targetSdk = 35' in build,'Android 35 baseline')

manifest=R/'app/src/main/AndroidManifest.xml'
ET.parse(manifest)
m=manifest.read_text(encoding='utf-8')
need('android:name=".OknDspApplication"' in m,'process-scoped Application registered')
need('android:configChanges="orientation|screenSize|smallestScreenSize|keyboardHidden"' in m,'orientation session preservation')

ble_profile=text('app/src/main/java/com/okn/dsp/ble/BleProfile.kt')
for u in ('0000ab00-0000-1000-8000-00805f9b34fb','0000ab01-0000-1000-8000-00805f9b34fb','0000ab02-0000-1000-8000-00805f9b34fb'):
    need(u in ble_profile,f'BLE verified UUID {u[:8]}')

scalars=text('app/src/main/java/com/okn/dsp/protocol/VerifiedScalarControls.kt')
for token in ('VerifiedScalarControl(2,','VerifiedScalarControl(3,','VerifiedScalarControl(8,','VerifiedScalarControl(9,','VerifiedScalarControl(10,','VerifiedScalarControl(13,','VerifiedScalarControl(11,'):
    need(token in scalars,f'scalar allow-list {token}')

emap=text('app/src/main/java/com/okn/dsp/protocol/ConfirmedDspMap.kt')
need('intArrayOf(4, 5, 6, 14, 15, 16, 17)' in emap,'7-channel EQ actuator map unchanged')
need('EQ_BAND_COUNT = 15' in emap and 'EQ_BAND_BYTES = 48' in emap,'15x48 EQ geometry unchanged')

save=text('app/src/main/java/com/okn/dsp/protocol/SaveParamsPolicy.kt')
need('570000000700000000' in save,'exact SaveParams trigger unchanged')
wg=text('app/src/main/java/com/okn/dsp/protocol/WriteGate.kt')
need('enabled: Boolean = false' in wg,'generic write gate locked')

# V2 acoustic / transport invariants.
ble=text('app/src/main/java/com/okn/dsp/ble/BleDspManager.kt')
api33_call='g.writeCharacteristic(\n                    ch,\n                    bytes,\n                    BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE,'
need(ble.count(api33_call)==1,'Android 13+ path contains exactly one queued GATT write call')
need('minPacingMs = 90L' in ble,'BLE global realtime budget 90ms')
need('WRITE_TYPE_DEFAULT' not in ble,'no unverified write-type change')

queue=text('app/src/main/java/com/okn/dsp/queue/RealtimeCommandQueue.kt')
need('minPacingMs: Long = 90L' in queue,'queue default pacing 90ms')
need('writeTimeoutMs = 2500L' in queue,'GATT callback timeout retained')
need('realtime[command.key] = command' in queue,'latest-target-wins coalescing retained')
need('inflight != null' in queue,'one-inflight guard retained')

ramp=text('app/src/main/java/com/okn/dsp/smoothing/ScalarRampController.kt')
need('id == 11 -> 0.5f' in ramp,'TrebleBoost <=0.5dB step retained')
need('if (id == 11) 96L else 90L' in ramp,'scalar audio-safe pacing')
need('abs(delta) * 0.18f' in ramp,'adaptive latest-target scalar step')

eq=text('app/src/main/java/com/okn/dsp/smoothing/EqSlewController.kt')
need('main.postDelayed({ drive(k) }, 110L)' in eq,'full 48-byte EQ coefficient writes paced at 110ms')

phone=text('app/src/main/java/com/okn/dsp/smoothing/PhoneVolumeBridge.kt')
need('PHONE_STEP_INTERVAL_MS = 110L' in phone,'phone STREAM_MUSIC mirror one-index pacing')
need('shouldIgnoreObserver()' in phone and 'suppressObserverUntil' in phone,'async phone-volume feedback guard')
need('next = if (target > cur) cur + 1 else cur - 1' in phone,'phone volume moves one index per step')

ui_kit=text('app/src/main/java/com/okn/dsp/ui/UiKit.kt')
need(ui_kit.count('isSoundEffectsEnabled = false')>=2,'UI touch sound disabled for text/seek controls')
need(ui_kit.count('isHapticFeedbackEnabled = false')>=2,'UI haptic feedback disabled for text/seek controls')
for rel in ('KnobView.kt','VerticalFader.kt','RealtimeEqGraphView.kt'):
    src=text('app/src/main/java/com/okn/dsp/ui/'+rel)
    need('isSoundEffectsEnabled = false' in src,f'touch sound disabled {rel}')

ui=text('app/src/main/java/com/okn/dsp/ui/ReferenceDspUi.kt')
need('activePanel().bind(s)' in ui,'only active panel rebinds during realtime movement')
need('global.bind(s);eq.bind(s);channel.bind(s)' not in ui,'hidden-panel bind storm removed')
for label in ('Global Controls','Graphic EQ','Parametric EQ','Crossover','Delay','Output','Save Preset','Load Preset'):
    need(label in ui,f'reference UI preserved: {label}')

prefs=text('app/src/main/java/com/okn/dsp/persistence/DspPreferences.kt')
need('okn_dsp_v1_local_state' in prefs,'V1 local state namespace intentionally retained for V1->V2 value continuity')
need('debounceMs: Long = 350L' in prefs,'local persistence write-pressure debounce 350ms')

ref=R/'evidence/OKN_DSP_V2_UI_MASTER_REFERENCE.png'
need(ref.is_file(),'V2 UI master evidence embedded')
if ref.is_file(): print('UI_REFERENCE_SHA256',hashlib.sha256(ref.read_bytes()).hexdigest())

# Structural source guard.
kt=list((R/'app/src/main/java').rglob('*.kt'))
need(len(kt)>=25,f'Kotlin source set present ({len(kt)} files)')
for p in kt:
    s=p.read_text(encoding='utf-8')
    need(s.count('{')==s.count('}'),f'balanced Kotlin braces {p.relative_to(R)}')

fails=[m for ok,m in checks if not ok]
print(f'PREFLIGHT checks={len(checks)} pass={len(checks)-len(fails)} fail={len(fails)}')
if fails: sys.exit(1)
print('PREFLIGHT V2 PASS')
