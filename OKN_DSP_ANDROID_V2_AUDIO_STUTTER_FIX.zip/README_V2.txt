OKN_DSP — V2 AUDIO STUTTER / POP MITIGATION
===========================================

VersionCode: 2
VersionName: 1.0.1-v2-audio-stutter-fix
Package: com.okn.dsp

USER-REPORTED DEFECT
- While connected and playing audio, pressing tuning controls or dragging sliders can make the speaker audio jump / pop / stutter.

V2 CHANGE SCOPE
- UI appearance remains the same reference UI.
- BLE protocol, authentication, scalar IDs, EQ actuator IDs, packet encoding and SaveParams trigger are unchanged.
- No new DSP write family is guessed.

AUDIO-SAFE CONTROL PATH
1. UI value still follows the finger immediately.
2. Hardware target remains latest-target-wins.
3. Global BLE realtime budget changed from 38 ms to 90 ms (about 11 control writes/sec maximum across the app).
4. Scalar ramps are callback-gated and use adaptive bounded steps; TrebleBoost remains <=0.5 dB/step and now uses 96 ms nominal spacing.
5. Full 48-byte PEAKING EQ coefficient updates use 110 ms spacing.
6. Android STREAM_MUSIC mirroring moves one phone volume index at a time (110 ms) instead of jumping several coarse volume indices at once.
7. Programmatic phone-volume observer callbacks have an asynchronous guard so they cannot feed an old intermediate phone value back into DSP MasterVolume.
8. Android touch click/haptic feedback is disabled for tuning controls so system UI click sounds are not routed into the connected audio path.
9. Hidden DSP panels no longer redraw/rebind on every movement.
10. Local persistence remains automatic, but JSON/disk flush is debounced to 350 ms and still flushes when the Activity stops.

VERIFIED HARDWARE BOUNDARY (UNCHANGED)
- Service AB00 / write AB01 / notify AB02.
- Scalar IDs: 2,3,8,9,10,13,11.
- EQ actuator IDs CH1..CH7: 4,5,6,14,15,16,17.
- EQ: 15 bands/channel, only verified PEAKING type=12, full 48-byte record.
- SaveParams ID7 trigger 570000000700000000 remains manual guarded only.
- Crossover / Delay / hardware preset / unknown Output packets remain locked.

IMPORTANT QUALIFICATION BOUNDARY
The code change directly removes write pressure and phone-volume feedback mechanisms that can produce audible control-time glitches, but an absolute no-pop/no-stutter claim still requires the V2 APK to be built and tested on the real DSP while audio is playing.
