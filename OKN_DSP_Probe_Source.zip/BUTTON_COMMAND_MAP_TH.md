# OKN DSP Probe V11 — Button / Wire Command Map

เอกสารนี้ระบุว่าปุ่มแต่ละปุ่มใน V11 ทำอะไรและมีข้อมูลใดส่งออกไปยังบอร์ด

| ปุ่ม | สิ่งที่ส่งไปบอร์ด |
|---|---|
| USB Scan | **0 bytes** — enumerate ผ่าน Android UsbManager เท่านั้น |
| Probe <USB device> | **ไม่มี USB OUT** — อ่าน device/config/raw descriptors, HID report descriptor ด้วย GET_DESCRIPTOR (IN), HID INPUT/FEATURE ด้วย GET_REPORT (IN), และ interrupt-IN เท่านั้น |
| BLE Scan | **0 GATT command bytes** — Android BLE scan/receive advertisements เท่านั้น |
| GATT Probe | connect + discoverServices; ถ้า AB01 รองรับ READ จะทำ **GATT characteristic READ AB01** เท่านั้น; ไม่มี characteristic write |
| Classic/SDP | Android Classic discovery เท่านั้น |
| SDP Probe | SDP `fetchUuidsWithSdp()` เพื่ออ่าน advertised UUIDs; ไม่มี SPP payload |
| SPP Passive Connect (NO TX) | เปิด RFCOMM/SPP และอ่านประมาณ 3 วินาที; **TX = 0 bytes** |
| BLE Device Description (READ-ONLY) | เปิด notify AB02 ด้วย CCCD `01 00`; เขียน AUTH16 `63 1C 06 24 43 FD 38 44 55 80 01 F3 ED A0 CC F8` ไป AB01; หลังรับ AUTH32/derive RandKey จะ AES/CFB8-encrypt plaintext request `66 1C 06 24` แล้วเขียน ciphertext 4 bytes ไป AB01. Ciphertext เปลี่ยนตาม session RandKey จึงไม่มีค่า hex คงที่ |
| Share captured Device Description JSON | **0 bytes** — Android share sheet/local data only |
| Store current JSON as Snapshot A | **0 bytes** — copy JSON ล่าสุดเข้า RAM โทรศัพท์ |
| Store current JSON as Snapshot B | **0 bytes** — copy JSON ล่าสุดเข้า RAM โทรศัพท์ |
| Compare Snapshot A ↔ B | **0 bytes** — parse/diff JSON ใน RAM โทรศัพท์ |
| Copy Report | **0 bytes** — clipboard local only |
| Share | **0 bytes** — Android share sheet/local report only |

## สิ่งที่ไม่มีใน V11

- ไม่มีปุ่ม CH1–CH7 `+/-` ที่ส่งคำสั่งไปบอร์ด เพราะ Device Description ที่มีอยู่ยังไม่แสดง standalone per-channel volume/gain actuator
- ไม่มี UFE command `0x57`
- ไม่มี SaveParams ID7 write
- ไม่มี unknown actuator scan/write
- ไม่มี ACP active `SET_REPORT`
- ไม่มี erase / boot / OTA / firmware payload
