# OKN DSP Probe V11 — Read-only Descriptor A/B Diff

V11 ต่อจาก V10 โดยคงเส้นทางที่ยืนยันกับบอร์ดจริงแล้วเท่านั้น:

1. เขียน AUTH16 ไป AB01: `63 1C 06 24 43 FD 38 44 55 80 01 F3 ED A0 CC F8`
2. รับ AUTH32 จาก notify แล้ว derive session RandKey
3. สร้าง AES/CFB8 session
4. เข้ารหัส plaintext Device Description request `66 1C 06 24` แล้วเขียน ciphertext ไป AB01
5. รับ/ถอดรหัส Device Description JSON จาก notification

## สิ่งที่เพิ่มใน V11

- **Store current JSON as Snapshot A (LOCAL ONLY)** — สำเนา JSON ล่าสุดลง RAM ของโทรศัพท์, ส่ง 0 bytes ไปบอร์ด
- **Store current JSON as Snapshot B (LOCAL ONLY)** — สำเนา JSON ล่าสุดลง RAM ของโทรศัพท์, ส่ง 0 bytes ไปบอร์ด
- **Compare Snapshot A ↔ B (LOCAL ONLY)** — diff metadata, actuator, sensor และทุก field ใน EQ records ใน RAM, ส่ง 0 bytes ไปบอร์ด
- ลบ dormant V5 ACP active `SET_REPORT` implementation ออกจาก source V11 เพื่อไม่ให้มี code path สำหรับทดสอบ ACP active ซ้ำ

## จุดประสงค์

Device Description ที่ยืนยันแล้วมี EQ actuator 7 ช่อง (ID 4,5,6,14,15,16,17) แต่ **ไม่มี scalar actuator ชื่อ CH1Volume..CH7Volume**. V11 จึงไม่สร้างหรือส่งคำสั่ง channel-volume แบบเดา และไม่ใช้ EQ gain แทน volume.

วิธีทดลองที่ตั้งใจไว้คือ capture A, เปลี่ยนเพียง ONE setting ผ่านซอฟต์แวร์ GoloPine/DSTech ที่เชื่อถือได้, capture B, แล้ว diff เพื่อดูว่ามี field/actuator ใดเปลี่ยนจริง.

## Safety

V11 ไม่มี UFE `0x57` write, SaveParams, erase, boot, OTA, firmware payload หรือ guessed actuator scan. USB probe ที่เข้าถึงได้จาก UI ใช้ descriptor reads / HID GET_REPORT / interrupt-IN เท่านั้น. SPP passive probe ส่ง 0 bytes.
