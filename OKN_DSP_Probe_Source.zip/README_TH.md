# OKN DSP Probe V3

รุ่น V3 สำหรับ Samsung S25+ ใช้ตรวจบอร์ด BP1048P4 แบบอ่านอย่างเดียว

## สิ่งที่เพิ่มจาก V2
- ถอดขนาด HID INPUT / OUTPUT / FEATURE จาก Report Descriptor อัตโนมัติ
- `GET_REPORT FEATURE` ขอข้อมูลตามขนาดที่ descriptor ระบุจริงเท่านั้น
- สำหรับบอร์ดที่ตรวจพบ IF4 จะอ่าน FEATURE 8 bytes จำนวน 3 ครั้งเพื่อดูว่าค่าเสถียรหรือเปลี่ยนแปลง
- ไม่ขอ FEATURE 256 bytes อีก เพื่อหลีกเลี่ยงการอ่านเกินขนาดที่ descriptor ประกาศ
- BLE: หลัง GATT enumeration จะลอง `READ` AB01 ถ้า characteristic อนุญาต โดยไม่มีการ WRITE

## ขอบเขตความปลอดภัย
แอปไม่ส่ง `SET_REPORT`, ไม่ส่ง endpoint OUT, ไม่เขียน BLE characteristic, ไม่แก้ DSP, ไม่ erase และไม่เขียน firmware

## วิธีใช้ USB
1. เปิดบอร์ดด้วยไฟเลี้ยงตามปกติ
2. ต่อ USB-C data จาก Samsung S25+ ไปบอร์ด
3. เปิด OKN DSP Probe V3
4. กด `USB Scan`
5. แตะ `Probe VID=6324 PID=1719` และอนุญาต USB
6. รอ `USB V3 read-only probe complete`
7. กด `Copy Report` แล้วส่งรายงานกลับมา

## วิธีใช้ BLE
1. กด `BLE Scan`
2. แตะ `LE-GoloPine_DSP_A` / `LE-GoloPine_DSP_Amp`
3. รอ GATT enumeration และ `GATT V3 READ-ONLY: AB01 read started=...`
4. ส่งรายงานกลับมา
