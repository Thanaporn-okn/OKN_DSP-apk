# OKN DSP Probe V5

V5 ทำต่อจากผล V4 ที่ยืนยันว่า HID IF4 รับ `SET_REPORT OUTPUT` ขนาด 256 bytes ได้ แต่การส่ง ACP `CTRL 0x00 / LEN=0` เพียงครั้งเดียวแล้วเรียก `GET_REPORT INPUT` ซ้ำ ไม่ได้คำตอบ (`read=0`)

## สิ่งที่ V5 เปลี่ยน

V5 ยังส่งเพียงคำขอ Firmware Version เดิม:

`A5 5A 00 00 16`

แต่จะทำ transaction แบบ **ส่งคำขอเดิมใหม่ในแต่ละ retry** สูงสุด 5 ครั้ง:

`SET_REPORT(CTRL 0x00) -> รอ 10 ms -> GET_REPORT INPUT`

แล้วจึง retry ด้วยคำขอเดิมหากไม่มี reply

เหตุผลคือ implementation ของ ACP บางรุ่นต้อง retransmit request ไม่ใช่ส่งครั้งเดียวแล้ว polling GET_REPORT หลายครั้ง

## Safety gate

แอปจะทำงานเฉพาะเมื่อพบ:

- VID `6324`, PID `1719`
- HID Interface 4
- Usage Page `0xFF00`, Usage `0x55AA`
- Input 256 bytes / Output 256 bytes / Feature 8 bytes
- ไม่มี Report ID

ไม่มี UI เลือก CTRL อื่น และ V5 ไม่มี DSP write, Save, Erase, OTA, Bootloader command หรือ Firmware write

## วิธีทดสอบ

1. ต่อบอร์ดกับ Samsung S25+ ด้วย USB-C data
2. `USB Scan` -> แตะ `Probe VID=6324 PID=1719` -> Allow
3. รอ `USB V5 passive probe complete`
4. กด `ACP Safe FW Read V5 — CTRL 0x00 only` หนึ่งครั้ง
5. กด `Copy Report`
6. ส่งเฉพาะบรรทัด `ACP V5 ...` กลับมา
