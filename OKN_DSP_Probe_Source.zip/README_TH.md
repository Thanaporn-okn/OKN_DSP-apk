# OKN DSP Probe V8.0.0

ผล V7 ยืนยันว่า Classic SPP 0x1101 ของ `GoloPine_DSP_Amplifier` เชื่อมต่อได้จริง แต่บอร์ดไม่ส่งข้อมูลเอง (`totalRx=0`) จนกว่า host จะเริ่ม protocol บางอย่าง

V8 **ไม่ส่งข้อมูลสุ่มผ่าน SPP** เพราะยังไม่ทราบ protocol ของ SPP และ public BP1048 SDK แสดง SPP callback แบบ generic ไม่ได้ยืนยันว่า SPP เป็น firmware updater

V8 เพิ่มการทดสอบ BLE แบบ manual ที่อิงจากแอป OKN เดิมเท่านั้น:

1. BLE Scan
2. GATT Probe `LE-GoloPine_DSP_A`
3. เมื่อพบ AB00/AB01/AB02 จะมีปุ่ม `BLE Auth Probe (AUTH16 only)`
4. ปุ่มนี้จะเปิด AB02 Notify และส่งเฉพาะ AUTH16 ที่ยืนยันแล้ว: `631C062443FD3844558001F3EDA0CCF8`
5. ถ้าได้ AB02 32 ไบต์ แอปจะ log raw response และ decode typeId/versionId/RandKey ในเครื่อง แล้ว disconnect ทันที

ไม่มี UFE write, DSP parameter write, SaveParams, erase, boot, OTA หรือ firmware transfer ใน V8
