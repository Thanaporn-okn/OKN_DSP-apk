# OKN DSP Probe V10

V10 ใช้เส้นทางเดียวกับ V9 ที่ยืนยันกับบอร์ดจริงแล้ว: BLE AUTH16 -> AUTH32 -> AES/CFB8 session -> Device Description request `66 1C 06 24`.

สิ่งที่เพิ่มใน V10:
- แสดง `BLE MAP V10 ACT[...]` สำหรับ actuator ทุกตัวแบบย่อ
- แสดง `BLE MAP V10 SENSOR[...]` สำหรับ sensor ทุกตัว
- เก็บ Device Description JSON ที่ถอดรหัสแล้ว 1:1 ในหน่วยความจำ
- ปุ่ม **Share captured Device Description JSON** เพื่อส่ง JSON ฉบับเต็มออกจากมือถือ

V10 ไม่เพิ่มคำสั่ง DSP ใหม่: ไม่มี UFE write 0x57, SaveParams, erase, boot, OTA หรือ firmware payload.
