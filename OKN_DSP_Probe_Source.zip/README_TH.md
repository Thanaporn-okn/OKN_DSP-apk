# OKN DSP Probe V1

แอปตรวจสอบฮาร์ดแวร์แบบ **read-only** สำหรับงาน reverse engineering ของ
**OKN_DSP 7-Channel Digital Audio Processor Preamp / MVSilicon BP1048P4**
โดยออกแบบให้ใช้บน Samsung S25+ หรือ Android ที่รองรับ USB Host + Bluetooth LE

## สิ่งที่ V1 ตรวจได้

### USB
- VID / PID
- Device class / subclass / protocol
- Manufacturer / Product / Serial (ถ้า Android อนุญาต)
- Interface / alternate setting
- Interface class / subclass / protocol
- Endpoint address / IN-OUT / transfer type / max packet / interval
- Raw USB descriptors
- HID report descriptor ด้วยคำสั่งมาตรฐาน USB `GET_DESCRIPTOR` แบบ IN/read-only

แอป **ไม่ claim audio/HID endpoint เพื่อส่งข้อมูล**, ไม่ส่ง OUT packet และไม่แฟลช firmware

### Bluetooth LE
- BLE device name / address / RSSI
- advertised service UUIDs
- manufacturer-specific advertisement bytes
- raw advertisement bytes
- เมื่อผู้ใช้แตะอุปกรณ์: connect GATT ชั่วคราวและ enumerate
  Service / Characteristic / Descriptor UUIDs + characteristic properties
- ตรวจเครื่องหมาย service ที่ทราบจากแอป OKN DSP เดิม:
  - AB00 service: `0000ab00-0000-1000-8000-00805f9b34fb`
  - AB01 TX: `0000ab01-0000-1000-8000-00805f9b34fb`
  - AB02 RX: `0000ab02-0000-1000-8000-00805f9b34fb`

ไม่มี characteristic read/write และไม่มี DSP command ใน Probe V1

## วิธีใช้บน Samsung S25+

1. ติดตั้ง APK
2. เปิดแอปและอนุญาต Nearby devices / Bluetooth เมื่อแอปขอ
3. จ่ายไฟ DSP ด้วยวิธีที่ใช้งานบอร์ดตามปกติ
4. เชื่อม USB-C **เฉพาะเมื่อยืนยันว่าเป็นพอร์ต USB data/5V มาตรฐานของบอร์ด**
5. กด `USB Scan`
6. ถ้ามี device ขึ้น ให้กด `Probe VID=.... PID=....`
7. กด `BLE Scan` แล้วแตะ `GATT Probe` ของอุปกรณ์ DSP
8. กด `Copy Report` แล้วนำข้อความทั้งหมดกลับมาให้ ChatGPT วิเคราะห์ต่อ

## Build APK ด้วย GitHub Actions

โปรเจกต์มี `.github/workflows/build-apk.yml` พร้อมใช้งาน

Workflow ใช้:
- JDK 17
- Android API 35 / Build Tools 35.0.0
- Gradle 8.9
- Android Gradle Plugin 8.7.3

ขั้น license ใช้ `yes | sdkmanager --licenses` เพื่อหลีกเลี่ยง CI ค้างที่คำถาม y/N
จากนั้น APK จะอยู่ใน artifact `OKN_DSP_Probe_V1` เป็น `app-debug.apk`

## สิ่งที่ต้องการจากผล Probe

ผลที่สำคัญที่สุดสำหรับเฟสถัดไปคือ:
- USB VID/PID และ interfaces
- ถ้ามี HID: HID report descriptor
- ถ้ามี vendor-specific interface: endpoint IN/OUT และ packet size
- ถ้ามี DFU/CDC: class/subclass/protocol
- BLE service UUIDs ทั้งหมด
- characteristic ที่มี WRITE / WRITE_NR / NOTIFY / INDICATE
- พบหรือไม่พบ AB00 / AB01 / AB02

ข้อมูลเหล่านี้จะใช้ตัดสินว่า firmware update จาก Samsung S25+ ควรเดินทางผ่าน
USB HID, vendor-specific USB, CDC/DFU, BLE proprietary transport หรือจำเป็นต้องใช้ bootloader ทางอื่น

## V1.0.1 compile fix
แก้การ Build บน Android SDK 35: Android `UsbConstants` ไม่มี `USB_RECIP_INTERFACE` จึงกำหนดค่า recipient ของ USB interface ตาม bmRequestType เป็น `0x01` ภายใน `UsbProbe.java` แทน โดยพฤติกรรม Probe ยังคงเป็น read-only เหมือนเดิม

