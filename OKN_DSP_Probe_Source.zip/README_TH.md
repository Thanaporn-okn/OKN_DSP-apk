# OKN DSP Probe V4

V4 ใช้ยืนยันว่า USB Vendor HID IF4 ของบอร์ด OKN ใช้โปรโตคอล ACP ของตระกูล MVSilicon หรือไม่

## สิ่งที่เพิ่มจาก V3

ปุ่ม `ACP Safe FW Read — CTRL 0x00 only` จะทำงานเมื่อบอร์ด VID `6324` PID `1719` ได้รับ USB permission แล้วเท่านั้น และจะตรวจ HID descriptor ก่อนว่าเป็นรูปแบบเดิมที่พบจริง:

- Interface 4 = HID
- Usage Page `0xFF00` / Usage `0x55AA`
- Input 256 bytes
- Output 256 bytes
- Feature 8 bytes
- ไม่มี Report ID

ถ้าตรงทุกข้อ แอปจะส่งคำขอ ACP เพียงคำสั่งเดียว:

`A5 5A 00 00 16`

`CTRL=0x00`, `LEN=0` ใช้เป็นคำขออ่าน Firmware Version ตามหลักฐานของโปรโตคอล ACP บน MVSilicon BP10xx/AP82xx ที่มี HID shape เดียวกัน

จากนั้นแอปจะอ่าน INPUT report และรับผลเฉพาะเมื่อ reply มี header `A5 5A` และ CTRL ตรงกับ `0x00` เท่านั้น

## ความปลอดภัย

V4 ไม่มีคำสั่งปรับ DSP, Save, Erase, OTA, Bootloader หรือ Firmware Write และไม่มี UI ให้เลือก CTRL อื่น ปุ่ม ACP เป็น manual action เท่านั้น ส่วน probe ปกติยังคงเป็น read-only เหมือน V3

## วิธีทดสอบ

1. เปิดบอร์ดตามปกติและต่อ USB-C data กับ Samsung S25+
2. กด `USB Scan`
3. แตะ `Probe VID=6324 PID=1719` และกด Allow
4. รอ `USB V4 passive probe complete`
5. กด `ACP Safe FW Read — CTRL 0x00 only` หนึ่งครั้ง
6. กด `Copy Report` และส่งช่วง `ACP V4 ...` กลับมา
