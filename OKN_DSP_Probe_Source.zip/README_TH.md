# OKN DSP Probe V2

รุ่น V2 สำหรับ Samsung S25+ ใช้ตรวจบอร์ด BP1048P4 แบบอ่านอย่างเดียว

สิ่งที่เพิ่มจาก V1:
- Claim HID interface แล้วอ่าน HID Report Descriptor ซ้ำ
- HID `GET_REPORT` ชนิด INPUT และ FEATURE (USB IN เท่านั้น)
- อ่าน Interrupt-IN endpoint แบบ timeout สั้น
- เก็บ hex response ลง Probe report

## ขอบเขตความปลอดภัย
แอป **ไม่** ส่ง `SET_REPORT`, ไม่ส่งข้อมูลไป endpoint OUT, ไม่แก้ DSP, ไม่ erase และไม่เขียน firmware

## วิธีใช้
1. เปิดบอร์ดด้วยไฟเลี้ยงตามปกติ
2. ต่อ USB-C data จาก Samsung S25+ ไปบอร์ด
3. เปิด OKN DSP Probe V2
4. กด `USB Scan`
5. แตะปุ่ม `Probe VID=6324 PID=1719` และอนุญาต USB
6. รอจนขึ้น `USB V2 read-only probe complete`
7. กด `Copy Report` แล้วส่งรายงานทั้งหมดกลับมา

BLE ยังใช้เหมือน V1: กด `BLE Scan` แล้วแตะ GATT Probe หากต้องการตรวจ service
