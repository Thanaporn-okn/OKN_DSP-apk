# OKN DSP Probe V7.0.0

V7 ใช้ผลจากบอร์ดจริงที่ยืนยันว่า `GoloPine_DSP_Amplifier` ประกาศ Classic Bluetooth SPP UUID `0x1101` พร้อม A2DP/AVRCP แต่ไม่ประกาศ OBEX `0x1105/0x1106` ผ่าน SDP

## สิ่งที่เพิ่ม
หลังทำ Classic/SDP แล้ว ถ้าอุปกรณ์ประกาศ SPP แอปจะเพิ่มปุ่ม `SPP Passive Connect (NO TX)`

ปุ่มนี้ทำเพียง:
- เปิด RFCOMM socket ไปที่ SPP UUID 0x1101
- ไม่เปิด OutputStream และไม่ส่ง payload ใด ๆ
- ฟังข้อมูลที่บอร์ดส่งมาเองเป็นเวลา 3 วินาที
- ปิด socket

ถ้า Android ขอ Pair ระหว่าง connect เป็นการร้องขอจากระบบ Bluetooth ของโทรศัพท์ ไม่ใช่การเขียน firmware

V7 ไม่มี firmware transfer, ไม่มี erase, ไม่มี OTA command และไม่มี SPP TX payload
