# OKN DSP Probe V9

V9 ใช้ผลที่ยืนยันแล้วจากบอร์ดจริง: AUTH16 ไป AB01 และ AUTH32 จาก AB02 ใช้งานได้จริง

ขั้นตอนทดสอบ:
1. เปิดบอร์ดและ Bluetooth โดยไม่ต้องเสียบ USB
2. กด `BLE Scan`
3. แตะ `GATT Probe: LE-GoloPine_DSP_A`
4. เมื่อพบ AB00/AB01/AB02 จะมีปุ่ม `BLE Device Description (READ-ONLY)`
5. กดปุ่มนั้น 1 ครั้ง แล้วรอจนเห็น `BLE DESC V9 COMPLETE`
6. กด Copy Report แล้วส่งบรรทัด `BLE DESC V9 ...` กลับมา

V9 ส่ง active BLE เพียง 2 อย่างที่ยืนยันจากแอป OKN เดิมแล้ว: AUTH16 และ Device Description request 66 1C 06 24 (เข้ารหัสด้วย session RandKey) ไม่มี UFE write 0x57, SaveParams, erase, boot, OTA หรือ firmware payload
