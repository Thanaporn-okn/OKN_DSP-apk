# OKN DSP Probe V6

V6 ทำต่อจากผลจริงของบอร์ดที่ V5 ส่งคำขออ่าน ACP Firmware Version `CTRL 0x00 / LEN=0` เดิมซ้ำ 5 ครั้งแล้ว `GET_REPORT INPUT` ยังได้ `read=0` ทุกครั้ง

ดังนั้น V6 **หยุดยิง ACP ซ้ำ** และเปลี่ยนเป้าหมายไปตรวจ transport ที่มีโอกาสเกี่ยวกับ firmware update โดยไม่เขียนข้อมูลลงบอร์ด:

- BLE scan + GATT enumeration/read AB01 แบบเดิม (ไม่ WRITE)
- Classic Bluetooth discovery (BR/EDR)
- แสดงชนิดอุปกรณ์ LE / CLASSIC / DUAL และ bond state
- ปุ่ม `SDP Probe` เพื่อเรียก `fetchUuidsWithSdp()` และอ่าน Service UUIDs
- ทำ label ให้ SPP `0x1101`, OBEX Object Push `0x1105`, OBEX File Transfer `0x1106` ถ้าพบ
- USB descriptor / HID GET_REPORT แบบ passive เหมือนเดิม

## ความปลอดภัย

V6 UI ไม่มีปุ่ม ACP active read แล้ว และไม่ได้เปิด RFCOMM/OBEX socket, ไม่ pair อัตโนมัติ, ไม่ส่งไฟล์, ไม่ erase และไม่เขียน firmware

## วิธีทดสอบ

1. เปิดบอร์ด DSP ตามปกติ
2. เปิด V6 และอนุญาต Nearby devices / Bluetooth
3. กด `Classic/SDP`
4. รอ `CLASSIC FOUND ...` ประมาณ 10-20 วินาที
5. ถ้าพบชื่อที่เกี่ยวกับ `GoloPine`, `DSP`, `DSTech` หรืออุปกรณ์เดียวกับบอร์ด ให้แตะ `SDP Probe` ของตัวนั้น
6. รอ `SDP RESULT ... uuids=[...]`
7. กด Copy Report แล้วส่งเฉพาะบรรทัด `CLASSIC ...`, `SDP ...` และ `SDP PROFILE ...` กลับมา

ถ้าไม่พบ Classic device ให้ส่ง report ที่มี `CLASSIC DISCOVERY finished` มาเช่นกัน เพราะนั่นเป็นผลที่มีความหมาย
