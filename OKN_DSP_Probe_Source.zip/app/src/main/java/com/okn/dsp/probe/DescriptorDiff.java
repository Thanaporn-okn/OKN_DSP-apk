package com.okn.dsp.probe;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Purely local comparison of two already-decrypted Device Description JSON snapshots. */
final class DescriptorDiff {
    private static final int MAX_CHANGES = 500;

    private DescriptorDiff() {}

    static String compare(byte[] aBytes, byte[] bBytes) {
        StringBuilder out = new StringBuilder();
        Counter c = new Counter();
        try {
            Object ao = new JSONTokener(new String(aBytes, StandardCharsets.UTF_8)).nextValue();
            Object bo = new JSONTokener(new String(bBytes, StandardCharsets.UTF_8)).nextValue();
            if (!(ao instanceof JSONObject) || !(bo instanceof JSONObject)) {
                return "SNAPSHOT DIFF ERROR: root JSON is not an object";
            }
            JSONObject a = (JSONObject) ao;
            JSONObject b = (JSONObject) bo;

            out.append("SNAPSHOT DIFF BEGIN A=").append(aBytes.length)
                    .append(" bytes B=").append(bBytes.length).append(" bytes\n");

            compareTopLevel(a, b, out, c);
            compareEntities("ACTUATOR", a.optJSONArray("actuators"), b.optJSONArray("actuators"), out, c);
            compareEntities("SENSOR", a.optJSONArray("sensors"), b.optJSONArray("sensors"), out, c);

            if (c.count == 0) {
                out.append("SNAPSHOT DIFF RESULT: no JSON field changed\n");
            } else {
                out.append("SNAPSHOT DIFF RESULT: ").append(c.count).append(" changed field(s)");
                if (c.truncated) out.append("; output truncated after ").append(MAX_CHANGES);
                out.append("\n");
            }
            out.append("SNAPSHOT DIFF END");
            return out.toString();
        } catch (Throwable t) {
            return "SNAPSHOT DIFF ERROR: " + t.getClass().getSimpleName() + ": " + safe(t.getMessage());
        }
    }

    private static void compareTopLevel(JSONObject a, JSONObject b, StringBuilder out, Counter c) {
        Set<String> keys = keys(a, b);
        keys.remove("actuators");
        keys.remove("sensors");
        List<String> ordered = new ArrayList<>(keys);
        Collections.sort(ordered);
        for (String k : ordered) {
            compareValue("META." + k, a.opt(k), b.opt(k), out, c);
            if (c.truncated) return;
        }
    }

    private static void compareEntities(String label, JSONArray aa, JSONArray bb,
                                        StringBuilder out, Counter c) {
        Map<Integer, JSONObject> a = byId(aa);
        Map<Integer, JSONObject> b = byId(bb);
        Set<Integer> ids = new HashSet<>();
        ids.addAll(a.keySet());
        ids.addAll(b.keySet());
        List<Integer> ordered = new ArrayList<>(ids);
        Collections.sort(ordered);

        for (int id : ordered) {
            JSONObject av = a.get(id), bv = b.get(id);
            String name = entityName(av != null ? av : bv);
            String base = label + " ID" + id + (name.isEmpty() ? "" : " " + name);
            if (av == null || bv == null) {
                emit(out, c, base + ": " + (av == null ? "added in B" : "missing in B"));
            } else {
                compareObject(base, av, bv, out, c, true);
            }
            if (c.truncated) return;
        }
    }

    private static Map<Integer, JSONObject> byId(JSONArray x) {
        Map<Integer, JSONObject> out = new HashMap<>();
        if (x == null) return out;
        for (int i = 0; i < x.length(); i++) {
            JSONObject o = x.optJSONObject(i);
            if (o != null && o.has("ID")) out.put(o.optInt("ID", Integer.MIN_VALUE), o);
        }
        return out;
    }

    private static String entityName(JSONObject o) {
        return o == null ? "" : o.optString("name", "");
    }

    private static void compareObject(String path, JSONObject a, JSONObject b,
                                      StringBuilder out, Counter c, boolean entityRoot) {
        Set<String> all = keys(a, b);
        List<String> ordered = new ArrayList<>(all);
        Collections.sort(ordered);
        for (String k : ordered) {
            if (entityRoot && ("ID".equals(k) || "name".equals(k))) continue;
            compareValue(path + "." + k, a.opt(k), b.opt(k), out, c);
            if (c.truncated) return;
        }
    }

    private static void compareArray(String path, JSONArray a, JSONArray b,
                                     StringBuilder out, Counter c) {
        int max = Math.max(a.length(), b.length());
        for (int i = 0; i < max; i++) {
            Object av = i < a.length() ? a.opt(i) : null;
            Object bv = i < b.length() ? b.opt(i) : null;
            compareValue(path + "[" + (i + 1) + "]", av, bv, out, c);
            if (c.truncated) return;
        }
    }

    private static void compareValue(String path, Object a, Object b,
                                     StringBuilder out, Counter c) {
        if (isNull(a) && isNull(b)) return;
        if (a instanceof JSONObject && b instanceof JSONObject) {
            compareObject(path, (JSONObject) a, (JSONObject) b, out, c, false);
            return;
        }
        if (a instanceof JSONArray && b instanceof JSONArray) {
            compareArray(path, (JSONArray) a, (JSONArray) b, out, c);
            return;
        }
        if (equalScalar(a, b)) return;
        emit(out, c, path + ": " + val(a) + " -> " + val(b));
    }

    private static boolean equalScalar(Object a, Object b) {
        if (isNull(a) || isNull(b)) return isNull(a) && isNull(b);
        if (a instanceof Number && b instanceof Number) {
            return Double.doubleToLongBits(((Number) a).doubleValue())
                    == Double.doubleToLongBits(((Number) b).doubleValue());
        }
        return String.valueOf(a).equals(String.valueOf(b));
    }

    private static boolean isNull(Object x) {
        return x == null || x == JSONObject.NULL;
    }

    private static String val(Object x) {
        if (isNull(x)) return "<null>";
        String s = String.valueOf(x);
        if (s.length() > 180) s = s.substring(0, 180) + "…";
        return s;
    }

    private static Set<String> keys(JSONObject a, JSONObject b) {
        Set<String> out = new HashSet<>();
        Iterator<String> ai = a.keys();
        while (ai.hasNext()) out.add(ai.next());
        Iterator<String> bi = b.keys();
        while (bi.hasNext()) out.add(bi.next());
        return out;
    }

    private static void emit(StringBuilder out, Counter c, String line) {
        if (c.count >= MAX_CHANGES) {
            c.truncated = true;
            return;
        }
        c.count++;
        out.append("DIFF ").append(line).append('\n');
    }

    private static String safe(String x) {
        return x == null ? "" : x.replace('\n', ' ').replace('\r', ' ');
    }

    private static final class Counter {
        int count;
        boolean truncated;
    }
}
