package com.okn.dsp.probe;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;
import android.os.Build;
import android.os.SystemClock;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

final class UsbProbe {
    // USB bmRequestType recipient bits are defined by the USB specification,
    // but Android UsbConstants does not expose USB_RECIP_INTERFACE.
    private static final int USB_RECIP_INTERFACE = 0x01;
    interface Host {
        void line(String s);
        void refreshUsbButtons(List<UsbDevice> devices);
    }

    static final String ACTION_USB_PERMISSION = "com.okn.dsp.probe.USB_PERMISSION";

    private final Context context;
    private final UsbManager manager;
    private final Host host;

    UsbProbe(Context context, Host host) {
        this.context = context;
        this.host = host;
        this.manager = (UsbManager) context.getSystemService(Context.USB_SERVICE);
    }

    UsbManager manager() { return manager; }

    void enumerate() {
        if (manager == null) {
            host.line("USB host manager unavailable");
            host.refreshUsbButtons(new ArrayList<>());
            return;
        }
        Map<String, UsbDevice> map = manager.getDeviceList();
        List<UsbDevice> devices = new ArrayList<>(map.values());
        devices.sort(Comparator.comparingInt(UsbDevice::getVendorId)
                .thenComparingInt(UsbDevice::getProductId));
        host.line("USB ENUM: " + devices.size() + " attached device(s)");
        for (UsbDevice d : devices) describePublic(d);
        host.refreshUsbButtons(devices);
    }

    void requestPermission(UsbDevice d) {
        if (manager == null || d == null) return;
        if (manager.hasPermission(d)) {
            probeWithPermission(d);
            return;
        }
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 31) flags |= PendingIntent.FLAG_MUTABLE;
        PendingIntent pi = PendingIntent.getBroadcast(context, 7002,
                new Intent(ACTION_USB_PERMISSION).setPackage(context.getPackageName()), flags);
        host.line("USB: requesting read-only access for " + id(d));
        manager.requestPermission(d, pi);
    }

    void describePublic(UsbDevice d) {
        host.line("USB DEVICE " + id(d)
                + " name=" + d.getDeviceName()
                + " class=" + className(d.getDeviceClass()) + "(" + d.getDeviceClass() + ")"
                + " sub=" + d.getDeviceSubclass()
                + " proto=" + d.getDeviceProtocol()
                + " version=" + safeVersion(d));
        host.line("  strings manufacturer=" + safeManufacturer(d)
                + " product=" + safeProduct(d)
                + " serial=" + safeSerial(d));
        for (int i = 0; i < d.getInterfaceCount(); i++) {
            UsbInterface f = d.getInterface(i);
            host.line(String.format(Locale.US,
                    "  IF[%d] id=%d alt=%d class=%s(%d) sub=%d proto=%d endpoints=%d",
                    i, f.getId(), f.getAlternateSetting(), className(f.getInterfaceClass()),
                    f.getInterfaceClass(), f.getInterfaceSubclass(), f.getInterfaceProtocol(),
                    f.getEndpointCount()));
            for (int e = 0; e < f.getEndpointCount(); e++) {
                UsbEndpoint ep = f.getEndpoint(e);
                host.line(String.format(Locale.US,
                        "    EP[%d] addr=0x%02X dir=%s type=%s(%d) maxPacket=%d interval=%d",
                        e, ep.getAddress(),
                        ep.getDirection() == UsbConstants.USB_DIR_IN ? "IN" : "OUT",
                        endpointType(ep.getType()), ep.getType(),
                        ep.getMaxPacketSize(), ep.getInterval()));
            }
        }
        host.line("  permission=" + (manager != null && manager.hasPermission(d)));
    }

    void probeWithPermission(UsbDevice d) {
        if (manager == null || d == null) return;
        describePublic(d);
        UsbDeviceConnection c = manager.openDevice(d);
        if (c == null) {
            host.line("USB OPEN FAILED " + id(d));
            return;
        }
        try {
            byte[] raw = c.getRawDescriptors();
            host.line("USB RAW DESCRIPTORS bytes=" + (raw == null ? 0 : raw.length));
            if (raw != null) {
                dumpDescriptors(raw);
                dumpHidReportsReadOnly(c, raw);
                probeHidReadOnly(c, d, raw);
            }
        } catch (Throwable t) {
            host.line("USB descriptor error: " + t.getClass().getSimpleName() + ": " + safeMsg(t));
        } finally {
            c.close();
        }
        host.line("USB V3 read-only probe complete. No SET_REPORT, endpoint OUT, DSP write, erase, or firmware write was performed.");
    }

    private void dumpDescriptors(byte[] raw) {
        int p = 0;
        int currentInterface = -1;
        while (p + 2 <= raw.length) {
            int len = raw[p] & 0xff;
            int type = raw[p + 1] & 0xff;
            if (len < 2 || p + len > raw.length) break;
            if (type == 4 && len >= 9) currentInterface = raw[p + 2] & 0xff;
            String extra = "";
            if (type == 1 && len >= 18) {
                int vid = u16(raw, p + 8), pid = u16(raw, p + 10);
                extra = String.format(Locale.US, " VID=%04X PID=%04X", vid, pid);
            } else if (type == 2 && len >= 9) {
                extra = " totalLen=" + u16(raw, p + 2) + " interfaces=" + (raw[p + 4] & 0xff);
            } else if (type == 4 && len >= 9) {
                extra = " if=" + (raw[p + 2] & 0xff) + " alt=" + (raw[p + 3] & 0xff)
                        + " class=" + className(raw[p + 5] & 0xff)
                        + " sub=" + (raw[p + 6] & 0xff) + " proto=" + (raw[p + 7] & 0xff);
            } else if (type == 5 && len >= 7) {
                extra = String.format(Locale.US, " ep=0x%02X attr=0x%02X max=%d",
                        raw[p + 2] & 0xff, raw[p + 3] & 0xff, u16(raw, p + 4));
            } else if (type == 0x21) {
                extra = " HID forIf=" + currentInterface;
            }
            host.line(String.format(Locale.US, "  DESC off=%d len=%d type=0x%02X%s hex=%s",
                    p, len, type, extra, hex(raw, p, len, 96)));
            p += len;
        }
        if (p < raw.length) host.line("  RAW TAIL " + hex(raw, p, raw.length - p, 256));
    }

    /**
     * GET_DESCRIPTOR(HID_REPORT) is a standard USB IN request: it only reads descriptor bytes.
     * No interface is claimed and no OUT/control-write request is sent.
     */
    private void dumpHidReportsReadOnly(UsbDeviceConnection c, byte[] raw) {
        int p = 0;
        int currentInterface = -1;
        while (p + 2 <= raw.length) {
            int len = raw[p] & 0xff;
            int type = raw[p + 1] & 0xff;
            if (len < 2 || p + len > raw.length) break;
            if (type == 4 && len >= 9) currentInterface = raw[p + 2] & 0xff;
            if (type == 0x21 && currentInterface >= 0 && len >= 9) {
                int n = raw[p + 5] & 0xff;
                for (int k = 0; k < n; k++) {
                    int base = p + 6 + 3 * k;
                    if (base + 2 >= p + len) break;
                    int descType = raw[base] & 0xff;
                    int descLen = u16(raw, base + 1);
                    if (descType != 0x22 || descLen <= 0 || descLen > 4096) continue;
                    byte[] b = new byte[descLen];
                    int got = c.controlTransfer(
                            UsbConstants.USB_DIR_IN | UsbConstants.USB_TYPE_STANDARD | USB_RECIP_INTERFACE,
                            0x06, 0x22 << 8, currentInterface,
                            b, b.length, 1500);
                    host.line("  HID REPORT if=" + currentInterface + " declared=" + descLen
                            + " read=" + got + (got > 0 ? " hex=" + hex(b, 0, got, 1024) : ""));
                }
            }
            p += len;
        }
    }


    /**
     * V3 active-read stage. Every transaction below is host-to-device READ only.
     * V2 revealed that this device may return more bytes than the HID descriptor
     * declares for FEATURE reports when a large buffer is requested. V3 therefore
     * derives report lengths from the HID report descriptor and never requests more
     * than the declared report size.
     */
    private void probeHidReadOnly(UsbDeviceConnection c, UsbDevice d, byte[] raw) {
        host.line("USB HID V3 EXACT-READ: starting descriptor-sized HID checks");
        for (int i = 0; i < d.getInterfaceCount(); i++) {
            UsbInterface f = d.getInterface(i);
            if (f.getInterfaceClass() != UsbConstants.USB_CLASS_HID) continue;
            int ifId = f.getId();
            int declared = reportDescriptorLength(raw, ifId);
            boolean claimed = false;
            try {
                claimed = c.claimInterface(f, false);
                host.line("  HID IF" + ifId + " claim=" + claimed
                        + " endpoints=" + f.getEndpointCount()
                        + " reportDescLen=" + declared);

                byte[] reportDesc = null;
                if (claimed && declared > 0 && declared <= 4096) {
                    reportDesc = new byte[declared];
                    int got = c.controlTransfer(
                            UsbConstants.USB_DIR_IN | UsbConstants.USB_TYPE_STANDARD | USB_RECIP_INTERFACE,
                            0x06, 0x22 << 8, ifId,
                            reportDesc, reportDesc.length, 1200);
                    host.line("    CLAIMED HID REPORT if=" + ifId + " declared=" + declared
                            + " read=" + got + (got > 0 ? " hex=" + hex(reportDesc, 0, got, 1024) : ""));
                    if (got > 0 && got < reportDesc.length) {
                        byte[] trimmed = new byte[got];
                        System.arraycopy(reportDesc, 0, trimmed, 0, got);
                        reportDesc = trimmed;
                    } else if (got <= 0) {
                        reportDesc = null;
                    }
                }

                if (claimed && reportDesc != null) {
                    HidShape shape = parseHidShape(reportDesc);
                    host.line("    HID SHAPE if=" + ifId
                            + " reportIdPresent=" + shape.reportIdPresent
                            + " inputBytes=" + shape.inputBytes
                            + " outputBytes=" + shape.outputBytes
                            + " featureBytes=" + shape.featureBytes);

                    if (shape.reportIdPresent) {
                        host.line("    NOTE: report IDs are present; V3 will not guess IDs.");
                    } else {
                        if (shape.inputBytes > 0 && shape.inputBytes <= 4096) {
                            readHidReport(c, ifId, 1, 0, shape.inputBytes, "INPUT exact");
                        }
                        if (shape.featureBytes > 0 && shape.featureBytes <= 4096) {
                            for (int attempt = 1; attempt <= 3; attempt++) {
                                readHidReport(c, ifId, 3, 0, shape.featureBytes,
                                        "FEATURE exact #" + attempt);
                                if (attempt < 3) SystemClock.sleep(80);
                            }
                        }
                    }

                    // Read only interrupt-IN endpoints. No OUT endpoint is touched.
                    for (int e = 0; e < f.getEndpointCount(); e++) {
                        UsbEndpoint ep = f.getEndpoint(e);
                        if (ep.getDirection() != UsbConstants.USB_DIR_IN
                                || ep.getType() != UsbConstants.USB_ENDPOINT_XFER_INT) continue;
                        int size = Math.max(1, Math.min(4096, ep.getMaxPacketSize()));
                        byte[] in = new byte[size];
                        for (int attempt = 1; attempt <= 3; attempt++) {
                            int got = c.bulkTransfer(ep, in, in.length, 250);
                            host.line(String.format(Locale.US,
                                    "    INT-IN if=%d ep=0x%02X attempt=%d read=%d%s",
                                    ifId, ep.getAddress(), attempt, got,
                                    got > 0 ? " hex=" + hex(in, 0, got, 1024) : ""));
                            if (got > 0) break;
                        }
                    }
                }
            } catch (Throwable t) {
                host.line("  HID IF" + ifId + " read error: "
                        + t.getClass().getSimpleName() + ": " + safeMsg(t));
            } finally {
                if (claimed) {
                    try { c.releaseInterface(f); } catch (Throwable ignored) {}
                }
            }
        }
        host.line("USB HID V3 EXACT-READ: finished; all requests were IN/read-only");
    }

    private void readHidReport(UsbDeviceConnection c, int ifId, int reportType,
                               int reportId, int exactLen, String label) {
        int len = Math.max(1, Math.min(exactLen, 4096));
        byte[] b = new byte[len];
        int got = c.controlTransfer(
                UsbConstants.USB_DIR_IN | UsbConstants.USB_TYPE_CLASS | USB_RECIP_INTERFACE,
                0x01, (reportType << 8) | (reportId & 0xff), ifId,
                b, b.length, 1000);
        host.line("    GET_REPORT " + label + " if=" + ifId
                + " reportId=" + reportId + " requested=" + len + " read=" + got
                + (got > 0 ? " hex=" + hex(b, 0, got, 2048) : ""));
    }

    private static final class HidShape {
        int inputBits;
        int outputBits;
        int featureBits;
        boolean reportIdPresent;
        int inputBytes;
        int outputBytes;
        int featureBytes;
    }

    /** Minimal HID short-item parser sufficient to derive report byte lengths safely. */
    private HidShape parseHidShape(byte[] d) {
        HidShape out = new HidShape();
        int reportSize = 0;
        int reportCount = 0;
        int p = 0;
        while (p < d.length) {
            int prefix = d[p++] & 0xff;
            if (prefix == 0xFE) { // long item
                if (p + 2 > d.length) break;
                int n = d[p] & 0xff;
                p += 2 + n;
                continue;
            }
            int sizeCode = prefix & 0x03;
            int size = sizeCode == 3 ? 4 : sizeCode;
            int type = (prefix >> 2) & 0x03;
            int tag = (prefix >> 4) & 0x0F;
            if (p + size > d.length) break;
            int value = 0;
            for (int i = 0; i < size; i++) value |= (d[p + i] & 0xff) << (8 * i);
            p += size;

            if (type == 1) { // Global
                if (tag == 7) reportSize = value;       // Report Size
                else if (tag == 9) reportCount = value; // Report Count
                else if (tag == 8) out.reportIdPresent = true; // Report ID
            } else if (type == 0) { // Main
                long bits = (long) reportSize * (long) reportCount;
                if (bits > Integer.MAX_VALUE) bits = Integer.MAX_VALUE;
                if (tag == 8) out.inputBits += (int) bits;
                else if (tag == 9) out.outputBits += (int) bits;
                else if (tag == 11) out.featureBits += (int) bits;
            }
        }
        out.inputBytes = (out.inputBits + 7) / 8;
        out.outputBytes = (out.outputBits + 7) / 8;
        out.featureBytes = (out.featureBits + 7) / 8;
        return out;
    }

    private int reportDescriptorLength(byte[] raw, int targetIf) {
        int p = 0;
        int currentInterface = -1;
        while (p + 2 <= raw.length) {
            int len = raw[p] & 0xff;
            int type = raw[p + 1] & 0xff;
            if (len < 2 || p + len > raw.length) break;
            if (type == 4 && len >= 9) currentInterface = raw[p + 2] & 0xff;
            if (type == 0x21 && currentInterface == targetIf && len >= 9) {
                int n = raw[p + 5] & 0xff;
                for (int k = 0; k < n; k++) {
                    int base = p + 6 + 3 * k;
                    if (base + 2 >= p + len) break;
                    if ((raw[base] & 0xff) == 0x22) return u16(raw, base + 1);
                }
            }
            p += len;
        }
        return -1;
    }

    static String id(UsbDevice d) {
        return String.format(Locale.US, "VID=%04X PID=%04X", d.getVendorId(), d.getProductId());
    }

    static String className(int c) {
        switch (c) {
            case UsbConstants.USB_CLASS_PER_INTERFACE: return "PER_INTERFACE";
            case UsbConstants.USB_CLASS_AUDIO: return "AUDIO";
            case UsbConstants.USB_CLASS_COMM: return "CDC_COMM";
            case UsbConstants.USB_CLASS_HID: return "HID";
            case UsbConstants.USB_CLASS_PHYSICA: return "PHYSICAL";
            case UsbConstants.USB_CLASS_STILL_IMAGE: return "STILL_IMAGE";
            case UsbConstants.USB_CLASS_PRINTER: return "PRINTER";
            case UsbConstants.USB_CLASS_MASS_STORAGE: return "MASS_STORAGE";
            case UsbConstants.USB_CLASS_HUB: return "HUB";
            case UsbConstants.USB_CLASS_CDC_DATA: return "CDC_DATA";
            case UsbConstants.USB_CLASS_CONTENT_SEC: return "CONTENT_SECURITY";
            case UsbConstants.USB_CLASS_VIDEO: return "VIDEO";
            case UsbConstants.USB_CLASS_WIRELESS_CONTROLLER: return "WIRELESS";
            case UsbConstants.USB_CLASS_MISC: return "MISC";
            case UsbConstants.USB_CLASS_APP_SPEC: return "APP_SPECIFIC/DFU?";
            case UsbConstants.USB_CLASS_VENDOR_SPEC: return "VENDOR_SPECIFIC";
            default: return "CLASS_0x" + String.format(Locale.US, "%02X", c & 0xff);
        }
    }

    private static String endpointType(int t) {
        switch (t) {
            case UsbConstants.USB_ENDPOINT_XFER_CONTROL: return "CONTROL";
            case UsbConstants.USB_ENDPOINT_XFER_ISOC: return "ISO";
            case UsbConstants.USB_ENDPOINT_XFER_BULK: return "BULK";
            case UsbConstants.USB_ENDPOINT_XFER_INT: return "INTERRUPT";
            default: return "TYPE_" + t;
        }
    }

    private static int u16(byte[] b, int o) {
        return (b[o] & 0xff) | ((b[o + 1] & 0xff) << 8);
    }

    static String hex(byte[] b, int off, int len, int maxBytes) {
        int n = Math.min(len, maxBytes);
        StringBuilder s = new StringBuilder(n * 3 + 16);
        for (int i = 0; i < n; i++) {
            if (i > 0) s.append(' ');
            s.append(String.format(Locale.US, "%02X", b[off + i] & 0xff));
        }
        if (n < len) s.append(" ...(+").append(len - n).append(" bytes)");
        return s.toString();
    }

    private static String safeVersion(UsbDevice d) {
        try { return d.getVersion(); } catch (Throwable t) { return "?"; }
    }
    private static String safeManufacturer(UsbDevice d) {
        try { String s = d.getManufacturerName(); return s == null ? "?" : s; }
        catch (Throwable t) { return "<permission>"; }
    }
    private static String safeProduct(UsbDevice d) {
        try { String s = d.getProductName(); return s == null ? "?" : s; }
        catch (Throwable t) { return "<permission>"; }
    }
    private static String safeSerial(UsbDevice d) {
        try { String s = d.getSerialNumber(); return s == null ? "?" : s; }
        catch (Throwable t) { return "<permission>"; }
    }
    private static String safeMsg(Throwable t) {
        String m = t.getMessage(); return m == null ? "" : m;
    }
}
