package com.okn.dsp.probe;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

final class ProbeLog {
    private final StringBuilder text = new StringBuilder(16 * 1024);
    private final SimpleDateFormat time = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US);

    synchronized String add(String line) {
        String s = "[" + time.format(new Date()) + "] " + line;
        text.append(s).append('\n');
        return s;
    }

    synchronized String all() {
        return text.toString();
    }

    synchronized void clear() {
        text.setLength(0);
    }
}
