package com.okn.dsp.probe;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class MainActivity extends Activity implements UsbProbe.Host, BluetoothProbe.Host {
    private static final int REQ_BT = 7101;

    private final ProbeLog report = new ProbeLog();
    private final Set<String> bleButtonAddresses = new HashSet<>();
    private TextView logView;
    private LinearLayout usbButtons;
    private LinearLayout bleButtons;
    private ScrollView logScroll;
    private UsbProbe usbProbe;
    private BluetoothProbe btProbe;

    private final BroadcastReceiver usbReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            String a = i.getAction();
            if (UsbProbe.ACTION_USB_PERMISSION.equals(a)) {
                UsbDevice d = getUsbExtra(i);
                boolean ok = i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false);
                line("USB permission result=" + ok + " device=" + (d == null ? "?" : UsbProbe.id(d)));
                if (ok && d != null) usbProbe.probeWithPermission(d);
            } else if (UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(a)) {
                line("USB DEVICE ATTACHED");
                usbProbe.enumerate();
            } else if (UsbManager.ACTION_USB_DEVICE_DETACHED.equals(a)) {
                line("USB DEVICE DETACHED");
                usbProbe.enumerate();
            }
        }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        usbProbe = new UsbProbe(this, this);
        btProbe = new BluetoothProbe(this, this);
        registerUsbReceiver();
        header();
        usbProbe.enumerate();
        ensureBluetoothPermissions(false);
    }

    @Override protected void onDestroy() {
        try { unregisterReceiver(usbReceiver); } catch (Throwable ignored) {}
        if (btProbe != null) btProbe.close();
        super.onDestroy();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(14), dp(14), dp(14));
        root.setBackgroundColor(0xfff5f7fa);

        TextView title = new TextView(this);
        title.setText("OKN DSP Probe V3\nBP1048P4 / Samsung USB-C + Bluetooth");
        title.setTextSize(21);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setTextColor(0xff101828);
        root.addView(title);

        TextView safety = new TextView(this);
        safety.setText("READ-ONLY V3: exact HID report-length reads + BLE AB01 READ. No SET_REPORT, USB OUT, BLE write, DSP write, erase, or firmware flash.");
        safety.setTextSize(13);
        safety.setTextColor(0xff475467);
        safety.setPadding(0, dp(6), 0, dp(10));
        root.addView(safety);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        Button usb = button("USB Scan");
        Button ble = button("BLE Scan");
        Button copy = button("Copy Report");
        Button share = button("Share");
        actions.addView(usb, weight());
        actions.addView(ble, weight());
        actions.addView(copy, weight());
        actions.addView(share, weight());
        root.addView(actions);

        TextView u = section("USB devices — tap to request read-only descriptor access");
        root.addView(u);
        usbButtons = new LinearLayout(this);
        usbButtons.setOrientation(LinearLayout.VERTICAL);
        root.addView(usbButtons);

        TextView b = section("BLE devices — scan, then tap a device to enumerate GATT");
        root.addView(b);
        bleButtons = new LinearLayout(this);
        bleButtons.setOrientation(LinearLayout.VERTICAL);
        root.addView(bleButtons);

        TextView r = section("Probe report");
        root.addView(r);
        logView = new TextView(this);
        logView.setTextSize(11);
        logView.setTypeface(Typeface.MONOSPACE);
        logView.setTextColor(0xff101828);
        logView.setTextIsSelectable(true);
        logView.setPadding(dp(8), dp(8), dp(8), dp(8));
        logScroll = new ScrollView(this);
        logScroll.addView(logView);
        root.addView(logScroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        usb.setOnClickListener(v -> usbProbe.enumerate());
        ble.setOnClickListener(v -> {
            if (ensureBluetoothPermissions(true)) btProbe.startBleScan();
        });
        copy.setOnClickListener(v -> copyReport());
        share.setOnClickListener(v -> shareReport());

        setContentView(root);
    }

    private void header() {
        line("OKN DSP Probe V3.0.0");
        line("PHONE manufacturer=" + Build.MANUFACTURER + " model=" + Build.MODEL
                + " product=" + Build.PRODUCT + " AndroidSDK=" + Build.VERSION.SDK_INT
                + " release=" + Build.VERSION.RELEASE);
        line("Known OKN BLE profile from the existing controller app: service AB00, TX AB01, RX AB02.");
        line("USB safety V3: only IN/read operations are used. FEATURE reads are capped to the exact size declared by the HID descriptor. No SET_REPORT or OUT transfer is sent.");
    }

    @Override public void line(String s) {
        final String added = report.add(s);
        runOnUiThread(() -> {
            logView.append(added + "\n");
            logScroll.post(() -> logScroll.fullScroll(View.FOCUS_DOWN));
        });
    }

    @Override public void refreshUsbButtons(List<UsbDevice> devices) {
        runOnUiThread(() -> {
            usbButtons.removeAllViews();
            if (devices.isEmpty()) {
                TextView t = new TextView(this);
                t.setText("No USB device detected. Connect the DSP through a USB-C OTG/data path and tap USB Scan.");
                t.setTextColor(0xff667085);
                usbButtons.addView(t);
                return;
            }
            for (UsbDevice d : devices) {
                Button x = button("Probe " + UsbProbe.id(d) + "  " + safeUsbName(d));
                x.setOnClickListener(v -> usbProbe.requestPermission(d));
                usbButtons.addView(x, new LinearLayout.LayoutParams(-1, -2));
            }
        });
    }

    @Override public void onBleCandidate(BluetoothDevice d, int rssi, String detail) {
        final String addr = BluetoothProbe.safeAddr(d);
        runOnUiThread(() -> {
            if (!bleButtonAddresses.add(addr)) return;
            Button x = button("GATT Probe: " + BluetoothProbe.safeName(d) + "  " + addr + "  " + rssi + " dBm");
            x.setOnClickListener(v -> btProbe.probeGatt(d));
            bleButtons.addView(x, new LinearLayout.LayoutParams(-1, -2));
        });
    }

    private boolean ensureBluetoothPermissions(boolean request) {
        if (Build.VERSION.SDK_INT >= 31) {
            boolean scan = checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED;
            boolean connect = checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
            if (!scan || !connect) {
                if (request) requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}, REQ_BT);
                return false;
            }
        } else {
            boolean loc = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
            if (!loc) {
                if (request) requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_BT);
                return false;
            }
        }
        return true;
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_BT) return;
        boolean ok = grantResults.length > 0;
        for (int x : grantResults) ok &= x == PackageManager.PERMISSION_GRANTED;
        line("Bluetooth permission result=" + ok);
        if (ok) btProbe.startBleScan();
    }

    private void registerUsbReceiver() {
        IntentFilter f = new IntentFilter();
        f.addAction(UsbProbe.ACTION_USB_PERMISSION);
        f.addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED);
        f.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(usbReceiver, f, RECEIVER_NOT_EXPORTED);
        else registerReceiver(usbReceiver, f);
    }

    private void copyReport() {
        ClipboardManager c = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        c.setPrimaryClip(ClipData.newPlainText("OKN DSP Probe report", report.all()));
        Toast.makeText(this, "Copied probe report", Toast.LENGTH_SHORT).show();
    }

    private void shareReport() {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_SUBJECT, "OKN DSP Probe report");
        i.putExtra(Intent.EXTRA_TEXT, report.all());
        startActivity(Intent.createChooser(i, "Share OKN DSP Probe report"));
    }

    private TextView section(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(14);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setTextColor(0xff344054);
        t.setPadding(0, dp(10), 0, dp(4));
        return t;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(s);
        b.setTextSize(12);
        return b;
    }

    private LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(0, -2, 1f);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private static String safeUsbName(UsbDevice d) {
        try {
            String p = d.getProductName();
            return p == null ? "" : p;
        } catch (Throwable t) {
            return "";
        }
    }

    @SuppressWarnings("deprecation")
    private static UsbDevice getUsbExtra(Intent i) {
        if (Build.VERSION.SDK_INT >= 33) return i.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice.class);
        return i.getParcelableExtra(UsbManager.EXTRA_DEVICE);
    }
}
