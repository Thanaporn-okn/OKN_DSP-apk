package com.okn.dsp.probe;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;
import android.util.SparseArray;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

final class BluetoothProbe {
    interface Host {
        void line(String s);
        void onBleCandidate(BluetoothDevice d, int rssi, String detail);
    }

    static final UUID KNOWN_OKN_SERVICE = UUID.fromString("0000ab00-0000-1000-8000-00805f9b34fb");
    static final UUID KNOWN_OKN_TX = UUID.fromString("0000ab01-0000-1000-8000-00805f9b34fb");
    static final UUID KNOWN_OKN_RX = UUID.fromString("0000ab02-0000-1000-8000-00805f9b34fb");

    private final Context context;
    private final Host host;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final BluetoothAdapter adapter;
    private BluetoothLeScanner scanner;
    private final Set<String> seen = new HashSet<>();
    private final List<BluetoothGatt> gatts = new ArrayList<>();
    private boolean scanning;

    BluetoothProbe(Context context, Host host) {
        this.context = context.getApplicationContext();
        this.host = host;
        BluetoothAdapter a = null;
        try {
            BluetoothManager m = (BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE);
            a = m == null ? null : m.getAdapter();
        } catch (Throwable ignored) {}
        adapter = a;
    }

    boolean hasPermissions() {
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            return context.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                    && context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    void startBleScan() {
        if (!hasPermissions()) { host.line("BLE: permission missing"); return; }
        if (adapter == null) { host.line("BLE: adapter unavailable"); return; }
        try {
            if (!adapter.isEnabled()) { host.line("BLE: Bluetooth is OFF"); return; }
            scanner = adapter.getBluetoothLeScanner();
            if (scanner == null) { host.line("BLE: scanner unavailable"); return; }
            stopBleScan();
            seen.clear();
            scanning = true;
            host.line("BLE SCAN started for 12 seconds. Tap a discovered device to enumerate GATT services.");
            scanner.startScan(scanCallback);
            main.postDelayed(this::stopBleScan, 12_000L);
        } catch (SecurityException e) {
            host.line("BLE: permission rejected by Android");
        } catch (Throwable t) {
            host.line("BLE start error: " + t.getClass().getSimpleName() + ": " + safeMsg(t));
        }
    }

    void stopBleScan() {
        if (!scanning) return;
        scanning = false;
        try {
            if (scanner != null && hasPermissions()) scanner.stopScan(scanCallback);
        } catch (Throwable ignored) {}
        host.line("BLE SCAN stopped");
    }

    void probeGatt(BluetoothDevice d) {
        if (d == null || !hasPermissions()) return;
        String name = safeName(d);
        host.line("GATT CONNECT read-only: " + name + " [" + safeAddr(d) + "]");
        try {
            BluetoothGatt g = d.connectGatt(context, false, gattCallback, BluetoothDevice.TRANSPORT_LE);
            if (g != null) {
                synchronized (gatts) { gatts.add(g); }
                main.postDelayed(() -> timeoutGatt(g), 15_000L);
            }
        } catch (Throwable t) {
            host.line("GATT connect error: " + t.getClass().getSimpleName() + ": " + safeMsg(t));
        }
    }

    void close() {
        stopBleScan();
        synchronized (gatts) {
            for (BluetoothGatt g : gatts) {
                try { g.disconnect(); } catch (Throwable ignored) {}
                try { g.close(); } catch (Throwable ignored) {}
            }
            gatts.clear();
        }
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult r) {
            BluetoothDevice d = r.getDevice();
            if (d == null) return;
            String addr = safeAddr(d);
            if (!seen.add(addr)) return;
            ScanRecord rec = r.getScanRecord();
            StringBuilder detail = new StringBuilder();
            if (rec != null) {
                List<ParcelUuid> uuids = rec.getServiceUuids();
                if (uuids != null && !uuids.isEmpty()) detail.append(" advServices=").append(uuids);
                SparseArray<byte[]> m = rec.getManufacturerSpecificData();
                if (m != null && m.size() > 0) {
                    detail.append(" mfg=");
                    for (int i = 0; i < m.size(); i++) {
                        if (i > 0) detail.append(';');
                        detail.append(String.format(Locale.US, "%04X:", m.keyAt(i)))
                                .append(UsbProbe.hex(m.valueAt(i), 0, m.valueAt(i).length, 48));
                    }
                }
                byte[] all = rec.getBytes();
                if (all != null) detail.append(" advRaw=").append(UsbProbe.hex(all, 0, all.length, 128));
            }
            String n = safeName(d);
            host.line("BLE FOUND name=" + n + " addr=" + addr + " rssi=" + r.getRssi() + detail);
            host.onBleCandidate(d, r.getRssi(), detail.toString());
        }

        @Override public void onScanFailed(int errorCode) {
            scanning = false;
            host.line("BLE SCAN failed code=" + errorCode);
        }
    };

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
            host.line("GATT state status=" + status + " newState=" + newState
                    + " device=" + safeName(g.getDevice()));
            if (status == BluetoothGatt.GATT_SUCCESS && newState == android.bluetooth.BluetoothProfile.STATE_CONNECTED) {
                try {
                    boolean started = g.discoverServices();
                    host.line("GATT discoverServices started=" + started);
                } catch (Throwable t) {
                    finishGatt(g, "discover error " + t.getClass().getSimpleName());
                }
            } else if (newState == android.bluetooth.BluetoothProfile.STATE_DISCONNECTED) {
                finishGatt(g, "disconnected");
            }
        }

        @Override public void onServicesDiscovered(BluetoothGatt g, int status) {
            host.line("GATT SERVICES status=" + status + " device=" + safeName(g.getDevice()));
            if (status == BluetoothGatt.GATT_SUCCESS) {
                boolean known = false;
                for (BluetoothGattService s : g.getServices()) {
                    if (KNOWN_OKN_SERVICE.equals(s.getUuid())) known = true;
                    host.line("  SERVICE " + s.getUuid() + " type=" + serviceType(s.getType()));
                    for (BluetoothGattCharacteristic c : s.getCharacteristics()) {
                        boolean knownChar = KNOWN_OKN_TX.equals(c.getUuid()) || KNOWN_OKN_RX.equals(c.getUuid());
                        host.line("    CHAR " + c.getUuid() + " props=" + properties(c.getProperties())
                                + (knownChar ? "  <KNOWN OKN>" : ""));
                        for (BluetoothGattDescriptor d : c.getDescriptors()) {
                            host.line("      DESC " + d.getUuid());
                        }
                    }
                }
                if (known) host.line("*** FOUND known OKN control service AB00 / AB01 / AB02 ***");

                BluetoothGattService okn = g.getService(KNOWN_OKN_SERVICE);
                BluetoothGattCharacteristic tx = okn == null ? null : okn.getCharacteristic(KNOWN_OKN_TX);
                if (tx != null && (tx.getProperties() & BluetoothGattCharacteristic.PROPERTY_READ) != 0) {
                    try {
                        boolean started = g.readCharacteristic(tx);
                        host.line("GATT V3 READ-ONLY: AB01 read started=" + started);
                        if (started) return;
                    } catch (Throwable t) {
                        host.line("GATT V3 AB01 read error: " + t.getClass().getSimpleName() + ": " + safeMsg(t));
                    }
                }
                host.line("GATT enumeration complete. No characteristic write was performed.");
            }
            finishGatt(g, "services complete");
        }

        @Override public void onCharacteristicRead(BluetoothGatt g, BluetoothGattCharacteristic c, int status) {
            byte[] value = c == null ? null : c.getValue();
            logCharacteristicRead(g, c, value, status);
        }

        @Override public void onCharacteristicRead(BluetoothGatt g, BluetoothGattCharacteristic c,
                                                    byte[] value, int status) {
            logCharacteristicRead(g, c, value, status);
        }
    };

    private void logCharacteristicRead(BluetoothGatt g, BluetoothGattCharacteristic c,
                                       byte[] value, int status) {
        UUID uuid = c == null ? null : c.getUuid();
        host.line("GATT CHAR READ status=" + status + " uuid=" + uuid
                + " len=" + (value == null ? 0 : value.length)
                + (value != null && value.length > 0
                ? " hex=" + UsbProbe.hex(value, 0, value.length, 512) : ""));
        finishGatt(g, "read complete");
    }

    private void timeoutGatt(BluetoothGatt g) {
        synchronized (gatts) {
            if (!gatts.contains(g)) return;
        }
        finishGatt(g, "15s timeout");
    }

    private void finishGatt(BluetoothGatt g, String why) {
        boolean doClose;
        synchronized (gatts) { doClose = gatts.remove(g); }
        if (!doClose) return;
        host.line("GATT close: " + why);
        try { g.disconnect(); } catch (Throwable ignored) {}
        try { g.close(); } catch (Throwable ignored) {}
    }

    private static String properties(int p) {
        List<String> a = new ArrayList<>();
        if ((p & BluetoothGattCharacteristic.PROPERTY_BROADCAST) != 0) a.add("BROADCAST");
        if ((p & BluetoothGattCharacteristic.PROPERTY_READ) != 0) a.add("READ");
        if ((p & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0) a.add("WRITE_NR");
        if ((p & BluetoothGattCharacteristic.PROPERTY_WRITE) != 0) a.add("WRITE");
        if ((p & BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0) a.add("NOTIFY");
        if ((p & BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) a.add("INDICATE");
        if ((p & BluetoothGattCharacteristic.PROPERTY_SIGNED_WRITE) != 0) a.add("SIGNED_WRITE");
        if ((p & BluetoothGattCharacteristic.PROPERTY_EXTENDED_PROPS) != 0) a.add("EXTENDED");
        return a.isEmpty() ? "NONE" : String.join("|", a);
    }

    private static String serviceType(int t) {
        return t == BluetoothGattService.SERVICE_TYPE_PRIMARY ? "PRIMARY" : "SECONDARY";
    }

    static String safeName(BluetoothDevice d) {
        try { String n = d.getName(); return n == null ? "<unnamed>" : n; }
        catch (Throwable t) { return "<permission>"; }
    }
    static String safeAddr(BluetoothDevice d) {
        try { return d.getAddress(); } catch (Throwable t) { return "<permission>"; }
    }
    private static String safeMsg(Throwable t) {
        String m = t.getMessage(); return m == null ? "" : m;
    }
}
