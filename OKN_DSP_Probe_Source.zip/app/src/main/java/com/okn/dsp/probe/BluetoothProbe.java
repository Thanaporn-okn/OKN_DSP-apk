package com.okn.dsp.probe;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothSocket;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;
import android.os.Parcelable;
import android.util.SparseArray;

import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

import org.json.JSONArray;
import org.json.JSONObject;

final class BluetoothProbe {
    interface Host {
        void line(String s);
        void onBleCandidate(BluetoothDevice d, int rssi, String detail);
        void onClassicCandidate(BluetoothDevice d, int rssi, String detail);
        void onSppCandidate(BluetoothDevice d);
        void onBleAuthCandidate(BluetoothDevice d);
        void onDescriptorJson(byte[] json);
    }

    static final UUID KNOWN_OKN_SERVICE = UUID.fromString("0000ab00-0000-1000-8000-00805f9b34fb");
    static final UUID KNOWN_OKN_TX = UUID.fromString("0000ab01-0000-1000-8000-00805f9b34fb");
    static final UUID KNOWN_OKN_RX = UUID.fromString("0000ab02-0000-1000-8000-00805f9b34fb");
    private static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    private static final byte[] AUTH16 = hexBytes("631C062443FD3844558001F3EDA0CCF8");
    private static final byte[] DEFAULT_PREAUTH_KEY = hexBytes("2AAF948632A59FF8F2B23E6E4193FD21");
    private static final byte[] TYPE_53285_PREAUTH_KEY = hexBytes("10E7D2F443924938A28D759BAC0E9E22");
    private static final byte[] SESSION_IV = repeatByte((byte)0x01, 16);
    private static final byte[] DEVICE_DESCRIPTION_REQUEST = hexBytes("661C0624");

    private static final UUID UUID_SPP = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");
    private static final UUID UUID_OBEX_OBJECT_PUSH = UUID.fromString("00001105-0000-1000-8000-00805f9b34fb");
    private static final UUID UUID_OBEX_FILE_TRANSFER = UUID.fromString("00001106-0000-1000-8000-00805f9b34fb");

    private final Context context;
    private final Host host;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final BluetoothAdapter adapter;
    private BluetoothLeScanner scanner;
    private final Set<String> seenBle = new HashSet<>();
    private final Set<String> seenClassic = new HashSet<>();
    private final List<BluetoothGatt> gatts = new ArrayList<>();
    private boolean scanningBle;
    private boolean scanningClassic;
    private boolean receiverRegistered;

    BluetoothProbe(Context context, Host host) {
        this.context = context.getApplicationContext();
        this.host = host;
        BluetoothAdapter a = null;
        try {
            BluetoothManager m = (BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE);
            a = m == null ? null : m.getAdapter();
        } catch (Throwable ignored) {}
        adapter = a;
        registerClassicReceiver();
    }

    boolean hasPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            return context.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                    && context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    void startBleScan() {
        if (!hasPermissions()) { host.line("BLE: permission missing"); return; }
        if (adapter == null) { host.line("BLE: adapter unavailable"); return; }
        try {
            if (!adapter.isEnabled()) { host.line("BLE: Bluetooth is OFF"); return; }
            stopClassicScan();
            scanner = adapter.getBluetoothLeScanner();
            if (scanner == null) { host.line("BLE: scanner unavailable"); return; }
            stopBleScan();
            seenBle.clear();
            scanningBle = true;
            host.line("BLE SCAN started for 12 seconds. Tap a discovered device to enumerate GATT services.");
            scanner.startScan(scanCallback);
            main.postDelayed(this::stopBleScan, 12_000L);
        } catch (SecurityException e) {
            host.line("BLE: permission rejected by Android");
        } catch (Throwable t) {
            host.line("BLE start error: " + t.getClass().getSimpleName() + ": " + safeMsg(t));
        }
    }

    void stopBleScan() {
        if (!scanningBle) return;
        scanningBle = false;
        try {
            if (scanner != null && hasPermissions()) scanner.stopScan(scanCallback);
        } catch (Throwable ignored) {}
        host.line("BLE SCAN stopped");
    }

    void startClassicScan() {
        if (!hasPermissions()) { host.line("CLASSIC: permission missing"); return; }
        if (adapter == null) { host.line("CLASSIC: adapter unavailable"); return; }
        try {
            if (!adapter.isEnabled()) { host.line("CLASSIC: Bluetooth is OFF"); return; }
            stopBleScan();
            if (adapter.isDiscovering()) adapter.cancelDiscovery();
            seenClassic.clear();
            dumpBondedDevices();
            boolean started = adapter.startDiscovery();
            scanningClassic = started;
            host.line("CLASSIC DISCOVERY started=" + started + ". Tap a discovered device to request standard SDP UUIDs. No pairing or OBEX data is sent by the probe.");
            if (started) main.postDelayed(this::stopClassicScan, 18_000L);
        } catch (SecurityException e) {
            host.line("CLASSIC: permission rejected by Android");
        } catch (Throwable t) {
            host.line("CLASSIC start error: " + t.getClass().getSimpleName() + ": " + safeMsg(t));
        }
    }

    void stopClassicScan() {
        if (!scanningClassic) return;
        scanningClassic = false;
        try {
            if (adapter != null && adapter.isDiscovering() && hasPermissions()) adapter.cancelDiscovery();
        } catch (Throwable ignored) {}
        host.line("CLASSIC DISCOVERY stopped");
    }

    void probeSdp(BluetoothDevice d) {
        if (d == null || !hasPermissions()) return;
        try {
            ParcelUuid[] cached = d.getUuids();
            host.line("SDP PROBE request name=" + safeName(d) + " addr=" + safeAddr(d)
                    + " type=" + typeName(safeType(d)) + " bond=" + bondName(safeBond(d))
                    + " cachedUuids=" + uuidsText(cached));
            boolean started = d.fetchUuidsWithSdp();
            host.line("SDP fetchUuidsWithSdp started=" + started + ". This performs Bluetooth service discovery only; it does not connect to an OBEX service or send a firmware file.");
        } catch (SecurityException e) {
            host.line("SDP: permission rejected by Android");
        } catch (Throwable t) {
            host.line("SDP start error: " + t.getClass().getSimpleName() + ": " + safeMsg(t));
        }
    }

    void probeSppPassive(BluetoothDevice d) {
        if (d == null || !hasPermissions()) return;
        final String name = safeName(d);
        final String addr = safeAddr(d);
        host.line("SPP V7 PASSIVE request name=" + name + " addr=" + addr
                + " bond=" + bondName(safeBond(d)) + " uuid=" + UUID_SPP);
        host.line("SPP V7 SAFETY: connect + passive RX for 3000 ms only; OutputStream is never opened and ZERO bytes are transmitted by the app. Android may request pairing if the device requires authentication.");
        new Thread(() -> {
            BluetoothSocket socket = null;
            try {
                try {
                    if (adapter != null && adapter.isDiscovering()) adapter.cancelDiscovery();
                } catch (Throwable ignored) {}
                socket = d.createRfcommSocketToServiceRecord(UUID_SPP);
                host.line("SPP V7 CONNECT starting");
                socket.connect();
                host.line("SPP V7 CONNECTED remote=" + name + " addr=" + addr);

                InputStream in = socket.getInputStream();
                byte[] buf = new byte[512];
                int total = 0;
                long end = System.currentTimeMillis() + 3000L;
                while (System.currentTimeMillis() < end) {
                    int available = 0;
                    try { available = in.available(); } catch (Throwable ignored) {}
                    if (available > 0) {
                        int want = Math.min(buf.length, available);
                        int n = in.read(buf, 0, want);
                        if (n > 0) {
                            total += n;
                            host.line("SPP V7 PASSIVE RX len=" + n + " hex="
                                    + UsbProbe.hex(buf, 0, n, 1024));
                        }
                    }
                    try { Thread.sleep(50L); } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                }
                host.line("SPP V7 PASSIVE complete totalRx=" + total + " bytes; tx=0 bytes");
            } catch (SecurityException e) {
                host.line("SPP V7 permission rejected by Android");
            } catch (Throwable t) {
                host.line("SPP V7 CONNECT/READ error: " + t.getClass().getSimpleName() + ": " + safeMsg(t));
            } finally {
                if (socket != null) {
                    try { socket.close(); } catch (Throwable ignored) {}
                }
                host.line("SPP V7 socket closed; tx=0 bytes");
            }
        }, "OKN-SPP-Passive").start();
    }

    void probeBleDescriptor(BluetoothDevice d) {
        if (d == null || !hasPermissions()) return;
        final String name = safeName(d);
        final String addr = safeAddr(d);
        host.line("BLE DESC V11 request name=" + name + " addr=" + addr);
        host.line("BLE DESC V11 SAFETY: uses the verified AUTH16 challenge, derives the session RandKey locally, then sends ONLY the encrypted Device Description request 66 1C 06 24 used by the existing OKN controller app. It does not send UFE 0x57 writes, SaveParams, erase, boot, OTA, or firmware payloads.");

        final BluetoothGattCallback cb = new BluetoothGattCallback() {
            private BluetoothGattCharacteristic tx;
            private boolean authSent;
            private boolean descriptorSent;
            private boolean done;
            private Cipher txCipher;
            private Cipher rxCipher;
            private int expected = -1;
            private int chunks;
            private final ByteArrayOutputStream jsonBytes = new ByteArrayOutputStream(20000);

            private void finish(BluetoothGatt g, String why) {
                if (done) return;
                done = true;
                host.line("BLE DESC V11 close: " + why);
                try { g.disconnect(); } catch (Throwable ignored) {}
                try { g.close(); } catch (Throwable ignored) {}
            }

            private boolean writeNoResponse(BluetoothGatt g, byte[] data, String tag) {
                try {
                    boolean started;
                    if (Build.VERSION.SDK_INT >= 33) {
                        started = g.writeCharacteristic(tx, data, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE)
                                == android.bluetooth.BluetoothStatusCodes.SUCCESS;
                    } else {
                        //noinspection deprecation
                        tx.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE);
                        //noinspection deprecation
                        tx.setValue(data);
                        //noinspection deprecation
                        started = g.writeCharacteristic(tx);
                    }
                    host.line("BLE DESC V11 " + tag + " write started=" + started + " len=" + data.length
                            + " hex=" + UsbProbe.hex(data, 0, data.length, 128));
                    return started;
                } catch (Throwable t) {
                    host.line("BLE DESC V11 " + tag + " write error: " + t.getClass().getSimpleName() + ": " + safeMsg(t));
                    return false;
                }
            }

            @Override public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
                host.line("BLE DESC V11 state status=" + status + " newState=" + newState);
                if (status == BluetoothGatt.GATT_SUCCESS && newState == android.bluetooth.BluetoothProfile.STATE_CONNECTED) {
                    try {
                        boolean started = g.discoverServices();
                        host.line("BLE DESC V11 discoverServices started=" + started);
                        if (!started) finish(g, "discover did not start");
                    } catch (Throwable t) {
                        finish(g, "discover error: " + t.getClass().getSimpleName());
                    }
                } else if (newState == android.bluetooth.BluetoothProfile.STATE_DISCONNECTED) {
                    finish(g, "disconnected");
                }
            }

            @Override public void onServicesDiscovered(BluetoothGatt g, int status) {
                if (status != BluetoothGatt.GATT_SUCCESS) { finish(g, "service status=" + status); return; }
                BluetoothGattService svc = g.getService(KNOWN_OKN_SERVICE);
                tx = svc == null ? null : svc.getCharacteristic(KNOWN_OKN_TX);
                BluetoothGattCharacteristic rx = svc == null ? null : svc.getCharacteristic(KNOWN_OKN_RX);
                if (tx == null || rx == null) { finish(g, "AB01/AB02 missing"); return; }
                try {
                    boolean local = g.setCharacteristicNotification(rx, true);
                    BluetoothGattDescriptor cccd = rx.getDescriptor(CCCD);
                    host.line("BLE DESC V11 notifyLocal=" + local + " cccd=" + (cccd != null));
                    if (!local || cccd == null) { finish(g, "cannot enable AB02 notify"); return; }
                    boolean started;
                    if (Build.VERSION.SDK_INT >= 33) {
                        started = g.writeDescriptor(cccd, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)
                                == android.bluetooth.BluetoothStatusCodes.SUCCESS;
                    } else {
                        //noinspection deprecation
                        cccd.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                        //noinspection deprecation
                        started = g.writeDescriptor(cccd);
                    }
                    host.line("BLE DESC V11 CCCD write started=" + started);
                    if (!started) finish(g, "CCCD write did not start");
                } catch (Throwable t) {
                    finish(g, "notify error: " + t.getClass().getSimpleName());
                }
            }

            @Override public void onDescriptorWrite(BluetoothGatt g, BluetoothGattDescriptor descriptor, int status) {
                if (done || descriptor == null || !CCCD.equals(descriptor.getUuid())) return;
                host.line("BLE DESC V11 CCCD status=" + status);
                if (status != BluetoothGatt.GATT_SUCCESS || tx == null) { finish(g, "CCCD failed"); return; }
                authSent = writeNoResponse(g, AUTH16, "AUTH16");
                if (!authSent) { finish(g, "AUTH16 write did not start"); return; }
                main.postDelayed(() -> finish(g, "12s timeout waiting auth/descriptor"), 12000L);
            }

            @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic characteristic, byte[] value) {
                handleRx(g, characteristic, value);
            }

            @SuppressWarnings("deprecation")
            @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic characteristic) {
                if (Build.VERSION.SDK_INT >= 33) return;
                handleRx(g, characteristic, characteristic == null ? null : characteristic.getValue());
            }

            private void handleRx(BluetoothGatt g, BluetoothGattCharacteristic characteristic, byte[] value) {
                if (done || characteristic == null || !KNOWN_OKN_RX.equals(characteristic.getUuid())) return;
                byte[] v = value == null ? new byte[0] : value.clone();
                if (!descriptorSent) {
                    if (!authSent || v.length != 32) {
                        host.line("BLE DESC V11 pre-session RX ignored len=" + v.length);
                        return;
                    }
                    host.line("BLE DESC V11 AUTH32 RX len=32 hex=" + UsbProbe.hex(v, 0, v.length, 256));
                    try {
                        AuthDecoded a = decodeAuth(v);
                        host.line("BLE DESC V11 auth typeId=" + a.typeId + " versionId=" + a.versionId
                                + " uniqueId=" + bytesHex(a.uniqueId) + " randKey=" + bytesHex(a.randKey));
                        txCipher = sessionCipher(a.randKey, true);
                        rxCipher = sessionCipher(a.randKey, false);
                        byte[] enc = txCipher.update(DEVICE_DESCRIPTION_REQUEST);
                        if (enc == null || enc.length != DEVICE_DESCRIPTION_REQUEST.length) {
                            finish(g, "descriptor encrypt failed"); return;
                        }
                        host.line("BLE DESC V11 descriptor plaintext=66 1C 06 24 ciphertext=" + UsbProbe.hex(enc, 0, enc.length, 64));
                        descriptorSent = writeNoResponse(g, enc, "DESC_REQ");
                        if (!descriptorSent) finish(g, "descriptor request write did not start");
                    } catch (Throwable t) {
                        host.line("BLE DESC V11 auth/session error: " + t.getClass().getSimpleName() + ": " + safeMsg(t));
                        finish(g, "auth/session setup failed");
                    }
                    return;
                }

                try {
                    byte[] plain = rxCipher == null ? null : rxCipher.update(v);
                    if (plain == null || plain.length == 0) return;
                    chunks++;
                    if (expected < 0) {
                        if (plain.length < 4 || (plain[0] & 0xff) != 0x86) {
                            host.line("BLE DESC V11 first decrypted packet unexpected len=" + plain.length
                                    + " hex=" + UsbProbe.hex(plain, 0, plain.length, 128));
                            return;
                        }
                        expected = (plain[1] & 0xff) | ((plain[2] & 0xff) << 8) | ((plain[3] & 0xff) << 16);
                        host.line("BLE DESC V11 descriptor announced length=" + expected + " firstChunkPlain="
                                + UsbProbe.hex(plain, 0, Math.min(plain.length, 32), 128));
                        if (expected <= 0 || expected > 1024 * 1024) { finish(g, "invalid descriptor length=" + expected); return; }
                        jsonBytes.reset();
                        jsonBytes.write(plain, 4, plain.length - 4);
                    } else {
                        if ((plain[0] & 0xff) != 0x82) {
                            host.line("BLE DESC V11 continuation unexpected marker=0x" + Integer.toHexString(plain[0] & 0xff));
                            return;
                        }
                        jsonBytes.write(plain, 1, plain.length - 1);
                    }

                    if (expected > 0 && jsonBytes.size() >= expected) {
                        byte[] all = jsonBytes.toByteArray();
                        byte[] json = new byte[expected];
                        System.arraycopy(all, 0, json, 0, expected);
                        host.line("BLE DESC V11 COMPLETE bytes=" + json.length + " chunks=" + chunks + " sha256=" + sha256(json));
                        host.line(descriptorSummary(json).replace("BLE DESC V9 SUMMARY", "BLE DESC V11 SUMMARY"));
                        logDescriptorMap(json);
                        host.onDescriptorJson(json);
                        finish(g, "Device Description captured/export-ready; no DSP write sent");
                    }
                } catch (Throwable t) {
                    host.line("BLE DESC V11 RX/decrypt error: " + t.getClass().getSimpleName() + ": " + safeMsg(t));
                    finish(g, "RX/decrypt error");
                }
            }
        };

        try {
            BluetoothGatt g = d.connectGatt(context, false, cb, BluetoothDevice.TRANSPORT_LE);
            if (g == null) host.line("BLE DESC V11 connectGatt returned null");
        } catch (Throwable t) {
            host.line("BLE DESC V11 connect error: " + t.getClass().getSimpleName() + ": " + safeMsg(t));
        }
    }

    void probeGatt(BluetoothDevice d) {
        if (d == null || !hasPermissions()) return;
        String name = safeName(d);
        host.line("GATT CONNECT read-only: " + name + " [" + safeAddr(d) + "]");
        try {
            BluetoothGatt g = d.connectGatt(context, false, gattCallback, BluetoothDevice.TRANSPORT_LE);
            if (g != null) {
                synchronized (gatts) { gatts.add(g); }
                main.postDelayed(() -> timeoutGatt(g), 15_000L);
            }
        } catch (Throwable t) {
            host.line("GATT connect error: " + t.getClass().getSimpleName() + ": " + safeMsg(t));
        }
    }

    void close() {
        stopBleScan();
        stopClassicScan();
        synchronized (gatts) {
            for (BluetoothGatt g : gatts) {
                try { g.disconnect(); } catch (Throwable ignored) {}
                try { g.close(); } catch (Throwable ignored) {}
            }
            gatts.clear();
        }
        if (receiverRegistered) {
            try { context.unregisterReceiver(classicReceiver); } catch (Throwable ignored) {}
            receiverRegistered = false;
        }
    }

    private void registerClassicReceiver() {
        try {
            IntentFilter f = new IntentFilter();
            f.addAction(BluetoothDevice.ACTION_FOUND);
            f.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
            f.addAction(BluetoothDevice.ACTION_UUID);
            if (Build.VERSION.SDK_INT >= 33) context.registerReceiver(classicReceiver, f, Context.RECEIVER_EXPORTED);
            else context.registerReceiver(classicReceiver, f);
            receiverRegistered = true;
        } catch (Throwable t) {
            host.line("CLASSIC receiver registration failed: " + t.getClass().getSimpleName() + ": " + safeMsg(t));
        }
    }

    private void dumpBondedDevices() {
        try {
            Set<BluetoothDevice> bonded = adapter.getBondedDevices();
            host.line("CLASSIC bonded devices=" + bonded.size());
            for (BluetoothDevice d : bonded) {
                ParcelUuid[] uuids = d.getUuids();
                host.line("  BONDED name=" + safeName(d) + " addr=" + safeAddr(d)
                        + " type=" + typeName(safeType(d)) + " uuids=" + uuidsText(uuids));
                host.onClassicCandidate(d, 0, "bonded=true");
            }
        } catch (Throwable t) {
            host.line("CLASSIC bonded list error: " + t.getClass().getSimpleName() + ": " + safeMsg(t));
        }
    }

    private final BroadcastReceiver classicReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            String action = i.getAction();
            if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
                scanningClassic = false;
                host.line("CLASSIC DISCOVERY finished");
                return;
            }
            BluetoothDevice d = getBtExtra(i);
            if (d == null) return;
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                int rssi = i.getShortExtra(BluetoothDevice.EXTRA_RSSI, Short.MIN_VALUE);
                String addr = safeAddr(d);
                if (!seenClassic.add(addr)) return;
                String detail = "type=" + typeName(safeType(d)) + " bond=" + bondName(safeBond(d))
                        + " class=" + classText(d) + " cachedUuids=" + uuidsText(safeUuids(d));
                host.line("CLASSIC FOUND name=" + safeName(d) + " addr=" + addr + " rssi=" + rssi + " " + detail);
                host.onClassicCandidate(d, rssi, detail);
            } else if (BluetoothDevice.ACTION_UUID.equals(action)) {
                ParcelUuid[] uuids = getUuidExtra(i);
                host.line("SDP RESULT name=" + safeName(d) + " addr=" + safeAddr(d)
                        + " uuids=" + uuidsText(uuids));
                boolean hasSpp = false;
                if (uuids != null) {
                    for (ParcelUuid pu : uuids) {
                        if (pu == null) continue;
                        UUID u = pu.getUuid();
                        if (UUID_SPP.equals(u)) hasSpp = true;
                        String label = uuidLabel(u);
                        if (!label.isEmpty()) host.line("  SDP PROFILE " + u + " = " + label);
                    }
                }
                if (hasSpp) {
                    host.line("  SDP V7: SPP advertised; adding manual passive-connect button. No SPP data is sent automatically.");
                    host.onSppCandidate(d);
                }
            }
        }
    };

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult r) {
            BluetoothDevice d = r.getDevice();
            if (d == null) return;
            String addr = safeAddr(d);
            if (!seenBle.add(addr)) return;
            ScanRecord rec = r.getScanRecord();
            StringBuilder detail = new StringBuilder();
            detail.append(" type=").append(typeName(safeType(d)));
            if (rec != null) {
                List<ParcelUuid> uuids = rec.getServiceUuids();
                if (uuids != null && !uuids.isEmpty()) detail.append(" advServices=").append(uuids);
                SparseArray<byte[]> m = rec.getManufacturerSpecificData();
                if (m != null && m.size() > 0) {
                    detail.append(" mfg=");
                    for (int i = 0; i < m.size(); i++) {
                        if (i > 0) detail.append(';');
                        detail.append(String.format(Locale.US, "%04X:", m.keyAt(i)))
                                .append(UsbProbe.hex(m.valueAt(i), 0, m.valueAt(i).length, 48));
                    }
                }
                byte[] all = rec.getBytes();
                if (all != null) detail.append(" advRaw=").append(UsbProbe.hex(all, 0, all.length, 128));
            }
            String n = safeName(d);
            host.line("BLE FOUND name=" + n + " addr=" + addr + " rssi=" + r.getRssi() + detail);
            host.onBleCandidate(d, r.getRssi(), detail.toString());
        }

        @Override public void onScanFailed(int errorCode) {
            scanningBle = false;
            host.line("BLE SCAN failed code=" + errorCode);
        }
    };

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
            host.line("GATT state status=" + status + " newState=" + newState
                    + " device=" + safeName(g.getDevice()));
            if (status == BluetoothGatt.GATT_SUCCESS && newState == android.bluetooth.BluetoothProfile.STATE_CONNECTED) {
                try {
                    boolean started = g.discoverServices();
                    host.line("GATT discoverServices started=" + started);
                } catch (Throwable t) {
                    finishGatt(g, "discover error " + t.getClass().getSimpleName());
                }
            } else if (newState == android.bluetooth.BluetoothProfile.STATE_DISCONNECTED) {
                finishGatt(g, "disconnected");
            }
        }

        @Override public void onServicesDiscovered(BluetoothGatt g, int status) {
            host.line("GATT SERVICES status=" + status + " device=" + safeName(g.getDevice()));
            if (status == BluetoothGatt.GATT_SUCCESS) {
                boolean known = false;
                for (BluetoothGattService s : g.getServices()) {
                    if (KNOWN_OKN_SERVICE.equals(s.getUuid())) known = true;
                    host.line("  SERVICE " + s.getUuid() + " type=" + serviceType(s.getType()));
                    for (BluetoothGattCharacteristic c : s.getCharacteristics()) {
                        boolean knownChar = KNOWN_OKN_TX.equals(c.getUuid()) || KNOWN_OKN_RX.equals(c.getUuid());
                        host.line("    CHAR " + c.getUuid() + " props=" + properties(c.getProperties())
                                + (knownChar ? "  <KNOWN OKN>" : ""));
                        for (BluetoothGattDescriptor d : c.getDescriptors()) {
                            host.line("      DESC " + d.getUuid());
                        }
                    }
                }
                if (known) {
                    host.line("*** FOUND known OKN control service AB00 / AB01 / AB02 ***");
                    host.onBleAuthCandidate(g.getDevice());
                }

                BluetoothGattService okn = g.getService(KNOWN_OKN_SERVICE);
                BluetoothGattCharacteristic tx = okn == null ? null : okn.getCharacteristic(KNOWN_OKN_TX);
                if (tx != null && (tx.getProperties() & BluetoothGattCharacteristic.PROPERTY_READ) != 0) {
                    try {
                        boolean started = g.readCharacteristic(tx);
                        host.line("GATT V6 READ-ONLY: AB01 read started=" + started);
                        if (started) return;
                    } catch (Throwable t) {
                        host.line("GATT V6 AB01 read error: " + t.getClass().getSimpleName() + ": " + safeMsg(t));
                    }
                }
                host.line("GATT enumeration complete. No characteristic write was performed.");
            }
            finishGatt(g, "services complete");
        }

        @Override public void onCharacteristicRead(BluetoothGatt g, BluetoothGattCharacteristic c, int status) {
            byte[] value = c == null ? null : c.getValue();
            logCharacteristicRead(g, c, value, status);
        }

        @Override public void onCharacteristicRead(BluetoothGatt g, BluetoothGattCharacteristic c,
                                                    byte[] value, int status) {
            logCharacteristicRead(g, c, value, status);
        }
    };

    private void logCharacteristicRead(BluetoothGatt g, BluetoothGattCharacteristic c,
                                       byte[] value, int status) {
        UUID uuid = c == null ? null : c.getUuid();
        host.line("GATT CHAR READ status=" + status + " uuid=" + uuid
                + " len=" + (value == null ? 0 : value.length)
                + (value != null && value.length > 0
                ? " hex=" + UsbProbe.hex(value, 0, value.length, 512) : ""));
        finishGatt(g, "read complete");
    }

    private void timeoutGatt(BluetoothGatt g) {
        synchronized (gatts) {
            if (!gatts.contains(g)) return;
        }
        finishGatt(g, "15s timeout");
    }

    private void finishGatt(BluetoothGatt g, String why) {
        boolean doClose;
        synchronized (gatts) { doClose = gatts.remove(g); }
        if (!doClose) return;
        host.line("GATT close: " + why);
        try { g.disconnect(); } catch (Throwable ignored) {}
        try { g.close(); } catch (Throwable ignored) {}
    }

    @SuppressWarnings("deprecation")
    private BluetoothDevice getBtExtra(Intent i) {
        try {
            if (Build.VERSION.SDK_INT >= 33) return i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice.class);
            return i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
        } catch (Throwable t) { return null; }
    }

    @SuppressWarnings("deprecation")
    private ParcelUuid[] getUuidExtra(Intent i) {
        try {
            Parcelable[] p;
            if (Build.VERSION.SDK_INT >= 33) p = i.getParcelableArrayExtra(BluetoothDevice.EXTRA_UUID, ParcelUuid.class);
            else p = i.getParcelableArrayExtra(BluetoothDevice.EXTRA_UUID);
            if (p == null) return null;
            ParcelUuid[] out = new ParcelUuid[p.length];
            for (int x = 0; x < p.length; x++) out[x] = (ParcelUuid) p[x];
            return out;
        } catch (Throwable t) { return null; }
    }

    private static final class AuthDecoded {
        final int typeId;
        final int versionId;
        final byte[] uniqueId;
        final byte[] randKey;
        AuthDecoded(int typeId, int versionId, byte[] uniqueId, byte[] randKey) {
            this.typeId = typeId; this.versionId = versionId; this.uniqueId = uniqueId; this.randKey = randKey;
        }
    }

    private static AuthDecoded decodeAuth(byte[] response32) throws Exception {
        if (response32 == null || response32.length != 32) throw new IllegalArgumentException("auth response must be 32 bytes");
        int typeId = ((response32[0] & 0xff) << 8) | (response32[1] & 0xff);
        int versionId = ((response32[2] & 0xff) << 8) | (response32[3] & 0xff);
        byte[] key = typeId == 53285 ? TYPE_53285_PREAUTH_KEY : DEFAULT_PREAUTH_KEY;
        Cipher c = Cipher.getInstance("AES/CFB8/NoPadding");
        c.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"), new IvParameterSpec(SESSION_IV));
        byte[] enc = new byte[24];
        System.arraycopy(response32, 8, enc, 0, 24);
        byte[] plain = c.update(enc);
        if (plain == null || plain.length != 24) throw new IllegalStateException("pre-auth decrypt length");
        byte[] unique = new byte[8];
        byte[] rand = new byte[16];
        System.arraycopy(plain, 0, unique, 0, 8);
        System.arraycopy(plain, 8, rand, 0, 16);
        return new AuthDecoded(typeId, versionId, unique, rand);
    }

    private static Cipher sessionCipher(byte[] randKey, boolean encrypt) throws Exception {
        Cipher c = Cipher.getInstance("AES/CFB8/NoPadding");
        c.init(encrypt ? Cipher.ENCRYPT_MODE : Cipher.DECRYPT_MODE,
                new SecretKeySpec(randKey.clone(), "AES"), new IvParameterSpec(SESSION_IV));
        return c;
    }

    private static byte[] repeatByte(byte v, int n) {
        byte[] b = new byte[n];
        for (int i = 0; i < n; i++) b[i] = v;
        return b;
    }

    private static String bytesHex(byte[] b) {
        return b == null ? "" : UsbProbe.hex(b, 0, b.length, Math.max(64, b.length * 3));
    }

    private static String sha256(byte[] b) {
        try {
            byte[] d = MessageDigest.getInstance("SHA-256").digest(b);
            StringBuilder sb = new StringBuilder(64);
            for (byte x : d) sb.append(String.format(Locale.US, "%02x", x & 0xff));
            return sb.toString();
        } catch (Throwable t) { return "<sha256-error>"; }
    }

    private void logDescriptorMap(byte[] json) {
        try {
            JSONObject root = new JSONObject(new String(json, StandardCharsets.UTF_8));
            host.line("BLE MAP V11 ROOT " + primitiveSummary(root, "actuators", "sensors"));
            JSONArray acts = root.optJSONArray("actuators");
            if (acts != null) {
                for (int i = 0; i < acts.length(); i++) {
                    JSONObject a = acts.optJSONObject(i);
                    if (a == null) continue;
                    JSONArray eq = a.optJSONArray("UFE_TYPE_BIQUAD_CASCADE15_F");
                    String extra = eq == null ? "" : " eqBands=" + eq.length();
                    host.line("BLE MAP V11 ACT[" + i + "] "
                            + primitiveSummary(a, "UFE_TYPE_BIQUAD_CASCADE15_F") + extra);
                }
            }
            JSONArray sensors = root.optJSONArray("sensors");
            if (sensors != null) {
                for (int i = 0; i < sensors.length(); i++) {
                    JSONObject x = sensors.optJSONObject(i);
                    if (x == null) continue;
                    host.line("BLE MAP V11 SENSOR[" + i + "] " + primitiveSummary(x));
                }
            }
        } catch (Throwable t) {
            host.line("BLE MAP V11 parse error: " + t.getClass().getSimpleName() + ": " + safeMsg(t));
        }
    }

    private static String primitiveSummary(JSONObject o, String... skipKeys) {
        if (o == null) return "{}";
        Set<String> skip = new HashSet<>();
        if (skipKeys != null) for (String k : skipKeys) skip.add(k);
        StringBuilder sb = new StringBuilder();
        Iterator<String> it = o.keys();
        while (it.hasNext()) {
            String k = it.next();
            if (skip.contains(k)) continue;
            Object v = o.opt(k);
            if (v == null || v == JSONObject.NULL || v instanceof JSONObject || v instanceof JSONArray) continue;
            if (sb.length() > 0) sb.append(' ');
            String text = String.valueOf(v).replace('\n', ' ').replace('\r', ' ');
            if (text.length() > 120) text = text.substring(0, 120) + "...";
            sb.append(k).append('=').append(text);
        }
        return sb.length() == 0 ? "<no-primitive-fields>" : sb.toString();
    }

    private static String descriptorSummary(byte[] json) {
        try {
            JSONObject root = new JSONObject(new String(json, StandardCharsets.UTF_8));
            JSONArray acts = root.optJSONArray("actuators");
            JSONArray sensors = root.optJSONArray("sensors");
            int actuatorCount = acts == null ? 0 : acts.length();
            int sensorCount = sensors == null ? 0 : sensors.length();
            StringBuilder scalars = new StringBuilder();
            int[] scalarIds = {2, 3, 8, 9, 10, 13, 11};
            int[] eqIds = {4, 5, 6, 14, 15, 16, 17};
            int[] eqCounts = new int[7];
            String[] eqFirst = new String[7];
            if (acts != null) {
                for (int i = 0; i < acts.length(); i++) {
                    JSONObject a = acts.optJSONObject(i);
                    if (a == null) continue;
                    int id = a.optInt("ID", -1);
                    int type = a.optInt("type", -1);
                    for (int sid : scalarIds) if (id == sid && a.has("UFE_TYPE_FLOAT32")) {
                        if (scalars.length() > 0) scalars.append(' ');
                        scalars.append("ID").append(id).append('=').append(a.optDouble("UFE_TYPE_FLOAT32", Double.NaN));
                    }
                    for (int c = 0; c < eqIds.length; c++) if (id == eqIds[c]) {
                        JSONArray arr = a.optJSONArray("UFE_TYPE_BIQUAD_CASCADE15_F");
                        eqCounts[c] = arr == null ? 0 : arr.length();
                        if (arr != null && arr.length() > 0) {
                            JSONObject b = arr.optJSONObject(0);
                            if (b != null) eqFirst[c] = "typ=" + b.optInt("typ", -1)
                                    + ",F=" + b.optDouble("F", Double.NaN)
                                    + ",Q=" + b.optDouble("Q", Double.NaN)
                                    + ",B=" + b.optDouble("B", Double.NaN)
                                    + ",G=" + b.optDouble("G", Double.NaN)
                                    + ",R=" + b.optDouble("R", Double.NaN);
                        }
                    }
                }
            }
            StringBuilder eq = new StringBuilder();
            for (int c = 0; c < 7; c++) {
                if (c > 0) eq.append(" | ");
                eq.append("CH").append(c + 1).append("/ID").append(eqIds[c]).append('=').append(eqCounts[c]);
                if (eqFirst[c] != null) eq.append(" [B1 ").append(eqFirst[c]).append(']');
            }
            return "BLE DESC V11 SUMMARY actuators=" + actuatorCount + " sensors=" + sensorCount
                    + " scalars={" + scalars + "} EQ={" + eq + "}";
        } catch (Throwable t) {
            String txt = new String(json, StandardCharsets.UTF_8);
            String head = txt.substring(0, Math.min(300, txt.length())).replace('\n', ' ').replace('\r', ' ');
            return "BLE DESC V11 JSON parse failed: " + t.getClass().getSimpleName() + " head=" + head;
        }
    }

    private static String decodeAuthSummary(byte[] response32) {
        try {
            AuthDecoded a = decodeAuth(response32);
            return "BLE AUTH decoded typeId=" + a.typeId + " versionId=" + a.versionId
                    + " uniqueId=" + bytesHex(a.uniqueId) + " randKey=" + bytesHex(a.randKey);
        } catch (Throwable t) {
            return "BLE AUTH decode error: " + t.getClass().getSimpleName() + ": " + safeMsg(t);
        }
    }

    private static byte[] hexBytes(String s) {
        String x = s.replaceAll("[^0-9A-Fa-f]", "");
        byte[] out = new byte[x.length() / 2];
        for (int i = 0; i < out.length; i++) out[i] = (byte) Integer.parseInt(x.substring(i * 2, i * 2 + 2), 16);
        return out;
    }

    private static ParcelUuid[] safeUuids(BluetoothDevice d) {
        try { return d.getUuids(); } catch (Throwable t) { return null; }
    }
    private static int safeType(BluetoothDevice d) {
        try { return d.getType(); } catch (Throwable t) { return BluetoothDevice.DEVICE_TYPE_UNKNOWN; }
    }
    private static int safeBond(BluetoothDevice d) {
        try { return d.getBondState(); } catch (Throwable t) { return BluetoothDevice.BOND_NONE; }
    }
    private static String classText(BluetoothDevice d) {
        try { return d.getBluetoothClass() == null ? "?" : d.getBluetoothClass().toString(); }
        catch (Throwable t) { return "?"; }
    }

    private static String typeName(int t) {
        switch (t) {
            case BluetoothDevice.DEVICE_TYPE_CLASSIC: return "CLASSIC";
            case BluetoothDevice.DEVICE_TYPE_LE: return "LE";
            case BluetoothDevice.DEVICE_TYPE_DUAL: return "DUAL";
            default: return "UNKNOWN";
        }
    }
    private static String bondName(int b) {
        switch (b) {
            case BluetoothDevice.BOND_BONDED: return "BONDED";
            case BluetoothDevice.BOND_BONDING: return "BONDING";
            default: return "NONE";
        }
    }
    private static String uuidsText(ParcelUuid[] uuids) {
        if (uuids == null) return "<none/cached-empty>";
        if (uuids.length == 0) return "[]";
        StringBuilder s = new StringBuilder("[");
        for (int i = 0; i < uuids.length; i++) {
            if (i > 0) s.append(", ");
            s.append(uuids[i]);
        }
        return s.append(']').toString();
    }
    private static String uuidLabel(UUID u) {
        if (UUID_SPP.equals(u)) return "Serial Port Profile (SPP)";
        if (UUID_OBEX_OBJECT_PUSH.equals(u)) return "OBEX Object Push";
        if (UUID_OBEX_FILE_TRANSFER.equals(u)) return "OBEX File Transfer";
        String x = u.toString().toLowerCase(Locale.US);
        if (x.startsWith("0000110b-")) return "A2DP Audio Sink";
        if (x.startsWith("0000110e-") || x.startsWith("0000110c-")) return "AVRCP";
        return "";
    }

    private static String properties(int p) {
        List<String> a = new ArrayList<>();
        if ((p & BluetoothGattCharacteristic.PROPERTY_BROADCAST) != 0) a.add("BROADCAST");
        if ((p & BluetoothGattCharacteristic.PROPERTY_READ) != 0) a.add("READ");
        if ((p & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0) a.add("WRITE_NR");
        if ((p & BluetoothGattCharacteristic.PROPERTY_WRITE) != 0) a.add("WRITE");
        if ((p & BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0) a.add("NOTIFY");
        if ((p & BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) a.add("INDICATE");
        if ((p & BluetoothGattCharacteristic.PROPERTY_SIGNED_WRITE) != 0) a.add("SIGNED_WRITE");
        if ((p & BluetoothGattCharacteristic.PROPERTY_EXTENDED_PROPS) != 0) a.add("EXTENDED");
        return a.isEmpty() ? "NONE" : String.join("|", a);
    }

    private static String serviceType(int t) {
        return t == BluetoothGattService.SERVICE_TYPE_PRIMARY ? "PRIMARY" : "SECONDARY";
    }

    static String safeName(BluetoothDevice d) {
        try { String n = d.getName(); return n == null ? "<unnamed>" : n; }
        catch (Throwable t) { return "<permission>"; }
    }
    static String safeAddr(BluetoothDevice d) {
        try { return d.getAddress(); } catch (Throwable t) { return "<permission>"; }
    }
    private static String safeMsg(Throwable t) {
        String m = t.getMessage(); return m == null ? "" : m;
    }
}
