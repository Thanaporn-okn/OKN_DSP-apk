package com.okn.dsp.probe;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothSocket;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;
import android.os.Parcelable;
import android.util.SparseArray;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

final class BluetoothProbe {
    interface Host {
        void line(String s);
        void onBleCandidate(BluetoothDevice d, int rssi, String detail);
        void onClassicCandidate(BluetoothDevice d, int rssi, String detail);
        void onSppCandidate(BluetoothDevice d);
    }

    static final UUID KNOWN_OKN_SERVICE = UUID.fromString("0000ab00-0000-1000-8000-00805f9b34fb");
    static final UUID KNOWN_OKN_TX = UUID.fromString("0000ab01-0000-1000-8000-00805f9b34fb");
    static final UUID KNOWN_OKN_RX = UUID.fromString("0000ab02-0000-1000-8000-00805f9b34fb");

    private static final UUID UUID_SPP = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");
    private static final UUID UUID_OBEX_OBJECT_PUSH = UUID.fromString("00001105-0000-1000-8000-00805f9b34fb");
    private static final UUID UUID_OBEX_FILE_TRANSFER = UUID.fromString("00001106-0000-1000-8000-00805f9b34fb");

    private final Context context;
    private final Host host;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final BluetoothAdapter adapter;
    private BluetoothLeScanner scanner;
    private final Set<String> seenBle = new HashSet<>();
    private final Set<String> seenClassic = new HashSet<>();
    private final List<BluetoothGatt> gatts = new ArrayList<>();
    private boolean scanningBle;
    private boolean scanningClassic;
    private boolean receiverRegistered;

    BluetoothProbe(Context context, Host host) {
        this.context = context.getApplicationContext();
        this.host = host;
        BluetoothAdapter a = null;
        try {
            BluetoothManager m = (BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE);
            a = m == null ? null : m.getAdapter();
        } catch (Throwable ignored) {}
        adapter = a;
        registerClassicReceiver();
    }

    boolean hasPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            return context.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                    && context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    void startBleScan() {
        if (!hasPermissions()) { host.line("BLE: permission missing"); return; }
        if (adapter == null) { host.line("BLE: adapter unavailable"); return; }
        try {
            if (!adapter.isEnabled()) { host.line("BLE: Bluetooth is OFF"); return; }
            stopClassicScan();
            scanner = adapter.getBluetoothLeScanner();
            if (scanner == null) { host.line("BLE: scanner unavailable"); return; }
            stopBleScan();
            seenBle.clear();
            scanningBle = true;
            host.line("BLE SCAN started for 12 seconds. Tap a discovered device to enumerate GATT services.");
            scanner.startScan(scanCallback);
            main.postDelayed(this::stopBleScan, 12_000L);
        } catch (SecurityException e) {
            host.line("BLE: permission rejected by Android");
        } catch (Throwable t) {
            host.line("BLE start error: " + t.getClass().getSimpleName() + ": " + safeMsg(t));
        }
    }

    void stopBleScan() {
        if (!scanningBle) return;
        scanningBle = false;
        try {
            if (scanner != null && hasPermissions()) scanner.stopScan(scanCallback);
        } catch (Throwable ignored) {}
        host.line("BLE SCAN stopped");
    }

    void startClassicScan() {
        if (!hasPermissions()) { host.line("CLASSIC: permission missing"); return; }
        if (adapter == null) { host.line("CLASSIC: adapter unavailable"); return; }
        try {
            if (!adapter.isEnabled()) { host.line("CLASSIC: Bluetooth is OFF"); return; }
            stopBleScan();
            if (adapter.isDiscovering()) adapter.cancelDiscovery();
            seenClassic.clear();
            dumpBondedDevices();
            boolean started = adapter.startDiscovery();
            scanningClassic = started;
            host.line("CLASSIC DISCOVERY started=" + started + ". Tap a discovered device to request standard SDP UUIDs. No pairing or OBEX data is sent by the probe.");
            if (started) main.postDelayed(this::stopClassicScan, 18_000L);
        } catch (SecurityException e) {
            host.line("CLASSIC: permission rejected by Android");
        } catch (Throwable t) {
            host.line("CLASSIC start error: " + t.getClass().getSimpleName() + ": " + safeMsg(t));
        }
    }

    void stopClassicScan() {
        if (!scanningClassic) return;
        scanningClassic = false;
        try {
            if (adapter != null && adapter.isDiscovering() && hasPermissions()) adapter.cancelDiscovery();
        } catch (Throwable ignored) {}
        host.line("CLASSIC DISCOVERY stopped");
    }

    void probeSdp(BluetoothDevice d) {
        if (d == null || !hasPermissions()) return;
        try {
            ParcelUuid[] cached = d.getUuids();
            host.line("SDP PROBE request name=" + safeName(d) + " addr=" + safeAddr(d)
                    + " type=" + typeName(safeType(d)) + " bond=" + bondName(safeBond(d))
                    + " cachedUuids=" + uuidsText(cached));
            boolean started = d.fetchUuidsWithSdp();
            host.line("SDP fetchUuidsWithSdp started=" + started + ". This performs Bluetooth service discovery only; it does not connect to an OBEX service or send a firmware file.");
        } catch (SecurityException e) {
            host.line("SDP: permission rejected by Android");
        } catch (Throwable t) {
            host.line("SDP start error: " + t.getClass().getSimpleName() + ": " + safeMsg(t));
        }
    }

    void probeSppPassive(BluetoothDevice d) {
        if (d == null || !hasPermissions()) return;
        final String name = safeName(d);
        final String addr = safeAddr(d);
        host.line("SPP V7 PASSIVE request name=" + name + " addr=" + addr
                + " bond=" + bondName(safeBond(d)) + " uuid=" + UUID_SPP);
        host.line("SPP V7 SAFETY: connect + passive RX for 3000 ms only; OutputStream is never opened and ZERO bytes are transmitted by the app. Android may request pairing if the device requires authentication.");
        new Thread(() -> {
            BluetoothSocket socket = null;
            try {
                try {
                    if (adapter != null && adapter.isDiscovering()) adapter.cancelDiscovery();
                } catch (Throwable ignored) {}
                socket = d.createRfcommSocketToServiceRecord(UUID_SPP);
                host.line("SPP V7 CONNECT starting");
                socket.connect();
                host.line("SPP V7 CONNECTED remote=" + name + " addr=" + addr);

                InputStream in = socket.getInputStream();
                byte[] buf = new byte[512];
                int total = 0;
                long end = System.currentTimeMillis() + 3000L;
                while (System.currentTimeMillis() < end) {
                    int available = 0;
                    try { available = in.available(); } catch (Throwable ignored) {}
                    if (available > 0) {
                        int want = Math.min(buf.length, available);
                        int n = in.read(buf, 0, want);
                        if (n > 0) {
                            total += n;
                            host.line("SPP V7 PASSIVE RX len=" + n + " hex="
                                    + UsbProbe.hex(buf, 0, n, 1024));
                        }
                    }
                    try { Thread.sleep(50L); } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                }
                host.line("SPP V7 PASSIVE complete totalRx=" + total + " bytes; tx=0 bytes");
            } catch (SecurityException e) {
                host.line("SPP V7 permission rejected by Android");
            } catch (Throwable t) {
                host.line("SPP V7 CONNECT/READ error: " + t.getClass().getSimpleName() + ": " + safeMsg(t));
            } finally {
                if (socket != null) {
                    try { socket.close(); } catch (Throwable ignored) {}
                }
                host.line("SPP V7 socket closed; tx=0 bytes");
            }
        }, "OKN-SPP-Passive").start();
    }

    void probeGatt(BluetoothDevice d) {
        if (d == null || !hasPermissions()) return;
        String name = safeName(d);
        host.line("GATT CONNECT read-only: " + name + " [" + safeAddr(d) + "]");
        try {
            BluetoothGatt g = d.connectGatt(context, false, gattCallback, BluetoothDevice.TRANSPORT_LE);
            if (g != null) {
                synchronized (gatts) { gatts.add(g); }
                main.postDelayed(() -> timeoutGatt(g), 15_000L);
            }
        } catch (Throwable t) {
            host.line("GATT connect error: " + t.getClass().getSimpleName() + ": " + safeMsg(t));
        }
    }

    void close() {
        stopBleScan();
        stopClassicScan();
        synchronized (gatts) {
            for (BluetoothGatt g : gatts) {
                try { g.disconnect(); } catch (Throwable ignored) {}
                try { g.close(); } catch (Throwable ignored) {}
            }
            gatts.clear();
        }
        if (receiverRegistered) {
            try { context.unregisterReceiver(classicReceiver); } catch (Throwable ignored) {}
            receiverRegistered = false;
        }
    }

    private void registerClassicReceiver() {
        try {
            IntentFilter f = new IntentFilter();
            f.addAction(BluetoothDevice.ACTION_FOUND);
            f.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
            f.addAction(BluetoothDevice.ACTION_UUID);
            if (Build.VERSION.SDK_INT >= 33) context.registerReceiver(classicReceiver, f, Context.RECEIVER_EXPORTED);
            else context.registerReceiver(classicReceiver, f);
            receiverRegistered = true;
        } catch (Throwable t) {
            host.line("CLASSIC receiver registration failed: " + t.getClass().getSimpleName() + ": " + safeMsg(t));
        }
    }

    private void dumpBondedDevices() {
        try {
            Set<BluetoothDevice> bonded = adapter.getBondedDevices();
            host.line("CLASSIC bonded devices=" + bonded.size());
            for (BluetoothDevice d : bonded) {
                ParcelUuid[] uuids = d.getUuids();
                host.line("  BONDED name=" + safeName(d) + " addr=" + safeAddr(d)
                        + " type=" + typeName(safeType(d)) + " uuids=" + uuidsText(uuids));
                host.onClassicCandidate(d, 0, "bonded=true");
            }
        } catch (Throwable t) {
            host.line("CLASSIC bonded list error: " + t.getClass().getSimpleName() + ": " + safeMsg(t));
        }
    }

    private final BroadcastReceiver classicReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            String action = i.getAction();
            if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
                scanningClassic = false;
                host.line("CLASSIC DISCOVERY finished");
                return;
            }
            BluetoothDevice d = getBtExtra(i);
            if (d == null) return;
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                int rssi = i.getShortExtra(BluetoothDevice.EXTRA_RSSI, Short.MIN_VALUE);
                String addr = safeAddr(d);
                if (!seenClassic.add(addr)) return;
                String detail = "type=" + typeName(safeType(d)) + " bond=" + bondName(safeBond(d))
                        + " class=" + classText(d) + " cachedUuids=" + uuidsText(safeUuids(d));
                host.line("CLASSIC FOUND name=" + safeName(d) + " addr=" + addr + " rssi=" + rssi + " " + detail);
                host.onClassicCandidate(d, rssi, detail);
            } else if (BluetoothDevice.ACTION_UUID.equals(action)) {
                ParcelUuid[] uuids = getUuidExtra(i);
                host.line("SDP RESULT name=" + safeName(d) + " addr=" + safeAddr(d)
                        + " uuids=" + uuidsText(uuids));
                boolean hasSpp = false;
                if (uuids != null) {
                    for (ParcelUuid pu : uuids) {
                        if (pu == null) continue;
                        UUID u = pu.getUuid();
                        if (UUID_SPP.equals(u)) hasSpp = true;
                        String label = uuidLabel(u);
                        if (!label.isEmpty()) host.line("  SDP PROFILE " + u + " = " + label);
                    }
                }
                if (hasSpp) {
                    host.line("  SDP V7: SPP advertised; adding manual passive-connect button. No SPP data is sent automatically.");
                    host.onSppCandidate(d);
                }
            }
        }
    };

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult r) {
            BluetoothDevice d = r.getDevice();
            if (d == null) return;
            String addr = safeAddr(d);
            if (!seenBle.add(addr)) return;
            ScanRecord rec = r.getScanRecord();
            StringBuilder detail = new StringBuilder();
            detail.append(" type=").append(typeName(safeType(d)));
            if (rec != null) {
                List<ParcelUuid> uuids = rec.getServiceUuids();
                if (uuids != null && !uuids.isEmpty()) detail.append(" advServices=").append(uuids);
                SparseArray<byte[]> m = rec.getManufacturerSpecificData();
                if (m != null && m.size() > 0) {
                    detail.append(" mfg=");
                    for (int i = 0; i < m.size(); i++) {
                        if (i > 0) detail.append(';');
                        detail.append(String.format(Locale.US, "%04X:", m.keyAt(i)))
                                .append(UsbProbe.hex(m.valueAt(i), 0, m.valueAt(i).length, 48));
                    }
                }
                byte[] all = rec.getBytes();
                if (all != null) detail.append(" advRaw=").append(UsbProbe.hex(all, 0, all.length, 128));
            }
            String n = safeName(d);
            host.line("BLE FOUND name=" + n + " addr=" + addr + " rssi=" + r.getRssi() + detail);
            host.onBleCandidate(d, r.getRssi(), detail.toString());
        }

        @Override public void onScanFailed(int errorCode) {
            scanningBle = false;
            host.line("BLE SCAN failed code=" + errorCode);
        }
    };

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
            host.line("GATT state status=" + status + " newState=" + newState
                    + " device=" + safeName(g.getDevice()));
            if (status == BluetoothGatt.GATT_SUCCESS && newState == android.bluetooth.BluetoothProfile.STATE_CONNECTED) {
                try {
                    boolean started = g.discoverServices();
                    host.line("GATT discoverServices started=" + started);
                } catch (Throwable t) {
                    finishGatt(g, "discover error " + t.getClass().getSimpleName());
                }
            } else if (newState == android.bluetooth.BluetoothProfile.STATE_DISCONNECTED) {
                finishGatt(g, "disconnected");
            }
        }

        @Override public void onServicesDiscovered(BluetoothGatt g, int status) {
            host.line("GATT SERVICES status=" + status + " device=" + safeName(g.getDevice()));
            if (status == BluetoothGatt.GATT_SUCCESS) {
                boolean known = false;
                for (BluetoothGattService s : g.getServices()) {
                    if (KNOWN_OKN_SERVICE.equals(s.getUuid())) known = true;
                    host.line("  SERVICE " + s.getUuid() + " type=" + serviceType(s.getType()));
                    for (BluetoothGattCharacteristic c : s.getCharacteristics()) {
                        boolean knownChar = KNOWN_OKN_TX.equals(c.getUuid()) || KNOWN_OKN_RX.equals(c.getUuid());
                        host.line("    CHAR " + c.getUuid() + " props=" + properties(c.getProperties())
                                + (knownChar ? "  <KNOWN OKN>" : ""));
                        for (BluetoothGattDescriptor d : c.getDescriptors()) {
                            host.line("      DESC " + d.getUuid());
                        }
                    }
                }
                if (known) host.line("*** FOUND known OKN control service AB00 / AB01 / AB02 ***");

                BluetoothGattService okn = g.getService(KNOWN_OKN_SERVICE);
                BluetoothGattCharacteristic tx = okn == null ? null : okn.getCharacteristic(KNOWN_OKN_TX);
                if (tx != null && (tx.getProperties() & BluetoothGattCharacteristic.PROPERTY_READ) != 0) {
                    try {
                        boolean started = g.readCharacteristic(tx);
                        host.line("GATT V6 READ-ONLY: AB01 read started=" + started);
                        if (started) return;
                    } catch (Throwable t) {
                        host.line("GATT V6 AB01 read error: " + t.getClass().getSimpleName() + ": " + safeMsg(t));
                    }
                }
                host.line("GATT enumeration complete. No characteristic write was performed.");
            }
            finishGatt(g, "services complete");
        }

        @Override public void onCharacteristicRead(BluetoothGatt g, BluetoothGattCharacteristic c, int status) {
            byte[] value = c == null ? null : c.getValue();
            logCharacteristicRead(g, c, value, status);
        }

        @Override public void onCharacteristicRead(BluetoothGatt g, BluetoothGattCharacteristic c,
                                                    byte[] value, int status) {
            logCharacteristicRead(g, c, value, status);
        }
    };

    private void logCharacteristicRead(BluetoothGatt g, BluetoothGattCharacteristic c,
                                       byte[] value, int status) {
        UUID uuid = c == null ? null : c.getUuid();
        host.line("GATT CHAR READ status=" + status + " uuid=" + uuid
                + " len=" + (value == null ? 0 : value.length)
                + (value != null && value.length > 0
                ? " hex=" + UsbProbe.hex(value, 0, value.length, 512) : ""));
        finishGatt(g, "read complete");
    }

    private void timeoutGatt(BluetoothGatt g) {
        synchronized (gatts) {
            if (!gatts.contains(g)) return;
        }
        finishGatt(g, "15s timeout");
    }

    private void finishGatt(BluetoothGatt g, String why) {
        boolean doClose;
        synchronized (gatts) { doClose = gatts.remove(g); }
        if (!doClose) return;
        host.line("GATT close: " + why);
        try { g.disconnect(); } catch (Throwable ignored) {}
        try { g.close(); } catch (Throwable ignored) {}
    }

    @SuppressWarnings("deprecation")
    private BluetoothDevice getBtExtra(Intent i) {
        try {
            if (Build.VERSION.SDK_INT >= 33) return i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice.class);
            return i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
        } catch (Throwable t) { return null; }
    }

    @SuppressWarnings("deprecation")
    private ParcelUuid[] getUuidExtra(Intent i) {
        try {
            Parcelable[] p;
            if (Build.VERSION.SDK_INT >= 33) p = i.getParcelableArrayExtra(BluetoothDevice.EXTRA_UUID, ParcelUuid.class);
            else p = i.getParcelableArrayExtra(BluetoothDevice.EXTRA_UUID);
            if (p == null) return null;
            ParcelUuid[] out = new ParcelUuid[p.length];
            for (int x = 0; x < p.length; x++) out[x] = (ParcelUuid) p[x];
            return out;
        } catch (Throwable t) { return null; }
    }

    private static ParcelUuid[] safeUuids(BluetoothDevice d) {
        try { return d.getUuids(); } catch (Throwable t) { return null; }
    }
    private static int safeType(BluetoothDevice d) {
        try { return d.getType(); } catch (Throwable t) { return BluetoothDevice.DEVICE_TYPE_UNKNOWN; }
    }
    private static int safeBond(BluetoothDevice d) {
        try { return d.getBondState(); } catch (Throwable t) { return BluetoothDevice.BOND_NONE; }
    }
    private static String classText(BluetoothDevice d) {
        try { return d.getBluetoothClass() == null ? "?" : d.getBluetoothClass().toString(); }
        catch (Throwable t) { return "?"; }
    }

    private static String typeName(int t) {
        switch (t) {
            case BluetoothDevice.DEVICE_TYPE_CLASSIC: return "CLASSIC";
            case BluetoothDevice.DEVICE_TYPE_LE: return "LE";
            case BluetoothDevice.DEVICE_TYPE_DUAL: return "DUAL";
            default: return "UNKNOWN";
        }
    }
    private static String bondName(int b) {
        switch (b) {
            case BluetoothDevice.BOND_BONDED: return "BONDED";
            case BluetoothDevice.BOND_BONDING: return "BONDING";
            default: return "NONE";
        }
    }
    private static String uuidsText(ParcelUuid[] uuids) {
        if (uuids == null) return "<none/cached-empty>";
        if (uuids.length == 0) return "[]";
        StringBuilder s = new StringBuilder("[");
        for (int i = 0; i < uuids.length; i++) {
            if (i > 0) s.append(", ");
            s.append(uuids[i]);
        }
        return s.append(']').toString();
    }
    private static String uuidLabel(UUID u) {
        if (UUID_SPP.equals(u)) return "Serial Port Profile (SPP)";
        if (UUID_OBEX_OBJECT_PUSH.equals(u)) return "OBEX Object Push";
        if (UUID_OBEX_FILE_TRANSFER.equals(u)) return "OBEX File Transfer";
        String x = u.toString().toLowerCase(Locale.US);
        if (x.startsWith("0000110b-")) return "A2DP Audio Sink";
        if (x.startsWith("0000110e-") || x.startsWith("0000110c-")) return "AVRCP";
        return "";
    }

    private static String properties(int p) {
        List<String> a = new ArrayList<>();
        if ((p & BluetoothGattCharacteristic.PROPERTY_BROADCAST) != 0) a.add("BROADCAST");
        if ((p & BluetoothGattCharacteristic.PROPERTY_READ) != 0) a.add("READ");
        if ((p & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0) a.add("WRITE_NR");
        if ((p & BluetoothGattCharacteristic.PROPERTY_WRITE) != 0) a.add("WRITE");
        if ((p & BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0) a.add("NOTIFY");
        if ((p & BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) a.add("INDICATE");
        if ((p & BluetoothGattCharacteristic.PROPERTY_SIGNED_WRITE) != 0) a.add("SIGNED_WRITE");
        if ((p & BluetoothGattCharacteristic.PROPERTY_EXTENDED_PROPS) != 0) a.add("EXTENDED");
        return a.isEmpty() ? "NONE" : String.join("|", a);
    }

    private static String serviceType(int t) {
        return t == BluetoothGattService.SERVICE_TYPE_PRIMARY ? "PRIMARY" : "SECONDARY";
    }

    static String safeName(BluetoothDevice d) {
        try { String n = d.getName(); return n == null ? "<unnamed>" : n; }
        catch (Throwable t) { return "<permission>"; }
    }
    static String safeAddr(BluetoothDevice d) {
        try { return d.getAddress(); } catch (Throwable t) { return "<permission>"; }
    }
    private static String safeMsg(Throwable t) {
        String m = t.getMessage(); return m == null ? "" : m;
    }
}
