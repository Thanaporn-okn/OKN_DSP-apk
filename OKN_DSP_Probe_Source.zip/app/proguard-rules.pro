# No shrinking rules required for the probe app.
