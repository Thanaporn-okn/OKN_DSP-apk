#!/usr/bin/env python3
from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'evidence_manifest.json').read_text())
errors=[]
if m.get('schema')!=4: errors.append('evidence schema must be 4')
if m.get('project_version')!=21: errors.append('project_version must be 21')
if m.get('target')!='BP1048P4' or m.get('board')!='GoloPine 7CH': errors.append('target/board mismatch')
if m.get('policy')!='FAIL_CLOSED_NO_INFERENCE': errors.append('policy mismatch')
if m.get('hardware_authorized') is not False: errors.append('hardware_authorized must be false')
req=m.get('required_exact_evidence',{})
if any(bool(v) for v in req.values()): errors.append('V21 exact evidence flags must all remain false')
prov=m.get('provenance',{})
if prov.get('previous_source_sha256')!='11a44a48bf149649ac2a15d4a92046e6388c7db3ef75932772ee1f065b94435d': errors.append('V20 source provenance mismatch')
if prov.get('validation_zip_sha256')!='de65ce5eaf8a62f3e4ee65cde6f1daee964b4dc856288d2a3b0a5d50eb8a3519': errors.append('V20 validation provenance mismatch')
if not any(o.get('id')=='v20-ci-validation' for o in m.get('observations',[])): errors.append('V20 CI observation missing')
for ob in m.get('observations',[]):
    if ob.get('authorizes') not in ([],None): errors.append('observations may not authorize hardware in V21')
if errors:
    [print('BLOCKED:',e) for e in errors]; sys.exit(1)
print('PASS: V21 evidence manifest is internally consistent and non-authorizing')
