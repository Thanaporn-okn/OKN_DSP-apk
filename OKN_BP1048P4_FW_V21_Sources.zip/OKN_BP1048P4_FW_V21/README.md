# OKN_BP1048P4_FW_V21

V21 preserves the V20 read-only hardware discovery gate and adds a canonical, machine-verifiable Android discovery capture/import path. The goal is to collect real USB-OTG/BLE/serial enumeration evidence from a phone without adding any programmer write path.

## What V21 adds

- `android_discovery_capture_schema.json`: fixed read-only capture contract.
- `tools/android_discovery_capture.py`: canonical SHA-256 validator; no device I/O.
- `tools/import_android_discovery.py`: local file importer into `hardware_probe_evidence/`; no device I/O.
- Inner canonical capture hash plus outer exact-file SHA-256 binding.
- Android transport observations for USB host, BLE, and serial enumeration.
- Tests proving commands/writes/program operations are rejected and imports never authorize hardware.

The wire frame remains Protocol V2. DSP/core behavior is unchanged. V21 intentionally contains no destructive executor, programmer packet, bootloader command, target address/pin sequence, or flash image.

## Current hardware state

`hardware_flashable=false`, `mobile_flashable=false`, and exact BP1048P4/GoloPine integration remains locked until content-bound, reviewed exact-target/board evidence and explicit authorization exist. A read-only Android capture is evidence for review only; it cannot prove the programmer protocol by itself.

See `docs/ANDROID_DISCOVERY_CAPTURE_V21.md`, `docs/HARDWARE_DISCOVERY_V21.md`, `docs/MOBILE_FLASH_TRANSACTION_V19.md`, and `docs/PORT_INTEGRATION_PLAN_V18.md`.
