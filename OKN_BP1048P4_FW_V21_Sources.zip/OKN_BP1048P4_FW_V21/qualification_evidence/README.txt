V21 evidence bundle directory. Files placed here authorize nothing until listed, content-hash-verified, classified, reviewed, bound to claims, and explicitly authorized.
