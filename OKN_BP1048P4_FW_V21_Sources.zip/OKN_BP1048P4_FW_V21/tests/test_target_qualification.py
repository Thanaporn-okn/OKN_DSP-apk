#!/usr/bin/env python3
from pathlib import Path
import copy,hashlib,json,sys,tempfile
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'tools'))
from target_qualification_policy import CLAIM_CLASSES,evaluate,record_is_qualified
from qualification_bundle import verify_bundle
m=json.loads((root/'target_qualification_manifest.json').read_text())
b=json.loads((root/'qualification_bundle_manifest.json').read_text())
br=verify_bundle(b,root)
assert br['ok'] and not br['verified_index']
r=evaluate(m,br['verified_index'])
assert not r['hardware_ready'] and not r['mobile_ready']
assert all(v is False for v in r['qualified'].values())
# Filename/string hints still never qualify.
fake={'verified':True,'reviewed':True,'classification':'FAMILY_ONLY','artifact_sha256':'a'*64,'artifact_id':'fake','source':'BP1048P4_SDK.zip','evidence_locator':'filename says BP1048P4'}
assert not record_is_qualified('exact_chip_identity',fake,{})
# Even exact classification/hash/review does not qualify without a content-bound verified file.
fake['classification']='EXACT_TARGET'; fake['artifact_sha256']='b'*64
assert not record_is_qualified('exact_chip_identity',fake,{})
# Build a synthetic content-bound bundle and bind every claim to the exact same reviewed test file.
with tempfile.TemporaryDirectory() as td:
    td=Path(td); (td/'qualification_evidence').mkdir()
    payload=b'V21 synthetic exact evidence for policy test only\n'
    f=td/'qualification_evidence'/'evidence.bin'; f.write_bytes(payload)
    sha=hashlib.sha256(payload).hexdigest()
    all_classes=sorted(set().union(*CLAIM_CLASSES.values()))
    bm={'schema':1,'project_version':21,'target':'BP1048P4','board':'GoloPine 7CH','policy':'CONTENT_BOUND_HASH_VERIFIED_REVIEW_REQUIRED','state':'TEST','bundle_root':'qualification_evidence','artifacts':[{'id':'synthetic','path':'evidence.bin','sha256':sha,'source':'synthetic unit-test evidence','classifications':all_classes,'reviewed':True}]}
    vr=verify_bundle(bm,td); assert vr['ok'] and 'synthetic' in vr['verified_index']
    m2=copy.deepcopy(m)
    for name,classes in CLAIM_CLASSES.items():
        cls=sorted(classes)[0]
        m2['claims'][name]={'verified':True,'reviewed':True,'classification':cls,'artifact_sha256':sha,'artifact_id':'synthetic','source':'synthetic unit-test evidence','evidence_locator':'unit-test:claim/'+name}
    r2=evaluate(m2,vr['verified_index'])
    assert r2['hardware_complete'] and r2['mobile_complete']
    assert not r2['hardware_ready'] and not r2['mobile_ready']
    m2['hardware_authorized']=True
    assert evaluate(m2,vr['verified_index'])['hardware_ready'] and not evaluate(m2,vr['verified_index'])['mobile_ready']
    m2['mobile_flash_authorized']=True
    assert evaluate(m2,vr['verified_index'])['mobile_ready']
    # A claim hash mismatch cannot borrow a valid artifact id.
    m2['claims']['programmer_transport']['artifact_sha256']='0'*64
    assert not evaluate(m2,vr['verified_index'])['hardware_ready']
print('ALL V21 TARGET QUALIFICATION TESTS PASS')
