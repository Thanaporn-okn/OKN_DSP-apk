import 'package:flutter/material.dart';

void main()=>runApp(const OKN());

class OKN extends StatelessWidget{
 const OKN({super.key});
 @override
 Widget build(BuildContext c){
  return MaterialApp(
   debugShowCheckedModeBanner:false,
   theme:ThemeData.dark(),
   home:Scaffold(
    appBar:AppBar(title:const Text('OKN_DSP BP1048P4 V34')),
    body:const Padding(
     padding:EdgeInsets.all(20),
     child:Text(
      'Bluetooth Real DSP Controller\n\n'
      'Bluetooth Permission\n'
      'Scan Device\n'
      'Connect / Disconnect\n'
      'Device Status\n'
      'TX BP1048P4 Packet\n'
      'RX Data Parser\n'
      'HEX Monitor\n'
      'Volume EQ Delay\n'
      'HPF LPF Control',
      style:TextStyle(fontSize:20),
     ),
    ),
   ),
  );
 }
}
