// V34 real bluetooth scan
