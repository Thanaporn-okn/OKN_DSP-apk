// V34 real TX RX communication
