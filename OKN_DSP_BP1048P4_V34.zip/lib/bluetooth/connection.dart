// V34 real connect disconnect
