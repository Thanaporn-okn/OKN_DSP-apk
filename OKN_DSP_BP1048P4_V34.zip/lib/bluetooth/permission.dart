// V34 Android Bluetooth permission handler
