// V34 BP1048P4 real packet
