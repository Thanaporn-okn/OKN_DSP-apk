// V34 Volume EQ Delay HPF LPF commands
