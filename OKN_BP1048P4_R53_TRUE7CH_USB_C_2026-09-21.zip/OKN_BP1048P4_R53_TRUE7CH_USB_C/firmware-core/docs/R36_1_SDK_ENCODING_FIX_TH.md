# R36.1 — SDK encoding fix

สาเหตุที่ GitHub Actions รอบแรกหยุด:
`BT_Audio_APP/bt_audio_app_src/inc/app_config.h` ใน public SDK มีข้อความภาษาจีนแบบ legacy encoding จึงไม่ใช่ UTF-8 ทั้งไฟล์ ขณะที่ R36 เดิมใช้ `Path.read_text(..., encoding='utf-8', errors='strict')` ทำให้เกิด `UnicodeDecodeError` ก่อนเปิด `CFG_CHIP_BP1048P4`.

การแก้ใน R36.1:
- `experimental_r36/scripts/enable_bp1048p4.py` อ่าน/เขียนเป็น raw bytes เท่านั้น
- แก้เฉพาะ ASCII macro prefix ของ `CFG_CHIP_BP10128` และ `CFG_CHIP_BP1048P4`
- ไม่ decode/re-encode ข้อความจีนและไม่เปลี่ยน non-ASCII bytes
- ยังคง pin SDK commit `8105bd864b04995d81c9f9ae77cb158259f39015`
- ยังคง refuse หาก macro ที่คาดไว้ไม่พบหรือมี active `CFG_CHIP_*` มากกว่าหนึ่งตัว

Validation:
- Python syntax/compile: PASS
- regression with deliberately invalid UTF-8 bytes: PASS
- non-ASCII byte preservation: PASS
- R36 SDK bridge host test: PASS
- R36 experimental guard: PASS

การใช้งานบน GitHub Actions:
แทนที่ ZIP เดิมด้วย ZIP R36.1 โดยใช้ชื่อเดิม `OKN_BP1048P4_PHASE3_TRUE7CH_Source_R36.zip` แล้วกด Re-run workflow เดิมได้เลย ไม่ต้องแก้ `R36_ZIP_BUILD.yml`.
