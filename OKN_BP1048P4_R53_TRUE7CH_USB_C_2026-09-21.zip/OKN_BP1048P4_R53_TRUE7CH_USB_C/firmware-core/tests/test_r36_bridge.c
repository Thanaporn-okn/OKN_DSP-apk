#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "okn_r36_sdk_bridge.h"

static void f32le(uint8_t *p,float f){uint32_t u;memcpy(&u,&f,4);p[0]=(uint8_t)u;p[1]=(uint8_t)(u>>8);p[2]=(uint8_t)(u>>16);p[3]=(uint8_t)(u>>24);}
static void set_ch(uint8_t id, float db){uint8_t p[13]={0x57,0,0,0,id,0,0,0,4,0,0,0,0};f32le(p+9,db);assert(okn_r36_ufe_write_apply(p,sizeof(p)));}

int main(void)
{
    int i;
    okn_r36_init();
#if OKN_R53_DAC_EXACT_Q12_UNITY
    assert(okn_r36_gain_q12(0)==4096u);
#else
    assert(okn_r36_gain_q12(0)==4095u);
#endif
    set_ch(22,-6.0f);
    assert(okn_r36_gain_q12(0) >= 2040u && okn_r36_gain_q12(0) <= 2060u);
    set_ch(22,6.0f);
    assert(okn_r36_gain_q12(0) >= 8160u && okn_r36_gain_q12(0) <= 8191u);

    /* CH4 ramps from 0 dB to -6 dB while CH5 remains untouched. */
    okn_r36_init();
    set_ch(25,-6.0f);
    set_ch(26,0.0f);
    {
        int16_t src[2]={10000,10000}, dst[2]={0};
        okn_r36_process_i2s16_copy(3,src,dst,1);
        assert(dst[0] < 10000 && dst[0] > 9000); /* not an abrupt half-volume step */
        assert(dst[1] == 10000);
        assert(src[0] == 10000 && src[1] == 10000);
    }
    for(i=0;i<127;i++){
        int16_t x[2]={10000,10000};
        okn_r36_process_i2s16_copy(3,x,x,1);
        assert(x[1]==10000);
    }
    {
        int16_t x[2]={10000,10000};
        okn_r36_process_i2s16_copy(3,x,x,1);
        assert(x[0]>4900 && x[0]<5120);
        assert(x[1]==10000);
    }

    /* Re-target during a ramp must remain bounded and converge. */
    set_ch(25,6.0f);
    for(i=0;i<128;i++){
        int16_t x[2]={10000,10000};
        okn_r36_process_i2s16_copy(3,x,x,1);
        assert(x[1]==10000);
    }
    {
        int16_t x[2]={10000,10000};
        okn_r36_process_i2s16_copy(3,x,x,1);
        assert(x[0] > 19500 && x[0] < 20100);
    }

    {
        uint8_t rr[9]={0x58,0,0,0,25,0,0,0,4}, out[13];
        assert(okn_r36_ufe_read(rr,sizeof(rr),out,sizeof(out))==13u && out[0]==0x60 && out[4]==25);
    }
    puts("R53 SDK bridge host tests: PASS");
    return 0;
}
