#ifndef OKN_R36_SDK_BRIDGE_H
#define OKN_R36_SDK_BRIDGE_H

#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
#include "okn_gain7.h"
#include "okn_ufe_gain7.h"

#ifdef __cplusplus
extern "C" {
#endif

#define OKN_R36_SDK_COMMIT "8105bd864b04995d81c9f9ae77cb158259f39015"
#define OKN_R36_MAX_I2S_FRAMES 512u
#define OKN_R53_I2S_RAMP_FRAMES 128u

/* MVSilicon's own application code repeatedly uses 4095 as nominal 0 dB.
 * Exact Q12 arithmetic unity is 4096, but forcing that on an unverified
 * production sink changes vendor convention. Keep compatibility by default.
 * Set to 1 only for a sacrificial-board experiment after confirming the sink
 * accepts 4096 without unintended gain/overflow behavior. */
#ifndef OKN_R53_DAC_EXACT_Q12_UNITY
#define OKN_R53_DAC_EXACT_Q12_UNITY 0
#endif

typedef struct {
    okn_gain7_state_t gain;
    bool bound;
    /* I2S-only smoothing state. q22 = q14 << 8. The logical gain table
     * remains Q2.14 and is independent from all EQ coefficients. */
    int32_t i2s_current_q22[OKN_GAIN7_CHANNELS];
    int32_t i2s_step_q22[OKN_GAIN7_CHANNELS];
    uint16_t i2s_remaining[OKN_GAIN7_CHANNELS];
    uint16_t i2s_target_q14[OKN_GAIN7_CHANNELS];
} okn_r36_ctx_t;

extern okn_r36_ctx_t g_okn_r36;

void okn_r36_init(void);
uint16_t okn_r36_gain_q12(uint8_t ch0);
bool okn_r36_ufe_write_apply(const uint8_t *p, size_t n);
size_t okn_r36_ufe_read(const uint8_t *req, size_t n, uint8_t *out, size_t cap);
void okn_r36_process_i2s16_copy(uint8_t first_ch0, const int16_t *src, int16_t *dst, size_t frames);

#ifdef OKN_R36_VENDOR_SDK
void okn_r36_apply_dac_sinks(void);
uint16_t __wrap_AudioI2S0_DataSet(void *Buf, uint16_t Len);
uint16_t __wrap_AudioI2S1_DataSet(void *Buf, uint16_t Len);
#endif

#ifdef __cplusplus
}
#endif
#endif
