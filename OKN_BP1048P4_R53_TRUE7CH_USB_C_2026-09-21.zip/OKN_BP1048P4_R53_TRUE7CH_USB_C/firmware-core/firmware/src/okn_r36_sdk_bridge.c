#include "okn_r36_sdk_bridge.h"
#include <string.h>

okn_r36_ctx_t g_okn_r36;

static int16_t sat16_r53(int32_t v)
{
    if (v > 32767) return 32767;
    if (v < -32768) return -32768;
    return (int16_t)v;
}

static void r53_sync_ramp_target(uint8_t ch0)
{
    uint16_t target;
    int32_t target_q22;
    int32_t delta;
    int32_t step;
    if (ch0 >= OKN_GAIN7_CHANNELS) return;
    target = okn_gain7_get_q14(&g_okn_r36.gain, ch0);
    if (g_okn_r36.i2s_target_q14[ch0] == target) return;
    g_okn_r36.i2s_target_q14[ch0] = target;
    target_q22 = ((int32_t)target) << 8;
    delta = target_q22 - g_okn_r36.i2s_current_q22[ch0];
    step = delta / (int32_t)OKN_R53_I2S_RAMP_FRAMES;
    if ((step == 0) && (delta != 0)) step = (delta > 0) ? 1 : -1;
    g_okn_r36.i2s_step_q22[ch0] = step;
    g_okn_r36.i2s_remaining[ch0] = OKN_R53_I2S_RAMP_FRAMES;
}

static uint16_t r53_next_i2s_q14(uint8_t ch0)
{
    int32_t target_q22;
    int32_t q22;
    if (ch0 >= OKN_GAIN7_CHANNELS) return 16384u;
    r53_sync_ramp_target(ch0);
    target_q22 = ((int32_t)g_okn_r36.i2s_target_q14[ch0]) << 8;
    if (g_okn_r36.i2s_remaining[ch0] != 0u) {
        if (g_okn_r36.i2s_remaining[ch0] == 1u) {
            g_okn_r36.i2s_current_q22[ch0] = target_q22;
        } else {
            q22 = g_okn_r36.i2s_current_q22[ch0] + g_okn_r36.i2s_step_q22[ch0];
            if ((g_okn_r36.i2s_step_q22[ch0] > 0 && q22 > target_q22) ||
                (g_okn_r36.i2s_step_q22[ch0] < 0 && q22 < target_q22)) {
                q22 = target_q22;
            }
            g_okn_r36.i2s_current_q22[ch0] = q22;
        }
        g_okn_r36.i2s_remaining[ch0]--;
    }
    q22 = g_okn_r36.i2s_current_q22[ch0];
    if (q22 < 0) q22 = 0;
    return (uint16_t)((q22 + 128) >> 8);
}

static void r53_process_i2s_lane(uint8_t ch0, int16_t *pcm, size_t frames,
                                  uint8_t lane, uint8_t lanes)
{
    size_t i;
    if (!pcm || ch0 >= OKN_GAIN7_CHANNELS || lanes == 0u || lane >= lanes) return;
    for (i = 0; i < frames; ++i) {
        size_t pos = i * lanes + lane;
        uint16_t g = r53_next_i2s_q14(ch0);
        int32_t y = ((int32_t)pcm[pos] * (int32_t)g + 8192) >> 14;
        pcm[pos] = sat16_r53(y);
    }
}

void okn_r36_init(void)
{
    uint8_t i;
    okn_gain7_init(&g_okn_r36.gain);
    for (i = 0; i < OKN_GAIN7_CHANNELS; ++i) {
        uint16_t g = okn_gain7_get_q14(&g_okn_r36.gain, i);
        g_okn_r36.i2s_target_q14[i] = g;
        g_okn_r36.i2s_current_q22[i] = ((int32_t)g) << 8;
        g_okn_r36.i2s_step_q22[i] = 0;
        g_okn_r36.i2s_remaining[i] = 0u;
    }
    g_okn_r36.bound = true;
}

uint16_t okn_r36_gain_q12(uint8_t ch0)
{
    uint32_t q14 = okn_gain7_get_q14(&g_okn_r36.gain, ch0);
    uint32_t q12;
#if OKN_R53_DAC_EXACT_Q12_UNITY
    q12 = (q14 + 2u) >> 2; /* 16384 -> 4096 */
#else
    q12 = (q14 * 4095u + 8192u) >> 14; /* vendor nominal convention */
#endif
    if (q12 > 8191u) q12 = 8191u;
    return (uint16_t)q12;
}

void okn_r36_process_i2s16_copy(uint8_t first_ch0, const int16_t *src, int16_t *dst, size_t frames)
{
    size_t samples;
    if (!src || !dst || frames > OKN_R36_MAX_I2S_FRAMES || first_ch0 + 1u >= OKN_GAIN7_CHANNELS) return;
    samples = frames * 2u;
    if (src != dst) memcpy(dst, src, samples * sizeof(int16_t));
    r53_process_i2s_lane(first_ch0, dst, frames, 0u, 2u);
    r53_process_i2s_lane((uint8_t)(first_ch0 + 1u), dst, frames, 1u, 2u);
}

bool okn_r36_ufe_write_apply(const uint8_t *p, size_t n)
{
    bool ok;
    if (!g_okn_r36.bound) okn_r36_init();
    ok = okn_ufe_gain7_write(&g_okn_r36.gain, p, n);
#ifdef OKN_R36_VENDOR_SDK
    if (ok) okn_r36_apply_dac_sinks();
#endif
    return ok;
}

size_t okn_r36_ufe_read(const uint8_t *req, size_t n, uint8_t *out, size_t cap)
{
    if (!g_okn_r36.bound) okn_r36_init();
    return okn_ufe_gain7_read(&g_okn_r36.gain, req, n, out, cap);
}

#ifdef OKN_R36_VENDOR_SDK
#include "audio_core_api.h"
#include "i2s_interface.h"
#include "i2s.h"

extern uint16_t __real_AudioI2S0_DataSet(void *Buf, uint16_t Len);
extern uint16_t __real_AudioI2S1_DataSet(void *Buf, uint16_t Len);

static int16_t s_i2s0_scratch[OKN_R36_MAX_I2S_FRAMES * 2u];
static int16_t s_i2s1_scratch[OKN_R36_MAX_I2S_FRAMES * 2u];

void okn_r36_apply_dac_sinks(void)
{
    if (!g_okn_r36.bound) okn_r36_init();
    AudioCoreSinkVolSet(AUDIO_DAC0_SINK_NUM, okn_r36_gain_q12(0), okn_r36_gain_q12(1));
#ifdef CFG_RES_AUDIO_DACX_EN
    AudioCoreSinkVolSet(AUDIO_DACX_SINK_NUM, okn_r36_gain_q12(2), okn_r36_gain_q12(2));
#endif
}

static uint16_t wrap_i2s(void *buf, uint16_t frames, uint8_t first_ch0, int16_t *scratch,
                         I2S_MODULE module, uint16_t (*real_fn)(void *, uint16_t))
{
    if (!buf || frames == 0u || frames > OKN_R36_MAX_I2S_FRAMES) return real_fn(buf, frames);
    if (I2S_WordlengthGet(module) != I2S_LENGTH_16BITS) return real_fn(buf, frames);
    if (!g_okn_r36.bound) okn_r36_init();
    okn_r36_process_i2s16_copy(first_ch0, (const int16_t *)buf, scratch, frames);
    return real_fn(scratch, frames);
}

uint16_t __wrap_AudioI2S0_DataSet(void *Buf, uint16_t Len)
{
    return wrap_i2s(Buf, Len, 3u, s_i2s0_scratch, I2S0_MODULE, __real_AudioI2S0_DataSet);
}

uint16_t __wrap_AudioI2S1_DataSet(void *Buf, uint16_t Len)
{
    return wrap_i2s(Buf, Len, 5u, s_i2s1_scratch, I2S1_MODULE, __real_AudioI2S1_DataSet);
}
#endif
