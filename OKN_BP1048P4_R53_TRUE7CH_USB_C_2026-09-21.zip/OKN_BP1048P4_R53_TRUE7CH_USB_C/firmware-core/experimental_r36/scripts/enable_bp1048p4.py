#!/usr/bin/env python3
from pathlib import Path
import argparse, re, subprocess

PIN='8105bd864b04995d81c9f9ae77cb158259f39015'


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('sdk_root', type=Path)
    a=ap.parse_args()
    root=a.sdk_root.resolve()

    try:
        head=subprocess.check_output(
            ['git','-C',str(root),'rev-parse','HEAD'],
            text=True
        ).strip()
    except Exception as e:
        raise SystemExit(f'cannot verify SDK git commit: {e}')

    if head != PIN:
        raise SystemExit(f'REFUSE: SDK HEAD {head} != pinned {PIN}')

    p=root/'BT_Audio_APP/bt_audio_app_src/inc/app_config.h'
    data=p.read_bytes()

    # IMPORTANT: the public SDK header contains legacy Chinese text encoding.
    # Never decode/re-encode the whole file. Patch only the ASCII macro prefix
    # so every non-ASCII byte remains byte-for-byte identical.
    bp10128 = re.compile(rb'(?m)^([ \t]*)#define([ \t]+)CFG_CHIP_BP10128\b')
    p4      = re.compile(rb'(?m)^([ \t]*)//#define([ \t]+)CFG_CHIP_BP1048P4\b')

    if len(bp10128.findall(data)) != 1:
        raise SystemExit('REFUSE: expected exactly one active BP10128 line')
    if len(p4.findall(data)) != 1:
        raise SystemExit('REFUSE: expected exactly one commented BP1048P4 line')

    data, n1 = bp10128.subn(rb'\1//#define\2CFG_CHIP_BP10128', data, count=1)
    data, n2 = p4.subn(rb'\1#define\2CFG_CHIP_BP1048P4', data, count=1)
    if n1 != 1 or n2 != 1:
        raise SystemExit(f'REFUSE: patch count mismatch bp10128={n1} p4={n2}')

    active = re.findall(rb'(?m)^[ \t]*#define[ \t]+(CFG_CHIP_[A-Za-z0-9_]+)\b', data)
    if active != [b'CFG_CHIP_BP1048P4']:
        raise SystemExit('REFUSE: expected exactly one active CFG_CHIP_BP1048P4, got ' + repr(active))

    p.write_bytes(data)
    print('R36.1 P4 overlay: PASS (binary-safe, no text transcoding)')


if __name__=='__main__':
    main()
