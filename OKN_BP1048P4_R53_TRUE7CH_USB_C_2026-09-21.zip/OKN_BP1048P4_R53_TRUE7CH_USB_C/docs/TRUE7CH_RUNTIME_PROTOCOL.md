# TRUE7CH runtime protocol

Transport: USB HID IF4, 256-byte reports.

## Gain
IDs: 22..28 = CH1..CH7.
Range: -70.0..+6.0 dB, 0.5 dB step.
State format: Q2.14 internally; runtime payload is float32 little-endian dB.

Write frame (meaningful prefix 17 bytes):
A5 5A 57 0C ID32BE OFFSET16BE LEN16BE FLOAT32LE 16

Read request (meaningful prefix 13 bytes):
A5 5A 58 08 ID32BE OFFSET16BE LEN16BE 16

Read response (meaningful prefix 17 bytes):
A5 5A 60 0C ID32BE OFFSET16BE LEN16BE FLOAT32LE 16

## EQ
IDs: 30..36 = EQ CH1..CH7.
15 peaking bands/channel. EQ state and gain state are separate; gain implementation does not edit an EQ band's gain.

R53 processing order is EQ -> dedicated gain.
