# R53 — เหตุที่ direct USB-C flash จาก stock board ยังไม่เปิด

## Feature 8-byte app-preboot path
Reference source ทำงานเป็นสองชั้น:
1. SET Feature `AA` -> arm `pc_upgrade`
2. GET Feature -> byte0=`55`; แล้วจะเรียก `start_up_grate(AppResourceUsbDevice)` เฉพาะ build ที่ `FLASH_BOOT_EN` เปิด

`start_up_grate()` จะตั้ง PC/update flags และ jump เข้า flashboot ก็ต่อเมื่อ `ResourceValue(AppResourceUsbDevice)` เป็นจริงด้วย

ผล live R46G: ได้ `55` แต่หลัง 10 วินาทียัง VID/PID/path/descriptors เดิม จึงยืนยันได้เพียงว่า runtime handler ทำงาน ไม่ได้ยืนยันว่า flashboot ถูกเข้าแล้ว

ความเป็นไปได้ที่ยังแยกไม่ได้แบบ read-only:
- production firmware compile `FLASH_BOOT_EN=0`
- หรือ `FLASH_BOOT_EN=1` แต่ USB resource bit ไม่ ready/logic ต่างจาก reference

`Communication_Effect_0x02` ไม่ช่วยแยก เพราะตอบ RAM/CPU metrics ไม่ได้ expose ModeResourceReady.

## ทำไมไม่ยิง flash command เพื่อเดา
Command table ที่พบ (`cxxx`, `chiperas`, `bootdat`, `codedata`, `constdat`, `cnfgdat`, `btupdat`, `upinfo`) ล้วน stateful/erase/program/finalize. ไม่มี command ที่พิสูจน์ว่าเป็น strict read-only identity.

## Image gate
R41 linked image แสดงว่า DSP/link สำเร็จ แต่ application header ยังไม่จบ:
- +0xBC code CRC = FFFFFFFF
- +0xC0 magic = B0BEBDC9
- +0xE0..E3 = FFFFFFFF

จึงยังไม่ใช่ production flash image.

## เป้าหมายถัดไปที่ทำให้ S25+ flash ได้จริง
1. ให้ R53 application มี boot-entry command ของเราเองหลัง bootstrap ครั้งแรก
2. จบ post-link metadata/CRC ตาม maker/downloader ที่ reverse ได้
3. ยืนยัน production layout + recovery/backup บนบอร์ดทดลองอย่างน้อยหนึ่งตัว
4. จากนั้นค่อยเปิด Android flasher state machine: enter boot -> detect boot interface -> send MVA/code records -> verify -> reboot

ข้อ 1–4 เป็น software path; ไม่ต้องแก้ hardware ของบอร์ด แต่ bootstrap ครั้งแรกจาก stock ยังต้องมี stock-supported boot entry ที่พิสูจน์ได้ หรือ programmer ที่เชื่อถือได้หนึ่งครั้ง.
