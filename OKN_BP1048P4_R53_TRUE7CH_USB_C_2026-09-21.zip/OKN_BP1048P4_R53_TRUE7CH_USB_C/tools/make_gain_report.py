#!/usr/bin/env python3
"""Build/parse the proven runtime-only 7CH gain HID payload. No flash commands."""
import argparse, struct

def write(ch,db):
    if not 1 <= ch <= 7: raise ValueError('channel must be 1..7')
    if not -70.0 <= db <= 6.0: raise ValueError('gain must be -70..+6 dB')
    idx=round((db+70.0)*2)
    db=-70.0+idx*0.5
    aid=21+ch
    r=bytearray(256)
    r[:4]=b'\xA5\x5A\x57\x0C'
    r[4:8]=aid.to_bytes(4,'big'); r[8:10]=b'\0\0'; r[10:12]=(4).to_bytes(2,'big')
    r[12:16]=struct.pack('<f',db); r[16]=0x16
    return bytes(r),db

def read(ch):
    aid=21+ch; r=bytearray(256); r[:4]=b'\xA5\x5A\x58\x08'; r[4:8]=aid.to_bytes(4,'big'); r[10:12]=(4).to_bytes(2,'big'); r[12]=0x16; return bytes(r)

ap=argparse.ArgumentParser(); sub=ap.add_subparsers(dest='cmd',required=True)
w=sub.add_parser('write'); w.add_argument('channel',type=int); w.add_argument('db',type=float)
r=sub.add_parser('read'); r.add_argument('channel',type=int)
a=ap.parse_args()
if a.cmd=='write': data,q=write(a.channel,a.db); print(f'quantized_db={q:.1f}')
else: data=read(a.channel)
print('frame_prefix=' + data[:20].hex(' '))
print('hid_set_report=bmRequestType=0x21 bRequest=0x09 wValue=0x0200 wIndex=4 length=256')
