#!/usr/bin/env python3
"""Fail-closed BP1048P4 application-image metadata inspector.

Read-only. Never patches, erases, programs, or emits a flashable image.
The currently recovered metadata is not sufficient by itself to prove a
production GoloPine layout/recovery path, so FLASH_GATE stays closed unless
explicit evidence files are supplied.
"""
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path

MAGIC = 0xB0BEBDC9

def u32le(b: bytes) -> int: return int.from_bytes(b, 'little')

def inspect(path: Path, app_offset: int) -> dict:
    b = path.read_bytes()
    base = app_offset
    out = {
        'file': str(path), 'size': len(b), 'sha256': hashlib.sha256(b).hexdigest(),
        'app_offset': hex(app_offset), 'read_only': True,
    }
    if len(b) < base + 0xE4:
        out.update(error='image too short for BP1048 application header', flash_gate=False)
        return out
    crc_word = u32le(b[base+0xBC:base+0xC0])
    magic = u32le(b[base+0xC0:base+0xC4])
    e0,e1,e2,e3 = b[base+0xE0:base+0xE4]
    code_len = e0 | (e1<<8) | (e2<<16)
    length_check_ok = ((e0+e1+e2)&0xFF) == e3
    out.update({
        'code_crc_word_at_BC': f'0x{crc_word:08X}',
        'code_crc_present': crc_word != 0xFFFFFFFF,
        'magic_at_C0': f'0x{magic:08X}', 'magic_ok': magic == MAGIC,
        'code_length_24le': code_len,
        'length_check_byte_E3': f'0x{e3:02X}', 'length_check_ok': length_check_ok,
        'length_fits_file': code_len >= 0xEC and base + code_len <= len(b),
        'metadata_complete_enough_for_offline_validation': (
            crc_word != 0xFFFFFFFF and magic == MAGIC and length_check_ok and
            code_len >= 0xEC and base + code_len <= len(b)
        ),
        'fastcrc_included_ranges': [
            '0x0000..0x00A3','0x00A8..0x00BB','0x00C0..0x00CB',
            '0x00D4..0x00E3','0x00EC..code_length-1'],
        'warning': 'Metadata completeness is not production-layout/recovery proof.'
    })
    return out

def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument('image', type=Path)
    ap.add_argument('--app-offset', type=lambda x:int(x,0), default=0x10000)
    ap.add_argument('--production-layout-proof', type=Path)
    ap.add_argument('--stock-backup-proof', type=Path)
    ap.add_argument('--json', action='store_true')
    a=ap.parse_args()
    o=inspect(a.image,a.app_offset)
    layout=bool(a.production_layout_proof and a.production_layout_proof.is_file() and a.production_layout_proof.stat().st_size)
    backup=bool(a.stock_backup_proof and a.stock_backup_proof.is_file() and a.stock_backup_proof.stat().st_size)
    o['production_layout_proof_supplied']=layout
    o['stock_backup_proof_supplied']=backup
    o['flash_gate']=bool(o.get('metadata_complete_enough_for_offline_validation') and layout and backup)
    if a.json: print(json.dumps(o,indent=2,ensure_ascii=False))
    else:
        for k,v in o.items(): print(f'{k}={v}')
        print('RESULT=' + ('FLASH_GATE_OPEN' if o['flash_gate'] else 'FLASH_GATE_CLOSED'))
    return 0 if o.get('metadata_complete_enough_for_offline_validation') else 2
if __name__=='__main__': raise SystemExit(main())
