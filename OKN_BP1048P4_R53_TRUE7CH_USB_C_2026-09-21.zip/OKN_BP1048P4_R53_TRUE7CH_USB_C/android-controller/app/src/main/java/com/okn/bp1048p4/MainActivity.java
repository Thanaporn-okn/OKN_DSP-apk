package com.okn.bp1048p4;

import android.app.*;
import android.os.*;
import android.content.*;
import android.hardware.usb.*;
import android.view.*;
import android.widget.*;
import java.nio.*;
import java.util.*;

public class MainActivity extends Activity {
    private static final int VID = 0x6324;
    private static final int PID = 0x1719;
    private static final int IFACE_ID = 4;
    private static final String ACTION_USB_PERMISSION = "com.okn.bp1048p4.USB_PERMISSION";
    private static final int REPORT_BYTES = 256;
    private final SeekBar[] sliders = new SeekBar[7];
    private final TextView[] values = new TextView[7];
    private TextView status;
    private UsbManager usbManager;
    private UsbDevice device;
    private UsbDeviceConnection connection;
    private UsbInterface hidInterface;

    private final BroadcastReceiver permissionReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!ACTION_USB_PERMISSION.equals(intent.getAction())) return;
            UsbDevice d = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
            boolean granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false);
            if (granted && d != null) openDevice(d); else setStatus("USB permission denied");
        }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        usbManager = (UsbManager)getSystemService(Context.USB_SERVICE);
        IntentFilter f = new IntentFilter(ACTION_USB_PERMISSION);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(permissionReceiver, f, RECEIVER_NOT_EXPORTED);
        else registerReceiver(permissionReceiver, f);
        setContentView(buildUi());
        findAndRequest();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        try { unregisterReceiver(permissionReceiver); } catch (Exception ignored) {}
        closeUsb();
    }

    private View buildUi() {
        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 28, 28, 28);
        sv.addView(root);

        TextView title = new TextView(this);
        title.setText("OKN BP1048P4 R53 — TRUE 7CH GAIN");
        title.setTextSize(21f);
        root.addView(title);

        TextView note = new TextView(this);
        note.setText("Gain IDs 22–28 • -70…+6 dB • step 0.5 dB\nEQ is NOT used for volume. Requires R53/R41-compatible runtime firmware.");
        note.setPadding(0, 8, 0, 16);
        root.addView(note);

        Button connect = new Button(this);
        connect.setText("CONNECT USB");
        connect.setOnClickListener(v -> findAndRequest());
        root.addView(connect);

        Button readAll = new Button(this);
        readAll.setText("READ BACK 7CH");
        readAll.setOnClickListener(v -> new Thread(this::readAllGains).start());
        root.addView(readAll);

        for (int ch=0; ch<7; ch++) {
            final int c = ch;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(0, 12, 0, 4);
            TextView label = new TextView(this);
            label.setText("CH" + (ch+1));
            label.setTextSize(17f);
            row.addView(label);
            values[ch] = new TextView(this);
            values[ch].setText("0.0 dB");
            row.addView(values[ch]);
            sliders[ch] = new SeekBar(this);
            sliders[ch].setMax(152); // -70 dB .. +6 dB in 0.5 dB
            sliders[ch].setProgress(140); // 0 dB
            sliders[ch].setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                    values[c].setText(String.format(Locale.US, "%.1f dB", progressToDb(p)));
                }
                @Override public void onStartTrackingTouch(SeekBar s) {}
                @Override public void onStopTrackingTouch(SeekBar s) {
                    final float db = progressToDb(s.getProgress());
                    new Thread(() -> writeGain(c, db)).start();
                }
            });
            row.addView(sliders[ch]);
            root.addView(row);
        }
        status = new TextView(this);
        status.setPadding(0, 20, 0, 40);
        status.setText("USB: not connected");
        root.addView(status);
        return sv;
    }

    private float progressToDb(int p) { return -70.0f + p * 0.5f; }
    private int dbToProgress(float db) {
        int p = Math.round((db + 70.0f) * 2.0f);
        return Math.max(0, Math.min(152, p));
    }

    private void setStatus(String s) { runOnUiThread(() -> status.setText(s)); }

    private void findAndRequest() {
        UsbDevice found = null;
        for (UsbDevice d : usbManager.getDeviceList().values()) {
            if (d.getVendorId() == VID && d.getProductId() == PID) { found = d; break; }
        }
        if (found == null) { setStatus(String.format(Locale.US,"USB: %04X:%04X not found", VID, PID)); return; }
        device = found;
        if (usbManager.hasPermission(found)) openDevice(found);
        else {
            PendingIntent pi = PendingIntent.getBroadcast(this, 0,
                    new Intent(ACTION_USB_PERMISSION).setPackage(getPackageName()),
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            usbManager.requestPermission(found, pi);
            setStatus("USB found; requesting permission…");
        }
    }

    private void openDevice(UsbDevice d) {
        closeUsb();
        UsbInterface match = null;
        for (int i=0;i<d.getInterfaceCount();i++) {
            UsbInterface itf = d.getInterface(i);
            if (itf.getId() == IFACE_ID) { match = itf; break; }
        }
        if (match == null) { setStatus("USB IF4 not found; refusing to send"); return; }
        UsbDeviceConnection c = usbManager.openDevice(d);
        if (c == null) { setStatus("openDevice failed"); return; }
        if (!c.claimInterface(match, true)) { c.close(); setStatus("claim IF4 failed"); return; }
        device = d; connection = c; hidInterface = match;
        setStatus(String.format(Locale.US, "Connected %04X:%04X IF%d — runtime control ready", d.getVendorId(), d.getProductId(), match.getId()));
    }

    private synchronized void closeUsb() {
        if (connection != null) {
            try { if (hidInterface != null) connection.releaseInterface(hidInterface); } catch (Exception ignored) {}
            connection.close();
        }
        connection = null; hidInterface = null;
    }

    private byte[] gainWriteReport(int ch0, float db) {
        byte[] r = new byte[REPORT_BYTES];
        int id = 22 + ch0;
        r[0]=(byte)0xA5; r[1]=0x5A; r[2]=0x57; r[3]=0x0C;
        r[4]=(byte)(id>>>24); r[5]=(byte)(id>>>16); r[6]=(byte)(id>>>8); r[7]=(byte)id;
        r[8]=0; r[9]=0; r[10]=0; r[11]=4;
        int bits = Float.floatToIntBits(db);
        r[12]=(byte)bits; r[13]=(byte)(bits>>>8); r[14]=(byte)(bits>>>16); r[15]=(byte)(bits>>>24);
        r[16]=0x16;
        return r;
    }

    private byte[] gainReadReport(int ch0) {
        byte[] r = new byte[REPORT_BYTES];
        int id = 22 + ch0;
        r[0]=(byte)0xA5; r[1]=0x5A; r[2]=0x58; r[3]=0x08;
        r[4]=(byte)(id>>>24); r[5]=(byte)(id>>>16); r[6]=(byte)(id>>>8); r[7]=(byte)id;
        r[8]=0; r[9]=0; r[10]=0; r[11]=4; r[12]=0x16;
        return r;
    }

    private synchronized int sendOutput(byte[] report) {
        if (connection == null || hidInterface == null) return -999;
        return connection.controlTransfer(0x21, 0x09, 0x0200, hidInterface.getId(), report, REPORT_BYTES, 1200);
    }

    private synchronized byte[] getInput() {
        if (connection == null || hidInterface == null) return null;
        byte[] in = new byte[REPORT_BYTES];
        int rc = connection.controlTransfer(0xA1, 0x01, 0x0100, hidInterface.getId(), in, REPORT_BYTES, 1200);
        if (rc <= 0) return null;
        return Arrays.copyOf(in, rc);
    }

    private void writeGain(int ch0, float db) {
        int rc = sendOutput(gainWriteReport(ch0, db));
        if (rc == REPORT_BYTES) setStatus(String.format(Locale.US,"CH%d -> %.1f dB sent (HID %d B)", ch0+1, db, rc));
        else setStatus("Gain write failed/short: rc=" + rc);
    }

    private Float readGain(int ch0) {
        int rc = sendOutput(gainReadReport(ch0));
        if (rc != REPORT_BYTES) return null;
        try { Thread.sleep(12); } catch (InterruptedException ignored) {}
        byte[] in = getInput();
        if (in == null || in.length < 17) return null;
        // Expected: A5 5A 60 0C id32be off16be len16be float32le 16
        if ((in[0]&0xFF)!=0xA5 || (in[1]&0xFF)!=0x5A || (in[2]&0xFF)!=0x60 || (in[3]&0xFF)!=0x0C) return null;
        int id = ((in[4]&0xFF)<<24)|((in[5]&0xFF)<<16)|((in[6]&0xFF)<<8)|(in[7]&0xFF);
        if (id != 22+ch0 || (in[10]&0xFF)!=0 || (in[11]&0xFF)!=4) return null;
        int bits = (in[12]&0xFF)|((in[13]&0xFF)<<8)|((in[14]&0xFF)<<16)|((in[15]&0xFF)<<24);
        return Float.intBitsToFloat(bits);
    }

    private void readAllGains() {
        if (connection == null) { setStatus("Connect USB first"); return; }
        int ok = 0;
        for (int ch=0;ch<7;ch++) {
            Float db = readGain(ch);
            if (db != null && !db.isNaN()) {
                final int c=ch, p=dbToProgress(db); final float d=db;
                runOnUiThread(() -> { sliders[c].setProgress(p); values[c].setText(String.format(Locale.US,"%.1f dB",d)); });
                ok++;
            }
        }
        setStatus("Readback: " + ok + "/7 channels verified");
    }
}
