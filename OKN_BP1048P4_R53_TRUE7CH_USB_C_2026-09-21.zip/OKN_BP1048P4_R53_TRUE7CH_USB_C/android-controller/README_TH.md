# Android controller — Samsung S25+ / USB-C

แอปนี้เป็น **runtime gain controller** สำหรับ firmware R53/R41-compatible เท่านั้น ไม่ใช่ stock-app patch และไม่ใช้ EQ ทำ Gain

- USB target ที่พิสูจน์ในชุดข้อมูล: VID:PID `6324:1719`, custom HID interface `4`
- HID Output SET_REPORT: `21 09 0200 IF4`, 256 bytes
- Gain write control `0x57`, read `0x58`, response `0x60`
- IDs CH1..CH7 = `22..28`
- ช่วง Gain `-70.0 .. +6.0 dB`, step 0.5 dB
- ตัวแอปอ่านค่ากลับทั้ง 7CH ได้; การเขียนสำเร็จที่ USB layer (256 bytes) ไม่ถูกนับเป็น firmware verification จนกว่าจะอ่าน `0x60` กลับได้

## Build
ใช้ workflow `.github/workflows/android.yml` หรือ Gradle 8.10.2 + JDK17 + Android SDK 35

> Stock firmware เดิมยังไม่มี handler `0x57/0x58` ที่เราพิสูจน์ ดังนั้น slider จะมีผลจริงหลัง firmware R53 ถูก bootstrap ลงบอร์ดแล้วเท่านั้น
