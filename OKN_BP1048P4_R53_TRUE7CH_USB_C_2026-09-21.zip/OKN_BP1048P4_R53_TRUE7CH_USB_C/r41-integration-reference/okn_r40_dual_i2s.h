#ifndef OKN_R40_DUAL_I2S_H
#define OKN_R40_DUAL_I2S_H
#include <stdint.h>
void okn_r40_dual_i2s_init(uint32_t sample_rate, uint16_t frames);
void okn_r40_apply_dac_gains(void);
void okn_r40_route_from_dac0(const int16_t *src_lr, uint16_t frames);
uint8_t okn_r40_i2s_space_ok(uint16_t frames);
uint8_t okn_r40_i2s_push(uint16_t frames);
#endif
