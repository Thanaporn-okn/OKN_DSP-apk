#ifndef OKN_EQ7_H
#define OKN_EQ7_H
#include <stddef.h>
#include <stdint.h>

#define OKN_EQ7_CHANNELS 7u
#define OKN_EQ7_BANDS 15u
#define OKN_EQ7_ID_CH1 30u
#define OKN_EQ7_ID_CH7 36u
#define OKN_EQ7_SLOT_BYTES 16u

void okn_eq7_init(uint32_t sample_rate);
uint8_t okn_eq7_set_peaking(uint8_t ch0, uint8_t band0, uint8_t enabled,
                            float f0_hz, float q, float gain_db);
void okn_eq7_process_mono(uint8_t ch0, int16_t *pcm, size_t samples);
void okn_eq7_process_interleaved_lane(uint8_t ch0, int16_t *pcm,
                                      size_t frames, uint8_t lane, uint8_t lanes);
uint8_t okn_eq7_ufe_write(const uint8_t *req, size_t n);
size_t okn_eq7_ufe_read(const uint8_t *req, size_t n, uint8_t *out, size_t cap);
#endif
