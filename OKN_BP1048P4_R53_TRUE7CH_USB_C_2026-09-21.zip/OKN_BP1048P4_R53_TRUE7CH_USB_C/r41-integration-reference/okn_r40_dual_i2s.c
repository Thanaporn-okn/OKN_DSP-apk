#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include "app_config.h"
#include "audio_core_api.h"
#include "i2s_interface.h"
#include "dma.h"
#include "gpio.h"
#include "okn_r40_dual_i2s.h"
#include "okn_eq7.h"

/* Keep this translation unit on the vendor SDK's unsigned-char bool ABI.
   Only the two bool-free R36 helpers are needed here. */
extern uint16_t okn_r36_gain_q12(uint8_t ch0);
extern void okn_r36_process_i2s16_copy(uint8_t first_ch0,
                                        const int16_t *src,
                                        int16_t *dst,
                                        size_t frames);

#define OKN_R40_MAX_FRAMES 512u
static uint32_t s_i2s0_fifo[OKN_R40_MAX_FRAMES * 2u];
static uint32_t s_i2s1_fifo[OKN_R40_MAX_FRAMES * 2u];
static int16_t  s_i2s0_out[OKN_R40_MAX_FRAMES * 2u];
static int16_t  s_i2s1_out[OKN_R40_MAX_FRAMES * 2u];
static uint16_t s_frames;
static uint8_t s_ready;

static void okn_r40_i2s0_pins(void)
{
    GPIO_PortAModeSet(GPIOA0, 9); /* mclk */
    GPIO_PortAModeSet(GPIOA1, 6); /* lrclk */
    GPIO_PortAModeSet(GPIOA2, 5); /* bclk */
    GPIO_PortAModeSet(GPIOA3, 7); /* dout */
    GPIO_PortAModeSet(GPIOA4, 1); /* din */
}

static void okn_r40_i2s1_pins(void)
{
    GPIO_PortAModeSet(GPIOA7, 5);  /* mclk */
    GPIO_PortAModeSet(GPIOA8, 1);  /* lrclk */
    GPIO_PortAModeSet(GPIOA9, 2);  /* bclk */
    GPIO_PortAModeSet(GPIOA10, 4); /* dout */
    GPIO_PortAModeSet(GPIOA11, 2); /* din */
}

static void okn_r40_init_one(I2S_MODULE module, uint8_t peripheral,
                             void *fifo, uint32_t sample_rate, uint16_t frames)
{
    I2SParamCt p;
    memset(&p, 0, sizeof(p));
    p.IsMasterMode = 0u;
    p.SampleRate = sample_rate;
    p.I2sFormat = I2S_FORMAT_I2S;
    p.I2sBits = I2S_LENGTH_16BITS;
    p.I2sTxRxEnable = 1u;
    p.TxPeripheralID = peripheral;
    p.TxBuf = fifo;
    p.TxLen = (uint16_t)(frames * 8u); /* vendor: two stereo DMA frames */
    AudioI2S_Init(module, &p);
}

void okn_r40_apply_dac_gains(void)
{
    AudioCoreSinkVolSet(AUDIO_DAC0_SINK_NUM,
                        okn_r36_gain_q12(0u), okn_r36_gain_q12(1u));
#ifdef CFG_RES_AUDIO_DACX_EN
    /* CH3 physical lane. Both DACX lanes carry the same gain until R41 routing. */
    AudioCoreSinkVolSet(AUDIO_DACX_SINK_NUM,
                        okn_r36_gain_q12(2u), okn_r36_gain_q12(2u));
#endif
}

void okn_r40_dual_i2s_init(uint32_t sample_rate, uint16_t frames)
{
    if ((frames == 0u) || (frames > OKN_R40_MAX_FRAMES)) {
        s_ready = 0u;
        return;
    }
    s_frames = frames;
    memset(s_i2s0_fifo, 0, sizeof(s_i2s0_fifo));
    memset(s_i2s1_fifo, 0, sizeof(s_i2s1_fifo));
    memset(s_i2s0_out, 0, sizeof(s_i2s0_out));
    memset(s_i2s1_out, 0, sizeof(s_i2s1_out));
    okn_r40_i2s0_pins();
    okn_r40_i2s1_pins();
    okn_r40_init_one(I2S0_MODULE, PERIPHERAL_ID_I2S0_TX,
                     s_i2s0_fifo, sample_rate, frames);
    okn_r40_init_one(I2S1_MODULE, PERIPHERAL_ID_I2S1_TX,
                     s_i2s1_fifo, sample_rate, frames);
    s_ready = 1u;
    okn_r40_apply_dac_gains();
}

void okn_r40_route_from_dac0(const int16_t *src_lr, uint16_t frames)
{
    if (!s_ready || !src_lr || frames != s_frames) return;
    memcpy(s_i2s0_out, src_lr, (size_t)frames * 2u * sizeof(int16_t));
    memcpy(s_i2s1_out, src_lr, (size_t)frames * 2u * sizeof(int16_t));
    okn_eq7_process_interleaved_lane(3u, s_i2s0_out, frames, 0u, 2u);
    okn_eq7_process_interleaved_lane(4u, s_i2s0_out, frames, 1u, 2u);
    okn_eq7_process_interleaved_lane(5u, s_i2s1_out, frames, 0u, 2u);
    okn_eq7_process_interleaved_lane(6u, s_i2s1_out, frames, 1u, 2u);
    okn_r36_process_i2s16_copy(3u, s_i2s0_out, s_i2s0_out, frames);
    okn_r36_process_i2s16_copy(5u, s_i2s1_out, s_i2s1_out, frames);
}

uint8_t okn_r40_i2s_space_ok(uint16_t frames)
{
    if (!s_ready) return 1u;
    if (frames != s_frames) return 0u;
    return AudioI2S0_DataSpaceLenGet() >= frames &&
           AudioI2S1_DataSpaceLenGet() >= frames;
}

uint8_t okn_r40_i2s_push(uint16_t frames)
{
    if (!s_ready) return 1u;
    if (!okn_r40_i2s_space_ok(frames)) return 0u;
    AudioI2S0_DataSet(s_i2s0_out, frames);
    AudioI2S1_DataSet(s_i2s1_out, frames);
    return 1u;
}
