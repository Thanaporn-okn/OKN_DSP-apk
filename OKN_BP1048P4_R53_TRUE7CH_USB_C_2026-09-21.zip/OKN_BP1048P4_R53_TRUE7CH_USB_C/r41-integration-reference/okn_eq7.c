#include "okn_eq7.h"
#include <math.h>
#include <string.h>

#define OKN_EQ7_WRITE 0x57u
#define OKN_EQ7_READ 0x58u
#define OKN_EQ7_READ_RESPONSE 0x60u
#define OKN_PI_F 3.14159265358979323846f

typedef struct {
    uint8_t enabled;
    float f0_hz, q, gain_db;
    float b0, b1, b2, a1, a2;
    float z1, z2;
} okn_eq7_band_t;

typedef struct {
    uint32_t sample_rate;
    okn_eq7_band_t band[OKN_EQ7_CHANNELS][OKN_EQ7_BANDS];
} okn_eq7_state_t;

static okn_eq7_state_t g_eq7;

static uint16_t r16be(const uint8_t *p){return (uint16_t)(((uint16_t)p[0]<<8)|p[1]);}
static uint32_t r32be(const uint8_t *p){return ((uint32_t)p[0]<<24)|((uint32_t)p[1]<<16)|((uint32_t)p[2]<<8)|p[3];}
static uint32_t r32le(const uint8_t *p){return (uint32_t)p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);}
static void w16be(uint8_t *p,uint16_t v){p[0]=(uint8_t)(v>>8);p[1]=(uint8_t)v;}
static void w32be(uint8_t *p,uint32_t v){p[0]=(uint8_t)(v>>24);p[1]=(uint8_t)(v>>16);p[2]=(uint8_t)(v>>8);p[3]=(uint8_t)v;}
static void w32le(uint8_t *p,uint32_t v){p[0]=(uint8_t)v;p[1]=(uint8_t)(v>>8);p[2]=(uint8_t)(v>>16);p[3]=(uint8_t)(v>>24);}
static float rf32le(const uint8_t *p){uint32_t u=r32le(p);float f;memcpy(&f,&u,4);return f;}
static void wf32le(uint8_t *p,float f){uint32_t u;memcpy(&u,&f,4);w32le(p,u);}

static int16_t sat16f(float x)
{
    int32_t v;
    if (x > 32767.0f) return 32767;
    if (x < -32768.0f) return -32768;
    v=(int32_t)(x >= 0.0f ? x + 0.5f : x - 0.5f);
    return (int16_t)v;
}

static void identity(okn_eq7_band_t *b)
{
    b->b0=1.0f; b->b1=0.0f; b->b2=0.0f; b->a1=0.0f; b->a2=0.0f;
    b->z1=0.0f; b->z2=0.0f;
}

void okn_eq7_init(uint32_t sample_rate)
{
    uint8_t ch,band;
    memset(&g_eq7,0,sizeof(g_eq7));
    g_eq7.sample_rate=sample_rate ? sample_rate : 48000u;
    for(ch=0;ch<OKN_EQ7_CHANNELS;ch++) for(band=0;band<OKN_EQ7_BANDS;band++) {
        g_eq7.band[ch][band].f0_hz=1000.0f;
        g_eq7.band[ch][band].q=1.0f;
        g_eq7.band[ch][band].gain_db=0.0f;
        identity(&g_eq7.band[ch][band]);
    }
}

uint8_t okn_eq7_set_peaking(uint8_t ch0, uint8_t band0, uint8_t enabled,
                            float f0_hz, float q, float gain_db)
{
    okn_eq7_band_t *b;
    float fs,A,w,alpha,c,a0;
    if(ch0>=OKN_EQ7_CHANNELS || band0>=OKN_EQ7_BANDS || enabled>1u) return 0u;
    if(!(f0_hz==f0_hz) || !(q==q) || !(gain_db==gain_db)) return 0u;
    fs=(float)(g_eq7.sample_rate ? g_eq7.sample_rate : 48000u);
    if(f0_hz<20.0f || f0_hz>(fs*0.5f-50.0f) || q<0.10f || q>20.0f || gain_db<-18.0f || gain_db>18.0f) return 0u;
    b=&g_eq7.band[ch0][band0];
    b->enabled=enabled; b->f0_hz=f0_hz; b->q=q; b->gain_db=gain_db;
    b->z1=0.0f; b->z2=0.0f;
    if(!enabled){identity(b);return 1u;}
    A=powf(10.0f,gain_db/40.0f);
    w=2.0f*OKN_PI_F*f0_hz/fs;
    alpha=sinf(w)/(2.0f*q);
    c=cosf(w);
    a0=1.0f+alpha/A;
    b->b0=(1.0f+alpha*A)/a0;
    b->b1=(-2.0f*c)/a0;
    b->b2=(1.0f-alpha*A)/a0;
    b->a1=(-2.0f*c)/a0;
    b->a2=(1.0f-alpha/A)/a0;
    return 1u;
}

static float run_band(okn_eq7_band_t *b,float x)
{
    float y=b->b0*x+b->z1;
    b->z1=b->b1*x-b->a1*y+b->z2;
    b->z2=b->b2*x-b->a2*y;
    return y;
}

static int16_t run_sample(uint8_t ch0,int16_t x)
{
    uint8_t band; float y=(float)x;
    for(band=0;band<OKN_EQ7_BANDS;band++) if(g_eq7.band[ch0][band].enabled) y=run_band(&g_eq7.band[ch0][band],y);
    return sat16f(y);
}

void okn_eq7_process_mono(uint8_t ch0,int16_t *pcm,size_t samples)
{
    size_t i; if(!pcm||ch0>=OKN_EQ7_CHANNELS)return;
    for(i=0;i<samples;i++) pcm[i]=run_sample(ch0,pcm[i]);
}

void okn_eq7_process_interleaved_lane(uint8_t ch0,int16_t *pcm,size_t frames,uint8_t lane,uint8_t lanes)
{
    size_t i,pos; if(!pcm||ch0>=OKN_EQ7_CHANNELS||lanes==0u||lane>=lanes)return;
    for(i=0;i<frames;i++){pos=i*lanes+lane;pcm[pos]=run_sample(ch0,pcm[pos]);}
}

static int ch_from_id(uint32_t id){if(id<OKN_EQ7_ID_CH1||id>OKN_EQ7_ID_CH7)return -1;return (int)(id-OKN_EQ7_ID_CH1);}

uint8_t okn_eq7_ufe_write(const uint8_t *req,size_t n)
{
    uint32_t id,en;uint16_t off,len;int ch;uint8_t band;
    if(!req||n!=25u||req[0]!=OKN_EQ7_WRITE)return 0u;
    id=r32be(req+1);off=r16be(req+5);len=r16be(req+7);ch=ch_from_id(id);
    if(ch<0||len!=OKN_EQ7_SLOT_BYTES||(off%OKN_EQ7_SLOT_BYTES)!=0u)return 0u;
    band=(uint8_t)(off/OKN_EQ7_SLOT_BYTES);if(band>=OKN_EQ7_BANDS)return 0u;
    en=r32le(req+9);if(en>1u)return 0u;
    return okn_eq7_set_peaking((uint8_t)ch,band,(uint8_t)en,rf32le(req+13),rf32le(req+17),rf32le(req+21));
}

size_t okn_eq7_ufe_read(const uint8_t *req,size_t n,uint8_t *out,size_t cap)
{
    uint32_t id;uint16_t off,len;int ch;uint8_t band;okn_eq7_band_t *b;
    if(!req||!out||n!=9u||cap<25u||req[0]!=OKN_EQ7_READ)return 0u;
    id=r32be(req+1);off=r16be(req+5);len=r16be(req+7);ch=ch_from_id(id);
    if(ch<0||len!=OKN_EQ7_SLOT_BYTES||(off%OKN_EQ7_SLOT_BYTES)!=0u)return 0u;
    band=(uint8_t)(off/OKN_EQ7_SLOT_BYTES);if(band>=OKN_EQ7_BANDS)return 0u;
    b=&g_eq7.band[ch][band];
    out[0]=OKN_EQ7_READ_RESPONSE;w32be(out+1,id);w16be(out+5,off);w16be(out+7,OKN_EQ7_SLOT_BYTES);
    w32le(out+9,(uint32_t)b->enabled);wf32le(out+13,b->f0_hz);wf32le(out+17,b->q);wf32le(out+21,b->gain_db);
    return 25u;
}
