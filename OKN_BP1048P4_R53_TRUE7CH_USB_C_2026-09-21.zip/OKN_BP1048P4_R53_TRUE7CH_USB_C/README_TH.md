# OKN BP1048P4 R53 — TRUE 7CH DSP + Samsung S25+ USB-C

ชุดนี้ต่อจากข้อมูล R36/R41/R46/R50 ใน archive ที่ให้มา โดยยึดเงื่อนไขหลัก:

- **ไม่ใช้ EQ ทำ Gain/Volume**
- Gain 7 ช่องเป็น state/processing stage แยกจาก PEQ โดยเด็ดขาด
- ไม่ต้องแก้ hardware
- เป้าหมาย runtime: Samsung S25+ USB-C -> custom HID IF4 -> firmware -> Gain CH1..CH7
- เป้าหมาย update: direct USB-C จากมือถือ แต่ต้องผ่าน boot/image/recovery gate ก่อนจึงเปิดเขียน flash

## สิ่งที่เขียนใหม่ใน R53

1. `firmware-core/firmware/src/okn_r36_sdk_bridge.c`
   - dedicated Gain 7CH เดิม Q2.14 ช่วง -70..+6 dB, step 0.5 dB
   - CH4..CH7 เพิ่ม 128-frame gain ramp ลด click/pop
   - ไม่มีการแตะ EQ coefficient ใน gain path
   - DAC CH1..CH3 ใช้ vendor sink volume path; default 0 dB = 4095 ตาม convention ของ SDK
   - exact arithmetic unity 4096 เปิดได้ด้วย `OKN_R53_DAC_EXACT_Q12_UNITY=1` สำหรับบอร์ดทดลองเท่านั้น

2. `r41-integration-reference/`
   - 7x15 PEQ แยก CH1..CH7
   - EQ IDs 30..36
   - Gain IDs 22..28
   - ลำดับ processing = **EQ -> dedicated gain**
   - routing: CH1 DAC0L, CH2 DAC0R, CH3 DACX/bass, CH4 I2S0L, CH5 I2S0R, CH6 I2S1L, CH7 I2S1R

3. `android-controller/`
   - Android USB Host controller สำหรับ S25+
   - target VID:PID 6324:1719, IF4
   - slider 7 ช่อง -70..+6 dB / 0.5 dB
   - WRITE `0x57`, READ `0x58`, response `0x60`
   - อ่านกลับ 7 ช่องเพื่อยืนยัน firmware state ไม่ใช่ดูแค่ USB transfer return code

4. `.github/workflows/`
   - `android-controller.yml`: build APK ด้วย JDK17 + Gradle 8.10.2 + compileSdk35
   - `firmware-r53-build-not-for-flash.yml`: target compile/link จาก public BP1048 SDK commit ที่ pin ไว้ และออกหลักฐาน `.adx/.bin/.map`
   - output firmware ยังตั้งชื่อ `NOT_FOR_FLASH` โดยตั้งใจ จน metadata/layout/recovery proof ครบ

5. `tools/r53_image_gate.py`
   - read-only image checker
   - ตรวจ magic `0xB0BEBDC9`, code CRC field @ +0xBC, code length @ +0xE0..E3
   - **ไม่ patch image และไม่เขียน flash**

## Runtime packet ที่ S25+ ส่ง

Gain CH1..CH7 ใช้ ID 22..28:

`A5 5A 57 0C [id32 BE] [offset=0000] [len=0004] [float dB LE] 16`

อ่านกลับ:

`A5 5A 58 08 [id32 BE] 0000 0004 16`

response:

`A5 5A 60 0C [id32 BE] 0000 0004 [float dB LE] 16`

ตัวอย่าง packet ดู `tools/make_gain_report.py`.

## สถานะ direct flash จาก stock board

**ยังปิด gate อยู่** ไม่ใช่เพราะ 7CH DSP ทำไม่ได้ แต่เพราะจุด bootstrap/update ของ stock production board ยังไม่มี proof ที่พอจะเขียน flash อย่างรับผิดชอบ:

- live board เคยตอบ Feature arm `AA -> 55` แต่ไม่ detach/re-enumerate เข้า flashboot
- source vendor มีสองเงื่อนไขที่อธิบายอาการนี้ได้: production อาจ compile `FLASH_BOOT_EN=0` หรือ resource `AppResourceUsbDevice` ไม่ ready ตอนเรียก `start_up_grate()`
- flashboot command ที่ reverse ได้ทั้ง 8 ตัวมี side effect; ไม่มี identity/readback command ที่พิสูจน์ว่า strict read-only
- ยังไม่มี stock full 4 MiB readback + production flash layout proof
- R41 reference image เองยังมี CRC/length metadata ของ application header เป็น `FF`, จึงห้ามเอาไปเขียน

ดังนั้น **controller 7CH พร้อมแล้ว**, **target build พร้อมให้รัน**, แต่ “มือถือ stock-board -> program flash” ยังไม่ควรเปิดจนแก้ boot handoff + image metadata + recovery proof ครบ.

## ทดสอบแล้ว

รัน `firmware-core/tests/run_host_tests.sh` ผ่านทั้งหมด รวม:
- 7CH isolation
- no-EQ-as-gain guard
- runtime protocol guards
- I2S ramp
- DAC 4095 vendor convention + optional 4096 exact-unity compile mode
- reverse/flash safety gates R16..R36

ดูผล gate ของ R41 ที่ `evidence/R53_IMAGE_GATE_ON_R41_REFERENCE.json`.
