# V31 target linker/memory evidence intake

V31 adds a read-only parser for a future **exact BP1048P4** linker script or text map.
The parser hashes the supplied file and records literal `MEMORY` region declarations.
It does not run a compiler/linker, execute target code, touch hardware, infer macro
expressions, or authorize RAM/Flash capacity or placement.

The shipped `target_memory_report.json` intentionally contains **no addresses or sizes**.
Public listings for an exact-model BP1048P4 datasheet and BP-series development/debug
hardware are research leads only until the actual files/packages are ingested, hashed,
and reviewed through the qualification bundle.

Example for a future reviewed exact-target linker artifact:

```sh
python3 tools/target_memory_intake.py \
  --input path/to/reviewed_exact_bp1048p4.ld \
  --classification EXACT_TARGET --reviewed \
  --output target_memory_candidate.json
```

Even that output remains non-authorizing. A separate reviewed claim must identify the
correct RAM region, confirm the chip/board provenance, and map the delay/persistence
workspace before any target port can be enabled.
