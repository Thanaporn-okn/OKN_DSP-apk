# V31 Vendor SDK Adapter Conformance Contract

V31 adds a compile-only harness for a future reviewed BP1048P4/GoloPine SDK binding shim.

The harness can prove only that a shim is syntactically compatible with the adapter-facing
contract. It **cannot** prove chip identity, board routing, memory map, image format,
programmer transport, recovery behavior, or electrical safety. Therefore a compile PASS
never authorizes runtime hardware access or flashing.

The shipped `vendor_sdk_binding_manifest.json` is intentionally locked and contains no
vendor header or symbol mapping. A family/B1-shaped fixture is accepted for ABI-shape
testing but is deliberately rejected when exact-target acceptance is requested. A
synthetic exact fixture exists only to regression-test the gate and is never evidence.

The conformance probe is compile-only (`-c`): no linker, no target execution, no `.bin`,
and no programmer/hardware I/O.
