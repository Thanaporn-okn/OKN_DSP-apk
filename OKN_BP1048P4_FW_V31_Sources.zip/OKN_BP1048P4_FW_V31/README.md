# OKN_BP1048P4_FW_V31

V31 is a target-memory evidence-intake hardening revision of the portable clean-room
firmware foundation. Protocol V2 and persistence schema 2 remain unchanged.

## What V31 adds

- Read-only `target_memory_intake.py` for future exact BP1048P4 linker/map artifacts.
- SHA-256 binding of the supplied linker/map input before any values are recorded.
- Literal-only GNU `MEMORY` region parsing; macro/arithmetic expressions are not inferred.
- Shipped `target_memory_report.json` contains no target address or capacity values.
- Family/B1 linker evidence remains non-authorizing even if it parses successfully.
- Public research records an exact-model `BP1048P4数据手册_V0.8.pdf` download listing and a BP-series debugger/development-tool listing, but neither listing authorizes hardware without the actual reviewed artifact/package.
- V30 GitHub validation is bound as the immediate predecessor.

## Safety status

This package is **not** a BP1048P4/GoloPine flash image. It emits no programmer packet,
does not invoke a target linker, and contains no guessed BP1048P4 address/pin/memory
value. Hardware and mobile flashing remain locked.

Run:

```sh
make host-test
```
