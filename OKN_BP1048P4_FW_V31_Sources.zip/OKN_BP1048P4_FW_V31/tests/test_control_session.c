#include "../src/transport/okn_control_session.h"
#include <assert.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

static void write_f32_le(uint8_t *p, float f) {
    uint32_t u;
    memcpy(&u, &f, sizeof(u));
    p[0]=(uint8_t)u; p[1]=(uint8_t)(u>>8); p[2]=(uint8_t)(u>>16); p[3]=(uint8_t)(u>>24);
}

static size_t finish_pkt(uint8_t *p, uint8_t cmd, uint16_t plen) {
    p[0]='O'; p[1]='K'; p[2]=OKN_PROTO_VERSION; p[3]=cmd;
    p[4]=(uint8_t)plen; p[5]=(uint8_t)(plen>>8);
    const uint16_t crc=okn_crc16_ccitt(p,6u+plen);
    p[6u+plen]=(uint8_t)crc; p[7u+plen]=(uint8_t)(crc>>8);
    return 8u+plen;
}

static size_t make_set_gain(uint8_t *p, uint8_t ch, float db) {
    p[6]=ch; write_f32_le(&p[7],db);
    return finish_pkt(p,OKN_CMD_SET_CH_GAIN,5u);
}

int main(void) {
    okn_controller_t ctl;
    okn_control_session_t session;
    uint8_t req[32], rsp1[OKN_CONTROL_MAX_FRAME], rsp2[OKN_CONTROL_MAX_FRAME];
    okn_controller_init(&ctl);
    okn_control_session_init(&session,&ctl);

    /* First execution mutates once and caches the response. */
    size_t n=make_set_gain(req,2u,-8.0f);
    const uint32_t rev0=ctl.revision;
    okn_control_session_result_t a=okn_control_session_execute(&session,req,n,rsp1,sizeof(rsp1));
    assert(a.protocol.transport_status==OKN_OK && a.protocol.command_status==OKN_OK);
    assert(!a.duplicate_replayed && a.protocol.response_len>0u);
    assert(ctl.revision==rev0+1u && fabsf(ctl.state.ch[2].gain_db+8.0f)<0.0001f);
    assert(session.executed_requests==1u && session.duplicate_replays==0u);

    /* Exact retry is replayed byte-for-byte and does not mutate/revise again. */
    const uint32_t rev1=ctl.revision;
    okn_control_session_result_t b=okn_control_session_execute(&session,req,n,rsp2,sizeof(rsp2));
    assert(b.protocol.transport_status==OKN_OK && b.duplicate_replayed);
    assert(ctl.revision==rev1 && b.protocol.response_len==a.protocol.response_len);
    assert(memcmp(rsp1,rsp2,b.protocol.response_len)==0);
    assert(session.executed_requests==1u && session.duplicate_replays==1u);

    /* A negative ACK is also cacheable/replayable without side effects. */
    n=make_set_gain(req,7u,-3.0f);
    const uint32_t rev2=ctl.revision;
    a=okn_control_session_execute(&session,req,n,rsp1,sizeof(rsp1));
    assert(a.protocol.transport_status==OKN_OK && a.protocol.command_status==OKN_ERR_ARG);
    assert(!a.duplicate_replayed && ctl.revision==rev2);
    b=okn_control_session_execute(&session,req,n,rsp2,sizeof(rsp2));
    assert(b.protocol.transport_status==OKN_OK && b.protocol.command_status==OKN_ERR_ARG);
    assert(b.duplicate_replayed && ctl.revision==rev2);

    /* An undersized caller response buffer must not cause a SET to be applied
     * twice. The session internally caches the full ACK, then a retry can fetch
     * it without re-evaluating the command. */
    n=make_set_gain(req,1u,-5.5f);
    const uint32_t rev3=ctl.revision;
    a=okn_control_session_execute(&session,req,n,rsp1,4u);
    assert(a.protocol.transport_status==OKN_ERR_BUFFER);
    assert(a.protocol.command_evaluated && a.protocol.command_status==OKN_OK);
    assert(a.required_response_len>4u && a.protocol.response_len==0u);
    assert(ctl.revision==rev3+1u);
    b=okn_control_session_execute(&session,req,n,rsp2,sizeof(rsp2));
    assert(b.protocol.transport_status==OKN_OK && b.duplicate_replayed);
    assert(ctl.revision==rev3+1u && b.protocol.response_len==b.required_response_len);


    /* Read-only capability queries are also cacheable and never change DSP
     * revision/state. This lets Android retry a lost capability response
     * without ambiguity before enabling controls. */
    n=finish_pkt(req,OKN_CMD_GET_CAPABILITIES,0u);
    const uint32_t rev_cap=ctl.revision;
    a=okn_control_session_execute(&session,req,n,rsp1,sizeof(rsp1));
    assert(a.protocol.transport_status==OKN_OK && a.protocol.command_status==OKN_OK);
    assert(!a.duplicate_replayed && rsp1[3]==OKN_CMD_CAPABILITIES);
    assert(ctl.revision==rev_cap);
    b=okn_control_session_execute(&session,req,n,rsp2,sizeof(rsp2));
    assert(b.protocol.transport_status==OKN_OK && b.duplicate_replayed);
    assert(b.protocol.response_len==a.protocol.response_len);
    assert(memcmp(rsp1,rsp2,b.protocol.response_len)==0);
    assert(ctl.revision==rev_cap);

    /* Corrupt frames are never cached, because no command was evaluated. */
    uint8_t corrupt[32];
    memcpy(corrupt,req,n); corrupt[n-1u]^=1u;
    const uint32_t executed_before=session.executed_requests;
    a=okn_control_session_execute(&session,corrupt,n,rsp1,sizeof(rsp1));
    assert(a.protocol.transport_status==OKN_ERR_CRC && !a.protocol.command_evaluated);
    assert(session.executed_requests==executed_before);

    /* Cache scope is the current connection/session only. Disconnect reset
     * deliberately allows the same command to execute in a new session. */
    n=make_set_gain(req,4u,-4.0f);
    a=okn_control_session_execute(&session,req,n,rsp1,sizeof(rsp1));
    assert(a.protocol.transport_status==OKN_OK && !a.duplicate_replayed);
    const uint32_t rev4=ctl.revision;
    okn_control_session_reset(&session);
    assert(!session.cache_valid);
    b=okn_control_session_execute(&session,req,n,rsp2,sizeof(rsp2));
    assert(b.protocol.transport_status==OKN_OK && !b.duplicate_replayed);
    assert(ctl.revision==rev4+1u);

    puts("ALL V31 CONTROL-SESSION TESTS PASS");
    return 0;
}
