#include "../src/runtime/okn_runtime.h"
#include <assert.h>
#include <stdio.h>

static unsigned events[32], event_count;
static int fail_channel = -1;
static void ev(unsigned n){ events[event_count++]=n; }
static int h_init(void){ev(1);return OKN_OK;}
static int h_mute(bool on){ev(on?2:7);return OKN_OK;}
static int h_audio(void){ev(3);return OKN_OK;}
static int h_master(float db){(void)db;ev(4);return OKN_OK;}
static int h_channel(unsigned ch,const okn_channel_state_t *s){(void)s;ev(5);return ((int)ch==fail_channel)?OKN_ERR_HAL:OKN_OK;}
static int h_notify(const uint8_t *p,size_t n){(void)p;(void)n;return OKN_OK;}
static const bp1048p4_hal_t H={
 .platform_init=h_init,.set_output_safety_mute=h_mute,.audio_start=h_audio,
 .apply_master_gain=h_master,.apply_channel_state=h_channel,.ble_notify=h_notify
};
static const bp1048p4_port_evidence_t E={
 .magic=BP1048P4_PORT_EVIDENCE_MAGIC,.abi_version=BP1048P4_PORT_ABI_VERSION,
 .bp1048p4_target_verified=true,.board_profile_verified=true,
 .platform_init_verified=true,.platform_init_output_safe_verified=true,
 .output_safety_mute_verified=true,.audio_path_verified=true,
 .ble_path_verified=false,.storage_path_verified=false
};

int main(void){
 okn_controller_t ctl; okn_boot_report_t r;
 assert(bp1048p4_hal_validate_contract(bp1048p4_hal_get(),bp1048p4_port_evidence_get())==OKN_ERR_HAL_LOCKED);

/* platform_init is the first hardware callback. V13 therefore requires
    * evidence that this callback itself leaves outputs safe/inactive. */
 bp1048p4_port_evidence_t unsafe_init=E;
 unsafe_init.platform_init_output_safe_verified=false;
 event_count=0; fail_channel=-1;
 assert(bp1048p4_hal_validate_contract(&H,&unsafe_init)==OKN_ERR_HAL_LOCKED);
 assert(okn_runtime_boot_safe(&ctl,&H,&unsafe_init,NULL,&r)==OKN_ERR_HAL_LOCKED);
 assert(event_count==0u); /* no hardware callback before evidence gate passes */

 event_count=0; fail_channel=-1;
 assert(okn_runtime_boot_safe(&ctl,&H,&E,NULL,&r)==OKN_OK);
 assert(r.stage==OKN_BOOT_RUNNING && r.failsafe_mute_asserted==0);
 assert(event_count==12u); /* init,mute,audio,master,7ch,unmute */
 assert(events[0]==1u && events[1]==2u && events[2]==3u && events[3]==4u && events[11]==7u);

 event_count=0; fail_channel=2;
 assert(okn_runtime_boot_safe(&ctl,&H,&E,NULL,&r)==OKN_ERR_HAL);
 assert(r.stage==OKN_BOOT_FAILED && r.failsafe_mute_asserted==1);
 assert(events[event_count-1]==2u); /* final action re-asserts failsafe mute */
 puts("ALL V31 SAFE-BOOT TESTS PASS");
 return 0;
}
