#!/usr/bin/env python3
from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'evidence_manifest.json').read_text())
errors=[]
if m.get('schema')!=4: errors.append('evidence schema must be 4')
if m.get('project_version')!=31: errors.append('project_version must be 31')
if m.get('target')!='BP1048P4' or m.get('board')!='GoloPine 7CH': errors.append('target/board mismatch')
if m.get('policy')!='FAIL_CLOSED_NO_INFERENCE': errors.append('policy mismatch')
if m.get('hardware_authorized') is not False: errors.append('hardware_authorized must be false')
req=m.get('required_exact_evidence',{})
if any(bool(v) for v in req.values()): errors.append('V31 exact evidence flags must all remain false')
prov=m.get('provenance',{})
if prov.get('previous_source_sha256')!='addbcf7f26050dce9732312bc92cfa6dfbe127926e4004adb8c69d401c6866f6': errors.append('V30 source provenance mismatch')
if prov.get('validation_zip_sha256')!='8e82a91201b8ea458a6a5833898486ebfe5df7a8859eec517aa934f2dcd62a04': errors.append('V30 validation provenance mismatch')
if not any(o.get('id')=='v30-ci-validation' for o in m.get('observations',[])): errors.append('V30 CI observation missing')
for ob in m.get('observations',[]):
    if ob.get('authorizes') not in ([],None): errors.append('observations may not authorize hardware in V31')
if errors:
    [print('BLOCKED:',e) for e in errors]; sys.exit(1)
print('PASS: V31 evidence manifest is internally consistent and non-authorizing')
