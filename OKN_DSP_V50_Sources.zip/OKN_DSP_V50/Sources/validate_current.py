#!/usr/bin/env python3
from pathlib import Path
import runpy
HERE=Path(__file__).resolve().parent
runpy.run_path(str(HERE/'validate_v50_usb_feature_readonly.py'), run_name='__main__')
