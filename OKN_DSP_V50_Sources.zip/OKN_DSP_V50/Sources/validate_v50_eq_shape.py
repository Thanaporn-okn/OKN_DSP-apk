#!/usr/bin/env python3
from pathlib import Path
import json, math, re, sys

root = Path(__file__).resolve().parents[1]
ble = (root/'app/src/main/java/com/okn/dsp/BleManager.java').read_text()
view = (root/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
proto = (root/'app/src/main/java/com/okn/dsp/DspProtocol.java').read_text()
main = (root/'app/src/main/java/com/okn/dsp/MainActivity.java').read_text()
gradle = (root/'app/build.gradle').read_text()
desc = json.loads((root/'Sources/ProtocolEvidence/GoloPine_DeviceDescription_REAL_20260906_204555.json').read_text())

def method(text, marker):
    i=text.index(marker); b=text.index('{',i); depth=0
    for j in range(b,len(text)):
        if text[j]=='{': depth += 1
        elif text[j]=='}':
            depth -= 1
            if depth == 0: return text[i:j+1]
    raise AssertionError('unclosed '+marker)

shape_pump = method(ble, '    private void scheduleEqShapePump(')

checks = {
    'V50 version': "versionCode 1050" in gradle and "versionName '50.0.0'" in gradle,
    'separate frequency writable mask': 'eqFrequencyWritable' in view,
    'separate Q writable mask': 'eqQWritable' in view,
    'listener exposes separate F/Q capabilities': 'boolean gainWritable, boolean frequencyWritable, boolean qWritable' in ble and 'boolean gainWritable, boolean frequencyWritable, boolean qWritable' in main,
    'locked sliders have no touch target': 'collectTouchTargets && enabled' in view,
    'frequency apply guard': 'if (!eqFrequencyWritable[ch][b]) return;' in view,
    'Q apply guard': 'if (!eqQWritable[ch][b]) return;' in view,
    'gain apply guard': 'if (!eqGainWritable[ch][b]) return;' in view,
    'native tone shape builder': 'static EqBand toneControlShapeFromCurrent' in proto,
    'native lowpass shape builder': 'static EqBand generalLowPassShapeFromCurrent' in proto,
    'shape detects changed frequency': 'boolean frequencyChanged' in ble,
    'shape detects changed Q': 'boolean qChanged' in ble,
    'tone control Q explicitly rejected': 'throw new IllegalArgumentException("tone-q")' in ble,
    'tone control path preserves type': 'DspProtocol.toneControlShapeFromCurrent(current, requested.frequency)' in ble,
    'lowpass path supports F/Q': 'DspProtocol.generalLowPassShapeFromCurrent(current, requested.frequency, requested.q)' in ble,
    'placeholder rows still use strict safe gate': 'if (band0 > 0) return b.safePeakingDescriptor();' in ble,
    'shape health gate preserved': 'safePeakingRows == EXPECTED_SAFE_PEAKING_ROWS' in ble,
    'F/Q realtime gap is 110 ms': 'EQ_SHAPE_MIN_GAP_MS = 110L' in ble and 'long shapeGap = EQ_SHAPE_MIN_GAP_MS;' in shape_pump,
    'F/Q pump bypasses 380 ms music settle': 'EQ_INTERACTIVE_MUSIC_SETTLE_MS' not in shape_pump and 'EQ_INTERACTIVE_MUSIC_MIN_GAP_MS' not in shape_pump,
    'Gain music-safe settle preserved': 'EQ_INTERACTIVE_MUSIC_SETTLE_MS = 380L' in ble and 'EQ_INTERACTIVE_MUSIC_MIN_GAP_MS = 380L' in ble,
    'no automatic SaveParams': 'requestPersistentSave()' in ble,
}

# Derive exact writable counts from the supplied real descriptor under V50 policy.
def finite(v): return isinstance(v,(int,float)) and math.isfinite(v)
def safe_peaking(b):
    vals=[b.get(k) for k in ('F','F2','Q','B','G','R','B0','B1','B2','A1','A2')]
    if b.get('typ') != 12 or not all(finite(x) for x in vals): return False
    if not (20 <= b['F'] <= 20000 and .05 <= b['Q'] <= 20 and -24 <= b['B'] <= 24): return False
    if abs(b['R']) > .0001: return False
    identity = abs(b['B0']-1) < .0001 and all(abs(b[k]) < .0001 for k in ('B1','B2','A1','A2'))
    return not identity

f_count=q_count=gain_count=locked=0
ids={4,5,6,14,15,16,17}
for a in desc.get('actuators',[]):
    if a.get('ID') not in ids: continue
    arr=a.get('UFE_TYPE_BIQUAD_CASCADE15_F',[])
    for i,b in enumerate(arr):
        if safe_peaking(b):
            f_count += 1; q_count += 1; gain_count += 1
        elif i == 0 and b.get('typ') == 3:
            f_count += 1; q_count += 1; gain_count += 1
        elif i == 0 and b.get('typ') == 17:
            f_count += 1; gain_count += 1
        else:
            locked += 1

checks['descriptor F writable count=62'] = f_count == 62
checks['descriptor Q writable count=56'] = q_count == 56
checks['descriptor Gain writable count=62'] = gain_count == 62
checks['descriptor unsafe placeholder locked count=43'] = locked == 43

# Explicit regression: CH6 Band9 must remain locked.
ch6 = next(a for a in desc['actuators'] if a.get('ID') == 16)['UFE_TYPE_BIQUAD_CASCADE15_F']
checks['CH6 Band9 remains placeholder'] = ch6[8].get('typ') == 12 and abs(ch6[8].get('R',0)-.12) < 1e-6 and not safe_peaking(ch6[8])

for k,v in checks.items(): print(('PASS' if v else 'FAIL'), k)
failed=[k for k,v in checks.items() if not v]
if failed:
    raise SystemExit('V50 validation failed: ' + ', '.join(failed))
print(f'V50_EQ_SHAPE_PASS F={f_count}/105 Q={q_count}/105 Gain={gain_count}/105 locked={locked}/105')
