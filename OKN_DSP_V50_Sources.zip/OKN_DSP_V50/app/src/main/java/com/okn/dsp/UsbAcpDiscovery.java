package com.okn.dsp;

import android.content.Context;
import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * V50 USB/HID read-only Feature-report qualification for the real OKN BP1048P4 board.
 *
 * Hardware evidence from V46/V48/V49:
 *   VID 0x6324, PID 0x1719, HID interface 4, no interrupt endpoints.
 *   IF4 HID report descriptor = vendor page 0xFF00 / usage 0x55AA,
 *   256-byte Input + 256-byte Output + 8-byte Feature report.
 *
 * V50 is zero-TX by construction:
 *   - no HID SET_REPORT;
 *   - no ACP/UFE frame;
 *   - no actuator/effect/gain/EQ/SaveParams write;
 *   - only standard GET_DESCRIPTOR and HID GET_REPORT(Feature) IN transfers;
 *   - claimInterface(..., false) only.
 */
public final class UsbAcpDiscovery {
    public static final int TARGET_VID = 0x6324;
    public static final int TARGET_PID = 0x1719;
    public static final int TARGET_INTERFACE = 4;

    private static final int USB_RECIP_INTERFACE = 0x01;
    private static final int USB_REQ_GET_DESCRIPTOR = 0x06;
    private static final int HID_REQ_GET_REPORT = 0x01;
    private static final int HID_DT_REPORT = 0x22;
    private static final int HID_REPORT_TYPE_FEATURE = 0x03;
    private static final int FEATURE_REPORT_SIZE = 8;
    private static final int IO_TIMEOUT_MS = 1000;

    private UsbAcpDiscovery() {}

    public static UsbDevice findTarget(Context context) {
        UsbManager manager = (UsbManager) context.getSystemService(Context.USB_SERVICE);
        if (manager == null) return null;
        Map<String, UsbDevice> map = manager.getDeviceList();
        if (map == null || map.isEmpty()) return null;
        UsbDevice pid1719Fallback = null;
        for (UsbDevice d : map.values()) {
            if (d == null) continue;
            if (d.getVendorId() == TARGET_VID && d.getProductId() == TARGET_PID && hasTargetHidInterface(d)) return d;
            if (d.getProductId() == TARGET_PID && hasTargetHidInterface(d)) pid1719Fallback = d;
        }
        return pid1719Fallback;
    }

    public static String summary(Context context) {
        UsbManager manager = (UsbManager) context.getSystemService(Context.USB_SERVICE);
        if (manager == null) return "UsbManager unavailable";
        UsbDevice d = findTarget(context);
        if (d == null) return "target 0x6324:0x1719 IF4 not detected";
        return String.format(Locale.US, "%04X:%04X IF4 FEATURE-READ permission=%s",
                d.getVendorId(), d.getProductId(), manager.hasPermission(d) ? "yes" : "no");
    }

    public static String buildEnumerationReport(Context context) {
        UsbManager manager = (UsbManager) context.getSystemService(Context.USB_SERVICE);
        StringBuilder out = new StringBuilder(3072);
        out.append("OKN DSP V50 — USB HID Feature discovery\n")
                .append("ZERO TX: descriptors + Feature GET_REPORT only.\n\n");
        if (manager == null) return out.append("UsbManager unavailable on this device.").toString();
        Map<String, UsbDevice> map = manager.getDeviceList();
        if (map == null || map.isEmpty()) return out.append("No USB device detected.\n").toString();
        List<String> keys = new ArrayList<>(map.keySet());
        Collections.sort(keys);
        out.append("Detected devices: ").append(keys.size()).append("\n\n");
        int n=0;
        for (String key: keys) {
            UsbDevice d=map.get(key); if (d==null) continue; n++;
            out.append('#').append(n).append(' ')
                    .append(String.format(Locale.US,"VID=%04X PID=%04X",d.getVendorId(),d.getProductId()))
                    .append(" ifaces=").append(d.getInterfaceCount())
                    .append(" permission=").append(manager.hasPermission(d)?"yes":"no")
                    .append(isExactTarget(d)?"  <V50 TARGET>":(isTransportCandidate(d)?"  <candidate>":""))
                    .append('\n');
            appendInterfaces(out,d); out.append('\n');
        }
        return out.toString();
    }

    /** Requires explicit Android USB permission. Performs IN-only transfers. */
    public static String buildAcpCatalogProbe(Context context, UsbDevice requestedDevice) {
        UsbManager manager = (UsbManager) context.getSystemService(Context.USB_SERVICE);
        StringBuilder out = new StringBuilder(8192);
        out.append("OKN DSP V50 — IF4 HID FEATURE READ-ONLY probe\n")
                .append("SAFETY: USB OUT=0; SET_REPORT=0; ACP/UFE TX=0; DSP writes=0; SaveParams=0.\n")
                .append("Only GET_DESCRIPTOR(report) and GET_REPORT(Feature, 8 bytes) are used.\n\n");
        if (manager == null) return out.append("UsbManager unavailable.").toString();
        UsbDevice d = requestedDevice != null ? requestedDevice : findTarget(context);
        if (d == null) return out.append("Target 0x6324:0x1719 IF4 HID not detected.").toString();
        out.append(String.format(Locale.US,"Target VID=%04X PID=%04X interfaces=%d\n",d.getVendorId(),d.getProductId(),d.getInterfaceCount()));
        if (d.getProductId()!=TARGET_PID || !hasTargetHidInterface(d)) return out.append("FAIL-CLOSED: PID/IF4 mismatch.\n").toString();
        if (!manager.hasPermission(d)) return out.append("USB permission=no. No device connection opened.\n").toString();
        out.append("USB permission=yes\n");
        UsbInterface hid=findInterface(d,TARGET_INTERFACE);
        if (hid==null || hid.getInterfaceClass()!=UsbConstants.USB_CLASS_HID) return out.append("FAIL-CLOSED: IF4 missing/not HID.\n").toString();
        out.append("IF4 class=HID sub=").append(hid.getInterfaceSubclass()).append(" proto=").append(hid.getInterfaceProtocol()).append(" endpoints=").append(hid.getEndpointCount()).append('\n');
        UsbDeviceConnection conn=manager.openDevice(d);
        if (conn==null) return out.append("openDevice failed.\n").toString();
        boolean claimed=false;
        try {
            claimed=conn.claimInterface(hid,false);
            out.append("claim IF4 force=false => ").append(claimed?"OK":"FAILED").append(" (force=true forbidden)\n");
            if(!claimed) return out.append("FAIL-CLOSED: IF4 not claimed.\n").toString();

            byte[] desc=new byte[128];
            int reportLen=conn.controlTransfer(
                    UsbConstants.USB_DIR_IN | UsbConstants.USB_TYPE_STANDARD | USB_RECIP_INTERFACE,
                    USB_REQ_GET_DESCRIPTOR, HID_DT_REPORT<<8, TARGET_INTERFACE,
                    desc, desc.length, IO_TIMEOUT_MS);
            out.append("\n[1] HID transport gate\nGET_DESCRIPTOR(report) result=").append(reportLen).append('\n');
            if(reportLen>0) out.append("reportDescriptor=").append(hex(desc,reportLen)).append('\n');
            boolean transportOk=looksLikeExpectedAcpHid(desc,reportLen);
            out.append("vendorPageFF00_usage55AA_input256_output256_feature8=").append(transportOk?"YES":"NO").append('\n');
            if(!transportOk) return out.append("FAIL-CLOSED: V48 HID shape not reproduced. No Feature read attempted.\n").toString();

            out.append("\n[2] HID Feature GET_REPORT (IN only)\n")
                    .append("bmRequestType=0xA1 bRequest=0x01 wValue=0x0300 wIndex=4 wLength=8\n");
            byte[] feature=new byte[FEATURE_REPORT_SIZE];
            int got=conn.controlTransfer(
                    UsbConstants.USB_DIR_IN | UsbConstants.USB_TYPE_CLASS | USB_RECIP_INTERFACE,
                    HID_REQ_GET_REPORT, HID_REPORT_TYPE_FEATURE<<8, TARGET_INTERFACE,
                    feature, feature.length, IO_TIMEOUT_MS);
            out.append("GET_REPORT(feature) result=").append(got).append('\n');
            if(got>0) out.append("featureReport=").append(hex(feature,got)).append('\n');
            else out.append("No Feature report payload returned.\n");

            out.append("\nV50 COMPLETE: USB OUT=0; SET_REPORT=0; ACP/UFE TX=0; DSP state unchanged.\n")
                    .append("Copy this full report for the authentication/session decision.");
            return out.toString();
        } catch (RuntimeException e) {
            return out.append("\nProbe exception: ").append(e.getClass().getSimpleName()).append("\nUSB OUT remains 0.\n").toString();
        } finally {
            if(claimed){try{conn.releaseInterface(hid);}catch(RuntimeException ignored){}}
            conn.close();
        }
    }

    private static boolean looksLikeExpectedAcpHid(byte[] d,int len){
        if(d==null||len<36) return false;
        byte[] prefix=new byte[]{0x06,0x00,(byte)0xFF,0x0A,(byte)0xAA,0x55,(byte)0xA1,0x01};
        for(int i=0;i<prefix.length;i++) if(d[i]!=prefix[i]) return false;
        return contains(d,len,new byte[]{0x75,0x08,(byte)0x96,0x00,0x01,0x09,0x01,(byte)0x81,0x02})
            && contains(d,len,new byte[]{(byte)0x96,0x00,0x01,0x09,0x01,(byte)0x91,0x02})
            && contains(d,len,new byte[]{(byte)0x95,0x08,0x09,0x01,(byte)0xB1,0x02});
    }

    private static boolean contains(byte[] h,int len,byte[] n){
        if(h==null||n==null||n.length==0) return false;
        int lim=Math.min(len,h.length)-n.length;
        for(int i=0;i<=lim;i++){boolean ok=true;for(int j=0;j<n.length;j++)if(h[i+j]!=n[j]){ok=false;break;}if(ok)return true;}
        return false;
    }
    private static boolean isExactTarget(UsbDevice d){return d!=null&&d.getVendorId()==TARGET_VID&&d.getProductId()==TARGET_PID&&hasTargetHidInterface(d);}
    private static boolean isTransportCandidate(UsbDevice d){return d!=null&&d.getProductId()==TARGET_PID&&hasTargetHidInterface(d);}
    private static boolean hasTargetHidInterface(UsbDevice d){UsbInterface i=findInterface(d,TARGET_INTERFACE);return i!=null&&i.getInterfaceClass()==UsbConstants.USB_CLASS_HID;}
    private static UsbInterface findInterface(UsbDevice d,int id){if(d==null)return null;for(int i=0;i<d.getInterfaceCount();i++){UsbInterface ui=d.getInterface(i);if(ui!=null&&ui.getId()==id)return ui;}return null;}
    private static void appendInterfaces(StringBuilder out,UsbDevice d){
        for(int i=0;i<d.getInterfaceCount();i++){UsbInterface ui=d.getInterface(i);out.append("  IF ").append(ui.getId()).append(" class=").append(ui.getInterfaceClass()).append(" sub=").append(ui.getInterfaceSubclass()).append(" proto=").append(ui.getInterfaceProtocol()).append(" eps=").append(ui.getEndpointCount());if(ui.getInterfaceClass()==UsbConstants.USB_CLASS_HID)out.append(" HID");out.append('\n');for(int e=0;e<ui.getEndpointCount();e++){UsbEndpoint ep=ui.getEndpoint(e);out.append(String.format(Locale.US,"    EP 0x%02X %s type=%d maxPacket=%d\n",ep.getAddress(),ep.getDirection()==UsbConstants.USB_DIR_IN?"IN":"OUT",ep.getType(),ep.getMaxPacketSize()));}}
    }
    private static String hex(byte[] b,int len){if(b==null||len<=0)return "";int n=Math.min(len,b.length);StringBuilder s=new StringBuilder(n*2);for(int i=0;i<n;i++)s.append(String.format(Locale.US,"%02X",b[i]&0xFF));return s.toString();}
}
