# OKN DSP V50

V50 extends the V49 controller so EQ shape controls reflect what the real DSP descriptor can safely edit in real time.

## V50 EQ behavior
- Strict-safe PEAKING rows: **Frequency + Q + Gain LIVE**.
- CH3 Band 1 (native General Low-pass/type 3): **Frequency + Q + Gain LIVE** using native low-pass coefficient math.
- CH1/CH2/CH4/CH5/CH6/CH7 Band 1 (native Tone Control/type 17): **Frequency + Gain LIVE**. Q is locked because this filter family has no PEQ-Q parameter.
- The 43 descriptor `R=0.12` placeholder/bypass rows remain locked. The supplied V38 hardware evidence correlates unsafe writes to these rows with severe pumping/reboot (notably CH6 Band9).
- Locked sliders are visually marked and do not accept touch, so the UI no longer appears to change a value that was not sent to hardware.
- The serialized BLE/AES-CFB8 write path is retained. F/Q uses the 110 ms realtime lane even during music; Gain keeps the V45 music-safe settle policy.
- No automatic SaveParams is added.

For the supplied real descriptor this means Frequency is hardware-writable on 62/105 rows, Q on 56/105 rows, and the remaining 43 placeholder rows stay protected.

## Build
Use `.github/workflows/OKN_DSP_AutoBuild.yml`. V50 runs the V38, V39 and V50 validators before building the signed Release APK.
