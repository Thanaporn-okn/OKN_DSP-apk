# OKN DSP V50 — BP1048P4 IF4 HID Feature Read-Only Qualification

V50 follows the real-board V48/V49 evidence.

## Why V50 exists

V48 proved that the physical 0x6324:0x1719 board exposes HID interface 4 with vendor Usage Page 0xFF00 / Usage 0x55AA, 256-byte Input, 256-byte Output and an 8-byte Feature report.

V49 sent one known Generic BP10 ACP selector-0 catalog read frame. USB accepted the 256-byte Output Report, but six subsequent Input GET_REPORT requests returned zero bytes. V50 therefore does not transmit another ACP frame and does not guess a write-side handshake.

## V50 probe

The Mix-page button is `USB FEATURE READ (0 TX)`.

After Android USB permission and a non-forcing claim of IF4, V50 first re-reads the HID report descriptor. Only if the V48 descriptor shape is reproduced does it perform one IN-only HID Feature GET_REPORT:

- bmRequestType = 0xA1
- bRequest = 0x01 (GET_REPORT)
- wValue = 0x0300 (Feature, Report ID 0)
- wIndex = 4
- wLength = 8

## Safety

V50 contains no USB OUT control transfer in the probe, no HID SET_REPORT, no ACP/UFE TX frame, no gain/EQ/effect-node write and no SaveParams action. `claimInterface(..., false)` remains mandatory. CH1/2/4/5/6/7 output sliders remain fail-closed; CH3/ID8 is unchanged.
