# OKN DSP V46

V46 is the real-hardware transient fix after V45 video `36944.mp4` showed that a short loud burst can still occur exactly when Out Volume commits, even though the UI is correctly limited to -12..0 dB.

Out Volume remains on the verified safe PEQ Band2 carrier, but **no longer rewrites the full 48-byte PEQ record**. V46 sends only the contiguous `B0/B1/B2` numerator coefficients: 12 bytes at record offset `+28`. For Band2 that is UFE memory offset `76 (0x004C)`, length `12 (0x000C)`. Type, F/F2, Q, B, G, R and A1/A2 are not present in the Out Volume packet.

The attenuation math is unchanged: `k = 10^(dB/20)`, range `-12..0 dB`, UI preview while dragging and one hardware commit on release. Normal EQ and reset behavior remains on the earlier verified paths.

Run `python3 Sources/validate_current.py` before build.
