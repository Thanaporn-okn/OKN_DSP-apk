# OKN DSP V46 — Bass Volume ID8 Extended Test

V46 follows the user's requirement: **Bass Volume only**. It does not increase bass through any EQ band and does not modify Master Volume.

The real DSP descriptor advertises BassVolume as actuator **ID8 / FLOAT32 / -70..+6 dB**. V45 already used the verified ID8 write/readback path, but the user's test still sounded very quiet at +6 dB. V46 therefore performs one controlled diagnostic: the Bass Volume slider can request up to **+12 dB** on ID8 while keeping the exact same UFE FLOAT32 packet.

After the final slider write settles, V46 reads ID8 back from the DSP. If firmware accepts +7..+12, the returned value remains on screen. If firmware clamps at its advertised +6 dB limit, V46 detects the +6 readback, stops retrying, and snaps the UI to the real DSP value. This cleanly distinguishes a firmware limit from an app-slider limit.

No Bass/Sub DSP Gain control exists. No EQ band is used as bass compensation.

Version: **46.0.0** (`versionCode 1046`).
