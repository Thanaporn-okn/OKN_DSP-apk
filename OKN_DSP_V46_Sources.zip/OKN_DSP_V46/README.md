# OKN DSP V46

V46 is based on **V45 Stable**. The V43/V44/V45 audio coexistence fixes are retained unchanged.

## What V46 changes

- **Bass Volume remains hardware-safe:** ID8 stays exactly at the board-declared `-70..+6 dB` range. V46 does not send out-of-range values.
- **Adds Bass Boost:** exposes the already verified scalar actuator **ID10 / BassBoost / -12..+12 dB** as a separate slider.
- **DSP readback:** the Bass Boost slider follows the real ID10 value reported by the board after connect/refresh.
- **No hidden coupling:** moving Bass Volume changes only ID8; moving Bass Boost changes only ID10.
- **EQ is frozen:** V46 does not modify the 7-channel x 15-band EQ mapping, coefficient builders, EQ packet encoder, Safe Reset, V45 interactive EQ coalescing, or BLE EQ write path.
- **Bass Cutoff remains ID9** and unchanged.

## Why this is the safe fix

The real Device Description declares BassVolume (ID8) with max `+6 dB`, so extending ID8 above +6 would be an unverified hardware write. The same descriptor independently declares BassBoost (ID10) with a verified `-12..+12 dB` range. V46 uses that existing scalar instead of changing any EQ band.

Version: **46.0.0** (`versionCode 1046`).
