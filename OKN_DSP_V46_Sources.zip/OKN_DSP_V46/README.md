# OKN DSP V46

V46 is based on V45 and changes **Bass Volume only**.

## V46 audio change
- Bass Volume stays on the existing UFE scalar actuator **ID 8 / BassVolume**.
- Controller range is extended from `-70..+6 dB` to `-70..+74 dB`, matching the user's prior real-board test of this same BassVolume control.
- Default Bass Volume remains `+2 dB`.
- Master Volume remains `-70..+6 dB`.
- **BassBoost ID10 is not used or repurposed.**
- **No EQ actuator mapping, EQ gain/F/Q range, coefficient formula, 48-byte EQ writer, EQ cadence, or Safe Reset behavior is changed.**

The stock device descriptor in `Sources/ProtocolEvidence/` is kept unchanged and still records its advertised BassVolume range (`max=6`). V46 intentionally treats +74 dB as a controller extension supported by the user's prior board test, not as a rewrite of the stock descriptor.

## Build
GitHub Actions workflow: `.github/workflows/OKN_DSP_AutoBuild.yml`. It auto-selects the newest packaged source/repo tree, validates SHA256 + DSP safety invariants, installs Android SDK packages/licenses, builds the signed Release APK and uploads APK + SHA256.
