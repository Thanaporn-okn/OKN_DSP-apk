# OKN DSP V46 — Read-only USB / ACP Transport Discovery

V46 is based on the real V45 hardware result: even a 12-byte B0/B1/B2-only update on CH1
still produces an audible click. Therefore V46 does not expose any CH1/2/4/5/6/7 biquad
probe or output-volume write.

**Normal output control**
- CH3 remains the hardware-confirmed `BassVolume` scalar actuator ID8.
- CH1, CH2, CH4, CH5, CH6 and CH7 remain hardware-write locked.
- No V44 full-record or V45 numerator-only output-gain probe is reachable from the UI.

**New V46 diagnostic**
The Mix page provides `USB / ACP READ-ONLY SCAN`. It enumerates Android USB device
descriptors only: VID, PID, interfaces, endpoint direction/type/max packet size and current
USB permission state. It sends **zero bytes** to the DSP and never opens/claims an interface.

This is the correct next diagnostic because the GoloPine documentation confirms a wired
USB Type-C tuning mode while the verified BLE/UFE descriptor does not publish independent
CH1/2/4/5/6/7 scalar gain actuators. The scan will identify the exact USB transport exposed
by this specific board before any protocol query is attempted.

See `Sources/V46_USB_ACP_READONLY_DISCOVERY.txt`.
