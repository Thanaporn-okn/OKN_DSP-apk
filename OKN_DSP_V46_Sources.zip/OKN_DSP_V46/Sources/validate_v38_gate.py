#!/usr/bin/env python3
import json, math, pathlib, sys
root = pathlib.Path(__file__).resolve().parent.parent
p = root / 'Sources' / 'ProtocolEvidence' / 'GoloPine_DeviceDescription_REAL_20260906_204555.json'
d = json.loads(p.read_text())
ids = [4,5,6,14,15,16,17]
expected = {
  4:[2,3,4,5,6,7,8,9,10,11,12,13],
  5:[2,3,4,5,6,7,8,9,10,11,12,13,14,15],
  6:[2,3,5,6,7],
  14:[2,3,4,5],
  15:[2,4,5],
  16:[2,5,6,11,12,13,14],
  17:[2,4,6,7,10,11,12,13,14,15],
}
def safe(b):
    vals = [b.get(k) for k in ('F','F2','Q','B','G','R','B0','B1','B2','A1','A2')]
    if b.get('typ') != 12 or not all(isinstance(x,(int,float)) and math.isfinite(x) for x in vals): return False
    if not (20 <= b['F'] <= 20000 and .05 <= b['Q'] <= 20 and -24 <= b['B'] <= 24): return False
    if abs(b['R']) > .0001: return False
    identity = abs(b['B0']-1) < .0001 and all(abs(b[k]) < .0001 for k in ('B1','B2','A1','A2'))
    return not identity
found={}
for a in d.get('actuators',[]):
    aid=a.get('ID')
    if aid not in ids: continue
    arr=a.get('UFE_TYPE_BIQUAD_CASCADE15_F',[])
    found[aid]=[i for i,b in enumerate(arr,1) if safe(b)]
if found != expected:
    print('FAIL safe map',found)
    sys.exit(1)
if sum(map(len,found.values())) != 55:
    print('FAIL safe count')
    sys.exit(1)

# Verify that the RBJ peaking equation used by DspProtocol reproduces all 55 live
# safe descriptor rows to the captured float precision.
max_err = 0.0
unsafe_identity = 0
unsafe_total = 0
for a in d.get('actuators',[]):
    if a.get('ID') not in ids: continue
    for b in a.get('UFE_TYPE_BIQUAD_CASCADE15_F',[]):
        if safe(b):
            f,q,boost = float(b['F']), float(b['Q']), round(float(b['B']), 2)
            A = 10 ** (boost / 40.0)
            w0 = 2.0 * math.pi * f / 44100.0
            alpha = math.sin(w0) / (2.0*q)
            a0 = 1.0 + alpha/A
            calc = [(1+alpha*A)/a0, (-2*math.cos(w0))/a0, (1-alpha*A)/a0,
                    (-2*math.cos(w0))/a0, (1-alpha/A)/a0]
            cap = [b['B0'],b['B1'],b['B2'],b['A1'],b['A2']]
            max_err = max(max_err, max(abs(x-y) for x,y in zip(calc,cap)))
        elif b.get('typ') == 12 and abs(float(b.get('R',999)) - .12) < 1e-6:
            unsafe_total += 1
            if abs(float(b['B0'])-1) < 1e-6 and all(abs(float(b[k])) < 1e-6 for k in ('B1','B2','A1','A2')):
                unsafe_identity += 1
if max_err > 3e-5:
    print('FAIL coefficient replay max_err=', max_err)
    sys.exit(1)
if unsafe_total != 43 or unsafe_identity != 43:
    print('FAIL unsafe identity rows',unsafe_total,unsafe_identity)
    sys.exit(1)

# Explicitly protect the row involved in the user's reboot test.
ch6 = next(a for a in d['actuators'] if a.get('ID') == 16)['UFE_TYPE_BIQUAD_CASCADE15_F']
if safe(ch6[8]):
    print('FAIL CH6 Band9 must remain locked')
    sys.exit(1)
print(f'V38_SAFE_PEQ_GATE_PASS count=55 unsafeIdentity=43 coeffMaxErr={max_err:.8g} CH6_B9=LOCKED')
