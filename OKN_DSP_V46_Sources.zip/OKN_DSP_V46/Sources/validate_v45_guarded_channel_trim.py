#!/usr/bin/env python3
from pathlib import Path
import json, re

ROOT = Path(__file__).resolve().parents[1]
BLE = (ROOT/'app/src/main/java/com/okn/dsp/BleManager.java').read_text()
PROTO = (ROOT/'app/src/main/java/com/okn/dsp/DspProtocol.java').read_text()
VIEW = (ROOT/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
GRADLE = (ROOT/'app/build.gradle').read_text()
DESC = json.loads((ROOT/'Sources/ProtocolEvidence/GoloPine_DeviceDescription_REAL_20260906_204555.json').read_text())

def req(ok, msg):
    if not ok: raise AssertionError(msg)

def actuator(i):
    return next(a for a in DESC['actuators'] if int(a['ID']) == i)

def band1(i):
    return actuator(i)['UFE_TYPE_BIQUAD_CASCADE15_F'][0]

req('versionCode 1045' in GRADLE and "versionName '45.0.0'" in GRADLE, 'V45 version mismatch')
req((ROOT/'Sources/VERSION.txt').read_text().splitlines()[:3] == ['OKN DSP V45','versionName=45.0.0','versionCode=1045'], 'VERSION.txt mismatch')

# Descriptor-grounded topology remains unchanged; no guessed scalar volume IDs.
req([int(actuator(i)['ID']) for i in [4,5,6,14,15,16,17]] == [4,5,6,14,15,16,17], 'EQ actuator map changed')
req([int(band1(i)['typ']) for i in [4,5,6,14,15,16,17]] == [17,17,3,17,17,17,17], 'Band1 pattern changed')
volume_scalar_ids=sorted(int(a['ID']) for a in DESC['actuators'] if int(a.get('type',-1)) == 2000 and 'Volume' in a.get('name',''))
req(volume_scalar_ids == [2,3,8], f'unexpected scalar Volume actuator set {volume_scalar_ids}')

# Existing verified mapping only: CH3 -> ID8; other channels -> existing Band1 record.
method = re.search(r'void setChannelTrimRealtime\(.*?\n    \}', BLE, re.S)
req(method, 'setChannelTrimRealtime missing')
t = method.group(0)
req('if (channel0 == 2)' in t and 'DspProtocol.ID_BASS_VOLUME' in t, 'CH3 ID8 path missing')
req('startGuardedChannelTrim(channel0, rounded)' in t, 'non-CH3 guarded path missing')
req('DspProtocol.encodeEqWrite(ch, 1, target)' in BLE, 'full Band1 writer changed')
req('static final int[] EQ_ACTUATORS = {4, 5, 6, 14, 15, 16, 17};' in PROTO, 'verified actuator map changed')
req('static EqBand firstBandCellGainFromCurrent' in PROTO, 'cell-gain builder missing')

# V44 partial record experiment must not be present in production V45 path.
for forbidden in ['encodeChannelTrimPartialWrite', 'CHANNEL_TRIM_PARTIAL_OFFSET', 'offset=20', 'length=20']:
    req(forbidden not in BLE and forbidden not in PROTO, 'V44 partial-write artifact present: '+forbidden)

# Guard sequence: fresh precheck -> verified Master mute -> one full record -> transient hold -> fresh postcheck -> restore.
for token in [
    'startDescriptorRequest("TRIM_PRECHECK")',
    'CHANNEL_TRIM_GUARD_MUTE_DB = -70.0f',
    'CHANNEL_TRIM_MUTE_SETTLE_MS = 450L',
    'CHANNEL_TRIM_FILTER_SETTLE_MS = 1800L',
    'PendingCommand.scalar(DspProtocol.ID_MASTER_VOLUME, CHANNEL_TRIM_GUARD_MUTE_DB)',
    'PendingCommand.channelTrim(channelTrimGuardChannel, channelTrimGuardTarget)',
    'startDescriptorRequest("TRIM_POSTCHECK")',
    'channelTrimGuardExpected.firstMismatch(scalarValues, eqBands)',
    'PendingCommand.scalar(DspProtocol.ID_MASTER_VOLUME, channelTrimGuardMasterBefore)',
    'publishDescriptorToUi("TRIM_VERIFIED", 105)']:
    req(token in BLE, 'missing V45 guard token: '+token)

# Expected postcheck snapshot explicitly allows only target Band1 and muted Master to differ.
req('channelTrimGuardExpected.scalars.put(DspProtocol.ID_MASTER_VOLUME, CHANNEL_TRIM_GUARD_MUTE_DB);' in BLE, 'expected muted Master missing')
req('channelTrimGuardExpected.eq[ch][0] = channelTrimGuardTarget;' in BLE, 'expected target Band1 missing')

# Fail closed: cross-channel mismatch never restores Master and forces a fresh session.
req('CHANNEL TRIM UNCONFIRMED' in BLE and 'MASTER HELD -70 dB' in BLE and 'reconnect/re-auth' in BLE, 'fail-closed mismatch path missing')
req('sessionFault(channelTrimGuardActive' in BLE, 'guarded GATT/write failure path missing')
req('clearChannelTrimGuardState();' in BLE, 'guard state cleanup missing')

# Normal writer remains serialized and encrypted in one continuous TX stream.
req('liveWriteBusy = true;' in BLE and 'liveInflight = next;' in BLE, 'one-write-in-flight guard missing')
req('encrypted = txCipher.next(next.plain);' in BLE, 'continuous TX cipher path missing')

# No automatic/batch channel trim replay. Each non-CH3 gesture commits once; batch reset is locked.
req('activeSlider.type == SL_CHANNEL && activeSlider.index != 2' in VIEW, 'release-only commit missing')
req('pendingSlider.type == SL_CHANNEL && pendingSlider.index != 2' in VIEW, 'tap commit missing')
req('batch Reset Channels is locked' in VIEW, 'unsafe batch reset not locked')
req('Guarded output trim • Master mute + 7-channel postcheck' in VIEW, 'V45 UI status missing')

# V38/V39/V41 critical invariants preserved.
req('private static final long EQ_SHAPE_MIN_GAP_MS = 110L;' in BLE, 'V38 F/Q spacing changed')
req('private static final long EQ_RESET_MIN_GAP_MS = 110L;' in BLE, 'V39 Reset spacing changed')
req('SAVE_PRECHECK' in BLE and 'SAVE_POSTCHECK' in BLE and 'SAVE UNCONFIRMED' in BLE, 'V41 guarded Save missing')
req('return encodeWrite(ID_SAVE_PARAMS, 0, new byte[0]);' in PROTO, 'ID7 SaveParams format changed')

print('V45_GUARDED_CHANNEL_TRIM_PASS',
      'CH3=ID8', 'CH1/2/4/5/6/7=fullBand1UnderMasterMute',
      'precheck=fresh', 'mute=-70dB', 'muteSettle=450ms',
      'transientHold=1800ms', 'postcheck=all7', 'batchReset=LOCKED')
