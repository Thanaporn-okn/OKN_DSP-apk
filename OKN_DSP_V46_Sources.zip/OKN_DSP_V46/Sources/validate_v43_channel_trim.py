#!/usr/bin/env python3
from pathlib import Path
import json, math, re, sys

ROOT = Path(__file__).resolve().parents[1]
BLE = (ROOT/'app/src/main/java/com/okn/dsp/BleManager.java').read_text()
PROTO = (ROOT/'app/src/main/java/com/okn/dsp/DspProtocol.java').read_text()
VIEW = (ROOT/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
STATE = (ROOT/'app/src/main/java/com/okn/dsp/DspState.java').read_text()
ACT = (ROOT/'app/src/main/java/com/okn/dsp/MainActivity.java').read_text()
GRADLE = (ROOT/'app/build.gradle').read_text()
DESC_PATH = ROOT/'Sources/ProtocolEvidence/GoloPine_DeviceDescription_REAL_20260906_204555.json'
DESC = json.loads(DESC_PATH.read_text())

def req(ok, msg):
    if not ok:
        raise AssertionError(msg)

def actuator(i):
    for a in DESC['actuators']:
        if int(a['ID']) == i:
            return a
    raise KeyError(i)

def band1(i):
    return actuator(i)['UFE_TYPE_BIQUAD_CASCADE15_F'][0]

# Version / base identity.
req('versionCode 1043' in GRADLE and "versionName '43.0.0'" in GRADLE, 'V43 version mismatch')
req((ROOT/'Sources/VERSION.txt').read_text().splitlines()[:2] == ['OKN DSP V43', 'versionName=43.0.0'], 'VERSION.txt mismatch')

# Real descriptor topology: no guessed channel actuator IDs.
req([int(actuator(i)['ID']) for i in [4,5,6,14,15,16,17]] == [4,5,6,14,15,16,17], 'channel actuator IDs mismatch')
req(actuator(6)['name'] == 'BiquadCascadeBassChannel', 'CH3 is not BassChannel')
for i, token in [(14,'i2sout0L'),(15,'i2sout0R'),(16,'i2sout1L'),(17,'i2sout1R')]:
    req(token in actuator(i).get('desc',''), f'output identity missing for ID{i}')
req(actuator(8)['name'] == 'BassVolume', 'ID8 not BassVolume')
req('min=-70,max=6' in actuator(8).get('cpar',''), 'ID8 range evidence changed')

pattern = [int(band1(i)['typ']) for i in [4,5,6,14,15,16,17]]
req(pattern == [17,17,3,17,17,17,17], f'Band1 pattern changed: {pattern}')
req(abs(float(actuator(9)['UFE_TYPE_FLOAT32']) - float(band1(6)['F'])) < 1e-4, 'BassCutoff/CH3 Band1 F relation missing')
req(abs(float(actuator(8)['UFE_TYPE_FLOAT32']) - float(band1(6)['G'])) > 1.0, 'ID8 unexpectedly aliases CH3 Band1.G')

# Type17 exact math replay and uniform-G proof.
SAMPLE_RATE=44100.0
def tone(row, g):
    tb=10**(float(row['R'])/20.0)
    bb=10**(float(row['B'])/20.0)
    at=math.tan(math.pi*float(row['F2'])/SAMPLE_RATE)
    ab=math.tan(math.pi*float(row['F'])/SAMPLE_RATE)
    knumT=2.0/(1.0+(1.0/tb)); kdenT=2.0/(1.0+tb)
    knumB=2.0/(1.0+(1.0/bb)); kdenB=2.0/(1.0+bb)
    a10=at+kdenT; b10=at+knumT; a11=at-kdenT; b11=at-knumT
    a20=ab*kdenB+1.0; b20=ab*knumB-1.0; a21=ab*kdenB-1.0; b21=ab*knumB+1.0
    a0=a10*a20; gl=10**(g/20.0)
    return ((b10*b20/a0)*gl, (((b10*b21)+(b11*b20))/a0)*gl, (b11*b21/a0)*gl,
            ((a10*a21)+(a11*a20))/a0, (a11*a21)/a0)

row = band1(4)
calc0 = tone(row, float(row['G']))
cap = tuple(float(row[k]) for k in ['B0','B1','B2','A1','A2'])
maxerr=max(abs(a-b) for a,b in zip(calc0,cap))
req(maxerr < 1e-4, f'type17 captured-math replay error {maxerr}')
calc_m6=tone(row,-6.0)
scale=10**(-6/20.0)
for j in range(3): req(abs(calc_m6[j]/calc0[j]-scale) < 1e-12, 'G is not uniform numerator gain')
req(abs(calc_m6[3]-calc0[3]) < 1e-12 and abs(calc_m6[4]-calc0[4]) < 1e-12, 'G changed denominator/EQ shape')

# Source implementation must preserve non-G metadata for type17 cell trim.
req('static EqBand firstBandCellGainFromCurrent' in PROTO, 'cell-gain builder missing')
req('static EqBand toneControlCellGainFromCurrent' in PROTO, 'tone cell-gain builder missing')
req('current.boostDb, cellGainDb, current.r' in PROTO, 'B/G/R preservation missing')
req('double gl = Math.pow(10.0, cellGainDb / 20.0);' in PROTO, 'cell gain conversion missing')
req('requestedGainDb < -12f || requestedGainDb > 12f' in PROTO, 'conservative V43 G range missing')

# Runtime mapping: CH3 -> verified ID8, other six -> Band1.G / existing EQ writer.
trim_method = re.search(r'void setChannelTrimRealtime\(.*?\n    \}', BLE, re.S)
req(trim_method is not None, 'setChannelTrimRealtime missing')
t=trim_method.group(0)
req('if (channel0 == 2)' in t and 'DspProtocol.ID_BASS_VOLUME' in t, 'CH3 does not use verified ID8')
req('channelTrimPending.put(channel0, rounded)' in t, 'six-channel trim queue missing')
req('PendingCommand.channelTrim(ch, target)' in BLE, 'channel trim command missing')
req('DspProtocol.encodeEqWrite(ch, 1, target)' in BLE, 'trim is not existing Band1 full-record writer')
req('static final int[] EQ_ACTUATORS = {4, 5, 6, 14, 15, 16, 17};' in PROTO, 'verified EQ actuator map changed')

# Fresh-descriptor exact gate / readback mapping.
for token in ['validateChannelTrimBand1Pattern()', 'channelTrimHealthGate = validateChannelTrimBand1Pattern();',
              'DspProtocol.EQ_TONE_CONTROL_TYPE', 'DspProtocol.EQ_GENERAL_LOWPASS_TYPE']:
    req(token in BLE, 'channel trim descriptor gate missing: '+token)
req('final float fg = (ch == 2 && bass != null) ? bass : first.gain;' in BLE, 'trim readback map missing')
req('listener.onChannelTrimValue' in BLE and 'onChannelTrimValue' in ACT and 'setChannelTrimFromDsp' in VIEW, 'trim readback callback chain missing')
req('channelVolume[2] = bassVolume;' in STATE, 'CH3 local mirror missing')

# Full-record collision protection.
req('band1GainAfterTrim' in BLE, 'B/G stale-record guard missing')
req('channelTrimPending.containsKey(channel0) || channelTrimWriteInFlightChannel == channel0' in BLE, 'same-channel collision deferral missing')
req('DspProtocol.firstBandGainFromCurrent(current, deferredGain)' in BLE, 'deferred B rebuild missing')
req('DspProtocol.EqBand current = eqBands[ch][0];' in BLE and 'firstBandCellGainFromCurrent(current, gainDb)' in BLE, 'G target not rebuilt at send time')

# One write in flight / fail closed preserved.
req('if (liveWriteBusy || !eqRealtimePending.isEmpty() || !eqShapePending.isEmpty())' in BLE, 'trim does not yield to existing EQ writers')
req('liveWriteBusy = true;' in BLE and 'liveInflight = next;' in BLE, 'single in-flight scheduler missing')
req('encrypted = txCipher.next(next.plain);' in BLE, 'continuous TX stream path missing')
req('sessionFault("DSP command callback timeout")' in BLE, 'write timeout fail-closed missing')
req('sessionFault("GATT write failed " + status)' in BLE, 'GATT failure fail-closed missing')

# V38/V39/V41 invariants retained in V43-compatible form.
req('private static final long EQ_SHAPE_MIN_GAP_MS = 110L;' in BLE, 'V38 F/Q spacing changed')
req('private static final long EQ_RESET_MIN_GAP_MS = 110L;' in BLE, 'V39 reset spacing changed')
reset = re.search(r'int resetEqSafe\(int channel0\) \{.*?\n    \}', BLE, re.S)
req(reset is not None, 'Safe Reset missing')
r=reset.group(0)
req('firstBandGainFromCurrent(current, 0f)' in r and 'peakingFromCurrent(current, 0f)' in r, 'Safe Reset no longer Gain-only')
req('peakingShapeFromCurrent' not in r, 'Safe Reset writes F/Q')
req('encodeSaveParamsTrigger()' in PROTO and 'return encodeWrite(ID_SAVE_PARAMS, 0, new byte[0]);' in PROTO, 'V41 ID7 zero-payload Save changed')
req('SAVE UNCONFIRMED' in BLE and 'SAVE_POSTCHECK' in BLE and 'SAVE_PRECHECK' in BLE, 'V41 guarded postcheck changed')
req('realtimeQueuesIdleForSave' in BLE and 'channelTrimPending.isEmpty()' in BLE, 'Save boundary ignores V43 trim queue')

# V43 hardware-derived stutter fix: non-CH3 full records commit once per gesture
# and use the official-app-style 380 ms channel-trim cadence instead of the 45 ms EQ lane.
req('private static final long CHANNEL_TRIM_MIN_GAP_MS = 380L;' in BLE, 'V43 channel trim cadence is not 380 ms')
req('long waitTrim = CHANNEL_TRIM_MIN_GAP_MS - (now - lastChannelTrimWriteUptimeMs);' in BLE, 'dedicated trim cadence gate missing')
req('lastChannelTrimWriteUptimeMs = now;' in BLE, 'trim cadence timestamp not advanced')
req('if (s.index == 2) sendVerifiedChannelTrim(s.index);' in VIEW, 'CH3 scalar live path missing')
req('activeSlider.type == SL_CHANNEL && activeSlider.index != 2' in VIEW, 'non-CH3 release commit missing')
req('pendingSlider.type == SL_CHANNEL && pendingSlider.index != 2' in VIEW, 'non-CH3 tap commit missing')
# The captured descriptor is complete for this device: there are no other scalar Volume actuators to guess.
volume_scalar_ids=sorted(int(a['ID']) for a in DESC['actuators'] if int(a.get('type',-1)) == 2000 and 'Volume' in a.get('name',''))
req(volume_scalar_ids == [2,3,8], f'unexpected scalar Volume actuator set {volume_scalar_ids}')
hci=(ROOT/'Sources/ProtocolEvidence/V17_Recovery/ORIGINAL_APP_HCI_EVIDENCE_V12.txt').read_text()
req('mean ~= 379.98 ms' in hci and 'median ~= 380.17 ms' in hci, 'original ~380 ms scheduler evidence missing')

# UI: existing controls are now hardware-gated, no redesign dependency.
req('Hardware output trim • fresh-descriptor 7/7 safety gate' in VIEW, 'Mix channel hardware status missing')
req('sendVerifiedChannelTrim' in VIEW and '!channelTrimWritable[s.index]' in VIEW, 'UI trim safety lock missing')

print('V43_CHANNEL_TRIM_PASS',
      'band1Pattern=' + ','.join(map(str,pattern)),
      'type17ReplayMaxErr=%.9g' % maxerr,
      'G(-6)dBScale=%.12f' % scale,
      'CH3=ID8',
      'otherChannels=Band1.G')
