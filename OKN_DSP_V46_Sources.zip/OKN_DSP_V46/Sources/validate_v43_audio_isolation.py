#!/usr/bin/env python3
from pathlib import Path
import hashlib

ROOT = Path(__file__).resolve().parents[1]
BLE_P = ROOT / 'app/src/main/java/com/okn/dsp/BleManager.java'
DSP_P = ROOT / 'app/src/main/java/com/okn/dsp/DspProtocol.java'
VIEW_P = ROOT / 'app/src/main/java/com/okn/dsp/DspView.java'
GRADLE_P = ROOT / 'app/build.gradle'
BLE = BLE_P.read_text()
DSP = DSP_P.read_text()
VIEW = VIEW_P.read_text()
GRADLE = GRADLE_P.read_text()

def req(cond, msg):
    if not cond:
        raise AssertionError(msg)

def method(text, marker):
    i = text.index(marker)
    b = text.index('{', i)
    depth = 0
    for j in range(b, len(text)):
        if text[j] == '{': depth += 1
        elif text[j] == '}':
            depth -= 1
            if depth == 0:
                return text[i:j+1]
    raise AssertionError('unclosed method: ' + marker)

def sha_bytes(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

req('versionCode 1043' in GRADLE and "versionName '43.0.0'" in GRADLE, 'V43 version mismatch')

# Route-aware quiet mode.
req('import android.media.AudioDeviceInfo;' in BLE, 'AudioDeviceInfo import missing')
req('audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)' in BLE, 'Bluetooth audio route detection missing')
req('AudioDeviceInfo.TYPE_BLUETOOTH_A2DP' in BLE, 'A2DP route detection missing')
req('AudioDeviceInfo.TYPE_BLE_HEADSET' in BLE and 'AudioDeviceInfo.TYPE_BLE_SPEAKER' in BLE,
    'BLE audio route detection missing')
req('audioManager.isMusicActive()' in BLE, 'music activity check missing')
req('AUDIO_ACTIVE_HOLD_MS = 5000L' in BLE, 'V43 route anti-flap hold mismatch')
req('BACKGROUND_SENSOR_POLLING_ENABLED = false' in BLE, 'hard-isolation polling switch must be OFF')
req('if (!BACKGROUND_SENSOR_POLLING_ENABLED || isMediaPlaybackActive()) return;' in method(BLE, '    private void originalCommandSchedulerTick('),
    'autonomous 380 ms poll path is not disabled')

# Audio-route pacing and priority policy.
req('AUDIO_SAFE_EQ_REALTIME_MIN_GAP_MS = 140L' in BLE, 'Bluetooth-audio Gain pacing mismatch')
req('AUDIO_SAFE_EQ_SHAPE_MIN_GAP_MS = 240L' in BLE, 'Bluetooth-audio F/Q pacing mismatch')
req('AUDIO_SAFE_EQ_RESET_MIN_GAP_MS = 240L' in BLE, 'Bluetooth-audio reset pacing mismatch')
req('long minGap = currentEqRealtimeGapMs();' in method(BLE, '    private void scheduleEqRealtimePump('),
    'Gain lane does not use adaptive pacing')
req('long shapeGap = currentEqShapeGapMs();' in method(BLE, '    private void scheduleEqShapePump('),
    'shape lane does not use adaptive pacing')
load = method(BLE, '    private void loadDescriptor(')
req('BluetoothGatt.CONNECTION_PRIORITY_LOW_POWER' in load and 'isMediaPlaybackActive()' in load,
    'post-descriptor Bluetooth-audio low-power policy missing')

# No second PCM/music pipeline.
java = '\n'.join(p.read_text(errors='ignore') for p in (ROOT/'app/src/main/java').rglob('*.java'))
for forbidden in ('import android.media.AudioTrack;', 'import android.media.MediaPlayer;', 'androidx.media3.exoplayer', 'com.google.android.exoplayer'):
    req(forbidden not in java, 'unexpected Android music renderer/decoder added: ' + forbidden)

# Preserve proven idle timings, packet/filter path and save boundaries.
req('EQ_REALTIME_MIN_GAP_MS = 45L' in BLE, 'idle Gain timing changed')
req('EQ_SHAPE_MIN_GAP_MS = 110L' in BLE, 'idle F/Q timing changed')
req('EQ_RESET_MIN_GAP_MS = 110L' in BLE, 'idle reset timing changed')
req('EXPECTED_SAFE_PEAKING_ROWS = 55' in BLE, '55-row safe PEQ gate changed')
req('safePeakingRows == EXPECTED_SAFE_PEAKING_ROWS' in BLE, 'safe PEQ health gate missing')
req('static final int ID_SAVE_PARAMS = 7;' in DSP, 'SaveParams ID7 missing')
req('startDescriptorRequest("SAVE_PRECHECK")' in BLE and 'startDescriptorRequest("SAVE_POSTCHECK")' in BLE,
    'guarded save verification missing')
req('requestVerifiedRestore()' in BLE and 'startDescriptorRequest("RESTORE")' in BLE,
    'readback-only restore missing')
req(VIEW.count('requestPersistentSave()') == 1, 'unexpected automatic/duplicate SaveParams caller')

expected_hashes = {
    'DspProtocol.java': 'e0b3af39fa0de56812600801765d6d544fd3f093ae8f37d043e3bf99e41c5b46',
    'DspState.java': 'c52e1cec09f81068e998f0a08bc71297e235770d1fb678fc514aebb471ee1178',
    'MainActivity.java': 'ffcccdfbaf2f8df351f53f335ba9b80b924e48c3c99afd0da1ee6c03e3ac91a4',
}
for name, expected in expected_hashes.items():
    actual = sha_bytes(ROOT/'app/src/main/java/com/okn/dsp'/name)
    req(actual == expected, f'{name} changed unexpectedly: {actual}')

expected_method_hashes = {
    'sendScheduledControl': '8c39c0643084615777997900f428e3c32971bdd5e2afa0d768c04c4dbfedf777',
    'writeNoResponse': 'e6895bee7c3f2d12c2531d7d48346559d6b00a4c227b38ecfc63f2ce2a9d9256',
}
for name, expected in expected_method_hashes.items():
    marker = '    private ' + ('void ' if name == 'sendScheduledControl' else 'boolean ') + name + '('
    actual = hashlib.sha256(method(BLE, marker).encode()).hexdigest()
    req(actual == expected, f'{name} low-level TX path changed unexpectedly: {actual}')

print('V43_AUDIO_HARD_ISOLATION_STATIC_PASS')
print('background sensor polling: DISABLED')
print('Bluetooth audio route: A2DP/BLE-aware -> LOW_POWER priority')
print('Bluetooth audio gaps: gain=140ms shape=240ms reset=240ms')
print('idle/user-driven base gaps retained: gain=45ms shape=110ms reset=110ms')
print('PCM renderer/resampler added: NO')
print('V41 Save/Restore + V38/V39 safety boundaries retained: PASS')
