#!/usr/bin/env python3
from pathlib import Path
import hashlib, re, sys

ROOT = Path(__file__).resolve().parents[1]
BLE_P = ROOT / 'app/src/main/java/com/okn/dsp/BleManager.java'
DSP_P = ROOT / 'app/src/main/java/com/okn/dsp/DspProtocol.java'
VIEW_P = ROOT / 'app/src/main/java/com/okn/dsp/DspView.java'
GRADLE_P = ROOT / 'app/build.gradle'
BLE = BLE_P.read_text()
DSP = DSP_P.read_text()
VIEW = VIEW_P.read_text()
GRADLE = GRADLE_P.read_text()

def req(cond, msg):
    if not cond:
        raise AssertionError(msg)

def method(text, marker):
    i = text.index(marker)
    b = text.index('{', i)
    depth = 0
    for j in range(b, len(text)):
        if text[j] == '{': depth += 1
        elif text[j] == '}':
            depth -= 1
            if depth == 0:
                return text[i:j+1]
    raise AssertionError('unclosed method: ' + marker)

def sha_bytes(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

# V42 package identity.
req('versionCode 1042' in GRADLE and "versionName '42.0.0'" in GRADLE, 'V42 version mismatch')

# Audio coexistence gate: detect playback only; never capture or render music.
req('import android.media.AudioManager;' in BLE, 'AudioManager import missing')
req('audioManager.isMusicActive()' in BLE, 'media activity gate missing')
req('AUDIO_ACTIVE_HOLD_MS = 2000L' in BLE, 'anti-flap hold missing')
req('AUDIO_SAFE_EQ_REALTIME_MIN_GAP_MS = 90L' in BLE, 'active-music Gain pacing mismatch')
req('AUDIO_SAFE_EQ_SHAPE_MIN_GAP_MS = 160L' in BLE, 'active-music F/Q pacing mismatch')
req('AUDIO_SAFE_EQ_RESET_MIN_GAP_MS = 160L' in BLE, 'active-music reset pacing mismatch')
req('if (isMediaPlaybackActive()) return;' in method(BLE, '    private void originalCommandSchedulerTick('),
    'sensor polling is not suppressed during playback')
req('long minGap = currentEqRealtimeGapMs();' in method(BLE, '    private void scheduleEqRealtimePump('),
    'Gain lane does not use adaptive pacing')
req('long shapeGap = currentEqShapeGapMs();' in method(BLE, '    private void scheduleEqShapePump('),
    'shape lane does not use adaptive pacing')
req('BluetoothGatt.CONNECTION_PRIORITY_LOW_POWER' in method(BLE, '    private void startDescriptorRequest('),
    'descriptor playback coexistence priority missing')
req('active.requestConnectionPriority(BluetoothGatt.CONNECTION_PRIORITY_BALANCED)' in method(BLE, '    private void loadDescriptor('),
    'descriptor completion does not restore balanced priority')

# The controller must not become a second Android PCM/music pipeline.
java = '\n'.join(p.read_text(errors='ignore') for p in (ROOT/'app/src/main/java').rglob('*.java'))
for forbidden in ('import android.media.AudioTrack;', 'import android.media.MediaPlayer;', 'androidx.media3.exoplayer', 'com.google.android.exoplayer'):
    req(forbidden not in java, 'unexpected Android music renderer/decoder added: ' + forbidden)

# Preserve the proven idle timings and strict-safe gates.
req('EQ_REALTIME_MIN_GAP_MS = 45L' in BLE, 'idle Gain timing changed')
req('EQ_SHAPE_MIN_GAP_MS = 110L' in BLE, 'idle F/Q timing changed')
req('EQ_RESET_MIN_GAP_MS = 110L' in BLE, 'idle reset timing changed')
req('EXPECTED_SAFE_PEAKING_ROWS = 55' in BLE, '55-row safe PEQ gate changed')
req('safePeakingRows == EXPECTED_SAFE_PEAKING_ROWS' in BLE, 'safe PEQ health gate missing')
req('DspProtocol.peakingFromCurrent(current, 0f)' in BLE, 'Gain-only Safe Reset target changed')

# Retain V41 guarded Save/Restore semantics.
req('static final int ID_SAVE_PARAMS = 7;' in DSP, 'SaveParams ID7 missing')
req('encodeWrite(ID_SAVE_PARAMS, 0, new byte[0])' in method(DSP, '    static byte[] encodeSaveParamsTrigger('),
    'SaveParams trigger format changed')
req('startDescriptorRequest("SAVE_PRECHECK")' in BLE, 'fresh save precheck missing')
req('startDescriptorRequest("SAVE_POSTCHECK")' in BLE, 'fresh save postcheck missing')
req('boolean eqOk = eqCount == 105;' in BLE, '105/105 EQ gate missing')
req('boolean sensorOk = sensorCount >= 4;' in BLE, 'sensor health gate missing')
req('SAVE UNCONFIRMED' in BLE and 'DO NOT RETRY automatically' in BLE, 'save uncertainty warning missing')
req('requestVerifiedRestore()' in BLE and 'startDescriptorRequest("RESTORE")' in BLE, 'readback-only restore missing')
req(VIEW.count('requestPersistentSave()') == 1, 'unexpected automatic/duplicate SaveParams caller')
req(BLE.count('sendSaveParamsOnce()') == 2, 'SaveParams helper must have one definition and one guarded call')

# Critical packet/filter implementation remains bit-for-bit V41.
expected_hashes = {
    'DspProtocol.java': 'e0b3af39fa0de56812600801765d6d544fd3f093ae8f37d043e3bf99e41c5b46',
    'DspState.java': 'c52e1cec09f81068e998f0a08bc71297e235770d1fb678fc514aebb471ee1178',
    'MainActivity.java': 'ffcccdfbaf2f8df351f53f335ba9b80b924e48c3c99afd0da1ee6c03e3ac91a4',
}
for name, expected in expected_hashes.items():
    actual = sha_bytes(ROOT/'app/src/main/java/com/okn/dsp'/name)
    req(actual == expected, f'{name} changed unexpectedly: {actual}')

# Sensitive low-level TX path itself remains unchanged; V42 changes only scheduling policy around it.
expected_method_hashes = {
    'sendScheduledControl': '8c39c0643084615777997900f428e3c32971bdd5e2afa0d768c04c4dbfedf777',
    'writeNoResponse': 'e6895bee7c3f2d12c2531d7d48346559d6b00a4c227b38ecfc63f2ce2a9d9256',
}
for name, expected in expected_method_hashes.items():
    body = method(BLE, '    private ' + ('void ' if name == 'sendScheduledControl' else 'boolean ') + name + '(')
    actual = hashlib.sha256(body.encode()).hexdigest()
    req(actual == expected, f'{name} low-level TX path changed unexpectedly: {actual}')

print('V42_AUDIO_COEXISTENCE_STATIC_PASS')
print('media-active: poll=SUPPRESSED gainGap=90ms shapeGap=160ms resetGap=160ms')
print('idle: gainGap=45ms shapeGap=110ms resetGap=110ms')
print('descriptor: LOW_POWER while media active -> BALANCED after validated readback')
print('PCM renderer/resampler added: NO')
print('V41 Save/Restore + V38/V39 safety boundaries retained: PASS')
