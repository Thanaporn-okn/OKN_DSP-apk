from pathlib import Path
root=Path(__file__).resolve().parents[1]
ble=(root/'app/src/main/java/com/okn/dsp/BleManager.java').read_text()
view=(root/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
grad=(root/'app/build.gradle').read_text()
checks={
 'version': "versionCode 1046" in grad and "versionName '46.0.0'" in grad,
 'ch1_only_gate': 'if (channel0 != 0)' in ble and 'only CH1 is enabled for isolated hardware proof' in ble,
 'no_immediate_trim_postread': 'startDescriptorRequest("TRIM_POSTCHECK")' not in ble,
 'master_mute': 'CHANNEL_TRIM_GUARD_MUTE_DB = -70.0f' in ble,
 'settle_1800': 'CHANNEL_TRIM_FILTER_SETTLE_MS = 1800L' in ble,
 'full_record_path': 'PendingCommand.channelTrim(channelTrimGuardChannel, channelTrimGuardTarget)' in ble,
 'v44_partial_absent': 'encodeEqCellGainPartialWrite' not in ble,
 'do_not_save_message': 'DO NOT SAVE' in ble,
 'ui_ch1_isolated': 'CH1 isolated trim test' in view,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL'), k)
raise SystemExit(0 if all(checks.values()) else 1)
