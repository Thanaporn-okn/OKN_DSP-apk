#!/usr/bin/env python3
from pathlib import Path
import sys
root = Path(__file__).resolve().parent.parent
ble = (root/'app/src/main/java/com/okn/dsp/BleManager.java').read_text()
dsp = (root/'app/src/main/java/com/okn/dsp/DspProtocol.java').read_text()
view = (root/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
state = (root/'app/src/main/java/com/okn/dsp/DspState.java').read_text()
build = (root/'app/build.gradle').read_text()
evidence = (root/'Sources/ProtocolEvidence/GoloPine_DeviceDescription_REAL_20260906_204555.json').read_text()
checks = {
    'version46': 'versionCode 1046' in build and "versionName '46.0.0'" in build,
    'id8': 'static final int ID_BASS_VOLUME = 8;' in dsp,
    'descriptor_still_original': '"name": "BassVolume"' in evidence and 'min=-70,max=6' in evidence,
    'experimental_id8_cap': 'case ID_BASS_VOLUME:' in dsp and 'lo = -70f; hi = 12f;' in dsp,
    'state_cap_12': 'bassVolume = clamp(value, -70f, 12f);' in state,
    'ui_cap_12': '-70f, 12f, SL_BASS, -1' in view,
    'direct_id8_write': 'DspProtocol.encodeFloatWrite(id, value)' in ble,
    'direct_id8_readback': 'DspProtocol.encodeRead(DspProtocol.ID_BASS_VOLUME, 0, 4)' in ble,
    'clamp_detection': 'Bass Volume firmware clamp' in ble and 'target > 6.05f' in ble,
    'no_v44_bass_eq_slider': 'SL_BASS_CHANNEL_GAIN' not in view and 'Bass/Sub DSP Gain' not in view,
    'no_band1_bass_volume_hook': 'sendVerifiedEqGain(2, 0)' not in view,
    'no_master_autowrite': 'sendVerifiedScalar(DspProtocol.ID_MASTER_VOLUME, state.masterVolume);' in view,
    'hard_isolation': 'BACKGROUND_SENSOR_POLLING_ENABLED = false' in ble,
}
for k,v in checks.items(): print(f'{k}={"PASS" if v else "FAIL"}')
if not all(checks.values()): sys.exit(1)
print('V46_BASS_VOLUME_ID8_EXTENDED_STATIC_PASS')
