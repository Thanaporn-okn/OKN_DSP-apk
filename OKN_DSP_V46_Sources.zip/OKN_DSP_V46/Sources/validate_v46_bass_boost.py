#!/usr/bin/env python3
from pathlib import Path
import hashlib

root = Path(__file__).resolve().parents[1]
ble = (root/'app/src/main/java/com/okn/dsp/BleManager.java').read_text()
view = (root/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
state = (root/'app/src/main/java/com/okn/dsp/DspState.java').read_text()
proto = (root/'app/src/main/java/com/okn/dsp/DspProtocol.java').read_text()
gradle = (root/'app/build.gradle').read_text()
desc = (root/'Sources/ProtocolEvidence/GoloPine_DeviceDescription_REAL_20260906_204555.json').read_text()

def method(text, marker):
    i = text.index(marker)
    b = text.index('{', i)
    depth = 0
    for j in range(b, len(text)):
        if text[j] == '{': depth += 1
        elif text[j] == '}':
            depth -= 1
            if depth == 0: return text[i:j+1]
    raise AssertionError('unclosed method ' + marker)

def sha(s):
    return hashlib.sha256(s.encode()).hexdigest()

checks = {
    'V46 version': "versionCode 1046" in gradle and "versionName '46.0.0'" in gradle,
    'BassVolume ID8 retained': 'static final int ID_BASS_VOLUME = 8;' in proto,
    'BassVolume hard max remains +6': 'case ID_BASS_VOLUME:' in proto and 'lo = -70f; hi = 6f; break;' in proto,
    'BassBoost ID10 verified scalar': 'static final int ID_BASS_BOOST = 10;' in proto and 'ID_BASS_BOOST' in proto,
    'BassBoost protocol range -12..+12': 'case ID_BASS_BOOST:' in proto and 'lo = -12f; hi = 12f; break;' in proto,
    'Descriptor proves BassVolume +6': '"ID": 8' in desc and '"name": "BassVolume"' in desc and 'min=-70,max=6' in desc,
    'Descriptor proves BassBoost +12': '"ID": 10' in desc and '"name": "BassBoost"' in desc and 'min=-12,max=12' in desc,
    'BassBoost state exists': 'public float bassBoost;' in state and 'setBassBoost(float value)' in state,
    'BassBoost state clamp': 'bassBoost = clamp(value, -12f, 12f);' in state,
    'BassBoost UI range': '"Bass Boost", "BOOST"' in view and '-12f, 12f, SL_BASS_BOOST' in view,
    'BassBoost readback only to state': 'actuatorId == DspProtocol.ID_BASS_BOOST' in view and 'state.setBassBoost(value);' in view,
    'BassBoost writes ID10 only': 'sendVerifiedScalar(DspProtocol.ID_BASS_BOOST, state.bassBoost);' in view,
    'BassVolume still writes ID8 only': 'sendVerifiedScalar(DspProtocol.ID_BASS_VOLUME, state.bassVolume);' in view,
    'verified EQ mapping retained': 'static final int[] EQ_ACTUATORS = {4, 5, 6, 14, 15, 16, 17};' in proto,
    'V45 music EQ settle retained': 'EQ_INTERACTIVE_MUSIC_SETTLE_MS = 380L' in ble,
    'V44 audio guard retained': 'AUDIO_GUARD_HOLD_MS = 8000L' in ble,
    'normal scheduler remains 380ms': 'ORIGINAL_COMMAND_CADENCE_MS = 380L' in ble,
    'Safe Reset music cadence remains 380ms': 'EQ_RESET_MUSIC_MIN_GAP_MS = 380L' in ble,
}

# Strong freeze: V46 must not alter the V45 transport/protocol files at all.
checks['BleManager byte-for-byte V45'] = hashlib.sha256(ble.encode()).hexdigest() == '15cfc4bd64723e7508694d19ab271f173b91fc78acd5118ddcbbfae90e50bff9'
checks['DspProtocol byte-for-byte V45'] = hashlib.sha256(proto.encode()).hexdigest() == 'e0b3af39fa0de56812600801765d6d544fd3f093ae8f37d043e3bf99e41c5b46'

# Freeze DspView's EQ bridge methods even though the Mix UI is allowed to change.
for label, marker, expected in [
    ('DspView.sendVerifiedEqGain', '    private void sendVerifiedEqGain(', '3104545feddc6b916d75dfc2aa95750fea3e240cc5126584b7371c08b78864ab'),
    ('DspView.sendVerifiedEqShape', '    private void sendVerifiedEqShape(', 'bda3a29f7629eb9a93a6ee553bdfd16793a32075059e94c15ede9710c29467e3'),
    ('DspView.setEqFromDsp', '    void setEqFromDsp(', '52cb867068d2c08f83972ad7ddd9ccedf5893ee9c8c00de9de1b4c3fad30eabf'),
]:
    checks['frozen '+label] = sha(method(view, marker)) == expected

failed = [k for k,v in checks.items() if not v]
for k,v in checks.items():
    print(('PASS' if v else 'FAIL'), k)
if failed:
    raise SystemExit('V46 validation failed: ' + ', '.join(failed))
print('V46_BASS_BOOST_EQ_FROZEN_PASS')
