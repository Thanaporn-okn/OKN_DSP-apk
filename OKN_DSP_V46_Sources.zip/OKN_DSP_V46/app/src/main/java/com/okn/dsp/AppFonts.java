package com.okn.dsp;

import android.graphics.Typeface;
import android.os.Build;

import java.io.File;

/**
 * Keeps OKN DSP Canvas/dialog typography independent from Samsung/user-selected
 * display fonts without bundling a font binary in the APK.
 *
 * Android 14+ AOSP system images commonly include RobotoFlex-Regular.ttf.
 * Older images commonly expose Roboto-Regular.ttf. We try concrete system font
 * files first so a user-selected UI font family cannot replace our Canvas text.
 */
public final class AppFonts {
    private static final String[] BASE_PATHS = {
            "/system/fonts/RobotoFlex-Regular.ttf",
            "/system/fonts/Roboto-Regular.ttf",
            "/system/fonts/RobotoStatic-Regular.ttf",
            "/system/fonts/NotoSans-Regular.ttf",
            "/product/fonts/RobotoFlex-Regular.ttf",
            "/product/fonts/Roboto-Regular.ttf",
            "/system_ext/fonts/RobotoFlex-Regular.ttf",
            "/system_ext/fonts/Roboto-Regular.ttf"
    };

    private static final Typeface BASE = loadPhysicalFont();

    public static final Typeface REGULAR = makeWeight(BASE, 400, Typeface.NORMAL);
    public static final Typeface MEDIUM = makeWeight(BASE, 500, Typeface.NORMAL);
    public static final Typeface BOLD = makeWeight(BASE, 700, Typeface.BOLD);

    private AppFonts() {}

    private static Typeface loadPhysicalFont() {
        for (String path : BASE_PATHS) {
            try {
                File file = new File(path);
                if (file.isFile() && file.canRead()) {
                    return Typeface.createFromFile(file);
                }
            } catch (RuntimeException ignored) {
                // Continue to the next known Android system font path.
            }
        }
        // Final fallback. A concrete file is preferred because Samsung/theme
        // font replacement can affect named generic families on some devices.
        return Typeface.create("sans-serif", Typeface.NORMAL);
    }

    private static Typeface makeWeight(Typeface base, int weight, int legacyStyle) {
        try {
            if (Build.VERSION.SDK_INT >= 28) {
                return Typeface.create(base, weight, false);
            }
        } catch (RuntimeException ignored) {
            // Use the legacy style fallback below.
        }
        return Typeface.create(base, legacyStyle);
    }
}
