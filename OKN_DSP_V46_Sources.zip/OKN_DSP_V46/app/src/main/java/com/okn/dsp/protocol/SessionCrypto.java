package com.okn.dsp.protocol;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/** Verified post-auth AES/CFB8 stream. A fresh instance is required per TX or RX direction. */
public final class SessionCrypto {
    private final Cipher cipher;

    public SessionCrypto(byte[] randKey, boolean encrypt) {
        if (randKey == null || randKey.length != 16) throw new IllegalArgumentException("RandKey must be 16 bytes");
        try {
            cipher = Cipher.getInstance("AES/CFB8/NoPadding");
            cipher.init(encrypt ? Cipher.ENCRYPT_MODE : Cipher.DECRYPT_MODE,
                    new SecretKeySpec(randKey.clone(), "AES"),
                    new IvParameterSpec(new byte[] {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}));
        } catch (Exception e) {
            throw new IllegalStateException("AES/CFB8 unavailable", e);
        }
    }

    /** Uses update() so the stream state remains continuous across packets. */
    public byte[] update(byte[] input) {
        byte[] out = cipher.update(input);
        return out == null ? new byte[0] : out;
    }
}
