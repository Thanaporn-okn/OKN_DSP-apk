package com.okn.dsp;

import android.content.Context;
import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * V46 deliberately performs USB descriptor enumeration only.
 *
 * There is no interface claim, permission request, USB transfer, endpoint write,
 * HID SET_REPORT, UFE packet, ACP packet, actuator write or SaveParams here.
 * The only goal is to identify the GoloPine wired transport safely before implementing it.
 */
public final class UsbAcpDiscovery {
    private UsbAcpDiscovery() {}

    public static String summary(Context context) {
        UsbManager manager = (UsbManager) context.getSystemService(Context.USB_SERVICE);
        if (manager == null) return "UsbManager unavailable";
        Map<String, UsbDevice> map = manager.getDeviceList();
        if (map == null || map.isEmpty()) return "no USB device detected";
        int candidates = 0;
        for (UsbDevice d : map.values()) if (isTransportCandidate(d)) candidates++;
        return map.size() + " device(s), " + candidates + " HID/vendor candidate(s)";
    }

    public static String buildReadOnlyReport(Context context) {
        UsbManager manager = (UsbManager) context.getSystemService(Context.USB_SERVICE);
        StringBuilder out = new StringBuilder(2048);
        out.append("OKN DSP V46 — USB descriptor discovery\n")
                .append("READ ONLY: descriptor enumeration; 0 bytes sent to DSP.\n\n");
        if (manager == null) return out.append("UsbManager unavailable on this device.").toString();

        Map<String, UsbDevice> map = manager.getDeviceList();
        if (map == null || map.isEmpty()) {
            return out.append("No USB device detected.\n")
                    .append("Connect the powered DSP USB Type-C port to the phone in USB-host/OTG mode, then scan again.")
                    .toString();
        }

        List<String> keys = new ArrayList<>(map.keySet());
        Collections.sort(keys);
        out.append("Detected devices: ").append(keys.size()).append("\n\n");
        int n = 0;
        for (String key : keys) {
            UsbDevice d = map.get(key);
            if (d == null) continue;
            n++;
            out.append('#').append(n).append(' ')
                    .append(String.format(Locale.US, "VID=%04X PID=%04X", d.getVendorId(), d.getProductId()))
                    .append(" devClass=").append(d.getDeviceClass())
                    .append(" ifaces=").append(d.getInterfaceCount())
                    .append(" permission=").append(manager.hasPermission(d) ? "yes" : "no")
                    .append(isTransportCandidate(d) ? "  <candidate>" : "")
                    .append('\n');

            for (int i = 0; i < d.getInterfaceCount(); i++) {
                UsbInterface f = d.getInterface(i);
                out.append("  IF ").append(f.getId())
                        .append(" class=").append(f.getInterfaceClass())
                        .append(" sub=").append(f.getInterfaceSubclass())
                        .append(" proto=").append(f.getInterfaceProtocol())
                        .append(" eps=").append(f.getEndpointCount());
                if (f.getInterfaceClass() == UsbConstants.USB_CLASS_HID) out.append(" HID");
                if (f.getInterfaceClass() == UsbConstants.USB_CLASS_VENDOR_SPEC) out.append(" VENDOR");
                out.append('\n');
                for (int e = 0; e < f.getEndpointCount(); e++) {
                    UsbEndpoint ep = f.getEndpoint(e);
                    out.append("    EP ").append(String.format(Locale.US, "0x%02X", ep.getAddress()))
                            .append(' ')
                            .append(ep.getDirection() == UsbConstants.USB_DIR_IN ? "IN" : "OUT")
                            .append(" type=").append(ep.getType())
                            .append(" maxPacket=").append(ep.getMaxPacketSize())
                            .append('\n');
                }
            }
            out.append('\n');
        }
        out.append("V46 does not open interfaces or transmit any ACP/UFE command.\n")
                .append("Copy or screenshot this report; VID/PID/interface layout will select the safe wired transport for the next build.");
        return out.toString();
    }

    private static boolean isTransportCandidate(UsbDevice d) {
        // 0x8888 is used by known MVSilicon BP10/BP1048 Generic ACP devices.
        if (d.getVendorId() == 0x8888) return true;
        for (int i = 0; i < d.getInterfaceCount(); i++) {
            int cls = d.getInterface(i).getInterfaceClass();
            if (cls == UsbConstants.USB_CLASS_HID || cls == UsbConstants.USB_CLASS_VENDOR_SPEC) return true;
        }
        return false;
    }
}
