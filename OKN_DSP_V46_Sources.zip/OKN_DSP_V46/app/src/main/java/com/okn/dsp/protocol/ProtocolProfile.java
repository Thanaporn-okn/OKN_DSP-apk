package com.okn.dsp.protocol;

import java.util.UUID;

/** Verified BLE/UFE profile imported from the V35 readback proof. */
public final class ProtocolProfile {
    private ProtocolProfile() {}

    public static final UUID SERVICE_AB00 = UUID.fromString("0000ab00-0000-1000-8000-00805f9b34fb");
    public static final UUID WRITE_AB01 = UUID.fromString("0000ab01-0000-1000-8000-00805f9b34fb");
    public static final UUID NOTIFY_AB02 = UUID.fromString("0000ab02-0000-1000-8000-00805f9b34fb");

    public static final int CMD_WRITE = 0x57;
    public static final int CMD_READ = 0x58;
    public static final int CMD_READ_RESPONSE = 0x60;

    public static final int SAVE_PARAMS = 7;
    public static final int MASTER_VOLUME = 2;
    public static final int REMIND_SOUND_VOLUME = 3;
    public static final int BASS_VOLUME = 8;
    public static final int BASS_CUTOFF = 9;
    public static final int BASS_BOOST = 10;
    public static final int MIDDLE_BOOST = 13;
    public static final int TREBLE_BOOST = 11;

    public static final int[] EQ_ACTUATOR_BY_CHANNEL = {4, 5, 6, 14, 15, 16, 17};
    public static final int EQ_BAND_COUNT = 15;
    public static final int EQ_BAND_BYTES = 48;
    public static final int SAMPLE_RATE_HZ = 44100;

    public static int eqActuator(int channelIndex) {
        if (channelIndex < 0 || channelIndex >= EQ_ACTUATOR_BY_CHANNEL.length) throw new IllegalArgumentException("channelIndex");
        return EQ_ACTUATOR_BY_CHANNEL[channelIndex];
    }

    public static int eqBandOffset(int bandIndex) {
        if (bandIndex < 0 || bandIndex >= EQ_BAND_COUNT) throw new IllegalArgumentException("bandIndex");
        return bandIndex * EQ_BAND_BYTES;
    }
}
