package com.okn.dsp.protocol;

/** 48-byte UFE biquad band encoder; peaking coefficients use the verified 44.1 kHz RBJ form. */
public final class EqBandCodec {
    private EqBandCodec() {}
    public static final int PEAKING_TYPE = 12;

    public static byte[] encodePeaking(float frequencyHz, float q, float boostDb) {
        if (!(frequencyHz > 0f && frequencyHz < ProtocolProfile.SAMPLE_RATE_HZ / 2f)) throw new IllegalArgumentException("frequencyHz");
        if (!(q > 0f)) throw new IllegalArgumentException("q");
        double a = Math.pow(10.0, boostDb / 40.0);
        double w0 = 2.0 * Math.PI * frequencyHz / ProtocolProfile.SAMPLE_RATE_HZ;
        double alpha = Math.sin(w0) / (2.0 * q);
        double a0 = 1.0 + alpha / a;
        float b0 = (float)((1.0 + alpha * a) / a0);
        float b1 = (float)((-2.0 * Math.cos(w0)) / a0);
        float b2 = (float)((1.0 - alpha * a) / a0);
        float a1 = (float)((-2.0 * Math.cos(w0)) / a0);
        float a2 = (float)((1.0 - alpha / a) / a0);
        return ByteCodec.concat(
                ByteCodec.i32le(PEAKING_TYPE),
                ByteCodec.f32le(frequencyHz),
                ByteCodec.f32le(0f),
                ByteCodec.f32le(q),
                ByteCodec.f32le(boostDb),
                ByteCodec.f32le(0f),
                ByteCodec.f32le(0f),
                ByteCodec.f32le(b0),
                ByteCodec.f32le(b1),
                ByteCodec.f32le(b2),
                ByteCodec.f32le(a1),
                ByteCodec.f32le(a2));
    }
}
