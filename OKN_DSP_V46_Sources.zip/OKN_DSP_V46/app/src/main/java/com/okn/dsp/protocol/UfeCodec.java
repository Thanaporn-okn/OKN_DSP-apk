package com.okn.dsp.protocol;

/** Verified UFE serializer. Header integers are BE; scalar FLOAT32 payload is LE. */
public final class UfeCodec {
    private UfeCodec() {}

    public static byte[] encodeRead(int id, int offset, int length) {
        requireRange(offset, length);
        return ByteCodec.concat(new byte[] {(byte)ProtocolProfile.CMD_READ}, ByteCodec.u32be(id), ByteCodec.u16be(offset), ByteCodec.u16be(length));
    }

    public static byte[] encodeWrite(int id, int offset, byte[] data) {
        if (data == null) data = new byte[0];
        requireRange(offset, data.length);
        return ByteCodec.concat(new byte[] {(byte)ProtocolProfile.CMD_WRITE}, ByteCodec.u32be(id), ByteCodec.u16be(offset), ByteCodec.u16be(data.length), data);
    }

    public static byte[] encodeFloat32Write(int id, float value) {
        return encodeWrite(id, 0, ByteCodec.f32le(value));
    }

    public static ReadResponse decodeReadResponse(byte[] bytes) {
        if (bytes == null || bytes.length < 9) throw new IllegalArgumentException("read response too short");
        int cmd = bytes[0] & 0xff;
        if (cmd != ProtocolProfile.CMD_READ_RESPONSE) throw new IllegalArgumentException("not a 0x60 read response");
        int id = ByteCodec.readI32be(bytes, 1);
        int offset = ByteCodec.readU16be(bytes, 5);
        int length = ByteCodec.readU16be(bytes, 7);
        if (bytes.length != 9 + length) throw new IllegalArgumentException("length mismatch");
        byte[] data = new byte[length];
        System.arraycopy(bytes, 9, data, 0, length);
        return new ReadResponse(id, offset, data);
    }

    private static void requireRange(int offset, int length) {
        if (offset < 0 || offset > 0xffff || length < 0 || length > 0xffff) throw new IllegalArgumentException("UFE range");
    }

    public static final class ReadResponse {
        public final int id;
        public final int offset;
        public final byte[] data;
        public ReadResponse(int id, int offset, byte[] data) { this.id = id; this.offset = offset; this.data = data; }
        public Float float32leOrNull() { return data.length == 4 ? ByteCodec.readF32le(data, 0) : null; }
    }
}
