# Version 2 Phase 1 hardening: no custom shrinking rules are required.
