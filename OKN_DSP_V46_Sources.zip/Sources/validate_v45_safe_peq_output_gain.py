#!/usr/bin/env python3
from pathlib import Path
import json, math, re, sys
ROOT=Path(__file__).resolve().parents[1]
view=(ROOT/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
ble=(ROOT/'app/src/main/java/com/okn/dsp/BleManager.java').read_text()
dsp=(ROOT/'app/src/main/java/com/okn/dsp/DspProtocol.java').read_text()
state=(ROOT/'app/src/main/java/com/okn/dsp/DspState.java').read_text()
gradle=(ROOT/'app/build.gradle').read_text()
desc=json.loads((ROOT/'Sources/ProtocolEvidence/GoloPine_DeviceDescription_REAL_20260906_204555.json').read_text())

def req(cond,msg):
    if not cond:
        raise SystemExit('FAIL: '+msg)

req('versionCode 1045' in gradle and "versionName '45.0.0'" in gradle, 'V45 version mismatch')
req('OUTPUT_GAIN_CARRIER_BAND0 = 1' in dsp, 'carrier must be Band2/ui index1')
req('outputCarrierFromCurrent' in dsp and 'outputCarrierGainDb' in dsp, 'carrier builder/readback missing')
req('requestedGainDb < -12f || requestedGainDb > 0f' in dsp, 'protocol attenuation guard missing')
req('gainDb < -12f || gainDb > 0f' in ble, 'BLE attenuation guard missing')
req('state.channelVolume[ch], -12f, 0f' in view, 'UI range is not -12..0')
req('clamp(value, -12f, 0f)' in state, 'state channel-volume setter still allows positive values')
req('clamp(prefs.getFloat("channelVolume_" + ch, DEFAULT_CHANNEL_VOL[ch]), -12f, 0f)' in state, 'stored positive channel volume not clamped on load')
req('DspProtocol.encodeEqWrite(ch, band0 + 1, target)' in ble, 'carrier packet does not use computed Band2')
req('DspProtocol.outputCarrierFromCurrent(current, gain)' in ble, 'Out Volume is not built from safe carrier')
req('DspProtocol.outputCarrierGainDb(carrier)' in ble, 'carrier readback not derived from coefficients')
req('eqBands[ch][DspProtocol.OUTPUT_GAIN_CARRIER_BAND0]' in ble, 'carrier row not used in hardware path')
req('firstBandChannelGainFromCurrent(current, gain)' not in ble, 'runtime still uses old Band1/native-G Out Volume path')
req('DspProtocol.encodeEqWrite(ch, 1, target)' not in ble, 'runtime still writes Out Volume to Band1')
req('if (channel0 == 2) state.setEqGain(2, 0, gainDb);' not in view, 'CH3 Out Volume still coupled to Band1 EQ')
req('if (ch == 2 && b == 0) state.setChannelVolume(2, next);' not in view, 'CH3 EQ still drives Out Volume')
req('ble.setChannelVolumeRealtime(s.index, state.channelVolume[s.index])' in view, 'touch-release commit missing')
# Preserve carrier attenuation whenever Band2 EQ parameters are edited/reset.
req(ble.count('DspProtocol.outputCarrierFromCurrent(target, carrierAtten)') >= 3,
    'Band2 EQ gain/shape/reset do not all preserve Out Volume')
# Native special Band1 EQ path remains available for EQ itself, but never for Out Volume.
req('DspProtocol.firstBandGainFromCurrent(current, gainDb)' in ble, 'native Band1 EQ gain path was accidentally removed')

# Descriptor proof: Band2 is strict-safe PEAKING on all seven output actuators.
ids=[4,5,6,14,15,16,17]
acts={a.get('ID'):a for a in desc.get('actuators',[]) if a.get('ID') in ids}
req(set(acts)==set(ids), 'missing output actuator in descriptor')
carrier=[]
for aid in ids:
    b=acts[aid]['UFE_TYPE_BIQUAD_CASCADE15_F'][1]
    finite=all(isinstance(b.get(k),(int,float)) and math.isfinite(float(b[k])) for k in ('F','F2','Q','B','G','R','B0','B1','B2','A1','A2'))
    safe=(b.get('typ')==12 and finite and 20<=b['F']<=20000 and .05<=b['Q']<=20 and abs(b['R'])<=1e-4 and -12<=b['B']<=12)
    req(safe, f'actuator {aid} Band2 is not strict-safe PEAKING')
    carrier.append((aid,b))

# Replay nominal PEQ coefficients and prove -6 dB is a constant full-band numerator scale.
def peaking(f,q,boost):
    A=10**(boost/40.0)
    w0=2*math.pi*f/44100.0
    alpha=math.sin(w0)/(2*q)
    a0=1+alpha/A
    return ((1+alpha*A)/a0, (-2*math.cos(w0))/a0, (1-alpha*A)/a0,
            (-2*math.cos(w0))/a0, (1-alpha/A)/a0)
k=10**(-6/20.0)
max_capture_err=0.0
for aid,b in carrier:
    nom=peaking(float(b['F']),float(b['Q']),float(b['B']))
    cap=(float(b['B0']),float(b['B1']),float(b['B2']),float(b['A1']),float(b['A2']))
    max_capture_err=max(max_capture_err,max(abs(x-y) for x,y in zip(nom,cap)))
    target=(nom[0]*k,nom[1]*k,nom[2]*k,cap[3],cap[4])
    ratios=[target[i]/nom[i] for i in range(3) if abs(nom[i])>1e-7]
    req(all(abs(r-k)<1e-12 for r in ratios), f'actuator {aid} numerator is not constant-scaled')
    req(target[3]==cap[3] and target[4]==cap[4], f'actuator {aid} denominator changed')
req(max_capture_err < 3e-5, f'carrier nominal replay error too large {max_capture_err}')

# ACTION_MOVE remains UI-only; hardware write is release-only.
m=re.search(r'else if \(s\.type == SL_CHANNEL\) \{(.*?)\n\s*\} else if \(s\.type == SL_EQ_FREQ\)', view, re.S)
req(m is not None, 'SL_CHANNEL block missing')
req('setChannelVolumeRealtime' not in m.group(1), 'ACTION_MOVE still transmits Out Volume')
up=view[view.index('case MotionEvent.ACTION_UP:'):view.index('// A clean tap on a slider')]
req('commitSlider(activeSlider);' in up and 'applySlider(activeSlider, x);' not in up,
    'fast ACTION_UP safety regression')

print('V45 SAFE PEQ OUTPUT GAIN validation: PASS')
print('carrier=Band2 type12 on actuators 4,5,6,14,15,16,17')
print(f'carrier nominal replay maxErr={max_capture_err:.8g}')
print(f'-6dB numerator scale={k:.10f}; denominator unchanged')
print('Band1/native G Out Volume runtime path: DISABLED')
print('range=-12..0 dB; release-to-apply retained')
