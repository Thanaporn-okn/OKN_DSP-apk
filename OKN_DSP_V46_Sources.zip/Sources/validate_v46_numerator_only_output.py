#!/usr/bin/env python3
from pathlib import Path
import json, math, re, struct
ROOT=Path(__file__).resolve().parents[1]
view=(ROOT/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
ble=(ROOT/'app/src/main/java/com/okn/dsp/BleManager.java').read_text()
dsp=(ROOT/'app/src/main/java/com/okn/dsp/DspProtocol.java').read_text()
state=(ROOT/'app/src/main/java/com/okn/dsp/DspState.java').read_text()
gradle=(ROOT/'app/build.gradle').read_text()
desc=json.loads((ROOT/'Sources/ProtocolEvidence/GoloPine_DeviceDescription_REAL_20260906_204555.json').read_text())
def req(c,m):
    if not c: raise SystemExit('FAIL: '+m)
req('versionCode 1046' in gradle and "versionName '46.0.0'" in gradle, 'V46 version mismatch')
req('EQ_NUMERATOR_OFFSET_BYTES = 28' in dsp, 'numerator offset must be 28')
req('EQ_NUMERATOR_BYTES = 12' in dsp, 'numerator payload must be 12 bytes')
req('encodeEqNumeratorWrite' in dsp, 'numerator-only encoder missing')
req('data.putFloat(target.b0)' in dsp and 'data.putFloat(target.b1)' in dsp and 'data.putFloat(target.b2)' in dsp, 'B0/B1/B2 payload incomplete')
req('eqBandOffset(band1) + EQ_NUMERATOR_OFFSET_BYTES' in dsp, 'numerator memory offset wrong')
req('DspProtocol.encodeEqNumeratorWrite(ch, band0 + 1, target)' in ble, 'Out Volume does not use numerator-only encoder')
# channelGain factory must not use full row encoder
m=re.search(r'static PendingCommand channelGain\(int ch, DspProtocol\.EqBand target\) \{(.*?)\n\s*\}',ble,re.S)
req(m is not None, 'channelGain factory missing')
req('encodeEqNumeratorWrite' in m.group(1), 'channelGain is not numerator-only')
req('encodeEqWrite' not in m.group(1), 'channelGain still rewrites full 48-byte row')
req('requestedGainDb < -12f || requestedGainDb > 0f' in dsp, 'protocol attenuation guard missing')
req('gainDb < -12f || gainDb > 0f' in ble, 'BLE attenuation guard missing')
req('state.channelVolume[ch], -12f, 0f' in view, 'UI range is not -12..0')
req('clamp(value, -12f, 0f)' in state, 'state positive guard missing')
# release only
sm=re.search(r'else if \(s\.type == SL_CHANNEL\) \{(.*?)\n\s*\} else if \(s\.type == SL_EQ_FREQ\)',view,re.S)
req(sm is not None and 'setChannelVolumeRealtime' not in sm.group(1), 'ACTION_MOVE still transmits')
up=view[view.index('case MotionEvent.ACTION_UP:'):view.index('// A clean tap on a slider')]
req('commitSlider(activeSlider);' in up and 'applySlider(activeSlider, x);' not in up, 'ACTION_UP resample regression')
# descriptor Band2 proof and packet-layout proof
ids=[4,5,6,14,15,16,17]
acts={a.get('ID'):a for a in desc.get('actuators',[]) if a.get('ID') in ids}
req(set(acts)==set(ids),'descriptor output actuator set incomplete')
k=10**(-6/20.0)
def peaking(f,q,boost):
    A=10**(boost/40.0); w=2*math.pi*f/44100.0; alpha=math.sin(w)/(2*q); a0=1+alpha/A
    return ((1+alpha*A)/a0,(-2*math.cos(w))/a0,(1-alpha*A)/a0,(-2*math.cos(w))/a0,(1-alpha/A)/a0)
for aid in ids:
    b=acts[aid]['UFE_TYPE_BIQUAD_CASCADE15_F'][1]
    req(b['typ']==12 and abs(b['R'])<=1e-4,'Band2 carrier not safe for actuator '+str(aid))
    nom=peaking(float(b['F']),float(b['Q']),float(b['B']))
    target=[nom[0]*k,nom[1]*k,nom[2]*k]
    payload=b''.join(struct.pack('<f',x) for x in target)
    req(len(payload)==12,'numerator payload not 12 bytes')
# UFE packet plain length = 9 header + 12 payload = 21, offset Band2=48+28=76
req(48+28==76,'Band2 numerator offset proof failed')
print('V46 NUMERATOR-ONLY OUTPUT validation: PASS')
print('Out Volume packet: UFE 0x57, Band2 offset=76 (0x004C), payload=12 (0x000C)')
print(f'-6dB scale={k:.10f}; only B0/B1/B2 transmitted')
print('Full 48-byte Out Volume row rewrite: DISABLED')
print('Range=-12..0 dB; release-to-apply retained')
