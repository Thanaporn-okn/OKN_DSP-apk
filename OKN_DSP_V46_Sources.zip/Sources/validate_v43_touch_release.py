#!/usr/bin/env python3
from pathlib import Path
import re
ROOT=Path(__file__).resolve().parents[1]
view=(ROOT/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
ble=(ROOT/'app/src/main/java/com/okn/dsp/BleManager.java').read_text()
gradle=(ROOT/'app/build.gradle').read_text()

def req(cond,msg):
    if not cond: raise SystemExit('FAIL: '+msg)

req('versionCode 1043' in gradle and "versionName '43.0.0'" in gradle, 'V43 version mismatch')
req('private void commitSlider(SliderHit s)' in view, 'commitSlider missing')
req('s.type != SL_CHANNEL' in view, 'commitSlider not channel-scoped')
req('ble.setChannelVolumeRealtime(s.index, state.channelVolume[s.index])' in view, 'final channel commit missing')
req('commitSlider(activeSlider);' in view, 'drag ACTION_UP commit missing')
req('commitSlider(pendingSlider);' in view, 'tap commit missing')

m=re.search(r'else if \(s\.type == SL_CHANNEL\) \{(.*?)\n\s*\} else if \(s\.type == SL_EQ_FREQ\)', view, re.S)
req(m is not None, 'SL_CHANNEL apply block not found')
body=m.group(1)
req('setChannelVolumeRealtime' not in body, 'ACTION_MOVE still transmits Out Volume')
req('state.setChannelVolume(s.index, next)' in body, 'local preview update missing')
req('CHANNEL_GAIN_MIN_GAP_MS = 120L' in ble, 'safe final-write pacing changed')
req('firstBandChannelGainFromCurrent' in ble, 'verified native G writer missing')
req('channelGainPending.remove(channel0)' in ble and 'channelGainPending.put(channel0, rounded)' in ble, 'latest-wins transport guard missing')

print('V43 Out Volume touch-release validation: PASS')
print('ACTION_MOVE=UI preview only; ACTION_UP/tap=single hardware commit')
print('Verified V42 native G mapping preserved; final-write pacing >=120 ms')
