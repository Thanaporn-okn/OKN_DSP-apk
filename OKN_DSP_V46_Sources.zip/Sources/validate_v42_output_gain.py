#!/usr/bin/env python3
from pathlib import Path
import json, math, re

ROOT = Path(__file__).resolve().parents[1]
BLE = (ROOT/'app/src/main/java/com/okn/dsp/BleManager.java').read_text()
DSP = (ROOT/'app/src/main/java/com/okn/dsp/DspProtocol.java').read_text()
VIEW = (ROOT/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
MAIN = (ROOT/'app/src/main/java/com/okn/dsp/MainActivity.java').read_text()
STATE = (ROOT/'app/src/main/java/com/okn/dsp/DspState.java').read_text()
GRADLE = (ROOT/'app/build.gradle').read_text()
DESC = json.loads((ROOT/'Sources/ProtocolEvidence/GoloPine_DeviceDescription_REAL_20260906_204555.json').read_text())

def req(cond, msg):
    if not cond:
        raise AssertionError(msg)

def near(a,b,tol,msg):
    req(abs(a-b) <= tol, f'{msg}: {a} vs {b}')

req("versionCode 1042" in GRADLE and "versionName '42.0.0'" in GRADLE, 'V42 version mismatch')
req('static final int[] EQ_ACTUATORS = {4, 5, 6, 14, 15, 16, 17};' in DSP, 'verified seven actuator map changed')
req('firstBandChannelGainFromCurrent' in DSP, 'V42 channel-gain builder missing')
req('toneControlCellGainFromCurrent' in DSP, 'Tone Control G builder missing')
req('setChannelVolumeRealtime' in BLE, 'BLE channel-gain entry missing')
req('CHANNEL_GAIN_MIN_GAP_MS = 120L' in BLE, 'V42 output pacing changed')
req('channelGainPending.remove(channel0)' in BLE and 'channelGainPending.put(channel0, rounded)' in BLE, 'latest-wins queue missing')
req('DspProtocol.firstBandChannelGainFromCurrent(current, gain)' in BLE, 'send-time live-record rebuild missing')
req('PendingCommand.channelGain(ch, target)' in BLE, 'channel-gain packet path missing')
req('DspProtocol.encodeEqWrite(ch, 1, target)' in BLE, 'band-1 full record write missing')
req('onChannelVolumeValue' in BLE and 'onChannelVolumeValue' in MAIN and 'setChannelVolumeFromDsp' in VIEW, 'DSP readback sync path incomplete')
req('Out Volume Ch' in VIEW, 'Out Volume UI label missing')
req('DSP Out Gain • native first-cell G mapping' in VIEW, 'V42 UI mapping note missing')
req('DEFAULT_CHANNEL_VOL = {0f, 0f, 0f, 0f, 0f, 0f, 0f}' in STATE, 'channel defaults must be neutral 0 dB')
# Existing Save/Restore safety must remain.
for token in ['ID_SAVE_PARAMS = 7','encodeSaveParamsTrigger','SAVE_PRECHECK','SAVE_POSTCHECK','requestVerifiedRestore','DO NOT RETRY automatically']:
    req(token in (DSP+BLE), 'V41 safety invariant missing: '+token)
req('safePeakingRows == EXPECTED_SAFE_PEAKING_ROWS' in BLE, '55-row safe gate missing')
req('boolean eqOk = eqCount == 105;' in BLE, '105-row descriptor gate missing')

acts={a['ID']:a for a in DESC['actuators']}
expected=[(4,17),(5,17),(6,3),(14,17),(15,17),(16,17),(17,17)]
fs=44100.0
for aid, typ in expected:
    req(aid in acts, f'actuator {aid} missing')
    arr=acts[aid].get('UFE_TYPE_BIQUAD_CASCADE15_F')
    req(isinstance(arr,list) and len(arr)>=1, f'actuator {aid} first record missing')
    b=arr[0]
    req(b['typ']==typ, f'actuator {aid} first type changed')
    near(float(b['G']),0.0,1e-6,f'actuator {aid} baseline G')
    target=-6.0
    ratio=10**(target/20.0)
    if typ==17:
        tb=10**(float(b['R'])/20.0); bb=10**(float(b['B'])/20.0)
        at=math.tan(math.pi*float(b['F2'])/fs); ab=math.tan(math.pi*float(b['F'])/fs)
        knumT=2/(1+1/tb); kdenT=2/(1+tb); knumB=2/(1+1/bb); kdenB=2/(1+bb)
        a10=at+kdenT; b10=at+knumT; a11=at-kdenT; b11=at-knumT
        a20=ab*kdenB+1; b20=ab*knumB-1; a21=ab*kdenB-1; b21=ab*knumB+1; a0=a10*a20
        coeff=[(b10*b20)/a0, ((b10*b21)+(b11*b20))/a0, (b11*b21)/a0,
               ((a10*a21)+(a11*a20))/a0, (a11*a21)/a0]
    else:
        w0=2*math.pi*float(b['F'])/fs; cs=math.cos(w0); sn=math.sin(w0); alpha=sn/(2*float(b['Q'])); a0=1+alpha
        coeff=[((1-cs)/2)/a0, (1-cs)/a0, ((1-cs)/2)/a0, (-2*cs)/a0, (1-alpha)/a0]
    captured=[float(b['B0']),float(b['B1']),float(b['B2']),float(b['A1']),float(b['A2'])]
    for i,(x,y) in enumerate(zip(coeff,captured)):
        near(x,y,4e-5,f'actuator {aid} baseline coefficient {i}')
    # -6 dB G scales numerator only.
    for i in range(3):
        near((coeff[i]*ratio)/coeff[i],ratio,1e-12,f'actuator {aid} numerator ratio {i}')

print('V42 Out Volume validation: PASS')
print('actuators=4,5,6,14,15,16,17; band1 offset=0; payload=48 bytes')
print('G=-6 dB numerator ratio=%.10f; denominator unchanged' % (10**(-6/20)))
print('latest-wins output lane >=120 ms; no invented ChannelVolume actuator')
