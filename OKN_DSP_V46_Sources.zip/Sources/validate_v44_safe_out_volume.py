#!/usr/bin/env python3
from pathlib import Path
import re
ROOT=Path(__file__).resolve().parents[1]
view=(ROOT/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
ble=(ROOT/'app/src/main/java/com/okn/dsp/BleManager.java').read_text()
dsp=(ROOT/'app/src/main/java/com/okn/dsp/DspProtocol.java').read_text()
gradle=(ROOT/'app/build.gradle').read_text()

def req(cond,msg):
    if not cond: raise SystemExit('FAIL: '+msg)

req('versionCode 1044' in gradle and "versionName '44.0.0'" in gradle, 'V44 version mismatch')
req('state.channelVolume[ch], -12f, 0f' in view, 'Out Volume UI is not capped at 0 dB')
req('gainDb < -12f || gainDb > 0f' in ble, 'BLE Out Volume positive-value guard missing')
req('requestedGainDb < -12f || requestedGainDb > 0f' in dsp, 'protocol Out Volume positive-value guard missing')
req('ble.setChannelVolumeRealtime(s.index, state.channelVolume[s.index])' in view, 'final Out Volume commit missing')
req('commitSlider(pendingSlider);' in view, 'tap-to-commit missing')
# Active drags must commit the last ACTION_MOVE preview and must not re-sample release x.
up=view[view.index('case MotionEvent.ACTION_UP:'):view.index('// A clean tap on a slider')]
req('if (activeSlider != null)' in up, 'activeSlider ACTION_UP block missing')
req('commitSlider(activeSlider);' in up, 'active drag final commit missing')
req('applySlider(activeSlider, x);' not in up, 'ACTION_UP still re-samples fast release coordinate')
# ACTION_MOVE remains UI-only for Out Volume.
m2=re.search(r'else if \(s\.type == SL_CHANNEL\) \{(.*?)\n\s*\} else if \(s\.type == SL_EQ_FREQ\)', view, re.S)
req(m2 is not None, 'SL_CHANNEL apply block not found')
req('setChannelVolumeRealtime' not in m2.group(1), 'ACTION_MOVE still transmits Out Volume')
req('state.setChannelVolume(s.index, next)' in m2.group(1), 'local drag preview missing')
# Proven mapping and safety gates remain.
req('static final int[] EQ_ACTUATORS = {4, 5, 6, 14, 15, 16, 17};' in dsp, 'verified actuator map changed')
req('DspProtocol.firstBandChannelGainFromCurrent(current, gain)' in ble, 'verified channel-gain builder path changed')
req('DspProtocol.encodeEqWrite(ch, 1, target)' in ble, 'final first-record packet path changed')
req('CHANNEL_GAIN_MIN_GAP_MS = 120L' in ble, 'output pacing guard changed')
req('safePeakingRows == EXPECTED_SAFE_PEAKING_ROWS' in ble, '55-row safe PEQ gate missing')
print('V44 Safe Out Volume validation: PASS')
print('range=-12..0 dB; positive hardware writes rejected')
print('ACTION_MOVE=preview only; ACTION_UP=commit last preview without release-x resample')
print('V42 actuator/native-G mapping preserved')
