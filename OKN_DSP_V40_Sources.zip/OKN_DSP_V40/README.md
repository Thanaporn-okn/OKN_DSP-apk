# OKN DSP V40

Base: **V39 real-hardware stable**.

V40 adds **automatic DSP readback/synchronization** without changing the V39 hardware writer. After initial connection, reconnect, or manual refresh, the authenticated fresh Device Description is treated as the authoritative snapshot. The UI is updated with current Master/Bass/BassCutoff and all 7 x 15 EQ Frequency/Q/Gain values, writable locks are rebuilt, then the synchronized state is checkpointed locally.

Safety boundary: readback callbacks do not echo values back to the DSP; no new actuator mapping or packet format is introduced; SaveParams is never automatic; V38 safe-PEQ gating and V39 Gain-only Safe Reset remain unchanged.

Version: **40.0.0** (`versionCode 1040`)
