# HeavyMarket v3 — Mobile GitHub Build

รุ่นนี้ออกแบบสำหรับอัปโหลดผ่านมือถือเป็น **2 ไฟล์เท่านั้น**:

1. `HeavyMarketApp_v3.zip` — ซอร์สโค้ด Android ทั้งหมด
2. `build-apk.yml` — GitHub Actions workflow สำหรับแตก ZIP และ build APK อัตโนมัติ

> สำคัญ: GitHub Actions จะอ่าน workflow เฉพาะไฟล์ที่อยู่ใน `.github/workflows/` เท่านั้น ดังนั้นให้วาง `build-apk.yml` ที่ path นั้น ส่วน ZIP ให้วางที่ root ของ repository.

Workflow จะเลือก `HeavyMarketApp_v*.zip` ที่เลขเวอร์ชันสูงสุดเอง จึงอัปโหลด v4/v5 ในอนาคตได้โดยไม่ต้องแก้ชื่อ ZIP ใน YAML.

---

# Heavy Market Android

แอปรวมประกาศขายรถบรรทุก/เครื่องจักรหนัก มี 3 หน้าหลัก:

1. **ล่าสุด** — รายการขายล่าสุด + refresh อัตโนมัติทุก 30 วินาที
2. **ในกลุ่ม** — แสดงรายการจาก backend ที่คุณมีสิทธิ์นำเข้าจากกลุ่ม/แหล่งข้อมูลที่อนุญาต
3. **Marketplace** — หน้าค้นหา/หมวดหมู่แบบ marketplace สำหรับรถบรรทุก รถหกล้อ รถดั้ม แม็คโค รถไถ หัวลาก อะไหล่ และอื่นๆ

## ใช้งานทันที

ถ้ายังไม่ตั้ง `DATA_API_BASE` แอปจะเปิดด้วยข้อมูลตัวอย่าง เพื่อให้ทดสอบหน้าจอและ APK ได้ทันที

แอปรับ Share จาก Facebook ได้: เปิดโพสต์ > Share > เลือก **Heavy Market** รายการจะถูกเก็บเข้า “ล่าสุด” ในเครื่อง

## Build APK อัตโนมัติบน GitHub

1. แตก ZIP นี้ก่อน แล้วอัปโหลดไฟล์ทั้งหมดเข้า repository (GitHub ไม่แตก ZIP ใน repository ให้อัตโนมัติ)
2. Push เข้า branch `main` หรือ `master`
3. เปิดแท็บ **Actions** > **Build HeavyMarket APK**
4. เมื่อเสร็จ เข้า build run > **Artifacts** > ดาวน์โหลด `HeavyMarket-v1.0.X`

เลขเวอร์ชันถูกสร้างจาก `GITHUB_RUN_NUMBER` + `GITHUB_RUN_ATTEMPT` อัตโนมัติ จึงไม่ต้องเปิดไฟล์มาเปลี่ยน versionCode/versionName ทุกครั้ง และการ Re-run หลัง error จะได้เวอร์ชันย่อยใหม่ด้วย

ถ้า build รอบหนึ่ง error ให้แก้สาเหตุหรือกด Re-run; `run_attempt` จะเพิ่มและได้ชื่อเวอร์ชันใหม่อัตโนมัติ พร้อมเก็บ build reports ตอนล้มเหลวไว้ให้ตรวจ

## ข้อมูลจริง

ตั้ง Repository Variable ชื่อ `DATA_API_BASE` ตามเอกสาร `docs/BACKEND_API_TH.md`.

## v2 — เน้นสินค้ามือสอง

- ค่าเริ่มต้นทุกหน้าเป็น **มือสองเด่น**: รายการที่ตรวจพบว่าเป็นมือสองขึ้นก่อน และซ่อนรายการที่ระบุชัดว่าเป็นรถใหม่/มือหนึ่ง/ป้ายแดง
- มีตัวกรอง **มือสองเท่านั้น** และ **ดูทั้งหมด**
- แสดงป้าย `มือสอง` บนรายการที่ตรวจพบจากข้อความ เช่น มือสอง, รถบ้าน, เจ้าของขายเอง, ผ่านการใช้งาน, พร้อมใช้งาน, เอกสาร/ทะเบียน ฯลฯ
- ยังคงเรียงรายการล่าสุดภายในกลุ่มความสำคัญเดียวกัน
- ฝั่ง API สามารถส่งประกาศตาม schema เดิมได้ ระบบในแอปจะช่วยจัดลำดับและกรองมือสองเพิ่มอีกชั้น

## v4 - GitHub Actions build fix
- แก้ปัญหา `sdkmanager tools` / `Failed to find package 'tools'`
- workflow ใหม่ไม่ใช้ `android-actions/setup-android@v3`
- ใช้ Android SDK ที่ติดตั้งมากับ GitHub-hosted Ubuntu runner และติดตั้งเฉพาะแพ็กเกจที่ขาด
- build ด้วย Gradle 8.9 ผ่าน `./gradlew`
- workflow ใช้ GitHub Actions รุ่นที่รองรับ Node 24
