package com.okn.dsp

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * V64 production verified control hub.
 *
 * ID3 RemindSoundVolume is promoted into Production Global Controls only after the
 * V63 guarded runtime proof succeeded: fresh baseline -> +1.0 dB target -> descriptor
 * verify -> exact auto-restore -> restore verify, with no SaveParams.
 *
 * Launcher rule remains strict: no mock/local DSP controls and no generic writes.
 */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
    }

    private fun buildUi(): ScrollView {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 32)
        }

        root.addView(TextView(this).apply {
            text = "OKN DSP V64 — PRODUCTION VERIFIED CONTROL HUB"
            textSize = 22f
        })

        root.addView(TextView(this).apply {
            text = "REAL DSP CONTROLS ONLY • NO MOCK EQ • NO LOCAL PRESET WRITE • GENERIC WRITES LOCKED"
            textSize = 14f
            setPadding(0, 8, 0, 12)
        })

        root.addView(TextView(this).apply {
            text = "Verified writable coverage\n" +
                "• Global FLOAT32: ID2 MasterVolume, ID3 RemindSoundVolume, ID8 BassVolume, ID9 BassCutoff, ID10 BassBoost, ID13 MiddleBoost, ID11 TrebleBoost\n" +
                "• ID3 promotion basis: V63 guarded proof passed target readback + exact restore at -70 → -69 → -70 dB with NO SaveParams\n" +
                "• EQ 7CH: CH1–CH7 actuator IDs 4,5,6,14,15,16,17 • 15 bands/channel • writable only on verified safe PEAKING bands\n" +
                "• Permanent SAVE: actuator ID7 SaveParams • exact trigger 570000000700000000 • persistence proved with two real power-cycles\n" +
                "• Preset, Delay and unknown writes remain locked."
            textSize = 13f
            setPadding(0, 0, 0, 16)
        })

        root.addView(Button(this).apply {
            text = "GLOBAL CONTROLS • 7 VERIFIED REAL DSP CONTROLS • APPLY + VERIFY + PERMANENT SAVE"
            setOnClickListener { startActivity(Intent(this@MainActivity, ScalarControlActivity::class.java)) }
        })

        root.addView(TextView(this).apply {
            text = "Production Global Controls now includes ID3 RemindSoundVolume. Every APPLY uses WRITE 0x57 → fresh Device Description verify → automatic rollback if verify fails. Permanent Save remains a separate guarded action."
            textSize = 12f
            setPadding(0, 2, 0, 12)
        })

        root.addView(Button(this).apply {
            text = "LIVE EQ 7CH • REAL DSP • APPLY + VERIFY + PERMANENT SAVE"
            setOnClickListener { startActivity(Intent(this@MainActivity, LiveEqActivity::class.java)) }
        })

        root.addView(TextView(this).apply {
            text = "7CH real EQ from live Device Description • 105 bands • writes only verified safe PEAKING bands • automatic rollback when readback does not match."
            textSize = 12f
            setPadding(0, 2, 0, 12)
        })

        root.addView(Button(this).apply {
            text = "ADVANCED • EVIDENCE / CAPTURE LAB (READ-ONLY / PROOF TOOLS)"
            setOnClickListener { startActivity(Intent(this@MainActivity, EvidenceLabActivity::class.java)) }
        })

        root.addView(TextView(this).apply {
            text = "V64 removes the dedicated ID3 proof button from the production launcher because V63 already completed that proof. The proof source/capture remain bundled as evidence; production ID3 control now lives only in the verified Global Controls path."
            textSize = 12f
            setPadding(0, 16, 0, 0)
        })

        return ScrollView(this).apply { addView(root) }
    }
}
