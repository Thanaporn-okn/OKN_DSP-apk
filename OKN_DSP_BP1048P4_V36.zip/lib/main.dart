import 'package:flutter/material.dart';

void main()=>runApp(const App());

class App extends StatelessWidget{
 const App({super.key});
 Widget build(BuildContext c)=>MaterialApp(
 title:'OKN DSP BP1048P4 V36',
 home:Scaffold(
 appBar:AppBar(title:const Text('OKN_DSP BP1048P4 V36')),
 body:const Padding(
 padding:EdgeInsets.all(20),
 child:Text(
 'Bluetooth DSP Controller\n\n'
 'Flutter Project Fixed\n'
 'pubspec.yaml Ready\n'
 'CH1-CH7 DSP Control\n'
 'BP1048P4 TX RX Layer',
 style:TextStyle(fontSize:22))),
 ));
}
