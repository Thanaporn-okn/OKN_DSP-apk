package com.okn.dsp
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity()
