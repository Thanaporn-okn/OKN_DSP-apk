# OKN_BP1048P4_FW_V26

V26 is a numeric/state hardening revision of the portable clean-room firmware foundation. It preserves the V25 release-candidate fuzzing, source inventory, provenance chain, and every fail-closed hardware/mobile-flash gate.

## What V26 adds

- Rejects NaN and positive/negative infinity through the DSP/control mutation path and regression-tests negative ACK/no-revision-bump behavior.
- Canonicalizes accepted `-0.0` to `+0.0` at DSP setters and persistence serialization for deterministic state bytes/readback.
- Keeps runtime persistence restore strictly on schema 2.
- Adds explicit `okn_persist_migrate_v1_state()` for legacy schema-1 **state-only** migration.
- Deliberately does **not** trust or return schema-1 generation because the legacy CRC did not protect that field.
- Adds regression tests proving a schema-1-only storage slot is not auto-restored and payload corruption is rejected during explicit migration.
- Binds the immediate predecessor to the uploaded V25 GitHub validation artifact.

The wire frame remains Protocol V2. Persistence writes remain schema 2. Exact BP1048P4/GoloPine NVM mapping is still unverified.

## Safety status

- Exact BP1048P4/GoloPine hardware integration: LOCKED.
- Hardware flashable: NO.
- Mobile flashable: NO.
- Programmer I/O: NOT IMPLEMENTED.
- Destructive executor: NOT IMPLEMENTED.
- Target `.bin/.img`: NONE.
- No guessed register/address/pin/programmer packet is introduced by V26.
