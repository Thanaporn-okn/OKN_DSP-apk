#!/usr/bin/env python3
from pathlib import Path
import json, sys

ROOT=Path(__file__).resolve().parents[1]
fw=json.loads((ROOT/'firmware_manifest.json').read_text())
h=(ROOT/'src/persist/okn_persistence.h').read_text()
c=(ROOT/'src/persist/okn_persistence.c').read_text()
dsp=(ROOT/'src/core/okn_dsp.c').read_text()
runtime=(ROOT/'src/runtime/okn_runtime.c').read_text()
errors=[]

p=fw.get('persistence',{})
if p.get('schema') != 2: errors.append('current persistence schema must remain 2')
if p.get('legacy_schema1_auto_restore') is not False: errors.append('schema-1 auto restore must remain disabled')
if p.get('legacy_schema1_explicit_state_migration') is not True: errors.append('explicit schema-1 state migration must be enabled')
if p.get('legacy_generation_trusted') is not False: errors.append('schema-1 generation must remain untrusted')
if p.get('canonical_float_zero') is not True: errors.append('canonical float zero policy missing')
if '#define OKN_PERSIST_SCHEMA_LEGACY_V1 1u' not in h: errors.append('legacy schema constant missing')
if 'okn_persist_migrate_v1_state' not in h or 'okn_persist_migrate_v1_state' not in c: errors.append('explicit migration API missing')
if 'image_crc32_schema1_payload' not in c: errors.append('legacy payload CRC verifier missing')
if 'canonical_zero' not in dsp: errors.append('DSP zero canonicalization missing')
if 'okn_persist_migrate_v1_state' in runtime: errors.append('runtime must not auto-invoke legacy migration')
if errors:
    for e in errors: print('BLOCKED:',e)
    sys.exit(1)
print('PASS: V26 numeric/state policy rejects non-finite values, canonicalizes zero, and keeps schema-1 migration explicit/non-automatic')
