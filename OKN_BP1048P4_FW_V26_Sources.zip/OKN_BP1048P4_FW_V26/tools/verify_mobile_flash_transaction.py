#!/usr/bin/env python3
from pathlib import Path
import json, sys
from mobile_flash_transaction import evaluate, SEQUENCE
root=Path(__file__).resolve().parents[1]
tx=json.loads((root/'mobile_flash_transaction.json').read_text())
r=evaluate(root,tx)
errors=list(r['errors'])
if tx.get('state')!='LOCKED': errors.append('shipped V26 transaction must remain LOCKED')
if tx.get('execution_authorized') is not False: errors.append('execution_authorized must be false')
if tx.get('destructive_executor_implemented') is not False: errors.append('destructive executor must be absent')
if tx.get('no_programmer_packets') is not True: errors.append('programmer packet guard must be true')
if tx.get('required_sequence')!=SEQUENCE: errors.append('sequence mismatch')
for key in ('image','backup'):
    rec=tx.get(key,{})
    if rec.get('path') is not None or rec.get('sha256') is not None or rec.get('hash_verified') is not False:
        errors.append(key+' must be empty/unverified in shipped V26')
if r['armable'] or r['destructive_execution_available']: errors.append('shipped V26 must not be executable')
if errors:
    [print('BLOCKED:',e) for e in errors]; sys.exit(1)
print('PASS: V26 mobile flash transaction is input-bound, backup-first, content-hash-verified, and non-executing')
