#!/usr/bin/env python3
from pathlib import Path
import argparse, hashlib, json, sys

EXCLUDED_NAMES = {"source_inventory.json"}
EXCLUDED_DIRS = {"build", "__pycache__", ".git"}
EXCLUDED_SUFFIXES = {".pyc"}

def is_excluded(rel: Path) -> bool:
    if rel.name in EXCLUDED_NAMES:
        return True
    if any(part in EXCLUDED_DIRS for part in rel.parts):
        return True
    if rel.suffix in EXCLUDED_SUFFIXES:
        return True
    return False

def build_inventory(root: Path) -> dict:
    files = []
    for p in sorted(root.rglob("*"), key=lambda x: x.as_posix()):
        if not p.is_file() or p.is_symlink():
            continue
        rel = p.relative_to(root)
        if is_excluded(rel):
            continue
        data = p.read_bytes()
        files.append({
            "path": rel.as_posix(),
            "size": len(data),
            "sha256": hashlib.sha256(data).hexdigest(),
        })
    digest = hashlib.sha256()
    for rec in files:
        digest.update(f"{rec['sha256']}  {rec['size']}  {rec['path']}\n".encode("utf-8"))
    return {
        "schema": 1,
        "project_version": 26,
        "algorithm": "SHA-256",
        "self_excluded": "source_inventory.json",
        "generated_artifacts_excluded": ["build/**", "**/__pycache__/**", "**/*.pyc"],
        "file_count": len(files),
        "aggregate_sha256": digest.hexdigest(),
        "files": files,
        "authorizes_hardware": False,
        "authorizes_mobile_flash": False,
    }

def main() -> int:
    ap = argparse.ArgumentParser(description="Generate/verify deterministic V26 shipped-source inventory.")
    ap.add_argument("--root", default=str(Path(__file__).resolve().parents[1]))
    ap.add_argument("--write", action="store_true")
    args = ap.parse_args()
    root = Path(args.root).resolve()
    path = root / "source_inventory.json"
    actual = build_inventory(root)
    if args.write:
        path.write_text(json.dumps(actual, indent=2) + "\n", encoding="utf-8")
        print(f"WROTE source_inventory.json files={actual['file_count']} aggregate={actual['aggregate_sha256']}")
        return 0
    if not path.exists():
        print("BLOCKED: source_inventory.json missing")
        return 1
    expected = json.loads(path.read_text(encoding="utf-8"))
    if expected != actual:
        exp = {x["path"]: x for x in expected.get("files", [])}
        act = {x["path"]: x for x in actual.get("files", [])}
        for name in sorted(set(exp) | set(act)):
            if name not in exp:
                print("BLOCKED: unexpected shipped file:", name)
            elif name not in act:
                print("BLOCKED: missing shipped file:", name)
            elif exp[name] != act[name]:
                print("BLOCKED: changed shipped file:", name)
        if expected.get("aggregate_sha256") != actual.get("aggregate_sha256"):
            print("BLOCKED: aggregate SHA-256 mismatch")
        return 1
    print(f"PASS: V26 source inventory verifies {actual['file_count']} files aggregate={actual['aggregate_sha256']}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
