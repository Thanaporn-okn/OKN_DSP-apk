#include "../src/core/okn_controller.h"
#include "../src/core/okn_protocol.h"
#include "../src/runtime/okn_runtime.h"
#include <assert.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

static void write_f32_le(uint8_t *p, float f) {
    uint32_t u; memcpy(&u, &f, sizeof(u));
    p[0]=(uint8_t)u; p[1]=(uint8_t)(u>>8); p[2]=(uint8_t)(u>>16); p[3]=(uint8_t)(u>>24);
}
static size_t finish_pkt(uint8_t *p, uint8_t cmd, uint16_t plen) {
    p[0]='O'; p[1]='K'; p[2]=OKN_PROTO_VERSION; p[3]=cmd; p[4]=(uint8_t)plen; p[5]=(uint8_t)(plen>>8);
    uint16_t crc=okn_crc16_ccitt(p, 6u+plen); p[6u+plen]=(uint8_t)crc; p[7u+plen]=(uint8_t)(crc>>8); return 8u+plen;
}
static size_t make_set_gain(uint8_t *p, uint8_t ch, float db) {
    p[6]=ch; write_f32_le(&p[7], db); return finish_pkt(p, OKN_CMD_SET_CH_GAIN, 5u);
}
static size_t make_set_peq(uint8_t *p, uint8_t ch, uint8_t band, float hz, float gain, float q) {
    p[6]=ch; p[7]=band; p[8]=1; p[9]=OKN_FILTER_PEQ;
    write_f32_le(&p[10],hz); write_f32_le(&p[14],gain); write_f32_le(&p[18],q);
    return finish_pkt(p, OKN_CMD_SET_PEQ, 16u);
}

static unsigned mock_master_calls, mock_channel_calls;
static int mock_init(void){return OKN_OK;} static int mock_mute(bool enable){(void)enable;return OKN_OK;} static int mock_audio(void){return OKN_OK;}
static int mock_master(float db){(void)db; ++mock_master_calls; return OKN_OK;}
static int mock_channel(unsigned ch,const okn_channel_state_t *s){(void)ch;(void)s;++mock_channel_calls;return OKN_OK;}
static int mock_notify(const uint8_t *p,size_t n){(void)p;(void)n;return OKN_OK;}
static const bp1048p4_hal_t MOCK_HAL={
 .platform_init=mock_init,.set_output_safety_mute=mock_mute,.audio_start=mock_audio,
 .apply_master_gain=mock_master,.apply_channel_state=mock_channel,.ble_notify=mock_notify
};

int main(void) {
    okn_controller_t ctl; okn_controller_init(&ctl);
    assert(OKN_CHANNELS==7u && OKN_PEQ_BANDS==15u);
    assert(okn_validate_state(&ctl.state)==OKN_OK);
    assert(okn_crc16_ccitt((const uint8_t*)"123456789",9)==0x29B1u);

    assert(okn_set_channel_gain(&ctl.state,0,-6.0f)==OKN_OK);
    assert(okn_set_channel_gain(&ctl.state,7,-6.0f)==OKN_ERR_ARG);
    assert(okn_set_channel_delay(&ctl.state,6,50.0f)==OKN_OK);
    assert(okn_set_channel_delay(&ctl.state,6,50.1f)==OKN_ERR_RANGE);
    assert(okn_set_peq_band(&ctl.state,0,14,true,OKN_FILTER_PEQ,1000.0f,3.0f,1.2f)==OKN_OK);
    assert(okn_set_peq_band(&ctl.state,0,15,true,OKN_FILTER_PEQ,1000.0f,3.0f,1.2f)==OKN_ERR_ARG);
    assert(okn_set_hpf(&ctl.state,0,true,80.0f,0.707f)==OKN_OK);
    assert(okn_set_lpf(&ctl.state,0,true,18000.0f,0.707f)==OKN_OK);

    /* V26 numeric hardening: non-finite values are never accepted, and
     * negative zero is canonicalized at the state mutation boundary. */
    assert(okn_set_master_gain(&ctl.state,NAN)==OKN_ERR_RANGE);
    assert(okn_set_channel_gain(&ctl.state,0,INFINITY)==OKN_ERR_RANGE);
    assert(okn_set_channel_delay(&ctl.state,0,-INFINITY)==OKN_ERR_RANGE);
    assert(okn_set_channel_gain(&ctl.state,0,-0.0f)==OKN_OK);
    assert(ctl.state.ch[0].gain_db==0.0f && !signbit(ctl.state.ch[0].gain_db));


    /* V13 controller mutation boundary is atomic with dirty/revision metadata. */
    okn_controller_t atomic_ctl;
    okn_controller_init(&atomic_ctl);
    uint32_t atomic_rev = atomic_ctl.revision;
    assert(okn_controller_set_channel_gain(&atomic_ctl, 4u, -7.25f) == OKN_OK);
    assert(fabsf(atomic_ctl.state.ch[4].gain_db + 7.25f) < 0.0001f);
    assert(atomic_ctl.revision == atomic_rev + 1u);
    assert((atomic_ctl.channel_dirty_mask & (1u << 4)) != 0u);
    atomic_rev = atomic_ctl.revision;
    const float atomic_gain = atomic_ctl.state.ch[4].gain_db;
    assert(okn_controller_set_channel_gain(&atomic_ctl, 7u, -1.0f) == OKN_ERR_ARG);
    assert(atomic_ctl.revision == atomic_rev);
    assert(atomic_ctl.state.ch[4].gain_db == atomic_gain);

    uint8_t pkt[128], rsp[160]; size_t n,rn=0;
    n=make_set_gain(pkt,2,-9.5f);
    uint32_t rev0=ctl.revision;
    assert(okn_protocol_execute(&ctl,pkt,n,rsp,sizeof(rsp),&rn)==OKN_OK);
    assert(fabsf(ctl.state.ch[2].gain_db+9.5f)<0.0001f);
    assert(ctl.revision==rev0+1u && (ctl.channel_dirty_mask&(1u<<2))!=0u);
    assert(rn>8u && rsp[3]==OKN_CMD_ACK);

    n=make_set_peq(pkt,3,5,1250.0f,-2.5f,1.1f);
    assert(okn_protocol_apply(&ctl,pkt,n)==OKN_OK);
    assert(fabsf(ctl.state.ch[3].peq[5].freq_hz-1250.0f)<0.01f);

    /* Non-finite command payloads are valid frames but invalid commands:
     * negative ACK, no revision bump, no state mutation. */
    n=make_set_gain(pkt,1,NAN); rev0=ctl.revision; rn=0u;
    assert(okn_protocol_execute(&ctl,pkt,n,rsp,sizeof(rsp),&rn)==OKN_OK);
    assert(rsp[3]==OKN_CMD_ACK && ctl.revision==rev0);
    assert((int16_t)((uint16_t)rsp[7] | ((uint16_t)rsp[8] << 8))==OKN_ERR_RANGE);
    n=make_set_gain(pkt,1,INFINITY); rev0=ctl.revision;
    assert(okn_protocol_execute(&ctl,pkt,n,rsp,sizeof(rsp),&rn)==OKN_OK);
    assert(rsp[3]==OKN_CMD_ACK && ctl.revision==rev0);

    /* Bad CRC must not mutate state/revision. */
    n=make_set_gain(pkt,1,-4.0f); rev0=ctl.revision; pkt[n-1]^=1u;
    assert(okn_protocol_apply(&ctl,pkt,n)==OKN_ERR_CRC && ctl.revision==rev0);

    /* GET_INFO reports the actual V26 project version while protocol remains V2. */
    n=finish_pkt(pkt,OKN_CMD_GET_INFO,0u);
    assert(okn_protocol_execute(&ctl,pkt,n,rsp,sizeof(rsp),&rn)==OKN_OK);
    assert(rsp[3]==OKN_CMD_INFO && rsp[6+5]==0u);
    assert(((uint16_t)rsp[6] | ((uint16_t)rsp[7] << 8)) == OKN_FW_VERSION);
    assert(OKN_FW_VERSION == 26u && rsp[8] == OKN_PROTO_VERSION && OKN_PROTO_VERSION == 0x02u);

    /* A valid frame with an invalid application value must still produce a
     * negative ACK and return transport/encoding success so it can be sent. */
    n=make_set_gain(pkt,7u,-6.0f); rev0=ctl.revision; rn=0u;
    assert(okn_protocol_execute(&ctl,pkt,n,rsp,sizeof(rsp),&rn)==OKN_OK);
    assert(rsp[3]==OKN_CMD_ACK && rn==15u && ctl.revision==rev0);
    assert(rsp[6]==OKN_CMD_SET_CH_GAIN);
    assert((int16_t)((uint16_t)rsp[7] | ((uint16_t)rsp[8] << 8)) == OKN_ERR_ARG);


    /* V13 exposes command status independently from transport status. */
    n=make_set_gain(pkt,7u,-6.0f); rev0=ctl.revision;
    okn_protocol_result_t pr=okn_protocol_execute_ex(&ctl,pkt,n,rsp,sizeof(rsp));
    assert(pr.transport_status==OKN_OK && pr.command_evaluated);
    assert(pr.command_status==OKN_ERR_ARG && pr.response_len==15u);
    assert(rsp[3]==OKN_CMD_ACK && ctl.revision==rev0);

    /* A valid read command with invalid payload gets a negative ACK, not a
     * transport abort. */
    pkt[6]=7u; n=finish_pkt(pkt,OKN_CMD_GET_CHANNEL_STATE,1u);
    pr=okn_protocol_execute_ex(&ctl,pkt,n,rsp,sizeof(rsp));
    assert(pr.transport_status==OKN_OK && pr.command_evaluated);
    assert(pr.command_status==OKN_ERR_FORMAT && rsp[3]==OKN_CMD_ACK);

    /* Corrupt framing remains a transport error and no command is evaluated. */
    n=make_set_gain(pkt,1u,-3.0f); pkt[n-1u]^=1u;
    pr=okn_protocol_execute_ex(&ctl,pkt,n,rsp,sizeof(rsp));
    assert(pr.transport_status==OKN_ERR_CRC && !pr.command_evaluated && pr.response_len==0u);

    /* Response-capacity failure is transport-only after a valid command. */
    n=finish_pkt(pkt,OKN_CMD_GET_INFO,0u);
    pr=okn_protocol_execute_ex(&ctl,pkt,n,rsp,4u);
    assert(pr.transport_status==OKN_ERR_BUFFER && pr.command_evaluated);
    assert(pr.command_status==OKN_OK && pr.response_len==0u);


    /* V16 capability handshake is read-only, fixed-schema and explicitly
     * reports locked hardware/mobile-flash status. */
    n=finish_pkt(pkt,OKN_CMD_GET_CAPABILITIES,0u); rev0=ctl.revision;
    assert(okn_protocol_execute(&ctl,pkt,n,rsp,sizeof(rsp),&rn)==OKN_OK);
    assert(rsp[3]==OKN_CMD_CAPABILITIES);
    assert(OKN_CAPABILITIES_PAYLOAD_LEN==27u);
    assert(rn==(size_t)(8u+OKN_CAPABILITIES_PAYLOAD_LEN));
    assert(rsp[6]==OKN_CAPABILITIES_SCHEMA);
    assert(rsp[7]==OKN_CHANNELS && rsp[8]==OKN_PEQ_BANDS);
    assert(rsp[9]==OKN_PROTO_VERSION);
    assert(((uint16_t)rsp[10] | ((uint16_t)rsp[11]<<8))==OKN_FW_VERSION);
    assert(((uint16_t)rsp[12] | ((uint16_t)rsp[13]<<8))==50u);
    assert(((uint16_t)rsp[14] | ((uint16_t)rsp[15]<<8))==OKN_PROTO_MAX_PAYLOAD);
    assert(((uint16_t)rsp[16] | ((uint16_t)rsp[17]<<8))==(OKN_PROTO_MAX_PAYLOAD+8u));
    {
        const uint32_t caps=(uint32_t)rsp[18] | ((uint32_t)rsp[19]<<8) |
                            ((uint32_t)rsp[20]<<16) | ((uint32_t)rsp[21]<<24);
        assert((caps & OKN_CAP_CAPABILITY_QUERY)!=0u);
        assert((caps & OKN_CAP_IDEMPOTENT_RETRY)!=0u);
        assert((caps & OKN_CAP_FLASH_FAIL_CLOSED)!=0u);
    }
    assert(rsp[23]==1u && rsp[23]==1u);
    assert(rsp[24]==0u && rsp[25]==0u && rsp[26]==0u);
    assert(rsp[27]==0u && rsp[28]==0u);
    {
        const uint32_t cap_rev=(uint32_t)rsp[29] | ((uint32_t)rsp[30]<<8) |
                               ((uint32_t)rsp[31]<<16) | ((uint32_t)rsp[32]<<24);
        assert(cap_rev==ctl.revision);
    }
    assert(ctl.revision==rev0);

    /* Non-empty capability query is a valid frame with a command error;
     * it must produce a negative ACK, not mutate state. */
    pkt[6]=0xAAu; n=finish_pkt(pkt,OKN_CMD_GET_CAPABILITIES,1u); rev0=ctl.revision;
    pr=okn_protocol_execute_ex(&ctl,pkt,n,rsp,sizeof(rsp));
    assert(pr.transport_status==OKN_OK && pr.command_evaluated);
    assert(pr.command_status==OKN_ERR_FORMAT && rsp[3]==OKN_CMD_ACK);
    assert(ctl.revision==rev0);

    /* Readback commands let the app resync without reusing legacy GoloPine packets. */
    n=finish_pkt(pkt,OKN_CMD_GET_MASTER_STATE,0u);
    assert(okn_protocol_execute(&ctl,pkt,n,rsp,sizeof(rsp),&rn)==OKN_OK);
    assert(rsp[3]==OKN_CMD_MASTER_STATE && rn==16u);

    pkt[6]=2u; n=finish_pkt(pkt,OKN_CMD_GET_CHANNEL_STATE,1u);
    assert(okn_protocol_execute(&ctl,pkt,n,rsp,sizeof(rsp),&rn)==OKN_OK);
    assert(rsp[3]==OKN_CMD_CHANNEL_STATE && rsp[6]==2u);

    pkt[6]=3u; pkt[7]=5u; n=finish_pkt(pkt,OKN_CMD_GET_PEQ_STATE,2u);
    assert(okn_protocol_execute(&ctl,pkt,n,rsp,sizeof(rsp),&rn)==OKN_OK);
    assert(rsp[3]==OKN_CMD_PEQ_STATE && rsp[6]==3u && rsp[7]==5u);

    /* Dirty apply is transactional per item: successful items clear. */
    okn_controller_mark_all_dirty(&ctl); mock_master_calls=mock_channel_calls=0;
    assert(okn_runtime_apply_dirty(&ctl,&MOCK_HAL)==OKN_OK);
    assert(!ctl.master_dirty && ctl.channel_dirty_mask==0u);
    assert(mock_master_calls==1u && mock_channel_calls==7u);

    okn_controller_mark_all_dirty(&ctl);
    assert(okn_runtime_apply_dirty(&ctl,bp1048p4_hal_get())==OKN_ERR_HAL_LOCKED);
    assert(ctl.master_dirty); /* fail closed; nothing is silently considered applied */

    ctl.state.ch[0].mute=true;
    assert(okn_effective_channel_linear_gain(&ctl.state,0)==0.0f);
    puts("ALL V26 CORE TESTS PASS");
    return 0;
}
