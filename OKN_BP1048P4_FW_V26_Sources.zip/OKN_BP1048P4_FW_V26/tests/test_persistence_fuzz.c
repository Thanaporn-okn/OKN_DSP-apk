#include "../src/persist/okn_persistence.h"
#include "../src/core/okn_controller.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

static uint32_t prng_state=0x25C0FFEEu;
static uint32_t prng32(void) {
    uint32_t x=prng_state;
    x^=x<<13; x^=x>>17; x^=x<<5;
    prng_state=x;
    return x;
}

int main(void) {
    okn_controller_t ctl;
    okn_controller_init(&ctl);
    assert(okn_controller_set_master_gain(&ctl,-6.0f)==OKN_OK);
    assert(okn_controller_set_channel_gain(&ctl,3u,-9.5f)==OKN_OK);

    uint8_t image[OKN_PERSIST_IMAGE_SIZE];
    size_t image_len=0u;
    const uint32_t generation=0x12345678u;
    assert(okn_persist_encode(&ctl.state,generation,image,sizeof(image),&image_len)==OKN_OK);
    assert(image_len==OKN_PERSIST_IMAGE_SIZE);

    okn_dsp_state_t out;
    uint32_t gen=0u;
    assert(okn_persist_decode(image,image_len,&out,&gen)==OKN_OK);
    assert(gen==generation);

    /* Truncation is always rejected. */
    for (size_t n=0u;n<image_len;++n)
        assert(okn_persist_decode(image,n,&out,&gen)==OKN_ERR_FORMAT);

    /* Every single-byte one-bit corruption anywhere in the encoded image,
     * including generation/header and stored CRC, must be rejected. */
    for (size_t i=0u;i<image_len;++i) {
        uint8_t bad[OKN_PERSIST_IMAGE_SIZE];
        memcpy(bad,image,image_len);
        bad[i]^=0x01u;
        assert(okn_persist_decode(bad,image_len,&out,&gen)!=OKN_OK);
    }

    /* Regression for the schema-1 hole: generation is now CRC-covered. */
    {
        uint8_t bad[OKN_PERSIST_IMAGE_SIZE];
        memcpy(bad,image,image_len);
        bad[8]^=0x80u;
        assert(okn_persist_decode(bad,image_len,&out,&gen)==OKN_ERR_STATE_CRC);
    }

    /* Deterministic random-bit corpus across the full image. */
    for (unsigned round=0u;round<5000u;++round) {
        uint8_t bad[OKN_PERSIST_IMAGE_SIZE];
        memcpy(bad,image,image_len);
        const size_t pos=(size_t)(prng32()%image_len);
        const uint8_t bit=(uint8_t)(1u<<(prng32()%8u));
        bad[pos]^=bit;
        assert(okn_persist_decode(bad,image_len,&out,&gen)!=OKN_OK);
    }

    /* Original image must remain valid after the corruption corpus. */
    assert(okn_persist_decode(image,image_len,&out,&gen)==OKN_OK);
    assert(gen==generation);

    puts("ALL V26 PERSISTENCE CORRUPTION FUZZ TESTS PASS");
    return 0;
}
