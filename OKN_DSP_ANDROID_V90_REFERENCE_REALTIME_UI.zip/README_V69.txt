OKN_DSP V69 — PRODUCTION SAVE-STATE HARDENING

AUTHORITATIVE BASE
- V68 source: OKN_DSP_ANDROID_V68_UNIFIED_VERIFIED_LIVE_EQ_WRITE_MIGRATION.zip
- V68 source SHA256: 02595f372c1c48e1301040954f2e19e9bf22db4adb2d250b2487178a6d69ebe2
- V68 runtime success capture SHA256: 5b9d18cbb93b8769d84339660c3c63b97bf97a3953764e5fdbae71060f034a5d
- V68 runtime qualification: PASSED (safe PEAKING CH1/ID4/Band4 -0.1 -> -0.2 verified -> exact -0.1 restore verified -> manual SaveParams GATT status0 + 5s settle complete).

Build identity:
versionCode=69
versionName=5.0.0-v69-production-save-state-hardening

V69 keeps the V68 verified write scope unchanged:
- Scalar IDs [2,3,8,9,10,13,11] only.
- EQ actuator IDs [4,5,6,14,15,16,17], safe PEAKING(type=12) bands only, full 48-byte record.
- Sensors READ ONLY.
- Generic writes=false.
- Preset/delay/unknown writes remain locked.
- SaveParams exact ID7 trigger 570000000700000000, manual only, no auto-save/retry.

V69 hardening adds no new write family. It adds a final-state guard around manual Permanent Save:
1) Track the last verified state for every scalar/EQ control touched since the previous save.
2) Before SaveParams, read a fresh full Device Description in the same session.
3) Require 7 scalars + 105 EQ + 4 sensors and exact semantic match for every touched last-verified control.
4) Only then send SaveParams.
5) Require matching GATT status0 and 5s settle.
6) Read another fresh full Device Description.
7) Re-verify every touched state before declaring PERSISTENT_SAVE_COMPLETE.
8) Any pre/post mismatch or descriptor failure => SAVE UNCONFIRMED/BLOCKED, retain RAM DIRTY, no blind retry.

Runtime status: PENDING REAL DSP V69 CAPTURE.
