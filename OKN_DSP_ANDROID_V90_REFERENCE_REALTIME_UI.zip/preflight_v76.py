#!/usr/bin/env python3
from pathlib import Path
import hashlib,re
root=Path(__file__).resolve().parent

def req(rel):
 p=root/rel; assert p.is_file(),f'missing {rel}'; return p
def txt(rel): return req(rel).read_text(errors='replace')
def has(rel,m): assert m in txt(rel),f'missing {m!r} in {rel}'
def sha(rel,e):
 g=hashlib.sha256(req(rel).read_bytes()).hexdigest(); assert g==e,f'hash mismatch {rel}: {g}'
U='app/src/main/java/com/okn/dsp/UnifiedControlActivity.kt'; G='app/build.gradle.kts'; M='app/src/main/java/com/okn/dsp/MainActivity.kt'; WG='app/src/main/java/com/okn/dsp/protocol/WriteGate.kt'; SP='app/src/main/java/com/okn/dsp/protocol/VerifiedScalarControls.kt'; CAP='evidence/OKN_DSP_V75_FIELD_SELF_CHECK_RUNTIME_SUCCESS_CAPTURE.txt'
for r in [U,G,M,WG,SP,CAP,'README_V76.txt','evidence/OKN_DSP_V76_PRODUCTION_SESSION_HEALTH_GATE_PLAN.txt','evidence/OKN_DSP_V76_PRODUCTION_SESSION_HEALTH_GATE_PLAN.json']: req(r)
has(G,'versionCode = 76'); has(G,'5.7.0-v76-production-session-health-gate'); has(U,'V76 • PRODUCTION SAFE'); has(U,'RUN V76 SESSION HEALTH GATE • READ ONLY')
has(WG,'const val enabled: Boolean = false'); has(WG,'const val unifiedVerifiedScalarWritesEnabled: Boolean = true'); has(WG,'const val unifiedVerifiedEqWritesEnabled: Boolean = true')
ids=[int(x) for x in re.findall(r'VerifiedScalarControl\((\d+),',txt(SP))]; assert ids==[2,3,8,9,10,13,11],ids
u=txt(U)
assert u.count('UfeCodec.encodeFloat32Write')==2
assert u.count('LiveEqPolicy.encodeWrite')==1
assert u.count('LiveEqPolicy.encodeRestore')==1
assert u.count('SaveParamsPolicy.encodeTrigger()')==1
assert u.count('UfeCodec.encodeWrite(')==0
assert u.count('if (!isCurrentGatt(g,')==7
for m in ['sessionHealthGatePassed = false','V76_SESSION_HEALTH_GATE_RESET reason=new-session','V76_SESSION_HEALTH_GATE_RESET reason=disconnect','V76_SESSION_HEALTH_GATE_RESULT pass=$pass writesSent=0 healthGatePassed=$sessionHealthGatePassed','sessionHealthGatePassed = pass']:
 assert m in u,m
# UI and backend guards must cover scalar, EQ, and Save.
assert u.count('sessionReady && sessionHealthGatePassed')>=5
for m in ['reason=session-health-gate-not-passed id=${c.id}','reason=session-health-gate-not-passed ch=$channel1 band=$band1','V76_UNIFIED_SAVEPARAMS_BLOCKED reason=session-health-gate-not-passed']:
 assert m in u,m
assert 'if (!sessionReady || !sessionHealthGatePassed || hasPendingControlWrite()' in u
assert 'if (!sessionReady || !sessionHealthGatePassed || !VerifiedScalarControls.allowed(id)' in u
assert 'if (!sessionReady || !sessionHealthGatePassed || ch !in 1..7' in u
assert 'if (!sessionReady || !sessionHealthGatePassed || saveInFlight' in u
assert 'if (!sessionReady || !sessionHealthGatePassed || !saveInFlight' in u
# Health gate itself remains read-only.
f=u[u.index('    private fun runFieldSelfCheck()'):u.index('    private fun confirmArmPowerCycleProof()')]
for m in ['scalarValues.size == 7','eqCount == 105','sensors.size == 4','gattWriteTickets.isEmpty()','!unsavedVerifiedChanges && verifiedChangeCount == 0','writesSent=0']:
 assert m in f,m
for bad in ['writeNoResponse(','UfeCodec.','LiveEqPolicy.encode','SaveParamsPolicy.encodeTrigger','writeCharacteristic(']: assert bad not in f,bad
# ARM-before-write ordering remains centralized.
h=u[u.index('    private fun writeNoResponse('):u.index('    private fun record(kind: String, text: String) {')]
a=h.index('gattWriteTickets.addLast(kind)'); b=h.index('V76_UNIFIED_GATT_TICKET_PREPARED'); c=h.index('if (purpose != null) armGattActionTimeout(purpose)'); d=h.index('g.writeCharacteristic(ch, bytes, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE)'); assert a<b<c<d,(a,b,c,d)
# V75 real runtime basis.
cap=txt(CAP)
for m in ['V75_UNIFIED_LOAD mode=REFRESH scalarCount=7 expectedScalars=7 eqBands=105 expectedEqBands=105','V75_UNIFIED_REFRESH_COMPLETE refresh=1','V75_FIELD_SELF_CHECK_RESULT pass=true writesSent=0 sessionReady=true scalarCount=7 eqBands=105 sensors=4','sessionObjectsOk=true','exactScalarIds=true','genericWrites=false','protocolIdle=true','ramClean=true','verifiedChangeCount=0']:
 assert m in cap,m
sha(CAP,'306f3ca2cf3c2b21c6c2b5cce5e1483ddaeba035a57a139bd734dbd60265e8c6')
# Production modules unchanged from V74/V75.
for r,e in {
'app/src/main/java/com/okn/dsp/ScalarControlActivity.kt':'01f6aca6f2131bd41ca4fd1d674d879cade425ccc7ddef77e63718e8e124ffed',
'app/src/main/java/com/okn/dsp/LiveEqActivity.kt':'3240ca56c81b7960098ae9fb6ea7421d32e74b11e42810ce4c5b71b35d7ab8d0',
'app/src/main/java/com/okn/dsp/protocol/SaveParamsPolicy.kt':'88005dba77d2b84597f5bd5e23eaaacec7d25b59dc0f38b8affbde2d2cfbeb85',
'app/src/main/java/com/okn/dsp/protocol/LiveEqPolicy.kt':'cfb046aa09acaf8429176a9b99e988ea06347f3daeea988b7c118d056400d2bc',
WG:'8aa82bb069dd64dc2d1274801f1f4420a764f52670246e9c813b0723531be472',
SP:'4c096b001523704dcb6aa36496dd17263d6df84a0a1fee20c2fc40d60e898f6b'}.items(): sha(r,e)
print('OK: V76 production session health gate preflight passed')
