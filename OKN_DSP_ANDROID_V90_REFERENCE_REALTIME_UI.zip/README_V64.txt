OKN DSP V64 — ID3 PRODUCTION GLOBAL CONTROL

V64 promotes RemindSoundVolume actuator ID3 into Production Global Controls after the V63 guarded proof passed on the real DSP.

Production Global Controls now contains 7 verified FLOAT32 controls:
ID2 MasterVolume
ID3 RemindSoundVolume
ID8 BassVolume
ID9 BassCutoff
ID10 BassBoost
ID13 MiddleBoost
ID11 TrebleBoost

Each APPLY is guarded: WRITE 0x57 -> fresh Device Description -> exact/tolerant scalar readback verification -> automatic restore on failure.
Permanent SAVE is separate and uses the V57-proven SaveParams ID7 exact trigger 570000000700000000.
SaveParams saves the DSP's current turning parameters as a whole. No auto-save is performed.

LIVE EQ 7CH remains the V62-proven production path.
Generic writes, Preset, Delay and unknown writes remain locked.
The V63 dedicated proof button is no longer exposed on the production launcher; the proof capture remains under evidence/.
