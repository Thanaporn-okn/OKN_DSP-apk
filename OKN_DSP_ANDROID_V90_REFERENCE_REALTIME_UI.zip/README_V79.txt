OKN DSP V79 — PRODUCTION ICON REFRESH

Base: V78 Production Baseline (runtime-qualified on real DSP).

V79 changes:
- versionCode 79
- versionName 5.10.0-v79-production-icon-refresh
- launcher/app icon replaced from the user's uploaded image
- mdpi/hdpi/xhdpi/xxhdpi/xxxhdpi launcher PNGs regenerated
- adaptive foreground regenerated at 432x432
- UI/log/diagnostic release labels advanced to V79
- diagnostic fallback chain: V79 -> V78 -> V77 -> V76 -> V75 -> V74

Production behavior remains V78:
- Global IDs 2,3,8,9,10,13,11
- safe-PEAKING EQ only
- Sensors READ ONLY
- genericWrites=false
- manual guarded SaveParams
- session health gate + connection/session/GATT epoch binding
- direct reconnect without scan
- Preset / Delay / unknown writes remain locked

No new DSP protocol or writer family is introduced.
