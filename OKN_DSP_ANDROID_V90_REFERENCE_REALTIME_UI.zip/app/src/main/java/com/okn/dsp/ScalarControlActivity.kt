package com.okn.dsp

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.ContentValues
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.widget.*
import androidx.core.app.ActivityCompat
import com.okn.dsp.protocol.*
import com.okn.dsp.transport.BleProfile
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * V66 verified global-control page.
 * Seven FLOAT32 scalar actuators are writable: six proven by V44/V45/V62 plus ID3 proven by V63.
 * Every scalar write is followed by a full Device Description refresh and verification.
 * SaveParams ID=7 is available only as a separate explicit guarded action after at least
 * one scalar write has verified in the current session. Generic/unknown writes remain locked.
 */
class ScalarControlActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private val ts = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    private val startupProbe16 = ByteCodec.hexToBytes("631C062443FD3844558001F3EDA0CCF8")

    private lateinit var status: TextView
    private lateinit var logView: TextView
    private lateinit var deviceList: LinearLayout
    private lateinit var controlsHost: LinearLayout
    private lateinit var startSessionButton: Button

    private var scanner: android.bluetooth.le.BluetoothLeScanner? = null
    private val found = LinkedHashMap<String, BluetoothDevice>()
    private var gatt: BluetoothGatt? = null
    private var ab01: BluetoothGattCharacteristic? = null
    private var ab02: BluetoothGattCharacteristic? = null
    private var connectedName: String? = null

    // Auth/session state.
    private var waitingAuth = false
    private var sessionReady = false
    private var txCipher: SessionTxCipher? = null
    private var rxCipher: SessionRxCipher? = null

    private enum class DescMode { INITIAL, VERIFY_TARGET, VERIFY_RESTORE }
    private var descMode: DescMode? = null
    private var descExpected = -1
    private val descBytes = ByteArrayOutputStream()
    private val currentValues = LinkedHashMap<Int, Float>()

    private var pendingId: Int? = null
    private var pendingTarget: Float? = null
    private var pendingOriginal: Float? = null
    private var verificationTimeout: Runnable? = null

    // V66 explicit permanent-save state. The trigger itself is centralized in SaveParamsPolicy.
    private val saveCommitSettleMs = 5000L
    private var unsavedVerifiedChanges = false
    private var verifiedChangeCount = 0
    private var saveInFlight = false
    private var saveGattOk = false
    private var saveSettleRunnable: Runnable? = null
    private lateinit var permanentSaveButton: Button

    private val captureLines = mutableListOf<String>()
    private var packetNo = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestBlePermissions()
        record("META", "V66_SCALAR_CONTROL_ACTIVITY_START")
        record("META", "V66_SCALAR_RUNTIME_EVIDENCE ids=2,3,8,9,10,13,11 source=V44+V45+V62+V63")
        record("META", "V66_SAVEPARAMS_PERSISTENCE_EVIDENCE trigger=570000000700000000 actuator=7 targetPersisted=true originalRestoredPersisted=true powerCycles=2 source=V57")
    }

    override fun onDestroy() {
        cancelSaveSettle()
        super.onDestroy()
        try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
        try { gatt?.close() } catch (_: Exception) {}
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 22, 22, 28)
        }
        root.addView(TextView(this).apply {
            text = "OKN DSP V66 — VERIFIED GLOBAL CONTROLS + PERMANENT SAVE"
            textSize = 22f
        })
        status = TextView(this).apply {
            text = "DISCONNECTED • verified scalar writes + guarded permanent SAVE"
            textSize = 14f
            setPadding(0, 8, 0, 10)
        }
        root.addView(status)
        root.addView(TextView(this).apply {
            text = "V44/V45/V62 proved the original six FLOAT32 production controls. V63 separately proved ID3 RemindSoundVolume with fresh descriptor preflight, target readback and exact restore. V57 proved SaveParams ID7 persistence with two real DSP power-cycles. V66 promotes ID3 into Production Global Controls: IDs 2,3,8,9,10,13,11 are writable; every APPLY is readback-verified and SAVE is a separate explicit guarded action."
            textSize = 13f
        })

        root.addView(Button(this).apply {
            text = "SCAN DSP"
            setOnClickListener { startScan() }
        })
        deviceList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(deviceList)

        startSessionButton = Button(this).apply {
            text = "START VERIFIED LIVE CONTROL SESSION"
            isEnabled = false
            setOnClickListener { confirmStartSession() }
        }
        root.addView(startSessionButton)

        controlsHost = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(controlsHost)
        renderControls()

        permanentSaveButton = Button(this).apply {
            text = "SAVE VERIFIED GLOBAL CONTROLS TO DSP (PERMANENT) • GUARDED"
            isEnabled = true
            setOnClickListener { confirmPermanentSave() }
        }
        root.addView(permanentSaveButton)
        root.addView(TextView(this).apply {
            text = "SAVE จะส่ง SaveParams ID7 ที่ V57 พิสูจน์แล้ว เฉพาะเมื่อมี scalar change ที่ V66 verify ผ่านใน session นี้และ protocol ว่างอยู่. SaveParams บันทึก turning parameters ปัจจุบันของ DSP ทั้งชุด ไม่ใช่เฉพาะ control ล่าสุด. APPLY ไม่ auto-save."
            textSize = 12f
            setPadding(0, 0, 0, 8)
        })

        root.addView(Button(this).apply {
            text = "SAVE V66 CAPTURE TO DOWNLOADS"
            setOnClickListener { saveCapture() }
        })
        logView = TextView(this).apply { textSize = 11f; setPadding(0, 12, 0, 0) }
        root.addView(logView)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun renderControls() {
        controlsHost.removeAllViews()
        if (!sessionReady) {
            controlsHost.addView(TextView(this).apply {
                text = "เชื่อมต่อ DSP แล้วกด START VERIFIED LIVE CONTROL SESSION เพื่ออ่านค่าจริงก่อน"
                textSize = 14f
                setPadding(0, 12, 0, 12)
            })
            return
        }

        record("META", "V66_SCALAR_CONTROLS_RENDER_START count=${VerifiedScalarControls.controls.size} mainThread=${Looper.myLooper() == Looper.getMainLooper()}")
        for (c in VerifiedScalarControls.controls) {
            val current = currentValues[c.id]
            val block = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, 12, 0, 12)
            }
            val title = TextView(this).apply {
                text = "${c.name} • ID ${c.id} • current=${current?.let { fmt(it) } ?: "?"} ${c.unit} • range=${fmt(c.min)}..${fmt(c.max)}"
                textSize = 16f
            }
            block.addView(title)
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val edit = EditText(this).apply {
                inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED
                setText(current?.let { fmt(it) } ?: "")
                hint = c.unit
            }
            row.addView(edit, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(Button(this).apply {
                text = "APPLY + VERIFY"
                isEnabled = current != null
                setOnClickListener {
                    val v = edit.text.toString().toFloatOrNull()
                    if (v == null) {
                        Toast.makeText(this@ScalarControlActivity, "กรอกตัวเลขก่อน", Toast.LENGTH_SHORT).show()
                    } else confirmScalarWrite(c, v)
                }
            })
            block.addView(row)
            controlsHost.addView(block)
        }
        record("META", "V66_SCALAR_CONTROLS_RENDER_COMPLETE childCount=${controlsHost.childCount} mainThread=${Looper.myLooper() == Looper.getMainLooper()}")
    }

    private fun confirmScalarWrite(c: VerifiedScalarControl, requested: Float) {
        val target = VerifiedScalarControls.sanitize(c.id, requested)
        if (target == null) {
            Toast.makeText(this, "ค่านอกช่วง ${c.min}..${c.max} ${c.unit}", Toast.LENGTH_LONG).show()
            return
        }
        val original = currentValues[c.id] ?: run {
            Toast.makeText(this, "ยังไม่มี baseline ของ ${c.name}", Toast.LENGTH_LONG).show(); return
        }
        if (!sessionReady || descMode != null || pendingId != null || saveInFlight) {
            Toast.makeText(this, "Session ยังไม่พร้อมหรือกำลัง verify/save ค่าเดิม", Toast.LENGTH_LONG).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("V66 VERIFIED SCALAR WRITE")
            .setMessage("${c.name} ID=${c.id}\n${fmt(original)} → ${fmt(target)} ${c.unit}\n\nจะส่ง WRITE 0x57 แล้วอ่าน Device Description กลับมาตรวจทันที. ถ้า verify ไม่ผ่านจะคืนค่าเดิม.\n\nAPPLY รอบนี้ยังไม่ส่ง SaveParams; ถ้าต้องการบันทึกถาวรให้กด SAVE แยกหลัง verify ผ่าน")
            .setNegativeButton("ยกเลิก", null)
            .setPositiveButton("WRITE + VERIFY") { _, _ -> sendScalarWrite(c, original, target) }
            .show()
    }

    private fun sendScalarWrite(c: VerifiedScalarControl, original: Float, target: Float) {
        val g = gatt ?: return
        val w = ab01 ?: return
        val tx = txCipher ?: return
        pendingId = c.id
        pendingOriginal = original
        pendingTarget = target
        val plain = UfeCodec.encodeFloat32Write(c.id, target)
        val enc = tx.encryptNext(plain)
        record("META", "V66_SCALAR_WRITE_PLAIN=${ByteCodec.run { plain.toHex() }} id=${c.id} name=${c.name} original=$original target=$target saveParams=false")
        if (!writeNoResponse(g, w, enc, "TX_SCALAR_WRITE_V66_ID${c.id}")) {
            clearPending("write-queue-failed")
            return
        }
        status.text = "WRITE sent ${c.name}=${fmt(target)} ${c.unit} • verifying descriptor"
        handler.postDelayed({ requestDescriptor(DescMode.VERIFY_TARGET) }, 350L)
    }

    private fun requestDescriptor(mode: DescMode) {
        val g = gatt ?: return
        val w = ab01 ?: return
        val tx = txCipher ?: return
        descMode = mode
        descExpected = -1
        descBytes.reset()
        val plain = SessionCryptoFacts.DEVICE_DESCRIPTION_REQUEST
        val enc = tx.encryptNext(plain)
        record("META", "V66_DESC_REQUEST mode=$mode plain=${ByteCodec.run { plain.toHex() }}")
        if (!writeNoResponse(g, w, enc, "TX_DESC_V66_${mode.name}")) {
            if (mode == DescMode.VERIFY_TARGET) restorePending("desc-request-failed") else clearPending("desc-request-failed")
            return
        }
        verificationTimeout?.let { handler.removeCallbacks(it) }
        verificationTimeout = Runnable {
            record("META", "V66_VERIFY_TIMEOUT mode=$mode id=${pendingId ?: -1}")
            if (mode == DescMode.VERIFY_TARGET) restorePending("verify-timeout") else clearPending("restore-verify-timeout")
        }.also { handler.postDelayed(it, 12000L) }
    }

    private fun restorePending(reason: String) {
        val id = pendingId ?: return
        val original = pendingOriginal ?: return
        val g = gatt ?: return
        val w = ab01 ?: return
        val tx = txCipher ?: return
        if (!VerifiedScalarControls.allowed(id)) { clearPending("restore-id-not-allowed"); return }
        val plain = UfeCodec.encodeFloat32Write(id, original)
        val enc = tx.encryptNext(plain)
        record("META", "V66_FAILSAFE_RESTORE_PLAIN=${ByteCodec.run { plain.toHex() }} id=$id original=$original reason=$reason saveParams=false")
        if (!writeNoResponse(g, w, enc, "TX_SCALAR_RESTORE_V66_ID$id")) {
            clearPending("restore-queue-failed")
            return
        }
        handler.postDelayed({ requestDescriptor(DescMode.VERIFY_RESTORE) }, 350L)
    }

    private fun confirmStartSession() {
        if (saveInFlight) { Toast.makeText(this, "V66 กำลัง SAVE • รอให้ commit จบก่อน", Toast.LENGTH_LONG).show(); return }
        if (pendingId != null || descMode != null || waitingAuth) { Toast.makeText(this, "V66 protocol busy • รอ verify ให้จบก่อน", Toast.LENGTH_LONG).show(); return }
        if (gatt == null || ab01 == null || ab02 == null) {
            Toast.makeText(this, "เชื่อม AB00/AB01/AB02 ก่อน", Toast.LENGTH_LONG).show(); return
        }
        AlertDialog.Builder(this)
            .setTitle("Start V66 verified global-control session")
            .setMessage("AUTH16 → derive current-session RandKey → อ่าน Device Description สด. จากนั้นอนุญาตเฉพาะ scalar IDs 2,8,9,10,13,11. APPLY ทุกครั้งต้อง verify ก่อน และ SaveParams ID7 จะส่งได้เฉพาะเมื่อผู้ใช้กด SAVE แยกหลัง verified change เท่านั้น")
            .setNegativeButton("ยกเลิก", null)
            .setPositiveButton("START") { _, _ -> startSession() }
            .show()
    }

    private fun startSession() {
        val g = gatt ?: return
        val w = ab01 ?: return
        waitingAuth = true
        sessionReady = false
        txCipher = null
        rxCipher = null
        descMode = null
        currentValues.clear()
        clearPending("new-session", recordEvent = false)
        cancelSaveSettle()
        unsavedVerifiedChanges = false
        verifiedChangeCount = 0
        saveInFlight = false
        saveGattOk = false
        record("META", "V66_LIVE_SCALAR_SESSION_START")
        if (!writeNoResponse(g, w, startupProbe16, "TX_AUTH16_V66")) {
            waitingAuth = false
            status.text = "AUTH16 queue failed"
        } else status.text = "AUTH16 sent • waiting 32B auth response"
    }

    private fun handleAb02(value: ByteArray) {
        record("RX_NOTIFY", "len=${value.size} hex=${ByteCodec.run { value.toHex() }}")
        if (waitingAuth) {
            if (value.size != 32) return
            try {
                val d = PreAuthRandKeyDecoder.decode(value)
                txCipher = SessionTxCipher(d.randKey)
                rxCipher = SessionRxCipher(d.randKey)
                waitingAuth = false
                record("META", "V66_RANDKEY_DERIVED type=${d.typeId} ver=${d.versionId} rand=${ByteCodec.run { d.randKey.toHex() }}")
                requestDescriptor(DescMode.INITIAL)
            } catch (e: Exception) {
                waitingAuth = false
                record("META", "V66_AUTH_DECODE_ERROR ${e.javaClass.simpleName}:${e.message}")
                status.text = "Auth decode failed"
            }
            return
        }

        val rx = rxCipher ?: return
        val plain = try { rx.decryptNext(value) } catch (e: Exception) {
            record("META", "V66_RX_DECRYPT_ERROR ${e.javaClass.simpleName}:${e.message}")
            sessionReady = false
            return
        }
        record("RX_PLAIN", "len=${plain.size} hex=${ByteCodec.run { plain.toHex() }}")
        if (descMode != null) collectDescriptor(plain)
    }

    private fun collectDescriptor(plain: ByteArray) {
        val mode = descMode ?: return
        if (descExpected < 0) {
            if (plain.size < 4 || (plain[0].toInt() and 0xff) != 0x86) {
                record("META", "V66_DESC_NONHEADER mode=$mode marker=${plain.firstOrNull()?.toInt()?.and(0xff)} len=${plain.size}")
                return
            }
            descExpected = (plain[1].toInt() and 0xff) or ((plain[2].toInt() and 0xff) shl 8) or ((plain[3].toInt() and 0xff) shl 16)
            descBytes.reset()
            descBytes.write(plain, 4, plain.size - 4)
            record("META", "V66_DESC_HEADER mode=$mode jsonLen=$descExpected")
        } else {
            if (plain.isEmpty() || (plain[0].toInt() and 0xff) != 0x82) {
                record("META", "V66_DESC_NONCONT mode=$mode marker=${plain.firstOrNull()?.toInt()?.and(0xff)} len=${plain.size}")
                return
            }
            descBytes.write(plain, 1, plain.size - 1)
        }
        if (descExpected > 0 && descBytes.size() >= descExpected) {
            val bytes = descBytes.toByteArray().copyOf(descExpected)
            val obj = JSONObject(bytes.toString(Charsets.UTF_8))
            record("META", "V66_DESC_COMPLETE mode=$mode bytes=${bytes.size}")
            descMode = null
            descExpected = -1
            descBytes.reset()
            verificationTimeout?.let { handler.removeCallbacks(it) }
            verificationTimeout = null
            // V66: BluetoothGatt notifications may arrive off the main thread.
            // onDescriptorComplete mutates Android Views (status + dynamic control rows),
            // so dispatch it to the main looper before touching the UI hierarchy.
            handler.post { onDescriptorComplete(mode, obj) }
        }
    }

    private fun onDescriptorComplete(mode: DescMode, obj: JSONObject) {
        val values = extractScalarValues(obj)
        when (mode) {
            DescMode.INITIAL -> {
                currentValues.clear(); currentValues.putAll(values)
                val expectedCount = VerifiedScalarControls.controls.size
                sessionReady = values.size == expectedCount
                record("META", "V66_INITIAL_DESCRIPTOR_READY count=${values.size} expected=$expectedCount ready=$sessionReady values=${values.entries.joinToString { "${it.key}=${it.value}" }}")
                status.text = if (sessionReady)
                    "V66 GLOBAL CONTROLS READY • seven verified scalar controls loaded • no unsaved V66 change yet"
                else
                    "V66 BLOCKED • verified scalar descriptor incomplete (${values.size}/$expectedCount)"
                renderControls()
            }
            DescMode.VERIFY_TARGET -> {
                val id = pendingId ?: return
                val expected = pendingTarget ?: return
                val actual = values[id]
                val ok = actual != null && VerifiedScalarControls.matches(id, actual, expected)
                record("META", "V66_TARGET_DESCRIPTOR_VERIFY id=$id expected=$expected actual=${actual ?: "MISSING"} verified=$ok")
                if (ok) {
                    currentValues.clear(); currentValues.putAll(values)
                    unsavedVerifiedChanges = true
                    verifiedChangeCount += 1
                    record("META", "V66_SCALAR_WRITE_COMPLETE id=$id verified=true saveParamsSent=false persistence=RAM_DIRTY verifiedChangeCount=$verifiedChangeCount")
                    status.text = "V66 VERIFIED • ID$id=${fmt(actual!!)} • UNSAVED • กด SAVE TO DSP เมื่อพร้อม"
                    clearPending("verified", recordEvent = false)
                    renderControls()
                } else restorePending("target-verify-failed")
            }
            DescMode.VERIFY_RESTORE -> {
                val id = pendingId ?: return
                val expected = pendingOriginal ?: return
                val actual = values[id]
                val ok = actual != null && VerifiedScalarControls.matches(id, actual, expected)
                record("META", "V66_RESTORE_DESCRIPTOR_VERIFY id=$id expected=$expected actual=${actual ?: "MISSING"} verified=$ok")
                currentValues.clear(); currentValues.putAll(values)
                status.text = if (ok) "Target verify failed • original restored safely" else "RESTORE VERIFY FAILED — stop control and save capture"
                if (!ok) sessionReady = false
                clearPending(if (ok) "restored" else "restore-verify-failed", recordEvent = false)
                renderControls()
            }
        }
    }

    private fun extractScalarValues(obj: JSONObject): Map<Int, Float> {
        val out = LinkedHashMap<Int, Float>()
        val arr = obj.optJSONArray("actuators") ?: return out
        for (i in 0 until arr.length()) {
            val a = arr.optJSONObject(i) ?: continue
            val id = a.optInt("ID", -1)
            if (!VerifiedScalarControls.allowed(id) || a.optInt("type", -1) != 2000 || !a.has("UFE_TYPE_FLOAT32")) continue
            val v = a.optDouble("UFE_TYPE_FLOAT32", Double.NaN).toFloat()
            if (v.isFinite()) out[id] = v
        }
        return out
    }

    private fun clearPending(reason: String, recordEvent: Boolean = true) {
        if (recordEvent) record("META", "V66_PENDING_CLEAR reason=$reason id=${pendingId ?: -1}")
        pendingId = null; pendingTarget = null; pendingOriginal = null
        verificationTimeout?.let { handler.removeCallbacks(it) }
        verificationTimeout = null
    }

    private fun confirmPermanentSave() {
        if (!WriteGate.verifiedScalarPersistentSaveEnabled) {
            Toast.makeText(this, "V66 scalar persistent-save gate disabled", Toast.LENGTH_LONG).show(); return
        }
        if (!sessionReady || gatt == null || ab01 == null || txCipher == null) {
            Toast.makeText(this, "เชื่อม DSP และ START V66 session ก่อน", Toast.LENGTH_LONG).show(); return
        }
        if (saveInFlight || pendingId != null || descMode != null || waitingAuth) {
            Toast.makeText(this, "Protocol กำลัง busy/verify อยู่ กรุณารอให้จบก่อน SAVE", Toast.LENGTH_LONG).show(); return
        }
        if (!unsavedVerifiedChanges || verifiedChangeCount <= 0) {
            Toast.makeText(this, "ยังไม่มี scalar change ที่ V66 verify ผ่านใน session นี้ จึงยังไม่ส่ง SaveParams", Toast.LENGTH_LONG).show(); return
        }
        if (!SaveParamsPolicy.triggerIsExact()) {
            record("META", "V66_SCALAR_SAVE_BLOCKED reason=saveparams-trigger-not-exact")
            Toast.makeText(this, "SaveParams trigger policy mismatch • blocked", Toast.LENGTH_LONG).show(); return
        }
        AlertDialog.Builder(this)
            .setTitle("SAVE VERIFIED GLOBAL CONTROLS PERMANENTLY")
            .setMessage("มี verified scalar changes = $verifiedChangeCount\n\nV66 จะส่ง SaveParams ID7 trigger ที่ V57 พิสูจน์ด้วย power-cycle 2 รอบแล้ว:\n57 00000007 0000 0000\n\nSaveParams จะบันทึก turning parameters ปัจจุบันของ DSP ทั้งชุด รวม EQ ปัจจุบันด้วย. ห้ามปิด DSP ระหว่างช่วง commit 5 วินาที")
            .setNegativeButton("ยกเลิก", null)
            .setPositiveButton("SAVE PERMANENTLY") { _, _ -> sendPermanentSave() }
            .show()
    }

    private fun sendPermanentSave() {
        val g = gatt ?: return
        val w = ab01 ?: return
        val tx = txCipher ?: return
        if (!sessionReady || saveInFlight || pendingId != null || descMode != null || waitingAuth || !unsavedVerifiedChanges) {
            record("META", "V66_SCALAR_SAVE_BLOCKED reason=guard-race sessionReady=$sessionReady saveInFlight=$saveInFlight pendingScalar=${pendingId != null} descMode=$descMode waitingAuth=$waitingAuth dirty=$unsavedVerifiedChanges")
            Toast.makeText(this, "SAVE guard ไม่พร้อม • ไม่มีการส่ง SaveParams", Toast.LENGTH_LONG).show(); return
        }
        val plain = SaveParamsPolicy.encodeTrigger()
        if (ByteCodec.run { plain.toHex() } != "570000000700000000") {
            record("META", "V66_SCALAR_SAVE_BLOCKED reason=unexpected-trigger plain=${ByteCodec.run { plain.toHex() }}")
            return
        }
        saveInFlight = true
        saveGattOk = false
        val enc = tx.encryptNext(plain)
        record("META", "V66_SCALAR_SAVEPARAMS_TRIGGER_PLAIN=${ByteCodec.run { plain.toHex() }} actuator=7 offset=0 length=0 payload=none verifiedScalarChanges=$verifiedChangeCount evidence=V57_two_power_cycles")
        if (!writeNoResponse(g, w, enc, "TX_SAVEPARAMS_ID7_V66_SCALAR")) {
            saveInFlight = false
            record("META", "V66_SCALAR_SAVEPARAMS_QUEUE_FAILED changesRemainUnsaved=true")
            status.text = "V66 SAVE queue failed • scalar changes remain UNSAVED"
            return
        }
        record("META", "V66_SCALAR_SAVEPARAMS_QUEUE_OK settleMs=$saveCommitSettleMs")
        status.text = "V66 SaveParams sent • DO NOT POWER OFF • waiting ${saveCommitSettleMs}ms commit window"
        cancelSaveSettle()
        saveSettleRunnable = Runnable {
            if (!saveInFlight) return@Runnable
            if (saveGattOk) {
                val savedCount = verifiedChangeCount
                unsavedVerifiedChanges = false
                verifiedChangeCount = 0
                saveInFlight = false
                record("META", "V66_SCALAR_PERSISTENT_SAVE_COMPLETE saveParamsActuator=7 savedVerifiedScalarChanges=$savedCount trigger=570000000700000000 gattStatus=0 settleMs=$saveCommitSettleMs persistenceBasis=V57_TWO_POWER_CYCLE_PROOF")
                runOnUiThread { status.text = "V66 GLOBAL CONTROLS SAVED TO DSP PERMANENTLY • safe to power off" }
            } else {
                saveInFlight = false
                record("META", "V66_SCALAR_PERSISTENT_SAVE_UNCONFIRMED reason=no-success-gatt-callback changesRemainUnsaved=true")
                runOnUiThread { status.text = "V66 SAVE UNCONFIRMED • scalar changes remain UNSAVED • save capture" }
            }
        }.also { handler.postDelayed(it, saveCommitSettleMs) }
    }

    private fun cancelSaveSettle() {
        saveSettleRunnable?.let { handler.removeCallbacks(it) }
        saveSettleRunnable = null
    }

    private fun startScan() {
        if (saveInFlight) { Toast.makeText(this, "V66 กำลัง SAVE • ห้ามเปลี่ยน connection", Toast.LENGTH_LONG).show(); return }
        if (!hasBlePermission()) { requestBlePermissions(); return }
        val adapter = getSystemService(BluetoothManager::class.java)?.adapter ?: return
        if (!adapter.isEnabled) { Toast.makeText(this, "เปิด Bluetooth ก่อน", Toast.LENGTH_SHORT).show(); return }
        found.clear(); deviceList.removeAllViews()
        scanner = adapter.bluetoothLeScanner
        status.text = "SCANNING"
        try { scanner?.startScan(scanCallback) } catch (_: SecurityException) { return }
        handler.postDelayed({ try { scanner?.stopScan(scanCallback) } catch (_: Exception) {} }, 10000L)
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val d = result.device
            val name = result.scanRecord?.deviceName ?: try { d.name } catch (_: SecurityException) { null }
            if (name?.contains("GOLOPINE", true) != true && name?.contains("DSP", true) != true) return
            if (found.putIfAbsent(d.address, d) != null) return
            runOnUiThread {
                deviceList.addView(Button(this@ScalarControlActivity).apply {
                    text = "${name ?: "DSP"} • ${d.address}\nแตะเพื่อเชื่อมต่อ"
                    setOnClickListener { connect(d, name ?: "DSP") }
                })
            }
        }
    }

    private fun connect(device: BluetoothDevice, name: String) {
        if (saveInFlight) { Toast.makeText(this, "V66 กำลัง SAVE • ห้ามเปลี่ยน connection", Toast.LENGTH_LONG).show(); return }
        if (!hasBlePermission()) return
        try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
        try { gatt?.close() } catch (_: Exception) {}
        connectedName = name
        status.text = "CONNECTING $name"
        record("META", "V66_CONNECT_START name=$name address=${device.address}")
        try {
            gatt = device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
        } catch (_: SecurityException) { status.text = "CONNECT permission error" }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, statusCode: Int, newState: Int) {
            record("META", "GATT_STATE status=$statusCode newState=$newState")
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                runOnUiThread { status.text = "CONNECTED ${connectedName ?: "DSP"} • discovering" }
                try {
                    g.requestMtu(517)
                    handler.postDelayed({
                        try { g.discoverServices() } catch (_: SecurityException) {}
                    }, 250L)
                } catch (_: SecurityException) {}
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                if (saveInFlight) {
                    cancelSaveSettle()
                    saveInFlight = false
                    saveGattOk = false
                    record("META", "V66_SCALAR_PERSISTENT_SAVE_UNCONFIRMED reason=disconnect-during-save changesRemainUnsaved=true")
                }
                sessionReady = false; waitingAuth = false; txCipher = null; rxCipher = null
                runOnUiThread { status.text = "DISCONNECTED"; startSessionButton.isEnabled = false; renderControls() }
            }
        }

        override fun onMtuChanged(g: BluetoothGatt, mtu: Int, statusCode: Int) { record("META", "MTU_CHANGED mtu=$mtu status=$statusCode") }

        override fun onServicesDiscovered(g: BluetoothGatt, statusCode: Int) {
            val service = g.getService(BleProfile.AB00_SERVICE)
            ab01 = service?.getCharacteristic(BleProfile.AB01_WRITE)
            ab02 = service?.getCharacteristic(BleProfile.AB02_NOTIFY)
            val ok = statusCode == BluetoothGatt.GATT_SUCCESS && ab01 != null && ab02 != null
            record("META", "SERVICES_DISCOVERED status=$statusCode AB01=${ab01 != null} AB02=${ab02 != null}")
            if (!ok) { runOnUiThread { status.text = "AB00/AB01/AB02 profile not found" }; return }
            subscribeAb02(g, ab02!!)
            runOnUiThread { status.text = "CONNECTED • enabling AB02 notifications"; startSessionButton.isEnabled = false }
        }

        override fun onDescriptorWrite(g: BluetoothGatt, descriptor: BluetoothGattDescriptor, statusCode: Int) {
            record("META", "CCCD_WRITE status=$statusCode")
            runOnUiThread {
                if (statusCode == BluetoothGatt.GATT_SUCCESS) {
                    status.text = "CONNECTED • AB02 notifications READY"
                    startSessionButton.isEnabled = true
                } else {
                    status.text = "CCCD notification enable failed: $statusCode"
                    startSessionButton.isEnabled = false
                }
            }
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, statusCode: Int) {
            record("META", "TX_WRITE_RESULT status=$statusCode uuid=${characteristic.uuid}")
            if (saveInFlight && characteristic.uuid == BleProfile.AB01_WRITE) {
                saveGattOk = statusCode == BluetoothGatt.GATT_SUCCESS
                record("META", "V66_SCALAR_SAVEPARAMS_GATT_RESULT status=$statusCode ok=$saveGattOk")
                if (!saveGattOk) {
                    cancelSaveSettle()
                    saveInFlight = false
                    runOnUiThread { status.text = "V66 SAVE FAILED • GATT status=$statusCode • scalar changes remain UNSAVED" }
                }
            }
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            if (characteristic.uuid == BleProfile.AB02_NOTIFY) handleAb02(value)
        }

        @Suppress("DEPRECATION")
        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            if (android.os.Build.VERSION.SDK_INT < 33 && characteristic.uuid == BleProfile.AB02_NOTIFY) handleAb02(characteristic.value ?: byteArrayOf())
        }
    }

    private fun subscribeAb02(g: BluetoothGatt, ch: BluetoothGattCharacteristic) {
        if (!hasBlePermission()) return
        try {
            g.setCharacteristicNotification(ch, true)
            val cccd = ch.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")) ?: return
            val v = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            if (android.os.Build.VERSION.SDK_INT >= 33) g.writeDescriptor(cccd, v)
            else {
                @Suppress("DEPRECATION") cccd.value = v
                @Suppress("DEPRECATION") g.writeDescriptor(cccd)
            }
        } catch (e: Exception) { record("META", "SUBSCRIBE_ERROR ${e.javaClass.simpleName}:${e.message}") }
    }

    private fun writeNoResponse(g: BluetoothGatt, ch: BluetoothGattCharacteristic, bytes: ByteArray, label: String): Boolean {
        if (!hasBlePermission()) return false
        record("TX", "$label len=${bytes.size} hex=${ByteCodec.run { bytes.toHex() }}")
        return try {
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                g.writeCharacteristic(ch, bytes, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE) == BluetoothStatusCodes.SUCCESS
            } else {
                @Suppress("DEPRECATION") ch.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                @Suppress("DEPRECATION") ch.value = bytes
                @Suppress("DEPRECATION") g.writeCharacteristic(ch)
            }
        } catch (e: Exception) {
            record("META", "$label ERROR ${e.javaClass.simpleName}:${e.message}")
            false
        }
    }

    private fun record(kind: String, text: String) {
        val line = "${ts.format(Date())}\t#${++packetNo}\t$kind\t$text"
        synchronized(captureLines) { captureLines.add(line) }
        runOnUiThread { logView.text = (logView.text.toString() + line + "\n").takeLast(14000) }
    }

    private fun saveCapture() {
        val text = buildString {
            append("=== OKN DSP V66 VERIFIED GLOBAL CONTROLS + PERMANENT SAVE CAPTURE ===\n")
            synchronized(captureLines) { captureLines.forEach { append(it).append('\n') } }
        }
        val name = "OKN_DSP_V66_CAPTURE_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.txt"
        try {
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: error("insert failed")
                contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) }
                Toast.makeText(this, "Saved Downloads/$name", Toast.LENGTH_LONG).show()
            } else {
                val f = java.io.File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), name)
                f.writeText(text)
                Toast.makeText(this, "Saved ${f.absolutePath}", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Save failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun fmt(v: Float): String = String.format(Locale.US, "%.3f", v)

    private fun requestBlePermissions() {
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT), 100)
        }
    }

    private fun hasBlePermission(): Boolean = android.os.Build.VERSION.SDK_INT < 31 ||
        (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
         checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED)
}
