package com.okn.dsp.protocol

/** Read-only evidence state model. It never emits DSP writes. */
enum class CapturePhase { BASELINE, SINGLE_PARAMETER_DIFF, REPEAT_SESSION, UNKNOWN }

data class ControlledCapture(
    val sessionId: String,
    val device: String,
    val firmware: String,
    val officialApp: String,
    val phase: CapturePhase,
    val action: String,
    val oldValue: String? = null,
    val newValue: String? = null,
    val rawCaptureFile: String,
) {
    fun isParameterDiff(): Boolean =
        phase == CapturePhase.SINGLE_PARAMETER_DIFF &&
        !oldValue.isNullOrBlank() && !newValue.isNullOrBlank() &&
        oldValue != newValue
}

object ControlledCaptureValidator {
    fun validate(c: ControlledCapture): List<String> = buildList {
        if (c.sessionId.isBlank()) add("missing session id")
        if (c.device.isBlank()) add("missing device")
        if (c.firmware.isBlank()) add("missing firmware")
        if (c.officialApp.isBlank()) add("missing official app version")
        if (c.rawCaptureFile.isBlank()) add("missing raw capture file")
        if (c.phase == CapturePhase.SINGLE_PARAMETER_DIFF && !c.isParameterDiff())
            add("single-parameter diff requires distinct old/new values")
    }
}
