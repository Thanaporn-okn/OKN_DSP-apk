package com.okn.dsp.protocol

import java.nio.ByteBuffer
import java.nio.ByteOrder

object ByteCodec {
    fun u16be(v: Int): ByteArray = byteArrayOf((v ushr 8).toByte(), v.toByte())

    fun u32be(v: Int): ByteArray = byteArrayOf(
        (v ushr 24).toByte(),
        (v ushr 16).toByte(),
        (v ushr 8).toByte(),
        v.toByte(),
    )

    fun i32le(v: Int): ByteArray = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(v).array()
    fun f32le(v: Float): ByteArray = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putFloat(v).array()

    fun readI32le(b: ByteArray, off: Int): Int =
        ByteBuffer.wrap(b, off, 4).order(ByteOrder.LITTLE_ENDIAN).int

    fun readF32le(b: ByteArray, off: Int): Float =
        ByteBuffer.wrap(b, off, 4).order(ByteOrder.LITTLE_ENDIAN).float

    fun readU16be(b: ByteArray, off: Int): Int =
        ((b[off].toInt() and 0xff) shl 8) or (b[off + 1].toInt() and 0xff)

    fun readU32be(b: ByteArray, off: Int): Int =
        ((b[off].toInt() and 0xff) shl 24) or
        ((b[off + 1].toInt() and 0xff) shl 16) or
        ((b[off + 2].toInt() and 0xff) shl 8) or
        (b[off + 3].toInt() and 0xff)

    fun hexToBytes(hex: String): ByteArray {
        val s = hex.replace(" ", "").replace("\n", "").trim()
        require(s.length % 2 == 0) { "hex length must be even" }
        return ByteArray(s.length / 2) { i -> s.substring(i * 2, i * 2 + 2).toInt(16).toByte() }
    }

    fun ByteArray.toHex(): String = joinToString("") { "%02X".format(it.toInt() and 0xff) }
}
