package com.okn.dsp.protocol

/** Byte-level fields visible in the 32-byte authentication response. */
data class AuthResponseHeader(
    val typeId: Int,
    val versionId: Int,
    val field4to7: ByteArray,
    val fixed8: ByteArray,
    val encryptedRandKey: ByteArray,
)

object AuthResponseCodec {
    fun parse32(bytes: ByteArray): AuthResponseHeader {
        require(bytes.size == 32) { "authentication response must be 32 bytes" }
        return AuthResponseHeader(
            typeId = ByteCodec.readU16be(bytes, 0),
            versionId = ByteCodec.readU16be(bytes, 2),
            field4to7 = bytes.copyOfRange(4, 8),
            fixed8 = bytes.copyOfRange(8, 16),
            encryptedRandKey = bytes.copyOfRange(16, 32),
        )
    }
}
