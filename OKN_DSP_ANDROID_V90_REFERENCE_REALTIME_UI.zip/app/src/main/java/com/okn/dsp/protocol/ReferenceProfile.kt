package com.okn.dsp.protocol

/**
 * Immutable provenance for protocol evidence.
 * A protocol observation must never be silently mixed across app/firmware profiles.
 */
data class ReferenceProfile(
    val id: String,
    val appVersion: String,
    val releaseDate: String?,
    val source: String,
    val artifactUrl: String?,
    val artifactSha256: String?,
    val notes: String,
)

object ReferenceProfiles {
    val reference250401 = ReferenceProfile(
        id = "golopine-250401-reference",
        appVersion = "250401",
        releaseDate = "2025-04-01",
        source = "Existing reverse-engineering evidence bundle",
        artifactUrl = null,
        artifactSha256 = "b1700436077aa0dcebf3fd8bc509a7a377c2eb9b62c9cb96980a5fe0bbd0fddb",
        notes = "Reference profile used for the existing AOT/GATT analysis.",
    )

    val official20260401 = ReferenceProfile(
        id = "golopine-official-20260401",
        appVersion = "2026-04-01",
        releaseDate = "2026-04-01",
        source = "GoloPine official product page",
        artifactUrl = "https://golodsp.com/wp-content/uploads/2026/05/golopine_audio_turning_release_2026-04-01.apk_.zip",
        artifactSha256 = null,
        notes = "Official download is listed by GoloPine; binary hash is intentionally unknown until the artifact is locally obtained and hashed.",
    )

    fun sameEvidenceProfile(a: ReferenceProfile, b: ReferenceProfile): Boolean =
        a.id == b.id && a.appVersion == b.appVersion && a.artifactSha256 == b.artifactSha256
}
