package com.okn.dsp.protocol

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

/** One verified 48-byte UFE_TYPE_BIQUAD_CASCADE15_F band record. */
data class EqBand48(
    val type: Int,
    val frequency: Float,
    val frequency2: Float,
    val q: Float,
    val boostDb: Float,
    val gain: Float,
    val r: Float,
    val b0: Float,
    val b1: Float,
    val b2: Float,
    val a1: Float,
    val a2: Float,
)

object EqBandCodec {
    const val BYTES = 48
    const val PEAKING_TYPE = 12
    const val SAMPLE_RATE_HZ = 44100.0

    fun decode(bytes: ByteArray): EqBand48 {
        require(bytes.size == BYTES) { "EQ band must be 48 bytes" }
        return EqBand48(
            type = ByteCodec.readI32le(bytes, 0),
            frequency = ByteCodec.readF32le(bytes, 4),
            frequency2 = ByteCodec.readF32le(bytes, 8),
            q = ByteCodec.readF32le(bytes, 12),
            boostDb = ByteCodec.readF32le(bytes, 16),
            gain = ByteCodec.readF32le(bytes, 20),
            r = ByteCodec.readF32le(bytes, 24),
            b0 = ByteCodec.readF32le(bytes, 28),
            b1 = ByteCodec.readF32le(bytes, 32),
            b2 = ByteCodec.readF32le(bytes, 36),
            a1 = ByteCodec.readF32le(bytes, 40),
            a2 = ByteCodec.readF32le(bytes, 44),
        )
    }

    fun encode(v: EqBand48): ByteArray =
        ByteCodec.i32le(v.type) +
            ByteCodec.f32le(v.frequency) +
            ByteCodec.f32le(v.frequency2) +
            ByteCodec.f32le(v.q) +
            ByteCodec.f32le(v.boostDb) +
            ByteCodec.f32le(v.gain) +
            ByteCodec.f32le(v.r) +
            ByteCodec.f32le(v.b0) +
            ByteCodec.f32le(v.b1) +
            ByteCodec.f32le(v.b2) +
            ByteCodec.f32le(v.a1) +
            ByteCodec.f32le(v.a2)

    /** RBJ peaking EQ. Matches captured GoloPine coefficients at fs=44.1 kHz. */
    fun peaking(frequencyHz: Double, q: Double, boostDb: Double): EqBand48 {
        require(frequencyHz > 0.0 && frequencyHz < SAMPLE_RATE_HZ / 2.0)
        require(q > 0.0)
        val a = 10.0.pow(boostDb / 40.0)
        val w0 = 2.0 * PI * frequencyHz / SAMPLE_RATE_HZ
        val alpha = sin(w0) / (2.0 * q)
        val a0 = 1.0 + alpha / a
        val b0 = (1.0 + alpha * a) / a0
        val b1 = (-2.0 * cos(w0)) / a0
        val b2 = (1.0 - alpha * a) / a0
        val a1 = (-2.0 * cos(w0)) / a0
        val a2 = (1.0 - alpha / a) / a0
        return EqBand48(
            type = PEAKING_TYPE,
            frequency = frequencyHz.toFloat(),
            frequency2 = 0f,
            q = q.toFloat(),
            boostDb = boostDb.toFloat(),
            gain = 0f,
            r = 0f,
            b0 = b0.toFloat(),
            b1 = b1.toFloat(),
            b2 = b2.toFloat(),
            a1 = a1.toFloat(),
            a2 = a2.toFloat(),
        )
    }
}
