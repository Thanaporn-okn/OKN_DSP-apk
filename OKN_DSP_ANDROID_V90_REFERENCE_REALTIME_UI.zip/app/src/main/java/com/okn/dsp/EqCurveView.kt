package com.okn.dsp

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.MotionEvent
import android.view.View
import com.okn.dsp.protocol.EqBand48
import com.okn.dsp.protocol.LiveEqPolicy
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln

/** Lightweight self-drawn EQ graph used by overview and editor screens. */
class EqCurveView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var channelColor: Int = Color.rgb(24, 200, 255)
    private var data: List<EqBand48?> = emptyList()
    private var selected: Int = -1
    private var onBandTap: ((Int) -> Unit)? = null

    fun setChannelColor(value: Int) { channelColor = value; invalidate() }
    fun setBands(value: List<EqBand48?>, selectedBand: Int = -1) {
        data = value
        selected = selectedBand
        invalidate()
    }
    fun setOnBandTapListener(listener: ((Int) -> Unit)?) { onBandTap = listener }

    private fun xForFreq(freq: Float): Float {
        val f = freq.coerceIn(20f, 20000f).toDouble()
        val t = (ln(f) - ln(20.0)) / (ln(20000.0) - ln(20.0))
        return paddingLeft + t.toFloat() * (width - paddingLeft - paddingRight)
    }

    private fun yForDb(db: Float): Float {
        val top = paddingTop.toFloat()
        val usable = (height - paddingTop - paddingBottom).toFloat().coerceAtLeast(1f)
        val t = ((12f - db.coerceIn(-12f, 12f)) / 24f)
        return top + t * usable
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        paint.style = Paint.Style.FILL
        paint.color = Color.rgb(3, 17, 26)
        canvas.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), 14f, 14f, paint)

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        paint.color = Color.argb(70, 70, 140, 170)
        for (i in 0..6) {
            val y = paddingTop + (height - paddingTop - paddingBottom) * i / 6f
            canvas.drawLine(paddingLeft.toFloat(), y, (width - paddingRight).toFloat(), y, paint)
        }
        val freqs = floatArrayOf(20f, 50f, 100f, 250f, 500f, 1000f, 2000f, 5000f, 10000f, 20000f)
        for (f in freqs) {
            val x = xForFreq(f)
            canvas.drawLine(x, paddingTop.toFloat(), x, (height - paddingBottom).toFloat(), paint)
        }
        paint.color = Color.argb(130, 90, 170, 195)
        paint.strokeWidth = 1.5f
        canvas.drawLine(paddingLeft.toFloat(), yForDb(0f), (width - paddingRight).toFloat(), yForDb(0f), paint)

        if (data.isEmpty()) return
        val curve = Path()
        val left = paddingLeft.toFloat()
        val right = (width - paddingRight).toFloat()
        val steps = width.coerceAtLeast(80)
        for (i in 0..steps) {
            val px = left + (right - left) * i / steps.toFloat()
            val norm = ((px - left) / (right - left).coerceAtLeast(1f)).coerceIn(0f, 1f)
            val lf = ln(20.0) + norm.toDouble() * (ln(20000.0) - ln(20.0))
            var db = 0.0
            data.forEach { b ->
                if (b != null && LiveEqPolicy.isWritable(b)) {
                    val center = ln(b.frequency.coerceAtLeast(20f).toDouble())
                    val widthLog = (0.34 / b.q.coerceAtLeast(.1f).toDouble()).coerceIn(0.025, 0.55)
                    val z = (lf - center) / widthLog
                    db += b.boostDb.toDouble() * exp(-0.5 * z * z)
                }
            }
            val py = yForDb(db.toFloat().coerceIn(-12f, 12f))
            if (i == 0) curve.moveTo(px, py) else curve.lineTo(px, py)
        }
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2.4f
        paint.color = channelColor
        canvas.drawPath(curve, paint)

        data.forEachIndexed { index, b ->
            if (b == null || !LiveEqPolicy.isWritable(b)) return@forEachIndexed
            val x = xForFreq(b.frequency)
            val y = yForDb(b.boostDb)
            paint.style = Paint.Style.FILL
            paint.color = if (index == selected) Color.WHITE else channelColor
            canvas.drawCircle(x, y, if (index == selected) 5.5f else 3.6f, paint)
            if (index == selected) {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 2f
                paint.color = channelColor
                canvas.drawCircle(x, y, 7.5f, paint)
            }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!isEnabled || event.action != MotionEvent.ACTION_UP || data.isEmpty()) return true
        var best = -1
        var bestDist = Float.MAX_VALUE
        data.forEachIndexed { index, b ->
            if (b != null && LiveEqPolicy.isWritable(b)) {
                val d = abs(xForFreq(b.frequency) - event.x)
                if (d < bestDist) { bestDist = d; best = index }
            }
        }
        if (best >= 0) onBandTap?.invoke(best)
        return true
    }
}
