package com.okn.dsp

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.ContentValues
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.widget.*
import androidx.core.app.ActivityCompat
import com.okn.dsp.protocol.*
import com.okn.dsp.transport.BleProfile
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.abs

/**
 * V63 dedicated proof for actuator ID3 RemindSoundVolume.
 *
 * Guardrails:
 * - ID3 is NOT added to the production VerifiedScalarControls allow-list.
 * - Generic WriteGate.enabled remains false.
 * - The proof obtains a fresh live baseline, changes it by exactly 1.0 dB in-range,
 *   verifies via a fresh Device Description, then automatically restores the exact baseline
 *   and verifies the restore.
 * - SaveParams is never sent. This is RAM-only proof and leaves the baseline restored.
 */
class RemindSoundProofActivity : Activity() {
    companion object {
        const val ID = 3
        const val NAME = "RemindSoundVolume"
        const val MIN_DB = -70.0f
        const val MAX_DB = 6.0f
        const val DELTA_DB = 1.0f
        const val VERIFY_TOLERANCE_DB = 0.06f
    }

    private val handler = Handler(Looper.getMainLooper())
    private val ts = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    private val startupProbe16 = ByteCodec.hexToBytes("631C062443FD3844558001F3EDA0CCF8")

    private lateinit var status: TextView
    private lateinit var liveValue: TextView
    private lateinit var logView: TextView
    private lateinit var deviceList: LinearLayout
    private lateinit var startSessionButton: Button
    private lateinit var runProofButton: Button

    private var scanner: android.bluetooth.le.BluetoothLeScanner? = null
    private val found = LinkedHashMap<String, BluetoothDevice>()
    private var gatt: BluetoothGatt? = null
    private var ab01: BluetoothGattCharacteristic? = null
    private var ab02: BluetoothGattCharacteristic? = null
    private var connectedName: String? = null

    private var waitingAuth = false
    private var sessionReady = false
    private var txCipher: SessionTxCipher? = null
    private var rxCipher: SessionRxCipher? = null

    private enum class DescMode { INITIAL, PREFLIGHT, VERIFY_TARGET, VERIFY_RESTORE }
    private var descMode: DescMode? = null
    private var descExpected = -1
    private val descBytes = ByteArrayOutputStream()
    private var verificationTimeout: Runnable? = null

    private var baselineDb: Float? = null
    private var targetDb: Float? = null
    private var proofInFlight = false
    private var targetVerified = false

    private val captureLines = mutableListOf<String>()
    private var packetNo = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestBlePermissions()
        record("META", "V63_REMIND_SOUND_ID3_ACTIVITY_START")
        record("META", "V63_ID3_STATIC_POLICY id=3 name=RemindSoundVolume min=-70.0 max=6.0 deltaDb=1.0 productionAllowList=false genericWrites=false saveParams=false")
    }

    override fun onDestroy() {
        verificationTimeout?.let { handler.removeCallbacks(it) }
        super.onDestroy()
        try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
        try { gatt?.close() } catch (_: Exception) {}
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 22, 22, 28)
        }
        root.addView(TextView(this).apply {
            text = "OKN DSP V63 — REMIND SOUND VOLUME ID3 GUARDED PROOF"
            textSize = 22f
        })
        status = TextView(this).apply {
            text = "DISCONNECTED • proof only • auto-restore • NO SAVEPARAMS"
            textSize = 14f
            setPadding(0, 8, 0, 8)
        }
        root.addView(status)
        root.addView(TextView(this).apply {
            text = "Dedicated runtime proof for actuator ID3 RemindSoundVolume (FLOAT32, -70..6 dB, descriptor incmt=1). V63 does NOT expose ID3 in Production Global Controls. It reads a fresh baseline, applies a guarded 1.0 dB test in RAM, verifies by fresh Device Description, then automatically restores the exact baseline and verifies again. SaveParams ID7 is never sent."
            textSize = 13f
            setPadding(0, 0, 0, 10)
        })

        root.addView(Button(this).apply {
            text = "SCAN DSP"
            setOnClickListener { startScan() }
        })
        deviceList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(deviceList)

        startSessionButton = Button(this).apply {
            text = "START V63 READ-ONLY ID3 SESSION"
            isEnabled = false
            setOnClickListener { confirmStartSession() }
        }
        root.addView(startSessionButton)

        liveValue = TextView(this).apply {
            text = "ID3 live baseline: ?"
            textSize = 17f
            setPadding(0, 10, 0, 10)
        }
        root.addView(liveValue)

        runProofButton = Button(this).apply {
            text = "RUN GUARDED ID3 PROOF • 1.0 dB → VERIFY → AUTO-RESTORE • NO SAVE"
            isEnabled = false
            setOnClickListener { confirmRunProof() }
        }
        root.addView(runProofButton)

        root.addView(TextView(this).apply {
            text = "Safety: the proof always refreshes the baseline immediately before the write. If target verification fails, V63 still restores the fresh baseline and verifies the restore. If restore verification fails, the session is blocked and no further write is allowed."
            textSize = 12f
            setPadding(0, 4, 0, 10)
        })

        root.addView(Button(this).apply {
            text = "SAVE V63 CAPTURE TO DOWNLOADS"
            setOnClickListener { saveCapture() }
        })
        logView = TextView(this).apply { textSize = 11f; setPadding(0, 12, 0, 0) }
        root.addView(logView)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun confirmStartSession() {
        if (proofInFlight || descMode != null || waitingAuth) {
            Toast.makeText(this, "V63 protocol busy", Toast.LENGTH_LONG).show(); return
        }
        if (gatt == null || ab01 == null || ab02 == null) {
            Toast.makeText(this, "เชื่อม AB00/AB01/AB02 ก่อน", Toast.LENGTH_LONG).show(); return
        }
        AlertDialog.Builder(this)
            .setTitle("Start V63 ID3 read-only session")
            .setMessage("AUTH16 → derive current RandKey → read fresh Device Description. ขั้น START ยังไม่เขียน ID3 และไม่ส่ง SaveParams")
            .setNegativeButton("ยกเลิก", null)
            .setPositiveButton("START") { _, _ -> startSession() }
            .show()
    }

    private fun startSession() {
        val g = gatt ?: return
        val w = ab01 ?: return
        waitingAuth = true
        sessionReady = false
        proofInFlight = false
        targetVerified = false
        baselineDb = null
        targetDb = null
        txCipher = null
        rxCipher = null
        descMode = null
        liveValue.text = "ID3 live baseline: ?"
        runProofButton.isEnabled = false
        record("META", "V63_ID3_SESSION_START")
        if (!writeNoResponse(g, w, startupProbe16, "TX_AUTH16_V63")) {
            waitingAuth = false
            status.text = "AUTH16 queue failed"
        } else status.text = "AUTH16 sent • waiting 32B auth response"
    }

    private fun confirmRunProof() {
        if (!WriteGate.remindSoundVolumeProofEnabled) {
            Toast.makeText(this, "V63 ID3 proof gate disabled", Toast.LENGTH_LONG).show(); return
        }
        if (!sessionReady || proofInFlight || descMode != null || waitingAuth || txCipher == null) {
            Toast.makeText(this, "V63 session ยังไม่พร้อม", Toast.LENGTH_LONG).show(); return
        }
        val shown = baselineDb ?: run {
            Toast.makeText(this, "ยังไม่มี live baseline ID3", Toast.LENGTH_LONG).show(); return
        }
        AlertDialog.Builder(this)
            .setTitle("V63 GUARDED ID3 PROOF")
            .setMessage("ID3 RemindSoundVolume live=${fmt(shown)} dB\n\nเมื่อยืนยัน V63 จะอ่าน baseline สดอีกครั้ง แล้วเปลี่ยน 1.0 dB ภายในช่วง -70..6 dB → fresh descriptor verify → AUTO-RESTORE baseline → verify.\n\nNO SAVEPARAMS • ไม่มีการบันทึกถาวร")
            .setNegativeButton("ยกเลิก", null)
            .setPositiveButton("RUN PROOF") { _, _ -> beginFreshPreflight() }
            .show()
    }

    private fun beginFreshPreflight() {
        if (!sessionReady || proofInFlight || descMode != null) return
        proofInFlight = true
        targetVerified = false
        runProofButton.isEnabled = false
        status.text = "V63 preflight • reading fresh ID3 baseline"
        requestDescriptor(DescMode.PREFLIGHT)
    }

    private fun safeTarget(baseline: Float): Float? {
        if (!baseline.isFinite() || baseline < MIN_DB - VERIFY_TOLERANCE_DB || baseline > MAX_DB + VERIFY_TOLERANCE_DB) return null
        val up = baseline + DELTA_DB
        if (up <= MAX_DB) return up
        val down = baseline - DELTA_DB
        if (down >= MIN_DB) return down
        return null
    }

    private fun sendTargetWrite() {
        val base = baselineDb ?: return stopProof("missing-baseline-before-target")
        val target = safeTarget(base) ?: return stopProof("no-safe-target")
        targetDb = target
        val g = gatt ?: return stopProof("gatt-missing-target")
        val w = ab01 ?: return stopProof("ab01-missing-target")
        val tx = txCipher ?: return stopProof("tx-missing-target")
        val plain = UfeCodec.encodeFloat32Write(ID, target)
        record("META", "V63_ID3_WRITE_PLAIN=${ByteCodec.run { plain.toHex() }} id=3 name=RemindSoundVolume baseline=$base target=$target delta=${target-base} saveParams=false")
        val enc = tx.encryptNext(plain)
        if (!writeNoResponse(g, w, enc, "TX_ID3_TARGET_V63")) {
            return stopProof("target-write-queue-failed")
        }
        status.text = "V63 ID3 target sent ${fmt(target)} dB • verifying"
        handler.postDelayed({ requestDescriptor(DescMode.VERIFY_TARGET) }, 350L)
    }

    private fun sendRestore(reason: String) {
        val base = baselineDb ?: return stopProof("missing-baseline-before-restore")
        val g = gatt ?: return stopProof("gatt-missing-restore")
        val w = ab01 ?: return stopProof("ab01-missing-restore")
        val tx = txCipher ?: return stopProof("tx-missing-restore")
        val plain = UfeCodec.encodeFloat32Write(ID, base)
        record("META", "V63_ID3_RESTORE_WRITE_PLAIN=${ByteCodec.run { plain.toHex() }} id=3 baseline=$base reason=$reason saveParams=false")
        val enc = tx.encryptNext(plain)
        if (!writeNoResponse(g, w, enc, "TX_ID3_RESTORE_V63")) {
            return stopProof("restore-write-queue-failed")
        }
        status.text = "V63 restoring exact ID3 baseline ${fmt(base)} dB • verifying"
        handler.postDelayed({ requestDescriptor(DescMode.VERIFY_RESTORE) }, 350L)
    }

    private fun requestDescriptor(mode: DescMode) {
        val g = gatt ?: return stopProof("gatt-missing-desc-$mode")
        val w = ab01 ?: return stopProof("ab01-missing-desc-$mode")
        val tx = txCipher ?: return stopProof("tx-missing-desc-$mode")
        descMode = mode
        descExpected = -1
        descBytes.reset()
        val plain = SessionCryptoFacts.DEVICE_DESCRIPTION_REQUEST
        val enc = tx.encryptNext(plain)
        record("META", "V63_DESC_REQUEST mode=$mode plain=${ByteCodec.run { plain.toHex() }}")
        if (!writeNoResponse(g, w, enc, "TX_DESC_V63_${mode.name}")) {
            descMode = null
            if (mode == DescMode.VERIFY_TARGET) sendRestore("target-desc-queue-failed") else stopProof("desc-request-queue-failed-$mode")
            return
        }
        verificationTimeout?.let { handler.removeCallbacks(it) }
        verificationTimeout = Runnable {
            record("META", "V63_VERIFY_TIMEOUT mode=$mode")
            descMode = null
            if (mode == DescMode.VERIFY_TARGET) sendRestore("target-verify-timeout") else stopProof("verify-timeout-$mode")
        }.also { handler.postDelayed(it, 12000L) }
    }

    private fun handleAb02(value: ByteArray) {
        record("RX_NOTIFY", "len=${value.size} hex=${ByteCodec.run { value.toHex() }}")
        if (waitingAuth) {
            if (value.size != 32) return
            try {
                val d = PreAuthRandKeyDecoder.decode(value)
                txCipher = SessionTxCipher(d.randKey)
                rxCipher = SessionRxCipher(d.randKey)
                waitingAuth = false
                record("META", "V63_RANDKEY_DERIVED type=${d.typeId} ver=${d.versionId} rand=${ByteCodec.run { d.randKey.toHex() }}")
                requestDescriptor(DescMode.INITIAL)
            } catch (e: Exception) {
                waitingAuth = false
                record("META", "V63_AUTH_DECODE_ERROR ${e.javaClass.simpleName}:${e.message}")
                runOnUiThread { status.text = "Auth decode failed" }
            }
            return
        }

        val rx = rxCipher ?: return
        val plain = try { rx.decryptNext(value) } catch (e: Exception) {
            record("META", "V63_RX_DECRYPT_ERROR ${e.javaClass.simpleName}:${e.message}")
            sessionReady = false
            return
        }
        record("RX_PLAIN", "len=${plain.size} hex=${ByteCodec.run { plain.toHex() }}")
        if (descMode != null) collectDescriptor(plain)
    }

    private fun collectDescriptor(plain: ByteArray) {
        val mode = descMode ?: return
        if (descExpected < 0) {
            if (plain.size < 4 || (plain[0].toInt() and 0xff) != 0x86) {
                record("META", "V63_DESC_NONHEADER mode=$mode marker=${plain.firstOrNull()?.toInt()?.and(0xff)} len=${plain.size}")
                return
            }
            descExpected = (plain[1].toInt() and 0xff) or ((plain[2].toInt() and 0xff) shl 8) or ((plain[3].toInt() and 0xff) shl 16)
            descBytes.reset()
            descBytes.write(plain, 4, plain.size - 4)
            record("META", "V63_DESC_HEADER mode=$mode jsonLen=$descExpected")
        } else {
            if (plain.isEmpty() || (plain[0].toInt() and 0xff) != 0x82) {
                record("META", "V63_DESC_NONCONT mode=$mode marker=${plain.firstOrNull()?.toInt()?.and(0xff)} len=${plain.size}")
                return
            }
            descBytes.write(plain, 1, plain.size - 1)
        }
        if (descExpected > 0 && descBytes.size() >= descExpected) {
            val bytes = descBytes.toByteArray().copyOf(descExpected)
            val obj = JSONObject(bytes.toString(Charsets.UTF_8))
            record("META", "V63_DESC_COMPLETE mode=$mode bytes=${bytes.size}")
            descMode = null
            descExpected = -1
            descBytes.reset()
            verificationTimeout?.let { handler.removeCallbacks(it) }
            verificationTimeout = null
            handler.post { onDescriptorComplete(mode, obj) }
        }
    }

    private fun onDescriptorComplete(mode: DescMode, obj: JSONObject) {
        val live = extractId3(obj)
        when (mode) {
            DescMode.INITIAL -> {
                if (live == null) {
                    sessionReady = false
                    baselineDb = null
                    liveValue.text = "ID3 live baseline: MISSING"
                    status.text = "V63 BLOCKED • ID3 FLOAT32 missing from fresh descriptor"
                    runProofButton.isEnabled = false
                    record("META", "V63_ID3_INITIAL_READY ready=false reason=missing-id3")
                } else {
                    sessionReady = true
                    baselineDb = live
                    targetDb = safeTarget(live)
                    liveValue.text = "ID3 RemindSoundVolume • live=${fmt(live)} dB • proof target=${targetDb?.let { fmt(it) } ?: "BLOCKED"} dB"
                    status.text = "V63 ID3 READY • fresh descriptor loaded • proof not started • NO SAVEPARAMS"
                    runProofButton.isEnabled = targetDb != null
                    record("META", "V63_ID3_INITIAL_READY ready=true live=$live safeTarget=${targetDb ?: "NONE"} saveParams=false")
                }
            }
            DescMode.PREFLIGHT -> {
                if (live == null) return stopProof("preflight-id3-missing")
                val target = safeTarget(live) ?: return stopProof("preflight-no-safe-target")
                baselineDb = live
                targetDb = target
                liveValue.text = "ID3 fresh baseline=${fmt(live)} dB • guarded target=${fmt(target)} dB"
                record("META", "V63_ID3_PREFLIGHT id=3 baseline=$live target=$target delta=${target-live} freshDescriptor=true inRange=true")
                sendTargetWrite()
            }
            DescMode.VERIFY_TARGET -> {
                val expected = targetDb ?: return stopProof("missing-target-verify")
                val ok = live != null && abs(live - expected) <= VERIFY_TOLERANCE_DB
                targetVerified = ok
                record("META", "V63_ID3_TARGET_DESCRIPTOR_VERIFY id=3 expected=$expected actual=${live ?: "MISSING"} verified=$ok")
                if (ok) {
                    liveValue.text = "ID3 target verified=${fmt(live!!)} dB • AUTO-RESTORE queued"
                    status.text = "V63 target verified • auto-restoring fresh baseline • NO SAVE"
                    handler.postDelayed({ sendRestore("target-verified") }, 1200L)
                } else {
                    status.text = "V63 target verify failed • restoring fresh baseline now"
                    sendRestore("target-verify-failed")
                }
            }
            DescMode.VERIFY_RESTORE -> {
                val expected = baselineDb ?: return stopProof("missing-baseline-restore-verify")
                val ok = live != null && abs(live - expected) <= VERIFY_TOLERANCE_DB
                record("META", "V63_ID3_RESTORE_DESCRIPTOR_VERIFY id=3 expected=$expected actual=${live ?: "MISSING"} verified=$ok")
                proofInFlight = false
                if (ok) {
                    baselineDb = live
                    targetDb = safeTarget(live!!)
                    liveValue.text = "ID3 restored=${fmt(live)} dB • baseline intact"
                    if (targetVerified) {
                        status.text = "V63 COMPLETE • ID3 RemindSoundVolume write/readback proven • baseline restored • NO SAVEPARAMS"
                        record("META", "V63_REMIND_SOUND_ID3_PROOF_COMPLETE id=3 baseline=$expected target=${targetDbForRecord()} targetVerified=true restored=true saveParamsSent=false persistence=RAM_ONLY")
                    } else {
                        status.text = "V63 TARGET NOT VERIFIED • baseline restored safely • save capture"
                        record("META", "V63_REMIND_SOUND_ID3_TARGET_NOT_VERIFIED baseline=$expected restored=true saveParamsSent=false")
                    }
                    runProofButton.isEnabled = sessionReady && targetDb != null
                } else {
                    sessionReady = false
                    runProofButton.isEnabled = false
                    status.text = "V63 RESTORE VERIFY FAILED — STOP • do not write/save • save capture"
                    record("META", "V63_ID3_PROOF_STOPPED reason=restore-verify-failed baseline=$expected actual=${live ?: "MISSING"} saveParamsSent=false")
                }
            }
        }
    }

    private fun targetDbForRecord(): String {
        val base = baselineDb ?: return "UNKNOWN"
        val prior = if (base + DELTA_DB <= MAX_DB) base + DELTA_DB else base - DELTA_DB
        return prior.toString()
    }

    private fun extractId3(obj: JSONObject): Float? {
        val arr = obj.optJSONArray("actuators") ?: return null
        for (i in 0 until arr.length()) {
            val a = arr.optJSONObject(i) ?: continue
            if (a.optInt("ID", -1) != ID) continue
            if (a.optInt("type", -1) != 2000 || !a.has("UFE_TYPE_FLOAT32")) return null
            val v = a.optDouble("UFE_TYPE_FLOAT32", Double.NaN).toFloat()
            return v.takeIf { it.isFinite() }
        }
        return null
    }

    private fun stopProof(reason: String) {
        proofInFlight = false
        sessionReady = false
        verificationTimeout?.let { handler.removeCallbacks(it) }
        verificationTimeout = null
        record("META", "V63_ID3_PROOF_STOPPED reason=$reason saveParamsSent=false")
        runOnUiThread {
            runProofButton.isEnabled = false
            status.text = "V63 STOPPED • $reason • NO SAVE • save capture"
        }
    }

    private fun startScan() {
        if (!hasBlePermission()) { requestBlePermissions(); return }
        val adapter = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter ?: return
        if (!adapter.isEnabled) { Toast.makeText(this, "เปิด Bluetooth ก่อน", Toast.LENGTH_SHORT).show(); return }
        found.clear(); deviceList.removeAllViews()
        scanner = adapter.bluetoothLeScanner
        status.text = "SCANNING"
        try { scanner?.startScan(scanCallback) } catch (_: SecurityException) { return }
        handler.postDelayed({ try { scanner?.stopScan(scanCallback) } catch (_: Exception) {} }, 10000L)
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val d = result.device
            val name = result.scanRecord?.deviceName ?: try { d.name } catch (_: SecurityException) { null }
            if (name?.contains("GOLOPINE", true) != true && name?.contains("DSP", true) != true) return
            if (found.putIfAbsent(d.address, d) != null) return
            runOnUiThread {
                deviceList.addView(Button(this@RemindSoundProofActivity).apply {
                    text = "${name ?: "DSP"} • ${d.address}\nแตะเพื่อเชื่อมต่อ"
                    setOnClickListener { connect(d, name ?: "DSP") }
                })
            }
        }
    }

    private fun connect(device: BluetoothDevice, name: String) {
        if (proofInFlight) { Toast.makeText(this, "V63 proof กำลังทำงาน • ห้ามเปลี่ยน connection", Toast.LENGTH_LONG).show(); return }
        if (!hasBlePermission()) return
        try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
        try { gatt?.close() } catch (_: Exception) {}
        connectedName = name
        status.text = "CONNECTING $name"
        record("META", "V63_CONNECT_START name=$name address=${device.address}")
        try {
            gatt = device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
        } catch (_: SecurityException) { status.text = "CONNECT permission error" }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, statusCode: Int, newState: Int) {
            record("META", "GATT_STATE status=$statusCode newState=$newState")
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                runOnUiThread { status.text = "CONNECTED ${connectedName ?: "DSP"} • discovering" }
                try {
                    g.requestMtu(517)
                    handler.postDelayed({ try { g.discoverServices() } catch (_: SecurityException) {} }, 250L)
                } catch (_: SecurityException) {}
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                if (proofInFlight) record("META", "V63_ID3_PROOF_STOPPED reason=disconnect-during-proof saveParamsSent=false")
                proofInFlight = false
                sessionReady = false; waitingAuth = false; txCipher = null; rxCipher = null
                runOnUiThread {
                    status.text = "DISCONNECTED"
                    startSessionButton.isEnabled = false
                    runProofButton.isEnabled = false
                }
            }
        }

        override fun onMtuChanged(g: BluetoothGatt, mtu: Int, statusCode: Int) {
            record("META", "MTU_CHANGED mtu=$mtu status=$statusCode")
        }

        override fun onServicesDiscovered(g: BluetoothGatt, statusCode: Int) {
            val service = g.getService(BleProfile.AB00_SERVICE)
            ab01 = service?.getCharacteristic(BleProfile.AB01_WRITE)
            ab02 = service?.getCharacteristic(BleProfile.AB02_NOTIFY)
            val ok = statusCode == BluetoothGatt.GATT_SUCCESS && ab01 != null && ab02 != null
            record("META", "SERVICES_DISCOVERED status=$statusCode AB01=${ab01 != null} AB02=${ab02 != null}")
            if (!ok) { runOnUiThread { status.text = "AB00/AB01/AB02 profile not found" }; return }
            subscribeAb02(g, ab02!!)
            runOnUiThread { status.text = "CONNECTED • enabling AB02 notifications"; startSessionButton.isEnabled = false }
        }

        override fun onDescriptorWrite(g: BluetoothGatt, descriptor: BluetoothGattDescriptor, statusCode: Int) {
            record("META", "CCCD_WRITE status=$statusCode")
            runOnUiThread {
                if (statusCode == BluetoothGatt.GATT_SUCCESS) {
                    status.text = "CONNECTED • AB02 notifications READY"
                    startSessionButton.isEnabled = true
                } else {
                    status.text = "CCCD notification enable failed: $statusCode"
                    startSessionButton.isEnabled = false
                }
            }
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, statusCode: Int) {
            record("META", "TX_WRITE_RESULT status=$statusCode uuid=${characteristic.uuid}")
            if (statusCode != BluetoothGatt.GATT_SUCCESS && proofInFlight && characteristic.uuid == BleProfile.AB01_WRITE) {
                record("META", "V63_ID3_GATT_WRITE_NONZERO status=$statusCode")
            }
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            if (characteristic.uuid == BleProfile.AB02_NOTIFY) handleAb02(value)
        }

        @Suppress("DEPRECATION")
        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            if (android.os.Build.VERSION.SDK_INT < 33 && characteristic.uuid == BleProfile.AB02_NOTIFY) handleAb02(characteristic.value ?: byteArrayOf())
        }
    }

    private fun subscribeAb02(g: BluetoothGatt, ch: BluetoothGattCharacteristic) {
        if (!hasBlePermission()) return
        try {
            g.setCharacteristicNotification(ch, true)
            val cccd = ch.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")) ?: return
            val v = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            if (android.os.Build.VERSION.SDK_INT >= 33) g.writeDescriptor(cccd, v)
            else {
                @Suppress("DEPRECATION") cccd.value = v
                @Suppress("DEPRECATION") g.writeDescriptor(cccd)
            }
        } catch (e: Exception) { record("META", "SUBSCRIBE_ERROR ${e.javaClass.simpleName}:${e.message}") }
    }

    private fun writeNoResponse(g: BluetoothGatt, ch: BluetoothGattCharacteristic, bytes: ByteArray, label: String): Boolean {
        if (!hasBlePermission()) return false
        record("TX", "$label len=${bytes.size} hex=${ByteCodec.run { bytes.toHex() }}")
        return try {
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                g.writeCharacteristic(ch, bytes, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE) == BluetoothStatusCodes.SUCCESS
            } else {
                @Suppress("DEPRECATION") ch.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                @Suppress("DEPRECATION") ch.value = bytes
                @Suppress("DEPRECATION") g.writeCharacteristic(ch)
            }
        } catch (e: Exception) {
            record("META", "$label ERROR ${e.javaClass.simpleName}:${e.message}")
            false
        }
    }

    private fun record(kind: String, text: String) {
        val line = "${ts.format(Date())}\t#${++packetNo}\t$kind\t$text"
        synchronized(captureLines) { captureLines.add(line) }
        runOnUiThread { logView.text = (logView.text.toString() + line + "\n").takeLast(14000) }
    }

    private fun saveCapture() {
        val text = buildString {
            append("=== OKN DSP V63 REMIND SOUND VOLUME ID3 GUARDED PROOF CAPTURE ===\n")
            synchronized(captureLines) { captureLines.forEach { append(it).append('\n') } }
        }
        val name = "OKN_DSP_V63_CAPTURE_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.txt"
        try {
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: error("insert failed")
                contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) }
                Toast.makeText(this, "Saved Downloads/$name", Toast.LENGTH_LONG).show()
            } else {
                val f = java.io.File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), name)
                f.writeText(text)
                Toast.makeText(this, "Saved ${f.absolutePath}", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Save failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun fmt(v: Float): String = String.format(Locale.US, "%.3f", v)

    private fun requestBlePermissions() {
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT), 100)
        }
    }

    private fun hasBlePermission(): Boolean = android.os.Build.VERSION.SDK_INT < 31 ||
        (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
         checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED)
}
