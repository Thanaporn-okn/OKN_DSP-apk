package com.okn.dsp.protocol

import kotlin.math.abs

data class EqChannelProbe(
    val channel: Int,
    val actuatorId: Int,
    val bandIndex1: Int,
    val expectedFrequencyHz: Float,
    val expectedQ: Float = 2.23f,
) {
    val offset: Int get() = (bandIndex1 - 1) * EqBandCodec.BYTES
    val label: String get() = "CH$channel / ID$actuatorId / Band$bandIndex1"
}

/**
 * V50 runtime map proof.
 * CH1/ID4/Band4 was already proven by V49. V50 probes CH2..CH7 only.
 * Each probe starts from a live, guarded 0 dB peaking band, writes -0.25 dB,
 * verifies via Device Description, then restores the live baseline record and
 * verifies the semantic baseline before proceeding to the next channel.
 */
object SevenChannelEqMapPolicy {
    const val TARGET_BOOST_DB = -0.25f
    const val FIELD_TOL = 0.0045f
    const val PREFLIGHT_TOL = 0.02f

    val probes = listOf(
        EqChannelProbe(channel = 2, actuatorId = 5, bandIndex1 = 4, expectedFrequencyHz = 100.0f),
        EqChannelProbe(channel = 3, actuatorId = 6, bandIndex1 = 5, expectedFrequencyHz = 158.8f),
        EqChannelProbe(channel = 4, actuatorId = 14, bandIndex1 = 4, expectedFrequencyHz = 100.0f),
        EqChannelProbe(channel = 5, actuatorId = 15, bandIndex1 = 4, expectedFrequencyHz = 100.0f),
        EqChannelProbe(channel = 6, actuatorId = 16, bandIndex1 = 5, expectedFrequencyHz = 158.8f),
        EqChannelProbe(channel = 7, actuatorId = 17, bandIndex1 = 4, expectedFrequencyHz = 100.0f),
    )

    fun preflight(probe: EqChannelProbe, actual: EqBand48): Boolean =
        actual.type == EqBandCodec.PEAKING_TYPE &&
            abs(actual.frequency - probe.expectedFrequencyHz) <= 0.35f &&
            abs(actual.frequency2) <= PREFLIGHT_TOL &&
            abs(actual.q - probe.expectedQ) <= PREFLIGHT_TOL &&
            abs(actual.boostDb) <= PREFLIGHT_TOL &&
            abs(actual.gain) <= PREFLIGHT_TOL &&
            abs(actual.r) <= PREFLIGHT_TOL

    fun targetFromBaseline(actual: EqBand48): EqBand48 =
        EqBandCodec.peaking(
            frequencyHz = actual.frequency.toDouble(),
            q = actual.q.toDouble(),
            boostDb = TARGET_BOOST_DB.toDouble(),
        )

    fun semanticMatches(actual: EqBand48, expected: EqBand48): Boolean =
        actual.type == expected.type &&
            abs(actual.frequency - expected.frequency) <= FIELD_TOL &&
            abs(actual.frequency2 - expected.frequency2) <= FIELD_TOL &&
            abs(actual.q - expected.q) <= FIELD_TOL &&
            abs(actual.boostDb - expected.boostDb) <= FIELD_TOL &&
            abs(actual.gain - expected.gain) <= FIELD_TOL &&
            abs(actual.r - expected.r) <= FIELD_TOL &&
            abs(actual.b0 - expected.b0) <= FIELD_TOL &&
            abs(actual.b1 - expected.b1) <= FIELD_TOL &&
            abs(actual.b2 - expected.b2) <= FIELD_TOL &&
            abs(actual.a1 - expected.a1) <= FIELD_TOL &&
            abs(actual.a2 - expected.a2) <= FIELD_TOL

    fun encodeTargetWrite(probe: EqChannelProbe, baseline: EqBand48): ByteArray =
        UfeCodec.encodeWrite(probe.actuatorId, probe.offset, EqBandCodec.encode(targetFromBaseline(baseline)))

    fun encodeRestoreWrite(probe: EqChannelProbe, baseline: EqBand48): ByteArray =
        UfeCodec.encodeWrite(probe.actuatorId, probe.offset, EqBandCodec.encode(baseline))
}
