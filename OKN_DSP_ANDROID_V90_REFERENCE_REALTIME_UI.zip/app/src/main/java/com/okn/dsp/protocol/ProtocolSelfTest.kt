package com.okn.dsp.protocol

import com.okn.dsp.protocol.ByteCodec.toHex
import kotlin.math.abs

object ProtocolSelfTest {
    private fun ok(name: String, pass: Boolean, detail: String = ""): String =
        (if (pass) "PASS" else "FAIL") + " • " + name + if (detail.isBlank()) "" else " • $detail"

    fun run(): List<String> = buildList {
        val master = UfeCodec.encodeFloat32Write(ConfirmedDspMap.MASTER_VOLUME, -13.76f)
        add(ok("UFE Master -13.76 dB", master.toHex() == "570000000200000004F6285CC1", master.toHex()))

        val read = UfeCodec.encodeRead(21, 0, 4)
        add(ok("UFE READ ID21 len4", read.toHex() == "580000001500000004", read.toHex()))

        val keyA = ByteCodec.hexToBytes("81162308EBF817D62C083CD5250A2D4D")
        val encA = SessionTxCipher(keyA).encryptNext(SessionCryptoFacts.DEVICE_DESCRIPTION_REQUEST)
        add(ok("AES-CFB8 session A", encA.toHex() == "AC6B6C12", encA.toHex()))

        val keyB = ByteCodec.hexToBytes("2CDB9100B0162F6D82285C9706EFABB3")
        val encB = SessionTxCipher(keyB).encryptNext(SessionCryptoFacts.DEVICE_DESCRIPTION_REQUEST)
        add(ok("AES-CFB8 session B", encB.toHex() == "B596F744", encB.toHex()))

        val keyLatest = ByteCodec.hexToBytes("0168DEEB916838D752E0D696BB3655E6")
        val latestRequestCipher = ByteCodec.hexToBytes("5DFCB7E5")
        val latestPlain = SessionCryptoEvidence.decryptFirstPostAuthPacket(keyLatest, latestRequestCipher)
        add(ok("SAME-SESSION 20:45:55 decrypt 5DFCB7E5", latestPlain.toHex() == "661C0624",
            latestPlain.toHex()))

        val rxFirstCipher = ByteCodec.hexToBytes("BD6816A7A6079CC1E9DD53E8C21B4C0967487A96618F2C203B9819AD970A30DF")
        val rxFirstPlain = SessionCryptoEvidence.decryptFirstPostAuthPacket(keyLatest, rxFirstCipher)
        add(ok("SAME-SESSION RX IV=01 / device-desc header", rxFirstPlain.toHex() ==
            "86E646007B226E616D65223A22476F6C6F50696E655F4453505F416D706C6966",
            rxFirstPlain.copyOfRange(0, 4).toHex()))
        add(ok("Device-desc framing 0x86 + U24LE length", DeviceDescriptionProof.FIRST_RX_HEADER == "86E64600" &&
            DeviceDescriptionProof.DEVICE_JSON_BYTES == 18150, DeviceDescriptionProof.FIRST_RX_HEADER))
        add(ok("Readback 0x58/0x60 evidence", DeviceDescriptionProof.READBACK_PAIRS == 83,
            "pairs=${DeviceDescriptionProof.READBACK_PAIRS}"))

        val captured = ByteCodec.hexToBytes(
            "0C0000000080C7430000000052B80E408FC275410000000000000000D441833FA53FFEBF44CE763FA53FFEBFEB517D3F"
        )
        val band = EqBandCodec.decode(captured)
        add(ok("EQ48 decode type/f/q", band.type == 12 && abs(band.frequency - 399f) < 0.001f && abs(band.q - 2.23f) < 0.001f,
            "type=${band.type} f=${band.frequency} q=${band.q} boost=${band.boostDb}"))

        val calc = EqBandCodec.peaking(399.0, 2.23, 15.36)
        val coeffPass = abs(calc.b0 - band.b0) < 0.00001f &&
            abs(calc.b1 - band.b1) < 0.00001f &&
            abs(calc.b2 - band.b2) < 0.00001f &&
            abs(calc.a2 - band.a2) < 0.00001f
        add(ok("RBJ PEAKING @44.1kHz", coeffPass,
            "B0=${calc.b0} B1=${calc.b1} B2=${calc.b2} A2=${calc.a2}"))

        val eqWrite = UfeCodec.encodeWrite(4, 288, captured)
        add(ok("EQ CH1 Band7 header", eqWrite.size == 57 && eqWrite.copyOfRange(0, 9).toHex() == "570000000401200030",
            eqWrite.copyOfRange(0, 9).toHex()))

        val authChecks = AuthVectorLab.pairedVectors.map { AuthVectorLab.check(it) }
        add(ok("AUTH 32B fields / 4 paired vectors", authChecks.all {
            it.typeId == 53284 && it.versionId == 58252 && it.fixed8Hex == AuthVectorLab.FIXED_8_15_HEX
        }, "paired=${authChecks.size}"))
        add(ok("AUTH C0 xor RandKey[0] invariant", authChecks.map { it.firstXor }.distinct() == listOf(0x5C),
            authChecks.joinToString { "%02X".format(it.firstXor) }))
        add(ok("AUTH RandKey drives verified post-auth CFB8", authChecks.all { it.requestCipherMatches },
            "${authChecks.size}/${authChecks.size} device-description request vectors"))
    }
}
