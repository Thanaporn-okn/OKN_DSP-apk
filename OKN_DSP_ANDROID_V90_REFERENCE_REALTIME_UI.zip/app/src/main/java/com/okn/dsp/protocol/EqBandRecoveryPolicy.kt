package com.okn.dsp.protocol

import kotlin.math.abs

/**
 * V48 recovery-only policy for the single CH1 / actuator ID4 / Band4 record
 * left at -0.5 dB by the V46 controlled proof. The original 48-byte record
 * is taken verbatim from the V46 pre-write baseline / restore packet.
 */
object EqBandRecoveryPolicy {
    const val ACTUATOR_ID = 4
    const val BAND_INDEX_1 = 4
    const val OFFSET = (BAND_INDEX_1 - 1) * EqBandCodec.BYTES
    const val FIELD_TOL = 0.0025f

    private const val ORIGINAL_HEX =
        "0C0000000000C8420000000052B80E400000000000000000000000000000803FAE28FFBF9A5E7E3FAE28FFBF9A5E7E3F"
    private const val V46_TARGET_HEX =
        "0C0000000000C8420000000052B80E40000000BF0000000000000000FDF37F3F9D22FFBF805E7E3F9D22FFBF7D527E3F"

    val original: EqBand48 by lazy { EqBandCodec.decode(ByteCodec.hexToBytes(ORIGINAL_HEX)) }
    val v46Target: EqBand48 by lazy { EqBandCodec.decode(ByteCodec.hexToBytes(V46_TARGET_HEX)) }

    fun originalBytes(): ByteArray = ByteCodec.hexToBytes(ORIGINAL_HEX)
    fun encodeRecoveryWrite(): ByteArray = UfeCodec.encodeWrite(ACTUATOR_ID, OFFSET, originalBytes())

    fun matches(actual: EqBand48, expected: EqBand48): Boolean =
        actual.type == expected.type &&
            abs(actual.frequency - expected.frequency) <= FIELD_TOL &&
            abs(actual.frequency2 - expected.frequency2) <= FIELD_TOL &&
            abs(actual.q - expected.q) <= FIELD_TOL &&
            abs(actual.boostDb - expected.boostDb) <= FIELD_TOL &&
            abs(actual.gain - expected.gain) <= FIELD_TOL &&
            abs(actual.r - expected.r) <= FIELD_TOL &&
            abs(actual.b0 - expected.b0) <= FIELD_TOL &&
            abs(actual.b1 - expected.b1) <= FIELD_TOL &&
            abs(actual.b2 - expected.b2) <= FIELD_TOL &&
            abs(actual.a1 - expected.a1) <= FIELD_TOL &&
            abs(actual.a2 - expected.a2) <= FIELD_TOL

    fun classify(actual: EqBand48): String = when {
        matches(actual, original) -> "ORIGINAL_0DB"
        matches(actual, v46Target) -> "V46_TARGET_MINUS0P5DB"
        else -> "UNEXPECTED"
    }
}
