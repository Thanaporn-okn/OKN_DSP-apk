package com.okn.dsp

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.ContentValues
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.widget.*
import androidx.core.app.ActivityCompat
import com.okn.dsp.protocol.*
import com.okn.dsp.transport.BleProfile
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * V50: guarded runtime proof for the remaining six EQ actuator IDs.
 * CH1/ID4/Band4 was already proven by V49. V50 preflights CH2..CH7 from one
 * live Device Description, then probes one channel at a time:
 * semantic baseline -> -0.25 dB target -> descriptor verify -> baseline restore
 * -> descriptor verify -> next channel. Any failure stops the sequence.
 * SaveParams ID7 is never sent.
 */
class EqProofActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private val ts = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    private val startupProbe16 = ByteCodec.hexToBytes("631C062443FD3844558001F3EDA0CCF8")

    private lateinit var status: TextView
    private lateinit var logView: TextView
    private lateinit var deviceList: LinearLayout
    private lateinit var startSessionButton: Button
    private lateinit var runProofButton: Button
    private lateinit var baselineView: TextView

    private var scanner: android.bluetooth.le.BluetoothLeScanner? = null
    private val found = LinkedHashMap<String, BluetoothDevice>()
    private var gatt: BluetoothGatt? = null
    private var ab01: BluetoothGattCharacteristic? = null
    private var ab02: BluetoothGattCharacteristic? = null
    private var connectedName: String? = null

    private var waitingAuth = false
    private var sessionReady = false
    private var txCipher: SessionTxCipher? = null
    private var rxCipher: SessionRxCipher? = null

    private enum class DescMode { INITIAL, VERIFY_TARGET, VERIFY_RESTORE }
    private var descMode: DescMode? = null
    private var descExpected = -1
    private val descBytes = ByteArrayOutputStream()

    private val baselines = linkedMapOf<Int, EqBand48>()
    private var proofRunning = false
    private var probeIndex = -1
    private var targetWritten = false
    private var targetVerified = false
    private var restoreAttempt = 0
    private var proofTimeout: Runnable? = null
    private var stopAfterRestore = false

    private val targetVerifyDelayMs = 3000L
    private val preRestoreSettleMs = 3000L
    private val restoreVerifyDelayMs = 3000L
    private val restoreRetryDelayMs = 2500L
    private val betweenChannelsDelayMs = 1500L

    private val captureLines = mutableListOf<String>()
    private var packetNo = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestBlePermissions()
        record("META", "V50_EQ_MAP_ACTIVITY_START")
        record("META", "V50_CH1_RUNTIME_EVIDENCE_FROM_V49 actuator=4 band=4 targetVerified=true restored=true")
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (proofRunning) {
            Toast.makeText(this, "V50 กำลังทดสอบ/คืนค่า กรุณารอจนจบก่อน", Toast.LENGTH_LONG).show()
            return
        }
        super.onBackPressed()
    }

    override fun onDestroy() {
        cancelGlobalFailsafe()
        try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
        try { gatt?.close() } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 22, 22, 28)
        }
        root.addView(TextView(this).apply {
            text = "OKN DSP V50 — 7CH EQ ACTUATOR MAP PROOF"
            textSize = 22f
        })
        status = TextView(this).apply {
            text = "DISCONNECTED • SaveParams/normal EQ writes LOCKED"
            textSize = 14f
            setPadding(0, 8, 0, 10)
        }
        root.addView(status)
        root.addView(TextView(this).apply {
            text = "CH1 / ID4 was fully proven by V49. V50 verifies the remaining channel actuator map one at a time: CH2 ID5 Band4, CH3 ID6 Band5, CH4 ID14 Band4, CH5 ID15 Band4, CH6 ID16 Band5, CH7 ID17 Band4. Each channel must start as a guarded 0 dB peaking band. V50 writes only -0.25 dB, verifies, restores the live baseline, verifies, then advances. SaveParams ID7 is never sent."
            textSize = 13f
        })

        root.addView(Button(this).apply {
            text = "SCAN DSP"
            setOnClickListener { startScan() }
        })
        deviceList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(deviceList)

        startSessionButton = Button(this).apply {
            text = "START V50 7CH MAP SESSION"
            isEnabled = false
            setOnClickListener { confirmStartSession() }
        }
        root.addView(startSessionButton)

        baselineView = TextView(this).apply {
            text = "7CH preflight: not loaded"
            textSize = 14f
            setPadding(0, 10, 0, 10)
        }
        root.addView(baselineView)

        runProofButton = Button(this).apply {
            text = "RUN CH2→CH7 ACTUATOR MAP PROOF (-0.25 dB → RESTORE EACH)"
            isEnabled = false
            setOnClickListener { confirmRunProof() }
        }
        root.addView(runProofButton)

        root.addView(Button(this).apply {
            text = "SAVE V50 CAPTURE TO DOWNLOADS"
            setOnClickListener { saveCapture() }
        })

        logView = TextView(this).apply { textSize = 11f; setPadding(0, 12, 0, 0) }
        root.addView(logView)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun confirmStartSession() {
        if (gatt == null || ab01 == null || ab02 == null) {
            Toast.makeText(this, "เชื่อม AB00/AB01/AB02 ก่อน", Toast.LENGTH_LONG).show(); return
        }
        AlertDialog.Builder(this)
            .setTitle("Start V50 7CH map session")
            .setMessage("AUTH16 → derive RandKey → อ่าน Device Description สด → preflight CH2..CH7\n\nขั้นนี้ยังไม่เขียน EQ")
            .setNegativeButton("ยกเลิก", null)
            .setPositiveButton("START READ-ONLY 7CH PREFLIGHT") { _, _ -> startSession() }
            .show()
    }

    private fun startSession() {
        val g = gatt ?: return
        val w = ab01 ?: return
        waitingAuth = true
        sessionReady = false
        txCipher = null
        rxCipher = null
        descMode = null
        descExpected = -1
        descBytes.reset()
        baselines.clear()
        proofRunning = false
        probeIndex = -1
        targetWritten = false
        targetVerified = false
        restoreAttempt = 0
        stopAfterRestore = false
        runProofButton.isEnabled = false
        baselineView.text = "7CH preflight: loading..."
        record("META", "V50_EQ_MAP_SESSION_START")
        if (!writeNoResponse(g, w, startupProbe16, "TX_AUTH16_V50")) {
            waitingAuth = false
            status.text = "AUTH16 queue failed"
        } else status.text = "AUTH16 sent • waiting 32B auth response"
    }

    private fun confirmRunProof() {
        if (!sessionReady) return
        AlertDialog.Builder(this)
            .setTitle("V50 CH2→CH7 actuator map proof")
            .setMessage("ทดสอบทีละช่องเท่านั้น: -0.25 dB → verify → restore live baseline → verify. ถ้าช่องใดไม่ผ่าน V50 จะหยุดทันที. SaveParams ID7 จะไม่ถูกส่ง")
            .setNegativeButton("ยกเลิก", null)
            .setPositiveButton("RUN 6 CHANNEL PROOF") { _, _ -> runAllRemainingChannels() }
            .show()
    }

    private fun runAllRemainingChannels() {
        if (!sessionReady || proofRunning || descMode != null) {
            Toast.makeText(this, "Session ไม่พร้อมหรือ proof กำลังทำงาน", Toast.LENGTH_LONG).show(); return
        }
        if (!WriteGate.sevenChannelEqMapProofEnabled) {
            Toast.makeText(this, "V50 7CH map proof gate disabled", Toast.LENGTH_LONG).show(); return
        }
        if (SevenChannelEqMapPolicy.probes.any { baselines[it.channel] == null || !SevenChannelEqMapPolicy.preflight(it, baselines[it.channel]!!) }) {
            Toast.makeText(this, "Preflight เปลี่ยน/ไม่พร้อม กรุณาเริ่ม session ใหม่", Toast.LENGTH_LONG).show(); return
        }
        proofRunning = true
        probeIndex = 0
        targetWritten = false
        targetVerified = false
        restoreAttempt = 0
        stopAfterRestore = false
        runProofButton.isEnabled = false
        armGlobalFailsafe()
        record("META", "V50_MULTI_CHANNEL_PROOF_START remainingChannels=6 targetBoost=${SevenChannelEqMapPolicy.TARGET_BOOST_DB} saveParams=false")
        startCurrentProbe()
    }

    private fun currentProbe(): EqChannelProbe? = SevenChannelEqMapPolicy.probes.getOrNull(probeIndex)

    private fun startCurrentProbe() {
        val probe = currentProbe() ?: run { completeAllChannels(); return }
        val baseline = baselines[probe.channel] ?: run { finishFailed("missing-baseline-${probe.channel}"); return }
        targetWritten = false
        targetVerified = false
        restoreAttempt = 0
        stopAfterRestore = false
        record("META", "V50_CHANNEL_PROOF_START channel=${probe.channel} actuator=${probe.actuatorId} band=${probe.bandIndex1} offset=${probe.offset} baselineBoost=${baseline.boostDb}")
        runOnUiThread { status.text = "V50 testing CH${probe.channel} / ID${probe.actuatorId} • target -0.25 dB" }
        writeTarget(probe, baseline)
    }

    private fun writeTarget(probe: EqChannelProbe, baseline: EqBand48) {
        val g = gatt ?: run { finishFailed("missing-gatt") ; return }
        val w = ab01 ?: run { finishFailed("missing-ab01") ; return }
        val tx = txCipher ?: run { finishFailed("missing-tx") ; return }
        if (descMode != null) {
            handler.postDelayed({ writeTarget(probe, baseline) }, 400L)
            return
        }
        val plain = SevenChannelEqMapPolicy.encodeTargetWrite(probe, baseline)
        val enc = tx.encryptNext(plain)
        record("META", "V50_EQ_TARGET_WRITE_PLAIN=${ByteCodec.run { plain.toHex() }} channel=${probe.channel} actuator=${probe.actuatorId} band=${probe.bandIndex1} offset=${probe.offset} originalBoost=${baseline.boostDb} targetBoost=${SevenChannelEqMapPolicy.TARGET_BOOST_DB} saveParams=false")
        if (!writeNoResponse(g, w, enc, "TX_EQ_CH${probe.channel}_ID${probe.actuatorId}_TARGET_V50")) {
            finishFailed("target-write-queue-failed-ch${probe.channel}"); return
        }
        targetWritten = true
        record("META", "V50_TARGET_VERIFY_DELAY_MS=$targetVerifyDelayMs channel=${probe.channel}")
        handler.postDelayed({ requestDescriptor(DescMode.VERIFY_TARGET) }, targetVerifyDelayMs)
    }

    private fun writeRestore(reason: String) {
        val probe = currentProbe() ?: return
        val baseline = baselines[probe.channel] ?: run { finishFailed("missing-restore-baseline-ch${probe.channel}"); return }
        val g = gatt ?: run { finishFailed("missing-gatt") ; return }
        val w = ab01 ?: run { finishFailed("missing-ab01") ; return }
        val tx = txCipher ?: run { finishFailed("missing-tx") ; return }
        if (descMode != null) {
            handler.postDelayed({ writeRestore(reason) }, 400L)
            return
        }
        restoreAttempt += 1
        val plain = SevenChannelEqMapPolicy.encodeRestoreWrite(probe, baseline)
        val enc = tx.encryptNext(plain)
        record("META", "V50_EQ_RESTORE_WRITE_PLAIN=${ByteCodec.run { plain.toHex() }} attempt=$restoreAttempt channel=${probe.channel} actuator=${probe.actuatorId} band=${probe.bandIndex1} offset=${probe.offset} baselineBoost=${baseline.boostDb} reason=$reason saveParams=false")
        if (!writeNoResponse(g, w, enc, "TX_EQ_CH${probe.channel}_ID${probe.actuatorId}_RESTORE_V50_A$restoreAttempt")) {
            finishFailed("restore-write-queue-failed-ch${probe.channel}"); return
        }
        record("META", "V50_RESTORE_VERIFY_DELAY_MS=$restoreVerifyDelayMs channel=${probe.channel} attempt=$restoreAttempt")
        handler.postDelayed({ requestDescriptor(DescMode.VERIFY_RESTORE) }, restoreVerifyDelayMs)
    }

    private fun requestDescriptor(mode: DescMode) {
        val g = gatt ?: return
        val w = ab01 ?: return
        val tx = txCipher ?: return
        descMode = mode
        descExpected = -1
        descBytes.reset()
        val plain = SessionCryptoFacts.DEVICE_DESCRIPTION_REQUEST
        val enc = tx.encryptNext(plain)
        record("META", "V50_DESC_REQUEST mode=$mode plain=${ByteCodec.run { plain.toHex() }} channel=${currentProbe()?.channel ?: 0}")
        if (!writeNoResponse(g, w, enc, "TX_DESC_V50_${mode.name}")) {
            descMode = null
            if (targetWritten) writeRestore("descriptor-request-failed-$mode") else finishFailed("descriptor-request-failed-$mode")
        }
    }

    private fun handleAb02(value: ByteArray) {
        record("RX_NOTIFY", "len=${value.size} hex=${ByteCodec.run { value.toHex() }}")
        if (waitingAuth) {
            if (value.size != 32) return
            try {
                val d = PreAuthRandKeyDecoder.decode(value)
                txCipher = SessionTxCipher(d.randKey)
                rxCipher = SessionRxCipher(d.randKey)
                waitingAuth = false
                record("META", "V50_RANDKEY_DERIVED type=${d.typeId} ver=${d.versionId} rand=${ByteCodec.run { d.randKey.toHex() }}")
                runOnUiThread { status.text = "AUTH OK • reading live 7CH Device Description" }
                requestDescriptor(DescMode.INITIAL)
            } catch (e: Exception) {
                waitingAuth = false
                record("META", "V50_AUTH_DECODE_ERROR ${e.javaClass.simpleName}:${e.message}")
                runOnUiThread { status.text = "Auth decode failed" }
            }
            return
        }

        val rx = rxCipher ?: return
        val plain = try { rx.decryptNext(value) } catch (e: Exception) {
            record("META", "V50_RX_DECRYPT_ERROR ${e.javaClass.simpleName}:${e.message}")
            sessionReady = false
            return
        }
        record("RX_PLAIN", "len=${plain.size} hex=${ByteCodec.run { plain.toHex() }}")
        if (descMode != null) collectDescriptor(plain)
    }

    private fun collectDescriptor(plain: ByteArray) {
        val mode = descMode ?: return
        if (descExpected < 0) {
            if (plain.size < 4 || (plain[0].toInt() and 0xff) != 0x86) {
                record("META", "V50_DESC_NONHEADER mode=$mode marker=${plain.firstOrNull()?.toInt()?.and(0xff)} len=${plain.size}")
                return
            }
            descExpected = (plain[1].toInt() and 0xff) or ((plain[2].toInt() and 0xff) shl 8) or ((plain[3].toInt() and 0xff) shl 16)
            descBytes.reset()
            descBytes.write(plain, 4, plain.size - 4)
            record("META", "V50_DESC_HEADER mode=$mode jsonLen=$descExpected")
        } else {
            if (plain.isEmpty() || (plain[0].toInt() and 0xff) != 0x82) {
                record("META", "V50_DESC_NONCONT mode=$mode marker=${plain.firstOrNull()?.toInt()?.and(0xff)} len=${plain.size}")
                return
            }
            descBytes.write(plain, 1, plain.size - 1)
        }
        if (descExpected > 0 && descBytes.size() >= descExpected) {
            val bytes = descBytes.toByteArray().copyOf(descExpected)
            val obj = JSONObject(bytes.toString(Charsets.UTF_8))
            record("META", "V50_DESC_COMPLETE mode=$mode bytes=${bytes.size}")
            descMode = null
            descExpected = -1
            descBytes.reset()
            onDescriptorComplete(mode, obj)
        }
    }

    private fun onDescriptorComplete(mode: DescMode, obj: JSONObject) {
        when (mode) {
            DescMode.INITIAL -> handleInitialDescriptor(obj)
            DescMode.VERIFY_TARGET -> handleTargetVerify(obj)
            DescMode.VERIFY_RESTORE -> handleRestoreVerify(obj)
        }
    }

    private fun handleInitialDescriptor(obj: JSONObject) {
        baselines.clear()
        val lines = mutableListOf("CH1 / ID4 / Band4: VERIFIED by V49 runtime proof")
        var allOk = true
        SevenChannelEqMapPolicy.probes.forEach { probe ->
            val band = extractBand(obj, probe.actuatorId, probe.bandIndex1)
            if (band == null) {
                allOk = false
                lines += "CH${probe.channel}: MISSING"
                record("META", "V50_PREFLIGHT channel=${probe.channel} actuator=${probe.actuatorId} band=${probe.bandIndex1} ok=false reason=missing")
            } else {
                val ok = SevenChannelEqMapPolicy.preflight(probe, band)
                if (ok) baselines[probe.channel] = band else allOk = false
                lines += "CH${probe.channel} / ID${probe.actuatorId} / Band${probe.bandIndex1}: F=${fmt(band.frequency)} Q=${fmt(band.q)} B=${fmt(band.boostDb)} R=${fmt(band.r)} • ${if (ok) "READY" else "BLOCKED"}"
                record("META", "V50_PREFLIGHT channel=${probe.channel} actuator=${probe.actuatorId} band=${probe.bandIndex1} offset=${probe.offset} frequency=${band.frequency} q=${band.q} boost=${band.boostDb} r=${band.r} ok=$ok")
            }
        }
        if (allOk && baselines.size == SevenChannelEqMapPolicy.probes.size) {
            sessionReady = true
            record("META", "V50_ALL_REMAINING_CHANNELS_PREFLIGHT_READY count=${baselines.size}")
            runOnUiThread {
                baselineView.text = lines.joinToString("\n")
                status.text = "V50 READY • CH2..CH7 preflight passed • CH1 already proven by V49"
                runProofButton.isEnabled = true
            }
        } else {
            sessionReady = false
            record("META", "V50_PREFLIGHT_BLOCKED ready=${baselines.size} expected=${SevenChannelEqMapPolicy.probes.size}")
            runOnUiThread {
                baselineView.text = lines.joinToString("\n")
                status.text = "V50 BLOCKED • one or more channel baselines are unexpected"
                runProofButton.isEnabled = false
            }
        }
    }

    private fun handleTargetVerify(obj: JSONObject) {
        val probe = currentProbe() ?: run { finishFailed("probe-missing-target-verify"); return }
        val baseline = baselines[probe.channel] ?: run { finishFailed("baseline-missing-target-verify"); return }
        val expected = SevenChannelEqMapPolicy.targetFromBaseline(baseline)
        val actual = extractBand(obj, probe.actuatorId, probe.bandIndex1)
        val ok = actual != null && SevenChannelEqMapPolicy.semanticMatches(actual, expected)
        targetVerified = ok
        record("META", "V50_TARGET_DESCRIPTOR_VERIFY channel=${probe.channel} actuator=${probe.actuatorId} band=${probe.bandIndex1} expectedBoost=${expected.boostDb} actualBoost=${actual?.boostDb ?: Float.NaN} verified=$ok")
        if (ok) {
            record("META", "V50_PRE_RESTORE_SETTLE_MS=$preRestoreSettleMs channel=${probe.channel}")
            handler.postDelayed({ writeRestore("target-verified") }, preRestoreSettleMs)
        } else {
            stopAfterRestore = true
            record("META", "V50_TARGET_VERIFY_FAILED channel=${probe.channel} restoreRequired=true")
            handler.postDelayed({ writeRestore("target-verify-failed") }, 500L)
        }
    }

    private fun handleRestoreVerify(obj: JSONObject) {
        val probe = currentProbe() ?: run { finishFailed("probe-missing-restore-verify"); return }
        val baseline = baselines[probe.channel] ?: run { finishFailed("baseline-missing-restore-verify"); return }
        val actual = extractBand(obj, probe.actuatorId, probe.bandIndex1)
        val ok = actual != null && SevenChannelEqMapPolicy.semanticMatches(actual, baseline)
        record("META", "V50_RESTORE_DESCRIPTOR_VERIFY channel=${probe.channel} actuator=${probe.actuatorId} band=${probe.bandIndex1} attempt=$restoreAttempt expectedBoost=${baseline.boostDb} actualBoost=${actual?.boostDb ?: Float.NaN} verified=$ok")
        if (ok) {
            targetWritten = false
            record("META", "V50_CHANNEL_PROOF_COMPLETE channel=${probe.channel} actuator=${probe.actuatorId} band=${probe.bandIndex1} targetVerified=$targetVerified restored=true restoreAttempts=$restoreAttempt saveParamsSent=false")
            if (!targetVerified || stopAfterRestore) {
                finishStopped("target-verify-failed-ch${probe.channel}-but-restored")
                return
            }
            probeIndex += 1
            if (probeIndex >= SevenChannelEqMapPolicy.probes.size) {
                completeAllChannels()
            } else {
                val next = currentProbe()!!
                runOnUiThread { status.text = "CH${probe.channel} verified+restored • next CH${next.channel}" }
                handler.postDelayed({ startCurrentProbe() }, betweenChannelsDelayMs)
            }
        } else if (restoreAttempt < 2) {
            record("META", "V50_RESTORE_RETRY_SCHEDULED channel=${probe.channel} nextAttempt=${restoreAttempt + 1} delayMs=$restoreRetryDelayMs")
            handler.postDelayed({ writeRestore("restore-verify-retry") }, restoreRetryDelayMs)
        } else {
            finishStopped("restore-verify-failed-ch${probe.channel}")
        }
    }

    private fun completeAllChannels() {
        proofRunning = false
        sessionReady = false
        targetWritten = false
        cancelGlobalFailsafe()
        record("META", "V50_ALL_7CH_ACTUATOR_MAP_COMPLETE ch1FromV49=true ch2Id5=true ch3Id6=true ch4Id14=true ch5Id15=true ch6Id16=true ch7Id17=true saveParamsSent=false")
        runOnUiThread {
            status.text = "V50 COMPLETE • 7CH EQ actuator map runtime verified • all tested bands restored • SaveParams NOT sent"
            runProofButton.isEnabled = false
        }
    }

    private fun finishFailed(reason: String) {
        record("META", "V50_PROOF_FAILED reason=$reason targetWritten=$targetWritten channel=${currentProbe()?.channel ?: 0}")
        if (targetWritten && descMode == null && restoreAttempt < 2) {
            stopAfterRestore = true
            writeRestore("finish-failed-$reason")
            return
        }
        finishStopped(reason)
    }

    private fun finishStopped(reason: String) {
        proofRunning = false
        sessionReady = false
        cancelGlobalFailsafe()
        record("META", "V50_SEQUENCE_STOPPED reason=$reason channel=${currentProbe()?.channel ?: 0} saveParamsSent=false")
        runOnUiThread {
            status.text = "V50 STOPPED: $reason • save capture • do not retry"
            runProofButton.isEnabled = false
        }
    }

    private fun armGlobalFailsafe() {
        cancelGlobalFailsafe()
        proofTimeout = Runnable {
            if (proofRunning && targetWritten) {
                val ch = currentProbe()?.channel ?: 0
                record("META", "V50_FAILSAFE_RESTORE_TRIGGERED channel=$ch mode=$descMode restoreAttempt=$restoreAttempt")
                stopAfterRestore = true
                if (descMode == null && restoreAttempt < 2) writeRestore("global-failsafe-timeout")
            }
        }.also { handler.postDelayed(it, 180000L) }
        record("META", "V50_FAILSAFE_WINDOW_MS=180000")
    }

    private fun cancelGlobalFailsafe() {
        proofTimeout?.let { handler.removeCallbacks(it) }
        proofTimeout = null
    }

    private fun extractBand(obj: JSONObject, actuatorId: Int, bandIndex1: Int): EqBand48? {
        val arr = obj.optJSONArray("actuators") ?: return null
        for (i in 0 until arr.length()) {
            val a = arr.optJSONObject(i) ?: continue
            if (a.optInt("ID", -1) != actuatorId || a.optInt("type", -1) != 4084) continue
            val bands = a.optJSONArray("UFE_TYPE_BIQUAD_CASCADE15_F") ?: return null
            val b = bands.optJSONObject(bandIndex1 - 1) ?: return null
            fun f(key: String): Float = b.optDouble(key, Double.NaN).toFloat()
            val out = EqBand48(
                type = b.optInt("typ", -1),
                frequency = f("F"), frequency2 = f("F2"), q = f("Q"), boostDb = f("B"),
                gain = f("G"), r = f("R"), b0 = f("B0"), b1 = f("B1"), b2 = f("B2"),
                a1 = f("A1"), a2 = f("A2"),
            )
            if (listOf(out.frequency, out.frequency2, out.q, out.boostDb, out.gain, out.r, out.b0, out.b1, out.b2, out.a1, out.a2).any { !it.isFinite() }) return null
            return out
        }
        return null
    }

    private fun startScan() {
        if (!hasBlePermission()) { requestBlePermissions(); return }
        val adapter = getSystemService(BluetoothManager::class.java)?.adapter ?: return
        if (!adapter.isEnabled) { Toast.makeText(this, "เปิด Bluetooth ก่อน", Toast.LENGTH_SHORT).show(); return }
        found.clear(); deviceList.removeAllViews()
        scanner = adapter.bluetoothLeScanner
        status.text = "SCANNING"
        try { scanner?.startScan(scanCallback) } catch (_: SecurityException) { return }
        handler.postDelayed({ try { scanner?.stopScan(scanCallback) } catch (_: Exception) {} }, 10000L)
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val d = result.device
            val name = result.scanRecord?.deviceName ?: try { d.name } catch (_: SecurityException) { null }
            if (name?.contains("GOLOPINE", true) != true && name?.contains("DSP", true) != true) return
            if (found.putIfAbsent(d.address, d) != null) return
            runOnUiThread {
                deviceList.addView(Button(this@EqProofActivity).apply {
                    text = "${name ?: "DSP"} • ${d.address}\nแตะเพื่อเชื่อมต่อ"
                    setOnClickListener { connect(d, name ?: "DSP") }
                })
            }
        }
    }

    private fun connect(device: BluetoothDevice, name: String) {
        if (!hasBlePermission()) return
        try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
        try { gatt?.close() } catch (_: Exception) {}
        connectedName = name
        status.text = "CONNECTING $name"
        record("META", "V50_CONNECT_START name=$name address=${device.address}")
        try { gatt = device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE) }
        catch (_: SecurityException) { status.text = "CONNECT permission error" }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, statusCode: Int, newState: Int) {
            record("META", "GATT_STATE status=$statusCode newState=$newState")
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                runOnUiThread { status.text = "CONNECTED ${connectedName ?: "DSP"} • discovering" }
                try {
                    g.requestMtu(517)
                    handler.postDelayed({ try { g.discoverServices() } catch (_: SecurityException) {} }, 250L)
                } catch (_: SecurityException) {}
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                sessionReady = false; waitingAuth = false; txCipher = null; rxCipher = null
                proofRunning = false; targetWritten = false; cancelGlobalFailsafe()
                runOnUiThread { status.text = "DISCONNECTED"; startSessionButton.isEnabled = false; runProofButton.isEnabled = false }
            }
        }

        override fun onMtuChanged(g: BluetoothGatt, mtu: Int, statusCode: Int) { record("META", "MTU_CHANGED mtu=$mtu status=$statusCode") }

        override fun onServicesDiscovered(g: BluetoothGatt, statusCode: Int) {
            val service = g.getService(BleProfile.AB00_SERVICE)
            ab01 = service?.getCharacteristic(BleProfile.AB01_WRITE)
            ab02 = service?.getCharacteristic(BleProfile.AB02_NOTIFY)
            val ok = statusCode == BluetoothGatt.GATT_SUCCESS && ab01 != null && ab02 != null
            record("META", "SERVICES_DISCOVERED status=$statusCode AB01=${ab01 != null} AB02=${ab02 != null}")
            if (!ok) { runOnUiThread { status.text = "AB00/AB01/AB02 profile not found" }; return }
            subscribeAb02(g, ab02!!)
            runOnUiThread { status.text = "CONNECTED • enabling AB02 notifications"; startSessionButton.isEnabled = false }
        }

        override fun onDescriptorWrite(g: BluetoothGatt, descriptor: BluetoothGattDescriptor, statusCode: Int) {
            record("META", "CCCD_WRITE status=$statusCode")
            runOnUiThread {
                if (statusCode == BluetoothGatt.GATT_SUCCESS) {
                    status.text = "CONNECTED • AB02 notifications READY"
                    startSessionButton.isEnabled = true
                } else {
                    status.text = "CCCD notification enable failed: $statusCode"
                    startSessionButton.isEnabled = false
                }
            }
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, statusCode: Int) {
            record("META", "TX_WRITE_RESULT status=$statusCode uuid=${characteristic.uuid}")
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            if (characteristic.uuid == BleProfile.AB02_NOTIFY) handleAb02(value)
        }

        @Suppress("DEPRECATION")
        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            if (android.os.Build.VERSION.SDK_INT < 33 && characteristic.uuid == BleProfile.AB02_NOTIFY) handleAb02(characteristic.value ?: byteArrayOf())
        }
    }

    private fun subscribeAb02(g: BluetoothGatt, ch: BluetoothGattCharacteristic) {
        if (!hasBlePermission()) return
        try {
            g.setCharacteristicNotification(ch, true)
            val cccd = ch.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")) ?: return
            val v = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            if (android.os.Build.VERSION.SDK_INT >= 33) g.writeDescriptor(cccd, v)
            else {
                @Suppress("DEPRECATION") cccd.value = v
                @Suppress("DEPRECATION") g.writeDescriptor(cccd)
            }
        } catch (e: Exception) { record("META", "SUBSCRIBE_ERROR ${e.javaClass.simpleName}:${e.message}") }
    }

    private fun writeNoResponse(g: BluetoothGatt, ch: BluetoothGattCharacteristic, bytes: ByteArray, label: String): Boolean {
        if (!hasBlePermission()) return false
        record("TX", "$label len=${bytes.size} hex=${ByteCodec.run { bytes.toHex() }}")
        return try {
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                g.writeCharacteristic(ch, bytes, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE) == BluetoothStatusCodes.SUCCESS
            } else {
                @Suppress("DEPRECATION") ch.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                @Suppress("DEPRECATION") ch.value = bytes
                @Suppress("DEPRECATION") g.writeCharacteristic(ch)
            }
        } catch (e: Exception) {
            record("META", "$label ERROR ${e.javaClass.simpleName}:${e.message}")
            false
        }
    }

    private fun record(kind: String, text: String) {
        val line = "${ts.format(Date())}\t#${++packetNo}\t$kind\t$text"
        synchronized(captureLines) { captureLines.add(line) }
        runOnUiThread { logView.text = (logView.text.toString() + line + "\n").takeLast(16000) }
    }

    private fun saveCapture() {
        val text = buildString {
            append("=== OKN DSP V50 7CH EQ ACTUATOR MAP PROOF CAPTURE ===\n")
            synchronized(captureLines) { captureLines.forEach { append(it).append('\n') } }
        }
        val name = "OKN_DSP_V50_CAPTURE_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.txt"
        try {
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: error("insert failed")
                contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) }
                Toast.makeText(this, "Saved Downloads/$name", Toast.LENGTH_LONG).show()
            } else {
                val f = java.io.File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), name)
                f.writeText(text)
                Toast.makeText(this, "Saved ${f.absolutePath}", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) { Toast.makeText(this, "Save failed: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun requestBlePermissions() {
        val perms = if (android.os.Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (perms.any { ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }) {
            ActivityCompat.requestPermissions(this, perms, 1001)
        }
    }

    private fun hasBlePermission(): Boolean = if (android.os.Build.VERSION.SDK_INT >= 31) {
        ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
    } else ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun fmt(v: Float): String = String.format(Locale.US, "%.3f", v)
}
