package com.okn.dsp.protocol

/**
 * Read-only proof extracted from the official GoloPine session captured at 20:45:55.
 * No live write path is enabled here.
 */
object DeviceDescriptionProof {
    const val SESSION_LABEL = "2026-09-06 20:45:55"
    const val AUTH_REQUEST16 = "631C062443FD3844558001F3EDA0CCF8"
    const val AUTH_RESPONSE32 = "D024E38C00000000420DA6E8FDDF06895D514A274A2181DEB2F457CA70A60EC1"
    const val DEVICE_REQUEST_CIPHER = "5DFCB7E5"
    const val DEVICE_REQUEST_PLAIN = "661C0624"
    const val FIRST_RX_HEADER = "86E64600"
    const val DEVICE_JSON_BYTES = 18150
    const val DEVICE_CIPHER_BYTES = 18231
    const val DEVICE_NOTIFICATIONS = 78
    const val ACTUATOR_COUNT = 15
    const val SENSOR_COUNT = 4
    const val READBACK_PAIRS = 83

    val actuatorMap = listOf(
        "ID 7 • SaveParams • type 2100",
        "ID 2 • MasterVolume • FLOAT32",
        "ID 3 • RemindSoundVolume • FLOAT32",
        "ID 8 • BassVolume • FLOAT32",
        "ID 9 • BassCutoff • FLOAT32",
        "ID 10 • BassBoost • FLOAT32",
        "ID 13 • MiddleBoost • FLOAT32",
        "ID 11 • TrebleBoost • FLOAT32",
        "ID 4 • BiquadCascadeLeftChannel • type 4084 / 15 bands",
        "ID 5 • BiquadCascadeRightChannel • type 4084 / 15 bands",
        "ID 6 • BiquadCascadeBassChannel • type 4084 / 15 bands",
        "ID 14 • BiquadCascade4thChannel • type 4084 / 15 bands",
        "ID 15 • BiquadCascade5thChannel • type 4084 / 15 bands",
        "ID 16 • BiquadCascade6thChannel • type 4084 / 15 bands",
        "ID 17 • BiquadCascade7thChannel • type 4084 / 15 bands",
    )

    fun report(): List<String> = buildList {
        add("Official session: $SESSION_LABEL")
        add("AUTH16=$AUTH_REQUEST16")
        add("AUTH32=$AUTH_RESPONSE32")
        add("AES-CFB8 post-auth: key=RandKey, TX/RX IV=01×16, independent continuous streams")
        add("Device request: $DEVICE_REQUEST_CIPHER -> $DEVICE_REQUEST_PLAIN")
        add("RX first header=$FIRST_RX_HEADER = 0x86 + U24LE length 0x46E6 = $DEVICE_JSON_BYTES")
        add("RX continuation marker=0x82")
        add("Device description: $DEVICE_NOTIFICATIONS notifications / $DEVICE_CIPHER_BYTES cipher bytes -> $DEVICE_JSON_BYTES JSON bytes")
        add("Descriptor parsed: GoloPine_DSP_Amplifier • sensors=$SENSOR_COUNT • actuators=$ACTUATOR_COUNT")
        actuatorMap.forEach { add(it) }
        add("Readback: request 0x58 + ID(BE32)+offset(BE16)+len(BE16)")
        add("Readback: response 0x60 + same header + data • $READBACK_PAIRS captured pairs matched")
        add("Sensor poll IDs verified: 19/20 BOOL, 0/21 FLOAT32 little-endian")
        add("LIVE WRITE LOCKED: only standalone pre-auth RandKey extraction remains unverified")
    }
}
