package com.okn.dsp.protocol

/**
 * V29 verified UFE application serializer from controlled HCI + official-app logs.
 * Header integer fields are big-endian. Scalar actuator float payloads are little-endian.
 */
data class UfePacket(
    val command: Int,
    val actuatorId: Int,
    val memoryOffset: Int,
    val memoryLength: Int,
    val data: ByteArray = byteArrayOf(),
)

object UfeCodec {
    fun encodeRead(actuatorId: Int, memoryOffset: Int, memoryLength: Int): ByteArray {
        require(actuatorId >= 0)
        require(memoryOffset in 0..0xffff)
        require(memoryLength in 0..0xffff)
        return byteArrayOf(UfeConstants.READ_SENSOR_ACTUATOR_COMMAND.toByte()) +
            ByteCodec.u32be(actuatorId) +
            ByteCodec.u16be(memoryOffset) +
            ByteCodec.u16be(memoryLength)
    }

    fun encodeWrite(actuatorId: Int, memoryOffset: Int, data: ByteArray): ByteArray {
        require(actuatorId >= 0)
        require(memoryOffset in 0..0xffff)
        require(data.size <= 0xffff)
        return byteArrayOf(UfeConstants.WRITE_ACTUATOR_COMMAND.toByte()) +
            ByteCodec.u32be(actuatorId) +
            ByteCodec.u16be(memoryOffset) +
            ByteCodec.u16be(data.size) + data
    }

    fun encodeFloat32Write(actuatorId: Int, value: Float, memoryOffset: Int = 0): ByteArray =
        encodeWrite(actuatorId, memoryOffset, ByteCodec.f32le(value))

    fun decodeRequest(bytes: ByteArray): UfePacket {
        require(bytes.size >= 9) { "UFE request must be at least 9 bytes" }
        val command = bytes[0].toInt() and 0xff
        val id = ByteCodec.readU32be(bytes, 1)
        val offset = ByteCodec.readU16be(bytes, 5)
        val length = ByteCodec.readU16be(bytes, 7)
        val data = if (bytes.size > 9) bytes.copyOfRange(9, bytes.size) else byteArrayOf()
        if (command == UfeConstants.WRITE_ACTUATOR_COMMAND) {
            require(data.size == length) { "WRITE length=$length but data=${data.size}" }
        }
        return UfePacket(command, id, offset, length, data)
    }
}
