package com.okn.dsp.protocol

import com.okn.dsp.protocol.ByteCodec.toHex

/** V40: the pre-auth response32 -> RandKey transform is now independently verified. */
object RandKeyPreAuthLab {
    data class VectorResult(
        val label: String,
        val typeId: Int,
        val versionId: Int,
        val uniqueIdHex: String,
        val derivedRandKeyHex: String,
        val expectedRandKeyHex: String,
        val pass: Boolean,
    )

    val results: List<VectorResult> = AuthVectorLab.pairedVectors.map { v ->
        val decoded = PreAuthRandKeyDecoder.decode(ByteCodec.hexToBytes(v.response32Hex))
        val derived = decoded.randKey.toHex()
        VectorResult(
            label = v.label,
            typeId = decoded.typeId,
            versionId = decoded.versionId,
            uniqueIdHex = decoded.uniqueId.toHex(),
            derivedRandKeyHex = derived,
            expectedRandKeyHex = v.randKeyHex,
            pass = derived == v.randKeyHex,
        )
    }

    val automaticRandKeyVerified: Boolean = results.isNotEmpty() && results.all { it.pass }

    fun report(): List<String> = buildList {
        add("V40 PRE-AUTH RANDKEY DECODER • AOT CALL-SITE RECOVERED")
        add("response32[8..31] -> AES-CFB8 decrypt, IV=01x16 -> uniqueID[8] + RandKey[16]")
        add("default fixed key=2AAF948632A59FF8F2B23E6E4193FD21")
        add("TypeID 53285 alternate key=10E7D2F443924938A28D759BAC0E9E22")
        results.forEach { r ->
            add("${r.label} • Type=${r.typeId} Ver=${r.versionId} UUID=${r.uniqueIdHex}")
            add("${r.label} • derived=${r.derivedRandKeyHex} expected=${r.expectedRandKeyHex} ${if (r.pass) "PASS" else "FAIL"}")
        }
        add("AUTO RANDKEY=${if (automaticRandKeyVerified) "VERIFIED (${results.size}/${results.size})" else "FAILED"}")
        add("LIVE DSP PARAM WRITE 0x57 remains locked in V40. Only auth/device-description/readback traffic is enabled.")
    }
}
