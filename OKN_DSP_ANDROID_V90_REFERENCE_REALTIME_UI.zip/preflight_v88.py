#!/usr/bin/env python3
from pathlib import Path
import hashlib,re
root=Path(__file__).resolve().parent

def req(rel):
    p=root/rel
    assert p.is_file(), f'missing {rel}'
    return p

def txt(rel): return req(rel).read_text(errors='replace')
def has(rel,m): assert m in txt(rel), f'missing {m!r} in {rel}'
def sha(rel,e):
    g=hashlib.sha256(req(rel).read_bytes()).hexdigest()
    assert g==e, f'hash mismatch {rel}: {g}'

def combined_hash(paths):
    h=hashlib.sha256()
    for p in sorted(paths, key=lambda x:x.relative_to(root).as_posix()):
        rel=p.relative_to(root).as_posix()
        h.update(rel.encode()+b'\0'+p.read_bytes()+b'\0')
    return h.hexdigest()

U='app/src/main/java/com/okn/dsp/UnifiedControlActivity.kt'
G='app/build.gradle.kts'
M='app/src/main/java/com/okn/dsp/MainActivity.kt'
WG='app/src/main/java/com/okn/dsp/protocol/WriteGate.kt'
SP='app/src/main/java/com/okn/dsp/protocol/VerifiedScalarControls.kt'
KEY='app/okn_dsp_stable_debug.keystore'
CAP87='evidence/OKN_DSP_V87_IDLE_LIFECYCLE_PROOF_ATTEMPT_CAPTURE.txt'
PLAN='evidence/OKN_DSP_V88_LIFECYCLE_DESTROY_PERSISTENT_OBSERVABILITY_PLAN.txt'
PLANJ='evidence/OKN_DSP_V88_LIFECYCLE_DESTROY_PERSISTENT_OBSERVABILITY_PLAN.json'
for r in [U,G,M,WG,SP,KEY,CAP87,PLAN,PLANJ,'README_V88.txt']:
    req(r)

has(G,'applicationId = "com.okn.dsp"')
has(G,'versionCode = 88')
has(G,'versionName = "5.19.0-v88-lifecycle-destroy-persistent-observability"')
has(M,'V88 lifecycle-destroy persistent observability + READ-ONLY recreate probe launcher')
has(U,'V88 • PRODUCTION SAFE')
has(U,'RUN V88 SESSION HEALTH GATE • READ ONLY')
has(U,'RUN V88 LIFECYCLE RECREATE PROBE • READ ONLY')
has(U,'lifecycleDestroyFailClosed=V87_STATIC_CARRIED lifecycleDestroyObservability=required lifecycleRecreateProbe=readOnly')
has(U,'lifecycleDestroyObservability=V88_PENDING_RUNTIME_PROOF lifecycleRecreateProbe=V88_PENDING_RUNTIME_PROOF')

# V87 real-device attempt is a healthy baseline but did not prove lifecycle destroy.
c87=txt(CAP87)
for m in [
    'V87_SESSION_HEALTH_GATE_RESULT pass=true writesSent=0',
    'scalarCount=7', 'eqBands=105', 'sensors=4', 'protocolIdle=true', 'ramClean=true'
]: assert m in c87, f'V87 baseline evidence missing {m}'
assert 'V87_LIFECYCLE_DESTROY_FAIL_CLOSED' not in c87, 'V87 attempt unexpectedly contains lifecycle destroy proof'

# Stable signing identity carried unchanged.
has(G,'create("stableDebug")')
has(G,'storeFile = file("okn_dsp_stable_debug.keystore")')
has(G,'signingConfig = signingConfigs.getByName("stableDebug")')
sha(KEY,'ba1c52f2607c09953c52fdd79c5f72026aaf0adb8aa44bcba277f7d9b49d9511')

u=txt(U)

# V86 all-status disconnect invariant remains intact in V88.
cb_start=u.index('    private val gattCallback = object')
cb_end=u.index('        override fun onMtuChanged',cb_start)
cb=u[cb_start:cb_end]
a=cb.index('if (newState == BluetoothProfile.STATE_DISCONNECTED)')
b=cb.index('if (statusCode != BluetoothGatt.GATT_SUCCESS)')
assert a < b, (a,b)
for m in [
    'cancelConnectionWatchdog("gatt-disconnected-status-$statusCode")',
    'handler.post { failClosedDisconnectedAllStatus(g, statusCode) }',
    'return',
]: assert m in cb,m

helper_start=u.index('    private fun failClosedDisconnectedAllStatus(callbackGatt: BluetoothGatt, statusCode: Int)')
helper_end=u.index('    private val gattCallback = object',helper_start)
helper=u[helper_start:helper_end]
for m in [
    'V88_ALL_STATUS_DISCONNECT_STALE status=$statusCode',
    'V88_UNIFIED_PERSISTENT_SAVE_UNCONFIRMED reason=disconnect-during-save',
    'V88_UNIFIED_WRITE_STATE_UNCONFIRMED reason=disconnect-during-scalar-pipeline',
    'V88_UNIFIED_EQ_WRITE_STATE_UNCONFIRMED reason=disconnect-during-eq-pipeline',
    'invalidateForConnectionTransition("gatt-disconnected-status-$statusCode")',
    'V88_ALL_STATUS_DISCONNECT_FAIL_CLOSED status=$statusCode',
    'persistCriticalCapture(',
]: assert m in helper,m
x=helper.index('gatt = null')
y=helper.index('invalidateForConnectionTransition("gatt-disconnected-status-$statusCode")')
z=helper.index('callbackGatt.close()')
assert x < y < z, (x,y,z)

# V87 lifecycle fail-closed cleanup/journal is carried and V88 persists every destroy, even idle.
d_start=u.index('    override fun onDestroy() {')
d_end=u.index('    private fun runLifecycleRecreateProbe()',d_start)
d=u[d_start:d_end]
for m in [
    'val purposeAtDestroy = pendingGattPurpose',
    'val hadSavePipeline = saveInFlight || purposeAtDestroy == PendingGattPurpose.SAVE_PARAMS',
    'V88_UNIFIED_PERSISTENT_SAVE_UNCONFIRMED reason=activity-destroy-during-save',
    'V88_UNIFIED_WRITE_STATE_UNCONFIRMED reason=activity-destroy-during-scalar-pipeline',
    'V88_UNIFIED_EQ_WRITE_STATE_UNCONFIRMED reason=activity-destroy-during-eq-pipeline',
    'cancelDescriptorTimeout()',
    'cancelGattActionTimeout()',
    'cancelConnectionWatchdog("activity-destroy")',
    'cancelSaveTimers()',
    'gatt = null',
    'invalidateForConnectionTransition("activity-destroy")',
    'closingGatt?.close()',
    'V88_LIFECYCLE_DESTROY_FAIL_CLOSED',
    'persistLifecycleDestroyCapture(',
    'super.onDestroy()',
]: assert m in d,m
# Critical persistence (if active pipeline) precedes state clearing. Lifecycle persistence is unconditional after final marker.
cond=d.index('if (hadControlPipeline)')
crit=d.index('persistCriticalCapture(',cond)
cancel=d.index('cancelDescriptorTimeout()')
gnull=d.index('gatt = null')
inv=d.index('invalidateForConnectionTransition("activity-destroy")')
close=d.index('closingGatt?.close()')
marker=d.index('V88_LIFECYCLE_DESTROY_FAIL_CLOSED')
lifep=d.index('persistLifecycleDestroyCapture(')
sup=d.index('super.onDestroy()')
assert cond < crit < cancel < gnull < inv < close < marker < lifep < sup, (cond,crit,cancel,gnull,inv,close,marker,lifep,sup)
for forbidden in [
    'connectGatt(', 'startSession()', 'requestDescriptor(', 'UfeCodec.encodeFloat32Write',
    'LiveEqPolicy.encodeWrite', 'LiveEqPolicy.encodeRestore', 'SaveParamsPolicy.encodeTrigger()'
]: assert forbidden not in d, f'onDestroy must not launch DSP action: {forbidden}'

# Deterministic lifecycle recreate probe is READ ONLY and blocked while a pipeline is busy.
p_start=u.index('    private fun runLifecycleRecreateProbe() {')
p_end=u.index('    private fun dp(value: Int)',p_start)
probe=u[p_start:p_end]
for m in [
    'hasPendingControlWrite() || descMode != null || pendingGattPurpose != null || saveInFlight',
    'V88_LIFECYCLE_RECREATE_PROBE_BLOCKED',
    'V88_LIFECYCLE_RECREATE_PROBE_REQUEST readOnly=true',
    'writesSent=0',
    'recreate()',
]: assert m in probe,m
for forbidden in [
    'connectGatt(', 'startSession()', 'requestDescriptor(', 'writeNoResponse(',
    'UfeCodec.encodeFloat32Write', 'LiveEqPolicy.encodeWrite', 'LiveEqPolicy.encodeRestore',
    'SaveParamsPolicy.encodeTrigger()'
]: assert forbidden not in probe, f'recreate probe must be read-only: {forbidden}'

# Persistent lifecycle evidence is loaded before UI and exported by the recreated Activity.
create_start=u.index('    override fun onCreate(savedInstanceState: Bundle?) {')
create_end=u.index('    @Suppress("DEPRECATION")', create_start)
create=u[create_start:create_end]
assert create.index('recoveredLifecycleDestroyText = loadLifecycleDestroyCapture()') < create.index('buildUi()')
for m in [
    'V88_RECOVERED_LIFECYCLE_DESTROY_CAPTURE available=true',
    'private val lifecycleCaptureFileName = "okn_dsp_v88_last_lifecycle_destroy_capture.txt"',
    'private fun loadLifecycleDestroyCapture(): String?',
    '=== OKN DSP V88 PERSISTED LIFECYCLE DESTROY DIAGNOSTIC ===',
    'readOnlyLifecycleObservation=true',
    'exportIncludesRecoveredLifecycleDestroy=',
    '=== RECOVERED/PERSISTED LAST LIFECYCLE DESTROY ===',
    '=== END RECOVERED LIFECYCLE DESTROY ===',
]: assert m in u,m

# Critical diagnostic lineage V88 -> V87 -> V86 -> ... -> V74.
for m in [
    'private val criticalCaptureFileName = "okn_dsp_v88_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV87 = "okn_dsp_v87_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV86 = "okn_dsp_v86_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV85 = "okn_dsp_v85_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV84 = "okn_dsp_v84_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV83 = "okn_dsp_v83_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileName = "okn_dsp_v82_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV81 = "okn_dsp_v81_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV80 = "okn_dsp_v80_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV79 = "okn_dsp_v79_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV78 = "okn_dsp_v78_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV77 = "okn_dsp_v77_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV76 = "okn_dsp_v76_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV75 = "okn_dsp_v75_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV74 = "okn_dsp_v74_last_critical_capture.txt"',
    'val legacyV87 = java.io.File(filesDir, legacyCriticalCaptureFileNameV87)',
    'legacyV87.isFile && legacyV87.length() > 0L -> legacyV87.readText()',
]: assert m in u,m

# Full invalidation clears session/crypto/live cache and bumps epoch.
inv_start=u.index('    private fun invalidateForConnectionTransition(reason: String)')
inv_end=u.index('    private fun renderAll()',inv_start)
invtxt=u[inv_start:inv_end]
for m in [
    'connectionEpoch += 1L','sessionReady = false','txCipher = null','rxCipher = null',
    'ab01 = null','ab02 = null','scalarValues.clear()','sensors.clear()',
    'for (c in bands.indices) for (b in bands[c].indices) bands[c][b] = null',
    'resetSessionHealthGate(reason, recordEvent = true)'
]: assert m in invtxt,m

# Production writer scope frozen.
has(WG,'const val enabled: Boolean = false')
has(WG,'const val unifiedVerifiedScalarWritesEnabled: Boolean = true')
has(WG,'const val unifiedVerifiedEqWritesEnabled: Boolean = true')
ids=[int(x) for x in re.findall(r'VerifiedScalarControl\((\d+),',txt(SP))]
assert ids==[2,3,8,9,10,13,11],ids
assert u.count('UfeCodec.encodeFloat32Write')==2
assert u.count('LiveEqPolicy.encodeWrite')==1
assert u.count('LiveEqPolicy.encodeRestore')==1
assert u.count('SaveParamsPolicy.encodeTrigger()')==1
assert u.count('UfeCodec.encodeWrite(')==0

# ARM-before-write invariant preserved.
h=u[u.index('    private fun writeNoResponse('):u.index('    private fun record(kind: String, text: String) {')]
a=h.index('gattWriteTickets.addLast(kind)')
b=h.index('V88_UNIFIED_GATT_TICKET_PREPARED')
c=h.index('if (purpose != null) armGattActionTimeout(purpose)')
dw=h.index('g.writeCharacteristic(ch, bytes, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE)')
assert a<b<c<dw,(a,b,c,dw)

# Protocol/transport frozen byte-for-byte from V86/V87.
protocol_files=list((root/'app/src/main/java/com/okn/dsp/protocol').glob('*.kt'))
transport_files=list((root/'app/src/main/java/com/okn/dsp/transport').glob('*.kt'))
combo=combined_hash(protocol_files+transport_files)
assert combo=='f897e05f77e7f4e631d591c29a6d758ef355c7b4fba693e63dabe0572cb8552b', combo

assert u.count('class UnifiedControlActivity : Activity()')==1
assert u.count('private fun failClosedDisconnectedAllStatus(callbackGatt: BluetoothGatt, statusCode: Int)')==1
assert u.count('override fun onDestroy()')==1
assert u.count('private fun runLifecycleRecreateProbe()')==1
assert u.count('private fun persistLifecycleDestroyCapture(')==1

print('V88 PRECHECK PASS')
print('versionCode=88')
print('releasePurpose=lifecycle-destroy-persistent-observability')
print('stableSigningKeySha256=ba1c52f2607c09953c52fdd79c5f72026aaf0adb8aa44bcba277f7d9b49d9511')
print('allStatusDisconnectBaseline=V86_RUNTIME_PASSED')
print('lifecycleDestroyBaseline=V87_STATIC_CARRIED')
print('recreateProbe=READ_ONLY')
print('writerCounts=scalar2 eqWrite1 eqRestore1 save1 generic0')
print('protocolTransportCombinedSha256=f897e05f77e7f4e631d591c29a6d758ef355c7b4fba693e63dabe0572cb8552b')
