#!/usr/bin/env python3
from pathlib import Path
import hashlib,re
root=Path(__file__).resolve().parent

def req(rel):
    p=root/rel
    assert p.is_file(),f'missing {rel}'
    return p

def txt(rel): return req(rel).read_text(errors='replace')
def has(rel,m): assert m in txt(rel),f'missing {m!r} in {rel}'
def sha(rel,e):
    g=hashlib.sha256(req(rel).read_bytes()).hexdigest()
    assert g==e,f'hash mismatch {rel}: {g}'

U='app/src/main/java/com/okn/dsp/UnifiedControlActivity.kt'
G='app/build.gradle.kts'
M='app/src/main/java/com/okn/dsp/MainActivity.kt'
WG='app/src/main/java/com/okn/dsp/protocol/WriteGate.kt'
SP='app/src/main/java/com/okn/dsp/protocol/VerifiedScalarControls.kt'
CAP='evidence/OKN_DSP_V76_SESSION_HEALTH_GATE_RUNTIME_SUCCESS_CAPTURE.txt'
PLAN='evidence/OKN_DSP_V78_DIRECT_RECONNECT_EPOCH_BINDING_PLAN.txt'
PLANJ='evidence/OKN_DSP_V78_DIRECT_RECONNECT_EPOCH_BINDING_PLAN.json'
for r in [U,G,M,WG,SP,CAP,'README_V78.txt',PLAN,PLANJ]: req(r)

# Build/release identity.
has(G,'versionCode = 78')
has(G,'5.9.0-v78-direct-reconnect-epoch-binding')
has(M,'V78 production direct-reconnect connection-epoch health-gate-binding launcher')
has(U,'V78 • PRODUCTION SAFE')
has(U,'RUN V78 SESSION HEALTH GATE • READ ONLY')
has(U,'connectionEpochBinding=required')
has(U,'sessionHealthGate=V76_PASSED connectionEpochHealthGate=V78')
u=txt(U)

# Diagnostic lineage must compile and remain version-correct.
for m in [
    'private val criticalCaptureFileName = "okn_dsp_v78_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileName = "okn_dsp_v77_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV76 = "okn_dsp_v76_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV75 = "okn_dsp_v75_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV74 = "okn_dsp_v74_last_critical_capture.txt"',
]: has(U,m)
for sym in ['criticalCaptureFileName','legacyCriticalCaptureFileName','legacyCriticalCaptureFileNameV76','legacyCriticalCaptureFileNameV75','legacyCriticalCaptureFileNameV74']:
    assert u.count('private val '+sym+' =') == 1, sym
for m in ['val legacyV77 =','val legacyV76 =','val legacyV75 =','val legacyV74 =']:
    assert m in u,m

# Production write scope remains frozen.
has(WG,'const val enabled: Boolean = false')
has(WG,'const val unifiedVerifiedScalarWritesEnabled: Boolean = true')
has(WG,'const val unifiedVerifiedEqWritesEnabled: Boolean = true')
ids=[int(x) for x in re.findall(r'VerifiedScalarControl\((\d+),',txt(SP))]
assert ids==[2,3,8,9,10,13,11],ids
assert u.count('UfeCodec.encodeFloat32Write')==2
assert u.count('LiveEqPolicy.encodeWrite')==1
assert u.count('LiveEqPolicy.encodeRestore')==1
assert u.count('SaveParamsPolicy.encodeTrigger()')==1
assert u.count('UfeCodec.encodeWrite(')==0
assert u.count('if (!isCurrentGatt(g,')==7

# Direct reconnect UI + cached device. No scan is invoked from reconnectCurrentDevice().
for m in [
    'private lateinit var reconnectButton: Button',
    'private var selectedDevice: BluetoothDevice? = null',
    'private var selectedDeviceName: String? = null',
    'text = "RECONNECT CURRENT DSP • NO SCAN"',
    'setOnClickListener { reconnectCurrentDevice() }',
    'V78_RECONNECT_CURRENT_REQUEST',
    'transitionReason = "reconnect-current"',
    'directReconnect = true',
]: assert m in u,m
r=u[u.index('    private fun reconnectCurrentDevice()'):u.index('    private fun startScan()',u.index('    private fun reconnectCurrentDevice()'))]
assert 'startScan(' not in r
assert 'connect(device, name, transitionReason = "reconnect-current", directReconnect = true)' in r

# Connection/session epoch state and exact binding.
for m in [
    'private var connectionEpoch = 0L',
    'private var controlSessionEpoch = 0L',
    'private var healthGateBoundConnectionEpoch = -1L',
    'private var healthGateBoundSessionEpoch = -1L',
    'private var healthGateBoundGattIdentity = 0',
    'healthGateBoundConnectionEpoch == connectionEpoch',
    'healthGateBoundSessionEpoch == controlSessionEpoch',
    'healthGateBoundGattIdentity == activeIdentity',
    'healthGateBoundGattIdentity = activeGattIdentity',
    'healthGateBoundConnectionEpoch = connectionEpoch',
    'healthGateBoundSessionEpoch = controlSessionEpoch',
]: assert m in u,m

# connect transition must invalidate before replacement connectGatt, and old GATT must be detached first.
start=u.index('    private fun connect(device: BluetoothDevice, name: String, transitionReason: String, directReconnect: Boolean)')
connect=u[start:u.index('    private val gattCallback = object',start)]
for m in ['selectedDevice = device','selectedDeviceName = name','invalidateForConnectionTransition(transitionReason)','oldGatt?.disconnect()','oldGatt?.close()','V78_RECONNECT_SETTLE_WAIT ms=600','val requestedEpoch = connectionEpoch','V78_CONNECT_OPEN_CANCELLED reason=stale-connection-epoch','device.connectGatt']:
    assert m in connect,m
i_inv=connect.index('invalidateForConnectionTransition(transitionReason)')
i_null=connect.index('gatt = null')
i_disc=connect.index('oldGatt?.disconnect()')
i_close=connect.index('oldGatt?.close()')
i_epoch=connect.index('val requestedEpoch = connectionEpoch')
i_connect=connect.index('device.connectGatt')
assert i_inv < i_null < i_disc < i_close < i_epoch < i_connect,(i_inv,i_null,i_disc,i_close,i_epoch,i_connect)

# transition invalidation disables stale UI and clears stale session objects.
inv=u[u.index('    private fun invalidateForConnectionTransition'):u.index('    private fun renderAll()',u.index('    private fun invalidateForConnectionTransition'))]
for m in [
    'connectionEpoch += 1L','sessionReady = false','resetSessionHealthGate(reason, recordEvent = true)',
    'txCipher = null','rxCipher = null','ab01 = null','ab02 = null','descMode = null',
    'scalarValues.clear()','sensors.clear()','startSessionButton.isEnabled = false','refreshButton.isEnabled = false',
    'pendingConnectRunnable?.let { handler.removeCallbacks(it) }','V78_CONNECTION_EPOCH_INVALIDATE','staleSessionObjectsCleared=true'
]: assert m in inv,m

# START creates new control-session epoch and resets gate.
start=u[u.index('    private fun startSession()'):u.index('    private fun requestDescriptor',u.index('    private fun startSession()'))]
assert start.index('controlSessionEpoch += 1L') < start.index('resetSessionHealthGate("new-session")')

# Gate is read-only and binds current connection/session/GATT only on PASS.
f=u[u.index('    private fun runFieldSelfCheck()'):u.index('    private fun confirmArmPowerCycleProof()')]
for m in ['scalarValues.size == 7','eqCount == 105','sensors.size == 4','gattWriteTickets.isEmpty()','!unsavedVerifiedChanges && verifiedChangeCount == 0','writesSent=0','healthGateBoundGattIdentity = activeGattIdentity']:
    assert m in f,m
for bad in ['writeNoResponse(','UfeCodec.','LiveEqPolicy.encode','SaveParamsPolicy.encodeTrigger','writeCharacteristic(']:
    assert bad not in f,bad

# UI/backend must use bound validity, not raw PASS boolean.
assert u.count('sessionHealthGateValid()') >= 15
for m in [
    'if (!sessionHealthGateValid()) {',
    'if (!sessionHealthGateValid() || hasPendingControlWrite()',
    'if (!sessionHealthGateValid() || !VerifiedScalarControls.allowed(id)',
    'if (!sessionHealthGateValid() || ch !in 1..7',
    'if (!sessionHealthGateValid() || saveInFlight',
    'if (!sessionHealthGateValid() || !saveInFlight',
    'reason=session-health-gate-not-current id=${c.id}',
    'reason=session-health-gate-not-current ch=$channel1 band=$band1',
    'V78_UNIFIED_SAVEPARAMS_BLOCKED reason=session-health-gate-not-current',
]: assert m in u,m
for line in u.splitlines():
    if 'isEnabled =' in line:
        assert 'sessionHealthGatePassed' not in line,line

# V74 ARM-before-write ordering remains centralized and unchanged structurally.
h=u[u.index('    private fun writeNoResponse('):u.index('    private fun record(kind: String, text: String) {')]
a=h.index('gattWriteTickets.addLast(kind)')
b=h.index('V78_UNIFIED_GATT_TICKET_PREPARED')
c=h.index('if (purpose != null) armGattActionTimeout(purpose)')
d=h.index('g.writeCharacteristic(ch, bytes, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE)')
assert a<b<c<d,(a,b,c,d)

# V76 real-device qualification basis.
cap=txt(CAP)
for m in [
    'V76_SESSION_HEALTH_GATE_RESULT pass=true writesSent=0 healthGatePassed=true sessionReady=true scalarCount=7 eqBands=105 sensors=4',
    'V76_SESSION_HEALTH_GATE_RESET reason=new-session',
    'V76_UNIFIED_LOAD mode=INITIAL scalarCount=7 expectedScalars=7 eqBands=105 expectedEqBands=105',
]: assert m in cap,m
assert cap.count('V76_SESSION_HEALTH_GATE_RESULT pass=true writesSent=0') >= 2
sha(CAP,'6075dc8ea585c14a5ae5dfc1655b54d05094edbc8b905cfa90d5c08a11a88fef')

# Production protocol/control modules unchanged.
for rr,e in {
'app/src/main/java/com/okn/dsp/ScalarControlActivity.kt':'01f6aca6f2131bd41ca4fd1d674d879cade425ccc7ddef77e63718e8e124ffed',
'app/src/main/java/com/okn/dsp/LiveEqActivity.kt':'3240ca56c81b7960098ae9fb6ea7421d32e74b11e42810ce4c5b71b35d7ab8d0',
'app/src/main/java/com/okn/dsp/protocol/SaveParamsPolicy.kt':'88005dba77d2b84597f5bd5e23eaaacec7d25b59dc0f38b8affbde2d2cfbeb85',
'app/src/main/java/com/okn/dsp/protocol/LiveEqPolicy.kt':'cfb046aa09acaf8429176a9b99e988ea06347f3daeea988b7c118d056400d2bc',
WG:'8aa82bb069dd64dc2d1274801f1f4420a764f52670246e9c813b0723531be472',
SP:'4c096b001523704dcb6aa36496dd17263d6df84a0a1fee20c2fc40d60e898f6b'
}.items(): sha(rr,e)

# Basic Kotlin source sanity for the exact regression that previously broke V77.
for sym in ['legacyCriticalCaptureFileNameV76','legacyCriticalCaptureFileNameV75','legacyCriticalCaptureFileNameV74','pendingConnectRunnable','selectedDevice','selectedDeviceName']:
    assert u.count(sym) >= 2,sym
assert u.count('{') == u.count('}'), (u.count('{'),u.count('}'))

print('OK: V78 direct reconnect + connection-epoch binding preflight passed')
