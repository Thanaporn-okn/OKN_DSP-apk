OKN DSP V66 — UNIFIED REFRESH FEEDBACK FIX

Purpose
V65 already sent a new Device Description request when REFRESH ALL • SAME SESSION • READ ONLY was tapped, but if the DSP values did not change the screen looked identical and the READY status text was rewritten with the same message. The user therefore had no visible proof that refresh actually ran.

V66 fix
- Refresh button changes to REFRESHING #N • PLEASE WAIT while the read is in flight.
- Status changes to V66 REFRESHING #N while the same authenticated BLE session is used.
- A dedicated REFRESH STATUS line shows START time.
- On completion it shows COMPLETE, elapsed milliseconds, and changed counts for 7 scalars / 105 EQ bands / 4 sensors.
- If nothing changed it explicitly says NO VALUE CHANGES • refresh succeeded but DSP returned the same values.
- A completion Toast is shown.
- Capture markers: V66_UNIFIED_REFRESH_TAP and V66_UNIFIED_REFRESH_COMPLETE.

Safety/invariants
- Unified dashboard remains READ ONLY.
- No UFE parameter WRITE 0x57 path is added to UnifiedControlActivity.
- No SaveParams is sent from UnifiedControlActivity.
- Generic writes remain locked.
- Existing production Global 7 controls and Live EQ 7CH write/verify/rollback/permanent-save behavior remains unchanged.

Expected proof
After the initial V66 UNIFIED READY state, tap REFRESH ALL once. The UI must visibly move through REFRESHING #1 and then REFRESH #1 COMPLETE. A successful capture must include:
V66_UNIFIED_REFRESH_TAP refresh=1 sameSession=true readOnly=true ...
V66_UNIFIED_DESC_COMPLETE mode=REFRESH ...
V66_UNIFIED_LOAD mode=REFRESH ... ready=true ...
V66_UNIFIED_REFRESH_COMPLETE refresh=1 ... ready=true sameSession=true readOnly=true
