OKN DSP V80 — PERSISTENT LAST-DSP RECONNECT

Base: V79 Production Baseline (runtime-qualified on real DSP; V79 icon refresh passed).

V80 changes:
- versionCode 80
- versionName 5.11.0-v80-persistent-last-dsp-reconnect
- remembers the last selected DSP Bluetooth address/name in app-local SharedPreferences
- after app restart, RECONNECT LAST DSP • NO SCAN can reconnect without a new BLE advertisement scan
- current in-memory device remains preferred while the app is open
- invalid cached address is cleared safely and falls back to SCAN DSP
- every reconnect still invalidates the old connection/session/health gate before opening a new GATT
- a fresh START CONTROL SESSION / Auth / Health Gate is still required after reconnect
- diagnostic fallback chain: V80 -> V79 -> V78 -> V77 -> V76 -> V75 -> V74

Production behavior remains V79/V78:
- Global IDs 2,3,8,9,10,13,11
- safe-PEAKING EQ only
- Sensors READ ONLY
- genericWrites=false
- manual guarded SaveParams
- session health gate + connection/session/GATT epoch binding
- direct reconnect without scan
- V79 launcher icon preserved
- Preset / Delay / unknown writes remain locked

No new DSP protocol or writer family is introduced.
