OKN DSP V88 — LIFECYCLE DESTROY PERSISTENT OBSERVABILITY

Version: 5.19.0-v88-lifecycle-destroy-persistent-observability (versionCode 88)

Why V88 exists
- V86 is the runtime-qualified production baseline for all-status DISCONNECTED fail-closed behavior.
- V87 added fail-closed cleanup/journaling to UnifiedControlActivity.onDestroy().
- The first V87 real-device idle lifecycle proof attempt ended with a normal Health Gate PASS but exported no lifecycle-destroy marker. The capture therefore could not prove that Activity destruction/recreation actually occurred.
- V87 only persisted lifecycle evidence when a Scalar/EQ/Save pipeline was active, so an idle destroy marker could be lost with the destroyed Activity's in-memory capture.

V88 change
- Persist a dedicated lifecycle-destroy diagnostic on every UnifiedControlActivity.onDestroy(), including protocol-idle destruction.
- Recover that lifecycle diagnostic in the next Activity instance and include it in exported diagnostics.
- Add a deterministic button: RUN V88 LIFECYCLE RECREATE PROBE • READ ONLY.
- The probe is blocked while any Scalar/EQ/Save/descriptor pipeline is active; otherwise it records a READ-ONLY request and calls Activity.recreate().
- onDestroy still detaches GATT, invalidates connection/session epoch, clears live cache, closes the old GATT, and does not reconnect/start/auth/write/save automatically.
- V86 all-status disconnect, V87 active-pipeline uncertainty journaling, writer surface, protocol/transport, stable signing identity, Last-DSP cache, and Session Health Gate remain unchanged.

Runtime proof target
1) Install V88 over V87 without uninstall/clear-data.
2) Connect -> START -> SYNC -> RUN V88 SESSION HEALTH GATE • READ ONLY -> PASS.
3) While protocol-idle, tap RUN V88 LIFECYCLE RECREATE PROBE • READ ONLY.
4) The Activity recreates and must return fail-closed/disconnected with Health Gate locked; no automatic BLE/DSP action is allowed.
5) Immediately reconnect -> START -> SYNC -> Health Gate PASS again.
6) Export diagnostics. The file must include RECOVERED/PERSISTED LAST LIFECYCLE DESTROY and show V88_LIFECYCLE_RECREATE_PROBE_REQUEST followed by V88_LIFECYCLE_DESTROY_FAIL_CLOSED from the previous Activity.
7) Normal proof target requires controlPipelineUnconfirmed=false and writesSent=0 at the probe request.

Do not intentionally run the recreate probe during APPLY/rollback/Save. The button blocks while a control pipeline is active.
