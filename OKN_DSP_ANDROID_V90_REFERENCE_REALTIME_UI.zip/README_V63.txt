OKN DSP V63 — REMIND SOUND VOLUME ID3 GUARDED PROOF

Purpose
- Runtime-prove actuator ID3 RemindSoundVolume before exposing it as a production writable control.
- Device Description evidence: ID3, type=2000 FLOAT32, min=-70, max=6, incmt=1, unit=dB.
- Production Global Controls remain unchanged: IDs 2,8,9,10,13,11 only.
- Generic writes remain locked.

Guarded proof sequence
1) Connect + START read-only session.
2) Read fresh Device Description and extract live ID3 baseline.
3) On explicit RUN confirmation, read a second fresh preflight descriptor.
4) Choose an in-range target exactly 1.0 dB from the fresh baseline.
5) WRITE 0x57 ID3 FLOAT32 target, then fresh descriptor verify.
6) Automatically WRITE the exact fresh baseline back, then fresh descriptor verify.
7) Never send SaveParams ID7. Persistence remains RAM-only.

Success marker
V63_REMIND_SOUND_ID3_PROOF_COMPLETE ... targetVerified=true restored=true saveParamsSent=false persistence=RAM_ONLY

Stop conditions
- Missing/invalid ID3 descriptor
- Target verification failure (V63 still attempts exact restore)
- Restore verification failure => STOP; no more writes; save capture
- Disconnect during proof => STOP

After a successful capture, ID3 can be considered for the next production allow-list integration. This V63 build itself does not add ID3 to Production Global Controls and does not persist the proof value.
