OKN DSP V72 — PRODUCTION UI MIGRATION

V72 is a production UI release built directly from the runtime-qualified V71 source.

Primary V72 goal:
- Launch directly into the real DSP control screen.
- Replace the qualification-style dashboard with a daily-use Production UI.
- Keep verified protocol behavior byte-for-byte in the existing writer/policy modules.

Production UI:
- Direct launcher -> UnifiedControlActivity.
- Persistent top connection/status area with SCAN DSP, START CONTROL SESSION, and SYNC LIVE VALUES.
- Tabs: GLOBAL / EQ 7CH / STATUS.
- SAVE TO DSP remains visible outside the tabs so Global or EQ changes can be saved without navigating away.
- Session log is hidden by default and available from STATUS only.
- Evidence Lab and capture export remain available under Advanced/Status.

Preserved verified scope from V71:
- Global scalar writes: IDs 2,3,8,9,10,13,11.
- EQ writes: verified safe PEAKING type=12 full 48-byte records only.
- Fresh preflight -> GATT success -> fresh descriptor verify -> exact rollback/restore verify on failure.
- Sensors: READ ONLY.
- SaveParams: manual guarded with fresh PRE-SAVE and POST-SAVE checks.
- Power-cycle/reconnect persistence proof remains available.
- Active-GATT callback identity isolation remains active on all seven callbacks.
- genericWrites=false; preset/delay/unknown writes remain locked.

V72 does not add a new protocol writer or write family.

Runtime qualification target:
1. App opens directly to V72 Production UI.
2. Connect/start session and load 7 Scalars + 105 EQ + 4 Sensors.
3. SYNC LIVE VALUES completes in the same session.
4. Global regression: ID9 tiny temporary change -> verify -> exact baseline restore -> verify.
5. EQ regression: one live safe-PEAKING band tiny temporary change -> verify -> exact baseline restore -> verify.
6. Manual SAVE TO DSP -> PRECHECK -> SaveParams -> 5s settle -> POSTCHECK -> COMPLETE.
7. Reconnect regression: disconnect/reconnect/start/sync remains stable with active-GATT isolation.
8. Capture confirms no generic/preset/delay/unknown write path was enabled.
