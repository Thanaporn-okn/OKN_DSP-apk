OKN DSP V45 — VERIFIED LIVE SCALAR CONTROLS

Evidence milestone inherited from V44:
- current-session RandKey derivation verified on real DSP
- Device Description 18,143 bytes verified
- WRITE 0x57 MasterVolume ID=2 verified by target descriptor
- automatic restore verified by descriptor
- SaveParams ID=7 was NOT sent

V45 enables a new VERIFIED LIVE SCALAR CONTROLS screen for these descriptor-proven FLOAT32 actuators only:
- ID 2 MasterVolume: -70..6 dB
- ID 8 BassVolume: -70..6 dB
- ID 9 BassCutoff: 20..250 Hz
- ID 10 BassBoost: -12..12 dB
- ID 13 MiddleBoost: -12..12 dB
- ID 11 TrebleBoost: -12..12 dB

Write policy:
- each requested value must pass the per-actuator range allow-list
- plaintext is UFE WRITE 0x57 + ID(BE32) + offset(BE16) + len(BE16) + FLOAT32 little-endian
- encrypted with current-session AES-CFB8 TX stream
- every write is followed by Device Description refresh and exact value verification
- if target verification fails or times out, V45 automatically restores the baseline value and verifies restore
- SaveParams ID=7 is never sent
- RemindSoundVolume ID=3 is omitted
- EQ/biquad IDs 4,5,6,14,15,16,17 remain write-locked
- Preset/Delay/unknown writes remain locked

This is the first normal control surface backed by the runtime-proven WRITE serializer.
