OKN DSP V76 — PRODUCTION SESSION HEALTH GATE

Authoritative base
- V75 Production Release Baseline passed real-device Connect/Auth/Sync + READ-ONLY Field Self-Check.
- V75 runtime proof shows 7 scalars + 105 EQ + 4 sensors, sessionReady=true, protocolIdle=true, RAM clean, writer locks intact, and writesSent=0.

V76 scope
- No new DSP write family and no payload change.
- Preserve verified scalar IDs 2,3,8,9,10,13,11.
- Preserve safe PEAKING EQ type=12 full 48-byte records only.
- Preserve SaveParams exact trigger 570000000700000000 through SaveParamsPolicy.
- Preserve V74 ARM-before-write ordering, V73 persistent diagnostics and stale-GATT isolation.
- Generic/unknown/preset/delay writes remain locked.

New V76 safety behavior
- Every new authenticated control session starts with SESSION HEALTH GATE = LOCKED.
- Global APPLY, EQ APPLY and SAVE TO DSP are disabled until the current session passes a READ-ONLY health gate.
- Health gate checks the same proven V75 invariants: sessionReady, 7+105+4 counts, live GATT/AB01/AB02/TX/RX objects, exact scalar allow-list, writer locks, protocol idle, RAM clean and active GATT identity.
- Health check sends no DSP write and records writesSent=0.
- PASS unlocks production controls for that current session only.
- Disconnect or START of a new session resets the gate to LOCKED.
- Backend guards independently reject Scalar/EQ/Save if the gate is not passed, even if UI state were stale.

Expected V76 qualification
1. Install V76.
2. Connect / START CONTROL SESSION / SYNC LIVE VALUES.
3. Confirm APPLY and SAVE are locked before the health gate.
4. Open STATUS and press RUN V76 SESSION HEALTH GATE • READ ONLY.
5. Require PASS; confirm Global/EQ APPLY unlocks while Save remains locked until a verified change exists.
6. Export diagnostic capture and require V76_SESSION_HEALTH_GATE_RESULT pass=true writesSent=0.
7. One tiny scalar target/return-baseline regression may then be used to prove the gate does not regress the V74/V75 writer path; no protocol expansion is part of V76.

Mobile deliverables remain separate: Source ZIP, GitHub Actions workflow YML, SHA256 TXT.
