#!/usr/bin/env python3
from pathlib import Path
import hashlib, re, sys

root = Path(__file__).resolve().parent

def req(rel):
    p = root / rel
    assert p.is_file(), f"missing {rel}"
    return p

def txt(rel):
    return req(rel).read_text(encoding='utf-8', errors='replace')

def has(rel, marker):
    assert marker in txt(rel), f"missing marker {marker!r} in {rel}"

def sha(rel, expected):
    actual = hashlib.sha256(req(rel).read_bytes()).hexdigest()
    assert actual == expected, f"hash mismatch {rel}: {actual}"

def combined_hash(paths):
    h = hashlib.sha256()
    for p in sorted(paths, key=lambda x: x.relative_to(root).as_posix()):
        rel = p.relative_to(root).as_posix()
        h.update(rel.encode() + b'\0' + p.read_bytes() + b'\0')
    return h.hexdigest()

U = 'app/src/main/java/com/okn/dsp/UnifiedControlActivity.kt'
G = 'app/build.gradle.kts'
M = 'app/src/main/java/com/okn/dsp/MainActivity.kt'
WG = 'app/src/main/java/com/okn/dsp/protocol/WriteGate.kt'
SC = 'app/src/main/java/com/okn/dsp/protocol/VerifiedScalarControls.kt'
EQ = 'app/src/main/java/com/okn/dsp/protocol/LiveEqPolicy.kt'
STYLE = 'app/src/main/res/values/styles.xml'
KEY = 'app/okn_dsp_stable_debug.keystore'
README = 'README_V89.txt'
PLAN = 'evidence/OKN_DSP_V89_PRODUCTION_OPERATOR_UI_PLAN.txt'
PLANJ = 'evidence/OKN_DSP_V89_PRODUCTION_OPERATOR_UI_PLAN.json'

for f in [U,G,M,WG,SC,EQ,STYLE,KEY,README,PLAN,PLANJ]:
    req(f)

# Version / app identity.
has(G, 'applicationId = "com.okn.dsp"')
has(G, 'versionCode = 89')
has(G, 'versionName = "5.20.0-v89-production-operator-ui"')
has(M, 'V89 production operator UI launcher over the frozen V88 qualified control core')

# V89 production UI requirements.
for marker in [
    'V89_PRODUCTION_OPERATOR_UI_START',
    'text = "V89"',
    'text = "7-Channel DSP Controller"',
    'text = "Connect last DSP"',
    'text = "Load DSP controls"',
    'text = "Refresh live values"',
    'text = "Run safety check • Read only"',
    'text = "GLOBAL"',
    'text = "EQ 7CH"',
    'text = "SYSTEM"',
    'text = "Show advanced diagnostics"',
    'text = "Apply & verify"',
    'text = "Save to DSP • Locked"',
]:
    has(U, marker)
has(STYLE, 'Theme.Material3.Light.NoActionBar')
has(STYLE, '@color/okn_background')

# Frozen production protocol + transport byte-for-byte from V88.
protocol_files = list((root/'app/src/main/java/com/okn/dsp/protocol').glob('*.kt'))
transport_files = list((root/'app/src/main/java/com/okn/dsp/transport').glob('*.kt'))
combo = combined_hash(protocol_files + transport_files)
assert combo == 'f897e05f77e7f4e631d591c29a6d758ef355c7b4fba693e63dabe0572cb8552b', combo

# Stable signing identity unchanged.
sha(KEY, 'ba1c52f2607c09953c52fdd79c5f72026aaf0adb8aa44bcba277f7d9b49d9511')

# Verified write scope unchanged.
wg = txt(WG)
assert 'const val enabled: Boolean = false' in wg
assert 'const val unifiedVerifiedScalarWritesEnabled: Boolean = true' in wg
assert 'const val unifiedVerifiedEqWritesEnabled: Boolean = true' in wg
sc = txt(SC)
ids = [int(x) for x in re.findall(r'VerifiedScalarControl\((\d+),', sc)]
assert ids == [2,3,8,9,10,13,11], ids
has(EQ, 'b.type == EqBandCodec.PEAKING_TYPE')
has(EQ, 'const val MIN_BOOST_DB = -12.0f')
has(EQ, 'const val MAX_BOOST_DB = 12.0f')

# Core V88 safety paths retained in UnifiedControlActivity.
u = txt(U)
for marker in [
    'V88_ALL_STATUS_DISCONNECT_FAIL_CLOSED',
    'V88_LIFECYCLE_DESTROY_FAIL_CLOSED',
    'V88_SESSION_HEALTH_GATE_RESULT',
    'SaveParamsPolicy.encodeTrigger()',
    'UfeCodec.encodeFloat32Write(id, target)',
    'UfeCodec.encodeFloat32Write(id, original)',
    'LiveEqPolicy.encodeWrite(ch, band1, target)',
    'LiveEqPolicy.encodeRestore(ch, band1, original)',
    'private fun failClosedDisconnectedAllStatus(callbackGatt: BluetoothGatt, statusCode: Int)',
]:
    assert marker in u, marker

# ARM-before-write ordering remains intact.
section = u[u.index('    private fun writeNoResponse('):u.index('    private fun record(kind: String, text: String) {')]
a = section.index('gattWriteTickets.addLast(kind)')
b = section.index('V88_UNIFIED_GATT_TICKET_PREPARED')
c = section.index('if (purpose != null) armGattActionTimeout(purpose)')
d = section.index('g.writeCharacteristic(ch, bytes, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE)')
assert a < b < c < d, (a,b,c,d)

# No accidental duplicate production Activity or lifecycle callbacks.
assert u.count('class UnifiedControlActivity : Activity()') == 1
assert u.count('override fun onDestroy()') == 1
assert u.count('private fun failClosedDisconnectedAllStatus(callbackGatt: BluetoothGatt, statusCode: Int)') == 1

print('V89 PREFLIGHT PASS')
print('versionCode=89')
print('versionName=5.20.0-v89-production-operator-ui')
print('protocolTransportCombinedSha256=' + combo)
print('keystoreSha256=ba1c52f2607c09953c52fdd79c5f72026aaf0adb8aa44bcba277f7d9b49d9511')
print('writerScope=scalar[2,3,8,9,10,13,11]+safePeakingEq+manualSave;generic=false')
print('ui=production-operator-ui')
