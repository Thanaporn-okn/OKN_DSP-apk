OKN DSP V56 — SAVEPARAMS RESTORE BUTTON / STALE-GATT RACE FIX

WHY V56 EXISTS
- V55 successfully proved the first persistence half: CH1/ID4/Band4 -0.1 dB survived a real DSP power-cycle.
- The V55 screen then showed TARGET_PERSISTED VERIFIED while RESTORE ORIGINAL remained grey.
- Root cause addressed: a delayed STATE_DISCONNECTED/callback from the previous BluetoothGatt can arrive after the replacement connection/session is ready and disable action buttons.

V56 FIX
- Ignores every callback from a stale/replaced BluetoothGatt object before it can mutate cipher, protocol, phase, or UI state.
- Re-arms the restore action from both the normal main-handler path and an independent guarded background reassertion.
- Keeps shared preference key okn_v52_saveparams so V55 TARGET_PERSISTED phase carries directly into V56.

SAFETY / PROTOCOL UNCHANGED
- SaveParams remains only actuator ID7 / offset0 / length0 / no payload.
- No generic Save button.
- Restore is permitted only when fresh Device Description says CH1/ID4/Band4 is the safe PEAKING test band at exactly -0.1 dB and local phase is TARGET_PERSISTED or RESTORE_NOT_PERSISTED.
- Flow: read -0.1 -> RESTORE ORIGINAL 0.0 + descriptor verify -> SaveParams -> WAIT_RESTORE_REBOOT -> real second power-cycle -> fresh descriptor verify 0.0 -> COMPLETE.
