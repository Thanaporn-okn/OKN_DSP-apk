#!/usr/bin/env python3
from pathlib import Path
import hashlib,re
root=Path(__file__).resolve().parent

def req(rel):
    p=root/rel
    assert p.is_file(), f'missing {rel}'
    return p

def text(rel): return req(rel).read_text(errors='replace')
def contains(rel, marker):
    s=text(rel); assert marker in s, f'missing {marker!r} in {rel}'

def sha(rel, expected):
    got=hashlib.sha256(req(rel).read_bytes()).hexdigest()
    assert got==expected, f'hash mismatch {rel}: {got}'

U='app/src/main/java/com/okn/dsp/UnifiedControlActivity.kt'
M='app/src/main/java/com/okn/dsp/MainActivity.kt'
G='app/build.gradle.kts'
MAN='app/src/main/AndroidManifest.xml'
GATE='app/src/main/java/com/okn/dsp/protocol/WriteGate.kt'
SP='app/src/main/java/com/okn/dsp/protocol/VerifiedScalarControls.kt'
CAP='evidence/OKN_DSP_V73_PRODUCTION_SAFE_RUNTIME_SUCCESS_AND_GATT_RACE_CAPTURE.txt'
PLAN='evidence/OKN_DSP_V74_GATT_ARM_BEFORE_WRITE_ORDERING_FIX_PLAN.txt'
PLANJ='evidence/OKN_DSP_V74_GATT_ARM_BEFORE_WRITE_ORDERING_FIX_PLAN.json'

for rel in [U,M,G,MAN,GATE,SP,'README_V74.txt',PLAN,PLANJ,CAP]: req(rel)
contains(G,'versionCode = 74')
contains(G,'5.5.0-v74-gatt-arm-before-write-ordering-fix')
contains(M,'startActivity(Intent(this, UnifiedControlActivity::class.java))')
contains(M,'finish()')
contains(MAN,'android:label="OKN DSP"')
for m in ['V74 • PRODUCTION SAFE','DSP CONNECTION','START CONTROL SESSION','SYNC LIVE VALUES',
          '● GLOBAL','EQ 7CH','DSP STATUS','SAVE TO DSP • LOCKED',
          'EXPORT DIAGNOSTIC CAPTURE • CURRENT + LAST FAILURE']:
    contains(U,m)

contains(GATE,'const val enabled: Boolean = false')
contains(GATE,'const val unifiedVerifiedScalarWritesEnabled: Boolean = true')
contains(GATE,'const val unifiedVerifiedEqWritesEnabled: Boolean = true')
ids=[int(x) for x in re.findall(r'VerifiedScalarControl\((\d+),',text(SP))]
assert ids==[2,3,8,9,10,13,11],ids

u=text(U)
# Writer surface/payload families remain unchanged from V73.
assert u.count('UfeCodec.encodeFloat32Write')==2
assert u.count('LiveEqPolicy.encodeWrite')==1
assert u.count('LiveEqPolicy.encodeRestore')==1
assert u.count('SaveParamsPolicy.encodeTrigger()')==1
assert u.count('UfeCodec.encodeWrite(')==0
assert u.count('EqBandCodec.encode')==0
# Seven stale-GATT callback identity guards retained.
labels=['onConnectionStateChange','onMtuChanged','onServicesDiscovered','onDescriptorWrite','onCharacteristicWrite','onCharacteristicChanged33','onCharacteristicChangedLegacy']
for label in labels:
    assert f'if (!isCurrentGatt(g, "{label}")) return' in u,label
assert u.count('if (!isCurrentGatt(g,')==7

# V74 ordering correction must be centralized in writeNoResponse.
helper=u[u.index('    private fun writeNoResponse('):u.index('    private fun record(kind: String, text: String) {')]
idx_ticket=helper.index('gattWriteTickets.addLast(kind)')
idx_prepared=helper.index('V74_UNIFIED_GATT_TICKET_PREPARED')
idx_arm=helper.index('if (purpose != null) armGattActionTimeout(purpose)')
idx_write=helper.index('g.writeCharacteristic(ch, bytes, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE)')
assert idx_ticket < idx_prepared < idx_arm < idx_write, (idx_ticket,idx_prepared,idx_arm,idx_write)
assert 'beforeWriteCharacteristic=true' in helper
assert 'V74_UNIFIED_GATT_PREARM_ROLLBACK' in helper
assert 'V74_UNIFIED_GATT_WRITE_ACCEPTED' in helper
# No caller-side post-write ARM may remain: one definition + one helper call only.
assert u.count('armGattActionTimeout(')==2, u.count('armGattActionTimeout(')
# Every control family still goes through writeNoResponse with an explicit purpose.
for purpose in ['SCALAR_TARGET','SCALAR_RESTORE','EQ_TARGET','EQ_RESTORE','SAVE_PARAMS']:
    assert f'PendingGattPurpose.{purpose})' in u, purpose

# Unconfirmed target safety is preserved: STOP, never a second automatic write.
for m in [
    'V74_UNIFIED_UNCONFIRMED_TARGET_POLICY action=STOP_NO_SECOND_WRITE family=SCALAR',
    'V74_UNIFIED_UNCONFIRMED_TARGET_POLICY action=STOP_NO_SECOND_WRITE family=EQ',
    'V74_UNIFIED_GATT_RESULT_TIMEOUT','callbackAgeMs=',
    'private fun restorePending(reason: String)','private fun restorePendingEq(reason: String)',
    'sensorReadOnly=true','genericWrites=false']:
    assert m in u,m
assert 'restorePending("target-gatt-unconfirmed")' not in u
assert 'restorePendingEq("target-gatt-unconfirmed")' not in u
assert 'restorePending("target-gatt-failed-' not in u
assert 'restorePendingEq("target-gatt-failed-' not in u

# Persistent diagnostics retained, with V73 legacy-read continuity.
for m in ['okn_dsp_v74_last_critical_capture.txt','okn_dsp_v73_last_critical_capture.txt',
          'V74 PERSISTED CRITICAL DIAGNOSTIC','RECOVERED/PERSISTED LAST CRITICAL FAILURE']:
    assert m in u,m

# V73 evidence must prove both functional success and the ordering race being fixed.
cap=text(CAP)
for m in ['V73_UNIFIED_PERSISTENT_SAVE_COMPLETE','precheck=true postcheck=true',
          'callbackAgeMs=-1','armedGattIdentity=0','V73_UNIFIED_EQ_TARGET_DESCRIPTOR_VERIFY']:
    assert m in cap,m
sha(CAP,'c490c815ede7fc5ea7fad01fff7d396ed2f88c0cf924826acb339956dd8eb536')

# Production modules remain byte-for-byte unchanged.
sha('app/src/main/java/com/okn/dsp/ScalarControlActivity.kt','01f6aca6f2131bd41ca4fd1d674d879cade425ccc7ddef77e63718e8e124ffed')
sha('app/src/main/java/com/okn/dsp/LiveEqActivity.kt','3240ca56c81b7960098ae9fb6ea7421d32e74b11e42810ce4c5b71b35d7ab8d0')
sha('app/src/main/java/com/okn/dsp/protocol/SaveParamsPolicy.kt','88005dba77d2b84597f5bd5e23eaaacec7d25b59dc0f38b8affbde2d2cfbeb85')
sha('app/src/main/java/com/okn/dsp/protocol/LiveEqPolicy.kt','cfb046aa09acaf8429176a9b99e988ea06347f3daeea988b7c118d056400d2bc')
sha('app/src/main/java/com/okn/dsp/protocol/EqBandCodec.kt','4f033a406e363b2418af9b39fa2e42a13674b09f9de2bb7acf1eb6ff1918cd58')
print('OK: V74 GATT arm-before-write ordering preflight passed')
