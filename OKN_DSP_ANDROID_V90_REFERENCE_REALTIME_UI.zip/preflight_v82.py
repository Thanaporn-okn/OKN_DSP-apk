#!/usr/bin/env python3
from pathlib import Path
import hashlib,re
root=Path(__file__).resolve().parent

def req(rel):
    p=root/rel
    assert p.is_file(), f'missing {rel}'
    return p

def txt(rel): return req(rel).read_text(errors='replace')
def has(rel,m): assert m in txt(rel), f'missing {m!r} in {rel}'
def sha(rel,e):
    g=hashlib.sha256(req(rel).read_bytes()).hexdigest()
    assert g==e, f'hash mismatch {rel}: {g}'

U='app/src/main/java/com/okn/dsp/UnifiedControlActivity.kt'
G='app/build.gradle.kts'
M='app/src/main/java/com/okn/dsp/MainActivity.kt'
WG='app/src/main/java/com/okn/dsp/protocol/WriteGate.kt'
SP='app/src/main/java/com/okn/dsp/protocol/VerifiedScalarControls.kt'
KEY='app/okn_dsp_stable_debug.keystore'
CAP80='evidence/OKN_DSP_V80_PERSISTENT_LAST_DSP_RECONNECT_RUNTIME_SUCCESS_CAPTURE.txt'
PLAN='evidence/OKN_DSP_V82_STABLE_UPGRADE_SIGNING_PLAN.txt'
PLANJ='evidence/OKN_DSP_V82_STABLE_UPGRADE_SIGNING_PLAN.json'
for r in [U,G,M,WG,SP,KEY,CAP80,PLAN,PLANJ,'README_V82.txt']:
    req(r)

# Build/version identity.
has(G,'applicationId = "com.okn.dsp"')
has(G,'versionCode = 82')
has(G,'versionName = "5.13.0-v82-stable-upgrade-signing-cache-state"')
has(M,'V82 stable-upgrade signing + explicit last-DSP cache-state launcher')
has(U,'V82 • PRODUCTION SAFE')
has(U,'RUN V82 SESSION HEALTH GATE • READ ONLY')

# Stable debug signing identity must be source-fixed and exact.
has(G,'create("stableDebug")')
has(G,'storeFile = file("okn_dsp_stable_debug.keystore")')
has(G,'storePassword = "android"')
has(G,'keyAlias = "androiddebugkey"')
has(G,'keyPassword = "android"')
has(G,'signingConfig = signingConfigs.getByName("stableDebug")')
sha(KEY,'ba1c52f2607c09953c52fdd79c5f72026aaf0adb8aa44bcba277f7d9b49d9511')

u=txt(U)
# Cache-state UI is explicit and write-free.
for m in [
    'RECONNECT LAST DSP • NO SCAN',
    'NO SAVED DSP • SCAN ONCE',
    'V82_LAST_DSP_CACHE_AVAILABLE',
    'V82_LAST_DSP_CACHE_MISSING action=SCAN_ONCE writesSent=0',
    'V82_LAST_DSP_CACHE_UPDATED',
    'V82_RECONNECT_LAST_REQUEST',
]: assert m in u, m
cache=u[u.index('    private fun restoreLastDspReconnectUi()'):u.index('    private fun startScan()',u.index('    private fun restoreLastDspReconnectUi()'))]
for bad in ['writeCharacteristic(', 'writeNoResponse(', 'UfeCodec.', 'LiveEqPolicy.encode', 'SaveParamsPolicy.encodeTrigger', 'beginSession()', 'confirmStartSession()']:
    assert bad not in cache, bad

# V81 connection watchdog behavior carried unchanged in structure.
for m in [
    'private val connectionReadyTimeoutMs = 15000L',
    'private fun armConnectionWatchdog(epoch: Long, transitionReason: String)',
    'V82_CONNECTION_WATCHDOG_ARM',
    'V82_CONNECTION_WATCHDOG_TIMEOUT',
    'V82_CONNECTION_WATCHDOG_RECOVERY_COMPLETE',
    'V82_CONNECTION_READY_FAIL_CLOSED',
]: assert m in u, m
start=u.index('    private fun connect(device: BluetoothDevice, name: String, transitionReason: String, directReconnect: Boolean)')
connect=u[start:u.index('    private val gattCallback = object',start)]
for m in ['invalidateForConnectionTransition(transitionReason)','armConnectionWatchdog(requestedEpoch, transitionReason)','device.connectGatt']:
    assert m in connect,m
assert connect.index('invalidateForConnectionTransition(transitionReason)') < connect.index('armConnectionWatchdog(requestedEpoch, transitionReason)') < connect.index('device.connectGatt')

# Health gate binding remains exact.
for m in ['private var connectionEpoch = 0L','private var controlSessionEpoch = 0L','healthGateBoundConnectionEpoch == connectionEpoch','healthGateBoundSessionEpoch == controlSessionEpoch','healthGateBoundGattIdentity == activeIdentity']:
    assert m in u,m

# Production write scope remains frozen.
has(WG,'const val enabled: Boolean = false')
has(WG,'const val unifiedVerifiedScalarWritesEnabled: Boolean = true')
has(WG,'const val unifiedVerifiedEqWritesEnabled: Boolean = true')
ids=[int(x) for x in re.findall(r'VerifiedScalarControl\((\d+),',txt(SP))]
assert ids==[2,3,8,9,10,13,11],ids
assert u.count('UfeCodec.encodeFloat32Write')==2
assert u.count('LiveEqPolicy.encodeWrite')==1
assert u.count('LiveEqPolicy.encodeRestore')==1
assert u.count('SaveParamsPolicy.encodeTrigger()')==1
assert u.count('UfeCodec.encodeWrite(')==0

# ARM-before-write central order retained.
h=u[u.index('    private fun writeNoResponse('):u.index('    private fun record(kind: String, text: String) {')]
a=h.index('gattWriteTickets.addLast(kind)')
b=h.index('V82_UNIFIED_GATT_TICKET_PREPARED')
c=h.index('if (purpose != null) armGattActionTimeout(purpose)')
d=h.index('g.writeCharacteristic(ch, bytes, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE)')
assert a<b<c<d,(a,b,c,d)

# Diagnostic lineage symbols compile-resolvable: V82 current -> V81 -> V80 -> ... -> V74.
for m in [
    'private val criticalCaptureFileName = "okn_dsp_v82_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileName = "okn_dsp_v81_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV80 = "okn_dsp_v80_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV79 = "okn_dsp_v79_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV78 = "okn_dsp_v78_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV77 = "okn_dsp_v77_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV76 = "okn_dsp_v76_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV75 = "okn_dsp_v75_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV74 = "okn_dsp_v74_last_critical_capture.txt"',
    'val legacyV81 = java.io.File(filesDir, legacyCriticalCaptureFileName)',
    'val legacyV80 = java.io.File(filesDir, legacyCriticalCaptureFileNameV80)',
]: assert m in u,m
for sym in ['criticalCaptureFileName','legacyCriticalCaptureFileName','legacyCriticalCaptureFileNameV80','legacyCriticalCaptureFileNameV79','legacyCriticalCaptureFileNameV78','legacyCriticalCaptureFileNameV77','legacyCriticalCaptureFileNameV76','legacyCriticalCaptureFileNameV75','legacyCriticalCaptureFileNameV74']:
    assert u.count('private val '+sym+' =')==1,sym

# Freeze protocol files against V81/V80 baseline.
protocol_hashes={
'AuthResponseCodec.kt':'0cbe3174f4d0bf543edb1dfd41db71ab4970effb3743be9e6c7d5a174a5e5f90',
'AuthSessionAnalyzer.kt':'63c8e8afcbc0fb5a2400a8e620932af72bec4d695463c8ed86b0c6bd5d507f7d',
'AuthVectorLab.kt':'16ba1e0fa076da2b5b6b1ccc0c97bee7f015895c7ebceb55a5f1e704ebfe113a',
'ByteCodec.kt':'04843cec90b69886607d98a0aabf0ad81812fc8d25df913c5b1847a10fd7a3ae',
'ConfirmedDspMap.kt':'6e68295f194dd0b0f70d0b83b9ba2324a9a2a8eaf2350b5d5a821f838ae2c66d',
'LiveEqPolicy.kt':'cfb046aa09acaf8429176a9b99e988ea06347f3daeea988b7c118d056400d2bc',
'SaveParamsPolicy.kt':'88005dba77d2b84597f5bd5e23eaaacec7d25b59dc0f38b8affbde2d2cfbeb85',
'SessionCrypto.kt':'bae330efd6e9beb628b287e43e36bd98d80b3f9b4d1c014f65c63ef16efa586e',
'UfeCodec.kt':'b47f66afec8fd3383581c30b2dc1ad9ad41e3b7089f427f0b094e91581588c34',
'VerifiedScalarControls.kt':'4c096b001523704dcb6aa36496dd17263d6df84a0a1fee20c2fc40d60e898f6b',
'WriteGate.kt':'8aa82bb069dd64dc2d1274801f1f4420a764f52670246e9c813b0723531be472',
}
for name,hv in protocol_hashes.items():
    sha('app/src/main/java/com/okn/dsp/protocol/'+name,hv)

# V80 real-DSP persistent reconnect proof remains bundled.
cap=txt(CAP80)
for m in ['V80_LAST_DSP_CACHE_AVAILABLE','V80_RECONNECT_LAST_REQUEST source=persisted-address','V80_UNIFIED_LOAD mode=INITIAL scalarCount=7 expectedScalars=7 eqBands=105 expectedEqBands=105','V80_SESSION_HEALTH_GATE_RESULT pass=true writesSent=0']:
    assert m in cap,m

print('V82 PRELIGHT PASS: stable signing identity + explicit cache state + writer/protocol freeze')
