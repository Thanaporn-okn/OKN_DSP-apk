OKN DSP Android V60 — V59 RAM-DIRTY IMPORT RECOVERY

Purpose
- Recover safely from the user closing V59 after MasterVolume ID2 was descriptor-verified at -59.08 dB but before SaveParams.
- No automatic write and no automatic SaveParams.

Guarded recovery
1. Connect + START V60.
2. Fresh Device Description must contain all six verified scalar IDs.
3. Recovery import is accepted only if fresh live ID2 matches -59.08 dB using the verified scalar tolerance.
4. IMPORT only sets app-local unsavedVerifiedChanges=true and verifiedChangeCount=1. It sends NO BLE write and NO SaveParams.
5. User must separately press permanent SAVE; the exact proven SaveParams ID7 trigger is 570000000700000000.
6. If fresh ID2 differs from -59.08, import is blocked and nothing is written/saved.

Evidence
- Uploaded V59 capture verified original=-59.180317, target=-59.08, descriptor actual=-59.08, verified=true, persistence=RAM_DIRTY, saveParamsSent=false.
- V57 already proved SaveParams ID7 survives two real DSP power cycles.

versionCode 60
versionName 4.2.0-v60-v59-ram-dirty-import-recovery
