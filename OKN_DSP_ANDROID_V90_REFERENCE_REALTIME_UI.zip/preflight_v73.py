#!/usr/bin/env python3
from pathlib import Path
import hashlib,re,sys
root=Path(__file__).resolve().parent

def req(rel):
    p=root/rel
    assert p.is_file(), f'missing {rel}'
    return p

def text(rel): return req(rel).read_text()
def contains(rel, marker):
    s=text(rel); assert marker in s, f'missing {marker!r} in {rel}'

def sha(rel, expected):
    got=hashlib.sha256(req(rel).read_bytes()).hexdigest()
    assert got==expected, f'hash mismatch {rel}: {got}'

U='app/src/main/java/com/okn/dsp/UnifiedControlActivity.kt'
M='app/src/main/java/com/okn/dsp/MainActivity.kt'
G='app/build.gradle.kts'
MAN='app/src/main/AndroidManifest.xml'
GATE='app/src/main/java/com/okn/dsp/protocol/WriteGate.kt'
SP='app/src/main/java/com/okn/dsp/protocol/VerifiedScalarControls.kt'

for rel in [U,M,G,MAN,GATE,SP,'README_V73.txt',
            'evidence/OKN_DSP_V73_PERSISTENT_DIAGNOSTICS_SAFE_GATT_UNCERTAINTY_PLAN.txt',
            'evidence/OKN_DSP_V73_PERSISTENT_DIAGNOSTICS_SAFE_GATT_UNCERTAINTY_PLAN.json',
            'evidence/OKN_DSP_V71_STALE_GATT_RUNTIME_SUCCESS_CAPTURE.txt']:
    req(rel)
contains(G,'versionCode = 73')
contains(G,'5.4.0-v73-persistent-diagnostics-safe-gatt-uncertainty')
contains(M,'startActivity(Intent(this, UnifiedControlActivity::class.java))')
contains(M,'finish()')
contains(MAN,'android:label="OKN DSP"')
for m in ['V73 • PRODUCTION SAFE','DSP CONNECTION','START CONTROL SESSION','SYNC LIVE VALUES',
          '● GLOBAL','EQ 7CH','DSP STATUS','SAVE TO DSP • LOCKED',
          'EXPORT DIAGNOSTIC CAPTURE • CURRENT + LAST FAILURE']:
    contains(U,m)
contains(GATE,'const val enabled: Boolean = false')
contains(GATE,'const val unifiedVerifiedScalarWritesEnabled: Boolean = true')
contains(GATE,'const val unifiedVerifiedEqWritesEnabled: Boolean = true')
ids=[int(x) for x in re.findall(r'VerifiedScalarControl\((\d+),',text(SP))]
assert ids==[2,3,8,9,10,13,11],ids
u=text(U)
assert u.count('UfeCodec.encodeFloat32Write')==2
assert u.count('LiveEqPolicy.encodeWrite')==1
assert u.count('LiveEqPolicy.encodeRestore')==1
assert u.count('SaveParamsPolicy.encodeTrigger()')==1
assert u.count('UfeCodec.encodeWrite(')==0
assert u.count('EqBandCodec.encode')==0
labels=['onConnectionStateChange','onMtuChanged','onServicesDiscovered','onDescriptorWrite','onCharacteristicWrite','onCharacteristicChanged33','onCharacteristicChangedLegacy']
for label in labels:
    assert f'if (!isCurrentGatt(g, "{label}")) return' in u,label
assert u.count('if (!isCurrentGatt(g,')==7
for m in [
    'V73_UNIFIED_SCALAR_PREFLIGHT_START','V73_UNIFIED_TARGET_DESCRIPTOR_VERIFY','V73_UNIFIED_RESTORE_DESCRIPTOR_VERIFY',
    'V73_UNIFIED_EQ_PREFLIGHT_START','V73_UNIFIED_EQ_TARGET_DESCRIPTOR_VERIFY','V73_UNIFIED_EQ_RESTORE_DESCRIPTOR_VERIFY',
    'V73_UNIFIED_SAVE_PRECHECK_RESULT','V73_UNIFIED_SAVE_POSTCHECK_RESULT','V73_UNIFIED_PERSISTENT_SAVE_COMPLETE',
    'V73_UNIFIED_POWER_CYCLE_PERSISTENCE_PROOF_RESULT','V73_UNIFIED_STALE_GATT_CALLBACK_IGNORED',
    'V73_UNIFIED_GATT_ACTION_ARM','V73_UNIFIED_GATT_RESULT_TIMEOUT','callbackAgeMs=',
    'V73_UNIFIED_UNCONFIRMED_TARGET_POLICY action=STOP_NO_SECOND_WRITE family=SCALAR',
    'V73_UNIFIED_UNCONFIRMED_TARGET_POLICY action=STOP_NO_SECOND_WRITE family=EQ',
    'okn_dsp_v73_last_critical_capture.txt','PERSISTED CRITICAL DIAGNOSTIC',
    'RECOVERED/PERSISTED LAST CRITICAL FAILURE','sensorReadOnly=true','genericWrites=false']:
    assert m in u,m
# No automatic second write when target GATT itself is unconfirmed/non-success.
assert 'restorePending("target-gatt-unconfirmed")' not in u
assert 'restorePendingEq("target-gatt-unconfirmed")' not in u
assert 'restorePending("target-gatt-failed-' not in u
assert 'restorePendingEq("target-gatt-failed-' not in u
# But exact rollback writer is retained for confirmed-target fresh-verify failure paths.
assert 'private fun restorePending(reason: String)' in u
assert 'private fun restorePendingEq(reason: String)' in u
# Production modules must be byte-for-byte unchanged.
sha('app/src/main/java/com/okn/dsp/ScalarControlActivity.kt','01f6aca6f2131bd41ca4fd1d674d879cade425ccc7ddef77e63718e8e124ffed')
sha('app/src/main/java/com/okn/dsp/LiveEqActivity.kt','3240ca56c81b7960098ae9fb6ea7421d32e74b11e42810ce4c5b71b35d7ab8d0')
sha('app/src/main/java/com/okn/dsp/protocol/SaveParamsPolicy.kt','88005dba77d2b84597f5bd5e23eaaacec7d25b59dc0f38b8affbde2d2cfbeb85')
sha('app/src/main/java/com/okn/dsp/protocol/LiveEqPolicy.kt','cfb046aa09acaf8429176a9b99e988ea06347f3daeea988b7c118d056400d2bc')
sha('app/src/main/java/com/okn/dsp/protocol/EqBandCodec.kt','4f033a406e363b2418af9b39fa2e42a13674b09f9de2bb7acf1eb6ff1918cd58')
sha('evidence/OKN_DSP_V71_STALE_GATT_RUNTIME_SUCCESS_CAPTURE.txt','f10275ebfebade6aaf515f43d8749513e25e8737322fd621cf17e44cf462d29d')
print('OK: V73 persistent diagnostics + safe GATT uncertainty preflight passed')
