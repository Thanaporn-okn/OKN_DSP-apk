OKN_DSP V68 — UNIFIED VERIFIED LIVE-EQ WRITE MIGRATION

Base: V67 runtime-qualified Unified verified Global-write migration.
V67 authoritative source SHA256: eefd150b5d484f333a192b03b8418bc197e96d8fbac356c01342f50812e1068b
V67 runtime capture SHA256: 81da058e93f5c4a469dfb7e9fb10f7a18311f2aacd9a4cedfec33fe36fb50fe8

V68 keeps the seven verified scalar writes and migrates the separately-qualified LIVE EQ safe-PEAKING write path into the same BLE/auth/RandKey session. Sensors and non-standard EQ bands remain READ ONLY. Generic/unknown/preset/delay writes remain locked. SaveParams is manual guarded only and uses exact trigger 570000000700000000 after verified scalar/EQ changes. No auto-save.

Build identity:
versionCode=68
versionName=4.9.0-v68-unified-verified-live-eq-write-migration

Runtime status: NOT YET QUALIFIED until a real V68 capture passes temporary safe EQ change -> verify -> exact baseline restore -> verify -> manual guarded SaveParams.
