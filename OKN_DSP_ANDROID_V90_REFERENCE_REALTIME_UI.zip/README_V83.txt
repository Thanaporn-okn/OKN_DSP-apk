OKN DSP V83 — STABLE UPGRADE CONTINUITY PROOF

BASELINE
- V82 is the current production-safe baseline.
- V82 proved Last-DSP cache, GATT status 147 fail-closed recovery, reconnect, Auth/Sync and final Health Gate PASS with writesSent=0.
- V83 adds no DSP protocol/write family.

WHY V83 EXISTS
V82 introduced a project-stable debug signing identity. V83 is the first following version that can prove Android accepts an in-place update using the same certificate and preserves SharedPreferences across that update.

STABLE SIGNING IDENTITY — MUST NOT CHANGE
- app/okn_dsp_stable_debug.keystore
- Keystore SHA256: ba1c52f2607c09953c52fdd79c5f72026aaf0adb8aa44bcba277f7d9b49d9511
- Certificate SHA-256: C3:DA:85:AF:2E:97:8D:BD:0E:D9:BB:69:5E:5C:79:A2:63:18:95:95:C1:16:AD:93:A1:DE:D7:5A:2E:B9:83:97
- This is an iterative project debug key, not Play Store/release signing.

V83 READ-ONLY PROBE
At Activity start V83 records V83_STABLE_UPGRADE_CONTINUITY_PROBE containing:
- firstInstallTime
- lastUpdateTime
- updatedInPlace
- cachePresent
- saved DSP address/name
- stableSigning=projectStableDebugKey
- writesSent=0

PASS CONDITION
Install V83 directly over the installed V82 without uninstalling. Do not SCAN first. On V83 startup, RECONNECT LAST DSP • NO SCAN should already be enabled and the diagnostic probe should show updatedInPlace=true and cachePresent=true.

PRODUCTION DSP WRITE SCOPE UNCHANGED
- Scalars: IDs 2,3,8,9,10,13,11 only
- EQ: safe PEAKING only, IDs 4,5,6,14,15,16,17
- Sensors: READ ONLY
- genericWrites=false
- SaveParams manual guarded
- Preset / Delay / unknown writes remain locked
