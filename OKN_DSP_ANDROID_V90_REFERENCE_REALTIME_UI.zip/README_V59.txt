OKN DSP Android V60 — VERIFIED GLOBAL CONTROLS + PERMANENT SAVE
===============================================================

Purpose
-------
V60 promotes the already-proven scalar control path into the same production-style persistence model used by V58 live EQ.
It does NOT unlock new/unknown DSP commands.

Evidence reused
---------------
1) V44/V45 proved real FLOAT32 WRITE 0x57 + fresh Device Description readback for the verified scalar allow-list.
2) V49/V50/V51 proved the 7-channel EQ actuator map and live guarded EQ writes.
3) V57 proved SaveParams actuator ID7 persistence with two real DSP power-cycles.
4) V58 proved the integrated live EQ -> verify -> explicit SaveParams flow.

V60 verified global scalar allow-list
-------------------------------------
- ID2  MasterVolume    -70 .. +6 dB
- ID8  BassVolume      -70 .. +6 dB
- ID9  BassCutoff       20 .. 250 Hz
- ID10 BassBoost       -12 .. +12 dB
- ID13 MiddleBoost     -12 .. +12 dB
- ID11 TrebleBoost     -12 .. +12 dB

Scalar write sequence
---------------------
- User starts a fresh authenticated BLE session.
- App reads Device Description and requires all 6 verified scalar values.
- User chooses one scalar target.
- App sends WRITE_ACTUATOR 0x57 with FLOAT32 little-endian payload.
- App reads a fresh Device Description and verifies actual ~= target.
- If target verification fails, app writes the exact pre-write scalar value back and verifies the restore.
- Successful target verification marks the session RAM_DIRTY; there is no auto-save.

Permanent SAVE sequence
-----------------------
- SAVE button is always clickable to avoid UI enable-state races, but a runtime guard blocks the write unless:
  * current V60 session is ready,
  * no scalar verification/restore is pending,
  * no Device Description request is active,
  * auth is complete,
  * no SaveParams write is already in flight,
  * at least one scalar change in the current session has verified successfully.
- Exact SaveParams trigger only:
  57 00000007 0000 0000
- Encoding is centralized in SaveParamsPolicy.encodeTrigger().
- App requires GATT status=0 and a 5000 ms commit window before declaring the save complete.
- SaveParams stores the DSP's current turning parameters as a set, including any current EQ state.

V60 also retains the proven V60-labeled live-EQ module (protocol logic unchanged from V58), with guarded permanent SAVE.

Still locked / not claimed
--------------------------
- RemindSoundVolume ID3 is omitted.
- Preset writes are not enabled.
- Delay writes are not enabled.
- Unknown/non-standard actuator writes are not enabled.
- Non-standard EQ bands remain read-only.
- Generic WriteGate.enabled remains false.

Version
-------
versionCode 59
versionName 4.1.0-v60-verified-global-controls-permanent-save
