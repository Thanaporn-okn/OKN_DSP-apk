OKN DSP V85 — ALL-STATUS DISCONNECT FAIL-CLOSED UNIFICATION

Version: 5.16.0-v85-all-status-disconnect-fail-closed (versionCode 85)

This release carries the V84 production DSP writer/protocol surface unchanged.
It hardens BLE disconnect handling so every STATE_DISCONNECTED callback is routed through the same fail-closed detach/epoch/live-cache/uncertainty-journal path, regardless of Android GATT status code.

Real-device basis: V84 power loss produced status=8 + DISCONNECTED, then safely recovered and re-passed Health Gate with writesSent=0.

Runtime qualification remains READ-ONLY: Connect/START/SYNC/Health PASS, power DSP off, observe all-status disconnect fail-closed, power on, reconnect/START/SYNC/Health PASS, export diagnostic.
Do not APPLY or SAVE during qualification.
