OKN_DSP V70 — POWER-CYCLE / RECONNECT PERSISTENCE PROOF

AUTHORITATIVE BASE
- V69 source: OKN_DSP_ANDROID_V69_PRODUCTION_SAVE_STATE_HARDENING.zip
- V69 source SHA256: b761c9ffbb4bdf0609ec944d0939fb934887a79a940d362e619dd2e7e7acf3e5
- V69 runtime success capture SHA256: dcd74329985f4a15a5df83056c15e4f7304521c653de843e59d02fa05109dc81
- V69 runtime qualification: PASSED (ID9 117.3 -> 118.3 verified -> 117.3 verified; PRE-SAVE verified, SaveParams GATT status0 + 5s settle, POST-SAVE verified, PERSISTENT_SAVE_COMPLETE).

Build identity:
versionCode=70
versionName=5.1.0-v70-power-cycle-reconnect-persistence-proof

V70 keeps V69 verified writer scope unchanged:
- Scalar IDs [2,3,8,9,10,13,11] only.
- EQ actuator IDs [4,5,6,14,15,16,17], safe PEAKING(type=12) write only, full 48-byte record.
- Sensors READ ONLY.
- Generic writes=false.
- Preset/delay/unknown writes remain locked.
- SaveParams exact ID7 trigger 570000000700000000, manual only.
- V69 PRE-SAVE and POST-SAVE fresh-descriptor guards remain mandatory.

V70 adds no new protocol write. New proof pipeline:
1) After successful POST-SAVE verification, store a local snapshot of all 7 verified scalar values and all 105 decoded EQ band records.
2) User explicitly presses ARM POWER-CYCLE / RECONNECT PROOF while RAM is clean and protocol idle.
3) User powers the DSP OFF for about 10 seconds and back ON. App must observe BLE disconnect.
4) Reconnect and START V70; new auth/RandKey session reads a fresh full descriptor.
5) Require 7 scalars + 105 EQ + 4 sensors and compare 7 scalars + all 105 EQ records with the stored POST-SAVE snapshot.
6) Sensors are excluded from value comparison because they are dynamic.
7) PASS is read-only and emits V70_UNIFIED_POWER_CYCLE_PERSISTENCE_PROOF_RESULT verified=true.
8) Any mismatch blocks the proof; no write or auto-retry is sent.

Runtime status: PENDING REAL DSP V70 CAPTURE.
