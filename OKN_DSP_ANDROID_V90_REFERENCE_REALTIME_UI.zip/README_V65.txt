OKN DSP V65 — UNIFIED SINGLE-SESSION READ-ONLY INTEGRATION

V64 promoted RemindSoundVolume ID3 into Production Global Controls and runtime-proved the production write -> verify -> restore -> permanent Save path.

V65 adds a new Unified Single-Session Dashboard. It connects/authenticates once, derives RandKey once, reads one live Device Description, then renders:
- all 7 verified scalar values,
- all 7CH x 15 EQ bands,
- all 4 known sensors.

The new unified dashboard is intentionally READ ONLY. It contains no parameter write encoder call and no SaveParams call. This isolates session-sharing architecture from already-proved write/save behavior.

The existing Global Controls and Live EQ production screens are retained and relabeled V65. Their verified write/readback/rollback/explicit permanent Save behavior is unchanged.

Success marker:
V65_UNIFIED_LOAD ... scalarCount=7 ... eqBands=105 ... sensors=4 ... ready=true genericWrites=false saveParamsSent=false

Save a capture with the button "SAVE V65 UNIFIED CAPTURE TO DOWNLOADS" and inspect the success marker before migrating writes to the shared session.
