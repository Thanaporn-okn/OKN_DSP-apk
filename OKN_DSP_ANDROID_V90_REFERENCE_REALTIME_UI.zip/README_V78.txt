OKN DSP V78 — DIRECT RECONNECT + CONNECTION-EPOCH BINDING

Authoritative base
- V76 is the last fully runtime-qualified production baseline.
- V77 introduced connectionEpoch/controlSessionEpoch/GATT-identity health-gate binding and was successfully built/installed after its compile fix, but runtime qualification exposed a usability/testability problem: while the DSP is already connected, a second BLE scan may not show the same DSP because the peripheral may not advertise while connected.

V78 scope
- No new DSP write family and no payload change.
- Preserve verified scalar IDs 2,3,8,9,10,13,11.
- Preserve safe PEAKING EQ type=12 full 48-byte records only.
- Preserve SaveParams exact trigger 570000000700000000 through SaveParamsPolicy.
- Preserve V74 ARM-before-write ordering, V73 persistent diagnostics, V71 stale-GATT callback isolation, V76 per-session health gate, and V77 connection/session/GATT binding.
- Generic/unknown/preset/delay writes remain locked.

V78 correction
1. Add RECONNECT CURRENT DSP • NO SCAN after one DSP has been selected once.
2. Cache the selected BluetoothDevice + name in memory only; reconnect uses the exact same BluetoothDevice address directly and does not depend on a new advertisement scan.
3. Reconnect immediately calls connection-transition invalidation before opening the new GATT: sessionReady=false, Health Gate LOCKED, stale AB01/AB02 + TX/RX session objects cleared.
4. START CONTROL SESSION and SYNC are disabled immediately during the transition so stale UI state cannot start work on the old session.
5. Existing GATT is disconnected/closed, then V78 waits 600 ms before opening the new GATT to give the old BLE link time to settle.
6. The delayed connect is bound to the requested connectionEpoch. A newer connection transition cancels/invalidates an older delayed connect.
7. Health Gate PASS is still bound to connectionEpoch + controlSessionEpoch + activeGattIdentity and remains READ ONLY with writesSent=0.

Expected V78 qualification — no DSP write required
- Initial SCAN once -> select DSP -> START -> SYNC -> Health Gate PASS.
- Press RECONNECT CURRENT DSP • NO SCAN. Require gate LOCKED immediately and START/SYNC disabled during transition.
- Wait for reconnect/service discovery, then START a fresh session. Gate must remain LOCKED until READ-ONLY gate is run.
- Run V78 SESSION HEALTH GATE READ ONLY. Require PASS and writesSent=0.
- Export diagnostic capture. Require V78_RECONNECT_CURRENT_REQUEST, V78_CONNECTION_EPOCH_INVALIDATE reason=reconnect-current, V78_UNIFIED_CONNECT_START directReconnect=true, and a later V78_SESSION_HEALTH_GATE_RESULT pass=true writesSent=0 bound to current epochs/GATT identity.

Mobile deliverables remain separate: Source ZIP, GitHub Actions workflow YML, SHA256 TXT.
