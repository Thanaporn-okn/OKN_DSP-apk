OKN DSP V89 — PRODUCTION OPERATOR UI
=====================================

Purpose
- Replace the engineering/proof-oriented V88 screen presentation with a cleaner production operator UI for real daily use.
- This is an explicit new UI requirement, so the version is correctly advanced from V88 to V89.

What changed
- New compact OKN DSP V89 header and production visual hierarchy.
- Clear connection flow: Find DSP / Connect last DSP / Load DSP controls / Refresh live values / Safety Check.
- Safety Check moved into the main connection area so it is easy to run before control changes.
- Global controls rendered as clean cards with live value + edit + Apply & verify.
- 7-channel EQ rendered as channel selector + per-band production cards.
- Sensors moved to a simple SYSTEM view.
- Engineering evidence tools remain available but are hidden under Advanced diagnostics by default.
- Permanent Save remains visible and locked until verified changes are eligible.

What did NOT change
- BLE protocol/transport modules are byte-for-byte frozen from V88.
- Protocol/transport combined SHA256 remains f897e05f77e7f4e631d591c29a6d758ef355c7b4fba693e63dabe0572cb8552b.
- Stable signing keystore remains byte-for-byte unchanged.
- Verified scalar allow-list remains [2,3,8,9,10,13,11].
- EQ writes remain safe PEAKING type=12 only, full 48-byte record with fresh verify/rollback.
- SaveParams remains manual guarded only.
- Preset / Delay / unknown writes remain locked; generic writes remain disabled.
- V86 all-status disconnect fail-closed, V87 lifecycle fail-closed and V88 persistent lifecycle observability remain in the core.

Version
- versionCode=89
- versionName=5.20.0-v89-production-operator-ui

Qualification rule
- V89 is not Production Final until GitHub Actions build passes, stable signing is verified, APK installs over V88, and a real-DSP START/SYNC/Safety Check smoke test passes.
