OKN DSP V58 — LIVE EQ 7CH + PERMANENT SAVE
============================================

V58 promotes two already runtime-proven paths into one real user workflow:
1) V51/V49/V50: user-controlled verified LIVE EQ over the proven 7-channel actuator map.
2) V57: SaveParams actuator ID7 persistence proved with two real DSP power-cycles.

Runtime scope
-------------
- BLE service AB00, write AB01, notify AB02.
- AUTH16 -> derive current RandKey -> AES-CFB8 session -> live Device Description.
- EQ map: CH1=ID4, CH2=ID5, CH3=ID6, CH4=ID14, CH5=ID15, CH6=ID16, CH7=ID17.
- 15 bands/channel, 48 bytes/band, offset=(band-1)*48.
- V58 only writes standard PEAKING type=12 bands with safe F/F2/Q/G/R semantics.
- Every EQ APPLY writes one 48-byte record, waits 3 s, reads a fresh Device Description and verifies the full semantic band record.
- Verify failure automatically rolls back the exact previous logical band value and verifies rollback.

Permanent SAVE
--------------
- SAVE is explicit; V58 never auto-saves after APPLY.
- SAVE is allowed only after >=1 V58 EQ change has been readback-verified in the current session and while protocol state is idle.
- SaveParams trigger is exactly: 57 00000007 0000 0000 (ID7, offset0, length0, no payload).
- V57 proved this trigger with target persistence and restored-original persistence across two real DSP power-cycles.
- After SAVE queue success V58 waits 5000 ms commit window and requires GATT status=0 before marking the current verified-change set saved.
- SaveParams saves the DSP's current turning parameters, not only the most recently edited EQ band.

Safety locks
------------
- Generic WriteGate remains disabled.
- Preset, delay and unknown writes remain blocked.
- Non-standard EQ bands remain READ ONLY.
- SAVE is guarded in code even though the UI button is always tappable (avoids Android button-state races seen during V52–V57 proof work).
- Disconnect/restart session clears V58's local unsaved-change authorization; a fresh verified V58 change is required before permanent SAVE can be sent.

Version
-------
versionCode 58
versionName 4.0.0-v58-live-eq-7ch-permanent-save
