OKN DSP V86 — ARTIFACT DELIVERY PATH FIX

Version: 5.17.0-v86-artifact-delivery-fix (versionCode 86)

Why V86 exists
- V85 source preflight, Gradle build, APK signing verification, and APK packaging step all passed on GitHub Actions.
- The workflow failed only at actions/upload-artifact because files were created in the checkout working directory while upload searched /tmp/okn_v85/artifact/*.

V86 change
- Keeps the V85 all-status disconnect fail-closed safety logic and V84-qualified DSP writer/protocol surface unchanged.
- Bumps app version to V86 per project release rules.
- Workflow now creates and validates artifacts explicitly under /tmp/okn_v86/artifact and uploads that exact directory.
- No new DSP command, auto reconnect, auto START/Auth, Scalar/EQ write, or SaveParams behavior is added.
- Stable project signing identity is carried unchanged.

Runtime qualification after install-over V85/V84 remains READ-ONLY:
Connect -> START -> SYNC -> Health PASS -> power DSP off -> observe V86_ALL_STATUS_DISCONNECT_FAIL_CLOSED -> power on -> reconnect -> START -> SYNC -> Health PASS -> export diagnostic.
Do not APPLY or SAVE during qualification.
