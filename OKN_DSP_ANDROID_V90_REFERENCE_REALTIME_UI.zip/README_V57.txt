OKN DSP V57 — GUARDED RESTORE BUTTON CORE FIX

WHY V57 EXISTS
- V56 fresh descriptor proved TARGET_PERSISTED: CH1/ID4/Band4 = -0.1 dB survived DSP power-cycle.
- The screen still showed RESTORE ORIGINAL grey even while local phase was TARGET_PERSISTED.
- Repeated Android/Samsung enabled-state races are therefore removed from the restore safety decision entirely.

V57 CORE FIX
- RESTORE ORIGINAL 0.0 dB + VERIFY + SAVEPARAMS is always visually tappable.
- A tap does NOTHING unless all hard guards pass at that exact moment:
  1) fresh authenticated sessionReady=true
  2) operation=NONE and no descriptor read in progress
  3) local phase TARGET_PERSISTED or RESTORE_NOT_PERSISTED
  4) fresh Device Description CH1/ID4/Band4 is safe PEAKING shape and exactly -0.1 dB
  5) live GATT/AB01/TX cipher are present
- Unsafe taps only log V57_GUARDED_RESTORE_TAP_REJECTED + Toast; NO WRITE and NO SaveParams.
- Safe taps log V57_GUARDED_RESTORE_TAP_ACCEPTED and then use the existing exact restore -> descriptor verify -> SaveParams ID7 path.
- Shared preference key okn_v52_saveparams is unchanged, so TARGET_PERSISTED from V56 carries into V57 on normal app update.

PROTOCOL / SAFETY UNCHANGED
- SaveParams trigger: UFE WRITE 0x57 / actuator ID7 / offset0 / length0 / no payload.
- No generic Save button.
- Restore writes only CH1 / actuator4 / Band4 / offset144 exact original 0.0 record.
- After restore verify, SaveParams is sent once and phase becomes WAIT_RESTORE_REBOOT.
- Final proof still requires a real second DSP power-cycle and fresh 0.0 dB readback.

V56 -> V57 INSTALL/REINSTALL RECOVERY
- If app data is preserved, TARGET_PERSISTED carries automatically.
- If Android reinstall resets local phase to IDLE, fresh -0.1 dB enables IMPORT V56 TARGET-PERSISTED PROOF.
- That import performs NO WRITE and NO SaveParams; it only restores the already-proven local phase from the user's V56 power-cycle result, then the guarded restore still rechecks fresh live -0.1 dB before writing.
