# OKN DSP V81 — Connection Watchdog Fail-Closed Recovery

Release identity
- versionCode 81
- versionName 5.12.0-v81-connection-watchdog-fail-closed
- Base: V80 Production Baseline (persistent last-DSP reconnect qualified on real DSP)

Purpose
V80 can reconnect to the persisted DSP without scanning, but its connection setup had no bounded readiness timeout. If Android/GATT never reached a usable AB00/AB01/AB02 + CCCD-ready state, the UI could remain CONNECTING indefinitely.

V81 change
- Arm a 15,000 ms connection-readiness watchdog for every scan-select and RECONNECT LAST DSP connect attempt.
- Success condition is a successful CCCD write after AB00 service + AB01 write + AB02 notify discovery.
- On timeout, GATT state error, service/profile failure, or CCCD failure: fail closed, detach/close the active GATT, invalidate connection epoch/session/health gate, clear stale session objects, and return to a retryable UI.
- Stale callbacks from the detached GATT remain blocked by active-GATT identity isolation.
- Recovery sends no START/Auth/UFE/EQ/SaveParams write automatically.

Production writer scope remains unchanged
- Scalars: IDs 2,3,8,9,10,13,11 only.
- EQ: safe PEAKING type=12 only on mapped 7CH EQ actuators.
- SaveParams: manual guarded only.
- genericWrites=false.
- Preset / Delay / unknown writes remain locked.

Runtime qualification target
1. Normal RECONNECT LAST DSP must reach CONNECTION_READY before 15 s and then START/Auth/Sync/Health Gate PASS.
2. With DSP unavailable, reconnect must timeout and return fail-closed with Session gate LOCKED and no DSP writes.
3. After DSP is available again, RECONNECT LAST DSP must recover normally and Health Gate PASS.
