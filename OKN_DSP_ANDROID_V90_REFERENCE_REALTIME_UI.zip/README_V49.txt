OKN DSP Android V49 — FINAL EQ WRITE + RESTORE PROOF

Purpose
- Close the EQ runtime proof in one single guarded session after V46 and V48.
- V46 already proved the exact CH1/ID4/Band4 target record (-0.5 dB) is accepted and reflected by live Device Description.
- V48 already proved the exact original record (0.0 dB) restores correctly after a 3 second settle.
- V49 combines both paths: exact target -> verify -> exact restore -> verify.

Scope / safety
- ONLY CH1 / actuator ID4 / Band4 / offset 144 / 48 bytes.
- Baseline must exactly match the V48-restored original 0.0 dB record or V49 blocks the proof.
- Target is the exact V46-proven -0.5 dB record.
- Restore is the exact V48-proven 0.0 dB record.
- 3 second settle before target verification.
- 3 second settle before restore write.
- 3 second settle before restore verification.
- One restore retry maximum.
- 60 second global failsafe.
- SaveParams actuator ID7 is NEVER sent.
- Normal EQ, preset, delay and unknown writes remain locked.

Expected success markers
V49_TARGET_DESCRIPTOR_VERIFY ... expectedBoost=-0.5 actualBoost=-0.5 verified=true
V49_RESTORE_DESCRIPTOR_VERIFY ... expectedBoost=0.0 actualBoost=0.0 verified=true
V49_FINAL_EQ_WRITE_RESTORE_PROOF_COMPLETE ... targetVerified=true restored=true ... saveParamsSent=false

After install
1) SCAN DSP and connect LE-GoloPine_DSP_A.
2) START V49 FINAL EQ PROOF SESSION.
3) Confirm START READ-ONLY BASELINE CHECK.
4) Wait for V49 READY.
5) RUN FINAL CH1 BAND4 PROOF (-0.5 dB -> EXACT RESTORE), once.
6) Confirm RUN FINAL PROOF.
7) Do not touch EQ/volume/preset until V49 COMPLETE.
8) SAVE V49 CAPTURE TO DOWNLOADS and return the txt capture.
