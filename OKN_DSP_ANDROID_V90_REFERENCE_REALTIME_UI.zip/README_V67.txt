OKN_DSP V67 — UNIFIED VERIFIED GLOBAL-WRITE MIGRATION (PHASE 1)
Date: 2026-09-07

AUTHORITATIVE BASE
- OKN_DSP_ANDROID_V66_UNIFIED_REFRESH_FEEDBACK_FIX.zip
- Verified V66 source SHA256:
  fe37bb24213c6235446b33d5cc9068a916790a0baf6093d8d92a23769bc3d603
- V66 runtime qualification already PASSED for Unified same-session REFRESH.

V67 SCOPE
- versionCode=67
- versionName=4.8.0-v67-unified-verified-global-write-migration
- Unified writes ONLY verified scalar IDs: [2,3,8,9,10,13,11]
- EQ remains READ ONLY in Unified.
- Sensors remain READ ONLY.
- Generic WriteGate remains false.
- Unknown/preset/delay writes remain locked.
- V66 REFRESH ALL same-session behavior is preserved.
- No auto-save.
- SaveParams is manual guarded only after a verified scalar change.

V67 UNIFIED SCALAR PIPELINE
1. Same BLE/auth/RandKey session must already be ready.
2. Confirm selected ID is in exact seven-scalar allow-list.
3. Request a fresh full Device Description before every write.
4. Require complete 7 scalar + 105 EQ + 4 sensor descriptor counts.
5. Capture exact fresh live scalar baseline.
6. Encode only UFE FLOAT32 WRITE_ACTUATOR 0x57 for selected verified scalar.
7. Require the GATT write callback for that specific queued write to report success.
8. Request another fresh full Device Description in the same session.
9. Verify target readback with VerifiedScalarControls tolerance.
10. Only after target verify passes: mark RAM_DIRTY and increment verified-change count.
11. If target/GATT/verify fails after a baseline exists: write exact fresh baseline back.
12. Require restore GATT success, request fresh full descriptor, and verify exact restore.
13. RESTORE VERIFY FAILED/UNCONFIRMED => STOP; do not SaveParams.

GATT CALLBACK CORRELATION
- AUTH, descriptor requests, scalar writes, restore writes and SaveParams all use AB01.
- V67 queues an ordered GATT write ticket for every AB01 write.
- Only the matching SCALAR_TARGET / SCALAR_RESTORE / SAVE_PARAMS ticket can satisfy that action's required GATT result.
- OTHER tickets (AUTH/descriptor requests) cannot be mistaken for scalar/save results.

MANUAL GUARDED SAVEPARAMS
- Central policy only: SaveParamsPolicy.encodeTrigger().
- Exact plaintext must remain: 570000000700000000
- Trigger is enabled only after >=1 verified scalar change in the current V67 Unified session.
- GATT success is required.
- Then preserve the proven 5 second settle window.
- SaveParams persists current DSP turning parameters as a whole, including current EQ state.
- SAVE UNCONFIRMED => do not retry blindly; export capture for inspection.

PRESERVED PRODUCTION PATHS
- Existing separate ScalarControlActivity remains intact from V66.
- Existing separate LiveEqActivity remains intact from V66.
- No Unified EQ serializer was added in this phase.

STATIC DELIVERY STATUS
- V67 source migration and static policy/preflight checks: GENERATED.
- Runtime qualification on the real DSP: NOT YET CLAIMED by this source package.
- Runtime success must be decided only from the exported V67 capture after the APK is built and tested on the real DSP.
