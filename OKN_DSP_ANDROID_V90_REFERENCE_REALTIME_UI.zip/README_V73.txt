OKN DSP V73 — PERSISTENT DIAGNOSTICS + SAFE UNCONFIRMED-GATT POLICY

Authoritative base
- V72 Production UI Migration source.
- V71 remains the last fully runtime-qualified production writer baseline.
- V72 runtime proved Production UI connect/session/sync/live Global binding, but the first scalar Apply attempt reached:
  V73 predecessor observed state 1: FAILSAFE RESTORE queued / waiting required GATT success
  V73 predecessor observed state 2: SCALAR RESTORE GATT UNCONFIRMED — STOP / DO NOT SAVE
- After closing/reopening and performing a fresh read-only session, BassCutoff ID9 read 117.300 Hz again and RAM was clean/unarmed.
- The V72 failure capture was lost because Production capture lived only in Activity memory; V45 Evidence Lab uses a different capture buffer.

V73 goals
1. Preserve the V72 Production UI and the V71-qualified write scope.
2. Persist critical Production diagnostics to internal app storage immediately on GATT/ticket/save failure so they survive app restart.
3. STATUS export includes both the current session and the last persisted critical failure.
4. Add GATT timing/ticket evidence: callbackAgeMs, ticketDepth, active/armed GATT identity, timeout age.
5. New safety invariant: if a TARGET GATT result is unconfirmed (timeout) or explicitly non-success, STOP the session and DO NOT send a second write automatically.
6. Automatic rollback remains available only after the target GATT result was confirmed successful and fresh descriptor verification later shows a mismatch/failure.
7. No new protocol writer, no new actuator family, no auto-save.

Verified write scope preserved
- Global FLOAT32 IDs: 2,3,8,9,10,13,11
- EQ actuator IDs: 4,5,6,14,15,16,17
- EQ writes: verified safe PEAKING type=12 only, full 48-byte live record
- SaveParams: ID7 exact trigger via SaveParamsPolicy only
- Sensors: READ ONLY
- genericWrites=false
- Preset / Delay / unknown writes remain locked

Runtime qualification for V73
A. Install V73 and connect/start/sync read-only first.
B. Confirm 7 Scalars + 105 EQ + 4 Sensors and ID9 baseline from fresh live state.
C. Perform one tiny temporary scalar test only after read-only qualification.
D. If GATT is confirmed, continue normal fresh descriptor verification and exact rollback procedure.
E. If TARGET GATT is unconfirmed, V73 must STOP with NO AUTO-RESTORE; reconnect/start/sync read-only and inspect actual DSP state.
F. Export STATUS diagnostic. If the app is closed after a critical failure, reopen V73 and STATUS export must still include the persisted last failure.
G. Do not Permanent Save unless a verified change completes normally.
