OKN DSP V52 — SAVEPARAMS PERSISTENCE PROOF

WHAT V52 PROVES
- V51 already proved user-controlled LIVE EQ write/readback on the real DSP.
- Device Description identifies actuator ID7 as type=2100, name=SaveParams, cpar=Trigger, desc="Save all the turning parameters".
- V52 tests one narrow Trigger encoding only: UFE WRITE 0x57 + ID7 + offset0 + length0 + no payload.
- Exact plaintext under test: 570000000700000000.
- This is NOT called proven merely because the BLE write queues successfully. Persistence is only proven if a real DSP power-cycle preserves the -0.1 dB test value and a second power-cycle preserves the restored 0.0 dB original.

SAFETY SCOPE
- Test point only: CH1 / actuator ID4 / Band4 / offset144.
- Exact original target is 0.0 dB on the already-proven peaking band shape F≈100Hz, Q≈2.23.
- Test value is only -0.1 dB.
- If V51 left the live/RAM value at -0.2 dB, V52 first offers PREPARE 0.0 dB with NO SaveParams.
- Any unexpected band shape/value blocks the proof.
- There is NO generic SaveParams button.

USER FLOW
1) Open "V52 SAVEPARAMS PERSISTENCE PROOF".
2) SCAN DSP -> select LE-GoloPine_DSP_A.
3) Wait "CONNECTED • AB02 notifications READY".
4) Tap "START V52 PERSISTENCE SESSION" -> "START READ-ONLY PERSISTENCE CHECK".
5) If V52 reports known V51 live -0.2 dB, tap "PREPARE ORIGINAL CH1 BAND4 = 0.0 dB (NO SAVE)" and confirm. Wait for "V52 PREPARED".
6) When status says "V52 READY • exact original 0.0 dB verified", tap "WRITE TEST -0.1 dB + VERIFY + SAVEPARAMS" and confirm.
7) Wait until status explicitly says "NOW POWER-CYCLE DSP". Do not power-cycle before that message.
8) Turn DSP power OFF, wait a few seconds, turn DSP power ON.
9) In V52, SCAN/CONNECT again and START V52 PERSISTENCE SESSION again.
10) Success for phase 1 is "V52 TARGET PERSISTED VERIFIED • -0.1 dB survived DSP power-cycle".
11) Tap "RESTORE ORIGINAL 0.0 dB + VERIFY + SAVEPARAMS" and confirm.
12) Wait until V52 explicitly says "NOW POWER-CYCLE DSP" again.
13) Turn DSP power OFF/ON a second time.
14) SCAN/CONNECT and START V52 PERSISTENCE SESSION again.
15) Final success is "V52 COMPLETE • SaveParams persistence proven • original 0.0 dB persisted after second reboot".
16) Tap "SAVE V52 CAPTURE TO DOWNLOADS" and send the TXT capture.

FINAL SUCCESS MARKERS
V52_TARGET_DESCRIPTOR_VERIFY ... verified=true
V52_SAVEPARAMS_TRIGGER_PLAIN=570000000700000000 after=TARGET ...
V52_TARGET_POWER_CYCLE_VERIFY expected=-0.1 actual=-0.1 persisted=true
V52_RESTORE_DESCRIPTOR_VERIFY ... verified=true
V52_SAVEPARAMS_TRIGGER_PLAIN=570000000700000000 after=RESTORE ...
V52_RESTORE_POWER_CYCLE_VERIFY expected=0.0 actual=0.0 persisted=true
V52_SAVEPARAMS_PERSISTENCE_PROOF_COMPLETE ... targetPersisted=true originalRestoredPersisted=true ... powerCycles=2

STOP CONDITIONS
- V52 BLOCKED
- V52 TARGET VERIFY FAILED
- V52 SaveParams queue/GATT failed
- V52 SAVEPARAMS NOT PROVEN
- unexpected value after reboot
If any stop condition appears, do not improvise or press unrelated controls. Save the V52 capture and send it for inspection.
