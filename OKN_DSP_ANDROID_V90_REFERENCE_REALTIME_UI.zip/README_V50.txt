OKN DSP V50 — 7CH EQ ACTUATOR MAP PROOF

Purpose
- V49 already runtime-proved CH1 / actuator ID4 / Band4 / offset144.
- V50 verifies the remaining channel actuator IDs on the real DSP:
  CH2 ID5 Band4 offset144
  CH3 ID6 Band5 offset192
  CH4 ID14 Band4 offset144
  CH5 ID15 Band4 offset144
  CH6 ID16 Band5 offset192
  CH7 ID17 Band4 offset144

Guarded sequence
1. Connect AB00/AB01/AB02 and enable AB02 notifications.
2. AUTH16 -> live 32-byte auth response -> derive current RandKey.
3. Read live Device Description and preflight all six remaining probe bands.
4. Only if every probe is a PEAKING type12, expected F/Q, B=0 dB, G=0 and R=0:
   - write -0.25 dB target for one channel
   - wait 3 seconds
   - verify target from live Device Description
   - wait 3 seconds
   - restore the live semantic baseline record
   - wait 3 seconds
   - verify restore
   - only then advance to the next channel
5. One restore retry maximum. Any target/restore failure stops the sequence.

Safety
- Generic WriteGate remains disabled.
- SaveParams actuator ID7 is never written.
- Normal EQ UI, preset, delay and unknown writes remain locked.
- V50 target is only -0.25 dB and each channel is restored before the next begins.

Success marker
V50_ALL_7CH_ACTUATOR_MAP_COMPLETE ch1FromV49=true ch2Id5=true ch3Id6=true ch4Id14=true ch5Id15=true ch6Id16=true ch7Id17=true saveParamsSent=false
