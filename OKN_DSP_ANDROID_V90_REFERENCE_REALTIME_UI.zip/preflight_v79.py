#!/usr/bin/env python3
from pathlib import Path
import hashlib,re,struct
root=Path(__file__).resolve().parent

def req(rel):
    p=root/rel
    assert p.is_file(),f'missing {rel}'
    return p

def txt(rel): return req(rel).read_text(errors='replace')
def has(rel,m): assert m in txt(rel),f'missing {m!r} in {rel}'
def sha(rel,e):
    g=hashlib.sha256(req(rel).read_bytes()).hexdigest()
    assert g==e,f'hash mismatch {rel}: {g}'
def png_size(rel):
    b=req(rel).read_bytes()[:24]
    assert b[:8]==b'\x89PNG\r\n\x1a\n',f'not png {rel}'
    return struct.unpack('>II',b[16:24])

U='app/src/main/java/com/okn/dsp/UnifiedControlActivity.kt'
G='app/build.gradle.kts'
M='app/src/main/java/com/okn/dsp/MainActivity.kt'
WG='app/src/main/java/com/okn/dsp/protocol/WriteGate.kt'
SP='app/src/main/java/com/okn/dsp/protocol/VerifiedScalarControls.kt'
CAP78='evidence/OKN_DSP_V78_PRODUCTION_SAFE_DIAGNOSTIC_CAPTURE_20260908_014910.txt'
MASTER='evidence/OKN_DSP_V79_ICON_MASTER_USER_UPLOAD.png'
PLAN='evidence/OKN_DSP_V79_PRODUCTION_ICON_REFRESH_PLAN.txt'
PLANJ='evidence/OKN_DSP_V79_PRODUCTION_ICON_REFRESH_PLAN.json'
for r in [U,G,M,WG,SP,CAP78,MASTER,'README_V79.txt',PLAN,PLANJ]: req(r)

# Build/release identity.
has(G,'versionCode = 79')
has(G,'5.10.0-v79-production-icon-refresh')
has(M,'V79 production direct-reconnect connection-epoch health-gate-binding launcher')
has(U,'V79 • PRODUCTION SAFE')
has(U,'RUN V79 SESSION HEALTH GATE • READ ONLY')
has(U,'connectionEpochBinding=required')
has(U,'sessionHealthGate=V76_PASSED connectionEpochHealthGate=V78_PASSED iconRefresh=V79')
u=txt(U)

# Diagnostic lineage must compile and remain version-correct.
for m in [
    'private val criticalCaptureFileName = "okn_dsp_v79_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileName = "okn_dsp_v78_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV77 = "okn_dsp_v77_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV76 = "okn_dsp_v76_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV75 = "okn_dsp_v75_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV74 = "okn_dsp_v74_last_critical_capture.txt"',
]: has(U,m)
for sym in ['criticalCaptureFileName','legacyCriticalCaptureFileName','legacyCriticalCaptureFileNameV77','legacyCriticalCaptureFileNameV76','legacyCriticalCaptureFileNameV75','legacyCriticalCaptureFileNameV74']:
    assert u.count('private val '+sym+' =') == 1, sym
for m in ['val legacyV78 =','val legacyV77 =','val legacyV76 =','val legacyV75 =','val legacyV74 =']:
    assert m in u,m

# User-uploaded icon master and all Android launcher assets.
sha(MASTER,'d1f04138898fc1f1b4b5f5f3bd61639a9edad0d8d0586274b041e245ad9ec74a')
icons={
'app/src/main/res/mipmap-mdpi/ic_launcher.png':((48,48),'16b930fd04c5cfd86c0278781a541a1166214af884a305b7688ba424303a0786'),
'app/src/main/res/mipmap-hdpi/ic_launcher.png':((72,72),'bf64e92b76648a2012b30ec9ad9ac4ac681b02092fdd6c05ce1d32fe1fa803e6'),
'app/src/main/res/mipmap-xhdpi/ic_launcher.png':((96,96),'796fffe8b7a5a6acd4322bde54f4796d5281a5ff77b9fa1c94afe8b4b808ff1f'),
'app/src/main/res/mipmap-xxhdpi/ic_launcher.png':((144,144),'ba9aa193371bf466385e91dc2321b028d88a09cf348025f723191a45601839e0'),
'app/src/main/res/mipmap-xxxhdpi/ic_launcher.png':((192,192),'47bc7e64ee3cc123fdc61ad37cd656879fab2a758c24cdf77dc90e089a97b3e3'),
'app/src/main/res/drawable/icon_foreground.png':((432,432),'c610f27543c30b7d726c140313fcca73cf76ef37c47939199c5a46fc111ac543'),
}
for rel,(sz,h) in icons.items():
    assert png_size(rel)==sz,(rel,png_size(rel),sz)
    sha(rel,h)
has('app/src/main/AndroidManifest.xml','android:icon="@mipmap/ic_launcher"')
has('app/src/main/AndroidManifest.xml','android:roundIcon="@mipmap/ic_launcher"')
has('app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml','<foreground android:drawable="@drawable/icon_foreground"/>')

# Production write scope remains frozen.
has(WG,'const val enabled: Boolean = false')
has(WG,'const val unifiedVerifiedScalarWritesEnabled: Boolean = true')
has(WG,'const val unifiedVerifiedEqWritesEnabled: Boolean = true')
ids=[int(x) for x in re.findall(r'VerifiedScalarControl\((\d+),',txt(SP))]
assert ids==[2,3,8,9,10,13,11],ids
assert u.count('UfeCodec.encodeFloat32Write')==2
assert u.count('LiveEqPolicy.encodeWrite')==1
assert u.count('LiveEqPolicy.encodeRestore')==1
assert u.count('SaveParamsPolicy.encodeTrigger()')==1
assert u.count('UfeCodec.encodeWrite(')==0
assert u.count('if (!isCurrentGatt(g,')==7

# Direct reconnect and exact connection/session/GATT binding remain present.
for m in [
    'private lateinit var reconnectButton: Button',
    'private var selectedDevice: BluetoothDevice? = null',
    'text = "RECONNECT CURRENT DSP • NO SCAN"',
    'setOnClickListener { reconnectCurrentDevice() }',
    'V79_RECONNECT_CURRENT_REQUEST',
    'transitionReason = "reconnect-current"',
    'directReconnect = true',
    'private var connectionEpoch = 0L',
    'private var controlSessionEpoch = 0L',
    'healthGateBoundConnectionEpoch == connectionEpoch',
    'healthGateBoundSessionEpoch == controlSessionEpoch',
    'healthGateBoundGattIdentity == activeIdentity',
]: assert m in u,m
r=u[u.index('    private fun reconnectCurrentDevice()'):u.index('    private fun startScan()',u.index('    private fun reconnectCurrentDevice()'))]
assert 'startScan(' not in r
assert 'connect(device, name, transitionReason = "reconnect-current", directReconnect = true)' in r

# connect transition invalidation remains before connectGatt.
start=u.index('    private fun connect(device: BluetoothDevice, name: String, transitionReason: String, directReconnect: Boolean)')
connect=u[start:u.index('    private val gattCallback = object',start)]
for m in ['invalidateForConnectionTransition(transitionReason)','oldGatt?.disconnect()','oldGatt?.close()','V79_RECONNECT_SETTLE_WAIT ms=600','val requestedEpoch = connectionEpoch','device.connectGatt']:
    assert m in connect,m
assert connect.index('invalidateForConnectionTransition(transitionReason)') < connect.index('device.connectGatt')

# Gate is read-only and backend uses current binding.
f=u[u.index('    private fun runFieldSelfCheck()'):u.index('    private fun confirmArmPowerCycleProof()')]
for m in ['scalarValues.size == 7','eqCount == 105','sensors.size == 4','writesSent=0','healthGateBoundGattIdentity = activeGattIdentity']:
    assert m in f,m
for bad in ['writeNoResponse(','UfeCodec.','LiveEqPolicy.encode','SaveParamsPolicy.encodeTrigger','writeCharacteristic(']:
    assert bad not in f,bad
assert u.count('sessionHealthGateValid()') >= 15

# V74 ARM-before-write ordering still centralized.
h=u[u.index('    private fun writeNoResponse('):u.index('    private fun record(kind: String, text: String) {')]
a=h.index('gattWriteTickets.addLast(kind)')
b=h.index('V79_UNIFIED_GATT_TICKET_PREPARED')
c=h.index('if (purpose != null) armGattActionTimeout(purpose)')
d=h.index('g.writeCharacteristic(ch, bytes, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE)')
assert a<b<c<d,(a,b,c,d)

# Real V78 runtime baseline: direct reconnect invalidates old epoch, creates new GATT/session, and re-PASSes read-only.
cap=txt(CAP78)
for m in [
    'V78_RECONNECT_CURRENT_REQUEST',
    'V78_CONNECTION_EPOCH_INVALIDATE reason=reconnect-current connectionEpoch=2 sessionEpoch=1 sessionReady=false healthGateValid=false staleSessionObjectsCleared=true',
    'directReconnect=true connectionEpoch=2 sessionEpoch=1',
    'V78_SESSION_HEALTH_GATE_RESET reason=new-session connectionEpoch=2 sessionEpoch=2',
    'V78_UNIFIED_LOAD mode=REFRESH scalarCount=7 expectedScalars=7 eqBands=105 expectedEqBands=105',
    'V78_SESSION_HEALTH_GATE_RESULT pass=true writesSent=0 healthGatePassed=true healthGateValid=true sessionReady=true scalarCount=7 eqBands=105 sensors=4',
    'connectionEpoch=2 sessionEpoch=2 boundConnectionEpoch=2 boundSessionEpoch=2',
]: assert m in cap,m
sha(CAP78,'0c06c91de5302cbe1be620444486cd641f3b7f7c130432138c70b7b31050d52b')

# Frozen production modules remain byte-identical to V78.
for rr,e in {
'app/src/main/java/com/okn/dsp/ScalarControlActivity.kt':'01f6aca6f2131bd41ca4fd1d674d879cade425ccc7ddef77e63718e8e124ffed',
'app/src/main/java/com/okn/dsp/LiveEqActivity.kt':'3240ca56c81b7960098ae9fb6ea7421d32e74b11e42810ce4c5b71b35d7ab8d0',
'app/src/main/java/com/okn/dsp/protocol/SaveParamsPolicy.kt':'88005dba77d2b84597f5bd5e23eaaacec7d25b59dc0f38b8affbde2d2cfbeb85',
'app/src/main/java/com/okn/dsp/protocol/LiveEqPolicy.kt':'cfb046aa09acaf8429176a9b99e988ea06347f3daeea988b7c118d056400d2bc',
WG:'8aa82bb069dd64dc2d1274801f1f4420a764f52670246e9c813b0723531be472',
SP:'4c096b001523704dcb6aa36496dd17263d6df84a0a1fee20c2fc40d60e898f6b'
}.items(): sha(rr,e)

# Basic source sanity for previous V77 compile regression class.
for sym in ['legacyCriticalCaptureFileName','legacyCriticalCaptureFileNameV77','legacyCriticalCaptureFileNameV76','legacyCriticalCaptureFileNameV75','legacyCriticalCaptureFileNameV74','pendingConnectRunnable','selectedDevice','selectedDeviceName']:
    assert u.count(sym) >= 2,sym
assert u.count('{') == u.count('}'), (u.count('{'),u.count('}'))

print('OK: V79 production icon refresh preflight passed')
