OKN DSP V77 — CONNECTION-EPOCH HEALTH-GATE BINDING

Authoritative base
- V76 Production Session Health Gate passed real-device qualification.
- V76 runtime proof showed: initial health-gate PASS with writesSent=0, new-session reset, and second PASS after re-auth/reload.
- V76 source gap found during audit: connect(device, name) detached/closed the old GATT and created a new GATT without immediately invalidating sessionReady / health-gate binding / AB01/AB02 / TX/RX objects at connect-start. The guaranteed resets were on disconnect callback or START new session.

V77 scope
- No new DSP write family and no payload change.
- Preserve verified scalar IDs 2,3,8,9,10,13,11.
- Preserve safe PEAKING EQ type=12 full 48-byte records only.
- Preserve SaveParams exact trigger 570000000700000000 through SaveParamsPolicy.
- Preserve V74 ARM-before-write ordering, V73 persistent diagnostics, V71 stale-GATT callback isolation and V76 per-session health gate.
- Generic/unknown/preset/delay writes remain locked.

New V77 hardening
1. Every connect/reconnect start increments connectionEpoch and immediately invalidates the old control session before connectGatt() is called.
2. Immediate invalidation sets sessionReady=false and health gate LOCKED, clears AB01/AB02 + TX/RX ciphers + descriptor/live-value state, cancels pending descriptor/GATT timeout state, and records V77_CONNECTION_EPOCH_INVALIDATE.
3. Every START CONTROL SESSION increments controlSessionEpoch and resets the health gate.
4. A READ-ONLY gate PASS binds to three exact values: connectionEpoch, controlSessionEpoch and active BluetoothGatt identity.
5. UI and backend Scalar/EQ/Save guards use sessionHealthGateValid(), which requires all three bindings to still match the current connection/session/GATT.
6. A stale PASS boolean cannot unlock writes after a connection transition.
7. Field/session health gate still sends no DSP write and records writesSent=0.

Expected V77 qualification — no DSP write required
A. Install V77, connect, START, SYNC and run V77 SESSION HEALTH GATE READ ONLY. Require PASS and controls unlocked.
B. Without pressing APPLY or SAVE, SCAN DSP and tap the same DSP again to start a reconnect.
C. Immediately after reconnect starts, require Session gate LOCKED and production APPLY controls disabled before a new START session.
D. Wait AB02 READY, START V77 again and load 7 Scalars + 105 EQ + 4 Sensors. Gate must remain LOCKED.
E. Run the READ-ONLY gate again; require PASS and controls unlock.
F. Export diagnostic capture. Require V77_CONNECTION_EPOCH_INVALIDATE reason=connect-start before V77_UNIFIED_CONNECT_START/new active GATT assignment, healthGateValid=false during transition, and a later V77_SESSION_HEALTH_GATE_RESULT pass=true writesSent=0 with bound epochs/GATT identity equal to current values.

Mobile deliverables remain separate: Source ZIP, GitHub Actions workflow YML, SHA256 TXT.
