OKN DSP ANDROID V51 — VERIFIED LIVE EQ 7CH

Purpose
- Move from V49/V50 proof mode into the first real user-controlled EQ page.
- Use the runtime-proven 7CH actuator map:
  CH1=ID4, CH2=ID5, CH3=ID6, CH4=ID14, CH5=ID15, CH6=ID16, CH7=ID17.
- Load all 7 x 15 bands from the live Device Description.
- Expose only standard PEAKING bands that are safe under the verified serializer:
  typ=12, F2≈0, G≈0, R≈0, valid F/Q.
- Non-standard bands remain visible but READ ONLY.

Verified live write flow
1. User chooses one writable band and enters -12.0..+12.0 dB (0.1 dB step).
2. V51 builds the 48-byte record using the verified 44.1 kHz RBJ peaking coefficients.
3. Sends UFE WRITE 0x57 with actuator + offset=(band-1)*48 + len=48.
4. Waits 3000 ms.
5. Reads Device Description and verifies every band field.
6. If verification succeeds, the new value stays live in DSP RAM.
7. If verification fails, V51 writes the exact previous 48-byte record, verifies rollback,
   and retries rollback once if needed.
8. SaveParams ID7 is never sent. Changes are LIVE/RAM only and are not claimed persistent.

Safety
- One band write at a time.
- Back navigation blocked while verify/rollback is active.
- 45 s failsafe attempts rollback if a write is still pending.
- Generic WriteGate.enabled remains false.
- Preset and unknown writes remain locked.
- Type17/non-standard EQ bands are READ ONLY in V51.

Phone test
1. Open "V51 VERIFIED LIVE EQ 7CH".
2. SCAN DSP -> connect LE-GoloPine_DSP_A.
3. Wait "CONNECTED • AB02 notifications READY".
4. START V51 VERIFIED LIVE EQ SESSION -> START READ-ONLY LIVE EQ LOAD.
5. Wait "V51 LIVE EQ READY • 7CH×15 loaded".
6. Choose CH1 first and use a band marked LIVE WRITABLE.
7. Change only 0.1 dB for the first runtime test, then APPLY + VERIFY.
8. Wait for "V51 VERIFIED ... LIVE/RAM • SaveParams NOT sent".
9. SAVE V51 CAPTURE TO DOWNLOADS and send the TXT for review.

Success markers
- V51_LIVE_EQ_LOAD ... totalBands=105 ... ready=true
- V51_LIVE_EQ_WRITE_PLAIN ... saveParams=false
- V51_TARGET_DESCRIPTOR_VERIFY ... verified=true
- V51_LIVE_EQ_WRITE_COMPLETE ... verified=true ... saveParamsSent=false persistence=RAM_ONLY

Failure/rollback markers
- V51_TARGET_VERIFY_FAILED ... rollbackRequired=true
- V51_ROLLBACK_DESCRIPTOR_VERIFY ... verified=true
- V51_LIVE_EQ_WRITE_ABORTED_AND_ROLLED_BACK ... restored=true
- V51_LIVE_EQ_STOPPED ... (stop and save capture)
