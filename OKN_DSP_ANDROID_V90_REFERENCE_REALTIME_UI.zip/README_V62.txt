OKN DSP V62 — PRODUCTION CONTROL RENDER THREAD FIX

Purpose
- Fix V61 production Global Controls screen where status could reach READY but the six dynamic scalar rows (including MasterVolume ID2) could disappear/not render.
- Root cause addressed: BluetoothGatt notification/descriptor completion can execute off the Android main thread, while onDescriptorComplete updates status and rebuilds the dynamic controlsHost view hierarchy.
- V62 dispatches descriptor-complete UI handling to the main looper in BOTH ScalarControlActivity and LiveEqActivity.
- Adds render diagnostics: V62_SCALAR_CONTROLS_RENDER_START / COMPLETE with mainThread=true and childCount=6 expected after READY.

No protocol behavior changed.
- Scalar allow-list remains IDs 2,8,9,10,13,11 only.
- Generic writes remain locked.
- SaveParams remains actuator ID7 with exact plaintext 570000000700000000.
- APPLY still writes then fresh descriptor-verifies; no auto-save.
- Permanent SAVE remains explicit and guarded.
- LIVE EQ 7CH protocol path unchanged except UI completion is dispatched to main thread.

Expected Global Controls UI after START + READY
1) MasterVolume • ID 2
2) BassVolume • ID 8
3) BassCutoff • ID 9
4) BassBoost • ID 10
5) MiddleBoost • ID 13
6) TrebleBoost • ID 11
Each row shows current value, editable field, and APPLY + VERIFY.
