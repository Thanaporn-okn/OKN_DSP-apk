OKN DSP V82 — STABLE UPGRADE SIGNING + LAST-DSP CACHE STATE

BASELINE
- V80 is the latest runtime-qualified persistent-last-DSP reconnect baseline.
- V81 connection-watchdog fail-closed code is carried forward unchanged in V82 and still requires runtime qualification.
- V82 does not add any DSP protocol/write family.

ROOT CAUSE FIXED
Previous GitHub Actions builds used :app:assembleDebug on fresh runners without a fixed signing key. A fresh runner can create a different debug certificate, so installing a later APK may require uninstall/reinstall and therefore erase SharedPreferences such as last_dsp_address / last_dsp_name.

V82 CHANGE
- Adds project-local stable DEBUG signing identity for V82 and later iterative test builds.
- Debug signing keystore: app/okn_dsp_stable_debug.keystore
- Keystore SHA256: ba1c52f2607c09953c52fdd79c5f72026aaf0adb8aa44bcba277f7d9b49d9511
- Certificate SHA-256: C3:DA:85:AF:2E:97:8D:BD:0E:D9:BB:69:5E:5C:79:A2:63:18:95:95:C1:16:AD:93:A1:DE:D7:5A:2E:B9:83:97
- Alias/password are intentionally Android debug defaults. This is NOT a Play Store/release signing key.
- Future V83+ source packages must copy this exact keystore byte-for-byte to preserve update/data continuity.

LAST-DSP UI
- Saved cache present: RECONNECT LAST DSP • NO SCAN
- Saved cache absent: NO SAVED DSP • SCAN ONCE
- Missing cache is explicitly logged as V82_LAST_DSP_CACHE_MISSING writesSent=0.

IMPORTANT MIGRATION
V82 starts a new stable-signing lineage. The currently installed V81 APK was signed by a different runner debug key, so Android may require uninstalling V81 once before V82 can be installed. That one-time uninstall cannot recover an already-erased Last-DSP cache. After V82 is installed, scan/select the DSP once to seed the cache. From V83 onward, updates using this same stable key should preserve app data.

PRODUCTION DSP WRITE SCOPE (UNCHANGED)
- Scalars: IDs 2,3,8,9,10,13,11 only
- EQ: safe PEAKING only, IDs 4,5,6,14,15,16,17
- Sensors: READ ONLY
- genericWrites=false
- SaveParams manual guarded
- Preset / Delay / unknown writes remain locked
