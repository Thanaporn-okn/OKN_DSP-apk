#!/usr/bin/env python3
from pathlib import Path
import hashlib,re
root=Path(__file__).resolve().parent

def req(rel):
    p=root/rel
    assert p.is_file(), f'missing {rel}'
    return p

def txt(rel): return req(rel).read_text(errors='replace')
def has(rel,m): assert m in txt(rel), f'missing {m!r} in {rel}'
def sha(rel,e):
    g=hashlib.sha256(req(rel).read_bytes()).hexdigest()
    assert g==e, f'hash mismatch {rel}: {g}'

def combined_hash(paths):
    h=hashlib.sha256()
    for p in sorted(paths, key=lambda x:x.relative_to(root).as_posix()):
        rel=p.relative_to(root).as_posix()
        h.update(rel.encode()+b'\0'+p.read_bytes()+b'\0')
    return h.hexdigest()

U='app/src/main/java/com/okn/dsp/UnifiedControlActivity.kt'
G='app/build.gradle.kts'
M='app/src/main/java/com/okn/dsp/MainActivity.kt'
WG='app/src/main/java/com/okn/dsp/protocol/WriteGate.kt'
SP='app/src/main/java/com/okn/dsp/protocol/VerifiedScalarControls.kt'
KEY='app/okn_dsp_stable_debug.keystore'
CAP86='evidence/OKN_DSP_V86_ALL_STATUS_DISCONNECT_RUNTIME_SUCCESS_CAPTURE.txt'
PLAN='evidence/OKN_DSP_V87_LIFECYCLE_DESTROY_FAIL_CLOSED_PLAN.txt'
PLANJ='evidence/OKN_DSP_V87_LIFECYCLE_DESTROY_FAIL_CLOSED_PLAN.json'
for r in [U,G,M,WG,SP,KEY,CAP86,PLAN,PLANJ,'README_V87.txt']:
    req(r)

has(G,'applicationId = "com.okn.dsp"')
has(G,'versionCode = 87')
has(G,'versionName = "5.18.0-v87-lifecycle-destroy-fail-closed-journal"')
has(M,'V87 lifecycle-destroy fail-closed journal launcher')
has(U,'V87 • PRODUCTION SAFE')
has(U,'RUN V87 SESSION HEALTH GATE • READ ONLY')
has(U,'allStatusDisconnectFailClosed=V86_PASSED lifecycleDestroyFailClosed=required artifactDeliveryFix=V86_PASSED')
has(U,'lifecycleDestroyFailClosed=V87_PENDING_RUNTIME_PROOF')

# V86 real-device baseline carried as evidence.
c86=txt(CAP86)
for m in [
    'V86_SESSION_HEALTH_GATE_RESULT pass=true writesSent=0',
    'GATT_STATE status=8 newState=0',
    'V86_ALL_STATUS_DISCONNECT_FAIL_CLOSED status=8',
    'activeGattDetached=true',
    'liveCacheCleared=true',
    'V86_CONNECTION_READY connectionEpoch=3',
    'connectionEpoch=3 sessionEpoch=2',
]: assert m in c86, f'V86 runtime evidence missing {m}'

# Stable signing identity carried unchanged.
has(G,'create("stableDebug")')
has(G,'storeFile = file("okn_dsp_stable_debug.keystore")')
has(G,'signingConfig = signingConfigs.getByName("stableDebug")')
sha(KEY,'ba1c52f2607c09953c52fdd79c5f72026aaf0adb8aa44bcba277f7d9b49d9511')

u=txt(U)

# V86 all-status disconnect invariant remains intact in V87.
cb_start=u.index('    private val gattCallback = object')
cb_end=u.index('        override fun onMtuChanged',cb_start)
cb=u[cb_start:cb_end]
a=cb.index('if (newState == BluetoothProfile.STATE_DISCONNECTED)')
b=cb.index('if (statusCode != BluetoothGatt.GATT_SUCCESS)')
assert a < b, (a,b)
for m in [
    'cancelConnectionWatchdog("gatt-disconnected-status-$statusCode")',
    'handler.post { failClosedDisconnectedAllStatus(g, statusCode) }',
    'return',
]: assert m in cb,m

helper_start=u.index('    private fun failClosedDisconnectedAllStatus(callbackGatt: BluetoothGatt, statusCode: Int)')
helper_end=u.index('    private val gattCallback = object',helper_start)
helper=u[helper_start:helper_end]
for m in [
    'V87_ALL_STATUS_DISCONNECT_STALE status=$statusCode',
    'V87_UNIFIED_PERSISTENT_SAVE_UNCONFIRMED reason=disconnect-during-save',
    'V87_UNIFIED_WRITE_STATE_UNCONFIRMED reason=disconnect-during-scalar-pipeline',
    'V87_UNIFIED_EQ_WRITE_STATE_UNCONFIRMED reason=disconnect-during-eq-pipeline',
    'invalidateForConnectionTransition("gatt-disconnected-status-$statusCode")',
    'V87_ALL_STATUS_DISCONNECT_FAIL_CLOSED status=$statusCode',
    'persistCriticalCapture(',
]: assert m in helper,m
x=helper.index('gatt = null')
y=helper.index('invalidateForConnectionTransition("gatt-disconnected-status-$statusCode")')
z=helper.index('callbackGatt.close()')
assert x < y < z, (x,y,z)

# New V87 lifecycle fail-closed ordering and uncertainty journal.
d_start=u.index('    override fun onDestroy() {')
d_end=u.index('    private fun dp(value: Int)',d_start)
d=u[d_start:d_end]
for m in [
    'val purposeAtDestroy = pendingGattPurpose',
    'val hadSavePipeline = saveInFlight || purposeAtDestroy == PendingGattPurpose.SAVE_PARAMS',
    'purposeAtDestroy == PendingGattPurpose.SCALAR_TARGET',
    'purposeAtDestroy == PendingGattPurpose.SCALAR_RESTORE',
    'purposeAtDestroy == PendingGattPurpose.EQ_TARGET',
    'purposeAtDestroy == PendingGattPurpose.EQ_RESTORE',
    'V87_UNIFIED_PERSISTENT_SAVE_UNCONFIRMED reason=activity-destroy-during-save',
    'V87_UNIFIED_WRITE_STATE_UNCONFIRMED reason=activity-destroy-during-scalar-pipeline',
    'V87_UNIFIED_EQ_WRITE_STATE_UNCONFIRMED reason=activity-destroy-during-eq-pipeline',
    'persistCriticalCapture(',
    'cancelDescriptorTimeout()',
    'cancelGattActionTimeout()',
    'cancelConnectionWatchdog("activity-destroy")',
    'cancelSaveTimers()',
    'saveInFlight = false',
    'saveGattOk = false',
    'gatt = null',
    'invalidateForConnectionTransition("activity-destroy")',
    'closingGatt?.close()',
    'V87_LIFECYCLE_DESTROY_FAIL_CLOSED',
    'super.onDestroy()',
]: assert m in d,m
# Critical persistence must precede state clearing/detach; detach precedes invalidate; close precedes super.
p=d.index('persistCriticalCapture(')
c=d.index('cancelDescriptorTimeout()')
g=d.index('gatt = null')
i=d.index('invalidateForConnectionTransition("activity-destroy")')
cl=d.index('closingGatt?.close()')
r=d.index('V87_LIFECYCLE_DESTROY_FAIL_CLOSED')
sup=d.index('super.onDestroy()')
assert p < c < g < i < cl < r < sup, (p,c,g,i,cl,r,sup)
for forbidden in [
    'connectGatt(', 'startSession()', 'requestDescriptor(', 'UfeCodec.encodeFloat32Write',
    'LiveEqPolicy.encodeWrite', 'LiveEqPolicy.encodeRestore', 'SaveParamsPolicy.encodeTrigger()'
]: assert forbidden not in d, f'onDestroy must not launch DSP action: {forbidden}'

# Full invalidation clears session/crypto/live cache and bumps epoch.
inv_start=u.index('    private fun invalidateForConnectionTransition(reason: String)')
inv_end=u.index('    private fun renderAll()',inv_start)
inv=u[inv_start:inv_end]
for m in [
    'connectionEpoch += 1L','sessionReady = false','txCipher = null','rxCipher = null',
    'ab01 = null','ab02 = null','scalarValues.clear()','sensors.clear()',
    'for (c in bands.indices) for (b in bands[c].indices) bands[c][b] = null',
    'resetSessionHealthGate(reason, recordEvent = true)'
]: assert m in inv,m

# Watchdog + connection/session/GATT Health Gate binding unchanged.
for m in [
    'private val connectionReadyTimeoutMs = 15000L','V87_CONNECTION_WATCHDOG_ARM',
    'V87_CONNECTION_WATCHDOG_TIMEOUT','healthGateBoundConnectionEpoch == connectionEpoch',
    'healthGateBoundSessionEpoch == controlSessionEpoch','healthGateBoundGattIdentity == activeIdentity'
]: assert m in u,m

# Production writer scope frozen.
has(WG,'const val enabled: Boolean = false')
has(WG,'const val unifiedVerifiedScalarWritesEnabled: Boolean = true')
has(WG,'const val unifiedVerifiedEqWritesEnabled: Boolean = true')
ids=[int(x) for x in re.findall(r'VerifiedScalarControl\((\d+),',txt(SP))]
assert ids==[2,3,8,9,10,13,11],ids
assert u.count('UfeCodec.encodeFloat32Write')==2
assert u.count('LiveEqPolicy.encodeWrite')==1
assert u.count('LiveEqPolicy.encodeRestore')==1
assert u.count('SaveParamsPolicy.encodeTrigger()')==1
assert u.count('UfeCodec.encodeWrite(')==0

# ARM-before-write invariant preserved.
h=u[u.index('    private fun writeNoResponse('):u.index('    private fun record(kind: String, text: String) {')]
a=h.index('gattWriteTickets.addLast(kind)')
b=h.index('V87_UNIFIED_GATT_TICKET_PREPARED')
c=h.index('if (purpose != null) armGattActionTimeout(purpose)')
dw=h.index('g.writeCharacteristic(ch, bytes, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE)')
assert a<b<c<dw,(a,b,c,dw)

# Critical diagnostic lineage V87 -> V86 -> ... -> V74.
for m in [
    'private val criticalCaptureFileName = "okn_dsp_v87_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV86 = "okn_dsp_v86_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV85 = "okn_dsp_v85_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV84 = "okn_dsp_v84_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV83 = "okn_dsp_v83_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileName = "okn_dsp_v82_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV81 = "okn_dsp_v81_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV80 = "okn_dsp_v80_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV79 = "okn_dsp_v79_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV78 = "okn_dsp_v78_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV77 = "okn_dsp_v77_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV76 = "okn_dsp_v76_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV75 = "okn_dsp_v75_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV74 = "okn_dsp_v74_last_critical_capture.txt"',
    'val legacyV86 = java.io.File(filesDir, legacyCriticalCaptureFileNameV86)',
    'legacyV86.isFile && legacyV86.length() > 0L -> legacyV86.readText()',
]: assert m in u,m

# Protocol/transport frozen byte-for-byte from V86.
protocol_files=list((root/'app/src/main/java/com/okn/dsp/protocol').glob('*.kt'))
transport_files=list((root/'app/src/main/java/com/okn/dsp/transport').glob('*.kt'))
combo=combined_hash(protocol_files+transport_files)
assert combo=='f897e05f77e7f4e631d591c29a6d758ef355c7b4fba693e63dabe0572cb8552b', combo

assert u.count('class UnifiedControlActivity : Activity()')==1
assert u.count('private fun failClosedDisconnectedAllStatus(callbackGatt: BluetoothGatt, statusCode: Int)')==1
assert u.count('override fun onDestroy()')==1

print('V87 PRECHECK PASS')
print('versionCode=87')
print('releasePurpose=lifecycle-destroy-fail-closed-journal')
print('stableSigningKeySha256=ba1c52f2607c09953c52fdd79c5f72026aaf0adb8aa44bcba277f7d9b49d9511')
print('allStatusDisconnectBaseline=V86_RUNTIME_PASSED')
print('writerCounts=scalar2 eqWrite1 eqRestore1 save1 generic0')
print('protocolTransportCombinedSha256=f897e05f77e7f4e631d591c29a6d758ef355c7b4fba693e63dabe0572cb8552b')
