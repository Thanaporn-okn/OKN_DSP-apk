#!/usr/bin/env python3
from pathlib import Path
import hashlib,re
root=Path(__file__).resolve().parent

def req(rel):
    p=root/rel
    assert p.is_file(), f'missing {rel}'
    return p

def txt(rel): return req(rel).read_text(errors='replace')
def has(rel,m): assert m in txt(rel), f'missing {m!r} in {rel}'
def sha(rel,e):
    g=hashlib.sha256(req(rel).read_bytes()).hexdigest()
    assert g==e, f'hash mismatch {rel}: {g}'

U='app/src/main/java/com/okn/dsp/UnifiedControlActivity.kt'
G='app/build.gradle.kts'
M='app/src/main/java/com/okn/dsp/MainActivity.kt'
WG='app/src/main/java/com/okn/dsp/protocol/WriteGate.kt'
SP='app/src/main/java/com/okn/dsp/protocol/VerifiedScalarControls.kt'
KEY='app/okn_dsp_stable_debug.keystore'
CAP82='evidence/OKN_DSP_V82_FAIL_CLOSED_RECOVERY_RUNTIME_SUCCESS_CAPTURE.txt'
PLAN='evidence/OKN_DSP_V83_STABLE_UPGRADE_CONTINUITY_PROOF_PLAN.txt'
PLANJ='evidence/OKN_DSP_V83_STABLE_UPGRADE_CONTINUITY_PROOF_PLAN.json'
for r in [U,G,M,WG,SP,KEY,CAP82,PLAN,PLANJ,'README_V83.txt']:
    req(r)

# Build/version identity.
has(G,'applicationId = "com.okn.dsp"')
has(G,'versionCode = 83')
has(G,'versionName = "5.14.0-v83-stable-upgrade-continuity-proof"')
has(M,'V83 stable-upgrade continuity proof launcher')
has(U,'V83 • PRODUCTION SAFE')
has(U,'RUN V83 SESSION HEALTH GATE • READ ONLY')

# Stable signing identity must be exact V82 key/cert lineage.
has(G,'create("stableDebug")')
has(G,'storeFile = file("okn_dsp_stable_debug.keystore")')
has(G,'storePassword = "android"')
has(G,'keyAlias = "androiddebugkey"')
has(G,'keyPassword = "android"')
has(G,'signingConfig = signingConfigs.getByName("stableDebug")')
sha(KEY,'ba1c52f2607c09953c52fdd79c5f72026aaf0adb8aa44bcba277f7d9b49d9511')

u=txt(U)
# Upgrade continuity probe is startup read-only and records decisive fields.
for m in [
    'recordUpgradeContinuityProbe()',
    'private fun recordUpgradeContinuityProbe()',
    'V83_STABLE_UPGRADE_CONTINUITY_PROBE',
    'firstInstallTime', 'lastUpdateTime', 'updatedInPlace', 'cachePresent',
    'stableSigning=projectStableDebugKey writesSent=0',
]: assert m in u,m
probe=u[u.index('    private fun recordUpgradeContinuityProbe()'):u.index('    private fun startScan()',u.index('    private fun recordUpgradeContinuityProbe()'))]
for bad in ['writeCharacteristic(', 'writeNoResponse(', 'UfeCodec.', 'LiveEqPolicy.encode', 'SaveParamsPolicy.encodeTrigger', 'connectGatt(', 'startSession()', 'confirmStartSession()', '.edit()']:
    assert bad not in probe, f'probe must be read-only: {bad}'
# Probe is invoked after restoring Last-DSP UI and before permissions/connect activity.
oncreate=u[u.index('    override fun onCreate'):u.index('    @Suppress("DEPRECATION")',u.index('    override fun onCreate'))]
assert oncreate.index('restoreLastDspReconnectUi()') < oncreate.index('recordUpgradeContinuityProbe()') < oncreate.index('requestBlePermissions()')

# V81 watchdog behavior carried through V82/V83.
for m in [
    'private val connectionReadyTimeoutMs = 15000L',
    'private fun armConnectionWatchdog(epoch: Long, transitionReason: String)',
    'V83_CONNECTION_WATCHDOG_ARM',
    'V83_CONNECTION_WATCHDOG_TIMEOUT',
    'V83_CONNECTION_WATCHDOG_RECOVERY_COMPLETE',
    'V83_CONNECTION_READY_FAIL_CLOSED',
]: assert m in u,m
start=u.index('    private fun connect(device: BluetoothDevice, name: String, transitionReason: String, directReconnect: Boolean)')
connect=u[start:u.index('    private val gattCallback = object',start)]
for m in ['invalidateForConnectionTransition(transitionReason)','armConnectionWatchdog(requestedEpoch, transitionReason)','device.connectGatt']:
    assert m in connect,m
assert connect.index('invalidateForConnectionTransition(transitionReason)') < connect.index('armConnectionWatchdog(requestedEpoch, transitionReason)') < connect.index('device.connectGatt')

# Health-gate binding remains exact.
for m in ['private var connectionEpoch = 0L','private var controlSessionEpoch = 0L','healthGateBoundConnectionEpoch == connectionEpoch','healthGateBoundSessionEpoch == controlSessionEpoch','healthGateBoundGattIdentity == activeIdentity']:
    assert m in u,m

# Production write scope remains frozen.
has(WG,'const val enabled: Boolean = false')
has(WG,'const val unifiedVerifiedScalarWritesEnabled: Boolean = true')
has(WG,'const val unifiedVerifiedEqWritesEnabled: Boolean = true')
ids=[int(x) for x in re.findall(r'VerifiedScalarControl\((\d+),',txt(SP))]
assert ids==[2,3,8,9,10,13,11],ids
assert u.count('UfeCodec.encodeFloat32Write')==2
assert u.count('LiveEqPolicy.encodeWrite')==1
assert u.count('LiveEqPolicy.encodeRestore')==1
assert u.count('SaveParamsPolicy.encodeTrigger()')==1
assert u.count('UfeCodec.encodeWrite(')==0

# ARM-before-write central order retained.
h=u[u.index('    private fun writeNoResponse('):u.index('    private fun record(kind: String, text: String) {')]
a=h.index('gattWriteTickets.addLast(kind)')
b=h.index('V83_UNIFIED_GATT_TICKET_PREPARED')
c=h.index('if (purpose != null) armGattActionTimeout(purpose)')
d=h.index('g.writeCharacteristic(ch, bytes, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE)')
assert a<b<c<d,(a,b,c,d)

# Diagnostic lineage must compile-resolve V83 current -> V82 -> V81 -> ... -> V74.
for m in [
    'private val criticalCaptureFileName = "okn_dsp_v83_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileName = "okn_dsp_v82_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV81 = "okn_dsp_v81_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV80 = "okn_dsp_v80_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV79 = "okn_dsp_v79_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV78 = "okn_dsp_v78_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV77 = "okn_dsp_v77_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV76 = "okn_dsp_v76_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV75 = "okn_dsp_v75_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV74 = "okn_dsp_v74_last_critical_capture.txt"',
    'val legacyV82 = java.io.File(filesDir, legacyCriticalCaptureFileName)',
    'val legacyV81 = java.io.File(filesDir, legacyCriticalCaptureFileNameV81)',
]: assert m in u,m
for sym in ['criticalCaptureFileName','legacyCriticalCaptureFileName','legacyCriticalCaptureFileNameV81','legacyCriticalCaptureFileNameV80','legacyCriticalCaptureFileNameV79','legacyCriticalCaptureFileNameV78','legacyCriticalCaptureFileNameV77','legacyCriticalCaptureFileNameV76','legacyCriticalCaptureFileNameV75','legacyCriticalCaptureFileNameV74']:
    assert u.count('private val '+sym+' =')==1,sym

# Protocol modules frozen exactly against V82 baseline.
protocol_hashes={
'AuthResponseCodec.kt':'0cbe3174f4d0bf543edb1dfd41db71ab4970effb3743be9e6c7d5a174a5e5f90',
'AuthSessionAnalyzer.kt':'63c8e8afcbc0fb5a2400a8e620932af72bec4d695463c8ed86b0c6bd5d507f7d',
'AuthVectorLab.kt':'16ba1e0fa076da2b5b6b1ccc0c97bee7f015895c7ebceb55a5f1e704ebfe113a',
'ByteCodec.kt':'04843cec90b69886607d98a0aabf0ad81812fc8d25df913c5b1847a10fd7a3ae',
'ConfirmedDspMap.kt':'6e68295f194dd0b0f70d0b83b9ba2324a9a2a8eaf2350b5d5a821f838ae2c66d',
'LiveEqPolicy.kt':'cfb046aa09acaf8429176a9b99e988ea06347f3daeea988b7c118d056400d2bc',
'SaveParamsPolicy.kt':'88005dba77d2b84597f5bd5e23eaaacec7d25b59dc0f38b8affbde2d2cfbeb85',
'SessionCrypto.kt':'bae330efd6e9beb628b287e43e36bd98d80b3f9b4d1c014f65c63ef16efa586e',
'UfeCodec.kt':'b47f66afec8fd3383581c30b2dc1ad9ad41e3b7089f427f0b094e91581588c34',
'VerifiedScalarControls.kt':'4c096b001523704dcb6aa36496dd17263d6df84a0a1fee20c2fc40d60e898f6b',
'WriteGate.kt':'8aa82bb069dd64dc2d1274801f1f4420a764f52670246e9c813b0723531be472',
}
for name,hv in protocol_hashes.items():
    sha('app/src/main/java/com/okn/dsp/protocol/'+name,hv)

# V79 icon stays byte-identical.
icon_hashes={
'app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml':'26f045d965d04ea923732f0df4fba2d5618d021696f5360a00b25117e49cfe2d',
'app/src/main/res/mipmap-hdpi/ic_launcher.png':'bf64e92b76648a2012b30ec9ad9ac4ac681b02092fdd6c05ce1d32fe1fa803e6',
'app/src/main/res/mipmap-mdpi/ic_launcher.png':'16b930fd04c5cfd86c0278781a541a1166214af884a305b7688ba424303a0786',
'app/src/main/res/mipmap-xhdpi/ic_launcher.png':'796fffe8b7a5a6acd4322bde54f4796d5281a5ff77b9fa1c94afe8b4b808ff1f',
'app/src/main/res/mipmap-xxhdpi/ic_launcher.png':'ba9aa193371bf466385e91dc2321b028d88a09cf348025f723191a45601839e0',
'app/src/main/res/mipmap-xxxhdpi/ic_launcher.png':'47bc7e64ee3cc123fdc61ad37cd656879fab2a758c24cdf77dc90e089a97b3e3',
}
for rel,hv in icon_hashes.items(): sha(rel,hv)

# Latest V82 real-DSP evidence is bundled and proves fail-closed + recovery + PASS.
cap=txt(CAP82)
for m in [
    'V82_CONNECTION_READY_FAIL_CLOSED reason=gatt-state-status-147',
    'connectionEpoch=4 sessionReady=false healthGateValid=false writesSent=0',
    'V82_CONNECTION_READY connectionEpoch=5',
    'V82_UNIFIED_LOAD mode=REFRESH scalarCount=7 expectedScalars=7 eqBands=105 expectedEqBands=105',
    'V82_SESSION_HEALTH_GATE_RESULT pass=true writesSent=0',
    'connectionEpoch=5 sessionEpoch=1 boundConnectionEpoch=5 boundSessionEpoch=1',
]: assert m in cap,m

print('V83 PREFLIGHT PASS: stable-signing upgrade continuity probe + V82 writer/protocol/icon freeze')
