OKN DSP V75 — PRODUCTION RELEASE BASELINE FREEZE + FIELD SELF-CHECK

Authoritative base
- Source base: V74 GATT ARM-BEFORE-WRITE ORDERING FIX.
- V74 real-DSP runtime qualification passed Connect/Auth/Sync, scalar target/return-baseline, safe-PEAKING EQ target/return-baseline, guarded SaveParams PRECHECK/GATT/5s settle/POSTCHECK, persistent diagnostic export, and the ARM-before-write ordering proof.
- The V74 final diagnostic capture is included under evidence and is treated as the qualification basis for this release freeze.

V75 scope
- No new DSP write family.
- No payload/protocol expansion.
- Preserve scalar allow-list IDs: 2,3,8,9,10,13,11.
- Preserve EQ writes limited to verified safe PEAKING type=12 full 48-byte records.
- Preserve SaveParams exact trigger through SaveParamsPolicy only.
- Preserve V74 ARM-before-write ordering for scalar target/restore, EQ target/restore and SaveParams.
- Preserve persistent critical diagnostics and stale-GATT identity guards.
- Sensors remain read-only; non-standard EQ remains read-only; generic/unknown/preset/delay writes remain locked.

V75 new production field self-check
- STATUS adds RUN V75 FIELD SELF-CHECK • READ ONLY.
- The self-check sends no DSP write.
- It verifies the live production session is healthy before normal field use:
  * sessionReady=true
  * 7 verified scalar values loaded
  * 105 EQ bands loaded
  * 4 sensors loaded
  * GATT/AB01/AB02/TX/RX session objects present
  * exact scalar allow-list [2,3,8,9,10,13,11]
  * generic WriteGate=false and verified scalar/EQ gates enabled
  * protocol idle: no descriptor/write/save/auth pipeline in flight and no GATT ticket queued
  * RAM clean/unarmed: no unsaved verified change in the current session
  * active GATT identity present
- PASS/BLOCKED result is appended to the normal diagnostic capture with writesSent=0.
- Existing EXPORT DIAGNOSTIC CAPTURE can export the self-check result.

Critical diagnostic continuity
- V75 writes new critical snapshots to okn_dsp_v75_last_critical_capture.txt.
- It can recover a V74 persisted critical capture after upgrade, with V73 as the second legacy fallback.

Expected runtime qualification
1. Install V75 over V74.
2. Connect / START CONTROL SESSION / SYNC LIVE VALUES.
3. Confirm 7 scalars + 105 EQ + 4 sensors and RAM CLEAN/UNARMED.
4. Open STATUS and press RUN V75 FIELD SELF-CHECK • READ ONLY.
5. Require V75 FIELD SELF-CHECK PASS and export diagnostic capture.
6. No APPLY or SAVE is required for the V75 qualification because the DSP writer/payload surface is intentionally frozen from the V74 real-DSP-qualified baseline.

Mobile deliverables remain separate: Source ZIP, GitHub Actions workflow YML, SHA256 TXT.
