#!/usr/bin/env python3
from pathlib import Path
import hashlib,re
root=Path(__file__).resolve().parent

def req(rel):
    p=root/rel
    assert p.is_file(), f'missing {rel}'
    return p

def text(rel): return req(rel).read_text(errors='replace')
def contains(rel, marker):
    s=text(rel); assert marker in s, f'missing {marker!r} in {rel}'

def sha(rel, expected):
    got=hashlib.sha256(req(rel).read_bytes()).hexdigest()
    assert got==expected, f'hash mismatch {rel}: {got}'

U='app/src/main/java/com/okn/dsp/UnifiedControlActivity.kt'
M='app/src/main/java/com/okn/dsp/MainActivity.kt'
G='app/build.gradle.kts'
MAN='app/src/main/AndroidManifest.xml'
GATE='app/src/main/java/com/okn/dsp/protocol/WriteGate.kt'
SP='app/src/main/java/com/okn/dsp/protocol/VerifiedScalarControls.kt'
CAP='evidence/OKN_DSP_V74_FINAL_PRODUCTION_RUNTIME_SUCCESS_CAPTURE.txt'
PLAN='evidence/OKN_DSP_V75_PRODUCTION_RELEASE_FIELD_SELF_CHECK_PLAN.txt'
PLANJ='evidence/OKN_DSP_V75_PRODUCTION_RELEASE_FIELD_SELF_CHECK_PLAN.json'

for rel in [U,M,G,MAN,GATE,SP,'README_V75.txt',PLAN,PLANJ,CAP]: req(rel)
contains(G,'versionCode = 75')
contains(G,'5.6.0-v75-production-release-field-self-check')
contains(M,'startActivity(Intent(this, UnifiedControlActivity::class.java))')
contains(M,'finish()')
contains(MAN,'android:label="OKN DSP"')
for m in ['V75 • PRODUCTION SAFE','DSP CONNECTION','START CONTROL SESSION','SYNC LIVE VALUES',
          '● GLOBAL','EQ 7CH','DSP STATUS','SAVE TO DSP • LOCKED',
          'RUN V75 FIELD SELF-CHECK • READ ONLY',
          'EXPORT DIAGNOSTIC CAPTURE • CURRENT + LAST FAILURE']:
    contains(U,m)

contains(GATE,'const val enabled: Boolean = false')
contains(GATE,'const val unifiedVerifiedScalarWritesEnabled: Boolean = true')
contains(GATE,'const val unifiedVerifiedEqWritesEnabled: Boolean = true')
ids=[int(x) for x in re.findall(r'VerifiedScalarControl\((\d+),',text(SP))]
assert ids==[2,3,8,9,10,13,11],ids

u=text(U)
# V75 adds no DSP writer or payload family; production surface remains V74.
assert u.count('UfeCodec.encodeFloat32Write')==2
assert u.count('LiveEqPolicy.encodeWrite')==1
assert u.count('LiveEqPolicy.encodeRestore')==1
assert u.count('SaveParamsPolicy.encodeTrigger()')==1
assert u.count('UfeCodec.encodeWrite(')==0
assert u.count('EqBandCodec.encode')==0
# Seven stale-GATT callback identity guards retained.
labels=['onConnectionStateChange','onMtuChanged','onServicesDiscovered','onDescriptorWrite','onCharacteristicWrite','onCharacteristicChanged33','onCharacteristicChangedLegacy']
for label in labels:
    assert f'if (!isCurrentGatt(g, "{label}")) return' in u,label
assert u.count('if (!isCurrentGatt(g,')==7

# V74-qualified ARM-before-write ordering remains centralized and unchanged in behavior.
helper=u[u.index('    private fun writeNoResponse('):u.index('    private fun record(kind: String, text: String) {')]
idx_ticket=helper.index('gattWriteTickets.addLast(kind)')
idx_prepared=helper.index('V75_UNIFIED_GATT_TICKET_PREPARED')
idx_arm=helper.index('if (purpose != null) armGattActionTimeout(purpose)')
idx_write=helper.index('g.writeCharacteristic(ch, bytes, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE)')
assert idx_ticket < idx_prepared < idx_arm < idx_write, (idx_ticket,idx_prepared,idx_arm,idx_write)
assert 'beforeWriteCharacteristic=true' in helper
assert 'V75_UNIFIED_GATT_PREARM_ROLLBACK' in helper
assert 'V75_UNIFIED_GATT_WRITE_ACCEPTED' in helper
assert u.count('armGattActionTimeout(')==2, u.count('armGattActionTimeout(')
for purpose in ['SCALAR_TARGET','SCALAR_RESTORE','EQ_TARGET','EQ_RESTORE','SAVE_PARAMS']:
    assert f'PendingGattPurpose.{purpose})' in u, purpose

# Unconfirmed target safety remains STOP/no second write.
for m in [
    'V75_UNIFIED_UNCONFIRMED_TARGET_POLICY action=STOP_NO_SECOND_WRITE family=SCALAR',
    'V75_UNIFIED_UNCONFIRMED_TARGET_POLICY action=STOP_NO_SECOND_WRITE family=EQ',
    'V75_UNIFIED_GATT_RESULT_TIMEOUT','callbackAgeMs=',
    'private fun restorePending(reason: String)','private fun restorePendingEq(reason: String)',
    'sensorReadOnly=true','genericWrites=false']:
    assert m in u,m
assert 'restorePending("target-gatt-unconfirmed")' not in u
assert 'restorePendingEq("target-gatt-unconfirmed")' not in u

# V75 field self-check is explicitly READ ONLY and checks live release invariants.
field=u[u.index('    private fun runFieldSelfCheck()'):u.index('    private fun confirmArmPowerCycleProof()')]
for m in [
    'VerifiedScalarControls.controls.map { it.id } == listOf(2, 3, 8, 9, 10, 13, 11)',
    'scalarValues.size == 7','eqCount == 105','sensors.size == 4',
    'gatt != null && ab01 != null && ab02 != null && txCipher != null && rxCipher != null',
    '!WriteGate.enabled','WriteGate.unifiedVerifiedScalarWritesEnabled','WriteGate.unifiedVerifiedEqWritesEnabled',
    'gattWriteTickets.isEmpty()','!unsavedVerifiedChanges && verifiedChangeCount == 0',
    'V75_FIELD_SELF_CHECK_RESULT pass=$pass writesSent=0']:
    assert m in field,m
for forbidden in ['writeNoResponse(','UfeCodec.','LiveEqPolicy.encode','SaveParamsPolicy.encodeTrigger','writeCharacteristic(']:
    assert forbidden not in field, f'field self-check must be read-only: {forbidden}'

# Persistent diagnostics continue across V75 -> V74 -> V73 upgrades.
for m in ['okn_dsp_v75_last_critical_capture.txt','okn_dsp_v74_last_critical_capture.txt','okn_dsp_v73_last_critical_capture.txt',
          'V75 PERSISTED CRITICAL DIAGNOSTIC','RECOVERED/PERSISTED LAST CRITICAL FAILURE']:
    assert m in u,m

# V74 real-DSP final qualification is the release-freeze basis.
cap=text(CAP)
for m in [
    'V74_UNIFIED_POLICY scalarWrites=true scalarIds=2,3,8,9,10,13,11',
    'V74_UNIFIED_GATT_ACTION_ARM purpose=SCALAR_TARGET',
    'V74_UNIFIED_GATT_ACTION_ARM purpose=EQ_TARGET',
    'V74_UNIFIED_SAVE_PRECHECK_RESULT verified=true countsOk=true scalarMismatch=0 eqMismatch=0',
    'V74_UNIFIED_SAVEPARAMS_TRIGGER_PLAIN=570000000700000000',
    'V74_UNIFIED_GATT_ACTION_ARM purpose=SAVE_PARAMS',
    'V74_UNIFIED_GATT_RESULT purpose=SAVE_PARAMS ticket=SAVE_PARAMS status=0 ok=true callbackAgeMs=1',
    'V74_UNIFIED_SAVE_POSTCHECK_RESULT verified=true countsOk=true scalarMismatch=0 eqMismatch=0',
    'V74_UNIFIED_PERSISTENT_SAVE_COMPLETE savedVerifiedChanges=4 savedScalar=2 savedEq=2',
    'precheck=true postcheck=true']:
    assert m in cap,m
assert 'callbackAgeMs=-1' not in cap
sha(CAP,'098d7414d98637e4249910778f049403cd11d4dc4ca05cdbce286965ac48ae71')

# Production modules remain byte-for-byte unchanged from the V74 source baseline.
sha('app/src/main/java/com/okn/dsp/ScalarControlActivity.kt','01f6aca6f2131bd41ca4fd1d674d879cade425ccc7ddef77e63718e8e124ffed')
sha('app/src/main/java/com/okn/dsp/LiveEqActivity.kt','3240ca56c81b7960098ae9fb6ea7421d32e74b11e42810ce4c5b71b35d7ab8d0')
sha('app/src/main/java/com/okn/dsp/protocol/SaveParamsPolicy.kt','88005dba77d2b84597f5bd5e23eaaacec7d25b59dc0f38b8affbde2d2cfbeb85')
sha('app/src/main/java/com/okn/dsp/protocol/LiveEqPolicy.kt','cfb046aa09acaf8429176a9b99e988ea06347f3daeea988b7c118d056400d2bc')
sha('app/src/main/java/com/okn/dsp/protocol/EqBandCodec.kt','4f033a406e363b2418af9b39fa2e42a13674b09f9de2bb7acf1eb6ff1918cd58')
sha(GATE,'8aa82bb069dd64dc2d1274801f1f4420a764f52670246e9c813b0723531be472')
sha(SP,'4c096b001523704dcb6aa36496dd17263d6df84a0a1fee20c2fc40d60e898f6b')
print('OK: V75 production release baseline freeze + read-only field self-check preflight passed')
