OKN DSP V84 — PASSIVE DISCONNECT EPOCH DETACH FAIL-CLOSED

BASELINE
- V83 is the current runtime-qualified production baseline.
- V83 proved stable in-place upgrade continuity, preserved Last-DSP cache, successful reconnect/Auth/descriptor load, 7 Scalars + 105 EQ + 4 Sensors, and Health Gate PASS with writesSent=0.
- V84 adds no DSP protocol/write family.

WHY V84 EXISTS
Source audit of V83 found that a clean BluetoothGatt STATE_DISCONNECTED callback (status=0, newState=STATE_DISCONNECTED) reset the session gate but left the disconnected BluetoothGatt object as the active gatt and did not increment connectionEpoch. That could keep a stale GATT identity logically current until the next manual reconnect and could leave stale live values visible.

V84 CHANGE
On a clean passive disconnect V84 now:
- dispatches fail-closed cleanup onto the main handler,
- verifies the callback GATT is still the active GATT,
- records any active scalar/EQ/save pipeline as unconfirmed,
- cancels save timers,
- detaches gatt before cleanup so late callbacks fail isCurrentGatt(),
- calls invalidateForConnectionTransition("gatt-disconnected") to increment connectionEpoch and clear session/cipher/AB01/AB02/live caches,
- closes the disconnected BluetoothGatt,
- keeps Session Health Gate and Permanent Save locked,
- leaves Last-DSP cache available for retry,
- sends no automatic START/Auth/DSP write.

RUNTIME PROOF TARGET
1. Install V84 directly over V83; do not uninstall or clear data.
2. RECONNECT LAST DSP -> START CONTROL SESSION -> Health Gate PASS.
3. While session is READY, power the DSP off (or otherwise cause a clean status=0/newState=DISCONNECTED path if the device/stack provides it).
4. Expected diagnostic marker:
   V84_PASSIVE_DISCONNECT_FAIL_CLOSED ... activeGattDetached=true ... healthGateValid=false ... staleSessionObjectsCleared=true liveCacheCleared=true writesSent=0
5. Re-power DSP -> RECONNECT LAST DSP -> START -> SYNC -> Health Gate PASS again.

PRODUCTION DSP WRITE SCOPE UNCHANGED
- Scalars: IDs 2,3,8,9,10,13,11 only
- EQ: safe PEAKING only, IDs 4,5,6,14,15,16,17
- Sensors: READ ONLY
- genericWrites=false
- SaveParams manual guarded
- Preset / Delay / unknown writes remain locked

STABLE SIGNING IDENTITY — MUST NOT CHANGE
- app/okn_dsp_stable_debug.keystore
- Keystore SHA256: ba1c52f2607c09953c52fdd79c5f72026aaf0adb8aa44bcba277f7d9b49d9511
- Certificate SHA-256: C3:DA:85:AF:2E:97:8D:BD:0E:D9:BB:69:5E:5C:79:A2:63:18:95:95:C1:16:AD:93:A1:DE:D7:5A:2E:B9:83:97
