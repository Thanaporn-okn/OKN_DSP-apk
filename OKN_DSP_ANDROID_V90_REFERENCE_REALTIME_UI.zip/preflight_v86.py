#!/usr/bin/env python3
from pathlib import Path
import hashlib,re
root=Path(__file__).resolve().parent

def req(rel):
    p=root/rel
    assert p.is_file(), f'missing {rel}'
    return p

def txt(rel): return req(rel).read_text(errors='replace')
def has(rel,m): assert m in txt(rel), f'missing {m!r} in {rel}'
def sha(rel,e):
    g=hashlib.sha256(req(rel).read_bytes()).hexdigest()
    assert g==e, f'hash mismatch {rel}: {g}'

U='app/src/main/java/com/okn/dsp/UnifiedControlActivity.kt'
G='app/build.gradle.kts'
M='app/src/main/java/com/okn/dsp/MainActivity.kt'
WG='app/src/main/java/com/okn/dsp/protocol/WriteGate.kt'
SP='app/src/main/java/com/okn/dsp/protocol/VerifiedScalarControls.kt'
KEY='app/okn_dsp_stable_debug.keystore'
CAP84='evidence/OKN_DSP_V84_PRODUCTION_RUNTIME_STATUS8_RECOVERY_SUCCESS_CAPTURE.txt'
PLAN='evidence/OKN_DSP_V86_ARTIFACT_DELIVERY_FIX_PLAN.txt'
PLANJ='evidence/OKN_DSP_V86_ARTIFACT_DELIVERY_FIX_PLAN.json'
for r in [U,G,M,WG,SP,KEY,CAP84,PLAN,PLANJ,'README_V86.txt']:
    req(r)

has(G,'applicationId = "com.okn.dsp"')
has(G,'versionCode = 86')
has(G,'versionName = "5.17.0-v86-artifact-delivery-fix"')
has(M,'V86 all-status disconnect fail-closed unification launcher')
has(U,'V86 • PRODUCTION SAFE')
has(U,'RUN V86 SESSION HEALTH GATE • READ ONLY')
has(U,'artifactDeliveryFix=V86_WORKFLOW_ONLY')

# V84 real-device baseline that motivated all-status disconnect unification remains embedded.
c84=txt(CAP84)
for m in [
    'V84_SESSION_HEALTH_GATE_RESULT pass=true writesSent=0',
    'GATT_STATE status=8 newState=0',
    'V84_CONNECTION_EPOCH_INVALIDATE reason=connection-ready-failed-gatt-state-status-8',
    'V84_CONNECTION_READY_FAIL_CLOSED reason=gatt-state-status-8',
    'V84_CONNECTION_READY connectionEpoch=3',
    'connectionEpoch=3 sessionEpoch=2',
]: assert m in c84, f'V84 runtime evidence missing {m}'

# Stable signing identity carried unchanged.
has(G,'create("stableDebug")')
has(G,'storeFile = file("okn_dsp_stable_debug.keystore")')
has(G,'signingConfig = signingConfigs.getByName("stableDebug")')
sha(KEY,'ba1c52f2607c09953c52fdd79c5f72026aaf0adb8aa44bcba277f7d9b49d9511')

u=txt(U)
# Core V85 safety invariant must be carried unchanged in V86: DISCONNECTED first.
cb_start=u.index('    private val gattCallback = object')
cb_end=u.index('        override fun onMtuChanged',cb_start)
cb=u[cb_start:cb_end]
a=cb.index('if (newState == BluetoothProfile.STATE_DISCONNECTED)')
b=cb.index('if (statusCode != BluetoothGatt.GATT_SUCCESS)')
assert a < b, (a,b)
for m in [
    'cancelConnectionWatchdog("gatt-disconnected-status-$statusCode")',
    'handler.post { failClosedDisconnectedAllStatus(g, statusCode) }',
    'return',
]: assert m in cb,m

helper_start=u.index('    private fun failClosedDisconnectedAllStatus(callbackGatt: BluetoothGatt, statusCode: Int)')
helper_end=u.index('    private val gattCallback = object',helper_start)
helper=u[helper_start:helper_end]
for m in [
    'V86_ALL_STATUS_DISCONNECT_STALE status=$statusCode',
    'V86_UNIFIED_PERSISTENT_SAVE_UNCONFIRMED reason=disconnect-during-save',
    'V86_UNIFIED_WRITE_STATE_UNCONFIRMED reason=disconnect-during-scalar-pipeline',
    'V86_UNIFIED_EQ_WRITE_STATE_UNCONFIRMED reason=disconnect-during-eq-pipeline',
    'invalidateForConnectionTransition("gatt-disconnected-status-$statusCode")',
    'V86_ALL_STATUS_DISCONNECT_FAIL_CLOSED status=$statusCode',
    'liveCacheCleared=$liveCacheCleared writesSent=0',
    'persistCriticalCapture(',
]: assert m in helper,m
x=helper.index('gatt = null')
y=helper.index('invalidateForConnectionTransition("gatt-disconnected-status-$statusCode")')
z=helper.index('callbackGatt.close()')
assert x < y < z, (x,y,z)
for forbidden in ['connectGatt(', 'UfeCodec.encodeFloat32Write', 'LiveEqPolicy.encodeWrite', 'LiveEqPolicy.encodeRestore', 'SaveParamsPolicy.encodeTrigger()', 'startSession()']:
    assert forbidden not in helper, f'disconnect helper must not launch DSP action: {forbidden}'

# Full invalidation still clears session/crypto/live cache.
inv_start=u.index('    private fun invalidateForConnectionTransition(reason: String)')
inv_end=u.index('    private fun renderAll()',inv_start)
inv=u[inv_start:inv_end]
for m in ['connectionEpoch += 1L','sessionReady = false','txCipher = null','rxCipher = null','ab01 = null','ab02 = null','scalarValues.clear()','sensors.clear()','for (c in bands.indices) for (b in bands[c].indices) bands[c][b] = null','resetSessionHealthGate(reason, recordEvent = true)']:
    assert m in inv,m

# Watchdog + health gate binding unchanged.
for m in ['private val connectionReadyTimeoutMs = 15000L','V86_CONNECTION_WATCHDOG_ARM','V86_CONNECTION_WATCHDOG_TIMEOUT','healthGateBoundConnectionEpoch == connectionEpoch','healthGateBoundSessionEpoch == controlSessionEpoch','healthGateBoundGattIdentity == activeIdentity']:
    assert m in u,m

# Production writer scope frozen.
has(WG,'const val enabled: Boolean = false')
has(WG,'const val unifiedVerifiedScalarWritesEnabled: Boolean = true')
has(WG,'const val unifiedVerifiedEqWritesEnabled: Boolean = true')
ids=[int(x) for x in re.findall(r'VerifiedScalarControl\((\d+),',txt(SP))]
assert ids==[2,3,8,9,10,13,11],ids
assert u.count('UfeCodec.encodeFloat32Write')==2
assert u.count('LiveEqPolicy.encodeWrite')==1
assert u.count('LiveEqPolicy.encodeRestore')==1
assert u.count('SaveParamsPolicy.encodeTrigger()')==1
assert u.count('UfeCodec.encodeWrite(')==0

# ARM-before-write invariant preserved.
h=u[u.index('    private fun writeNoResponse('):u.index('    private fun record(kind: String, text: String) {')]
a=h.index('gattWriteTickets.addLast(kind)')
b=h.index('V86_UNIFIED_GATT_TICKET_PREPARED')
c=h.index('if (purpose != null) armGattActionTimeout(purpose)')
d=h.index('g.writeCharacteristic(ch, bytes, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE)')
assert a<b<c<d,(a,b,c,d)

# Critical diagnostic lineage V86 -> V85 -> V84 -> ... -> V74.
for m in [
    'private val criticalCaptureFileName = "okn_dsp_v86_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV85 = "okn_dsp_v85_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV84 = "okn_dsp_v84_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV83 = "okn_dsp_v83_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileName = "okn_dsp_v82_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV81 = "okn_dsp_v81_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV80 = "okn_dsp_v80_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV79 = "okn_dsp_v79_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV78 = "okn_dsp_v78_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV77 = "okn_dsp_v77_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV76 = "okn_dsp_v76_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV75 = "okn_dsp_v75_last_critical_capture.txt"',
    'private val legacyCriticalCaptureFileNameV74 = "okn_dsp_v74_last_critical_capture.txt"',
    'val legacyV85 = java.io.File(filesDir, legacyCriticalCaptureFileNameV85)',
    'legacyV85.isFile && legacyV85.length() > 0L -> legacyV85.readText()',
]: assert m in u,m

# Frozen protocol/transport hashes from V84/V85.
hashes={
'app/src/main/java/com/okn/dsp/protocol/AuthResponseCodec.kt':'0cbe3174f4d0bf543edb1dfd41db71ab4970effb3743be9e6c7d5a174a5e5f90',
'app/src/main/java/com/okn/dsp/protocol/AuthSessionAnalyzer.kt':'63c8e8afcbc0fb5a2400a8e620932af72bec4d695463c8ed86b0c6bd5d507f7d',
'app/src/main/java/com/okn/dsp/protocol/AuthVectorLab.kt':'16ba1e0fa076da2b5b6b1ccc0c97bee7f015895c7ebceb55a5f1e704ebfe113a',
'app/src/main/java/com/okn/dsp/protocol/ByteCodec.kt':'04843cec90b69886607d98a0aabf0ad81812fc8d25df913c5b1847a10fd7a3ae',
'app/src/main/java/com/okn/dsp/protocol/ConfirmedDspMap.kt':'6e68295f194dd0b0f70d0b83b9ba2324a9a2a8eaf2350b5d5a821f838ae2c66d',
'app/src/main/java/com/okn/dsp/protocol/ControlledCapture.kt':'0359e28b230618edfec7ed90d4f9a9cc116ce58f684ba640758ba22812e88776',
'app/src/main/java/com/okn/dsp/protocol/ControlledEqBandProof.kt':'9c93d7aabc0fc7edcb4056a3077cdb23a49c1469618453c87faa47c477c34126',
'app/src/main/java/com/okn/dsp/protocol/ControlledMasterVolumeProof.kt':'8357e6207b1b5382e4a70a0eeec25d03c38fc374d3a21633f156f341ffa57778',
'app/src/main/java/com/okn/dsp/protocol/DeviceDescriptionProof.kt':'ae0cbc9d09eed29bae77f32f84bba3c8cbea7db8e8f9b04b0e3a1311ca527307',
'app/src/main/java/com/okn/dsp/protocol/EqBandCodec.kt':'4f033a406e363b2418af9b39fa2e42a13674b09f9de2bb7acf1eb6ff1918cd58',
'app/src/main/java/com/okn/dsp/protocol/EqBandRecoveryPolicy.kt':'9928f69cadc2e6e172cf2eed61f7a9063374ef4c8cd73e4522a45a0b9b76b82d',
'app/src/main/java/com/okn/dsp/protocol/FinalEqWriteRestorePolicy.kt':'41468a2f9b40511efe2e0384683eed42c60ee765222b5b4bb138b85e962180d7',
'app/src/main/java/com/okn/dsp/protocol/LiveEqPolicy.kt':'cfb046aa09acaf8429176a9b99e988ea06347f3daeea988b7c118d056400d2bc',
'app/src/main/java/com/okn/dsp/protocol/PreAuthRandKeyDecoder.kt':'58d8a287449c849fb925070ac1f61ea26ba02875f58605fd7008439da78533ac',
'app/src/main/java/com/okn/dsp/protocol/ProtocolEvidence.kt':'c8989d2dd57299a64464f31824b86df9fd07f9ef376bc6b4cd6576d0076e5ef5',
'app/src/main/java/com/okn/dsp/protocol/ProtocolSelfTest.kt':'8e1ea8beda03c2b90679a1af0a142a823be23e93481b124b981df768b0a9a0be',
'app/src/main/java/com/okn/dsp/protocol/RandKeyPreAuthLab.kt':'feb00c3513d5869b1d72a34e864ae3396570eac23f3f9036c0f40b575d79686a',
'app/src/main/java/com/okn/dsp/protocol/ReferenceProfile.kt':'3cc1ad3d717f29358e04c0c5ccfff16c8f310006651fd3024fe570853c2595dc',
'app/src/main/java/com/okn/dsp/protocol/SaveParamsPolicy.kt':'88005dba77d2b84597f5bd5e23eaaacec7d25b59dc0f38b8affbde2d2cfbeb85',
'app/src/main/java/com/okn/dsp/protocol/SessionCrypto.kt':'bae330efd6e9beb628b287e43e36bd98d80b3f9b4d1c014f65c63ef16efa586e',
'app/src/main/java/com/okn/dsp/protocol/SevenChannelEqMapPolicy.kt':'6dde7ec82e42f974fe5bde040447a6ba089a3795ed930164c2622f280fd39da4',
'app/src/main/java/com/okn/dsp/protocol/UfeCodec.kt':'b47f66afec8fd3383581c30b2dc1ad9ad41e3b7089f427f0b094e91581588c34',
'app/src/main/java/com/okn/dsp/protocol/UfeConstants.kt':'e64de468c11d80ea052b97c9298a0a8a7f8cc49362f5bd06193d2c7c6d0108aa',
'app/src/main/java/com/okn/dsp/protocol/VerifiedScalarControls.kt':'4c096b001523704dcb6aa36496dd17263d6df84a0a1fee20c2fc40d60e898f6b',
'app/src/main/java/com/okn/dsp/protocol/WriteGate.kt':'8aa82bb069dd64dc2d1274801f1f4420a764f52670246e9c813b0723531be472',
'app/src/main/java/com/okn/dsp/transport/BleProfile.kt':'52f25f92e0dd5059417a894e0da7e58ea73de4505661e9b25e62e51e73d314a0',
'app/src/main/java/com/okn/dsp/transport/BleTransport.kt':'d44d661d0abe0e6dd7f3202011a97bab0de8f5e306ff70a1430ad02c9ccfc09b',
'app/src/main/java/com/okn/dsp/transport/DspTransport.kt':'1e2a2a54c2e31323da4bbc6f9efab01c2fdd2c2f2c9ebc8ee9d6f3e0ea1b6750',
}
for rel,hv in hashes.items(): sha(rel,hv)

assert u.count('class UnifiedControlActivity : Activity()')==1
assert u.count('private fun failClosedDisconnectedAllStatus(callbackGatt: BluetoothGatt, statusCode: Int)')==1
assert 'failClosedPassiveDisconnect(' not in u

print('V86 PRECHECK PASS')
print('versionCode=86')
print('releasePurpose=artifact-delivery-path-fix')
print('stableSigningKeySha256=ba1c52f2607c09953c52fdd79c5f72026aaf0adb8aa44bcba277f7d9b49d9511')
print('disconnectInvariant=STATE_DISCONNECTED-before-status-error')
print('writerCounts=scalar2 eqWrite1 eqRestore1 save1 generic0')
print('protocolTransportHashes=V84/V85-frozen')
