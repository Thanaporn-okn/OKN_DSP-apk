OKN DSP V55 — SAVEPARAMS SETTLE-HANG RECOVERY

WHY V55 EXISTS
- V54 successfully reached: "SaveParams queued after TARGET • waiting 3500ms commit settle", but the delayed UI/phase transition did not run on the tested Samsung/Android device.
- That means the exact guarded SaveParams ID7 trigger may already have been queued while local phase incorrectly remained IDLE.
- V55 removes delayed-handler ownership of proof state. After Android accepts the exact guarded ID7 write into the GATT queue, V55 immediately persists WAIT_TARGET_REBOOT or WAIT_RESTORE_REBOOT. This is only a SAVE ATTEMPT marker; persistence is still proven only by a real power-cycle and fresh Device Description.

V54 STUCK-STATE RECOVERY
- If V55 reads CH1 / ID4 / Band4 at exactly -0.1 dB while local phase is IDLE/SAVE_NOT_PROVEN, it does NOT re-send SaveParams.
- It enables: RESUME V54/V55 PENDING -0.1 dB SAVE ATTEMPT (NO WRITE).
- User confirmation stores WAIT_TARGET_REBOOT with no write and no SaveParams trigger. Then a real power-cycle proves whether the V54 SaveParams attempt actually persisted.

NORMAL V55 SAVE FLOW
- baseline 0.0 -> target -0.1 -> Device Description verify -> exact SaveParams ID7 trigger
- immediately persist WAIT_TARGET_REBOOT
- wait at least 5 seconds; delayed UI message is advisory only
- power-cycle -> reconnect/start -> verify -0.1
- restore 0.0 -> verify -> exact SaveParams ID7 trigger
- immediately persist WAIT_RESTORE_REBOOT
- wait at least 5 seconds -> power-cycle -> reconnect/start -> verify 0.0

SAFETY
- SaveParams remains restricted to actuator ID7, offset0, length0, no payload; exact plaintext 570000000700000000.
- Generic writes remain locked.
- Recovery path never writes and never re-sends SaveParams.
- A non-success SaveParams GATT callback rolls the local phase back and blocks power-cycle.
