OKN DSP V74 — GATT ARM-BEFORE-WRITE ORDERING FIX

Authoritative base
- Source base: V73 Persistent Diagnostics + Safe GATT Uncertainty.
- V73 runtime qualification proved Production UI Global write/verify/return-to-baseline, safe PEAKING EQ write/verify/return-to-baseline, guarded SaveParams PRE/POST checks, and persistent diagnostic export.
- V73 diagnostic evidence also exposed a real ordering race where an EQ target onCharacteristicWrite callback could arrive before GATT_ACTION_ARM was recorded (callbackAgeMs=-1, armedGattIdentity=0).

V74 scope
- No new DSP write family.
- No payload/protocol changes.
- Keep scalar allow-list IDs: 2,3,8,9,10,13,11.
- Keep EQ writes limited to verified safe PEAKING type=12 full 48-byte records.
- Keep SaveParams exact trigger through SaveParamsPolicy only.
- Keep sensors read-only, non-standard EQ read-only, generic/unknown/preset/delay writes locked.
- Keep V73 persistent critical diagnostic behavior and V71 stale-GATT identity guards.

V74 ordering invariant
Every AB01 write now prepares the write-ticket before calling Android writeCharacteristic().
For SCALAR_TARGET, SCALAR_RESTORE, EQ_TARGET, EQ_RESTORE and SAVE_PARAMS, V74 also arms timeout + active-GATT identity before writeCharacteristic().
If Android does not accept the write, V74 rolls back the pre-armed ticket and timeout state immediately.

Expected runtime proof
1. Connect / START CONTROL SESSION / SYNC LIVE VALUES.
2. Confirm 7 scalars + 105 EQ + 4 sensors.
3. Temporary BassCutoff ID9 baseline -> +1 Hz -> APPLY+VERIFY -> exact baseline -> APPLY+VERIFY.
4. Temporary safe PEAKING EQ band baseline -> -0.1 dB step -> APPLY+VERIFY -> exact baseline -> APPLY+VERIFY.
5. Guarded SAVE TO DSP once; PRECHECK + SaveParams GATT success + 5s settle + POSTCHECK.
6. Export diagnostic capture.
7. For every control write, GATT_ACTION_ARM must precede TX_WRITE_RESULT/GATT_RESULT and callbackAgeMs must never be -1 for an accepted control callback.

Mobile deliverables remain separate: Source ZIP, GitHub Actions workflow YML, SHA256 TXT.
