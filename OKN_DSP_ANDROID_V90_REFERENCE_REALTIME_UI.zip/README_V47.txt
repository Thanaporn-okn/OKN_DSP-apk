OKN DSP V47 — EQ RESTORE SETTLE + RETRY FIX

WHY V47 EXISTS
- V46 proved the CH1/ID4/Band4 48-byte target write works: Boost 0.0 -> -0.5 dB and the live descriptor verified -0.5.
- V46 then queued the restore immediately after the large VERIFY_TARGET descriptor completed. Android reported GATT write status=0, but reassembling the following VERIFY_RESTORE descriptor showed Band4 was still -0.5 dB.
- The V46 capture was saved before the activity emitted its final restore-verification META line.

V47 FIX
- Same tightly scoped proof only: CH1 actuator ID4, Band4, offset 144, length 48.
- Wait 1500 ms after target-descriptor completion before sending restore.
- Wait 1500 ms after restore write before requesting restore descriptor.
- If the first restore descriptor still does not match baseline, wait 2000 ms and retry restore exactly once.
- Global failsafe window increased to 45 s.
- SaveParams ID7 is never sent. Normal EQ 7CH remains locked/local-only.

TEST
1) Open V47 CONTROLLED EQ BAND WRITE PROOF.
2) SCAN DSP and connect LE-GoloPine_DSP_A.
3) START V47 EQ PROOF SESSION; wait for V47 EQ BASELINE READY.
4) RUN CONTROLLED CH1 BAND4 PROOF (-0.5 dB -> RESTORE) once.
5) Do not touch Volume/EQ/Preset while it runs. Wait for V47 COMPLETE or failure.
6) SAVE V47 CAPTURE TO DOWNLOADS and send the TXT capture.

SUCCESS MARKERS
- V47_TARGET_DESCRIPTOR_VERIFY ... verified=true
- V47_RESTORE_DESCRIPTOR_VERIFY ... verified=true
- V47_CONTROLLED_EQ_WRITE_PROOF_COMPLETE ... restored=true ... saveParamsSent=false
