OKN DSP V87 — LIFECYCLE DESTROY FAIL-CLOSED JOURNAL

Version: 5.18.0-v87-lifecycle-destroy-fail-closed-journal (versionCode 87)

Why V87 exists
- V86 real-DSP runtime proved all-status DISCONNECTED fail-closed with status=8, GATT detach, epoch invalidation, live-cache clear, reconnect recovery, and Health Gate PASS.
- Source audit found a separate lifecycle gap: onBackPressed blocks exit while a control pipeline is active, but Android may still call onDestroy during Activity recreation/configuration change without passing through onBackPressed.
- V86 onDestroy closed GATT but did not journal active Scalar/EQ/Save uncertainty or persist a critical capture before state was discarded.

V87 change
- onDestroy snapshots active Save/Scalar/EQ pipeline state before cancelling timers.
- If a control pipeline is active, records SAVE/SCALAR/EQ UNCONFIRMED markers and persists a critical diagnostic before cleanup.
- Detaches active GATT first, invalidates connection/session epoch and clears live cache, then closes the old GATT.
- No automatic reconnect, START, Auth, Scalar/EQ write, or SaveParams action is launched by onDestroy.
- V86 all-status disconnect behavior, verified writer surface, protocol/transport, stable signing key, Last-DSP cache, and Health Gate are carried unchanged.

Runtime proof target
1) Install V87 over V86 without uninstall/clear-data.
2) Connect -> START -> SYNC -> Health Gate PASS.
3) Trigger Activity recreation while connected but protocol-idle (screen rotation is sufficient if rotation is enabled).
4) Confirm recreated UI is fail-closed/disconnected; reconnect -> START -> SYNC -> Health Gate PASS; export diagnostic.
5) The normal lifecycle proof must show V87_LIFECYCLE_DESTROY_FAIL_CLOSED with controlPipelineUnconfirmed=false.
6) Do NOT intentionally rotate during APPLY/SAVE for the first production qualification. The active-pipeline journal is statically guarded; destructive timing tests are not required to prove normal lifecycle detach.
