OKN DSP V71 — STALE-GATT CALLBACK ISOLATION

V71 is a production hardening release built directly from the runtime-qualified V70 source.

Preserved verified scope:
- Global scalar writes: IDs 2,3,8,9,10,13,11
- EQ writes: only verified safe PEAKING type=12 full 48-byte records
- Sensors: READ ONLY
- SaveParams: manual guarded, fresh PRE-SAVE + POST-SAVE descriptor checks
- Power-cycle/reconnect persistence proof: 7 scalars + 105 EQ, read-only
- genericWrites=false; preset/delay/unknown writes remain locked

New V71 hardening:
- Every BluetoothGatt callback must belong to the current active gatt object before any session/crypto/ticket/proof/UI state can be changed.
- Old gatt is detached before close/reconnect and on Activity destruction.
- Stale callbacks are recorded as V71_UNIFIED_STALE_GATT_CALLBACK_IGNORED and otherwise ignored.

This restores the stale-GATT safety invariant documented in the V56 proof plan to the current Unified production path.
