OKN DSP V48 — EQ BAND RECOVERY ONLY

WHY V48 EXISTS
- V46 proved that 48-byte EQ WRITE 0x57 works on the real DSP.
- V46 target verification succeeded for CH1 / actuator ID4 / Band4 / offset144 at Boost=-0.5 dB.
- V46 restore did not reflect, and the later V47 read-only capture confirms the live band is still the exact V46 -0.5 dB target.
- V47 itself did not send any EQ write in the uploaded capture; it stopped after the INITIAL Device Description.

V48 SAFETY POLICY
- Only CH1 actuator ID4 / Band4 / offset144 / length48 is writable.
- Live descriptor MUST classify as the known V46 target (-0.5 dB) before RECOVER is enabled.
- If already original 0.0 dB, V48 sends no write.
- If the live band is anything else, V48 blocks recovery.
- Recovery payload is the exact original 48-byte V46 baseline record:
  0C0000000000C8420000000052B80E400000000000000000000000000000803FAE28FFBF9A5E7E3FAE28FFBF9A5E7E3F
- Recovery uses WRITE 0x57 / ID4 / offset144 / len48, waits 3s, then refreshes Device Description.
- One retry max after 2.5s if the first recovery has not reflected.
- SaveParams ID7 is NEVER sent. Normal EQ/Preset/unknown writes remain locked.

PHONE TEST
1) Open V48 EQ BAND RECOVERY.
2) SCAN DSP and connect LE-GoloPine_DSP_A.
3) START V48 RECOVERY SESSION -> START READ-ONLY RECOVERY CHECK.
4) Wait for one of:
   - V48 RECOVERY READY -> current band is known V46 -0.5 dB target.
   - V48 ALREADY RECOVERED -> no write needed.
   - RECOVERY BLOCKED -> stop and save capture.
5) If READY, press RECOVER CH1 BAND4 TO V46 ORIGINAL (0.0 dB) once.
6) Confirm RECOVER ORIGINAL; do not touch Volume/EQ/Preset while it runs.
7) Wait for V48 COMPLETE.
8) SAVE V48 RECOVERY CAPTURE TO DOWNLOADS and send the TXT capture.

SUCCESS MARKERS
- V48_RECOVERY_BASELINE ... classification=V46_TARGET_MINUS0P5DB
- V48_EQ_RECOVERY_WRITE_PLAIN=57... actuator=4 band=4 offset=144 originalBoost=0.0 saveParams=false
- V48_RECOVERY_DESCRIPTOR_VERIFY ... expectedBoost=0.0 actualBoost=0.0 verified=true
- V48_EQ_RECOVERY_COMPLETE ... restoredToV46Original=true ... saveParamsSent=false
