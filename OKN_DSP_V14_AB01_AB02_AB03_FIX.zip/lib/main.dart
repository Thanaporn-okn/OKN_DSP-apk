
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() => runApp(const OknDspApp());

class OknDspApp extends StatelessWidget {
  const OknDspApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'OKN DSP V12',
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.blue),
    home: const HomePage(),
  );
}

class DeviceInfo {
  final String name, address; final int rssi;
  const DeviceInfo(this.name, this.address, this.rssi);
}
class Packet {
  final String ch, hex, time; final int length;
  const Packet(this.ch, this.hex, this.time, this.length);
}
class ReadResult {
  final String stage, hex; final int length, status;
  const ReadResult(this.stage, this.hex, this.length, this.status);
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  static const methods = MethodChannel('okn_dsp/methods');
  static const events = EventChannel('okn_dsp/events');
  StreamSubscription? sub;
  final devices = <String, DeviceInfo>{};
  final packets = <Packet>[];
  final reads = <ReadResult>[];
  DeviceInfo? selected;
  String status = 'กด Bluetooth เพื่อค้นหา';
  String notifyStatus = 'ยังไม่ได้เปิด Notify';
  String gatt = '';
  String stage = 'ยังไม่ได้เริ่ม';
  bool scanning = false, connected = false, testing = false;

  @override void initState() {
    super.initState();
    sub = events.receiveBroadcastStream().listen(_onEvent);
  }

  void _onEvent(dynamic e) {
    if (!mounted || e is! Map) return;
    final t = e['type']?.toString() ?? '';
    if (t == 'scan') {
      final a = e['address']?.toString() ?? '';
      if (a.isNotEmpty) setState(() {
        devices[a] = DeviceInfo(
          (e['name']?.toString().isNotEmpty ?? false)
              ? e['name'].toString() : '(บอร์ดไม่ส่งชื่อ)',
          a, int.tryParse('${e['rssi']}') ?? 0);
      });
    } else if (t == 'scan_done') {
      setState(() { scanning=false; status='ค้นหาเสร็จแล้ว — พบ ${devices.length} อุปกรณ์'; });
    } else if (t == 'status') {
      setState(() => status=e['message']?.toString() ?? '');
    } else if (t == 'connected') {
      setState(() { connected=true; status='เชื่อมต่อ DSP แล้ว'; });
    } else if (t == 'disconnected') {
      setState(() { connected=false; testing=false; stage='หลุดการเชื่อมต่อ'; });
    } else if (t == 'gatt') {
      setState(() => gatt=e['text']?.toString() ?? '');
    } else if (t == 'notify') {
      setState(() => notifyStatus=e['message']?.toString() ?? '');
    } else if (t == 'rx') {
      setState(() {
        packets.insert(0, Packet(e['characteristic']?.toString() ?? '',
          e['data']?.toString() ?? '', e['time']?.toString() ?? '',
          int.tryParse('${e['length']}') ?? 0));
        if (packets.length>200) packets.removeLast();
      });
    } else if (t == 'read') {
      setState(() {
        reads.insert(0, ReadResult(e['stage']?.toString() ?? 'READ',
          e['data']?.toString() ?? '', int.tryParse('${e['length']}') ?? 0,
          int.tryParse('${e['status']}') ?? -1));
      });
    } else if (t == 'test') {
      setState(() => stage=e['message']?.toString() ?? '');
    }
  }

  Future<void> scan() async {
    setState(() { scanning=true; devices.clear(); status='กำลังค้นหา Bluetooth...'; });
    try { await methods.invokeMethod('scan'); }
    catch(e) { if(mounted) setState(() { scanning=false; status='สแกนไม่ได้: $e'; }); }
  }

  Future<void> connect(DeviceInfo d) async {
    setState(() { selected=d; connected=false; packets.clear(); reads.clear();
      gatt=''; stage='กำลังเชื่อมต่อ...'; notifyStatus='กำลังเชื่อมต่อ'; });
    try { await methods.invokeMethod('connect', {'address':d.address}); }
    catch(e) { if(mounted) setState(() => status='เชื่อมต่อไม่ได้: $e'); }
  }

  Future<void> runTest() async {
    if(!connected || testing) return;
    setState(() { testing=true; packets.clear(); reads.clear(); stage='AB01 → AB02 → AB03'; });
    try { await methods.invokeMethod('startFullTest'); }
    catch(e) { if(mounted) setState(() { testing=false; stage='ทดสอบไม่สำเร็จ: $e'; }); }
  }

  Future<void> readAb01() async {
    if(!connected) return;
    try { await methods.invokeMethod('readAb01'); }
    catch(e) { if(mounted) setState(() => stage='AB01 READ ไม่สำเร็จ: $e'); }
  }

  Future<void> copyAll() async {
    final lines=<String>[
      'OKN DSP V12 REVERSE ENGINEERING CAPTURE',
      'KNOWN: AB00 / AB01 / AB02 / AB03',
      'KNOWN: TX sample=16 bytes; RX sample=32 bytes',
      'KNOWN: bulk=18252 bytes = 77*235+157',
      'UNPROVEN: opcode/header/checksum/encryption/coefficient/endian/address',
      '',
      if(selected!=null) 'DEVICE: ${selected!.name} | ${selected!.address}',
      'STAGE: $stage','',
      'AB01 READ:',
      ...reads.reversed.map((r)=>'${r.stage} | STATUS=${r.status} | LEN=${r.length} | ${r.hex}'),
      '','NOTIFY:',
      ...packets.reversed.map((p)=>'${p.time} | ${p.ch} | LEN=${p.length} | ${p.hex}'),
    ];
    await Clipboard.setData(ClipboardData(text:lines.join('\n')));
    if(mounted) ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content:Text('คัดลอกข้อมูล Reverse Engineering แล้ว')));
  }

  Widget info() => Card(child: Padding(padding:const EdgeInsets.all(16), child:Column(
    crossAxisAlignment:CrossAxisAlignment.start, children: const [
      Text('ข้อมูลที่ยืนยันแล้ว',style:TextStyle(fontSize:21,fontWeight:FontWeight.bold)),
      SizedBox(height:8),
      Text('• Service AB00\n• AB01 = READ / WRITE, value handle 0x0006\n'
           '• AB02 = NOTIFY, value handle 0x0008, CCCD 0x0009\n'
           '• AB03 = NOTIFY, CCCD 0x000C\n• TX พบ 16 bytes / RX พบ 32 bytes\n'
           '• bulk notification 18,252 bytes = 77×235 + 157\n'
           '• 235 bytes ยังไม่ยืนยันว่าเป็น application packet'),
      SizedBox(height:10),
      Text('ยังไม่ยืนยัน: opcode/header, checksum/MAC, encryption/key, '
           'coefficient format, endian, bytes/stage, padding, address formula และ cascade=channel',
        style:TextStyle(fontWeight:FontWeight.w600)),
    ])));

  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('OKN DSP Controller V12'),
      actions:[IconButton(onPressed:scanning?null:scan,icon:const Icon(Icons.bluetooth_searching))]),
    body:ListView(padding:const EdgeInsets.all(12),children:[
      info(),
      if(selected!=null) Card(child:ListTile(
        leading:const Icon(Icons.developer_board), title:Text(selected!.name),
        subtitle:Text('${selected!.address}\nRSSI ${selected!.rssi} dBm'),
        trailing:connected?const Icon(Icons.bluetooth_connected):
          FilledButton(onPressed:()=>connect(selected!),child:const Text('เชื่อมต่อ')))),
      if(!connected) Card(child:Column(children:[
        const ListTile(title:Text('เลือกอุปกรณ์ช่องควบคุม DSP')),
        ...devices.values.map((d)=>ListTile(
          leading:const Icon(Icons.bluetooth), title:Text(d.name),
          subtitle:Text('${d.address}  RSSI ${d.rssi}'),
          trailing:OutlinedButton(onPressed:()=>connect(d),child:const Text('ใช้เป็น DSP')))),
        if(devices.isEmpty) const Padding(padding:EdgeInsets.all(16),
          child:Text('ยังไม่พบอุปกรณ์ กด Bluetooth ด้านบน')),
      ])),
      Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(
        crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text('สถานะ: $status'),const SizedBox(height:6),Text('ขั้นตอน: $stage'),
          const SizedBox(height:10),
          if(connected) FilledButton.icon(onPressed:testing?null:runTest,
            icon:const Icon(Icons.science),
            label:Text(testing?'กำลังเก็บ AB01 → AB02 → AB03...':'เริ่มทดสอบ AB01 → AB02 → AB03')),
          const SizedBox(height:6),
          OutlinedButton.icon(onPressed:connected?readAb01:null,
            icon:const Icon(Icons.download),label:const Text('อ่าน AB01 (READ เท่านั้น)')),
          const SizedBox(height:6),
          OutlinedButton.icon(onPressed:copyAll,icon:const Icon(Icons.copy),
            label:const Text('คัดลอกข้อมูลทั้งหมดเพื่อวิเคราะห์')),
        ]))),
      if(gatt.isNotEmpty) Card(child:Padding(padding:const EdgeInsets.all(10),
        child:SelectableText(gatt,style:const TextStyle(fontFamily:'monospace',fontSize:11)))),
      ListTile(title:const Text('AB01 READ RESPONSE',style:TextStyle(fontWeight:FontWeight.bold)),
        subtitle:Text('${reads.length} รายการ')),
      ...reads.map((r)=>Card(child:Padding(padding:const EdgeInsets.all(10),
        child:SelectableText('${r.stage}\nSTATUS=${r.status}  LEN=${r.length}\n${r.hex}',
          style:const TextStyle(fontFamily:'monospace'))))),
      ListTile(title:const Text('RX จาก AB02 / AB03',style:TextStyle(fontWeight:FontWeight.bold)),
        subtitle:Text('${packets.length} packets')),
      if(packets.isEmpty) const Padding(padding:EdgeInsets.all(20),
        child:Text('ยังไม่มี packet — เชื่อมต่อและเริ่มทดสอบ')),
      ...packets.take(80).map((p)=>Card(child:Padding(padding:const EdgeInsets.all(8),
        child:SelectableText('${p.time} | ${p.ch} | LEN=${p.length}\n${p.hex}',
          style:const TextStyle(fontFamily:'monospace',fontSize:12))))),
      const Card(child:Padding(padding:EdgeInsets.all(14),child:Text(
        '🛑 V12 เก็บหลักฐานเท่านั้น — ยังไม่มีการสร้าง/ส่ง payload ควบคุม DSP '
        'จากค่าที่ไม่พิสูจน์ เป้าหมายคือหาขอบเขต packet และความสัมพันธ์ของ AB01/AB02/AB03 ก่อนเขียน codec จริง.',
        style:TextStyle(fontWeight:FontWeight.w600)))),
    ]));
  @override void dispose(){sub?.cancel();super.dispose();}
}
