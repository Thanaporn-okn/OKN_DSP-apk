# OKN DSP V14 — AB01 → AB02 → AB03 Diagnostic

V14 fixes the build failure caused by Flutter's generated `test/widget_test.dart`
still referencing the old `MyApp` class.

The build workflow also deletes the generated `test/` directory before analysis,
so no stale MyApp test can enter the build.

DSP diagnostic flow:
1. Connect to the discovered real DSP.
2. Discover GATT.
3. Enable AB02 Notify.
4. Enable AB03 Notify.
5. READ AB01.
6. Capture raw AB02/AB03 packets.
7. Do not send guessed DSP-control payloads.

Known GATT:
Service 0000AB00-0000-1000-8000-00805F9B34FB
AB01 0000AB01-0000-1000-8000-00805F9B34FB  READ/WRITE
AB02 0000AB02-0000-1000-8000-00805F9B34FB  NOTIFY
AB03 0000AB03-0000-1000-8000-00805F9B34FB  NOTIFY
