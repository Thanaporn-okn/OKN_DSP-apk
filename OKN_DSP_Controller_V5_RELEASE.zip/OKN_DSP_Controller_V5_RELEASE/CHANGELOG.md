# Changelog

## V5.0.0
- DSP architecture
- BLE control framework
- BP1048P4 protocol layer
- Device profiles
- Preset system
- Debug framework
