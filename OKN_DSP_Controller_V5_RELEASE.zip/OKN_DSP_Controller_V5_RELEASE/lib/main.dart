import 'package:flutter/material.dart';

void main(){
  runApp(const OKNDSPApp());
}

class OKNDSPApp extends StatelessWidget{
  const OKNDSPApp({super.key});

  @override
  Widget build(BuildContext context){
    return MaterialApp(
      title: 'OKN DSP Controller V5',
      theme: ThemeData.dark(),
      home: const Scaffold(
        body: Center(
          child: Text('OKN DSP Controller V5')
        ),
      ),
    );
  }
}
