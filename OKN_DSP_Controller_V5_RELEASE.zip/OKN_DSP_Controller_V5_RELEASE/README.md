# OKN DSP Controller V5 RELEASE

Flutter project release structure.

Build:
flutter pub get
flutter build apk --release

Target:
MVSilicon BP1048P4 / GHXAMP 7CH framework
