import 'package:flutter/material.dart';

void main()=>runApp(const OKNDSP());

class OKNDSP extends StatelessWidget{
 const OKNDSP({super.key});

 @override
 Widget build(BuildContext context){
  return MaterialApp(
   debugShowCheckedModeBanner:false,
   theme:ThemeData.dark(),
   home:Scaffold(
    appBar:AppBar(title:const Text('OKN_DSP BP1048P4 V39')),
    body:const Padding(
     padding:EdgeInsets.all(20),
     child:Text(
      'Clean Android V2 Build\n\n'
      'Bluetooth DSP Controller\n'
      'BP1048P4 Command Layer\n'
      'CH1-CH7 Mixer Ready\n'
      'TX RX Monitor',
      style:TextStyle(fontSize:22),
     ),
    ),
   ),
  );
 }
}
