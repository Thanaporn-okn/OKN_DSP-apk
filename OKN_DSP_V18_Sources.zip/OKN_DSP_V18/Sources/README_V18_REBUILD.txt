OKN_DSP V18 — REBUILD FROM UI BASELINE
======================================

Goal
- Rebuild the DSP application UI around the five supplied 864x1536 reference screens.
- Keep one responsive 864x1536 design coordinate system and scale it to the available phone/tablet viewport.
- Every visible control has an active touch target; sliders follow the finger immediately.
- Bottom navigation implements Home / EQ / Crossover / Delay / Output.
- CH1..CH7 tabs are active on EQ / Crossover / Delay / Output.

Verified hardware paths carried from supplied V17 evidence
- Master Volume ID2
- Bass Volume ID8
- Bass Cutoff ID9
- Bass Boost ID10
- Treble Boost ID11 with safe <=0.5 dB slew
- Middle Boost ID13
- 7 x 15 EQ records on actuator IDs 4/5/6/14/15/16/17
- Device Description authentication, AES-CFB8 stream and AB00/AB01/AB02 transport
- Original-app ~380 ms serialized command scheduler

V18 EQ extension
- PEAKING type12 records can update Frequency/Gain/Q by rebuilding the known 48-byte filter record and preserving auxiliary F2/G/R metadata.
- Native Band-1 Tone Control / General Low-pass handling remains gain-only to avoid changing an unverified field mapping.

Important protocol boundary
- The supplied files do not contain verified actuator IDs / binary layouts for Crossover, Delay, per-channel Output, Mute, Solo, Phase, Link, Audio Source or System Preset.
- Those UI controls are implemented and update immediately, but their hardware writes remain protocol-gated. V18 does not invent actuator IDs or packet layouts.
- Once real packet captures for those controls are supplied, they can be connected without redesigning the UI.

Build
- Android Java, no external app runtime dependencies.
- compileSdk/targetSdk 35, minSdk 26, Java 17.
- Stable com.okn.dsp package and signing keystore retained for update compatibility.
