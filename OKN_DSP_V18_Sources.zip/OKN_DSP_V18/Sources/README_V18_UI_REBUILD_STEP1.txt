OKN_DSP V18 — STEP 1 FRESH REBUILD
==================================

GOAL
- Rebuild the DSP app UI from the five uploaded reference screens only:
  Home, EQ, Crossover, Delay and Output.
- Keep the uploaded V17 real-device BLE/protocol implementation as the hardware transport baseline.
- Make every visible UI control respond immediately on touch.
- Use one 864x1536 reference coordinate system and uniform scaling so touch geometry and artwork remain aligned on phones/tablets.

UI IMPLEMENTED
1) Home
   - Master Volume, Bass Volume, Bass Cutoff, Bass Boost, Middle Boost, Treble Boost.
   - Audio Source selector, System Preset selector and Device Status panel.
2) EQ
   - CH1..CH7 selection.
   - 15 bands in pages 1-6, 7-12, 13-15.
   - Graph touch Gain adjustment, table Type/Frequency/Gain/Q/Power controls.
   - Preset save/load in local SharedPreferences.
3) Crossover
   - HPF / LPF cards, filter type, frequency, slope, bypass.
   - Graph preview, reset, phase, polarity, L/R link and output mode.
4) Delay
   - CH1..CH7 delay sliders, ms/cm display, seat preset and Sync All.
5) Output
   - Master output, CH1..CH7 levels, Mute, Solo, Phase, Link, All Mute Off and Reset Levels.

HARDWARE SAFETY
- No guessed DSP packet is introduced.
- Uploaded V17 verified hardware writes are retained for Home scalar actuators and the 15 EQ records.
- Crossover / Delay / Output and unverified EQ Frequency/Q/Power operations change the UI immediately, but hardware serialization stays locked until a verified actuator/packet mapping is recovered.
- The original-app-style 380 ms serialized BLE command scheduler remains in BleManager. UI motion itself is immediate; command coalescing prevents the audio-stutter behavior documented in earlier versions.
- Treble ID11 retains the bounded safe-slew behavior from the uploaded V17 baseline.

VERSION POLICY
- V18 is Step 1 of the fresh rebuild.
- Do not overwrite a failed version. If a real build/runtime error is reported, create the next version number (V19, V20, ...).
