OKN_DSP V18 — 4-PAGE MINIMAL REAL-TIME UI
===========================================
Base: OKN_DSP V17 source package supplied by the user.

PAGES
1) Home
   - BLE/DSP connection status.
   - Shortcuts to Mix, EQ and Crossover.
   - Runtime/transport status.

2) Mix
   - Master Volume
   - Bass Volume
   - Bass Cutoff
   - Bass Boost
   - Middle Boost
   - Treble Boost
   UI follows the finger immediately.
   Hardware writes use the V17 verified actuator IDs and the original-app ~380 ms coalescing scheduler.
   Treble Boost keeps the V14 bounded safe-slew behavior while accepting the newest drag target continuously.

3) EQ
   - 15 bands × 7 channels.
   - Frequency / Gain / Q controls for the selected band.
   - Output Gain UI control.
   - Save/Load preset.
   - Type-12 PEAKING records: Frequency/Q/Gain are rebuilt from the existing verified 48-byte record format.
   - CH3 Band 1 native type-3 General Low-pass: Frequency/Q/Gain are rebuilt without type conversion.
   - CH1/2/4/5/6/7 Band 1 native type-17 Tone Control: Gain remains hardware-live; Q is not exposed as a hardware write because Tone Control does not use PEAKING-Q semantics. The UI can still be moved, but hardware shape write is intentionally locked.
   - Output Gain actuator ID/packet is not present in the supplied verified evidence, so its UI is real-time but hardware write is intentionally locked.

4) Crossover
   - Per-channel HPF, LPF and Delay controls.
   - Save/Load local preset.
   - UI follows the finger immediately.
   - The supplied V17 evidence explicitly states Crossover/Delay/unknown output writes remain locked. V18 therefore does NOT invent actuator IDs or packet layouts. Hardware writes remain locked until a real packet/descriptor mapping is captured.

REAL-TIME TRANSPORT RULE
- UI animation/touch tracking is immediate.
- Verified hardware commands are coalesced and serialized through the existing ~380 ms BLE scheduler copied from the original-app capture. This intentionally avoids high-rate AB01 flooding and the audio pumping/stutter incidents documented in V11/V13.

NO-GUESS POLICY
- V18 does not invent Crossover, Delay, Output Gain, Mute or Phase actuator IDs.
- Existing V17 BLE authentication, AES-CFB8 stream handling, AB01/AB02 transport, descriptor health gate and stable signing key are retained.
