OKN_DSP V18 — FIVE-PAGE UI REBUILD
==================================
Base: V17 transport/protocol source.

V18 UI scope is intentionally limited to the five user-supplied reference screens:
1. Home
2. Parametric EQ
3. Crossover
4. Delay
5. Output

Responsive behavior
- Reference coordinate space: 864 x 1536.
- The custom Android View maps drawing and touch coordinates to the physical display every frame.
- The app stays immersive/full-screen and all visible controls have touch hit areas.
- Slider values update visually on ACTION_MOVE without waiting for a BLE reply.

Verified live DSP control retained from uploaded source evidence
- Master Volume ID2
- Bass Volume ID8
- Bass Cutoff ID9
- Bass Boost ID10
- Middle Boost ID13
- Treble Boost ID11 with inherited V14 safe-slew behavior
- CH1..CH7 fifteen-band EQ gain through actuators 4,5,6,14,15,16,17 using V17 filter-aware Band 1 handling and V16 PEAKING handling for Bands 2..15

Important no-guess boundary
The uploaded V17 evidence explicitly states that Crossover, Delay, unknown Output/Fader/Mute/Phase writes do not yet have verified actuator mappings. V18 therefore makes those reference-page controls fully interactive and persistent in the UI, but does NOT fabricate unknown DSP packets. EQ Type/Frequency/Q/Power selectors are also interactive UI controls; the verified live writer continues to commit EQ gain only.

This distinction is required so the source remains faithful to the uploaded protocol evidence rather than pretending unverified controls are hardware-qualified.
