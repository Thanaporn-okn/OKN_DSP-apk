package com.okn.dsp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import java.util.Locale;

/**
 * OKN_DSP V18 single-surface responsive UI.
 * Reference coordinate space is 864x1536 (the uploaded UI captures).
 * It scales uniformly to every phone/tablet while preserving touch geometry.
 */
final class DspView extends View {
    private static final float W = 864f;
    private static final float H = 1536f;
    private static final float NAV_TOP = 1400f;
    private static final float NAV_H = 118f;

    private static final int PAGE_HOME = 0;
    private static final int PAGE_EQ = 1;
    private static final int PAGE_XOVER = 2;
    private static final int PAGE_DELAY = 3;
    private static final int PAGE_OUTPUT = 4;

    private static final int DRAG_NONE = 0;
    private static final int DRAG_HOME = 1;
    private static final int DRAG_EQ_GRAPH = 2;
    private static final int DRAG_DELAY = 3;
    private static final int DRAG_OUTPUT = 4;
    private static final int DRAG_MASTER_OUTPUT = 5;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint s = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final DspState state = new DspState();
    private BleManager ble;

    private int page = PAGE_HOME;
    private int dragKind = DRAG_NONE;
    private int dragIndex = -1;
    private float scale = 1f, ox = 0f, oy = 0f;
    private String bleStatus = "กำลังค้นหา...";
    private String bleDevice = "OKN-DSP-7CH";
    private boolean bleConnected = false;
    private String diagnostic = "";
    private final boolean[] unverifiedWarned = new boolean[5];

    private final int BG = Color.rgb(0, 8, 18);
    private final int PANEL = Color.rgb(3, 28, 49);
    private final int PANEL2 = Color.rgb(2, 18, 34);
    private final int BORDER = Color.rgb(12, 70, 116);
    private final int WHITE = Color.rgb(244, 248, 255);
    private final int SUB = Color.rgb(161, 190, 225);
    private final int CYAN = Color.rgb(0, 218, 255);
    private final int BLUE = Color.rgb(0, 126, 255);
    private final int GREEN = Color.rgb(0, 235, 126);
    private final int MAGENTA = Color.rgb(238, 52, 243);
    private final int ORANGE = Color.rgb(255, 148, 35);

    private final int[] chColors = {
            Color.rgb(20, 200, 255), Color.rgb(255, 156, 39), Color.rgb(0, 227, 102),
            Color.rgb(255, 218, 47), Color.rgb(255, 132, 38), Color.rgb(255, 58, 98),
            Color.rgb(207, 53, 245)
    };

    DspView(Context context, BleManager ble) {
        super(context);
        this.ble = ble;
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        setFocusable(true);
        setClickable(true);
        setHapticFeedbackEnabled(false);
        state.loadAll(context);
    }

    void setBleManager(BleManager manager) { ble = manager; }

    void setBleStatus(String status, String deviceName, boolean connected) {
        bleStatus = status == null ? "" : status;
        if (deviceName != null && !deviceName.trim().isEmpty()) bleDevice = deviceName;
        bleConnected = connected;
        invalidate();
    }

    void setDiagnostic(String message) {
        diagnostic = message == null ? "" : message;
        invalidate();
    }

    void setScalarFromDsp(int actuatorId, float value) {
        switch (actuatorId) {
            case DspProtocol.ID_MASTER_VOLUME: state.masterVolume = value; break;
            case DspProtocol.ID_BASS_VOLUME: state.bassVolume = value; break;
            case DspProtocol.ID_BASS_CUTOFF: state.bassCutoff = value; break;
            case DspProtocol.ID_BASS_BOOST: state.bassBoost = value; break;
            case DspProtocol.ID_MIDDLE_BOOST: state.middleBoost = value; break;
            case DspProtocol.ID_TREBLE_BOOST: state.trebleBoost = value; break;
            default: return;
        }
        invalidate();
    }

    void setEqFromDsp(int channel0, int uiBand0, float frequency, float gainDb, float q, boolean writable) {
        if (channel0 < 0 || channel0 >= DspState.CHANNELS || uiBand0 < 0 || uiBand0 >= DspState.BANDS) return;
        state.freq[channel0][uiBand0] = frequency;
        state.gain[channel0][uiBand0] = gainDb;
        state.q[channel0][uiBand0] = q;
        state.eqWritable[channel0][uiBand0] = writable;
        invalidate();
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float sx = getWidth() / W;
        float sy = getHeight() / H;
        scale = Math.min(sx, sy);
        if (!Float.isFinite(scale) || scale <= 0f) scale = 1f;
        ox = (getWidth() - W * scale) * 0.5f;
        oy = (getHeight() - H * scale) * 0.5f;

        c.drawColor(Color.BLACK);
        c.save();
        c.translate(ox, oy);
        c.scale(scale, scale);
        drawBackdrop(c);
        drawHeader(c);
        if (page != PAGE_HOME) drawChannelTabs(c);
        switch (page) {
            case PAGE_EQ: drawEq(c); break;
            case PAGE_XOVER: drawCrossover(c); break;
            case PAGE_DELAY: drawDelay(c); break;
            case PAGE_OUTPUT: drawOutput(c); break;
            default: drawHome(c); break;
        }
        drawBottomNav(c);
        c.restore();
    }

    private void drawBackdrop(Canvas c) {
        p.setShader(new LinearGradient(0, 0, W, H, Color.rgb(0, 18, 36), BG, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, W, H, p);
        p.setShader(null);
    }

    private void drawHeader(Canvas c) {
        drawWaveLogo(c, 64, 53, CYAN);
        text(c, page == PAGE_HOME ? "OKN_DSP" : "DSP Control", 116, 54, 34, WHITE, true, Paint.Align.LEFT);
        text(c, "Professional Audio Processor", 116, 84, 18, Color.rgb(126, 192, 246), false, Paint.Align.LEFT);

        roundPanel(c, 515, 21, 260, 72, 14, Color.rgb(14, 30, 46), Color.rgb(28, 53, 78));
        roundPanel(c, 528, 34, 42, 44, 10, Color.rgb(0, 118, 190), Color.rgb(26, 132, 207));
        text(c, "ᛒ", 549, 64, 28, WHITE, false, Paint.Align.CENTER);
        text(c, bleConnected ? "เชื่อมต่ออุปกรณ์" : bleStatus, 585, 50, 17, WHITE, true, Paint.Align.LEFT);
        text(c, bleDevice, 585, 73, 12.5f, SUB, false, Paint.Align.LEFT);
        p.setColor(bleConnected ? GREEN : Color.rgb(255, 191, 44));
        p.setShadowLayer(10, 0, 0, p.getColor());
        c.drawCircle(750, 57, 7, p);
        p.clearShadowLayer();
        drawGear(c, 816, 57, Color.rgb(194, 218, 255));
    }

    private void drawChannelTabs(Canvas c) {
        float y = 104f, x0 = 19f, gap = 6f;
        float w = (826f - gap * 6f) / 7f;
        for (int ch = 0; ch < 7; ch++) {
            float x = x0 + ch * (w + gap);
            boolean sel = state.channel == ch;
            roundPanel(c, x, y, w, 76, 11, sel ? Color.rgb(0, 126, 239) : PANEL2, sel ? CYAN : BORDER);
            if (sel) glowRect(c, x, y, w, 76, 11, CYAN);
            text(c, DspState.CHANNEL_SHORT[ch], x + w / 2, y + 31, 18, WHITE, true, Paint.Align.CENTER);
            text(c, DspState.CHANNEL_NAME[ch], x + w / 2, y + 58, 15, WHITE, false, Paint.Align.CENTER);
        }
    }

    private void drawHome(Canvas c) {
        String[] title = {"Master Volume", "Bass Volume", "Bass Cutoff", "Bass Boost", "Middle Boost", "Treble Boost"};
        String[] thai = {"ปรับระดับเสียงรวม", "ปรับระดับเสียงเบส", "ตั้งค่าความถี่ตัดเบส", "เพิ่มความหนักแน่นของเบส", "เพิ่มความชัดเจนย่านกลาง", "เพิ่มความใสย่านแหลม"};
        int[] colors = {BLUE, CYAN, MAGENTA, Color.rgb(255, 42, 111), Color.rgb(0, 154, 255), MAGENTA};
        for (int i = 0; i < 6; i++) {
            float y = 124 + i * 145f;
            roundPanel(c, 16, y, 832, 132, 19, PANEL, BORDER);
            drawRoundIcon(c, 74, y + 66, colors[i], i);
            text(c, title[i], 165, y + 56, 27, WHITE, true, Paint.Align.LEFT);
            text(c, thai[i], 165, y + 91, 18, SUB, false, Paint.Align.LEFT);
            drawHomeSlider(c, i, y + 62, colors[i]);
        }

        float by = 1001;
        roundPanel(c, 16, by, 408, 170, 18, PANEL, BORDER);
        drawMusicIcon(c, 73, by + 55, BLUE);
        text(c, "Audio Source", 140, by + 43, 23, WHITE, true, Paint.Align.LEFT);
        text(c, "แหล่งสัญญาณเสียง", 140, by + 73, 16, SUB, false, Paint.Align.LEFT);
        dropBox(c, 140, by + 91, 252, 55, DspState.AUDIO_SOURCES[state.audioSource]);

        roundPanel(c, 16, by + 182, 408, 170, 18, PANEL, BORDER);
        drawListIcon(c, 73, by + 238, BLUE);
        text(c, "System Preset", 140, by + 225, 23, WHITE, true, Paint.Align.LEFT);
        text(c, "พรีเซ็ตระบบ", 140, by + 255, 16, SUB, false, Paint.Align.LEFT);
        dropBox(c, 140, by + 274, 252, 55, DspState.HOME_PRESETS[state.homePreset]);

        roundPanel(c, 438, by, 410, 352, 18, PANEL, BORDER);
        drawChipIcon(c, 493, by + 52, BLUE);
        text(c, "Device Status", 560, by + 43, 23, WHITE, true, Paint.Align.LEFT);
        text(c, "สถานะอุปกรณ์", 560, by + 73, 16, SUB, false, Paint.Align.LEFT);
        divider(c, 460, by + 105, 826, by + 105);
        statusRow(c, by + 137, "Connected", bleConnected ? "Ready" : "Offline", bleConnected ? GREEN : Color.rgb(255, 187, 54));
        statusRow(c, by + 190, "Voltage", "-- V", Color.rgb(32, 238, 178));
        statusRow(c, by + 243, "Temperature", "-- °C", CYAN);
        statusRow(c, by + 296, "System", bleConnected ? "Normal" : "Waiting", bleConnected ? GREEN : SUB);
    }

    private void drawHomeSlider(Canvas c, int idx, float cy, int accent) {
        float min, max, value;
        if (idx == 0) { min = -70; max = 6; value = state.masterVolume; }
        else if (idx == 1) { min = -70; max = 6; value = state.bassVolume; }
        else if (idx == 2) { min = 20; max = 250; value = state.bassCutoff; }
        else { min = -12; max = 12; value = idx == 3 ? state.bassBoost : idx == 4 ? state.middleBoost : state.trebleBoost; }
        float x0 = 381, x1 = 665;
        float frac = idx == 2
                ? (float) ((Math.log(Math.max(min, value)) - Math.log(min)) / (Math.log(max) - Math.log(min)))
                : (value - min) / (max - min);
        frac = clamp(frac, 0, 1);
        float knob = x0 + frac * (x1 - x0);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(13);
        p.setColor(Color.rgb(34, 70, 106));
        c.drawLine(x0, cy, x1, cy, p);
        p.setShader(new LinearGradient(x0, cy, Math.max(x0 + 1, knob), cy, accent, CYAN, Shader.TileMode.CLAMP));
        p.setShadowLayer(8, 0, 0, accent);
        c.drawLine(x0, cy, knob, cy, p);
        p.clearShadowLayer(); p.setShader(null);
        p.setColor(WHITE); c.drawCircle(knob, cy, 18, p); p.setStrokeCap(Paint.Cap.BUTT);
        String valueText = idx == 2 ? String.format(Locale.US, "%.0f Hz", value) : DspState.db(value);
        roundPanel(c, 699, cy - 34, 126, 62, 12, PANEL2, Color.rgb(29, 77, 126));
        text(c, valueText, 762, cy + 8, 21, WHITE, false, Paint.Align.CENTER);
    }

    private void drawEq(Canvas c) {
        roundPanel(c, 16, 195, 832, 447, 18, PANEL, BORDER);
        drawWaveLogo(c, 66, 245, CYAN);
        text(c, "Parametric EQ", 136, 244, 33, WHITE, true, Paint.Align.LEFT);
        text(c, "ปรับแต่งความถี่เสียงอย่างละเอียด", 136, 278, 18, SUB, false, Paint.Align.LEFT);
        dropBox(c, 515, 218, 153, 72, DspState.CHANNEL_LONG[state.channel]);
        outlineButton(c, 681, 218, 145, 72, "↻  รีเซ็ต EQ", false);
        drawEqGraph(c, 73, 314, 755, 287);

        float gy = 658;
        String[] groups = {"Bands 1 - 6", "Bands 7 - 12", "Bands 13 - 15"};
        for (int i = 0; i < 3; i++) {
            float x = 18 + i * 221f;
            float w = i == 2 ? 211 : 216;
            outlineButton(c, x, gy, w, 56, groups[i], state.eqGroup == i);
        }

        float tableY = 724;
        roundPanel(c, 16, tableY, 832, 452, 18, PANEL, BORDER);
        text(c, "#", 43, tableY + 37, 15, SUB, true, Paint.Align.CENTER);
        text(c, "Type", 187, tableY + 37, 15, SUB, true, Paint.Align.CENTER);
        text(c, "Frequency", 362, tableY + 37, 15, SUB, true, Paint.Align.CENTER);
        text(c, "Gain", 522, tableY + 37, 15, SUB, true, Paint.Align.CENTER);
        text(c, "Q", 660, tableY + 37, 15, SUB, true, Paint.Align.CENTER);
        text(c, "Power", 790, tableY + 37, 15, SUB, true, Paint.Align.CENTER);
        int start = state.eqGroup * 6;
        int end = Math.min(DspState.BANDS, start + 6);
        for (int row = 0, b = start; b < end; b++, row++) drawEqRow(c, tableY + 55 + row * 64f, b);

        float py = 1190;
        roundPanel(c, 16, py, 832, 188, 18, PANEL, BORDER);
        drawFolderIcon(c, 63, py + 64, BLUE);
        text(c, "Preset", 130, py + 52, 22, WHITE, true, Paint.Align.LEFT);
        text(c, "ชุดค่าที่ใช้งานอยู่", 130, py + 80, 15, SUB, false, Paint.Align.LEFT);
        dropBox(c, 130, py + 100, 215, 50, "Custom 1");
        outlineButton(c, 360, py + 39, 132, 112, "▣\nSave", false);
        outlineButton(c, 508, py + 39, 132, 112, "□\nManage", false);
        text(c, "BETTER SOUND", 742, py + 116, 12, Color.rgb(126, 193, 248), false, Paint.Align.CENTER);
        text(c, "A BRIGHTER DRIVE", 742, py + 139, 10, Color.rgb(126, 193, 248), false, Paint.Align.CENTER);
    }

    private void drawEqGraph(Canvas c, float gx, float gy, float gw, float gh) {
        p.setColor(Color.rgb(0, 14, 27));
        c.drawRect(gx, gy, gx + gw, gy + gh, p);
        s.setStyle(Paint.Style.STROKE); s.setStrokeWidth(1); s.setColor(Color.rgb(17, 58, 92));
        for (int i = 0; i <= 12; i++) c.drawLine(gx + gw * i / 12f, gy, gx + gw * i / 12f, gy + gh, s);
        for (int i = 0; i <= 6; i++) c.drawLine(gx, gy + gh * i / 6f, gx + gw, gy + gh * i / 6f, s);
        text(c, "+12", gx - 16, gy + 10, 13, SUB, false, Paint.Align.RIGHT);
        text(c, "0", gx - 16, gy + gh / 2 + 5, 13, SUB, false, Paint.Align.RIGHT);
        text(c, "-12", gx - 16, gy + gh, 13, SUB, false, Paint.Align.RIGHT);
        String[] fx = {"20", "50", "100", "200", "500", "1k", "2k", "5k", "10k", "20k"};
        for (int i = 0; i < fx.length; i++) text(c, fx[i], gx + gw * i / (fx.length - 1f), gy + gh + 28, 12, SUB, false, Paint.Align.CENTER);

        int start = state.eqGroup * 6;
        int end = Math.min(DspState.BANDS, start + 6);
        Path path = new Path();
        boolean first = true;
        for (int b = start; b < end; b++) {
            float px = freqX(state.freq[state.channel][b], gx, gw);
            float py = gainY(state.gain[state.channel][b], gy, gh);
            if (first) { path.moveTo(px, py); first = false; } else path.lineTo(px, py);
        }
        s.setStyle(Paint.Style.STROKE); s.setStrokeWidth(4); s.setColor(CYAN); s.setShadowLayer(10, 0, 0, CYAN); c.drawPath(path, s); s.clearShadowLayer();
        for (int b = start; b < end; b++) {
            int color = chColors[b % chColors.length];
            float px = freqX(state.freq[state.channel][b], gx, gw);
            float py = gainY(state.gain[state.channel][b], gy, gh);
            p.setColor(color); p.setShadowLayer(12, 0, 0, color); c.drawCircle(px, py, b == state.selectedBand ? 10 : 8, p); p.clearShadowLayer();
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); p.setColor(WHITE); c.drawCircle(px, py, b == state.selectedBand ? 10 : 8, p); p.setStyle(Paint.Style.FILL);
        }
    }

    private void drawEqRow(Canvas c, float y, int b) {
        int color = chColors[b % chColors.length];
        divider(c, 33, y + 59, 830, y + 59);
        p.setColor(color); p.setShadowLayer(9, 0, 0, color); c.drawCircle(46, y + 29, 11, p); p.clearShadowLayer();
        text(c, Integer.toString(b + 1), 75, y + 35, 16, WHITE, false, Paint.Align.CENTER);
        smallCell(c, 104, y + 7, 166, 45, b == 1 || b == 5 ? (b == 1 ? "Low Shelf" : "High Shelf") : "PEQ");
        smallCell(c, 282, y + 7, 155, 45, DspState.hz(state.freq[state.channel][b]));
        smallCell(c, 447, y + 7, 142, 45, DspState.db(state.gain[state.channel][b]));
        smallCell(c, 600, y + 7, 123, 45, String.format(Locale.US, "%.2f", state.q[state.channel][b]));
        drawToggle(c, 754, y + 9, 72, 42, state.eqEnabled[state.channel][b], CYAN);
        if (b == state.selectedBand) glowRect(c, 31, y + 4, 797, 50, 10, CYAN);
    }

    private void drawCrossover(Canvas c) {
        roundPanel(c, 16, 195, 832, 470, 18, PANEL, BORDER);
        drawRoundIcon(c, 77, 251, MAGENTA, 2);
        text(c, "Crossover", 163, 252, 34, WHITE, true, Paint.Align.LEFT);
        text(c, "ตั้งค่าการแบ่งความถี่", 163, 286, 18, SUB, false, Paint.Align.LEFT);
        dropBox(c, 506, 228, 159, 64, "Magnitude");
        outlineButton(c, 682, 228, 145, 64, "↻  Reset", false);
        drawXoverGraph(c, 84, 370, 740, 250);

        float y = 681;
        drawFilterCard(c, y, true);
        drawFilterCard(c, y + 243, false);

        float ay = 1174;
        roundPanel(c, 16, ay, 832, 207, 18, PANEL, BORDER);
        drawGear(c, 69, ay + 45, BLUE);
        text(c, "Advanced Settings", 120, ay + 40, 20, WHITE, true, Paint.Align.LEFT);
        text(c, "ตั้งค่าขั้นสูง", 120, ay + 66, 15, SUB, false, Paint.Align.LEFT);
        advancedCell(c, 41, ay + 92, 188, 88, "Phase", state.phaseDeg[state.channel] + "°");
        advancedCell(c, 240, ay + 92, 188, 88, "Polarity", state.polarityInvert[state.channel] ? "Invert" : "Normal");
        advancedToggleCell(c, 439, ay + 92, 188, 88, "Link L/R", state.linkLR[state.channel]);
        advancedCell(c, 638, ay + 92, 188, 88, "Output Mode", DspState.OUTPUT_MODES[state.outputMode[state.channel]]);
    }

    private void drawXoverGraph(Canvas c, float gx, float gy, float gw, float gh) {
        p.setColor(Color.rgb(0, 14, 27)); c.drawRect(gx, gy, gx + gw, gy + gh, p);
        s.setStyle(Paint.Style.STROKE); s.setStrokeWidth(1); s.setColor(Color.rgb(16, 57, 90));
        for (int i = 0; i <= 12; i++) c.drawLine(gx + gw * i / 12f, gy, gx + gw * i / 12f, gy + gh, s);
        for (int i = 0; i <= 5; i++) c.drawLine(gx, gy + gh * i / 5f, gx + gw, gy + gh * i / 5f, s);
        float hpfX = freqX(state.hpfHz[state.channel], gx, gw);
        float lpfX = freqX(state.lpfHz[state.channel], gx, gw);
        Path hp = new Path(); hp.moveTo(gx, gy + gh); hp.cubicTo(hpfX - 90, gy + gh, hpfX - 50, gy + gh * .25f, hpfX, gy + gh * .35f); hp.lineTo(gx + gw, gy + gh * .35f);
        s.setStrokeWidth(4); s.setColor(CYAN); s.setShadowLayer(8, 0, 0, CYAN); c.drawPath(hp, s); s.clearShadowLayer();
        Path lp = new Path(); lp.moveTo(gx, gy + gh * .35f); lp.lineTo(lpfX, gy + gh * .35f); lp.cubicTo(lpfX + 65, gy + gh * .35f, lpfX + 120, gy + gh, gx + gw, gy + gh);
        s.setColor(MAGENTA); s.setShadowLayer(8, 0, 0, MAGENTA); c.drawPath(lp, s); s.clearShadowLayer();
        p.setColor(CYAN); c.drawCircle(hpfX, gy + gh * .35f, 10, p); p.setColor(MAGENTA); c.drawCircle(lpfX, gy + gh * .35f, 10, p);
        text(c, "High Pass (HPF)", 590, gy - 14, 14, CYAN, false, Paint.Align.LEFT);
        text(c, "Low Pass (LPF)", 720, gy - 14, 14, MAGENTA, false, Paint.Align.LEFT);
    }

    private void drawFilterCard(Canvas c, float y, boolean hpf) {
        int color = hpf ? CYAN : MAGENTA;
        String title = hpf ? "High Pass Filter (HPF)" : "Low Pass Filter (LPF)";
        String thai = hpf ? "กรองความถี่ต่ำออก" : "กรองความถี่สูงออก";
        boolean bypass = hpf ? state.hpfBypass[state.channel] : state.lpfBypass[state.channel];
        int type = hpf ? state.hpfType[state.channel] : state.lpfType[state.channel];
        float hz = hpf ? state.hpfHz[state.channel] : state.lpfHz[state.channel];
        int slope = hpf ? state.hpfSlope[state.channel] : state.lpfSlope[state.channel];
        roundPanel(c, 16, y, 832, 226, 18, PANEL, BORDER);
        drawRoundIcon(c, 77, y + 57, color, hpf ? 4 : 5);
        text(c, title, 164, y + 52, 25, WHITE, true, Paint.Align.LEFT);
        text(c, thai, 164, y + 82, 16, SUB, false, Paint.Align.LEFT);
        text(c, "Bypass", 670, y + 61, 18, WHITE, false, Paint.Align.RIGHT);
        drawToggle(c, 690, y + 35, 113, 52, bypass, color);
        labeledDrop(c, 40, y + 118, 252, 84, "Type", DspState.FILTER_TYPES[type]);
        labeledDrop(c, 306, y + 118, 252, 84, "Frequency", DspState.hz(hz));
        labeledDrop(c, 572, y + 118, 252, 84, "Slope", slope + " dB/Oct");
    }

    private void drawDelay(Canvas c) {
        roundPanel(c, 16, 195, 832, 525, 18, PANEL, BORDER);
        drawRoundIcon(c, 77, 253, Color.rgb(0, 246, 166), 6);
        text(c, "Delay", 164, 251, 31, WHITE, true, Paint.Align.LEFT);
        text(c, "ตั้งค่าหน่วงเวลาเพื่อการจัดตำแหน่งเสียง", 164, 284, 17, SUB, false, Paint.Align.LEFT);
        outlineButton(c, 493, 220, 79, 55, "ms", state.delayUnit == 0);
        outlineButton(c, 573, 220, 79, 55, "cm", state.delayUnit == 1);
        outlineButton(c, 668, 220, 160, 55, "↻  ซิงค์ทุกช่อง", false);

        drawCar(c, 68, 326, 414, 348);
        float[] nodeX = {142, 402, 145, 405, 275, 276, 275};
        float[] nodeY = {408, 408, 565, 565, 347, 640, 640};
        for (int ch = 0; ch < 7; ch++) {
            int color = chColors[ch];
            float x = nodeX[ch], y = nodeY[ch];
            p.setColor(color); p.setShadowLayer(12, 0, 0, color); c.drawCircle(x, y, 14, p); p.clearShadowLayer();
            text(c, state.delayUnit == 0 ? String.format(Locale.US, "%.2f ms", state.delayMs[ch]) : DspState.cm(state.delayMs[ch]), x, y - 23, 13, WHITE, true, Paint.Align.CENTER);
        }

        roundPanel(c, 493, 303, 335, 124, 14, PANEL2, BORDER);
        text(c, "Seat Preset", 561, 338, 20, WHITE, true, Paint.Align.LEFT);
        text(c, "ตำแหน่งการฟัง", 561, 365, 14, SUB, false, Paint.Align.LEFT);
        dropBox(c, 561, 378, 239, 39, DspState.SEAT_PRESETS[state.seatPreset]);
        roundPanel(c, 493, 441, 335, 113, 14, PANEL2, BORDER);
        text(c, "Distance Reference", 561, 476, 19, WHITE, true, Paint.Align.LEFT);
        text(c, "Speed of Sound (20°C)", 561, 510, 14, SUB, false, Paint.Align.LEFT);
        text(c, "343 m/s (34.3 cm/ms)", 561, 535, 14, SUB, false, Paint.Align.LEFT);
        roundPanel(c, 493, 569, 335, 119, 14, PANEL2, BORDER);
        text(c, "Total Delay Range", 561, 604, 19, WHITE, true, Paint.Align.LEFT);
        float max = 0f; for (float v : state.delayMs) max = Math.max(max, v);
        text(c, "0.00 ms", 545, 652, 19, WHITE, false, Paint.Align.CENTER);
        text(c, String.format(Locale.US, "%.2f ms", max), 770, 652, 19, WHITE, false, Paint.Align.CENTER);

        float y = 735;
        for (int ch = 0; ch < 7; ch++) drawDelayRow(c, y + ch * 91f, ch);
    }

    private void drawDelayRow(Canvas c, float y, int ch) {
        roundPanel(c, 16, y, 832, 78, 13, PANEL, BORDER);
        p.setColor(chColors[ch]); p.setShadowLayer(9, 0, 0, chColors[ch]); c.drawCircle(49, y + 29, 13, p); p.clearShadowLayer();
        text(c, DspState.CHANNEL_SHORT[ch], 85, y + 27, 18, WHITE, true, Paint.Align.LEFT);
        text(c, DspState.CHANNEL_NAME[ch], 85, y + 51, 14, SUB, false, Paint.Align.LEFT);
        float x0 = 203, x1 = 649, cy = y + 31;
        float frac = clamp(state.delayMs[ch] / 10f, 0, 1); drawSlider(c, x0, x1, cy, frac, chColors[ch]);
        roundPanel(c, 681, y + 9, 145, 59, 10, PANEL2, BORDER);
        text(c, state.delayUnit == 0 ? DspState.ms(state.delayMs[ch]) : DspState.cm(state.delayMs[ch]), 753, y + 34, 17, WHITE, true, Paint.Align.CENTER);
        text(c, state.delayUnit == 0 ? DspState.cm(state.delayMs[ch]) : DspState.ms(state.delayMs[ch]), 753, y + 56, 12, SUB, false, Paint.Align.CENTER);
    }

    private void drawOutput(Canvas c) {
        roundPanel(c, 16, 195, 832, 350, 18, PANEL, BORDER);
        drawRoundIcon(c, 77, 250, ORANGE, 0);
        text(c, "Output", 165, 252, 34, WHITE, true, Paint.Align.LEFT);
        text(c, "ปรับระดับเอาต์พุตแต่ละช่อง", 165, 288, 18, SUB, false, Paint.Align.LEFT);
        outlineButton(c, 506, 228, 158, 65, "◉  All Mute Off", false);
        outlineButton(c, 682, 228, 145, 65, "↻  Reset Levels", false);

        roundPanel(c, 38, 335, 520, 184, 13, PANEL2, BORDER);
        text(c, "Output Level Overview", 55, 367, 17, WHITE, true, Paint.Align.LEFT);
        for (int ch = 0; ch < 7; ch++) {
            float x = 91 + ch * 61f;
            float h = 25 + clamp((state.outputLevel[ch] + 60f) / 72f, 0, 1) * 78;
            for (int seg = 0; seg < 9; seg++) {
                float yy = 475 - seg * 9f;
                p.setColor(seg * 9 < h ? chColors[ch] : Color.rgb(14, 45, 68));
                c.drawRoundRect(new RectF(x - 8, yy, x + 8, yy + 5), 2, 2, p);
            }
            text(c, DspState.CHANNEL_SHORT[ch], x, 501, 12, WHITE, false, Paint.Align.CENTER);
        }

        roundPanel(c, 572, 335, 255, 184, 13, PANEL2, BORDER);
        text(c, "Master Output", 591, 376, 18, WHITE, true, Paint.Align.LEFT);
        roundPanel(c, 731, 350, 77, 52, 10, PANEL2, BORDER);
        text(c, DspState.db(state.masterOutput), 769, 383, 18, WHITE, false, Paint.Align.CENTER);
        drawSlider(c, 599, 808, 449, clamp((state.masterOutput + 60) / 72f, 0, 1), CYAN);

        float y = 563;
        for (int ch = 0; ch < 7; ch++) drawOutputRow(c, y + ch * 111f, ch);
    }

    private void drawOutputRow(Canvas c, float y, int ch) {
        roundPanel(c, 16, y, 832, 98, 14, PANEL, BORDER);
        p.setColor(chColors[ch]); p.setShadowLayer(10, 0, 0, chColors[ch]); c.drawCircle(58, y + 39, 24, p); p.clearShadowLayer();
        text(c, Integer.toString(ch + 1), 58, y + 47, 19, WHITE, true, Paint.Align.CENTER);
        text(c, DspState.CHANNEL_SHORT[ch], 105, y + 31, 19, WHITE, true, Paint.Align.LEFT);
        text(c, DspState.CHANNEL_NAME[ch], 105, y + 57, 14, SUB, false, Paint.Align.LEFT);
        drawSlider(c, 198, 424, y + 42, clamp((state.outputLevel[ch] + 60) / 72f, 0, 1), chColors[ch]);
        roundPanel(c, 438, y + 17, 92, 51, 9, PANEL2, BORDER);
        text(c, DspState.db(state.outputLevel[ch]), 484, y + 50, 16, WHITE, false, Paint.Align.CENTER);
        actionSquare(c, 548, y + 13, 64, 60, "🔇", "Mute", state.outputMute[ch]);
        actionSquare(c, 619, y + 13, 64, 60, "◉", "Solo", state.outputSolo[ch]);
        actionSquare(c, 690, y + 13, 64, 60, "Ø", "Phase", state.outputPhase[ch]);
        actionSquare(c, 761, y + 13, 64, 60, "↗", "Link", state.outputLink[ch]);
    }

    private void drawBottomNav(Canvas c) {
        roundPanel(c, 16, NAV_TOP, 832, NAV_H, 17, Color.rgb(1, 18, 33), BORDER);
        String[] labels = {"Home", "EQ", "Crossover", "Delay", "Output"};
        for (int i = 0; i < 5; i++) {
            float w = 832f / 5f;
            float x = 16 + i * w;
            boolean sel = page == i;
            if (sel) {
                p.setColor(Color.rgb(0, 103, 224)); p.setShadowLayer(18, 0, 0, BLUE);
                c.drawRoundRect(new RectF(x + 5, NAV_TOP + 5, x + w - 5, NAV_TOP + NAV_H - 5), 14, 14, p); p.clearShadowLayer();
            }
            int color = sel ? CYAN : Color.rgb(185, 211, 248);
            float cx = x + w / 2f;
            if (i == 0) drawHomeNavIcon(c, cx, NAV_TOP + 41, color);
            else if (i == 1) drawEqNavIcon(c, cx, NAV_TOP + 41, color);
            else if (i == 2) drawXoverIcon(c, cx, NAV_TOP + 41, color);
            else if (i == 3) drawClock(c, cx, NAV_TOP + 41, color);
            else drawBars(c, cx, NAV_TOP + 41, color);
            text(c, labels[i], cx, NAV_TOP + 91, 18, color, false, Paint.Align.CENTER);
        }
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (!Float.isFinite(scale) || scale <= 0f) return true;
        float x = (e.getX() - ox) / scale;
        float y = (e.getY() - oy) / scale;
        if (x < 0 || x > W || y < 0 || y > H) return true;

        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (y >= NAV_TOP) {
                    page = Math.max(0, Math.min(4, (int) ((x - 16) / (832f / 5f))));
                    dragKind = DRAG_NONE; invalidate(); return true;
                }
                if (x >= 505 && x <= 785 && y <= 100) {
                    if (ble != null) { if (ble.isDspReady()) ble.requestDspRefresh(); else ble.startScan(); }
                    return true;
                }
                if (x >= 790 && y <= 100) {
                    toast(bleConnected ? "DSP READY • V18" : bleStatus); return true;
                }
                if (page != PAGE_HOME && y >= 100 && y <= 186) {
                    int ch = (int) ((x - 19) / (118f));
                    if (ch >= 0 && ch < 7) { state.channel = ch; invalidate(); }
                    return true;
                }
                if (page == PAGE_HOME) return homeDown(x, y);
                if (page == PAGE_EQ) return eqDown(x, y);
                if (page == PAGE_XOVER) return xoverDown(x, y);
                if (page == PAGE_DELAY) return delayDown(x, y);
                return outputDown(x, y);

            case MotionEvent.ACTION_MOVE:
                if (dragKind == DRAG_HOME) { updateHomeSlider(dragIndex, x); invalidate(); return true; }
                if (dragKind == DRAG_EQ_GRAPH) { updateEqGraph(y); invalidate(); return true; }
                if (dragKind == DRAG_DELAY) { updateDelay(dragIndex, x); invalidate(); return true; }
                if (dragKind == DRAG_OUTPUT) { updateOutput(dragIndex, x); invalidate(); return true; }
                if (dragKind == DRAG_MASTER_OUTPUT) { updateMasterOutput(x); invalidate(); return true; }
                break;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (dragKind == DRAG_HOME && dragIndex == 5 && ble != null) ble.setScalarRealtime(DspProtocol.ID_TREBLE_BOOST, state.trebleBoost);
                dragKind = DRAG_NONE; dragIndex = -1; performClick(); return true;
            default: break;
        }
        return true;
    }

    @Override public boolean performClick() { super.performClick(); return true; }

    private boolean homeDown(float x, float y) {
        for (int i = 0; i < 6; i++) {
            float rowY = 124 + i * 145f;
            if (x >= 355 && x <= 685 && y >= rowY + 22 && y <= rowY + 100) {
                dragKind = DRAG_HOME; dragIndex = i; updateHomeSlider(i, x); invalidate(); return true;
            }
        }
        float by = 1001;
        if (x >= 130 && x <= 408 && y >= by + 85 && y <= by + 158) {
            state.audioSource = (state.audioSource + 1) % DspState.AUDIO_SOURCES.length;
            warnUnverified(PAGE_HOME, "Audio Source"); invalidate(); return true;
        }
        if (x >= 130 && x <= 408 && y >= by + 265 && y <= by + 346) {
            state.applyHomePreset((state.homePreset + 1) % DspState.HOME_PRESETS.length);
            sendHomeTonal(); invalidate(); return true;
        }
        return true;
    }

    private void updateHomeSlider(int idx, float x) {
        float frac = clamp((x - 381f) / (665f - 381f), 0, 1);
        if (idx == 0) state.masterVolume = round1(-70 + frac * 76);
        else if (idx == 1) state.bassVolume = round1(-70 + frac * 76);
        else if (idx == 2) state.bassCutoff = Math.round((float) Math.exp(Math.log(20) + frac * (Math.log(250) - Math.log(20))));
        else if (idx == 3) state.bassBoost = round1(-12 + frac * 24);
        else if (idx == 4) state.middleBoost = round1(-12 + frac * 24);
        else state.trebleBoost = round1(-12 + frac * 24);
        if (idx != 5) sendHomeScalar(idx);
    }

    private boolean eqDown(float x, float y) {
        if (x >= 675 && y >= 205 && y <= 300) {
            state.flattenEq(state.channel); for (int b = 0; b < 15; b++) sendEqBand(state.channel, b); invalidate(); return true;
        }
        if (y >= 650 && y <= 720) {
            int g = Math.max(0, Math.min(2, (int) ((x - 18) / 221f))); state.eqGroup = g; state.selectedBand = g * 6; invalidate(); return true;
        }
        if (x >= 73 && x <= 828 && y >= 310 && y <= 645) {
            int b = nearestVisibleBand(x, y); if (b >= 0) { state.selectedBand = b; dragKind = DRAG_EQ_GRAPH; dragIndex = b; updateEqGraph(y); invalidate(); } return true;
        }
        if (y >= 779 && y <= 1168) {
            int row = (int) ((y - 779) / 64f);
            int b = state.eqGroup * 6 + row;
            if (b >= 0 && b < 15) {
                state.selectedBand = b;
                if (x >= 104 && x <= 270) { toast("Filter type ใช้ชนิดจริงจาก DSP และไม่แปลง type"); }
                else if (x >= 282 && x <= 437) { state.freq[state.channel][b] = stepFreq(state.freq[state.channel][b], x > 359); warnUnverified(PAGE_EQ, "EQ Frequency"); }
                else if (x >= 447 && x <= 589) { state.gain[state.channel][b] = clamp(round1(state.gain[state.channel][b] + (x > 518 ? 0.5f : -0.5f)), -12, 12); sendEqBand(state.channel, b); }
                else if (x >= 600 && x <= 723) { state.q[state.channel][b] = clamp(round2(state.q[state.channel][b] + (x > 661 ? .05f : -.05f)), .2f, 10f); warnUnverified(PAGE_EQ, "EQ Q"); }
                else if (x >= 744 && x <= 835) state.eqEnabled[state.channel][b] = !state.eqEnabled[state.channel][b];
                invalidate();
            }
            return true;
        }
        if (y >= 1220 && y <= 1360) {
            if (x >= 340 && x <= 505) { state.saveAll(getContext()); toast("บันทึกพรีเซ็ตในเครื่องแล้ว"); }
            else if (x >= 505 && x <= 660) { boolean ok = state.loadAll(getContext()); toast(ok ? "โหลดพรีเซ็ตแล้ว" : "ยังไม่มีพรีเซ็ตที่บันทึก"); invalidate(); }
            return true;
        }
        return true;
    }

    private int nearestVisibleBand(float x, float y) {
        int start = state.eqGroup * 6, end = Math.min(15, start + 6); int best = -1; float dBest = Float.MAX_VALUE;
        for (int b = start; b < end; b++) {
            float px = freqX(state.freq[state.channel][b], 73, 755), py = gainY(state.gain[state.channel][b], 314, 287);
            float dx = x - px, dy = y - py, d = dx * dx + dy * dy; if (d < dBest) { dBest = d; best = b; }
        }
        return dBest <= 65 * 65 ? best : -1;
    }

    private void updateEqGraph(float y) {
        int b = dragIndex >= 0 ? dragIndex : state.selectedBand; if (b < 0 || b >= 15) return;
        float gain = 12f - clamp((y - 314) / 287f, 0, 1) * 24f; state.gain[state.channel][b] = round1(gain); sendEqBand(state.channel, b);
    }

    private boolean xoverDown(float x, float y) {
        int ch = state.channel;
        if (x >= 675 && y >= 210 && y <= 310) { state.resetCrossover(ch); warnUnverified(PAGE_XOVER, "Crossover"); invalidate(); return true; }
        if (y >= 715 && y <= 900) { // HPF
            if (x >= 690 && y <= 790) state.hpfBypass[ch] = !state.hpfBypass[ch];
            else if (x < 300) state.hpfType[ch] = (state.hpfType[ch] + 1) % DspState.FILTER_TYPES.length;
            else if (x < 570) state.hpfHz[ch] = stepXoverFreq(state.hpfHz[ch], x > 440);
            else state.hpfSlope[ch] = nextSlope(state.hpfSlope[ch]);
            warnUnverified(PAGE_XOVER, "HPF"); invalidate(); return true;
        }
        if (y >= 958 && y <= 1148) { // LPF
            if (x >= 690 && y <= 1030) state.lpfBypass[ch] = !state.lpfBypass[ch];
            else if (x < 300) state.lpfType[ch] = (state.lpfType[ch] + 1) % DspState.FILTER_TYPES.length;
            else if (x < 570) state.lpfHz[ch] = stepXoverFreq(state.lpfHz[ch], x > 440);
            else state.lpfSlope[ch] = nextSlope(state.lpfSlope[ch]);
            warnUnverified(PAGE_XOVER, "LPF"); invalidate(); return true;
        }
        if (y >= 1260 && y <= 1385) {
            if (x < 235) state.phaseDeg[ch] = (state.phaseDeg[ch] + 15) % 360;
            else if (x < 435) state.polarityInvert[ch] = !state.polarityInvert[ch];
            else if (x < 635) state.linkLR[ch] = !state.linkLR[ch];
            else state.outputMode[ch] = (state.outputMode[ch] + 1) % DspState.OUTPUT_MODES.length;
            warnUnverified(PAGE_XOVER, "Advanced Crossover"); invalidate(); return true;
        }
        return true;
    }

    private boolean delayDown(float x, float y) {
        if (x >= 485 && x <= 655 && y >= 205 && y <= 286) { state.delayUnit = x < 573 ? 0 : 1; invalidate(); return true; }
        if (x >= 655 && y >= 205 && y <= 286) {
            float v = state.delayMs[state.channel]; for (int ch = 0; ch < 7; ch++) state.delayMs[ch] = v; warnUnverified(PAGE_DELAY, "Delay Sync"); invalidate(); return true;
        }
        if (x >= 560 && x <= 810 && y >= 360 && y <= 430) { state.seatPreset = (state.seatPreset + 1) % DspState.SEAT_PRESETS.length; invalidate(); return true; }
        if (y >= 735 && y <= 1375) {
            int ch = (int) ((y - 735) / 91f); if (ch >= 0 && ch < 7 && x >= 185 && x <= 665) { state.channel = ch; dragKind = DRAG_DELAY; dragIndex = ch; updateDelay(ch, x); warnUnverified(PAGE_DELAY, "Delay"); invalidate(); }
            return true;
        }
        return true;
    }

    private void updateDelay(int ch, float x) {
        float frac = clamp((x - 203) / (649 - 203f), 0, 1); state.delayMs[ch] = round2(frac * 10f);
    }

    private boolean outputDown(float x, float y) {
        if (x >= 500 && x <= 675 && y >= 210 && y <= 310) { for (int ch = 0; ch < 7; ch++) state.outputMute[ch] = false; warnUnverified(PAGE_OUTPUT, "Output Mute"); invalidate(); return true; }
        if (x >= 675 && y >= 210 && y <= 310) { state.masterOutput = -1f; float[] d = {-3f,-2.5f,-4f,-1f,-2f,-3.5f,-4.5f}; System.arraycopy(d,0,state.outputLevel,0,7); warnUnverified(PAGE_OUTPUT, "Output Reset"); invalidate(); return true; }
        if (x >= 585 && x <= 820 && y >= 410 && y <= 485) { dragKind = DRAG_MASTER_OUTPUT; updateMasterOutput(x); warnUnverified(PAGE_OUTPUT, "Master Output"); invalidate(); return true; }
        if (y >= 563 && y <= 1355) {
            int ch = (int) ((y - 563) / 111f); if (ch < 0 || ch >= 7) return true; state.channel = ch;
            float rowY = 563 + ch * 111f;
            if (x >= 185 && x <= 435 && y >= rowY + 12 && y <= rowY + 80) { dragKind = DRAG_OUTPUT; dragIndex = ch; updateOutput(ch, x); }
            else if (x >= 540 && x < 615) state.outputMute[ch] = !state.outputMute[ch];
            else if (x >= 615 && x < 686) state.outputSolo[ch] = !state.outputSolo[ch];
            else if (x >= 686 && x < 757) state.outputPhase[ch] = !state.outputPhase[ch];
            else if (x >= 757 && x <= 835) state.outputLink[ch] = !state.outputLink[ch];
            warnUnverified(PAGE_OUTPUT, "Output"); invalidate(); return true;
        }
        return true;
    }

    private void updateOutput(int ch, float x) {
        float frac = clamp((x - 198) / (424 - 198f), 0, 1); state.outputLevel[ch] = round1(-60 + frac * 72);
        if (state.outputLink[ch]) { int peer = linkedPeer(ch); if (peer >= 0) state.outputLevel[peer] = state.outputLevel[ch]; }
    }

    private void updateMasterOutput(float x) { state.masterOutput = round1(-60 + clamp((x - 599) / (808 - 599f), 0, 1) * 72); }

    private int linkedPeer(int ch) {
        if (ch == 0) return 1; if (ch == 1) return 0; if (ch == 2) return 3; if (ch == 3) return 2; if (ch == 5) return 6; if (ch == 6) return 5; return -1;
    }

    private void sendHomeScalar(int idx) {
        if (ble == null) return;
        if (idx == 0) ble.setScalarRealtime(DspProtocol.ID_MASTER_VOLUME, state.masterVolume);
        else if (idx == 1) ble.setScalarRealtime(DspProtocol.ID_BASS_VOLUME, state.bassVolume);
        else if (idx == 2) ble.setScalarRealtime(DspProtocol.ID_BASS_CUTOFF, state.bassCutoff);
        else if (idx == 3) ble.setScalarRealtime(DspProtocol.ID_BASS_BOOST, state.bassBoost);
        else if (idx == 4) ble.setScalarRealtime(DspProtocol.ID_MIDDLE_BOOST, state.middleBoost);
        else if (idx == 5) ble.setScalarRealtime(DspProtocol.ID_TREBLE_BOOST, state.trebleBoost);
    }

    private void sendHomeTonal() { for (int i = 1; i < 6; i++) sendHomeScalar(i); }

    private void sendEqBand(int ch, int band) {
        if (ble == null || !state.eqEnabled[ch][band]) return;
        if (state.eqWritable[ch][band]) ble.setEqRealtime(ch, band, state.freq[ch][band], state.gain[ch][band], state.q[ch][band]);
    }

    private void warnUnverified(int pageId, String control) {
        if (ble == null || unverifiedWarned[pageId]) return;
        unverifiedWarned[pageId] = true;
        ble.reportUnverifiedControl(control);
    }

    private float stepFreq(float v, boolean up) { return clamp(Math.round(v * (up ? 1.05f : .95f)), 20, 20000); }
    private float stepXoverFreq(float v, boolean up) { return clamp(Math.round(v * (up ? 1.12f : .89f)), 20, 20000); }
    private int nextSlope(int v) { for (int i = 0; i < DspState.SLOPES.length; i++) if (DspState.SLOPES[i] == v) return DspState.SLOPES[(i + 1) % DspState.SLOPES.length]; return 24; }

    private void statusRow(Canvas c, float y, String label, String value, int color) {
        p.setColor(color); c.drawCircle(479, y - 5, 9, p); text(c, label, 516, y, 17, WHITE, false, Paint.Align.LEFT); text(c, value, 811, y, 16, color, true, Paint.Align.RIGHT); divider(c, 462, y + 24, 826, y + 24);
    }

    private void labeledDrop(Canvas c, float x, float y, float w, float h, String label, String value) {
        roundPanel(c, x, y, w, h, 12, PANEL2, BORDER); text(c, label, x + 15, y + 27, 15, SUB, false, Paint.Align.LEFT); text(c, value, x + 18, y + 63, 18, WHITE, false, Paint.Align.LEFT); text(c, "⌄", x + w - 22, y + 61, 25, SUB, false, Paint.Align.CENTER);
    }

    private void advancedCell(Canvas c, float x, float y, float w, float h, String label, String value) {
        roundPanel(c, x, y, w, h, 11, PANEL2, BORDER); text(c, label, x + 16, y + 28, 14, SUB, false, Paint.Align.LEFT); text(c, "‹", x + 22, y + 65, 25, SUB, false, Paint.Align.CENTER); text(c, value, x + w / 2, y + 66, 17, WHITE, false, Paint.Align.CENTER); text(c, "›", x + w - 22, y + 65, 25, SUB, false, Paint.Align.CENTER);
    }

    private void advancedToggleCell(Canvas c, float x, float y, float w, float h, String label, boolean on) {
        roundPanel(c, x, y, w, h, 11, PANEL2, BORDER); text(c, label, x + 16, y + 28, 14, SUB, false, Paint.Align.LEFT); drawToggle(c, x + 58, y + 43, 78, 39, on, CYAN);
    }

    private void smallCell(Canvas c, float x, float y, float w, float h, String value) {
        roundPanel(c, x, y, w, h, 8, PANEL2, BORDER); text(c, "‹", x + 14, y + 30, 18, SUB, false, Paint.Align.CENTER); text(c, value, x + w / 2, y + 29, 14, WHITE, false, Paint.Align.CENTER); text(c, "›", x + w - 14, y + 30, 18, SUB, false, Paint.Align.CENTER);
    }

    private void dropBox(Canvas c, float x, float y, float w, float h, String value) {
        roundPanel(c, x, y, w, h, 10, PANEL2, BORDER); text(c, value, x + 14, y + h / 2 + 7, Math.min(16f, value.length() > 18 ? 13f : 16f), WHITE, false, Paint.Align.LEFT); text(c, "⌄", x + w - 20, y + h / 2 + 8, 23, SUB, false, Paint.Align.CENTER);
    }

    private void actionSquare(Canvas c, float x, float y, float w, float h, String icon, String label, boolean on) {
        roundPanel(c, x, y, w, h, 9, on ? Color.rgb(0, 89, 151) : PANEL2, on ? CYAN : BORDER); text(c, icon, x + w / 2, y + 28, 17, on ? CYAN : WHITE, false, Paint.Align.CENTER); text(c, label, x + w / 2, y + 49, 11, WHITE, false, Paint.Align.CENTER);
    }

    private void drawToggle(Canvas c, float x, float y, float w, float h, boolean on, int accent) {
        roundPanel(c, x, y, w, h, h / 2, on ? Color.rgb(0, 124, 230) : Color.rgb(38, 63, 91), on ? accent : Color.rgb(59, 85, 115)); p.setColor(WHITE); c.drawCircle(on ? x + w - h / 2 : x + h / 2, y + h / 2, h * .37f, p);
    }

    private void drawSlider(Canvas c, float x0, float x1, float y, float frac, int accent) {
        frac = clamp(frac, 0, 1); float k = x0 + (x1 - x0) * frac; p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeWidth(11); p.setColor(Color.rgb(32, 67, 101)); c.drawLine(x0, y, x1, y, p); p.setShader(new LinearGradient(x0, y, Math.max(x0 + 1, k), y, accent, CYAN, Shader.TileMode.CLAMP)); c.drawLine(x0, y, k, y, p); p.setShader(null); p.setColor(WHITE); p.setShadowLayer(6,0,0,WHITE); c.drawCircle(k, y, 14, p); p.clearShadowLayer(); p.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawCar(Canvas c, float x, float y, float w, float h) {
        s.setStyle(Paint.Style.STROKE); s.setStrokeWidth(3); s.setColor(Color.rgb(0, 123, 231)); s.setShadowLayer(10,0,0,BLUE);
        RectF body = new RectF(x + 80, y, x + w - 80, y + h); c.drawRoundRect(body, 80, 80, s);
        c.drawRoundRect(new RectF(x + 132, y + 95, x + 205, y + 177), 18, 18, s); c.drawRoundRect(new RectF(x + 210, y + 95, x + 283, y + 177), 18, 18, s);
        c.drawRoundRect(new RectF(x + 132, y + 210, x + 205, y + 293), 18, 18, s); c.drawRoundRect(new RectF(x + 210, y + 210, x + 283, y + 293), 18, 18, s); s.clearShadowLayer();
    }

    private void drawRoundIcon(Canvas c, float cx, float cy, int color, int type) {
        p.setColor(Color.argb(25, Color.red(color), Color.green(color), Color.blue(color))); p.setShadowLayer(16,0,0,color); c.drawCircle(cx,cy,47,p); p.clearShadowLayer(); s.setStyle(Paint.Style.STROKE); s.setStrokeWidth(3); s.setColor(color); c.drawCircle(cx,cy,45,s);
        if (type == 0) drawSpeaker(c,cx,cy,color);
        else if (type == 2 || type == 5) { Path path=new Path(); path.moveTo(cx-28,cy-14);path.cubicTo(cx-5,cy-14,cx-8,cy+15,cx+27,cy+17); c.drawPath(path,s); }
        else if (type == 4) { Path path=new Path(); path.moveTo(cx-28,cy+18);path.cubicTo(cx-5,cy+18,cx-10,cy-18,cx+28,cy-18); c.drawPath(path,s); }
        else if (type == 6) { c.drawCircle(cx,cy,22,s); c.drawLine(cx,cy,cx,cy-14,s); c.drawLine(cx,cy,cx+12,cy+8,s); }
        else { for(int i=0;i<5;i++) c.drawLine(cx-22+i*11,cy+20,cx-22+i*11,cy+20-i*8,s); }
    }

    private void drawSpeaker(Canvas c, float cx, float cy, int color) { p.setColor(color); Path t=new Path(); t.moveTo(cx-20,cy-8);t.lineTo(cx-7,cy-8);t.lineTo(cx+6,cy-19);t.lineTo(cx+6,cy+19);t.lineTo(cx-7,cy+8);t.lineTo(cx-20,cy+8);t.close();c.drawPath(t,p);s.setColor(color);s.setStrokeWidth(3);s.setStyle(Paint.Style.STROKE);c.drawArc(new RectF(cx,cy-16,cx+28,cy+16),-52,104,false,s); }

    private void drawWaveLogo(Canvas c, float cx, float cy, int color) { p.setColor(color); p.setShadowLayer(10,0,0,color); float[] h={24,42,62,78,58,40,25}; for(int i=0;i<7;i++){float xx=cx-36+i*12;c.drawRoundRect(new RectF(xx-3,cy-h[i]/2,xx+3,cy+h[i]/2),4,4,p);} p.clearShadowLayer(); }
    private void drawGear(Canvas c,float cx,float cy,int color){s.setStyle(Paint.Style.STROKE);s.setStrokeWidth(3);s.setColor(color);c.drawCircle(cx,cy,18,s);c.drawCircle(cx,cy,6,s);for(int i=0;i<8;i++){double a=i*Math.PI/4;float x1=cx+(float)Math.cos(a)*20,y1=cy+(float)Math.sin(a)*20,x2=cx+(float)Math.cos(a)*27,y2=cy+(float)Math.sin(a)*27;c.drawLine(x1,y1,x2,y2,s);}}
    private void drawMusicIcon(Canvas c,float cx,float cy,int color){roundPanel(c,cx-32,cy-32,64,64,12,Color.rgb(0,66,128),BORDER);text(c,"♫",cx,cy+12,36,color,true,Paint.Align.CENTER);}
    private void drawListIcon(Canvas c,float cx,float cy,int color){roundPanel(c,cx-32,cy-32,64,64,12,Color.rgb(0,66,128),BORDER);s.setColor(color);s.setStrokeWidth(4);for(int i=-1;i<=1;i++)c.drawLine(cx-17,cy+i*12,cx+17,cy+i*12,s);}
    private void drawChipIcon(Canvas c,float cx,float cy,int color){roundPanel(c,cx-30,cy-30,60,60,12,Color.rgb(0,66,128),BORDER);s.setColor(color);s.setStrokeWidth(3);c.drawRect(cx-14,cy-14,cx+14,cy+14,s);for(int i=-1;i<=1;i++){c.drawLine(cx-22,cy+i*9,cx-14,cy+i*9,s);c.drawLine(cx+14,cy+i*9,cx+22,cy+i*9,s);}}
    private void drawFolderIcon(Canvas c,float cx,float cy,int color){s.setColor(color);s.setStyle(Paint.Style.STROKE);s.setStrokeWidth(4);Path f=new Path();f.moveTo(cx-25,cy-17);f.lineTo(cx-8,cy-17);f.lineTo(cx,cy-8);f.lineTo(cx+26,cy-8);f.lineTo(cx+26,cy+20);f.lineTo(cx-25,cy+20);f.close();c.drawPath(f,s);}
    private void drawHomeNavIcon(Canvas c,float cx,float cy,int color){s.setColor(color);s.setStrokeWidth(4);s.setStyle(Paint.Style.STROKE);Path h=new Path();h.moveTo(cx-20,cy);h.lineTo(cx,cy-18);h.lineTo(cx+20,cy);h.lineTo(cx+16,cy);h.lineTo(cx+16,cy+19);h.lineTo(cx+3,cy+19);h.lineTo(cx+3,cy+6);h.lineTo(cx-3,cy+6);h.lineTo(cx-3,cy+19);h.lineTo(cx-16,cy+19);h.close();c.drawPath(h,s);}
    private void drawEqNavIcon(Canvas c,float cx,float cy,int color){s.setColor(color);s.setStrokeWidth(3);for(int i=-1;i<=1;i++){float xx=cx+i*15;c.drawLine(xx,cy-20,xx,cy+20,s);float yy=cy+(i==0?-7:i==-1?7:2);c.drawCircle(xx,yy,5,s);}}
    private void drawXoverIcon(Canvas c,float cx,float cy,int color){s.setColor(color);s.setStrokeWidth(3);Path a=new Path();a.moveTo(cx-24,cy+16);a.cubicTo(cx-5,cy+16,cx-10,cy-16,cx+24,cy-16);c.drawPath(a,s);Path b=new Path();b.moveTo(cx-24,cy-16);b.cubicTo(cx+5,cy-16,cx+10,cy+16,cx+24,cy+16);c.drawPath(b,s);}
    private void drawClock(Canvas c,float cx,float cy,int color){s.setColor(color);s.setStrokeWidth(3);c.drawCircle(cx,cy,22,s);c.drawLine(cx,cy,cx,cy-13,s);c.drawLine(cx,cy,cx+10,cy+7,s);}
    private void drawBars(Canvas c,float cx,float cy,int color){p.setColor(color);for(int i=0;i<4;i++){float h=10+i*9;c.drawRoundRect(new RectF(cx-23+i*13,cy+20-h,cx-17+i*13,cy+20),3,3,p);}}

    private void outlineButton(Canvas c,float x,float y,float w,float h,String label,boolean selected){roundPanel(c,x,y,w,h,11,selected?Color.rgb(0,119,232):PANEL2,selected?CYAN:BORDER);String[] a=label.split("\\n");if(a.length==1)text(c,a[0],x+w/2,y+h/2+7,16,WHITE,false,Paint.Align.CENTER);else{for(int i=0;i<a.length;i++)text(c,a[i],x+w/2,y+h/2-12+i*27,16,WHITE,i==0,Paint.Align.CENTER);}}
    private void roundPanel(Canvas c,float x,float y,float w,float h,float r,int fill,int border){p.setStyle(Paint.Style.FILL);p.setColor(fill);c.drawRoundRect(new RectF(x,y,x+w,y+h),r,r,p);s.setStyle(Paint.Style.STROKE);s.setStrokeWidth(1.4f);s.setColor(border);c.drawRoundRect(new RectF(x,y,x+w,y+h),r,r,s);}
    private void glowRect(Canvas c,float x,float y,float w,float h,float r,int color){s.setStyle(Paint.Style.STROKE);s.setStrokeWidth(2);s.setColor(color);s.setShadowLayer(12,0,0,color);c.drawRoundRect(new RectF(x,y,x+w,y+h),r,r,s);s.clearShadowLayer();}
    private void divider(Canvas c,float x1,float y1,float x2,float y2){s.setStyle(Paint.Style.STROKE);s.setStrokeWidth(1);s.setColor(Color.rgb(17,53,82));c.drawLine(x1,y1,x2,y2,s);}
    private void text(Canvas c,String value,float x,float y,float size,int color,boolean bold,Paint.Align align){p.setShader(null);p.setStyle(Paint.Style.FILL);p.setColor(color);p.setTextSize(size);p.setTextAlign(align);p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));c.drawText(value,x,y,p);}
    private float freqX(float f,float gx,float gw){double t=(Math.log(Math.max(20,f))-Math.log(20))/(Math.log(20000)-Math.log(20));return gx+(float)t*gw;}
    private float gainY(float g,float gy,float gh){return gy+(12-clamp(g,-12,12))/24f*gh;}
    private float clamp(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}
    private float round1(float v){return Math.round(v*10f)/10f;}
    private float round2(float v){return Math.round(v*100f)/100f;}
    private void toast(String m){Toast.makeText(getContext(),m,Toast.LENGTH_SHORT).show();}
}
