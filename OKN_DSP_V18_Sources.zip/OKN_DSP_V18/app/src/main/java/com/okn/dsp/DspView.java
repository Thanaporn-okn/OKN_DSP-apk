package com.okn.dsp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import java.util.Locale;

/**
 * OKN_DSP V18 UI rebuilt from the five supplied reference screens.
 * All controls update the UI on touch immediately. Verified Home/EQ controls are
 * forwarded to BleManager; unverified hardware groups remain protocol-gated.
 */
final class DspView extends View {
    private static final float W = 864f;
    private static final float H = 1536f;
    private static final float NAV_TOP = 1384f;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint s = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final DspState state = new DspState();
    private BleManager ble;

    private float scale = 1f, ox = 0f, oy = 0f;
    private int drag = -1;
    private String bleStatus = "กำลังค้นหา...";
    private String bleDevice = "OKN-DSP-7CH";
    private boolean bleConnected = false;
    private String diagnostic = "";
    private long lastUnverifiedToast = 0L;

    private final int BG = Color.rgb(1, 10, 20);
    private final int PANEL = Color.rgb(3, 27, 48);
    private final int PANEL2 = Color.rgb(2, 18, 34);
    private final int BORDER = Color.rgb(8, 75, 124);
    private final int BLUE = Color.rgb(0, 130, 255);
    private final int CYAN = Color.rgb(0, 220, 255);
    private final int WHITE = Color.rgb(241, 247, 255);
    private final int SUB = Color.rgb(150, 184, 221);
    private final int GREEN = Color.rgb(0, 236, 124);
    private final int ORANGE = Color.rgb(255, 154, 25);
    private final int MAGENTA = Color.rgb(239, 55, 230);
    private final int RED = Color.rgb(255, 50, 93);

    private final int[] CH_COLORS = {
            Color.rgb(20,185,255), Color.rgb(255,153,35), Color.rgb(0,230,111),
            Color.rgb(255,79,202), Color.rgb(238,238,238), Color.rgb(170,57,236), Color.rgb(10,214,242)
    };
    private final int[] BAND_COLORS = {
            Color.rgb(255,61,86), Color.rgb(255,150,37), Color.rgb(255,231,31),
            Color.rgb(0,235,97), Color.rgb(0,220,232), Color.rgb(179,52,238)
    };

    DspView(Context context) {
        super(context);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        setFocusable(true);
        setClickable(true);
        state.load(context);
    }

    void setBleManager(BleManager ble) { this.ble = ble; }

    void setBleStatus(String status, String deviceName, boolean connected) {
        bleStatus = status == null ? "" : status;
        if (deviceName != null && !deviceName.isEmpty()) bleDevice = deviceName;
        bleConnected = connected;
        invalidate();
    }

    void setDiagnostic(String message) {
        diagnostic = message == null ? "" : message;
        invalidate();
    }

    void setScalarFromDsp(int id, float value) {
        switch (id) {
            case DspProtocol.ID_MASTER_VOLUME: state.masterVolume = value; break;
            case DspProtocol.ID_BASS_VOLUME: state.bassVolume = value; break;
            case DspProtocol.ID_BASS_CUTOFF: state.bassCutoff = value; break;
            case DspProtocol.ID_BASS_BOOST: state.bassBoost = value; break;
            case DspProtocol.ID_MIDDLE_BOOST: state.middleBoost = value; break;
            case DspProtocol.ID_TREBLE_BOOST: state.trebleBoost = value; break;
            default: return;
        }
        invalidate();
    }

    void setEqFromDsp(int ch, int band, float frequency, float gainDb, float q, boolean writable) {
        if (ch < 0 || ch >= DspState.CHANNELS || band < 0 || band >= DspState.BANDS) return;
        state.eqFreq[ch][band] = frequency;
        state.eqGain[ch][band] = gainDb;
        state.eqQ[ch][band] = q;
        state.eqWritable[ch][band] = writable;
        invalidate();
    }

    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        scale = Math.min(w / W, h / H);
        ox = (w - W * scale) * 0.5f;
        oy = (h - H * scale) * 0.5f;
    }

    @Override protected void onDraw(Canvas raw) {
        super.onDraw(raw);
        raw.drawColor(BG);
        raw.save();
        raw.translate(ox, oy);
        raw.scale(scale, scale);
        drawBackdrop(raw);
        drawHeader(raw);
        if (state.page > 0) drawChannelTabs(raw);
        switch (state.page) {
            case 0: drawHome(raw); break;
            case 1: drawEq(raw); break;
            case 2: drawCrossover(raw); break;
            case 3: drawDelay(raw); break;
            default: drawOutput(raw); break;
        }
        drawBottomNav(raw);
        raw.restore();
    }

    private void drawBackdrop(Canvas c) {
        p.setShader(new LinearGradient(0,0,W,H, Color.rgb(1,9,18), Color.rgb(0,18,36), Shader.TileMode.CLAMP));
        c.drawRect(0,0,W,H,p); p.setShader(null);
        p.setColor(Color.argb(38,0,126,255)); p.setShadowLayer(90,0,0,BLUE); c.drawCircle(72,260,90,p); p.clearShadowLayer();
    }

    private void drawHeader(Canvas c) {
        // Waveform mark
        stroke(CYAN, 5f); s.setStrokeCap(Paint.Cap.ROUND);
        float[] hh={20,35,55,72,55,35,20};
        for(int i=0;i<hh.length;i++) c.drawLine(33+i*10,54-hh[i]/2,33+i*10,54+hh[i]/2,s);
        s.setStrokeCap(Paint.Cap.BUTT);
        text(c,state.page==0?"OKN_DSP":"DSP Control",118,50,39,WHITE,true,Paint.Align.LEFT);
        text(c,"Professional Audio Processor",119,79,20,Color.rgb(91,191,255),false,Paint.Align.LEFT);

        // BLE status panel
        panel(c,505,20,270,72,15,PANEL2,BORDER);
        roundedFill(c,516,31,50,50,12,Color.rgb(5,103,181));
        text(c,"B",541,64,26,WHITE,true,Paint.Align.CENTER);
        text(c,bleConnected?"เชื่อมต่ออุปกรณ์":"เชื่อมต่ออุปกรณ์",578,50,15,WHITE,true,Paint.Align.LEFT);
        text(c,bleDevice,578,72,12,SUB,false,Paint.Align.LEFT);
        p.setColor(bleConnected?GREEN:Color.rgb(55,105,115));
        if(bleConnected){p.setShadowLayer(14,0,0,GREEN);} c.drawCircle(748,56,6,p); p.clearShadowLayer();

        drawGear(c,815,55,WHITE);
    }

    private void drawChannelTabs(Canvas c) {
        float gap=7f, x=18f, y=104f, h=76f, w=(W-36f-gap*6f)/7f;
        for(int ch=0; ch<7; ch++) {
            boolean sel=ch==state.channel;
            panel(c,x+ch*(w+gap),y,w,h,9,sel?Color.rgb(0,117,223):PANEL2,sel?CYAN:BORDER);
            if(sel) glowRect(c,x+ch*(w+gap),y,w,h,9,CYAN);
            String[] z=DspState.CH_SHORT[ch].split("\\n");
            text(c,z[0],x+ch*(w+gap)+w/2,y+31,18,WHITE,true,Paint.Align.CENTER);
            text(c,z[1],x+ch*(w+gap)+w/2,y+58,15,WHITE,false,Paint.Align.CENTER);
        }
    }

    private void drawHome(Canvas c) {
        float[] yy={125,273,421,569,717,865};
        String[] title={"Master Volume","Bass Volume","Bass Cutoff","Bass Boost","Middle Boost","Treble Boost"};
        String[] sub={"ปรับระดับเสียงรวม","ปรับระดับเสียงเบส","ตั้งค่าความถี่ตัดเบส","เพิ่มความหนักแน่นของเบส","เพิ่มความชัดเจนย่านกลาง","เพิ่มความใสย่านแหลม"};
        int[] colors={BLUE,CYAN,MAGENTA,RED,BLUE,MAGENTA};
        for(int i=0;i<6;i++) {
            panel(c,16,yy[i],832,136,20,PANEL,BORDER);
            glowCircle(c,85,yy[i]+67,45,colors[i]);
            drawHomeGlyph(c,85,yy[i]+67,colors[i],i);
            text(c,title[i],165,yy[i]+54,28,WHITE,true,Paint.Align.LEFT);
            text(c,sub[i],165,yy[i]+89,18,Color.rgb(112,173,226),false,Paint.Align.LEFT);
            drawHomeSlider(c,i,yy[i]+58,colors[i]);
        }

        panel(c,16,1021,412,338,20,PANEL,BORDER);
        smallIconBox(c,39,1042,77,77,BLUE,"♪");
        text(c,"Audio Source",139,1069,23,WHITE,true,Paint.Align.LEFT);
        text(c,"แหล่งสัญญาณเสียง",139,1098,17,SUB,false,Paint.Align.LEFT);
        valueBox(c,139,1115,269,54,DspState.SOURCES[state.audioSource],false);
        divider(c,35,1182,409,1182);
        smallIconBox(c,39,1203,77,77,BLUE,"≡");
        text(c,"System Preset",139,1230,23,WHITE,true,Paint.Align.LEFT);
        text(c,"พรีเซ็ตระบบ",139,1259,17,SUB,false,Paint.Align.LEFT);
        valueBox(c,139,1276,269,54,DspState.PRESETS[state.systemPreset],false);

        panel(c,439,1021,409,338,20,PANEL,BORDER);
        smallIconBox(c,464,1042,77,77,BLUE,"▣");
        text(c,"Device Status",566,1069,23,WHITE,true,Paint.Align.LEFT);
        text(c,"สถานะอุปกรณ์",566,1098,17,SUB,false,Paint.Align.LEFT);
        divider(c,463,1128,826,1128);
        statusLine(c,480,1164,"Connected",bleConnected?"YES":"NO",bleConnected?GREEN:SUB);
        statusLine(c,480,1218,"Voltage","13.6 V",Color.rgb(74,225,205));
        statusLine(c,480,1272,"Temperature","42 °C",Color.rgb(74,225,205));
        statusLine(c,480,1326,"System",bleConnected?"Normal":bleStatus,bleConnected?GREEN:SUB);
    }

    private void drawHomeSlider(Canvas c,int idx,float cy,int color) {
        float x0=382, x1=666;
        float value,lo,hi;
        String display;
        if(idx==0){value=state.masterVolume;lo=-70;hi=6;display=DspState.db(value);}
        else if(idx==1){value=state.bassVolume;lo=-70;hi=6;display=DspState.db(value);}
        else if(idx==2){value=state.bassCutoff;lo=20;hi=250;display=DspState.hz(value);}
        else if(idx==3){value=state.bassBoost;lo=-10;hi=12;display=DspState.db(value);}
        else if(idx==4){value=state.middleBoost;lo=-12;hi=12;display=DspState.db(value);}
        else {value=state.trebleBoost;lo=-12;hi=12;display=DspState.db(value);}
        float frac=(value-lo)/(hi-lo); frac=DspState.clamp(frac,0,1); float k=x0+(x1-x0)*frac;
        stroke(Color.rgb(31,72,113),14); c.drawLine(x0,cy,x1,cy,s);
        p.setShader(new LinearGradient(x0,cy,k,cy,color,CYAN,Shader.TileMode.CLAMP)); p.setStrokeWidth(14); p.setStrokeCap(Paint.Cap.ROUND); c.drawLine(x0,cy,k,cy,p); p.setStrokeCap(Paint.Cap.BUTT); p.setShader(null);
        p.setColor(WHITE); p.setShadowLayer(16,0,0,color); c.drawCircle(k,cy,19,p); p.clearShadowLayer();
        String ticks=idx==2?"20        50       100       150       250":"-12       -6        0        +6       +12";
        if(idx==0 || idx==1) ticks="-70      -50      -30      -10       +6";
        text(c,ticks,x0,cy+43,13,SUB,false,Paint.Align.LEFT);
        valueBox(c,697,cy-31,127,62,display,true);
    }

    private void drawEq(Canvas c) {
        panel(c,16,197,832,430,18,PANEL,BORDER);
        glowCircle(c,77,250,39,CYAN); drawEqGlyph(c,77,250,CYAN);
        text(c,"Parametric EQ",134,249,30,WHITE,true,Paint.Align.LEFT);
        text(c,"ปรับแต่งความถี่เสียงอย่างละเอียด",134,283,18,SUB,false,Paint.Align.LEFT);
        valueBox(c,485,219,178,70,"ช่องสัญญาณ\nCH"+(state.channel+1)+" - "+DspState.CH_NAME[state.channel],false);
        button(c,677,219,153,70,"↻  รีเซ็ต EQ",false);
        drawEqGraph(c,43,313,785,284);

        float y=647; float[] xx={18,244,470}; String[] labs={"Bands 1 - 6","Bands 7 - 12","Bands 13 - 15"};
        for(int i=0;i<3;i++) button(c,xx[i],y,i==2?190:220,58,labs[i],state.eqPage==i);

        panel(c,16,716,832,467,18,PANEL,BORDER);
        text(c,"#",49,755,17,SUB,true,Paint.Align.CENTER);
        text(c,"Type",157,755,17,SUB,true,Paint.Align.LEFT);
        text(c,"Frequency",332,755,17,SUB,true,Paint.Align.LEFT);
        text(c,"Gain",486,755,17,SUB,true,Paint.Align.LEFT);
        text(c,"Q",643,755,17,SUB,true,Paint.Align.LEFT);
        text(c,"Power",780,755,17,SUB,true,Paint.Align.CENTER);
        int start=state.eqPage*6, count=Math.min(6,DspState.BANDS-start);
        for(int r=0;r<count;r++) drawEqRow(c,start+r,780+r*65);

        panel(c,16,1193,832,166,18,PANEL,BORDER);
        smallIconBox(c,42,1218,82,75,BLUE,"□");
        text(c,"Preset",142,1245,22,WHITE,true,Paint.Align.LEFT);
        text(c,"ชุดค่าที่ใช้งานอยู่",142,1275,16,SUB,false,Paint.Align.LEFT);
        valueBox(c,142,1290,187,51,DspState.PRESETS[state.eqPreset],false);
        button(c,341,1219,135,105,"▣\nSave",false);
        button(c,490,1219,153,105,"□\nManage",false);
        text(c,"BETTER SOUND",700,1290,11,Color.rgb(95,182,235),false,Paint.Align.CENTER);
        text(c,"A BRIGHTER DRIVE",700,1316,11,Color.rgb(95,182,235),false,Paint.Align.CENTER);
    }

    private void drawEqGraph(Canvas c,float x,float y,float w,float h) {
        panel(c,x,y,w,h,3,Color.rgb(2,17,31),Color.rgb(36,93,137));
        stroke(Color.argb(90,42,94,129),1);
        for(int i=1;i<12;i++) c.drawLine(x+w*i/12f,y,x+w*i/12f,y+h,s);
        for(int i=1;i<6;i++) c.drawLine(x,y+h*i/6f,x+w,y+h*i/6f,s);
        text(c,"dB",x-9,y+23,16,SUB,false,Paint.Align.RIGHT);
        text(c,"+12",x-10,y+54,14,SUB,false,Paint.Align.RIGHT); text(c,"+6",x-10,y+104,14,SUB,false,Paint.Align.RIGHT);
        text(c,"0",x-10,y+h/2+5,14,SUB,false,Paint.Align.RIGHT); text(c,"-6",x-10,y+h-53,14,SUB,false,Paint.Align.RIGHT); text(c,"-12",x-10,y+h-5,14,SUB,false,Paint.Align.RIGHT);
        String[] fx={"20","50","100","200","500","1k","2k","5k","10k","20k"};
        for(int i=0;i<fx.length;i++) text(c,fx[i],x+w*i/(fx.length-1),y+h+29,13,SUB,false,Paint.Align.CENTER);

        Path path=new Path(); int ch=state.channel;
        boolean started=false;
        for(int b=0;b<DspState.BANDS;b++) {
            float px=freqX(state.eqFreq[ch][b],x,w), py=gainY(state.eqPower[ch][b]?state.eqGain[ch][b]:0f,y,h);
            if(!started){path.moveTo(px,py);started=true;} else path.lineTo(px,py);
        }
        stroke(CYAN,4); s.setShadowLayer(10,0,0,CYAN); c.drawPath(path,s); s.clearShadowLayer();
        for(int b=0;b<DspState.BANDS;b++) {
            float px=freqX(state.eqFreq[ch][b],x,w), py=gainY(state.eqPower[ch][b]?state.eqGain[ch][b]:0f,y,h); int color=BAND_COLORS[b%6];
            p.setColor(color); p.setShadowLayer(13,0,0,color); c.drawCircle(px,py,8,p); p.clearShadowLayer(); stroke(WHITE,2); c.drawCircle(px,py,8,s);
        }
    }

    private void drawEqRow(Canvas c,int band,float y) {
        int ch=state.channel, color=BAND_COLORS[band%6];
        p.setColor(color); p.setShadowLayer(8,0,0,color); c.drawCircle(47,y+22,10,p); p.clearShadowLayer();
        text(c,String.valueOf(band+1),73,y+29,17,WHITE,false,Paint.Align.LEFT);
        miniValue(c,103,y,174,47,DspState.EQ_TYPES[state.eqType[ch][band]]+"  ⌄");
        miniValue(c,286,y,143,47,"‹  "+DspState.hz(state.eqFreq[ch][band])+"  ›");
        miniValue(c,438,y,143,47,"‹  "+DspState.db(state.eqGain[ch][band])+"  ›");
        miniValue(c,590,y,143,47,"‹  "+String.format(Locale.US,"%.2f",state.eqQ[ch][band])+"  ›");
        drawSwitch(c,768,y+23,state.eqPower[ch][band],BLUE);
    }

    private void drawCrossover(Canvas c) {
        panel(c,16,197,832,468,18,PANEL,BORDER);
        glowCircle(c,87,253,45,MAGENTA); drawFilterGlyph(c,87,253,MAGENTA,false);
        text(c,"Crossover",162,258,32,WHITE,true,Paint.Align.LEFT);
        text(c,"ตั้งค่าการแบ่งความถี่",162,291,18,SUB,false,Paint.Align.LEFT);
        valueBox(c,493,233,171,58,"Magnitude  ⌄",false); button(c,679,233,150,58,"↻  Reset",false);
        text(c,"●  High Pass (HPF)",548,354,15,CYAN,false,Paint.Align.LEFT); text(c,"●  Low Pass (LPF)",704,354,15,MAGENTA,false,Paint.Align.LEFT);
        drawCrossoverGraph(c,48,372,776,253);

        drawFilterCard(c,16,681,true);
        drawFilterCard(c,16,929,false);

        panel(c,16,1180,832,179,18,PANEL,BORDER);
        smallIconBox(c,40,1193,62,62,BLUE,"⚙"); text(c,"Advanced Settings",121,1220,20,WHITE,true,Paint.Align.LEFT); text(c,"ตั้งค่าขั้นสูง",121,1247,15,SUB,false,Paint.Align.LEFT);
        field(c,40,1260,198,78,"Phase",state.phaseDeg[state.channel]+"°");
        field(c,250,1260,190,78,"Polarity",state.polarityInvert[state.channel]?"Invert":"Normal");
        field(c,452,1260,146,78,"Link L/R",state.linkLR?"ON":"OFF");
        field(c,610,1260,218,78,"Output Mode",state.outputMode==0?"Stereo":"Mono");
    }

    private void drawCrossoverGraph(Canvas c,float x,float y,float w,float h) {
        panel(c,x,y,w,h,2,Color.rgb(2,17,31),Color.rgb(36,93,137));
        stroke(Color.argb(85,42,94,129),1);
        for(int i=1;i<14;i++) c.drawLine(x+w*i/14f,y,x+w*i/14f,y+h,s);
        for(int i=1;i<5;i++) c.drawLine(x,y+h*i/5f,x+w,y+h*i/5f,s);
        int ch=state.channel;
        float hx=freqX(state.hpfFreq[ch],x,w), lx=freqX(state.lpfFreq[ch],x,w), mid=y+h*0.38f;
        Path hp=new Path(); hp.moveTo(x,y+h); hp.cubicTo(hx-w*.18f,y+h,hx-w*.06f,mid,hx,mid); hp.lineTo(x+w,mid);
        stroke(CYAN,4); s.setShadowLayer(10,0,0,CYAN); c.drawPath(hp,s); s.clearShadowLayer();
        Path lp=new Path(); lp.moveTo(x,mid); lp.lineTo(lx,mid); lp.cubicTo(lx+w*.06f,mid,lx+w*.18f,y+h,x+w,y+h);
        stroke(MAGENTA,4); s.setShadowLayer(10,0,0,MAGENTA); c.drawPath(lp,s); s.clearShadowLayer();
        p.setColor(CYAN); c.drawCircle(hx,mid,10,p); p.setColor(MAGENTA); c.drawCircle(lx,mid,10,p);
        String[] fx={"20","50","100","200","500","1k","2k","5k","10k","20k"};
        for(int i=0;i<fx.length;i++) text(c,fx[i],x+w*i/(fx.length-1),y+h+27,13,SUB,false,Paint.Align.CENTER);
    }

    private void drawFilterCard(Canvas c,float x,float y,boolean hpf) {
        int color=hpf?CYAN:MAGENTA; int ch=state.channel;
        panel(c,x,y,832,232,18,PANEL,BORDER); glowCircle(c,91,y+57,42,color); drawFilterGlyph(c,91,y+57,color,hpf);
        text(c,hpf?"High Pass Filter (HPF)":"Low Pass Filter (LPF)",166,y+51,26,WHITE,true,Paint.Align.LEFT);
        text(c,hpf?"กรองความถี่ต่ำออก":"กรองความถี่สูงออก",166,y+84,17,SUB,false,Paint.Align.LEFT);
        text(c,"Bypass",672,y+59,18,WHITE,false,Paint.Align.LEFT); drawSwitch(c,788,y+57,hpf?state.hpfBypass[ch]:state.lpfBypass[ch],color);
        field(c,40,y+111,246,96,"Type",DspState.FILTER_TYPES[hpf?state.hpfType[ch]:state.lpfType[ch]]);
        field(c,300,y+111,260,96,"Frequency",DspState.hz(hpf?state.hpfFreq[ch]:state.lpfFreq[ch]));
        field(c,575,y+111,253,96,"Slope",DspState.FILTER_SLOPES[hpf?state.hpfSlope[ch]:state.lpfSlope[ch]]);
    }

    private void drawDelay(Canvas c) {
        panel(c,16,197,832,520,18,PANEL,BORDER);
        glowCircle(c,85,251,42,Color.rgb(0,238,156)); drawClock(c,85,251,Color.rgb(0,238,156));
        text(c,"Delay",154,251,31,WHITE,true,Paint.Align.LEFT); text(c,"ตั้งค่าหน่วงเวลาเพื่อการจัดตำแหน่งเสียง",154,284,17,SUB,false,Paint.Align.LEFT);
        button(c,486,223,78,58,"ms",state.delayUnitMs); button(c,565,223,83,58,"cm",!state.delayUnitMs); button(c,662,223,169,58,"↻  ซิงค์ทุกช่อง",false);
        drawCarMap(c,45,312,432,377);
        panel(c,494,302,326,125,14,PANEL2,BORDER); text(c,"Seat Preset",584,337,19,WHITE,true,Paint.Align.LEFT); text(c,"ตำแหน่งการฟัง",584,364,14,SUB,false,Paint.Align.LEFT); valueBox(c,584,374,215,43,DspState.SEATS[state.seatPreset],false);
        panel(c,494,438,326,136,14,PANEL2,BORDER); text(c,"Distance Reference",583,476,19,WHITE,true,Paint.Align.LEFT); text(c,"อ้างอิงระยะทางเสียง",583,501,14,SUB,false,Paint.Align.LEFT); text(c,"Speed of Sound (20°C)",582,535,14,SUB,false,Paint.Align.LEFT); text(c,String.format(Locale.US,"%.0f m/s (%.1f cm/ms)",state.speedOfSound,state.speedOfSound/10f),582,560,14,SUB,false,Paint.Align.LEFT);
        panel(c,494,586,326,107,14,PANEL2,BORDER); text(c,"Total Delay Range",582,620,18,WHITE,true,Paint.Align.LEFT); float max=0; for(float v:state.delayMs)max=Math.max(max,v); text(c,"0.00 ms",548,664,20,WHITE,false,Paint.Align.CENTER); text(c,String.format(Locale.US,"%.2f ms",max),756,664,20,WHITE,false,Paint.Align.CENTER);

        for(int ch=0;ch<7;ch++) drawDelayRow(c,ch,729+ch*90);
    }

    private void drawCarMap(Canvas c,float x,float y,float w,float h) {
        // Stylized car cabin / speaker positions following reference layout.
        stroke(Color.rgb(17,121,213),3); s.setShadowLayer(10,0,0,BLUE);
        RectF body=new RectF(x+80,y+15,x+w-70,y+h-18); c.drawRoundRect(body,95,95,s); s.clearShadowLayer();
        for(int r=0;r<2;r++) for(int col=0;col<2;col++) {
            float sx=x+160+col*115, sy=y+115+r*135; panel(c,sx-34,sy-48,68,96,18,Color.rgb(3,45,79),Color.rgb(9,91,150));
        }
        float[][] pos={{x+91,y+112},{x+w-75,y+112},{x+84,y+279},{x+w-68,y+279},{x+w/2,y+51},{x+w/2,y+h-37},{x+w-69,y+281}};
        for(int ch=0;ch<7;ch++) {
            float px,py;
            if(ch==0){px=x+92;py=y+109;} else if(ch==1){px=x+w-76;py=y+109;} else if(ch==2){px=x+84;py=y+278;} else if(ch==3){px=x+w-68;py=y+278;} else if(ch==4){px=x+w/2;py=y+48;} else if(ch==5){px=x+w/2;py=y+h-37;} else {px=x+w-20;py=y+h-80;}
            int color=CH_COLORS[ch]; p.setColor(color); p.setShadowLayer(14,0,0,color); c.drawCircle(px,py,17,p); p.clearShadowLayer(); stroke(WHITE,2); c.drawCircle(px,py,10,s);
            if(ch<6) text(c,String.format(Locale.US,"%.2f ms",state.delayMs[ch]),px,py+(ch==4?-29:ch==5?47:3),14,WHITE,false,Paint.Align.CENTER);
        }
    }

    private void drawDelayRow(Canvas c,int ch,float y) {
        panel(c,17,y,831,78,16,PANEL,BORDER); int color=CH_COLORS[ch]; p.setColor(color); p.setShadowLayer(10,0,0,color); c.drawCircle(49,y+39,13,p); p.clearShadowLayer();
        text(c,"CH"+(ch+1),84,y+29,19,WHITE,true,Paint.Align.LEFT); text(c,DspState.CH_NAME[ch],84,y+55,14,SUB,false,Paint.Align.LEFT);
        float x0=201,x1=648, frac=DspState.clamp(state.delayMs[ch]/10f,0,1), k=x0+(x1-x0)*frac;
        stroke(Color.rgb(34,72,105),10); c.drawLine(x0,y+37,x1,y+37,s); stroke(color,10); s.setShadowLayer(8,0,0,color); c.drawLine(x0,y+37,k,y+37,s); s.clearShadowLayer(); p.setColor(WHITE); p.setShadowLayer(8,0,0,color); c.drawCircle(k,y+37,13,p); p.clearShadowLayer();
        for(int i=0;i<=5;i++) text(c,String.valueOf(i*2),x0+(x1-x0)*i/5f,y+66,11,SUB,false,Paint.Align.CENTER);
        String top=state.delayUnitMs?String.format(Locale.US,"%.2f ms",state.delayMs[ch]):String.format(Locale.US,"%.1f cm",state.delayCm(ch));
        String bot=state.delayUnitMs?String.format(Locale.US,"%.1f cm",state.delayCm(ch)):String.format(Locale.US,"%.2f ms",state.delayMs[ch]);
        valueBox(c,684,y+10,143,58,top+"\n"+bot,true);
    }

    private void drawOutput(Canvas c) {
        panel(c,16,197,832,355,18,PANEL,BORDER);
        glowCircle(c,85,254,42,ORANGE); drawSpeaker(c,85,254,ORANGE);
        text(c,"Output",173,263,34,WHITE,true,Paint.Align.LEFT); text(c,"ปรับระดับเอาต์พุตแต่ละช่อง",173,297,18,SUB,false,Paint.Align.LEFT);
        button(c,485,234,168,62,"🔇  All Mute Off",false); button(c,667,234,164,62,"↻  Reset Levels",false);
        panel(c,38,337,525,193,12,PANEL2,BORDER); text(c,"Output Level Overview",52,369,18,WHITE,false,Paint.Align.LEFT); drawMeters(c,57,389,486,116);
        panel(c,576,337,252,193,12,PANEL2,BORDER); text(c,"Master Output",591,386,18,WHITE,true,Paint.Align.LEFT); valueBox(c,718,355,96,50,DspState.db(state.masterOutput),true); drawHorizontalSlider(c,601,452,796,state.masterOutput,-60,12,CYAN);
        text(c,"-60       -40       -20        0      +12",601,496,11,SUB,false,Paint.Align.LEFT);
        for(int ch=0;ch<7;ch++) drawOutputRow(c,ch,569+ch*109);
    }

    private void drawMeters(Canvas c,float x,float y,float w,float h) {
        float barW=31,gap=37; for(int ch=0;ch<7;ch++) {
            float bx=x+ch*(barW+gap), frac=(state.outputDb[ch]+60f)/72f; frac=DspState.clamp(frac,0,1); int color=CH_COLORS[ch];
            for(int i=0;i<10;i++){float yy=y+h-i*9; p.setColor(i/10f<frac?color:Color.rgb(14,45,67)); c.drawRect(bx,yy,bx+barW,yy+5,p);} text(c,"CH"+(ch+1),bx+barW/2,y+h+24,13,WHITE,false,Paint.Align.CENTER); text(c,DspState.CH_NAME[ch],bx+barW/2,y+h+44,10,SUB,false,Paint.Align.CENTER);
        }
    }

    private void drawOutputRow(Canvas c,int ch,float y) {
        panel(c,17,y,831,96,16,PANEL,BORDER); int color=CH_COLORS[ch]; glowCircle(c,61,y+48,24,color); text(c,String.valueOf(ch+1),61,y+55,18,WHITE,true,Paint.Align.CENTER);
        text(c,"CH"+(ch+1),108,y+37,20,WHITE,true,Paint.Align.LEFT); text(c,DspState.CH_NAME[ch],108,y+65,14,SUB,false,Paint.Align.LEFT);
        drawHorizontalSlider(c,198,y+41,432,state.outputDb[ch],-60,12,color); valueBox(c,446,y+20,91,55,DspState.db(state.outputDb[ch]),true);
        tinyButton(c,553,y+16,61,64,"Mute",state.mute[ch]); tinyButton(c,622,y+16,61,64,"Solo",state.solo[ch]); tinyButton(c,691,y+16,61,64,"Phase",state.outPhase[ch]); if(ch<2) tinyButton(c,760,y+16,69,64,"Link",state.outLink[ch]);
    }

    private void drawBottomNav(Canvas c) {
        panel(c,16,NAV_TOP,832,126,17,PANEL2,BORDER);
        String[] labs={"Home","EQ","Crossover","Delay","Output"};
        for(int i=0;i<5;i++) {
            float x=20+i*164f,w=160; boolean sel=i==state.page;
            if(sel){roundedFill(c,x,NAV_TOP+5,w,116,14,Color.rgb(0,81,192)); glowRect(c,x,NAV_TOP+5,w,116,14,BLUE);}
            int color=sel?CYAN:Color.rgb(178,211,243);
            float cx=x+w/2;
            if(i==0) drawHomeNav(c,cx,NAV_TOP+47,color); else if(i==1) drawEqGlyph(c,cx,NAV_TOP+47,color); else if(i==2) drawFilterGlyph(c,cx,NAV_TOP+47,color,true); else if(i==3) drawClock(c,cx,NAV_TOP+47,color); else drawBars(c,cx,NAV_TOP+47,color);
            text(c,labs[i],cx,NAV_TOP+102,17,sel?WHITE:Color.rgb(170,205,238),false,Paint.Align.CENTER);
        }
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        float x=(event.getX()-ox)/scale, y=(event.getY()-oy)/scale;
        if(x<0||x>W||y<0||y>H) return true;
        switch(event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                drag=-1;
                if(handleGlobalDown(x,y)) { invalidate(); return true; }
                if(state.page==0) handleHomeDown(x,y);
                else if(state.page==1) handleEqDown(x,y);
                else if(state.page==2) handleCrossoverDown(x,y);
                else if(state.page==3) handleDelayDown(x,y);
                else handleOutputDown(x,y);
                invalidate(); return true;
            case MotionEvent.ACTION_MOVE:
                handleDrag(x,y); invalidate(); return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if(drag>=100&&drag<106 && drag==105 && ble!=null) ble.flushScalarRealtime(DspProtocol.ID_TREBLE_BOOST);
                drag=-1; state.save(getContext()); invalidate(); performClick(); return true;
        }
        return true;
    }

    @Override public boolean performClick(){super.performClick();return true;}

    private boolean handleGlobalDown(float x,float y) {
        if(y>=NAV_TOP) {
            int pg=(int)((x-18)/164f); if(pg>=0&&pg<5){state.page=pg; drag=-1; return true;}
        }
        if(x>=500&&x<=780&&y>=15&&y<=98) { if(ble!=null){if(ble.isDspReady())ble.requestDspRefresh();else ble.startScan();} return true; }
        if(x>=785&&y<=100){Toast.makeText(getContext(),"OKN_DSP V18 • "+(bleConnected?"DSP connected":"DSP disconnected"),Toast.LENGTH_SHORT).show();return true;}
        if(state.page>0&&y>=104&&y<=182) {
            int ch=(int)((x-18)/((W-36f-7f*6f)/7f+7f)); if(ch>=0&&ch<7){state.channel=ch;return true;}
        }
        return false;
    }

    private void handleHomeDown(float x,float y) {
        float[] yy={125,273,421,569,717,865};
        for(int i=0;i<6;i++) if(y>=yy[i]+20&&y<=yy[i]+110&&x>=350&&x<=690){drag=100+i; updateHome(i,x); return;}
        if(x>=130&&x<=415&&y>=1110&&y<=1175){state.audioSource=(state.audioSource+1)%DspState.SOURCES.length;unverified("Audio Source");return;}
        if(x>=130&&x<=415&&y>=1270&&y<=1340){state.systemPreset=(state.systemPreset+1)%DspState.PRESETS.length;applyHomePreset();return;}
    }

    private void updateHome(int idx,float x) {
        float f=DspState.clamp((x-382f)/(666f-382f),0,1); float v;
        if(idx==0){v=-70+76*f;state.masterVolume=DspState.round1(v);sendScalar(DspProtocol.ID_MASTER_VOLUME,state.masterVolume);}
        else if(idx==1){v=-70+76*f;state.bassVolume=DspState.round1(v);sendScalar(DspProtocol.ID_BASS_VOLUME,state.bassVolume);}
        else if(idx==2){v=20+230*f;state.bassCutoff=Math.round(v);sendScalar(DspProtocol.ID_BASS_CUTOFF,state.bassCutoff);}
        else if(idx==3){v=-10+22*f;state.bassBoost=DspState.round1(v);sendScalar(DspProtocol.ID_BASS_BOOST,state.bassBoost);}
        else if(idx==4){v=-12+24*f;state.middleBoost=DspState.round1(v);sendScalar(DspProtocol.ID_MIDDLE_BOOST,state.middleBoost);}
        else {v=-12+24*f;state.trebleBoost=DspState.round1(v);sendScalar(DspProtocol.ID_TREBLE_BOOST,state.trebleBoost);}
    }

    private void applyHomePreset(){
        switch(state.systemPreset){case 2:state.bassBoost=2;state.middleBoost=1;state.trebleBoost=3;break;case 3:state.bassBoost=4;state.middleBoost=2;state.trebleBoost=2;break;case 4:state.bassBoost=1;state.middleBoost=2;state.trebleBoost=3;break;default:state.bassBoost=0;state.middleBoost=0;state.trebleBoost=0;}
        sendScalar(DspProtocol.ID_BASS_BOOST,state.bassBoost);sendScalar(DspProtocol.ID_MIDDLE_BOOST,state.middleBoost);sendScalar(DspProtocol.ID_TREBLE_BOOST,state.trebleBoost);
    }

    private void handleEqDown(float x,float y) {
        if(y>=647&&y<=710){if(x<238)state.eqPage=0;else if(x<465)state.eqPage=1;else state.eqPage=2;return;}
        if(y>=219&&y<=289&&x>=670){state.flattenEq(state.channel);sendEqRange(state.channel);return;}
        if(y>=313&&y<=597&&x>=43&&x<=828){int b=nearestBandByX(x,43,785);drag=200+b;updateEqGraph(b,y,313,284);return;}
        if(y>=780&&y<=1175){int r=(int)((y-780)/65f),band=state.eqPage*6+r;if(band>=DspState.BANDS)return;float ry=780+r*65;
            if(x>=103&&x<=277){state.eqType[state.channel][band]=(state.eqType[state.channel][band]+1)%DspState.EQ_TYPES.length;unverified("EQ filter type");}
            else if(x>=286&&x<=429){adjustEqFreq(band,x<357?-1:1);}
            else if(x>=438&&x<=581){adjustEqGain(band,x<509?-1:1);}
            else if(x>=590&&x<=733){adjustEqQ(band,x<661?-1:1);}
            else if(x>=735){state.eqPower[state.channel][band]=!state.eqPower[state.channel][band];unverified("EQ band power");}
            return;
        }
        if(y>=1285&&x>=130&&x<=335){state.eqPreset=(state.eqPreset+1)%DspState.PRESETS.length;return;}
        if(y>=1215&&x>=340&&x<=480){state.save(getContext());Toast.makeText(getContext(),"บันทึก Preset แล้ว",Toast.LENGTH_SHORT).show();return;}
        if(y>=1215&&x>=485&&x<=650){Toast.makeText(getContext(),"Preset Manager พร้อมใช้งานในเครื่อง",Toast.LENGTH_SHORT).show();return;}
    }

    private int nearestBandByX(float x,float gx,float gw){int ch=state.channel,best=0;float bd=Float.MAX_VALUE;for(int b=0;b<15;b++){float d=Math.abs(freqX(state.eqFreq[ch][b],gx,gw)-x);if(d<bd){bd=d;best=b;}}return best;}
    private void updateEqGraph(int band,float y,float gy,float gh){float gain=12f-DspState.clamp((y-gy)/gh,0,1)*24f;state.eqGain[state.channel][band]=DspState.round1(gain);sendEq(band);}
    private void adjustEqFreq(int band,int dir){float v=state.eqFreq[state.channel][band]*(dir>0?1.12246f:0.8909f);state.eqFreq[state.channel][band]=DspState.round1(DspState.clamp(v,20,20000));sendEq(band);}
    private void adjustEqGain(int band,int dir){state.eqGain[state.channel][band]=DspState.round1(DspState.clamp(state.eqGain[state.channel][band]+dir*.5f,-12,12));sendEq(band);}
    private void adjustEqQ(int band,int dir){state.eqQ[state.channel][band]=DspState.round1(DspState.clamp(state.eqQ[state.channel][band]+dir*.1f,.1f,10));sendEq(band);}

    private void handleCrossoverDown(float x,float y) {
        int ch=state.channel;
        if(y>=233&&y<=295&&x>=675){state.resetCrossover(ch);unverified("Crossover Reset");return;}
        if(y>=725&&y<=780&&x>=730){state.hpfBypass[ch]=!state.hpfBypass[ch];unverified("HPF Bypass");return;}
        if(y>=974&&y<=1030&&x>=730){state.lpfBypass[ch]=!state.lpfBypass[ch];unverified("LPF Bypass");return;}
        if(y>=792&&y<=902){if(x<293){state.hpfType[ch]=(state.hpfType[ch]+1)%DspState.FILTER_TYPES.length;}else if(x<567){cycleFilterFreq(true,1);}else state.hpfSlope[ch]=(state.hpfSlope[ch]+1)%DspState.FILTER_SLOPES.length;unverified("HPF");return;}
        if(y>=1040&&y<=1152){if(x<293){state.lpfType[ch]=(state.lpfType[ch]+1)%DspState.FILTER_TYPES.length;}else if(x<567){cycleFilterFreq(false,1);}else state.lpfSlope[ch]=(state.lpfSlope[ch]+1)%DspState.FILTER_SLOPES.length;unverified("LPF");return;}
        if(y>=1260&&y<=1345){if(x<245){state.phaseDeg[ch]=(state.phaseDeg[ch]+15)%360;}else if(x<445){state.polarityInvert[ch]=!state.polarityInvert[ch];}else if(x<605){state.linkLR=!state.linkLR;}else state.outputMode=1-state.outputMode;unverified("Crossover Advanced");}
    }
    private void cycleFilterFreq(boolean hpf,int dir){int ch=state.channel;float v=hpf?state.hpfFreq[ch]:state.lpfFreq[ch];v*=dir>0?1.25f:.8f;v=DspState.clamp(v,20,20000);if(hpf)state.hpfFreq[ch]=Math.round(v);else state.lpfFreq[ch]=Math.round(v);}

    private void handleDelayDown(float x,float y) {
        if(y>=223&&y<=285){if(x>=480&&x<565){state.delayUnitMs=true;return;}if(x>=565&&x<650){state.delayUnitMs=false;return;}if(x>=655){float v=state.delayMs[state.channel];for(int c=0;c<7;c++)state.delayMs[c]=v;unverified("Delay Sync");return;}}
        if(y>=370&&y<=425&&x>=575){state.seatPreset=(state.seatPreset+1)%DspState.SEATS.length;return;}
        for(int ch=0;ch<7;ch++){float ry=729+ch*90;if(y>=ry&&y<=ry+78&&x>=185&&x<=665){drag=300+ch;updateDelay(ch,x);return;}}
    }
    private void updateDelay(int ch,float x){float f=DspState.clamp((x-201)/(648f-201f),0,1);state.delayMs[ch]=DspState.round1(f*10f);unverified("Delay CH"+(ch+1));}

    private void handleOutputDown(float x,float y) {
        if(y>=234&&y<=300&&x>=480&&x<660){for(int c=0;c<7;c++)state.mute[c]=false;unverified("All Mute Off");return;}
        if(y>=234&&y<=300&&x>=660){state.resetOutput();unverified("Output Reset");return;}
        if(y>=420&&y<=485&&x>=580&&x<=820){drag=500;updateMasterOutput(x);return;}
        for(int ch=0;ch<7;ch++){float ry=569+ch*109;if(y>=ry&&y<=ry+96){if(x>=185&&x<=445){drag=400+ch;updateOutput(ch,x);}else if(x>=548&&x<618)state.mute[ch]=!state.mute[ch];else if(x>=618&&x<688)state.solo[ch]=!state.solo[ch];else if(x>=688&&x<758)state.outPhase[ch]=!state.outPhase[ch];else if(x>=758&&ch<2)state.outLink[ch]=!state.outLink[ch];unverified("Output CH"+(ch+1));return;}}
    }
    private void updateMasterOutput(float x){float f=DspState.clamp((x-601)/(796f-601f),0,1);state.masterOutput=DspState.round1(-60+72*f);unverified("Master Output");}
    private void updateOutput(int ch,float x){float f=DspState.clamp((x-198)/(432f-198f),0,1);state.outputDb[ch]=DspState.round1(-60+72*f);unverified("Output Level CH"+(ch+1));}

    private void handleDrag(float x,float y) {
        if(drag>=100&&drag<106) updateHome(drag-100,x);
        else if(drag>=200&&drag<215) updateEqGraph(drag-200,y,313,284);
        else if(drag>=300&&drag<307) updateDelay(drag-300,x);
        else if(drag>=400&&drag<407) updateOutput(drag-400,x);
        else if(drag==500) updateMasterOutput(x);
    }

    private void sendScalar(int id,float value){if(ble!=null)ble.setScalarRealtime(id,value);}
    private void sendEq(int band){if(ble==null)return;int ch=state.channel;if(state.eqWritable[ch][band])ble.setEqRealtime(ch,band,state.eqFreq[ch][band],state.eqGain[ch][band],state.eqQ[ch][band]);else unverified("EQ Band "+(band+1));}
    private void sendEqRange(int ch){for(int b=0;b<15;b++)if(state.eqWritable[ch][b])ble.setEqRealtime(ch,b,state.eqFreq[ch][b],state.eqGain[ch][b],state.eqQ[ch][b]);}
    private void unverified(String name){
        if(ble!=null)ble.reportUnverifiedControl(name);
        long now=System.currentTimeMillis(); if(now-lastUnverifiedToast>3500){lastUnverifiedToast=now; diagnostic=name+" • UI Real-Time • hardware packet not verified in supplied source";}
    }

    // ---------- drawing helpers ----------
    private void panel(Canvas c,float x,float y,float w,float h,float r,int fill,int border){p.setStyle(Paint.Style.FILL);p.setColor(fill);c.drawRoundRect(new RectF(x,y,x+w,y+h),r,r,p);stroke(border,1.3f);c.drawRoundRect(new RectF(x,y,x+w,y+h),r,r,s);}
    private void roundedFill(Canvas c,float x,float y,float w,float h,float r,int color){p.setStyle(Paint.Style.FILL);p.setColor(color);c.drawRoundRect(new RectF(x,y,x+w,y+h),r,r,p);}
    private void glowRect(Canvas c,float x,float y,float w,float h,float r,int color){stroke(color,2);s.setShadowLayer(13,0,0,color);c.drawRoundRect(new RectF(x,y,x+w,y+h),r,r,s);s.clearShadowLayer();}
    private void glowCircle(Canvas c,float cx,float cy,float r,int color){p.setStyle(Paint.Style.FILL);p.setColor(Color.argb(28,255,255,255));p.setShadowLayer(18,0,0,color);c.drawCircle(cx,cy,r,p);p.clearShadowLayer();stroke(color,3);s.setShadowLayer(10,0,0,color);c.drawCircle(cx,cy,r,s);s.clearShadowLayer();}
    private void stroke(int color,float width){s.setStyle(Paint.Style.STROKE);s.setStrokeWidth(width);s.setColor(color);}
    private void text(Canvas c,String text,float x,float y,float size,int color,boolean bold,Paint.Align align){p.setShader(null);p.setStyle(Paint.Style.FILL);p.setColor(color);p.setTextSize(size);p.setTextAlign(align);p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));String[] lines=text.split("\\n");if(lines.length==1)c.drawText(lines[0],x,y,p);else{float start=y-(lines.length-1)*size*.54f;for(int i=0;i<lines.length;i++)c.drawText(lines[i],x,start+i*size*1.08f,p);}}
    private void divider(Canvas c,float x1,float y1,float x2,float y2){stroke(Color.rgb(20,52,80),1);c.drawLine(x1,y1,x2,y2,s);}
    private void button(Canvas c,float x,float y,float w,float h,String label,boolean selected){panel(c,x,y,w,h,11,selected?Color.rgb(0,102,218):PANEL2,selected?CYAN:BORDER);if(selected)glowRect(c,x,y,w,h,11,CYAN);text(c,label,x+w/2,y+h/2+7,18,WHITE,selected,Paint.Align.CENTER);}
    private void tinyButton(Canvas c,float x,float y,float w,float h,String label,boolean selected){panel(c,x,y,w,h,9,selected?Color.rgb(0,95,190):PANEL2,selected?CYAN:BORDER);if(selected)glowRect(c,x,y,w,h,9,CYAN);text(c,label,x+w/2,y+h/2+5,12,WHITE,false,Paint.Align.CENTER);}
    private void valueBox(Canvas c,float x,float y,float w,float h,String value,boolean center){panel(c,x,y,w,h,10,PANEL2,Color.rgb(25,82,135));text(c,value,center?x+w/2:x+14,y+h/2+7,Math.min(18,h*.31f),WHITE,false,center?Paint.Align.CENTER:Paint.Align.LEFT);}
    private void miniValue(Canvas c,float x,float y,float w,float h,String value){panel(c,x,y,w,h,8,PANEL2,Color.rgb(17,73,118));text(c,value,x+w/2,y+h/2+6,14,WHITE,false,Paint.Align.CENTER);}
    private void field(Canvas c,float x,float y,float w,float h,String label,String value){panel(c,x,y,w,h,10,PANEL2,Color.rgb(20,72,114));text(c,label,x+15,y+25,14,SUB,false,Paint.Align.LEFT);text(c,value,x+15,y+58,18,WHITE,false,Paint.Align.LEFT);text(c,"⌄",x+w-21,y+58,17,Color.rgb(180,215,246),false,Paint.Align.CENTER);}
    private void statusLine(Canvas c,float x,float y,String left,String right,int rightColor){p.setColor(rightColor);c.drawCircle(x,y-5,8,p);text(c,left,x+34,y,17,Color.rgb(198,219,239),false,Paint.Align.LEFT);text(c,right,812,y,16,rightColor,false,Paint.Align.RIGHT);divider(c,x,y+22,814,y+22);}
    private void smallIconBox(Canvas c,float x,float y,float w,float h,int color,String glyph){panel(c,x,y,w,h,13,Color.rgb(0,55,103),Color.rgb(0,119,214));p.setColor(Color.argb(35,0,200,255));p.setShadowLayer(15,0,0,color);c.drawRoundRect(new RectF(x+6,y+6,x+w-6,y+h-6),10,10,p);p.clearShadowLayer();text(c,glyph,x+w/2,y+h/2+11,35,Color.rgb(128,225,255),true,Paint.Align.CENTER);}
    private void drawSwitch(Canvas c,float cx,float cy,boolean on,int color){float w=71,h=38;roundedFill(c,cx-w/2,cy-h/2,w,h,20,on?Color.rgb(0,130,245):Color.rgb(32,55,83));if(on){p.setColor(color);p.setShadowLayer(10,0,0,color);c.drawRoundRect(new RectF(cx-w/2,cy-h/2,cx+w/2,cy+h/2),20,20,p);p.clearShadowLayer();}p.setColor(WHITE);c.drawCircle(cx+(on?17:-17),cy,15,p);}
    private void drawHorizontalSlider(Canvas c,float x0,float cy,float x1,float value,float lo,float hi,int color){float f=DspState.clamp((value-lo)/(hi-lo),0,1),k=x0+(x1-x0)*f;stroke(Color.rgb(35,73,109),10);c.drawLine(x0,cy,x1,cy,s);stroke(color,10);s.setShadowLayer(7,0,0,color);c.drawLine(x0,cy,k,cy,s);s.clearShadowLayer();p.setColor(WHITE);p.setShadowLayer(8,0,0,color);c.drawCircle(k,cy,13,p);p.clearShadowLayer();}
    private float freqX(float freq,float gx,float gw){double f=(Math.log(Math.max(20f,freq))-Math.log(20))/(Math.log(20000)-Math.log(20));return gx+(float)f*gw;}
    private float gainY(float gain,float gy,float gh){return gy+(12f-DspState.clamp(gain,-12,12))/24f*gh;}

    private void drawHomeGlyph(Canvas c,float cx,float cy,int color,int type){stroke(color,4);if(type==0){drawSpeaker(c,cx,cy,color);return;}if(type==1){c.drawCircle(cx,cy,21,s);c.drawCircle(cx,cy,8,s);}else if(type==2){Path q=new Path();q.moveTo(cx-25,cy-10);q.lineTo(cx+25,cy-10);q.moveTo(cx-9,cy-28);q.lineTo(cx-9,cy+27);c.drawPath(q,s);}else if(type==3){for(int i=0;i<5;i++)c.drawLine(cx-24+i*12,cy+22,cx-24+i*12,cy+22-(i+1)*9,s);}else if(type==4){Path q=new Path();q.moveTo(cx-27,cy+8);q.lineTo(cx-18,cy-4);q.lineTo(cx-9,cy+18);q.lineTo(cx,cy-18);q.lineTo(cx+9,cy+10);q.lineTo(cx+18,cy-6);q.lineTo(cx+28,cy+5);c.drawPath(q,s);}else{Path star=new Path();for(int i=0;i<8;i++){double a=-Math.PI/2+i*Math.PI/4;float r=i%2==0?26:9;float xx=cx+(float)Math.cos(a)*r,yy=cy+(float)Math.sin(a)*r;if(i==0)star.moveTo(xx,yy);else star.lineTo(xx,yy);}star.close();p.setColor(color);c.drawPath(star,p);}}
    private void drawSpeaker(Canvas c,float cx,float cy,int color){p.setColor(color);Path q=new Path();q.moveTo(cx-26,cy-9);q.lineTo(cx-11,cy-9);q.lineTo(cx+5,cy-23);q.lineTo(cx+5,cy+23);q.lineTo(cx-11,cy+9);q.lineTo(cx-26,cy+9);q.close();c.drawPath(q,p);stroke(color,3);c.drawArc(new RectF(cx-1,cy-17,cx+31,cy+17),-55,110,false,s);c.drawArc(new RectF(cx-4,cy-26,cx+46,cy+26),-52,104,false,s);}
    private void drawEqGlyph(Canvas c,float cx,float cy,int color){stroke(color,3);Path q=new Path();q.moveTo(cx-29,cy+8);q.lineTo(cx-20,cy-7);q.lineTo(cx-12,cy+18);q.lineTo(cx-2,cy-20);q.lineTo(cx+8,cy+14);q.lineTo(cx+16,cy-5);q.lineTo(cx+29,cy+5);c.drawPath(q,s);}
    private void drawFilterGlyph(Canvas c,float cx,float cy,int color,boolean hpf){stroke(color,3);Path q=new Path();if(hpf){q.moveTo(cx-28,cy+22);q.cubicTo(cx-12,cy+22,cx-10,cy-19,cx+11,cy-19);q.lineTo(cx+29,cy-19);}else{q.moveTo(cx-28,cy-19);q.lineTo(cx-6,cy-19);q.cubicTo(cx+14,cy-19,cx+14,cy+22,cx+29,cy+22);}c.drawPath(q,s);}
    private void drawClock(Canvas c,float cx,float cy,int color){stroke(color,3);c.drawCircle(cx,cy,25,s);c.drawLine(cx,cy,cx,cy-15,s);c.drawLine(cx,cy,cx+12,cy+7,s);}
    private void drawGear(Canvas c,float cx,float cy,int color){stroke(color,3);c.drawCircle(cx,cy,19,s);c.drawCircle(cx,cy,6,s);for(int i=0;i<8;i++){double a=i*Math.PI/4;float x1=cx+(float)Math.cos(a)*21,y1=cy+(float)Math.sin(a)*21,x2=cx+(float)Math.cos(a)*27,y2=cy+(float)Math.sin(a)*27;c.drawLine(x1,y1,x2,y2,s);}}
    private void drawHomeNav(Canvas c,float cx,float cy,int color){stroke(color,3);Path q=new Path();q.moveTo(cx-23,cy);q.lineTo(cx,cy-20);q.lineTo(cx+23,cy);q.lineTo(cx+18,cy);q.lineTo(cx+18,cy+21);q.lineTo(cx+4,cy+21);q.lineTo(cx+4,cy+7);q.lineTo(cx-4,cy+7);q.lineTo(cx-4,cy+21);q.lineTo(cx-18,cy+21);q.lineTo(cx-18,cy);q.close();c.drawPath(q,s);}
    private void drawBars(Canvas c,float cx,float cy,int color){stroke(color,4);for(int i=0;i<4;i++)c.drawLine(cx-24+i*16,cy+23,cx-24+i*16,cy+23-(i+1)*13,s);}
}
