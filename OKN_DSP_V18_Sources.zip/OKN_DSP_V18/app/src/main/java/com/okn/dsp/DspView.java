package com.okn.dsp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

import java.util.Locale;

/**
 * V18 five-page UI rebuilt from the five user supplied reference screens.
 *
 * The drawing space is 864 x 1536 and is mapped to the physical display on every
 * frame, so no Android XML density bucket can clip the interface. Touch input is
 * mapped back into the same reference coordinate system. Visual values change on
 * ACTION_MOVE immediately. Verified DSP writes continue to use the V17 transport;
 * controls without a verified actuator mapping remain UI-state only rather than
 * inventing hardware packets.
 */
final class DspView extends View {
    private static final float DW = 864f;
    private static final float DH = 1536f;

    private static final int PAGE_HOME = 0;
    private static final int PAGE_EQ = 1;
    private static final int PAGE_XOVER = 2;
    private static final int PAGE_DELAY = 3;
    private static final int PAGE_OUTPUT = 4;

    private static final int DRAG_NONE = 0;
    private static final int DRAG_HOME_BASE = 100;
    private static final int DRAG_EQ_GRAPH = 200;
    private static final int DRAG_DELAY_BASE = 300;
    private static final int DRAG_OUTPUT_MASTER = 400;
    private static final int DRAG_OUTPUT_BASE = 410;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final DspState state = new DspState();
    private BleManager ble;

    private int page = PAGE_HOME;
    private int drag = DRAG_NONE;
    private int dragBand = -1;
    private String bleStatus = "กำลังค้นหา...";
    private String bleDevice = "DSP-7900";
    private boolean bleConnected = false;
    private String diagnostic = "";
    private int eqPreset = 0;
    private boolean crossoverMagnitude = true;

    private final int BG = Color.rgb(0, 7, 17);
    private final int PANEL = Color.rgb(3, 25, 46);
    private final int PANEL2 = Color.rgb(2, 18, 34);
    private final int BORDER = Color.rgb(10, 70, 116);
    private final int BORDER_SOFT = Color.rgb(10, 53, 89);
    private final int CYAN = Color.rgb(0, 224, 255);
    private final int BLUE = Color.rgb(0, 126, 255);
    private final int GREEN = Color.rgb(0, 237, 126);
    private final int WHITE = Color.rgb(242, 247, 255);
    private final int SUB = Color.rgb(160, 191, 230);
    private final int GRID = Color.rgb(12, 49, 78);

    private final int[] channelColors = {
            Color.rgb(28, 172, 255), Color.rgb(0, 220, 245), Color.rgb(0, 235, 103),
            Color.rgb(255, 207, 55), Color.rgb(255, 145, 37), Color.rgb(255, 55, 89),
            Color.rgb(212, 53, 246)
    };
    private final int[] eqColors = {
            Color.rgb(255, 56, 80), Color.rgb(255, 159, 40), Color.rgb(255, 235, 22),
            Color.rgb(0, 236, 92), Color.rgb(24, 224, 239), Color.rgb(186, 47, 241)
    };

    DspView(Context context, BleManager ble) {
        super(context);
        this.ble = ble;
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        setFocusable(true);
        setClickable(true);
        state.loadHome(context);
        state.loadEq(context);
    }

    void setBleManager(BleManager ble) { this.ble = ble; }

    void setBleStatus(String status, String deviceName, boolean connected) {
        bleStatus = status == null ? "" : status;
        if (deviceName != null && !deviceName.isEmpty()) bleDevice = deviceName;
        bleConnected = connected;
        invalidate();
    }

    void setDiagnostic(String message) {
        diagnostic = message == null ? "" : message;
        invalidate();
    }

    void setScalarFromDsp(int actuatorId, float value) {
        switch (actuatorId) {
            case DspProtocol.ID_MASTER_VOLUME: state.masterVolume = value; break;
            case DspProtocol.ID_BASS_VOLUME: state.bassVolume = value; break;
            case DspProtocol.ID_BASS_CUTOFF: state.bassCutoff = value; break;
            case DspProtocol.ID_BASS_BOOST: state.bassBoost = value; break;
            case DspProtocol.ID_MIDDLE_BOOST: state.middleBoost = value; break;
            case DspProtocol.ID_TREBLE_BOOST: state.trebleBoost = value; break;
            default: return;
        }
        invalidate();
    }

    void setEqFromDsp(int channel0, int uiBand0, float frequency, float gainDb, float q, boolean writable) {
        if (channel0 < 0 || channel0 >= DspState.CHANNELS || uiBand0 < 0 || uiBand0 >= DspState.BANDS) return;
        state.freq[channel0][uiBand0] = frequency;
        state.gain[channel0][uiBand0] = gainDb;
        state.q[channel0][uiBand0] = q;
        state.eqWritable[channel0][uiBand0] = writable;
        invalidate();
    }

    private void sendHomeScalar(int idx) {
        if (ble == null) return;
        if (idx == 0) ble.setScalarRealtime(DspProtocol.ID_MASTER_VOLUME, state.masterVolume);
        else if (idx == 1) ble.setScalarRealtime(DspProtocol.ID_BASS_VOLUME, state.bassVolume);
        else if (idx == 2) ble.setScalarRealtime(DspProtocol.ID_BASS_CUTOFF, state.bassCutoff);
        else if (idx == 3) ble.setScalarRealtime(DspProtocol.ID_BASS_BOOST, state.bassBoost);
        else if (idx == 4) ble.setScalarRealtime(DspProtocol.ID_MIDDLE_BOOST, state.middleBoost);
        else if (idx == 5) ble.setScalarRealtime(DspProtocol.ID_TREBLE_BOOST, state.trebleBoost);
    }

    private void sendEqGain(int channel0, int band0) {
        if (ble == null || channel0 < 0 || channel0 >= 7 || band0 < 0 || band0 >= 15) return;
        ble.setEqRealtime(channel0, band0, state.freq[channel0][band0], state.gain[channel0][band0], state.q[channel0][band0]);
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        float sx = Math.max(0.0001f, getWidth() / DW);
        float sy = Math.max(0.0001f, getHeight() / DH);
        c.drawColor(BG);
        c.save();
        c.scale(sx, sy);
        drawBackdrop(c);
        drawHeader(c, page != PAGE_HOME);
        if (page == PAGE_HOME) drawHome(c);
        else {
            drawChannelTabs(c);
            if (page == PAGE_EQ) drawEq(c);
            else if (page == PAGE_XOVER) drawCrossover(c);
            else if (page == PAGE_DELAY) drawDelay(c);
            else drawOutput(c);
        }
        drawBottomNav(c);
        c.restore();
    }

    private void drawBackdrop(Canvas c) {
        p.setShader(new LinearGradient(0, 0, DW, DH, Color.rgb(0, 18, 37), Color.rgb(0, 4, 12), Shader.TileMode.CLAMP));
        c.drawRect(0, 0, DW, DH, p);
        p.setShader(null);
    }

    private void drawHeader(Canvas c, boolean dspControl) {
        drawLogo(c, 30, 20, 72);
        if (dspControl) {
            text(c, "DSP Control", 115, 52, 39, WHITE, false, Paint.Align.LEFT);
            text(c, "Professional Audio Processor", 116, 78, 19, Color.rgb(94, 193, 241), false, Paint.Align.LEFT);
        } else {
            text(c, "OKN_", 137, 60, 42, WHITE, true, Paint.Align.LEFT);
            text(c, "DSP", 252, 60, 42, CYAN, true, Paint.Align.LEFT);
            text(c, "Professional Audio Processor", 137, 88, 20, Color.rgb(117, 188, 235), false, Paint.Align.LEFT);
        }

        roundPanel(c, dspControl ? 520 : 505, 18, dspControl ? 247 : 255, 70, 14, PANEL2, BORDER);
        glowDot(c, dspControl ? 550 : 541, 52, bleConnected ? GREEN : Color.rgb(255, 193, 50), 10);
        text(c, bleConnected ? "Connected" : shortStatus(), dspControl ? 574 : 573, 49, 19, bleConnected ? GREEN : WHITE, false, Paint.Align.LEFT);
        text(c, deviceLabel(), dspControl ? 574 : 573, 72, 17, SUB, false, Paint.Align.LEFT);
        text(c, "›", dspControl ? 739 : 728, 60, 43, SUB, false, Paint.Align.CENTER);
        drawGear(c, 812, 54, 25);
    }

    private String shortStatus() {
        if (bleStatus == null || bleStatus.isEmpty()) return "Bluetooth";
        if (bleStatus.length() > 15) return "Bluetooth";
        return bleStatus;
    }

    private String deviceLabel() {
        if (bleDevice == null || bleDevice.isEmpty() || bleDevice.startsWith("OKN-DSP")) return "DSP-7900";
        return bleDevice;
    }

    private void drawLogo(Canvas c, float x, float y, float h) {
        float cy = y + h * 0.5f;
        float[] hs = {27, 47, 68, 88, 61, 42};
        p.setStrokeWidth(7);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setColor(CYAN);
        p.setShadowLayer(13, 0, 0, CYAN);
        for (int i = 0; i < hs.length; i++) {
            float xx = x + i * 13f;
            c.drawLine(xx, cy - hs[i] / 2f, xx, cy + hs[i] / 2f, p);
        }
        p.clearShadowLayer();
        p.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawGear(Canvas c, float cx, float cy, float r) {
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(4);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setColor(Color.rgb(190, 218, 255));
        c.drawCircle(cx, cy, r * .72f, stroke);
        c.drawCircle(cx, cy, r * .22f, stroke);
        for (int i = 0; i < 8; i++) {
            double a = Math.PI * i / 4.0;
            c.drawLine(cx + (float)Math.cos(a) * r * .82f, cy + (float)Math.sin(a) * r * .82f,
                    cx + (float)Math.cos(a) * r * 1.05f, cy + (float)Math.sin(a) * r * 1.05f, stroke);
        }
    }

    private void drawChannelTabs(Canvas c) {
        float gap = 7f;
        float x = 18f;
        float w = 111f;
        for (int ch = 0; ch < 7; ch++) {
            boolean selected = state.channel == ch;
            int fill = selected ? Color.rgb(0, 100, 225) : Color.rgb(2, 26, 48);
            int border = selected ? CYAN : BORDER;
            roundPanel(c, x, 104, w, 78, 10, fill, border);
            if (selected) glowRect(c, x, 104, w, 78, 10, CYAN);
            text(c, "CH" + (ch + 1), x + w / 2f, 139, 20, WHITE, false, Paint.Align.CENTER);
            text(c, DspState.CHANNEL_NAME[ch], x + w / 2f, 165, 16, WHITE, false, Paint.Align.CENTER);
            x += w + gap;
        }
    }

    private void drawHome(Canvas c) {
        String[] title = {"Master Volume", "Bass Volume", "Bass Cutoff", "Bass Boost", "Middle Boost", "Treble Boost"};
        String[] th = {"ปรับระดับเสียงรวม", "ปรับระดับเสียงเบส", "ตั้งค่าความถี่ตัดเบส", "เพิ่มความหนักแน่นของเบส", "เพิ่มความชัดเจนย่านกลาง", "เพิ่มความใสย่านแหลม"};
        int[] colors = {Color.rgb(0, 135, 255), Color.rgb(0, 227, 242), Color.rgb(229, 50, 236), Color.rgb(255, 42, 109), Color.rgb(0, 139, 255), Color.rgb(209, 55, 241)};
        float[] ys = {124, 273, 422, 571, 720, 869};
        for (int i = 0; i < 6; i++) {
            roundPanel(c, 16, ys[i], 832, 137, 18, PANEL, BORDER);
            drawRingIcon(c, 84, ys[i] + 68, 48, colors[i], i);
            text(c, title[i], 165, ys[i] + 57, 29, WHITE, true, Paint.Align.LEFT);
            text(c, th[i], 165, ys[i] + 91, 19, Color.rgb(121, 179, 224), false, Paint.Align.LEFT);
            drawHomeSlider(c, i, 380, ys[i] + 60, 669, colors[i]);
            roundPanel(c, 698, ys[i] + 28, 126, 64, 12, PANEL2, Color.rgb(25, 73, 119));
            text(c, homeValue(i), 761, ys[i] + 70, 25, WHITE, false, Paint.Align.CENTER);
        }

        // Source / preset left column.
        roundPanel(c, 16, 1021, 411, 158, 18, PANEL, BORDER);
        drawSmallSquareIcon(c, 40, 1041, 78, "♫");
        text(c, "Audio Source", 139, 1072, 24, WHITE, true, Paint.Align.LEFT);
        text(c, "แหล่งสัญญาณเสียง", 139, 1100, 17, SUB, false, Paint.Align.LEFT);
        roundPanel(c, 140, 1117, 267, 50, 10, PANEL2, BORDER);
        text(c, audioSourceName(), 154, 1149, 18, WHITE, false, Paint.Align.LEFT);
        text(c, "⌄", 382, 1149, 25, SUB, false, Paint.Align.CENTER);

        roundPanel(c, 16, 1193, 411, 166, 18, PANEL, BORDER);
        drawSmallSquareIcon(c, 40, 1213, 78, "≡");
        text(c, "System Preset", 139, 1245, 24, WHITE, true, Paint.Align.LEFT);
        text(c, "พรีเซ็ตระบบ", 139, 1273, 17, SUB, false, Paint.Align.LEFT);
        roundPanel(c, 140, 1291, 267, 50, 10, PANEL2, BORDER);
        text(c, presetName(), 154, 1323, 18, WHITE, false, Paint.Align.LEFT);
        text(c, "⌄", 382, 1323, 25, SUB, false, Paint.Align.CENTER);

        roundPanel(c, 440, 1021, 408, 338, 18, PANEL, BORDER);
        drawSmallSquareIcon(c, 463, 1042, 76, "▦");
        text(c, "Device Status", 563, 1074, 24, WHITE, true, Paint.Align.LEFT);
        text(c, "สถานะอุปกรณ์", 563, 1102, 18, SUB, false, Paint.Align.LEFT);
        statusLine(c, 1115, "Connected", deviceLabel(), bleConnected ? GREEN : Color.rgb(255, 193, 50));
        statusLine(c, 1170, "Voltage", "13.6 V", GREEN);
        statusLine(c, 1225, "Temperature", "42 °C", Color.rgb(0, 229, 210));
        statusLine(c, 1280, "System", bleConnected ? "Normal" : "Standby", GREEN);
    }

    private void drawHomeSlider(Canvas c, int idx, float x0, float cy, float x1, int color) {
        float value = homeRaw(idx);
        float lo = homeMin(idx), hi = homeMax(idx);
        float f = (DspState.clamp(value, lo, hi) - lo) / (hi - lo);
        drawSlider(c, x0, cy, x1, f, color, 18);
        String[] labels;
        if (idx == 2) labels = new String[]{"20", "50", "100", "200", "500"};
        else if (idx == 0) labels = new String[]{"-60", "-40", "-20", "0", "+12"};
        else if (idx == 1 || idx >= 4) labels = new String[]{"-12", "-6", "0", "+6", "+12"};
        else labels = new String[]{"-10", "-6", "0", "+6", "+12"};
        for (int i = 0; i < labels.length; i++) text(c, labels[i], x0 + (x1 - x0) * i / 4f, cy + 42, 16, SUB, false, Paint.Align.CENTER);
    }

    private float homeRaw(int idx) {
        switch (idx) {
            case 0: return state.masterVolume;
            case 1: return state.bassVolume;
            case 2: return state.bassCutoff;
            case 3: return state.bassBoost;
            case 4: return state.middleBoost;
            default: return state.trebleBoost;
        }
    }

    private float homeMin(int idx) { return idx == 2 ? 20f : (idx == 0 ? -60f : -12f); }
    private float homeMax(int idx) { return idx == 2 ? 500f : 12f; }

    private String homeValue(int idx) {
        if (idx == 2) return String.format(Locale.US, "%.0f Hz", state.bassCutoff);
        return DspState.db(homeRaw(idx));
    }

    private void drawEq(Canvas c) {
        roundPanel(c, 16, 197, 832, 438, 18, PANEL, BORDER);
        drawRingIcon(c, 78, 251, 41, CYAN, 6);
        text(c, "Parametric EQ", 134, 257, 31, WHITE, true, Paint.Align.LEFT);
        text(c, "ปรับแต่งความถี่เสียงอย่างละเอียด", 134, 288, 20, SUB, false, Paint.Align.LEFT);

        roundPanel(c, 482, 217, 184, 72, 11, PANEL2, BORDER);
        text(c, "ช่องสัญญาณ", 505, 243, 16, WHITE, false, Paint.Align.LEFT);
        text(c, DspState.CHANNEL_LONG[state.channel], 505, 273, 18, WHITE, false, Paint.Align.LEFT);
        text(c, "⌄", 641, 265, 23, SUB, false, Paint.Align.CENTER);
        roundPanel(c, 678, 217, 155, 72, 11, PANEL2, BORDER);
        text(c, "◯", 714, 263, 32, WHITE, false, Paint.Align.CENTER);
        text(c, "รีเซ็ต EQ", 758, 262, 19, WHITE, false, Paint.Align.CENTER);

        drawEqGraph(c, 73, 315, 754, 270);
        drawEqGroupTabs(c);
        drawEqTable(c);

        roundPanel(c, 16, 1193, 832, 167, 18, PANEL, BORDER);
        drawSmallSquareIcon(c, 44, 1218, 82, "□");
        text(c, "Preset", 141, 1250, 24, WHITE, true, Paint.Align.LEFT);
        text(c, "ชุดค่าที่ใช้งานอยู่", 141, 1278, 17, SUB, false, Paint.Align.LEFT);
        roundPanel(c, 141, 1290, 184, 53, 10, PANEL2, BORDER);
        text(c, eqPresetName(), 155, 1324, 17, WHITE, false, Paint.Align.LEFT);
        text(c, "⌄", 302, 1323, 23, SUB, false, Paint.Align.CENTER);
        actionButton(c, 340, 1223, 135, 109, "▣", "Save");
        actionButton(c, 487, 1223, 151, 109, "□", "Manage");
        text(c, "B E T T E R   S O U N D", 739, 1307, 11, SUB, false, Paint.Align.CENTER);
        text(c, "A   B R I G H T E R   D R I V E", 739, 1330, 10, SUB, false, Paint.Align.CENTER);
    }

    private void drawEqGraph(Canvas c, float x, float y, float w, float h) {
        stroke.setStrokeWidth(1f);
        stroke.setColor(GRID);
        for (int i = 0; i <= 12; i++) c.drawLine(x + w * i / 12f, y, x + w * i / 12f, y + h, stroke);
        for (int i = 0; i <= 6; i++) c.drawLine(x, y + h * i / 6f, x + w, y + h * i / 6f, stroke);
        String[] db = {"+12", "+6", "0", "-6", "-12"};
        for (int i = 0; i < db.length; i++) text(c, db[i], x - 17, y + 47 + i * 54, 16, SUB, false, Paint.Align.RIGHT);
        text(c, "dB", x - 17, y + 20, 16, SUB, false, Paint.Align.RIGHT);
        String[] hz = {"20", "50", "100", "200", "500", "1k", "2k", "5k", "10k", "20k"};
        for (int i = 0; i < hz.length; i++) text(c, hz[i], x + w * i / (hz.length - 1f), y + h + 31, 16, SUB, false, Paint.Align.CENTER);
        text(c, "Hz", x + w + 5, y + h + 31, 16, SUB, false, Paint.Align.RIGHT);

        int start = state.eqGroup * 6;
        int count = Math.min(6, DspState.BANDS - start);
        Path path = new Path();
        for (int i = 0; i < count; i++) {
            int b = start + i;
            float px = logFreqX(state.freq[state.channel][b], x, w);
            float py = y + h * (12f - DspState.clamp(state.gain[state.channel][b], -12f, 12f)) / 24f;
            if (i == 0) path.moveTo(px, py); else path.lineTo(px, py);
        }
        stroke.setStrokeWidth(4);
        stroke.setColor(CYAN);
        stroke.setShadowLayer(13, 0, 0, CYAN);
        c.drawPath(path, stroke);
        stroke.clearShadowLayer();
        for (int i = 0; i < count; i++) {
            int b = start + i;
            float px = logFreqX(state.freq[state.channel][b], x, w);
            float py = y + h * (12f - DspState.clamp(state.gain[state.channel][b], -12f, 12f)) / 24f;
            glowDot(c, px, py, eqColors[i], 10);
        }
    }

    private void drawEqGroupTabs(Canvas c) {
        String[] names = {"Bands 1 - 6", "Bands 7 - 12", "Bands 13 - 15"};
        float[] xs = {18, 244, 456};
        float[] ws = {221, 205, 199};
        for (int i = 0; i < 3; i++) {
            boolean selected = state.eqGroup == i;
            roundPanel(c, xs[i], 651, ws[i], 57, 10, selected ? Color.rgb(0, 113, 232) : PANEL2, selected ? CYAN : BORDER);
            if (selected) glowRect(c, xs[i], 651, ws[i], 57, 10, CYAN);
            text(c, names[i], xs[i] + ws[i] / 2, 688, 20, WHITE, false, Paint.Align.CENTER);
        }
    }

    private void drawEqTable(Canvas c) {
        roundPanel(c, 16, 711, 832, 465, 18, PANEL, BORDER);
        text(c, "#", 49, 758, 17, WHITE, false, Paint.Align.CENTER);
        text(c, "Type", 145, 758, 17, WHITE, false, Paint.Align.CENTER);
        text(c, "Frequency", 359, 758, 17, WHITE, false, Paint.Align.CENTER);
        text(c, "Gain", 506, 758, 17, WHITE, false, Paint.Align.CENTER);
        text(c, "Q", 668, 758, 17, WHITE, false, Paint.Align.CENTER);
        text(c, "Power", 795, 758, 17, WHITE, false, Paint.Align.CENTER);
        stroke.setStrokeWidth(1); stroke.setColor(BORDER_SOFT); c.drawLine(32, 770, 832, 770, stroke);

        int start = state.eqGroup * 6;
        int count = Math.min(6, DspState.BANDS - start);
        for (int row = 0; row < 6; row++) {
            float y = 782 + row * 63f;
            if (row >= count) {
                stroke.setColor(BORDER_SOFT); c.drawLine(34, y + 55, 830, y + 55, stroke);
                continue;
            }
            int b = start + row;
            glowDot(c, 47, y + 27, eqColors[row], 10);
            text(c, Integer.toString(b + 1), 76, y + 34, 18, WHITE, false, Paint.Align.CENTER);
            field(c, 102, y + 4, 173, 46, typeName(state.eqType[state.channel][b]), true);
            field(c, 290, y + 4, 135, 46, DspState.hz(state.freq[state.channel][b]), true);
            field(c, 439, y + 4, 137, 46, DspState.db(state.gain[state.channel][b]), true);
            field(c, 590, y + 4, 146, 46, String.format(Locale.US, "%.2f", state.q[state.channel][b]), true);
            drawToggle(c, 756, y + 10, 74, 36, state.eqPower[state.channel][b], CYAN);
            stroke.setColor(BORDER_SOFT); c.drawLine(34, y + 58, 830, y + 58, stroke);
        }
    }

    private String typeName(int t) { return DspState.EQ_TYPES[Math.floorMod(t, DspState.EQ_TYPES.length)]; }

    private void drawCrossover(Canvas c) {
        roundPanel(c, 17, 198, 831, 468, 18, PANEL, BORDER);
        drawRingIcon(c, 81, 257, 45, Color.rgb(226, 51, 240), 2);
        text(c, "Crossover", 171, 261, 31, WHITE, true, Paint.Align.LEFT);
        text(c, "ตั้งค่าการแบ่งความถี่", 171, 294, 19, SUB, false, Paint.Align.LEFT);
        field(c, 493, 233, 171, 60, crossoverMagnitude ? "Magnitude" : "Phase", false);
        roundPanel(c, 679, 233, 149, 60, 11, PANEL2, BORDER);
        text(c, "↻", 715, 271, 31, WHITE, false, Paint.Align.CENTER);
        text(c, "Reset", 773, 271, 19, WHITE, false, Paint.Align.CENTER);
        drawCrossoverGraph(c, 82, 371, 738, 244);

        drawFilterPanel(c, true, 681, Color.rgb(0, 184, 255));
        drawFilterPanel(c, false, 927, Color.rgb(233, 50, 237));

        roundPanel(c, 17, 1175, 831, 192, 18, PANEL, BORDER);
        drawSmallSquareIcon(c, 40, 1187, 62, "⚙");
        text(c, "Advanced Settings", 121, 1210, 21, WHITE, true, Paint.Align.LEFT);
        text(c, "ตั้งค่าขั้นสูง", 121, 1235, 16, SUB, false, Paint.Align.LEFT);
        advancedCell(c, 39, 1253, 201, "Phase", state.phaseDeg[state.channel] + "°", true);
        advancedCell(c, 252, 1253, 190, "Polarity", state.polarityInvert[state.channel] ? "Invert" : "Normal", true);
        roundPanel(c, 454, 1253, 145, 98, 10, PANEL2, BORDER);
        text(c, "↔", 479, 1291, 23, SUB, false, Paint.Align.CENTER);
        text(c, "Link L/R", 533, 1289, 15, WHITE, false, Paint.Align.CENTER);
        drawToggle(c, 500, 1304, 65, 35, state.linkLR[state.channel], CYAN);
        advancedCell(c, 612, 1253, 216, "Output Mode", state.outputMode[state.channel] == 0 ? "Stereo" : "Mono", false);
    }

    private void drawCrossoverGraph(Canvas c, float x, float y, float w, float h) {
        stroke.setStrokeWidth(1); stroke.setColor(GRID);
        for (int i = 0; i <= 12; i++) c.drawLine(x + w * i / 12f, y, x + w * i / 12f, y + h, stroke);
        for (int i = 0; i <= 5; i++) c.drawLine(x, y + h * i / 5f, x + w, y + h * i / 5f, stroke);
        String[] db = {"+12", "+6", "0", "-6", "-12", "-24"};
        for (int i = 0; i < db.length; i++) text(c, db[i], x - 12, y + 35 + i * 42, 15, SUB, false, Paint.Align.RIGHT);
        String[] hz = {"20", "50", "100", "200", "500", "1k", "2k", "5k", "10k", "20k"};
        for (int i = 0; i < hz.length; i++) text(c, hz[i], x + w * i / (hz.length - 1f), y + h + 31, 15, SUB, false, Paint.Align.CENTER);

        float hpfX = logFreqX(state.hpfFreq[state.channel], x, w);
        float lpfX = logFreqX(state.lpfFreq[state.channel], x, w);
        Path hp = new Path(); hp.moveTo(x, y + h); hp.lineTo(hpfX - 80, y + h * .62f); hp.lineTo(hpfX, y + h * .38f); hp.lineTo(x + w, y + h * .38f);
        Path lp = new Path(); lp.moveTo(x, y + h * .38f); lp.lineTo(lpfX, y + h * .38f); lp.lineTo(lpfX + 90, y + h * .65f); lp.lineTo(x + w, y + h);
        stroke.setStrokeWidth(4);
        stroke.setColor(CYAN); stroke.setShadowLayer(12, 0, 0, CYAN); c.drawPath(hp, stroke); stroke.clearShadowLayer();
        stroke.setColor(Color.rgb(235, 48, 239)); stroke.setShadowLayer(12, 0, 0, Color.rgb(235, 48, 239)); c.drawPath(lp, stroke); stroke.clearShadowLayer();
        glowDot(c, hpfX, y + h * .38f, CYAN, 10);
        glowDot(c, lpfX, y + h * .38f, Color.rgb(235, 48, 239), 10);
        text(c, "●  High Pass (HPF)     ●  Low Pass (LPF)", x + w - 5, y - 14, 15, SUB, false, Paint.Align.RIGHT);
    }

    private void drawFilterPanel(Canvas c, boolean high, float y, int color) {
        roundPanel(c, 17, y, 831, 231, 18, PANEL, BORDER);
        drawRingIcon(c, 82, y + 59, 43, color, high ? 7 : 8);
        text(c, high ? "High Pass Filter (HPF)" : "Low Pass Filter (LPF)", 165, y + 55, 27, WHITE, true, Paint.Align.LEFT);
        text(c, high ? "กรองความถี่ต่ำออก" : "กรองความถี่สูงออก", 165, y + 86, 18, SUB, false, Paint.Align.LEFT);
        text(c, "Bypass", 677, y + 56, 17, WHITE, false, Paint.Align.LEFT);
        drawToggle(c, 748, y + 31, 76, 42, high ? state.hpfBypass[state.channel] : state.lpfBypass[state.channel], color);
        int type = high ? state.hpfType[state.channel] : state.lpfType[state.channel];
        int slope = high ? state.hpfSlope[state.channel] : state.lpfSlope[state.channel];
        float freq = high ? state.hpfFreq[state.channel] : state.lpfFreq[state.channel];
        filterField(c, 40, y + 113, 259, "Type", DspState.FILTER_TYPES[Math.floorMod(type, DspState.FILTER_TYPES.length)]);
        filterField(c, 310, y + 113, 250, "Frequency", DspState.hz(freq));
        filterField(c, 573, y + 113, 254, "Slope", DspState.SLOPES[Math.floorMod(slope, DspState.SLOPES.length)]);
    }

    private void drawDelay(Canvas c) {
        roundPanel(c, 18, 196, 830, 533, 18, PANEL, BORDER);
        drawRingIcon(c, 82, 256, 44, Color.rgb(30, 237, 149), 9);
        text(c, "Delay", 154, 257, 29, WHITE, true, Paint.Align.LEFT);
        text(c, "ตั้งค่าหน่วงเวลาเพื่อการจัดตำแหน่งเสียง", 154, 288, 18, SUB, false, Paint.Align.LEFT);
        roundPanel(c, 486, 223, 161, 57, 10, PANEL2, BORDER);
        roundPanel(c, state.delayUnitMs ? 489 : 566, 226, 77, 51, 9, Color.rgb(0, 114, 236), CYAN);
        text(c, "ms", 527, 260, 18, WHITE, false, Paint.Align.CENTER);
        text(c, "cm", 607, 260, 18, WHITE, false, Paint.Align.CENTER);
        roundPanel(c, 659, 223, 173, 57, 10, PANEL2, BORDER);
        text(c, "↻", 697, 260, 30, WHITE, false, Paint.Align.CENTER);
        text(c, "ซิงค์ทุกช่อง", 764, 258, 17, WHITE, false, Paint.Align.CENTER);

        drawCar(c, 48, 316, 420, 374);
        delayInfoPanels(c);
        for (int ch = 0; ch < 7; ch++) drawDelayRow(c, ch, 744 + ch * 82f);
    }

    private void drawCar(Canvas c, float x, float y, float w, float h) {
        stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(3); stroke.setColor(Color.rgb(0, 103, 197));
        RectF body = new RectF(x + 95, y, x + w - 45, y + h); c.drawRoundRect(body, 90, 90, stroke);
        c.drawLine(x + 155, y + 65, x + w - 105, y + 65, stroke);
        c.drawLine(x + 155, y + h - 70, x + w - 105, y + h - 70, stroke);
        for (int r = 0; r < 2; r++) for (int col = 0; col < 2; col++) {
            float sx = x + 170 + col * 105; float sy = y + 125 + r * 145;
            roundPanel(c, sx, sy, 74, 92, 22, Color.rgb(0, 50, 88), Color.rgb(0, 91, 155));
        }
        float[][] pin = {{145,98},{370,100},{137,265},{374,265},{258,40},{258,335},{262,232}};
        for (int ch = 0; ch < 7; ch++) {
            float px = x + pin[ch][0], py = y + pin[ch][1];
            glowDot(c, px, py, channelColors[ch], 15);
            text(c, String.format(Locale.US, "%.2f ms", state.delayMs[ch]), px + (px < x + w/2 ? -24 : 24), py + 7, 16, WHITE, false,
                    px < x + w/2 ? Paint.Align.RIGHT : Paint.Align.LEFT);
        }
    }

    private void delayInfoPanels(Canvas c) {
        float x = 496;
        roundPanel(c, x, 301, 337, 125, 12, PANEL2, BORDER);
        text(c, "♧", x + 34, 347, 30, CYAN, false, Paint.Align.CENTER);
        text(c, "Seat Preset", x + 87, 337, 20, WHITE, true, Paint.Align.LEFT);
        text(c, "ตำแหน่งการฟัง", x + 87, 365, 16, SUB, false, Paint.Align.LEFT);
        field(c, x + 87, 372, 226, 42, state.seatPreset == 0 ? "Driver (Left)" : "All Seats", false);

        roundPanel(c, x, 438, 337, 139, 12, PANEL2, BORDER);
        text(c, "⌁", x + 35, 486, 31, CYAN, false, Paint.Align.CENTER);
        text(c, "Distance Reference", x + 87, 472, 19, WHITE, true, Paint.Align.LEFT);
        text(c, "อ้างอิงระยะทางเสียง", x + 87, 500, 15, SUB, false, Paint.Align.LEFT);
        text(c, "Speed of Sound (20°C)", x + 87, 536, 16, SUB, false, Paint.Align.LEFT);
        text(c, "343 m/s (34.3 cm/ms)", x + 87, 562, 16, SUB, false, Paint.Align.LEFT);

        roundPanel(c, x, 589, 337, 119, 12, PANEL2, BORDER);
        text(c, "▥", x + 36, 636, 30, CYAN, false, Paint.Align.CENTER);
        text(c, "Total Delay Range", x + 87, 623, 19, WHITE, true, Paint.Align.LEFT);
        text(c, "ช่วงหน่วงเวลาทั้งหมด", x + 87, 650, 15, SUB, false, Paint.Align.LEFT);
        text(c, "0.00 ms", x + 87, 684, 20, WHITE, false, Paint.Align.LEFT);
        text(c, String.format(Locale.US, "%.2f ms", maxDelay()), x + 298, 684, 20, WHITE, false, Paint.Align.RIGHT);
    }

    private float maxDelay() {
        float m = 0f; for (float v : state.delayMs) m = Math.max(m, v); return m;
    }

    private void drawDelayRow(Canvas c, int ch, float y) {
        roundPanel(c, 17, y, 831, 76, 15, PANEL, BORDER);
        glowDot(c, 48, y + 34, channelColors[ch], 12);
        text(c, "CH" + (ch + 1), 83, y + 31, 20, WHITE, true, Paint.Align.LEFT);
        text(c, DspState.CHANNEL_NAME[ch], 83, y + 57, 16, SUB, false, Paint.Align.LEFT);
        float frac = DspState.clamp(state.delayMs[ch] / 10f, 0f, 1f);
        drawSlider(c, 198, y + 30, 646, frac, channelColors[ch], 15);
        for (int i = 0; i <= 5; i++) text(c, Integer.toString(i * 2), 198 + (646 - 198) * i / 5f, y + 61, 13, SUB, false, Paint.Align.CENTER);
        roundPanel(c, 678, y + 9, 154, 57, 9, PANEL2, BORDER);
        text(c, delayDisplay(ch), 755, y + 31, 17, WHITE, false, Paint.Align.CENTER);
        text(c, String.format(Locale.US, "%.1f cm", state.delayMs[ch] * 34.3f), 755, y + 54, 15, SUB, false, Paint.Align.CENTER);
    }

    private String delayDisplay(int ch) {
        if (state.delayUnitMs) return String.format(Locale.US, "%.2f ms", state.delayMs[ch]);
        return String.format(Locale.US, "%.1f cm", state.delayMs[ch] * 34.3f);
    }

    private void drawOutput(Canvas c) {
        roundPanel(c, 17, 197, 831, 356, 18, PANEL, BORDER);
        drawRingIcon(c, 82, 259, 44, Color.rgb(255, 152, 38), 0);
        text(c, "Output", 174, 266, 31, WHITE, true, Paint.Align.LEFT);
        text(c, "ปรับระดับเอาต์พุตแต่ละช่อง", 174, 298, 19, SUB, false, Paint.Align.LEFT);
        roundPanel(c, 478, 233, 167, 62, 11, PANEL2, BORDER);
        text(c, "♩", 515, 273, 25, WHITE, false, Paint.Align.CENTER);
        text(c, "All Mute Off", 579, 271, 17, WHITE, false, Paint.Align.CENTER);
        roundPanel(c, 659, 233, 172, 62, 11, PANEL2, BORDER);
        text(c, "↻", 695, 273, 28, WHITE, false, Paint.Align.CENTER);
        text(c, "Reset Levels", 760, 271, 17, WHITE, false, Paint.Align.CENTER);

        roundPanel(c, 31, 336, 529, 202, 11, PANEL2, BORDER_SOFT);
        text(c, "Output Level Overview", 51, 369, 18, WHITE, false, Paint.Align.LEFT);
        drawMeters(c, 70, 389, 455, 101);
        roundPanel(c, 570, 336, 263, 202, 11, PANEL2, BORDER_SOFT);
        text(c, "Master Output", 590, 375, 18, WHITE, false, Paint.Align.LEFT);
        roundPanel(c, 724, 354, 95, 50, 9, PANEL2, BORDER);
        text(c, DspState.db(state.masterOutput), 772, 386, 18, WHITE, false, Paint.Align.CENTER);
        drawSlider(c, 590, 446, 813, (state.masterOutput + 60f) / 72f, CYAN, 16);
        String[] lab = {"-60", "-40", "-20", "0", "+12"};
        for (int i = 0; i < 5; i++) text(c, lab[i], 590 + 223 * i / 4f, 493, 14, SUB, false, Paint.Align.CENTER);

        for (int ch = 0; ch < 7; ch++) drawOutputRow(c, ch, 571 + ch * 109f);
    }

    private void drawMeters(Canvas c, float x, float y, float w, float h) {
        float colW = w / 7f;
        for (int ch = 0; ch < 7; ch++) {
            float level = (state.fader[ch] + 60f) / 72f;
            int segments = 12;
            for (int s = 0; s < segments; s++) {
                float yy = y + h - (s + 1) * 7f;
                p.setColor(s < Math.round(level * segments) ? channelColors[ch] : Color.rgb(5, 35, 57));
                c.drawRoundRect(new RectF(x + ch * colW + 12, yy, x + ch * colW + 38, yy + 4), 2, 2, p);
            }
            text(c, "CH" + (ch + 1), x + ch * colW + 25, y + h + 24, 14, WHITE, false, Paint.Align.CENTER);
            text(c, DspState.CHANNEL_NAME[ch], x + ch * colW + 25, y + h + 45, 12, SUB, false, Paint.Align.CENTER);
        }
    }

    private void drawOutputRow(Canvas c, int ch, float y) {
        roundPanel(c, 17, y, 831, 99, 14, PANEL, BORDER);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(4); p.setColor(channelColors[ch]); p.setShadowLayer(10, 0, 0, channelColors[ch]);
        c.drawCircle(61, y + 40, 25, p); p.clearShadowLayer(); p.setStyle(Paint.Style.FILL);
        text(c, Integer.toString(ch + 1), 61, y + 48, 19, WHITE, true, Paint.Align.CENTER);
        text(c, "CH" + (ch + 1), 108, y + 37, 20, WHITE, true, Paint.Align.LEFT);
        text(c, DspState.CHANNEL_NAME[ch], 108, y + 65, 16, SUB, false, Paint.Align.LEFT);
        drawSlider(c, 195, y + 34, 426, (state.fader[ch] + 60f) / 72f, channelColors[ch], 14);
        String[] lab = {"-60", "-40", "-20", "0", "+12"};
        for (int i = 0; i < 5; i++) text(c, lab[i], 195 + 231 * i / 4f, y + 69, 12, SUB, false, Paint.Align.CENTER);
        roundPanel(c, 441, y + 17, 93, 50, 9, PANEL2, BORDER);
        text(c, DspState.db(state.fader[ch]), 487, y + 49, 17, WHITE, false, Paint.Align.CENTER);
        miniButton(c, 548, y + 11, 63, 69, state.mute[ch], "◖", "Mute");
        miniButton(c, 621, y + 11, 63, 69, state.solo[ch], "♧", "Solo");
        miniButton(c, 694, y + 11, 63, 69, state.phase180[ch], "Ø", "Phase");
        if (ch < 2 || state.link[ch]) miniButton(c, 767, y + 11, 63, 69, state.link[ch], "↗", "Link");
    }

    private void drawBottomNav(Canvas c) {
        roundPanel(c, 17, 1396, 830, 106, 18, Color.rgb(2, 20, 37), BORDER);
        String[] labels = {"Home", "EQ", "Crossover", "Delay", "Output"};
        float cell = 830f / 5f;
        for (int i = 0; i < 5; i++) {
            float x = 17 + i * cell;
            if (page == i) {
                roundPanel(c, x + 4, 1401, cell - 8, 96, 14, Color.rgb(0, 91, 211), BLUE);
                glowRect(c, x + 4, 1401, cell - 8, 96, 14, BLUE);
            }
            int col = page == i ? CYAN : Color.rgb(182, 215, 249);
            float cx = x + cell / 2;
            if (i == 0) navHomeIcon(c, cx, 1434, col);
            else if (i == 1) navEqIcon(c, cx, 1434, col);
            else if (i == 2) navXoverIcon(c, cx, 1434, col);
            else if (i == 3) navClockIcon(c, cx, 1434, col);
            else navOutputIcon(c, cx, 1434, col);
            text(c, labels[i], cx, 1482, 18, col, false, Paint.Align.CENTER);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX() * DW / Math.max(1f, getWidth());
        float y = e.getY() * DH / Math.max(1f, getHeight());
        int action = e.getActionMasked();

        if (action == MotionEvent.ACTION_DOWN) {
            if (y >= 1390f) {
                int target = Math.max(0, Math.min(4, (int)((x - 17f) / (830f / 5f))));
                page = target;
                drag = DRAG_NONE;
                invalidate();
                return true;
            }
            if (page != PAGE_HOME && y >= 100f && y <= 190f) {
                int ch = Math.max(0, Math.min(6, (int)((x - 18f) / 118f)));
                state.channel = ch;
                invalidate();
                return true;
            }
            if (x >= 500 && x < 785 && y <= 95) {
                if (ble != null) { if (bleConnected) ble.requestDspRefresh(); else ble.startScan(); }
                return true;
            }
            if (x >= 785 && y <= 95) {
                if (ble != null) ble.requestDspRefresh();
                return true;
            }
            if (page == PAGE_HOME) return handleHomeDown(x, y);
            if (page == PAGE_EQ) return handleEqDown(x, y);
            if (page == PAGE_XOVER) return handleXoverDown(x, y);
            if (page == PAGE_DELAY) return handleDelayDown(x, y);
            return handleOutputDown(x, y);
        }

        if (action == MotionEvent.ACTION_MOVE) {
            if (drag >= DRAG_HOME_BASE && drag < DRAG_HOME_BASE + 6) updateHomeDrag(drag - DRAG_HOME_BASE, x);
            else if (drag == DRAG_EQ_GRAPH) updateEqGraphDrag(x, y);
            else if (drag >= DRAG_DELAY_BASE && drag < DRAG_DELAY_BASE + 7) updateDelayDrag(drag - DRAG_DELAY_BASE, x);
            else if (drag == DRAG_OUTPUT_MASTER) updateOutputMaster(x);
            else if (drag >= DRAG_OUTPUT_BASE && drag < DRAG_OUTPUT_BASE + 7) updateOutputDrag(drag - DRAG_OUTPUT_BASE, x);
            return true;
        }

        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            if (drag >= DRAG_HOME_BASE && drag < DRAG_HOME_BASE + 6 && ble != null) {
                int idx = drag - DRAG_HOME_BASE;
                if (idx == 0) ble.flushScalarRealtime(DspProtocol.ID_MASTER_VOLUME);
                else if (idx == 5) ble.flushScalarRealtime(DspProtocol.ID_TREBLE_BOOST);
            }
            drag = DRAG_NONE;
            dragBand = -1;
            state.saveHome(getContext());
            state.saveEq(getContext());
            invalidate();
            return true;
        }
        return true;
    }

    private boolean handleHomeDown(float x, float y) {
        float[] ys = {124, 273, 422, 571, 720, 869};
        for (int i = 0; i < 6; i++) {
            if (y >= ys[i] + 28 && y <= ys[i] + 108 && x >= 350 && x <= 690) {
                drag = DRAG_HOME_BASE + i; updateHomeDrag(i, x); return true;
            }
        }
        if (x >= 140 && x <= 407 && y >= 1110 && y <= 1175) {
            state.audioSource = (state.audioSource + 1) % 3; state.saveHome(getContext()); invalidate(); return true;
        }
        if (x >= 140 && x <= 407 && y >= 1284 && y <= 1348) {
            state.applyHomePreset((state.homePreset + 1) % 4);
            for (int i = 1; i < 6; i++) sendHomeScalar(i);
            state.saveHome(getContext()); invalidate(); return true;
        }
        if (x >= 500 && x <= 780 && y <= 100) {
            if (ble != null) ble.startScan(); return true;
        }
        return true;
    }

    private void updateHomeDrag(int idx, float x) {
        float f = DspState.clamp((x - 380f) / (669f - 380f), 0f, 1f);
        float value;
        if (idx == 2) value = expMap(f, 20f, 500f);
        else value = homeMin(idx) + f * (homeMax(idx) - homeMin(idx));
        value = round1(value);
        if (idx == 0) state.masterVolume = DspState.clamp(value, -60f, 6f);
        else if (idx == 1) state.bassVolume = DspState.clamp(value, -12f, 6f);
        else if (idx == 2) state.bassCutoff = DspState.clamp(Math.round(value), 20f, 250f);
        else if (idx == 3) state.bassBoost = value;
        else if (idx == 4) state.middleBoost = value;
        else state.trebleBoost = value;
        sendHomeScalar(idx);
        invalidate();
    }

    private boolean handleEqDown(float x, float y) {
        if (x >= 482 && x <= 666 && y >= 210 && y <= 300) { state.channel = (state.channel + 1) % 7; invalidate(); return true; }
        if (x >= 678 && x <= 833 && y >= 210 && y <= 300) {
            state.flattenEq(state.channel); for (int b = 0; b < 15; b++) sendEqGain(state.channel, b); invalidate(); return true;
        }
        if (y >= 645 && y <= 714) {
            if (x < 240) state.eqGroup = 0; else if (x < 452) state.eqGroup = 1; else if (x < 660) state.eqGroup = 2;
            invalidate(); return true;
        }
        if (x >= 70 && x <= 830 && y >= 310 && y <= 590) {
            int b = nearestVisibleEqBand(x, y);
            if (b >= 0) { dragBand = b; drag = DRAG_EQ_GRAPH; updateEqGraphDrag(x, y); }
            return true;
        }
        if (y >= 782 && y <= 1165) {
            int row = (int)((y - 782) / 63f);
            int b = state.eqGroup * 6 + row;
            if (row >= 0 && row < 6 && b < 15) {
                if (x >= 100 && x <= 275) state.eqType[state.channel][b] = (state.eqType[state.channel][b] + 1) % 3;
                else if (x >= 288 && x <= 426) {
                    float factor = x < 357 ? 0.9f : 1.1f;
                    state.freq[state.channel][b] = DspState.clamp(roundFreq(state.freq[state.channel][b] * factor), 20f, 20000f);
                } else if (x >= 438 && x <= 577) {
                    state.gain[state.channel][b] = DspState.clamp(round1(state.gain[state.channel][b] + (x < 508 ? -0.5f : 0.5f)), -12f, 12f);
                    sendEqGain(state.channel, b);
                } else if (x >= 589 && x <= 738) {
                    state.q[state.channel][b] = DspState.clamp(round2(state.q[state.channel][b] + (x < 664 ? -0.05f : 0.05f)), 0.05f, 20f);
                } else if (x >= 750 && x <= 840) state.eqPower[state.channel][b] = !state.eqPower[state.channel][b];
                state.saveEq(getContext()); invalidate(); return true;
            }
        }
        if (x >= 140 && x <= 326 && y >= 1284 && y <= 1348) { eqPreset = (eqPreset + 1) % 4; invalidate(); return true; }
        if (x >= 335 && x <= 480 && y >= 1210 && y <= 1345) { state.saveHome(getContext()); state.saveEq(getContext()); invalidate(); return true; }
        if (x >= 485 && x <= 645 && y >= 1210 && y <= 1345) { eqPreset = (eqPreset + 1) % 4; invalidate(); return true; }
        return true;
    }

    private int nearestVisibleEqBand(float x, float y) {
        int start = state.eqGroup * 6, count = Math.min(6, 15 - start);
        float best = 1e9f; int bestBand = -1;
        for (int i = 0; i < count; i++) {
            int b = start + i;
            float px = logFreqX(state.freq[state.channel][b], 73, 754);
            float py = 315 + 270 * (12f - DspState.clamp(state.gain[state.channel][b], -12f, 12f)) / 24f;
            float d = (px - x) * (px - x) + (py - y) * (py - y);
            if (d < best) { best = d; bestBand = b; }
        }
        return bestBand;
    }

    private void updateEqGraphDrag(float x, float y) {
        if (dragBand < 0 || dragBand >= 15) return;
        float gain = 12f - DspState.clamp((y - 315f) / 270f, 0f, 1f) * 24f;
        state.gain[state.channel][dragBand] = DspState.clamp(round1(gain), -12f, 12f);
        sendEqGain(state.channel, dragBand);
        invalidate();
    }

    private boolean handleXoverDown(float x, float y) {
        int ch = state.channel;
        if (x >= 490 && x < 675 && y >= 225 && y <= 304) { crossoverMagnitude = !crossoverMagnitude; invalidate(); return true; }
        if (x >= 680 && y >= 225 && y <= 304) {
            state.hpfFreq[ch] = 100f; state.lpfFreq[ch] = 1000f; state.hpfSlope[ch] = state.lpfSlope[ch] = 3; invalidate(); return true;
        }
        if (y >= 681 && y <= 912) {
            if (x >= 730 && y <= 770) state.hpfBypass[ch] = !state.hpfBypass[ch];
            else if (x >= 40 && x <= 300 && y >= 790) state.hpfType[ch] = (state.hpfType[ch] + 1) % DspState.FILTER_TYPES.length;
            else if (x >= 310 && x <= 560 && y >= 790) state.hpfFreq[ch] = nextFreq(state.hpfFreq[ch], x < 435 ? -1 : 1);
            else if (x >= 573 && x <= 827 && y >= 790) state.hpfSlope[ch] = Math.floorMod(state.hpfSlope[ch] + (x < 700 ? -1 : 1), DspState.SLOPES.length);
        } else if (y >= 927 && y <= 1160) {
            if (x >= 730 && y <= 1015) state.lpfBypass[ch] = !state.lpfBypass[ch];
            else if (x >= 40 && x <= 300 && y >= 1035) state.lpfType[ch] = (state.lpfType[ch] + 1) % DspState.FILTER_TYPES.length;
            else if (x >= 310 && x <= 560 && y >= 1035) state.lpfFreq[ch] = nextFreq(state.lpfFreq[ch], x < 435 ? -1 : 1);
            else if (x >= 573 && x <= 827 && y >= 1035) state.lpfSlope[ch] = Math.floorMod(state.lpfSlope[ch] + (x < 700 ? -1 : 1), DspState.SLOPES.length);
        } else if (y >= 1250 && y <= 1360) {
            if (x < 240) state.phaseDeg[ch] = Math.floorMod(state.phaseDeg[ch] + (x < 140 ? -15 : 15), 360);
            else if (x < 442) state.polarityInvert[ch] = !state.polarityInvert[ch];
            else if (x < 600) state.linkLR[ch] = !state.linkLR[ch];
            else state.outputMode[ch] = 1 - state.outputMode[ch];
        }
        state.saveEq(getContext()); invalidate(); return true;
    }

    private boolean handleDelayDown(float x, float y) {
        if (y >= 220 && y <= 285 && x >= 485 && x <= 650) { state.delayUnitMs = x < 566; invalidate(); return true; }
        if (y >= 220 && y <= 285 && x >= 659 && x <= 835) {
            float v = state.delayMs[state.channel]; for (int i = 0; i < 7; i++) state.delayMs[i] = v; state.saveEq(getContext()); invalidate(); return true;
        }
        if (x >= 580 && x <= 820 && y >= 368 && y <= 420) { state.seatPreset = 1 - state.seatPreset; invalidate(); return true; }
        for (int ch = 0; ch < 7; ch++) {
            float yy = 744 + ch * 82f;
            if (y >= yy && y <= yy + 76 && x >= 180 && x <= 665) {
                drag = DRAG_DELAY_BASE + ch; updateDelayDrag(ch, x); return true;
            }
        }
        return true;
    }

    private void updateDelayDrag(int ch, float x) {
        float f = DspState.clamp((x - 198f) / (646f - 198f), 0f, 1f);
        state.delayMs[ch] = round2(f * 10f);
        invalidate();
    }

    private boolean handleOutputDown(float x, float y) {
        if (y >= 225 && y <= 305 && x >= 470 && x <= 650) {
            for (int i = 0; i < 7; i++) state.mute[i] = false; invalidate(); return true;
        }
        if (y >= 225 && y <= 305 && x >= 655 && x <= 835) {
            float[] defaults = {-3f, -2.5f, -4f, -1f, -2f, -3.5f, -4.5f};
            System.arraycopy(defaults, 0, state.fader, 0, 7); state.masterOutput = -1f; invalidate(); return true;
        }
        if (y >= 410 && y <= 490 && x >= 570 && x <= 830) { drag = DRAG_OUTPUT_MASTER; updateOutputMaster(x); return true; }
        for (int ch = 0; ch < 7; ch++) {
            float yy = 571 + ch * 109f;
            if (y < yy || y > yy + 99) continue;
            if (x >= 180 && x <= 440) { drag = DRAG_OUTPUT_BASE + ch; updateOutputDrag(ch, x); return true; }
            if (x >= 545 && x < 615) state.mute[ch] = !state.mute[ch];
            else if (x >= 615 && x < 690) state.solo[ch] = !state.solo[ch];
            else if (x >= 690 && x < 763) state.phase180[ch] = !state.phase180[ch];
            else if (x >= 763 && x < 840 && (ch < 2 || state.link[ch])) state.link[ch] = !state.link[ch];
            state.saveEq(getContext()); invalidate(); return true;
        }
        return true;
    }

    private void updateOutputMaster(float x) {
        float f = DspState.clamp((x - 590f) / (813f - 590f), 0f, 1f);
        state.masterOutput = round1(-60f + f * 72f); invalidate();
    }

    private void updateOutputDrag(int ch, float x) {
        float f = DspState.clamp((x - 195f) / (426f - 195f), 0f, 1f);
        state.fader[ch] = round1(-60f + f * 72f); invalidate();
    }

    private float nextFreq(float current, int direction) {
        double factor = direction < 0 ? 1.0 / 1.122462048 : 1.122462048;
        return DspState.clamp(roundFreq((float)(current * factor)), 20f, 20000f);
    }

    private String audioSourceName() {
        String[] s = {"High Level (Speaker)", "Bluetooth", "AUX / RCA"};
        return s[Math.floorMod(state.audioSource, s.length)];
    }

    private String presetName() {
        String[] s = {"Flat", "Pop", "Rock", "Jazz"};
        return s[Math.floorMod(state.homePreset, s.length)];
    }

    private String eqPresetName() {
        String[] s = {"Custom 1", "Custom 2", "Custom 3", "Flat"};
        return s[Math.floorMod(eqPreset, s.length)];
    }

    private void statusLine(Canvas c, float y, String label, String value, int color) {
        stroke.setStrokeWidth(1); stroke.setColor(BORDER_SOFT); c.drawLine(466, y + 41, 824, y + 41, stroke);
        glowDot(c, 479, y + 19, color, 8);
        text(c, label, 518, y + 26, 17, SUB, false, Paint.Align.LEFT);
        text(c, value, 820, y + 26, 17, label.equals("System") ? GREEN : SUB, false, Paint.Align.RIGHT);
    }

    private void drawRingIcon(Canvas c, float cx, float cy, float r, int color, int kind) {
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(4); p.setColor(color); p.setShadowLayer(14, 0, 0, color);
        c.drawCircle(cx, cy, r, p); p.clearShadowLayer();
        stroke.setColor(color); stroke.setStrokeWidth(5); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeCap(Paint.Cap.ROUND);
        if (kind == 0) {
            Path path = new Path(); path.moveTo(cx - 20, cy - 10); path.lineTo(cx - 8, cy - 10); path.lineTo(cx + 7, cy - 24); path.lineTo(cx + 7, cy + 24); path.lineTo(cx - 8, cy + 10); path.lineTo(cx - 20, cy + 10); c.drawPath(path, stroke);
            c.drawArc(new RectF(cx - 2, cy - 20, cx + 28, cy + 20), -60, 120, false, stroke);
        } else if (kind == 2) {
            c.drawLine(cx - 20, cy - 18, cx + 22, cy - 18, stroke); c.drawLine(cx - 7, cy - 18, cx - 7, cy + 24, stroke); c.drawLine(cx - 7, cy - 18, cx + 23, cy + 12, stroke);
        } else if (kind == 9) {
            c.drawCircle(cx, cy, 22, stroke); c.drawLine(cx, cy, cx, cy - 14, stroke); c.drawLine(cx, cy, cx + 12, cy + 6, stroke);
        } else if (kind == 7 || kind == 8) {
            Path path = new Path();
            if (kind == 7) { path.moveTo(cx - 25, cy + 20); path.cubicTo(cx - 7, cy + 20, cx - 11, cy - 17, cx + 25, cy - 17); }
            else { path.moveTo(cx - 25, cy - 17); path.cubicTo(cx + 8, cy - 17, cx + 7, cy + 20, cx + 25, cy + 20); }
            c.drawPath(path, stroke);
        } else if (kind == 6) {
            for (int i = 0; i < 5; i++) c.drawLine(cx - 25 + i * 12, cy - 25 + (i % 2) * 12, cx - 25 + i * 12, cy + 25 - (i % 2) * 12, stroke);
        } else {
            c.drawCircle(cx, cy, 20, stroke); c.drawCircle(cx, cy, 8, stroke);
        }
        stroke.setStrokeCap(Paint.Cap.BUTT); p.setStyle(Paint.Style.FILL);
    }

    private void drawSmallSquareIcon(Canvas c, float x, float y, float s, String symbol) {
        roundPanel(c, x, y, s, s, 14, Color.rgb(0, 61, 121), Color.rgb(0, 134, 241));
        glowRect(c, x, y, s, s, 14, BLUE);
        text(c, symbol, x + s / 2, y + s * .65f, s * .46f, Color.rgb(146, 226, 255), true, Paint.Align.CENTER);
    }

    private void actionButton(Canvas c, float x, float y, float w, float h, String icon, String label) {
        roundPanel(c, x, y, w, h, 12, Color.rgb(2, 36, 65), BORDER);
        text(c, icon, x + w/2, y + 50, 34, Color.rgb(185, 231, 255), false, Paint.Align.CENTER);
        text(c, label, x + w/2, y + 83, 16, SUB, false, Paint.Align.CENTER);
    }

    private void field(Canvas c, float x, float y, float w, float h, String value, boolean arrows) {
        roundPanel(c, x, y, w, h, 8, PANEL2, BORDER);
        if (arrows) {
            text(c, "‹", x + 13, y + h * .67f, 26, SUB, false, Paint.Align.CENTER);
            text(c, "›", x + w - 13, y + h * .67f, 26, SUB, false, Paint.Align.CENTER);
        } else text(c, "⌄", x + w - 20, y + h * .67f, 22, SUB, false, Paint.Align.CENTER);
        text(c, value, x + w/2, y + h * .66f, 16, WHITE, false, Paint.Align.CENTER);
    }

    private void filterField(Canvas c, float x, float y, float w, String title, String value) {
        roundPanel(c, x, y, w, 101, 10, PANEL2, BORDER);
        text(c, title, x + 18, y + 30, 16, WHITE, false, Paint.Align.LEFT);
        roundPanel(c, x + 14, y + 47, w - 28, 45, 8, PANEL2, BORDER);
        text(c, value, x + 25, y + 77, 17, WHITE, false, Paint.Align.LEFT);
        text(c, "⌄", x + w - 30, y + 77, 23, SUB, false, Paint.Align.CENTER);
    }

    private void advancedCell(Canvas c, float x, float y, float w, String title, String value, boolean arrows) {
        roundPanel(c, x, y, w, 98, 10, PANEL2, BORDER);
        text(c, title, x + 20, y + 31, 15, WHITE, false, Paint.Align.LEFT);
        roundPanel(c, x + 12, y + 48, w - 24, 39, 7, PANEL2, BORDER);
        if (arrows) { text(c, "‹", x + 25, y + 77, 25, SUB, false, Paint.Align.CENTER); text(c, "›", x + w - 25, y + 77, 25, SUB, false, Paint.Align.CENTER); }
        else text(c, "⌄", x + w - 28, y + 77, 22, SUB, false, Paint.Align.CENTER);
        text(c, value, x + w/2, y + 76, 16, WHITE, false, Paint.Align.CENTER);
    }

    private void miniButton(Canvas c, float x, float y, float w, float h, boolean active, String icon, String label) {
        roundPanel(c, x, y, w, h, 9, active ? Color.rgb(0, 67, 126) : PANEL2, active ? CYAN : BORDER);
        if (active) glowRect(c, x, y, w, h, 9, CYAN);
        text(c, icon, x + w/2, y + 31, 23, active ? CYAN : Color.rgb(203, 228, 251), false, Paint.Align.CENTER);
        text(c, label, x + w/2, y + 56, 12, active ? CYAN : SUB, false, Paint.Align.CENTER);
    }

    private void drawToggle(Canvas c, float x, float y, float w, float h, boolean on, int color) {
        p.setColor(on ? Color.rgb(0, 126, 240) : Color.rgb(32, 58, 88));
        if (on) p.setShadowLayer(10, 0, 0, color);
        c.drawRoundRect(new RectF(x, y, x + w, y + h), h/2, h/2, p); p.clearShadowLayer();
        p.setColor(WHITE); float r = h * .38f; c.drawCircle(on ? x + w - h/2 : x + h/2, y + h/2, r, p);
    }

    private void drawSlider(Canvas c, float x0, float cy, float x1, float frac, int color, float knobR) {
        frac = DspState.clamp(frac, 0f, 1f);
        p.setColor(Color.rgb(31, 72, 112)); c.drawRoundRect(new RectF(x0, cy - 7, x1, cy + 7), 8, 8, p);
        p.setShader(new LinearGradient(x0, cy, x1, cy, color, CYAN, Shader.TileMode.CLAMP));
        c.drawRoundRect(new RectF(x0, cy - 7, x0 + (x1 - x0) * frac, cy + 7), 8, 8, p); p.setShader(null);
        float kx = x0 + (x1 - x0) * frac;
        p.setColor(WHITE); p.setShadowLayer(12, 0, 0, color); c.drawCircle(kx, cy, knobR, p); p.clearShadowLayer();
    }

    private void glowDot(Canvas c, float x, float y, int color, float r) {
        p.setColor(color); p.setShadowLayer(13, 0, 0, color); c.drawCircle(x, y, r, p); p.clearShadowLayer();
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); p.setColor(WHITE); c.drawCircle(x, y, r + 1, p); p.setStyle(Paint.Style.FILL);
    }

    private void roundPanel(Canvas c, float x, float y, float w, float h, float r, int fill, int border) {
        p.setStyle(Paint.Style.FILL); p.setColor(fill); c.drawRoundRect(new RectF(x, y, x + w, y + h), r, r, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.5f); p.setColor(border); c.drawRoundRect(new RectF(x, y, x + w, y + h), r, r, p); p.setStyle(Paint.Style.FILL);
    }

    private void glowRect(Canvas c, float x, float y, float w, float h, float r, int color) {
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); p.setColor(color); p.setShadowLayer(12, 0, 0, color);
        c.drawRoundRect(new RectF(x, y, x + w, y + h), r, r, p); p.clearShadowLayer(); p.setStyle(Paint.Style.FILL);
    }

    private void text(Canvas c, String s, float x, float y, float size, int color, boolean bold, Paint.Align align) {
        p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(color); p.setTextSize(size); p.setTextAlign(align);
        p.setTypeface(Typeface.create(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL));
        c.drawText(s == null ? "" : s, x, y, p);
    }

    private void navHomeIcon(Canvas c, float cx, float cy, int color) {
        p.setColor(color); Path h = new Path(); h.moveTo(cx - 22, cy); h.lineTo(cx, cy - 19); h.lineTo(cx + 22, cy); h.lineTo(cx + 18, cy + 23); h.lineTo(cx + 5, cy + 23); h.lineTo(cx + 5, cy + 6); h.lineTo(cx - 5, cy + 6); h.lineTo(cx - 5, cy + 23); h.lineTo(cx - 18, cy + 23); h.close(); c.drawPath(h, p);
    }

    private void navEqIcon(Canvas c, float cx, float cy, int color) {
        stroke.setStrokeWidth(3); stroke.setColor(color); Path q = new Path(); q.moveTo(cx - 25, cy + 5); q.lineTo(cx - 18, cy - 9); q.lineTo(cx - 10, cy + 17); q.lineTo(cx, cy - 18); q.lineTo(cx + 9, cy + 11); q.lineTo(cx + 18, cy - 6); q.lineTo(cx + 26, cy + 5); c.drawPath(q, stroke);
    }

    private void navXoverIcon(Canvas c, float cx, float cy, int color) {
        stroke.setStrokeWidth(3); stroke.setColor(color); Path a = new Path(); a.moveTo(cx - 25, cy - 15); a.cubicTo(cx - 5, cy - 15, cx - 13, cy + 20, cx + 25, cy + 20); c.drawPath(a, stroke); Path b = new Path(); b.moveTo(cx - 25, cy + 20); b.cubicTo(cx + 13, cy + 20, cx + 5, cy - 15, cx + 25, cy - 15); c.drawPath(b, stroke);
    }

    private void navClockIcon(Canvas c, float cx, float cy, int color) {
        stroke.setStrokeWidth(3); stroke.setColor(color); c.drawCircle(cx, cy, 20, stroke); c.drawLine(cx, cy, cx, cy - 11, stroke); c.drawLine(cx, cy, cx + 10, cy + 5, stroke);
    }

    private void navOutputIcon(Canvas c, float cx, float cy, int color) {
        p.setColor(color); for (int i = 0; i < 4; i++) c.drawRoundRect(new RectF(cx - 20 + i * 12, cy + 18 - i * 10, cx - 14 + i * 12, cy + 25), 3, 3, p);
    }

    private float logFreqX(float hz, float x, float w) {
        double a = Math.log10(Math.max(20f, hz) / 20.0) / Math.log10(20000.0 / 20.0);
        return x + (float)a * w;
    }

    private float expMap(float f, float lo, float hi) {
        return (float)(lo * Math.pow(hi / lo, f));
    }

    private float round1(float v) { return Math.round(v * 10f) / 10f; }
    private float round2(float v) { return Math.round(v * 100f) / 100f; }
    private float roundFreq(float v) {
        if (v < 100) return Math.round(v);
        if (v < 1000) return Math.round(v / 5f) * 5f;
        return Math.round(v / 50f) * 50f;
    }
}
