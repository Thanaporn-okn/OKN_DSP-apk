package com.okn.dsp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import java.util.Locale;

/**
 * V18: five-page full-screen UI rebuilt from the five uploaded reference screens.
 * The UI is immediate. Verified BLE writes remain serialized by BleManager's
 * original-app 380 ms scheduler to avoid the audio pumping seen in V11.
 */
final class DspView extends View {
    private static final float W = 864f;
    private static final float H = 1536f;
    private static final float NAV_H = 126f;
    private static final float BASE_NAV_TOP = H - NAV_H;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final DspState s = new DspState();
    private BleManager ble;

    private int page = 0; // Home/EQ/Crossover/Delay/Output
    private float scale = 1f, offsetX = 0f, offsetY = 0f, viewportH = H, extraH = 0f;
    private int dragHome = -1, dragDelay = -1, dragOutput = -1;
    private boolean dragMasterOutput = false, dragEqGraph = false;

    private String bleStatus = "กำลังค้นหา...";
    private String bleDevice = "OKN-DSP_7CH";
    private boolean bleConnected = false;
    private String diagnostic = "";

    private final int BG0 = Color.rgb(0, 6, 17);
    private final int BG1 = Color.rgb(0, 14, 29);
    private final int PANEL = Color.rgb(3, 27, 48);
    private final int PANEL2 = Color.rgb(2, 18, 35);
    private final int BORDER = Color.rgb(10, 78, 128);
    private final int CYAN = Color.rgb(0, 219, 255);
    private final int BLUE = Color.rgb(0, 126, 255);
    private final int WHITE = Color.rgb(241, 247, 255);
    private final int SUB = Color.rgb(157, 188, 225);
    private final int GREEN = Color.rgb(0, 235, 120);
    private final int MAGENTA = Color.rgb(240, 54, 236);
    private final int ORANGE = Color.rgb(255, 151, 37);
    private final int YELLOW = Color.rgb(255, 220, 45);
    private final int RED = Color.rgb(255, 58, 98);
    private final int PURPLE = Color.rgb(181, 57, 244);

    private final int[] channelColors = {BLUE, CYAN, Color.rgb(0,225,107), YELLOW, ORANGE, RED, PURPLE};
    private final int[] bandColors = {RED, ORANGE, Color.YELLOW, Color.GREEN, CYAN, PURPLE, MAGENTA};

    DspView(Context context, BleManager ble) {
        super(context);
        this.ble = ble;
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        setClickable(true);
        setFocusable(true);
        setHapticFeedbackEnabled(false);
    }

    void setBleManager(BleManager manager) { ble = manager; }
    void setBleStatus(String status, String deviceName, boolean connected) {
        bleStatus = status == null ? "" : status;
        if (deviceName != null && !deviceName.isEmpty()) bleDevice = deviceName;
        bleConnected = connected;
        invalidate();
    }
    void setDiagnostic(String message) { diagnostic = message == null ? "" : message; invalidate(); }
    void setScalarFromDsp(int id, float v) {
        switch (id) {
            case DspProtocol.ID_MASTER_VOLUME: s.masterVolume = v; break;
            case DspProtocol.ID_BASS_VOLUME: s.bassVolume = v; break;
            case DspProtocol.ID_BASS_CUTOFF: s.bassCutoff = v; break;
            case DspProtocol.ID_BASS_BOOST: s.bassBoost = v; break;
            case DspProtocol.ID_MIDDLE_BOOST: s.middleBoost = v; break;
            case DspProtocol.ID_TREBLE_BOOST: s.trebleBoost = v; break;
            default: return;
        }
        invalidate();
    }
    void setEqFromDsp(int ch, int band, int type, float f, float g, float q, boolean writable) {
        if (ch < 0 || ch >= DspState.CHANNELS || band < 0 || band >= DspState.BANDS) return;
        s.eqType[ch][band] = type; s.freq[ch][band] = f; s.gain[ch][band] = g; s.q[ch][band] = q; s.eqWritable[ch][band] = writable;
        invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float widthScale = getWidth() / W;
        float hAtWidth = getHeight() / widthScale;
        if (hAtWidth >= H) {
            scale = widthScale; viewportH = hAtWidth; extraH = viewportH - H; offsetX = 0; offsetY = 0;
        } else {
            scale = getHeight() / H; viewportH = H; extraH = 0; offsetX = (getWidth() - W * scale) * .5f; offsetY = 0;
        }
        canvas.drawColor(BG0);
        canvas.save(); canvas.translate(offsetX, offsetY); canvas.scale(scale, scale);
        drawBackground(canvas);
        drawHeader(canvas);
        if (page == 0) drawHome(canvas);
        else { drawChannelTabs(canvas); if (page == 1) drawEq(canvas); else if (page == 2) drawCrossover(canvas); else if (page == 3) drawDelay(canvas); else drawOutput(canvas); }
        drawBottomNav(canvas);
        canvas.restore();
    }

    private float y(float base) {
        if (extraH <= 0f || base <= 104f) return base;
        if (base >= BASE_NAV_TOP) return base + extraH;
        float t = (base - 104f) / (BASE_NAV_TOP - 104f);
        return base + extraH * t;
    }
    private float navTop() { return viewportH - NAV_H; }

    private void drawBackground(Canvas c) {
        p.setShader(new LinearGradient(0,0,W,viewportH,BG1,BG0, Shader.TileMode.CLAMP));
        c.drawRect(0,0,W,viewportH,p); p.setShader(null);
        p.setColor(Color.argb(22,0,170,255)); c.drawCircle(86,y(260),170,p);
        p.setColor(Color.argb(14,0,100,255)); c.drawCircle(800,y(980),260,p);
    }

    private void drawHeader(Canvas c) {
        drawWaveLogo(c, 60, 52, CYAN, .82f);
        text(c, page == 0 ? "OKN_DSP" : "DSP Control", 116, 51, 39, WHITE, true, Paint.Align.LEFT);
        text(c, "Professional Audio Processor", 116, 82, 20, Color.rgb(88,190,255), false, Paint.Align.LEFT);

        float x = 505, yy = 20, w = 270, h = 66;
        roundPanel(c,x,yy,w,h,15,Color.rgb(11,31,49),Color.rgb(30,58,84));
        roundPanel(c,x+14,yy+13,48,42,11,Color.rgb(0,105,176),Color.rgb(0,158,245));
        text(c,"ᛒ",x+38,yy+43,28,WHITE,true,Paint.Align.CENTER);
        text(c,bleConnected?"เชื่อมต่ออุปกรณ์":bleStatus,x+73,yy+31,17,WHITE,true,Paint.Align.LEFT);
        text(c,bleDevice,x+73,yy+53,12,SUB,false,Paint.Align.LEFT);
        p.setColor(bleConnected?GREEN:Color.rgb(255,185,48)); p.setShadowLayer(11,0,0,p.getColor()); c.drawCircle(x+w-22,yy+33,7,p); p.clearShadowLayer();
        drawGear(c, 824, 53, WHITE);
    }

    private void drawChannelTabs(Canvas c) {
        float top=y(104), bot=y(181), gap=7f, left=18f, avail=W-36f, cell=(avail-gap*6f)/7f;
        for(int i=0;i<7;i++){
            float x=left+i*(cell+gap); boolean sel=i==s.channel;
            roundPanel(c,x,top,cell,bot-top,10,sel?Color.rgb(0,110,222):Color.rgb(2,25,46),sel?CYAN:BORDER);
            if(sel) glow(c,x,top,cell,bot-top,10,CYAN);
            String[] a=DspState.CHANNEL_TAB[i].split("\\n"); text(c,a[0],x+cell/2,top+31,17,WHITE,true,Paint.Align.CENTER); text(c,a[1],x+cell/2,top+57,13,sel?WHITE:SUB,false,Paint.Align.CENTER);
        }
    }

    private void drawHome(Canvas c) {
        String[] title={"Master Volume","Bass Volume","Bass Cutoff","Bass Boost","Middle Boost","Treble Boost"};
        String[] sub={"ปรับระดับเสียงรวม","ปรับระดับเสียงเบส","ตั้งค่าความถี่ตัดเบส","เพิ่มความหนักแน่นของเบส","เพิ่มความชัดเจนย่านกลาง","เพิ่มความใสย่านแหลม"};
        int[] ac={BLUE,CYAN,MAGENTA,RED,BLUE,MAGENTA};
        float[] top={125,274,423,572,721,870};
        for(int i=0;i<6;i++){
            float t=y(top[i]), b=y(top[i]+135); roundPanel(c,16,t,832,b-t,22,PANEL,BORDER);
            drawHomeIcon(c,83,(t+b)/2,ac[i],i); text(c,title[i],167,t+57,28,WHITE,true,Paint.Align.LEFT); text(c,sub[i],167,t+91,17,SUB,false,Paint.Align.LEFT);
            float cy=(t+b)/2; drawHomeSlider(c,i,381,cy,667,ac[i]);
            roundPanel(c,698,t+28,126,b-t-56,12,PANEL2,Color.rgb(34,92,145)); text(c,homeValue(i),761,t+77,26,WHITE,true,Paint.Align.CENTER);
        }

        float t=y(1024), mid=y(1184), b=y(1376);
        roundPanel(c,16,t,411,mid-t-12,20,PANEL,BORDER); drawSquareIcon(c,40,t+20,76,76,CYAN,"♫");
        text(c,"Audio Source",140,t+49,23,WHITE,true,Paint.Align.LEFT); text(c,"แหล่งสัญญาณเสียง",140,t+80,16,SUB,false,Paint.Align.LEFT);
        dropdown(c,140,t+96,270,53,audioSourceText());
        roundPanel(c,16,mid,411,b-mid,20,PANEL,BORDER); drawSquareIcon(c,40,mid+20,76,76,BLUE,"☰");
        text(c,"System Preset",140,mid+49,23,WHITE,true,Paint.Align.LEFT); text(c,"พรีเซ็ตระบบ",140,mid+80,16,SUB,false,Paint.Align.LEFT);
        dropdown(c,140,mid+96,270,53,homePresetText());

        roundPanel(c,438,t,410,b-t,20,PANEL,BORDER); drawSquareIcon(c,462,t+20,76,76,BLUE,"▣");
        text(c,"Device Status",566,t+49,23,WHITE,true,Paint.Align.LEFT); text(c,"สถานะอุปกรณ์",566,t+80,16,SUB,false,Paint.Align.LEFT);
        statusRow(c,466,t+130,"●","Connected",bleConnected?"DSP-7900":"--",bleConnected?GREEN:SUB);
        statusRow(c,466,t+190,"▱","Voltage","-- V",CYAN);
        statusRow(c,466,t+250,"♨","Temperature","-- °C",CYAN);
        statusRow(c,466,t+310,"✓","System",bleConnected?"Normal":"Offline",bleConnected?GREEN:SUB);
    }

    private String homeValue(int i){
        if(i==0)return DspState.db(s.masterVolume); if(i==1)return DspState.db(s.bassVolume); if(i==2)return DspState.hz(s.bassCutoff);
        if(i==3)return DspState.db(s.bassBoost); if(i==4)return DspState.db(s.middleBoost); return DspState.db(s.trebleBoost);
    }
    private String audioSourceText(){ return new String[]{"High Level (Speaker)","Low Level (RCA)","Bluetooth"}[s.audioSource%3]; }
    private String homePresetText(){ return new String[]{"Flat","Pop","Rock","Jazz"}[s.homePreset%4]; }

    private void drawEq(Canvas c) {
        float mt=y(198), mb=y(634); roundPanel(c,16,mt,832,mb-mt,20,PANEL,BORDER);
        drawWaveLogo(c,72,mt+57,CYAN,.72f); text(c,"Parametric EQ",133,mt+61,31,WHITE,true,Paint.Align.LEFT); text(c,"ปรับแต่งความถี่เสียงอย่างละเอียด",133,mt+91,17,SUB,false,Paint.Align.LEFT);
        dropdown(c,485,mt+22,181,70,"CH"+(s.channel+1)+" - "+DspState.CHANNEL_NAME[s.channel]);
        outlineButton(c,679,mt+22,151,70,"↻  รีเซ็ต EQ",false);
        drawEqGraph(c,74,mt+116,754,mb-mt-145);

        float bt=y(650), bb=y(709); String[] banks={"Bands 1 - 6","Bands 7 - 12","Bands 13 - 15"};
        for(int i=0;i<3;i++){float x=18+i*216; float w=i==2?200:216; outlineButton(c,x,bt,w,bb-bt,banks[i],s.eqBank==i);}

        float tt=y(711), tb=y(1190); roundPanel(c,16,tt,832,tb-tt,18,PANEL,BORDER);
        text(c,"#",49,tt+42,16,SUB,true,Paint.Align.CENTER); text(c,"Type",158,tt+42,16,SUB,true,Paint.Align.CENTER); text(c,"Frequency",352,tt+42,16,SUB,true,Paint.Align.CENTER);
        text(c,"Gain",510,tt+42,16,SUB,true,Paint.Align.CENTER); text(c,"Q",655,tt+42,16,SUB,true,Paint.Align.CENTER); text(c,"Power",788,tt+42,16,SUB,true,Paint.Align.CENTER);
        float rowH=(tb-tt-58)/6f; int start=s.eqBank*6;
        for(int r=0;r<6;r++){
            int band=start+r; if(band>=DspState.BANDS) break; float rt=tt+58+r*rowH, cy=rt+rowH/2;
            if(r>0) divider(c,34,rt,830,rt);
            int bc=bandColors[band%bandColors.length]; p.setColor(bc); p.setShadowLayer(8,0,0,bc); c.drawCircle(47,cy,12,p); p.clearShadowLayer(); text(c,String.valueOf(band+1),76,cy+6,16,WHITE,false,Paint.Align.CENTER);
            miniCell(c,101,cy-24,176,48,eqTypeText(s.eqType[s.channel][band]),false);
            miniCell(c,290,cy-24,137,48,DspState.hz(s.freq[s.channel][band]),true);
            miniCell(c,441,cy-24,137,48,DspState.db(s.gain[s.channel][band]),true);
            miniCell(c,592,cy-24,137,48,DspState.q(s.q[s.channel][band]),true);
            drawToggle(c,758,cy-21,72,42,s.eqPower[s.channel][band],CYAN);
        }

        float pt=y(1202), pb=y(1364); roundPanel(c,16,pt,832,pb-pt,18,PANEL,BORDER);
        drawSquareIcon(c,42,pt+28,70,70,BLUE,"□"); text(c,"Preset",140,pt+55,21,WHITE,true,Paint.Align.LEFT); text(c,"ชุดค่าที่ใช้งานอยู่",140,pt+84,14,SUB,false,Paint.Align.LEFT);
        dropdown(c,140,pt+96,188,48,"Custom 1"); outlineButton(c,342,pt+30,132,92,"▣\nSave",false); outlineButton(c,485,pt+30,154,92,"□\nManage",false);
        text(c,"BETTER SOUND",744,pt+88,11,Color.rgb(100,194,255),false,Paint.Align.CENTER); text(c,"A BRIGHTER DRIVE",744,pt+111,11,Color.rgb(100,194,255),false,Paint.Align.CENTER);
    }

    private void drawEqGraph(Canvas c,float gx,float gy,float gw,float gh){
        p.setColor(Color.rgb(1,17,31)); c.drawRect(gx,gy,gx+gw,gy+gh,p); stroke.setStrokeWidth(1); stroke.setColor(Color.rgb(14,46,70));
        for(int i=0;i<=12;i++){float xx=gx+gw*i/12f;c.drawLine(xx,gy,xx,gy+gh,stroke);} for(int i=0;i<=6;i++){float yy=gy+gh*i/6f;c.drawLine(gx,yy,gx+gw,yy,stroke);}
        text(c,"dB",gx-23,gy+18,15,SUB,false,Paint.Align.CENTER); String[] db={"+12","+6","0","-6","-12"}; for(int i=0;i<5;i++) text(c,db[i],gx-15,gy+11+i*(gh-22)/4f,14,SUB,false,Paint.Align.RIGHT);
        float[] ticks={20,50,100,200,500,1000,2000,5000,10000,20000}; String[] tl={"20","50","100","200","500","1k","2k","5k","10k","20k"}; for(int i=0;i<ticks.length;i++) text(c,tl[i],freqX(ticks[i],gx,gw),gy+gh+24,13,SUB,false,Paint.Align.CENTER); text(c,"Hz",gx+gw+4,gy+gh+24,13,SUB,false,Paint.Align.LEFT);
        int start=s.eqBank*6, end=Math.min(DspState.BANDS,start+6); Path line=new Path(); boolean first=true;
        for(int b=start;b<end;b++){float xx=freqX(s.freq[s.channel][b],gx,gw), yy=gainY(s.gain[s.channel][b],gy,gh); if(first){line.moveTo(xx,yy);first=false;}else line.lineTo(xx,yy);} stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(4); stroke.setShader(new LinearGradient(gx,gy,gx+gw,gy,CYAN,MAGENTA,Shader.TileMode.CLAMP)); c.drawPath(line,stroke); stroke.setShader(null);
        for(int b=start;b<end;b++){float xx=freqX(s.freq[s.channel][b],gx,gw), yy=gainY(s.gain[s.channel][b],gy,gh); int bc=bandColors[b%bandColors.length]; p.setColor(bc);p.setShadowLayer(14,0,0,bc);c.drawCircle(xx,yy,10,p);p.clearShadowLayer();stroke.setColor(WHITE);stroke.setStrokeWidth(2);c.drawCircle(xx,yy,10,stroke);}
    }

    private String eqTypeText(int t){ if(t==DspProtocol.EQ_PEAKING_TYPE)return "PEQ"; if(t==DspProtocol.EQ_TONE_CONTROL_TYPE)return "Tone"; if(t==DspProtocol.EQ_GENERAL_LOWPASS_TYPE)return "Low Pass"; return "Type "+t; }

    private void drawCrossover(Canvas c){
        float mt=y(198), mb=y(666); roundPanel(c,16,mt,832,mb-mt,20,PANEL,BORDER); drawHomeIcon(c,88,mt+70,MAGENTA,2); text(c,"Crossover",165,mt+66,31,WHITE,true,Paint.Align.LEFT); text(c,"ตั้งค่าการแบ่งความถี่",165,mt+98,17,SUB,false,Paint.Align.LEFT); dropdown(c,493,mt+35,171,58,"Magnitude"); outlineButton(c,680,mt+35,150,58,"↻  Reset",false); drawCrossoverGraph(c,82,mt+172,746,mb-mt-205);
        drawFilterCard(c,y(681),y(914),true); drawFilterCard(c,y(929),y(1162),false);
        float t=y(1178), b=y(1372); roundPanel(c,18,t,828,b-t,18,PANEL,BORDER); drawSquareIcon(c,40,t+18,60,60,BLUE,"⚙"); text(c,"Advanced Settings",120,t+47,20,WHITE,true,Paint.Align.LEFT); text(c,"ตั้งค่าขั้นสูง",120,t+71,14,SUB,false,Paint.Align.LEFT);
        advancedCell(c,39,t+92,198,78,"Phase",s.crossoverPhase[s.channel]+"°"); advancedCell(c,251,t+92,190,78,"Polarity",s.polarityInvert[s.channel]?"Invert":"Normal");
        roundPanel(c,455,t+92,143,78,12,PANEL2,BORDER); text(c,"🔗  Link L/R",526,t+28+92,15,WHITE,false,Paint.Align.CENTER); drawToggle(c,487,t+126,78,40,s.linkLR[s.channel],CYAN);
        advancedCell(c,612,t+92,214,78,"Output Mode",s.outputMode[s.channel]==0?"Stereo":"Mono");
    }

    private void drawCrossoverGraph(Canvas c,float gx,float gy,float gw,float gh){
        p.setColor(Color.rgb(1,17,31));c.drawRect(gx,gy,gx+gw,gy+gh,p);stroke.setColor(Color.rgb(13,45,70));stroke.setStrokeWidth(1);for(int i=0;i<=12;i++){float xx=gx+gw*i/12f;c.drawLine(xx,gy,xx,gy+gh,stroke);}for(int i=0;i<=5;i++){float yy=gy+gh*i/5f;c.drawLine(gx,yy,gx+gw,yy,stroke);} float hpf=s.hpfFreq[s.channel],lpf=s.lpfFreq[s.channel];
        Path hp=new Path(); Path lp=new Path(); for(int i=0;i<=100;i++){float f=(float)Math.exp(Math.log(20)+i/100f*(Math.log(20000)-Math.log(20)));float xx=freqX(f,gx,gw);float hpy=gy+gh*(1f-(float)(1.0/(1.0+Math.pow(hpf/Math.max(20f,f),4))));float lpy=gy+gh*(1f-(float)(1.0/(1.0+Math.pow(Math.max(20f,f)/lpf,4))));if(i==0){hp.moveTo(xx,hpy);lp.moveTo(xx,lpy);}else{hp.lineTo(xx,hpy);lp.lineTo(xx,lpy);}}
        stroke.setStyle(Paint.Style.STROKE);stroke.setStrokeWidth(4);stroke.setColor(CYAN);stroke.setShadowLayer(10,0,0,CYAN);c.drawPath(hp,stroke);stroke.clearShadowLayer();stroke.setColor(MAGENTA);stroke.setShadowLayer(10,0,0,MAGENTA);c.drawPath(lp,stroke);stroke.clearShadowLayer();
        p.setColor(CYAN);c.drawCircle(freqX(hpf,gx,gw),gy+gh*.22f,9,p);p.setColor(MAGENTA);c.drawCircle(freqX(lpf,gx,gw),gy+gh*.22f,9,p);
        float[] ticks={20,50,100,200,500,1000,2000,5000,10000,20000};String[] tl={"20","50","100","200","500","1k","2k","5k","10k","20k"};for(int i=0;i<ticks.length;i++)text(c,tl[i],freqX(ticks[i],gx,gw),gy+gh+23,13,SUB,false,Paint.Align.CENTER);
    }

    private void drawFilterCard(Canvas c,float top,float bottom,boolean high){
        int ac=high?CYAN:MAGENTA; roundPanel(c,18,top,828,bottom-top,18,PANEL,BORDER); drawHomeIcon(c,88,top+60,ac,high?4:5); text(c,high?"High Pass Filter (HPF)":"Low Pass Filter (LPF)",165,top+52,25,WHITE,true,Paint.Align.LEFT); text(c,high?"กรองความถี่ต่ำออก":"กรองความถี่สูงออก",165,top+82,16,SUB,false,Paint.Align.LEFT); text(c,"Bypass",675,top+61,17,WHITE,false,Paint.Align.RIGHT); drawToggle(c,702,top+36,122,50,high?s.hpfBypass[s.channel]:s.lpfBypass[s.channel],ac);
        String type=filterType(high?s.hpfType[s.channel]:s.lpfType[s.channel]); String freq=DspState.hz(high?s.hpfFreq[s.channel]:s.lpfFreq[s.channel]); String slope=slopeText(high?s.hpfSlope[s.channel]:s.lpfSlope[s.channel]);
        labelCell(c,40,top+112,240,93,"Type",type); labelCell(c,292,top+112,268,93,"Frequency",freq); labelCell(c,573,top+112,253,93,"Slope",slope);
    }
    private String filterType(int i){return new String[]{"Linkwitz-Riley","Butterworth","Bessel"}[Math.floorMod(i,3)];}
    private String slopeText(int i){return new String[]{"6 dB/Oct","12 dB/Oct","24 dB/Oct","48 dB/Oct"}[Math.floorMod(i,4)];}

    private void drawDelay(Canvas c){
        float t=y(198), b=y(728); roundPanel(c,18,t,828,b-t,18,PANEL,BORDER); drawHomeIcon(c,84,t+63,Color.rgb(0,240,145),4); text(c,"Delay",154,t+53,30,WHITE,true,Paint.Align.LEFT); text(c,"ตั้งค่าหน่วงเวลาเพื่อการจัดตำแหน่งเสียง",154,t+84,16,SUB,false,Paint.Align.LEFT);
        outlineButton(c,486,t+23,82,58,"ms",s.delayUnit==0); outlineButton(c,568,t+23,82,58,"cm",s.delayUnit==1); outlineButton(c,664,t+23,168,58,"↻  ซิงค์ทุกช่อง",false);
        drawCar(c,70,t+128,420,b-t-156);
        roundPanel(c,496,t+103,334,124,14,PANEL2,BORDER); text(c,"♙",526,t+139,25,CYAN,true,Paint.Align.CENTER); text(c,"Seat Preset",566,t+136,20,WHITE,true,Paint.Align.LEFT); text(c,"ตำแหน่งการฟัง",566,t+163,14,SUB,false,Paint.Align.LEFT); dropdown(c,565,t+174,248,43,seatText());
        roundPanel(c,496,t+238,334,130,14,PANEL2,BORDER); text(c,"⌁",527,t+280,25,CYAN,true,Paint.Align.CENTER); text(c,"Distance Reference",566,t+274,19,WHITE,true,Paint.Align.LEFT); text(c,"อ้างอิงระยะทางเสียง",566,t+300,14,SUB,false,Paint.Align.LEFT); text(c,"Speed of Sound (20°C)",566,t+335,14,SUB,false,Paint.Align.LEFT); text(c,"343 m/s (34.3 cm/ms)",566,t+357,14,SUB,false,Paint.Align.LEFT);
        roundPanel(c,496,t+379,334,118,14,PANEL2,BORDER); text(c,"▥",527,t+417,25,CYAN,true,Paint.Align.CENTER); text(c,"Total Delay Range",566,t+411,19,WHITE,true,Paint.Align.LEFT); text(c,"ช่วงหน่วงเวลาทั้งหมด",566,t+438,14,SUB,false,Paint.Align.LEFT); text(c,"0.00 ms",566,t+474,17,WHITE,true,Paint.Align.LEFT); text(c,maxDelayText(),807,t+474,17,WHITE,true,Paint.Align.RIGHT);

        float rt=y(744), rb=y(1368), row=(rb-rt)/7f; for(int ch=0;ch<7;ch++){float a=rt+ch*row,cy=a+row/2;roundPanel(c,18,a+4,828,row-8,14,PANEL,BORDER);p.setColor(channelColors[ch]);p.setShadowLayer(8,0,0,channelColors[ch]);c.drawCircle(48,cy,13,p);p.clearShadowLayer();text(c,"CH"+(ch+1),83,cy-3,18,WHITE,true,Paint.Align.LEFT);text(c,DspState.CHANNEL_NAME[ch],83,cy+22,14,SUB,false,Paint.Align.LEFT);drawDelaySlider(c,198,cy,646,s.delayMs[ch],channelColors[ch]);roundPanel(c,680,cy-30,140,60,10,PANEL2,BORDER);text(c,s.delayUnit==0?DspState.delay(s.delayMs[ch]):DspState.distance(s.delayMs[ch]),750,cy-3,17,WHITE,true,Paint.Align.CENTER);text(c,s.delayUnit==0?DspState.distance(s.delayMs[ch]):DspState.delay(s.delayMs[ch]),750,cy+20,13,SUB,false,Paint.Align.CENTER);}
    }
    private String seatText(){return new String[]{"Driver (Left)","Passenger (Right)","Front Center","Rear Center"}[s.seatPreset%4];}
    private String maxDelayText(){float m=0;for(float v:s.delayMs)m=Math.max(m,v);return String.format(Locale.US,"%.2f ms",m);}

    private void drawOutput(Canvas c){
        float t=y(198), b=y(553); roundPanel(c,18,t,828,b-t,18,PANEL,BORDER); drawHomeIcon(c,88,t+62,ORANGE,0); text(c,"Output",173,t+55,31,WHITE,true,Paint.Align.LEFT); text(c,"ปรับระดับเอาต์พุตแต่ละช่อง",173,t+88,17,SUB,false,Paint.Align.LEFT); outlineButton(c,478,t+35,168,58,"🔇  All Mute Off",false); outlineButton(c,658,t+35,172,58,"↻  Reset Levels",false);
        roundPanel(c,39,t+138,525,b-t-160,13,PANEL2,BORDER); text(c,"Output Level Overview",53,t+171,16,WHITE,true,Paint.Align.LEFT); drawMeters(c,66,t+205,475,b-t-245);
        roundPanel(c,579,t+138,247,b-t-160,13,PANEL2,BORDER); text(c,"Master Output",597,t+183,18,WHITE,true,Paint.Align.LEFT); roundPanel(c,724,t+157,91,50,10,PANEL2,BORDER);text(c,DspState.db(s.masterOutput),769,t+190,18,WHITE,true,Paint.Align.CENTER); drawHorizontalSlider(c,603,t+248,800,s.masterOutput,-60,12,CYAN); labels(c,603,t+291,800,new String[]{"-60","-40","-20","0","+12"});
        float rt=y(568), rb=y(1368), row=(rb-rt)/7f;for(int ch=0;ch<7;ch++){float a=rt+ch*row,cy=a+row/2;roundPanel(c,18,a+4,828,row-8,14,PANEL,BORDER);p.setColor(channelColors[ch]);p.setShadowLayer(7,0,0,channelColors[ch]);c.drawCircle(62,cy,25,p);p.clearShadowLayer();text(c,String.valueOf(ch+1),62,cy+7,18,WHITE,true,Paint.Align.CENTER);text(c,"CH"+(ch+1),108,cy-9,18,WHITE,true,Paint.Align.LEFT);text(c,DspState.CHANNEL_NAME[ch],108,cy+20,14,SUB,false,Paint.Align.LEFT);drawHorizontalSlider(c,196,cy,424,s.outputGain[ch],-60,12,channelColors[ch]);roundPanel(c,438,cy-27,95,54,9,PANEL2,BORDER);text(c,DspState.db(s.outputGain[ch]),485,cy+6,16,WHITE,true,Paint.Align.CENTER);smallAction(c,546,cy-34,61,68,"◖","Mute",s.mute[ch]);smallAction(c,615,cy-34,61,68,"♩","Solo",s.solo[ch]);smallAction(c,684,cy-34,61,68,"Ø","Phase",s.phase180[ch]);if(ch<2)smallAction(c,753,cy-34,73,68,"↗","Link",s.outputLink[ch]);}
    }

    private void drawMeters(Canvas c,float x,float yy,float w,float h){float cell=w/7f;for(int ch=0;ch<7;ch++){float cx=x+cell*(ch+.5f);for(int k=0;k<9;k++){float bh=8,by=yy+h-30-k*11;p.setColor(k<5?channelColors[ch]:Color.rgb(10,49,72));c.drawRoundRect(new RectF(cx-10,by,cx+10,by+bh),3,3,p);}text(c,"CH"+(ch+1),cx,yy+h-4,13,WHITE,true,Paint.Align.CENTER);}}

    private void drawBottomNav(Canvas c){
        float top=navTop();roundPanel(c,16,top+7,832,NAV_H-14,18,Color.rgb(2,17,32),BORDER);String[] lab={"Home","EQ","Crossover","Delay","Output"};
        for(int i=0;i<5;i++){float cell=832/5f,x=16+i*cell, cx=x+cell/2;boolean sel=i==page;if(sel){roundPanel(c,x+4,top+11,cell-8,NAV_H-22,14,Color.rgb(0,78,193),Color.rgb(0,133,255));glow(c,x+4,top+11,cell-8,NAV_H-22,14,CYAN);}int col=sel?CYAN:Color.rgb(181,208,245);float iy=top+46;if(i==0)drawHomeNav(c,cx,iy,col);else if(i==1)drawEqNav(c,cx,iy,col);else if(i==2)drawCrossNav(c,cx,iy,col);else if(i==3)drawClock(c,cx,iy,col);else drawBars(c,cx,iy,col);text(c,lab[i],cx,top+93,17,col,false,Paint.Align.CENTER);}
    }

    @Override public boolean onTouchEvent(MotionEvent e){
        if(scale<=0)return true;float x=(e.getX()-offsetX)/scale, yy=(e.getY()-offsetY)/scale;if(x<0||x>W||yy<0||yy>viewportH)return true;int a=e.getActionMasked();
        if(a==MotionEvent.ACTION_DOWN){
            if(yy<100&&x>780){if(ble!=null)ble.startScan();return true;}
            if(yy>=navTop()){page=Math.max(0,Math.min(4,(int)((x-16)/(832/5f))));invalidate();return true;}
            if(page>0 && yy>=y(104)&&yy<=y(181)){int ch=(int)((x-18)/((W-36+7)/7f));if(ch>=0&&ch<7){s.channel=ch;invalidate();}return true;}
            if(page==0)return homeDown(x,yy);if(page==1)return eqDown(x,yy);if(page==2)return crossDown(x,yy);if(page==3)return delayDown(x,yy);return outputDown(x,yy);
        }
        if(a==MotionEvent.ACTION_MOVE){if(dragHome>=0){updateHome(dragHome,x);invalidate();return true;}if(dragDelay>=0){updateDelay(dragDelay,x);invalidate();return true;}if(dragOutput>=0){updateOutput(dragOutput,x);invalidate();return true;}if(dragMasterOutput){s.masterOutput=round1(-60+clamp((x-603)/(800-603),0,1)*72);unverified("Master Output");invalidate();return true;}if(dragEqGraph){updateEqGraph(x,yy);invalidate();return true;}}
        if(a==MotionEvent.ACTION_UP||a==MotionEvent.ACTION_CANCEL){int h=dragHome;dragHome=dragDelay=dragOutput=-1;dragMasterOutput=dragEqGraph=false;if(h==5&&ble!=null)ble.setScalarRealtime(DspProtocol.ID_TREBLE_BOOST,s.trebleBoost);performClick();return true;}return true;
    }
    @Override public boolean performClick(){super.performClick();return true;}

    private boolean homeDown(float x,float yy){
        float[] top={125,274,423,572,721,870};for(int i=0;i<6;i++){float cy=(y(top[i])+y(top[i]+135))/2;if(x>=350&&x<=684&&Math.abs(yy-cy)<40){dragHome=i;updateHome(i,x);invalidate();return true;}}
        float t=y(1024),mid=y(1184);if(x>=140&&x<=410&&yy>=t+90&&yy<=t+158){s.audioSource=(s.audioSource+1)%3;unverified("Audio Source");invalidate();return true;}if(x>=140&&x<=410&&yy>=mid+90&&yy<=mid+158){s.homePreset=(s.homePreset+1)%4;s.applyHomePreset(s.homePreset);sendAllHomeTonal();invalidate();return true;}return true;
    }
    private void updateHome(int i,float x){float f=clamp((x-381)/(667-381),0,1);if(i==0)s.masterVolume=round1(-60+f*72);else if(i==1)s.bassVolume=round1(-12+f*24);else if(i==2)s.bassCutoff=Math.round((float)Math.exp(Math.log(20)+f*(Math.log(500)-Math.log(20))));else if(i==3)s.bassBoost=round1(-10+f*22);else if(i==4)s.middleBoost=round1(-12+f*24);else s.trebleBoost=round1(-12+f*24);if(i!=5)sendHome(i);}
    private void sendHome(int i){if(ble==null)return;if(i==0)ble.setScalarRealtime(DspProtocol.ID_MASTER_VOLUME,s.masterVolume);else if(i==1)ble.setScalarRealtime(DspProtocol.ID_BASS_VOLUME,s.bassVolume);else if(i==2)ble.setScalarRealtime(DspProtocol.ID_BASS_CUTOFF,s.bassCutoff);else if(i==3)ble.setScalarRealtime(DspProtocol.ID_BASS_BOOST,s.bassBoost);else if(i==4)ble.setScalarRealtime(DspProtocol.ID_MIDDLE_BOOST,s.middleBoost);else ble.setScalarRealtime(DspProtocol.ID_TREBLE_BOOST,s.trebleBoost);}
    private void sendAllHomeTonal(){for(int i=1;i<6;i++)sendHome(i);}

    private boolean eqDown(float x,float yy){
        float mt=y(198);if(x>=679&&x<=830&&yy>=mt+22&&yy<=mt+92){for(int b=0;b<15;b++){s.gain[s.channel][b]=0;sendEq(b);}invalidate();return true;}if(x>=485&&x<=666&&yy>=mt+22&&yy<=mt+92){s.channel=(s.channel+1)%7;invalidate();return true;}
        float bt=y(650),bb=y(709);if(yy>=bt&&yy<=bb){if(x<234)s.eqBank=0;else if(x<450)s.eqBank=1;else s.eqBank=2;invalidate();return true;}
        float tt=y(711),tb=y(1190);if(yy>=tt+58&&yy<=tb){float rowH=(tb-tt-58)/6f;int r=(int)((yy-(tt+58))/rowH);int b=s.eqBank*6+r;if(b>=0&&b<15){s.selectedBand=b;float cy=tt+58+r*rowH+rowH/2;if(x>=101&&x<=277){cycleEqTypeLocal(b);unverified("EQ Type");}else if(x>=290&&x<=427){adjustEqFreq(b,x<358?-1:1);sendEq(b);}else if(x>=441&&x<=578){adjustEqGain(b,x<509?-1:1);sendEq(b);}else if(x>=592&&x<=729){adjustEqQ(b,x<660?-1:1);sendEq(b);}else if(x>=748&&x<=838){s.eqPower[s.channel][b]=!s.eqPower[s.channel][b];unverified("EQ Power");}invalidate();return true;}}
        float gy=mt+116,gh=y(634)-mt-145;if(x>=74&&x<=828&&yy>=gy&&yy<=gy+gh){int b=nearestVisibleBand(x,yy,74,gy,754,gh);if(b>=0){s.selectedBand=b;dragEqGraph=true;updateEqGraph(x,yy);invalidate();}return true;}
        float pt=y(1202);if(yy>=pt+22&&yy<=pt+140){if(x>=342&&x<=474){s.saveEq(getContext());toast("บันทึก Preset EQ แล้ว");}else if(x>=485&&x<=639){boolean ok=s.loadEq(getContext());if(ok)for(int b=0;b<15;b++)sendEq(b);toast(ok?"โหลด Preset EQ แล้ว":"ยังไม่มี Preset EQ");}return true;}return true;
    }
    private void cycleEqTypeLocal(int b){int t=s.eqType[s.channel][b];if(t==12)s.eqType[s.channel][b]=17;else if(t==17)s.eqType[s.channel][b]=3;else s.eqType[s.channel][b]=12;}
    private void adjustEqFreq(int b,int d){float f=s.freq[s.channel][b];f*=d>0?1.08f:1/1.08f;s.freq[s.channel][b]=Math.round(clamp(f,20,20000));}
    private void adjustEqGain(int b,int d){s.gain[s.channel][b]=round1(clamp(s.gain[s.channel][b]+d*.5f,-12,12));}
    private void adjustEqQ(int b,int d){s.q[s.channel][b]=round2(clamp(s.q[s.channel][b]+d*.05f,.05f,20));}
    private void sendEq(int b){if(ble!=null&&s.eqWritable[s.channel][b]&&s.eqPower[s.channel][b])ble.setEqRealtime(s.channel,b,s.freq[s.channel][b],s.gain[s.channel][b],s.q[s.channel][b]);}
    private int nearestVisibleBand(float x,float yy,float gx,float gy,float gw,float gh){int st=s.eqBank*6,en=Math.min(15,st+6),best=-1;float bd=Float.MAX_VALUE;for(int b=st;b<en;b++){float px=freqX(s.freq[s.channel][b],gx,gw),py=gainY(s.gain[s.channel][b],gy,gh),dx=px-x,dy=py-yy,d=dx*dx+dy*dy;if(d<bd){bd=d;best=b;}}return bd<70*70?best:-1;}
    private void updateEqGraph(float x,float yy){int b=s.selectedBand;if(b<0||b>=15)return;float mt=y(198),gy=mt+116,gh=y(634)-mt-145;s.gain[s.channel][b]=round1(12-clamp((yy-gy)/gh,0,1)*24);if(s.eqType[s.channel][b]==12){double frac=clamp((x-74)/754,0,1);s.freq[s.channel][b]=Math.round((float)Math.exp(Math.log(20)+frac*(Math.log(20000)-Math.log(20))));}sendEq(b);}

    private boolean crossDown(float x,float yy){float h=y(681),l=y(929),a=y(1178);if(yy>=h&&yy<=y(914))return filterDown(x,yy,h,true);if(yy>=l&&yy<=y(1162))return filterDown(x,yy,l,false);if(yy>=a&&yy<=y(1372)){if(x<237){s.crossoverPhase[s.channel]=(s.crossoverPhase[s.channel]+15)%360;}else if(x<441){s.polarityInvert[s.channel]=!s.polarityInvert[s.channel];}else if(x<598){s.linkLR[s.channel]=!s.linkLR[s.channel];}else{s.outputMode[s.channel]=(s.outputMode[s.channel]+1)%2;}unverified("Crossover Advanced");invalidate();}return true;}
    private boolean filterDown(float x,float yy,float top,boolean high){if(x>=680&&yy<=top+100){if(high)s.hpfBypass[s.channel]=!s.hpfBypass[s.channel];else s.lpfBypass[s.channel]=!s.lpfBypass[s.channel];}else if(yy>=top+105){if(x<285){if(high)s.hpfType[s.channel]=(s.hpfType[s.channel]+1)%3;else s.lpfType[s.channel]=(s.lpfType[s.channel]+1)%3;}else if(x<568){float f=high?s.hpfFreq[s.channel]:s.lpfFreq[s.channel];f*=x<430?.8f:1.25f;f=clamp(f,20,20000);if(high)s.hpfFreq[s.channel]=f;else s.lpfFreq[s.channel]=f;}else{if(high)s.hpfSlope[s.channel]=(s.hpfSlope[s.channel]+1)%4;else s.lpfSlope[s.channel]=(s.lpfSlope[s.channel]+1)%4;}}unverified(high?"HPF":"LPF");invalidate();return true;}

    private boolean delayDown(float x,float yy){float t=y(198);if(yy>=t+18&&yy<=t+92){if(x>=486&&x<568)s.delayUnit=0;else if(x>=568&&x<650)s.delayUnit=1;else if(x>=664){float min=s.delayMs[0];for(float v:s.delayMs)min=Math.min(min,v);for(int i=0;i<7;i++)s.delayMs[i]=round2(s.delayMs[i]-min);unverified("Delay Sync");}invalidate();return true;}if(x>=565&&x<=813&&yy>=t+160&&yy<=t+230){s.seatPreset=(s.seatPreset+1)%4;invalidate();return true;}float rt=y(744),rb=y(1368),row=(rb-rt)/7f;if(yy>=rt&&yy<=rb){int ch=Math.min(6,(int)((yy-rt)/row));if(x>=188&&x<=660){dragDelay=ch;updateDelay(ch,x);invalidate();}}return true;}
    private void updateDelay(int ch,float x){s.delayMs[ch]=round2(clamp((x-198)/(646-198),0,1)*10);unverified("Delay CH"+(ch+1));}

    private boolean outputDown(float x,float yy){float t=y(198);if(yy>=t+20&&yy<=t+110){if(x>=478&&x<646){for(int i=0;i<7;i++)s.mute[i]=false;unverified("All Mute Off");}else if(x>=658){float[] d={-3f,-2.5f,-4f,-1f,-2f,-3.5f,-4.5f};System.arraycopy(d,0,s.outputGain,0,7);unverified("Reset Levels");}invalidate();return true;}if(yy>=t+225&&yy<=t+300&&x>=585&&x<=812){dragMasterOutput=true;s.masterOutput=round1(-60+clamp((x-603)/(800-603),0,1)*72);unverified("Master Output");invalidate();return true;}float rt=y(568),rb=y(1368),row=(rb-rt)/7f;if(yy>=rt&&yy<=rb){int ch=Math.min(6,(int)((yy-rt)/row));float cy=rt+ch*row+row/2;if(x>=185&&x<=435){dragOutput=ch;updateOutput(ch,x);}else if(x>=540&&x<611)s.mute[ch]=!s.mute[ch];else if(x>=611&&x<680)s.solo[ch]=!s.solo[ch];else if(x>=680&&x<749)s.phase180[ch]=!s.phase180[ch];else if(x>=749&&ch<2)s.outputLink[ch]=!s.outputLink[ch];unverified("Output CH"+(ch+1));invalidate();}return true;}
    private void updateOutput(int ch,float x){s.outputGain[ch]=round1(-60+clamp((x-196)/(424-196),0,1)*72);unverified("Output Level");}

    private void unverified(String name){if(ble!=null)ble.reportUnverifiedControl(name);}

    private void drawHomeSlider(Canvas c,int i,float x0,float cy,float x1,int ac){float min,max,v;if(i==0){min=-60;max=12;v=s.masterVolume;}else if(i==1){min=-12;max=12;v=s.bassVolume;}else if(i==2){min=20;max=500;v=s.bassCutoff;}else if(i==3){min=-10;max=12;v=s.bassBoost;}else if(i==4){min=-12;max=12;v=s.middleBoost;}else{min=-12;max=12;v=s.trebleBoost;}float f=i==2?(float)((Math.log(v)-Math.log(min))/(Math.log(max)-Math.log(min))):clamp((v-min)/(max-min),0,1);drawHorizontalSlider(c,x0,cy,x1,min+f*(max-min),min,max,ac);String[] l=i==0?new String[]{"-60","-40","-20","0","+12"}:i==2?new String[]{"20","50","100","200","500"}:new String[]{"-12","-6","0","+6","+12"};labels(c,x0,cy+43,x1,l);}
    private void drawHorizontalSlider(Canvas c,float x0,float cy,float x1,float value,float min,float max,int ac){float f=clamp((value-min)/(max-min),0,1),kx=x0+f*(x1-x0);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeWidth(13);p.setColor(Color.rgb(37,74,112));c.drawLine(x0,cy,x1,cy,p);p.setShader(new LinearGradient(x0,cy,kx,cy,BLUE,ac,Shader.TileMode.CLAMP));p.setShadowLayer(9,0,0,ac);c.drawLine(x0,cy,kx,cy,p);p.clearShadowLayer();p.setShader(null);p.setColor(WHITE);c.drawCircle(kx,cy,18,p);p.setStrokeCap(Paint.Cap.BUTT);}
    private void drawDelaySlider(Canvas c,float x0,float cy,float x1,float ms,int ac){drawHorizontalSlider(c,x0,cy,x1,ms,0,10,ac);labels(c,x0,cy+36,x1,new String[]{"0","2","4","6","8","10"});}
    private void labels(Canvas c,float x0,float yy,float x1,String[] l){for(int i=0;i<l.length;i++)text(c,l[i],x0+i*(x1-x0)/(l.length-1f),yy,12,SUB,false,Paint.Align.CENTER);}

    private void statusRow(Canvas c,float x,float yy,String icon,String label,String val,int col){divider(c,x,yy-24,824,yy-24);text(c,icon,x+12,yy+7,21,col,true,Paint.Align.CENTER);text(c,label,x+50,yy+7,16,WHITE,false,Paint.Align.LEFT);text(c,val,815,yy+7,16,col,false,Paint.Align.RIGHT);}
    private void dropdown(Canvas c,float x,float yy,float w,float h,String value){roundPanel(c,x,yy,w,h,10,PANEL2,Color.rgb(35,89,139));text(c,value,x+14,yy+h/2+7,16,WHITE,false,Paint.Align.LEFT);text(c,"⌄",x+w-22,yy+h/2+8,22,SUB,true,Paint.Align.CENTER);}
    private void miniCell(Canvas c,float x,float yy,float w,float h,String value,boolean arrows){roundPanel(c,x,yy,w,h,9,PANEL2,Color.rgb(28,83,132));if(arrows){text(c,"‹",x+13,yy+h/2+7,23,SUB,false,Paint.Align.CENTER);text(c,"›",x+w-13,yy+h/2+7,23,SUB,false,Paint.Align.CENTER);}text(c,value,x+w/2,yy+h/2+6,14,WHITE,false,Paint.Align.CENTER);}
    private void labelCell(Canvas c,float x,float yy,float w,float h,String label,String value){roundPanel(c,x,yy,w,h,11,PANEL2,BORDER);text(c,label,x+14,yy+26,15,WHITE,false,Paint.Align.LEFT);dropdown(c,x+10,yy+38,w-20,45,value);}
    private void advancedCell(Canvas c,float x,float yy,float w,float h,String label,String value){roundPanel(c,x,yy,w,h,11,PANEL2,BORDER);text(c,label,x+14,yy+25,14,WHITE,false,Paint.Align.LEFT);text(c,"‹",x+18,yy+59,22,SUB,false,Paint.Align.CENTER);text(c,value,x+w/2,yy+59,16,WHITE,false,Paint.Align.CENTER);text(c,"›",x+w-18,yy+59,22,SUB,false,Paint.Align.CENTER);}
    private void smallAction(Canvas c,float x,float yy,float w,float h,String icon,String label,boolean on){roundPanel(c,x,yy,w,h,10,on?Color.rgb(0,78,130):PANEL2,on?CYAN:BORDER);text(c,icon,x+w/2,yy+29,20,on?CYAN:WHITE,true,Paint.Align.CENTER);text(c,label,x+w/2,yy+52,12,on?CYAN:SUB,false,Paint.Align.CENTER);}
    private void drawToggle(Canvas c,float x,float yy,float w,float h,boolean on,int ac){roundPanel(c,x,yy,w,h,h/2,on?Color.rgb(0,118,206):Color.rgb(35,61,91),on?ac:Color.rgb(49,81,116));float r=h*.39f,kx=on?x+w-h/2:x+h/2;p.setColor(WHITE);p.setShadowLayer(on?8:0,0,0,on?ac:WHITE);c.drawCircle(kx,yy+h/2,r,p);p.clearShadowLayer();}
    private void outlineButton(Canvas c,float x,float yy,float w,float h,String label,boolean selected){roundPanel(c,x,yy,w,h,11,selected?Color.rgb(0,95,214):PANEL2,selected?CYAN:BORDER);if(selected)glow(c,x,yy,w,h,11,CYAN);String[] a=label.split("\\n");if(a.length==1)text(c,a[0],x+w/2,yy+h/2+7,16,WHITE,false,Paint.Align.CENTER);else{text(c,a[0],x+w/2,yy+35,23,WHITE,true,Paint.Align.CENTER);text(c,a[1],x+w/2,yy+67,15,SUB,false,Paint.Align.CENTER);}}
    private void drawSquareIcon(Canvas c,float x,float yy,float w,float h,int ac,String glyph){roundPanel(c,x,yy,w,h,14,Color.rgb(2,49,88),Color.rgb(0,100,173));glow(c,x,yy,w,h,14,ac);text(c,glyph,x+w/2,yy+h/2+11,34,ac,true,Paint.Align.CENTER);}

    private void drawHomeIcon(Canvas c,float cx,float cy,int ac,int type){p.setColor(Color.argb(24,Color.red(ac),Color.green(ac),Color.blue(ac)));p.setShadowLayer(18,0,0,ac);c.drawCircle(cx,cy,50,p);p.clearShadowLayer();stroke.setStyle(Paint.Style.STROKE);stroke.setStrokeWidth(3);stroke.setColor(ac);c.drawCircle(cx,cy,50,stroke);if(type==0)drawSpeaker(c,cx-4,cy,ac);else if(type==1){stroke.setStrokeWidth(5);c.drawCircle(cx,cy,20,stroke);c.drawCircle(cx,cy,8,stroke);}else if(type==2){stroke.setStrokeWidth(4);c.drawLine(cx-26,cy-20,cx+25,cy-20,stroke);c.drawLine(cx-10,cy-20,cx-10,cy+25,stroke);c.drawLine(cx-10,cy-20,cx+19,cy+2,stroke);}else if(type==3){p.setColor(ac);for(int i=0;i<6;i++)c.drawRoundRect(new RectF(cx-25+i*9,cy+23-i*8,cx-19+i*9,cy+28),3,3,p);}else if(type==4){drawClock(c,cx,cy,ac);}else{Path q=new Path();q.moveTo(cx-28,cy-17);q.cubicTo(cx-5,cy-24,cx-6,cy+8,cx+25,cy+18);stroke.setStrokeWidth(4);c.drawPath(q,stroke);}}
    private void drawWaveLogo(Canvas c,float cx,float cy,int ac,float sc){p.setColor(ac);p.setShadowLayer(14,0,0,ac);float[] h={24,50,75,100,74,50,25};for(int i=0;i<7;i++){float xx=cx+(i-3)*13*sc;c.drawRoundRect(new RectF(xx-4*sc,cy-h[i]*sc/2,xx+4*sc,cy+h[i]*sc/2),5,5,p);}p.clearShadowLayer();}
    private void drawSpeaker(Canvas c,float cx,float cy,int ac){p.setColor(ac);Path a=new Path();a.moveTo(cx-24,cy-8);a.lineTo(cx-10,cy-8);a.lineTo(cx+6,cy-22);a.lineTo(cx+6,cy+22);a.lineTo(cx-10,cy+8);a.lineTo(cx-24,cy+8);a.close();c.drawPath(a,p);stroke.setColor(ac);stroke.setStrokeWidth(3);c.drawArc(new RectF(cx,cy-17,cx+31,cy+17),-55,110,false,stroke);c.drawArc(new RectF(cx-1,cy-26,cx+45,cy+26),-52,104,false,stroke);}
    private void drawGear(Canvas c,float cx,float cy,int ac){stroke.setStyle(Paint.Style.STROKE);stroke.setStrokeWidth(4);stroke.setColor(ac);c.drawCircle(cx,cy,19,stroke);c.drawCircle(cx,cy,7,stroke);for(int i=0;i<8;i++){double a=i*Math.PI/4;float x1=cx+(float)Math.cos(a)*21,y1=cy+(float)Math.sin(a)*21,x2=cx+(float)Math.cos(a)*27,y2=cy+(float)Math.sin(a)*27;c.drawLine(x1,y1,x2,y2,stroke);}}
    private void drawHomeNav(Canvas c,float cx,float cy,int ac){stroke.setColor(ac);stroke.setStrokeWidth(4);Path h=new Path();h.moveTo(cx-20,cy);h.lineTo(cx,cy-18);h.lineTo(cx+20,cy);h.lineTo(cx+16,cy);h.lineTo(cx+16,cy+20);h.lineTo(cx+4,cy+20);h.lineTo(cx+4,cy+6);h.lineTo(cx-4,cy+6);h.lineTo(cx-4,cy+20);h.lineTo(cx-16,cy+20);h.lineTo(cx-16,cy);c.drawPath(h,stroke);}
    private void drawEqNav(Canvas c,float cx,float cy,int ac){stroke.setColor(ac);stroke.setStrokeWidth(2.5f);Path q=new Path();q.moveTo(cx-23,cy+8);q.lineTo(cx-15,cy-4);q.lineTo(cx-8,cy+12);q.lineTo(cx,cy-13);q.lineTo(cx+8,cy+10);q.lineTo(cx+15,cy-5);q.lineTo(cx+23,cy+5);c.drawPath(q,stroke);}
    private void drawCrossNav(Canvas c,float cx,float cy,int ac){stroke.setColor(ac);stroke.setStrokeWidth(3);c.drawLine(cx-23,cy-14,cx-7,cy-14,stroke);c.drawLine(cx+23,cy-14,cx+7,cy-14,stroke);Path a=new Path();a.moveTo(cx-7,cy-14);a.cubicTo(cx-2,cy-14,cx-1,cy+17,cx-24,cy+18);c.drawPath(a,stroke);Path b=new Path();b.moveTo(cx+7,cy-14);b.cubicTo(cx+2,cy-14,cx+1,cy+17,cx+24,cy+18);c.drawPath(b,stroke);}
    private void drawClock(Canvas c,float cx,float cy,int ac){stroke.setColor(ac);stroke.setStrokeWidth(3);c.drawCircle(cx,cy,22,stroke);c.drawLine(cx,cy,cx,cy-13,stroke);c.drawLine(cx,cy,cx+10,cy+7,stroke);}
    private void drawBars(Canvas c,float cx,float cy,int ac){p.setColor(ac);float[] h={18,30,42,55};for(int i=0;i<4;i++)c.drawRoundRect(new RectF(cx-22+i*12,cy+h[i]/2*-1,cx-16+i*12,cy+h[i]/2),3,3,p);}
    private void drawCar(Canvas c,float x,float yy,float w,float h){float cx=x+w/2,top=yy+12,bottom=yy+h-12;stroke.setColor(Color.rgb(0,133,255));stroke.setStrokeWidth(3);stroke.setShadowLayer(12,0,0,BLUE);Path car=new Path();car.moveTo(cx,top);car.cubicTo(x+48,top+40,x+28,top+h*.35f,x+40,bottom-50);car.cubicTo(x+70,bottom,cx-65,bottom,cx,bottom);car.cubicTo(cx+65,bottom,x+w-70,bottom,x+w-40,bottom-50);car.cubicTo(x+w-28,top+h*.35f,x+w-48,top+40,cx,top);c.drawPath(car,stroke);stroke.clearShadowLayer();for(int r=0;r<2;r++)for(int k=0;k<2;k++){float sx=cx+(k==0?-68:68),sy=yy+130+r*115;roundPanel(c,sx-45,sy-35,90,72,16,Color.rgb(1,37,69),Color.rgb(0,86,151));}float[] px={x+55,x+w-55,x+50,x+w-50,cx,cx,x+w-52};float[] py={yy+105,yy+105,yy+h*.66f,yy+h*.66f,yy+45,yy+h*.84f,yy+h*.56f};for(int i=0;i<7;i++){p.setColor(channelColors[i]);p.setShadowLayer(11,0,0,channelColors[i]);c.drawCircle(px[i],py[i],12,p);p.clearShadowLayer();stroke.setColor(WHITE);stroke.setStrokeWidth(2);c.drawCircle(px[i],py[i],12,stroke);text(c,String.format(Locale.US,"%.2f ms",s.delayMs[i]),px[i]+(i%2==0?-18:18),py[i]-24,13,WHITE,true,i%2==0?Paint.Align.RIGHT:Paint.Align.LEFT);}}

    private void roundPanel(Canvas c,float x,float yy,float w,float h,float r,int fill,int border){p.setShader(null);p.setStyle(Paint.Style.FILL);p.setColor(fill);c.drawRoundRect(new RectF(x,yy,x+w,yy+h),r,r,p);stroke.setShader(null);stroke.setStyle(Paint.Style.STROKE);stroke.setStrokeWidth(1.4f);stroke.setColor(border);c.drawRoundRect(new RectF(x,yy,x+w,yy+h),r,r,stroke);}
    private void glow(Canvas c,float x,float yy,float w,float h,float r,int ac){stroke.setStyle(Paint.Style.STROKE);stroke.setStrokeWidth(2);stroke.setColor(ac);stroke.setShadowLayer(13,0,0,ac);c.drawRoundRect(new RectF(x,yy,x+w,yy+h),r,r,stroke);stroke.clearShadowLayer();}
    private void divider(Canvas c,float x1,float y1,float x2,float y2){stroke.setColor(Color.rgb(18,48,75));stroke.setStrokeWidth(1);c.drawLine(x1,y1,x2,y2,stroke);}
    private void text(Canvas c,String txt,float x,float yy,float size,int color,boolean bold,Paint.Align align){p.setShader(null);p.setStyle(Paint.Style.FILL);p.setColor(color);p.setTextSize(size);p.setTextAlign(align);p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));c.drawText(txt,x,yy,p);}
    private float freqX(float f,float x,float w){double t=(Math.log(clamp(f,20,20000))-Math.log(20))/(Math.log(20000)-Math.log(20));return x+(float)t*w;}
    private float gainY(float g,float yy,float h){return yy+(12-clamp(g,-12,12))/24f*h;}
    private float clamp(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}
    private float round1(float v){return Math.round(v*10f)/10f;}
    private float round2(float v){return Math.round(v*100f)/100f;}
    private void toast(String m){Toast.makeText(getContext(),m,Toast.LENGTH_SHORT).show();}
}
