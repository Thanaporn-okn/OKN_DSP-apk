package com.okn.dsp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import java.util.Locale;

/**
 * OKN_DSP V18 minimal four-page UI.
 *
 * UI motion is immediate. Verified DSP writes are coalesced by BleManager into the
 * original-app 380 ms scheduler so dragging does not flood AB01. Unsupported actuator
 * families remain interactive in the UI but are deliberately not written to hardware.
 */
final class DspView extends View {
    private static final float W = 786f;
    private static final float H = 1536f;
    private static final float NAV_H = 122f;

    private static final int PAGE_HOME = 0;
    private static final int PAGE_MIX = 1;
    private static final int PAGE_EQ = 2;
    private static final int PAGE_XOVER = 3;

    private static final int DRAG_NONE = 0;
    private static final int DRAG_MIX = 1;
    private static final int DRAG_EQ_FREQ = 2;
    private static final int DRAG_EQ_GAIN = 3;
    private static final int DRAG_EQ_Q = 4;
    private static final int DRAG_OUTPUT = 5;
    private static final int DRAG_HPF = 6;
    private static final int DRAG_LPF = 7;
    private static final int DRAG_DELAY = 8;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final DspState state = new DspState();

    private BleManager ble;
    private int page = PAGE_HOME;
    private int dragKind = DRAG_NONE;
    private int dragIndex = -1;
    private float scale = 1f;
    private float offsetX = 0f;
    private float offsetY = 0f;
    private float viewportH = H;

    private String bleStatus = "กำลังค้นหา DSP";
    private String bleDevice = "OKN-DSP_7CH";
    private boolean bleConnected = false;
    private String diagnostic = "";

    private final int BG = Color.rgb(5, 12, 20);
    private final int PANEL = Color.rgb(13, 27, 39);
    private final int PANEL2 = Color.rgb(18, 35, 49);
    private final int BORDER = Color.rgb(40, 66, 86);
    private final int WHITE = Color.rgb(240, 246, 250);
    private final int SUB = Color.rgb(146, 167, 184);
    private final int CYAN = Color.rgb(29, 206, 238);
    private final int BLUE = Color.rgb(30, 140, 235);
    private final int GREEN = Color.rgb(51, 222, 121);
    private final int ORANGE = Color.rgb(255, 176, 72);
    private final int RED = Color.rgb(255, 94, 102);

    DspView(Context context, BleManager ble) {
        super(context);
        this.ble = ble;
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        setFocusable(true);
        setClickable(true);
        setHapticFeedbackEnabled(false);
    }

    void setBleManager(BleManager ble) {
        this.ble = ble;
    }

    void setBleStatus(String status, String deviceName, boolean connected) {
        bleStatus = status == null ? "" : status;
        if (deviceName != null && !deviceName.isEmpty()) bleDevice = deviceName;
        bleConnected = connected;
        invalidate();
    }

    void setDiagnostic(String message) {
        diagnostic = message == null ? "" : message;
        invalidate();
    }

    void setScalarFromDsp(int actuatorId, float value) {
        switch (actuatorId) {
            case DspProtocol.ID_MASTER_VOLUME: state.masterVolume = value; break;
            case DspProtocol.ID_BASS_VOLUME: state.bassVolume = value; break;
            case DspProtocol.ID_BASS_CUTOFF: state.bassCutoff = value; break;
            case DspProtocol.ID_BASS_BOOST: state.bassBoost = value; break;
            case DspProtocol.ID_MIDDLE_BOOST: state.middleBoost = value; break;
            case DspProtocol.ID_TREBLE_BOOST: state.trebleBoost = value; break;
            default: return;
        }
        invalidate();
    }

    void setEqFromDsp(int channel0, int band0, float frequency, float gainDb, float q,
                      boolean writable, boolean shapeWritable) {
        if (channel0 < 0 || channel0 >= DspState.CHANNELS || band0 < 0 || band0 >= DspState.BANDS) return;
        state.freq[channel0][band0] = frequency;
        state.gain[channel0][band0] = gainDb;
        state.q[channel0][band0] = q;
        state.eqWritable[channel0][band0] = writable;
        state.eqShapeWritable[channel0][band0] = shapeWritable;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float widthScale = getWidth() / W;
        float atWidth = getHeight() / widthScale;
        if (atWidth >= H) {
            scale = widthScale;
            viewportH = atWidth;
            offsetX = 0f;
            offsetY = 0f;
        } else {
            scale = Math.min(widthScale, getHeight() / H);
            viewportH = H;
            offsetX = (getWidth() - W * scale) * 0.5f;
            offsetY = (getHeight() - H * scale) * 0.5f;
        }

        canvas.drawColor(BG);
        canvas.save();
        canvas.translate(offsetX, offsetY);
        canvas.scale(scale, scale);
        drawBackground(canvas);
        drawHeader(canvas);
        if (page == PAGE_HOME) drawHome(canvas);
        else if (page == PAGE_MIX) drawMix(canvas);
        else if (page == PAGE_EQ) drawEq(canvas);
        else drawCrossover(canvas);
        drawBottomNav(canvas);
        canvas.restore();
    }

    private void drawBackground(Canvas c) {
        p.setShader(new LinearGradient(0, 0, W, viewportH,
                Color.rgb(8, 21, 32), Color.rgb(3, 8, 14), Shader.TileMode.CLAMP));
        c.drawRect(0, 0, W, viewportH, p);
        p.setShader(null);
    }

    private float navTop() {
        return viewportH - NAV_H;
    }

    private String pageName() {
        if (page == PAGE_MIX) return "Mix";
        if (page == PAGE_EQ) return "EQ";
        if (page == PAGE_XOVER) return "Crossover";
        return "Home";
    }

    private void drawHeader(Canvas c) {
        text(c, "OKN_DSP", 28, 46, 31, WHITE, true, Paint.Align.LEFT);
        text(c, pageName(), 28, 78, 18, SUB, false, Paint.Align.LEFT);

        float x = 470, y = 24, w = 286, h = 64;
        roundPanel(c, x, y, w, h, 19, PANEL, bleConnected ? Color.rgb(32, 111, 78) : BORDER);
        p.setColor(bleConnected ? GREEN : ORANGE);
        p.setShadowLayer(10, 0, 0, p.getColor());
        c.drawCircle(x + 28, y + 24, 8, p);
        p.clearShadowLayer();
        text(c, bleConnected ? "Connected" : bleStatus, x + 48, y + 29, 16, WHITE, true, Paint.Align.LEFT);
        text(c, bleDevice, x + 48, y + 51, 13, SUB, false, Paint.Align.LEFT);
    }

    private void drawHome(Canvas c) {
        float y = 128;
        roundPanel(c, 22, y, 742, 170, 25, PANEL, BORDER);
        p.setColor(bleConnected ? GREEN : ORANGE);
        c.drawCircle(76, y + 61, 28, p);
        text(c, bleConnected ? "✓" : "•", 76, y + 72, 27, Color.rgb(5, 25, 20), true, Paint.Align.CENTER);
        text(c, bleConnected ? "DSP พร้อมใช้งาน" : "กำลังเชื่อมต่อ DSP", 126, y + 58, 28, WHITE, true, Paint.Align.LEFT);
        text(c, bleConnected ? "ค่าที่รองรับจะส่งผ่าน BLE แบบ Real-time" : "แตะการ์ดนี้เพื่อค้นหาอุปกรณ์อีกครั้ง",
                126, y + 91, 17, SUB, false, Paint.Align.LEFT);
        text(c, "7 Channel Digital Signal Processor", 126, y + 124, 16, CYAN, false, Paint.Align.LEFT);

        roundPanel(c, 22, 322, 742, 226, 25, PANEL, BORDER);
        text(c, "DSP 7 Ch", 48, 385, 45, WHITE, true, Paint.Align.LEFT);
        text(c, "Minimal control • safe BLE scheduler • live tuning", 48, 425, 18, SUB, false, Paint.Align.LEFT);
        drawWave(c, 46, 470, 690, 42, CYAN);
        chip(c, 48, 505, 142, "MIX LIVE", GREEN);
        chip(c, 204, 505, 164, "15-BAND EQ", CYAN);
        chip(c, 382, 505, 188, "7 CHANNEL", BLUE);

        text(c, "Control", 24, 600, 20, SUB, true, Paint.Align.LEFT);
        homeShortcut(c, 22, 626, 232, 188, "Mix", "Volume & Tone", PAGE_MIX, "≋");
        homeShortcut(c, 277, 626, 232, 188, "EQ", "15 Band × 7 Ch", PAGE_EQ, "▥");
        homeShortcut(c, 532, 626, 232, 188, "Crossover", "Filter & Delay", PAGE_XOVER, "⌁");

        roundPanel(c, 22, 846, 742, 332, 25, PANEL, BORDER);
        text(c, "Runtime", 48, 895, 22, WHITE, true, Paint.Align.LEFT);
        infoRow(c, 48, 938, "BLE transport", "AB01 / AB02", bleConnected ? GREEN : SUB);
        infoRow(c, 48, 984, "Control cadence", "380 ms safe scheduler", CYAN);
        infoRow(c, 48, 1030, "EQ mapping", "15 records × 7 channels", CYAN);
        infoRow(c, 48, 1076, "UI response", "Immediate touch tracking", GREEN);
        if (!diagnostic.isEmpty()) {
            String d = diagnostic.length() > 70 ? diagnostic.substring(0, 70) + "…" : diagnostic;
            text(c, d, 48, 1134, 14, SUB, false, Paint.Align.LEFT);
        }
    }

    private void homeShortcut(Canvas c, float x, float y, float w, float h, String title, String sub, int target, String icon) {
        roundPanel(c, x, y, w, h, 23, PANEL, BORDER);
        p.setColor(Color.argb(35, 29, 206, 238));
        c.drawCircle(x + 54, y + 55, 31, p);
        text(c, icon, x + 54, y + 66, 32, CYAN, true, Paint.Align.CENTER);
        text(c, title, x + 24, y + 121, 25, WHITE, true, Paint.Align.LEFT);
        text(c, sub, x + 24, y + 151, 15, SUB, false, Paint.Align.LEFT);
        text(c, "›", x + w - 27, y + 109, 34, SUB, false, Paint.Align.CENTER);
    }

    private void drawMix(Canvas c) {
        String[] names = {"Master Volume", "Bass Volume", "Bass Cutoff", "Bass Boost", "Middle Boost", "Treble Boost"};
        String[] subs = {"ระดับเสียงรวม", "ระดับเสียงเบส", "ความถี่ตัดเบส", "เพิ่มย่านเบส", "เพิ่มย่านกลาง", "เพิ่มย่านแหลม"};
        for (int i = 0; i < 6; i++) {
            float y = mixRowY(i);
            roundPanel(c, 22, y, 742, 154, 22, PANEL, BORDER);
            text(c, names[i], 46, y + 43, 23, WHITE, true, Paint.Align.LEFT);
            text(c, subs[i], 46, y + 70, 14, SUB, false, Paint.Align.LEFT);
            float value = mixValue(i);
            float min = mixMin(i), max = mixMax(i);
            drawHorizontalSlider(c, 272, y + 84, 652, value, min, max, i == 2, true);
            roundPanel(c, 662, y + 60, 84, 50, 12, PANEL2, BORDER);
            text(c, mixValueText(i, value), 704, y + 92, 15, WHITE, true, Paint.Align.CENTER);
            text(c, i == 5 ? "safe slew" : "LIVE", 704, y + 126, 11, i == 5 ? ORANGE : GREEN, true, Paint.Align.CENTER);
        }
    }

    private float mixRowY(int i) {
        return 126f + i * 185f;
    }

    private float mixValue(int i) {
        if (i == 0) return state.masterVolume;
        if (i == 1) return state.bassVolume;
        if (i == 2) return state.bassCutoff;
        if (i == 3) return state.bassBoost;
        if (i == 4) return state.middleBoost;
        return state.trebleBoost;
    }

    private float mixMin(int i) { return i <= 1 ? -70f : i == 2 ? 20f : -12f; }
    private float mixMax(int i) { return i <= 1 ? 6f : i == 2 ? 250f : 12f; }

    private String mixValueText(int i, float v) {
        return i == 2 ? String.format(Locale.US, "%.0f Hz", v) : String.format(Locale.US, "%+.1f", v);
    }

    private void drawEq(Canvas c) {
        drawChannelTabs(c, 124);
        drawEqGraph(c);
        drawEqBands(c);

        int ch = state.channel;
        int b = state.selectedBand;
        boolean gainLive = state.eqWritable[ch][b];
        boolean shapeLive = state.eqShapeWritable[ch][b];

        text(c, "Band " + (b + 1), 24, 838, 24, WHITE, true, Paint.Align.LEFT);
        text(c, DspState.CHANNEL_SHORT[ch] + " • " + DspState.CHANNEL_LONG[ch], 135, 838, 15, SUB, false, Paint.Align.LEFT);
        chip(c, 588, 810, 176, gainLive ? "GAIN LIVE" : "GAIN LOCK", gainLive ? GREEN : ORANGE);

        drawEqParamRow(c, 858, "Frequency", DspState.hz(state.freq[ch][b]), state.freq[ch][b], 20f, 20000f, true,
                shapeLive ? GREEN : ORANGE, shapeLive ? "HW LIVE" : "UI ONLY");
        drawEqParamRow(c, 951, "Gain", DspState.db(state.gain[ch][b]), state.gain[ch][b], -12f, 12f, false,
                gainLive ? GREEN : ORANGE, gainLive ? "HW LIVE" : "UI ONLY");
        drawEqParamRow(c, 1044, "Q Factor", String.format(Locale.US, "%.2f", state.q[ch][b]), state.q[ch][b], 0.05f, 20f, true,
                shapeLive ? GREEN : ORANGE, shapeLive ? "HW LIVE" : "UI ONLY");

        roundPanel(c, 22, 1147, 742, 96, 19, PANEL, BORDER);
        text(c, "Output Gain", 46, 1186, 20, WHITE, true, Paint.Align.LEFT);
        drawHorizontalSlider(c, 220, 1200, 634, state.fader[ch], -60f, 12f, false, true);
        text(c, DspState.db(state.fader[ch]), 735, 1206, 14, WHITE, true, Paint.Align.RIGHT);
        text(c, "UI LIVE • hardware actuator ยังไม่ยืนยัน", 46, 1225, 12, ORANGE, false, Paint.Align.LEFT);

        outlineButton(c, 22, 1272, 230, 78, "↻  DSP Refresh");
        outlineButton(c, 278, 1272, 230, 78, "⇧  Load Preset");
        outlineButton(c, 534, 1272, 230, 78, "▣  Save Preset");
    }

    private void drawEqGraph(Canvas c) {
        float gx = 38, gy = 214, gw = 726, gh = 300;
        roundPanel(c, 22, 202, 742, 332, 20, PANEL, BORDER);
        p.setColor(Color.rgb(6, 17, 26));
        c.drawRoundRect(new RectF(gx, gy, gx + gw, gy + gh), 12, 12, p);
        stroke.setStrokeWidth(1);
        stroke.setColor(Color.rgb(32, 56, 72));
        for (int i = 0; i <= 10; i++) {
            float x = gx + gw * i / 10f;
            c.drawLine(x, gy, x, gy + gh, stroke);
        }
        for (int i = 0; i <= 4; i++) {
            float y = gy + gh * i / 4f;
            c.drawLine(gx, y, gx + gw, y, stroke);
        }
        int ch = state.channel;
        Path path = new Path();
        for (int b = 0; b < DspState.BANDS; b++) {
            float x = freqX(state.freq[ch][b], gx, gw);
            float y = gainY(state.gain[ch][b], gy, gh);
            if (b == 0) path.moveTo(x, y); else path.lineTo(x, y);
        }
        stroke.setStrokeWidth(4);
        stroke.setColor(CYAN);
        stroke.setShadowLayer(8, 0, 0, CYAN);
        c.drawPath(path, stroke);
        stroke.clearShadowLayer();
        for (int b = 0; b < DspState.BANDS; b++) {
            float x = freqX(state.freq[ch][b], gx, gw);
            float y = gainY(state.gain[ch][b], gy, gh);
            p.setColor(b == state.selectedBand ? WHITE : CYAN);
            c.drawCircle(x, y, b == state.selectedBand ? 9 : 6, p);
        }
        text(c, "+12", 31, gy + 10, 11, SUB, false, Paint.Align.RIGHT);
        text(c, "0", 31, gy + gh / 2 + 5, 11, SUB, false, Paint.Align.RIGHT);
        text(c, "-12", 31, gy + gh, 11, SUB, false, Paint.Align.RIGHT);
    }

    private void drawEqBands(Canvas c) {
        float y = 557, h = 222;
        roundPanel(c, 22, y, 742, h, 20, PANEL, BORDER);
        text(c, "15 Band", 42, y + 35, 18, WHITE, true, Paint.Align.LEFT);
        text(c, "แตะ band เพื่อเลือก", 146, y + 35, 13, SUB, false, Paint.Align.LEFT);
        float start = 50f, usable = 690f, col = usable / DspState.BANDS;
        float top = y + 61, bottom = y + 178;
        int ch = state.channel;
        for (int b = 0; b < DspState.BANDS; b++) {
            float cx = start + col * (b + 0.5f);
            boolean sel = b == state.selectedBand;
            if (sel) {
                p.setColor(Color.argb(30, 29, 206, 238));
                c.drawRoundRect(new RectF(cx - col * .42f, top - 15, cx + col * .42f, bottom + 28), 7, 7, p);
            }
            p.setStrokeWidth(4);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(Color.rgb(45, 70, 87));
            c.drawLine(cx, top, cx, bottom, p);
            float ky = top + (12f - clamp(state.gain[ch][b], -12f, 12f)) / 24f * (bottom - top);
            p.setColor(state.eqWritable[ch][b] ? CYAN : ORANGE);
            c.drawCircle(cx, ky, sel ? 8 : 6, p);
            text(c, Integer.toString(b + 1), cx, bottom + 24, 10, sel ? WHITE : SUB, sel, Paint.Align.CENTER);
        }
        p.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawEqParamRow(Canvas c, float y, String name, String valueText, float value,
                                float min, float max, boolean logarithmic, int statusColor, String status) {
        roundPanel(c, 22, y, 742, 80, 18, PANEL, BORDER);
        text(c, name, 46, y + 32, 18, WHITE, true, Paint.Align.LEFT);
        text(c, status, 46, y + 57, 11, statusColor, true, Paint.Align.LEFT);
        drawHorizontalSlider(c, 220, y + 41, 634, value, min, max, logarithmic, true);
        text(c, valueText, 742, y + 47, 14, WHITE, true, Paint.Align.RIGHT);
    }

    private void drawCrossover(Canvas c) {
        drawChannelTabs(c, 124);
        drawCrossoverGraph(c);
        int ch = state.channel;
        drawCrossoverRow(c, 610, "High Pass Filter (HPF)", state.hpfEnabled[ch], DspState.hz(state.hpfHz[ch]), state.hpfHz[ch], true);
        drawCrossoverRow(c, 790, "Low Pass Filter (LPF)", state.lpfEnabled[ch], DspState.hz(state.lpfHz[ch]), state.lpfHz[ch], false);

        roundPanel(c, 22, 970, 742, 154, 22, PANEL, BORDER);
        text(c, "Delay", 46, 1012, 22, WHITE, true, Paint.Align.LEFT);
        text(c, "0.00–20.00 ms", 46, 1041, 13, SUB, false, Paint.Align.LEFT);
        drawHorizontalSlider(c, 250, 1035, 644, state.delayMs[ch], 0f, 20f, false, true);
        text(c, String.format(Locale.US, "%.2f ms", state.delayMs[ch]), 742, 1041, 15, WHITE, true, Paint.Align.RIGHT);
        text(c, "UI LIVE • hardware packet ยังไม่ยืนยัน", 46, 1090, 12, ORANGE, false, Paint.Align.LEFT);

        roundPanel(c, 22, 1152, 742, 82, 18, PANEL, BORDER);
        text(c, "Filter type", 46, 1185, 15, SUB, false, Paint.Align.LEFT);
        chip(c, 160, 1167, 210, "Linkwitz-Riley", CYAN);
        chip(c, 386, 1167, 154, "24 dB/Oct", BLUE);
        chip(c, 556, 1167, 176, "REAL-TIME UI", GREEN);

        outlineButton(c, 150, 1270, 230, 78, "⇧  Load Preset");
        outlineButton(c, 406, 1270, 230, 78, "▣  Save Preset");
    }

    private void drawCrossoverGraph(Canvas c) {
        float gx = 46, gy = 228, gw = 710, gh = 300;
        roundPanel(c, 22, 202, 742, 352, 20, PANEL, BORDER);
        p.setColor(Color.rgb(6, 17, 26));
        c.drawRoundRect(new RectF(gx, gy, gx + gw, gy + gh), 12, 12, p);
        stroke.setColor(Color.rgb(33, 58, 74));
        stroke.setStrokeWidth(1);
        for (int i = 0; i <= 10; i++) c.drawLine(gx + gw * i / 10f, gy, gx + gw * i / 10f, gy + gh, stroke);
        for (int i = 0; i <= 4; i++) c.drawLine(gx, gy + gh * i / 4f, gx + gw, gy + gh * i / 4f, stroke);
        int ch = state.channel;
        float hx = freqX(state.hpfHz[ch], gx, gw);
        float lx = freqX(state.lpfHz[ch], gx, gw);
        Path hp = new Path();
        hp.moveTo(gx, gy + gh);
        hp.lineTo(Math.max(gx, hx - 65), gy + gh);
        hp.lineTo(hx, gy + 25);
        hp.lineTo(gx + gw, gy + 25);
        stroke.setStrokeWidth(4); stroke.setColor(BLUE); c.drawPath(hp, stroke);
        Path lp = new Path();
        lp.moveTo(gx, gy + 25); lp.lineTo(lx, gy + 25); lp.lineTo(Math.min(gx + gw, lx + 70), gy + gh); lp.lineTo(gx + gw, gy + gh);
        stroke.setColor(RED); c.drawPath(lp, stroke);
        p.setColor(BLUE); c.drawCircle(hx, gy + 25, 8, p);
        p.setColor(RED); c.drawCircle(lx, gy + 25, 8, p);
        text(c, "HPF", hx + 12, gy + 61, 13, BLUE, true, Paint.Align.LEFT);
        text(c, "LPF", lx - 12, gy + 61, 13, RED, true, Paint.Align.RIGHT);
    }

    private void drawCrossoverRow(Canvas c, float y, String title, boolean enabled, String valueText, float value, boolean highPass) {
        roundPanel(c, 22, y, 742, 154, 22, PANEL, BORDER);
        drawToggle(c, 48, y + 36, enabled);
        text(c, title, 122, y + 43, 20, WHITE, true, Paint.Align.LEFT);
        text(c, "Linkwitz-Riley 24 dB/Oct", 122, y + 70, 13, SUB, false, Paint.Align.LEFT);
        drawHorizontalSlider(c, 248, y + 103, 646, value, 20f, 20000f, true, enabled);
        text(c, valueText, 742, y + 109, 15, WHITE, true, Paint.Align.RIGHT);
        text(c, "UI LIVE • HW LOCK", 48, y + 132, 11, ORANGE, true, Paint.Align.LEFT);
    }

    private void drawChannelTabs(Canvas c, float y) {
        for (int ch = 0; ch < DspState.CHANNELS; ch++) {
            float x = 22 + ch * 106f;
            boolean sel = ch == state.channel;
            roundPanel(c, x, y, 96, 56, 14, sel ? Color.rgb(15, 108, 135) : PANEL, sel ? CYAN : BORDER);
            text(c, DspState.CHANNEL_SHORT[ch], x + 48, y + 35, 16, sel ? WHITE : SUB, sel, Paint.Align.CENTER);
        }
    }

    private void drawBottomNav(Canvas c) {
        float y = navTop();
        p.setColor(Color.rgb(7, 17, 25));
        c.drawRect(0, y, W, viewportH, p);
        stroke.setStrokeWidth(1);
        stroke.setColor(BORDER);
        c.drawLine(0, y, W, y, stroke);
        String[] labels = {"Home", "Mix", "EQ", "Crossover"};
        String[] icons = {"⌂", "≋", "▥", "⌁"};
        for (int i = 0; i < 4; i++) {
            float cx = W / 8f + i * W / 4f;
            boolean sel = i == page;
            int col = sel ? CYAN : SUB;
            if (sel) {
                p.setColor(Color.argb(38, 29, 206, 238));
                c.drawCircle(cx, y + 35, 27, p);
            }
            text(c, icons[i], cx, y + 44, 28, col, true, Paint.Align.CENTER);
            text(c, labels[i], cx, y + 88, 14, col, sel, Paint.Align.CENTER);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (scale <= 0f || Float.isNaN(scale) || Float.isInfinite(scale)) return true;
        float x = (event.getX() - offsetX) / scale;
        float y = (event.getY() - offsetY) / scale;
        if (x < 0 || x > W || y < 0 || y > viewportH) return true;

        int action = event.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN) {
            if (y <= 104 && x >= 450) {
                if (ble != null) ble.startScan();
                return true;
            }
            if (y >= navTop()) {
                page = Math.min(3, Math.max(0, (int) (x / (W / 4f))));
                clearDrag();
                invalidate();
                return true;
            }
            if (page == PAGE_HOME) return handleHomeDown(x, y);
            if (page == PAGE_MIX) return handleMixDown(x, y);
            if (page == PAGE_EQ) return handleEqDown(x, y);
            return handleCrossoverDown(x, y);
        }

        if (action == MotionEvent.ACTION_MOVE) {
            updateDrag(x, y);
            return true;
        }

        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            finishDrag();
            clearDrag();
            performClick();
            return true;
        }
        return true;
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    private boolean handleHomeDown(float x, float y) {
        if (y >= 128 && y <= 298) {
            if (ble != null) ble.startScan();
            return true;
        }
        if (y >= 626 && y <= 814) {
            if (x < 264) page = PAGE_MIX;
            else if (x < 522) page = PAGE_EQ;
            else page = PAGE_XOVER;
            invalidate();
        }
        return true;
    }

    private boolean handleMixDown(float x, float y) {
        for (int i = 0; i < 6; i++) {
            float sy = mixRowY(i) + 84;
            if (x >= 250 && x <= 672 && Math.abs(y - sy) <= 44) {
                dragKind = DRAG_MIX;
                dragIndex = i;
                updateMix(i, x);
                invalidate();
                return true;
            }
        }
        return true;
    }

    private boolean handleEqDown(float x, float y) {
        if (handleChannelTap(x, y, 124)) return true;

        if (y >= 557 && y <= 779 && x >= 44 && x <= 750) {
            float col = 690f / DspState.BANDS;
            int b = Math.min(DspState.BANDS - 1, Math.max(0, (int) ((x - 50f) / col)));
            state.selectedBand = b;
            invalidate();
            return true;
        }

        if (x >= 190 && x <= 670 && Math.abs(y - (858 + 41)) <= 38) {
            dragKind = DRAG_EQ_FREQ; updateEqParam(x); invalidate(); return true;
        }
        if (x >= 190 && x <= 670 && Math.abs(y - (951 + 41)) <= 38) {
            dragKind = DRAG_EQ_GAIN; updateEqParam(x); invalidate(); return true;
        }
        if (x >= 190 && x <= 670 && Math.abs(y - (1044 + 41)) <= 38) {
            dragKind = DRAG_EQ_Q; updateEqParam(x); invalidate(); return true;
        }
        if (x >= 190 && x <= 670 && Math.abs(y - 1200) <= 38) {
            dragKind = DRAG_OUTPUT; updateOutput(x); invalidate(); return true;
        }

        if (y >= 1260 && y <= 1365) {
            if (x >= 22 && x <= 252) {
                if (ble != null) ble.requestDspRefresh();
            } else if (x >= 278 && x <= 508) {
                boolean ok = state.loadEq(getContext());
                if (ok) sendEqChannel(state.channel);
                toast(ok ? "โหลด EQ preset แล้ว" : "ยังไม่มี EQ preset");
                invalidate();
            } else if (x >= 534 && x <= 764) {
                state.saveEq(getContext());
                toast("บันทึก EQ preset แล้ว");
            }
            return true;
        }
        return true;
    }

    private boolean handleCrossoverDown(float x, float y) {
        if (handleChannelTap(x, y, 124)) return true;
        int ch = state.channel;
        if (x >= 30 && x <= 112 && y >= 620 && y <= 690) {
            state.hpfEnabled[ch] = !state.hpfEnabled[ch];
            reportUnverified("HPF enable");
            invalidate();
            return true;
        }
        if (x >= 30 && x <= 112 && y >= 800 && y <= 870) {
            state.lpfEnabled[ch] = !state.lpfEnabled[ch];
            reportUnverified("LPF enable");
            invalidate();
            return true;
        }
        if (x >= 220 && x <= 670 && Math.abs(y - 713) <= 50) {
            dragKind = DRAG_HPF; updateCrossover(x); invalidate(); return true;
        }
        if (x >= 220 && x <= 670 && Math.abs(y - 893) <= 50) {
            dragKind = DRAG_LPF; updateCrossover(x); invalidate(); return true;
        }
        if (x >= 220 && x <= 670 && Math.abs(y - 1035) <= 50) {
            dragKind = DRAG_DELAY; updateCrossover(x); invalidate(); return true;
        }
        if (y >= 1260 && y <= 1365) {
            if (x >= 150 && x <= 380) {
                boolean ok = state.loadCrossover(getContext());
                toast(ok ? "โหลด Crossover preset แล้ว" : "ยังไม่มี Crossover preset");
                invalidate();
            } else if (x >= 406 && x <= 636) {
                state.saveCrossover(getContext());
                toast("บันทึก Crossover preset แล้ว");
            }
        }
        return true;
    }

    private boolean handleChannelTap(float x, float y, float tabY) {
        if (y < tabY || y > tabY + 64) return false;
        int ch = (int) ((x - 22) / 106f);
        if (ch >= 0 && ch < DspState.CHANNELS) {
            state.channel = ch;
            invalidate();
            return true;
        }
        return false;
    }

    private void updateDrag(float x, float y) {
        if (dragKind == DRAG_MIX) updateMix(dragIndex, x);
        else if (dragKind == DRAG_EQ_FREQ || dragKind == DRAG_EQ_GAIN || dragKind == DRAG_EQ_Q) updateEqParam(x);
        else if (dragKind == DRAG_OUTPUT) updateOutput(x);
        else if (dragKind == DRAG_HPF || dragKind == DRAG_LPF || dragKind == DRAG_DELAY) updateCrossover(x);
        else return;
        invalidate();
    }

    private void updateMix(int idx, float x) {
        float frac = clamp((x - 272f) / (652f - 272f), 0f, 1f);
        if (idx == 0) state.masterVolume = round1(-70f + frac * 76f);
        else if (idx == 1) state.bassVolume = round1(-70f + frac * 76f);
        else if (idx == 2) state.bassCutoff = Math.round(logValue(frac, 20f, 250f));
        else if (idx == 3) state.bassBoost = round1(-12f + frac * 24f);
        else if (idx == 4) state.middleBoost = round1(-12f + frac * 24f);
        else state.trebleBoost = round1(-12f + frac * 24f);
        sendMix(idx);
    }

    private void sendMix(int idx) {
        if (ble == null) return;
        if (idx == 0) ble.setScalarRealtime(DspProtocol.ID_MASTER_VOLUME, state.masterVolume);
        else if (idx == 1) ble.setScalarRealtime(DspProtocol.ID_BASS_VOLUME, state.bassVolume);
        else if (idx == 2) ble.setScalarRealtime(DspProtocol.ID_BASS_CUTOFF, state.bassCutoff);
        else if (idx == 3) ble.setScalarRealtime(DspProtocol.ID_BASS_BOOST, state.bassBoost);
        else if (idx == 4) ble.setScalarRealtime(DspProtocol.ID_MIDDLE_BOOST, state.middleBoost);
        else if (idx == 5) ble.setScalarRealtime(DspProtocol.ID_TREBLE_BOOST, state.trebleBoost);
    }

    private void updateEqParam(float x) {
        int ch = state.channel, b = state.selectedBand;
        float frac = clamp((x - 220f) / (634f - 220f), 0f, 1f);
        if (dragKind == DRAG_EQ_FREQ) state.freq[ch][b] = logValue(frac, 20f, 20000f);
        else if (dragKind == DRAG_EQ_GAIN) state.gain[ch][b] = round1(-12f + frac * 24f);
        else if (dragKind == DRAG_EQ_Q) state.q[ch][b] = round2(logValue(frac, 0.05f, 20f));

        boolean canSend = dragKind == DRAG_EQ_GAIN ? state.eqWritable[ch][b] : state.eqShapeWritable[ch][b];
        if (canSend && ble != null) {
            ble.setEqRealtime(ch, b, state.freq[ch][b], state.gain[ch][b], state.q[ch][b]);
        }
    }

    private void sendEqChannel(int ch) {
        if (ble == null) return;
        for (int b = 0; b < DspState.BANDS; b++) {
            if (state.eqWritable[ch][b]) {
                ble.setEqRealtime(ch, b, state.freq[ch][b], state.gain[ch][b], state.q[ch][b]);
            }
        }
    }

    private void updateOutput(float x) {
        float frac = clamp((x - 220f) / (634f - 220f), 0f, 1f);
        state.fader[state.channel] = round1(-60f + frac * 72f);
    }

    private void updateCrossover(float x) {
        int ch = state.channel;
        if (dragKind == DRAG_HPF) {
            float frac = clamp((x - 248f) / (646f - 248f), 0f, 1f);
            state.hpfHz[ch] = Math.round(logValue(frac, 20f, 20000f));
        } else if (dragKind == DRAG_LPF) {
            float frac = clamp((x - 248f) / (646f - 248f), 0f, 1f);
            state.lpfHz[ch] = Math.round(logValue(frac, 20f, 20000f));
        } else if (dragKind == DRAG_DELAY) {
            float frac = clamp((x - 250f) / (644f - 250f), 0f, 1f);
            state.delayMs[ch] = round2(frac * 20f);
        }
    }

    private void finishDrag() {
        if (dragKind == DRAG_EQ_FREQ || dragKind == DRAG_EQ_Q) {
            if (!state.eqShapeWritable[state.channel][state.selectedBand]) reportUnverified("EQ Frequency/Q");
        } else if (dragKind == DRAG_EQ_GAIN) {
            if (!state.eqWritable[state.channel][state.selectedBand]) reportUnverified("EQ Gain");
        } else if (dragKind == DRAG_OUTPUT) {
            reportUnverified("Output Gain");
        } else if (dragKind == DRAG_HPF) {
            reportUnverified("HPF frequency");
        } else if (dragKind == DRAG_LPF) {
            reportUnverified("LPF frequency");
        } else if (dragKind == DRAG_DELAY) {
            reportUnverified("Delay");
        }
    }

    private void reportUnverified(String name) {
        if (ble != null) ble.reportUnverifiedControl(name);
    }

    private void clearDrag() {
        dragKind = DRAG_NONE;
        dragIndex = -1;
    }

    private void drawHorizontalSlider(Canvas c, float x0, float cy, float x1, float value,
                                      float min, float max, boolean logarithmic, boolean enabled) {
        float frac;
        if (logarithmic) {
            float v = clamp(value, min, max);
            frac = (float) ((Math.log(v) - Math.log(min)) / (Math.log(max) - Math.log(min)));
        } else {
            frac = (value - min) / (max - min);
        }
        frac = clamp(frac, 0f, 1f);
        float knob = x0 + frac * (x1 - x0);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(10);
        p.setColor(Color.rgb(48, 66, 78));
        c.drawLine(x0, cy, x1, cy, p);
        p.setColor(enabled ? CYAN : Color.rgb(96, 112, 123));
        c.drawLine(x0, cy, knob, cy, p);
        p.setColor(enabled ? WHITE : Color.rgb(172, 181, 188));
        c.drawCircle(knob, cy, 12, p);
        p.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawToggle(Canvas c, float x, float cy, boolean on) {
        float w = 58, h = 30;
        roundPanel(c, x, cy - h / 2, w, h, 15, on ? Color.rgb(19, 144, 168) : Color.rgb(58, 70, 80), on ? CYAN : BORDER);
        p.setColor(WHITE);
        c.drawCircle(on ? x + 43 : x + 15, cy, 11, p);
    }

    private void infoRow(Canvas c, float x, float y, String label, String value, int color) {
        text(c, label, x, y, 15, SUB, false, Paint.Align.LEFT);
        text(c, value, 724, y, 15, color, true, Paint.Align.RIGHT);
        stroke.setColor(Color.rgb(31, 48, 61)); stroke.setStrokeWidth(1); c.drawLine(x, y + 17, 724, y + 17, stroke);
    }

    private void chip(Canvas c, float x, float y, float w, String label, int color) {
        roundPanel(c, x, y, w, 38, 19, Color.argb(25, Color.red(color), Color.green(color), Color.blue(color)),
                Color.argb(150, Color.red(color), Color.green(color), Color.blue(color)));
        text(c, label, x + w / 2, y + 25, 12, color, true, Paint.Align.CENTER);
    }

    private void outlineButton(Canvas c, float x, float y, float w, float h, String label) {
        roundPanel(c, x, y, w, h, 18, PANEL, Color.rgb(44, 100, 126));
        text(c, label, x + w / 2, y + h / 2 + 6, 15, WHITE, true, Paint.Align.CENTER);
    }

    private void drawWave(Canvas c, float x, float y, float w, float h, int color) {
        stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(2); stroke.setColor(color);
        Path path = new Path();
        for (int i = 0; i <= 100; i++) {
            float xx = x + w * i / 100f;
            float yy = y + h / 2f + (float) Math.sin(i * 0.34) * (8 + 10 * (float) Math.sin(i * 0.07));
            if (i == 0) path.moveTo(xx, yy); else path.lineTo(xx, yy);
        }
        c.drawPath(path, stroke);
    }

    private void roundPanel(Canvas c, float x, float y, float w, float h, float r, int fill, int border) {
        p.setStyle(Paint.Style.FILL); p.setColor(fill);
        c.drawRoundRect(new RectF(x, y, x + w, y + h), r, r, p);
        stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(1.2f); stroke.setColor(border);
        c.drawRoundRect(new RectF(x, y, x + w, y + h), r, r, stroke);
    }

    private void text(Canvas c, String s, float x, float y, float size, int color, boolean bold, Paint.Align align) {
        p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(color); p.setTextSize(size); p.setTextAlign(align);
        p.setTypeface(Typeface.create("sans", bold ? Typeface.BOLD : Typeface.NORMAL));
        c.drawText(s, x, y, p);
    }

    private float freqX(float freq, float gx, float gw) {
        double frac = (Math.log(clamp(freq, 20f, 20000f)) - Math.log(20)) / (Math.log(20000) - Math.log(20));
        return gx + (float) frac * gw;
    }

    private float gainY(float gain, float gy, float gh) {
        return gy + (12f - clamp(gain, -12f, 12f)) / 24f * gh;
    }

    private float logValue(float frac, float min, float max) {
        return (float) Math.exp(Math.log(min) + frac * (Math.log(max) - Math.log(min)));
    }

    private float clamp(float v, float lo, float hi) { return Math.max(lo, Math.min(hi, v)); }
    private float round1(float v) { return Math.round(v * 10f) / 10f; }
    private float round2(float v) { return Math.round(v * 100f) / 100f; }
    private void toast(String s) { Toast.makeText(getContext(), s, Toast.LENGTH_SHORT).show(); }
}
