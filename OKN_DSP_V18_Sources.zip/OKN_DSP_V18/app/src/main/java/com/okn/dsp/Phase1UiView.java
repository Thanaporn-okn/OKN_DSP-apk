package com.okn.dsp;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import java.util.Locale;

/**
 * Phase 1 UI implementation based on the four supplied 864x1536 reference screens.
 * The supplied references are used as the visual base; live controls are redrawn on
 * top so every slider/button responds immediately without waiting for BLE/DSP I/O.
 */
final class Phase1UiView extends View {
    private static final float RW = 864f;
    private static final float RH = 1536f;

    private static final int PAGE_HOME = 0;
    private static final int PAGE_MIX = 1;
    private static final int PAGE_EQ = 2;
    private static final int PAGE_XOVER = 3;

    private static final int CYAN = Color.rgb(0, 220, 255);
    private static final int BLUE = Color.rgb(0, 126, 255);
    private static final int MAGENTA = Color.rgb(242, 36, 226);
    private static final int ORANGE = Color.rgb(255, 153, 16);
    private static final int WHITE = Color.rgb(244, 248, 255);
    private static final int SUB = Color.rgb(170, 195, 230);
    private static final int PANEL = Color.rgb(4, 24, 48);
    private static final int TRACK = Color.rgb(25, 59, 101);

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Rect src = new Rect();
    private final RectF dst = new RectF();
    private final DspState state = new DspState();

    private final Bitmap[] pages = new Bitmap[4];

    private int page = PAGE_HOME;
    private int dragKind = 0;
    private int dragIndex = -1;
    private int eqQuickPreset = 0;
    private int homeQuickPreset = 0;

    private int xoverChannel = 0;
    private final boolean[] hpfOn = new boolean[DspState.CHANNELS];
    private final boolean[] lpfOn = new boolean[DspState.CHANNELS];
    private final float[] hpfHz = new float[DspState.CHANNELS];
    private final float[] lpfHz = new float[DspState.CHANNELS];
    private final int[] hpfSlope = new int[DspState.CHANNELS];
    private final int[] lpfSlope = new int[DspState.CHANNELS];
    private final float[] delayMs = new float[DspState.CHANNELS];
    private final boolean[] xoverPhase180 = new boolean[DspState.CHANNELS];
    private final boolean[] linkFilters = new boolean[DspState.CHANNELS];

    Phase1UiView(Context context) {
        super(context);
        setFocusable(true);
        setClickable(true);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);

        pages[PAGE_HOME] = BitmapFactory.decodeResource(getResources(), R.drawable.ui_home);
        pages[PAGE_MIX] = BitmapFactory.decodeResource(getResources(), R.drawable.ui_mix);
        pages[PAGE_EQ] = BitmapFactory.decodeResource(getResources(), R.drawable.ui_eq);
        pages[PAGE_XOVER] = BitmapFactory.decodeResource(getResources(), R.drawable.ui_crossover);

        state.masterVolume = -12f;
        state.bassVolume = 4f;
        state.bassCutoff = 80f;
        state.bassBoost = 6f;
        state.middleBoost = 2f;
        state.trebleBoost = 3f;
        for (int c = 0; c < DspState.CHANNELS; c++) {
            state.fader[c] = -12f;
            for (int b = 0; b < DspState.BANDS; b++) state.eqWritable[c][b] = true;
            hpfOn[c] = true;
            lpfOn[c] = true;
            hpfHz[c] = 80f;
            lpfHz[c] = 4000f;
            hpfSlope[c] = 3;
            lpfSlope[c] = 3;
            delayMs[c] = 0f;
        }
        applyReferenceEqCurve();
    }

    private void applyReferenceEqCurve() {
        float[] f = {20f, 31.5f, 50f, 80f, 125f, 200f, 315f, 500f, 800f, 1250f, 2000f, 3150f, 5000f, 8000f, 12500f};
        float[] g = {-2f, -0.5f, 2f, 5f, 7f, 5f, 2f, 0f, -2.5f, -3.5f, -1.8f, 0.2f, 2.5f, 5.2f, 6.5f};
        for (int c = 0; c < DspState.CHANNELS; c++) {
            for (int b = 0; b < DspState.BANDS; b++) {
                state.freq[c][b] = f[b];
                state.gain[c][b] = g[b];
                state.q[c][b] = 1.2f;
            }
        }
        state.selectedBand = 4;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        drawReference(canvas, pages[page]);
        float sx = getWidth() / RW;
        float sy = getHeight() / RH;
        canvas.save();
        canvas.scale(sx, sy);
        if (page == PAGE_HOME) drawHomeLive(canvas);
        else if (page == PAGE_MIX) drawMixLive(canvas);
        else if (page == PAGE_EQ) drawEqLive(canvas);
        else drawXoverLive(canvas);
        canvas.restore();
    }

    private void drawReference(Canvas c, Bitmap b) {
        c.drawColor(Color.rgb(0, 5, 18));
        if (b == null) return;
        src.set(0, 0, b.getWidth(), b.getHeight());
        dst.set(0, 0, getWidth(), getHeight());
        p.setAlpha(255);
        p.setShader(null);
        c.drawBitmap(b, src, dst, p);
    }

    private void drawHomeLive(Canvas c) {
        drawDbSlider(c, 181, 615, 805, state.masterVolume, -60f, 6f, CYAN, MAGENTA);
        mask(660, 526, 165, 74, 18, c);
        label(c, db(state.masterVolume), 807, 576, 39, CYAN, true, Paint.Align.RIGHT);
        drawPresetSelection(c, 49, 1083, 149, 101, homeQuickPreset, 5);
    }

    private void drawMixLive(Canvas c) {
        drawDbSlider(c, 181, 389, 804, state.masterVolume, -60f, 6f, CYAN, MAGENTA);
        drawDbSlider(c, 181, 557, 804, state.bassVolume, -20f, 20f, CYAN, BLUE);
        drawLogSlider(c, 181, 716, 804, state.bassCutoff, 20f, 320f, MAGENTA, MAGENTA);
        drawDbSlider(c, 181, 872, 804, state.bassBoost, -12f, 12f, CYAN, MAGENTA);
        drawDbSlider(c, 181, 1028, 804, state.middleBoost, -12f, 12f, MAGENTA, MAGENTA);
        drawDbSlider(c, 181, 1190, 804, state.trebleBoost, -12f, 12f, ORANGE, ORANGE);

        drawMixValue(c, 332, db(state.masterVolume), CYAN);
        drawMixValue(c, 500, db(state.bassVolume), CYAN);
        drawMixValue(c, 658, String.format(Locale.US, "%.0f Hz", state.bassCutoff), MAGENTA);
        drawMixValue(c, 815, db(state.bassBoost), CYAN);
        drawMixValue(c, 970, db(state.middleBoost), MAGENTA);
        drawMixValue(c, 1128, db(state.trebleBoost), ORANGE);

        // Tone Balance values in the summary strip.
        mask(399, 1285, 414, 83, 8, c);
        label(c, db(state.masterVolume), 447, 1337, 18, CYAN, true, Paint.Align.CENTER);
        label(c, db(state.bassVolume), 556, 1337, 18, CYAN, true, Paint.Align.CENTER);
        label(c, db(state.middleBoost), 663, 1337, 18, MAGENTA, true, Paint.Align.CENTER);
        label(c, db(state.trebleBoost), 771, 1337, 18, ORANGE, true, Paint.Align.CENTER);
    }

    private void drawMixValue(Canvas c, float y, String value, int color) {
        mask(657, y - 42, 170, 66, 14, c);
        label(c, value, 809, y + 4, 34, color, true, Paint.Align.RIGHT);
    }

    private void drawEqLive(Canvas c) {
        drawChannelStrip(c, state.channel, 252, new String[]{"CH1","CH2","CH3","CH4","CH5","CH6","CH7"});
        drawEqGraph(c);
        drawEqParameterPanel(c);
        drawDbSlider(c, 160, 1014, 680, state.fader[state.channel], -60f, 6f, CYAN, MAGENTA);
        mask(690, 970, 136, 80, 12, c);
        label(c, db(state.fader[state.channel]), 815, 1025, 34, CYAN, true, Paint.Align.RIGHT);
        drawPresetSelection(c, 48, 1267, 150, 94, eqQuickPreset, 5);
    }

    private void drawChannelStrip(Canvas c, int selected, float top, String[] labels) {
        mask(22, top - 8, 820, 105, 24, c);
        float left = 28f;
        float gap = 8f;
        float w = 108f;
        for (int i = 0; i < 7; i++) {
            float x = left + i * (w + gap);
            p.setStyle(Paint.Style.FILL);
            p.setColor(i == selected ? Color.rgb(5, 55, 95) : Color.rgb(4, 29, 57));
            c.drawRoundRect(new RectF(x, top, x + w, top + 91), 14, 14, p);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(i == selected ? 3f : 1.5f);
            stroke.setColor(i == selected ? CYAN : Color.rgb(19, 75, 128));
            if (i == selected) stroke.setShadowLayer(12, 0, 0, CYAN);
            c.drawRoundRect(new RectF(x, top, x + w, top + 91), 14, 14, stroke);
            stroke.clearShadowLayer();
            label(c, labels[i], x + w / 2f, top + 69, 18, WHITE, true, Paint.Align.CENTER);
        }
    }

    private void drawEqGraph(Canvas c) {
        float gx = 77f, gy = 432f, gw = 731f, gh = 230f;
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.rgb(3, 20, 40));
        c.drawRect(gx, gy, gx + gw, gy + gh, p);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(1f);
        stroke.setColor(Color.rgb(28, 57, 91));
        for (int i = 0; i <= 12; i++) {
            float x = gx + gw * i / 12f;
            c.drawLine(x, gy, x, gy + gh, stroke);
        }
        for (int i = 0; i <= 4; i++) {
            float y = gy + gh * i / 4f;
            c.drawLine(gx, y, gx + gw, y, stroke);
        }
        float zeroY = gainToY(0f, gy, gh);
        stroke.setColor(Color.rgb(75, 111, 151));
        c.drawLine(gx, zeroY, gx + gw, zeroY, stroke);

        Path curve = new Path();
        for (int b = 0; b < DspState.BANDS; b++) {
            float x = freqToX(state.freq[state.channel][b], gx, gw);
            float y = gainToY(state.gain[state.channel][b], gy, gh);
            if (b == 0) curve.moveTo(x, y); else curve.lineTo(x, y);
        }
        stroke.setStrokeWidth(4f);
        stroke.setColor(CYAN);
        stroke.setShadowLayer(8, 0, 0, BLUE);
        c.drawPath(curve, stroke);
        stroke.clearShadowLayer();

        for (int b = 0; b < DspState.BANDS; b++) {
            float x = freqToX(state.freq[state.channel][b], gx, gw);
            float y = gainToY(state.gain[state.channel][b], gy, gh);
            int color = bandColor(b);
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            if (b == state.selectedBand) p.setShadowLayer(14, 0, 0, color);
            c.drawCircle(x, y, b == state.selectedBand ? 9f : 6f, p);
            p.clearShadowLayer();
            stroke.setStrokeWidth(2f);
            stroke.setColor(WHITE);
            c.drawCircle(x, y, b == state.selectedBand ? 9f : 6f, stroke);
        }
    }

    private void drawEqParameterPanel(Canvas c) {
        int b = state.selectedBand;
        float freq = state.freq[state.channel][b];
        float gain = state.gain[state.channel][b];
        float q = state.q[state.channel][b];

        mask(35, 718, 800, 173, 18, c);
        label(c, "Band " + (b + 1), 126, 773, 25, WHITE, true, Paint.Align.CENTER);
        button(c, 52, 738, 43, 43, "‹", false, CYAN);
        button(c, 214, 738, 43, 43, "›", false, CYAN);

        label(c, "Frequency (Hz)", 371, 744, 16, SUB, false, Paint.Align.CENTER);
        label(c, freqText(freq), 371, 792, 29, CYAN, true, Paint.Align.CENTER);
        drawLinearTrack(c, 294, 833, 451, logFrac(freq, 20f, 20000f), CYAN, BLUE);

        label(c, "Gain (dB)", 558, 744, 16, SUB, false, Paint.Align.CENTER);
        label(c, signed1(gain), 558, 792, 29, MAGENTA, true, Paint.Align.CENTER);
        drawLinearTrack(c, 482, 833, 637, (gain + 12f) / 24f, MAGENTA, MAGENTA);

        label(c, "Q (Quality)", 746, 744, 16, SUB, false, Paint.Align.CENTER);
        label(c, String.format(Locale.US, "%.1f", q), 746, 792, 29, ORANGE, true, Paint.Align.CENTER);
        drawLinearTrack(c, 670, 833, 824, (q - 0.1f) / 9.9f, ORANGE, ORANGE);
    }

    private void drawXoverLive(Canvas c) {
        String[] ch = {"CH1\nFront L","CH2\nFront R","CH3\nRear L","CH4\nRear R","CH5\nCenter","CH6\nSub L","CH7\nSub R"};
        drawXoverChannelStrip(c, ch);
        drawXoverGraph(c);
        drawXoverControls(c);
    }

    private void drawXoverChannelStrip(Canvas c, String[] labels) {
        mask(27, 455, 811, 80, 17, c);
        float left = 75f;
        float w = 98f;
        for (int i = 0; i < 7; i++) {
            float x = left + i * w;
            p.setStyle(Paint.Style.FILL);
            p.setColor(i == xoverChannel ? Color.rgb(4, 68, 115) : Color.rgb(4, 27, 53));
            c.drawRoundRect(new RectF(x, 457, x + 95, 525), 12, 12, p);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(i == xoverChannel ? 3f : 1.2f);
            stroke.setColor(i == xoverChannel ? CYAN : Color.rgb(22, 68, 110));
            c.drawRoundRect(new RectF(x, 457, x + 95, 525), 12, 12, stroke);
            String[] parts = labels[i].split("\\n");
            label(c, parts[0], x + 47.5f, 485, 17, WHITE, true, Paint.Align.CENTER);
            label(c, parts[1], x + 47.5f, 510, 13, SUB, false, Paint.Align.CENTER);
        }
    }

    private void drawXoverGraph(Canvas c) {
        float gx = 84f, gy = 607f, gw = 728f, gh = 155f;
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.rgb(3, 20, 40));
        c.drawRect(gx, gy, gx + gw, gy + gh, p);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(1f);
        stroke.setColor(Color.rgb(28, 57, 91));
        for (int i = 0; i <= 12; i++) {
            float x = gx + gw * i / 12f;
            c.drawLine(x, gy, x, gy + gh, stroke);
        }
        for (int i = 0; i <= 4; i++) {
            float y = gy + gh * i / 4f;
            c.drawLine(gx, y, gx + gw, y, stroke);
        }

        Path path = new Path();
        for (int i = 0; i <= 120; i++) {
            float frac = i / 120f;
            float freq = (float) Math.exp(Math.log(20f) + frac * (Math.log(20000f) - Math.log(20f)));
            float gain = crossoverGainDb(freq);
            float x = gx + frac * gw;
            float y = gy + clamp(-gain / 48f, 0f, 1f) * gh;
            if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
        }
        stroke.setStrokeWidth(4f);
        stroke.setColor(CYAN);
        stroke.setShadowLayer(10, 0, 0, BLUE);
        c.drawPath(path, stroke);
        stroke.clearShadowLayer();

        float hx = freqToX(hpfHz[xoverChannel], gx, gw);
        float lx = freqToX(lpfHz[xoverChannel], gx, gw);
        p.setColor(CYAN); c.drawCircle(hx, gy + 3, 9, p);
        p.setColor(MAGENTA); c.drawCircle(lx, gy + 3, 9, p);
    }

    private float crossoverGainDb(float f) {
        float gain = 0f;
        if (hpfOn[xoverChannel] && f < hpfHz[xoverChannel]) {
            float oct = (float) (Math.log(hpfHz[xoverChannel] / f) / Math.log(2));
            gain -= oct * slopeDb(hpfSlope[xoverChannel]);
        }
        if (lpfOn[xoverChannel] && f > lpfHz[xoverChannel]) {
            float oct = (float) (Math.log(f / lpfHz[xoverChannel]) / Math.log(2));
            gain -= oct * slopeDb(lpfSlope[xoverChannel]);
        }
        return Math.max(-48f, gain);
    }

    private float slopeDb(int idx) { return new float[]{6f, 12f, 18f, 24f}[clampInt(idx, 0, 3)]; }

    private void drawXoverControls(Canvas c) {
        // HPF
        mask(39, 837, 385, 239, 20, c);
        label(c, "High Pass Filter", 205, 890, 24, WHITE, true, Paint.Align.CENTER);
        toggle(c, 344, 875, hpfOn[xoverChannel], CYAN);
        label(c, "Frequency", 78, 935, 15, SUB, false, Paint.Align.LEFT);
        label(c, freqText(hpfHz[xoverChannel]), 397, 935, 25, WHITE, true, Paint.Align.RIGHT);
        drawLinearTrack(c, 103, 969, 349, logFrac(hpfHz[xoverChannel], 20f, 5000f), CYAN, BLUE);
        drawSlopeButtons(c, 51, 1024, hpfSlope[xoverChannel], CYAN);

        // LPF
        mask(439, 837, 385, 239, 20, c);
        label(c, "Low Pass Filter", 613, 890, 24, WHITE, true, Paint.Align.CENTER);
        toggle(c, 746, 875, lpfOn[xoverChannel], MAGENTA);
        label(c, "Frequency", 478, 935, 15, SUB, false, Paint.Align.LEFT);
        label(c, freqText(lpfHz[xoverChannel]), 798, 935, 25, WHITE, true, Paint.Align.RIGHT);
        drawLinearTrack(c, 516, 969, 765, logFrac(lpfHz[xoverChannel], 80f, 20000f), MAGENTA, MAGENTA);
        drawSlopeButtons(c, 451, 1024, lpfSlope[xoverChannel], MAGENTA);

        // Delay
        mask(30, 1094, 470, 255, 20, c);
        label(c, "Delay", 150, 1143, 24, WHITE, true, Paint.Align.CENTER);
        toggle(c, 430, 1132, true, ORANGE);
        label(c, "Delay Time", 51, 1197, 16, SUB, false, Paint.Align.LEFT);
        label(c, String.format(Locale.US, "%.2f ms", delayMs[xoverChannel]), 468, 1197, 22, WHITE, true, Paint.Align.RIGHT);
        drawLinearTrack(c, 103, 1230, 421, delayMs[xoverChannel] / 20f, ORANGE, ORANGE);
        label(c, "Distance (at 343 m/s)", 51, 1274, 15, SUB, false, Paint.Align.LEFT);
        label(c, String.format(Locale.US, "%.1f cm", delayMs[xoverChannel] * 34.3f), 468, 1274, 20, WHITE, true, Paint.Align.RIGHT);
        drawLinearTrack(c, 103, 1308, 421, delayMs[xoverChannel] / 20f, WHITE, ORANGE);

        // Phase / polarity and link
        mask(514, 1094, 310, 122, 20, c);
        label(c, "Phase / Polarity", 670, 1141, 21, WHITE, true, Paint.Align.CENTER);
        button(c, 623, 1160, 98, 48, "0°", !xoverPhase180[xoverChannel], CYAN);
        button(c, 725, 1160, 86, 48, "180°", xoverPhase180[xoverChannel], CYAN);

        mask(514, 1227, 310, 122, 20, c);
        label(c, "Link Filters", 642, 1275, 22, WHITE, true, Paint.Align.CENTER);
        label(c, "Link HPF & LPF", 642, 1305, 15, SUB, false, Paint.Align.CENTER);
        toggle(c, 760, 1287, linkFilters[xoverChannel], CYAN);
    }

    private void drawSlopeButtons(Canvas c, float x, float y, int selected, int color) {
        String[] names = {"6 dB", "12 dB", "18 dB", "24 dB"};
        for (int i = 0; i < 4; i++) button(c, x + i * 88f, y, 78, 44, names[i], i == selected, color);
    }

    private void toggle(Canvas c, float cx, float cy, boolean on, int color) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(on ? Color.argb(210, Color.red(color), Color.green(color), Color.blue(color)) : Color.rgb(20, 52, 87));
        c.drawRoundRect(new RectF(cx - 34, cy - 20, cx + 34, cy + 20), 20, 20, p);
        p.setColor(WHITE);
        c.drawCircle(on ? cx + 15 : cx - 15, cy, 16, p);
    }

    private void button(Canvas c, float x, float y, float w, float h, String text, boolean selected, int color) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(selected ? Color.argb(220, Color.red(color), Color.green(color), Color.blue(color)) : Color.rgb(6, 32, 61));
        c.drawRoundRect(new RectF(x, y, x + w, y + h), 10, 10, p);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(selected ? 2.5f : 1.2f);
        stroke.setColor(selected ? color : Color.rgb(25, 83, 135));
        c.drawRoundRect(new RectF(x, y, x + w, y + h), 10, 10, stroke);
        label(c, text, x + w / 2f, y + h / 2f + 7, Math.min(18f, h * 0.42f), WHITE, selected, Paint.Align.CENTER);
    }

    private void drawPresetSelection(Canvas c, float x, float y, float w, float h, int selected, int count) {
        float gap = 10f;
        for (int i = 0; i < count; i++) {
            float xx = x + i * (w + gap);
            if (i == selected) {
                stroke.setStyle(Paint.Style.STROKE);
                stroke.setStrokeWidth(3f);
                stroke.setColor(CYAN);
                stroke.setShadowLayer(14, 0, 0, CYAN);
                c.drawRoundRect(new RectF(xx, y, xx + w, y + h), 18, 18, stroke);
                stroke.clearShadowLayer();
            }
        }
    }

    private void drawDbSlider(Canvas c, float x1, float y, float x2, float value, float min, float max, int c1, int c2) {
        drawLinearTrack(c, x1, y, x2, (value - min) / (max - min), c1, c2);
    }

    private void drawLogSlider(Canvas c, float x1, float y, float x2, float value, float min, float max, int c1, int c2) {
        drawLinearTrack(c, x1, y, x2, logFrac(value, min, max), c1, c2);
    }

    private void drawLinearTrack(Canvas c, float x1, float y, float x2, float frac, int c1, int c2) {
        frac = clamp(frac, 0f, 1f);
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        p.setColor(PANEL);
        c.drawRoundRect(new RectF(x1 - 9, y - 18, x2 + 9, y + 18), 16, 16, p);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeWidth(12f);
        stroke.setColor(TRACK);
        c.drawLine(x1, y, x2, y, stroke);
        float knob = x1 + (x2 - x1) * frac;
        if (knob > x1 + 1f) {
            p.setShader(new LinearGradient(x1, y, knob, y, c1, c2, Shader.TileMode.CLAMP));
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(12f);
            p.setStrokeCap(Paint.Cap.ROUND);
            c.drawLine(x1, y, knob, y, p);
            p.setShader(null);
        }
        p.setStyle(Paint.Style.FILL);
        p.setColor(WHITE);
        p.setShadowLayer(10, 0, 0, c2);
        c.drawCircle(knob, y, 18f, p);
        p.clearShadowLayer();
        stroke.setStrokeCap(Paint.Cap.BUTT);
    }

    private void mask(float x, float y, float w, float h, float r, Canvas c) {
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        p.setColor(PANEL);
        c.drawRoundRect(new RectF(x, y, x + w, y + h), r, r, p);
    }

    private void label(Canvas c, String text, float x, float y, float size, int color, boolean bold, Paint.Align align) {
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        p.setTextSize(size);
        p.setTextAlign(align);
        p.setTypeface(android.graphics.Typeface.create("sans", bold ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL));
        c.drawText(text, x, y, p);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (getWidth() <= 0 || getHeight() <= 0) return true;
        float x = event.getX() * RW / getWidth();
        float y = event.getY() * RH / getHeight();
        int action = event.getActionMasked();

        if (action == MotionEvent.ACTION_DOWN) {
            dragKind = 0;
            dragIndex = -1;

            if (y >= 1380f) {
                page = clampInt((int) (x / (RW / 4f)), 0, 3);
                invalidate();
                return true;
            }
            if (x >= 744 && y <= 115) {
                toast("Phase 1: UI mode • DSP control will be connected in Phase 2");
                return true;
            }

            if (page == PAGE_HOME) handleHomeDown(x, y);
            else if (page == PAGE_MIX) handleMixDown(x, y);
            else if (page == PAGE_EQ) handleEqDown(x, y);
            else handleXoverDown(x, y);
            return true;
        }

        if (action == MotionEvent.ACTION_MOVE) {
            if (page == PAGE_HOME && dragKind == 1) updateHomeMaster(x);
            else if (page == PAGE_MIX && dragKind == 2) updateMixSlider(dragIndex, x);
            else if (page == PAGE_EQ) updateEqDrag(x, y);
            else if (page == PAGE_XOVER) updateXoverDrag(x, y);
            invalidate();
            return true;
        }

        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            dragKind = 0;
            dragIndex = -1;
            invalidate();
            return true;
        }
        return true;
    }

    private void handleHomeDown(float x, float y) {
        if (y >= 580 && y <= 650) {
            dragKind = 1;
            updateHomeMaster(x);
            invalidate();
            return;
        }
        if (y >= 705 && y <= 852) {
            page = x < 432 ? PAGE_MIX : PAGE_EQ;
            invalidate();
            return;
        }
        if (y >= 860 && y <= 1012) {
            if (x < 432) page = PAGE_XOVER;
            else { state.saveHome(getContext()); toast("Preset saved locally"); }
            invalidate();
            return;
        }
        if (y >= 1070 && y <= 1190) {
            int idx = clampInt((int) ((x - 44) / 160f), 0, 4);
            homeQuickPreset = idx;
            applyQuickPreset(idx);
            invalidate();
        }
    }

    private void updateHomeMaster(float x) {
        state.masterVolume = round1(-60f + clamp((x - 181f) / (805f - 181f), 0f, 1f) * 66f);
    }

    private void handleMixDown(float x, float y) {
        float[] ys = {389, 557, 716, 872, 1028, 1190};
        for (int i = 0; i < ys.length; i++) {
            if (Math.abs(y - ys[i]) <= 46f) {
                dragKind = 2;
                dragIndex = i;
                updateMixSlider(i, x);
                invalidate();
                return;
            }
        }
    }

    private void updateMixSlider(int i, float x) {
        float f = clamp((x - 181f) / (804f - 181f), 0f, 1f);
        if (i == 0) state.masterVolume = round1(-60f + f * 66f);
        else if (i == 1) state.bassVolume = round1(-20f + f * 40f);
        else if (i == 2) state.bassCutoff = Math.round(expLerp(20f, 320f, f));
        else if (i == 3) state.bassBoost = round1(-12f + f * 24f);
        else if (i == 4) state.middleBoost = round1(-12f + f * 24f);
        else state.trebleBoost = round1(-12f + f * 24f);
    }

    private void handleEqDown(float x, float y) {
        if (y >= 245 && y <= 355) {
            int ch = clampInt((int) ((x - 28) / 116f), 0, 6);
            state.channel = ch;
            invalidate();
            return;
        }
        if (y >= 420 && y <= 680) {
            state.selectedBand = nearestEqBand(x, y);
            dragKind = 3;
            updateEqGraphPoint(x, y);
            invalidate();
            return;
        }
        if (y >= 720 && y <= 810 && x < 280) {
            if (x < 135) state.selectedBand = (state.selectedBand + DspState.BANDS - 1) % DspState.BANDS;
            else state.selectedBand = (state.selectedBand + 1) % DspState.BANDS;
            invalidate();
            return;
        }
        if (y >= 810 && y <= 865) {
            if (x >= 275 && x <= 465) { dragKind = 4; updateEqFrequency(x); }
            else if (x >= 470 && x <= 650) { dragKind = 5; updateEqGain(x); }
            else if (x >= 655 && x <= 838) { dragKind = 6; updateEqQ(x); }
            invalidate();
            return;
        }
        if (y >= 970 && y <= 1050 && x >= 145 && x <= 700) {
            dragKind = 7;
            updateEqFader(x);
            invalidate();
            return;
        }
        if (y >= 1090 && y <= 1215) {
            if (x < 430) { state.saveEq(getContext()); toast("EQ preset saved locally"); }
            else { boolean ok = state.loadEq(getContext()); toast(ok ? "EQ preset loaded" : "No saved EQ preset yet"); }
            invalidate();
            return;
        }
        if (y >= 1240 && y <= 1375) {
            int idx = clampInt((int) ((x - 40) / 162f), 0, 4);
            eqQuickPreset = idx;
            applyEqPreset(idx);
            invalidate();
        }
    }

    private void updateEqDrag(float x, float y) {
        if (dragKind == 3) updateEqGraphPoint(x, y);
        else if (dragKind == 4) updateEqFrequency(x);
        else if (dragKind == 5) updateEqGain(x);
        else if (dragKind == 6) updateEqQ(x);
        else if (dragKind == 7) updateEqFader(x);
    }

    private int nearestEqBand(float x, float y) {
        float gx = 77f, gy = 432f, gw = 731f, gh = 230f;
        int best = 0;
        float bestD = Float.MAX_VALUE;
        for (int b = 0; b < DspState.BANDS; b++) {
            float px = freqToX(state.freq[state.channel][b], gx, gw);
            float py = gainToY(state.gain[state.channel][b], gy, gh);
            float dx = px - x, dy = py - y;
            float d = dx * dx + dy * dy;
            if (d < bestD) { bestD = d; best = b; }
        }
        return best;
    }

    private void updateEqGraphPoint(float x, float y) {
        float gx = 77f, gy = 432f, gw = 731f, gh = 230f;
        int b = state.selectedBand;
        float xf = clamp((x - gx) / gw, 0f, 1f);
        float yf = clamp((y - gy) / gh, 0f, 1f);
        state.freq[state.channel][b] = roundHz(expLerp(20f, 20000f, xf));
        state.gain[state.channel][b] = round1(12f - yf * 24f);
    }

    private void updateEqFrequency(float x) {
        float f = clamp((x - 294f) / (451f - 294f), 0f, 1f);
        state.freq[state.channel][state.selectedBand] = roundHz(expLerp(20f, 20000f, f));
    }

    private void updateEqGain(float x) {
        float f = clamp((x - 482f) / (637f - 482f), 0f, 1f);
        state.gain[state.channel][state.selectedBand] = round1(-12f + f * 24f);
    }

    private void updateEqQ(float x) {
        float f = clamp((x - 670f) / (824f - 670f), 0f, 1f);
        state.q[state.channel][state.selectedBand] = round1(0.1f + f * 9.9f);
    }

    private void updateEqFader(float x) {
        float f = clamp((x - 160f) / (680f - 160f), 0f, 1f);
        state.fader[state.channel] = round1(-60f + f * 66f);
    }

    private void handleXoverDown(float x, float y) {
        if (y >= 448 && y <= 535) {
            int ch = clampInt((int) ((x - 75f) / 98f), 0, 6);
            xoverChannel = ch;
            invalidate();
            return;
        }
        if (y >= 850 && y <= 910) {
            if (x < 430) hpfOn[xoverChannel] = !hpfOn[xoverChannel];
            else lpfOn[xoverChannel] = !lpfOn[xoverChannel];
            invalidate();
            return;
        }
        if (y >= 940 && y <= 995) {
            if (x < 430) { dragKind = 8; updateHpf(x); }
            else { dragKind = 9; updateLpf(x); }
            invalidate();
            return;
        }
        if (y >= 1010 && y <= 1080) {
            if (x < 430) hpfSlope[xoverChannel] = clampInt((int) ((x - 51f) / 88f), 0, 3);
            else lpfSlope[xoverChannel] = clampInt((int) ((x - 451f) / 88f), 0, 3);
            invalidate();
            return;
        }
        if (y >= 1205 && y <= 1255 && x < 500) {
            dragKind = 10;
            updateDelay(x);
            invalidate();
            return;
        }
        if (y >= 1285 && y <= 1335 && x < 500) {
            dragKind = 10;
            updateDelay(x);
            invalidate();
            return;
        }
        if (y >= 1145 && y <= 1220 && x >= 600) {
            xoverPhase180[xoverChannel] = x >= 720;
            invalidate();
            return;
        }
        if (y >= 1235 && y <= 1345 && x >= 690) {
            linkFilters[xoverChannel] = !linkFilters[xoverChannel];
            invalidate();
        }
    }

    private void updateXoverDrag(float x, float y) {
        if (dragKind == 8) updateHpf(x);
        else if (dragKind == 9) updateLpf(x);
        else if (dragKind == 10) updateDelay(x);
    }

    private void updateHpf(float x) {
        float f = clamp((x - 103f) / (349f - 103f), 0f, 1f);
        hpfHz[xoverChannel] = roundHz(expLerp(20f, 5000f, f));
        if (linkFilters[xoverChannel] && hpfHz[xoverChannel] > lpfHz[xoverChannel]) lpfHz[xoverChannel] = hpfHz[xoverChannel];
    }

    private void updateLpf(float x) {
        float f = clamp((x - 516f) / (765f - 516f), 0f, 1f);
        lpfHz[xoverChannel] = roundHz(expLerp(80f, 20000f, f));
        if (linkFilters[xoverChannel] && lpfHz[xoverChannel] < hpfHz[xoverChannel]) hpfHz[xoverChannel] = lpfHz[xoverChannel];
    }

    private void updateDelay(float x) {
        float f = clamp((x - 103f) / (421f - 103f), 0f, 1f);
        delayMs[xoverChannel] = Math.round(f * 2000f) / 100f;
    }

    private void applyQuickPreset(int idx) {
        if (idx == 0) {
            state.bassVolume = 0f; state.bassCutoff = 80f; state.bassBoost = 0f; state.middleBoost = 0f; state.trebleBoost = 0f;
        } else if (idx == 1) {
            state.bassVolume = 2f; state.bassCutoff = 90f; state.bassBoost = 2f; state.middleBoost = 1f; state.trebleBoost = 3f;
        } else if (idx == 2) {
            state.bassVolume = 4f; state.bassCutoff = 80f; state.bassBoost = 5f; state.middleBoost = 2f; state.trebleBoost = 2f;
        } else if (idx == 3) {
            state.bassVolume = 0f; state.bassCutoff = 100f; state.bassBoost = 0f; state.middleBoost = 4f; state.trebleBoost = 2f;
        }
        applyEqPreset(idx);
    }

    private void applyEqPreset(int idx) {
        for (int c = 0; c < DspState.CHANNELS; c++) {
            for (int b = 0; b < DspState.BANDS; b++) {
                float t = b / (float) (DspState.BANDS - 1);
                float v;
                if (idx == 0) v = 0f;
                else if (idx == 1) v = 3f * (float) Math.sin(t * Math.PI * 2f - 0.6f);
                else if (idx == 2) v = 5f * Math.abs(t - 0.5f) - 1.5f;
                else if (idx == 3) v = 4f - 14f * Math.abs(t - 0.55f);
                else continue; // Custom keeps current values.
                state.gain[c][b] = round1(clamp(v, -12f, 12f));
            }
        }
    }

    private float freqToX(float freq, float x, float w) {
        return x + logFrac(freq, 20f, 20000f) * w;
    }

    private float gainToY(float gain, float y, float h) {
        return y + clamp((12f - gain) / 24f, 0f, 1f) * h;
    }

    private float logFrac(float v, float min, float max) {
        v = clamp(v, min, max);
        return (float) ((Math.log(v) - Math.log(min)) / (Math.log(max) - Math.log(min)));
    }

    private float expLerp(float min, float max, float f) {
        return (float) Math.exp(Math.log(min) + clamp(f, 0f, 1f) * (Math.log(max) - Math.log(min)));
    }

    private float roundHz(float v) {
        if (v < 100f) return Math.round(v);
        if (v < 1000f) return Math.round(v / 5f) * 5f;
        return Math.round(v / 10f) * 10f;
    }

    private String db(float v) { return String.format(Locale.US, "%+.1f dB", v); }
    private String signed1(float v) { return String.format(Locale.US, "%+.1f", v); }

    private String freqText(float hz) {
        if (hz >= 1000f) {
            float k = hz / 1000f;
            return k >= 10f ? String.format(Locale.US, "%.1f kHz", k) : String.format(Locale.US, "%.2f kHz", k);
        }
        return String.format(Locale.US, "%.0f Hz", hz);
    }

    private int bandColor(int b) {
        int[] colors = {CYAN, CYAN, CYAN, BLUE, CYAN, BLUE, Color.rgb(104, 110, 255), MAGENTA,
                MAGENTA, MAGENTA, MAGENTA, Color.rgb(255, 86, 189), ORANGE, ORANGE, ORANGE};
        return colors[clampInt(b, 0, colors.length - 1)];
    }

    private float round1(float v) { return Math.round(v * 10f) / 10f; }
    private float clamp(float v, float lo, float hi) { return Math.max(lo, Math.min(hi, v)); }
    private int clampInt(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }
    private void toast(String s) { Toast.makeText(getContext(), s, Toast.LENGTH_SHORT).show(); }
}
