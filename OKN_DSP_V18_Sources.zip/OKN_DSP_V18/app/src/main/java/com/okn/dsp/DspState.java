package com.okn.dsp;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Locale;

/** Runtime UI state for the five reference screens. */
final class DspState {
    static final int CHANNELS = 7;
    static final int BANDS = 15;

    float masterVolume = -3f;
    float bassVolume = 4f;
    float bassCutoff = 100f;
    float bassBoost = 3f;
    float middleBoost = -2f;
    float trebleBoost = 1f;
    int audioSource = 0;
    int homePreset = 0;

    final float[][] freq = new float[CHANNELS][BANDS];
    final float[][] gain = new float[CHANNELS][BANDS];
    final float[][] q = new float[CHANNELS][BANDS];
    final int[][] eqType = new int[CHANNELS][BANDS];
    final boolean[][] eqWritable = new boolean[CHANNELS][BANDS];
    final boolean[][] eqPower = new boolean[CHANNELS][BANDS];

    final boolean[] hpfBypass = new boolean[CHANNELS];
    final boolean[] lpfBypass = new boolean[CHANNELS];
    final int[] hpfType = new int[CHANNELS];
    final int[] lpfType = new int[CHANNELS];
    final float[] hpfFreq = new float[CHANNELS];
    final float[] lpfFreq = new float[CHANNELS];
    final int[] hpfSlope = new int[CHANNELS];
    final int[] lpfSlope = new int[CHANNELS];
    final int[] crossoverPhase = new int[CHANNELS];
    final boolean[] polarityInvert = new boolean[CHANNELS];
    final boolean[] linkLR = new boolean[CHANNELS];
    final int[] outputMode = new int[CHANNELS];

    final float[] delayMs = new float[CHANNELS];
    int delayUnit = 0; // 0 ms, 1 cm
    int seatPreset = 0;

    float masterOutput = -1f;
    final float[] outputGain = new float[CHANNELS];
    final boolean[] mute = new boolean[CHANNELS];
    final boolean[] solo = new boolean[CHANNELS];
    final boolean[] phase180 = new boolean[CHANNELS];
    final boolean[] outputLink = new boolean[CHANNELS];

    int channel = 0;
    int selectedBand = 0;
    int eqBank = 0;
    int eqPreset = 0;

    static final String[] CHANNEL_NAME = {
            "Front L", "Front R", "Rear L", "Rear R", "Center", "Sub L", "Sub R"
    };
    static final String[] CHANNEL_TAB = {
            "CH1\nFront L", "CH2\nFront R", "CH3\nRear L", "CH4\nRear R", "CH5\nCenter", "CH6\nSub L", "CH7\nSub R"
    };

    private static final float[] DEFAULT_15 = {
            32f, 50f, 80f, 125f, 200f, 315f, 500f, 800f,
            1250f, 2000f, 3150f, 5000f, 8000f, 12500f, 16000f
    };

    DspState() {
        for (int c = 0; c < CHANNELS; c++) {
            for (int b = 0; b < BANDS; b++) {
                freq[c][b] = DEFAULT_15[b];
                gain[c][b] = 0f;
                q[c][b] = 1.0f;
                eqType[c][b] = DspProtocol.EQ_PEAKING_TYPE;
                eqWritable[c][b] = false;
                eqPower[c][b] = true;
            }
            hpfBypass[c] = false;
            lpfBypass[c] = false;
            hpfType[c] = 0;
            lpfType[c] = 0;
            hpfFreq[c] = 100f;
            lpfFreq[c] = 1000f;
            hpfSlope[c] = 2; // 24 dB/Oct
            lpfSlope[c] = 2;
            crossoverPhase[c] = 0;
            polarityInvert[c] = false;
            linkLR[c] = c == 0 || c == 1;
            outputMode[c] = 0;
            outputGain[c] = new float[]{-3f,-2.5f,-4f,-1f,-2f,-3.5f,-4.5f}[c];
            mute[c] = false;
            solo[c] = false;
            phase180[c] = false;
            outputLink[c] = c == 0 || c == 1;
        }
        float[] d = {0f,1.25f,2.60f,2.30f,0.80f,3.10f,1.90f};
        System.arraycopy(d, 0, delayMs, 0, CHANNELS);
    }

    void applyHomePreset(int preset) {
        homePreset = preset;
        switch (preset) {
            case 1: // Pop
                bassVolume = 2f; bassCutoff = 100f; bassBoost = 2f; middleBoost = 1f; trebleBoost = 3f; break;
            case 2: // Rock
                bassVolume = 4f; bassCutoff = 90f; bassBoost = 4f; middleBoost = 2f; trebleBoost = 2f; break;
            case 3: // Jazz
                bassVolume = 2f; bassCutoff = 110f; bassBoost = 1f; middleBoost = 2f; trebleBoost = 3f; break;
            default:
                bassVolume = 0f; bassCutoff = 100f; bassBoost = 0f; middleBoost = 0f; trebleBoost = 0f; break;
        }
    }

    void saveHome(Context context) {
        SharedPreferences.Editor e = context.getSharedPreferences("okn_dsp_home", Context.MODE_PRIVATE).edit();
        e.putFloat("master", masterVolume).putFloat("bass", bassVolume).putFloat("cutoff", bassCutoff)
                .putFloat("bassboost", bassBoost).putFloat("middle", middleBoost).putFloat("treble", trebleBoost)
                .putInt("source", audioSource).putInt("preset", homePreset).apply();
    }

    boolean loadHome(Context context) {
        SharedPreferences p = context.getSharedPreferences("okn_dsp_home", Context.MODE_PRIVATE);
        if (!p.contains("master")) return false;
        masterVolume = p.getFloat("master", -3f); bassVolume = p.getFloat("bass", 4f);
        bassCutoff = p.getFloat("cutoff", 100f); bassBoost = p.getFloat("bassboost", 3f);
        middleBoost = p.getFloat("middle", -2f); trebleBoost = p.getFloat("treble", 1f);
        audioSource = p.getInt("source", 0); homePreset = p.getInt("preset", 0);
        return true;
    }

    void saveEq(Context context) {
        SharedPreferences.Editor e = context.getSharedPreferences("okn_dsp_eq", Context.MODE_PRIVATE).edit();
        for (int c = 0; c < CHANNELS; c++) for (int b = 0; b < BANDS; b++) {
            e.putFloat("f_"+c+'_'+b, freq[c][b]).putFloat("g_"+c+'_'+b, gain[c][b])
                    .putFloat("q_"+c+'_'+b, q[c][b]).putBoolean("p_"+c+'_'+b, eqPower[c][b]);
        }
        e.putInt("preset", eqPreset).putBoolean("saved", true).apply();
    }

    boolean loadEq(Context context) {
        SharedPreferences p = context.getSharedPreferences("okn_dsp_eq", Context.MODE_PRIVATE);
        if (!p.getBoolean("saved", false)) return false;
        for (int c = 0; c < CHANNELS; c++) for (int b = 0; b < BANDS; b++) {
            freq[c][b] = p.getFloat("f_"+c+'_'+b, freq[c][b]); gain[c][b] = p.getFloat("g_"+c+'_'+b, gain[c][b]);
            q[c][b] = p.getFloat("q_"+c+'_'+b, q[c][b]); eqPower[c][b] = p.getBoolean("p_"+c+'_'+b, true);
        }
        eqPreset = p.getInt("preset", 0);
        return true;
    }

    static String db(float v) { return String.format(Locale.US, "%.1f dB", v); }
    static String hz(float v) {
        if (v >= 1000f) return String.format(Locale.US, v >= 10000f ? "%.0f kHz" : "%.1f kHz", v / 1000f);
        return String.format(Locale.US, "%.0f Hz", v);
    }
    static String q(float v) { return String.format(Locale.US, "%.2f", v); }
    static String delay(float ms) { return String.format(Locale.US, "%.2f ms", ms); }
    static String distance(float ms) { return String.format(Locale.US, "%.1f cm", ms * 34.3f); }
}
