package com.okn.dsp;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Locale;

final class DspState {
    static final int CHANNELS = 7;
    static final int BANDS = 15;

    static final String[] CH_SHORT = {"CH1\nFront L", "CH2\nFront R", "CH3\nRear L", "CH4\nRear R", "CH5\nCenter", "CH6\nSub L", "CH7\nSub R"};
    static final String[] CH_NAME = {"Front L", "Front R", "Rear L", "Rear R", "Center", "Sub L", "Sub R"};
    static final String[] EQ_TYPES = {"PEQ", "Low Shelf", "High Shelf"};
    static final String[] FILTER_TYPES = {"Linkwitz-Riley", "Butterworth", "Bessel"};
    static final String[] FILTER_SLOPES = {"12 dB/Oct", "18 dB/Oct", "24 dB/Oct", "36 dB/Oct", "48 dB/Oct"};
    static final String[] PRESETS = {"Flat", "Custom 1", "Pop", "Rock", "Jazz"};
    static final String[] SOURCES = {"High Level (Speaker)", "Low Level (RCA)", "Bluetooth"};
    static final String[] SEATS = {"Driver (Left)", "Passenger (Right)", "Front Center", "Rear Center"};

    int page = 0; // Home, EQ, Crossover, Delay, Output
    int channel = 0;

    float masterVolume = -3f;
    float bassVolume = 4f;
    float bassCutoff = 100f;
    float bassBoost = 3f;
    float middleBoost = -2f;
    float trebleBoost = 1f;
    int audioSource = 0;
    int systemPreset = 0;

    final float[][] eqFreq = new float[CHANNELS][BANDS];
    final float[][] eqGain = new float[CHANNELS][BANDS];
    final float[][] eqQ = new float[CHANNELS][BANDS];
    final int[][] eqType = new int[CHANNELS][BANDS];
    final boolean[][] eqPower = new boolean[CHANNELS][BANDS];
    final boolean[][] eqWritable = new boolean[CHANNELS][BANDS];
    int eqPage = 0;
    int eqPreset = 1;

    final boolean[] hpfBypass = new boolean[CHANNELS];
    final boolean[] lpfBypass = new boolean[CHANNELS];
    final float[] hpfFreq = new float[CHANNELS];
    final float[] lpfFreq = new float[CHANNELS];
    final int[] hpfType = new int[CHANNELS];
    final int[] lpfType = new int[CHANNELS];
    final int[] hpfSlope = new int[CHANNELS];
    final int[] lpfSlope = new int[CHANNELS];
    final int[] phaseDeg = new int[CHANNELS];
    final boolean[] polarityInvert = new boolean[CHANNELS];
    boolean linkLR = true;
    int outputMode = 0;

    final float[] delayMs = new float[CHANNELS];
    boolean delayUnitMs = true;
    int seatPreset = 0;
    float speedOfSound = 343f;

    float masterOutput = -1f;
    final float[] outputDb = new float[CHANNELS];
    final boolean[] mute = new boolean[CHANNELS];
    final boolean[] solo = new boolean[CHANNELS];
    final boolean[] outPhase = new boolean[CHANNELS];
    final boolean[] outLink = new boolean[CHANNELS];

    private static final float[] DEFAULT_15 = {
            32f, 50f, 80f, 100f, 200f, 315f, 500f, 800f,
            1250f, 2000f, 3150f, 5000f, 8000f, 10000f, 16000f
    };

    DspState() {
        for (int c = 0; c < CHANNELS; c++) {
            for (int b = 0; b < BANDS; b++) {
                eqFreq[c][b] = DEFAULT_15[b];
                eqGain[c][b] = 0f;
                eqQ[c][b] = 1f;
                eqType[c][b] = 0;
                eqPower[c][b] = true;
                eqWritable[c][b] = false;
            }
            hpfFreq[c] = 100f;
            lpfFreq[c] = (c >= 5) ? 1000f : 20000f;
            hpfType[c] = 0;
            lpfType[c] = 0;
            hpfSlope[c] = 2;
            lpfSlope[c] = 2;
            phaseDeg[c] = 0;
            delayMs[c] = new float[]{0f,1.25f,2.60f,2.30f,0.80f,3.10f,1.90f}[c];
            outputDb[c] = new float[]{-3f,-2.5f,-4f,-1f,-2f,-3.5f,-4.5f}[c];
            outLink[c] = c < 2;
        }
        // Reference-screen starting curve for CH1.
        float[] g = {-3f, 0f, 3f, 2.5f, 6f, 2f, -4f, -1f, 1.5f, 3f, 1f, 5f, 1f, -2f, 2f};
        for (int b = 0; b < BANDS; b++) eqGain[0][b] = g[b];
    }

    void flattenEq(int ch) {
        for (int b = 0; b < BANDS; b++) eqGain[ch][b] = 0f;
    }

    void resetCrossover(int ch) {
        hpfBypass[ch] = false;
        lpfBypass[ch] = false;
        hpfFreq[ch] = 100f;
        lpfFreq[ch] = 1000f;
        hpfType[ch] = lpfType[ch] = 0;
        hpfSlope[ch] = lpfSlope[ch] = 2;
        phaseDeg[ch] = 0;
        polarityInvert[ch] = false;
    }

    void resetOutput() {
        masterOutput = -1f;
        float[] v = {-3f,-2.5f,-4f,-1f,-2f,-3.5f,-4.5f};
        for (int c=0;c<CHANNELS;c++) {
            outputDb[c]=v[c]; mute[c]=false; solo[c]=false; outPhase[c]=false;
        }
    }

    float delayCm(int ch) { return delayMs[ch] * speedOfSound / 10f; }

    void save(Context context) {
        SharedPreferences.Editor e = context.getSharedPreferences("okn_dsp_v18", Context.MODE_PRIVATE).edit();
        e.putFloat("master", masterVolume).putFloat("bassVolume", bassVolume).putFloat("bassCutoff", bassCutoff)
                .putFloat("bassBoost", bassBoost).putFloat("middleBoost", middleBoost).putFloat("trebleBoost", trebleBoost)
                .putInt("audioSource", audioSource).putInt("systemPreset", systemPreset).putFloat("masterOutput", masterOutput)
                .putBoolean("saved", true);
        for (int c=0;c<CHANNELS;c++) {
            e.putFloat("delay_"+c, delayMs[c]).putFloat("out_"+c, outputDb[c]);
            e.putBoolean("mute_"+c,mute[c]).putBoolean("solo_"+c,solo[c]).putBoolean("phase_"+c,outPhase[c]);
            e.putFloat("hpf_"+c,hpfFreq[c]).putFloat("lpf_"+c,lpfFreq[c]);
            for (int b=0;b<BANDS;b++) {
                e.putFloat("ef_"+c+"_"+b,eqFreq[c][b]);
                e.putFloat("eg_"+c+"_"+b,eqGain[c][b]);
                e.putFloat("eq_"+c+"_"+b,eqQ[c][b]);
                e.putBoolean("ep_"+c+"_"+b,eqPower[c][b]);
            }
        }
        e.apply();
    }

    void load(Context context) {
        SharedPreferences p = context.getSharedPreferences("okn_dsp_v18", Context.MODE_PRIVATE);
        if (!p.getBoolean("saved", false)) return;
        masterVolume=p.getFloat("master",masterVolume); bassVolume=p.getFloat("bassVolume",bassVolume);
        bassCutoff=p.getFloat("bassCutoff",bassCutoff); bassBoost=p.getFloat("bassBoost",bassBoost);
        middleBoost=p.getFloat("middleBoost",middleBoost); trebleBoost=p.getFloat("trebleBoost",trebleBoost);
        audioSource=p.getInt("audioSource",audioSource); systemPreset=p.getInt("systemPreset",systemPreset);
        masterOutput=p.getFloat("masterOutput",masterOutput);
        for(int c=0;c<CHANNELS;c++) {
            delayMs[c]=p.getFloat("delay_"+c,delayMs[c]); outputDb[c]=p.getFloat("out_"+c,outputDb[c]);
            mute[c]=p.getBoolean("mute_"+c,mute[c]); solo[c]=p.getBoolean("solo_"+c,solo[c]); outPhase[c]=p.getBoolean("phase_"+c,outPhase[c]);
            hpfFreq[c]=p.getFloat("hpf_"+c,hpfFreq[c]); lpfFreq[c]=p.getFloat("lpf_"+c,lpfFreq[c]);
            for(int b=0;b<BANDS;b++) {
                eqFreq[c][b]=p.getFloat("ef_"+c+"_"+b,eqFreq[c][b]); eqGain[c][b]=p.getFloat("eg_"+c+"_"+b,eqGain[c][b]);
                eqQ[c][b]=p.getFloat("eq_"+c+"_"+b,eqQ[c][b]); eqPower[c][b]=p.getBoolean("ep_"+c+"_"+b,eqPower[c][b]);
            }
        }
    }

    static float clamp(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}
    static float round1(float v){return Math.round(v*10f)/10f;}
    static String db(float v){return String.format(Locale.US,"%.1f dB",v);}
    static String hz(float v){return v>=1000f?String.format(Locale.US,"%.1f kHz",v/1000f):String.format(Locale.US,"%.0f Hz",v);}
}
