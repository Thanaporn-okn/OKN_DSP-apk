package com.okn.dsp;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Locale;

final class DspState {
    static final int CHANNELS = 7;
    static final int BANDS = 15;

    float masterVolume = -3f;
    float bassVolume = 4f;
    float bassCutoff = 100f;
    float bassBoost = 3f;
    float middleBoost = -2f;
    float trebleBoost = 1f;
    int homePreset = 0;
    int audioSource = 0;

    final float[][] freq = new float[CHANNELS][BANDS];
    final float[][] gain = new float[CHANNELS][BANDS];
    final float[][] q = new float[CHANNELS][BANDS];
    final boolean[][] eqWritable = new boolean[CHANNELS][BANDS];
    final boolean[][] eqPower = new boolean[CHANNELS][BANDS];
    final int[][] eqType = new int[CHANNELS][BANDS];

    // Output levels are intentionally kept as UI state until a verified hardware
    // actuator mapping is available in the uploaded protocol evidence.
    final float[] fader = new float[CHANNELS];
    final boolean[] mute = new boolean[CHANNELS];
    final boolean[] solo = new boolean[CHANNELS];
    final boolean[] phase180 = new boolean[CHANNELS];
    final boolean[] link = new boolean[CHANNELS];
    float masterOutput = -1f;

    final float[] delayMs = {0.00f, 1.25f, 2.60f, 2.30f, 0.80f, 3.10f, 1.90f};
    boolean delayUnitMs = true;
    int seatPreset = 0;

    final boolean[] hpfBypass = new boolean[CHANNELS];
    final boolean[] lpfBypass = new boolean[CHANNELS];
    final float[] hpfFreq = new float[CHANNELS];
    final float[] lpfFreq = new float[CHANNELS];
    final int[] hpfSlope = new int[CHANNELS];
    final int[] lpfSlope = new int[CHANNELS];
    final int[] hpfType = new int[CHANNELS];
    final int[] lpfType = new int[CHANNELS];
    final int[] phaseDeg = new int[CHANNELS];
    final boolean[] polarityInvert = new boolean[CHANNELS];
    final boolean[] linkLR = new boolean[CHANNELS];
    final int[] outputMode = new int[CHANNELS];

    int channel = 0;
    int selectedBand = 0;
    int eqGroup = 0;

    static final String[] CHANNEL_SHORT = {
            "CH1\nFront L", "CH2\nFront R", "CH3\nRear L", "CH4\nRear R",
            "CH5\nCenter", "CH6\nSub L", "CH7\nSub R"
    };
    static final String[] CHANNEL_LONG = {
            "CH1 - Front L", "CH2 - Front R", "CH3 - Rear L", "CH4 - Rear R",
            "CH5 - Center", "CH6 - Sub L", "CH7 - Sub R"
    };
    static final String[] CHANNEL_NAME = {"Front L", "Front R", "Rear L", "Rear R", "Center", "Sub L", "Sub R"};
    static final String[] EQ_TYPES = {"PEQ", "Low Shelf", "High Shelf"};
    static final String[] FILTER_TYPES = {"Linkwitz-Riley", "Butterworth", "Bessel"};
    static final String[] SLOPES = {"6 dB/Oct", "12 dB/Oct", "18 dB/Oct", "24 dB/Oct", "36 dB/Oct", "48 dB/Oct"};

    private static final float[] DEFAULT_15 = {
            32f, 50f, 100f, 200f, 500f, 1000f, 2000f, 5000f,
            10000f, 12500f, 14000f, 16000f, 18000f, 19000f, 20000f
    };

    DspState() {
        float[] outputDefaults = {-3f, -2.5f, -4f, -1f, -2f, -3.5f, -4.5f};
        for (int c = 0; c < CHANNELS; c++) {
            resetEq(c);
            fader[c] = outputDefaults[c];
            mute[c] = false;
            solo[c] = false;
            phase180[c] = false;
            link[c] = c < 2;
            hpfFreq[c] = 100f;
            lpfFreq[c] = 1000f;
            hpfSlope[c] = 3;
            lpfSlope[c] = 3;
            hpfType[c] = 0;
            lpfType[c] = 0;
            phaseDeg[c] = 0;
            polarityInvert[c] = false;
            linkLR[c] = true;
            outputMode[c] = 0;
        }
    }

    void resetEq(int c) {
        for (int b = 0; b < BANDS; b++) {
            freq[c][b] = DEFAULT_15[b];
            gain[c][b] = 0f;
            q[c][b] = 1f;
            eqWritable[c][b] = false;
            eqPower[c][b] = true;
            eqType[c][b] = 0;
        }
        if (BANDS >= 6) {
            eqType[c][1] = 1;
            eqType[c][5] = 2;
        }
    }

    void flattenEq(int c) {
        for (int b = 0; b < BANDS; b++) gain[c][b] = 0f;
    }

    void applyHomePreset(int preset) {
        homePreset = preset;
        switch (preset) {
            case 1:
                bassVolume = 2f; bassCutoff = 100f; bassBoost = 2f; middleBoost = 1f; trebleBoost = 3f; break;
            case 2:
                bassVolume = 4f; bassCutoff = 90f; bassBoost = 4f; middleBoost = 2f; trebleBoost = 2f; break;
            case 3:
                bassVolume = 2f; bassCutoff = 110f; bassBoost = 1f; middleBoost = 2f; trebleBoost = 3f; break;
            default:
                bassVolume = 0f; bassCutoff = 100f; bassBoost = 0f; middleBoost = 0f; trebleBoost = 0f; break;
        }
    }

    void saveHome(Context context) {
        SharedPreferences.Editor e = context.getSharedPreferences("okn_dsp_home", Context.MODE_PRIVATE).edit();
        e.putFloat("master", masterVolume)
                .putFloat("bass", bassVolume)
                .putFloat("cutoff", bassCutoff)
                .putFloat("bassboost", bassBoost)
                .putFloat("middle", middleBoost)
                .putFloat("treble", trebleBoost)
                .putInt("preset", homePreset)
                .putInt("source", audioSource)
                .apply();
    }

    boolean loadHome(Context context) {
        SharedPreferences p = context.getSharedPreferences("okn_dsp_home", Context.MODE_PRIVATE);
        if (!p.contains("master")) return false;
        masterVolume = p.getFloat("master", -3f);
        bassVolume = p.getFloat("bass", 4f);
        bassCutoff = p.getFloat("cutoff", 100f);
        bassBoost = p.getFloat("bassboost", 3f);
        middleBoost = p.getFloat("middle", -2f);
        trebleBoost = p.getFloat("treble", 1f);
        homePreset = p.getInt("preset", 0);
        audioSource = p.getInt("source", 0);
        return true;
    }

    void saveEq(Context context) {
        SharedPreferences.Editor e = context.getSharedPreferences("okn_dsp_eq", Context.MODE_PRIVATE).edit();
        for (int c = 0; c < CHANNELS; c++) {
            e.putFloat("fader_" + c, fader[c]);
            e.putBoolean("mute_" + c, mute[c]);
            e.putBoolean("solo_" + c, solo[c]);
            e.putBoolean("phase_" + c, phase180[c]);
            e.putBoolean("link_" + c, link[c]);
            e.putFloat("delay_" + c, delayMs[c]);
            e.putFloat("hpf_" + c, hpfFreq[c]);
            e.putFloat("lpf_" + c, lpfFreq[c]);
            for (int b = 0; b < BANDS; b++) {
                e.putFloat("freq_" + c + "_" + b, freq[c][b]);
                e.putFloat("gain_" + c + "_" + b, gain[c][b]);
                e.putFloat("q_" + c + "_" + b, q[c][b]);
                e.putBoolean("power_" + c + "_" + b, eqPower[c][b]);
                e.putInt("type_" + c + "_" + b, eqType[c][b]);
            }
        }
        e.putFloat("master_output", masterOutput)
                .putInt("bands", BANDS)
                .putBoolean("saved", true)
                .apply();
    }

    boolean loadEq(Context context) {
        SharedPreferences p = context.getSharedPreferences("okn_dsp_eq", Context.MODE_PRIVATE);
        if (!p.getBoolean("saved", false)) return false;
        masterOutput = p.getFloat("master_output", -1f);
        for (int c = 0; c < CHANNELS; c++) {
            fader[c] = p.getFloat("fader_" + c, fader[c]);
            mute[c] = p.getBoolean("mute_" + c, false);
            solo[c] = p.getBoolean("solo_" + c, false);
            phase180[c] = p.getBoolean("phase_" + c, false);
            link[c] = p.getBoolean("link_" + c, link[c]);
            delayMs[c] = p.getFloat("delay_" + c, delayMs[c]);
            hpfFreq[c] = p.getFloat("hpf_" + c, hpfFreq[c]);
            lpfFreq[c] = p.getFloat("lpf_" + c, lpfFreq[c]);
            for (int b = 0; b < BANDS; b++) {
                freq[c][b] = p.getFloat("freq_" + c + "_" + b, freq[c][b]);
                gain[c][b] = p.getFloat("gain_" + c + "_" + b, gain[c][b]);
                q[c][b] = p.getFloat("q_" + c + "_" + b, q[c][b]);
                eqPower[c][b] = p.getBoolean("power_" + c + "_" + b, true);
                eqType[c][b] = p.getInt("type_" + c + "_" + b, eqType[c][b]);
            }
        }
        return true;
    }

    static String db(float v) {
        return String.format(Locale.US, "%.1f dB", v);
    }

    static String hz(float v) {
        if (v >= 1000f) {
            float k = v / 1000f;
            if (Math.abs(k - Math.round(k)) < 0.05f) return String.format(Locale.US, "%.0f kHz", k);
            return String.format(Locale.US, "%.1f kHz", k);
        }
        return String.format(Locale.US, "%.0f Hz", v);
    }

    static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
