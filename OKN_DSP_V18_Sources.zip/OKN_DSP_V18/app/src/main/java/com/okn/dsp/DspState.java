package com.okn.dsp;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Locale;

final class DspState {
    static final int CHANNELS = 7;
    static final int BANDS = 15;

    float masterVolume = -3f;
    float bassVolume = 4f;
    float bassCutoff = 100f;
    float bassBoost = 3f;
    float middleBoost = -2f;
    float trebleBoost = 1f;

    final float[][] freq = new float[CHANNELS][BANDS];
    final float[][] gain = new float[CHANNELS][BANDS];
    final float[][] q = new float[CHANNELS][BANDS];
    final boolean[][] eqWritable = new boolean[CHANNELS][BANDS];
    final boolean[][] eqShapeWritable = new boolean[CHANNELS][BANDS];
    final float[] fader = new float[CHANNELS];

    final boolean[] hpfEnabled = new boolean[CHANNELS];
    final boolean[] lpfEnabled = new boolean[CHANNELS];
    final float[] hpfHz = new float[CHANNELS];
    final float[] lpfHz = new float[CHANNELS];
    final float[] delayMs = new float[CHANNELS];

    int channel = 0;
    int selectedBand = 0;

    static final String[] CHANNEL_SHORT = {"CH1", "CH2", "CH3", "CH4", "CH5", "CH6", "CH7"};
    static final String[] CHANNEL_LONG = {
            "Front Left", "Front Right", "Rear Left", "Rear Right", "Center", "Sub", "AUX"
    };

    private static final float[] DEFAULT_15 = {
            20f, 25f, 40f, 63f, 100f, 160f, 250f, 400f,
            630f, 1000f, 1600f, 2500f, 4000f, 6300f, 16000f
    };

    DspState() {
        for (int c = 0; c < CHANNELS; c++) {
            resetEq(c);
            fader[c] = -3f;
            hpfEnabled[c] = false;
            lpfEnabled[c] = false;
            hpfHz[c] = 80f;
            lpfHz[c] = 3500f;
            delayMs[c] = 0f;
        }
    }

    void resetEq(int c) {
        for (int b = 0; b < BANDS; b++) {
            freq[c][b] = DEFAULT_15[b];
            gain[c][b] = 0f;
            q[c][b] = 1.41f;
            eqWritable[c][b] = false;
            eqShapeWritable[c][b] = false;
        }
    }

    void flattenEq(int c) {
        for (int b = 0; b < BANDS; b++) gain[c][b] = 0f;
    }

    void saveEq(Context context) {
        SharedPreferences.Editor e = context.getSharedPreferences("okn_dsp_eq", Context.MODE_PRIVATE).edit();
        for (int c = 0; c < CHANNELS; c++) {
            e.putFloat("fader_" + c, fader[c]);
            for (int b = 0; b < BANDS; b++) {
                e.putFloat("freq_" + c + "_" + b, freq[c][b]);
                e.putFloat("gain_" + c + "_" + b, gain[c][b]);
                e.putFloat("q_" + c + "_" + b, q[c][b]);
            }
        }
        e.putInt("bands", BANDS).putBoolean("saved", true).apply();
    }

    boolean loadEq(Context context) {
        SharedPreferences p = context.getSharedPreferences("okn_dsp_eq", Context.MODE_PRIVATE);
        if (!p.getBoolean("saved", false)) return false;
        for (int c = 0; c < CHANNELS; c++) {
            fader[c] = p.getFloat("fader_" + c, fader[c]);
            for (int b = 0; b < BANDS; b++) {
                freq[c][b] = p.getFloat("freq_" + c + "_" + b, freq[c][b]);
                gain[c][b] = p.getFloat("gain_" + c + "_" + b, gain[c][b]);
                q[c][b] = p.getFloat("q_" + c + "_" + b, q[c][b]);
            }
        }
        return true;
    }

    void saveCrossover(Context context) {
        SharedPreferences.Editor e = context.getSharedPreferences("okn_dsp_xover", Context.MODE_PRIVATE).edit();
        for (int c = 0; c < CHANNELS; c++) {
            e.putBoolean("hpf_on_" + c, hpfEnabled[c]);
            e.putBoolean("lpf_on_" + c, lpfEnabled[c]);
            e.putFloat("hpf_" + c, hpfHz[c]);
            e.putFloat("lpf_" + c, lpfHz[c]);
            e.putFloat("delay_" + c, delayMs[c]);
        }
        e.putBoolean("saved", true).apply();
    }

    boolean loadCrossover(Context context) {
        SharedPreferences p = context.getSharedPreferences("okn_dsp_xover", Context.MODE_PRIVATE);
        if (!p.getBoolean("saved", false)) return false;
        for (int c = 0; c < CHANNELS; c++) {
            hpfEnabled[c] = p.getBoolean("hpf_on_" + c, hpfEnabled[c]);
            lpfEnabled[c] = p.getBoolean("lpf_on_" + c, lpfEnabled[c]);
            hpfHz[c] = p.getFloat("hpf_" + c, hpfHz[c]);
            lpfHz[c] = p.getFloat("lpf_" + c, lpfHz[c]);
            delayMs[c] = p.getFloat("delay_" + c, delayMs[c]);
        }
        return true;
    }

    static String db(float v) {
        return String.format(Locale.US, "%+.1f dB", v);
    }

    static String hz(float v) {
        if (v >= 1000f) {
            float k = v / 1000f;
            if (Math.abs(k - Math.round(k)) < 0.05f) return String.format(Locale.US, "%.0f kHz", k);
            return String.format(Locale.US, "%.1f kHz", k);
        }
        return String.format(Locale.US, "%.0f Hz", v);
    }
}
