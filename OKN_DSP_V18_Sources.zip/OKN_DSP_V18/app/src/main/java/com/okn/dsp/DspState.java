package com.okn.dsp;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Locale;

/**
 * V18 UI/state model.
 *
 * Hardware-backed fields stay limited to protocol data proven by the uploaded V17 evidence.
 * Crossover, Delay and Output states are fully interactive in the UI but are not serialized
 * to the DSP until a verified packet/actuator mapping exists; this prevents guessed writes.
 */
final class DspState {
    static final int CHANNELS = 7;
    static final int BANDS = 15;

    float masterVolume = -3f;
    float bassVolume = 4f;
    float bassCutoff = 100f;
    float bassBoost = 3f;
    float middleBoost = -2f;
    float trebleBoost = 1f;
    int audioSource = 0;
    int homePreset = 0;

    final float[][] freq = new float[CHANNELS][BANDS];
    final float[][] gain = new float[CHANNELS][BANDS];
    final float[][] q = new float[CHANNELS][BANDS];
    final boolean[][] eqWritable = new boolean[CHANNELS][BANDS];
    final boolean[][] eqEnabled = new boolean[CHANNELS][BANDS];

    final float[] fader = new float[CHANNELS];
    final boolean[] mute = new boolean[CHANNELS];
    final boolean[] phase180 = new boolean[CHANNELS];

    final int[] hpfType = new int[CHANNELS];
    final float[] hpfHz = new float[CHANNELS];
    final int[] hpfSlope = new int[CHANNELS];
    final boolean[] hpfBypass = new boolean[CHANNELS];
    final int[] lpfType = new int[CHANNELS];
    final float[] lpfHz = new float[CHANNELS];
    final int[] lpfSlope = new int[CHANNELS];
    final boolean[] lpfBypass = new boolean[CHANNELS];
    final int[] phaseDeg = new int[CHANNELS];
    final boolean[] polarityInvert = new boolean[CHANNELS];
    final boolean[] linkLR = new boolean[CHANNELS];
    final int[] outputMode = new int[CHANNELS];

    final float[] delayMs = new float[CHANNELS];
    int delayUnit = 0; // 0 ms, 1 cm
    int seatPreset = 0;

    float masterOutput = -1f;
    final float[] outputLevel = new float[CHANNELS];
    final boolean[] outputMute = new boolean[CHANNELS];
    final boolean[] outputSolo = new boolean[CHANNELS];
    final boolean[] outputPhase = new boolean[CHANNELS];
    final boolean[] outputLink = new boolean[CHANNELS];

    int channel = 0;
    int selectedBand = 0;
    int eqGroup = 0;

    static final String[] CHANNEL_SHORT = {"CH1", "CH2", "CH3", "CH4", "CH5", "CH6", "CH7"};
    static final String[] CHANNEL_NAME = {"Front L", "Front R", "Rear L", "Rear R", "Center", "Sub L", "Sub R"};
    static final String[] CHANNEL_LONG = {
            "CH1 - Front L", "CH2 - Front R", "CH3 - Rear L", "CH4 - Rear R",
            "CH5 - Center", "CH6 - Sub L", "CH7 - Sub R"
    };

    static final String[] FILTER_TYPES = {"Linkwitz-Riley", "Butterworth", "Bessel"};
    static final int[] SLOPES = {12, 18, 24, 36, 48};
    static final String[] OUTPUT_MODES = {"Stereo", "Mono", "L Only", "R Only"};
    static final String[] AUDIO_SOURCES = {"High Level (Speaker)", "Low Level (RCA)"};
    static final String[] HOME_PRESETS = {"Flat", "Pop", "Rock", "Jazz"};
    static final String[] SEAT_PRESETS = {"Driver (Left)", "Passenger (Right)", "Front Center", "All Seats"};

    private static final float[] DEFAULT_15 = {
            20f, 32f, 50f, 80f, 125f, 200f, 315f, 500f,
            800f, 1250f, 2000f, 3150f, 5000f, 10000f, 16000f
    };

    DspState() {
        float[] d = {0f, 1.25f, 2.60f, 2.30f, 0.80f, 3.10f, 1.90f};
        float[] out = {-3.0f, -2.5f, -4.0f, -1.0f, -2.0f, -3.5f, -4.5f};
        for (int c = 0; c < CHANNELS; c++) {
            resetEq(c);
            fader[c] = -3f;
            mute[c] = false;
            phase180[c] = false;
            hpfType[c] = 0;
            hpfHz[c] = 100f;
            hpfSlope[c] = 24;
            hpfBypass[c] = false;
            lpfType[c] = 0;
            lpfHz[c] = 1000f;
            lpfSlope[c] = 24;
            lpfBypass[c] = false;
            phaseDeg[c] = 0;
            polarityInvert[c] = false;
            linkLR[c] = c < 2;
            outputMode[c] = 0;
            delayMs[c] = d[c];
            outputLevel[c] = out[c];
            outputMute[c] = false;
            outputSolo[c] = false;
            outputPhase[c] = false;
            outputLink[c] = c < 2;
        }
    }

    void resetEq(int c) {
        for (int b = 0; b < BANDS; b++) {
            freq[c][b] = DEFAULT_15[b];
            gain[c][b] = 0f;
            q[c][b] = 1.0f;
            eqWritable[c][b] = false;
            eqEnabled[c][b] = true;
        }
    }

    void flattenEq(int c) {
        for (int b = 0; b < BANDS; b++) gain[c][b] = 0f;
    }

    void resetCrossover(int c) {
        hpfType[c] = 0; hpfHz[c] = 100f; hpfSlope[c] = 24; hpfBypass[c] = false;
        lpfType[c] = 0; lpfHz[c] = 1000f; lpfSlope[c] = 24; lpfBypass[c] = false;
        phaseDeg[c] = 0; polarityInvert[c] = false; linkLR[c] = c < 2; outputMode[c] = 0;
    }

    void applyHomePreset(int preset) {
        homePreset = Math.max(0, Math.min(HOME_PRESETS.length - 1, preset));
        switch (homePreset) {
            case 1:
                bassVolume = 2f; bassCutoff = 100f; bassBoost = 2f; middleBoost = 1f; trebleBoost = 3f;
                break;
            case 2:
                bassVolume = 4f; bassCutoff = 90f; bassBoost = 4f; middleBoost = 2f; trebleBoost = 2f;
                break;
            case 3:
                bassVolume = 2f; bassCutoff = 110f; bassBoost = 1f; middleBoost = 2f; trebleBoost = 3f;
                break;
            default:
                bassVolume = 0f; bassCutoff = 100f; bassBoost = 0f; middleBoost = 0f; trebleBoost = 0f;
                break;
        }
    }

    void saveAll(Context context) {
        SharedPreferences.Editor e = context.getSharedPreferences("okn_dsp_v18", Context.MODE_PRIVATE).edit();
        e.putBoolean("saved", true)
                .putFloat("master", masterVolume).putFloat("bass", bassVolume)
                .putFloat("cutoff", bassCutoff).putFloat("bassboost", bassBoost)
                .putFloat("middle", middleBoost).putFloat("treble", trebleBoost)
                .putInt("audio_source", audioSource).putInt("home_preset", homePreset)
                .putFloat("master_output", masterOutput).putInt("seat", seatPreset);
        for (int c = 0; c < CHANNELS; c++) {
            e.putFloat("fader_" + c, fader[c]);
            e.putBoolean("mute_" + c, mute[c]);
            e.putBoolean("phase180_" + c, phase180[c]);
            e.putInt("hpf_type_" + c, hpfType[c]);
            e.putFloat("hpf_hz_" + c, hpfHz[c]);
            e.putInt("hpf_slope_" + c, hpfSlope[c]);
            e.putBoolean("hpf_bypass_" + c, hpfBypass[c]);
            e.putInt("lpf_type_" + c, lpfType[c]);
            e.putFloat("lpf_hz_" + c, lpfHz[c]);
            e.putInt("lpf_slope_" + c, lpfSlope[c]);
            e.putBoolean("lpf_bypass_" + c, lpfBypass[c]);
            e.putInt("phase_deg_" + c, phaseDeg[c]);
            e.putBoolean("polarity_" + c, polarityInvert[c]);
            e.putBoolean("linklr_" + c, linkLR[c]);
            e.putInt("output_mode_" + c, outputMode[c]);
            e.putFloat("delay_" + c, delayMs[c]);
            e.putFloat("out_level_" + c, outputLevel[c]);
            e.putBoolean("out_mute_" + c, outputMute[c]);
            e.putBoolean("out_solo_" + c, outputSolo[c]);
            e.putBoolean("out_phase_" + c, outputPhase[c]);
            e.putBoolean("out_link_" + c, outputLink[c]);
            for (int b = 0; b < BANDS; b++) {
                e.putFloat("freq_" + c + "_" + b, freq[c][b]);
                e.putFloat("gain_" + c + "_" + b, gain[c][b]);
                e.putFloat("q_" + c + "_" + b, q[c][b]);
                e.putBoolean("eq_on_" + c + "_" + b, eqEnabled[c][b]);
            }
        }
        e.apply();
    }

    boolean loadAll(Context context) {
        SharedPreferences p = context.getSharedPreferences("okn_dsp_v18", Context.MODE_PRIVATE);
        if (!p.getBoolean("saved", false)) return false;
        masterVolume = p.getFloat("master", masterVolume);
        bassVolume = p.getFloat("bass", bassVolume);
        bassCutoff = p.getFloat("cutoff", bassCutoff);
        bassBoost = p.getFloat("bassboost", bassBoost);
        middleBoost = p.getFloat("middle", middleBoost);
        trebleBoost = p.getFloat("treble", trebleBoost);
        audioSource = p.getInt("audio_source", audioSource);
        homePreset = p.getInt("home_preset", homePreset);
        masterOutput = p.getFloat("master_output", masterOutput);
        seatPreset = p.getInt("seat", seatPreset);
        for (int c = 0; c < CHANNELS; c++) {
            fader[c] = p.getFloat("fader_" + c, fader[c]);
            mute[c] = p.getBoolean("mute_" + c, mute[c]);
            phase180[c] = p.getBoolean("phase180_" + c, phase180[c]);
            hpfType[c] = p.getInt("hpf_type_" + c, hpfType[c]);
            hpfHz[c] = p.getFloat("hpf_hz_" + c, hpfHz[c]);
            hpfSlope[c] = p.getInt("hpf_slope_" + c, hpfSlope[c]);
            hpfBypass[c] = p.getBoolean("hpf_bypass_" + c, hpfBypass[c]);
            lpfType[c] = p.getInt("lpf_type_" + c, lpfType[c]);
            lpfHz[c] = p.getFloat("lpf_hz_" + c, lpfHz[c]);
            lpfSlope[c] = p.getInt("lpf_slope_" + c, lpfSlope[c]);
            lpfBypass[c] = p.getBoolean("lpf_bypass_" + c, lpfBypass[c]);
            phaseDeg[c] = p.getInt("phase_deg_" + c, phaseDeg[c]);
            polarityInvert[c] = p.getBoolean("polarity_" + c, polarityInvert[c]);
            linkLR[c] = p.getBoolean("linklr_" + c, linkLR[c]);
            outputMode[c] = p.getInt("output_mode_" + c, outputMode[c]);
            delayMs[c] = p.getFloat("delay_" + c, delayMs[c]);
            outputLevel[c] = p.getFloat("out_level_" + c, outputLevel[c]);
            outputMute[c] = p.getBoolean("out_mute_" + c, outputMute[c]);
            outputSolo[c] = p.getBoolean("out_solo_" + c, outputSolo[c]);
            outputPhase[c] = p.getBoolean("out_phase_" + c, outputPhase[c]);
            outputLink[c] = p.getBoolean("out_link_" + c, outputLink[c]);
            for (int b = 0; b < BANDS; b++) {
                freq[c][b] = p.getFloat("freq_" + c + "_" + b, freq[c][b]);
                gain[c][b] = p.getFloat("gain_" + c + "_" + b, gain[c][b]);
                q[c][b] = p.getFloat("q_" + c + "_" + b, q[c][b]);
                eqEnabled[c][b] = p.getBoolean("eq_on_" + c + "_" + b, eqEnabled[c][b]);
            }
        }
        return true;
    }

    static String db(float v) { return String.format(Locale.US, "%.1f dB", v); }

    static String hz(float v) {
        if (v >= 1000f) {
            float k = v / 1000f;
            if (Math.abs(k - Math.round(k)) < 0.05f) return String.format(Locale.US, "%.0f kHz", k);
            return String.format(Locale.US, "%.1f kHz", k);
        }
        return String.format(Locale.US, "%.0f Hz", v);
    }

    static String ms(float v) { return String.format(Locale.US, "%.2f ms", v); }
    static String cm(float ms) { return String.format(Locale.US, "%.1f cm", ms * 34.3f); }
}
