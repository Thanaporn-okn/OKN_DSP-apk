package com.okn.dsp;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Locale;

/** Local Phase-1 state. No transport calls are made from this class. */
final class DspState {
    static final int CHANNELS = 7;
    static final int BANDS = 15;

    float masterVolume = -12f;
    float bassVolume = 4f;
    float bassCutoff = 80f;
    float bassBoost = 6f;
    float middleBoost = 2f;
    float trebleBoost = 3f;
    int homePreset = 0;

    final float[][] freq = new float[CHANNELS][BANDS];
    final float[][] gain = new float[CHANNELS][BANDS];
    final float[][] q = new float[CHANNELS][BANDS];
    final boolean[][] eqWritable = new boolean[CHANNELS][BANDS];
    final float[] fader = new float[CHANNELS];
    final boolean[] mute = new boolean[CHANNELS];
    final boolean[] phase180 = new boolean[CHANNELS];

    int channel = 0;
    int selectedBand = 4;

    static final String[] CHANNEL_SHORT = {
            "CH1\nFront L", "CH2\nFront R", "CH3\nRear L", "CH4\nRear R",
            "CH5\nCenter", "CH6\nSub L", "CH7\nSub R"
    };
    static final String[] CHANNEL_LONG = {
            "Channel 1 - Front L", "Channel 2 - Front R", "Channel 3 - Rear L",
            "Channel 4 - Rear R", "Channel 5 - Center", "Channel 6 - Sub L",
            "Channel 7 - Sub R"
    };

    private static final float[] DEFAULT_15 = {
            20f, 31f, 50f, 80f, 125f, 200f, 315f, 500f,
            800f, 1250f, 2000f, 3150f, 5000f, 8000f, 12500f
    };

    private static final float[] REFERENCE_CURVE = {
            -3f, -1f, 2f, 4f, 5f, 4f, 2f, 0f, -2f, -3f, -2f, 0f, 2f, 5f, 6f
    };

    DspState() {
        for (int c = 0; c < CHANNELS; c++) {
            for (int b = 0; b < BANDS; b++) {
                freq[c][b] = DEFAULT_15[b];
                gain[c][b] = REFERENCE_CURVE[b];
                q[c][b] = 1.2f;
                eqWritable[c][b] = true;
            }
            fader[c] = -12f;
            mute[c] = false;
            phase180[c] = false;
        }
    }

    void resetEq(int c) {
        for (int b = 0; b < BANDS; b++) {
            freq[c][b] = DEFAULT_15[b];
            gain[c][b] = 0f;
            q[c][b] = 1.2f;
            eqWritable[c][b] = true;
        }
    }

    void flattenEq(int c) {
        for (int b = 0; b < BANDS; b++) gain[c][b] = 0f;
    }

    void applyHomePreset(int preset) {
        homePreset = preset;
        switch (preset) {
            case 1: // Pop
                bassVolume = 2f;
                bassCutoff = 90f;
                bassBoost = 2f;
                middleBoost = 1f;
                trebleBoost = 4f;
                break;
            case 2: // Rock
                bassVolume = 4f;
                bassCutoff = 80f;
                bassBoost = 6f;
                middleBoost = 2f;
                trebleBoost = 3f;
                break;
            case 3: // Vocal
                bassVolume = 0f;
                bassCutoff = 100f;
                bassBoost = 0f;
                middleBoost = 5f;
                trebleBoost = 2f;
                break;
            case 4: // Custom keeps the current manual values
                break;
            default: // Flat
                bassVolume = 0f;
                bassCutoff = 80f;
                bassBoost = 0f;
                middleBoost = 0f;
                trebleBoost = 0f;
                break;
        }
    }

    void applyEqPreset(int preset, int c) {
        float[] shape;
        switch (preset) {
            case 1: // Pop
                shape = new float[]{-1, 0, 1, 2, 3, 2, 1, 0, 1, 2, 3, 4, 4, 3, 2};
                break;
            case 2: // Rock
                shape = new float[]{4, 5, 4, 3, 1, -1, -2, -1, 1, 2, 3, 4, 5, 5, 4};
                break;
            case 3: // Vocal
                shape = new float[]{-4, -3, -2, -1, 0, 1, 2, 4, 5, 5, 4, 3, 2, 1, 0};
                break;
            case 4: // Custom: preserve current curve
                return;
            default:
                shape = new float[BANDS];
                break;
        }
        for (int b = 0; b < BANDS; b++) gain[c][b] = shape[b];
    }

    void saveEq(Context context) {
        SharedPreferences.Editor e = context.getSharedPreferences("okn_dsp_eq_v18", Context.MODE_PRIVATE).edit();
        for (int c = 0; c < CHANNELS; c++) {
            e.putFloat("fader_" + c, fader[c]);
            e.putBoolean("mute_" + c, mute[c]);
            e.putBoolean("phase_" + c, phase180[c]);
            for (int b = 0; b < BANDS; b++) {
                e.putFloat("freq_" + c + "_" + b, freq[c][b]);
                e.putFloat("gain_" + c + "_" + b, gain[c][b]);
                e.putFloat("q_" + c + "_" + b, q[c][b]);
            }
        }
        e.putBoolean("saved", true).apply();
    }

    boolean loadEq(Context context) {
        SharedPreferences p = context.getSharedPreferences("okn_dsp_eq_v18", Context.MODE_PRIVATE);
        if (!p.getBoolean("saved", false)) return false;
        for (int c = 0; c < CHANNELS; c++) {
            fader[c] = p.getFloat("fader_" + c, fader[c]);
            mute[c] = p.getBoolean("mute_" + c, mute[c]);
            phase180[c] = p.getBoolean("phase_" + c, phase180[c]);
            for (int b = 0; b < BANDS; b++) {
                freq[c][b] = p.getFloat("freq_" + c + "_" + b, freq[c][b]);
                gain[c][b] = p.getFloat("gain_" + c + "_" + b, gain[c][b]);
                q[c][b] = p.getFloat("q_" + c + "_" + b, q[c][b]);
            }
        }
        return true;
    }

    static String db(float v) {
        return String.format(Locale.US, "%+.1f dB", v);
    }

    static String hz(float v) {
        if (v >= 1000f) {
            float k = v / 1000f;
            if (Math.abs(k - Math.round(k)) < 0.05f) return String.format(Locale.US, "%.0fk", k);
            return String.format(Locale.US, "%.1fk", k);
        }
        return String.format(Locale.US, "%.0f", v);
    }
}
