# OKN DSP V18 — Phase 1

V18 is built directly from V17 and keeps the V14/V16 visual base plus the V16 bottom-navigation touch fix and V17 custom Theme/Preset-name dialogs.

## V18 fixes

- Fix preset selection: tapping a saved preset now **loads it immediately**. The EQ graph, Frequency, Q, Gain Band, channel levels, Master/Bass/Cutoff and all stored preset values update as soon as the preset row is tapped.
- Replace the stock Android Saved Presets picker with a native custom card dialog matching the OKN DSP UI and Light/Dark/Midnight themes.
- Remove redundant full-state synchronous `SharedPreferences.commit()` operations from interactive UI paths (theme switching, navigation, channel/band selection, preset selection/load and slider release).
- Slider values still auto-save in real time through their individual setters using `SharedPreferences.apply()`.
- Full synchronous persistence remains at Activity lifecycle checkpoints (`onPause` / `onStop`) for durability when leaving the app.
- Keep V16 bottom navigation touch ownership so Home / Mix / Eq cannot accidentally move Gain Band underneath the navigation area.

## Version

- versionName: 18.0.0
- versionCode: 1018
