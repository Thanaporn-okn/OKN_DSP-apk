
import 'package:flutter/material.dart';

void main()=>runApp(const App());

class App extends StatelessWidget{
 const App({super.key});
 Widget build(BuildContext c)=>MaterialApp(
 theme:ThemeData.dark(),
 home:const DSP());
}

class DSP extends StatefulWidget{
 const DSP({super.key});
 State<DSP> createState()=>_DSPState();
}

class _DSPState extends State<DSP>{
 bool connected=false;
 int ch=1;
 double volume=50;
 final log=<String>[];

 void send(String cmd){
  setState(()=>log.add("TX CH$ch : $cmd"));
 }

 Widget build(BuildContext c)=>Scaffold(
 appBar:AppBar(title:const Text('OKN_DSP BP1048P4 V9')),
 body:ListView(
 padding:const EdgeInsets.all(16),
 children:[
 SwitchListTile(
 title:const Text('Bluetooth Connect'),
 value:connected,
 onChanged:(v)=>setState(()=>connected=v)),
 DropdownButton<int>(
 value:ch,
 items:List.generate(7,(i)=>DropdownMenuItem(
 value:i+1,child:Text('CH${i+1}'))),
 onChanged:(v)=>setState(()=>ch=v!)),
 Text('Volume ${volume.toInt()}'),
 Slider(value:volume,min:0,max:100,
 onChanged:(v){
 setState(()=>volume=v);
 }),
 ElevatedButton(
 onPressed:()=>send("VOL ${volume.toInt()}"),
 child:const Text('SEND VOLUME')),
 ElevatedButton(
 onPressed:()=>send("EQ UPDATE"),
 child:const Text('SEND EQ')),
 ElevatedButton(
 onPressed:()=>send("DELAY UPDATE"),
 child:const Text('SEND DELAY')),
 ElevatedButton(
 onPressed:()=>send("HPF LPF UPDATE"),
 child:const Text('SEND CROSSOVER')),
 const Text('TX/RX LOG'),
 ...log.map((e)=>Text(e))
 ]));
}
