# R25 Build Notes

R25 ใช้ Android project เดิมของ R24 แต่เพิ่มเฉพาะการวิเคราะห์แบบ READ-ONLY:

- correlate Classic address กับ BLE address ตามสูตรที่พบใน SDK
- บันทึก raw BLE advertisement bytes แบบ passive
- ตรวจว่า AB00/AB01/AB02/AB03 properties ตรงกับ SDK profile หรือไม่
- รวมผล SDP จาก Classic address กับ GATT จาก BLE address ใน summary เดียวกัน
- ไม่มี GATT characteristic read/write/subscribe
- ไม่มี BluetoothSocket/RFCOMM/OBEX session
- ไม่มี USB API และไม่มี firmware operation

Build:
- compileSdk/targetSdk 36
- Android Gradle Plugin 8.10.1
- Gradle fallback 8.11.1
- JDK 17
- ใช้ `OKN_BP1048P4_ANDROID_AUTO.yml` ตัวเดิมได้; workflow เลือก Source_R ที่เลขสูงสุดเอง
