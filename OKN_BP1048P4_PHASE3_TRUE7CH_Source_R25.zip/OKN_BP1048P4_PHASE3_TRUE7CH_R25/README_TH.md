# OKN BP1048P4 / GoloPine TRUE7CH — R25

R25 ต่อจาก R24 โดยใช้ผล live scan ของ Samsung S25+ ร่วมกับการ reverse SDK แบบ offline เพื่อ **correlate Classic/BLE identity และตัดสินหลักฐาน OBEX OTA โดยไม่ส่งข้อมูลไปบอร์ด**.

อ่าน `docs/R25_SDK_CORRELATION_REVERSE_TH.md` ก่อนใช้งาน.

## ผล reverse ใหม่

SDK สร้าง BLE address จาก Classic address ด้วยสูตร:

- byte0 `OR 0xC0`
- byte4 `+ 0x60`
- byteอื่นคงเดิม

บอร์ดจริงจาก R24 ตรงสูตรทุก byte:

`63:57:DC:10:68:0E` -> `E3:57:DC:10:C8:0E`

และ GATT `AB00/AB01/AB02/AB03` ที่พบจริงตรง profile shape ใน SDK. เมื่อ Classic SDP ของบอร์ดเดียวกันไม่พบ Object Push `0x1105` ขณะที่ OBEX stack ใน SDK register `0x1105` เมื่อ generic OBEX ถูก init หลักฐานจึงชี้ว่า stock MVA-over-OBEX OTA **ไม่ถูก expose ใน runtime ที่ตรวจพบ**.

นี่เป็น SDK-family/runtime inference ไม่ใช่ production firmware binary proof.

## Android R25 ทำอะไร

- Classic discovery และ `fetchUuidsWithSdp()`
- passive BLE scan พร้อม raw advertisement bytes
- BLE GATT `discoverServices()` และ enumerate UUID/properties/descriptors
- correlate Classic/BLE address อัตโนมัติตามสูตร SDK
- ตรวจ AB00 shape: AB01 read/write/write-no-response, AB02/AB03 notify + CCCD
- summary รวม Classic SDP + BLE GATT ของบอร์ดเดียวกัน แม้ Android ใช้คนละ address

## R25 ไม่ทำอะไร

ไม่มี USB API, ไม่มี RFCOMM/BluetoothSocket, ไม่มี OBEX connect/PUT/header/body, ไม่มี `.mva`, ไม่มี file picker, ไม่มี GATT value read/write/subscribe, ไม่มี erase/program/commit/apply/reset.

## Build จากมือถือ

ใช้ `.github/workflows/OKN_BP1048P4_ANDROID_AUTO.yml` ตัวเดิมที่ทำไว้แล้วได้เลย. Workflow จะเลือก `Source_R` ที่เลขสูงสุดเอง ดังนั้นเมื่ออัปโหลด `OKN_BP1048P4_PHASE3_TRUE7CH_Source_R25.zip` ไม่ต้องแก้เลข R ใน `.yml`.

Artifact จะตั้งชื่อจาก revision ที่ตรวจพบ เช่น `OKN_BT_OTA_Capability_R25`.
