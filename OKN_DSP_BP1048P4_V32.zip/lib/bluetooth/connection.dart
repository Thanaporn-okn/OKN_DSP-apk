// V32 connect disconnect manager
