// V32 HEX TX RX monitor
