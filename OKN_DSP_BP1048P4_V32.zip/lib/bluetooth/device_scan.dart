// V32 Bluetooth device scanner
