import 'package:flutter/material.dart';

void main()=>runApp(const OKN());

class OKN extends StatelessWidget{
 const OKN({super.key});
 @override
 Widget build(BuildContext c){
  return MaterialApp(
   debugShowCheckedModeBanner:false,
   theme:ThemeData.dark(),
   home:Scaffold(
    appBar:AppBar(title:const Text('OKN_DSP BP1048P4 V32')),
    body:const Padding(
     padding:EdgeInsets.all(20),
     child:Text(
      'Bluetooth DSP Controller\n\n'
      'Device Scan\n'
      'Device List\n'
      'Connect Status\n'
      'TX Command\n'
      'RX Response\n'
      'HEX Monitor\n'
      'Volume EQ Delay Control\n'
      'BP1048P4 Command',
      style:TextStyle(fontSize:20),
     ),
    ),
   ),
  );
 }
}
