// V32 controller screen
