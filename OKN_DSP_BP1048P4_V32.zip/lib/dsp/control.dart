// V32 volume EQ delay command
