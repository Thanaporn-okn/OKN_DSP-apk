// V32 BP1048P4 command builder
