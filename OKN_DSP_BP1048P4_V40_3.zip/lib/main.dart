import 'package:flutter/material.dart';

void main(){
 runApp(const OKNDSP());
}

class OKNDSP extends StatelessWidget{
 const OKNDSP({super.key});
 @override
 Widget build(BuildContext context){
  return MaterialApp(
   debugShowCheckedModeBanner:false,
   theme:ThemeData.dark(),
   home:Scaffold(
    appBar:AppBar(title:const Text('OKN_DSP BP1048P4 V40.3')),
    body:const Padding(
     padding:EdgeInsets.all(20),
     child:Column(
      crossAxisAlignment:CrossAxisAlignment.start,
      children:[
       Text('BUILD TEST SUCCESS',
       style:TextStyle(fontSize:26,color:Colors.cyan)),
       SizedBox(height:25),
       Text('Bluetooth DSP Controller'),
       Text('Scan Device'),
       Text('Connect / Disconnect'),
       Text('CH1-CH7 Control'),
       Text('Volume EQ Delay'),
       Text('HPF / LPF'),
       Text('BP1048P4 Command'),
       Text('TX RX HEX Monitor'),
      ],
     ),
    ),
   ),
  );
 }
}
