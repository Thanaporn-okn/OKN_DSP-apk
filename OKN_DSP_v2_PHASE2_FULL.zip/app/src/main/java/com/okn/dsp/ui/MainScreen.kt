package com.okn.dsp.ui
import androidx.compose.material3.*
import androidx.compose.runtime.*
@Composable
fun MainScreen(){
 MaterialTheme{
  Surface{
   Text("OKN_DSP BP1048P4 7CH\nPHASE 2 UI BASE")
  }
 }
}