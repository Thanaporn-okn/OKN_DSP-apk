package com.okn.dsp
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.okn.dsp.ui.MainScreen
class MainActivity:ComponentActivity(){
 override fun onCreate(b:Bundle?){
  super.onCreate(b)
  setContent{MainScreen()}
 }
}