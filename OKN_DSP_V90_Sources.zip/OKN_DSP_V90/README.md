# OKN DSP V90 — EQ Gain +/- + Actions Path Fix (Base V41)

V90 retains the V89 EQ Band Gain `- / +` controls for CH1–CH7. Each press changes the selected EQ band's proven realtime Gain path by 0.5 dB, only when BLE is READY and DSP readback marks that row gain-writable.

Safety remains unchanged: no invented actuator ID, no channel-output-volume mapping, no automatic SaveParams, and no unknown DSP write.

V90 also hardens the separate GitHub Actions workflow for phone uploads: it can locate `OKN_DSP_V*_Sources.zip` anywhere in the repository, discovers the actual Gradle project by `settings.gradle`, and prints the exact failing command on shell errors.
