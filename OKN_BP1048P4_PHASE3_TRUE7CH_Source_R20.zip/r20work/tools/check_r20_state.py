#!/usr/bin/env python3
import json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
d=json.loads((root/'config/DIRECT_USBC_BOOT55_PROBE_STATE_R20.json').read_text())
p=d['r20_probe']
assert p['strict_normal_descriptor_gate']
assert p['strict_if4_hid_report_gate']
assert p['requires_clean_feature_first_byte_00']
assert p['one_shot_per_app_launch']
assert p['set_report_payload_hex']=='55 DE AD BE EF 00 00 00'
for k in ['aa_command','endpoint_out','bulk_transfer','mva_transfer','flash_read','flash_write','erase','program','commit']:
    assert p[k] is False, k
print('R20 state policy: PASS')
