#!/usr/bin/env python3
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'android-usb-probe/app/src/main/java/com/okn/dsp/usbprobe/MainActivity.java'
s=p.read_text(encoding='utf-8')
required=[
    'TARGET_NORMAL_VID = 0x6324', 'TARGET_NORMAL_PID = 0x1719',
    '55 DE AD BE EF 00 00 00',
    'controlTransfer(0x21,0x09,0x0300,4,req,req.length,1200)',
    'controlTransfer(0xA1,0x01,0x0300,4,after,after.length,1200)',
    'boot55ProbeUsed = true',
    'GATE FAIL: clean baseline first byte is not 00',
    'NO flash payload, erase, program, commit, or MVA transfer was sent.'
]
for x in required:
    assert x in s, f'missing R20 guard/flow: {x}'
for forbidden in [
    '.bulkTransfer(', '.claimInterface(', '.releaseInterface(', '.requestWait(', '.queue(',
    '55 AA 55 AA', 'SET_REPORT FEATURE AA', 'A5 5A FE',
    'chipErase(', 'sectorErase(', 'flashWrite(', 'programFlash(', 'commitFlash(',
    'writeMemory(', 'readMemory(', 'sdpWrite(', 'jtagWrite('
]:
    assert forbidden not in s, f'forbidden R20 operation present: {forbidden}'
# Exactly one active host-to-device class control call, and it must be Feature SET_REPORT 0x55.
out_calls=[]
for line in s.splitlines():
    q=line.strip()
    if 'controlTransfer(' in q and not q.startswith('//'):
        if 'controlTransfer(0x21' in q or 'controlTransfer(0x01' in q or 'controlTransfer(0x00' in q:
            out_calls.append(q)
assert out_calls == ['int wn=c.controlTransfer(0x21,0x09,0x0300,4,req,req.length,1200);'], out_calls
print('R20 one-shot 0x55 boot-entry guard: PASS')
