R20 Android USB-C boot-entry probe
- package: com.okn.dsp.usbprobe
- versionCode: 20
- compileSdk/targetSdk: 35
- Java: 17
- build ด้วย OKN_BP1048P4_AUTO.yml เดิมได้
- host safety tests: tests/run_host_tests.sh
- state-changing operation เดียว: HID Feature SET_REPORT 8 bytes = 55 DE AD BE EF 00 00 00
- ไม่มี MVA / erase / program / flash write
