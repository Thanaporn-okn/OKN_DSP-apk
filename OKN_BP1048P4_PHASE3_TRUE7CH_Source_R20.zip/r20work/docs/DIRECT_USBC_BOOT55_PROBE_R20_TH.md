# R20 — Direct USB-C 0x55 code-upgrade entry probe

## เหตุผลที่มี R20

ผล R19 จากบอร์ดจริงยืนยันว่าการ power-cycle ขณะ S25+ ต่อ USB-C อยู่ ไม่ได้ทำให้เห็น flashboot: เห็นเพียง normal app `6324:1719`, 7 interfaces และ IF4 HID report descriptor เดิมเท่านั้น

ก่อนหน้านี้ R16 ส่ง Feature `AA` แล้ว normal app ตอบรับ (`GET_REPORT Feature` byte แรกเป็น `55`) แต่ไม่เกิด USB handoff/re-enumeration ส่วน R17 ส่ง PCTools version query `A5 5A 11 00 16` แล้วไม่พบ response

public BP10X SDK แยก Feature entry ออกเป็นสองกรณี:
- Request[0] = `AA`: ขอ upgrade แบบไม่มี code version comparison
- Request[0] = `55`: เปรียบเทียบ Request[1..4] กับ 4 bytes ของ code; ถ้าไม่ตรงจะ arm `pc_upgrade`

R20 จึงทดสอบเฉพาะเส้น `55` ซึ่งยังไม่เคยทดสอบบนบอร์ดนี้

## สิ่งที่ R20 ส่ง

หลัง strict gate ยืนยันว่าเป็น normal app เดิมทุกจุด และ Feature baseline byte แรกเป็น `00`:

`SET_REPORT Feature (8 bytes): 55 DE AD BE EF 00 00 00`

จากนั้นอ่าน `GET_REPORT Feature` เพียงหนึ่งครั้งเพื่อ trigger/observe handoff ตาม public source แล้วปิด connection ทันที

`DE AD BE EF` ถูกเลือกให้เป็น marker ที่ตั้งใจให้ไม่ตรงกับ code/version 4 bytes ของ target; R20 ไม่ตีความ marker นี้เป็น firmware data

## สิ่งที่ R20 ไม่ทำ

- ไม่ส่ง `AA`
- ไม่ส่ง MVA
- ไม่ส่ง endpoint OUT
- ไม่ใช้ bulk transfer
- ไม่ส่ง erase/program/commit
- ไม่อ่านหรือเขียน flash
- probe นี้รันได้ครั้งเดียวต่อการเปิดแอปหนึ่งครั้ง

## เกณฑ์ผลลัพธ์

1. ถ้า Feature reply byte แรกเป็น `55` และ USB detach/re-enumerate เป็น identity/interface shape ใหม่: เก็บ log ทั้งหมดและหยุด ห้ามส่ง payload ต่อ
2. ถ้า reply เป็น `55` แต่ normal app `6324:1719` อยู่เหมือนเดิม: หลักฐานจะชี้หนักขึ้นว่า target ไม่มี/ปิด flashboot handoff (`FLASH_BOOT_EN`) หรือ resource gate ของ vendor build ไม่ผ่าน
3. ถ้า SET_REPORT ไม่รับหรือ Feature reply ไม่เป็น `55`: เส้น 0x55 ของ target แตกต่างจาก public BP10X reference

หลังทดสอบ ให้ power-cycle บอร์ดหนึ่งครั้งก่อนใช้งานปกติ
