# OKN BP1048P4 TRUE7CH — R20

R20 ต่อจาก R19 เพื่อทดสอบ **เส้นทางเข้า flashboot แบบ 0x55 เพียงครั้งเดียว** ผ่าน S25+ → USB-C → บอร์ด โดยยังไม่มีคำสั่ง flash ใด ๆ

ลำดับใช้งาน:
1. ต่อ S25+ ↔ USB-C บอร์ดและเปิดบอร์ดตามปกติ
2. กด `2) SCAN`
3. กด `3) INSPECT` และอนุญาต USB; ต้องเห็น `EXACT-KNOWN-NORMAL-APP`
4. ตรวจว่า Feature baseline ของบอร์ดอยู่ในสภาพ clean หลัง power-cycle
5. กด `7) ONE-SHOT 0x55 BOOT ENTRY PROBE (NO FLASH)` แล้วกด `RUN ONCE`
6. รอ post-0x55 watch 20 วินาที
7. กด `8) COPY WHOLE LOG` แล้วส่ง log ทั้งหมด

R20 ส่ง host-to-device เพียง Feature SET_REPORT เดียว: `55 DE AD BE EF 00 00 00` แล้ว GET Feature หนึ่งครั้ง ไม่มี MVA/erase/program/write flash

รายละเอียด: `docs/DIRECT_USBC_BOOT55_PROBE_R20_TH.md`
