import 'package:flutter/material.dart';

void main()=>runApp(const OKNDSP());

class OKNDSP extends StatelessWidget{
 const OKNDSP({super.key});

 @override
 Widget build(BuildContext context){
  return MaterialApp(
   debugShowCheckedModeBanner:false,
   theme:ThemeData.dark(),
   home:Scaffold(
    appBar:AppBar(title:const Text("OKN_DSP BP1048P4")),
    body:const Center(
     child:Text(
      "OKN_DSP MOBILE BUILD",
      style:TextStyle(fontSize:26,color:Colors.cyan),
     ),
    ),
   ),
  );
 }
}
