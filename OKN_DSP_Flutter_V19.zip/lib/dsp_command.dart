class DSPCommand{

 List<int> volume(int ch,double value){
  int db=((value*60)-60).round();
  return [0xAA,ch,db&0xff,0x55];
 }

 List<int> eq(int band,int gain){
  return [0xBB,band,gain&0xff,0x55];
 }

 List<int> crossover(int hpf,int lpf){
  return [0xCC,hpf&0xff,lpf&0xff,0x55];
 }

 List<int> delay(int ch,int ms){
  return [0xDD,ch,ms&0xff,0x55];
 }

 List<int> savePreset(int id){
  return [0xEE,id,0x55];
 }

}
