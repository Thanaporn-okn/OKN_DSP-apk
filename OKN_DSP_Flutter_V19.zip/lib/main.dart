import 'package:flutter/material.dart';
import 'dsp_state.dart';

void main()=>runApp(const OKNDSP());

class OKNDSP extends StatelessWidget{
 const OKNDSP({super.key});
 Widget build(BuildContext c)=>MaterialApp(
 debugShowCheckedModeBanner:false,
 theme:ThemeData.dark(useMaterial3:true),
 home:const Home());
}

class Home extends StatefulWidget{
 const Home({super.key});
 State<Home> createState()=>_Home();
}

class _Home extends State<Home>{
 final dsp=DSPState();

 Widget build(BuildContext c)=>Scaffold(
 backgroundColor:const Color(0xff0b1016),
 body:SafeArea(child:Column(children:[
 const Text("OKN_DSP V19",
 style:TextStyle(fontSize:32,color:Colors.cyan)),
 const Text("DSP State Manager Ready"),
 Expanded(child:Row(children:
 List.generate(7,(i)=>Expanded(child:Column(children:[
 Text("CH${i+1}"),
 Expanded(child:RotatedBox(
 quarterTurns:3,
 child:Slider(
 value:dsp.volume[i],
 onChanged:(v){
 setState(()=>dsp.setVolume(i,v));
 }))),
 Text("${((dsp.volume[i]*60)-60).round()} dB")
 ])))))
 ])));
}
