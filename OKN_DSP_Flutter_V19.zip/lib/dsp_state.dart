class DSPState{
 List<double> volume=List.filled(7,0.5);
 List<int> eqGain=List.filled(15,0);
 List<int> delayMs=List.filled(7,0);

 int hpf=80;
 int lpf=20000;

 void setVolume(int ch,double v){
  volume[ch]=v;
 }

 void setEQ(int band,int gain){
  eqGain[band]=gain;
 }

 void setDelay(int ch,int ms){
  delayMs[ch]=ms;
 }
}
