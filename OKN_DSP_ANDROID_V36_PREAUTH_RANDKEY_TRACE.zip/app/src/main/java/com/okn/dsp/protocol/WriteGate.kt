package com.okn.dsp.protocol

/**
 * V34 live write gate.
 * UFE serializer + EQ48 + AES-CFB8 TX path are verified, but a standalone session still
 * still cannot independently derive the current RandKey from the 32-byte authentication response. Keep false.
 */
object WriteGate {
    const val enabled: Boolean = false
}
