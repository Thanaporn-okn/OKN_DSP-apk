import 'package:flutter/material.dart';

void main()=>runApp(const App());

class App extends StatelessWidget{
 const App({super.key});
 @override
 Widget build(BuildContext c){
  return MaterialApp(
   home: Scaffold(
    appBar: AppBar(title: const Text('OKN_DSP BP1048P4 V37')),
    body: const Padding(
     padding: EdgeInsets.all(20),
     child: Text(
      'Bluetooth DSP Controller\n\n'
      'Android V2 Embedding Fixed\n'
      'BP1048P4 Command Layer\n'
      'CH1-CH7 Control Ready',
      style: TextStyle(fontSize:22),
     ),
    ),
   ),
  );
 }
}
