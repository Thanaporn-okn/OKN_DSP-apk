#!/usr/bin/env python3
from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[1]
m=json.loads((root/"evidence_manifest.json").read_text())
errors=[]
if m.get("schema")!=4: errors.append("evidence schema must be 4")
if m.get("project_version")!=13: errors.append("project_version must be 13")
if m.get("target")!="BP1048P4" or m.get("board")!="GoloPine 7CH": errors.append("target/board mismatch")
if m.get("policy")!="FAIL_CLOSED_NO_INFERENCE": errors.append("policy mismatch")
if m.get("hardware_authorized") is not False: errors.append("hardware_authorized must be false")
req=m.get("required_exact_evidence",{})
if any(bool(v) for v in req.values()): errors.append("V13 exact evidence flags must all remain false")
prov=m.get("provenance",{})
if prov.get("previous_source_sha256")!="d2415abf0682042bc60ab61f0ca74e126a5d5aff34f836b5771f8803de2e7f71": errors.append("V12 source provenance mismatch")
if prov.get("validation_zip_sha256")!="18fd52dfb82b5fb1829a98ce50cb68b72511a5007f7f5da5b57d0bc080262add": errors.append("V12 validation provenance mismatch")
for ob in m.get("observations",[]):
    if ob.get("authorizes") not in ([],None): errors.append("observations may not authorize hardware in V13")
if errors:
    [print("BLOCKED:",e) for e in errors]; sys.exit(1)
print("PASS: V13 evidence manifest is internally consistent and non-authorizing")
