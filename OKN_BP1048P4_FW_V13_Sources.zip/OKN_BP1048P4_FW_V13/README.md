# OKN_BP1048P4_FW_V13

Portable clean-room control/DSP firmware architecture for the GoloPine 7CH
target using BP1048P4 as the intended chip. Hardware access remains fail-closed.

V12 GitHub Actions validation was accepted with source SHA
`d2415abf0682042bc60ab61f0ca74e126a5d5aff34f836b5771f8803de2e7f71` and validation ZIP SHA
`18fd52dfb82b5fb1829a98ce50cb68b72511a5007f7f5da5b57d0bc080262add`.

V13 is a transport/safe-init integrity release. The byte-stream parser now has
an explicit transport-driven partial-frame idle timeout path and an explicit
session reset API. The portable core does not read a hardware clock and does
not choose a BP1048P4/BLE timeout value; the verified transport adapter must
supply both elapsed time and policy timeout.

Safe boot now also requires exact-board evidence that `platform_init()` itself
leaves physical outputs inactive/muted. This closes the V12 assumption that a
hardware-specific init callback was safe before the explicit mute callback ran.
The shipped stub keeps this evidence false, so real hardware remains locked.

V12 control-plane integrity and V11 external delay-arena behavior are preserved.
Run `make verify`, `make test`, and `make demo`.

This release remains `hardware_flashable=false` and `mobile_flashable=false`
and intentionally ships no target `.bin`.
