#ifndef BP1048P4_PORT_CONTRACT_H
#define BP1048P4_PORT_CONTRACT_H

#include "bp1048p4_hal.h"
#include <stdbool.h>
#include <stdint.h>

#define BP1048P4_PORT_EVIDENCE_MAGIC 0x4F4B4E37u /* "OKN6" project marker, not HW MMIO */
#define BP1048P4_PORT_ABI_VERSION 2u

typedef struct {
    uint32_t magic;
    uint16_t abi_version;
    bool bp1048p4_target_verified;
    bool board_profile_verified;
    bool platform_init_verified;
    /* Exact-board evidence must prove platform_init itself leaves physical
     * outputs inactive/muted until set_output_safety_mute(true) is called. */
    bool platform_init_output_safe_verified;
    bool output_safety_mute_verified;
    bool audio_path_verified;
    bool ble_path_verified;
    bool storage_path_verified;
} bp1048p4_port_evidence_t;

/* This validates evidence + function presence only. It does not infer any
 * register address or claim that a BP1048B1/B2 SDK is binary-compatible with P4. */
okn_status_t bp1048p4_hal_validate_contract(const bp1048p4_hal_t *hal,
                                             const bp1048p4_port_evidence_t *evidence);

const bp1048p4_port_evidence_t *bp1048p4_port_evidence_get(void);

#endif
