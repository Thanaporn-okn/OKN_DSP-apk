#!/usr/bin/env python3
from pathlib import Path
import sys
root=Path(__file__).resolve().parents[1]
h=(root/'src/transport/okn_control_session.h').read_text()
c=(root/'src/transport/okn_control_session.c').read_text()
fm=(root/'firmware_manifest.json').read_text()
errors=[]
for sym in ('okn_control_session_execute','okn_control_session_reset','duplicate_replays','cached_request','cached_controller_revision','stale_cache_misses','in_flight','reentrant_rejections'):
    if sym not in h+c: errors.append('missing control-session symbol: '+sym)
if 'memcmp(session->cached_request, request, request_len)' not in c:
    errors.append('duplicate detection must compare exact request bytes')
if 'okn_protocol_execute_ex' not in c:
    errors.append('session must use separated protocol execution result')
if 'uint8_t encoded[OKN_CONTROL_MAX_FRAME]' not in c:
    errors.append('session must execute into full internal response buffer')

if 'session->cached_controller_revision == session->controller->revision' not in c:
    errors.append('duplicate cache must be bound to current controller revision')
if '++session->stale_cache_misses' not in c:
    errors.append('stale revision-bound cache misses must be observable')
if 'session->cached_controller_revision = session->controller->revision' not in c:
    errors.append('cache must snapshot controller revision after command evaluation')

if 'if (session->in_flight)' not in c:
    errors.append('control session must reject nested execution before protocol evaluation')
if 'r.protocol.transport_status = OKN_ERR_REENTRANT' not in c:
    errors.append('nested control-session execution must return OKN_ERR_REENTRANT')
if '++session->reentrant_rejections' not in c:
    errors.append('nested control-session rejection must be observable')
guard_pos=c.find('if (session->in_flight)')
proto_pos=c.find('okn_protocol_execute_ex')
cache_pos=c.find('request_bytes_match_cache(session, request, request_len)', c.find('okn_control_session_execute'))
if guard_pos < 0 or proto_pos < 0 or guard_pos > proto_pos:
    errors.append('in-flight guard must run before protocol evaluation')
if guard_pos < 0 or cache_pos < 0 or guard_pos > cache_pos:
    errors.append('in-flight guard must run before duplicate-cache lookup')
if '"control_session_inflight_guard": true' not in fm:
    errors.append('firmware manifest must declare control-session in-flight guard')
if '"control_session_reentrant_execute_rejected": true' not in fm:
    errors.append('firmware manifest must declare re-entrant session execution rejection')
if '"revision_bound_response_cache": true' not in fm:
    errors.append('firmware manifest must declare revision-bound response cache')
if '"single_outstanding_request": true' not in fm:
    errors.append('firmware manifest must declare serialized request contract')
if '"exact_duplicate_response_cache": true' not in fm:
    errors.append('firmware manifest must declare duplicate response cache')
if errors:
    [print('BLOCKED:',e) for e in errors]; sys.exit(1)
print('PASS: V37 control-session cache is exact-byte, revision-bound, reentrancy-guarded, retry-safe, and portable')
