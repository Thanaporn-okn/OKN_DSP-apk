#!/usr/bin/env python3
"""Deterministic V37 source-package builder.

This script creates a reproducible *source ZIP only*. It never invokes a linker,
never emits a target firmware image, and performs no hardware/programmer I/O.
"""
from pathlib import Path, PurePosixPath
import argparse, fnmatch, hashlib, json, os, shutil, stat, tempfile, zipfile

FIXED_DT = (1980, 1, 1, 0, 0, 0)
FILE_MODE = 0o100644
EXCLUDED_DIRS = {"build", "__pycache__", ".git"}
EXCLUDED_SUFFIXES = {".pyc"}

def is_excluded(rel: Path) -> bool:
    if any(part in EXCLUDED_DIRS for part in rel.parts):
        return True
    if rel.suffix in EXCLUDED_SUFFIXES:
        return True
    n = rel.name
    if fnmatch.fnmatch(n, "OKN_BP1048P4_FW_V*_Sources.zip"):
        return True
    if fnmatch.fnmatch(n, "OKN_BP1048P4_FW_V*_SHA256.txt"):
        return True
    return False

def collect_files(root: Path):
    out = []
    for p in sorted(root.rglob("*"), key=lambda x: x.relative_to(root).as_posix()):
        rel = p.relative_to(root)
        if is_excluded(rel):
            continue
        if p.is_symlink():
            raise ValueError(f"symlink is forbidden in reproducible package: {rel.as_posix()}")
        if p.is_dir():
            continue
        if not p.is_file():
            raise ValueError(f"unsupported filesystem entry: {rel.as_posix()}")
        out.append((rel, p.read_bytes()))
    return out

def tree_digest(files):
    h = hashlib.sha256()
    for rel, data in files:
        h.update(hashlib.sha256(data).hexdigest().encode("ascii"))
        h.update(b"  ")
        h.update(str(len(data)).encode("ascii"))
        h.update(b"  ")
        h.update(rel.as_posix().encode("utf-8"))
        h.update(b"\n")
    return h.hexdigest()

def build_zip(root: Path, out: Path):
    root = root.resolve()
    files = collect_files(root)
    out.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        prefix = root.name
        for rel, data in files:
            arc = f"{prefix}/{rel.as_posix()}"
            info = zipfile.ZipInfo(arc, FIXED_DT)
            info.create_system = 3
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = FILE_MODE << 16
            info.flag_bits |= 0x800  # UTF-8 names when needed.
            z.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    blob = out.read_bytes()
    return {
        "schema": 1,
        "project_version": 37,
        "file_count": len(files),
        "tree_sha256": tree_digest(files),
        "zip_sha256": hashlib.sha256(blob).hexdigest(),
        "zip_size": len(blob),
        "archive_root": root.name,
        "hardware_io_performed": False,
        "target_image_emitted": False,
        "authorizes_hardware": False,
        "authorizes_mobile_flash": False,
    }

def verify_archive(root: Path, archive: Path):
    expected = collect_files(root)
    expected_map = {f"{root.name}/{rel.as_posix()}": data for rel, data in expected}
    errors = []
    with zipfile.ZipFile(archive) as z:
        names = z.namelist()
        if names != sorted(names):
            errors.append("ZIP entries are not lexicographically sorted")
        if len(names) != len(set(names)):
            errors.append("ZIP contains duplicate entry names")
        if set(names) != set(expected_map):
            errors.append("ZIP entry set does not match source tree")
        for info in z.infolist():
            pp = PurePosixPath(info.filename)
            if pp.is_absolute() or ".." in pp.parts:
                errors.append(f"unsafe ZIP path: {info.filename}")
                continue
            if info.date_time != FIXED_DT:
                errors.append(f"non-normalized ZIP timestamp: {info.filename}")
            mode = (info.external_attr >> 16) & 0xFFFF
            if mode != FILE_MODE:
                errors.append(f"non-normalized ZIP mode: {info.filename} mode={oct(mode)}")
            if info.is_dir():
                errors.append(f"directory entry unexpectedly emitted: {info.filename}")
            if info.filename in expected_map and z.read(info) != expected_map[info.filename]:
                errors.append(f"ZIP data mismatch: {info.filename}")
    return errors

def verify_double_build(root: Path):
    with tempfile.TemporaryDirectory(prefix="okn-v30-repro-") as td:
        td = Path(td)
        a, b = td/"a.zip", td/"b.zip"
        ra, rb = build_zip(root, a), build_zip(root, b)
        if a.read_bytes() != b.read_bytes():
            raise RuntimeError("reproducibility failure: two builds are not byte-identical")
        errors = verify_archive(root, a)
        if errors:
            raise RuntimeError("; ".join(errors))
        return ra

def main():
    ap = argparse.ArgumentParser(description="Build or verify deterministic V37 source ZIP; never emits firmware.")
    ap.add_argument("--root", default=str(Path(__file__).resolve().parents[1]))
    ap.add_argument("--output")
    ap.add_argument("--verify", action="store_true")
    args = ap.parse_args()
    root = Path(args.root).resolve()
    if args.verify:
        result = verify_double_build(root)
        print(json.dumps(result, sort_keys=True))
        print("PASS: V37 deterministic source package is byte-reproducible and extract-roundtrip safe")
        return 0
    if not args.output:
        ap.error("--output is required unless --verify is used")
    result = build_zip(root, Path(args.output).resolve())
    print(json.dumps(result, sort_keys=True))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
