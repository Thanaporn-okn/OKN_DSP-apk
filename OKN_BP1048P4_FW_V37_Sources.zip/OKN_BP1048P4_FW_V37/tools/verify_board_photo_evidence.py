#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'board_photo_evidence_manifest.json').read_text())
errors=[]
if m.get('schema')!=1: errors.append('board photo evidence schema must be 1')
if m.get('project_version')!=37: errors.append('board photo evidence project_version must be 37')
if m.get('policy')!='CONTENT_BOUND_PHYSICAL_OBSERVATION_NO_PROGRAMMER_INFERENCE': errors.append('board photo evidence policy mismatch')
eroot=(root/m.get('evidence_root','')).resolve()
try: eroot.relative_to(root.resolve())
except ValueError: errors.append('evidence_root escapes project root')
arts={}
for a in m.get('artifacts',[]):
    aid=a.get('id'); rel=a.get('path'); declared=a.get('sha256')
    if not aid or not rel or not declared: errors.append('artifact missing id/path/hash'); continue
    p=(eroot/rel)
    try: p.resolve().relative_to(eroot)
    except ValueError: errors.append(aid+': path escapes evidence root'); continue
    if not p.is_file(): errors.append(aid+': file missing'); continue
    actual=hashlib.sha256(p.read_bytes()).hexdigest()
    if actual!=declared: errors.append(aid+': SHA256 mismatch')
    if p.stat().st_size!=a.get('size_bytes'): errors.append(aid+': size mismatch')
    arts[aid]=actual
obs=m.get('observations',{})
chip=obs.get('exact_chip_identity',{})
if chip.get('status')!='VERIFIED_FROM_VISIBLE_PACKAGE_MARKING': errors.append('exact chip observation status mismatch')
if chip.get('artifact_id')!='board-photo-37402-u24': errors.append('exact chip artifact binding mismatch')
if chip.get('component')!='U24': errors.append('chip reference designator mismatch')
if chip.get('marking')!='MVSILICON BP1048P4': errors.append('chip marking mismatch')
if chip.get('promotes_claim')!='exact_chip_identity': errors.append('chip claim mapping mismatch')
pcb=obs.get('pcb_identifier',{})
if pcb.get('marking')!='HQPCB-2': errors.append('PCB identifier observation mismatch')
rear=obs.get('rear_product_silkscreen',{})
if rear.get('marking')!='3/5/7-channels DSP Wireless audio front stage': errors.append('rear silkscreen observation mismatch')
for forbidden in ('exact_golopine_board_identity','board_pin_map','programmer_transport','flash_programmer','boot_pin','image_format'):
    if forbidden not in m.get('not_established',[]): errors.append('missing fail-closed not_established: '+forbidden)
if m.get('hardware_authorized') is not False or m.get('mobile_flash_authorized') is not False:
    errors.append('photos must not authorize hardware/mobile flash')
if errors:
    [print('BLOCKED:',e) for e in errors]; sys.exit(1)
print('PASS: V37 physical board photos are content-bound; BP1048P4 U24 marking verified; programmer/board-vendor claims remain locked')
