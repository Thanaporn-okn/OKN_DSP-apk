#!/usr/bin/env python3
from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'evidence_manifest.json').read_text())
errors=[]
if m.get('schema')!=4: errors.append('evidence schema must be 4')
if m.get('project_version')!=37: errors.append('project_version must be 37')
if m.get('target')!='BP1048P4' or m.get('board')!='GoloPine 7CH': errors.append('target/board mismatch')
if m.get('policy')!='FAIL_CLOSED_NO_INFERENCE': errors.append('policy mismatch')
if m.get('hardware_authorized') is not False: errors.append('hardware_authorized must be false')
req=m.get('required_exact_evidence',{})
if req.get('exact_bp1048p4_identity') is not True:
    errors.append('exact_bp1048p4_identity must be true from bound physical U24 photo')
for k,v in req.items():
    if k!='exact_bp1048p4_identity' and bool(v):
        errors.append('V37 exact evidence must remain false except chip identity: '+k)
prov=m.get('provenance',{})
if prov.get('previous_source_sha256')!='e7e2bdbbf3d3d566fb4bfa1fed69b5d10b57c37430616d2ae7a4482a3d88912c': errors.append('V36 source provenance mismatch')
if prov.get('validation_zip_sha256')!='0e588cec24a1a469f388cf5c3247adde54d21e9bfeb008b71861d2c62c66184a': errors.append('V36 validation provenance mismatch')
if not any(o.get('id')=='v36-ci-validation' for o in m.get('observations',[])): errors.append('V36 CI observation missing')
for ob in m.get('observations',[]):
    if ob.get('authorizes') not in ([],None): errors.append('observations may not authorize hardware in V37')
if errors:
    [print('BLOCKED:',e) for e in errors]; sys.exit(1)
print('PASS: V37 evidence manifest is internally consistent and non-authorizing')
