#!/usr/bin/env python3
"""V37 content-bound reviewed claim mapping.

This tool maps one explicitly reviewed exact-target evidence record to one narrowly
scoped qualification claim. It re-hashes the evidence bytes and enforces a scope
allowlist. A successful mapping is SUPPORTING_EVIDENCE_NON_AUTHORIZING only:
it never edits target_qualification_manifest.json and never authorizes hardware,
mobile flashing, programmer I/O, or target writes.
"""
from __future__ import annotations
import argparse, hashlib, json, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
MANIFEST=ROOT/'target_claim_mapping_manifest.json'

ALL_CLAIMS={
'exact_chip_identity','exact_golopine_board_identity','startup','linker_memory_map',
'flash_programmer','programmer_transport','image_layout','image_format','recovery_path',
'power_safety','board_pin_map','audio_api','board_audio_route','output_safety_mute',
'ble_api','board_ble_route','nvm_api','board_nvm_layout',
'original_firmware_backup_readback','post_flash_readback_verify','exact_ram_capacity',
'delay_arena_placement','persistence_workspace_strategy','platform_init_output_safe',
'android_host_transport'
}

SCOPE_ALLOWED={
'EXACT_CHIP_DOCUMENT':{
    'exact_chip_identity','exact_ram_capacity'
},
'EXACT_TARGET_SDK_DOCUMENT':{
    'exact_chip_identity','startup','linker_memory_map','image_layout',
    'audio_api','ble_api','nvm_api','exact_ram_capacity'
},
'EXACT_PROGRAMMER_DOCUMENT':{
    'exact_chip_identity','flash_programmer','programmer_transport','image_format',
    'image_layout','recovery_path'
},
'EXACT_BOARD_DOCUMENT':{
    'exact_golopine_board_identity','board_pin_map','board_audio_route',
    'output_safety_mute','board_ble_route','board_nvm_layout','platform_init_output_safe',
    'power_safety','delay_arena_placement','persistence_workspace_strategy'
},
'MEASURED_READBACK_EVIDENCE':{
    'original_firmware_backup_readback','post_flash_readback_verify','android_host_transport'
},
}

def sha256_file(p:Path)->str:
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):
            h.update(b)
    return h.hexdigest()

def load_json(p:Path)->dict:
    return json.loads(p.read_text(encoding='utf-8'))

def validate_intake_binding(intake:dict, document:Path, text_evidence:Path|None)->list[str]:
    e=[]
    if intake.get('schema')!=1 or intake.get('project_version')!=37:
        e.append('intake schema/project_version mismatch')
    if intake.get('review_ready_for_claim_mapping') is not True:
        e.append('document intake is not review-ready')
    if intake.get('authorizes_hardware') is not False or intake.get('authorizes_mobile_flash') is not False:
        e.append('intake unexpectedly authorizes hardware/mobile flash')
    if intake.get('promoted_claims') not in ([],None):
        e.append('intake must not contain pre-promoted claims')
    d=intake.get('document') or {}
    if d.get('classification')!='EXACT_TARGET_CANDIDATE':
        e.append('document must be an EXACT_TARGET_CANDIDATE')
    if d.get('reviewed') is not True:
        e.append('document must be explicitly reviewed')
    if not document.is_file():
        e.append('document file missing')
    else:
        if d.get('sha256')!=sha256_file(document):
            e.append('document SHA256 mismatch')
        if d.get('size_bytes')!=document.stat().st_size:
            e.append('document size mismatch')
    tr=intake.get('text_evidence')
    if tr is not None:
        if text_evidence is None or not text_evidence.is_file():
            e.append('bound text evidence file missing')
        else:
            if tr.get('sha256')!=sha256_file(text_evidence):
                e.append('text evidence SHA256 mismatch')
            if tr.get('size_bytes')!=text_evidence.stat().st_size:
                e.append('text evidence size mismatch')
    elif text_evidence is not None:
        e.append('unbound text evidence supplied')
    if intake.get('content_anchor_observed') is not True:
        e.append('exact-target content anchor not observed')
    return e

def build_mapping(intake:dict, document:Path, claim:str, scope:str, locator:str,
                  reviewer:str, text_evidence:Path|None=None)->dict:
    errors=validate_intake_binding(intake,document,text_evidence)
    if claim not in ALL_CLAIMS:
        errors.append('unknown qualification claim')
    if scope not in SCOPE_ALLOWED:
        errors.append('unknown evidence scope')
    elif claim not in SCOPE_ALLOWED[scope]:
        errors.append('claim is not allowed for this evidence scope')
    if not locator or not locator.strip():
        errors.append('evidence locator is required')
    if not reviewer or not reviewer.strip():
        errors.append('reviewer identifier is required')
    if errors:
        raise ValueError('; '.join(errors))
    d=intake['document']
    return {
      'schema':1,
      'project_version':37,
      'target':'BP1048P4',
      'board':'GoloPine 7CH',
      'policy':'REVIEWED_CONTENT_BOUND_SCOPE_LIMITED_SUPPORT_NO_AUTO_PROMOTION',
      'state':'REVIEWED_SUPPORT_MAPPING_NON_AUTHORIZING',
      'claim':claim,
      'evidence_scope':scope,
      'evidence':{
        'document_sha256':sha256_file(document),
        'document_size_bytes':document.stat().st_size,
        'document_source':d.get('source'),
        'document_classification':d.get('classification'),
        'text_evidence_sha256':sha256_file(text_evidence) if text_evidence else None,
        'locator':locator.strip(),
        'reviewer':reviewer.strip(),
      },
      'supported_non_authorizing':True,
      'promoted_to_target_qualification':False,
      'target_qualification_mutated':False,
      'authorizes_hardware':False,
      'authorizes_mobile_flash':False,
      'notes':'This mapping binds reviewed supporting evidence to one claim. Promotion/authorization remains a separate explicit reviewed step.'
    }

def locked_ok(m:dict)->bool:
    return (
      m.get('schema')==1 and m.get('project_version')==37 and
      m.get('state')=='LOCKED_NO_REVIEWED_CLAIM_MAPPING' and
      m.get('mappings')==[] and
      m.get('auto_promotes_target_qualification') is False and
      m.get('authorizes_hardware') is False and
      m.get('authorizes_mobile_flash') is False
    )

def main()->int:
    ap=argparse.ArgumentParser(description='V37 reviewed exact-target claim mapping; non-authorizing.')
    ap.add_argument('--expect-locked',action='store_true')
    ap.add_argument('--intake-record',type=Path)
    ap.add_argument('--document',type=Path)
    ap.add_argument('--text-evidence',type=Path)
    ap.add_argument('--claim',choices=sorted(ALL_CLAIMS))
    ap.add_argument('--scope',choices=sorted(SCOPE_ALLOWED))
    ap.add_argument('--locator')
    ap.add_argument('--reviewer')
    ap.add_argument('--output',type=Path)
    a=ap.parse_args()
    if a.expect_locked:
        m=load_json(MANIFEST)
        if not locked_ok(m):
            print('ERROR: shipped V37 target claim mapping manifest is not locked/empty',file=sys.stderr)
            return 1
        print('TARGET_CLAIM_MAPPING=LOCKED_NO_REVIEWED_CLAIM_MAPPING')
        print('PASS: V37 reviewed claim mapping is content-bound, scope-limited, and non-authorizing')
        return 0
    if not a.intake_record or not a.intake_record.is_file(): ap.error('--intake-record is required')
    if not a.document or not a.document.is_file(): ap.error('--document is required')
    if not a.claim or not a.scope or not a.locator or not a.reviewer:
        ap.error('--claim --scope --locator --reviewer are required')
    try:
        rec=build_mapping(load_json(a.intake_record),a.document,a.claim,a.scope,a.locator,a.reviewer,a.text_evidence)
    except ValueError as ex:
        print('ERROR: '+str(ex),file=sys.stderr); return 1
    out=json.dumps(rec,indent=2,sort_keys=True,ensure_ascii=False)+'\n'
    if a.output: a.output.write_text(out,encoding='utf-8')
    else: print(out,end='')
    return 0

if __name__=='__main__': raise SystemExit(main())
