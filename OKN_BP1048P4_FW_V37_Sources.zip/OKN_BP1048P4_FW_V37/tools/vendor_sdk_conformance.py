#!/usr/bin/env python3
"""V37 compile-only vendor SDK adapter conformance harness.

This tool checks only whether a reviewed binding shim is syntactically compatible
with the portable adapter contract. It never links, executes target code, emits a
firmware image, or performs hardware/programmer I/O. Passing this probe NEVER
authorizes hardware or mobile flashing.
"""
from pathlib import Path
import argparse, hashlib, json, shutil, subprocess, tempfile, sys

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "vendor_sdk_binding_manifest.json"

def compile_probe(cc: str, header: str, require_exact: bool) -> dict:
    resolved = shutil.which(cc) if "/" not in cc else cc
    result = {
        "schema": 1, "project_version": 37, "compiler": cc,
        "compiler_resolved": resolved, "binding_header": header,
        "require_exact_target": require_exact, "compile_only": True,
        "linker_invoked": False, "target_code_executed": False,
        "firmware_image_emitted": False, "hardware_io_performed": False,
        "authorizes_hardware": False, "authorizes_mobile_flash": False,
        "compile_pass": False,
    }
    if not resolved:
        result["error"] = "compiler not found"
        return result
    with tempfile.TemporaryDirectory(prefix="okn-v30-sdk-bind-") as td:
        out = Path(td)/"probe.o"
        macro = f'-DOKN_VENDOR_BINDING_HEADER="{header}"'
        cmd = [resolved, "-std=c11", "-Wall", "-Wextra", "-Werror", "-pedantic",
               "-Isrc", "-Itests/fixtures", macro]
        if require_exact:
            cmd += ["-DOKN_VENDOR_REQUIRE_EXACT_TARGET=1"]
        cmd += ["-c", "tests/vendor_sdk_binding_probe.c", "-o", str(out)]
        cp = subprocess.run(cmd, cwd=ROOT, text=True, capture_output=True, timeout=30)
        result["compiler_returncode"] = cp.returncode
        result["compile_pass"] = cp.returncode == 0 and out.exists()
        if cp.stderr:
            result["stderr_tail"] = cp.stderr[-4000:]
    return result

def verify_locked_manifest() -> list[str]:
    m = json.loads(MANIFEST.read_text())
    e=[]
    if m.get("schema") != 1 or m.get("project_version") != 37: e.append("binding manifest schema/version mismatch")
    if m.get("state") != "LOCKED_NO_EXACT_VENDOR_BINDING": e.append("shipped binding manifest must remain locked")
    if m.get("binding_header") is not None or m.get("binding_header_sha256") is not None: e.append("shipped binding header must remain absent")
    if m.get("reviewed") is not False: e.append("shipped binding must remain unreviewed")
    if m.get("evidence_class") != "NONE": e.append("shipped binding evidence class must remain NONE")
    if m.get("exact_bp1048p4_identity_verified") is not False or m.get("exact_golopine_board_verified") is not False: e.append("exact target evidence must remain false")
    for k in ["linker_invoked","target_code_executed","firmware_image_emitted","hardware_io_performed","authorizes_hardware","authorizes_mobile_flash"]:
        if m.get(k) is not False: e.append(k+" must remain false")
    if m.get("compile_only") is not True: e.append("compile_only must be true")
    return e

def main() -> int:
    ap=argparse.ArgumentParser(description="Compile-only V37 vendor SDK binding conformance; non-authorizing.")
    ap.add_argument("--cc", default="gcc")
    ap.add_argument("--header")
    ap.add_argument("--require-exact", action="store_true")
    ap.add_argument("--expect-locked", action="store_true")
    ap.add_argument("--self-test", action="store_true")
    args=ap.parse_args()

    if args.expect_locked:
        errors=verify_locked_manifest()
        if errors:
            for x in errors: print("BLOCKED:",x)
            return 1
        print("PASS: V37 shipped vendor SDK binding manifest is locked and non-authorizing")
        return 0

    if args.self_test:
        fam=compile_probe(args.cc, "family_only_vendor_shim.h", False)
        fam_exact=compile_probe(args.cc, "family_only_vendor_shim.h", True)
        syn=compile_probe(args.cc, "synthetic_exact_vendor_shim.h", True)
        if not fam["compile_pass"] or fam_exact["compile_pass"] or not syn["compile_pass"]:
            print(json.dumps({"family_shape":fam,"family_exact":fam_exact,"synthetic_exact":syn}, sort_keys=True))
            return 1
        print("PASS: V37 SDK conformance self-test accepts family ABI shape, rejects family as exact target, and accepts test-only exact shape")
        return 0

    if not args.header:
        ap.error("--header is required unless --expect-locked or --self-test is used")
    r=compile_probe(args.cc,args.header,args.require_exact)
    print(json.dumps(r,sort_keys=True))
    return 0 if r["compile_pass"] else 1

if __name__=="__main__":
    raise SystemExit(main())
