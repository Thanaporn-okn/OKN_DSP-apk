#!/usr/bin/env python3
from pathlib import Path
import json, sys
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/"tools"))
from discovery_fingerprint import derive

errors=[]
expected=json.loads((root/"transport_fingerprint_manifest.json").read_text())
actual=derive(root)
if actual!=expected:
    errors.append("transport_fingerprint_manifest.json is stale or not derived from current discovery bundle")
if expected.get("schema")!=1 or expected.get("project_version")!=37:
    errors.append("fingerprint schema/version mismatch")
if expected.get("state")!="LOCKED_NO_CAPTURE":
    errors.append("shipped V37 fingerprint state must remain LOCKED_NO_CAPTURE")
if expected.get("automatic_authorization") is not False:
    errors.append("fingerprint automatic authorization must remain false")
if expected.get("android_host_transport_verified") is not False:
    errors.append("fingerprint may not directly verify android_host_transport")
if expected.get("programmer_io_available") is not False:
    errors.append("fingerprint layer may not provide programmer IO")
for name,rec in expected.get("transports",{}).items():
    if rec.get("session_count")!=0:
        errors.append(name+": shipped fingerprint sessions must be zero")
    if rec.get("hardware_authorized") is not False or rec.get("mobile_flash_authorized") is not False:
        errors.append(name+": fingerprint observation may not authorize hardware")
if errors:
    for e in errors: print("BLOCKED:",e)
    sys.exit(1)
print("PASS: V37 multi-capture transport fingerprint is derived, volatile-ID-minimized, and non-authorizing")
