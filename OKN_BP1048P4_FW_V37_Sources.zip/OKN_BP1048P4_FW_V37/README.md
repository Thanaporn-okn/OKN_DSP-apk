# OKN_BP1048P4_FW_V37

V37 hardens the portable control session against nested/re-entrant execution while preserving Protocol V2, persistence schema 2, all V36 revision-bound replay behavior, and every exact-target hardware lock.

## What V37 adds

- Content-bound user board-photo evidence verifies the physical U24 package marking `MVSILICON BP1048P4`.
- PCB identifier `HQPCB-2` and rear product/channel labels are recorded as physical observations only.
- GoloPine brand binding, programmer interface, boot pins, linker/image format, and write protocol remain unverified/locked.

- `okn_control_session_t` now has an explicit in-flight execution guard.
- A second `okn_control_session_execute()` entry while the same session is already executing returns `OKN_ERR_REENTRANT`.
- Re-entrant rejection does not mutate DSP state, controller revision, duplicate cache, or cached response metadata.
- Diagnostic `reentrant_rejections` counts rejected nested entries.
- V36 exact-byte + revision-bound replay cache behavior is preserved.
- No target-specific register, linker, boot, BLE-write, NVM, image-format, or programmer packet has been added.

## Hardware status

The portable firmware core remains host-validated only. Physical BP1048P4 chip identity is now content-bound from the board photo set, but GoloPine board provenance, programmer/debug path, linker/image format, boot pins, and flashing remain fail-closed until separately proven and explicitly authorized.
