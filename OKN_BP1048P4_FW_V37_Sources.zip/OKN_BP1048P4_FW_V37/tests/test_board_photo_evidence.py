#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,tempfile,shutil
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'board_photo_evidence_manifest.json').read_text())
assert m['project_version']==37
assert m['observations']['exact_chip_identity']['marking']=='MVSILICON BP1048P4'
assert m['observations']['pcb_identifier']['marking']=='HQPCB-2'
assert m['hardware_authorized'] is False and m['mobile_flash_authorized'] is False
assert 'programmer_transport' in m['not_established']
# Exact chip claim must bind to the actual reviewed photo bytes.
qb=json.loads((root/'qualification_bundle_manifest.json').read_text())
photo=next(a for a in qb['artifacts'] if a['id']=='board-photo-37402-u24')
p=root/'qualification_evidence'/photo['path']
assert hashlib.sha256(p.read_bytes()).hexdigest()==photo['sha256']
tq=json.loads((root/'target_qualification_manifest.json').read_text())
claim=tq['claims']['exact_chip_identity']
assert claim['verified'] is True and claim['reviewed'] is True
assert claim['classification']=='EXACT_TARGET'
assert claim['artifact_sha256']==photo['sha256'] and claim['artifact_id']==photo['id']
# Photos must not promote brand/programmer/board-map claims.
for k in ('exact_golopine_board_identity','programmer_transport','flash_programmer','board_pin_map'):
    assert tq['claims'][k]['verified'] is False
print('ALL V37 BOARD PHOTO EVIDENCE TESTS PASS')
