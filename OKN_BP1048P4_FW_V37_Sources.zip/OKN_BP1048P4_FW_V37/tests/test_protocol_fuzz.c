#include "../src/transport/okn_stream.h"
#include "../src/core/okn_controller.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

static uint32_t prng_state = 0x25A5F00Du;
static uint32_t prng32(void) {
    uint32_t x = prng_state;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    prng_state = x;
    return x;
}

static size_t finish_pkt(uint8_t *p, uint8_t cmd, const uint8_t *payload, uint16_t plen) {
    p[0]=OKN_PROTO_MAGIC0; p[1]=OKN_PROTO_MAGIC1; p[2]=OKN_PROTO_VERSION; p[3]=cmd;
    p[4]=(uint8_t)plen; p[5]=(uint8_t)(plen>>8);
    if (plen) memcpy(&p[6],payload,plen);
    const uint16_t crc=okn_crc16_ccitt(p,6u+plen);
    p[6u+plen]=(uint8_t)crc; p[7u+plen]=(uint8_t)(crc>>8);
    return 8u+plen;
}

typedef struct {
    okn_controller_t ctl;
    unsigned calls;
} sink_t;

static okn_status_t on_frame(void *u, const uint8_t *frame, size_t len) {
    sink_t *s=(sink_t*)u;
    uint8_t rsp[OKN_PROTO_MAX_PACKET];
    const okn_protocol_result_t r=okn_protocol_execute_ex(&s->ctl,frame,len,rsp,sizeof(rsp));
    ++s->calls;
    return r.transport_status;
}

int main(void) {
    okn_controller_t ctl;
    okn_controller_init(&ctl);
    const uint32_t rev0=ctl.revision;
    uint8_t rsp[OKN_PROTO_MAX_PACKET];

    /* All-short / non-magic inputs must fail framing and never mutate state. */
    for (size_t n=0u; n<OKN_PROTO_MAX_PACKET+32u; ++n) {
        uint8_t b[OKN_PROTO_MAX_PACKET+32u];
        for (size_t i=0u;i<n;++i) {
            uint8_t v=(uint8_t)prng32();
            if (v==OKN_PROTO_MAGIC0) v=0u; /* prevent accidental valid magic */
            b[i]=v;
        }
        okn_protocol_result_t r=okn_protocol_execute_ex(&ctl,b,n,rsp,sizeof(rsp));
        assert(r.transport_status!=OKN_OK);
        assert(r.command_evaluated==false);
        assert(r.response_len==0u);
        assert(ctl.revision==rev0);
    }

    /* Single-byte corruption of a valid PING must never dispatch a mutation. */
    uint8_t ping[16];
    const size_t pn=finish_pkt(ping,OKN_CMD_PING,NULL,0u);
    for (size_t i=0u;i<pn;++i) {
        uint8_t bad[16];
        memcpy(bad,ping,pn);
        bad[i]^=0x01u;
        okn_protocol_result_t r=okn_protocol_execute_ex(&ctl,bad,pn,rsp,sizeof(rsp));
        assert(r.transport_status!=OKN_OK);
        assert(r.command_evaluated==false);
        assert(r.response_len==0u);
        assert(ctl.revision==rev0);
    }

    /* A syntactically valid unsupported command gets a negative ACK, not a
     * transport failure, and must not mutate the controller. */
    uint8_t unsupported[16];
    const size_t un=finish_pkt(unsupported,0x66u,NULL,0u);
    okn_protocol_result_t ur=okn_protocol_execute_ex(&ctl,unsupported,un,rsp,sizeof(rsp));
    assert(ur.transport_status==OKN_OK);
    assert(ur.command_evaluated==true);
    assert(ur.command_status==OKN_ERR_UNSUPPORTED);
    assert(ur.response_len>0u);
    assert(ctl.revision==rev0);

    /* Deterministic stream corruption/resynchronization corpus. Random noise
     * never contains 'O', so only injected valid frames can be delivered. */
    okn_stream_t st;
    sink_t sink;
    okn_stream_init(&st);
    okn_controller_init(&sink.ctl);
    sink.calls=0u;
    unsigned injected=0u;

    for (unsigned round=0u; round<4000u; ++round) {
        uint8_t noise[37];
        size_t nn=(size_t)(prng32()%sizeof(noise));
        for (size_t i=0u;i<nn;++i) {
            uint8_t v=(uint8_t)prng32();
            if (v==OKN_PROTO_MAGIC0) v=0x00u;
            noise[i]=v;
        }
        assert(okn_stream_feed(&st,noise,nn,on_frame,&sink)==OKN_OK);

        if ((round%53u)==0u) {
            size_t split=1u+(prng32()%(pn-1u));
            assert(okn_stream_feed(&st,ping,split,on_frame,&sink)==OKN_OK);
            assert(okn_stream_feed(&st,ping+split,pn-split,on_frame,&sink)==OKN_OK);
            ++injected;
        }

        assert(st.len<=OKN_STREAM_BUFFER_CAP);
        assert(okn_validate_state(&sink.ctl.state)==OKN_OK);
    }
    assert(sink.calls==injected);
    assert(st.frames_ok==injected);
    assert(sink.ctl.revision==0u);

    /* Oversized payload claims must resync rather than grow the buffer. */
    uint8_t poison[12]={OKN_PROTO_MAGIC0,OKN_PROTO_MAGIC1,OKN_PROTO_VERSION,OKN_CMD_PING,
                        0xFFu,0x7Fu,0u,0u,0u,0u,0u,0u};
    for (unsigned i=0u;i<200u;++i)
        assert(okn_stream_feed(&st,poison,sizeof(poison),on_frame,&sink)==OKN_OK);
    assert(st.len<=OKN_STREAM_BUFFER_CAP);
    assert(st.format_errors>0u);

    puts("ALL V37 PROTOCOL/STREAM FUZZ TESTS PASS");
    return 0;
}
