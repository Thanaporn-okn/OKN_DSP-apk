#!/usr/bin/env python3
import importlib.util, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('tmi',ROOT/'tools/target_memory_intake.py')
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

text='''\nMEMORY\n{\n  TEST_RAM (rwx) : ORIGIN = 0x1000, LENGTH = 64K\n  TEST_ROM (rx)  : ORIGIN = 0x200000, LENGTH = 1M\n}\n'''
regions=m.parse_memory_regions(text)
assert len(regions)==2
assert regions[0]['name']=='TEST_RAM' and regions[0]['origin_value']==0x1000 and regions[0]['length_bytes']==65536
assert regions[1]['length_bytes']==1048576
# Expressions are intentionally not evaluated: no arithmetic/macro inference.
expr=m.parse_memory_regions('MEMORY {\n X : ORIGIN = BASE, LENGTH = 64K\n}')
assert len(expr)==1 and expr[0]['origin_value'] is None and expr[0]['literal_values_only'] is False
with tempfile.TemporaryDirectory() as td:
    p=Path(td)/'synthetic.ld'; p.write_text(text)
    fam=m.build_report(p,'FAMILY_ONLY',True)
    assert fam['state']=='PARSED_FAMILY_ONLY_NON_AUTHORIZING'
    assert fam['review_ready'] is False and fam['authorizes_hardware'] is False
    ex=m.build_report(p,'EXACT_TARGET',True)
    assert ex['state']=='PARSED_EXACT_TARGET_REVIEWED_NON_AUTHORIZING'
    assert ex['review_ready'] is True
    assert ex['exact_ram_capacity_verified'] is False
    assert ex['delay_arena_placement_verified'] is False
    assert ex['authorizes_hardware'] is False and ex['authorizes_mobile_flash'] is False
print('ALL V37 TARGET MEMORY INTAKE TESTS PASS')
