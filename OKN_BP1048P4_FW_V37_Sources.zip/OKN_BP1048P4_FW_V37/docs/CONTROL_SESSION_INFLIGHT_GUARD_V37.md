# V37 control-session in-flight guard

V37 adds a single-session in-flight guard around `okn_control_session_execute()`.

The guard is intentionally a fail-closed re-entrancy guard, not a claim of thread safety.
A second entry while the same session is already executing is rejected with
`OKN_ERR_REENTRANT` before protocol evaluation, cache mutation, or DSP mutation.

This preserves V36's exact-byte, revision-bound replay cache and prevents a future
transport/callback integration from recursively entering the same control session.

No hardware I/O, programmer command, target address, pin, register, or firmware-image
format is introduced by this change.
