# V37 physical board-photo evidence

Five user-supplied photos from the physical project board are copied byte-for-byte into `qualification_evidence/board_photos/` and bound by SHA-256 in `board_photo_evidence_manifest.json` and `qualification_bundle_manifest.json`.

The clearest top-side photo (`37402.jpg`) visibly shows the U24 package marking `MVSILICON BP1048P4`. V37 therefore qualifies only the `exact_chip_identity` claim from this content-bound physical observation.

Other visible board observations include PCB identifier `HQPCB-2`, rear silkscreen `3/5/7-channels DSP Wireless audio front stage`, `Power DC 5-30V`, `USB-A`, `USB-C`, `SPDIF`, `AMP_EN GND`, channel group labels, and the four analog-control labels.

These photographs do **not** establish GoloPine brand provenance, MCU pin mapping, a programmer/debug connector, boot pins, programmer transport packets, linker/memory map, image format, NVM layout, BLE API, or audio-route internals. No hardware or mobile-flash authorization is granted by the photographs.
