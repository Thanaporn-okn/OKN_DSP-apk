# V36 revision-bound control-session replay cache

The one-entry duplicate-response cache is valid only while the controller revision is unchanged from the revision captured when the request was evaluated.

This prevents an exact-byte retry from replaying a stale ACK/response after another trusted controller path has changed DSP state. A revision mismatch invalidates the cached entry, increments `stale_cache_misses`, and re-evaluates the request against current state.

This remains a retry/idempotence mechanism, not a cryptographic anti-replay protocol. The transport contract is still one outstanding application request at a time, with `okn_control_session_reset()` required at a disconnect/reconnect boundary.
