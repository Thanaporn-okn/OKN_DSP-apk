OKN DSP Controller V5.3 COMPLETE FIX

Fix:
- Removed invalid ${applicationName} placeholder in AndroidManifest
- Fixed Manifest merger failure

Build:
flutter pub get
flutter build apk --release
