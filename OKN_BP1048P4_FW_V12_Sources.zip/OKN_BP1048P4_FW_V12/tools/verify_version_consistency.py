#!/usr/bin/env python3
from pathlib import Path
import json,re,sys
root=Path(__file__).resolve().parents[1]
h=(root/"src/core/okn_version.h").read_text()
def macro(name):
    m=re.search(r"^#define\s+"+re.escape(name)+r"\s+(0x[0-9A-Fa-f]+|[0-9]+)u?\s*$",h,re.M)
    if not m: raise SystemExit("missing macro "+name)
    return int(m.group(1),0)
project=macro("OKN_PROJECT_VERSION"); fw=macro("OKN_FW_VERSION"); proto=macro("OKN_PROTO_VERSION")
fm=json.loads((root/"firmware_manifest.json").read_text())
em=json.loads((root/"evidence_manifest.json").read_text())
sm=json.loads((root/"flash_session_manifest.json").read_text())
rm=json.loads((root/"resource_requirements.json").read_text())
errors=[]
if project!=12 or fw!=12: errors.append("C project/firmware version must be 12")
if proto!=2: errors.append("protocol version must remain 2")
if fm.get("version")!=project: errors.append("firmware_manifest version mismatch")
if fm.get("protocol_version")!=proto: errors.append("protocol manifest mismatch")
if em.get("project_version")!=project: errors.append("evidence manifest mismatch")
if sm.get("project_version")!=project: errors.append("flash session manifest mismatch")
if rm.get("project_version")!=project: errors.append("resource manifest mismatch")
if errors:
    [print("BLOCKED:",e) for e in errors]; sys.exit(1)
print("PASS: V12 version constants and manifests are consistent (FW=12, protocol=2)")
