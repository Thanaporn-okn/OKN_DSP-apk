#!/usr/bin/env python3
from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[1]
m=json.loads((root/"evidence_manifest.json").read_text())
errors=[]
if m.get("schema")!=3: errors.append("evidence schema must be 3")
if m.get("project_version")!=12: errors.append("project_version must be 12")
if m.get("target")!="BP1048P4" or m.get("board")!="GoloPine 7CH": errors.append("target/board mismatch")
if m.get("policy")!="FAIL_CLOSED_NO_INFERENCE": errors.append("policy mismatch")
if m.get("hardware_authorized") is not False: errors.append("hardware_authorized must be false")
req=m.get("required_exact_evidence",{})
if any(bool(v) for v in req.values()): errors.append("V12 exact evidence flags must all remain false")
prov=m.get("provenance",{})
if prov.get("previous_source_sha256")!="4338af05271e93249293dea827fc85a420ed4824e1265d87b53dc638ccc7401d": errors.append("V11 source provenance mismatch")
if prov.get("validation_zip_sha256")!="93cbb5026d501fc31e78552a2d57fe6793bf4ace55f6712297b5e1187210ec59": errors.append("V11 validation provenance mismatch")
for ob in m.get("observations",[]):
    if ob.get("authorizes") not in ([],None): errors.append("observations may not authorize hardware in V12")
if errors:
    [print("BLOCKED:",e) for e in errors]; sys.exit(1)
print("PASS: V12 evidence manifest is internally consistent and non-authorizing")
