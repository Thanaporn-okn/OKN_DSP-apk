#ifndef OKN_PROTOCOL_H
#define OKN_PROTOCOL_H

#include "okn_controller.h"
#include "okn_version.h"
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define OKN_PROTO_MAGIC0 0x4Fu /* O */
#define OKN_PROTO_MAGIC1 0x4Bu /* K */
#define OKN_PROTO_MAX_PAYLOAD 128u

typedef enum {
    OKN_CMD_PING = 0x01,
    OKN_CMD_GET_INFO = 0x02,
    OKN_CMD_GET_MASTER_STATE = 0x03,
    OKN_CMD_GET_CHANNEL_STATE = 0x04,
    OKN_CMD_GET_PEQ_STATE = 0x05,
    OKN_CMD_SET_MASTER_GAIN = 0x10,
    OKN_CMD_SET_CH_GAIN = 0x11,
    OKN_CMD_SET_CH_MUTE = 0x12,
    OKN_CMD_SET_CH_PHASE = 0x13,
    OKN_CMD_SET_CH_DELAY = 0x14,
    OKN_CMD_SET_PEQ = 0x20,
    OKN_CMD_SET_HPF = 0x21,
    OKN_CMD_SET_LPF = 0x22,
    OKN_CMD_MASTER_STATE = 0x73,
    OKN_CMD_CHANNEL_STATE = 0x74,
    OKN_CMD_PEQ_STATE = 0x75,
    OKN_CMD_ACK = 0x7E,
    OKN_CMD_INFO = 0x7F
} okn_command_t;

/*
 * V12 separates transport/framing/encoding success from application command
 * success. A valid frame can therefore produce a negative ACK while the
 * transport itself remains OK.
 */
typedef struct {
    okn_status_t transport_status;
    okn_status_t command_status;
    size_t response_len;
    bool command_evaluated;
} okn_protocol_result_t;

uint16_t okn_crc16_ccitt(const uint8_t *data, size_t len);
okn_status_t okn_protocol_apply(okn_controller_t *ctl, const uint8_t *packet, size_t len);
okn_protocol_result_t okn_protocol_execute_ex(okn_controller_t *ctl,
                                              const uint8_t *packet, size_t len,
                                              uint8_t *response, size_t response_cap);
okn_status_t okn_protocol_execute(okn_controller_t *ctl, const uint8_t *packet, size_t len,
                                  uint8_t *response, size_t response_cap, size_t *response_len);

#endif
