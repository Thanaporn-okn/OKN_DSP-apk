#include "okn_audio_engine.h"
#include <math.h>
#include <string.h>

_Static_assert(sizeof(float) == 4u, "V12 reference DSP requires 32-bit float");

static okn_biquad_kind_t peq_kind(okn_filter_type_t type) {
    switch (type) {
        case OKN_FILTER_PEQ: return OKN_BIQUAD_PEQ;
        case OKN_FILTER_LOW_SHELF: return OKN_BIQUAD_LOW_SHELF;
        case OKN_FILTER_HIGH_SHELF: return OKN_BIQUAD_HIGH_SHELF;
        case OKN_FILTER_NOTCH: return OKN_BIQUAD_NOTCH;
        case OKN_FILTER_BYPASS: default: return OKN_BIQUAD_BYPASS;
    }
}

size_t okn_audio_engine_required_delay_arena_samples(void) {
    return OKN_AUDIO_REF_DELAY_ARENA_SAMPLES;
}

static void init_coefficients(okn_audio_engine_t *engine) {
    for (unsigned c = 0; c < OKN_CHANNELS; ++c) {
        engine->lane[c].gain_linear = 1.0f;
        okn_biquad_identity(&engine->lane[c].hpf);
        okn_biquad_identity(&engine->lane[c].lpf);
        for (unsigned b = 0; b < OKN_PEQ_BANDS; ++b)
            okn_biquad_identity(&engine->lane[c].peq[b]);
    }
}

okn_status_t okn_audio_engine_bind_delay_arena(okn_audio_engine_t *engine,
                                                float *delay_arena,
                                                size_t delay_arena_samples) {
    if (!engine) return OKN_ERR_ARG;
    if (!delay_arena || delay_arena_samples < OKN_AUDIO_REF_DELAY_ARENA_SAMPLES)
        return OKN_ERR_BUFFER;

    engine->delay_arena = delay_arena;
    engine->delay_arena_samples = delay_arena_samples;
    memset(delay_arena, 0, OKN_AUDIO_REF_DELAY_ARENA_BYTES);

    for (unsigned c = 0; c < OKN_CHANNELS; ++c) {
        okn_audio_lane_t *l = &engine->lane[c];
        l->delay_line = &delay_arena[(size_t)c * OKN_AUDIO_REF_DELAY_STRIDE_SAMPLES];
        l->delay_capacity = OKN_AUDIO_REF_DELAY_STRIDE_SAMPLES;
        l->delay_pos = 0u;
    }
    return OKN_OK;
}

okn_status_t okn_audio_engine_init(okn_audio_engine_t *engine, uint32_t sample_rate_hz) {
    if (!engine) return OKN_ERR_ARG;
    if (sample_rate_hz == 0u || sample_rate_hz > OKN_AUDIO_REF_MAX_SAMPLE_RATE_HZ)
        return OKN_ERR_RANGE;
    memset(engine, 0, sizeof(*engine));
    engine->sample_rate_hz = sample_rate_hz;
    init_coefficients(engine);
    return OKN_OK;
}

okn_status_t okn_audio_engine_init_with_delay_arena(okn_audio_engine_t *engine,
                                                     uint32_t sample_rate_hz,
                                                     float *delay_arena,
                                                     size_t delay_arena_samples) {
    okn_status_t rc = okn_audio_engine_init(engine, sample_rate_hz);
    if (rc != OKN_OK) return rc;
    return okn_audio_engine_bind_delay_arena(engine, delay_arena, delay_arena_samples);
}

void okn_audio_engine_reset_history(okn_audio_engine_t *engine) {
    if (!engine) return;
    for (unsigned c = 0; c < OKN_CHANNELS; ++c) {
        okn_audio_lane_t *l = &engine->lane[c];
        okn_biquad_reset(&l->hpf_mem);
        okn_biquad_reset(&l->lpf_mem);
        for (unsigned b = 0; b < OKN_PEQ_BANDS; ++b)
            okn_biquad_reset(&l->peq_mem[b]);
        if (l->delay_line && l->delay_capacity)
            memset(l->delay_line, 0, (size_t)l->delay_capacity * sizeof(float));
        l->delay_pos = 0u;
    }
}

static okn_status_t design_or_identity(bool enabled, okn_biquad_kind_t kind,
                                       float fs, float freq, float gain, float q,
                                       okn_biquad_coeff_t *out) {
    if (!enabled || kind == OKN_BIQUAD_BYPASS) {
        okn_biquad_identity(out);
        return OKN_OK;
    }
    return okn_biquad_design(kind, fs, freq, gain, q, out);
}

okn_status_t okn_audio_engine_prepare(okn_audio_engine_t *engine,
                                      const okn_dsp_state_t *state,
                                      uint32_t revision) {
    if (!engine || !state || engine->sample_rate_hz == 0u) return OKN_ERR_ARG;
    if (okn_validate_state(state) != OKN_OK) return OKN_ERR_RANGE;

    const float fs = (float)engine->sample_rate_hz;
    for (unsigned c = 0; c < OKN_CHANNELS; ++c) {
        const okn_channel_state_t *s = &state->ch[c];
        okn_audio_lane_t *l = &engine->lane[c];

        l->gain_linear = okn_effective_channel_linear_gain(state, c);

        okn_status_t rc = design_or_identity(s->hpf.enabled, OKN_BIQUAD_HPF, fs,
                                             s->hpf.freq_hz, 0.0f, s->hpf.q, &l->hpf);
        if (rc != OKN_OK) return rc;

        rc = design_or_identity(s->lpf.enabled, OKN_BIQUAD_LPF, fs,
                                s->lpf.freq_hz, 0.0f, s->lpf.q, &l->lpf);
        if (rc != OKN_OK) return rc;

        for (unsigned b = 0; b < OKN_PEQ_BANDS; ++b) {
            const okn_peq_band_t *p = &s->peq[b];
            rc = design_or_identity(p->enabled, peq_kind(p->type), fs,
                                    p->freq_hz, p->gain_db, p->q, &l->peq[b]);
            if (rc != OKN_OK) return rc;
        }

        const float delay_f = s->delay_ms * fs / 1000.0f;
        const uint32_t delay = (uint32_t)lroundf(delay_f);
        if (delay > OKN_AUDIO_REF_MAX_DELAY_SAMPLES) return OKN_ERR_RANGE;

        if (delay > 0u) {
            if (!l->delay_line || l->delay_capacity <= delay)
                return OKN_ERR_BUFFER;
        }

        l->delay_samples = delay;
        if (l->delay_pos >= (delay ? delay : 1u))
            l->delay_pos = 0u;
    }

    engine->prepared_revision = revision;
    return OKN_OK;
}

static float apply_delay(okn_audio_lane_t *l, float x) {
    if (l->delay_samples == 0u) return x;
    const uint32_t n = l->delay_samples;
    if (!l->delay_line || l->delay_capacity <= n) return 0.0f; /* prepare() prevents this */
    if (l->delay_pos >= n) l->delay_pos = 0u;
    const float y = l->delay_line[l->delay_pos];
    l->delay_line[l->delay_pos] = x;
    ++l->delay_pos;
    if (l->delay_pos >= n) l->delay_pos = 0u;
    return y;
}

void okn_audio_engine_process_frame(okn_audio_engine_t *engine,
                                    const float in[OKN_CHANNELS],
                                    float out[OKN_CHANNELS]) {
    if (!engine || !in || !out) return;
    for (unsigned c = 0; c < OKN_CHANNELS; ++c) {
        okn_audio_lane_t *l = &engine->lane[c];
        float y = okn_biquad_process(&l->hpf, &l->hpf_mem, in[c]);
        for (unsigned b = 0; b < OKN_PEQ_BANDS; ++b)
            y = okn_biquad_process(&l->peq[b], &l->peq_mem[b], y);
        y = okn_biquad_process(&l->lpf, &l->lpf_mem, y);
        y *= l->gain_linear;
        out[c] = apply_delay(l, y);
    }
}
