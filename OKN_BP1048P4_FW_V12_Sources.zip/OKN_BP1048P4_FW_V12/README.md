# OKN_BP1048P4_FW_V12

Portable clean-room control/DSP firmware architecture for the GoloPine 7CH
target using BP1048P4 as the intended chip. Hardware access remains fail-closed.

V11 GitHub Actions validation was accepted with source SHA
`4338af05271e93249293dea827fc85a420ed4824e1265d87b53dc638ccc7401d` and validation ZIP SHA
`93cbb5026d501fc31e78552a2d57fe6793bf4ace55f6712297b5e1187210ec59`.

V12 is a control-plane integrity release. Protocol mutations now use
controller-level APIs that combine validated DSP mutation + dirty tracking +
revision update as one logical operation. Rejected values leave all three
unchanged.

V12 also introduces `okn_protocol_execute_ex()` and
`okn_protocol_result_t`, separating transport/framing/encoding status from
application command status. A syntactically valid frame whose command is
rejected produces a negative ACK while transport remains healthy; bad CRC or
bad framing is rejected before command execution.

V11 memory-readiness behavior is preserved:
- external caller-owned 7CH delay arena
- non-zero delay fails closed without the arena
- exact BP1048P4 RAM capacity/placement remains unverified and locked

Run `make verify`, `make test`, and `make demo`.
This release remains `hardware_flashable=false` and `mobile_flashable=false`
and intentionally ships no target `.bin`.
