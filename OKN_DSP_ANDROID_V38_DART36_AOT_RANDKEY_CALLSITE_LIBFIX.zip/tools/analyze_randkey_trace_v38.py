#!/usr/bin/env python3
from pathlib import Path
import argparse, re, json

ap=argparse.ArgumentParser()
ap.add_argument('--root', default='blutter_out')
ap.add_argument('--target', default='target')
ap.add_argument('--out', default='artifact')
a=ap.parse_args()
root=Path(a.root); target=Path(a.target); out=Path(a.out); out.mkdir(parents=True, exist_ok=True)
patterns=[
    r'RandKey', r'authentication response data length', r'AES/', r'cfb8', r'CFB-8',
    r'ENCRYPTED_SIZE', r'notify_encryption_required', r'Device Type and software version authentication',
    r'GetDevcieDescriptionCommand', r'WriteActuatorPeriperalCommand'
]
pat=re.compile('|'.join(patterns), re.I)
summary=[]; contexts=[]
for name in ['pp.txt','objs.txt']:
    p=root/name
    if p.exists():
        lines=p.read_text(errors='ignore').splitlines()
        hits=[(i,l) for i,l in enumerate(lines) if pat.search(l)]
        summary.append(f'[{name}] hits={len(hits)}')
        for i,l in hits[:80]: summary.append(f'{name}:{i+1}: {l}')
asm=root/'asm'
if asm.exists():
    hit_files=0
    for p in asm.rglob('*'):
        if not p.is_file(): continue
        try: lines=p.read_text(errors='ignore').splitlines()
        except Exception: continue
        idx=[i for i,l in enumerate(lines) if pat.search(l)]
        if not idx: continue
        hit_files += 1
        for i in idx[:12]:
            lo=max(0,i-90); hi=min(len(lines),i+141)
            contexts.append(f'===== {p} hit line {i+1} =====')
            contexts.extend(f'{j+1:06d}: {lines[j]}' for j in range(lo,hi))
    summary.append(f'[asm] hit_files={hit_files}')
else:
    summary.append('[asm] not present')
for n in ['static_string_offsets.txt','dart_runtime.txt','blutter_run.log']:
    p=target/n
    if p.exists():
        summary.append(f'\n===== {n} =====')
        summary.extend(p.read_text(errors='ignore').splitlines()[:500])
(out/'V38_AOT_RANDKEY_TRACE_REPORT.txt').write_text('\n'.join(summary)+'\n')
(out/'V38_AOT_RANDKEY_ASM_CONTEXT.txt').write_text('\n'.join(contexts)+'\n')
meta={"patterns":patterns,"report_lines":len(summary),"context_lines":len(contexts),"blutter_root_exists":root.exists()}
(out/'V38_AOT_RANDKEY_TRACE_META.json').write_text(json.dumps(meta,indent=2))
print('\n'.join(summary[:80]))
