OKN DSP V38 — DART 3.6 AOT RANDKEY CALLSITE TRACE / BUNDLED LIB FIX

STATUS
- BLE/GATT/Auth16->Response32 confirmed.
- Device Description 18,150 JSON bytes, 15 actuators, 4 sensors confirmed from official session evidence.
- READ 0x58 / RESPONSE 0x60 read-back framing confirmed from 83 pairs.
- LIVE DSP parameter WRITE remains LOCKED.
- Standalone Response32 -> RandKey derivation remains the final authentication blocker.

WHY V38 EXISTS
V37 correctly detected Dart 3.6.0 and selected the exact
blutter_dartvm3.6.0_android_arm64 binary, but the AOT job failed before parsing libapp.so because the dynamic loader could not locate bundled libcapstone.so.4.

V38 fixes only that tooling/runtime problem:
- locate the bundled glibc loader
- locate its bundled lib directory
- export LD_LIBRARY_PATH to that directory
- invoke the loader with --library-path as an additional hard guarantee
- verify libcapstone.so.4 exists before execution
- keep diagnostics/artifacts even if Blutter still exits non-zero

EXPECTED ANALYSIS ARTIFACT
OKN-DSP-V38-DART36-AOT-RANDKEY-CALLSITE

Important files when successful:
- V38_AOT_RANDKEY_TRACE_REPORT.txt
- V38_AOT_RANDKEY_ASM_CONTEXT.txt
- V38_AOT_RANDKEY_TRACE_META.json
- pp.txt
- objs.txt
- blutter_asm.tar.gz
- blutter_run.log

Safety / evidence policy:
No guessed DSP writes are enabled. WRITE 0x57 remains locked until standalone session authentication is independently verified.
