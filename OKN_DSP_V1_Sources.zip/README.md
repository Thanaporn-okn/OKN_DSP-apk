# OKN_DSP V1

Flutter application for a 7-channel DSP Audio Processor, rebuilt from the five supplied reference screens: Home, EQ, Crossover, Delay and Output.

## V1 implementation

- Edge-to-edge dark neon / glassmorphism UI for phones and tablets.
- Responsive layouts that retain the five-screen reference structure.
- Fine-grained `ValueNotifier` state so sliders, switches, dropdowns and buttons update local UI state synchronously on interaction.
- Interactive Parametric EQ graph with draggable nodes.
- HPF/LPF crossover visualization and filter controls.
- Car-speaker delay visualization with ms/cm conversion at 34.3 cm/ms.
- Output level overview, Master Output, and CH1-CH7 Mute/Solo/Phase/Link controls.
- BLE discovery/connection using `flutter_reactive_ble` 5.5.0 with runtime Android Bluetooth permission handling.
- Automatic discovery of characteristic `0000AB01-0000-1000-8000-00805F9B34FB` after BLE connection.
- Raw BLE notification and write transport in `BleDspService`.
- No fabricated DSP opcode/packet mapping. The UI command gateway records every control event while actual hardware frames remain disabled until the real DSP protocol is known.

## Mobile-friendly GitHub build

Use the separately supplied `OKN_DSP_AutoBuild.yml` as the repository workflow once. After that, each version only needs one source archive such as `OKN_DSP_V1_Sources.zip` placed in the repository root. A push containing that ZIP automatically starts the build; the workflow selects the newest V-number archive, extracts it, creates platform boilerplate, analyzes, tests and builds the release APK.

The source archive intentionally excludes `.github/workflows` so the workflow and source ZIP stay separate for mobile use.

`SHA256SUMS.txt` inside the source archive verifies every shipped source file. A separate `.sha256` file verifies the ZIP itself.

## Local build

```bash
./tool/bootstrap_platforms.sh
flutter run
```

## DSP protocol boundary

Characteristic UUID discovery is not enough to infer the hardware command protocol. Correct control frames require the real opcode layout, value scaling, endianness, checksums and response behavior. V1 therefore does not invent those bytes. When real write/notify packet captures or a protocol specification are available, the byte codec can be inserted behind `DspCommandGateway` without redesigning the five screens.
