OKN_DSP V1 — CLEAN REBUILD / HOME + PARAMETRIC EQ MASTER UI
============================================================

Identity
- App: OKN_DSP
- package/applicationId: com.okn.dsp
- versionCode: 1
- versionName: 1.0.0
- minSdk 26 / target+compileSdk 35 / JDK 17

UI scope
- Clean UI rebuild uses ONLY the two user-supplied 864x1536 masters:
  1) Home: six realtime global controls + sound presets
  2) Parametric EQ: 7 channels + realtime graph + six visible verified PEAKING rows + EQ presets
- Bottom navigation follows the supplied Home / EQ / Channel / More visual language.
- No invented Crossover/Delay/Mixer control page is exposed.

Realtime behavior
- Slider/graph/field movement updates local UI state immediately.
- Verified DSP targets are queued immediately with one GATT write in flight and latest-target-wins coalescing.
- No external relay/server path exists; the Android app talks directly to the DSP over BLE.
- TrebleBoost ID11 remains callback-gated and stepped to suppress transients.

Verified hardware boundary retained from proven captures
- BLE service AB00 / write AB01 / notify AB02 / secondary notify AB03
- Auth16 + AES-CFB8 authenticated session and fresh Device Description Health Gate
- Scalar allow-list: 2,3,8,9,10,13,11
- Home screen exposes verified: 2,8,9,10,13,11
- EQ actuator map CH1..CH7: 4,5,6,14,15,16,17
- 15 records/channel; only live descriptor PEAKING type=12 records are writable
- full 48-byte EQ record writes
- SaveParams ID7 remains manual guarded only and is not emitted by sliders/presets
- unknown/crossover/delay/output/preset hardware packets remain locked; nothing is guessed

Version rule
- This request resets the line to V1.
- Any build/runtime error after this package must be fixed as V2, then V3, etc.; do not overwrite the failed version.

Build delivery
- Upload OKN_DSP_V1_Sources.zip to repository root.
- Place build-okn-dsp-v1.yml in .github/workflows/.
- The workflow runs automatically on every push and uploads OKN_DSP_V1.apk as the Actions artifact.
- SHA256 manifest is inside Sources/OKN_DSP_V1_SHA256.txt as requested.
