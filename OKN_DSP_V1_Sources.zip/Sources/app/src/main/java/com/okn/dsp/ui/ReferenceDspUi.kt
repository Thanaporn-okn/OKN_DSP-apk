package com.okn.dsp.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import com.okn.dsp.protocol.EqBand48
import com.okn.dsp.protocol.LiveEqPolicy
import com.okn.dsp.protocol.VerifiedScalarControls
import com.okn.dsp.state.ConnectionState
import com.okn.dsp.state.DspState
import com.okn.dsp.state.DspStateStore
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

interface DspUiActions {
    fun scanConnect()
    fun showMainMenu()
    fun scalarChanged(id: Int, value: Float)
    fun toggleMasterMute()
    fun channelSelected(channel: Int)
    fun bandSelected(band: Int)
    fun eqChanged(channel: Int, band: Int, frequency: Float, q: Float, gain: Float)
    fun resetGlobal()
    fun savePreset()
    fun loadPreset()
    fun flatEq()
    fun copyEq()
    fun pasteEq()
    fun reconnect()
    fun disconnect()
    fun refresh()
    fun saveParams()
    fun showLogs()
}

data class UiSnapshot(val tab: Int = 0, val parametricMode: Boolean = true)

/**
 * Clean V1 UI rebuilt specifically from the two supplied 864x1536 master screenshots.
 * Only the Home and Parametric-EQ visual language is used.  The underlying proven
 * BLE/auth/session/descriptor/realtime writer remains unchanged and fail-closed.
 */
class ReferenceDspUi(
    private val context: Context,
    private val store: DspStateStore,
    private val actions: DspUiActions,
    initial: UiSnapshot = UiSnapshot(),
) {
    private val surface = DspCanvasView(context, actions, initial.tab.coerceIn(0, 1))
    val view: View = surface
    private var unsubscribe: (() -> Unit)? = null

    init {
        unsubscribe = store.subscribe { surface.bind(it) }
    }

    fun dispose() { unsubscribe?.invoke(); unsubscribe = null }
    fun snapshot(): UiSnapshot = UiSnapshot(surface.page, true)
    fun setPresetLabel(name: String) { surface.presetLabel = name; surface.invalidate() }
}

private class DspCanvasView(
    context: Context,
    private val actions: DspUiActions,
    initialPage: Int,
) : View(context) {
    companion object {
        private const val BW = 864f
        private const val BH = 1456f
        private val BAND_COLORS = intArrayOf(
            Color.rgb(255, 55, 79), Color.rgb(255, 205, 35), Color.rgb(35, 238, 143),
            Color.rgb(0, 210, 255), Color.rgb(194, 65, 245), Color.rgb(255, 82, 169)
        )
    }

    var page: Int = initialPage.coerceIn(0, 1)
    var presetLabel: String = "Flat"
    private var state = DspState()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val baseFace = Typeface.create("sans-serif", Typeface.NORMAL)
    private val boldFace = Typeface.create("sans-serif", Typeface.BOLD)
    private val italicBold = Typeface.create("sans-serif", Typeface.BOLD_ITALIC)
    private var sx = 1f
    private var sy = 1f
    private var drag: Drag? = null
    private var selectedHomePreset = 0
    private val bypassGain = mutableMapOf<Pair<Int, Int>, Float>()

    private sealed class Drag {
        data class Scalar(val id: Int) : Drag()
        data class EqGraph(val channel: Int, val band: Int) : Drag()
        data class EqField(val channel: Int, val band: Int, val field: Int) : Drag() // 0=freq 1=gain 2=q
    }

    init {
        isClickable = true
        isFocusable = true
        setBackgroundColor(Color.rgb(0, 8, 17))
    }

    fun bind(s: DspState) { state = s; invalidate() }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        sx = w / BW
        sy = h / BH
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.save()
        canvas.scale(sx, sy)
        drawBackground(canvas)
        drawHeader(canvas)
        if (page == 0) drawHome(canvas) else drawEq(canvas)
        drawBottomNav(canvas)
        canvas.restore()
    }

    private fun drawBackground(c: Canvas) {
        c.drawColor(Color.rgb(0, 8, 17))
        p.shader = LinearGradient(0f, 0f, BW, BH, intArrayOf(Color.rgb(0, 17, 31), Color.rgb(0, 7, 14)), null, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, BW, BH, p)
        p.shader = null
    }

    private fun drawHeader(c: Canvas) {
        val ready = state.connection == ConnectionState.READY && state.healthGatePass
        val green = Color.rgb(21, 255, 115)
        circle(c, 48f, 48f, 12f, if (ready) green else Color.rgb(62, 97, 117))
        text(c, if (ready) "เชื่อมต่อแล้ว" else "แตะเพื่อเชื่อมต่อ", 82f, 43f, 25f, if (ready) green else Color.rgb(153, 184, 208), true)
        val device = state.device.bluetoothName?.takeIf { it.isNotBlank() } ?: "OKN-DSP_7CH"
        text(c, device, 82f, 72f, 18f, Color.rgb(122, 180, 227), false)
        text(c, "›", 230f, 72f, 37f, Color.rgb(150, 201, 242), false)

        text(c, "OKN_DSP", 302f, 53f, 44f, Color.WHITE, true, italic = true)
        text(c, "DIGITAL SOUND PROCESSOR", 307f, 83f, 15f, Color.rgb(0, 205, 255), true, letter = .10f)

        stroke.strokeWidth = 4f
        stroke.color = Color.rgb(0, 214, 255)
        c.drawCircle(800f, 50f, 26f, stroke)
        for (i in 0 until 8) {
            val a = Math.toRadians((i * 45.0))
            val x1 = 800f + (31f * kotlin.math.cos(a)).toFloat()
            val y1 = 50f + (31f * kotlin.math.sin(a)).toFloat()
            val x2 = 800f + (39f * kotlin.math.cos(a)).toFloat()
            val y2 = 50f + (39f * kotlin.math.sin(a)).toFloat()
            c.drawLine(x1, y1, x2, y2, stroke)
        }
        c.drawCircle(800f, 50f, 8f, stroke)
    }

    private data class ScalarSpec(
        val id: Int, val title: String, val subtitle: String, val min: Float, val max: Float,
        val fallback: Float, val unit: String, val color: Int, val ticks: List<String>
    )

    private val homeSpecs = listOf(
        ScalarSpec(2, "Master Volume", "ปรับระดับเสียงรวม", -70f, 6f, -3f, "dB", Color.rgb(0, 134, 255), listOf("-60", "-40", "-20", "0", "+12")),
        ScalarSpec(8, "Bass Volume", "ปรับระดับเสียงเบส", -12f, 6f, 4f, "dB", Color.rgb(0, 219, 240), listOf("-12", "-6", "0", "+6", "+12")),
        ScalarSpec(9, "Bass Cutoff", "ตั้งค่าความถี่ตัดเบส", 20f, 250f, 100f, "Hz", Color.rgb(231, 47, 235), listOf("20", "50", "100", "200", "500")),
        ScalarSpec(10, "Bass Boost", "เพิ่มความหนักแน่นของเบส", -12f, 12f, 3f, "dB", Color.rgb(255, 49, 103), listOf("-10", "-6", "0", "+6", "+12")),
        ScalarSpec(13, "Middle Boost", "เพิ่มความชัดเจนย่านกลาง", -12f, 12f, -2f, "dB", Color.rgb(0, 146, 255), listOf("-12", "-6", "0", "+6", "+12")),
        ScalarSpec(11, "Treble Boost", "เพิ่มความใสย่านแหลม", -12f, 12f, 1f, "dB", Color.rgb(210, 45, 238), listOf("-12", "-6", "0", "+6", "+12")),
    )

    private fun drawHome(c: Canvas) {
        val y0 = 104f
        val rowH = 126f
        homeSpecs.forEachIndexed { i, spec -> drawScalarCard(c, spec, y0 + i * rowH) }
        drawHomePresets(c, 872f)
    }

    private fun drawScalarCard(c: Canvas, spec: ScalarSpec, top: Float) {
        card(c, 12f, top, 852f, top + 116f, 22f, Color.rgb(2, 28, 48), Color.rgb(9, 73, 108), 2f)
        glowCircle(c, 82f, top + 58f, 49f, spec.color)
        drawHomeIcon(c, spec.id, 82f, top + 58f, spec.color)
        text(c, spec.title, 160f, top + 46f, 29f, Color.WHITE, true)
        text(c, spec.subtitle, 160f, top + 80f, 19f, Color.rgb(145, 183, 216), false)

        val value = state.scalars[spec.id] ?: spec.fallback
        val tx1 = 380f; val tx2 = 670f; val ty = top + 56f
        drawSlider(c, spec, value, tx1, tx2, ty)

        card(c, 700f, top + 23f, 826f, top + 91f, 13f, Color.rgb(2, 20, 37), Color.rgb(37, 88, 132), 2f)
        val shown = if (spec.unit == "Hz") String.format(Locale.US, "%.0f Hz", value) else String.format(Locale.US, "%.1f dB", value)
        textCenter(c, shown, 763f, top + 66f, 26f, Color.WHITE, true)
    }

    private fun drawSlider(c: Canvas, spec: ScalarSpec, value: Float, x1: Float, x2: Float, y: Float) {
        val t = scalarFraction(spec, value)
        p.strokeWidth = 14f; p.strokeCap = Paint.Cap.ROUND; p.color = Color.rgb(32, 71, 103)
        c.drawLine(x1, y, x2, y, p)
        p.shader = LinearGradient(x1, y, x2, y, spec.color, Color.rgb(0, 130, 255), Shader.TileMode.CLAMP)
        c.drawLine(x1, y, x1 + (x2 - x1) * t, y, p)
        p.shader = null
        circle(c, x1 + (x2 - x1) * t, y, 18f, Color.WHITE)
        spec.ticks.forEachIndexed { i, label ->
            val x = x1 + (x2 - x1) * i / (spec.ticks.size - 1).toFloat()
            p.strokeWidth = 2f; p.color = Color.rgb(69, 135, 186); c.drawLine(x, y + 18f, x, y + 28f, p)
            textCenter(c, label, x, y + 53f, 16f, Color.rgb(151, 193, 228), false)
        }
    }

    private fun drawHomeIcon(c: Canvas, id: Int, cx: Float, cy: Float, color: Int) {
        stroke.color = color; stroke.strokeWidth = 6f; stroke.strokeCap = Paint.Cap.ROUND
        when (id) {
            2 -> { c.drawRect(cx - 25f, cy - 12f, cx - 7f, cy + 12f, stroke); c.drawLine(cx - 7f, cy - 12f, cx + 11f, cy - 27f, stroke); c.drawLine(cx - 7f, cy + 12f, cx + 11f, cy + 27f, stroke); c.drawArc(RectF(cx + 6f, cy - 25f, cx + 44f, cy + 25f), -55f, 110f, false, stroke) }
            8 -> { c.drawCircle(cx, cy, 23f, stroke); c.drawCircle(cx, cy, 8f, stroke) }
            9 -> { c.drawLine(cx - 25f, cy - 18f, cx - 25f, cy + 25f, stroke); c.drawLine(cx - 25f, cy - 18f, cx + 28f, cy - 5f, stroke); c.drawLine(cx - 3f, cy - 10f, cx - 3f, cy + 22f, stroke) }
            10 -> { for (i in 0..4) { val h = 12f + i * 8f; c.drawLine(cx - 26f + i * 13f, cy + 24f, cx - 26f + i * 13f, cy + 24f - h, stroke) } }
            13 -> { val path = Path(); path.moveTo(cx - 30f, cy); path.lineTo(cx - 20f, cy); path.lineTo(cx - 12f, cy - 20f); path.lineTo(cx - 2f, cy + 19f); path.lineTo(cx + 9f, cy - 15f); path.lineTo(cx + 17f, cy + 9f); path.lineTo(cx + 30f, cy + 9f); c.drawPath(path, stroke) }
            else -> { val path = Path(); path.moveTo(cx, cy - 30f); path.lineTo(cx + 10f, cy - 10f); path.lineTo(cx + 30f, cy); path.lineTo(cx + 10f, cy + 10f); path.lineTo(cx, cy + 30f); path.lineTo(cx - 10f, cy + 10f); path.lineTo(cx - 30f, cy); path.lineTo(cx - 10f, cy - 10f); path.close(); p.color = color; p.style = Paint.Style.FILL; c.drawPath(path, p) }
        }
    }

    private fun drawHomePresets(c: Canvas, top: Float) {
        card(c, 12f, top, 852f, 1310f, 22f, Color.rgb(1, 27, 45), Color.rgb(7, 64, 98), 2f)
        stroke.color = Color.rgb(0, 190, 255); stroke.strokeWidth = 5f
        c.drawRect(35f, top + 26f, 57f, top + 72f, stroke); c.drawLine(35f, top + 72f, 46f, top + 60f, stroke); c.drawLine(57f, top + 72f, 46f, top + 60f, stroke)
        text(c, "พรีเซ็ตเสียง", 92f, top + 54f, 29f, Color.WHITE, true)
        text(c, "เลือกโทนเสียงที่คุณชอบ", 92f, top + 86f, 19f, Color.rgb(150, 184, 211), false)
        outlineButton(c, 655f, top + 25f, 830f, top + 79f, "ดูเพิ่มเติม  ›", true)

        val labels = listOf("Flat", "Pop", "Rock", "Jazz")
        for (i in labels.indices) {
            val x1 = 31f + i * 202f; val x2 = x1 + 184f
            val active = selectedHomePreset == i
            card(c, x1, top + 104f, x2, top + 199f, 14f, if (active) Color.rgb(0, 132, 255) else Color.rgb(3, 21, 37), if (active) Color.rgb(0, 234, 255) else Color.rgb(35, 76, 111), 2f)
            textCenter(c, labels[i], (x1 + x2) / 2f + 18f, top + 162f, 24f, Color.WHITE, active)
            drawPresetIcon(c, i, x1 + 47f, top + 152f, if (active) Color.WHITE else Color.rgb(205, 228, 245))
        }
        outlineButton(c, 28f, top + 220f, 423f, top + 305f, "⇩   บันทึกเป็นพรีเซ็ต", false)
        outlineButton(c, 442f, top + 220f, 836f, top + 305f, "⇧   โหลดพรีเซ็ต", false)
    }

    private fun drawPresetIcon(c: Canvas, kind: Int, x: Float, y: Float, color: Int) {
        stroke.color = color; stroke.strokeWidth = 4f; stroke.strokeCap = Paint.Cap.ROUND
        when (kind) {
            0 -> for (i in 0..4) { val h = floatArrayOf(20f, 34f, 48f, 30f, 17f)[i]; c.drawLine(x - 24f + i * 12f, y - h / 2, x - 24f + i * 12f, y + h / 2, stroke) }
            1 -> { for (i in 0..2) c.drawCircle(x - 14f + i * 14f, y - 8f + (i % 2) * 8f, 7f, stroke); c.drawLine(x - 24f, y + 20f, x + 25f, y + 20f, stroke) }
            2 -> { c.drawLine(x - 18f, y + 18f, x + 18f, y - 18f, stroke); c.drawCircle(x - 17f, y + 17f, 12f, stroke); c.drawLine(x + 11f, y - 12f, x + 28f, y - 29f, stroke) }
            else -> { val path = Path(); path.moveTo(x - 18f, y - 12f); path.quadTo(x + 12f, y - 32f, x + 17f, y - 6f); path.quadTo(x + 20f, y + 25f, x - 8f, y + 22f); c.drawPath(path, stroke) }
        }
    }

    private fun drawEq(c: Canvas) {
        drawEqHeaderCard(c)
        drawEqGraph(c)
        drawEqRows(c)
        drawEqPresets(c)
    }

    private fun drawEqHeaderCard(c: Canvas) {
        card(c, 12f, 104f, 852f, 294f, 22f, Color.rgb(1, 27, 45), Color.rgb(8, 74, 109), 2f)
        drawWave(c, 62f, 153f, Color.rgb(0, 206, 255))
        text(c, "Parametric EQ", 126f, 150f, 30f, Color.WHITE, true)
        text(c, "ปรับแต่งความถี่เสียงอย่างละเอียด", 126f, 184f, 19f, Color.rgb(153, 188, 216), false)
        outlineButton(c, 632f, 126f, 835f, 183f, "ช่องสัญญาณ  ⌄", false)

        val chNames = listOf("CH1\nFL", "CH2\nFR", "CH3\nRL", "CH4\nRR", "CH5\nCEN", "CH6\nSUB", "CH7\nAUX")
        for (i in 0 until 7) {
            val x1 = 24f + i * 117f; val x2 = x1 + 107f
            val active = state.selectedChannel == i + 1
            card(c, x1, 212f, x2, 282f, 11f, if (active) Color.rgb(0, 132, 255) else Color.rgb(3, 20, 36), if (active) Color.rgb(0, 226, 255) else Color.rgb(27, 78, 116), 2f)
            val parts = chNames[i].split("\n")
            textCenter(c, parts[0], (x1 + x2) / 2f, 244f, 19f, Color.WHITE, active)
            textCenter(c, parts[1], (x1 + x2) / 2f, 269f, 18f, Color.WHITE, active)
        }
    }

    private fun drawEqGraph(c: Canvas) {
        card(c, 12f, 305f, 852f, 610f, 22f, Color.rgb(0, 20, 35), Color.rgb(8, 76, 110), 2f)
        val left = 75f; val top = 322f; val right = 825f; val bottom = 570f
        p.color = Color.rgb(15, 50, 73); p.strokeWidth = 1f
        for (i in 0..12) { val x = left + (right - left) * i / 12f; c.drawLine(x, top, x, bottom, p) }
        for (i in 0..8) { val y = top + (bottom - top) * i / 8f; c.drawLine(left, y, right, y, p) }
        text(c, "dB", 36f, 350f, 17f, Color.rgb(166, 202, 232), false)
        listOf("+12", "+6", "0", "-6", "-12").forEachIndexed { i, s -> text(c, s, 27f, top + i * (bottom - top) / 4f + 7f, 16f, Color.rgb(166, 202, 232), false) }
        val freqLabels = listOf(20f, 50f, 100f, 200f, 500f, 1000f, 2000f, 5000f, 10000f, 20000f)
        freqLabels.forEach { f -> val x = freqX(f, left, right); textCenter(c, if (f >= 1000) "${(f / 1000).roundToInt()}K" else f.roundToInt().toString(), x, 596f, 15f, Color.rgb(157, 195, 225), false) }
        text(c, "Hz", 813f, 559f, 15f, Color.rgb(166, 202, 232), false)
        outlineButton(c, 683f, 318f, 835f, 365f, "↻  รีเซ็ต EQ", false)

        val rows = visibleEqRows()
        if (rows.isEmpty()) {
            val demoF = floatArrayOf(50f, 100f, 500f, 2000f, 5000f, 10000f)
            val demoG = floatArrayOf(-3f, 0f, 4f, -2f, -4f, 2f)
            drawEqCurve(c, demoF.map { it }, demoG.map { it }, left, top, right, bottom)
            demoF.indices.forEach { i -> drawNode(c, freqX(demoF[i], left, right), gainY(demoG[i], top, bottom), BAND_COLORS[i]) }
        } else {
            val points = rows.map { it.second.frequency to it.second.boostDb }
            drawEqCurve(c, points.map { it.first }, points.map { it.second }, left, top, right, bottom)
            rows.forEachIndexed { i, pair -> drawNode(c, freqX(pair.second.frequency, left, right), gainY(pair.second.boostDb, top, bottom), BAND_COLORS[i % BAND_COLORS.size]) }
        }
    }

    private fun drawEqCurve(c: Canvas, freqs: List<Float>, gains: List<Float>, left: Float, top: Float, right: Float, bottom: Float) {
        if (freqs.isEmpty()) return
        val path = Path()
        freqs.indices.forEach { i ->
            val x = freqX(freqs[i], left, right); val y = gainY(gains[i], top, bottom)
            if (i == 0) path.moveTo(left, y) else path.lineTo(x, y)
        }
        path.lineTo(right, gainY(gains.last(), top, bottom))
        stroke.color = Color.rgb(0, 153, 255); stroke.strokeWidth = 4f; stroke.style = Paint.Style.STROKE
        c.drawPath(path, stroke)
    }

    private fun drawNode(c: Canvas, x: Float, y: Float, color: Int) {
        glowCircle(c, x, y, 15f, color)
        circle(c, x, y, 10f, color)
        stroke.color = Color.WHITE; stroke.strokeWidth = 2f; c.drawCircle(x, y, 11f, stroke)
    }

    private fun drawEqRows(c: Canvas) {
        val rows = visibleEqRows()
        for (i in 0 until 6) {
            val top = 620f + i * 75f
            val color = BAND_COLORS[i]
            card(c, 12f, top, 852f, top + 66f, 13f, Color.rgb(1, 24, 40), Color.rgb(18, 66, 96), 2f)
            glowCircle(c, 51f, top + 33f, 24f, color); textCenter(c, "${i + 1}", 51f, top + 42f, 25f, color, true)
            val row = rows.getOrNull(i)
            val actualBand = row?.first ?: (i + 1)
            val eq = row?.second
            val writable = eq != null && LiveEqPolicy.isWritable(eq)
            val typeText = if (writable) "Peak" else if (i == 0) "Low Shelf" else if (i == 5) "High Shelf" else "Peak"
            fieldBox(c, 103f, top + 10f, 265f, top + 56f, typeText + "  ⌄", 18f)
            val f = eq?.frequency ?: floatArrayOf(50f,100f,500f,2000f,5000f,10000f)[i]
            val g = eq?.boostDb ?: floatArrayOf(-3f,0f,4f,-2f,-4f,2f)[i]
            val q = eq?.q ?: if (i == 0 || i == 5) .70f else 1f
            smallLabel(c, "Freq", 306f, top + 16f); fieldBox(c, 282f, top + 23f, 432f, top + 57f, hzShort(f), 17f)
            smallLabel(c, "Gain", 479f, top + 16f); fieldBox(c, 456f, top + 23f, 604f, top + 57f, String.format(Locale.US, "%+.1f dB", g), 17f)
            smallLabel(c, "Q", 646f, top + 16f); fieldBox(c, 625f, top + 23f, 752f, top + 57f, String.format(Locale.US, "%.2f", q), 17f)
            val active = writable && abs(g) > .04f
            card(c, 773f, top + 10f, 833f, top + 57f, 10f, if (active) Color.argb(45, Color.red(color), Color.green(color), Color.blue(color)) else Color.rgb(3, 18, 30), color, 3f)
            stroke.color = color; stroke.strokeWidth = 4f; c.drawArc(RectF(790f, top + 20f, 816f, top + 47f), -45f, 270f, false, stroke); c.drawLine(803f, top + 17f, 803f, top + 31f, stroke)
            if (state.selectedEqBand == actualBand) { stroke.color = color; stroke.strokeWidth = 2f; c.drawRoundRect(RectF(13f, top + 1f, 851f, top + 65f), 13f, 13f, stroke) }
        }
    }

    private fun drawEqPresets(c: Canvas) {
        val top = 1080f
        card(c, 12f, top, 852f, 1303f, 21f, Color.rgb(1, 27, 45), Color.rgb(7, 64, 98), 2f)
        stroke.color = Color.rgb(0, 190, 255); stroke.strokeWidth = 5f
        c.drawRect(37f, top + 24f, 58f, top + 68f, stroke); c.drawLine(37f, top + 68f, 47f, top + 57f, stroke); c.drawLine(58f, top + 68f, 47f, top + 57f, stroke)
        text(c, "พรีเซ็ต EQ", 92f, top + 50f, 27f, Color.WHITE, true)
        text(c, "เลือกโทนเสียงที่คุณชอบ", 92f, top + 79f, 18f, Color.rgb(150, 184, 211), false)
        outlineButton(c, 654f, top + 20f, 836f, top + 72f, "จัดการพรีเซ็ต ›", false)
        val labels = listOf("Flat", "Vocal", "Pop", "Rock", "Jazz", "•••  เพิ่มเติม")
        for (i in labels.indices) {
            val x1 = 25f + i * 137f; val x2 = x1 + 127f
            val active = i == 0
            card(c, x1, top + 100f, x2, top + 184f, 11f, if (active) Color.rgb(0, 132, 255) else Color.rgb(3, 20, 36), if (active) Color.rgb(0, 226, 255) else Color.rgb(31, 75, 109), 2f)
            textCenter(c, labels[i], (x1 + x2) / 2f, top + 153f, if (i == 5) 16f else 19f, Color.WHITE, active)
        }
    }

    private fun drawBottomNav(c: Canvas) {
        val top = 1320f
        card(c, 0f, top, BW, BH, 28f, Color.rgb(1, 18, 31), Color.rgb(4, 35, 56), 1f)
        val items = listOf("⌂" to "หน้าแรก", "☷" to "EQ", "◉" to "ช่องสัญญาณ", "▦" to "เพิ่มเติม")
        items.forEachIndexed { i, item ->
            val x = 108f + i * 216f
            val active = (page == 0 && i == 0) || (page == 1 && i == 1)
            textCenter(c, item.first, x, top + 57f, 38f, if (active) Color.rgb(0, 212, 255) else Color.rgb(160, 200, 240), true)
            textCenter(c, item.second, x, top + 101f, 19f, if (active) Color.rgb(0, 212, 255) else Color.rgb(152, 194, 231), active)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x / sx; val y = event.y / sy
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (handleTapDown(x, y)) { performClick(); return true }
                drag = findDrag(x, y)
                drag?.let { updateDrag(it, x, y) }
                return true
            }
            MotionEvent.ACTION_MOVE -> { drag?.let { updateDrag(it, x, y) }; return true }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { drag = null; return true }
        }
        return true
    }

    override fun performClick(): Boolean { super.performClick(); return true }

    private fun handleTapDown(x: Float, y: Float): Boolean {
        if (y < 95f) {
            if (x > 735f) actions.showMainMenu() else if (x < 275f) actions.scanConnect()
            return true
        }
        if (y >= 1320f) {
            when ((x / 216f).toInt().coerceIn(0, 3)) {
                0 -> { page = 0; invalidate() }
                1 -> { page = 1; invalidate() }
                2 -> { page = 1; invalidate() }
                3 -> actions.showMainMenu()
            }
            return true
        }
        if (page == 0) return handleHomeTap(x, y)
        return handleEqTap(x, y)
    }

    private fun handleHomeTap(x: Float, y: Float): Boolean {
        if (y in 872f..1310f) {
            if (y in 897f..951f && x in 655f..835f) { actions.loadPreset(); return true }
            if (y in 976f..1071f) {
                val i = ((x - 31f) / 202f).toInt()
                if (i in 0..3) { selectedHomePreset = i; applyHomePreset(i); invalidate(); return true }
            }
            if (y in 1092f..1177f && x < 430f) { actions.savePreset(); return true }
            if (y in 1092f..1177f && x >= 430f) { actions.loadPreset(); return true }
        }
        return false
    }

    private fun handleEqTap(x: Float, y: Float): Boolean {
        if (y in 126f..183f && x in 632f..840f) {
            actions.channelSelected((state.selectedChannel % 7) + 1); return true
        }
        if (y in 212f..282f) {
            val idx = ((x - 24f) / 117f).toInt()
            if (idx in 0..6) { actions.channelSelected(idx + 1); return true }
        }
        if (y in 318f..365f && x > 670f) { actions.flatEq(); return true }
        if (y in 620f..1070f) {
            val i = ((y - 620f) / 75f).toInt()
            if (i in 0..5) {
                val row = visibleEqRows().getOrNull(i) ?: return true
                actions.bandSelected(row.first)
                if (x in 765f..840f) toggleBandBypass(row.first, row.second)
                return true
            }
        }
        if (y in 1100f..1265f) {
            if (y < 1160f && x > 640f) { actions.loadPreset(); return true }
            if (y in 1180f..1270f) {
                val i = ((x - 25f) / 137f).toInt()
                when (i) {
                    0 -> actions.flatEq()
                    1 -> applyEqPreset(floatArrayOf(-2f,-1f,2f,3f,2f,1f))
                    2 -> applyEqPreset(floatArrayOf(2f,1f,-1f,1f,2f,3f))
                    3 -> applyEqPreset(floatArrayOf(3f,2f,-1f,2f,3f,2f))
                    4 -> applyEqPreset(floatArrayOf(1f,1f,2f,1f,2f,3f))
                    5 -> actions.loadPreset()
                }
                return true
            }
        }
        return false
    }

    private fun findDrag(x: Float, y: Float): Drag? {
        if (page == 0) {
            if (x in 355f..690f && y in 104f..860f) {
                val i = ((y - 104f) / 126f).toInt()
                if (i in homeSpecs.indices) return Drag.Scalar(homeSpecs[i].id)
            }
        } else {
            if (y in 365f..570f && x in 75f..825f) {
                val rows = visibleEqRows()
                if (rows.isNotEmpty()) {
                    val nearest = rows.minByOrNull { abs(freqX(it.second.frequency,75f,825f)-x) + abs(gainY(it.second.boostDb,322f,570f)-y) }
                    if (nearest != null) { actions.bandSelected(nearest.first); return Drag.EqGraph(state.selectedChannel, nearest.first) }
                }
            }
            if (y in 620f..1070f) {
                val i = ((y - 620f) / 75f).toInt()
                val row = visibleEqRows().getOrNull(i)
                if (row != null) {
                    val field = when { x in 275f..445f -> 0; x in 448f..615f -> 1; x in 618f..760f -> 2; else -> -1 }
                    if (field >= 0) { actions.bandSelected(row.first); return Drag.EqField(state.selectedChannel, row.first, field) }
                }
            }
        }
        return null
    }

    private fun updateDrag(d: Drag, x: Float, y: Float) {
        when (d) {
            is Drag.Scalar -> {
                val spec = homeSpecs.firstOrNull { it.id == d.id } ?: return
                val t = ((x - 380f) / 290f).coerceIn(0f, 1f)
                var value = scalarValueFromFraction(spec, t)
                VerifiedScalarControls.byId(d.id)?.let { value = value.coerceIn(it.min, it.max) }
                if (d.id == 9) value = value.roundToInt().toFloat() else value = (value * 10f).roundToInt() / 10f
                actions.scalarChanged(d.id, value)
            }
            is Drag.EqGraph -> {
                val eq = eqBand(d.channel, d.band) ?: return
                if (!LiveEqPolicy.isWritable(eq)) return
                val f = xToFreq(x.coerceIn(75f, 825f), 75f, 825f).coerceIn(20f, 20000f)
                val g = yToGain(y.coerceIn(322f, 570f), 322f, 570f).coerceIn(-12f, 12f)
                actions.eqChanged(d.channel, d.band, f, eq.q.coerceIn(.1f, 10f), (g * 10f).roundToInt() / 10f)
            }
            is Drag.EqField -> {
                val eq = eqBand(d.channel, d.band) ?: return
                if (!LiveEqPolicy.isWritable(eq)) return
                when (d.field) {
                    0 -> {
                        val t = ((x - 282f) / 150f).coerceIn(0f, 1f)
                        val f = (20.0 * (1000.0.pow(t.toDouble()))).toFloat().coerceIn(20f, 20000f)
                        actions.eqChanged(d.channel, d.band, f, eq.q, eq.boostDb)
                    }
                    1 -> {
                        val t = ((x - 456f) / 148f).coerceIn(0f, 1f)
                        val g = -12f + 24f * t
                        actions.eqChanged(d.channel, d.band, eq.frequency, eq.q, (g * 10f).roundToInt() / 10f)
                    }
                    else -> {
                        val t = ((x - 625f) / 127f).coerceIn(0f, 1f)
                        val q = .2f + 9.8f * t
                        actions.eqChanged(d.channel, d.band, eq.frequency, (q * 100f).roundToInt() / 100f, eq.boostDb)
                    }
                }
            }
        }
    }

    private fun applyHomePreset(i: Int) {
        val values = when (i) {
            0 -> floatArrayOf(-3f, 0f, 100f, 0f, 0f, 0f)
            1 -> floatArrayOf(-3f, 2f, 100f, 2f, 1f, 3f)
            2 -> floatArrayOf(-3f, 4f, 90f, 4f, 2f, 2f)
            else -> floatArrayOf(-3f, 2f, 110f, 1f, 2f, 3f)
        }
        val ids = intArrayOf(2,8,9,10,13,11)
        ids.indices.forEach { k -> actions.scalarChanged(ids[k], values[k]) }
    }

    private fun applyEqPreset(gains: FloatArray) {
        val ch = state.selectedChannel
        visibleEqRows().forEachIndexed { i, row ->
            if (i < gains.size && LiveEqPolicy.isWritable(row.second)) actions.eqChanged(ch, row.first, row.second.frequency, row.second.q, gains[i])
        }
    }

    private fun toggleBandBypass(band: Int, eq: EqBand48) {
        if (!LiveEqPolicy.isWritable(eq)) return
        val key = state.selectedChannel to band
        if (abs(eq.boostDb) > .04f) {
            bypassGain[key] = eq.boostDb
            actions.eqChanged(state.selectedChannel, band, eq.frequency, eq.q, 0f)
        } else {
            val restore = bypassGain.remove(key) ?: 0f
            actions.eqChanged(state.selectedChannel, band, eq.frequency, eq.q, restore)
        }
    }

    private fun visibleEqRows(): List<Pair<Int, EqBand48>> {
        val rows = state.eq.getOrNull(state.selectedChannel - 1) ?: return emptyList()
        return rows.mapIndexedNotNull { i, b -> if (b != null && LiveEqPolicy.isWritable(b)) (i + 1) to b else null }.take(6)
    }

    private fun eqBand(ch: Int, band: Int): EqBand48? = state.eq.getOrNull(ch - 1)?.getOrNull(band - 1)

    private fun scalarFraction(spec: ScalarSpec, v: Float): Float {
        return if (spec.id == 9) {
            val minL = ln(spec.min); val maxL = ln(spec.max); ((ln(v.coerceIn(spec.min,spec.max))-minL)/(maxL-minL)).coerceIn(0f,1f)
        } else ((v - spec.min) / (spec.max - spec.min)).coerceIn(0f, 1f)
    }

    private fun scalarValueFromFraction(spec: ScalarSpec, t: Float): Float {
        return if (spec.id == 9) (spec.min.toDouble() * (spec.max / spec.min).toDouble().pow(t.toDouble())).toFloat()
        else spec.min + (spec.max - spec.min) * t
    }

    private fun freqX(f: Float, left: Float, right: Float): Float {
        val t = ((log10(f.coerceIn(20f, 20000f)) - log10(20f)) / (log10(20000f) - log10(20f))).coerceIn(0f,1f)
        return left + (right - left) * t
    }
    private fun xToFreq(x: Float, left: Float, right: Float): Float { val t=((x-left)/(right-left)).coerceIn(0f,1f); return (20.0 * 1000.0.pow(t.toDouble())).toFloat() }
    private fun gainY(g: Float, top: Float, bottom: Float): Float = top + (12f - g.coerceIn(-12f,12f)) / 24f * (bottom - top)
    private fun yToGain(y: Float, top: Float, bottom: Float): Float = 12f - ((y-top)/(bottom-top)).coerceIn(0f,1f)*24f

    private fun drawWave(c: Canvas, x: Float, y: Float, color: Int) {
        stroke.color = color; stroke.strokeWidth = 6f; stroke.strokeCap = Paint.Cap.ROUND
        val heights = floatArrayOf(18f,36f,56f,36f,19f)
        heights.forEachIndexed { i, h -> c.drawLine(x - 24f + i * 12f, y - h/2, x - 24f + i * 12f, y + h/2, stroke) }
    }

    private fun fieldBox(c: Canvas, l: Float, t: Float, r: Float, b: Float, s: String, size: Float) {
        card(c, l, t, r, b, 8f, Color.rgb(2, 18, 31), Color.rgb(28, 71, 106), 2f)
        textCenter(c, s, (l+r)/2f, (t+b)/2f + size*.34f, size, Color.rgb(227, 239, 249), false)
    }
    private fun smallLabel(c: Canvas, s: String, x: Float, y: Float) = text(c, s, x, y, 15f, Color.rgb(162, 198, 226), false)
    private fun hzShort(f: Float): String = if (f >= 1000f) String.format(Locale.US, if (f >= 10000f) "%.0f kHz" else "%.1f kHz", f/1000f) else String.format(Locale.US, "%.0f Hz", f)

    private fun outlineButton(c: Canvas, l: Float, t: Float, r: Float, b: Float, s: String, bright: Boolean) {
        card(c, l, t, r, b, 16f, Color.rgb(2, 20, 35), if (bright) Color.rgb(0, 133, 255) else Color.rgb(0, 118, 226), 2f)
        textCenter(c, s, (l+r)/2f, (t+b)/2f + 9f, 20f, Color.rgb(210, 233, 250), false)
    }

    private fun glowCircle(c: Canvas, x: Float, y: Float, radius: Float, color: Int) {
        p.shader = android.graphics.RadialGradient(x,y,radius*1.45f, intArrayOf(Color.argb(115,Color.red(color),Color.green(color),Color.blue(color)),Color.TRANSPARENT), floatArrayOf(.45f,1f),Shader.TileMode.CLAMP)
        c.drawCircle(x,y,radius*1.45f,p); p.shader=null
        stroke.color=color;stroke.strokeWidth=3f;c.drawCircle(x,y,radius,stroke)
    }
    private fun circle(c: Canvas, x: Float, y: Float, r: Float, color: Int) { p.style=Paint.Style.FILL;p.color=color;c.drawCircle(x,y,r,p) }
    private fun card(c: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float, fill: Int, border: Int, borderW: Float) {
        p.style=Paint.Style.FILL;p.color=fill;c.drawRoundRect(RectF(l,t,r,b),rad,rad,p)
        stroke.style=Paint.Style.STROKE;stroke.color=border;stroke.strokeWidth=borderW;c.drawRoundRect(RectF(l,t,r,b),rad,rad,stroke)
    }
    private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, bold: Boolean, italic: Boolean=false, letter: Float=0f) {
        p.style=Paint.Style.FILL;p.color=color;p.textSize=size;p.typeface=if(italic)italicBold else if(bold)boldFace else baseFace;p.textAlign=Paint.Align.LEFT;c.drawText(s,x,y,p)
    }
    private fun textCenter(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, bold: Boolean) {
        p.style=Paint.Style.FILL;p.color=color;p.textSize=size;p.typeface=if(bold)boldFace else baseFace;p.textAlign=Paint.Align.CENTER;c.drawText(s,x,y,p);p.textAlign=Paint.Align.LEFT
    }
}
