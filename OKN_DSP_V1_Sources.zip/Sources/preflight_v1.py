#!/usr/bin/env python3
from pathlib import Path
import hashlib, re, xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parent
HOME='4ffb30f11cf436edac60d725c0c31e940a981a1cf101f6d66712dc937472d8e7'
EQ='6ca27002bd3c9cb6f1eca3118ed4afbfbf5d8fdb854313e90982dba8470ca609'
KEY='ba1c52f2607c09953c52fdd79c5f72026aaf0adb8aa44bcba277f7d9b49d9511'

def sha(p):
    h=hashlib.sha256();
    with open(p,'rb') as f:
        for ch in iter(lambda:f.read(1<<20),b''): h.update(ch)
    return h.hexdigest()

def must(path, needle):
    s=(ROOT/path).read_text(encoding='utf-8')
    if needle not in s: raise SystemExit(f'ERROR missing {needle!r} in {path}')

def req(path):
    if not (ROOT/path).is_file(): raise SystemExit(f'ERROR missing {path}')

required=[
 'app/build.gradle.kts','app/src/main/AndroidManifest.xml','app/okn_dsp_stable_debug.keystore',
 'app/src/main/java/com/okn/dsp/MainActivity.kt','app/src/main/java/com/okn/dsp/ui/ReferenceDspUi.kt',
 'app/src/main/java/com/okn/dsp/ble/BleDspManager.kt','app/src/main/java/com/okn/dsp/ble/BleProfile.kt',
 'app/src/main/java/com/okn/dsp/protocol/VerifiedScalarControls.kt','app/src/main/java/com/okn/dsp/protocol/EqBandCodec.kt',
 'app/src/main/java/com/okn/dsp/protocol/SaveParamsPolicy.kt','app/src/main/java/com/okn/dsp/protocol/WriteGate.kt',
 'app/src/main/java/com/okn/dsp/queue/RealtimeCommandQueue.kt','app/src/main/java/com/okn/dsp/smoothing/ScalarRampController.kt',
 'app/src/main/java/com/okn/dsp/repository/DspRepository.kt','tools/ProtocolJvmSmoke.kt',
 'evidence/OKN_DSP_V1_UI_HOME_REFERENCE.jpg','evidence/OKN_DSP_V1_UI_EQ_REFERENCE.jpg','README_V1.txt'
]
for x in required:req(x)
print('OK required files',len(required))

for marker in ['applicationId = "com.okn.dsp"','versionCode = 1','versionName = "1.0.0"','compileSdk = 35','targetSdk = 35','minSdk = 26']:
    must('app/build.gradle.kts',marker)
ET.parse(ROOT/'app/src/main/AndroidManifest.xml')
if sha(ROOT/'evidence/OKN_DSP_V1_UI_HOME_REFERENCE.jpg')!=HOME: raise SystemExit('ERROR Home UI hash')
if sha(ROOT/'evidence/OKN_DSP_V1_UI_EQ_REFERENCE.jpg')!=EQ: raise SystemExit('ERROR EQ UI hash')
if sha(ROOT/'app/okn_dsp_stable_debug.keystore')!=KEY: raise SystemExit('ERROR signing key hash')

for u in ['0000ab00-0000-1000-8000-00805f9b34fb','0000ab01-0000-1000-8000-00805f9b34fb','0000ab02-0000-1000-8000-00805f9b34fb','0000ab03-0000-1000-8000-00805f9b34fb']:
    must('app/src/main/java/com/okn/dsp/ble/BleProfile.kt',u)
for m in ['631C062443FD3844558001F3EDA0CCF8','refreshDescriptor(DescriptorMode.INITIAL)','connectionEpoch','command.epoch != connectionEpoch']:
    must('app/src/main/java/com/okn/dsp/ble/BleDspManager.kt',m)

scalar=(ROOT/'app/src/main/java/com/okn/dsp/protocol/VerifiedScalarControls.kt').read_text()
ids=[int(x) for x in re.findall(r'VerifiedScalarControl\((\d+),',scalar)]
if ids != [2,3,8,9,10,13,11]: raise SystemExit(f'ERROR scalar list {ids}')

ui=(ROOT/'app/src/main/java/com/okn/dsp/ui/ReferenceDspUi.kt').read_text()
for m in ['Master Volume','Bass Volume','Bass Cutoff','Bass Boost','Middle Boost','Treble Boost','Parametric EQ','พรีเซ็ตเสียง','พรีเซ็ต EQ','visibleEqRows()','actions.eqChanged','actions.scalarChanged']:
    if m not in ui: raise SystemExit(f'ERROR UI marker {m}')

for m in ['const val enabled: Boolean = false','const val presetHardwareWritesEnabled: Boolean = false','const val crossoverWritesEnabled: Boolean = false','const val delayWritesEnabled: Boolean = false','const val unknownOutputWritesEnabled: Boolean = false']:
    must('app/src/main/java/com/okn/dsp/protocol/WriteGate.kt',m)
for m in ['private var inflight: Command? = null','realtime[command.key] = command']:
    must('app/src/main/java/com/okn/dsp/queue/RealtimeCommandQueue.kt',m)
for m in ['id == 11 -> 0.5f','target[id] = v']:
    must('app/src/main/java/com/okn/dsp/smoothing/ScalarRampController.kt',m)

allkt='\n'.join(p.read_text(errors='ignore') for p in (ROOT/'app/src/main/java').rglob('*.kt'))
if 'AA 55' in allkt or '0xAA, 0x55' in allkt: raise SystemExit('ERROR fake packet pattern')
print('PREFLIGHT_V1_PASS')
