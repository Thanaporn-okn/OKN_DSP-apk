# OKN DSP — Version 1 / Phase 1

Fresh UI rebuild for Android. The screens are drawn from code and do not use the reference screenshots as backgrounds.

## Implemented
Home, Mix, 7-channel / 15-band EQ, real-time UI graph, Light/Dark/Midnight themes, automatic local persistence, presets, responsive phone/tablet layout, and interactive controls.

## Not implemented yet
Real DSP/BLE packet transport. That starts in Phase 2 after the control/protocol data is supplied.
