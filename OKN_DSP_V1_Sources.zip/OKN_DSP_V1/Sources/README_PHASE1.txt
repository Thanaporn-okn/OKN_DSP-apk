OKN DSP V1 - PHASE 1 UI
=======================

Goal
----
Rebuild the OKN DSP app from Version 1 with a real coded UI based on the supplied visual references.
The Home, Mix and EQ pages are drawn/built from Android UI code. The screenshots in Sources/References
are reference-only and are NOT used as page backgrounds, overlays, WebViews or runtime screen images.

Implemented in V1
-----------------
1. Responsive Home / Mix / EQ pages for phones and tablets.
2. Light/Dark theme toggle. Theme choice is persisted.
3. Master Volume, Bass Volume, Bass Cutoff controls.
4. Seven channel volume controls.
5. Seven EQ channels, each with 15 bands.
6. Per-band Frequency, Q and Gain controls.
7. Direct EQ graph point dragging: horizontal = Frequency, vertical = Gain.
8. EQ graph redraws immediately during interaction; no artificial relay/delay is inserted.
9. Channel volume is also available on the EQ page.
10. Automatic local persistence through SharedPreferences on every value change.
11. Local preset save/load.
12. Search and menu buttons are functional.
13. Bluetooth row opens Android Bluetooth settings.
14. Stable signing key from the earlier OKN DSP line is retained for install/update continuity.

Phase boundary
--------------
No fake DSP/BLE command traffic is sent in Phase 1. Hardware status rows clearly identify Phase 2 work.
When the real DSP protocol/control data is supplied, Phase 2 will bind these already-live UI values to
real commands and real device feedback.

Version rule
------------
If a build/runtime error is found, do not overwrite V1. The correction becomes V2, then V3, etc.
