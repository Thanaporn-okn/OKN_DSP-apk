OKN_DSP V1 - Phase 1 UI
========================

This project is a new UI implementation written from code.
The uploaded reference image is NOT embedded, copied, or used as a bitmap/background.
All visible UI is drawn at runtime using Android Canvas primitives, text, paths, gradients, controls, and graphs.

Implemented pages
- Home: device status, input source buttons, quick actions, bottom navigation.
- Mix: Master Volume, Bass Volume, Bass Cutoff, Bass Boost, Middle Boost, Treble Boost.
- Eq: 7 channels, 15 bands per channel, real-time draggable graph points, Frequency/Gain/Q, Output Level, in-memory Save/Load Preset.
- Crossover: magnitude/phase graph, SUB/MID/HIGH/FULL filter UI, slopes, frequencies, Link L/R, delay controls, unit switching, Reset and demo Auto Align.

Interaction
- Sliders and knobs change values on ACTION_MOVE and redraw immediately.
- EQ graph points can be dragged in both frequency and gain and the graph follows immediately.
- Crossover graph follows cutoff changes immediately.
- Full-screen immersive mode is enabled.
- Layout scales from the current viewport and is not tied to one phone resolution.

Phase boundary
- Phase 1 contains UI and local demo state only.
- No BLE/DSP command transport is included in V1. Hardware protocol data should be added in Phase 2 from the files supplied by the user.

Version rule
- Any delivered build/runtime error is fixed in a NEW version number. V1 is never silently replaced by a different implementation.
