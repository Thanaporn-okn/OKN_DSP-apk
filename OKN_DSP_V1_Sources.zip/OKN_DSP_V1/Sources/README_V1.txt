OKN_DSP V1
==========

Goal
----
Build a new OKN_DSP Android app from version 1, matching only the five supplied UI pages.

Implemented UI
--------------
- Home: Master Volume, Bass Volume, Bass Cutoff, Bass Boost, Middle Boost, Treble Boost,
  Audio Source card, System Preset card and Device Status card.
- EQ: CH1..CH7, response graph, Bands 1-6 / 7-12 / 13-15, per-band Frequency/Gain/Q/Power,
  Reset, Save and Manage.
- Crossover: HPF/LPF graph and controls plus Advanced Settings.
- Delay: car/listening-position layout and 7 channel delay rows.
- Output: output meters, master output, 7 channel levels and Mute/Solo/Phase/Link buttons.
- Bottom navigation contains exactly Home / EQ / Crossover / Delay / Output.

Build identity
--------------
- app name: OKN_DSP
- namespace: com.okn.dsp
- applicationId: com.okn.dsp.control
- versionCode: 1
- versionName: 1.0.0
- minSdk: 26
- targetSdk / compileSdk: 35
- Java: 17

The new applicationId allows this reset V1 app to install without Android rejecting it as
a versionCode downgrade from an older com.okn.dsp build. Future V2+ should keep
com.okn.dsp.control and increase versionCode normally.

Build
-----
Use the separately supplied OKN_DSP_AutoBuild_V1.yml at .github/workflows/okn-dsp-build.yml.
Uploading/pushing OKN_DSP_V1_Sources.zip to the repository root triggers the build automatically.
The workflow builds the ZIP changed by that push, so an older V17 ZIP can remain in the repo
without being selected accidentally.
