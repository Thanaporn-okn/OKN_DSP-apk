OKN_DSP V1 — RESET BASELINE
===========================

This is a new numbering baseline. The project and Android version both restart at 1.

Input used:
- uploaded OKN_DSP_V17_Sources.zip
- uploaded OKN_DSP_AutoBuild.yml
- uploaded UI reference images for Home, EQ, Crossover, Delay and Output

Verified hardware behavior preserved from the uploaded source:
- BLE transport/authentication and AES-CFB8 stream handling
- AB00 / AB01 / AB02 application transport
- original-style 380 ms command scheduler
- verified scalar controls: Master, Bass Volume, Bass Cutoff, Bass Boost, Middle Boost, Treble Boost
- 7-channel x 15-band EQ descriptor reading/writing within verified filter-aware boundaries

UI scope for V1:
- Home: functional verified scalar controls
- EQ: functional 7-channel / 15-band EQ using live DSP descriptor data
- Crossover: visible UI foundation from the uploaded reference; DSP write intentionally locked until packet mapping is verified
- Delay: visible UI foundation from the uploaded reference; DSP write intentionally locked until packet mapping is verified
- Output: visible UI foundation from the uploaded reference; DSP write intentionally locked until packet mapping is verified

Important:
No guessed crossover/delay/output BLE packet is introduced. Those controls remain UI/local only until real device evidence identifies their actuator IDs, offsets, data types and ranges.

Clean reset identity:
- applicationId = com.okn.dsp.reset
- namespace = com.okn.dsp
- This lets V1 install beside the older app instead of being blocked by Android's version downgrade rule.
