OKN_DSP V1
===========

Scope of this clean restart:
- UI is based only on the two supplied reference screens: Home and EQ.
- Every visible slider/toggle/preset/channel/reset/save/load control on those screens has immediate local interaction.
- BLE scanning/connection is implemented.
- Known GATT characteristic from captured data is included exactly:
  0000ab01-0000-1000-8000-00805f9b34fb
- The app can discover/read/subscribe to that characteristic when supported.

Important protocol boundary:
The captured data available for V1 does not include verified DSP write packet frames.
V1 therefore DOES NOT invent write commands. UI state changes immediately and BLE diagnostics are real,
but hardware parameter writes remain disabled until an actual writable characteristic and packet format
are extracted/verified from the DSP protocol.

Version rule:
Any build/runtime error found after this package should be fixed as V2, never by silently overwriting V1.
