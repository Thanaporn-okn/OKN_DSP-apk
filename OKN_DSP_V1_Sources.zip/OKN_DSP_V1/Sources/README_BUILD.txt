OKN DSP V1 BUILD

Expected build environment:
- JDK 17
- Android SDK 35
- Android build-tools 35.0.0
- Gradle 8.9
- Android Gradle Plugin 8.7.3

GitHub Actions file is delivered separately as OKN_DSP_AutoBuild.yml.
The workflow finds the latest OKN_DSP_V*_Sources.zip, verifies Sources/SHA256SUMS.txt,
builds :app:assembleDebug, then uploads the APK and APK SHA256 as the Actions artifact.
