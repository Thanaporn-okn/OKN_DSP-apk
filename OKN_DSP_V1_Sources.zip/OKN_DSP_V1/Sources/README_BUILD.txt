OKN DSP V1 / Phase 1

Build target:
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- JDK 17
- compileSdk 35 / targetSdk 35 / minSdk 26

Automatic GitHub Actions flow:
1) Put OKN_DSP_V1_Sources.zip in repository root.
2) Put the provided OKN_DSP_AutoBuild.yml at .github/workflows/OKN_DSP_AutoBuild.yml.
3) Every push of an OKN_DSP_V*_Sources.zip triggers a build automatically.
4) Workflow chooses the highest V number, verifies Sources/SHA256SUMS.txt, builds the debug APK and uploads the APK + APK SHA256 as an artifact.

Important:
- Phase 1 uses Android framework APIs only; there are no external UI libraries.
- Screen reference images are retained in Sources only for documentation/audit.
- UI_REFERENCE_PHASE1.png is never loaded by the application.
