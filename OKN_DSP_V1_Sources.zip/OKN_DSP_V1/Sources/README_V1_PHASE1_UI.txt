OKN DSP V1 - PHASE 1 UI
========================

This is a new Phase 1 codebase built from scratch for the uploaded UI reference.
The reference screenshot/poster is NOT used as a screen background. UI cards, tabs, sliders,
EQ graph, buttons and theme elements are drawn from code.

Implemented in V1:
- Home / Mix / EQ navigation.
- Light / Dark theme switch. Theme choice is persisted automatically.
- Full local realtime control state: Master Volume, Bass Volume, Bass Cutoff,
  7 channel volumes, 7 channels x 15 EQ bands, Frequency, Q and Gain.
- EQ graph redraws immediately while Frequency/Q/Gain is dragged.
- Local autosave on every change using SharedPreferences apply(), with a synchronous final
  commit on touch release and when the Activity pauses.
- Close and reopen: the saved theme, page, selected channel/band, sliders and EQ data restore.
- Preset 1 Save / Load / Delete for all local values.
- Responsive custom drawing for phones/tablets and scrollable content on small screens.
- Bottom navigation is drawn last and receives touch priority over content controls to avoid
  page tabs accidentally changing an underlying slider.
- App icon is derived from the uploaded OKN DSP icon image.

Phase 1 hardware limitation:
- NO real DSP packet is sent yet. DspTransport is deliberately connected to NoOpDspTransport.
- The current ranges/default values are UI prototype values only. Do not treat them as proven
  DSP protocol constants.
- When the DSP control/protocol files are uploaded for Phase 2, the BLE/transport layer will be
  implemented behind DspTransport without rebuilding the UI from scratch.

Phase 2 integration boundary:
  DspTransport.setMasterVolume(db)
  DspTransport.setBassVolume(db)
  DspTransport.setBassCutoff(hz)
  DspTransport.setChannelVolume(channel, db)
  DspTransport.setEqBand(channel, band, frequencyHz, q, gainDb)

Build target:
- compileSdk 35
- targetSdk 35
- minSdk 26
- Java 17
- Android Gradle Plugin 8.7.3
- Gradle 8.9 in GitHub Actions
