OKN_DSP V1 — PHASE 1 UI
========================

Scope
-----
This version is a clean restart at Version 1 and implements the user interface only.
Phase 2 will connect the real DSP control protocol after the control data/files are supplied.
Phase 3 will create the release list/release flow.

UI implementation
-----------------
- Full-screen edge-to-edge Android Activity; status/navigation bars are hidden in immersive mode.
- Layout is calculated from the actual View width/height, so the same code scales across phones and tablets.
- No uploaded screenshot is used as a background, bitmap layer, WebView, or static UI image.
- The mountain header, DSP chassis, icons, cards, graphs, sliders and knobs are all rendered from code using Canvas primitives.
- Bottom navigation exists on every page: Home / Mix / Eq / Crossover.
- Home input-source buttons and quick actions are interactive.
- Mix sliders/knobs update values in the same touch frame.
- EQ has 7 channels x 15 bands. Frequency, gain, Q and output controls update immediately, and the EQ graph redraws from the live values.
- EQ presets are saved/loaded locally with SharedPreferences.
- Crossover cutoff, filter type, slope and delay controls are interactive. The crossover graph redraws from the live values.
- Crossover includes Magnitude/Phase view, Link L/R, Reset Delays and Auto Align UI behavior.

Important Phase 1 boundary
--------------------------
Any "UI READY" state shown in the interface is a UI state, not proof of a DSP/Bluetooth connection.
No BLE service UUIDs, DSP packets or hardware commands are sent in V1.

Version rule
------------
If a build/runtime defect is found after V1 is delivered, do not replace V1 in-place. Fix it as V2, then V3, and continue incrementing the version for each delivered correction.

Build
-----
The separate OKN_DSP_AutoBuild.yml workflow watches OKN_DSP_V*_Sources.zip files pushed to the repository root, verifies Sources/SHA256SUMS.txt, and builds an installable debug APK artifact automatically.
