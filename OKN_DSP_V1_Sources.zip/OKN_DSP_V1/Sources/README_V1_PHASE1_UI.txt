OKN DSP - VERSION 1 - PHASE 1 UI
=================================

GOAL
- Rebuild the UI from code based on the supplied Home / Mix / EQ references.
- The supplied reference screenshots are stored only in Sources/ for design comparison.
- They are NOT loaded by the Android app and are NOT used as screen backgrounds.

IMPLEMENTED IN VERSION 1
1. Native Android Java UI built programmatically.
2. Three working pages: Home, Mix, Eq.
3. Responsive layout for phones and tablets. Content width is capped on large tablets while the app background fills the whole screen.
4. Bottom Home / Mix / Eq navigation works immediately.
5. Theme menu with three persistent themes:
   - Ice Light
   - Midnight
   - AMOLED
6. Real-time local state:
   - Every slider movement updates its value immediately.
   - EQ graph invalidates immediately when Frequency / Q / Gain are changed.
   - Changes are written to SharedPreferences continuously with apply().
   - onPause() performs a synchronous commit so values survive closing/reopening the app.
7. Mix controls:
   - Master Volume
   - Bass Volume
   - Bass Cutoff
   - 7 independent channel volumes
8. EQ controls:
   - 15 bands x 7 channels
   - Frequency: 20 Hz to 20 kHz with logarithmic mapping
   - Q: 0.10 to 10.00
   - Gain: -12 dB to +12 dB
   - Graph follows current EQ values immediately
   - Tap a graph point area to select the nearest band
   - Previous/Next band buttons
   - Reset selected band
   - Reset EQ gain for selected channel
9. Presets:
   - Save all current global / channel / 7x15 EQ values under a custom local name
   - Load saved presets
   - Factory Flat preset
10. Launcher icon generated from the supplied OKN logo.

PHASE BOUNDARY
- Phase 1 contains UI/state only. It deliberately does NOT pretend to have a real BLE/DSP connection.
- Bluetooth scan, device protocol, actual DSP writes/reads and verification belong to Phase 2 after protocol/source data is supplied.

VERSIONING / INSTALLATION
- File version is Version 1.
- Android versionCode is 1001 rather than 1 so it is numerically newer than earlier test builds such as versionCode 17.
- The stable signing keystore from the supplied prior project is preserved so the app can use the same signing identity.

AUTOMATIC BUILD
- Use the separate OKN_DSP_AutoBuild.yml workflow file once in .github/workflows/.
- Future OKN_DSP_V*_Sources.zip uploads to repository root trigger the workflow automatically.
- There is no need to upload/replace the workflow for every version.

SHA256
- Sources/SHA256SUMS.txt contains hashes for the files inside the source tree, excluding SHA256SUMS.txt itself.
- The downloadable source ZIP hash is provided separately because placing the ZIP's own hash inside itself would be circular.
