OKN DSP VERSION 1 - PHASE 1 UI

Goal
- Rebuild the UI from code based on the three supplied reference screens.
- No reference screenshot is used as an app background.
- Phase 1 does not send commands to DSP hardware.

Implemented screens
1. Home
   - System Ready status card
   - Connection/status cards
   - Quick Control shortcut
   - Search and overflow buttons
2. Mix
   - Master Volume, Bass Volume, Bass Cutoff
   - Channel 1-7 volume sliders
   - Values update immediately while dragging
3. Eq
   - Channel tabs 1-7
   - 15-band interactive response graph
   - Frequency/Q/Ch Volume controls
   - Selected-band graph point updates immediately
   - Reset EQ, previous/next band
   - Local preset save/load demo

Responsive behavior
- No fixed bitmap layout is used.
- UI uses density-independent coordinates with centered adaptive content width.
- Narrow phones fit the full width; tablets use a wider centered content area.
- Vertical scrolling is enabled whenever screen height is insufficient.
- Bottom navigation stays fixed and usable.

Version policy
- This package starts again at V1 as requested.
- Every future correction/error fix must use a new version number.
