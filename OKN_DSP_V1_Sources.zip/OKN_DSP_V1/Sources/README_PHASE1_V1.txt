OKN DSP V1 — Phase 1 UI

This version is a clean UI rebuild written as native Android drawing/control code.
The uploaded screen images are used only as visual references. They are NOT embedded as page backgrounds and are NOT copied into the source package.

Implemented in V1:
- Responsive Home / Mix / Eq screens with a phone-first layout and centered max-width cards for tablets.
- Light, Dark and Ocean themes. Theme choice persists automatically.
- Master Volume, Bass Volume, Bass Cutoff and 7 channel volume sliders.
- 7 EQ channels x 15 bands.
- Per-band Frequency (20 Hz–20 kHz), Q (0.1–10.0) and Gain (-12 to +12 dB).
- EQ graph updates in the same touch frame while Frequency/Gain/Q are dragged.
- Q is visualized as the width of the selected-band highlight.
- Tap any EQ point to select its band; previous/next band buttons work.
- Reset EQ, local preset name/save/load, search navigation and theme menu are interactive.
- Every control value is saved with SharedPreferences immediately using apply() and restored on next app launch.
- Edge-to-edge system UI and scrollable content for different phone/tablet sizes.

Important Phase 1 boundary:
- Bluetooth, DSP hardware, firmware, amplifier and real-time device telemetry are deliberately NOT faked.
- Phase 2 will connect these UI state setters to the real DSP protocol once the protocol/control data is supplied.

Build:
- Android compile/target SDK 35
- minSdk 26
- Java source, no AndroidX runtime dependency
- GitHub Actions workflow installs JDK 17 + Android SDK 35 + Gradle 8.9 and builds :app:assembleDebug
