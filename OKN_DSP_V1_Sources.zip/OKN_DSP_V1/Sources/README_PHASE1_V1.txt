OKN_DSP V1 - PHASE 1 UI

This project is a clean UI implementation based on the uploaded visual reference.
The reference screenshot is NOT embedded, copied, or used as a bitmap background.
All visible app surfaces are generated from Android Canvas code, gradients, paths,
text, vector launcher assets, and interactive state.

Implemented screens:
- Home: connection status, drawn DSP device card, input source selector, quick actions.
- Mix: Master Volume, Bass Volume, Bass Cutoff, Bass Boost, Middle Boost, Treble Boost.
- Eq: 7 channel tabs, 15-band graph, per-band Frequency/Gain/Q, Output level,
  in-memory Save/Load preset, graph point drag editing.
- Crossover: live magnitude/phase graph preview, filter mode, slopes, cutoff controls,
  link toggle, channel delay, reset and auto-align preview.

Interaction rule:
Controls update local UI state immediately during ACTION_DOWN/ACTION_MOVE and call
invalidate() so the value and graph are redrawn in the same UI cycle. There is no
network/BLE relay layer in Phase 1.

Responsive/full-screen rule:
The app renders into the complete available display and scales the 1080x1920 design
coordinate system to the current device width/height. Orientation is not locked, and
the activity is resizeable for phones and tablets.

Phase 2 boundary:
Real DSP commands, BLE UUIDs, frame encoding/decoding, device synchronization and
readback will be added only when the real DSP control data/protocol files are supplied.
