# Phase 1 has no reflection-based libraries. Keep rules intentionally minimal.
