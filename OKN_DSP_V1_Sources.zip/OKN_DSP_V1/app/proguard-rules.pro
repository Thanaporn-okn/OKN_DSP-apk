# V1 keeps all classes unobfuscated for easier BLE diagnostics.
