# Phase 1 UI-only build: no custom ProGuard rules required.
