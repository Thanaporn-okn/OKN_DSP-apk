# Phase 1: no shrinking rules required.
