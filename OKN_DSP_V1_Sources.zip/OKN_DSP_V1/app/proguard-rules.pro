# Version 1 Phase 1: no custom shrinking rules are required.
