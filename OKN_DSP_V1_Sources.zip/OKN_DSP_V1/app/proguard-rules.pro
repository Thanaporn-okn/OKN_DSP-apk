# Phase 1 intentionally has no reflection-based runtime components.
