# Phase 1: no shrinking-specific rules required.
