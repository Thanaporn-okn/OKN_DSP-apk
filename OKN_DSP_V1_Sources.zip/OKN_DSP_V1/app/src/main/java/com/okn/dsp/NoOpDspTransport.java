package com.okn.dsp;

/** Phase 1 transport: deliberately sends nothing to hardware. */
public final class NoOpDspTransport implements DspTransport {
    @Override public void setMasterVolume(float db) { }
    @Override public void setBassVolume(float db) { }
    @Override public void setBassCutoff(float hz) { }
    @Override public void setChannelVolume(int channel, float db) { }
    @Override public void setEqBand(int channel, int band, float frequencyHz, float q, float gainDb) { }
}
