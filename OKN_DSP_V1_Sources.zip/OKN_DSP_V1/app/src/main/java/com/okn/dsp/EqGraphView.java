package com.okn.dsp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

import java.util.Locale;

/** Code-drawn 15-band EQ graph. No screenshot or bitmap is used as the graph background. */
public final class EqGraphView extends View {
    public interface Listener {
        void onBandSelected(int band);
        void onBandDragged(int band, float frequencyHz, float gainDb);
    }

    private final AppState state;
    private final boolean dark;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Listener listener;
    private int channel;
    private int selectedBand;
    private int draggingBand = -1;
    private float density;

    private final RectF plot = new RectF();
    private final float[] px = new float[AppState.BANDS];
    private final float[] py = new float[AppState.BANDS];

    public EqGraphView(Context context, AppState state, int channel, int selectedBand, boolean dark) {
        super(context);
        this.state = state;
        this.channel = channel;
        this.selectedBand = selectedBand;
        this.dark = dark;
        this.density = getResources().getDisplayMetrics().density;
        setMinimumHeight(dp(260));
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    public void setListener(Listener listener) { this.listener = listener; }

    public void setChannel(int channel) {
        this.channel = channel;
        invalidate();
    }

    public void setSelectedBand(int band) {
        this.selectedBand = Math.max(0, Math.min(AppState.BANDS - 1, band));
        invalidate();
    }

    public void refresh() { invalidate(); }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float left = dp(42), top = dp(18), right = getWidth() - dp(12), bottom = getHeight() - dp(34);
        plot.set(left, top, Math.max(left + dp(80), right), Math.max(top + dp(120), bottom));

        int grid = dark ? Color.rgb(56, 65, 79) : Color.rgb(224, 230, 239);
        int subtle = dark ? Color.rgb(157, 168, 188) : Color.rgb(111, 126, 151);
        int text = dark ? Color.rgb(202, 211, 226) : Color.rgb(87, 104, 133);
        int blue = Color.rgb(10, 132, 255);
        int fillBlue = dark ? Color.argb(36, 10, 132, 255) : Color.argb(22, 10, 132, 255);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dpF(1));
        paint.setColor(grid);
        for (int i = 0; i <= 4; i++) {
            float y = plot.top + i * plot.height() / 4f;
            canvas.drawLine(plot.left, y, plot.right, y, paint);
        }

        float[] labelFreqs = {20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000};
        for (float f : labelFreqs) {
            float x = freqToX(f);
            paint.setColor(grid);
            canvas.drawLine(x, plot.top, x, plot.bottom, paint);
        }

        textPaint.setColor(text);
        textPaint.setTextSize(dpF(10.5f));
        textPaint.setTextAlign(Paint.Align.RIGHT);
        float[] yVals = {12, 6, 0, -6, -12};
        for (int i = 0; i < yVals.length; i++) {
            float y = gainToY(yVals[i]);
            String s = yVals[i] > 0 ? "+" + (int)yVals[i] : Integer.toString((int)yVals[i]);
            canvas.drawText(s, plot.left - dp(7), y + dpF(3.5f), textPaint);
        }
        canvas.drawText("dB", plot.left - dp(7), plot.bottom + dp(20), textPaint);

        textPaint.setTextAlign(Paint.Align.CENTER);
        for (float f : labelFreqs) {
            canvas.drawText(formatFreq(f), freqToX(f), plot.bottom + dp(18), textPaint);
        }
        textPaint.setTextAlign(Paint.Align.RIGHT);
        canvas.drawText("Hz", plot.right, plot.bottom + dp(31), textPaint);

        for (int b = 0; b < AppState.BANDS; b++) {
            px[b] = freqToX(state.getBandFrequency(channel, b));
            py[b] = gainToY(state.getBandGain(channel, b));
        }

        // Selected-band Q visualization: narrower Q = wider highlighted frequency region.
        float q = state.getBandQ(channel, selectedBand);
        float bandHalfWidth = Math.max(dpF(5), Math.min(dpF(46), dpF(34) / (float)Math.sqrt(q)));
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(fillBlue);
        canvas.drawRoundRect(new RectF(px[selectedBand] - bandHalfWidth, plot.top, px[selectedBand] + bandHalfWidth, plot.bottom), dpF(9), dpF(9), paint);

        Path area = new Path();
        area.moveTo(px[0], plot.bottom);
        area.lineTo(px[0], py[0]);
        for (int b = 1; b < AppState.BANDS; b++) area.lineTo(px[b], py[b]);
        area.lineTo(px[AppState.BANDS - 1], plot.bottom);
        area.close();
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(fillBlue);
        canvas.drawPath(area, paint);

        Path curve = new Path();
        curve.moveTo(px[0], py[0]);
        for (int b = 1; b < AppState.BANDS; b++) curve.lineTo(px[b], py[b]);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dpF(2));
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setColor(blue);
        canvas.drawPath(curve, paint);

        for (int b = 0; b < AppState.BANDS; b++) {
            boolean selected = b == selectedBand;
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(blue);
            canvas.drawCircle(px[b], py[b], dpF(selected ? 6.5f : 4.5f), paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dpF(selected ? 2.4f : 1.4f));
            paint.setColor(dark ? Color.rgb(29, 35, 47) : Color.WHITE);
            canvas.drawCircle(px[b], py[b], dpF(selected ? 8.5f : 5.8f), paint);
        }

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(subtle);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                int nearest = nearestBand(event.getX(), event.getY());
                if (nearest >= 0) {
                    draggingBand = nearest;
                    selectedBand = nearest;
                    state.setSelectedBand(nearest);
                    if (listener != null) listener.onBandSelected(nearest);
                    getParent().requestDisallowInterceptTouchEvent(true);
                    invalidate();
                    return true;
                }
                return true;
            }
            case MotionEvent.ACTION_MOVE: {
                if (draggingBand >= 0) {
                    float f = xToFreq(clamp(event.getX(), plot.left, plot.right));
                    float g = yToGain(clamp(event.getY(), plot.top, plot.bottom));
                    state.setBandFrequency(channel, draggingBand, f);
                    state.setBandGain(channel, draggingBand, g);
                    if (listener != null) {
                        listener.onBandDragged(draggingBand,
                                state.getBandFrequency(channel, draggingBand),
                                state.getBandGain(channel, draggingBand));
                    }
                    invalidate();
                    return true;
                }
                break;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                draggingBand = -1;
                getParent().requestDisallowInterceptTouchEvent(false);
                return true;
        }
        return true;
    }

    private int nearestBand(float x, float y) {
        int nearest = -1;
        float best = dpF(36) * dpF(36);
        for (int b = 0; b < AppState.BANDS; b++) {
            float dx = x - px[b], dy = y - py[b];
            float d2 = dx * dx + dy * dy;
            if (d2 < best) {
                best = d2;
                nearest = b;
            }
        }
        // If the user taps inside the plot but not near a point, choose the nearest X band.
        if (nearest < 0 && plot.contains(x, y)) {
            float xBest = Float.MAX_VALUE;
            for (int b = 0; b < AppState.BANDS; b++) {
                float d = Math.abs(x - px[b]);
                if (d < xBest) { xBest = d; nearest = b; }
            }
        }
        return nearest;
    }

    private float freqToX(float freq) {
        double min = Math.log10(20.0), max = Math.log10(20000.0);
        double t = (Math.log10(Math.max(20.0, Math.min(20000.0, freq))) - min) / (max - min);
        return (float)(plot.left + t * plot.width());
    }

    private float xToFreq(float x) {
        double min = Math.log10(20.0), max = Math.log10(20000.0);
        double t = (x - plot.left) / Math.max(1f, plot.width());
        return (float)Math.pow(10.0, min + t * (max - min));
    }

    private float gainToY(float gain) {
        float t = (12f - gain) / 24f;
        return plot.top + t * plot.height();
    }

    private float yToGain(float y) {
        float t = (y - plot.top) / Math.max(1f, plot.height());
        float gain = 12f - t * 24f;
        return Math.round(gain * 10f) / 10f;
    }

    private String formatFreq(float f) {
        if (f >= 1000f) {
            float k = f / 1000f;
            if (Math.abs(k - Math.round(k)) < 0.01f) return String.format(Locale.US, "%dk", Math.round(k));
            return String.format(Locale.US, "%.1fk", k);
        }
        return Integer.toString(Math.round(f));
    }

    private float clamp(float v, float min, float max) { return Math.max(min, Math.min(max, v)); }
    private int dp(float v) { return Math.round(v * density); }
    private float dpF(float v) { return v * density; }
}
