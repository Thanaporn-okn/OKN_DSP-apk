package com.okn.dsp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

final class EqGraphView extends View {
    interface Listener {
        void onBandSelected(int band);
    }

    private final DspUiState state;
    private ThemePalette palette;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private Listener listener;
    private float density;

    EqGraphView(Context context, DspUiState state, ThemePalette palette) {
        super(context);
        this.state = state;
        this.palette = palette;
        density = getResources().getDisplayMetrics().density;
        setMinimumHeight((int) (280f * density));
        setFocusable(true);
        setClickable(true);
    }

    void setPalette(ThemePalette palette) {
        this.palette = palette;
        invalidate();
    }

    void setListener(Listener listener) {
        this.listener = listener;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int desired = (int) (300f * density);
        int height = resolveSize(desired, heightMeasureSpec);
        setMeasuredDimension(width, height);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        float left = 46f * density;
        float right = w - 18f * density;
        float top = 18f * density;
        float bottom = h - 38f * density;

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(palette.cardAlt);
        canvas.drawRoundRect(new RectF(0, 0, w, h), 22f * density, 22f * density, paint);

        float sx = xForFreq(state.freq[state.selectedChannel][state.selectedBand], left, right);
        paint.setColor(withAlpha(palette.accent, 28));
        canvas.drawRoundRect(new RectF(sx - 15f * density, top, sx + 15f * density, bottom), 12f * density, 12f * density, paint);

        paint.setStrokeWidth(1f * density);
        paint.setColor(withAlpha(palette.muted, 55));
        paint.setStyle(Paint.Style.STROKE);
        for (int db = -12; db <= 12; db += 6) {
            float y = yForGain(db, top, bottom);
            canvas.drawLine(left, y, right, y, paint);
        }
        float[] gridFreq = {20f, 50f, 100f, 200f, 500f, 1000f, 2000f, 5000f, 10000f, 20000f};
        for (float f : gridFreq) {
            float x = xForFreq(f, left, right);
            canvas.drawLine(x, top, x, bottom, paint);
        }

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(palette.muted);
        paint.setTextSize(11f * getResources().getDisplayMetrics().scaledDensity);
        paint.setTextAlign(Paint.Align.RIGHT);
        for (int db = -12; db <= 12; db += 6) {
            float y = yForGain(db, top, bottom);
            canvas.drawText(db > 0 ? "+" + db : String.valueOf(db), left - 8f * density, y + 4f * density, paint);
        }
        paint.setTextAlign(Paint.Align.CENTER);
        for (float f : gridFreq) {
            float x = xForFreq(f, left, right);
            String label;
            if (f >= 1000f) label = (Math.abs(f / 1000f - Math.round(f / 1000f)) < 0.01f)
                    ? Math.round(f / 1000f) + "k" : String.format("%.1fk", f / 1000f);
            else label = String.valueOf(Math.round(f));
            canvas.drawText(label, x, h - 13f * density, paint);
        }

        int ch = state.selectedChannel;
        path.reset();
        for (int b = 0; b < DspUiState.BANDS; b++) {
            float x = xForFreq(state.freq[ch][b], left, right);
            float y = yForGain(state.gain[ch][b], top, bottom);
            if (b == 0) path.moveTo(x, y); else path.lineTo(x, y);
        }
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2.2f * density);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setColor(palette.accent);
        canvas.drawPath(path, paint);

        paint.setStyle(Paint.Style.FILL);
        for (int b = 0; b < DspUiState.BANDS; b++) {
            float x = xForFreq(state.freq[ch][b], left, right);
            float y = yForGain(state.gain[ch][b], top, bottom);
            boolean selected = b == state.selectedBand;
            if (selected) {
                paint.setColor(palette.card);
                canvas.drawCircle(x, y, 9f * density, paint);
            }
            paint.setColor(palette.accent);
            canvas.drawCircle(x, y, (selected ? 6f : 4.3f) * density, paint);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getActionMasked() != MotionEvent.ACTION_DOWN) return super.onTouchEvent(event);
        float left = 46f * density;
        float right = getWidth() - 18f * density;
        int ch = state.selectedChannel;
        int nearest = 0;
        float best = Float.MAX_VALUE;
        for (int b = 0; b < DspUiState.BANDS; b++) {
            float x = xForFreq(state.freq[ch][b], left, right);
            float d = Math.abs(event.getX() - x);
            if (d < best) {
                best = d;
                nearest = b;
            }
        }
        state.selectedBand = nearest;
        state.saveFast();
        if (listener != null) listener.onBandSelected(nearest);
        performClick();
        invalidate();
        return true;
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    private float xForFreq(float f, float left, float right) {
        double min = Math.log10(20.0);
        double max = Math.log10(20000.0);
        double t = (Math.log10(Math.max(20f, Math.min(20000f, f))) - min) / (max - min);
        return left + (float) t * (right - left);
    }

    private float yForGain(float gain, float top, float bottom) {
        float t = (12f - gain) / 24f;
        return top + t * (bottom - top);
    }

    private static int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | ((alpha & 0xFF) << 24);
    }
}
