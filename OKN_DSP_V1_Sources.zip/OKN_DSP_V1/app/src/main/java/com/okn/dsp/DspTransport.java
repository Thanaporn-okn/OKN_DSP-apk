package com.okn.dsp;

/**
 * Phase 2 integration boundary.
 * Phase 1 keeps the UI fully interactive but does not send hardware packets.
 * When the user's DSP protocol data is supplied, a BLE/transport implementation can be
 * connected here without rewriting the UI or persistence layer.
 */
public interface DspTransport {
    void setMasterVolume(float db);
    void setBassVolume(float db);
    void setBassCutoff(float hz);
    void setChannelVolume(int channel, float db);
    void setEqBand(int channel, int band, float frequencyHz, float q, float gainDb);
}
