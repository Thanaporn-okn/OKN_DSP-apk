package com.okn.dsp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Phase 1 UI is rendered entirely from code. The uploaded design images are not
 * embedded as a background or screen bitmap. Every visible card, graph, icon,
 * button, channel chip and slider is drawn and hit-tested here.
 */
final class OknDspView extends View {
    private static final float DESIGN_W = 390f;
    private static final float MIN_DESIGN_H = 820f;

    private static final int A_NAV_HOME = 1;
    private static final int A_NAV_MIX = 2;
    private static final int A_NAV_EQ = 3;
    private static final int A_THEME = 4;
    private static final int A_RESET_GLOBAL = 5;
    private static final int A_RESET_CHANNELS = 6;
    private static final int A_CHANNEL = 7;
    private static final int A_BAND = 8;
    private static final int A_BAND_PREV = 9;
    private static final int A_BAND_NEXT = 10;
    private static final int A_FLAT = 11;
    private static final int A_RESET_EQ = 12;
    private static final int A_SAVE_PRESET = 13;
    private static final int A_LOAD_PRESET = 14;
    private static final int A_DELETE_PRESET = 15;
    private static final int A_MASTER = 20;
    private static final int A_BASS = 21;
    private static final int A_CUTOFF = 22;
    private static final int A_CHANNEL_VOL = 23;
    private static final int A_FREQ = 24;
    private static final int A_Q = 25;
    private static final int A_GAIN = 26;
    private static final int A_GRAPH = 27;

    private final AppState state;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final List<Hit> hits = new ArrayList<>();

    private Hit activeHit;
    private float scale = 1f;
    private float logicalW = DESIGN_W;
    private float logicalH = 844f;
    private float contentLeft = 0f;

    private int bg, card, card2, text, muted, border, pink, cyan, blue, green, purple, track;

    OknDspView(Context context, AppState state) {
        super(context);
        this.state = state;
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        setFocusable(true);
        setClickable(true);
        setLayerType(View.LAYER_TYPE_HARDWARE, null);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        calculateTransform();
        applyPalette();
        canvas.drawColor(bg);
        hits.clear();

        canvas.save();
        canvas.scale(scale, scale);
        canvas.translate(contentLeft, 0f);

        drawHeader(canvas);
        if (state.screen == 0) drawHome(canvas);
        else if (state.screen == 1) drawMix(canvas);
        else drawEq(canvas);
        drawBottomNav(canvas);

        canvas.restore();
    }

    private void calculateTransform() {
        float vw = Math.max(1, getWidth());
        float vh = Math.max(1, getHeight());
        scale = vw / DESIGN_W;
        logicalH = vh / scale;
        logicalW = DESIGN_W;
        contentLeft = 0f;

        if (logicalH < MIN_DESIGN_H) {
            scale = vh / MIN_DESIGN_H;
            logicalH = MIN_DESIGN_H;
            logicalW = vw / scale;
            contentLeft = (logicalW - DESIGN_W) * 0.5f;
        }
    }

    private void applyPalette() {
        pink = Color.rgb(255, 46, 109);
        cyan = Color.rgb(27, 201, 222);
        blue = Color.rgb(41, 121, 255);
        green = Color.rgb(34, 197, 94);
        purple = Color.rgb(139, 92, 246);
        if (state.darkTheme) {
            bg = Color.rgb(7, 14, 26);
            card = Color.rgb(17, 28, 45);
            card2 = Color.rgb(22, 36, 57);
            text = Color.rgb(245, 248, 253);
            muted = Color.rgb(153, 166, 187);
            border = Color.rgb(40, 57, 80);
            track = Color.rgb(63, 79, 101);
        } else {
            bg = Color.rgb(247, 249, 252);
            card = Color.WHITE;
            card2 = Color.rgb(242, 246, 251);
            text = Color.rgb(10, 18, 33);
            muted = Color.rgb(110, 126, 151);
            border = Color.rgb(224, 230, 239);
            track = Color.rgb(211, 220, 232);
        }
    }

    private void drawHeader(Canvas c) {
        float top = 14f;
        drawLogo(c, 18f, top + 3f, 34f);
        txt(c, "OKN DSP", 60f, top + 22f, 18f, text, Paint.Align.LEFT, true);
        txt(c, screenSubtitle(), 60f, top + 38f, 10f, muted, Paint.Align.LEFT, false);

        RectF theme = new RectF(336f, top + 1f, 374f, top + 39f);
        rounded(c, theme, 19f, card, border, 1f);
        drawThemeIcon(c, theme.centerX(), theme.centerY(), state.darkTheme);
        addHit(A_THEME, theme, 0, 0f, 0f, false);
    }

    private String screenSubtitle() {
        if (state.screen == 0) return "DSP Controller · Phase 1 UI";
        if (state.screen == 1) return "Global and channel controls";
        return "15-band EQ · 7 channels";
    }

    private void drawLogo(Canvas c, float x, float y, float s) {
        RectF r = new RectF(x, y, x + s, y + s);
        rounded(c, r, s * 0.22f, state.darkTheme ? Color.rgb(5, 18, 35) : Color.rgb(11, 28, 52), Color.TRANSPARENT, 0f);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(s * 0.09f);
        p.setShader(new LinearGradient(x + s * .35f, y + s * .15f, x + s * .65f, y + s * .85f,
                new int[]{Color.rgb(38, 225, 242), Color.rgb(36, 120, 255)}, null, Shader.TileMode.CLAMP));
        c.drawLine(x + s * .42f, y + s * .20f, x + s * .42f, y + s * .80f, p);
        c.drawLine(x + s * .46f, y + s * .55f, x + s * .72f, y + s * .28f, p);
        c.drawLine(x + s * .48f, y + s * .58f, x + s * .72f, y + s * .78f, p);
        p.setShader(null);
        p.setStrokeWidth(s * .045f);
        p.setColor(cyan);
        c.drawLine(x + s * .18f, y + s * .40f, x + s * .18f, y + s * .65f, p);
        c.drawLine(x + s * .82f, y + s * .40f, x + s * .82f, y + s * .65f, p);
    }

    private void drawThemeIcon(Canvas c, float cx, float cy, boolean dark) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2f);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setColor(dark ? Color.rgb(255, 213, 79) : Color.rgb(66, 80, 105));
        if (dark) {
            c.drawCircle(cx, cy, 6f, p);
            for (int i = 0; i < 8; i++) {
                double a = Math.PI * 2.0 * i / 8.0;
                c.drawLine(cx + (float)Math.cos(a) * 9f, cy + (float)Math.sin(a) * 9f,
                        cx + (float)Math.cos(a) * 12f, cy + (float)Math.sin(a) * 12f, p);
            }
        } else {
            c.drawArc(new RectF(cx - 8, cy - 8, cx + 8, cy + 8), 65, 235, false, p);
            c.drawCircle(cx + 4f, cy - 4f, 7f, p);
        }
        p.setStyle(Paint.Style.FILL);
    }

    private void drawHome(Canvas c) {
        float y = 70f;
        RectF ready = new RectF(16, y, 374, y + 65);
        rounded(c, ready, 18, state.darkTheme ? Color.rgb(14, 51, 43) : Color.rgb(235, 255, 245), state.darkTheme ? Color.rgb(28, 82, 70) : Color.rgb(211, 244, 225), 1);
        circle(c, 47, y + 32, 20, green);
        check(c, 47, y + 32, 8, Color.WHITE);
        txt(c, "SYSTEM STATUS", 76, y + 23, 9, muted, Paint.Align.LEFT, true);
        txt(c, "System Ready", 76, y + 39, 15, text, Paint.Align.LEFT, true);
        txt(c, "UI controls active · DSP transport starts in Phase 2", 76, y + 53, 9, muted, Paint.Align.LEFT, false);

        y += 79;
        txt(c, "Connection & Status", 18, y, 14, text, Paint.Align.LEFT, true);
        txt(c, "Auto-save On", 372, y, 10, green, Paint.Align.RIGHT, true);
        y += 13;
        statusRow(c, y, "BT", "Bluetooth", "Phase 2 connection", cyan, "Prepared"); y += 48;
        statusRow(c, y, "DSP", "DSP Device", "Protocol input files received", pink, "Queued"); y += 48;
        statusRow(c, y, "IN", "Audio Input", "UI simulation / local values", blue, "Active"); y += 48;
        statusRow(c, y, "PS", "Preset Sync", "One local preset slot", purple, state.hasPreset ? "Saved" : "Empty"); y += 48;

        txt(c, "Quick Control", 18, y + 11, 14, text, Paint.Align.LEFT, true);
        y += 24;
        RectF quick = new RectF(16, y, 374, y + 180);
        rounded(c, quick, 18, card, border, 1);
        drawLabeledSlider(c, "Master Volume", "Overall output", AppState.db(state.masterVolume),
                30, y + 20, 350, y + 55, state.masterVolume, -70, 6, pink, A_MASTER, 0, false);
        drawLabeledSlider(c, "Bass Volume", "Low-frequency level", AppState.db(state.bassVolume),
                30, y + 76, 350, y + 111, state.bassVolume, -70, 6, cyan, A_BASS, 0, false);
        drawLabeledSlider(c, "Bass Cutoff", "Crossover frequency", AppState.hz(state.bassCutoff),
                30, y + 132, 350, y + 167, state.bassCutoff, 20, 200, purple, A_CUTOFF, 0, false);

        float noteY = y + 194;
        RectF note = new RectF(16, noteY, 374, Math.min(noteY + 54, navTop() - 10));
        if (note.height() > 34) {
            rounded(c, note, 15, state.darkTheme ? Color.rgb(12, 31, 49) : Color.rgb(235, 246, 255), border, 1);
            txt(c, "REAL-TIME LOCAL STATE", 30, note.top + 18, 9, blue, Paint.Align.LEFT, true);
            txt(c, "Every drag/tap is persisted immediately and restored on next launch.", 30, note.top + 36, 9, muted, Paint.Align.LEFT, false);
        }
    }

    private void statusRow(Canvas c, float y, String badge, String title, String sub, int accent, String right) {
        RectF r = new RectF(16, y, 374, y + 42);
        rounded(c, r, 14, card, border, 1);
        circle(c, 38, y + 21, 14, withAlpha(accent, state.darkTheme ? 210 : 230));
        txt(c, badge, 38, y + 25, 8, Color.WHITE, Paint.Align.CENTER, true);
        txt(c, title, 62, y + 17, 11, text, Paint.Align.LEFT, true);
        txt(c, sub, 62, y + 31, 8.5f, muted, Paint.Align.LEFT, false);
        circle(c, 314, y + 21, 4, right.equals("Active") || right.equals("Prepared") || right.equals("Saved") ? green : blue);
        txt(c, right, 366, y + 24, 9, muted, Paint.Align.RIGHT, true);
    }

    private void drawMix(Canvas c) {
        float y = 70;
        txt(c, "Global", 18, y, 16, text, Paint.Align.LEFT, true);
        txt(c, "Overall output and bass settings", 372, y, 9, muted, Paint.Align.RIGHT, false);
        y += 10;
        RectF global = new RectF(16, y, 374, y + 176);
        rounded(c, global, 18, card, border, 1);
        drawCompactSlider(c, "Master Volume", state.masterVolume, -70, 6, pink, 30, y + 24, 350, A_MASTER, 0, false, AppState.db(state.masterVolume));
        drawCompactSlider(c, "Bass Volume", state.bassVolume, -70, 6, cyan, 30, y + 78, 350, A_BASS, 0, false, AppState.db(state.bassVolume));
        drawCompactSlider(c, "Bass Cutoff", state.bassCutoff, 20, 200, purple, 30, y + 132, 350, A_CUTOFF, 0, false, AppState.hz(state.bassCutoff));

        RectF resetGlobal = new RectF(226, y + 184, 374, y + 217);
        rounded(c, resetGlobal, 12, state.darkTheme ? Color.rgb(63, 25, 43) : Color.rgb(255, 238, 244), withAlpha(pink, 100), 1);
        txt(c, "Reset Global", resetGlobal.centerX(), resetGlobal.centerY() + 4, 10, pink, Paint.Align.CENTER, true);
        addHit(A_RESET_GLOBAL, resetGlobal, 0, 0, 0, false);

        y += 232;
        txt(c, "Channels", 18, y, 16, text, Paint.Align.LEFT, true);
        txt(c, "Individual channel levels", 372, y, 9, muted, Paint.Align.RIGHT, false);
        y += 12;

        float available = navTop() - y - 51;
        float rowH = Math.max(40f, Math.min(47f, available / 7f));
        RectF channels = new RectF(16, y, 374, y + rowH * 7f + 6);
        rounded(c, channels, 18, card, border, 1);
        int[] accents = {pink, cyan, green, pink, green, cyan, Color.rgb(255, 79, 79)};
        for (int i = 0; i < 7; i++) {
            float cy = y + 6 + rowH * i;
            circle(c, 38, cy + rowH * .5f, 13, accents[i]);
            txt(c, Integer.toString(i + 1), 38, cy + rowH * .5f + 4, 10, Color.WHITE, Paint.Align.CENTER, true);
            txt(c, "Volume " + AppState.CHANNEL_NAMES[i], 61, cy + rowH * .5f - 4, 10.5f, text, Paint.Align.LEFT, true);
            RectF sr = new RectF(61, cy + rowH * .5f + 3, 318, cy + rowH * .5f + 18);
            drawSliderTrack(c, sr, state.channelVolume[i], -70, 6, accents[i], false);
            txt(c, String.format(Locale.US, "%.0f", state.channelVolume[i]) + " dB", 354, cy + rowH * .5f + 8, 9, muted, Paint.Align.CENTER, true);
            addHit(A_CHANNEL_VOL, expanded(sr, 3, 10), i, -70, 6, false);
        }

        RectF resetChannels = new RectF(226, navTop() - 39, 374, navTop() - 7);
        rounded(c, resetChannels, 12, state.darkTheme ? Color.rgb(22, 50, 50) : Color.rgb(236, 253, 249), withAlpha(cyan, 110), 1);
        txt(c, "Reset Channels", resetChannels.centerX(), resetChannels.centerY() + 4, 10, cyan, Paint.Align.CENTER, true);
        addHit(A_RESET_CHANNELS, resetChannels, 0, 0, 0, false);
    }

    private void drawEq(Canvas c) {
        float y = 69;
        // Channel selector
        float gap = 5f;
        float chipW = (356f - gap * 6f) / 7f;
        for (int i = 0; i < 7; i++) {
            float x = 17 + i * (chipW + gap);
            RectF r = new RectF(x, y, x + chipW, y + 29);
            boolean sel = state.channel == i;
            rounded(c, r, 14, sel ? pink : card2, sel ? pink : border, 1);
            txt(c, AppState.CHANNEL_NAMES[i], r.centerX(), r.centerY() + 3.5f, 8.5f, sel ? Color.WHITE : muted, Paint.Align.CENTER, true);
            addHit(A_CHANNEL, r, i, 0, 0, false);
        }

        y += 42;
        txt(c, "Channel " + (state.channel + 1), 18, y, 15, text, Paint.Align.LEFT, true);
        txt(c, "Front Left · 15-band EQ", 18, y + 14, 8.5f, muted, Paint.Align.LEFT, false);
        RectF reset = new RectF(300, y - 10, 374, y + 20);
        rounded(c, reset, 12, state.darkTheme ? Color.rgb(63, 25, 43) : Color.rgb(255, 239, 244), withAlpha(pink, 80), 1);
        txt(c, "Reset EQ", reset.centerX(), reset.centerY() + 3.5f, 8.5f, pink, Paint.Align.CENTER, true);
        addHit(A_RESET_EQ, reset, 0, 0, 0, false);

        float graphTop = y + 28;
        float graphBottom = graphTop + 180;
        RectF gr = new RectF(18, graphTop, 372, graphBottom);
        rounded(c, gr, 14, card, border, 1);
        drawEqGraph(c, gr);
        addHit(A_GRAPH, gr, 0, -12, 12, false);

        float bandY = graphBottom + 10;
        float bw = 22f;
        float bgap = (354f - bw * 15f) / 14f;
        for (int b = 0; b < 15; b++) {
            float x = 18 + b * (bw + bgap);
            RectF br = new RectF(x, bandY, x + bw, bandY + 24);
            boolean sel = state.band == b;
            rounded(c, br, 9, sel ? withAlpha(pink, 230) : card2, sel ? pink : border, 1);
            txt(c, Integer.toString(b + 1), br.centerX(), br.centerY() + 3, 7.2f, sel ? Color.WHITE : muted, Paint.Align.CENTER, true);
            addHit(A_BAND, br, b, 0, 0, false);
        }

        y = bandY + 37;
        RectF info = new RectF(16, y, 374, y + 46);
        rounded(c, info, 15, card, border, 1);
        circle(c, 40, y + 23, 15, state.band % 2 == 0 ? pink : cyan);
        txt(c, Integer.toString(state.band + 1), 40, y + 27, 11, Color.WHITE, Paint.Align.CENTER, true);
        txt(c, "Band " + (state.band + 1), 64, y + 19, 12, text, Paint.Align.LEFT, true);
        txt(c, "Drag the graph point or use the controls below", 64, y + 34, 8.5f, muted, Paint.Align.LEFT, false);
        RectF prev = new RectF(314, y + 8, 338, y + 38);
        RectF next = new RectF(342, y + 8, 366, y + 38);
        rounded(c, prev, 12, card2, border, 1); rounded(c, next, 12, card2, border, 1);
        txt(c, "‹", prev.centerX(), prev.centerY() + 5, 18, muted, Paint.Align.CENTER, true);
        txt(c, "›", next.centerX(), next.centerY() + 5, 18, muted, Paint.Align.CENTER, true);
        addHit(A_BAND_PREV, prev, 0, 0, 0, false); addHit(A_BAND_NEXT, next, 0, 0, 0, false);

        y += 58;
        RectF controls = new RectF(16, y, 374, y + 166);
        rounded(c, controls, 17, card, border, 1);
        int ch = state.channel, b = state.band;
        drawControlSlider(c, "Frequency", AppState.hz(state.freq[ch][b]), state.freq[ch][b], 20, 20000, blue,
                30, y + 19, 350, A_FREQ, 0, true);
        drawControlSlider(c, "Q (Quality Factor)", AppState.qValue(state.q[ch][b]), state.q[ch][b], 0.1f, 10f, cyan,
                30, y + 72, 350, A_Q, 0, true);
        drawControlSlider(c, "Gain Band", AppState.db(state.gain[ch][b]), state.gain[ch][b], -12, 12, green,
                30, y + 125, 350, A_GAIN, 0, false);

        y += 177;
        RectF presets = new RectF(16, y, 374, Math.min(y + 86, navTop() - 8));
        if (presets.height() >= 68) {
            rounded(c, presets, 17, card, border, 1);
            txt(c, "Presets", 30, y + 21, 12, text, Paint.Align.LEFT, true);
            txt(c, state.hasPreset ? "Slot 1 saved" : "Slot 1 empty", 360, y + 21, 9, state.hasPreset ? green : muted, Paint.Align.RIGHT, true);
            RectF flat = new RectF(29, y + 35, 102, y + 69);
            RectF save = new RectF(109, y + 35, 202, y + 69);
            RectF load = new RectF(209, y + 35, 278, y + 69);
            RectF del = new RectF(285, y + 35, 361, y + 69);
            button(c, flat, "Flat", blue, false); button(c, save, "Save", pink, true);
            button(c, load, "Load", purple, false); button(c, del, "Delete", pink, false);
            addHit(A_FLAT, flat, 0, 0, 0, false);
            addHit(A_SAVE_PRESET, save, 0, 0, 0, false);
            addHit(A_LOAD_PRESET, load, 0, 0, 0, false);
            addHit(A_DELETE_PRESET, del, 0, 0, 0, false);
        }
    }

    private void drawEqGraph(Canvas c, RectF r) {
        float l = r.left + 30, rr = r.right - 12, t = r.top + 17, btm = r.bottom - 25;
        stroke.setStrokeWidth(1f);
        stroke.setColor(border);
        // dB horizontal grid
        for (int i = 0; i <= 4; i++) {
            float y = t + (btm - t) * i / 4f;
            c.drawLine(l, y, rr, y, stroke);
            float db = 12f - i * 6f;
            txt(c, String.format(Locale.US, "%+.0f", db), l - 6, y + 3, 7, muted, Paint.Align.RIGHT, false);
        }
        float[] fLabels = {20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000};
        for (float f : fLabels) {
            float x = freqX(f, l, rr);
            c.drawLine(x, t, x, btm, stroke);
            txt(c, shortHz(f), x, btm + 13, 6.5f, muted, Paint.Align.CENTER, false);
        }

        int ch = state.channel;
        path.reset();
        for (int i = 0; i < AppState.BANDS; i++) {
            float x = freqX(state.freq[ch][i], l, rr);
            float y = gainY(state.gain[ch][i], t, btm);
            if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
        }
        stroke.setStrokeWidth(2.4f);
        stroke.setShader(new LinearGradient(l, 0, rr, 0, new int[]{blue, cyan, green, pink}, null, Shader.TileMode.CLAMP));
        c.drawPath(path, stroke);
        stroke.setShader(null);

        for (int i = 0; i < AppState.BANDS; i++) {
            float x = freqX(state.freq[ch][i], l, rr);
            float y = gainY(state.gain[ch][i], t, btm);
            int col = i == state.band ? pink : (i < 5 ? blue : (i < 10 ? cyan : pink));
            circle(c, x, y, i == state.band ? 5.5f : 3.8f, col);
            circleStroke(c, x, y, i == state.band ? 7.5f : 5.2f, withAlpha(col, 90), 1f);
        }
    }

    private void drawBottomNav(Canvas c) {
        float top = navTop();
        RectF nav = new RectF(16, top, 374, logicalH - 13);
        rounded(c, nav, 18, card, border, 1);
        String[] labels = {"Home", "Mix", "EQ"};
        int[] actions = {A_NAV_HOME, A_NAV_MIX, A_NAV_EQ};
        for (int i = 0; i < 3; i++) {
            float cellL = 21 + i * 116f;
            RectF cell = new RectF(cellL, top + 6, cellL + 110, logicalH - 19);
            boolean sel = state.screen == i;
            if (sel) rounded(c, cell, 15, state.darkTheme ? withAlpha(pink, 75) : Color.rgb(255, 239, 245), Color.TRANSPARENT, 0);
            drawNavIcon(c, i, cell.centerX(), top + 19, sel ? pink : muted);
            txt(c, labels[i], cell.centerX(), top + 43, 8.5f, sel ? pink : muted, Paint.Align.CENTER, true);
            addHit(actions[i], cell, 0, 0, 0, false);
        }
    }

    private float navTop() {
        return logicalH - 65f;
    }

    private void drawNavIcon(Canvas c, int i, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(2f); stroke.setStyle(Paint.Style.STROKE);
        if (i == 0) {
            path.reset(); path.moveTo(cx - 7, cy); path.lineTo(cx, cy - 6); path.lineTo(cx + 7, cy); path.lineTo(cx + 7, cy + 7); path.lineTo(cx + 2, cy + 7); path.lineTo(cx + 2, cy + 2); path.lineTo(cx - 2, cy + 2); path.lineTo(cx - 2, cy + 7); path.lineTo(cx - 7, cy + 7); path.close(); c.drawPath(path, stroke);
        } else if (i == 1) {
            c.drawLine(cx - 7, cy - 6, cx - 7, cy + 7, stroke); c.drawLine(cx, cy - 6, cx, cy + 7, stroke); c.drawLine(cx + 7, cy - 6, cx + 7, cy + 7, stroke);
            circle(c, cx - 7, cy - 2, 2.5f, color); circle(c, cx, cy + 3, 2.5f, color); circle(c, cx + 7, cy - 1, 2.5f, color);
        } else {
            c.drawLine(cx - 7, cy + 6, cx - 7, cy - 1, stroke); c.drawLine(cx, cy + 6, cx, cy - 7, stroke); c.drawLine(cx + 7, cy + 6, cx + 7, cy - 4, stroke);
        }
        stroke.setStyle(Paint.Style.STROKE);
    }

    private void drawLabeledSlider(Canvas c, String title, String sub, String value,
                                   float left, float top, float right, float bottom,
                                   float v, float min, float max, int accent, int action, int index, boolean log) {
        txt(c, title, left, top + 10, 10.5f, text, Paint.Align.LEFT, true);
        txt(c, sub, left, top + 23, 8f, muted, Paint.Align.LEFT, false);
        txt(c, value, right, top + 10, 9f, muted, Paint.Align.RIGHT, true);
        RectF sr = new RectF(left, bottom - 10, right, bottom);
        drawSliderTrack(c, sr, v, min, max, accent, log);
        addHit(action, expanded(sr, 0, 10), index, min, max, log);
    }

    private void drawCompactSlider(Canvas c, String label, float v, float min, float max, int accent,
                                   float left, float cy, float right, int action, int index, boolean log, String value) {
        txt(c, label, left, cy - 7, 10.5f, text, Paint.Align.LEFT, true);
        txt(c, value, right, cy - 7, 9, muted, Paint.Align.RIGHT, true);
        RectF sr = new RectF(left, cy + 3, right, cy + 15);
        drawSliderTrack(c, sr, v, min, max, accent, log);
        addHit(action, expanded(sr, 0, 10), index, min, max, log);
    }

    private void drawControlSlider(Canvas c, String label, String value, float v, float min, float max, int accent,
                                   float left, float cy, float right, int action, int index, boolean log) {
        txt(c, label, left, cy, 10.5f, text, Paint.Align.LEFT, true);
        RectF pill = new RectF(right - 72, cy - 14, right, cy + 7);
        rounded(c, pill, 10, card2, border, 1);
        txt(c, value, pill.centerX(), pill.centerY() + 3, 8.5f, muted, Paint.Align.CENTER, true);
        RectF sr = new RectF(left, cy + 16, right, cy + 28);
        drawSliderTrack(c, sr, v, min, max, accent, log);
        addHit(action, expanded(sr, 0, 10), index, min, max, log);
    }

    private void drawSliderTrack(Canvas c, RectF r, float v, float min, float max, int accent, boolean log) {
        float cy = r.centerY();
        float x1 = r.left, x2 = r.right;
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(4f);
        p.setColor(track);
        c.drawLine(x1, cy, x2, cy, p);
        float t = valueToT(v, min, max, log);
        float x = x1 + (x2 - x1) * t;
        p.setShader(new LinearGradient(x1, 0, Math.max(x1 + 1, x), 0,
                new int[]{accent == pink ? pink : cyan, accent}, null, Shader.TileMode.CLAMP));
        c.drawLine(x1, cy, x, cy, p);
        p.setShader(null);
        circle(c, x, cy, 6.5f, state.darkTheme ? Color.rgb(238, 242, 248) : Color.WHITE);
        circleStroke(c, x, cy, 7.2f, withAlpha(accent, 130), 1.2f);
    }

    private float valueToT(float v, float min, float max, boolean log) {
        if (log) {
            double a = Math.log(Math.max(0.0001, min));
            double b = Math.log(Math.max(0.0001, max));
            return (float)((Math.log(Math.max(0.0001, v)) - a) / (b - a));
        }
        return (v - min) / (max - min);
    }

    private float tToValue(float t, float min, float max, boolean log) {
        t = AppState.clamp(t, 0f, 1f);
        if (log) {
            double a = Math.log(Math.max(0.0001, min));
            double b = Math.log(Math.max(0.0001, max));
            return (float)Math.exp(a + (b - a) * t);
        }
        return min + (max - min) * t;
    }

    private void button(Canvas c, RectF r, String label, int accent, boolean filled) {
        rounded(c, r, 10, filled ? accent : card2, filled ? accent : withAlpha(accent, 100), 1);
        txt(c, label, r.centerX(), r.centerY() + 3.5f, 8.5f, filled ? Color.WHITE : accent, Paint.Align.CENTER, true);
    }

    private void rounded(Canvas c, RectF r, float radius, int fill, int strokeColor, float sw) {
        p.setStyle(Paint.Style.FILL); p.setColor(fill); p.setShader(null); c.drawRoundRect(r, radius, radius, p);
        if (strokeColor != Color.TRANSPARENT && sw > 0) {
            stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(sw); stroke.setColor(strokeColor); stroke.setShader(null); c.drawRoundRect(r, radius, radius, stroke);
        }
    }

    private void circle(Canvas c, float cx, float cy, float radius, int color) {
        p.setStyle(Paint.Style.FILL); p.setShader(null); p.setColor(color); c.drawCircle(cx, cy, radius, p);
    }

    private void circleStroke(Canvas c, float cx, float cy, float radius, int color, float sw) {
        stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(sw); stroke.setColor(color); stroke.setShader(null); c.drawCircle(cx, cy, radius, stroke);
    }

    private void check(Canvas c, float cx, float cy, float s, int color) {
        stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(2.5f); stroke.setStrokeCap(Paint.Cap.ROUND); stroke.setColor(color);
        path.reset(); path.moveTo(cx - s * .65f, cy); path.lineTo(cx - s * .15f, cy + s * .45f); path.lineTo(cx + s * .75f, cy - s * .55f); c.drawPath(path, stroke);
    }

    private void txt(Canvas c, String s, float x, float y, float size, int color, Paint.Align align, boolean bold) {
        p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(color); p.setTextAlign(align); p.setTextSize(size);
        p.setTypeface(bold ? android.graphics.Typeface.create("sans", android.graphics.Typeface.BOLD) : android.graphics.Typeface.create("sans", android.graphics.Typeface.NORMAL));
        c.drawText(s, x, y, p);
    }

    private int withAlpha(int color, int a) {
        return Color.argb(a, Color.red(color), Color.green(color), Color.blue(color));
    }

    private RectF expanded(RectF r, float dx, float dy) {
        return new RectF(r.left - dx, r.top - dy, r.right + dx, r.bottom + dy);
    }

    private void addHit(int action, RectF rect, int index, float min, float max, boolean log) {
        hits.add(new Hit(action, new RectF(rect), index, min, max, log));
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX() / scale - contentLeft;
        float y = event.getY() / scale;
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                activeHit = findHit(x, y);
                if (activeHit == null) return true;
                if (isContinuous(activeHit.action)) {
                    updateContinuous(activeHit, x, y);
                } else {
                    performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
                }
                return true;
            case MotionEvent.ACTION_MOVE:
                if (activeHit != null && isContinuous(activeHit.action)) updateContinuous(activeHit, x, y);
                return true;
            case MotionEvent.ACTION_UP:
                if (activeHit != null) {
                    if (isContinuous(activeHit.action)) updateContinuous(activeHit, x, y);
                    else if (activeHit.rect.contains(x, y)) handleTap(activeHit);
                }
                activeHit = null;
                return true;
            case MotionEvent.ACTION_CANCEL:
                activeHit = null;
                return true;
            default:
                return true;
        }
    }

    private Hit findHit(float x, float y) {
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (h.rect.contains(x, y)) return h;
        }
        return null;
    }

    private boolean isContinuous(int action) {
        return action == A_MASTER || action == A_BASS || action == A_CUTOFF || action == A_CHANNEL_VOL
                || action == A_FREQ || action == A_Q || action == A_GAIN || action == A_GRAPH;
    }

    private void updateContinuous(Hit h, float x, float y) {
        if (h.action == A_GRAPH) {
            float l = h.rect.left + 30, rr = h.rect.right - 12, t = h.rect.top + 17, btm = h.rect.bottom - 25;
            int nearest = 0; float best = Float.MAX_VALUE;
            for (int i = 0; i < AppState.BANDS; i++) {
                float bx = freqX(state.freq[state.channel][i], l, rr);
                float d = Math.abs(bx - x);
                if (d < best) { best = d; nearest = i; }
            }
            state.band = nearest;
            float db = 12f - (y - t) / Math.max(1f, btm - t) * 24f;
            state.gain[state.channel][state.band] = AppState.clamp(db, -12f, 12f);
            state.saveNow();
            invalidate();
            return;
        }

        float t = (x - h.rect.left) / Math.max(1f, h.rect.width());
        float v = tToValue(t, h.min, h.max, h.log);
        if (h.action == A_MASTER) state.masterVolume = round(v, 0.1f);
        else if (h.action == A_BASS) state.bassVolume = round(v, 0.1f);
        else if (h.action == A_CUTOFF) state.bassCutoff = round(v, 1f);
        else if (h.action == A_CHANNEL_VOL) state.channelVolume[h.index] = round(v, 0.1f);
        else if (h.action == A_FREQ) state.freq[state.channel][state.band] = roundFreq(v);
        else if (h.action == A_Q) state.q[state.channel][state.band] = round(v, 0.01f);
        else if (h.action == A_GAIN) state.gain[state.channel][state.band] = round(v, 0.1f);
        state.saveNow();
        invalidate();
    }

    private float round(float v, float step) {
        return Math.round(v / step) * step;
    }

    private float roundFreq(float v) {
        if (v < 100) return Math.round(v);
        if (v < 1000) return Math.round(v / 5f) * 5f;
        return Math.round(v / 10f) * 10f;
    }

    private void handleTap(Hit h) {
        switch (h.action) {
            case A_NAV_HOME: state.screen = 0; break;
            case A_NAV_MIX: state.screen = 1; break;
            case A_NAV_EQ: state.screen = 2; break;
            case A_THEME: state.darkTheme = !state.darkTheme; break;
            case A_RESET_GLOBAL: state.resetGlobal(); invalidate(); return;
            case A_RESET_CHANNELS: state.resetChannels(); invalidate(); return;
            case A_CHANNEL: state.channel = h.index; break;
            case A_BAND: state.band = h.index; break;
            case A_BAND_PREV: state.band = (state.band + AppState.BANDS - 1) % AppState.BANDS; break;
            case A_BAND_NEXT: state.band = (state.band + 1) % AppState.BANDS; break;
            case A_FLAT: state.flattenCurrentEq(); invalidate(); return;
            case A_RESET_EQ: state.resetCurrentEq(); invalidate(); return;
            case A_SAVE_PRESET: state.savePreset(); invalidate(); return;
            case A_LOAD_PRESET: state.loadPreset(); invalidate(); return;
            case A_DELETE_PRESET: state.deletePreset(); invalidate(); return;
            default: return;
        }
        state.saveNow();
        invalidate();
    }

    private float freqX(float freq, float left, float right) {
        double a = Math.log10(20.0), b = Math.log10(20000.0);
        float t = (float)((Math.log10(AppState.clamp(freq, 20f, 20000f)) - a) / (b - a));
        return left + (right - left) * t;
    }

    private float gainY(float gain, float top, float bottom) {
        return top + (12f - AppState.clamp(gain, -12f, 12f)) / 24f * (bottom - top);
    }

    private String shortHz(float f) {
        if (f >= 1000) {
            float k = f / 1000f;
            return k == Math.round(k) ? String.format(Locale.US, "%.0fk", k) : String.format(Locale.US, "%.1fk", k);
        }
        return String.format(Locale.US, "%.0f", f);
    }

    private static final class Hit {
        final int action;
        final RectF rect;
        final int index;
        final float min, max;
        final boolean log;

        Hit(int action, RectF rect, int index, float min, float max, boolean log) {
            this.action = action;
            this.rect = rect;
            this.index = index;
            this.min = min;
            this.max = max;
            this.log = log;
        }
    }
}
