package com.okn.dsp;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Locale;

final class AppState {
    static final int CHANNELS = 7;
    static final int BANDS = 15;

    static final float[] DEFAULT_FREQ = {
            20f, 31.5f, 50f, 80f, 125f,
            200f, 315f, 500f, 800f, 1250f,
            2000f, 3150f, 5000f, 10000f, 20000f
    };

    static final String[] CHANNEL_NAMES = {
            "Ch1", "Ch2", "Ch3", "Ch4", "Ch5", "Ch6", "Ch7"
    };

    private static final String PREFS = "okn_dsp_v1_phase1";

    final Context context;
    boolean darkTheme;
    int screen = 0; // 0 Home, 1 Mix, 2 EQ
    int channel = 0;
    int band = 4;

    float masterVolume = -6f;
    float bassVolume = 2f;
    float bassCutoff = 80f;
    final float[] channelVolume = {-3f, -6f, -2f, -8f, 0f, -4f, -10f};
    final float[][] freq = new float[CHANNELS][BANDS];
    final float[][] gain = new float[CHANNELS][BANDS];
    final float[][] q = new float[CHANNELS][BANDS];

    final float[][] presetFreq = new float[CHANNELS][BANDS];
    final float[][] presetGain = new float[CHANNELS][BANDS];
    final float[][] presetQ = new float[CHANNELS][BANDS];
    boolean hasPreset = false;

    AppState(Context context) {
        this.context = context.getApplicationContext();
        setDefaults();
        load();
    }

    private void setDefaults() {
        for (int c = 0; c < CHANNELS; c++) {
            for (int b = 0; b < BANDS; b++) {
                freq[c][b] = DEFAULT_FREQ[b];
                gain[c][b] = 0f;
                q[c][b] = 1.0f;
                presetFreq[c][b] = DEFAULT_FREQ[b];
                presetGain[c][b] = 0f;
                presetQ[c][b] = 1.0f;
            }
        }
        // A small visual curve on first launch so the graph is immediately readable.
        gain[0][1] = -2f;
        gain[0][2] = 1f;
        gain[0][3] = 4f;
        gain[0][4] = 1f;
        gain[0][5] = -1f;
        gain[0][8] = -2f;
        gain[0][9] = -1f;
        gain[0][10] = 2f;
        gain[0][11] = 4f;
        gain[0][12] = 3f;
        gain[0][13] = 0f;
        gain[0][14] = -2f;
    }

    void saveNow() {
        SharedPreferences.Editor e = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit();
        e.putBoolean("dark", darkTheme)
                .putInt("screen", screen)
                .putInt("channel", channel)
                .putInt("band", band)
                .putFloat("master", masterVolume)
                .putFloat("bass", bassVolume)
                .putFloat("cutoff", bassCutoff)
                .putBoolean("hasPreset", hasPreset);

        for (int c = 0; c < CHANNELS; c++) {
            e.putFloat("channelVolume_" + c, channelVolume[c]);
            for (int b = 0; b < BANDS; b++) {
                String k = c + "_" + b;
                e.putFloat("freq_" + k, freq[c][b]);
                e.putFloat("gain_" + k, gain[c][b]);
                e.putFloat("q_" + k, q[c][b]);
                e.putFloat("pfreq_" + k, presetFreq[c][b]);
                e.putFloat("pgain_" + k, presetGain[c][b]);
                e.putFloat("pq_" + k, presetQ[c][b]);
            }
        }
        // apply() updates the in-memory preference map synchronously and writes to disk asynchronously.
        // It is intentionally called on every UI value change for real-time persistence without UI blocking.
        e.apply();
    }

    private void load() {
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (!p.contains("master")) return;

        darkTheme = p.getBoolean("dark", false);
        screen = clampInt(p.getInt("screen", 0), 0, 2);
        channel = clampInt(p.getInt("channel", 0), 0, CHANNELS - 1);
        band = clampInt(p.getInt("band", 4), 0, BANDS - 1);
        masterVolume = clamp(p.getFloat("master", -6f), -70f, 6f);
        bassVolume = clamp(p.getFloat("bass", 2f), -70f, 6f);
        bassCutoff = clamp(p.getFloat("cutoff", 80f), 20f, 200f);
        hasPreset = p.getBoolean("hasPreset", false);

        for (int c = 0; c < CHANNELS; c++) {
            channelVolume[c] = clamp(p.getFloat("channelVolume_" + c, channelVolume[c]), -70f, 6f);
            for (int b = 0; b < BANDS; b++) {
                String k = c + "_" + b;
                freq[c][b] = clamp(p.getFloat("freq_" + k, freq[c][b]), 20f, 20000f);
                gain[c][b] = clamp(p.getFloat("gain_" + k, gain[c][b]), -12f, 12f);
                q[c][b] = clamp(p.getFloat("q_" + k, q[c][b]), 0.1f, 10f);
                presetFreq[c][b] = clamp(p.getFloat("pfreq_" + k, presetFreq[c][b]), 20f, 20000f);
                presetGain[c][b] = clamp(p.getFloat("pgain_" + k, presetGain[c][b]), -12f, 12f);
                presetQ[c][b] = clamp(p.getFloat("pq_" + k, presetQ[c][b]), 0.1f, 10f);
            }
        }
    }

    void resetGlobal() {
        masterVolume = -6f;
        bassVolume = 2f;
        bassCutoff = 80f;
        saveNow();
    }

    void resetChannels() {
        float[] defaults = {-3f, -6f, -2f, -8f, 0f, -4f, -10f};
        System.arraycopy(defaults, 0, channelVolume, 0, CHANNELS);
        saveNow();
    }

    void flattenCurrentEq() {
        for (int b = 0; b < BANDS; b++) gain[channel][b] = 0f;
        saveNow();
    }

    void resetCurrentEq() {
        for (int b = 0; b < BANDS; b++) {
            freq[channel][b] = DEFAULT_FREQ[b];
            gain[channel][b] = 0f;
            q[channel][b] = 1f;
        }
        band = 4;
        saveNow();
    }

    void savePreset() {
        for (int c = 0; c < CHANNELS; c++) {
            System.arraycopy(freq[c], 0, presetFreq[c], 0, BANDS);
            System.arraycopy(gain[c], 0, presetGain[c], 0, BANDS);
            System.arraycopy(q[c], 0, presetQ[c], 0, BANDS);
        }
        hasPreset = true;
        saveNow();
    }

    void loadPreset() {
        if (!hasPreset) return;
        for (int c = 0; c < CHANNELS; c++) {
            System.arraycopy(presetFreq[c], 0, freq[c], 0, BANDS);
            System.arraycopy(presetGain[c], 0, gain[c], 0, BANDS);
            System.arraycopy(presetQ[c], 0, q[c], 0, BANDS);
        }
        saveNow();
    }

    void deletePreset() {
        hasPreset = false;
        saveNow();
    }

    static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    static int clampInt(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }

    static String db(float v) {
        return String.format(Locale.US, "%.1f dB", v);
    }

    static String hz(float v) {
        if (v >= 1000f) {
            float k = v / 1000f;
            return k >= 10f ? String.format(Locale.US, "%.0f kHz", k) : String.format(Locale.US, "%.2g kHz", k);
        }
        return String.format(Locale.US, "%.0f Hz", v);
    }

    static String qValue(float v) {
        return String.format(Locale.US, "%.2f", v);
    }
}
