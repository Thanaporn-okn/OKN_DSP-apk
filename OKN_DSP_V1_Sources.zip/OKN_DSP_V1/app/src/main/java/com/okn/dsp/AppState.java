package com.okn.dsp;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Locale;

public final class AppState {
    public static final int CHANNELS = 7;
    public static final int BANDS = 15;
    public static final int THEME_LIGHT = 0;
    public static final int THEME_DARK = 1;
    public static final int THEME_OCEAN = 2;

    private static final float[] DEFAULT_FREQ = {
            20f, 31.5f, 50f, 80f, 125f, 200f, 315f, 500f,
            800f, 1250f, 2000f, 3150f, 5000f, 8000f, 12500f
    };
    private static final float[] DEFAULT_GAIN_CH1 = {
            -2f, -1f, 1.5f, 4f, 2f, 0.2f, -1.2f, -1.8f,
            0f, 2.2f, 3.2f, 2.8f, 1.2f, -0.6f, -1.7f
    };
    private static final float[] DEFAULT_CHANNEL_VOLUMES = {-3f, -6f, -2f, -8f, 0f, -4f, -10f};

    private final SharedPreferences prefs;

    public int theme;
    public int page;
    public float masterVolume;
    public float bassVolume;
    public float bassCutoff;
    public int selectedChannel;
    public int selectedBand;
    public String presetName;
    public String loadChoice;

    public final float[] channelVolume = new float[CHANNELS];
    public final float[][] eqFreq = new float[CHANNELS][BANDS];
    public final float[][] eqQ = new float[CHANNELS][BANDS];
    public final float[][] eqGain = new float[CHANNELS][BANDS];

    public AppState(Context context) {
        prefs = context.getSharedPreferences("okn_dsp_v1_state", Context.MODE_PRIVATE);
        load();
    }

    private void load() {
        theme = prefs.getInt("theme", THEME_LIGHT);
        page = clampInt(prefs.getInt("page", 0), 0, 2);
        masterVolume = prefs.getFloat("master", -6f);
        bassVolume = prefs.getFloat("bass", 2f);
        bassCutoff = prefs.getFloat("cutoff", 80f);
        selectedChannel = clampInt(prefs.getInt("eq_channel", 0), 0, CHANNELS - 1);
        selectedBand = clampInt(prefs.getInt("eq_band", 4), 0, BANDS - 1);
        presetName = prefs.getString("preset_name", "My EQ");
        loadChoice = prefs.getString("load_choice", "Flat");

        for (int ch = 0; ch < CHANNELS; ch++) {
            channelVolume[ch] = prefs.getFloat("chv_" + ch, DEFAULT_CHANNEL_VOLUMES[ch]);
            for (int b = 0; b < BANDS; b++) {
                eqFreq[ch][b] = prefs.getFloat(key("f", ch, b), DEFAULT_FREQ[b]);
                eqQ[ch][b] = prefs.getFloat(key("q", ch, b), 1.0f);
                float dg = ch == 0 ? DEFAULT_GAIN_CH1[b] : 0f;
                eqGain[ch][b] = prefs.getFloat(key("g", ch, b), dg);
            }
        }
    }

    public void setTheme(int value) {
        theme = clampInt(value, THEME_LIGHT, THEME_OCEAN);
        prefs.edit().putInt("theme", theme).apply();
    }

    public void setPage(int value) {
        page = clampInt(value, 0, 2);
        prefs.edit().putInt("page", page).apply();
    }

    public void setMaster(float value) {
        masterVolume = clamp(value, -60f, 12f);
        prefs.edit().putFloat("master", masterVolume).apply();
    }

    public void setBass(float value) {
        bassVolume = clamp(value, -12f, 12f);
        prefs.edit().putFloat("bass", bassVolume).apply();
    }

    public void setCutoff(float value) {
        bassCutoff = clamp(value, 40f, 200f);
        prefs.edit().putFloat("cutoff", bassCutoff).apply();
    }

    public void setChannelVolume(int ch, float value) {
        if (ch < 0 || ch >= CHANNELS) return;
        channelVolume[ch] = clamp(value, -60f, 12f);
        prefs.edit().putFloat("chv_" + ch, channelVolume[ch]).apply();
    }

    public void setSelectedChannel(int ch) {
        selectedChannel = clampInt(ch, 0, CHANNELS - 1);
        prefs.edit().putInt("eq_channel", selectedChannel).apply();
    }

    public void setSelectedBand(int band) {
        selectedBand = clampInt(band, 0, BANDS - 1);
        prefs.edit().putInt("eq_band", selectedBand).apply();
    }

    public void setBandFrequency(int ch, int band, float hz) {
        if (!valid(ch, band)) return;
        eqFreq[ch][band] = clamp(hz, 20f, 20000f);
        prefs.edit().putFloat(key("f", ch, band), eqFreq[ch][band]).apply();
    }

    public void setBandQ(int ch, int band, float q) {
        if (!valid(ch, band)) return;
        eqQ[ch][band] = clamp(q, 0.1f, 10f);
        prefs.edit().putFloat(key("q", ch, band), eqQ[ch][band]).apply();
    }

    public void setBandGain(int ch, int band, float gain) {
        if (!valid(ch, band)) return;
        eqGain[ch][band] = clamp(gain, -12f, 12f);
        prefs.edit().putFloat(key("g", ch, band), eqGain[ch][band]).apply();
    }

    public void setPresetName(String name) {
        presetName = (name == null || name.trim().isEmpty()) ? "My EQ" : name.trim();
        prefs.edit().putString("preset_name", presetName).apply();
    }

    public void setLoadChoice(String choice) {
        loadChoice = choice == null ? "Flat" : choice;
        prefs.edit().putString("load_choice", loadChoice).apply();
    }

    public void resetEq(int ch) {
        if (ch < 0 || ch >= CHANNELS) return;
        SharedPreferences.Editor e = prefs.edit();
        for (int b = 0; b < BANDS; b++) {
            eqFreq[ch][b] = DEFAULT_FREQ[b];
            eqQ[ch][b] = 1f;
            eqGain[ch][b] = 0f;
            e.putFloat(key("f", ch, b), eqFreq[ch][b]);
            e.putFloat(key("q", ch, b), eqQ[ch][b]);
            e.putFloat(key("g", ch, b), eqGain[ch][b]);
        }
        e.apply();
    }

    public void savePreset(String name) {
        setPresetName(name);
        SharedPreferences.Editor e = prefs.edit();
        e.putBoolean("preset_saved", true);
        e.putString("saved_name", presetName);
        e.putFloat("p_master", masterVolume);
        e.putFloat("p_bass", bassVolume);
        e.putFloat("p_cutoff", bassCutoff);
        for (int ch = 0; ch < CHANNELS; ch++) {
            e.putFloat("p_chv_" + ch, channelVolume[ch]);
            for (int b = 0; b < BANDS; b++) {
                e.putFloat(key("pf", ch, b), eqFreq[ch][b]);
                e.putFloat(key("pq", ch, b), eqQ[ch][b]);
                e.putFloat(key("pg", ch, b), eqGain[ch][b]);
            }
        }
        e.apply();
        setLoadChoice(presetName);
    }

    public boolean hasPreset() {
        return prefs.getBoolean("preset_saved", false);
    }

    public String savedPresetName() {
        return prefs.getString("saved_name", presetName);
    }

    public void loadPreset() {
        if ("Flat".equals(loadChoice)) {
            SharedPreferences.Editor e = prefs.edit();
            masterVolume = -6f;
            bassVolume = 0f;
            bassCutoff = 80f;
            e.putFloat("master", masterVolume).putFloat("bass", bassVolume).putFloat("cutoff", bassCutoff);
            for (int ch = 0; ch < CHANNELS; ch++) {
                channelVolume[ch] = 0f;
                e.putFloat("chv_" + ch, 0f);
                for (int b = 0; b < BANDS; b++) {
                    eqFreq[ch][b] = DEFAULT_FREQ[b];
                    eqQ[ch][b] = 1f;
                    eqGain[ch][b] = 0f;
                    e.putFloat(key("f", ch, b), eqFreq[ch][b]);
                    e.putFloat(key("q", ch, b), 1f);
                    e.putFloat(key("g", ch, b), 0f);
                }
            }
            e.apply();
            return;
        }
        if (!hasPreset()) return;
        masterVolume = prefs.getFloat("p_master", masterVolume);
        bassVolume = prefs.getFloat("p_bass", bassVolume);
        bassCutoff = prefs.getFloat("p_cutoff", bassCutoff);
        SharedPreferences.Editor e = prefs.edit();
        e.putFloat("master", masterVolume).putFloat("bass", bassVolume).putFloat("cutoff", bassCutoff);
        for (int ch = 0; ch < CHANNELS; ch++) {
            channelVolume[ch] = prefs.getFloat("p_chv_" + ch, channelVolume[ch]);
            e.putFloat("chv_" + ch, channelVolume[ch]);
            for (int b = 0; b < BANDS; b++) {
                eqFreq[ch][b] = prefs.getFloat(key("pf", ch, b), eqFreq[ch][b]);
                eqQ[ch][b] = prefs.getFloat(key("pq", ch, b), eqQ[ch][b]);
                eqGain[ch][b] = prefs.getFloat(key("pg", ch, b), eqGain[ch][b]);
                e.putFloat(key("f", ch, b), eqFreq[ch][b]);
                e.putFloat(key("q", ch, b), eqQ[ch][b]);
                e.putFloat(key("g", ch, b), eqGain[ch][b]);
            }
        }
        e.apply();
    }

    public String formatDb(float value) {
        if (Math.abs(value) < 0.05f) return "0 dB";
        return String.format(Locale.US, "%+.1f dB", value).replace("+", "+");
    }

    private static String key(String prefix, int ch, int band) {
        return prefix + "_" + ch + "_" + band;
    }

    private static boolean valid(int ch, int band) {
        return ch >= 0 && ch < CHANNELS && band >= 0 && band < BANDS;
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private static int clampInt(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }
}
