package com.okn.dsp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import java.util.Locale;

/**
 * OKN_DSP V1 custom UI rebuilt from the uploaded 1024x1536 Parametric-EQ artwork.
 * The visual surface exposes the complete design language, while hardware writes remain
 * constrained to capabilities supported by the supplied protocol baseline.
 */
final class DspView extends View {
    private static final float W = 1024f;
    private static final float H = 1536f;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final DspState state = new DspState();

    private BleManager ble;
    private float scale = 1f;
    private float viewportH = H;
    private int bandPage = 0; // 0=1..7, 1=8..14, 2=15..20
    private boolean spectrumOn = true;
    private boolean zoomed = false;
    private boolean draggingGraph = false;
    private boolean draggingMaster = false;

    private String bleStatus = "กำลังค้นหา...";
    private String bleDevice = "OKN-DSP_7CH";
    private boolean bleConnected = false;
    private String diagnostic = "V1";

    private final int BG = Color.rgb(0, 10, 22);
    private final int PANEL = Color.rgb(2, 25, 45);
    private final int PANEL2 = Color.rgb(2, 18, 34);
    private final int BORDER = Color.rgb(12, 70, 116);
    private final int BORDER_BRIGHT = Color.rgb(0, 148, 255);
    private final int WHITE = Color.rgb(241, 247, 255);
    private final int SUB = Color.rgb(171, 196, 225);
    private final int CYAN = Color.rgb(0, 220, 255);
    private final int BLUE = Color.rgb(0, 137, 255);
    private final int GREEN = Color.rgb(0, 238, 102);
    private final int MUTED = Color.rgb(78, 104, 134);

    private final int[] COLORS = {
            Color.rgb(255, 57, 75), Color.rgb(255, 145, 0), Color.rgb(255, 226, 0),
            Color.rgb(0, 236, 82), Color.rgb(0, 218, 235), Color.rgb(0, 124, 255),
            Color.rgb(187, 36, 242)
    };

    DspView(Context context, BleManager ble) {
        super(context);
        this.ble = ble;
        stroke.setStyle(Paint.Style.STROKE);
        text.setTypeface(android.graphics.Typeface.create("sans", android.graphics.Typeface.NORMAL));
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        setFocusable(true);
        setClickable(true);
    }

    void setBleManager(BleManager ble) {
        this.ble = ble;
    }

    void setBleStatus(String status, String deviceName, boolean connected) {
        bleStatus = status == null ? "" : status;
        if (deviceName != null && !deviceName.isEmpty()) bleDevice = deviceName;
        bleConnected = connected;
        invalidate();
    }

    void setDiagnostic(String message) {
        diagnostic = message == null ? "" : message;
        invalidate();
    }

    void setScalarFromDsp(int actuatorId, float value) {
        if (actuatorId == DspProtocol.ID_MASTER_VOLUME) {
            state.masterVolume = value;
            invalidate();
        }
    }

    void setEqFromDsp(int channel0, int uiBand0, float frequency, float gainDb, float q,
                      int filterType, boolean writable) {
        if (channel0 < 0 || channel0 >= DspState.CHANNELS || uiBand0 < 0 || uiBand0 >= DspState.BANDS) return;
        state.freq[channel0][uiBand0] = frequency;
        state.gain[channel0][uiBand0] = gainDb;
        state.q[channel0][uiBand0] = q;
        state.type[channel0][uiBand0] = filterType;
        state.eqWritable[channel0][uiBand0] = writable;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        scale = getWidth() / W;
        viewportH = Math.max(H, getHeight() / scale);
        c.drawColor(BG);
        c.save();
        c.scale(scale, scale);
        drawBackground(c);
        drawHeader(c);
        drawTopNav(c);
        drawEqCard(c);
        drawBandTabs(c);
        drawBandTable(c);
        drawBottomControls(c);
        drawFooter(c);
        c.restore();
    }

    private float extraH() { return Math.max(0f, viewportH - H); }
    private float eqBottom() { return 670f + extraH() * 0.22f; }
    private float tabsY() { return eqBottom() + 12f; }
    private float tableY() { return tabsY() + 66f; }
    private float tableBottom() { return 1288f + extraH() * 0.72f; }
    private float bottomY() { return tableBottom() + 12f; }
    private float footerY() { return viewportH - 102f; }

    private void drawBackground(Canvas c) {
        fill.setShader(new LinearGradient(0, 0, W, viewportH,
                Color.rgb(2, 23, 42), Color.rgb(0, 6, 15), Shader.TileMode.CLAMP));
        c.drawRect(0, 0, W, viewportH, fill);
        fill.setShader(null);
        fill.setColor(Color.argb(18, 0, 170, 255));
        c.drawCircle(850, 360, 300, fill);
        fill.setColor(Color.argb(12, 0, 210, 255));
        c.drawCircle(175, 560, 240, fill);
    }

    private void drawHeader(Canvas c) {
        drawHamburger(c, 48, 50);
        drawEqLogo(c, 122, 53, 36, CYAN);
        label(c, "OKN_DSP", 204, 56, 42, WHITE, true, Paint.Align.LEFT);
        label(c, "PROFESSIONAL AUDIO CONTROL", 205, 82, 14, SUB, false, Paint.Align.LEFT);

        roundRect(c, 596, 18, 918, 86, 13, PANEL2, BORDER);
        fill.setColor(bleConnected ? GREEN : Color.rgb(255, 184, 0));
        c.drawCircle(626, 50, 10, fill);
        label(c, bleConnected ? "Connected" : compactStatus(), 653, 45, 18, WHITE, false, Paint.Align.LEFT);
        label(c, bleDevice, 653, 70, 18, SUB, false, Paint.Align.LEFT);
        chevronDown(c, 886, 49, WHITE);
        drawGear(c, 976, 51, WHITE);
    }

    private String compactStatus() {
        if (bleStatus == null || bleStatus.isEmpty()) return "Bluetooth";
        if (bleStatus.length() <= 19) return bleStatus;
        return bleStatus.substring(0, 18) + "…";
    }

    private void drawTopNav(Canvas c) {
        float y1 = 102, y2 = 217;
        roundRect(c, 19, y1, 1007, y2, 16, PANEL2, BORDER);
        String[] titles = {"EQ", "ช่องสัญญาณ", "Crossover", "Delay", "Output", "Preset"};
        float[] widths = {161, 167, 170, 166, 163, 160};
        float x = 19;
        for (int i = 0; i < titles.length; i++) {
            float w = widths[i];
            if (i == 0) {
                fill.setShader(new LinearGradient(x, y1, x + w, y2,
                        Color.rgb(0, 111, 255), Color.rgb(0, 210, 255), Shader.TileMode.CLAMP));
                roundRectShader(c, x + 1, y1 + 1, x + w - 1, y2 - 1, 15);
                fill.setShader(null);
            } else if (i > 0) {
                stroke.setColor(Color.rgb(16, 60, 93));
                stroke.setStrokeWidth(1.2f);
                c.drawLine(x, y1 + 18, x, y2 - 18, stroke);
            }
            float cx = x + w / 2f;
            drawNavIcon(c, i, cx, y1 + 42, i == 0 ? WHITE : Color.rgb(185, 209, 235));
            label(c, titles[i], cx, y1 + 92, i == 0 ? 18 : 17, WHITE, false, Paint.Align.CENTER);
            x += w;
        }
    }

    private void drawEqCard(Canvas c) {
        float bottom = eqBottom();
        roundRect(c, 18, 231, 1007, bottom, 16, PANEL, BORDER);
        drawEqLogo(c, 68, 280, 37, CYAN);
        label(c, "Parametric EQ", 135, 279, 38, WHITE, true, Paint.Align.LEFT);
        label(c, "ปรับแต่งความถี่เสียงอย่างละเอียด", 136, 310, 20, SUB, false, Paint.Align.LEFT);

        roundRect(c, 563, 245, 787, 316, 12, PANEL2, BORDER_BRIGHT);
        label(c, "ช่องสัญญาณ", 587, 273, 16, WHITE, false, Paint.Align.LEFT);
        label(c, DspState.CHANNEL_LONG[state.channel], 587, 300, 19, WHITE, false, Paint.Align.LEFT);
        chevronDown(c, 756, 283, WHITE);

        roundRect(c, 802, 245, 992, 316, 12, PANEL2, BORDER_BRIGHT);
        drawReset(c, 845, 281, WHITE);
        label(c, "รีเซ็ต EQ", 892, 289, 19, WHITE, false, Paint.Align.LEFT);

        drawGraph(c, 82, 338, 989, bottom - 42f);
    }

    private void drawGraph(Canvas c, float l, float t, float r, float b) {
        roundRect(c, l, t, r, b, 2, Color.rgb(1, 21, 38), BORDER);
        float minDb = zoomed ? -6f : -12f;
        float maxDb = zoomed ? 6f : 12f;

        stroke.setStrokeWidth(1f);
        for (int i = 0; i <= 12; i++) {
            float x = l + (r - l) * i / 12f;
            stroke.setColor(Color.argb(i % 2 == 0 ? 50 : 25, 45, 120, 180));
            c.drawLine(x, t, x, b, stroke);
        }
        for (int i = 0; i <= 6; i++) {
            float y = t + (b - t) * i / 6f;
            stroke.setColor(Color.argb(i == 3 ? 72 : 35, 46, 120, 180));
            c.drawLine(l, y, r, y, stroke);
        }

        label(c, "dB", 39, t + 18, 19, SUB, false, Paint.Align.LEFT);
        int[] dbLabels = zoomed ? new int[]{6, 3, 0, -3, -6} : new int[]{12, 6, 0, -6, -12};
        for (int value : dbLabels) {
            float y = gainToY(value, t, b, minDb, maxDb);
            label(c, value > 0 ? "+" + value : String.valueOf(value), 65, y + 6, 17, WHITE, false, Paint.Align.RIGHT);
        }

        float[] ticks = {20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000};
        String[] tickNames = {"20", "50", "100", "200", "500", "1k", "2k", "5k", "10k", "20k"};
        for (int i = 0; i < ticks.length; i++) {
            float x = freqToX(ticks[i], l, r);
            stroke.setColor(Color.rgb(125, 170, 205));
            stroke.setStrokeWidth(1.2f);
            c.drawLine(x, b, x, b + 8, stroke);
            label(c, tickNames[i], x, b + 30, 16, WHITE, false, Paint.Align.CENTER);
        }
        label(c, "Hz", r - 2, b + 30, 16, SUB, false, Paint.Align.RIGHT);

        // Decorative spectrum trace follows the reference artwork but carries no hardware meaning.
        if (spectrumOn) {
            path.reset();
            float mid = (t + b) * 0.5f;
            for (int i = 0; i < 100; i++) {
                float x = l + (r - l) * i / 99f;
                float envelope = (float) (9.0 * Math.sin(i * 0.23) + 5.0 * Math.sin(i * 0.61));
                float y = mid - envelope;
                if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
            }
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(1.4f);
            stroke.setColor(Color.argb(35, 0, 212, 255));
            c.drawPath(path, stroke);
        }

        // EQ curve across all 15 hardware records.
        float prevX = 0, prevY = 0;
        for (int band = 0; band < DspState.BANDS; band++) {
            float x = freqToX(state.freq[state.channel][band], l, r);
            float y = gainToY(state.gain[state.channel][band], t, b, minDb, maxDb);
            if (band > 0) {
                stroke.setStrokeWidth(4.2f);
                stroke.setColor(COLORS[(band - 1) % COLORS.length]);
                c.drawLine(prevX, prevY, x, y, stroke);
            }
            prevX = x;
            prevY = y;
        }

        int start = bandPage == 0 ? 0 : bandPage == 1 ? 7 : 14;
        int end = Math.min(DspState.BANDS, start + (bandPage < 2 ? 7 : 1));
        for (int band = start; band < end; band++) {
            float x = freqToX(state.freq[state.channel][band], l, r);
            float y = gainToY(state.gain[state.channel][band], t, b, minDb, maxDb);
            int col = COLORS[(band - start) % COLORS.length];
            if (band == state.selectedBand) {
                fill.setColor(Color.argb(42, Color.red(col), Color.green(col), Color.blue(col)));
                c.drawCircle(x, y, 29, fill);
            }
            fill.setColor(col);
            c.drawCircle(x, y, 15, fill);
            fill.setColor(WHITE);
            c.drawCircle(x, y, 11, fill);
            label(c, String.valueOf(band + 1), x, y + 5, 13, col, true, Paint.Align.CENTER);
        }

        roundRect(c, r - 110, t + 12, r - 9, t + 61, 10, PANEL2, BORDER_BRIGHT);
        drawMagnifier(c, r - 84, t + 35, WHITE);
        label(c, zoomed ? "ปกติ" : "ขยาย", r - 52, t + 42, 16, WHITE, false, Paint.Align.LEFT);
    }

    private void drawBandTabs(Canvas c) {
        float y = tabsY();
        float gap = 10f;
        float w = 230f;
        for (int i = 0; i < 3; i++) {
            float l = 20 + i * (w + gap);
            int border = i == bandPage ? CYAN : BORDER;
            if (i == bandPage) {
                fill.setShader(new LinearGradient(l, y, l + w, y + 54,
                        Color.rgb(0, 118, 255), Color.rgb(0, 211, 255), Shader.TileMode.CLAMP));
                roundRectShader(c, l, y, l + w, y + 54, 12);
                fill.setShader(null);
            } else roundRect(c, l, y, l + w, y + 54, 12, PANEL2, border);
            String txt = i == 0 ? "Bands 1 - 7" : i == 1 ? "Bands 8 - 14" : "Bands 15 - 20";
            label(c, txt, l + w / 2, y + 34, 18, WHITE, false, Paint.Align.CENTER);
        }

        float sl = 744, sr = 1006;
        roundRect(c, sl, y, sr, y + 54, 12, PANEL2, BORDER);
        drawSpectrumIcon(c, 777, y + 27, CYAN);
        label(c, "แสดงสเปกตรัม", 812, y + 34, 16, WHITE, false, Paint.Align.LEFT);
        drawSwitch(c, 936, y + 12, spectrumOn, true);
    }

    private void drawBandTable(Canvas c) {
        float top = tableY();
        float bottom = tableBottom();
        roundRect(c, 18, top, 1007, bottom, 16, PANEL, BORDER);

        float headerH = 65f;
        label(c, "#", 48, top + 40, 17, WHITE, true, Paint.Align.CENTER);
        label(c, "ประเภทฟิลเตอร์", 147, top + 27, 16, WHITE, true, Paint.Align.LEFT);
        label(c, "Filter Type", 147, top + 49, 13, SUB, false, Paint.Align.LEFT);
        label(c, "ความถี่", 369, top + 27, 16, WHITE, true, Paint.Align.CENTER);
        label(c, "Frequency", 369, top + 49, 13, SUB, false, Paint.Align.CENTER);
        label(c, "เกน", 574, top + 27, 16, WHITE, true, Paint.Align.CENTER);
        label(c, "Gain", 574, top + 49, 13, SUB, false, Paint.Align.CENTER);
        label(c, "ค่า Q", 755, top + 27, 16, WHITE, true, Paint.Align.CENTER);
        label(c, "Q Factor", 755, top + 49, 13, SUB, false, Paint.Align.CENTER);
        label(c, "ใช้งาน", 898, top + 27, 16, WHITE, true, Paint.Align.CENTER);
        label(c, "Active", 898, top + 49, 13, SUB, false, Paint.Align.CENTER);

        int visible = bandPage < 2 ? 7 : 6;
        float actionH = 72f;
        float rowsBottom = bottom - actionH;
        float rowH = (rowsBottom - (top + headerH)) / visible;
        for (int i = 0; i < visible; i++) {
            int logicalBand = bandPage == 0 ? i : bandPage == 1 ? i + 7 : i + 14;
            float y = top + headerH + i * rowH;
            drawBandRow(c, logicalBand, i, y, rowH);
        }
        drawActions(c, bottom - actionH + 4, bottom - 9);
    }

    private void drawBandRow(Canvas c, int logicalBand, int rowIndex, float y, float h) {
        stroke.setColor(Color.rgb(10, 50, 80));
        stroke.setStrokeWidth(1f);
        c.drawLine(30, y, 993, y, stroke);

        boolean virtual = logicalBand >= DspState.BANDS;
        boolean selected = !virtual && logicalBand == state.selectedBand;
        int col = COLORS[rowIndex % COLORS.length];
        fill.setColor(virtual ? MUTED : col);
        c.drawCircle(48, y + h / 2, 10, fill);
        label(c, String.valueOf(logicalBand + 1), 79, y + h / 2 + 6, 17, virtual ? SUB : WHITE, false, Paint.Align.CENTER);

        int fg = virtual ? MUTED : WHITE;
        float cy = y + h / 2;
        roundRect(c, 104, y + 7, 279, y + h - 7, 9, PANEL2, selected ? BORDER_BRIGHT : BORDER);
        if (!virtual) drawFilterGlyph(c, 125, cy, state.type[state.channel][logicalBand], fg);
        label(c, virtual ? "Locked" : filterName(state.type[state.channel][logicalBand]), 163, cy + 6, 15, fg, false, Paint.Align.LEFT);
        chevronDown(c, 258, cy, fg);

        valueBox(c, 296, y + 7, 462, y + h - 7,
                virtual ? "--" : DspState.hzLong(state.freq[state.channel][logicalBand]), fg, false);
        valueBox(c, 476, y + 7, 652, y + h - 7,
                virtual ? "--" : DspState.db(state.gain[state.channel][logicalBand]), fg, !virtual);
        valueBox(c, 665, y + 7, 826, y + h - 7,
                virtual ? "--" : DspState.q(state.q[state.channel][logicalBand]), fg, false);

        boolean writable = !virtual && state.eqWritable[state.channel][logicalBand];
        drawSwitch(c, 855, cy - 18, writable, !virtual);
        if (virtual) label(c, "LOCK", 946, cy + 5, 10, MUTED, true, Paint.Align.CENTER);
        else {
            fill.setColor(selected ? WHITE : SUB);
            for (int k = -1; k <= 1; k++) c.drawCircle(972, cy + k * 7, 1.8f, fill);
        }
    }

    private String filterName(int type) {
        if (type == DspProtocol.EQ_PEAKING_TYPE) return "PEQ";
        if (type == DspProtocol.EQ_TONE_CONTROL_TYPE) return "Tone";
        if (type == DspProtocol.EQ_GENERAL_LOWPASS_TYPE) return "Low Pass";
        return "Native " + type;
    }

    private void drawActions(Canvas c, float t, float b) {
        String[] labels = {"เพิ่มแบนด์", "คัดลอก", "วาง", "ล้างทั้งหมด", "Flat", "นำเข้า / ส่งออก"};
        float[] ws = {160, 126, 112, 160, 148, 181};
        float x = 32;
        for (int i = 0; i < labels.length; i++) {
            roundRect(c, x, t, x + ws[i], b, 9, PANEL2, BORDER_BRIGHT);
            label(c, labels[i], x + ws[i] / 2, (t + b) / 2 + 6, 14, WHITE, false, Paint.Align.CENTER);
            x += ws[i] + 10;
        }
    }

    private void drawBottomControls(Canvas c) {
        float y = bottomY();
        float h = Math.min(136f, footerY() - y - 8f);
        if (h < 92f) h = 92f;
        roundRect(c, 18, y, 578, y + h, 16, PANEL, BORDER);
        drawSpeaker(c, 63, y + 48, WHITE);
        label(c, "มาสเตอร์วอลลุ่ม", 104, y + 38, 17, WHITE, true, Paint.Align.LEFT);

        float sx1 = 104, sx2 = 321, sy = y + 67;
        stroke.setStrokeWidth(10);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setColor(Color.rgb(20, 76, 113));
        c.drawLine(sx1, sy, sx2, sy, stroke);
        float norm = clamp((state.masterVolume + 70f) / 76f, 0f, 1f);
        stroke.setColor(Color.rgb(0, 166, 255));
        c.drawLine(sx1, sy, sx1 + (sx2 - sx1) * norm, sy, stroke);
        fill.setColor(WHITE);
        c.drawCircle(sx1 + (sx2 - sx1) * norm, sy, 12, fill);
        stroke.setStrokeCap(Paint.Cap.BUTT);
        label(c, "-70 dB", sx1 - 4, y + 102, 13, SUB, false, Paint.Align.LEFT);
        label(c, "0", sx1 + (sx2 - sx1) * (70f / 76f), y + 102, 13, WHITE, false, Paint.Align.CENTER);
        label(c, "+6 dB", sx2 + 6, y + 102, 13, SUB, false, Paint.Align.RIGHT);

        roundRect(c, 344, y + 34, 455, y + 96, 10, PANEL2, BORDER);
        label(c, DspState.db(state.masterVolume), 399, y + 72, 17, WHITE, false, Paint.Align.CENTER);
        roundRect(c, 474, y + 25, 559, y + 106, 10, PANEL2, BORDER);
        drawMutedSpeaker(c, 517, y + 55, WHITE);
        label(c, "ปิดเสียง", 517, y + 94, 12, SUB, false, Paint.Align.CENTER);

        roundRect(c, 590, y, 1007, y + h, 16, PANEL, BORDER);
        label(c, "Preset", 610, y + 34, 17, WHITE, true, Paint.Align.LEFT);
        roundRect(c, 610, y + 50, 814, y + 100, 9, PANEL2, BORDER);
        label(c, "Default", 632, y + 81, 16, WHITE, false, Paint.Align.LEFT);
        chevronDown(c, 790, y + 75, WHITE);
        roundRect(c, 833, y + 24, 911, y + 106, 10, PANEL2, BORDER);
        drawSave(c, 872, y + 52, WHITE);
        label(c, "บันทึก", 872, y + 92, 12, WHITE, false, Paint.Align.CENTER);
        roundRect(c, 924, y + 24, 992, y + 106, 10, PANEL2, BORDER);
        label(c, "⋮", 958, y + 59, 34, WHITE, false, Paint.Align.CENTER);
        label(c, "เพิ่มเติม", 958, y + 92, 11, WHITE, false, Paint.Align.CENTER);
    }

    private void drawFooter(Canvas c) {
        float y = footerY();
        label(c, "OKN_DSP", 25, y + 39, 37, Color.rgb(184, 219, 248), true, Paint.Align.LEFT);
        label(c, "SOUND YOUR WAY", 28, y + 64, 12, Color.rgb(79, 111, 145), false, Paint.Align.LEFT);
        drawEqLogo(c, 746, y + 38, 24, CYAN);
        label(c, "พลังเสียงในแบบของคุณ", 786, y + 46, 16, SUB, false, Paint.Align.LEFT);
        if (!diagnostic.isEmpty()) label(c, diagnostic, 998, y + 76, 10, Color.rgb(67, 100, 128), false, Paint.Align.RIGHT);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX() / scale;
        float y = e.getY() / scale;
        int action = e.getActionMasked();

        if (action == MotionEvent.ACTION_DOWN) {
            if (hit(x, y, 596, 18, 918, 86)) {
                if (ble != null) ble.startScan();
                toast("ค้นหา DSP ใหม่");
                return true;
            }
            if (hit(x, y, 563, 245, 787, 316)) {
                state.channel = (state.channel + 1) % DspState.CHANNELS;
                ensureSelectedBandInPage();
                invalidate();
                return true;
            }
            if (hit(x, y, 802, 245, 992, 316)) {
                state.flattenEq(state.channel);
                sendVisibleHardwareGains();
                invalidate();
                toast("รีเซ็ต Gain ช่องนี้เป็น Flat");
                return true;
            }
            float gy1 = 338, gy2 = eqBottom() - 42f;
            if (hit(x, y, 879, gy1 + 12, 980, gy1 + 61)) {
                zoomed = !zoomed;
                invalidate();
                return true;
            }
            if (hit(x, y, 82, gy1, 989, gy2)) {
                int nearest = nearestHardwareBand(x, y, 82, gy1, 989, gy2);
                if (nearest >= 0) {
                    state.selectedBand = nearest;
                    bandPage = nearest < 7 ? 0 : nearest < 14 ? 1 : 2;
                    draggingGraph = state.eqWritable[state.channel][nearest];
                    if (!draggingGraph) toast("แบนด์นี้ยังไม่พร้อมเขียน Hardware");
                    invalidate();
                }
                return true;
            }
            float ty = tabsY();
            for (int i = 0; i < 3; i++) {
                float l = 20 + i * 240f;
                if (hit(x, y, l, ty, l + 230, ty + 54)) {
                    bandPage = i;
                    ensureSelectedBandInPage();
                    invalidate();
                    return true;
                }
            }
            if (hit(x, y, 744, ty, 1006, ty + 54)) {
                spectrumOn = !spectrumOn;
                invalidate();
                return true;
            }
            if (handleTableDown(x, y)) return true;

            float by = bottomY();
            if (hit(x, y, 95, by + 46, 330, by + 88)) {
                draggingMaster = true;
                updateMasterFromX(x, 104, 321);
                return true;
            }
            if (hit(x, y, 833, by + 24, 911, by + 106)) {
                state.saveEq(getContext());
                toast("บันทึก Preset ในเครื่องแล้ว");
                return true;
            }
            if (hit(x, y, 610, by + 50, 814, by + 100)) {
                boolean ok = state.loadEq(getContext());
                if (ok) {
                    sendVisibleHardwareGains();
                    if (ble != null) ble.setScalarRealtime(DspProtocol.ID_MASTER_VOLUME, state.masterVolume);
                    invalidate();
                }
                toast(ok ? "โหลด Preset แล้ว" : "ยังไม่มี Preset ที่บันทึก");
                return true;
            }
            if (hit(x, y, 474, by + 25, 559, by + 106)) {
                if (ble != null) ble.reportUnverifiedControl("Master mute");
                toast("Mute ยังล็อก: ไม่มี packet ที่ยืนยันในข้อมูลที่อัปโหลด");
                return true;
            }

            if (y >= 102 && y <= 217 && x > 180) {
                toast("หน้านี้ยังล็อกจนกว่าจะมี packet ที่ยืนยัน");
                return true;
            }
        } else if (action == MotionEvent.ACTION_MOVE) {
            if (draggingGraph) {
                updateSelectedGainFromGraphY(y, 338, eqBottom() - 42f);
                return true;
            }
            if (draggingMaster) {
                updateMasterFromX(x, 104, 321);
                return true;
            }
        } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            draggingGraph = false;
            draggingMaster = false;
            return true;
        }
        return true;
    }

    private boolean handleTableDown(float x, float y) {
        float top = tableY();
        float bottom = tableBottom();
        if (!hit(x, y, 18, top, 1007, bottom)) return false;
        float headerH = 65f;
        float actionH = 72f;
        float actionTop = bottom - actionH + 4;

        if (y >= actionTop) {
            if (x >= 32 && x <= 192) {
                toast("Hardware มี 15 แบนด์ตามข้อมูลจริง จึงยังเพิ่มแบนด์ไม่ได้");
            } else if (x >= 202 && x <= 328) {
                state.saveEq(getContext());
                toast("คัดลอกค่า EQ ไปยัง Preset ภายในแอปแล้ว");
            } else if (x >= 338 && x <= 450) {
                boolean ok = state.loadEq(getContext());
                if (ok) sendVisibleHardwareGains();
                toast(ok ? "วางค่า EQ แล้ว" : "ยังไม่มีค่าที่คัดลอก");
            } else if (x >= 460 && x <= 620) {
                state.flattenEq(state.channel);
                sendVisibleHardwareGains();
                toast("ล้าง Gain ช่องนี้แล้ว");
            } else if (x >= 630 && x <= 778) {
                state.flattenEq(state.channel);
                sendVisibleHardwareGains();
                toast("Flat");
            } else {
                toast("Import / Export จะเปิดใช้เมื่อกำหนดรูปแบบไฟล์แล้ว");
            }
            invalidate();
            return true;
        }

        int visible = bandPage < 2 ? 7 : 6;
        float rowsBottom = bottom - actionH;
        float rowH = (rowsBottom - (top + headerH)) / visible;
        if (y < top + headerH || y > rowsBottom) return true;
        int row = Math.max(0, Math.min(visible - 1, (int) ((y - (top + headerH)) / rowH)));
        int logicalBand = bandPage == 0 ? row : bandPage == 1 ? row + 7 : row + 14;
        if (logicalBand >= DspState.BANDS) {
            toast("Band " + (logicalBand + 1) + " ยังไม่มี hardware record ในข้อมูลที่อัปโหลด");
            return true;
        }
        state.selectedBand = logicalBand;
        if (x >= 476 && x <= 652) {
            float cy = top + headerH + row * rowH + rowH / 2;
            float delta = x < 520 ? -0.5f : x > 608 ? 0.5f : (y < cy ? 0.5f : -0.5f);
            setGain(logicalBand, state.gain[state.channel][logicalBand] + delta);
        } else if (x >= 296 && x <= 462) {
            locked("Frequency");
        } else if (x >= 665 && x <= 826) {
            locked("Q Factor");
        } else if (x >= 104 && x <= 279) {
            locked("Filter Type");
        } else if (x >= 840 && x <= 943) {
            locked("Active / Bypass");
        }
        invalidate();
        return true;
    }

    private void locked(String name) {
        if (ble != null) ble.reportUnverifiedControl(name);
        toast(name + " ยังล็อก เพราะข้อมูลที่อัปโหลดยังไม่มี writer ที่ยืนยัน");
    }

    private void setGain(int band, float value) {
        if (band < 0 || band >= DspState.BANDS) return;
        if (!state.eqWritable[state.channel][band]) {
            toast("Band " + (band + 1) + " ยังไม่พร้อมเขียน Hardware");
            return;
        }
        state.gain[state.channel][band] = Math.round(clamp(value, -12f, 12f) * 10f) / 10f;
        if (ble != null) ble.setEqRealtime(state.channel, band,
                state.freq[state.channel][band], state.gain[state.channel][band], state.q[state.channel][band]);
        invalidate();
    }

    private void updateSelectedGainFromGraphY(float y, float t, float b) {
        int band = state.selectedBand;
        if (band < 0 || band >= DspState.BANDS) return;
        float minDb = zoomed ? -6f : -12f;
        float maxDb = zoomed ? 6f : 12f;
        float norm = 1f - clamp((y - t) / (b - t), 0f, 1f);
        setGain(band, minDb + norm * (maxDb - minDb));
    }

    private void updateMasterFromX(float x, float l, float r) {
        float norm = clamp((x - l) / (r - l), 0f, 1f);
        state.masterVolume = Math.round((-70f + norm * 76f) * 10f) / 10f;
        if (ble != null) ble.setScalarRealtime(DspProtocol.ID_MASTER_VOLUME, state.masterVolume);
        invalidate();
    }

    private void sendVisibleHardwareGains() {
        if (ble == null) return;
        for (int b = 0; b < DspState.BANDS; b++) {
            if (state.eqWritable[state.channel][b]) {
                ble.setEqRealtime(state.channel, b, state.freq[state.channel][b],
                        state.gain[state.channel][b], state.q[state.channel][b]);
            }
        }
    }

    private int nearestHardwareBand(float x, float y, float l, float t, float r, float b) {
        float minDb = zoomed ? -6f : -12f;
        float maxDb = zoomed ? 6f : 12f;
        int best = -1;
        float bestD = 55f * 55f;
        for (int i = 0; i < DspState.BANDS; i++) {
            float px = freqToX(state.freq[state.channel][i], l, r);
            float py = gainToY(state.gain[state.channel][i], t, b, minDb, maxDb);
            float dx = x - px, dy = y - py;
            float d = dx * dx + dy * dy;
            if (d < bestD) { bestD = d; best = i; }
        }
        return best;
    }

    private void ensureSelectedBandInPage() {
        if (bandPage == 0 && (state.selectedBand < 0 || state.selectedBand > 6)) state.selectedBand = 0;
        if (bandPage == 1 && (state.selectedBand < 7 || state.selectedBand > 13)) state.selectedBand = 7;
        if (bandPage == 2 && state.selectedBand != 14) state.selectedBand = 14;
    }

    private float freqToX(float f, float l, float r) {
        double lo = Math.log10(20.0), hi = Math.log10(20000.0);
        double value = Math.log10(Math.max(20f, Math.min(20000f, f)));
        return (float) (l + (value - lo) / (hi - lo) * (r - l));
    }

    private float gainToY(float db, float t, float b, float minDb, float maxDb) {
        float n = (clamp(db, minDb, maxDb) - minDb) / (maxDb - minDb);
        return b - n * (b - t);
    }

    private void valueBox(Canvas c, float l, float t, float r, float b, String value, int fg, boolean gainWritable) {
        roundRect(c, l, t, r, b, 9, PANEL2, gainWritable ? BORDER_BRIGHT : BORDER);
        label(c, "‹", l + 16, (t + b) / 2 + 7, 24, gainWritable ? WHITE : MUTED, false, Paint.Align.CENTER);
        label(c, value, (l + r) / 2, (t + b) / 2 + 5, 15, fg, false, Paint.Align.CENTER);
        label(c, "›", r - 16, (t + b) / 2 + 7, 24, gainWritable ? WHITE : MUTED, false, Paint.Align.CENTER);
    }

    private void drawSwitch(Canvas c, float x, float y, boolean on, boolean enabled) {
        int bg = !enabled ? Color.rgb(35, 55, 72) : on ? Color.rgb(0, 151, 255) : Color.rgb(32, 75, 106);
        roundRect(c, x, y, x + 63, y + 36, 18, bg, enabled ? BORDER_BRIGHT : Color.rgb(40, 63, 81));
        fill.setColor(enabled ? WHITE : MUTED);
        c.drawCircle(on ? x + 45 : x + 18, y + 18, 14, fill);
    }

    private void drawNavIcon(Canvas c, int which, float cx, float cy, int color) {
        stroke.setColor(color);
        stroke.setStrokeWidth(3f);
        fill.setColor(color);
        if (which == 0) {
            path.reset();
            path.moveTo(cx - 22, cy); path.lineTo(cx - 15, cy); path.lineTo(cx - 10, cy - 12);
            path.lineTo(cx - 4, cy + 14); path.lineTo(cx + 2, cy - 18); path.lineTo(cx + 8, cy + 11);
            path.lineTo(cx + 13, cy - 6); path.lineTo(cx + 20, cy); path.lineTo(cx + 28, cy);
            c.drawPath(path, stroke);
        } else if (which == 1) {
            path.reset(); path.moveTo(cx - 22, cy - 8); path.lineTo(cx - 10, cy - 8); path.lineTo(cx + 3, cy - 19);
            path.lineTo(cx + 3, cy + 19); path.lineTo(cx - 10, cy + 8); path.lineTo(cx - 22, cy + 8); path.close(); c.drawPath(path, stroke);
            c.drawArc(cx - 5, cy - 16, cx + 25, cy + 16, -55, 110, false, stroke);
        } else if (which == 2) {
            c.drawCircle(cx, cy - 16, 5, stroke); c.drawCircle(cx - 20, cy + 16, 5, stroke); c.drawCircle(cx + 20, cy + 16, 5, stroke);
            c.drawLine(cx, cy - 11, cx, cy, stroke); c.drawLine(cx, cy, cx - 20, cy + 11, stroke); c.drawLine(cx, cy, cx + 20, cy + 11, stroke);
        } else if (which == 3) {
            c.drawRoundRect(new RectF(cx - 18, cy - 22, cx - 10, cy + 22), 3, 3, fill);
            c.drawRoundRect(new RectF(cx - 3, cy - 15, cx + 5, cy + 22), 3, 3, fill);
            c.drawRoundRect(new RectF(cx + 12, cy - 8, cx + 20, cy + 22), 3, 3, fill);
        } else if (which == 4) {
            for (int k = -1; k <= 1; k++) {
                float xx = cx + k * 14;
                c.drawLine(xx, cy - 20, xx, cy + 20, stroke);
                c.drawCircle(xx, cy + k * 7, 4, fill);
            }
        } else {
            c.drawRoundRect(new RectF(cx - 16, cy - 21, cx + 16, cy + 21), 3, 3, stroke);
            c.drawRect(cx - 7, cy - 18, cx + 6, cy - 6, stroke);
            c.drawLine(cx - 10, cy + 10, cx + 10, cy + 10, stroke);
        }
    }

    private void drawEqLogo(Canvas c, float cx, float cy, float size, int color) {
        fill.setColor(color);
        float[] heights = {18, 34, 52, 68, 50, 34, 18};
        float start = cx - 32;
        for (int i = 0; i < heights.length; i++) {
            float x = start + i * 11;
            c.drawRoundRect(new RectF(x - 3, cy - heights[i] / 2, x + 3, cy + heights[i] / 2), 3, 3, fill);
        }
    }

    private void drawFilterGlyph(Canvas c, float cx, float cy, int type, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(2.7f); path.reset();
        if (type == DspProtocol.EQ_PEAKING_TYPE) {
            path.moveTo(cx - 18, cy + 7); path.cubicTo(cx - 8, cy + 7, cx - 9, cy - 13, cx, cy - 13);
            path.cubicTo(cx + 9, cy - 13, cx + 8, cy + 7, cx + 18, cy + 7);
        } else if (type == DspProtocol.EQ_GENERAL_LOWPASS_TYPE) {
            path.moveTo(cx - 18, cy - 9); path.lineTo(cx - 3, cy - 9); path.cubicTo(cx + 6, cy - 9, cx + 7, cy + 9, cx + 18, cy + 9);
        } else {
            path.moveTo(cx - 18, cy + 8); path.cubicTo(cx - 8, cy + 8, cx - 6, cy - 8, cx + 2, cy - 8); path.lineTo(cx + 18, cy - 8);
        }
        c.drawPath(path, stroke);
    }

    private void drawHamburger(Canvas c, float x, float y) {
        stroke.setColor(SUB); stroke.setStrokeWidth(4f); stroke.setStrokeCap(Paint.Cap.ROUND);
        for (int i = -1; i <= 1; i++) c.drawLine(x - 17, y + i * 12, x + 17, y + i * 12, stroke);
        stroke.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawGear(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(5f); c.drawCircle(cx, cy, 14, stroke);
        fill.setColor(color); c.drawCircle(cx, cy, 5, fill);
        for (int i = 0; i < 8; i++) {
            double a = i * Math.PI / 4;
            float x1 = cx + (float)Math.cos(a) * 20, y1 = cy + (float)Math.sin(a) * 20;
            float x2 = cx + (float)Math.cos(a) * 25, y2 = cy + (float)Math.sin(a) * 25;
            c.drawLine(x1, y1, x2, y2, stroke);
        }
    }

    private void drawReset(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(3f);
        c.drawArc(new RectF(cx - 17, cy - 17, cx + 17, cy + 17), 25, 305, false, stroke);
        path.reset(); path.moveTo(cx + 13, cy - 13); path.lineTo(cx + 23, cy - 16); path.lineTo(cx + 19, cy - 6); path.close();
        fill.setColor(color); c.drawPath(path, fill);
    }

    private void drawMagnifier(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(2.6f); c.drawCircle(cx, cy - 3, 8, stroke); c.drawLine(cx + 6, cy + 4, cx + 14, cy + 12, stroke);
    }

    private void drawSpectrumIcon(Canvas c, float cx, float cy, int color) {
        fill.setColor(color); float[] h = {13, 24, 36, 22, 14};
        for (int i = 0; i < h.length; i++) c.drawRoundRect(new RectF(cx - 20 + i * 9, cy - h[i]/2, cx - 15 + i * 9, cy + h[i]/2), 3, 3, fill);
    }

    private void drawSpeaker(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(2.5f); path.reset();
        path.moveTo(cx - 18, cy - 8); path.lineTo(cx - 8, cy - 8); path.lineTo(cx + 4, cy - 18); path.lineTo(cx + 4, cy + 18); path.lineTo(cx - 8, cy + 8); path.lineTo(cx - 18, cy + 8); path.close();
        c.drawPath(path, stroke); c.drawArc(new RectF(cx - 3, cy - 15, cx + 27, cy + 15), -52, 104, false, stroke);
    }

    private void drawMutedSpeaker(Canvas c, float cx, float cy, int color) {
        drawSpeaker(c, cx - 5, cy, color); stroke.setColor(color); stroke.setStrokeWidth(3f);
        c.drawLine(cx + 12, cy - 11, cx + 26, cy + 11, stroke); c.drawLine(cx + 26, cy - 11, cx + 12, cy + 11, stroke);
    }

    private void drawSave(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(2.4f); c.drawRoundRect(new RectF(cx - 14, cy - 16, cx + 14, cy + 16), 2, 2, stroke);
        c.drawRect(cx - 7, cy - 14, cx + 6, cy - 4, stroke); c.drawRect(cx - 8, cy + 3, cx + 8, cy + 12, stroke);
    }

    private void chevronDown(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(2.2f); c.drawLine(cx - 8, cy - 4, cx, cy + 4, stroke); c.drawLine(cx, cy + 4, cx + 8, cy - 4, stroke);
    }

    private void roundRect(Canvas c, float l, float t, float r, float b, float rad, int fillColor, int borderColor) {
        fill.setStyle(Paint.Style.FILL); fill.setShader(null); fill.setColor(fillColor); c.drawRoundRect(new RectF(l, t, r, b), rad, rad, fill);
        stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(1.2f); stroke.setColor(borderColor); c.drawRoundRect(new RectF(l, t, r, b), rad, rad, stroke);
    }

    private void roundRectShader(Canvas c, float l, float t, float r, float b, float rad) {
        fill.setStyle(Paint.Style.FILL); c.drawRoundRect(new RectF(l, t, r, b), rad, rad, fill);
        stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(1.3f); stroke.setColor(Color.rgb(0, 226, 255)); c.drawRoundRect(new RectF(l, t, r, b), rad, rad, stroke);
    }

    private void label(Canvas c, String s, float x, float y, float size, int color, boolean bold, Paint.Align align) {
        text.setTextSize(size); text.setColor(color); text.setTextAlign(align);
        text.setTypeface(android.graphics.Typeface.create("sans", bold ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL));
        c.drawText(s, x, y, text);
    }

    private boolean hit(float x, float y, float l, float t, float r, float b) {
        return x >= l && x <= r && y >= t && y <= b;
    }

    private float clamp(float v, float lo, float hi) { return Math.max(lo, Math.min(hi, v)); }

    private void toast(String s) { Toast.makeText(getContext(), s, Toast.LENGTH_SHORT).show(); }
}
