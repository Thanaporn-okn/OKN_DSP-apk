package com.okn.dsp;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import java.util.Locale;

/**
 * V1 UI renderer.
 *
 * The five user supplied 864x1536 screenshots are used as the visual source of truth.
 * Dynamic controls are redrawn on top so the UI follows the finger immediately.
 * The recovered BLE implementation is used only for protocol mappings that are actually
 * verified by the uploaded evidence. Crossover/Delay/Output remain local-interactive until
 * their exact actuator mappings are captured from real hardware.
 */
final class DspView extends View {
    private static final float W = 864f;
    private static final float H = 1536f;

    private static final int HOME = 0;
    private static final int EQ = 1;
    private static final int CROSSOVER = 2;
    private static final int DELAY = 3;
    private static final int OUTPUT = 4;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final DspState state = new DspState();
    private BleManager ble;

    private final Bitmap[] backgrounds = new Bitmap[5];
    private int page = HOME;
    private int dragKind = 0;
    private int dragIndex = -1;
    private float scale = 1f;
    private float offsetX = 0f;
    private float offsetY = 0f;

    private String bleStatus = "กำลังค้นหา...";
    private String bleDevice = "OKN-DSP_7CH";
    private boolean bleConnected = false;
    private String diagnostic = "";

    private int eqPage = 0;
    private final boolean[][] eqPower = new boolean[DspState.CHANNELS][DspState.BANDS];
    private final int[][] eqType = new int[DspState.CHANNELS][DspState.BANDS];
    private final String[] eqTypeNames = {"PEQ", "Low Shelf", "High Shelf"};
    private int eqPreset = 0;
    private int audioSource = 0;
    private int xoViewMode = 0;
    private final int[] hpfType = new int[DspState.CHANNELS];
    private final int[] lpfType = new int[DspState.CHANNELS];

    private final boolean[] hpfBypass = new boolean[DspState.CHANNELS];
    private final boolean[] lpfBypass = new boolean[DspState.CHANNELS];
    private final float[] hpfFreq = new float[DspState.CHANNELS];
    private final float[] lpfFreq = new float[DspState.CHANNELS];
    private final int[] hpfSlope = new int[DspState.CHANNELS];
    private final int[] lpfSlope = new int[DspState.CHANNELS];
    private final int[] xoPhase = new int[DspState.CHANNELS];
    private final boolean[] xoPolarityInvert = new boolean[DspState.CHANNELS];
    private final boolean[] xoLink = new boolean[DspState.CHANNELS];
    private final boolean[] xoMono = new boolean[DspState.CHANNELS];

    private final float[] delayMs = {0f, 1.25f, 2.60f, 2.30f, 0.80f, 3.10f, 1.90f};
    private boolean delayShowCm = false;
    private int seatPreset = 0;

    private float masterOutput = -1f;
    private final float[] outLevel = {-3f, -2.5f, -4f, -1f, -2f, -3.5f, -4.5f};
    private final boolean[] outMute = new boolean[DspState.CHANNELS];
    private final boolean[] outSolo = new boolean[DspState.CHANNELS];
    private final boolean[] outPhase = new boolean[DspState.CHANNELS];
    private final boolean[] outLink = {true, true, false, false, false, false, false};

    private final int BG = Color.rgb(0, 10, 22);
    private final int PANEL = Color.rgb(3, 25, 45);
    private final int PANEL2 = Color.rgb(2, 18, 35);
    private final int BORDER = Color.rgb(14, 69, 114);
    private final int WHITE = Color.rgb(241, 247, 255);
    private final int SUB = Color.rgb(165, 196, 230);
    private final int CYAN = Color.rgb(0, 220, 255);
    private final int BLUE = Color.rgb(0, 132, 255);
    private final int GREEN = Color.rgb(0, 235, 120);
    private final int MAGENTA = Color.rgb(244, 57, 245);

    private final int[] channelColors = {
            Color.rgb(28, 184, 255), Color.rgb(22, 219, 235), Color.rgb(30, 224, 97),
            Color.rgb(255, 210, 45), Color.rgb(255, 149, 36), Color.rgb(255, 55, 94),
            Color.rgb(207, 58, 255)
    };

    DspView(Context context, BleManager ble) {
        super(context);
        this.ble = ble;
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        setClickable(true);
        setFocusable(true);
        setHapticFeedbackEnabled(false);

        backgrounds[HOME] = BitmapFactory.decodeResource(getResources(), R.drawable.ui_home);
        backgrounds[EQ] = BitmapFactory.decodeResource(getResources(), R.drawable.ui_eq);
        backgrounds[CROSSOVER] = BitmapFactory.decodeResource(getResources(), R.drawable.ui_crossover);
        backgrounds[DELAY] = BitmapFactory.decodeResource(getResources(), R.drawable.ui_delay);
        backgrounds[OUTPUT] = BitmapFactory.decodeResource(getResources(), R.drawable.ui_output);

        for (int c = 0; c < DspState.CHANNELS; c++) {
            hpfFreq[c] = 100f;
            lpfFreq[c] = 1000f;
            hpfSlope[c] = 24;
            lpfSlope[c] = 24;
            for (int b = 0; b < DspState.BANDS; b++) {
                eqPower[c][b] = true;
                eqType[c][b] = (b == 1 ? 1 : b == 5 ? 2 : 0);
            }
        }
        loadLocalState();
    }

    void setBleManager(BleManager ble) {
        this.ble = ble;
    }

    void setBleStatus(String status, String deviceName, boolean connected) {
        bleStatus = status == null ? "" : status;
        if (deviceName != null && !deviceName.isEmpty()) bleDevice = deviceName;
        bleConnected = connected;
        invalidate();
    }

    void setDiagnostic(String message) {
        diagnostic = message == null ? "" : message;
        invalidate();
    }

    void setScalarFromDsp(int actuatorId, float value) {
        switch (actuatorId) {
            case DspProtocol.ID_MASTER_VOLUME: state.masterVolume = value; break;
            case DspProtocol.ID_BASS_VOLUME: state.bassVolume = value; break;
            case DspProtocol.ID_BASS_CUTOFF: state.bassCutoff = value; break;
            case DspProtocol.ID_BASS_BOOST: state.bassBoost = value; break;
            case DspProtocol.ID_MIDDLE_BOOST: state.middleBoost = value; break;
            case DspProtocol.ID_TREBLE_BOOST: state.trebleBoost = value; break;
            default: return;
        }
        invalidate();
    }

    void setEqFromDsp(int channel0, int uiBand0, float frequency, float gainDb, float q, boolean writable) {
        if (channel0 < 0 || channel0 >= DspState.CHANNELS || uiBand0 < 0 || uiBand0 >= DspState.BANDS) return;
        state.freq[channel0][uiBand0] = frequency;
        state.gain[channel0][uiBand0] = gainDb;
        state.q[channel0][uiBand0] = q;
        state.eqWritable[channel0][uiBand0] = writable;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawColor(BG);
        scale = Math.min(getWidth() / W, getHeight() / H);
        offsetX = (getWidth() - W * scale) * 0.5f;
        offsetY = (getHeight() - H * scale) * 0.5f;
        canvas.save();
        canvas.translate(offsetX, offsetY);
        canvas.scale(scale, scale);
        Bitmap bg = backgrounds[page];
        if (bg != null) canvas.drawBitmap(bg, null, new RectF(0, 0, W, H), p);
        drawConnectionOverlay(canvas);
        if (page == HOME) drawHomeOverlay(canvas);
        else {
            drawChannelTabs(canvas);
            if (page == EQ) drawEqOverlay(canvas);
            else if (page == CROSSOVER) drawCrossoverOverlay(canvas);
            else if (page == DELAY) drawDelayOverlay(canvas);
            else if (page == OUTPUT) drawOutputOverlay(canvas);
        }
        canvas.restore();
    }

    private void drawConnectionOverlay(Canvas c) {
        float x = page == HOME ? 505 : 515;
        float y = page == HOME ? 18 : 19;
        float w = page == HOME ? 256 : 257;
        float h = page == HOME ? 72 : 66;
        roundPanel(c, x, y, w, h, 14, Color.rgb(2, 24, 42), Color.rgb(10, 70, 120));
        p.setColor(bleConnected ? GREEN : Color.rgb(80, 110, 135));
        p.setShadowLayer(bleConnected ? 12 : 0, 0, 0, bleConnected ? GREEN : Color.TRANSPARENT);
        c.drawCircle(x + 35, y + h / 2f, 10, p);
        p.clearShadowLayer();
        text(c, bleConnected ? "Connected" : compactStatus(), x + 67, y + 31, page == HOME ? 20 : 17, bleConnected ? GREEN : WHITE, true, Paint.Align.LEFT);
        text(c, bleDevice, x + 67, y + 55, 15, SUB, false, Paint.Align.LEFT);
    }

    private String compactStatus() {
        if (bleStatus == null || bleStatus.isEmpty()) return "Bluetooth";
        if (bleStatus.length() <= 18) return bleStatus;
        return bleStatus.substring(0, 18) + "…";
    }

    private void drawChannelTabs(Canvas c) {
        float y = 104, h = 77, gap = 7;
        float x = 18, totalW = 828, each = (totalW - gap * 6) / 7f;
        String[] a = {"CH1", "CH2", "CH3", "CH4", "CH5", "CH6", "CH7"};
        String[] b = {"Front L", "Front R", "Rear L", "Rear R", "Center", "Sub L", "Sub R"};
        for (int i = 0; i < 7; i++) {
            boolean sel = state.channel == i;
            int fill = sel ? Color.rgb(0, 117, 230) : Color.rgb(2, 23, 42);
            int border = sel ? CYAN : Color.rgb(8, 72, 121);
            roundPanel(c, x, y, each, h, 10, fill, border);
            if (sel) glowRect(c, x, y, each, h, 10, CYAN);
            text(c, a[i], x + each / 2f, y + 31, 18, WHITE, true, Paint.Align.CENTER);
            text(c, b[i], x + each / 2f, y + 58, 15, sel ? WHITE : SUB, false, Paint.Align.CENTER);
            x += each + gap;
        }
    }

    private void drawHomeOverlay(Canvas c) {
        final float[] cy = {181, 329, 476, 624, 772, 921};
        for (int i = 0; i < 6; i++) drawHomeSlider(c, i, cy[i]);
        String[] sources = {"High Level (Speaker)", "Low Level (RCA)"};
        drawValueCell(c, 140, 1118, 268, 50, sources[audioSource], 14);
        String[] presets = {"Flat", "Pop", "Rock", "Jazz"};
        drawValueCell(c, 140, 1291, 268, 50, presets[Math.max(0, Math.min(3, state.homePreset))], 16);
        // device status connection line
        p.setColor(PANEL2); c.drawRect(440, 1110, 841, 1355, p);
        text(c, "Device Status", 568, 1070, 24, WHITE, true, Paint.Align.LEFT);
        text(c, "สถานะอุปกรณ์", 568, 1100, 16, SUB, false, Paint.Align.LEFT);
        divider(c, 474, 1136, 816, 1136);
        p.setColor(bleConnected ? GREEN : Color.rgb(72, 105, 130)); c.drawCircle(478, 1160, 10, p);
        text(c, bleConnected ? "Connected" : "Disconnected", 518, 1168, 17, WHITE, false, Paint.Align.LEFT);
        text(c, bleDevice, 816, 1168, 16, SUB, false, Paint.Align.RIGHT);
        divider(c, 474, 1194, 816, 1194);
        text(c, "Voltage", 518, 1222, 16, SUB, false, Paint.Align.LEFT);
        text(c, "--.- V", 816, 1222, 16, SUB, false, Paint.Align.RIGHT);
        divider(c, 474, 1247, 816, 1247);
        text(c, "Temperature", 518, 1276, 16, SUB, false, Paint.Align.LEFT);
        text(c, "-- °C", 816, 1276, 16, SUB, false, Paint.Align.RIGHT);
        divider(c, 474, 1301, 816, 1301);
        text(c, "System", 518, 1330, 16, SUB, false, Paint.Align.LEFT);
        text(c, bleConnected ? "Normal" : "Waiting", 816, 1330, 16, bleConnected ? GREEN : SUB, false, Paint.Align.RIGHT);
    }

    private void drawHomeSlider(Canvas c, int idx, float cy) {
        float x0 = 386, x1 = 664;
        float value, lo, hi;
        int accent;
        switch (idx) {
            case 0: value = state.masterVolume; lo = -60; hi = 12; accent = BLUE; break;
            case 1: value = state.bassVolume; lo = -12; hi = 12; accent = CYAN; break;
            case 2: value = state.bassCutoff; lo = 20; hi = 500; accent = MAGENTA; break;
            case 3: value = state.bassBoost; lo = -10; hi = 12; accent = Color.rgb(255, 45, 110); break;
            case 4: value = state.middleBoost; lo = -12; hi = 12; accent = BLUE; break;
            default: value = state.trebleBoost; lo = -12; hi = 12; accent = MAGENTA; break;
        }
        p.setColor(PANEL); c.drawRoundRect(new RectF(365, cy - 27, 678, cy + 28), 12, 12, p);
        float frac = idx == 2 ? (float)((Math.log(Math.max(lo, value)) - Math.log(lo)) / (Math.log(hi) - Math.log(lo))) : (value - lo) / (hi - lo);
        frac = clamp(frac, 0, 1);
        float k = x0 + frac * (x1 - x0);
        p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeWidth(14); p.setColor(Color.rgb(35, 70, 105)); c.drawLine(x0, cy, x1, cy, p);
        p.setShader(new LinearGradient(x0, cy, Math.max(x0 + 1, k), cy, accent, CYAN, Shader.TileMode.CLAMP));
        p.setShadowLayer(10, 0, 0, accent); c.drawLine(x0, cy, k, cy, p); p.clearShadowLayer(); p.setShader(null);
        p.setColor(WHITE); c.drawCircle(k, cy, 19, p); p.setStrokeCap(Paint.Cap.BUTT);
        String v = idx == 2 ? String.format(Locale.US, "%.0f Hz", value) : String.format(Locale.US, "%.1f dB", value);
        drawValueCell(c, 700, cy - 30, 126, 62, v, 22);
    }

    private void drawEqOverlay(Canvas c) {
        drawEqGraph(c);
        drawEqPageTabs(c);
        drawEqRows(c);
        String[] names = {"Custom 1", "Flat"};
        drawValueCell(c, 138, 1281, 189, 51, names[eqPreset], 16);
    }

    private void drawEqGraph(Canvas c) {
        RectF g = new RectF(75, 316, 830, 586);
        p.setColor(Color.rgb(2, 20, 37)); c.drawRect(g, p);
        stroke.setStrokeWidth(1); stroke.setColor(Color.rgb(11, 53, 83));
        for (int i = 0; i <= 12; i++) {
            float x = g.left + i * g.width() / 12f; c.drawLine(x, g.top, x, g.bottom, stroke);
        }
        for (int i = 0; i <= 6; i++) {
            float y = g.top + i * g.height() / 6f; c.drawLine(g.left, y, g.right, y, stroke);
        }
        Path path = new Path();
        boolean started = false;
        for (int b = 0; b < DspState.BANDS; b++) {
            if (!eqPower[state.channel][b]) continue;
            float x = freqX(state.freq[state.channel][b], g.left, g.width());
            float y = gainY(state.gain[state.channel][b], g.top, g.height());
            if (!started) { path.moveTo(x, y); started = true; } else path.lineTo(x, y);
        }
        if (started) {
            stroke.setStrokeWidth(4); stroke.setColor(CYAN); stroke.setShadowLayer(11, 0, 0, CYAN); c.drawPath(path, stroke); stroke.clearShadowLayer();
        }
        for (int b = 0; b < DspState.BANDS; b++) {
            if (!eqPower[state.channel][b]) continue;
            float x = freqX(state.freq[state.channel][b], g.left, g.width());
            float y = gainY(state.gain[state.channel][b], g.top, g.height());
            int col = channelColors[b % channelColors.length];
            p.setColor(col); p.setShadowLayer(9, 0, 0, col); c.drawCircle(x, y, b == state.selectedBand ? 11 : 8, p); p.clearShadowLayer();
            stroke.setColor(WHITE); stroke.setStrokeWidth(2); c.drawCircle(x, y, b == state.selectedBand ? 11 : 8, stroke);
        }
    }

    private void drawEqPageTabs(Canvas c) {
        String[] labels = {"Bands 1 - 6", "Bands 7 - 12", "Bands 13 - 15"};
        float[] xs = {18, 244, 459};
        float[] ws = {220, 208, 194};
        for (int i = 0; i < 3; i++) {
            boolean sel = eqPage == i;
            roundPanel(c, xs[i], 653, ws[i], 56, 11, sel ? Color.rgb(0, 119, 231) : PANEL2, sel ? CYAN : BORDER);
            if (sel) glowRect(c, xs[i], 653, ws[i], 56, 11, CYAN);
            text(c, labels[i], xs[i] + ws[i] / 2, 689, 18, WHITE, false, Paint.Align.CENTER);
        }
    }

    private void drawEqRows(Canvas c) {
        p.setColor(PANEL); c.drawRoundRect(new RectF(18, 716, 845, 1178), 15, 15, p);
        text(c, "#", 47, 758, 16, WHITE, false, Paint.Align.CENTER);
        text(c, "Type", 135, 758, 16, WHITE, false, Paint.Align.LEFT);
        text(c, "Frequency", 346, 758, 16, WHITE, false, Paint.Align.CENTER);
        text(c, "Gain", 507, 758, 16, WHITE, false, Paint.Align.CENTER);
        text(c, "Q", 671, 758, 16, WHITE, false, Paint.Align.CENTER);
        text(c, "Power", 797, 758, 16, WHITE, false, Paint.Align.CENTER);
        divider(c, 32, 773, 829, 773);
        int start = eqPage == 0 ? 0 : eqPage == 1 ? 6 : 12;
        int count = eqPage == 2 ? 3 : 6;
        for (int r = 0; r < count; r++) {
            int b = start + r;
            float y = 781 + r * 65f;
            int col = channelColors[b % channelColors.length];
            p.setColor(col); p.setShadowLayer(8,0,0,col); c.drawCircle(47, y + 27, 11, p); p.clearShadowLayer();
            text(c, Integer.toString(b + 1), 73, y + 33, 17, WHITE, false, Paint.Align.LEFT);
            drawValueCell(c, 102, y + 4, 173, 48, eqTypeNames[eqType[state.channel][b]], 15);
            drawValueCell(c, 293, y + 4, 130, 48, formatHz(state.freq[state.channel][b]), 15);
            drawValueCell(c, 438, y + 4, 138, 48, String.format(Locale.US, "%.1f dB", state.gain[state.channel][b]), 15);
            drawValueCell(c, 592, y + 4, 143, 48, String.format(Locale.US, "%.2f", state.q[state.channel][b]), 15);
            drawToggle(c, 760, y + 6, 69, 45, eqPower[state.channel][b], CYAN);
            if (b == state.selectedBand) {
                stroke.setColor(CYAN); stroke.setStrokeWidth(1.5f); c.drawRoundRect(new RectF(30, y, 837, y + 57), 8, 8, stroke);
            }
        }
    }

    private void drawCrossoverOverlay(Canvas c) {
        drawValueCell(c, 493, 232, 168, 58, xoViewMode == 0 ? "Magnitude" : "Phase", 17);
        RectF g = new RectF(84, 372, 826, 614);
        p.setColor(Color.rgb(2, 20, 37)); c.drawRect(g, p);
        stroke.setColor(Color.rgb(10, 55, 87)); stroke.setStrokeWidth(1);
        for (int i = 0; i <= 12; i++) { float x = g.left + i*g.width()/12f; c.drawLine(x,g.top,x,g.bottom,stroke); }
        for (int i = 0; i <= 6; i++) { float y = g.top + i*g.height()/6f; c.drawLine(g.left,y,g.right,y,stroke); }
        float hx = freqX(hpfFreq[state.channel], g.left, g.width());
        float lx = freqX(lpfFreq[state.channel], g.left, g.width());
        Path hp = new Path(); hp.moveTo(g.left, g.bottom); hp.cubicTo(hx-130,g.bottom,hx-70,g.top+95,hx,g.top+90); hp.lineTo(g.right,g.top+90);
        stroke.setColor(CYAN); stroke.setStrokeWidth(4); stroke.setShadowLayer(8,0,0,CYAN); if (!hpfBypass[state.channel]) c.drawPath(hp, stroke); stroke.clearShadowLayer();
        Path lp = new Path(); lp.moveTo(g.left,g.top+90); lp.lineTo(lx,g.top+90); lp.cubicTo(lx+75,g.top+95,lx+125,g.bottom-10,g.right,g.bottom);
        stroke.setColor(MAGENTA); stroke.setStrokeWidth(4); stroke.setShadowLayer(8,0,0,MAGENTA); if (!lpfBypass[state.channel]) c.drawPath(lp, stroke); stroke.clearShadowLayer();
        p.setColor(CYAN); c.drawCircle(hx,g.top+90,10,p); p.setColor(MAGENTA); c.drawCircle(lx,g.top+90,10,p);
        drawToggle(c, 752, 716, 72, 43, hpfBypass[state.channel], CYAN);
        drawToggle(c, 752, 974, 72, 43, lpfBypass[state.channel], MAGENTA);
        drawValueCell(c, 51, 839, 229, 64, filterTypeName(hpfType[state.channel]), 18);
        drawValueCell(c, 307, 839, 253, 64, formatHz(hpfFreq[state.channel]), 18);
        drawValueCell(c, 587, 839, 238, 64, hpfSlope[state.channel] + " dB/Oct", 18);
        drawValueCell(c, 51, 1092, 229, 64, filterTypeName(lpfType[state.channel]), 18);
        drawValueCell(c, 307, 1092, 253, 64, formatHz(lpfFreq[state.channel]), 18);
        drawValueCell(c, 587, 1092, 238, 64, lpfSlope[state.channel] + " dB/Oct", 18);
        drawValueCell(c, 42, 1294, 196, 60, xoPhase[state.channel] + "°", 18);
        drawValueCell(c, 253, 1294, 188, 60, xoPolarityInvert[state.channel] ? "Invert" : "Normal", 18);
        drawToggle(c, 503, 1305, 70, 43, xoLink[state.channel], CYAN);
        drawValueCell(c, 624, 1294, 200, 60, xoMono[state.channel] ? "Mono" : "Stereo", 18);
    }

    private void drawDelayOverlay(Canvas c) {
        // Unit switch
        roundPanel(c, 484, 224, 164, 57, 10, PANEL2, BORDER);
        roundPanel(c, delayShowCm ? 568 : 486, 226, 78, 53, 9, Color.rgb(0,125,235), CYAN);
        text(c, "ms", 525, 261, 18, WHITE, false, Paint.Align.CENTER);
        text(c, "cm", 608, 261, 18, WHITE, false, Paint.Align.CENTER);
        String[] seats = {"Driver (Left)", "Front Passenger", "Center"};
        drawValueCell(c, 582, 365, 227, 51, seats[seatPreset], 16);
        float min = delayMs[0], max = delayMs[0]; for (float v:delayMs){min=Math.min(min,v);max=Math.max(max,v);}        
        text(c, delayText(min), 569, 672, 17, WHITE, false, Paint.Align.CENTER);
        text(c, delayText(max), 759, 672, 17, WHITE, false, Paint.Align.CENTER);
        float[] rowY = {769, 858, 947, 1036, 1125, 1215, 1304};
        for (int i = 0; i < 7; i++) drawDelayRow(c, i, rowY[i]);
        drawDelayCarLabels(c);
    }

    private void drawDelayCarLabels(Canvas c) {
        float[][] xy = {{91,421},{444,421},{88,578},{445,578},{270,350},{270,647},{445,647}};
        Paint.Align[] al = {Paint.Align.RIGHT,Paint.Align.LEFT,Paint.Align.RIGHT,Paint.Align.LEFT,Paint.Align.CENTER,Paint.Align.CENTER,Paint.Align.LEFT};
        for (int i=0;i<7;i++) {
            float x=xy[i][0],y=xy[i][1];
            p.setColor(Color.argb(185,0,13,28));
            float w=76; c.drawRoundRect(new RectF(x-(al[i]==Paint.Align.RIGHT?w:al[i]==Paint.Align.CENTER?w/2:0)-4,y-20,x+(al[i]==Paint.Align.LEFT?w:al[i]==Paint.Align.CENTER?w/2:0)+4,y+9),7,7,p);
            text(c, String.format(Locale.US,"%.2f ms",delayMs[i]), x, y, 15, WHITE, true, al[i]);
        }
    }

    private void drawDelayRow(Canvas c, int i, float cy) {
        p.setColor(PANEL); c.drawRoundRect(new RectF(18, cy-32, 846, cy+50), 13,13,p);
        p.setColor(channelColors[i]); c.drawCircle(48,cy+1,14,p);
        text(c, "CH"+(i+1), 79, cy-3, 18, WHITE, true, Paint.Align.LEFT);
        text(c, channelShort(i), 79, cy+25, 14, SUB, false, Paint.Align.LEFT);
        float x0=201,x1=648, frac=clamp(delayMs[i]/10f,0,1), k=x0+frac*(x1-x0);
        p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeWidth(11); p.setColor(Color.rgb(36,72,106)); c.drawLine(x0,cy,x1,cy,p);
        p.setColor(channelColors[i]); p.setShadowLayer(7,0,0,channelColors[i]); c.drawLine(x0,cy,k,cy,p); p.clearShadowLayer(); p.setColor(WHITE); c.drawCircle(k,cy,15,p); p.setStrokeCap(Paint.Cap.BUTT);
        drawValueCell(c, 687, cy-28, 139, 60, delayText(delayMs[i]), 16);
    }

    private void drawOutputOverlay(Canvas c) {
        drawOutputOverview(c);
        drawOutputSlider(c, -1, 590, 448, 810, masterOutput, Color.rgb(10,160,255));
        float[] rowY = {607, 714, 821, 928, 1035, 1142, 1249};
        for (int i = 0; i < 7; i++) drawOutputRow(c, i, rowY[i]);
    }

    private void drawOutputOverview(Canvas c) {
        p.setColor(PANEL); c.drawRoundRect(new RectF(31,342,561,548),12,12,p);
        text(c,"Output Level Overview",50,372,16,WHITE,false,Paint.Align.LEFT);
        for (int i=0;i<7;i++) {
            float x=107+i*63f;
            float frac=clamp((outLevel[i]+60f)/72f,0,1);
            for (int s=0;s<10;s++) {
                float y=484-s*10f;
                p.setColor(s/10f<=frac ? channelColors[i] : Color.rgb(8,39,62));
                c.drawRoundRect(new RectF(x-8,y,x+8,y+6),2,2,p);
            }
            text(c,"CH"+(i+1),x,510,13,WHITE,false,Paint.Align.CENTER);
        }
        drawOutputSlider(c,-1,588,447,809,masterOutput,CYAN);
        drawValueCell(c,724,353,102,53,String.format(Locale.US,"%.1f dB",masterOutput),18);
    }

    private void drawOutputRow(Canvas c, int i, float cy) {
        p.setColor(PANEL); c.drawRoundRect(new RectF(18,cy-38,846,cy+52),13,13,p);
        p.setColor(Color.argb(40,Color.red(channelColors[i]),Color.green(channelColors[i]),Color.blue(channelColors[i]))); c.drawCircle(62,cy+2,25,p);
        stroke.setColor(channelColors[i]); stroke.setStrokeWidth(3); c.drawCircle(62,cy+2,25,stroke);
        text(c,Integer.toString(i+1),62,cy+9,18,WHITE,true,Paint.Align.CENTER);
        text(c,"CH"+(i+1),107,cy-1,19,WHITE,true,Paint.Align.LEFT);
        text(c,channelShort(i),107,cy+26,14,SUB,false,Paint.Align.LEFT);
        drawOutputSlider(c,i,194,cy,421,outLevel[i],channelColors[i]);
        drawValueCell(c,443,cy-28,91,56,String.format(Locale.US,"%.1f dB",outLevel[i]),16);
        drawSmallButton(c,549,cy-29,68,60,"Mute",outMute[i]);
        drawSmallButton(c,626,cy-29,68,60,"Solo",outSolo[i]);
        drawSmallButton(c,702,cy-29,68,60,"Phase",outPhase[i]);
        if (i < 2) drawSmallButton(c,778,cy-29,64,60,"Link",outLink[i]);
    }

    private void drawOutputSlider(Canvas c, int index, float x0, float cy, float x1, float value, int color) {
        float frac=clamp((value+60f)/72f,0,1),k=x0+frac*(x1-x0);
        p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeWidth(11);p.setColor(Color.rgb(38,75,110));c.drawLine(x0,cy,x1,cy,p);
        p.setShader(new LinearGradient(x0,cy,Math.max(x0+1,k),cy,color,CYAN,Shader.TileMode.CLAMP));p.setShadowLayer(7,0,0,color);c.drawLine(x0,cy,k,cy,p);p.clearShadowLayer();p.setShader(null);p.setColor(WHITE);c.drawCircle(k,cy,15,p);p.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawSmallButton(Canvas c,float x,float y,float w,float h,String label,boolean on){
        roundPanel(c,x,y,w,h,10,on?Color.rgb(0,103,184):PANEL2,on?CYAN:BORDER);
        text(c,label,x+w/2,y+h/2+6,12,on?WHITE:SUB,false,Paint.Align.CENTER);
    }

    private void drawToggle(Canvas c,float x,float y,float w,float h,boolean on,int accent){
        roundPanel(c,x,y,w,h,h/2,on?Color.rgb(0,117,204):Color.rgb(39,64,92),on?accent:Color.rgb(48,77,107));
        float r=h/2-4; p.setColor(WHITE); c.drawCircle(on?x+w-h/2:x+h/2,y+h/2,r,p);
    }

    private void drawValueCell(Canvas c,float x,float y,float w,float h,String s,float size){
        roundPanel(c,x,y,w,h,10,PANEL2,Color.rgb(22,82,137));
        text(c,s,x+w/2,y+h/2+size*0.35f,size,WHITE,false,Paint.Align.CENTER);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (scale <= 0f) return true;
        float x = (event.getX() - offsetX) / scale;
        float y = (event.getY() - offsetY) / scale;
        if (x < 0 || x > W || y < 0 || y > H) return true;

        if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
            performClick();
            dragKind = 0; dragIndex = -1;
            if (handleGlobalDown(x,y)) return true;
            if (page == HOME) return handleHomeDown(x,y);
            if (handleChannelDown(x,y)) return true;
            if (page == EQ) return handleEqDown(x,y);
            if (page == CROSSOVER) return handleCrossoverDown(x,y);
            if (page == DELAY) return handleDelayDown(x,y);
            if (page == OUTPUT) return handleOutputDown(x,y);
            return true;
        }
        if (event.getActionMasked() == MotionEvent.ACTION_MOVE) {
            if (dragKind == 1) updateHomeSlider(dragIndex,x);
            else if (dragKind == 2) updateEqGraph(dragIndex,x,y);
            else if (dragKind == 3) updateDelaySlider(dragIndex,x);
            else if (dragKind == 4) updateOutputSlider(dragIndex,x);
            invalidate();
            return true;
        }
        if (event.getActionMasked() == MotionEvent.ACTION_UP || event.getActionMasked() == MotionEvent.ACTION_CANCEL) {
            if (dragKind == 1 && dragIndex >= 0 && ble != null) ble.flushScalarRealtime(homeActuator(dragIndex));
            if (dragKind >= 3 && page >= CROSSOVER) noteUnverifiedHardwareOnce();
            saveLocalState();
            dragKind = 0; dragIndex = -1;
            invalidate();
            return true;
        }
        return true;
    }

    @Override public boolean performClick() { super.performClick(); return true; }

    private boolean handleGlobalDown(float x,float y){
        if (y >= 1380) {
            int idx;
            if (x < 173) idx=HOME; else if (x<345) idx=EQ; else if (x<518) idx=CROSSOVER; else if (x<690) idx=DELAY; else idx=OUTPUT;
            page=idx; dragKind=0; invalidate(); return true;
        }
        if (x > 790 && y < 100) {
            toast("OKN_DSP V1\n" + (bleConnected ? "DSP connected" : "DSP not connected") + (diagnostic.isEmpty()?"":"\n"+diagnostic));
            return true;
        }
        if (((page==HOME && x>=505&&x<=770&&y<=100) || (page!=HOME&&x>=500&&x<=790&&y<=95))) {
            if (ble != null) {
                if (ble.isDspReady()) ble.requestDspRefresh(); else ble.startScan();
            }
            return true;
        }
        return false;
    }

    private boolean handleChannelDown(float x,float y){
        if (y < 102 || y > 184) return false;
        float gap=7,totalW=828,each=(totalW-gap*6)/7f;
        for(int i=0;i<7;i++){
            float sx=18+i*(each+gap);
            if(x>=sx&&x<=sx+each){state.channel=i;invalidate();return true;}
        }
        return true;
    }

    private boolean handleHomeDown(float x,float y){
        float[] cy={181,329,476,624,772,921};
        for(int i=0;i<6;i++) if(x>=360&&x<=690&&Math.abs(y-cy[i])<42){dragKind=1;dragIndex=i;updateHomeSlider(i,x);invalidate();return true;}
        if (x>=120&&x<=425&&y>=1260&&y<=1360) {
            state.homePreset=(state.homePreset+1)%4; state.applyHomePreset(state.homePreset); sendAllHome(); invalidate(); return true;
        }
        if (x>=120&&x<=425&&y>=1080&&y<=1190) { audioSource=(audioSource+1)%2; invalidate(); if(ble!=null)ble.reportUnverifiedControl("Audio Source"); return true; }
        return true;
    }

    private void updateHomeSlider(int idx,float x){
        float frac=clamp((x-386)/(664-386),0,1);
        switch(idx){
            case 0: state.masterVolume=round1(-60+frac*72); break;
            case 1: state.bassVolume=round1(-12+frac*24); break;
            case 2: state.bassCutoff=Math.round((float)Math.exp(Math.log(20)+frac*(Math.log(500)-Math.log(20)))); break;
            case 3: state.bassBoost=round1(-10+frac*22); break;
            case 4: state.middleBoost=round1(-12+frac*24); break;
            case 5: state.trebleBoost=round1(-12+frac*24); break;
        }
        sendHome(idx);
    }

    private void sendHome(int idx){
        if(ble==null)return;
        int id=homeActuator(idx); float v=homeValue(idx);
        float safe=DspProtocol.sanitizeScalar(id,v);
        if(Float.isFinite(safe)) ble.setScalarRealtime(id,safe);
    }
    private void sendAllHome(){for(int i=0;i<6;i++)sendHome(i);}
    private int homeActuator(int i){return i==0?DspProtocol.ID_MASTER_VOLUME:i==1?DspProtocol.ID_BASS_VOLUME:i==2?DspProtocol.ID_BASS_CUTOFF:i==3?DspProtocol.ID_BASS_BOOST:i==4?DspProtocol.ID_MIDDLE_BOOST:DspProtocol.ID_TREBLE_BOOST;}
    private float homeValue(int i){return i==0?state.masterVolume:i==1?state.bassVolume:i==2?state.bassCutoff:i==3?state.bassBoost:i==4?state.middleBoost:state.trebleBoost;}

    private boolean handleEqDown(float x,float y){
        if(x>=480&&x<=675&&y>=205&&y<=300){state.channel=(state.channel+1)%7;invalidate();return true;}
        if(y>=645&&y<=716){ if(x<240)eqPage=0;else if(x<455)eqPage=1;else eqPage=2; invalidate(); return true; }
        if(x>=75&&x<=830&&y>=300&&y<=600){int b=nearestEqBand(x,y);state.selectedBand=b;dragKind=2;dragIndex=b;updateEqGraph(b,x,y);invalidate();return true;}
        if(y>=775&&y<=1175){
            int row=(int)((y-781)/65f); int start=eqPage==0?0:eqPage==1?6:12; int max=eqPage==2?3:6;
            if(row>=0&&row<max){int b=start+row;state.selectedBand=b;float ry=781+row*65f;
                if(x>=100&&x<=275){eqType[state.channel][b]=(eqType[state.channel][b]+1)%eqTypeNames.length;}
                else if(x>=290&&x<=425){state.freq[state.channel][b]=stepFreq(state.freq[state.channel][b],x>357);}
                else if(x>=435&&x<=580){state.gain[state.channel][b]=clamp(round1(state.gain[state.channel][b]+(x>507?0.5f:-0.5f)),-12,12);sendEq(b);}
                else if(x>=590&&x<=740){state.q[state.channel][b]=clamp(round2(state.q[state.channel][b]+(x>665?0.1f:-0.1f)),0.2f,10f);}
                else if(x>=750){eqPower[state.channel][b]=!eqPower[state.channel][b];}
                invalidate();return true;}
        }
        if(x>=675&&y>=210&&y<=292){state.flattenEq(state.channel);for(int b=0;b<15;b++)sendEq(b);invalidate();return true;}
        if(x>=125&&x<=340&&y>=1260&&y<=1350){eqPreset=(eqPreset+1)%2;if(eqPreset==1){state.flattenEq(state.channel);for(int b=0;b<15;b++)sendEq(b);}invalidate();return true;}
        if(x>=340&&x<=500&&y>=1210&&y<=1355){state.saveEq(getContext());toast("Preset saved");return true;}
        if(x>=505&&x<=650&&y>=1210&&y<=1355){boolean ok=state.loadEq(getContext());toast(ok?"Preset loaded":"No saved preset");invalidate();return true;}
        return true;
    }

    private int nearestEqBand(float x,float y){
        RectF g=new RectF(75,316,830,586);int best=0;float bd=Float.MAX_VALUE;
        for(int b=0;b<15;b++){float px=freqX(state.freq[state.channel][b],g.left,g.width()),py=gainY(state.gain[state.channel][b],g.top,g.height());float d=(px-x)*(px-x)+(py-y)*(py-y);if(d<bd){bd=d;best=b;}}
        return best;
    }
    private void updateEqGraph(int b,float x,float y){
        RectF g=new RectF(75,316,830,586); float xf=clamp((x-g.left)/g.width(),0,1); double f=Math.exp(Math.log(20)+xf*(Math.log(20000)-Math.log(20)));
        state.freq[state.channel][b]=roundFreq((float)f); state.gain[state.channel][b]=round1(clamp(12-(y-g.top)/g.height()*24,-12,12)); sendEq(b);
    }
    private void sendEq(int b){if(ble!=null&&eqPower[state.channel][b])ble.setEqRealtime(state.channel,b,state.freq[state.channel][b],state.gain[state.channel][b],state.q[state.channel][b]);}

    private boolean handleCrossoverDown(float x,float y){
        if(x>=485&&x<=670&&y>=210&&y<=310){xoViewMode=(xoViewMode+1)%2;invalidate();return true;}
        if(x>=670&&y>=210&&y<=300){resetCrossover();invalidate();return true;}
        if(x>=735&&y>=690&&y<=780){hpfBypass[state.channel]=!hpfBypass[state.channel];invalidate();noteUnverifiedHardwareOnce();return true;}
        if(x>=735&&y>=945&&y<=1035){lpfBypass[state.channel]=!lpfBypass[state.channel];invalidate();noteUnverifiedHardwareOnce();return true;}
        if(y>=815&&y<=915){if(x<290)hpfType[state.channel]=(hpfType[state.channel]+1)%3;else if(x>=300&&x<=565)hpfFreq[state.channel]=stepFreq(hpfFreq[state.channel],x>432);else if(x>=580)hpfSlope[state.channel]=stepSlope(hpfSlope[state.channel],x>705);invalidate();noteUnverifiedHardwareOnce();return true;}
        if(y>=1065&&y<=1170){if(x<290)lpfType[state.channel]=(lpfType[state.channel]+1)%3;else if(x>=300&&x<=565)lpfFreq[state.channel]=stepFreq(lpfFreq[state.channel],x>432);else if(x>=580)lpfSlope[state.channel]=stepSlope(lpfSlope[state.channel],x>705);invalidate();noteUnverifiedHardwareOnce();return true;}
        if(y>=1270&&y<=1370){
            if(x<245)xoPhase[state.channel]=(xoPhase[state.channel]+90)%360;
            else if(x<450)xoPolarityInvert[state.channel]=!xoPolarityInvert[state.channel];
            else if(x<610)xoLink[state.channel]=!xoLink[state.channel];
            else xoMono[state.channel]=!xoMono[state.channel];
            invalidate();noteUnverifiedHardwareOnce();return true;
        }
        return true;
    }
    private void resetCrossover(){int c=state.channel;hpfBypass[c]=false;lpfBypass[c]=false;hpfFreq[c]=100;lpfFreq[c]=1000;hpfSlope[c]=24;lpfSlope[c]=24;xoPhase[c]=0;xoPolarityInvert[c]=false;xoLink[c]=false;xoMono[c]=false;}

    private boolean handleDelayDown(float x,float y){
        if(x>=480&&x<=650&&y>=215&&y<=290){delayShowCm=x>565;invalidate();return true;}
        if(x>=660&&y>=215&&y<=290){float v=delayMs[state.channel];for(int i=0;i<7;i++)delayMs[i]=v;invalidate();noteUnverifiedHardwareOnce();return true;}
        if(x>=560&&x<=830&&y>=340&&y<=425){seatPreset=(seatPreset+1)%3;invalidate();return true;}
        if(x>=500&&x<=830&&y>=440&&y<=585){toast("Speed of Sound (20°C): 343 m/s");return true;}
        float[] rowY={769,858,947,1036,1125,1215,1304};
        for(int i=0;i<7;i++) if(x>=185&&x<=670&&Math.abs(y-rowY[i])<42){dragKind=3;dragIndex=i;state.channel=i;updateDelaySlider(i,x);invalidate();return true;}
        return true;
    }
    private void updateDelaySlider(int i,float x){delayMs[i]=round2(clamp((x-201)/(648-201)*10f,0,10));}

    private boolean handleOutputDown(float x,float y){
        if(x>=500&&x<=665&&y>=230&&y<=315){for(int i=0;i<7;i++)outMute[i]=false;invalidate();noteUnverifiedHardwareOnce();return true;}
        if(x>=670&&y>=230&&y<=315){masterOutput=-1f;float[] d={-3,-2.5f,-4,-1,-2,-3.5f,-4.5f};System.arraycopy(d,0,outLevel,0,7);invalidate();noteUnverifiedHardwareOnce();return true;}
        if(x>=580&&x<=830&&y>=410&&y<=500){dragKind=4;dragIndex=-1;updateOutputSlider(-1,x);invalidate();return true;}
        float[] rowY={607,714,821,928,1035,1142,1249};
        for(int i=0;i<7;i++) if(Math.abs(y-rowY[i])<42){
            if(x>=180&&x<=435){dragKind=4;dragIndex=i;updateOutputSlider(i,x);invalidate();return true;}
            if(x>=540&&x<622){outMute[i]=!outMute[i];}
            else if(x>=622&&x<700){outSolo[i]=!outSolo[i];}
            else if(x>=700&&x<776){outPhase[i]=!outPhase[i];}
            else if(i<2&&x>=776){outLink[0]=outLink[1]=!outLink[i];}
            invalidate();noteUnverifiedHardwareOnce();return true;
        }
        return true;
    }
    private void updateOutputSlider(int i,float x){float x0=i<0?588:194,x1=i<0?809:421;float v=round1(-60+clamp((x-x0)/(x1-x0),0,1)*72);if(i<0)masterOutput=v;else{outLevel[i]=v;if(i<2&&outLink[i])outLevel[1-i]=v;}}

    private void noteUnverifiedHardwareOnce(){
        if(ble!=null) ble.reportUnverifiedControl(page==CROSSOVER?"Crossover":page==DELAY?"Delay":"Output");
    }

    private float stepFreq(float current,boolean up){
        final float[] f={20,25,31.5f,40,50,63,80,100,125,160,200,250,315,400,500,630,800,1000,1250,1600,2000,2500,3150,4000,5000,6300,8000,10000,12500,16000,20000};
        int best=0;float d=Float.MAX_VALUE;for(int i=0;i<f.length;i++){float nd=Math.abs(f[i]-current);if(nd<d){d=nd;best=i;}}
        best=Math.max(0,Math.min(f.length-1,best+(up?1:-1)));return f[best];
    }
    private int stepSlope(int current,boolean up){int[] s={6,12,18,24,36,48};int best=0;for(int i=0;i<s.length;i++)if(s[i]==current)best=i;best=Math.max(0,Math.min(s.length-1,best+(up?1:-1)));return s[best];}

    private void saveLocalState(){
        SharedPreferences.Editor e=getContext().getSharedPreferences("okn_dsp_v1_ui",Context.MODE_PRIVATE).edit();
        e.putInt("page",page).putInt("channel",state.channel).putInt("eqPage",eqPage).putInt("seat",seatPreset).putInt("audioSource",audioSource).putInt("xoView",xoViewMode).putBoolean("delayCm",delayShowCm).putFloat("masterOut",masterOutput);
        for(int c=0;c<7;c++){
            e.putFloat("hpf"+c,hpfFreq[c]).putFloat("lpf"+c,lpfFreq[c]).putInt("hs"+c,hpfSlope[c]).putInt("ls"+c,lpfSlope[c]).putBoolean("hb"+c,hpfBypass[c]).putBoolean("lb"+c,lpfBypass[c]).putInt("ph"+c,xoPhase[c]).putBoolean("pol"+c,xoPolarityInvert[c]).putBoolean("xl"+c,xoLink[c]).putBoolean("mono"+c,xoMono[c]).putInt("ht"+c,hpfType[c]).putInt("lt"+c,lpfType[c]).putFloat("delay"+c,delayMs[c]).putFloat("out"+c,outLevel[c]).putBoolean("om"+c,outMute[c]).putBoolean("os"+c,outSolo[c]).putBoolean("op"+c,outPhase[c]).putBoolean("ol"+c,outLink[c]);
            for(int b=0;b<15;b++)e.putBoolean("ep"+c+"_"+b,eqPower[c][b]).putInt("et"+c+"_"+b,eqType[c][b]);
        }
        e.apply();
        state.saveHome(getContext()); state.saveEq(getContext());
    }
    private void loadLocalState(){
        state.loadHome(getContext()); state.loadEq(getContext());
        SharedPreferences r=getContext().getSharedPreferences("okn_dsp_v1_ui",Context.MODE_PRIVATE);
        page=Math.max(0,Math.min(4,r.getInt("page",HOME)));state.channel=Math.max(0,Math.min(6,r.getInt("channel",0)));eqPage=Math.max(0,Math.min(2,r.getInt("eqPage",0)));seatPreset=Math.max(0,Math.min(2,r.getInt("seat",0)));audioSource=Math.max(0,Math.min(1,r.getInt("audioSource",0)));xoViewMode=Math.max(0,Math.min(1,r.getInt("xoView",0)));delayShowCm=r.getBoolean("delayCm",false);masterOutput=r.getFloat("masterOut",-1f);
        for(int c=0;c<7;c++){
            hpfFreq[c]=r.getFloat("hpf"+c,100);lpfFreq[c]=r.getFloat("lpf"+c,1000);hpfSlope[c]=r.getInt("hs"+c,24);lpfSlope[c]=r.getInt("ls"+c,24);hpfBypass[c]=r.getBoolean("hb"+c,false);lpfBypass[c]=r.getBoolean("lb"+c,false);xoPhase[c]=r.getInt("ph"+c,0);xoPolarityInvert[c]=r.getBoolean("pol"+c,false);xoLink[c]=r.getBoolean("xl"+c,false);xoMono[c]=r.getBoolean("mono"+c,false);hpfType[c]=r.getInt("ht"+c,0);lpfType[c]=r.getInt("lt"+c,0);delayMs[c]=r.getFloat("delay"+c,delayMs[c]);outLevel[c]=r.getFloat("out"+c,outLevel[c]);outMute[c]=r.getBoolean("om"+c,false);outSolo[c]=r.getBoolean("os"+c,false);outPhase[c]=r.getBoolean("op"+c,false);outLink[c]=r.getBoolean("ol"+c,outLink[c]);
            for(int b=0;b<15;b++){eqPower[c][b]=r.getBoolean("ep"+c+"_"+b,true);eqType[c][b]=r.getInt("et"+c+"_"+b,eqType[c][b]);}
        }
    }

    private String filterTypeName(int i){String[] n={"Linkwitz-Riley","Butterworth","Bessel"};return n[Math.max(0,Math.min(2,i))];}
    private String delayText(float ms){return delayShowCm?String.format(Locale.US,"%.1f cm",ms*34.3f):String.format(Locale.US,"%.2f ms",ms);}
    private String channelShort(int i){String[] n={"Front L","Front R","Rear L","Rear R","Center","Sub L","Sub R"};return n[Math.max(0,Math.min(6,i))];}
    private String formatHz(float f){return f>=1000?String.format(Locale.US,f>=10000?"%.1f kHz":"%.2f kHz",f/1000f):String.format(Locale.US,"%.0f Hz",f);}
    private float roundFreq(float f){if(f<100)return Math.round(f);if(f<1000)return Math.round(f/5f)*5f;return Math.round(f/50f)*50f;}
    private float freqX(float freq,float left,float width){double frac=(Math.log(Math.max(20,freq))-Math.log(20))/(Math.log(20000)-Math.log(20));return left+(float)frac*width;}
    private float gainY(float gain,float top,float height){return top+(12-clamp(gain,-12,12))/24f*height;}
    private float clamp(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}
    private float round1(float v){return Math.round(v*10f)/10f;}
    private float round2(float v){return Math.round(v*100f)/100f;}

    private void roundPanel(Canvas c,float x,float y,float w,float h,float r,int fill,int border){p.setStyle(Paint.Style.FILL);p.setColor(fill);c.drawRoundRect(new RectF(x,y,x+w,y+h),r,r,p);stroke.setStyle(Paint.Style.STROKE);stroke.setStrokeWidth(1.5f);stroke.setColor(border);c.drawRoundRect(new RectF(x,y,x+w,y+h),r,r,stroke);}
    private void glowRect(Canvas c,float x,float y,float w,float h,float r,int color){stroke.setStyle(Paint.Style.STROKE);stroke.setStrokeWidth(2.5f);stroke.setColor(color);stroke.setShadowLayer(13,0,0,color);c.drawRoundRect(new RectF(x,y,x+w,y+h),r,r,stroke);stroke.clearShadowLayer();}
    private void divider(Canvas c,float x1,float y1,float x2,float y2){stroke.setColor(Color.rgb(20,51,79));stroke.setStrokeWidth(1);c.drawLine(x1,y1,x2,y2,stroke);}
    private void text(Canvas c,String s,float x,float y,float size,int color,boolean bold,Paint.Align align){p.setShader(null);p.setStyle(Paint.Style.FILL);p.setColor(color);p.setTextSize(size);p.setTextAlign(align);p.setTypeface(android.graphics.Typeface.create("sans",bold?android.graphics.Typeface.BOLD:android.graphics.Typeface.NORMAL));c.drawText(s,x,y,p);}
    private void toast(String s){Toast.makeText(getContext(),s,Toast.LENGTH_SHORT).show();}
}
