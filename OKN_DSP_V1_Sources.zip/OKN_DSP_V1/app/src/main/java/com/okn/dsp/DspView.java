package com.okn.dsp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import java.util.Locale;

/**
 * OKN_DSP V1 UI. The five pages are intentionally limited to the five supplied
 * 864x1536 UI references: Home, EQ, Crossover, Delay and Output.
 */
final class DspView extends View {
    private static final float W = 864f;
    private static final float H = 1536f;
    private static final float NAV_H = 145f;

    private static final int PAGE_HOME = 0;
    private static final int PAGE_EQ = 1;
    private static final int PAGE_XOVER = 2;
    private static final int PAGE_DELAY = 3;
    private static final int PAGE_OUTPUT = 4;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint s = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final DspState state = new DspState();
    private BleManager ble;

    private int page = PAGE_HOME;
    private int dragHome = -1;
    private int dragDelay = -1;
    private int dragOutput = -1;
    private boolean dragMasterOutput = false;
    private float scale = 1f;
    private float offsetX = 0f;
    private float offsetY = 0f;
    private float viewportH = H;

    private String bleStatus = "กำลังค้นหา DSP...";
    private String bleDevice = "OKN-DSP-7CH";
    private boolean bleConnected = false;
    private String diagnostic = "";

    private final int BG0 = Color.rgb(0, 5, 15);
    private final int BG1 = Color.rgb(0, 17, 35);
    private final int PANEL = Color.rgb(3, 27, 48);
    private final int PANEL_DARK = Color.rgb(2, 18, 34);
    private final int BORDER = Color.rgb(10, 78, 127);
    private final int GRID = Color.rgb(13, 48, 77);
    private final int WHITE = Color.rgb(242, 247, 255);
    private final int SUB = Color.rgb(157, 190, 225);
    private final int CYAN = Color.rgb(0, 220, 255);
    private final int BLUE = Color.rgb(0, 132, 255);
    private final int GREEN = Color.rgb(0, 238, 122);
    private final int MAGENTA = Color.rgb(245, 50, 230);
    private final int ORANGE = Color.rgb(255, 155, 38);
    private final int RED = Color.rgb(255, 57, 101);
    private final int PURPLE = Color.rgb(179, 49, 250);
    private final int YELLOW = Color.rgb(255, 213, 40);

    private final int[] chColors = {
            Color.rgb(24, 178, 255), Color.rgb(31, 222, 241), Color.rgb(24, 225, 101),
            Color.rgb(255, 215, 43), Color.rgb(255, 146, 35), Color.rgb(255, 55, 91),
            Color.rgb(198, 50, 245)
    };
    private final int[] bandColors = {
            Color.rgb(255, 65, 83), Color.rgb(255, 145, 42), Color.rgb(255, 228, 20),
            Color.rgb(0, 233, 105), Color.rgb(26, 224, 236), Color.rgb(194, 54, 244),
            Color.rgb(35, 151, 255), Color.rgb(120, 92, 255), Color.rgb(252, 67, 226),
            Color.rgb(0, 210, 255), Color.rgb(255, 108, 50), Color.rgb(90, 235, 120),
            Color.rgb(255, 195, 36), Color.rgb(80, 150, 255), Color.rgb(231, 58, 203)
    };

    DspView(Context context, BleManager manager) {
        super(context);
        ble = manager;
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        setClickable(true);
        setFocusable(true);
    }

    void setBleManager(BleManager manager) {
        ble = manager;
    }

    void setBleStatus(String status, String deviceName, boolean connected) {
        bleStatus = status == null ? "" : status;
        if (deviceName != null && !deviceName.isEmpty()) bleDevice = deviceName;
        bleConnected = connected;
        invalidate();
    }

    void setDiagnostic(String message) {
        diagnostic = message == null ? "" : message;
        invalidate();
    }

    void setScalarFromDsp(int actuatorId, float value) {
        switch (actuatorId) {
            case DspProtocol.ID_MASTER_VOLUME: state.masterVolume = value; break;
            case DspProtocol.ID_BASS_VOLUME: state.bassVolume = value; break;
            case DspProtocol.ID_BASS_CUTOFF: state.bassCutoff = value; break;
            case DspProtocol.ID_BASS_BOOST: state.bassBoost = value; break;
            case DspProtocol.ID_MIDDLE_BOOST: state.middleBoost = value; break;
            case DspProtocol.ID_TREBLE_BOOST: state.trebleBoost = value; break;
            default: return;
        }
        invalidate();
    }

    void setEqFromDsp(int channel0, int band0, float frequency, float gainDb, float q, boolean writable) {
        if (channel0 < 0 || channel0 >= DspState.CHANNELS || band0 < 0 || band0 >= DspState.BANDS) return;
        state.freq[channel0][band0] = frequency;
        state.gain[channel0][band0] = gainDb;
        state.q[channel0][band0] = q;
        state.eqWritable[channel0][band0] = writable;
        invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float widthScale = getWidth() / W;
        float virtualHeight = getHeight() / widthScale;
        if (virtualHeight >= H) {
            scale = widthScale;
            viewportH = virtualHeight;
            offsetX = 0f;
            offsetY = 0f;
        } else {
            scale = Math.min(widthScale, getHeight() / H);
            viewportH = H;
            offsetX = (getWidth() - W * scale) * 0.5f;
            offsetY = (getHeight() - H * scale) * 0.5f;
        }

        canvas.drawColor(BG0);
        canvas.save();
        canvas.translate(offsetX, offsetY);
        canvas.scale(scale, scale);
        drawBackdrop(canvas);
        if (page == PAGE_HOME) {
            drawHomeHeader(canvas);
            drawHome(canvas);
        } else {
            drawControlHeader(canvas);
            drawChannelTabs(canvas);
            if (page == PAGE_EQ) drawEq(canvas);
            else if (page == PAGE_XOVER) drawCrossover(canvas);
            else if (page == PAGE_DELAY) drawDelay(canvas);
            else drawOutput(canvas);
        }
        drawBottomNav(canvas);
        canvas.restore();
    }

    private void drawBackdrop(Canvas c) {
        p.setShader(new LinearGradient(0, 0, W, viewportH, BG1, BG0, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, W, viewportH, p);
        p.setShader(null);
    }

    private float navTop() { return viewportH - NAV_H; }

    // -----------------------------------------------------------------------------------------
    // Header
    // -----------------------------------------------------------------------------------------

    private void drawHomeHeader(Canvas c) {
        drawWaveLogo(c, 65, 55, CYAN, 1.0f);
        text(c, "OKN_", 137, 59, 47, WHITE, true, Paint.Align.LEFT);
        float w = measure("OKN_", 47, true);
        text(c, "DSP", 137 + w, 59, 47, CYAN, true, Paint.Align.LEFT);
        text(c, "Professional Audio Processor", 137, 89, 20, Color.rgb(105, 175, 230), false, Paint.Align.LEFT);
        drawConnectionChip(c, 506, 20, 255, 67);
        drawGear(c, 812, 54, 23, Color.rgb(199, 222, 255));
    }

    private void drawControlHeader(Canvas c) {
        drawWaveLogo(c, 55, 50, CYAN, 0.9f);
        text(c, "DSP Control", 112, 52, 41, WHITE, false, Paint.Align.LEFT);
        text(c, "Professional Audio Processor", 113, 80, 18, Color.rgb(97, 175, 224), false, Paint.Align.LEFT);
        drawConnectionChip(c, 516, 20, 258, 66);
        drawGear(c, 812, 53, 21, Color.rgb(203, 225, 255));
    }

    private void drawConnectionChip(Canvas c, float x, float y, float w, float h) {
        card(c, x, y, w, h, 14, Color.rgb(4, 27, 48), Color.rgb(10, 74, 126));
        p.setColor(bleConnected ? GREEN : Color.rgb(20, 208, 150));
        p.setShadowLayer(12, 0, 0, p.getColor());
        c.drawCircle(x + 37, y + h / 2, 10, p);
        p.clearShadowLayer();
        text(c, bleConnected ? "Connected" : "เชื่อมต่ออุปกรณ์", x + 69, y + 29, 19, bleConnected ? GREEN : WHITE, true, Paint.Align.LEFT);
        text(c, bleDevice, x + 69, y + 52, 16, SUB, false, Paint.Align.LEFT);
        text(c, "›", x + w - 29, y + 45, 35, SUB, false, Paint.Align.CENTER);
    }

    private void drawChannelTabs(Canvas c) {
        float y = 104;
        float x = 18;
        float gap = 7;
        float w = (W - 36 - gap * 6) / 7f;
        for (int i = 0; i < 7; i++) {
            boolean selected = state.channel == i;
            int fill = selected ? Color.rgb(0, 111, 235) : Color.rgb(2, 28, 50);
            int border = selected ? CYAN : Color.rgb(7, 78, 128);
            card(c, x + i * (w + gap), y, w, 77, 9, fill, border);
            if (selected) glow(c, x + i * (w + gap), y, w, 77, 9, CYAN);
            String[] parts = DspState.CHANNEL_SHORT[i].split("\\n");
            text(c, parts[0], x + i * (w + gap) + w / 2, y + 34, 18, WHITE, false, Paint.Align.CENTER);
            text(c, parts[1], x + i * (w + gap) + w / 2, y + 60, 16, WHITE, false, Paint.Align.CENTER);
        }
    }

    // -----------------------------------------------------------------------------------------
    // Home page
    // -----------------------------------------------------------------------------------------

    private void drawHome(Canvas c) {
        String[] titles = {"Master Volume", "Bass Volume", "Bass Cutoff", "Bass Boost", "Middle Boost", "Treble Boost"};
        String[] subs = {"ปรับระดับเสียงรวม", "ปรับระดับเสียงเบส", "ตั้งค่าความถี่ตัดเบส", "เพิ่มความหนักแน่นของเบส", "เพิ่มความชัดเจนย่านกลาง", "เพิ่มความใสย่านแหลม"};
        int[] colors = {BLUE, CYAN, MAGENTA, RED, Color.rgb(0, 151, 255), Color.rgb(210, 54, 239)};
        for (int i = 0; i < 6; i++) {
            float y = 124 + i * 148;
            card(c, 16, y, 832, 135, 20, PANEL, BORDER);
            drawHomeIcon(c, 85, y + 68, 48, colors[i], i);
            text(c, titles[i], 165, y + 57, 28, WHITE, true, Paint.Align.LEFT);
            text(c, subs[i], 165, y + 94, 19, SUB, false, Paint.Align.LEFT);
            drawHomeSlider(c, i, 382, y + 58, 286, colors[i]);
            drawHomeValue(c, i, 698, y + 28, 125, 64);
        }

        float lowerY = 1023;
        card(c, 16, lowerY, 410, 158, 18, PANEL, BORDER);
        drawMusicIcon(c, 76, lowerY + 55, CYAN);
        text(c, "Audio Source", 140, lowerY + 45, 24, WHITE, true, Paint.Align.LEFT);
        text(c, "แหล่งสัญญาณเสียง", 140, lowerY + 75, 17, SUB, false, Paint.Align.LEFT);
        card(c, 140, lowerY + 93, 267, 51, 9, PANEL_DARK, BORDER);
        text(c, state.audioSource == 0 ? "High Level (Speaker)" : "Low Level (RCA)", 155, lowerY + 126, 17, WHITE, false, Paint.Align.LEFT);
        text(c, "⌄", 383, lowerY + 126, 23, SUB, false, Paint.Align.CENTER);

        card(c, 16, lowerY + 171, 410, 166, 18, PANEL, BORDER);
        drawListIcon(c, 77, lowerY + 222, CYAN);
        text(c, "System Preset", 140, lowerY + 216, 23, WHITE, true, Paint.Align.LEFT);
        text(c, "พรีเซ็ตระบบ", 140, lowerY + 247, 17, SUB, false, Paint.Align.LEFT);
        card(c, 140, lowerY + 267, 267, 50, 9, PANEL_DARK, BORDER);
        String[] presets = {"Flat", "Pop", "Rock", "Jazz"};
        text(c, presets[state.homePreset], 155, lowerY + 299, 17, WHITE, false, Paint.Align.LEFT);
        text(c, "⌄", 383, lowerY + 299, 23, SUB, false, Paint.Align.CENTER);

        card(c, 440, lowerY, 408, 337, 18, PANEL, BORDER);
        drawChipIcon(c, 493, lowerY + 55, CYAN);
        text(c, "Device Status", 565, lowerY + 45, 23, WHITE, true, Paint.Align.LEFT);
        text(c, "สถานะอุปกรณ์", 565, lowerY + 75, 17, SUB, false, Paint.Align.LEFT);
        divider(c, 462, lowerY + 110, 825, lowerY + 110);
        statusRow(c, lowerY + 136, GREEN, "Connected", bleConnected ? bleDevice : "—");
        statusRow(c, lowerY + 191, Color.rgb(0, 226, 140), "Voltage", "— V");
        statusRow(c, lowerY + 246, Color.rgb(0, 230, 220), "Temperature", "— °C");
        statusRow(c, lowerY + 301, CYAN, "System", bleConnected ? "Normal" : "Standby");

        if (!diagnostic.isEmpty()) {
            text(c, diagnostic, 30, Math.min(navTop() - 12, lowerY + 360), 12, Color.rgb(90, 130, 165), false, Paint.Align.LEFT);
        }
    }

    private void statusRow(Canvas c, float y, int color, String left, String right) {
        p.setColor(color);
        p.setShadowLayer(10, 0, 0, color);
        c.drawCircle(480, y, 9, p);
        p.clearShadowLayer();
        text(c, left, 517, y + 7, 17, WHITE, false, Paint.Align.LEFT);
        text(c, right, 817, y + 7, 16, right.equals("Normal") ? GREEN : SUB, false, Paint.Align.RIGHT);
        if (y < 1300) divider(c, 462, y + 28, 825, y + 28);
    }

    private void drawHomeSlider(Canvas c, int idx, float x, float y, float w, int color) {
        float min, max, value;
        if (idx == 0) { min = -60; max = 12; value = state.masterVolume; }
        else if (idx == 1) { min = -12; max = 12; value = state.bassVolume; }
        else if (idx == 2) { min = 20; max = 500; value = state.bassCutoff; }
        else { min = -12; max = 12; value = idx == 3 ? state.bassBoost : idx == 4 ? state.middleBoost : state.trebleBoost; }
        float frac = clamp((value - min) / (max - min), 0, 1);
        float knob = x + frac * w;
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(14);
        p.setColor(Color.rgb(35, 75, 112));
        c.drawLine(x, y, x + w, y, p);
        if (knob > x + 1) {
            p.setShader(new LinearGradient(x, y, knob, y, color, idx == 3 ? Color.rgb(255, 118, 180) : CYAN, Shader.TileMode.CLAMP));
            p.setShadowLayer(9, 0, 0, color);
            c.drawLine(x, y, knob, y, p);
            p.clearShadowLayer();
            p.setShader(null);
        }
        p.setColor(WHITE);
        c.drawCircle(knob, y, 19, p);
        p.setStrokeCap(Paint.Cap.BUTT);
        String[] ticks = idx == 2 ? new String[]{"20", "50", "100", "200", "500"}
                : idx == 0 ? new String[]{"-60", "-40", "-20", "0", "+12"}
                : new String[]{"-12", "-6", "0", "+6", "+12"};
        for (int i = 0; i < ticks.length; i++) {
            float tx = x + i * w / (ticks.length - 1);
            s.setColor(Color.rgb(66, 117, 164));
            s.setStrokeWidth(2);
            c.drawLine(tx, y + 27, tx, y + 38, s);
            text(c, ticks[i], tx, y + 57, 15, SUB, false, Paint.Align.CENTER);
        }
    }

    private void drawHomeValue(Canvas c, int idx, float x, float y, float w, float h) {
        card(c, x, y, w, h, 11, PANEL_DARK, Color.rgb(16, 74, 122));
        String value;
        if (idx == 0) value = DspState.db(state.masterVolume);
        else if (idx == 1) value = DspState.db(state.bassVolume);
        else if (idx == 2) value = String.format(Locale.US, "%.0f Hz", state.bassCutoff);
        else if (idx == 3) value = DspState.db(state.bassBoost);
        else if (idx == 4) value = DspState.db(state.middleBoost);
        else value = DspState.db(state.trebleBoost);
        text(c, value, x + w / 2, y + 42, 25, WHITE, true, Paint.Align.CENTER);
    }

    // -----------------------------------------------------------------------------------------
    // EQ page
    // -----------------------------------------------------------------------------------------

    private void drawEq(Canvas c) {
        card(c, 16, 196, 832, 438, 18, PANEL, BORDER);
        drawWaveLogo(c, 77, 253, CYAN, 0.75f);
        text(c, "Parametric EQ", 135, 258, 34, WHITE, true, Paint.Align.LEFT);
        text(c, "ปรับแต่งความถี่เสียงอย่างละเอียด", 135, 289, 18, SUB, false, Paint.Align.LEFT);
        card(c, 485, 218, 182, 72, 9, PANEL_DARK, BORDER);
        text(c, "ช่องสัญญาณ", 501, 246, 16, SUB, false, Paint.Align.LEFT);
        text(c, "CH" + (state.channel + 1) + " - " + DspState.CHANNEL_NAME[state.channel], 501, 274, 18, WHITE, false, Paint.Align.LEFT);
        text(c, "⌄", 644, 272, 22, SUB, false, Paint.Align.CENTER);
        card(c, 679, 218, 148, 72, 9, PANEL_DARK, BORDER);
        drawResetIcon(c, 714, 254, WHITE);
        text(c, "รีเซ็ต EQ", 745, 262, 17, WHITE, false, Paint.Align.LEFT);
        drawEqGraph(c, 73, 314, 755, 270);

        float tabY = 650;
        String[] groups = {"Bands 1 - 6", "Bands 7 - 12", "Bands 13 - 15"};
        float[] xs = {18, 241, 458};
        float[] ws = {221, 215, 195};
        for (int i = 0; i < 3; i++) {
            boolean sel = state.eqPage == i;
            card(c, xs[i], tabY, ws[i], 57, 9, sel ? Color.rgb(0, 111, 235) : PANEL_DARK, sel ? CYAN : BORDER);
            if (sel) glow(c, xs[i], tabY, ws[i], 57, 9, CYAN);
            text(c, groups[i], xs[i] + ws[i] / 2, tabY + 37, 19, WHITE, false, Paint.Align.CENTER);
        }

        float tableY = 710;
        card(c, 16, tableY, 832, 469, 15, PANEL, BORDER);
        text(c, "#", 48, tableY + 43, 16, WHITE, false, Paint.Align.CENTER);
        text(c, "Type", 112, tableY + 43, 16, WHITE, false, Paint.Align.LEFT);
        text(c, "Frequency", 310, tableY + 43, 16, WHITE, false, Paint.Align.CENTER);
        text(c, "Gain", 508, tableY + 43, 16, WHITE, false, Paint.Align.CENTER);
        text(c, "Q", 665, tableY + 43, 16, WHITE, false, Paint.Align.CENTER);
        text(c, "Power", 795, tableY + 43, 16, WHITE, false, Paint.Align.CENTER);
        divider(c, 31, tableY + 58, 830, tableY + 58);

        int start = state.eqPage == 0 ? 0 : state.eqPage == 1 ? 6 : 12;
        int count = state.eqPage < 2 ? 6 : 3;
        for (int r = 0; r < count; r++) {
            int b = start + r;
            float y = tableY + 91 + r * 62;
            p.setColor(bandColors[b]);
            p.setShadowLayer(9, 0, 0, bandColors[b]);
            c.drawCircle(47, y, 11, p);
            p.clearShadowLayer();
            text(c, String.valueOf(b + 1), 77, y + 6, 16, WHITE, false, Paint.Align.LEFT);
            smallField(c, 101, y - 24, 173, 47, eqTypeName(b), false);
            smallField(c, 290, y - 24, 151, 47, DspState.hz(state.freq[state.channel][b]), false);
            smallField(c, 454, y - 24, 126, 47, DspState.db(state.gain[state.channel][b]), true);
            smallField(c, 592, y - 24, 142, 47, String.format(Locale.US, "%.2f", state.q[state.channel][b]), false);
            drawToggle(c, 754, y, state.eqPower[state.channel][b], CYAN);
            if (r < count - 1) divider(c, 33, y + 31, 830, y + 31);
        }

        float py = 1193;
        card(c, 16, py, 832, 168, 16, PANEL, BORDER);
        drawFolderIcon(c, 82, py + 61, CYAN);
        text(c, "Preset", 141, py + 52, 22, WHITE, true, Paint.Align.LEFT);
        text(c, "ชุดค่าที่ใช้งานอยู่", 141, py + 80, 16, SUB, false, Paint.Align.LEFT);
        card(c, 141, py + 94, 187, 52, 9, PANEL_DARK, BORDER);
        text(c, "Custom 1", 157, py + 128, 17, WHITE, false, Paint.Align.LEFT);
        text(c, "⌄", 306, py + 127, 22, SUB, false, Paint.Align.CENTER);
        actionButton(c, 341, py + 31, 132, 93, "▣", "Save");
        actionButton(c, 485, py + 31, 153, 93, "□", "Manage");
        text(c, "BETTER SOUND", 699, py + 113, 10, SUB, true, Paint.Align.CENTER);
        text(c, "A BRIGHTER DRIVE", 699, py + 134, 10, SUB, true, Paint.Align.CENTER);
    }

    private String eqTypeName(int band) {
        if (band == 0) return state.channel == 2 ? "Low Pass" : "Tone";
        if (band == 1 || band == 5) return band == 1 ? "Low Shelf" : "High Shelf";
        return "PEQ";
    }

    private void drawEqGraph(Canvas c, float gx, float gy, float gw, float gh) {
        p.setColor(Color.rgb(0, 14, 28));
        c.drawRect(gx, gy, gx + gw, gy + gh, p);
        s.setColor(GRID);
        s.setStrokeWidth(1);
        for (int i = 0; i <= 12; i++) {
            float x = gx + i * gw / 12f;
            c.drawLine(x, gy, x, gy + gh, s);
        }
        for (int i = 0; i <= 8; i++) {
            float y = gy + i * gh / 8f;
            c.drawLine(gx, y, gx + gw, y, s);
        }
        String[] ft = {"20", "50", "100", "200", "500", "1k", "2k", "5k", "10k", "20k"};
        float[] ff = {20,50,100,200,500,1000,2000,5000,10000,20000};
        for (int i = 0; i < ft.length; i++) text(c, ft[i], freqX(ff[i], gx, gw), gy + gh + 30, 13, SUB, false, Paint.Align.CENTER);
        text(c, "+12", gx - 17, gy + 5, 13, SUB, false, Paint.Align.RIGHT);
        text(c, "+6", gx - 17, gy + gh * .25f + 5, 13, SUB, false, Paint.Align.RIGHT);
        text(c, "0", gx - 17, gy + gh * .5f + 5, 13, SUB, false, Paint.Align.RIGHT);
        text(c, "-6", gx - 17, gy + gh * .75f + 5, 13, SUB, false, Paint.Align.RIGHT);
        text(c, "-12", gx - 17, gy + gh + 5, 13, SUB, false, Paint.Align.RIGHT);

        Path line = new Path();
        boolean first = true;
        for (int b = 0; b < DspState.BANDS; b++) {
            float x = freqX(state.freq[state.channel][b], gx, gw);
            float g = state.eqPower[state.channel][b] ? state.gain[state.channel][b] : 0f;
            float y = gainY(g, gy, gh);
            if (first) { line.moveTo(x, y); first = false; } else line.lineTo(x, y);
        }
        s.setStyle(Paint.Style.STROKE);
        s.setStrokeWidth(4);
        s.setColor(CYAN);
        s.setShadowLayer(9, 0, 0, CYAN);
        c.drawPath(line, s);
        s.clearShadowLayer();
        for (int b = 0; b < DspState.BANDS; b++) {
            float x = freqX(state.freq[state.channel][b], gx, gw);
            float g = state.eqPower[state.channel][b] ? state.gain[state.channel][b] : 0f;
            float y = gainY(g, gy, gh);
            p.setColor(bandColors[b]);
            p.setShadowLayer(12,0,0,bandColors[b]);
            c.drawCircle(x, y, 9, p);
            p.clearShadowLayer();
            p.setColor(WHITE);
            c.drawCircle(x, y, 4, p);
        }
        s.setStyle(Paint.Style.FILL);
    }

    // -----------------------------------------------------------------------------------------
    // Crossover page
    // -----------------------------------------------------------------------------------------

    private void drawCrossover(Canvas c) {
        card(c, 17, 198, 830, 470, 18, PANEL, BORDER);
        drawFilterIcon(c, 83, 258, MAGENTA, false);
        text(c, "Crossover", 165, 261, 34, WHITE, true, Paint.Align.LEFT);
        text(c, "ตั้งค่าการแบ่งความถี่", 165, 294, 18, SUB, false, Paint.Align.LEFT);
        card(c, 494, 234, 171, 58, 9, PANEL_DARK, BORDER);
        text(c, "Magnitude", 579, 271, 19, WHITE, false, Paint.Align.CENTER);
        text(c, "⌄", 640, 270, 21, SUB, false, Paint.Align.CENTER);
        card(c, 681, 234, 148, 58, 9, PANEL_DARK, BORDER);
        drawResetIcon(c, 714, 263, WHITE);
        text(c, "Reset", 767, 270, 17, WHITE, false, Paint.Align.CENTER);
        drawCrossoverGraph(c, 83, 370, 737, 242);

        drawFilterPanel(c, 684, true);
        drawFilterPanel(c, 928, false);

        float ay = 1175;
        card(c, 17, ay, 830, 206, 17, PANEL, BORDER);
        drawGear(c, 73, ay + 47, 19, CYAN);
        text(c, "Advanced Settings", 121, ay + 42, 22, WHITE, true, Paint.Align.LEFT);
        text(c, "ตั้งค่าขั้นสูง", 121, ay + 70, 16, SUB, false, Paint.Align.LEFT);
        advancedField(c, 41, ay + 88, 196, 91, "Phase", state.phaseDeg[state.channel] + "°");
        advancedField(c, 252, ay + 88, 189, 91, "Polarity", state.polarityInvert[state.channel] ? "Invert" : "Normal");
        card(c, 455, ay + 88, 143, 91, 10, PANEL_DARK, BORDER);
        text(c, "Link L/R", 525, ay + 32 + 88, 16, WHITE, false, Paint.Align.CENTER);
        drawToggle(c, 490, ay + 150, state.linkLR[state.channel], CYAN);
        advancedField(c, 612, ay + 88, 215, 91, "Output Mode", state.outputMode[state.channel] == 0 ? "Stereo" : "Mono");
    }

    private void drawFilterPanel(Canvas c, float y, boolean highPass) {
        int color = highPass ? CYAN : MAGENTA;
        card(c, 17, y, 830, 228, 17, PANEL, BORDER);
        drawFilterIcon(c, 83, y + 69, color, highPass);
        text(c, highPass ? "High Pass Filter (HPF)" : "Low Pass Filter (LPF)", 164, y + 51, 27, WHITE, true, Paint.Align.LEFT);
        text(c, highPass ? "กรองความถี่ต่ำออก" : "กรองความถี่สูงออก", 164, y + 84, 17, SUB, false, Paint.Align.LEFT);
        text(c, "Bypass", 699, y + 60, 17, WHITE, false, Paint.Align.RIGHT);
        drawToggle(c, 755, y + 55, highPass ? state.hpfBypass[state.channel] : state.lpfBypass[state.channel], color);
        filterField(c, 42, y + 113, 242, 92, "Type", "Linkwitz-Riley");
        filterField(c, 297, y + 113, 262, 92, "Frequency", DspState.hz(highPass ? state.hpfFreq[state.channel] : state.lpfFreq[state.channel]));
        filterField(c, 573, y + 113, 254, 92, "Slope", (highPass ? state.hpfSlope[state.channel] : state.lpfSlope[state.channel]) + " dB/Oct");
    }

    private void drawCrossoverGraph(Canvas c, float gx, float gy, float gw, float gh) {
        p.setColor(Color.rgb(0, 14, 28));
        c.drawRect(gx, gy, gx + gw, gy + gh, p);
        s.setColor(GRID); s.setStrokeWidth(1);
        for (int i = 0; i <= 14; i++) c.drawLine(gx + i * gw / 14f, gy, gx + i * gw / 14f, gy + gh, s);
        for (int i = 0; i <= 6; i++) c.drawLine(gx, gy + i * gh / 6f, gx + gw, gy + i * gh / 6f, s);
        float hp = freqX(state.hpfFreq[state.channel], gx, gw);
        float lp = freqX(state.lpfFreq[state.channel], gx, gw);
        float zero = gy + gh * 0.36f;
        Path hpPath = new Path();
        hpPath.moveTo(gx, gy + gh);
        hpPath.cubicTo(hp - 170, gy + gh, hp - 75, zero + 40, hp, zero);
        hpPath.lineTo(gx + gw, zero);
        s.setStyle(Paint.Style.STROKE); s.setStrokeWidth(4); s.setColor(CYAN); s.setShadowLayer(9,0,0,CYAN); c.drawPath(hpPath,s); s.clearShadowLayer();
        Path lpPath = new Path();
        lpPath.moveTo(gx, zero);
        lpPath.lineTo(lp, zero);
        lpPath.cubicTo(lp + 70, zero + 25, lp + 180, gy + gh, gx + gw, gy + gh);
        s.setColor(MAGENTA); s.setShadowLayer(9,0,0,MAGENTA); c.drawPath(lpPath,s); s.clearShadowLayer(); s.setStyle(Paint.Style.FILL);
        p.setColor(CYAN); p.setShadowLayer(10,0,0,CYAN); c.drawCircle(hp, zero, 10,p); p.clearShadowLayer(); p.setColor(WHITE); c.drawCircle(hp,zero,5,p);
        p.setColor(MAGENTA); p.setShadowLayer(10,0,0,MAGENTA); c.drawCircle(lp, zero, 10,p); p.clearShadowLayer(); p.setColor(WHITE); c.drawCircle(lp,zero,5,p);
        String[] ft={"20","50","100","200","500","1k","2k","5k","10k","20k"}; float[] ff={20,50,100,200,500,1000,2000,5000,10000,20000};
        for(int i=0;i<ft.length;i++) text(c,ft[i],freqX(ff[i],gx,gw),gy+gh+26,13,SUB,false,Paint.Align.CENTER);
        text(c,"High Pass (HPF)", 575, gy-20, 14, SUB, false, Paint.Align.CENTER);
        p.setColor(CYAN); c.drawCircle(493,gy-25,6,p);
        text(c,"Low Pass (LPF)", 756, gy-20, 14, SUB, false, Paint.Align.CENTER);
        p.setColor(MAGENTA); c.drawCircle(679,gy-25,6,p);
    }

    // -----------------------------------------------------------------------------------------
    // Delay page
    // -----------------------------------------------------------------------------------------

    private void drawDelay(Canvas c) {
        card(c, 18, 197, 829, 529, 17, PANEL, BORDER);
        drawClock(c, 80, 255, GREEN, 38);
        text(c, "Delay", 154, 260, 34, WHITE, true, Paint.Align.LEFT);
        text(c, "ตั้งค่าหน่วงเวลาเพื่อการจัดตำแหน่งเสียง", 154, 295, 18, SUB, false, Paint.Align.LEFT);
        card(c, 487, 222, 161, 58, 9, PANEL_DARK, BORDER);
        card(c, 489, 224, 78, 54, 8, Color.rgb(0, 126, 240), CYAN);
        text(c, "ms", 528, 259, 19, WHITE, false, Paint.Align.CENTER);
        text(c, "cm", 608, 259, 19, SUB, false, Paint.Align.CENTER);
        card(c, 661, 222, 168, 58, 9, PANEL_DARK, BORDER);
        drawResetIcon(c, 694, 251, WHITE);
        text(c, "ซิงค์ทุกช่อง", 758, 260, 16, WHITE, false, Paint.Align.CENTER);
        drawCarDelay(c, 54, 304, 423, 391);

        card(c, 496, 300, 333, 125, 13, PANEL_DARK, BORDER);
        drawSeatIcon(c, 540, 345, CYAN);
        text(c, "Seat Preset", 582, 333, 20, WHITE, true, Paint.Align.LEFT);
        text(c, "ตำแหน่งการฟัง", 582, 361, 15, SUB, false, Paint.Align.LEFT);
        card(c, 582, 374, 224, 40, 8, PANEL_DARK, BORDER);
        text(c, state.seatPreset == 0 ? "Driver (Left)" : "Passenger (Right)", 596, 401, 15, WHITE, false, Paint.Align.LEFT);
        text(c, "⌄", 785, 400, 20, SUB, false, Paint.Align.CENTER);

        card(c, 496, 438, 333, 138, 13, PANEL_DARK, BORDER);
        drawRulerIcon(c, 540, 481, CYAN);
        text(c, "Distance Reference", 582, 471, 19, WHITE, true, Paint.Align.LEFT);
        text(c, "อ้างอิงระยะทางเสียง", 582, 499, 15, SUB, false, Paint.Align.LEFT);
        text(c, "Speed of Sound (20°C)", 582, 533, 15, SUB, false, Paint.Align.LEFT);
        text(c, "343 m/s (34.3 cm/ms)", 582, 559, 15, SUB, false, Paint.Align.LEFT);

        card(c, 496, 589, 333, 121, 13, PANEL_DARK, BORDER);
        drawBarsIcon(c, 540, 630, CYAN);
        text(c, "Total Delay Range", 582, 620, 19, WHITE, true, Paint.Align.LEFT);
        text(c, "ช่วงหน่วงเวลาทั้งหมด", 582, 647, 15, SUB, false, Paint.Align.LEFT);
        float max = 0f; for(float v:state.delayMs) max=Math.max(max,v);
        text(c, "0.00 ms", 548, 684, 17, WHITE, true, Paint.Align.CENTER);
        text(c, String.format(Locale.US,"%.2f ms",max), 781, 684, 17, WHITE, true, Paint.Align.CENTER);
        text(c, "น้อยที่สุด", 548, 707, 12, SUB, false, Paint.Align.CENTER);
        text(c, "มากที่สุด", 781, 707, 12, SUB, false, Paint.Align.CENTER);

        float y = 742;
        for (int ch = 0; ch < 7; ch++) {
            drawDelayRow(c, ch, y + ch * 91);
        }
    }

    private void drawCarDelay(Canvas c, float x, float y, float w, float h) {
        s.setStyle(Paint.Style.STROKE); s.setStrokeWidth(2); s.setColor(Color.rgb(0, 111, 188));
        RectF body = new RectF(x + 120, y + 20, x + 315, y + 365);
        c.drawRoundRect(body, 70, 70, s);
        c.drawRoundRect(new RectF(x+155,y+95,x+205,y+175),18,18,s);
        c.drawRoundRect(new RectF(x+230,y+95,x+280,y+175),18,18,s);
        c.drawRoundRect(new RectF(x+155,y+215,x+205,y+295),18,18,s);
        c.drawRoundRect(new RectF(x+230,y+215,x+280,y+295),18,18,s);
        float[][] pt = {{100,120},{333,120},{95,270},{340,270},{215,55},{215,340},{345,340}};
        for(int ch=0; ch<7; ch++){
            float cx=x+pt[ch][0], cy=y+pt[ch][1]; int color=chColors[ch];
            p.setColor(Color.argb(45,Color.red(color),Color.green(color),Color.blue(color))); p.setShadowLayer(18,0,0,color); c.drawCircle(cx,cy,24,p); p.clearShadowLayer();
            s.setColor(color); s.setStrokeWidth(4); c.drawCircle(cx,cy,16,s); p.setColor(WHITE); c.drawCircle(cx,cy,6,p);
            text(c,String.format(Locale.US,"%.2f ms",state.delayMs[ch]), cx + (ch%2==0?-20:22), cy-31, 14, WHITE, true, ch%2==0?Paint.Align.RIGHT:Paint.Align.LEFT);
        }
        s.setStyle(Paint.Style.FILL);
    }

    private void drawDelayRow(Canvas c, int ch, float y) {
        card(c, 18, y, 829, 80, 13, PANEL, BORDER);
        p.setColor(chColors[ch]); p.setShadowLayer(10,0,0,chColors[ch]); c.drawCircle(49,y+40,14,p); p.clearShadowLayer();
        text(c,"CH"+(ch+1),83,y+31,18,WHITE,true,Paint.Align.LEFT);
        text(c,DspState.CHANNEL_NAME[ch],83,y+56,14,SUB,false,Paint.Align.LEFT);
        float x0=198,x1=646,cy=y+35;
        drawLinearTrack(c,x0,cy,x1,state.delayMs[ch]/10f,chColors[ch]);
        for(int i=0;i<=5;i++){float tx=x0+i*(x1-x0)/5f;text(c,String.valueOf(i*2),tx,y+65,12,SUB,false,Paint.Align.CENTER);}
        card(c,679,y+10,151,60,9,PANEL_DARK,BORDER);
        text(c,String.format(Locale.US,"%.2f ms",state.delayMs[ch]),754,y+36,17,WHITE,true,Paint.Align.CENTER);
        text(c,DspState.delayCm(state.delayMs[ch]),754,y+58,13,SUB,false,Paint.Align.CENTER);
    }

    // -----------------------------------------------------------------------------------------
    // Output page
    // -----------------------------------------------------------------------------------------

    private void drawOutput(Canvas c) {
        card(c, 18, 197, 829, 356, 17, PANEL, BORDER);
        drawHomeIcon(c, 83, 260, 47, ORANGE, 0);
        text(c, "Output", 172, 267, 37, WHITE, true, Paint.Align.LEFT);
        text(c, "ปรับระดับเอาต์พุตแต่ละช่อง", 172, 303, 19, SUB, false, Paint.Align.LEFT);
        card(c, 479, 236, 168, 57, 9, PANEL_DARK, BORDER);
        text(c, "⌫  All Mute Off", 563, 272, 16, WHITE, false, Paint.Align.CENTER);
        card(c, 660, 236, 167, 57, 9, PANEL_DARK, BORDER);
        drawResetIcon(c, 695, 264, WHITE);
        text(c, "Reset Levels", 756, 272, 16, WHITE, false, Paint.Align.CENTER);

        card(c, 33, 336, 529, 197, 12, Color.rgb(0,20,37), BORDER);
        text(c,"Output Level Overview",52,367,17,WHITE,false,Paint.Align.LEFT);
        for(int ch=0;ch<7;ch++) drawMeter(c,86+ch*64,392,28,91,chColors[ch],state.outputGain[ch]);
        card(c, 575, 336, 253, 197, 12, Color.rgb(0,20,37), BORDER);
        text(c,"Master Output",594,382,18,WHITE,false,Paint.Align.LEFT);
        card(c,724,353,92,50,9,PANEL_DARK,BORDER);
        text(c,DspState.db(state.masterOutput),770,385,18,WHITE,true,Paint.Align.CENTER);
        drawLinearTrack(c,594,448,806,(state.masterOutput+60f)/72f,CYAN);
        String[] mt={"-60","-40","-20","0","+12"}; for(int i=0;i<5;i++) text(c,mt[i],594+i*(212f/4),493,13,SUB,false,Paint.Align.CENTER);

        float y=570;
        for(int ch=0;ch<7;ch++) drawOutputRow(c,ch,y+ch*104);
    }

    private void drawMeter(Canvas c, float x, float y, float bw, float h, int color, float value) {
        int bars=10; float active=clamp((value+60f)/72f,0,1)*bars;
        for(int i=0;i<bars;i++){
            float yy=y+h-(i+1)*(h/bars)+2;
            p.setColor(i<active?color:Color.rgb(9,45,70));
            if(i<active){p.setShadowLayer(7,0,0,color);} c.drawRoundRect(new RectF(x,yy,x+bw,yy+h/bars-4),2,2,p); p.clearShadowLayer();
        }
        text(c,"CH"+((int)((x-86)/64)+1),x+bw/2,y+h+25,13,WHITE,false,Paint.Align.CENTER);
    }

    private void drawOutputRow(Canvas c, int ch, float y) {
        card(c,18,y,829,92,13,PANEL,BORDER);
        p.setColor(chColors[ch]); p.setShadowLayer(12,0,0,chColors[ch]); c.drawCircle(61,y+34,24,p); p.clearShadowLayer();
        text(c,String.valueOf(ch+1),61,y+41,20,WHITE,true,Paint.Align.CENTER);
        text(c,"CH"+(ch+1),108,y+32,18,WHITE,true,Paint.Align.LEFT);
        text(c,DspState.CHANNEL_NAME[ch],108,y+58,14,SUB,false,Paint.Align.LEFT);
        drawLinearTrack(c,196,y+34,425,(state.outputGain[ch]+60f)/72f,chColors[ch]);
        card(c,441,y+12,91,50,8,PANEL_DARK,BORDER);
        text(c,DspState.db(state.outputGain[ch]),486,y+44,16,WHITE,true,Paint.Align.CENTER);
        tinyAction(c,548,y+10,58,62,"♩","Mute",state.outputMute[ch]);
        tinyAction(c,616,y+10,58,62,"◉","Solo",state.outputSolo[ch]);
        tinyAction(c,684,y+10,58,62,"Ø","Phase",state.outputPhase[ch]);
        if(ch<2) tinyAction(c,752,y+10,76,62,"↗","Link",state.outputLink[ch]);
    }

    // -----------------------------------------------------------------------------------------
    // Navigation and touch
    // -----------------------------------------------------------------------------------------

    private void drawBottomNav(Canvas c) {
        float y = navTop() + 8;
        card(c, 16, y, 832, NAV_H - 20, 17, Color.rgb(2, 20, 36), BORDER);
        String[] labels={"Home","EQ","Crossover","Delay","Output"};
        for(int i=0;i<5;i++){
            float x=20+i*165.4f; boolean sel=page==i;
            if(sel){card(c,x,y+5,164,112,14,Color.rgb(0,83,210),CYAN); glow(c,x,y+5,164,112,14,BLUE);}
            float cx=x+82, iy=y+43; int color=sel?CYAN:Color.rgb(177,213,249);
            if(i==0) drawHomeNav(c,cx,iy,color); else if(i==1) drawWaveMini(c,cx,iy,color); else if(i==2) drawXoverMini(c,cx,iy,color); else if(i==3) drawClock(c,cx,iy,color,21); else drawBarsIcon(c,cx,iy,color);
            text(c,labels[i],cx,y+96,18,sel?WHITE:SUB,false,Paint.Align.CENTER);
        }
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        float x=(e.getX()-offsetX)/scale;
        float y=(e.getY()-offsetY)/scale;
        if(e.getAction()==MotionEvent.ACTION_DOWN){
            if(y>=navTop()){ int idx=(int)((x-18)/165.4f); if(idx>=0&&idx<5){page=idx; dragHome=dragDelay=dragOutput=-1; invalidate(); return true;} }
            if(x>=495 && y<=95){ if(ble!=null){ if(ble.isDspReady()) ble.requestDspRefresh(); else ble.startScan(); } return true; }
            if(page!=PAGE_HOME && y>=104 && y<=181){ selectChannel(x); return true; }
            if(page==PAGE_HOME) return homeDown(x,y);
            if(page==PAGE_EQ) return eqDown(x,y);
            if(page==PAGE_XOVER) return crossoverDown(x,y);
            if(page==PAGE_DELAY) return delayDown(x,y);
            if(page==PAGE_OUTPUT) return outputDown(x,y);
        } else if(e.getAction()==MotionEvent.ACTION_MOVE){
            if(dragHome>=0){ updateHome(dragHome,x); return true; }
            if(dragDelay>=0){ updateDelay(dragDelay,x); return true; }
            if(dragMasterOutput){ updateMasterOutput(x); return true; }
            if(dragOutput>=0){ updateOutput(dragOutput,x); return true; }
        } else if(e.getAction()==MotionEvent.ACTION_UP || e.getAction()==MotionEvent.ACTION_CANCEL){
            if(dragHome>=0){ int idx=dragHome; dragHome=-1; if(ble!=null) ble.flushScalarRealtime(homeActuator(idx)); invalidate(); return true; }
            if(dragDelay>=0){ dragDelay=-1; unsupported("Delay"); return true; }
            if(dragMasterOutput){ dragMasterOutput=false; unsupported("Master Output"); return true; }
            if(dragOutput>=0){ dragOutput=-1; unsupported("Output Level"); return true; }
        }
        return true;
    }

    private void selectChannel(float x) {
        float gap=7,w=(W-36-gap*6)/7f;
        int ch=(int)((x-18)/(w+gap));
        if(ch>=0&&ch<7){state.channel=ch;invalidate();}
    }

    private boolean homeDown(float x,float y){
        for(int i=0;i<6;i++){
            float ry=124+i*148;
            if(y>=ry+22&&y<=ry+108&&x>=350&&x<=690){dragHome=i;updateHome(i,x);return true;}
        }
        if(x>=140&&x<=407&&y>=1116&&y<=1167){state.audioSource=1-state.audioSource;unsupported("Audio Source");invalidate();return true;}
        if(x>=140&&x<=407&&y>=1290&&y<=1345){state.applyHomePreset((state.homePreset+1)%4);sendAllHomeTonal();invalidate();return true;}
        return true;
    }

    private void updateHome(int idx,float x){
        float frac=clamp((x-382f)/286f,0,1);
        if(idx==0) state.masterVolume=round1(-60f+72f*frac);
        else if(idx==1) state.bassVolume=round1(-12f+24f*frac);
        else if(idx==2){double min=Math.log(20),max=Math.log(500);state.bassCutoff=Math.round((float)Math.exp(min+frac*(max-min)));}
        else if(idx==3) state.bassBoost=round1(-12f+24f*frac);
        else if(idx==4) state.middleBoost=round1(-12f+24f*frac);
        else state.trebleBoost=round1(-12f+24f*frac);
        sendHome(idx); invalidate();
    }

    private int homeActuator(int idx){
        if(idx==0)return DspProtocol.ID_MASTER_VOLUME; if(idx==1)return DspProtocol.ID_BASS_VOLUME; if(idx==2)return DspProtocol.ID_BASS_CUTOFF; if(idx==3)return DspProtocol.ID_BASS_BOOST; if(idx==4)return DspProtocol.ID_MIDDLE_BOOST; return DspProtocol.ID_TREBLE_BOOST;
    }
    private void sendHome(int idx){if(ble!=null)ble.setScalarRealtime(homeActuator(idx), idx==0?state.masterVolume:idx==1?state.bassVolume:idx==2?state.bassCutoff:idx==3?state.bassBoost:idx==4?state.middleBoost:state.trebleBoost);}
    private void sendAllHomeTonal(){for(int i=1;i<6;i++)sendHome(i);}

    private boolean eqDown(float x,float y){
        if(y>=650&&y<=707){ if(x<240)state.eqPage=0; else if(x<458)state.eqPage=1; else state.eqPage=2; invalidate(); return true; }
        if(x>=679&&x<=827&&y>=218&&y<=290){ for(int b=0;b<15;b++){state.gain[state.channel][b]=0f; if(state.eqWritable[state.channel][b]&&ble!=null)ble.setEqRealtime(state.channel,b,state.freq[state.channel][b],0f,state.q[state.channel][b]);} invalidate(); return true; }
        int start=state.eqPage==0?0:state.eqPage==1?6:12, count=state.eqPage<2?6:3;
        for(int r=0;r<count;r++){
            int b=start+r;float yy=710+91+r*62;
            if(y>=yy-27&&y<=yy+27){
                if(x>=454&&x<=580){ float delta=x<517?-0.5f:0.5f; state.gain[state.channel][b]=clamp(round1(state.gain[state.channel][b]+delta),-12,12); if(state.eqWritable[state.channel][b]&&ble!=null)ble.setEqRealtime(state.channel,b,state.freq[state.channel][b],state.gain[state.channel][b],state.q[state.channel][b]); else unsupported("EQ Band "+(b+1)); invalidate(); return true; }
                if(x>=754&&x<=834){state.eqPower[state.channel][b]=!state.eqPower[state.channel][b];unsupported("EQ Power");invalidate();return true;}
                if(x>=290&&x<=441){unsupported("EQ Frequency");return true;}
                if(x>=592&&x<=734){unsupported("EQ Q");return true;}
            }
        }
        if(y>=1224&&y<=1320&&x>=341&&x<=473){state.saveEq(getContext());toast("บันทึก Custom 1 แล้ว");return true;}
        if(y>=1224&&y<=1320&&x>=485&&x<=638){boolean ok=state.loadEq(getContext());if(ok){for(int b=0;b<15;b++)if(state.eqWritable[state.channel][b]&&ble!=null)ble.setEqRealtime(state.channel,b,state.freq[state.channel][b],state.gain[state.channel][b],state.q[state.channel][b]);}toast(ok?"โหลด Custom 1 แล้ว":"ยังไม่มี Custom 1");invalidate();return true;}
        return true;
    }

    private boolean crossoverDown(float x,float y){
        int ch=state.channel;
        if(x>=681&&x<=829&&y>=234&&y<=292){state.hpfFreq[ch]=100;state.lpfFreq[ch]=1000;state.hpfSlope[ch]=24;state.lpfSlope[ch]=24;state.hpfBypass[ch]=state.lpfBypass[ch]=false;unsupported("Crossover Reset");invalidate();return true;}
        if(y>=684&&y<=912){
            if(x>=740&&y<=780){state.hpfBypass[ch]=!state.hpfBypass[ch];unsupported("HPF Bypass");invalidate();return true;}
            if(x>=297&&x<=559&&y>=797&&y<=889){state.hpfFreq[ch]=nextFreq(state.hpfFreq[ch]);unsupported("HPF Frequency");invalidate();return true;}
            if(x>=573&&x<=827&&y>=797&&y<=889){state.hpfSlope[ch]=nextSlope(state.hpfSlope[ch]);unsupported("HPF Slope");invalidate();return true;}
        }
        if(y>=928&&y<=1156){
            if(x>=740&&y<=1024){state.lpfBypass[ch]=!state.lpfBypass[ch];unsupported("LPF Bypass");invalidate();return true;}
            if(x>=297&&x<=559&&y>=1041&&y<=1133){state.lpfFreq[ch]=nextFreq(state.lpfFreq[ch]);unsupported("LPF Frequency");invalidate();return true;}
            if(x>=573&&x<=827&&y>=1041&&y<=1133){state.lpfSlope[ch]=nextSlope(state.lpfSlope[ch]);unsupported("LPF Slope");invalidate();return true;}
        }
        if(y>=1263&&y<=1354){
            if(x<237){state.phaseDeg[ch]=(state.phaseDeg[ch]+45)%360;unsupported("Phase");}
            else if(x<441){state.polarityInvert[ch]=!state.polarityInvert[ch];unsupported("Polarity");}
            else if(x<598){state.linkLR[ch]=!state.linkLR[ch];unsupported("Link L/R");}
            else {state.outputMode[ch]=1-state.outputMode[ch];unsupported("Output Mode");}
            invalidate();return true;
        }
        return true;
    }

    private float nextFreq(float v){float[] a={20,32,50,63,80,100,125,160,200,250,315,400,500,630,800,1000,1250,1600,2000,2500,3150,4000,5000,6300,8000,10000,12500,16000,20000};for(float n:a)if(n>v+1)return n;return 20;}
    private int nextSlope(int v){return v==12?18:v==18?24:v==24?36:v==36?48:12;}

    private boolean delayDown(float x,float y){
        if(x>=661&&x<=829&&y>=222&&y<=280){float mx=0;for(float v:state.delayMs)mx=Math.max(mx,v);for(int i=0;i<7;i++)state.delayMs[i]=mx;unsupported("Sync Delay");invalidate();return true;}
        if(x>=582&&x<=806&&y>=374&&y<=414){state.seatPreset=1-state.seatPreset;unsupported("Seat Preset");invalidate();return true;}
        for(int ch=0;ch<7;ch++){float ry=742+ch*91;if(y>=ry&&y<=ry+80&&x>=180&&x<=660){dragDelay=ch;updateDelay(ch,x);return true;}}
        return true;
    }
    private void updateDelay(int ch,float x){state.delayMs[ch]=Math.round(clamp((x-198f)/(646f-198f),0,1)*1000f)/100f;invalidate();}

    private boolean outputDown(float x,float y){
        if(x>=479&&x<=647&&y>=236&&y<=293){for(int i=0;i<7;i++)state.outputMute[i]=false;unsupported("All Mute Off");invalidate();return true;}
        if(x>=660&&x<=827&&y>=236&&y<=293){state.masterOutput=-1;float[] d={-3f,-2.5f,-4f,-1f,-2f,-3.5f,-4.5f};System.arraycopy(d,0,state.outputGain,0,7);unsupported("Reset Levels");invalidate();return true;}
        if(y>=420&&y<=485&&x>=580&&x<=825){dragMasterOutput=true;updateMasterOutput(x);return true;}
        for(int ch=0;ch<7;ch++){
            float ry=570+ch*104;
            if(y>=ry&&y<=ry+92){
                if(x>=185&&x<=435){dragOutput=ch;updateOutput(ch,x);return true;}
                if(x>=548&&x<=606){state.outputMute[ch]=!state.outputMute[ch];unsupported("Output Mute");invalidate();return true;}
                if(x>=616&&x<=674){state.outputSolo[ch]=!state.outputSolo[ch];unsupported("Output Solo");invalidate();return true;}
                if(x>=684&&x<=742){state.outputPhase[ch]=!state.outputPhase[ch];unsupported("Output Phase");invalidate();return true;}
                if(ch<2&&x>=752&&x<=828){state.outputLink[ch]=!state.outputLink[ch];unsupported("Output Link");invalidate();return true;}
            }
        }
        return true;
    }
    private void updateMasterOutput(float x){float f=clamp((x-594f)/(806f-594f),0,1);state.masterOutput=round1(-60+72*f);invalidate();}
    private void updateOutput(int ch,float x){float f=clamp((x-196f)/(425f-196f),0,1);state.outputGain[ch]=round1(-60+72*f);invalidate();}

    private void unsupported(String name){ if(ble!=null)ble.reportUnverifiedControl(name); }

    // -----------------------------------------------------------------------------------------
    // Drawing primitives and icons
    // -----------------------------------------------------------------------------------------

    private void card(Canvas c,float x,float y,float w,float h,float r,int fill,int border){p.setStyle(Paint.Style.FILL);p.setColor(fill);c.drawRoundRect(new RectF(x,y,x+w,y+h),r,r,p);s.setStyle(Paint.Style.STROKE);s.setStrokeWidth(1.4f);s.setColor(border);c.drawRoundRect(new RectF(x,y,x+w,y+h),r,r,s);s.setStyle(Paint.Style.FILL);}
    private void glow(Canvas c,float x,float y,float w,float h,float r,int color){s.setStyle(Paint.Style.STROKE);s.setStrokeWidth(2.4f);s.setColor(color);s.setShadowLayer(16,0,0,color);c.drawRoundRect(new RectF(x,y,x+w,y+h),r,r,s);s.clearShadowLayer();s.setStyle(Paint.Style.FILL);}
    private void divider(Canvas c,float x1,float y1,float x2,float y2){s.setStyle(Paint.Style.STROKE);s.setStrokeWidth(1);s.setColor(Color.rgb(17,54,83));c.drawLine(x1,y1,x2,y2,s);s.setStyle(Paint.Style.FILL);}
    private void text(Canvas c,String v,float x,float y,float size,int color,boolean bold,Paint.Align align){p.setShader(null);p.setStyle(Paint.Style.FILL);p.setColor(color);p.setTextSize(size);p.setTextAlign(align);p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));c.drawText(v,x,y,p);}
    private float measure(String v,float size,boolean bold){p.setTextSize(size);p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));return p.measureText(v);}
    private float clamp(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}
    private float round1(float v){return Math.round(v*10f)/10f;}
    private float freqX(float f,float gx,float gw){double a=Math.log(20),b=Math.log(20000);return gx+(float)((Math.log(clamp(f,20,20000))-a)/(b-a))*gw;}
    private float gainY(float g,float gy,float gh){return gy+(12-clamp(g,-12,12))/24f*gh;}
    private void toast(String m){Toast.makeText(getContext(),m,Toast.LENGTH_SHORT).show();}

    private void drawLinearTrack(Canvas c,float x0,float y,float x1,float frac,int color){frac=clamp(frac,0,1);float k=x0+(x1-x0)*frac;p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeWidth(11);p.setColor(Color.rgb(35,74,109));c.drawLine(x0,y,x1,y,p);p.setShader(new LinearGradient(x0,y,k,y,color,CYAN,Shader.TileMode.CLAMP));p.setShadowLayer(7,0,0,color);c.drawLine(x0,y,k,y,p);p.clearShadowLayer();p.setShader(null);p.setColor(WHITE);c.drawCircle(k,y,15,p);p.setStrokeCap(Paint.Cap.BUTT);}
    private void drawToggle(Canvas c,float x,float cy,boolean on,int color){float w=70,h=39;card(c,x,cy-h/2,w,h,h/2,on?Color.rgb(0,115,205):Color.rgb(38,61,91),on?color:Color.rgb(55,82,113));float kx=on?x+w-19:x+19;p.setColor(WHITE);if(on)p.setShadowLayer(8,0,0,color);c.drawCircle(kx,cy,15,p);p.clearShadowLayer();}
    private void smallField(Canvas c,float x,float y,float w,float h,String value,boolean arrows){card(c,x,y,w,h,7,PANEL_DARK,BORDER);if(arrows)text(c,"‹",x+15,y+31,22,SUB,false,Paint.Align.CENTER);text(c,value,x+w/2,y+31,15,WHITE,false,Paint.Align.CENTER);if(arrows)text(c,"›",x+w-15,y+31,22,SUB,false,Paint.Align.CENTER);}
    private void actionButton(Canvas c,float x,float y,float w,float h,String icon,String label){card(c,x,y,w,h,10,Color.rgb(2,30,53),BORDER);text(c,icon,x+w/2,y+42,31,WHITE,true,Paint.Align.CENTER);text(c,label,x+w/2,y+75,15,SUB,false,Paint.Align.CENTER);}
    private void filterField(Canvas c,float x,float y,float w,float h,String label,String value){card(c,x,y,w,h,9,Color.rgb(2,28,49),BORDER);text(c,label,x+15,y+31,16,WHITE,false,Paint.Align.LEFT);card(c,x+12,y+45,w-24,39,7,PANEL_DARK,BORDER);text(c,value,x+24,y+70,17,WHITE,false,Paint.Align.LEFT);text(c,"⌄",x+w-35,y+70,21,SUB,false,Paint.Align.CENTER);}
    private void advancedField(Canvas c,float x,float y,float w,float h,String label,String value){card(c,x,y,w,h,9,Color.rgb(2,28,49),BORDER);text(c,label,x+16,y+31,15,WHITE,false,Paint.Align.LEFT);card(c,x+12,y+46,w-24,34,7,PANEL_DARK,BORDER);text(c,"‹",x+26,y+70,19,SUB,false,Paint.Align.CENTER);text(c,value,x+w/2,y+70,16,WHITE,false,Paint.Align.CENTER);text(c,"›",x+w-26,y+70,19,SUB,false,Paint.Align.CENTER);}
    private void tinyAction(Canvas c,float x,float y,float w,float h,String icon,String label,boolean on){card(c,x,y,w,h,8,on?Color.rgb(0,81,159):PANEL_DARK,on?CYAN:BORDER);text(c,icon,x+w/2,y+27,19,on?CYAN:WHITE,false,Paint.Align.CENTER);text(c,label,x+w/2,y+49,11,on?WHITE:SUB,false,Paint.Align.CENTER);}

    private void drawWaveLogo(Canvas c,float cx,float cy,int color,float mul){p.setColor(color);p.setShadowLayer(12,0,0,color);float[] hh={24,42,64,76,57,39,23};for(int i=0;i<hh.length;i++){float xx=cx+(i-3)*12*mul;float h=hh[i]*mul;c.drawRoundRect(new RectF(xx-4*mul,cy-h/2,xx+4*mul,cy+h/2),4,4,p);}p.clearShadowLayer();}
    private void drawWaveMini(Canvas c,float cx,float cy,int color){s.setStyle(Paint.Style.STROKE);s.setStrokeWidth(3);s.setColor(color);Path q=new Path();q.moveTo(cx-31,cy);q.lineTo(cx-24,cy);q.lineTo(cx-18,cy-14);q.lineTo(cx-10,cy+16);q.lineTo(cx-1,cy-25);q.lineTo(cx+8,cy+21);q.lineTo(cx+17,cy-13);q.lineTo(cx+24,cy);q.lineTo(cx+32,cy);c.drawPath(q,s);s.setStyle(Paint.Style.FILL);}
    private void drawGear(Canvas c,float cx,float cy,float r,int color){s.setStyle(Paint.Style.STROKE);s.setStrokeWidth(3);s.setColor(color);c.drawCircle(cx,cy,r,s);c.drawCircle(cx,cy,r*.35f,s);for(int i=0;i<8;i++){double a=i*Math.PI/4;float x1=cx+(float)Math.cos(a)*r,y1=cy+(float)Math.sin(a)*r,x2=cx+(float)Math.cos(a)*(r+8),y2=cy+(float)Math.sin(a)*(r+8);c.drawLine(x1,y1,x2,y2,s);}s.setStyle(Paint.Style.FILL);}
    private void drawHomeIcon(Canvas c,float cx,float cy,float r,int color,int type){p.setColor(Color.argb(25,Color.red(color),Color.green(color),Color.blue(color)));p.setShadowLayer(18,0,0,color);c.drawCircle(cx,cy,r,p);p.clearShadowLayer();s.setStyle(Paint.Style.STROKE);s.setStrokeWidth(3);s.setColor(color);c.drawCircle(cx,cy,r,s);s.setStyle(Paint.Style.FILL);if(type==0){Path sp=new Path();sp.moveTo(cx-23,cy-9);sp.lineTo(cx-8,cy-9);sp.lineTo(cx+8,cy-23);sp.lineTo(cx+8,cy+23);sp.lineTo(cx-8,cy+9);sp.lineTo(cx-23,cy+9);sp.close();p.setColor(color);c.drawPath(sp,p);s.setStyle(Paint.Style.STROKE);s.setStrokeWidth(3);s.setColor(color);c.drawArc(new RectF(cx+3,cy-22,cx+38,cy+22),-48,96,false,s);c.drawArc(new RectF(cx+1,cy-31,cx+51,cy+31),-45,90,false,s);s.setStyle(Paint.Style.FILL);}else if(type==1){s.setStyle(Paint.Style.STROKE);s.setStrokeWidth(5);s.setColor(color);c.drawCircle(cx,cy,20,s);c.drawCircle(cx,cy,8,s);s.setStyle(Paint.Style.FILL);}else if(type==2){s.setStyle(Paint.Style.STROKE);s.setStrokeWidth(4);s.setColor(color);c.drawLine(cx-25,cy-18,cx+24,cy-18,s);c.drawLine(cx-9,cy-18,cx-9,cy+24,s);c.drawLine(cx-9,cy-18,cx+20,cy+3,s);s.setStyle(Paint.Style.FILL);}else if(type==3){p.setColor(color);for(int i=0;i<6;i++)c.drawRoundRect(new RectF(cx-27+i*10,cy+20-i*8,cx-21+i*10,cy+25),2,2,p);}else if(type==4){s.setStyle(Paint.Style.STROKE);s.setStrokeWidth(4);s.setColor(color);Path q=new Path();q.moveTo(cx-28,cy+3);q.lineTo(cx-18,cy+3);q.lineTo(cx-10,cy-17);q.lineTo(cx,cy+20);q.lineTo(cx+11,cy-9);q.lineTo(cx+20,cy+7);q.lineTo(cx+29,cy+7);c.drawPath(q,s);s.setStyle(Paint.Style.FILL);}else{p.setColor(color);Path star=new Path();for(int i=0;i<8;i++){double a=-Math.PI/2+i*Math.PI/4;float rr=i%2==0?24:9;float xx=cx+(float)Math.cos(a)*rr,yy=cy+(float)Math.sin(a)*rr;if(i==0)star.moveTo(xx,yy);else star.lineTo(xx,yy);}star.close();c.drawPath(star,p);}}
    private void drawMusicIcon(Canvas c,float cx,float cy,int color){card(c,cx-38,cy-38,76,76,13,Color.rgb(1,48,87),BORDER);s.setStyle(Paint.Style.STROKE);s.setStrokeWidth(4);s.setColor(color);c.drawLine(cx+7,cy-23,cx+7,cy+17,s);c.drawLine(cx+7,cy-23,cx+26,cy-28,s);c.drawLine(cx+26,cy-28,cx+26,cy+10,s);c.drawCircle(cx,cy+21,9,s);c.drawCircle(cx+19,cy+14,9,s);s.setStyle(Paint.Style.FILL);}
    private void drawListIcon(Canvas c,float cx,float cy,int color){card(c,cx-38,cy-38,76,76,13,Color.rgb(1,48,87),BORDER);s.setStyle(Paint.Style.STROKE);s.setStrokeWidth(5);s.setStrokeCap(Paint.Cap.ROUND);s.setColor(color);for(int i=-1;i<=1;i++)c.drawLine(cx-19,cy+i*15,cx+20,cy+i*15,s);s.setStrokeCap(Paint.Cap.BUTT);s.setStyle(Paint.Style.FILL);}
    private void drawChipIcon(Canvas c,float cx,float cy,int color){card(c,cx-38,cy-38,76,76,13,Color.rgb(1,48,87),BORDER);s.setStyle(Paint.Style.STROKE);s.setStrokeWidth(3);s.setColor(color);c.drawRect(cx-16,cy-16,cx+16,cy+16,s);for(int i=-1;i<=1;i++){c.drawLine(cx-26,cy+i*10,cx-16,cy+i*10,s);c.drawLine(cx+16,cy+i*10,cx+26,cy+i*10,s);c.drawLine(cx+i*10,cy-26,cx+i*10,cy-16,s);c.drawLine(cx+i*10,cy+16,cx+i*10,cy+26,s);}s.setStyle(Paint.Style.FILL);}
    private void drawFolderIcon(Canvas c,float cx,float cy,int color){card(c,cx-39,cy-39,78,78,12,Color.rgb(1,48,87),BORDER);s.setStyle(Paint.Style.STROKE);s.setStrokeWidth(4);s.setColor(color);Path q=new Path();q.moveTo(cx-24,cy-16);q.lineTo(cx-5,cy-16);q.lineTo(cx+2,cy-8);q.lineTo(cx+26,cy-8);q.lineTo(cx+26,cy+20);q.lineTo(cx-24,cy+20);q.close();c.drawPath(q,s);s.setStyle(Paint.Style.FILL);}
    private void drawResetIcon(Canvas c,float cx,float cy,int color){s.setStyle(Paint.Style.STROKE);s.setStrokeWidth(3);s.setColor(color);c.drawArc(new RectF(cx-16,cy-16,cx+16,cy+16),40,285,false,s);Path q=new Path();q.moveTo(cx+13,cy-14);q.lineTo(cx+21,cy-12);q.lineTo(cx+16,cy-5);c.drawPath(q,s);s.setStyle(Paint.Style.FILL);}
    private void drawFilterIcon(Canvas c,float cx,float cy,int color,boolean high){p.setColor(Color.argb(25,Color.red(color),Color.green(color),Color.blue(color)));p.setShadowLayer(16,0,0,color);c.drawCircle(cx,cy,45,p);p.clearShadowLayer();s.setStyle(Paint.Style.STROKE);s.setStrokeWidth(3);s.setColor(color);c.drawCircle(cx,cy,45,s);Path q=new Path();if(high){q.moveTo(cx-26,cy+15);q.cubicTo(cx-15,cy+15,cx-12,cy-18,cx+8,cy-18);q.lineTo(cx+28,cy-18);}else{q.moveTo(cx-27,cy-18);q.lineTo(cx-5,cy-18);q.cubicTo(cx+12,cy-18,cx+14,cy+17,cx+29,cy+17);}c.drawPath(q,s);s.setStyle(Paint.Style.FILL);}
    private void drawClock(Canvas c,float cx,float cy,int color,float r){s.setStyle(Paint.Style.STROKE);s.setStrokeWidth(3);s.setColor(color);c.drawCircle(cx,cy,r,s);c.drawLine(cx,cy,cx,cy-r*.55f,s);c.drawLine(cx,cy,cx+r*.38f,cy+r*.25f,s);s.setStyle(Paint.Style.FILL);}
    private void drawSeatIcon(Canvas c,float cx,float cy,int color){s.setStyle(Paint.Style.STROKE);s.setStrokeWidth(3);s.setColor(color);c.drawCircle(cx,cy-14,7,s);c.drawRoundRect(new RectF(cx-10,cy-7,cx+10,cy+16),5,5,s);c.drawLine(cx-15,cy+15,cx+15,cy+15,s);s.setStyle(Paint.Style.FILL);}
    private void drawRulerIcon(Canvas c,float cx,float cy,int color){s.setStyle(Paint.Style.STROKE);s.setStrokeWidth(3);s.setColor(color);c.save();c.rotate(-42,cx,cy);c.drawRect(cx-22,cy-7,cx+22,cy+7,s);for(int i=-15;i<=15;i+=10)c.drawLine(cx+i,cy-7,cx+i,cy,s);c.restore();s.setStyle(Paint.Style.FILL);}
    private void drawBarsIcon(Canvas c,float cx,float cy,int color){p.setColor(color);float[] hh={17,29,42,55};for(int i=0;i<4;i++)c.drawRoundRect(new RectF(cx-23+i*14,cy+28-hh[i],cx-17+i*14,cy+28),2,2,p);}
    private void drawHomeNav(Canvas c,float cx,float cy,int color){s.setStyle(Paint.Style.STROKE);s.setStrokeWidth(4);s.setColor(color);Path q=new Path();q.moveTo(cx-24,cy);q.lineTo(cx,cy-21);q.lineTo(cx+24,cy);q.lineTo(cx+19,cy);q.lineTo(cx+19,cy+22);q.lineTo(cx+5,cy+22);q.lineTo(cx+5,cy+8);q.lineTo(cx-5,cy+8);q.lineTo(cx-5,cy+22);q.lineTo(cx-19,cy+22);q.lineTo(cx-19,cy);q.close();c.drawPath(q,s);s.setStyle(Paint.Style.FILL);}
    private void drawXoverMini(Canvas c,float cx,float cy,int color){s.setStyle(Paint.Style.STROKE);s.setStrokeWidth(3);s.setColor(color);Path q=new Path();q.moveTo(cx-29,cy-13);q.cubicTo(cx-8,cy-13,cx-7,cy+13,cx+4,cy+13);q.lineTo(cx+29,cy+13);c.drawPath(q,s);Path z=new Path();z.moveTo(cx-29,cy+13);z.cubicTo(cx-8,cy+13,cx-7,cy-13,cx+4,cy-13);z.lineTo(cx+29,cy-13);c.drawPath(z,s);s.setStyle(Paint.Style.FILL);}
}
