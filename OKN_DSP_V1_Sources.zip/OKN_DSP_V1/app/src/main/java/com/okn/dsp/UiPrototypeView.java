package com.okn.dsp;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

/**
 * OKN_DSP V1 / STEP 1
 *
 * Visual-only UI prototype. The five supplied UI reference screens are the
 * authoritative visual source. No BLE/DSP protocol logic is intentionally
 * enabled in this version.
 */
public final class UiPrototypeView extends View {
    private static final int PAGE_HOME = 0;
    private static final int PAGE_EQ = 1;
    private static final int PAGE_CROSSOVER = 2;
    private static final int PAGE_DELAY = 3;
    private static final int PAGE_OUTPUT = 4;

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Bitmap[] pages = new Bitmap[5];
    private int page = PAGE_HOME;

    public UiPrototypeView(Context context) {
        super(context);
        setBackgroundColor(Color.rgb(0, 6, 17));
        pages[PAGE_HOME] = BitmapFactory.decodeResource(getResources(), R.drawable.ui_home);
        pages[PAGE_EQ] = BitmapFactory.decodeResource(getResources(), R.drawable.ui_eq);
        pages[PAGE_CROSSOVER] = BitmapFactory.decodeResource(getResources(), R.drawable.ui_crossover);
        pages[PAGE_DELAY] = BitmapFactory.decodeResource(getResources(), R.drawable.ui_delay);
        pages[PAGE_OUTPUT] = BitmapFactory.decodeResource(getResources(), R.drawable.ui_output);
        setClickable(true);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Bitmap bitmap = pages[page];
        if (bitmap == null) return;

        // V1 goal is visual approval. Fill the full portrait viewport so the
        // entire supplied page remains visible on phones with different aspect ratios.
        Rect src = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
        RectF dst = new RectF(0, 0, getWidth(), getHeight());
        canvas.drawBitmap(bitmap, src, dst, paint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getActionMasked() != MotionEvent.ACTION_UP) return true;
        if (getWidth() <= 0 || getHeight() <= 0) return true;

        float yNorm = event.getY() / (float) getHeight();
        if (yNorm >= 0.885f) {
            float xNorm = event.getX() / (float) getWidth();
            int requested = Math.min(4, Math.max(0, (int) (xNorm * 5f)));
            if (requested != page) {
                page = requested;
                invalidate();
            }
        }
        performClick();
        return true;
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }
}
