package com.okn.dsp;

import java.util.Arrays;

/**
 * Phase 1 local UI state only. No BLE/DSP transport is used yet.
 * Phase 2 will bind these values to the real DSP protocol.
 */
public final class DspUiState {
    public int page = 0;
    public boolean connected = true;
    public int inputSource = 0;

    public float masterDb = -6f;
    public float bassDb = 0f;
    public float bassCutoffHz = 80f;
    public float bassBoostDb = 4f;
    public float middleBoostDb = 2f;
    public float trebleBoostDb = 3f;

    public int eqChannel = 0;
    public int selectedBand = 4;
    public final float[][] eqGainDb = new float[7][15];
    public final float[][] eqFrequencyHz = new float[7][15];
    public final float[][] eqQ = new float[7][15];
    public final float[] outputDb = new float[7];

    // SUB, MID, HIGH, FULL
    public final float[] crossoverLowHz = {80f, 80f, 3000f, 20f};
    public final float[] crossoverHighHz = {80f, 3000f, 3000f, 20000f};
    public final int[] crossoverSlopeDb = {12, 24, 24, 12};
    // 0=Low Pass, 1=Band Pass, 2=High Pass, 3=Bypass
    public final int[] crossoverMode = {0, 1, 2, 3};
    public final float[] delayMs = {2.50f, 1.20f, 0f, 0.80f};
    public boolean linkLR = true;
    public boolean magnitudeView = true;

    private final float[][] savedEqGainDb = new float[7][15];
    private final float[][] savedEqFrequencyHz = new float[7][15];
    private final float[][] savedEqQ = new float[7][15];
    private final float[] savedOutputDb = new float[7];
    public boolean hasSavedPreset = false;

    public DspUiState() {
        float[] baseFrequencies = {
                20f, 40f, 80f, 160f, 315f, 630f, 1000f, 1600f,
                2500f, 4000f, 6300f, 8000f, 10000f, 12500f, 20000f
        };
        float[] demoCurve = {
                -2f, 1f, 5f, 3f, 1f, 2f, 5f, 1f, -1f, 2f, 5f, 3f, 0.5f, -1f, -3f
        };
        for (int ch = 0; ch < 7; ch++) {
            for (int b = 0; b < 15; b++) {
                eqFrequencyHz[ch][b] = baseFrequencies[b];
                eqQ[ch][b] = 1.2f;
                eqGainDb[ch][b] = demoCurve[b] * (ch == 0 ? 1f : 0.55f);
            }
            outputDb[ch] = 0f;
        }
    }

    public void savePreset() {
        for (int ch = 0; ch < 7; ch++) {
            System.arraycopy(eqGainDb[ch], 0, savedEqGainDb[ch], 0, 15);
            System.arraycopy(eqFrequencyHz[ch], 0, savedEqFrequencyHz[ch], 0, 15);
            System.arraycopy(eqQ[ch], 0, savedEqQ[ch], 0, 15);
        }
        System.arraycopy(outputDb, 0, savedOutputDb, 0, 7);
        hasSavedPreset = true;
    }

    public boolean loadPreset() {
        if (!hasSavedPreset) return false;
        for (int ch = 0; ch < 7; ch++) {
            System.arraycopy(savedEqGainDb[ch], 0, eqGainDb[ch], 0, 15);
            System.arraycopy(savedEqFrequencyHz[ch], 0, eqFrequencyHz[ch], 0, 15);
            System.arraycopy(savedEqQ[ch], 0, eqQ[ch], 0, 15);
        }
        System.arraycopy(savedOutputDb, 0, outputDb, 0, 7);
        return true;
    }

    public void resetEqChannel(int channel) {
        Arrays.fill(eqGainDb[channel], 0f);
        Arrays.fill(eqQ[channel], 1.2f);
    }

    public static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}
