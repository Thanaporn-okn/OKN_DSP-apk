package com.okn.dsp;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Locale;

/**
 * Phase 1 local state store.
 * Every user adjustment is written immediately with SharedPreferences.apply(),
 * so closing/reopening the app restores the last UI value without a Save step.
 * Phase 2 will bind these same setters to the verified DSP transport/protocol.
 */
public final class DspState {
    public static final int SCREEN_HOME = 0;
    public static final int SCREEN_MIX = 1;
    public static final int SCREEN_EQ = 2;

    public static final int THEME_SYSTEM = 0;
    public static final int THEME_LIGHT = 1;
    public static final int THEME_DARK = 2;

    public static final int CHANNELS = 7;
    public static final int BANDS = 15;
    public static final float[] DEFAULT_FREQ = {
            25f, 40f, 63f, 100f, 160f,
            250f, 400f, 630f, 1000f, 1600f,
            2500f, 4000f, 6300f, 10000f, 16000f
    };

    private final SharedPreferences prefs;
    private int screen;
    private int themeMode;
    private int selectedChannel;
    private int selectedBand;
    private float masterDb;
    private float bassDb;
    private float bassCutoffHz;
    private final float[] channelDb = new float[CHANNELS];
    private final float[][] eqGain = new float[CHANNELS][BANDS];
    private final float[][] eqQ = new float[CHANNELS][BANDS];
    private final float[][] eqFreq = new float[CHANNELS][BANDS];
    private String presetName;
    private boolean hasPreset;

    public DspState(Context context) {
        prefs = context.getSharedPreferences("okn_dsp_v1_state", Context.MODE_PRIVATE);
        screen = prefs.getInt("screen", SCREEN_HOME);
        themeMode = prefs.getInt("theme", THEME_SYSTEM);
        selectedChannel = clampInt(prefs.getInt("selected_channel", 0), 0, CHANNELS - 1);
        selectedBand = clampInt(prefs.getInt("selected_band", 3), 0, BANDS - 1);
        masterDb = prefs.getFloat("master_db", -6f);
        bassDb = prefs.getFloat("bass_db", 2f);
        bassCutoffHz = prefs.getFloat("bass_cutoff_hz", 80f);
        for (int c = 0; c < CHANNELS; c++) {
            channelDb[c] = prefs.getFloat("ch_db_" + c, defaultChannel(c));
            for (int b = 0; b < BANDS; b++) {
                eqGain[c][b] = prefs.getFloat(key("eq_g", c, b), 0f);
                eqQ[c][b] = prefs.getFloat(key("eq_q", c, b), 1f);
                eqFreq[c][b] = prefs.getFloat(key("eq_f", c, b), DEFAULT_FREQ[b]);
            }
        }
        presetName = prefs.getString("preset_name", "Custom 1");
        hasPreset = prefs.getBoolean("preset_exists", false);
    }

    private static String key(String prefix, int c, int b) {
        return prefix + "_" + c + "_" + b;
    }

    private static float defaultChannel(int c) {
        float[] d = {-3f, -6f, -2f, -8f, 0f, -4f, -10f};
        return d[c];
    }

    public int getScreen() { return screen; }
    public void setScreen(int v) { screen = clampInt(v, 0, 2); prefs.edit().putInt("screen", screen).apply(); }

    public int getThemeMode() { return themeMode; }
    public void setThemeMode(int v) { themeMode = clampInt(v, 0, 2); prefs.edit().putInt("theme", themeMode).apply(); }

    public int getSelectedChannel() { return selectedChannel; }
    public void setSelectedChannel(int v) { selectedChannel = clampInt(v, 0, CHANNELS - 1); prefs.edit().putInt("selected_channel", selectedChannel).apply(); }

    public int getSelectedBand() { return selectedBand; }
    public void setSelectedBand(int v) { selectedBand = clampInt(v, 0, BANDS - 1); prefs.edit().putInt("selected_band", selectedBand).apply(); }

    public float getMasterDb() { return masterDb; }
    public void setMasterDb(float v) { masterDb = clamp(v, -60f, 6f); prefs.edit().putFloat("master_db", masterDb).apply(); }

    public float getBassDb() { return bassDb; }
    public void setBassDb(float v) { bassDb = clamp(v, -12f, 12f); prefs.edit().putFloat("bass_db", bassDb).apply(); }

    public float getBassCutoffHz() { return bassCutoffHz; }
    public void setBassCutoffHz(float v) { bassCutoffHz = clamp(v, 20f, 300f); prefs.edit().putFloat("bass_cutoff_hz", bassCutoffHz).apply(); }

    public float getChannelDb(int c) { return channelDb[clampInt(c, 0, CHANNELS - 1)]; }
    public void setChannelDb(int c, float v) {
        c = clampInt(c, 0, CHANNELS - 1);
        channelDb[c] = clamp(v, -60f, 6f);
        prefs.edit().putFloat("ch_db_" + c, channelDb[c]).apply();
    }

    public float getEqGain(int c, int b) { return eqGain[c][b]; }
    public void setEqGain(int c, int b, float v) {
        c = clampInt(c, 0, CHANNELS - 1); b = clampInt(b, 0, BANDS - 1);
        eqGain[c][b] = clamp(v, -12f, 12f);
        prefs.edit().putFloat(key("eq_g", c, b), eqGain[c][b]).apply();
    }

    public float getEqQ(int c, int b) { return eqQ[c][b]; }
    public void setEqQ(int c, int b, float v) {
        c = clampInt(c, 0, CHANNELS - 1); b = clampInt(b, 0, BANDS - 1);
        eqQ[c][b] = clamp(v, 0.1f, 10f);
        prefs.edit().putFloat(key("eq_q", c, b), eqQ[c][b]).apply();
    }

    public float getEqFreq(int c, int b) { return eqFreq[c][b]; }
    public void setEqFreq(int c, int b, float v) {
        c = clampInt(c, 0, CHANNELS - 1); b = clampInt(b, 0, BANDS - 1);
        eqFreq[c][b] = clamp(v, 20f, 20000f);
        prefs.edit().putFloat(key("eq_f", c, b), eqFreq[c][b]).apply();
    }

    public String getPresetName() { return presetName; }
    public void setPresetName(String name) {
        presetName = (name == null || name.trim().isEmpty()) ? "Custom 1" : name.trim();
        prefs.edit().putString("preset_name", presetName).apply();
    }

    public boolean hasPreset() { return hasPreset; }

    public void resetEqChannel(int c) {
        c = clampInt(c, 0, CHANNELS - 1);
        SharedPreferences.Editor e = prefs.edit();
        for (int b = 0; b < BANDS; b++) {
            eqGain[c][b] = 0f;
            eqQ[c][b] = 1f;
            eqFreq[c][b] = DEFAULT_FREQ[b];
            e.putFloat(key("eq_g", c, b), 0f);
            e.putFloat(key("eq_q", c, b), 1f);
            e.putFloat(key("eq_f", c, b), DEFAULT_FREQ[b]);
        }
        e.apply();
    }

    public void savePresetSnapshot() {
        SharedPreferences.Editor e = prefs.edit();
        for (int c = 0; c < CHANNELS; c++) {
            e.putString("preset_gain_" + c, encode(eqGain[c]));
            e.putString("preset_q_" + c, encode(eqQ[c]));
            e.putString("preset_freq_" + c, encode(eqFreq[c]));
        }
        hasPreset = true;
        e.putBoolean("preset_exists", true).apply();
    }

    public boolean loadPresetSnapshot() {
        if (!hasPreset) return false;
        SharedPreferences.Editor e = prefs.edit();
        for (int c = 0; c < CHANNELS; c++) {
            float[] g = decode(prefs.getString("preset_gain_" + c, null), BANDS);
            float[] q = decode(prefs.getString("preset_q_" + c, null), BANDS);
            float[] f = decode(prefs.getString("preset_freq_" + c, null), BANDS);
            if (g == null || q == null || f == null) return false;
            for (int b = 0; b < BANDS; b++) {
                eqGain[c][b] = clamp(g[b], -12f, 12f);
                eqQ[c][b] = clamp(q[b], 0.1f, 10f);
                eqFreq[c][b] = clamp(f[b], 20f, 20000f);
                e.putFloat(key("eq_g", c, b), eqGain[c][b]);
                e.putFloat(key("eq_q", c, b), eqQ[c][b]);
                e.putFloat(key("eq_f", c, b), eqFreq[c][b]);
            }
        }
        e.apply();
        return true;
    }

    public void deletePresetSnapshot() {
        SharedPreferences.Editor e = prefs.edit();
        for (int c = 0; c < CHANNELS; c++) {
            e.remove("preset_gain_" + c);
            e.remove("preset_q_" + c);
            e.remove("preset_freq_" + c);
        }
        hasPreset = false;
        e.putBoolean("preset_exists", false).apply();
    }

    private static String encode(float[] values) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < values.length; i++) {
            if (i > 0) sb.append(',');
            sb.append(String.format(Locale.US, "%.6f", values[i]));
        }
        return sb.toString();
    }

    private static float[] decode(String s, int expected) {
        if (s == null) return null;
        String[] parts = s.split(",");
        if (parts.length != expected) return null;
        float[] out = new float[expected];
        try {
            for (int i = 0; i < expected; i++) out[i] = Float.parseFloat(parts[i]);
            return out;
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    public static float clamp(float v, float lo, float hi) { return Math.max(lo, Math.min(hi, v)); }
    public static int clampInt(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }
}
