package com.okn.dsp;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Locale;

final class DspState {
    static final int CHANNELS = 7;
    static final int BANDS = 15;

    float masterVolume = -3f;

    final float[][] freq = new float[CHANNELS][BANDS];
    final float[][] gain = new float[CHANNELS][BANDS];
    final float[][] q = new float[CHANNELS][BANDS];
    final int[][] type = new int[CHANNELS][BANDS];
    final boolean[][] eqWritable = new boolean[CHANNELS][BANDS];

    int channel = 0;
    int selectedBand = 0;

    static final String[] CHANNEL_LONG = {
            "CH1 - Front L", "CH2 - Front R", "CH3 - Rear L", "CH4 - Rear R",
            "CH5 - Center", "CH6 - Sub", "CH7 - AUX"
    };

    private static final float[] DEFAULT_15 = {
            32f, 63f, 100f, 160f, 250f, 400f, 630f,
            1000f, 1600f, 2500f, 4000f, 6300f, 10000f, 14000f, 20000f
    };

    DspState() {
        for (int c = 0; c < CHANNELS; c++) resetEq(c);
    }

    void resetEq(int c) {
        for (int b = 0; b < BANDS; b++) {
            freq[c][b] = DEFAULT_15[b];
            gain[c][b] = 0f;
            q[c][b] = 1.00f;
            // Supplied evidence says Band 1 is native Tone Control on most channels and
            // native General Low-pass on CH3. The live descriptor overwrites this value.
            type[c][b] = b == 0 ? (c == 2 ? DspProtocol.EQ_GENERAL_LOWPASS_TYPE : DspProtocol.EQ_TONE_CONTROL_TYPE)
                    : DspProtocol.EQ_PEAKING_TYPE;
            eqWritable[c][b] = false;
        }
    }

    void flattenEq(int c) {
        for (int b = 0; b < BANDS; b++) gain[c][b] = 0f;
    }

    void saveEq(Context context) {
        SharedPreferences.Editor e = context.getSharedPreferences("okn_dsp_v1_eq", Context.MODE_PRIVATE).edit();
        e.putBoolean("saved", true);
        e.putFloat("master", masterVolume);
        for (int c = 0; c < CHANNELS; c++) {
            for (int b = 0; b < BANDS; b++) {
                e.putFloat("freq_" + c + "_" + b, freq[c][b]);
                e.putFloat("gain_" + c + "_" + b, gain[c][b]);
                e.putFloat("q_" + c + "_" + b, q[c][b]);
            }
        }
        e.apply();
    }

    boolean loadEq(Context context) {
        SharedPreferences p = context.getSharedPreferences("okn_dsp_v1_eq", Context.MODE_PRIVATE);
        if (!p.getBoolean("saved", false)) return false;
        masterVolume = p.getFloat("master", masterVolume);
        for (int c = 0; c < CHANNELS; c++) {
            for (int b = 0; b < BANDS; b++) {
                // Frequency/Q are restored visually only. The BLE writer still uses live
                // hardware Frequency/Q and commits only the verified gain path.
                freq[c][b] = p.getFloat("freq_" + c + "_" + b, freq[c][b]);
                gain[c][b] = p.getFloat("gain_" + c + "_" + b, gain[c][b]);
                q[c][b] = p.getFloat("q_" + c + "_" + b, q[c][b]);
            }
        }
        return true;
    }

    static String db(float v) {
        return String.format(Locale.US, "%.1f dB", v);
    }

    static String hzLong(float v) {
        if (v >= 1000f) {
            float k = v / 1000f;
            if (Math.abs(k - Math.round(k)) < 0.01f) return String.format(Locale.US, "%.1f kHz", k);
            return String.format(Locale.US, "%.2f kHz", k);
        }
        return String.format(Locale.US, "%.0f Hz", v);
    }

    static String q(float v) {
        return String.format(Locale.US, "%.2f", v);
    }
}
