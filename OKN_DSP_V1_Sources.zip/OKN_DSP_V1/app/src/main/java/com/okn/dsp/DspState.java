package com.okn.dsp;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Locale;

final class DspState {
    static final int CHANNELS = 7;
    static final int BANDS = 15;

    static final String[] CHANNEL_SHORT = {
            "CH1\nFront L", "CH2\nFront R", "CH3\nRear L", "CH4\nRear R",
            "CH5\nCenter", "CH6\nSub L", "CH7\nSub R"
    };
    static final String[] CHANNEL_NAME = {
            "Front L", "Front R", "Rear L", "Rear R", "Center", "Sub L", "Sub R"
    };

    // Verified scalar controls from the uploaded source data.
    float masterVolume = -3f;
    float bassVolume = 4f;
    float bassCutoff = 100f;
    float bassBoost = 3f;
    float middleBoost = -2f;
    float trebleBoost = 1f;

    int audioSource = 0;
    int homePreset = 0;

    final float[][] freq = new float[CHANNELS][BANDS];
    final float[][] gain = new float[CHANNELS][BANDS];
    final float[][] q = new float[CHANNELS][BANDS];
    final boolean[][] eqWritable = new boolean[CHANNELS][BANDS];
    final boolean[][] eqPower = new boolean[CHANNELS][BANDS];

    // UI state for pages present in the supplied mockups. These values are local until
    // a verified packet mapping is supplied for the corresponding hardware actuator.
    final boolean[] hpfBypass = new boolean[CHANNELS];
    final boolean[] lpfBypass = new boolean[CHANNELS];
    final float[] hpfFreq = new float[CHANNELS];
    final float[] lpfFreq = new float[CHANNELS];
    final int[] hpfSlope = new int[CHANNELS];
    final int[] lpfSlope = new int[CHANNELS];
    final int[] phaseDeg = new int[CHANNELS];
    final boolean[] polarityInvert = new boolean[CHANNELS];
    final boolean[] linkLR = new boolean[CHANNELS];
    final int[] outputMode = new int[CHANNELS];

    final float[] delayMs = {0f, 1.25f, 2.60f, 2.30f, 0.80f, 3.10f, 1.90f};
    int seatPreset = 0;

    float masterOutput = -1f;
    final float[] outputGain = {-3f, -2.5f, -4f, -1f, -2f, -3.5f, -4.5f};
    final boolean[] outputMute = new boolean[CHANNELS];
    final boolean[] outputSolo = new boolean[CHANNELS];
    final boolean[] outputPhase = new boolean[CHANNELS];
    final boolean[] outputLink = {true, true, false, false, false, false, false};

    int channel = 0;
    int eqPage = 0;

    private static final float[] DEFAULT_15 = {
            32f, 50f, 100f, 200f, 500f, 1000f, 2000f, 5000f,
            10000f, 12500f, 14000f, 16000f, 18000f, 19000f, 20000f
    };

    DspState() {
        for (int c = 0; c < CHANNELS; c++) {
            for (int b = 0; b < BANDS; b++) {
                freq[c][b] = DEFAULT_15[b];
                gain[c][b] = 0f;
                q[c][b] = 1.00f;
                eqWritable[c][b] = false;
                eqPower[c][b] = true;
            }
            hpfFreq[c] = 100f;
            lpfFreq[c] = 1000f;
            hpfSlope[c] = 24;
            lpfSlope[c] = 24;
            linkLR[c] = true;
        }

        // Match the EQ example shown in the uploaded UI for CH1 before live data arrives.
        gain[0][0] = -3f;
        gain[0][1] = 2.5f;
        gain[0][2] = 6f;
        gain[0][3] = -4f;
        gain[0][4] = 3f;
        gain[0][5] = -2f;
        freq[0][0] = 32f;
        freq[0][1] = 100f;
        freq[0][2] = 200f;
        freq[0][3] = 500f;
        freq[0][4] = 2000f;
        freq[0][5] = 10000f;
        q[0][0] = 0.70f;
        q[0][1] = 1.00f;
        q[0][2] = 1.20f;
        q[0][3] = 1.00f;
        q[0][4] = 1.00f;
        q[0][5] = 0.70f;
    }

    void applyHomePreset(int preset) {
        homePreset = preset;
        switch (preset) {
            case 1: // Pop
                bassVolume = 2f;
                bassCutoff = 100f;
                bassBoost = 2f;
                middleBoost = 1f;
                trebleBoost = 3f;
                break;
            case 2: // Rock
                bassVolume = 4f;
                bassCutoff = 90f;
                bassBoost = 4f;
                middleBoost = 2f;
                trebleBoost = 2f;
                break;
            case 3: // Jazz
                bassVolume = 2f;
                bassCutoff = 110f;
                bassBoost = 1f;
                middleBoost = 2f;
                trebleBoost = 3f;
                break;
            default:
                bassVolume = 0f;
                bassCutoff = 100f;
                bassBoost = 0f;
                middleBoost = 0f;
                trebleBoost = 0f;
                break;
        }
    }

    void saveEq(Context context) {
        SharedPreferences.Editor e = context.getSharedPreferences("okn_dsp_v1_eq", Context.MODE_PRIVATE).edit();
        for (int c = 0; c < CHANNELS; c++) {
            for (int b = 0; b < BANDS; b++) {
                e.putFloat("gain_" + c + "_" + b, gain[c][b]);
                e.putBoolean("power_" + c + "_" + b, eqPower[c][b]);
            }
        }
        e.putBoolean("saved", true).apply();
    }

    boolean loadEq(Context context) {
        SharedPreferences p = context.getSharedPreferences("okn_dsp_v1_eq", Context.MODE_PRIVATE);
        if (!p.getBoolean("saved", false)) return false;
        for (int c = 0; c < CHANNELS; c++) {
            for (int b = 0; b < BANDS; b++) {
                gain[c][b] = p.getFloat("gain_" + c + "_" + b, gain[c][b]);
                eqPower[c][b] = p.getBoolean("power_" + c + "_" + b, true);
            }
        }
        return true;
    }

    static String db(float v) {
        return String.format(Locale.US, "%.1f dB", v);
    }

    static String hz(float v) {
        if (v >= 1000f) {
            float k = v / 1000f;
            if (Math.abs(k - Math.round(k)) < 0.05f) return String.format(Locale.US, "%.1f kHz", k);
            return String.format(Locale.US, "%.1f kHz", k);
        }
        return String.format(Locale.US, "%.0f Hz", v);
    }

    static String delayCm(float ms) {
        return String.format(Locale.US, "%.1f cm", ms * 34.3f);
    }
}
