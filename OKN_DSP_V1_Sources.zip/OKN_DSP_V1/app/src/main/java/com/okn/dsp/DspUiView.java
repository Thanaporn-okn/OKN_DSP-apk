package com.okn.dsp;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * OKN DSP Version 1 - Phase 1 UI only.
 *
 * The entire interface is drawn from code. No uploaded screenshot is used as a
 * background or runtime image. Controls are interactive and local-only in V1.
 */
public class DspUiView extends View {
    private static final int PAGE_HOME = 0;
    private static final int PAGE_MIX = 1;
    private static final int PAGE_EQ = 2;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Typeface regular = Typeface.create("sans-serif", Typeface.NORMAL);
    private final Typeface medium = Typeface.create("sans-serif-medium", Typeface.NORMAL);
    private final Typeface bold = Typeface.create("sans-serif", Typeface.BOLD);
    private final float density;
    private final SharedPreferences prefs;

    private int page = PAGE_HOME;
    private float scrollY = 0f;
    private float maxScroll = 0f;
    private float layoutLeft = 0f;
    private float layoutWidth = 360f;
    private float screenWdp = 360f;
    private float screenHdp = 760f;
    private final float navHeight = 78f;

    private final List<Hit> hits = new ArrayList<>();
    private Hit activeHit;
    private float downX, downY, lastY;
    private boolean dragged;
    private boolean menuOpen;

    // Mix state
    private float masterDb = -6f;
    private float bassDb = 2f;
    private float bassCutoff = 80f;
    private final float[] channelDb = {-3f, -6f, -2f, -8f, 0f, -4f, -10f};

    // EQ state: 7 channels x 15 parametric bands.
    private final float[][] eqFreq = new float[7][15];
    private final float[][] eqQ = new float[7][15];
    private final float[][] eqGain = new float[7][15];
    private int selectedChannel = 0;
    private int selectedBand = 0;
    private String selectedPreset = "Flat";

    private final int[] channelColors = {
            Color.rgb(39, 148, 255), Color.rgb(55, 211, 91), Color.rgb(255, 161, 40),
            Color.rgb(244, 76, 121), Color.rgb(123, 79, 244), Color.rgb(18, 190, 207),
            Color.rgb(111, 85, 245)
    };

    public DspUiView(Context context) {
        super(context);
        density = getResources().getDisplayMetrics().density;
        prefs = context.getSharedPreferences("okn_dsp_v1", Context.MODE_PRIVATE);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        initEq();
    }

    private void initEq() {
        float[] f = {100f, 31.5f, 50f, 80f, 160f, 250f, 500f, 800f, 1000f, 2000f, 3200f, 5000f, 8000f, 12500f, 20000f};
        float[] g = {4.0f, -2.0f, -0.7f, 1.4f, 2.2f, 0.3f, -1.3f, -1.8f, 0.0f, 2.4f, 3.1f, 2.7f, 1.2f, -0.4f, -1.5f};
        for (int ch = 0; ch < 7; ch++) {
            System.arraycopy(f, 0, eqFreq[ch], 0, 15);
            System.arraycopy(g, 0, eqGain[ch], 0, 15);
            Arrays.fill(eqQ[ch], 1.0f);
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        screenWdp = getWidth() / density;
        screenHdp = getHeight() / density;
        layoutWidth = Math.min(screenWdp, 700f);
        layoutLeft = (screenWdp - layoutWidth) / 2f;
        hits.clear();

        drawBackground(c);

        float contentHeight;
        c.save();
        c.clipRect(0, 0, getWidth(), d(screenHdp - navHeight));
        c.translate(0, -d(scrollY));
        if (page == PAGE_HOME) contentHeight = drawHome(c);
        else if (page == PAGE_MIX) contentHeight = drawMix(c);
        else contentHeight = drawEq(c);
        c.restore();

        maxScroll = Math.max(0f, contentHeight - (screenHdp - navHeight));
        if (scrollY > maxScroll) scrollY = maxScroll;

        drawBottomNav(c);
        if (menuOpen) drawMenuPopup(c);
    }

    private void drawBackground(Canvas c) {
        p.setShader(new LinearGradient(0, 0, 0, getHeight(),
                Color.rgb(249, 252, 255), Color.rgb(242, 247, 253), Shader.TileMode.CLAMP));
        c.drawRect(0, 0, getWidth(), getHeight(), p);
        p.setShader(null);
    }

    private float drawHome(Canvas c) {
        float x = layoutLeft + 16f;
        float w = layoutWidth - 32f;
        float y = 26f;
        drawHeader(c, "OKN DSP", "DSP Controller", y);
        y += 96f;

        drawCard(c, x, y, w, 112f, 28f, Color.rgb(242, 255, 247));
        drawSoftCircle(c, x + 44, y + 56, 29, Color.rgb(211, 252, 224));
        p.setColor(Color.rgb(38, 202, 85));
        c.drawCircle(d(x + 44), d(y + 56), d(23), p);
        drawCheck(c, x + 44, y + 56, 13, Color.WHITE, 4);
        text(c, "SYSTEM STATUS", x + 88, y + 32, 10.5f, Color.rgb(111, 124, 145), medium);
        text(c, "System Ready", x + 88, y + 58, 21f, Color.rgb(13, 20, 31), bold);
        text(c, "All devices connected and running normally.", x + 88, y + 82, 11.5f, Color.rgb(115, 130, 154), regular);
        drawChevron(c, x + w - 25, y + 56, Color.rgb(86, 105, 132));
        addHit("homeStatus", 0, x, y, w, 112, true);
        y += 137f;

        text(c, "Connection & Status", x + 2, y + 18, 19f, Color.rgb(13, 20, 31), bold);
        textRight(c, "All Good", x + w - 18, y + 18, 12f, Color.rgb(20, 132, 243), medium);
        p.setColor(Color.rgb(49, 211, 89));
        c.drawCircle(d(x + w - 7), d(y + 14), d(4.5f), p);
        y += 34f;

        String[][] rows = {
                {"Bluetooth", "Phone connected", "Connected"},
                {"DSP Device", "OKN DSP-8 Pro", "Connected"},
                {"Audio Input", "AUX (Analog)", "Active"},
                {"Amplifier Link", "External Amplifier", "Connected"},
                {"Preset Sync", "User presets", "Synced"},
                {"Firmware Status", "v1.2.0 (Latest)", "Up to date"}
        };
        int[] icons = {0, 1, 2, 3, 4, 5};
        int[] colors = {
                Color.rgb(35, 147, 250), Color.rgb(116, 81, 244), Color.rgb(255, 156, 28),
                Color.rgb(244, 80, 122), Color.rgb(18, 190, 207), Color.rgb(126, 102, 244)
        };
        for (int i = 0; i < rows.length; i++) {
            drawHomeRow(c, x, y, w, rows[i][0], rows[i][1], rows[i][2], icons[i], colors[i], i);
            y += 70f;
        }

        drawCard(c, x, y + 6, w, 76f, 20f, Color.WHITE);
        drawSoftCircle(c, x + 37, y + 44, 23, Color.rgb(235, 246, 255));
        drawBarsIcon(c, x + 37, y + 44, Color.rgb(22, 132, 242));
        text(c, "Quick Control", x + 67, y + 37, 16f, Color.rgb(17, 25, 39), bold);
        text(c, "Adjust volume, presets and more", x + 67, y + 57, 11.5f, Color.rgb(123, 139, 164), regular);
        drawChevron(c, x + w - 24, y + 44, Color.rgb(95, 112, 137));
        addHit("quick", 0, x, y + 6, w, 76, true);
        return y + 100f;
    }

    private void drawHomeRow(Canvas c, float x, float y, float w, String title, String subtitle, String status, int icon, int color, int index) {
        drawCard(c, x, y, w, 62f, 18f, Color.WHITE);
        drawSoftCircle(c, x + 31, y + 31, 20.5f, lighten(color, 0.83f));
        p.setColor(color);
        c.drawCircle(d(x + 31), d(y + 31), d(19), p);
        drawMiniIcon(c, icon, x + 31, y + 31, Color.WHITE);
        text(c, title, x + 62, y + 27, 15.5f, Color.rgb(16, 24, 39), bold);
        text(c, subtitle, x + 62, y + 46, 11.4f, Color.rgb(126, 141, 165), regular);
        int statusColor = status.equals("Active") || status.equals("Up to date") ? Color.rgb(20, 132, 243) : Color.rgb(32, 197, 75);
        p.setColor(statusColor);
        c.drawCircle(d(x + w - 98), d(y + 31), d(4.5f), p);
        text(c, status, x + w - 87, y + 36, 11.8f, statusColor, medium);
        drawChevron(c, x + w - 20, y + 31, Color.rgb(110, 126, 150));
        addHit("homeRow", index, x, y, w, 62, true);
    }

    private float drawMix(Canvas c) {
        float x = layoutLeft + 16f;
        float w = layoutWidth - 32f;
        float y = 24f;
        drawHeader(c, "Mix", "Channel and bass controls", y);
        y += 90f;

        drawCard(c, x, y, w, 211f, 20f, Color.WHITE);
        text(c, "Global", x + 12, y + 27, 18f, Color.rgb(16, 24, 39), bold);
        textRight(c, "Overall output and bass settings", x + w - 12, y + 24, 10.4f, Color.rgb(116, 131, 154), regular);
        drawMixSliderRow(c, x + 12, y + 45, w - 24, 0, "Master Volume", formatDb(masterDb), masterDb, -24, 6, 0, Color.rgb(33, 146, 246));
        line(c, x + 12, y + 99, x + w - 12, y + 99, Color.rgb(232, 237, 244), 1);
        drawMixSliderRow(c, x + 12, y + 101, w - 24, 1, "Bass Volume", formatDb(bassDb), bassDb, -12, 12, 1, Color.rgb(252, 151, 32));
        line(c, x + 12, y + 155, x + w - 12, y + 155, Color.rgb(232, 237, 244), 1);
        drawMixSliderRow(c, x + 12, y + 157, w - 24, 2, "Bass Cutoff", Math.round(bassCutoff) + " Hz", bassCutoff, 40, 160, 2, Color.rgb(124, 82, 244));
        y += 225f;

        float channelsH = 49f + 7 * 53f;
        drawCard(c, x, y, w, channelsH, 20f, Color.WHITE);
        text(c, "Channels", x + 12, y + 28, 18f, Color.rgb(16, 24, 39), bold);
        textRight(c, "Individual channel levels", x + w - 12, y + 25, 10.5f, Color.rgb(117, 132, 156), regular);
        float ry = y + 43f;
        for (int i = 0; i < 7; i++) {
            drawChannelRow(c, x + 12, ry, w - 24, i);
            if (i < 6) line(c, x + 12, ry + 52, x + w - 12, ry + 52, Color.rgb(234, 238, 244), 1);
            ry += 53f;
        }
        return y + channelsH + 18f;
    }

    private void drawMixSliderRow(Canvas c, float x, float y, float w, int index, String label, String value, float cur, float min, float max, int icon, int color) {
        drawSoftCircle(c, x + 22, y + 26, 18, lighten(color, 0.84f));
        drawMiniIcon(c, icon == 0 ? 3 : (icon == 1 ? 2 : 6), x + 22, y + 26, color);
        text(c, label, x + 51, y + 23, 13.4f, Color.rgb(20, 27, 39), medium);
        drawValuePill(c, x + w - 62, y + 9, 61, 34, value);
        float sx = x + 52;
        float sy = y + 39;
        float ex = x + w - 75;
        drawSlider(c, sx, sy, ex, cur, min, max, Color.rgb(49, 157, 247));
        addHit("mixSlider", index, sx - 6, sy - 15, (ex - sx) + 12, 30, true);
    }

    private void drawChannelRow(Canvas c, float x, float y, float w, int index) {
        p.setColor(channelColors[index]);
        c.drawCircle(d(x + 20), d(y + 25), d(16), p);
        textCentered(c, String.valueOf(index + 1), x + 20, y + 30, 13.5f, Color.WHITE, bold);
        text(c, "Volume Ch" + (index + 1), x + 50, y + 22, 13f, Color.rgb(20, 27, 39), medium);
        drawValuePill(c, x + w - 62, y + 7, 61, 34, formatDb(channelDb[index]));
        float sx = x + 50;
        float sy = y + 37;
        float ex = x + w - 75;
        drawSlider(c, sx, sy, ex, channelDb[index], -18, 6, Color.rgb(49, 157, 247));
        addHit("channelSlider", index, sx - 6, sy - 15, (ex - sx) + 12, 30, true);
    }

    private float drawEq(Canvas c) {
        float x = layoutLeft + 16f;
        float w = layoutWidth - 32f;
        float y = 22f;
        drawHeader(c, "Eq", "15-band equalizer", y);
        y += 78f;

        float gap = 5f;
        float tabW = (w - gap * 6f) / 7f;
        for (int i = 0; i < 7; i++) {
            float tx = x + i * (tabW + gap);
            if (i == selectedChannel) {
                roundRect(c, tx, y, tabW, 28, 14, Color.rgb(21, 134, 246));
                textCentered(c, "Ch" + (i + 1), tx + tabW / 2, y + 19, 10.4f, Color.WHITE, medium);
            } else {
                roundRectStroke(c, tx, y, tabW, 28, 14, Color.rgb(232, 237, 244), Color.rgb(218, 225, 235), 0.8f);
                textCentered(c, "Ch" + (i + 1), tx + tabW / 2, y + 19, 10.4f, Color.rgb(87, 102, 127), regular);
            }
            addHit("eqChannel", i, tx, y, tabW, 28, true);
        }
        y += 40f;

        drawCard(c, x, y, w, 255f, 19f, Color.WHITE);
        text(c, "Channel " + (selectedChannel + 1), x + 12, y + 27, 16.5f, Color.rgb(16, 24, 39), bold);
        text(c, selectedChannel == 0 ? "Front Left  •  15-band EQ" : "Channel output  •  15-band EQ", x + 12, y + 45, 10.8f, Color.rgb(122, 137, 160), regular);
        roundRect(c, x + w - 90, y + 10, 78, 32, 15, Color.rgb(244, 247, 251));
        drawResetIcon(c, x + w - 76, y + 26, Color.rgb(93, 112, 137));
        text(c, "Reset EQ", x + w - 62, y + 30, 10.3f, Color.rgb(87, 104, 129), medium);
        addHit("eqReset", 0, x + w - 95, y + 7, 88, 38, true);

        drawEqGraph(c, x + 18, y + 57, w - 36, 179);
        y += 268f;

        drawCard(c, x, y, w, 226f, 19f, Color.WHITE);
        drawSoftCircle(c, x + 28, y + 28, 20, Color.rgb(235, 246, 255));
        textCentered(c, String.valueOf(selectedBand + 1), x + 28, y + 34, 16f, Color.rgb(21, 134, 246), bold);
        text(c, "Band " + (selectedBand + 1), x + 58, y + 25, 15.5f, Color.rgb(18, 26, 39), bold);
        text(c, "Adjust the selected band parameters", x + 58, y + 43, 10.7f, Color.rgb(123, 138, 160), regular);
        drawCircleButton(c, x + w - 57, y + 27, false, -1);
        drawCircleButton(c, x + w - 25, y + 27, false, 1);
        addHit("bandArrow", -1, x + w - 72, y + 10, 30, 34, true);
        addHit("bandArrow", 1, x + w - 40, y + 10, 30, 34, true);

        drawEqControl(c, x + 12, y + 60, w - 24, 0, "Frequency", formatFreq(eqFreq[selectedChannel][selectedBand]), 20, 20000, true);
        drawEqControl(c, x + 12, y + 113, w - 24, 1, "Q (Quality Factor)", String.format(Locale.US, "%.1f", eqQ[selectedChannel][selectedBand]), 0.1f, 10, false);
        drawEqControl(c, x + 12, y + 166, w - 24, 2, "Ch Volume", formatDbOne(eqGain[selectedChannel][selectedBand]), -12, 12, false);
        y += 239f;

        drawCard(c, x, y, w, 176f, 19f, Color.WHITE);
        drawSoftCircle(c, x + 28, y + 29, 20, Color.rgb(224, 251, 252));
        drawDocumentIcon(c, x + 28, y + 29, Color.rgb(18, 185, 203));
        text(c, "Presets", x + 58, y + 25, 15.5f, Color.rgb(18, 26, 39), bold);
        text(c, "Save and load EQ presets", x + 58, y + 43, 10.7f, Color.rgb(123, 138, 160), regular);
        drawDots(c, x + w - 18, y + 27, Color.rgb(112, 128, 151));
        addHit("presetMenu", 0, x + w - 35, y + 8, 30, 36, true);

        roundRectStroke(c, x + 12, y + 61, w - 119, 34, 8, Color.rgb(252, 253, 255), Color.rgb(215, 224, 235), 0.8f);
        text(c, "Preset name", x + 20, y + 83, 10.5f, Color.rgb(155, 168, 187), regular);
        roundRect(c, x + w - 96, y + 61, 84, 34, 9, Color.rgb(20, 134, 246));
        drawSaveIcon(c, x + w - 84, y + 78, Color.WHITE);
        text(c, "Save Preset", x + w - 67, y + 83, 10.5f, Color.WHITE, medium);
        addHit("presetSave", 0, x + w - 99, y + 57, 90, 42, true);

        text(c, "Load Preset", x + 12, y + 116, 10.8f, Color.rgb(74, 91, 117), medium);
        roundRectStroke(c, x + 12, y + 125, w - 119, 36, 8, Color.rgb(252, 253, 255), Color.rgb(215, 224, 235), 0.8f);
        text(c, selectedPreset, x + 21, y + 148, 10.8f, Color.rgb(68, 83, 109), regular);
        drawSmallDown(c, x + w - 120, y + 143, Color.rgb(87, 105, 130));
        addHit("presetCycle", 0, x + 12, y + 124, w - 119, 38, true);
        roundRect(c, x + w - 96, y + 125, 84, 36, 9, Color.rgb(240, 245, 250));
        drawFolderIcon(c, x + w - 84, y + 143, Color.rgb(76, 97, 125));
        text(c, "Load", x + w - 61, y + 148, 10.8f, Color.rgb(75, 95, 122), medium);
        addHit("presetLoad", 0, x + w - 99, y + 122, 90, 42, true);
        return y + 193f;
    }

    private void drawEqGraph(Canvas c, float x, float y, float w, float h) {
        float top = y + 4;
        float bottom = y + h - 22;
        float left = x + 24;
        float right = x + w - 4;

        // Selected frequency highlight.
        float selX = freqToX(eqFreq[selectedChannel][selectedBand], left, right);
        p.setColor(Color.argb(24, 33, 150, 243));
        c.drawRect(d(selX - 9), d(top), d(selX + 9), d(bottom), p);

        for (int i = 0; i <= 4; i++) {
            float yy = top + (bottom - top) * i / 4f;
            line(c, left, yy, right, yy, Color.rgb(232, 238, 245), 0.7f);
        }
        float[] gridF = {20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000};
        for (float f : gridF) {
            float gx = freqToX(f, left, right);
            line(c, gx, top, gx, bottom, Color.rgb(239, 243, 248), 0.55f);
        }

        textRight(c, "+12", left - 7, top + 3, 8.5f, Color.rgb(91, 108, 134), regular);
        textRight(c, "+6", left - 7, top + (bottom - top) * 0.25f + 3, 8.5f, Color.rgb(91, 108, 134), regular);
        textRight(c, "0", left - 7, top + (bottom - top) * 0.5f + 3, 8.5f, Color.rgb(91, 108, 134), regular);
        textRight(c, "-6", left - 7, top + (bottom - top) * 0.75f + 3, 8.5f, Color.rgb(91, 108, 134), regular);
        textRight(c, "-12", left - 7, bottom + 3, 8.5f, Color.rgb(91, 108, 134), regular);
        text(c, "(dB)", x, bottom + 16, 8.2f, Color.rgb(91, 108, 134), regular);

        String[] labels = {"20", "50", "100", "200", "500", "1K", "2K", "5K", "10K", "20K"};
        for (int i = 0; i < gridF.length; i++) {
            float gx = freqToX(gridF[i], left, right);
            textCentered(c, labels[i], gx, bottom + 16, 8.1f, Color.rgb(91, 108, 134), regular);
        }
        textRight(c, "(Hz)", right, bottom + 27, 8.2f, Color.rgb(91, 108, 134), regular);

        // Analytic response curve. Q changes the width of each band's influence.
        Path curve = new Path();
        int samples = 140;
        for (int i = 0; i < samples; i++) {
            float t = i / (samples - 1f);
            double logF = Math.log10(20.0) + t * (Math.log10(20000.0) - Math.log10(20.0));
            float f = (float) Math.pow(10, logF);
            float gain = responseAt(f);
            float yy = gainToY(gain, top, bottom);
            float xx = left + t * (right - left);
            if (i == 0) curve.moveTo(d(xx), d(yy)); else curve.lineTo(d(xx), d(yy));
        }
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(d(1.4f));
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        stroke.setColor(Color.rgb(31, 142, 242));
        c.drawPath(curve, stroke);

        Integer[] order = new Integer[15];
        for (int i = 0; i < 15; i++) order[i] = i;
        Arrays.sort(order, Comparator.comparingDouble(i -> eqFreq[selectedChannel][i]));
        for (int i : order) {
            float px = freqToX(eqFreq[selectedChannel][i], left, right);
            float py = gainToY(eqGain[selectedChannel][i], top, bottom);
            if (i == selectedBand) {
                p.setStyle(Paint.Style.FILL);
                p.setColor(Color.WHITE);
                c.drawCircle(d(px), d(py), d(7), p);
                p.setColor(Color.rgb(28, 144, 244));
                c.drawCircle(d(px), d(py), d(5), p);
            } else {
                p.setColor(Color.WHITE);
                c.drawCircle(d(px), d(py), d(4.5f), p);
                p.setColor(Color.rgb(28, 144, 244));
                c.drawCircle(d(px), d(py), d(3.3f), p);
            }
            addHit("eqPoint", i, px - 10, py - 10, 20, 20, true);
        }
    }

    private float responseAt(float f) {
        float total = 0f;
        for (int i = 0; i < 15; i++) {
            double octave = Math.log(f / eqFreq[selectedChannel][i]) / Math.log(2.0);
            double width = 0.72 / Math.max(0.1, eqQ[selectedChannel][i]);
            double weight = Math.exp(-0.5 * (octave * octave) / (width * width));
            total += eqGain[selectedChannel][i] * (float) weight;
        }
        return clamp(total, -12, 12);
    }

    private void drawEqControl(Canvas c, float x, float y, float w, int type, String label, String value, float min, float max, boolean log) {
        int iconColor = type == 0 ? Color.rgb(58, 88, 131) : (type == 1 ? Color.rgb(54, 78, 118) : Color.rgb(57, 79, 117));
        drawSoftCircle(c, x + 15, y + 17, 13.5f, Color.rgb(241, 246, 252));
        if (type == 0) drawWaveIcon(c, x + 15, y + 17, iconColor);
        else if (type == 1) textCentered(c, "Q", x + 15, y + 21, 10.5f, iconColor, bold);
        else drawSpeakerIcon(c, x + 15, y + 17, iconColor);
        text(c, label, x + 34, y + 17, 11.8f, Color.rgb(25, 33, 47), medium);
        drawValuePill(c, x + w - 69, y + 1, 68, 25, value);

        float sx = x + 35;
        float ex = x + w - 4;
        float sy = y + 34;
        float cur;
        if (type == 0) cur = eqFreq[selectedChannel][selectedBand];
        else if (type == 1) cur = eqQ[selectedChannel][selectedBand];
        else cur = eqGain[selectedChannel][selectedBand];
        drawSliderMapped(c, sx, sy, ex, cur, min, max, Color.rgb(28, 149, 245), log);
        addHit(type == 0 ? "eqFreq" : (type == 1 ? "eqQ" : "eqGain"), 0, sx - 5, sy - 13, (ex - sx) + 10, 27, true);

        if (type == 0) {
            text(c, "20 Hz", sx, y + 50, 8.5f, Color.rgb(113, 129, 153), regular);
            textRight(c, "20 kHz", ex, y + 50, 8.5f, Color.rgb(113, 129, 153), regular);
        } else if (type == 1) {
            text(c, "0.1", sx, y + 50, 8.5f, Color.rgb(113, 129, 153), regular);
            textRight(c, "10.0", ex, y + 50, 8.5f, Color.rgb(113, 129, 153), regular);
        } else {
            text(c, "-12 dB", sx, y + 50, 8.5f, Color.rgb(113, 129, 153), regular);
            textRight(c, "+12 dB", ex, y + 50, 8.5f, Color.rgb(113, 129, 153), regular);
        }
    }

    private void drawHeader(Canvas c, String title, String subtitle, float y) {
        float x = layoutLeft + 20;
        text(c, title, x, y + 28, title.length() > 5 ? 26f : 27f, Color.rgb(12, 18, 29), bold);
        text(c, subtitle, x, y + 47, 12.6f, Color.rgb(119, 134, 158), regular);

        float bx2 = layoutLeft + layoutWidth - 36;
        float bx1 = bx2 - 44;
        drawSoftCircle(c, bx1, y + 24, 19, Color.rgb(242, 247, 253));
        drawSearch(c, bx1, y + 24, Color.rgb(12, 22, 37));
        drawSoftCircle(c, bx2, y + 24, 19, Color.rgb(242, 247, 253));
        drawDots(c, bx2, y + 24, Color.rgb(13, 23, 38));
        addHit("search", 0, bx1 - 21, y + 3, 42, 42, true);
        addHit("menu", 0, bx2 - 21, y + 3, 42, 42, true);
    }

    private void drawBottomNav(Canvas c) {
        float x = layoutLeft + 16;
        float y = screenHdp - navHeight + 6;
        float w = layoutWidth - 32;
        drawCardScreen(c, x, y, w, navHeight - 12, 20f, Color.WHITE);
        float itemW = w / 3f;
        String[] names = {"Home", "Mix", "Eq"};
        for (int i = 0; i < 3; i++) {
            float cx = x + itemW * (i + 0.5f);
            boolean active = page == i;
            if (active) roundRectScreen(c, x + itemW * i + 12, y + 7, itemW - 24, 34, 14, Color.rgb(233, 244, 255));
            int col = active ? Color.rgb(19, 132, 243) : Color.rgb(101, 121, 149);
            if (i == 0) drawHomeIcon(c, cx, y + 22, col);
            else if (i == 1) drawMixIcon(c, cx, y + 22, col);
            else drawBarsIcon(c, cx, y + 22, col);
            textCenteredScreen(c, names[i], cx, y + 52, 11.5f, col, active ? medium : regular);
            addHitScreen("nav", i, x + itemW * i, y, itemW, navHeight - 12);
        }
    }

    private void drawMenuPopup(Canvas c) {
        float w = 142f;
        float x = layoutLeft + layoutWidth - w - 15f;
        float y = 67f;
        drawCardScreen(c, x, y, w, 86f, 14f, Color.WHITE);
        textScreen(c, "About Version 1", x + 14, y + 29, 11.2f, Color.rgb(35, 47, 64), medium);
        textScreen(c, "Reset UI values", x + 14, y + 64, 11.2f, Color.rgb(35, 47, 64), medium);
        lineScreen(c, x + 8, y + 43, x + w - 8, y + 43, Color.rgb(235, 239, 245), 1);
        addHitScreen("about", 0, x, y, w, 43);
        addHitScreen("resetUi", 0, x, y + 43, w, 43);
    }

    // ----------------------------- Touch ------------------------------------

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX() / density;
        float y = e.getY() / density;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = x;
                downY = y;
                lastY = y;
                dragged = false;
                activeHit = findHit(x, y);
                if (activeHit != null && isSlider(activeHit.id)) {
                    updateSlider(activeHit, x);
                }
                return true;
            case MotionEvent.ACTION_MOVE:
                if (activeHit != null && isSlider(activeHit.id)) {
                    if (Math.abs(x - downX) > 1f) dragged = true;
                    updateSlider(activeHit, x);
                } else {
                    float dy = y - lastY;
                    if (Math.abs(y - downY) > 4f) dragged = true;
                    if (dragged && y < screenHdp - navHeight) {
                        scrollY = clamp(scrollY - dy, 0, maxScroll);
                        invalidate();
                    }
                    lastY = y;
                }
                return true;
            case MotionEvent.ACTION_UP:
                if (!dragged && activeHit != null && !isSlider(activeHit.id)) {
                    handleTap(activeHit);
                }
                activeHit = null;
                return true;
            case MotionEvent.ACTION_CANCEL:
                activeHit = null;
                return true;
        }
        return super.onTouchEvent(e);
    }

    private boolean isSlider(String id) {
        return id.equals("mixSlider") || id.equals("channelSlider") || id.equals("eqFreq") || id.equals("eqQ") || id.equals("eqGain");
    }

    private void updateSlider(Hit h, float touchX) {
        float t = clamp((touchX - h.sliderStart) / (h.sliderEnd - h.sliderStart), 0, 1);
        if (h.id.equals("mixSlider")) {
            if (h.index == 0) masterDb = snap(-24 + t * 30, 0.5f);
            else if (h.index == 1) bassDb = snap(-12 + t * 24, 0.5f);
            else bassCutoff = Math.round(40 + t * 120);
        } else if (h.id.equals("channelSlider")) {
            channelDb[h.index] = snap(-18 + t * 24, 0.5f);
        } else if (h.id.equals("eqFreq")) {
            double min = Math.log10(20), max = Math.log10(20000);
            eqFreq[selectedChannel][selectedBand] = (float) Math.pow(10, min + t * (max - min));
        } else if (h.id.equals("eqQ")) {
            eqQ[selectedChannel][selectedBand] = snap(0.1f + t * 9.9f, 0.1f);
        } else if (h.id.equals("eqGain")) {
            eqGain[selectedChannel][selectedBand] = snap(-12 + t * 24, 0.1f);
        }
        invalidate();
    }

    private void handleTap(Hit h) {
        switch (h.id) {
            case "nav":
                page = h.index;
                scrollY = 0;
                menuOpen = false;
                break;
            case "quick":
                page = PAGE_MIX;
                scrollY = 0;
                break;
            case "search":
                toast("Search button active • Phase 1 UI mode");
                break;
            case "menu":
                menuOpen = !menuOpen;
                break;
            case "about":
                menuOpen = false;
                toast("OKN DSP Version 1 • Phase 1 UI");
                break;
            case "resetUi":
                menuOpen = false;
                resetUi();
                toast("UI values reset");
                break;
            case "homeStatus":
                toast("System status panel active • DSP binding starts in Phase 2");
                break;
            case "homeRow":
                toast("Status item " + (h.index + 1) + " selected");
                break;
            case "eqChannel":
                selectedChannel = h.index;
                selectedBand = 0;
                break;
            case "eqPoint":
                selectedBand = h.index;
                break;
            case "eqReset":
                Arrays.fill(eqGain[selectedChannel], 0f);
                Arrays.fill(eqQ[selectedChannel], 1f);
                toast("Channel " + (selectedChannel + 1) + " EQ reset");
                break;
            case "bandArrow":
                selectedBand = (selectedBand + h.index + 15) % 15;
                break;
            case "presetSave":
                savePreset();
                break;
            case "presetLoad":
                loadPreset();
                break;
            case "presetCycle":
                selectedPreset = selectedPreset.equals("Flat") ? "User 1" : (selectedPreset.equals("User 1") ? "Reference" : "Flat");
                break;
            case "presetMenu":
                toast("Preset menu active");
                break;
        }
        invalidate();
    }

    private void savePreset() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 15; i++) {
            if (i > 0) sb.append(',');
            sb.append(eqFreq[selectedChannel][i]).append(':')
                    .append(eqQ[selectedChannel][i]).append(':')
                    .append(eqGain[selectedChannel][i]);
        }
        prefs.edit().putString("preset_ch_" + selectedChannel, sb.toString()).apply();
        selectedPreset = "User 1";
        toast("User 1 preset saved locally");
    }

    private void loadPreset() {
        if (selectedPreset.equals("Flat")) {
            Arrays.fill(eqGain[selectedChannel], 0f);
            Arrays.fill(eqQ[selectedChannel], 1f);
            toast("Flat preset loaded");
            return;
        }
        String data = prefs.getString("preset_ch_" + selectedChannel, null);
        if (data == null) {
            toast("No local User 1 preset yet");
            return;
        }
        try {
            String[] bands = data.split(",");
            for (int i = 0; i < Math.min(15, bands.length); i++) {
                String[] v = bands[i].split(":");
                eqFreq[selectedChannel][i] = Float.parseFloat(v[0]);
                eqQ[selectedChannel][i] = Float.parseFloat(v[1]);
                eqGain[selectedChannel][i] = Float.parseFloat(v[2]);
            }
            toast("User 1 preset loaded");
        } catch (Exception ex) {
            toast("Preset data is invalid");
        }
    }

    private void resetUi() {
        masterDb = -6f;
        bassDb = 2f;
        bassCutoff = 80f;
        float[] v = {-3f, -6f, -2f, -8f, 0f, -4f, -10f};
        System.arraycopy(v, 0, channelDb, 0, 7);
        initEq();
        selectedChannel = 0;
        selectedBand = 0;
        selectedPreset = "Flat";
        scrollY = 0;
    }

    private Hit findHit(float x, float y) {
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (h.rect.contains(x, y)) return h;
        }
        return null;
    }

    // --------------------------- Drawing helpers ----------------------------

    private void drawCard(Canvas c, float x, float y, float w, float h, float r, int color) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        p.setShadowLayer(d(7), 0, d(2), Color.argb(20, 40, 74, 120));
        c.drawRoundRect(new RectF(d(x), d(y), d(x + w), d(y + h)), d(r), d(r), p);
        p.clearShadowLayer();
    }

    private void drawCardScreen(Canvas c, float x, float y, float w, float h, float r, int color) {
        drawCard(c, x, y, w, h, r, color);
    }

    private void roundRect(Canvas c, float x, float y, float w, float h, float r, int color) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        c.drawRoundRect(new RectF(d(x), d(y), d(x + w), d(y + h)), d(r), d(r), p);
    }

    private void roundRectScreen(Canvas c, float x, float y, float w, float h, float r, int color) {
        roundRect(c, x, y, w, h, r, color);
    }

    private void roundRectStroke(Canvas c, float x, float y, float w, float h, float r, int fill, int border, float sw) {
        roundRect(c, x, y, w, h, r, fill);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(d(sw));
        stroke.setColor(border);
        c.drawRoundRect(new RectF(d(x), d(y), d(x + w), d(y + h)), d(r), d(r), stroke);
    }

    private void drawSoftCircle(Canvas c, float cx, float cy, float r, int color) {
        p.setColor(color);
        p.setStyle(Paint.Style.FILL);
        c.drawCircle(d(cx), d(cy), d(r), p);
    }

    private void drawValuePill(Canvas c, float x, float y, float w, float h, String value) {
        roundRect(c, x, y, w, h, 9, Color.rgb(245, 248, 252));
        textCentered(c, value, x + w / 2, y + h / 2 + 4, 10.7f, Color.rgb(33, 43, 57), medium);
    }

    private void drawSlider(Canvas c, float sx, float sy, float ex, float val, float min, float max, int color) {
        drawSliderMapped(c, sx, sy, ex, val, min, max, color, false);
    }

    private void drawSliderMapped(Canvas c, float sx, float sy, float ex, float val, float min, float max, int color, boolean log) {
        float t;
        if (log) {
            double a = Math.log10(min), b = Math.log10(max);
            t = (float) ((Math.log10(Math.max(min, val)) - a) / (b - a));
        } else t = (val - min) / (max - min);
        t = clamp(t, 0, 1);
        float kx = sx + (ex - sx) * t;
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeWidth(d(4.5f));
        stroke.setColor(Color.rgb(218, 227, 238));
        c.drawLine(d(sx), d(sy), d(ex), d(sy), stroke);
        stroke.setColor(color);
        c.drawLine(d(sx), d(sy), d(kx), d(sy), stroke);
        p.setShadowLayer(d(3), 0, d(1), Color.argb(45, 20, 50, 80));
        p.setColor(Color.WHITE);
        c.drawCircle(d(kx), d(sy), d(7.3f), p);
        p.clearShadowLayer();
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(d(1.1f));
        stroke.setColor(Color.rgb(211, 220, 231));
        c.drawCircle(d(kx), d(sy), d(7.3f), stroke);
        if (activeHit != null && (activeHit.id.equals("eqFreq") || activeHit.id.equals("eqQ") || activeHit.id.equals("eqGain"))) {
            // no-op: redraw is already immediate; keep knob clean.
        }
    }

    private void drawCircleButton(Canvas c, float cx, float cy, boolean selected, int dir) {
        drawSoftCircle(c, cx, cy, 14, Color.rgb(246, 249, 252));
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(d(1.6f));
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setColor(Color.rgb(50, 65, 86));
        Path path = new Path();
        if (dir < 0) {
            path.moveTo(d(cx + 2), d(cy - 5));
            path.lineTo(d(cx - 3), d(cy));
            path.lineTo(d(cx + 2), d(cy + 5));
        } else {
            path.moveTo(d(cx - 2), d(cy - 5));
            path.lineTo(d(cx + 3), d(cy));
            path.lineTo(d(cx - 2), d(cy + 5));
        }
        c.drawPath(path, stroke);
    }

    private void drawSearch(Canvas c, float cx, float cy, int color) {
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(d(1.8f));
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setColor(color);
        c.drawCircle(d(cx - 2), d(cy - 2), d(6.3f), stroke);
        c.drawLine(d(cx + 2.5f), d(cy + 2.5f), d(cx + 7), d(cy + 7), stroke);
    }

    private void drawDots(Canvas c, float cx, float cy, int color) {
        p.setColor(color);
        for (int i = -1; i <= 1; i++) c.drawCircle(d(cx), d(cy + i * 5), d(1.3f), p);
    }

    private void drawChevron(Canvas c, float cx, float cy, int color) {
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(d(1.6f));
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setColor(color);
        c.drawLine(d(cx - 2), d(cy - 5), d(cx + 2), d(cy), stroke);
        c.drawLine(d(cx + 2), d(cy), d(cx - 2), d(cy + 5), stroke);
    }

    private void drawCheck(Canvas c, float cx, float cy, float size, int color, float sw) {
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(d(sw));
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        stroke.setColor(color);
        Path path = new Path();
        path.moveTo(d(cx - size * .55f), d(cy));
        path.lineTo(d(cx - size * .12f), d(cy + size * .38f));
        path.lineTo(d(cx + size * .62f), d(cy - size * .48f));
        c.drawPath(path, stroke);
    }

    private void drawMiniIcon(Canvas c, int icon, float cx, float cy, int color) {
        switch (icon) {
            case 0: drawBluetooth(c, cx, cy, color); break;
            case 1: drawChip(c, cx, cy, color); break;
            case 2: drawWaveIcon(c, cx, cy, color); break;
            case 3: drawSpeakerIcon(c, cx, cy, color); break;
            case 4: drawDocumentIcon(c, cx, cy, color); break;
            case 5: drawGear(c, cx, cy, color); break;
            default: drawFilterIcon(c, cx, cy, color); break;
        }
    }

    private void drawBluetooth(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(d(1.5f)); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeCap(Paint.Cap.ROUND);
        Path path = new Path();
        path.moveTo(d(cx), d(cy - 9)); path.lineTo(d(cx + 5), d(cy - 4)); path.lineTo(d(cx - 4), d(cy + 5));
        path.moveTo(d(cx), d(cy + 9)); path.lineTo(d(cx + 5), d(cy + 4)); path.lineTo(d(cx - 4), d(cy - 5));
        path.moveTo(d(cx), d(cy - 9)); path.lineTo(d(cx), d(cy + 9));
        c.drawPath(path, stroke);
    }

    private void drawChip(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(d(1.3f)); stroke.setStyle(Paint.Style.STROKE);
        c.drawRoundRect(new RectF(d(cx - 6), d(cy - 6), d(cx + 6), d(cy + 6)), d(1.5f), d(1.5f), stroke);
        for (int i = -1; i <= 1; i++) {
            float q = i * 4f;
            c.drawLine(d(cx - 9), d(cy + q), d(cx - 6), d(cy + q), stroke);
            c.drawLine(d(cx + 6), d(cy + q), d(cx + 9), d(cy + q), stroke);
            c.drawLine(d(cx + q), d(cy - 9), d(cx + q), d(cy - 6), stroke);
            c.drawLine(d(cx + q), d(cy + 6), d(cx + q), d(cy + 9), stroke);
        }
    }

    private void drawWaveIcon(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStrokeWidth(d(1.5f)); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeCap(Paint.Cap.ROUND);
        Path path = new Path();
        path.moveTo(d(cx - 9), d(cy));
        path.cubicTo(d(cx - 6), d(cy - 8), d(cx - 4), d(cy + 8), d(cx - 1), d(cy));
        path.cubicTo(d(cx + 2), d(cy - 8), d(cx + 4), d(cy + 8), d(cx + 7), d(cy));
        path.lineTo(d(cx + 9), d(cy));
        c.drawPath(path, stroke);
    }

    private void drawSpeakerIcon(Canvas c, float cx, float cy, int color) {
        p.setColor(color); p.setStyle(Paint.Style.FILL);
        Path sp = new Path();
        sp.moveTo(d(cx - 8), d(cy - 3)); sp.lineTo(d(cx - 4), d(cy - 3)); sp.lineTo(d(cx + 1), d(cy - 8));
        sp.lineTo(d(cx + 1), d(cy + 8)); sp.lineTo(d(cx - 4), d(cy + 3)); sp.lineTo(d(cx - 8), d(cy + 3)); sp.close();
        c.drawPath(sp, p);
        stroke.setColor(color); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(d(1.2f));
        c.drawArc(new RectF(d(cx - 1), d(cy - 6), d(cx + 9), d(cy + 6)), -55, 110, false, stroke);
    }

    private void drawDocumentIcon(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(d(1.3f));
        c.drawRoundRect(new RectF(d(cx - 6), d(cy - 8), d(cx + 6), d(cy + 8)), d(1.3f), d(1.3f), stroke);
        for (int i = 0; i < 3; i++) c.drawLine(d(cx - 3), d(cy - 3 + i * 4), d(cx + 3), d(cy - 3 + i * 4), stroke);
    }

    private void drawGear(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(d(1.6f));
        c.drawCircle(d(cx), d(cy), d(6), stroke);
        c.drawCircle(d(cx), d(cy), d(2), stroke);
        for (int i = 0; i < 8; i++) {
            double a = i * Math.PI / 4;
            c.drawLine(d(cx + (float)Math.cos(a) * 7), d(cy + (float)Math.sin(a) * 7), d(cx + (float)Math.cos(a) * 9), d(cy + (float)Math.sin(a) * 9), stroke);
        }
    }

    private void drawFilterIcon(Canvas c, float cx, float cy, int color) {
        p.setColor(color); p.setStyle(Paint.Style.FILL);
        Path path = new Path();
        path.moveTo(d(cx - 8), d(cy - 7)); path.lineTo(d(cx + 8), d(cy - 7)); path.lineTo(d(cx + 2), d(cy));
        path.lineTo(d(cx + 2), d(cy + 7)); path.lineTo(d(cx - 1), d(cy + 5)); path.lineTo(d(cx - 1), d(cy)); path.close();
        c.drawPath(path, p);
    }

    private void drawResetIcon(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(d(1.3f)); stroke.setStrokeCap(Paint.Cap.ROUND);
        c.drawArc(new RectF(d(cx - 5), d(cy - 5), d(cx + 5), d(cy + 5)), -70, 285, false, stroke);
        c.drawLine(d(cx - 5), d(cy - 3), d(cx - 6), d(cy - 8), stroke);
        c.drawLine(d(cx - 5), d(cy - 3), d(cx - 1), d(cy - 5), stroke);
    }

    private void drawSaveIcon(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(d(1.2f));
        c.drawRect(d(cx - 6), d(cy - 7), d(cx + 6), d(cy + 7), stroke);
        c.drawRect(d(cx - 3), d(cy - 6), d(cx + 3), d(cy - 1), stroke);
        c.drawRect(d(cx - 3), d(cy + 2), d(cx + 3), d(cy + 6), stroke);
    }

    private void drawFolderIcon(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(d(1.2f));
        Path path = new Path();
        path.moveTo(d(cx - 7), d(cy - 5)); path.lineTo(d(cx - 2), d(cy - 5)); path.lineTo(d(cx), d(cy - 2));
        path.lineTo(d(cx + 7), d(cy - 2)); path.lineTo(d(cx + 7), d(cy + 6)); path.lineTo(d(cx - 7), d(cy + 6)); path.close();
        c.drawPath(path, stroke);
    }

    private void drawSmallDown(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(d(1.2f)); stroke.setStrokeCap(Paint.Cap.ROUND);
        c.drawLine(d(cx - 3), d(cy - 1), d(cx), d(cy + 2), stroke);
        c.drawLine(d(cx), d(cy + 2), d(cx + 3), d(cy - 1), stroke);
    }

    private void drawHomeIcon(Canvas c, float cx, float cy, int color) {
        p.setColor(color); p.setStyle(Paint.Style.FILL);
        Path path = new Path();
        path.moveTo(d(cx - 9), d(cy)); path.lineTo(d(cx), d(cy - 8)); path.lineTo(d(cx + 9), d(cy));
        path.lineTo(d(cx + 7), d(cy)); path.lineTo(d(cx + 7), d(cy + 8)); path.lineTo(d(cx + 2), d(cy + 8));
        path.lineTo(d(cx + 2), d(cy + 2)); path.lineTo(d(cx - 2), d(cy + 2)); path.lineTo(d(cx - 2), d(cy + 8));
        path.lineTo(d(cx - 7), d(cy + 8)); path.lineTo(d(cx - 7), d(cy)); path.close(); c.drawPath(path, p);
    }

    private void drawMixIcon(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(d(1.6f)); stroke.setStrokeCap(Paint.Cap.ROUND);
        float[] dx = {-7, 0, 7}; float[] knob = {-3, 5, -1};
        for (int i = 0; i < 3; i++) {
            float xx = cx + dx[i]; c.drawLine(d(xx), d(cy - 10), d(xx), d(cy + 10), stroke);
            p.setColor(color); c.drawCircle(d(xx), d(cy + knob[i]), d(2.5f), p);
        }
    }

    private void drawBarsIcon(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(d(2.2f)); stroke.setStrokeCap(Paint.Cap.ROUND);
        c.drawLine(d(cx - 8), d(cy + 8), d(cx - 8), d(cy - 2), stroke);
        c.drawLine(d(cx), d(cy + 8), d(cx), d(cy - 9), stroke);
        c.drawLine(d(cx + 8), d(cy + 8), d(cx + 8), d(cy - 5), stroke);
    }

    private float freqToX(float f, float left, float right) {
        double min = Math.log10(20.0), max = Math.log10(20000.0);
        float t = (float) ((Math.log10(clamp(f, 20, 20000)) - min) / (max - min));
        return left + t * (right - left);
    }

    private float gainToY(float gain, float top, float bottom) {
        float t = (12f - clamp(gain, -12, 12)) / 24f;
        return top + t * (bottom - top);
    }

    private void line(Canvas c, float x1, float y1, float x2, float y2, int color, float sw) {
        stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(d(sw)); stroke.setColor(color);
        c.drawLine(d(x1), d(y1), d(x2), d(y2), stroke);
    }

    private void lineScreen(Canvas c, float x1, float y1, float x2, float y2, int color, float sw) {
        line(c, x1, y1, x2, y2, color, sw);
    }

    private void text(Canvas c, String s, float x, float baseline, float size, int color, Typeface typeface) {
        p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(color); p.setTypeface(typeface); p.setTextSize(d(size));
        c.drawText(s, d(x), d(baseline), p);
    }

    private void textScreen(Canvas c, String s, float x, float baseline, float size, int color, Typeface typeface) { text(c, s, x, baseline, size, color, typeface); }

    private void textRight(Canvas c, String s, float right, float baseline, float size, int color, Typeface typeface) {
        p.setTypeface(typeface); p.setTextSize(d(size));
        text(c, s, right - p.measureText(s) / density, baseline, size, color, typeface);
    }

    private void textCentered(Canvas c, String s, float cx, float baseline, float size, int color, Typeface typeface) {
        p.setTypeface(typeface); p.setTextSize(d(size));
        text(c, s, cx - (p.measureText(s) / density) / 2f, baseline, size, color, typeface);
    }

    private void textCenteredScreen(Canvas c, String s, float cx, float baseline, float size, int color, Typeface typeface) { textCentered(c, s, cx, baseline, size, color, typeface); }

    private void addHit(String id, int index, float x, float y, float w, float h, boolean scrollAware) {
        float yy = scrollAware ? y - scrollY : y;
        Hit hit = new Hit(id, index, new RectF(x, yy, x + w, yy + h));
        if (isSlider(id)) {
            hit.sliderStart = x + 6;
            hit.sliderEnd = x + w - 6;
        }
        hits.add(hit);
    }

    private void addHitScreen(String id, int index, float x, float y, float w, float h) {
        hits.add(new Hit(id, index, new RectF(x, y, x + w, y + h)));
    }

    private float d(float dp) { return dp * density; }
    private float clamp(float v, float min, float max) { return Math.max(min, Math.min(max, v)); }
    private float snap(float v, float step) { return Math.round(v / step) * step; }

    private int lighten(int color, float factor) {
        int r = Color.red(color), g = Color.green(color), b = Color.blue(color);
        r = (int)(r + (255 - r) * factor); g = (int)(g + (255 - g) * factor); b = (int)(b + (255 - b) * factor);
        return Color.rgb(clampInt(r), clampInt(g), clampInt(b));
    }
    private int clampInt(int v) { return Math.max(0, Math.min(255, v)); }

    private String formatDb(float v) {
        if (Math.abs(v - Math.round(v)) < .05f) return String.format(Locale.US, "%d dB", Math.round(v));
        return String.format(Locale.US, "%.1f dB", v);
    }
    private String formatDbOne(float v) { return String.format(Locale.US, "%.1f dB", v); }
    private String formatFreq(float f) {
        if (f >= 1000) return f >= 10000 ? String.format(Locale.US, "%.0f kHz", f / 1000f) : String.format(Locale.US, "%.1f kHz", f / 1000f);
        return String.format(Locale.US, "%.0f Hz", f);
    }

    private void toast(String message) { Toast.makeText(getContext(), message, Toast.LENGTH_SHORT).show(); }

    private static class Hit {
        final String id;
        final int index;
        final RectF rect;
        float sliderStart;
        float sliderEnd;
        Hit(String id, int index, RectF rect) { this.id = id; this.index = index; this.rect = rect; }
    }
}
