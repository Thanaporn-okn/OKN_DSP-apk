package com.okn.dsp;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Fresh Phase 1 UI renderer for OKN DSP V1.
 *
 * The uploaded reference poster is used only as a visual design guide. No screenshot is painted as
 * a screen background. Cards, controls, graph, tabs, icons and all interactions are drawn from code.
 */
public final class DspUiView extends View {
    public interface Host {
        void onThemeChanged();
    }

    private static final int HIT_THEME = 1;
    private static final int HIT_NAV_HOME = 10;
    private static final int HIT_NAV_MIX = 11;
    private static final int HIT_NAV_EQ = 12;
    private static final int HIT_HOME_CARD = 20;

    private static final int HIT_MIX_MASTER = 100;
    private static final int HIT_MIX_BASS = 101;
    private static final int HIT_MIX_CUTOFF = 102;
    private static final int HIT_MIX_CHANNEL = 110;

    private static final int HIT_EQ_CHANNEL = 200;
    private static final int HIT_EQ_NODE = 210;
    private static final int HIT_EQ_PREV = 220;
    private static final int HIT_EQ_NEXT = 221;
    private static final int HIT_EQ_FREQ = 230;
    private static final int HIT_EQ_Q = 231;
    private static final int HIT_EQ_GAIN = 232;
    private static final int HIT_EQ_RESET = 240;
    private static final int HIT_EQ_SAVE = 250;
    private static final int HIT_EQ_LOAD = 251;
    private static final int HIT_EQ_DELETE = 252;

    private static final int[] BAND_COLORS = new int[] {
            Color.rgb(36, 126, 255),
            Color.rgb(27, 193, 230),
            Color.rgb(35, 196, 166),
            Color.rgb(41, 197, 111),
            Color.rgb(255, 47, 109),
            Color.rgb(255, 72, 103),
            Color.rgb(124, 92, 255)
    };

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final UiStateStore store;
    private final DspTransport transport;
    private final Host host;
    private final float density;
    private final int touchSlop;
    private final Bitmap appIcon;

    private final List<HitTarget> hits = new ArrayList<>();
    private final float[] pageScroll = new float[] {0f, 0f, 0f};
    private final float[] pageMaxScroll = new float[] {0f, 0f, 0f};

    private float downX;
    private float downY;
    private float lastY;
    private boolean scrolling;
    private HitTarget activeHit;
    private String statusMessage = "Phase 1 • UI prototype • DSP transport disabled";

    private int bg;
    private int card;
    private int cardAlt;
    private int text;
    private int subText;
    private int line;
    private int blue;
    private int cyan;
    private int pink;
    private int red;
    private int green;
    private int violet;

    public DspUiView(Context context, UiStateStore store, DspTransport transport, Host host) {
        super(context);
        this.store = store;
        this.transport = transport;
        this.host = host;
        density = getResources().getDisplayMetrics().density;
        touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
        appIcon = BitmapFactory.decodeResource(getResources(), R.drawable.app_icon);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        setFocusable(true);
        setClickable(true);
    }

    public void resetScrollAndRefresh() {
        pageScroll[store.page] = 0f;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        resolveTheme();
        hits.clear();
        canvas.drawColor(bg);

        float width = getWidth();
        float height = getHeight();
        float headerH = dp(76);
        float navH = dp(78);
        float navTop = height - navH;

        drawHeader(canvas, width, headerH);

        canvas.save();
        canvas.clipRect(0, headerH, width, navTop);
        float bottom;
        if (store.page == UiStateStore.PAGE_MIX) {
            bottom = drawMix(canvas, width, headerH - pageScroll[store.page]);
        } else if (store.page == UiStateStore.PAGE_EQ) {
            bottom = drawEq(canvas, width, headerH - pageScroll[store.page]);
        } else {
            bottom = drawHome(canvas, width, headerH - pageScroll[store.page]);
        }
        canvas.restore();

        float contentHeight = Math.max(0f, bottom - (headerH - pageScroll[store.page]));
        float viewport = Math.max(1f, navTop - headerH);
        pageMaxScroll[store.page] = Math.max(0f, contentHeight - viewport + dp(12));
        pageScroll[store.page] = clamp(pageScroll[store.page], 0f, pageMaxScroll[store.page]);

        drawBottomNav(canvas, width, navTop, navH);
    }

    private void resolveTheme() {
        boolean dark = store.theme == UiStateStore.THEME_DARK;
        bg = Color.parseColor(dark ? "#0B111B" : "#F5F7FB");
        card = Color.parseColor(dark ? "#121C29" : "#FFFFFF");
        cardAlt = Color.parseColor(dark ? "#182433" : "#F0F4FA");
        text = Color.parseColor(dark ? "#F7FAFF" : "#0A1324");
        subText = Color.parseColor(dark ? "#98A6BA" : "#71809A");
        line = Color.parseColor(dark ? "#273548" : "#E2E8F0");
        blue = Color.rgb(38, 126, 255);
        cyan = Color.rgb(31, 205, 226);
        pink = Color.rgb(255, 47, 109);
        red = Color.rgb(255, 75, 85);
        green = Color.rgb(39, 199, 111);
        violet = Color.rgb(124, 92, 255);
    }

    private void drawHeader(Canvas c, float width, float headerH) {
        float left = dp(16);
        float icon = dp(42);
        float top = dp(12);

        if (appIcon != null) {
            paint.setAlpha(255);
            c.drawBitmap(appIcon, null, new RectF(left, top, left + icon, top + icon), paint);
        }

        float tx = left + icon + dp(10);
        drawText(c, "OKN DSP", tx, top + dp(17), sp(18), text, true);
        String subtitle = store.page == UiStateStore.PAGE_HOME ? "DSP Controller • V1" :
                (store.page == UiStateStore.PAGE_MIX ? "Channel and bass controls" : "15-band equalizer • 7 channels");
        drawText(c, subtitle, tx, top + dp(35), sp(11), subText, false);

        float themeSize = dp(38);
        float themeLeft = width - dp(16) - themeSize;
        RectF themeRect = new RectF(themeLeft, top + dp(1), themeLeft + themeSize, top + dp(1) + themeSize);
        fillRound(c, themeRect, dp(19), card);
        strokeRound(c, themeRect, dp(19), line, dp(1));
        drawThemeIcon(c, themeRect.centerX(), themeRect.centerY());
        addHit(themeRect, HIT_THEME, 0);
    }

    private float drawHome(Canvas c, float width, float startY) {
        Bounds b = contentBounds(width);
        float y = startY + dp(8);

        RectF hero = new RectF(b.left, y, b.right, y + dp(94));
        fillRound(c, hero, dp(20), card);
        strokeRound(c, hero, dp(20), line, dp(1));
        float cx = hero.left + dp(38);
        float cy = hero.top + dp(45);
        paint.setColor(withAlpha(green, 45));
        c.drawCircle(cx, cy, dp(25), paint);
        paint.setColor(green);
        c.drawCircle(cx, cy, dp(18), paint);
        drawCheck(c, cx, cy, Color.WHITE);
        drawText(c, "SYSTEM STATUS", hero.left + dp(74), hero.top + dp(26), sp(9), subText, true);
        drawText(c, "UI System Ready", hero.left + dp(74), hero.top + dp(46), sp(17), text, true);
        drawText(c, "Local state, theme and controls are active", hero.left + dp(74), hero.top + dp(66), sp(10), subText, false);
        drawText(c, "›", hero.right - dp(24), hero.centerY() + dp(6), sp(28), subText, false);
        addHit(hero, HIT_HOME_CARD, 0);
        y = hero.bottom + dp(16);

        drawText(c, "Connection & Status", b.left, y + dp(18), sp(16), text, true);
        drawTextRight(c, "Phase 1", b.right, y + dp(18), sp(11), blue, true);
        y += dp(30);

        String[][] rows = new String[][] {
                {"Bluetooth", "Hardware connection starts in Phase 2", "Not connected"},
                {"DSP Device", "Protocol data is not loaded yet", "Waiting"},
                {"Audio Input", "UI preview", "Ready"},
                {"Amplifier Link", "Transport hook prepared", "Phase 2"},
                {"Preset Sync", "Realtime local autosave", "Active"},
                {"Firmware Status", "No firmware query in Phase 1", "UI only"},
                {"Quick Control", "Open master, bass and channel controls", "Open"}
        };
        int[] rowColors = new int[] {blue, pink, cyan, red, green, violet, pink};
        for (int i = 0; i < rows.length; i++) {
            RectF r = new RectF(b.left, y, b.right, y + dp(66));
            fillRound(c, r, dp(15), card);
            strokeRound(c, r, dp(15), line, dp(1));
            drawCircleIcon(c, r.left + dp(28), r.centerY(), rowColors[i], i);
            drawText(c, rows[i][0], r.left + dp(55), r.top + dp(25), sp(13), text, true);
            drawText(c, rows[i][1], r.left + dp(55), r.top + dp(43), sp(9.5f), subText, false);
            drawTextRight(c, rows[i][2], r.right - dp(24), r.top + dp(35), sp(9.5f),
                    i == 0 || i == 1 || i == 3 || i == 5 ? subText : rowColors[i], true);
            drawText(c, "›", r.right - dp(14), r.top + dp(40), sp(21), subText, false);
            addHit(r, HIT_HOME_CARD, i + 1);
            y = r.bottom + dp(8);
        }

        RectF info = new RectF(b.left, y + dp(4), b.right, y + dp(52));
        fillRound(c, info, dp(14), withAlpha(blue, store.theme == UiStateStore.THEME_DARK ? 30 : 18));
        drawText(c, statusMessage, info.left + dp(14), info.centerY() + dp(4), sp(9.5f), text, false);
        y = info.bottom + dp(16);
        return y;
    }

    private float drawMix(Canvas c, float width, float startY) {
        Bounds b = contentBounds(width);
        float y = startY + dp(8);

        RectF global = new RectF(b.left, y, b.right, y + dp(240));
        fillRound(c, global, dp(18), card);
        strokeRound(c, global, dp(18), line, dp(1));
        drawText(c, "Global", global.left + dp(14), global.top + dp(25), sp(16), text, true);
        drawTextRight(c, "Overall output and bass settings", global.right - dp(14), global.top + dp(25), sp(9), subText, false);

        float rowY = global.top + dp(48);
        drawSliderRow(c, global.left + dp(12), rowY, global.width() - dp(24), "Master Volume",
                store.masterVolume, -60f, 12f, String.format(Locale.US, "%.0f dB", store.masterVolume), pink,
                HIT_MIX_MASTER, 0, false);
        rowY += dp(62);
        drawSliderRow(c, global.left + dp(12), rowY, global.width() - dp(24), "Bass Volume",
                store.bassVolume, -12f, 12f, String.format(Locale.US, "%.0f dB", store.bassVolume), cyan,
                HIT_MIX_BASS, 0, false);
        rowY += dp(62);
        drawSliderRow(c, global.left + dp(12), rowY, global.width() - dp(24), "Bass Cutoff",
                store.bassCutoff, 40f, 250f, String.format(Locale.US, "%.0f Hz", store.bassCutoff), pink,
                HIT_MIX_CUTOFF, 0, false);
        y = global.bottom + dp(12);

        float channelsH = dp(45 + 7 * 61 + 12);
        RectF channels = new RectF(b.left, y, b.right, y + channelsH);
        fillRound(c, channels, dp(18), card);
        strokeRound(c, channels, dp(18), line, dp(1));
        drawText(c, "Channels", channels.left + dp(14), channels.top + dp(25), sp(16), text, true);
        drawTextRight(c, "Individual channel levels", channels.right - dp(14), channels.top + dp(25), sp(9), subText, false);

        rowY = channels.top + dp(44);
        for (int ch = 0; ch < UiStateStore.CHANNEL_COUNT; ch++) {
            int accent = BAND_COLORS[ch % BAND_COLORS.length];
            drawSliderRow(c, channels.left + dp(12), rowY, channels.width() - dp(24), "Volume Ch" + (ch + 1),
                    store.channelVolumes[ch], -60f, 12f,
                    String.format(Locale.US, "%.0f dB", store.channelVolumes[ch]), accent,
                    HIT_MIX_CHANNEL, ch, true);
            rowY += dp(61);
        }
        y = channels.bottom + dp(16);

        RectF info = new RectF(b.left, y, b.right, y + dp(54));
        fillRound(c, info, dp(14), cardAlt);
        drawText(c, "Realtime local persistence", info.left + dp(14), info.top + dp(21), sp(11), text, true);
        drawText(c, "Values redraw immediately and are saved while dragging.", info.left + dp(14), info.top + dp(39), sp(9.5f), subText, false);
        y = info.bottom + dp(16);
        return y;
    }

    private float drawEq(Canvas c, float width, float startY) {
        Bounds b = contentBounds(width);
        float y = startY + dp(8);

        float chipGap = dp(5);
        float chipW = (b.width() - chipGap * 6f) / 7f;
        for (int ch = 0; ch < 7; ch++) {
            float x = b.left + ch * (chipW + chipGap);
            RectF chip = new RectF(x, y, x + chipW, y + dp(34));
            boolean selected = ch == store.selectedChannel;
            fillRound(c, chip, dp(17), selected ? pink : card);
            strokeRound(c, chip, dp(17), selected ? pink : line, dp(1));
            drawTextCentered(c, "Ch" + (ch + 1), chip.centerX(), chip.centerY() + dp(4), sp(9.5f), selected ? Color.WHITE : subText, true);
            addHit(chip, HIT_EQ_CHANNEL, ch);
        }
        y += dp(46);

        float chartH = dp(260);
        RectF chart = new RectF(b.left, y, b.right, y + chartH);
        fillRound(c, chart, dp(18), card);
        strokeRound(c, chart, dp(18), line, dp(1));
        drawText(c, "Channel " + (store.selectedChannel + 1), chart.left + dp(14), chart.top + dp(24), sp(16), text, true);
        drawText(c, "15-band EQ • draggable gain/frequency/Q", chart.left + dp(14), chart.top + dp(41), sp(9), subText, false);

        RectF reset = new RectF(chart.right - dp(92), chart.top + dp(11), chart.right - dp(12), chart.top + dp(40));
        fillRound(c, reset, dp(14), withAlpha(pink, store.theme == UiStateStore.THEME_DARK ? 40 : 22));
        drawTextCentered(c, "↻  Reset EQ", reset.centerX(), reset.centerY() + dp(4), sp(9), pink, true);
        addHit(reset, HIT_EQ_RESET, 0);

        RectF graph = new RectF(chart.left + dp(32), chart.top + dp(62), chart.right - dp(14), chart.bottom - dp(33));
        drawEqGraph(c, graph);
        drawText(c, "+12", chart.left + dp(7), graph.top + dp(5), sp(8), subText, false);
        drawText(c, "0", chart.left + dp(15), graph.centerY() + dp(3), sp(8), subText, false);
        drawText(c, "-12", chart.left + dp(7), graph.bottom, sp(8), subText, false);
        drawText(c, "20", graph.left, chart.bottom - dp(12), sp(7.5f), subText, false);
        drawTextCentered(c, "500", graph.left + graph.width() * 0.466f, chart.bottom - dp(12), sp(7.5f), subText, false);
        drawTextCentered(c, "2K", graph.left + graph.width() * 0.666f, chart.bottom - dp(12), sp(7.5f), subText, false);
        drawTextRight(c, "20K", graph.right, chart.bottom - dp(12), sp(7.5f), subText, false);
        y = chart.bottom + dp(12);

        RectF bandCard = new RectF(b.left, y, b.right, y + dp(304));
        fillRound(c, bandCard, dp(18), card);
        strokeRound(c, bandCard, dp(18), line, dp(1));

        float badgeCx = bandCard.left + dp(26);
        float badgeCy = bandCard.top + dp(26);
        paint.setColor(withAlpha(pink, store.theme == UiStateStore.THEME_DARK ? 55 : 30));
        c.drawCircle(badgeCx, badgeCy, dp(17), paint);
        drawTextCentered(c, String.valueOf(store.selectedBand + 1), badgeCx, badgeCy + dp(5), sp(13), pink, true);
        drawText(c, "Band " + (store.selectedBand + 1), bandCard.left + dp(52), bandCard.top + dp(24), sp(14), text, true);
        drawText(c, "Adjust the selected band parameters", bandCard.left + dp(52), bandCard.top + dp(40), sp(8.7f), subText, false);

        RectF prev = new RectF(bandCard.right - dp(72), bandCard.top + dp(10), bandCard.right - dp(42), bandCard.top + dp(40));
        RectF next = new RectF(bandCard.right - dp(36), bandCard.top + dp(10), bandCard.right - dp(6), bandCard.top + dp(40));
        fillRound(c, prev, dp(15), cardAlt); fillRound(c, next, dp(15), cardAlt);
        drawTextCentered(c, "‹", prev.centerX(), prev.centerY() + dp(5), sp(22), subText, true);
        drawTextCentered(c, "›", next.centerX(), next.centerY() + dp(5), sp(22), subText, true);
        addHit(prev, HIT_EQ_PREV, 0); addHit(next, HIT_EQ_NEXT, 0);

        int ch = store.selectedChannel;
        int band = store.selectedBand;
        float rowY = bandCard.top + dp(58);
        drawSliderRow(c, bandCard.left + dp(12), rowY, bandCard.width() - dp(24), "Frequency",
                logNorm(store.eqFrequency[ch][band], 20f, 20000f), 0f, 1f,
                UiStateStore.formatFrequency(store.eqFrequency[ch][band]), blue,
                HIT_EQ_FREQ, 0, false);
        rowY += dp(72);
        drawSliderRow(c, bandCard.left + dp(12), rowY, bandCard.width() - dp(24), "Q (Quality Factor)",
                store.eqQ[ch][band], 0.1f, 10f,
                String.format(Locale.US, "%.2f", store.eqQ[ch][band]), cyan,
                HIT_EQ_Q, 0, false);
        rowY += dp(72);
        drawSliderRow(c, bandCard.left + dp(12), rowY, bandCard.width() - dp(24), "Gain Band",
                store.eqGain[ch][band], -12f, 12f,
                String.format(Locale.US, "%+.1f dB", store.eqGain[ch][band]), green,
                HIT_EQ_GAIN, 0, false);
        y = bandCard.bottom + dp(12);

        RectF presets = new RectF(b.left, y, b.right, y + dp(145));
        fillRound(c, presets, dp(18), card);
        strokeRound(c, presets, dp(18), line, dp(1));
        drawText(c, "Presets", presets.left + dp(14), presets.top + dp(24), sp(15), text, true);
        drawText(c, "Save and restore all local Phase 1 control values", presets.left + dp(14), presets.top + dp(42), sp(9), subText, false);

        RectF slot = new RectF(presets.left + dp(12), presets.top + dp(54), presets.right - dp(12), presets.top + dp(88));
        fillRound(c, slot, dp(10), cardAlt);
        drawText(c, store.presetLabel(), slot.left + dp(12), slot.centerY() + dp(4), sp(9.5f), text, true);

        float gap = dp(7);
        float btnW = (presets.width() - dp(24) - gap * 2f) / 3f;
        RectF save = new RectF(presets.left + dp(12), presets.top + dp(98), presets.left + dp(12) + btnW, presets.bottom - dp(10));
        RectF load = new RectF(save.right + gap, save.top, save.right + gap + btnW, save.bottom);
        RectF del = new RectF(load.right + gap, save.top, presets.right - dp(12), save.bottom);
        fillRound(c, save, dp(11), pink);
        fillRound(c, load, dp(11), cardAlt);
        fillRound(c, del, dp(11), withAlpha(red, store.theme == UiStateStore.THEME_DARK ? 55 : 30));
        drawTextCentered(c, "Save", save.centerX(), save.centerY() + dp(4), sp(10), Color.WHITE, true);
        drawTextCentered(c, "Load", load.centerX(), load.centerY() + dp(4), sp(10), text, true);
        drawTextCentered(c, "Delete", del.centerX(), del.centerY() + dp(4), sp(10), red, true);
        addHit(save, HIT_EQ_SAVE, 0); addHit(load, HIT_EQ_LOAD, 0); addHit(del, HIT_EQ_DELETE, 0);
        y = presets.bottom + dp(16);

        RectF note = new RectF(b.left, y, b.right, y + dp(54));
        fillRound(c, note, dp(14), withAlpha(blue, store.theme == UiStateStore.THEME_DARK ? 28 : 18));
        drawText(c, statusMessage, note.left + dp(14), note.centerY() + dp(4), sp(9.3f), text, false);
        y = note.bottom + dp(16);
        return y;
    }

    private void drawEqGraph(Canvas c, RectF g) {
        stroke.setStrokeWidth(dp(1));
        stroke.setColor(line);
        for (int i = 0; i <= 4; i++) {
            float y = g.top + g.height() * i / 4f;
            c.drawLine(g.left, y, g.right, y, stroke);
        }
        for (int i = 0; i <= 6; i++) {
            float x = g.left + g.width() * i / 6f;
            c.drawLine(x, g.top, x, g.bottom, stroke);
        }

        int ch = store.selectedChannel;
        int selected = store.selectedBand;
        float selectedX = freqToX(store.eqFrequency[ch][selected], g);
        paint.setColor(withAlpha(pink, store.theme == UiStateStore.THEME_DARK ? 30 : 20));
        c.drawRect(selectedX - dp(12), g.top, selectedX + dp(12), g.bottom, paint);

        // Q visualization: selected-band bell width changes immediately with Q.
        float q = Math.max(0.1f, store.eqQ[ch][selected]);
        float gain = store.eqGain[ch][selected];
        float sigma = Math.max(dp(8), g.width() * 0.12f / (float)Math.sqrt(q));
        float centerY = gainToY(0f, g);
        float peakY = gainToY(gain, g);
        path.reset();
        for (int i = 0; i <= 80; i++) {
            float x = g.left + g.width() * i / 80f;
            float dx = (x - selectedX) / sigma;
            float influence = (float)Math.exp(-0.5f * dx * dx);
            float y = centerY + (peakY - centerY) * influence;
            if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
        }
        stroke.setStrokeWidth(dp(2));
        stroke.setColor(withAlpha(pink, 100));
        c.drawPath(path, stroke);

        for (int band = 0; band < UiStateStore.BAND_COUNT - 1; band++) {
            float x1 = freqToX(store.eqFrequency[ch][band], g);
            float y1 = gainToY(store.eqGain[ch][band], g);
            float x2 = freqToX(store.eqFrequency[ch][band + 1], g);
            float y2 = gainToY(store.eqGain[ch][band + 1], g);
            stroke.setStrokeWidth(dp(2.5f));
            stroke.setColor(BAND_COLORS[band % BAND_COLORS.length]);
            c.drawLine(x1, y1, x2, y2, stroke);
        }

        for (int band = 0; band < UiStateStore.BAND_COUNT; band++) {
            float x = freqToX(store.eqFrequency[ch][band], g);
            float y = gainToY(store.eqGain[ch][band], g);
            int color = band == selected ? pink : BAND_COLORS[band % BAND_COLORS.length];
            paint.setColor(card);
            c.drawCircle(x, y, dp(band == selected ? 6.5f : 5f), paint);
            paint.setColor(color);
            c.drawCircle(x, y, dp(band == selected ? 4.5f : 3.5f), paint);
            addHit(new RectF(x - dp(12), y - dp(12), x + dp(12), y + dp(12)), HIT_EQ_NODE, band);
        }
    }

    private void drawSliderRow(Canvas c, float x, float y, float w, String label,
                               float value, float min, float max, String valueText, int accent,
                               int hitType, int index, boolean channelBadge) {
        RectF row = new RectF(x, y, x + w, y + dp(58));
        fillRound(c, row, dp(13), cardAlt);

        float labelX = row.left + dp(channelBadge ? 45 : 12);
        if (channelBadge) {
            float cx = row.left + dp(22);
            float cy = row.centerY();
            paint.setColor(withAlpha(accent, store.theme == UiStateStore.THEME_DARK ? 65 : 35));
            c.drawCircle(cx, cy, dp(15), paint);
            drawTextCentered(c, String.valueOf(index + 1), cx, cy + dp(4.5f), sp(10.5f), accent, true);
        }
        drawText(c, label, labelX, row.top + dp(21), sp(10.5f), text, true);

        float valueChipW = dp(68);
        RectF valueChip = new RectF(row.right - valueChipW - dp(8), row.top + dp(8), row.right - dp(8), row.top + dp(31));
        fillRound(c, valueChip, dp(9), card);
        drawTextCentered(c, valueText, valueChip.centerX(), valueChip.centerY() + dp(3.5f), sp(8.7f), text, true);

        float sx1 = labelX;
        float sx2 = row.right - dp(14);
        float sy = row.bottom - dp(14);
        float norm = (max == min) ? 0f : clamp((value - min) / (max - min), 0f, 1f);
        float knobX = sx1 + (sx2 - sx1) * norm;

        stroke.setStrokeWidth(dp(4));
        stroke.setColor(line);
        c.drawLine(sx1, sy, sx2, sy, stroke);
        stroke.setColor(accent);
        c.drawLine(sx1, sy, knobX, sy, stroke);
        paint.setColor(card);
        c.drawCircle(knobX, sy, dp(7), paint);
        paint.setColor(accent);
        c.drawCircle(knobX, sy, dp(4.5f), paint);

        RectF hit = new RectF(sx1 - dp(8), sy - dp(18), sx2 + dp(8), sy + dp(18));
        addHit(hit, hitType, index);
    }

    private void drawBottomNav(Canvas c, float width, float top, float h) {
        paint.setColor(card);
        c.drawRect(0, top, width, top + h, paint);
        stroke.setColor(line);
        stroke.setStrokeWidth(dp(1));
        c.drawLine(0, top, width, top, stroke);

        float itemW = width / 3f;
        drawNavItem(c, new RectF(0, top, itemW, top + h), UiStateStore.PAGE_HOME, "Home", 0);
        drawNavItem(c, new RectF(itemW, top, itemW * 2f, top + h), UiStateStore.PAGE_MIX, "Mix", 1);
        drawNavItem(c, new RectF(itemW * 2f, top, width, top + h), UiStateStore.PAGE_EQ, "Eq", 2);
    }

    private void drawNavItem(Canvas c, RectF r, int page, String label, int icon) {
        boolean selected = store.page == page;
        if (selected) {
            RectF pill = new RectF(r.centerX() - dp(44), r.top + dp(8), r.centerX() + dp(44), r.bottom - dp(8));
            fillRound(c, pill, dp(18), withAlpha(pink, store.theme == UiStateStore.THEME_DARK ? 60 : 25));
        }
        int color = selected ? pink : subText;
        float cx = r.centerX();
        float cy = r.top + dp(26);
        if (icon == 0) drawHomeIcon(c, cx, cy, color);
        else if (icon == 1) drawMixIcon(c, cx, cy, color);
        else drawEqIcon(c, cx, cy, color);
        drawTextCentered(c, label, cx, r.top + dp(57), sp(9.5f), color, selected);
        addHit(r, page == UiStateStore.PAGE_HOME ? HIT_NAV_HOME : (page == UiStateStore.PAGE_MIX ? HIT_NAV_MIX : HIT_NAV_EQ), 0);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX();
        float y = event.getY();
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = x;
                downY = y;
                lastY = y;
                scrolling = false;
                activeHit = findHit(x, y);
                if (activeHit != null && isSlider(activeHit.type)) {
                    updateSlider(activeHit, x);
                }
                return true;

            case MotionEvent.ACTION_MOVE:
                if (activeHit != null && isSlider(activeHit.type)) {
                    updateSlider(activeHit, x);
                    return true;
                }
                if (!scrolling && Math.abs(y - downY) > touchSlop) {
                    scrolling = true;
                }
                if (scrolling) {
                    float dy = y - lastY;
                    pageScroll[store.page] = clamp(pageScroll[store.page] - dy, 0f, pageMaxScroll[store.page]);
                    lastY = y;
                    invalidate();
                }
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (activeHit != null && isSlider(activeHit.type)) {
                    updateSlider(activeHit, x);
                    store.commitFinal();
                } else if (!scrolling && event.getActionMasked() == MotionEvent.ACTION_UP && activeHit != null) {
                    handleTap(activeHit);
                }
                activeHit = null;
                scrolling = false;
                return true;
            default:
                return true;
        }
    }

    private boolean isSlider(int type) {
        return type == HIT_MIX_MASTER || type == HIT_MIX_BASS || type == HIT_MIX_CUTOFF ||
                type == HIT_MIX_CHANNEL || type == HIT_EQ_FREQ || type == HIT_EQ_Q || type == HIT_EQ_GAIN;
    }

    private void updateSlider(HitTarget hit, float x) {
        float norm = clamp((x - hit.rect.left) / Math.max(1f, hit.rect.width()), 0f, 1f);
        if (hit.type == HIT_MIX_MASTER) {
            store.masterVolume = lerp(-60f, 12f, norm);
            store.saveMasterAsync();
            transport.setMasterVolume(store.masterVolume);
        } else if (hit.type == HIT_MIX_BASS) {
            store.bassVolume = lerp(-12f, 12f, norm);
            store.saveBassVolumeAsync();
            transport.setBassVolume(store.bassVolume);
        } else if (hit.type == HIT_MIX_CUTOFF) {
            store.bassCutoff = lerp(40f, 250f, norm);
            store.saveBassCutoffAsync();
            transport.setBassCutoff(store.bassCutoff);
        } else if (hit.type == HIT_MIX_CHANNEL) {
            int ch = hit.index;
            store.channelVolumes[ch] = lerp(-60f, 12f, norm);
            store.saveChannelVolumeAsync(ch);
            transport.setChannelVolume(ch, store.channelVolumes[ch]);
        } else {
            int ch = store.selectedChannel;
            int band = store.selectedBand;
            if (hit.type == HIT_EQ_FREQ) {
                store.eqFrequency[ch][band] = logLerp(20f, 20000f, norm);
            } else if (hit.type == HIT_EQ_Q) {
                store.eqQ[ch][band] = lerp(0.1f, 10f, norm);
            } else if (hit.type == HIT_EQ_GAIN) {
                store.eqGain[ch][band] = lerp(-12f, 12f, norm);
            }
            store.saveEqBandAsync(ch, band);
            transport.setEqBand(ch, band, store.eqFrequency[ch][band], store.eqQ[ch][band], store.eqGain[ch][band]);
        }
        invalidate();
    }

    private void handleTap(HitTarget h) {
        if (h.type == HIT_THEME) {
            store.theme = store.theme == UiStateStore.THEME_LIGHT ? UiStateStore.THEME_DARK : UiStateStore.THEME_LIGHT;
            store.saveThemeNow();
            statusMessage = store.theme == UiStateStore.THEME_DARK ? "Dark theme saved" : "Light theme saved";
            if (host != null) host.onThemeChanged();
            invalidate();
            return;
        }
        if (h.type == HIT_NAV_HOME || h.type == HIT_NAV_MIX || h.type == HIT_NAV_EQ) {
            if (h.type == HIT_NAV_HOME) store.page = UiStateStore.PAGE_HOME;
            else if (h.type == HIT_NAV_MIX) store.page = UiStateStore.PAGE_MIX;
            else store.page = UiStateStore.PAGE_EQ;
            store.savePageAsync();
            invalidate();
            return;
        }
        if (h.type == HIT_HOME_CARD) {
            if (h.index == 7) {
                store.page = UiStateStore.PAGE_MIX;
                store.savePageAsync();
                statusMessage = "Quick Control opened";
            } else if (h.index == 1 || h.index == 2 || h.index == 4) {
                statusMessage = "Phase 2 will connect this control to the uploaded DSP protocol";
            } else if (h.index == 5) {
                statusMessage = "Realtime local autosave is active";
            } else {
                statusMessage = "Phase 1 UI control is active";
            }
            invalidate();
            return;
        }
        if (h.type == HIT_EQ_CHANNEL) {
            store.selectedChannel = h.index;
            store.saveSelectionAsync();
            statusMessage = "Channel " + (h.index + 1) + " selected";
            invalidate();
            return;
        }
        if (h.type == HIT_EQ_NODE) {
            store.selectedBand = h.index;
            store.saveSelectionAsync();
            statusMessage = "Band " + (h.index + 1) + " selected";
            invalidate();
            return;
        }
        if (h.type == HIT_EQ_PREV || h.type == HIT_EQ_NEXT) {
            int delta = h.type == HIT_EQ_PREV ? -1 : 1;
            store.selectedBand = (store.selectedBand + delta + UiStateStore.BAND_COUNT) % UiStateStore.BAND_COUNT;
            store.saveSelectionAsync();
            invalidate();
            return;
        }
        if (h.type == HIT_EQ_RESET) {
            store.resetSelectedChannelEq();
            sendChannelEq(store.selectedChannel);
            statusMessage = "Channel " + (store.selectedChannel + 1) + " EQ reset to flat";
            invalidate();
            return;
        }
        if (h.type == HIT_EQ_SAVE) {
            store.savePreset1();
            statusMessage = "Preset 1 saved";
            invalidate();
            return;
        }
        if (h.type == HIT_EQ_LOAD) {
            if (store.loadPreset1()) {
                sendAllToTransport();
                statusMessage = "Preset 1 loaded";
            } else {
                statusMessage = "Preset 1 is empty";
            }
            invalidate();
            return;
        }
        if (h.type == HIT_EQ_DELETE) {
            store.deletePreset1();
            statusMessage = "Preset 1 deleted";
            invalidate();
        }
    }

    private void sendChannelEq(int ch) {
        for (int band = 0; band < UiStateStore.BAND_COUNT; band++) {
            transport.setEqBand(ch, band, store.eqFrequency[ch][band], store.eqQ[ch][band], store.eqGain[ch][band]);
        }
    }

    private void sendAllToTransport() {
        transport.setMasterVolume(store.masterVolume);
        transport.setBassVolume(store.bassVolume);
        transport.setBassCutoff(store.bassCutoff);
        for (int ch = 0; ch < UiStateStore.CHANNEL_COUNT; ch++) {
            transport.setChannelVolume(ch, store.channelVolumes[ch]);
            sendChannelEq(ch);
        }
    }

    private HitTarget findHit(float x, float y) {
        for (int i = hits.size() - 1; i >= 0; i--) {
            HitTarget h = hits.get(i);
            if (h.rect.contains(x, y)) return new HitTarget(new RectF(h.rect), h.type, h.index);
        }
        return null;
    }

    private void addHit(RectF rect, int type, int index) {
        hits.add(new HitTarget(new RectF(rect), type, index));
    }

    private float freqToX(float freq, RectF g) {
        float n = logNorm(freq, 20f, 20000f);
        return g.left + g.width() * n;
    }

    private float gainToY(float gain, RectF g) {
        float n = clamp((gain + 12f) / 24f, 0f, 1f);
        return g.bottom - g.height() * n;
    }

    private Bounds contentBounds(float width) {
        float side = dp(14);
        float maxW = dp(720);
        float w = Math.min(width - side * 2f, maxW);
        float left = (width - w) / 2f;
        return new Bounds(left, left + w);
    }

    private void drawThemeIcon(Canvas c, float cx, float cy) {
        if (store.theme == UiStateStore.THEME_DARK) {
            paint.setColor(cyan);
            c.drawCircle(cx - dp(2), cy, dp(8), paint);
            paint.setColor(card);
            c.drawCircle(cx + dp(2), cy - dp(2), dp(8), paint);
        } else {
            paint.setColor(blue);
            c.drawCircle(cx, cy, dp(6), paint);
            stroke.setColor(blue);
            stroke.setStrokeWidth(dp(1.5f));
            for (int i = 0; i < 8; i++) {
                double a = Math.PI * 2.0 * i / 8.0;
                float x1 = cx + (float)Math.cos(a) * dp(10);
                float y1 = cy + (float)Math.sin(a) * dp(10);
                float x2 = cx + (float)Math.cos(a) * dp(13);
                float y2 = cy + (float)Math.sin(a) * dp(13);
                c.drawLine(x1, y1, x2, y2, stroke);
            }
        }
    }

    private void drawCheck(Canvas c, float cx, float cy, int color) {
        path.reset();
        path.moveTo(cx - dp(7), cy);
        path.lineTo(cx - dp(2), cy + dp(5));
        path.lineTo(cx + dp(8), cy - dp(7));
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(dp(2.5f));
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        stroke.setColor(color);
        c.drawPath(path, stroke);
    }

    private void drawCircleIcon(Canvas c, float cx, float cy, int color, int type) {
        paint.setColor(withAlpha(color, store.theme == UiStateStore.THEME_DARK ? 65 : 30));
        c.drawCircle(cx, cy, dp(18), paint);
        stroke.setColor(color);
        stroke.setStrokeWidth(dp(2));
        if (type == 0) {
            // Bluetooth-like rune.
            path.reset();
            path.moveTo(cx, cy - dp(9)); path.lineTo(cx + dp(7), cy - dp(3));
            path.lineTo(cx - dp(5), cy + dp(7)); path.moveTo(cx, cy - dp(9));
            path.lineTo(cx, cy + dp(9)); path.lineTo(cx + dp(7), cy + dp(3));
            path.lineTo(cx - dp(5), cy - dp(7));
            c.drawPath(path, stroke);
        } else if (type == 1) {
            c.drawRect(cx - dp(6), cy - dp(6), cx + dp(6), cy + dp(6), stroke);
            for (int i = -1; i <= 1; i += 2) {
                c.drawLine(cx + i * dp(9), cy - dp(4), cx + i * dp(6), cy - dp(4), stroke);
                c.drawLine(cx + i * dp(9), cy + dp(4), cx + i * dp(6), cy + dp(4), stroke);
            }
        } else if (type == 2 || type == 6) {
            for (int i = -2; i <= 2; i++) {
                float hh = dp(4 + (2 - Math.abs(i)) * 3);
                c.drawLine(cx + i * dp(4), cy - hh, cx + i * dp(4), cy + hh, stroke);
            }
        } else if (type == 3) {
            path.reset();
            path.moveTo(cx - dp(8), cy - dp(3)); path.lineTo(cx - dp(3), cy - dp(3));
            path.lineTo(cx + dp(4), cy - dp(8)); path.lineTo(cx + dp(4), cy + dp(8));
            path.lineTo(cx - dp(3), cy + dp(3)); path.lineTo(cx - dp(8), cy + dp(3)); path.close();
            c.drawPath(path, stroke);
        } else if (type == 4) {
            c.drawRect(cx - dp(7), cy - dp(8), cx + dp(7), cy + dp(8), stroke);
            c.drawLine(cx - dp(3), cy - dp(3), cx + dp(4), cy - dp(3), stroke);
            c.drawLine(cx - dp(3), cy + dp(2), cx + dp(4), cy + dp(2), stroke);
        } else {
            c.drawCircle(cx, cy, dp(7), stroke);
            c.drawCircle(cx, cy, dp(2), stroke);
        }
    }

    private void drawHomeIcon(Canvas c, float cx, float cy, int color) {
        path.reset();
        path.moveTo(cx - dp(8), cy);
        path.lineTo(cx, cy - dp(7));
        path.lineTo(cx + dp(8), cy);
        path.lineTo(cx + dp(7), cy + dp(8));
        path.lineTo(cx - dp(7), cy + dp(8));
        path.close();
        paint.setColor(color);
        c.drawPath(path, paint);
    }

    private void drawMixIcon(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color);
        stroke.setStrokeWidth(dp(1.8f));
        for (int i = -1; i <= 1; i++) {
            float x = cx + i * dp(7);
            c.drawLine(x, cy - dp(9), x, cy + dp(9), stroke);
            float knobY = cy + (i == -1 ? -dp(3) : (i == 0 ? dp(4) : -dp(1)));
            paint.setColor(color);
            c.drawCircle(x, knobY, dp(2.8f), paint);
        }
    }

    private void drawEqIcon(Canvas c, float cx, float cy, int color) {
        paint.setColor(color);
        for (int i = -1; i <= 1; i++) {
            float x = cx + i * dp(6);
            float h = i == 0 ? dp(9) : dp(6);
            c.drawRoundRect(new RectF(x - dp(1.6f), cy - h, x + dp(1.6f), cy + h), dp(1.6f), dp(1.6f), paint);
        }
    }

    private void fillRound(Canvas c, RectF r, float radius, int color) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(color);
        paint.setAlpha(Color.alpha(color));
        c.drawRoundRect(r, radius, radius, paint);
        paint.setAlpha(255);
    }

    private void strokeRound(Canvas c, RectF r, float radius, int color, float width) {
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(width);
        stroke.setColor(color);
        c.drawRoundRect(r, radius, radius, stroke);
    }

    private void drawText(Canvas c, String s, float x, float baseline, float size, int color, boolean bold) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(color);
        paint.setTextSize(size);
        paint.setTypeface(bold ? Typeface.create(Typeface.DEFAULT, Typeface.BOLD) : Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
        paint.setTextAlign(Paint.Align.LEFT);
        c.drawText(s, x, baseline, paint);
    }

    private void drawTextRight(Canvas c, String s, float x, float baseline, float size, int color, boolean bold) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(color);
        paint.setTextSize(size);
        paint.setTypeface(bold ? Typeface.create(Typeface.DEFAULT, Typeface.BOLD) : Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
        paint.setTextAlign(Paint.Align.RIGHT);
        c.drawText(s, x, baseline, paint);
    }

    private void drawTextCentered(Canvas c, String s, float x, float baseline, float size, int color, boolean bold) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(color);
        paint.setTextSize(size);
        paint.setTypeface(bold ? Typeface.create(Typeface.DEFAULT, Typeface.BOLD) : Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
        paint.setTextAlign(Paint.Align.CENTER);
        c.drawText(s, x, baseline, paint);
    }

    private float dp(float value) {
        return value * density;
    }

    private float sp(float value) {
        return value * getResources().getDisplayMetrics().scaledDensity;
    }

    private int withAlpha(int color, int alpha) {
        return Color.argb(clampInt(alpha, 0, 255), Color.red(color), Color.green(color), Color.blue(color));
    }

    private static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    private static int clampInt(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }

    private static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    private static float logLerp(float min, float max, float t) {
        double a = Math.log10(min);
        double b = Math.log10(max);
        return (float)Math.pow(10.0, a + (b - a) * t);
    }

    private static float logNorm(float value, float min, float max) {
        value = clamp(value, min, max);
        double a = Math.log10(min);
        double b = Math.log10(max);
        return (float)((Math.log10(value) - a) / (b - a));
    }

    private static final class HitTarget {
        final RectF rect;
        final int type;
        final int index;
        HitTarget(RectF rect, int type, int index) {
            this.rect = rect;
            this.type = type;
            this.index = index;
        }
    }

    private static final class Bounds {
        final float left;
        final float right;
        Bounds(float left, float right) {
            this.left = left;
            this.right = right;
        }
        float width() { return right - left; }
    }
}
