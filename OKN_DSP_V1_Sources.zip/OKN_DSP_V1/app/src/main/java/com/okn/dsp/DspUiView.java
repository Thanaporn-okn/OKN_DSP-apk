package com.okn.dsp;

import android.app.AlertDialog;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Build;
import android.text.InputType;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowInsets;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public final class DspUiView extends View {
    private static final int PAGE_HOME = 0;
    private static final int PAGE_MIX = 1;
    private static final int PAGE_EQ = 2;

    private final AppState state;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final float density;
    private final float scaledDensity;
    private final List<Hit> hits = new ArrayList<>();

    private Palette colors;
    private float topInset;
    private float bottomInset;
    private float contentLeft;
    private float contentRight;
    private float contentWidth;
    private float scrollY;
    private float maxScroll;
    private float pageHeight;
    private float navTop;

    private float downX, downY, lastY;
    private boolean moved;
    private Hit activeSlider;
    private boolean drawingScrollablePage;

    private static final class Palette {
        int bgTop, bgBottom, card, cardSoft, text, secondary, primary, border;
        int green, orange, pink, purple, cyan, blueSoft, danger;
    }

    private static final class Hit {
        RectF rect;
        String action;
        int a, b;
        float min, max;
        boolean log;
        Hit(RectF rect, String action, int a, int b) {
            this.rect = rect; this.action = action; this.a = a; this.b = b;
        }
        Hit slider(RectF rect, String action, int a, int b, float min, float max, boolean log) {
            this.rect = rect; this.action = action; this.a = a; this.b = b;
            this.min = min; this.max = max; this.log = log; return this;
        }
    }

    public DspUiView(Context context) {
        super(context);
        density = Resources.getSystem().getDisplayMetrics().density;
        scaledDensity = Resources.getSystem().getDisplayMetrics().scaledDensity;
        state = new AppState(context);
        setFocusable(true);
        setClickable(true);
        colors = paletteFor(state.theme);
        setBackgroundColor(colors.bgTop);
    }

    public boolean isDarkTheme() {
        return state.theme != AppState.THEME_LIGHT;
    }

    @Override
    public WindowInsets onApplyWindowInsets(WindowInsets insets) {
        if (Build.VERSION.SDK_INT >= 30) {
            android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
            topInset = bars.top;
            bottomInset = bars.bottom;
        } else {
            topInset = insets.getSystemWindowInsetTop();
            bottomInset = insets.getSystemWindowInsetBottom();
        }
        invalidate();
        return insets;
    }

    public boolean handleBack() {
        if (state.page != PAGE_HOME) {
            setPage(PAGE_HOME);
            return true;
        }
        if (scrollY > 0f) {
            scrollY = 0f;
            invalidate();
            return true;
        }
        return false;
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        colors = paletteFor(state.theme);
        drawBackground(c);
        hits.clear();
        layoutContentBounds();
        navTop = getHeight() - bottomInset - dp(92);

        c.save();
        c.clipRect(0, topInset, getWidth(), navTop);
        c.translate(0, -scrollY);
        drawingScrollablePage = true;
        pageHeight = drawCurrentPage(c);
        drawingScrollablePage = false;
        c.restore();

        maxScroll = Math.max(0f, pageHeight - navTop);
        if (scrollY > maxScroll) scrollY = maxScroll;

        drawBottomNav(c);
    }

    private void layoutContentBounds() {
        float side = dp(getWidth() / density < 420f ? 16f : 28f);
        float max = dp(900f);
        contentWidth = Math.min(getWidth() - side * 2f, max);
        contentLeft = (getWidth() - contentWidth) / 2f;
        contentRight = contentLeft + contentWidth;
    }

    private void drawBackground(Canvas c) {
        LinearGradient g = new LinearGradient(0, 0, getWidth(), getHeight(),
                colors.bgTop, colors.bgBottom, Shader.TileMode.CLAMP);
        p.setShader(g);
        c.drawRect(0, 0, getWidth(), getHeight(), p);
        p.setShader(null);
    }

    private float drawCurrentPage(Canvas c) {
        if (state.page == PAGE_MIX) return drawMix(c);
        if (state.page == PAGE_EQ) return drawEq(c);
        return drawHome(c);
    }

    private float drawHome(Canvas c) {
        float y = topInset + dp(28);
        drawTitle(c, "OKN DSP", "DSP Controller", y);
        drawHeaderButtons(c, y + dp(6));
        y += dp(112);

        RectF status = card(contentLeft, y, contentWidth, dp(132));
        drawRounded(c, status, colors.card, dp(24));
        drawSoftCircle(c, status.left + dp(48), status.centerY(), dp(31), colors.green);
        drawCheck(c, status.left + dp(48), status.centerY(), colors.card, dp(13));
        text(c, "SYSTEM STATUS", status.left + dp(94), status.top + dp(38), 13, colors.secondary, false);
        text(c, "UI Ready", status.left + dp(94), status.top + dp(69), 22, colors.text, true);
        text(c, "Phase 1 interface is active. DSP link starts in Phase 2.",
                status.left + dp(94), status.top + dp(96), 14, colors.secondary, false);
        drawChevron(c, status.right - dp(26), status.centerY(), colors.secondary, false);
        addHit(status, "status", 0, 0);
        y = status.bottom + dp(30);

        text(c, "Connection & Status", contentLeft + dp(4), y, 22, colors.text, true);
        textRight(c, "Phase 1", contentRight - dp(4), y, 14, colors.primary, true);
        y += dp(22);

        String[][] rows = {
                {"Bluetooth", "UI control prepared", "Ready"},
                {"DSP Device", "Awaiting protocol data", "Phase 2"},
                {"Audio Input", "AUX / source selector UI", "Ready"},
                {"Amplifier Link", "External amplifier UI", "Ready"},
                {"Preset Sync", "Local presets", "Synced"},
                {"Firmware Status", "Hardware read starts in Phase 2", "Pending"}
        };
        int[] accents = {Color.rgb(10,132,255), colors.purple, colors.orange, colors.pink, colors.cyan, colors.purple};
        String[] icons = {"bt", "chip", "audio", "speaker", "preset", "gear"};
        for (int i=0;i<rows.length;i++) {
            RectF r = card(contentLeft, y, contentWidth, dp(76));
            drawRounded(c, r, colors.card, dp(22));
            drawSoftCircle(c, r.left+dp(34), r.centerY(), dp(23), accents[i]);
            drawIcon(c, icons[i], r.left+dp(34), r.centerY(), dp(15), Color.WHITE);
            text(c, rows[i][0], r.left+dp(69), r.top+dp(31), 17, colors.text, true);
            text(c, rows[i][1], r.left+dp(69), r.top+dp(54), 13, colors.secondary, false);
            int statusColor = (i==1 || i==5) ? colors.secondary : (i==2 ? colors.primary : colors.green);
            drawDot(c, r.right-dp(128), r.centerY(), dp(5), statusColor);
            textRight(c, rows[i][2], r.right-dp(32), r.centerY()+dp(5), 14, statusColor, true);
            drawChevron(c, r.right-dp(17), r.centerY(), colors.secondary, false);
            addHit(r, "homeRow", i, 0);
            y = r.bottom + dp(10);
        }

        y += dp(8);
        RectF quick = card(contentLeft, y, contentWidth, dp(82));
        drawRounded(c, quick, colors.card, dp(22));
        drawSoftCircle(c, quick.left+dp(38), quick.centerY(), dp(25), colors.blueSoft);
        drawIcon(c, "eq", quick.left+dp(38), quick.centerY(), dp(16), colors.primary);
        text(c, "Quick Control", quick.left+dp(76), quick.top+dp(34), 17, colors.text, true);
        text(c, "Adjust volume, channels and EQ", quick.left+dp(76), quick.top+dp(58), 13, colors.secondary, false);
        drawChevron(c, quick.right-dp(24), quick.centerY(), colors.secondary, false);
        addHit(quick, "quick", 0, 0);
        return quick.bottom + dp(24);
    }

    private float drawMix(Canvas c) {
        float y = topInset + dp(28);
        drawTitle(c, "Mix", "Channel and bass controls", y);
        drawHeaderButtons(c, y + dp(6));
        y += dp(112);

        float globalH = dp(276);
        RectF global = card(contentLeft, y, contentWidth, globalH);
        drawRounded(c, global, colors.card, dp(24));
        text(c, "Global", global.left+dp(20), global.top+dp(34), 21, colors.text, true);
        textRight(c, "Overall output and bass settings", global.right-dp(20), global.top+dp(31), 12, colors.secondary, false);
        float rowY = global.top+dp(78);
        drawMixSliderRow(c, global, rowY, "Master Volume", state.masterVolume,
                -60f, 12f, "master", 0, "volume", colors.primary, formatDb(state.masterVolume));
        rowY += dp(82);
        drawMixSliderRow(c, global, rowY, "Bass Volume", state.bassVolume,
                -12f, 12f, "bass", 0, "audio", colors.orange, formatDb(state.bassVolume));
        rowY += dp(82);
        drawMixSliderRow(c, global, rowY, "Bass Cutoff", state.bassCutoff,
                40f, 200f, "cutoff", 0, "filter", colors.purple, String.format(Locale.US, "%.0f Hz", state.bassCutoff));
        y = global.bottom + dp(18);

        float channelsH = dp(604);
        RectF channels = card(contentLeft, y, contentWidth, channelsH);
        drawRounded(c, channels, colors.card, dp(24));
        text(c, "Channels", channels.left+dp(20), channels.top+dp(36), 21, colors.text, true);
        textRight(c, "Individual channel levels", channels.right-dp(20), channels.top+dp(33), 12, colors.secondary, false);
        float sy = channels.top + dp(74);
        int[] ac = {colors.primary, colors.green, colors.orange, colors.pink, colors.purple, colors.cyan, colors.purple};
        for (int ch=0; ch<AppState.CHANNELS; ch++) {
            drawChannelRow(c, channels, sy, ch, ac[ch]);
            sy += dp(73);
        }
        return channels.bottom + dp(24);
    }

    private float drawEq(Canvas c) {
        float y = topInset + dp(28);
        drawTitle(c, "Eq", "15-band equalizer", y);
        drawHeaderButtons(c, y + dp(6));
        y += dp(106);

        float gap = dp(8);
        float tabW = (contentWidth - gap * 6f) / 7f;
        for (int ch=0; ch<7; ch++) {
            RectF tab = new RectF(contentLeft + ch*(tabW+gap), y, contentLeft + ch*(tabW+gap)+tabW, y+dp(42));
            int fill = ch==state.selectedChannel ? colors.primary : colors.cardSoft;
            drawRounded(c, tab, fill, dp(18));
            textCenter(c, "Ch"+(ch+1), tab.centerX(), tab.centerY()+dp(5), 12, ch==state.selectedChannel ? Color.WHITE : colors.secondary, ch==state.selectedChannel);
            addHit(tab, "eqChannel", ch, 0);
        }
        y += dp(62);

        RectF graph = card(contentLeft, y, contentWidth, dp(316));
        drawRounded(c, graph, colors.card, dp(24));
        text(c, "Channel " + (state.selectedChannel+1), graph.left+dp(20), graph.top+dp(34), 20, colors.text, true);
        text(c, channelName(state.selectedChannel) + "  •  15-band EQ", graph.left+dp(20), graph.top+dp(57), 13, colors.secondary, false);
        RectF reset = new RectF(graph.right-dp(138), graph.top+dp(16), graph.right-dp(18), graph.top+dp(54));
        drawRounded(c, reset, colors.cardSoft, dp(18));
        drawIcon(c, "reset", reset.left+dp(23), reset.centerY(), dp(10), colors.secondary);
        text(c, "Reset EQ", reset.left+dp(42), reset.centerY()+dp(5), 12, colors.secondary, true);
        addHit(reset, "resetEq", 0, 0);
        drawEqGraph(c, graph);
        y = graph.bottom + dp(16);

        RectF editor = card(contentLeft, y, contentWidth, dp(346));
        drawRounded(c, editor, colors.card, dp(24));
        drawSoftCircle(c, editor.left+dp(36), editor.top+dp(40), dp(24), colors.blueSoft);
        textCenter(c, String.valueOf(state.selectedBand+1), editor.left+dp(36), editor.top+dp(47), 18, colors.primary, true);
        text(c, "Band " + (state.selectedBand+1), editor.left+dp(76), editor.top+dp(35), 18, colors.text, true);
        text(c, "Adjust the selected band parameters", editor.left+dp(76), editor.top+dp(58), 12, colors.secondary, false);
        RectF prev = new RectF(editor.right-dp(112), editor.top+dp(17), editor.right-dp(68), editor.top+dp(59));
        RectF next = new RectF(editor.right-dp(58), editor.top+dp(17), editor.right-dp(14), editor.top+dp(59));
        drawRounded(c, prev, colors.cardSoft, dp(18)); drawRounded(c, next, colors.cardSoft, dp(18));
        drawChevron(c, prev.centerX(), prev.centerY(), colors.text, true);
        drawChevron(c, next.centerX(), next.centerY(), colors.text, false);
        addHit(prev, "bandPrev", 0, 0); addHit(next, "bandNext", 0, 0);

        int ch = state.selectedChannel, b = state.selectedBand;
        float sy = editor.top+dp(104);
        drawEqEditorSlider(c, editor, sy, "Frequency", state.eqFreq[ch][b], 20f, 20000f, true,
                "eqFreq", "wave", formatHz(state.eqFreq[ch][b]), "20 Hz", "20 kHz");
        sy += dp(84);
        drawEqEditorSlider(c, editor, sy, "Q (Quality Factor)", state.eqQ[ch][b], 0.1f, 10f, true,
                "eqQ", "q", String.format(Locale.US, "%.2f", state.eqQ[ch][b]), "0.1", "10.0");
        sy += dp(84);
        drawEqEditorSlider(c, editor, sy, "Gain", state.eqGain[ch][b], -12f, 12f, false,
                "eqGain", "volume", formatDb(state.eqGain[ch][b]), "-12 dB", "+12 dB");
        y = editor.bottom + dp(16);

        RectF preset = card(contentLeft, y, contentWidth, dp(250));
        drawRounded(c, preset, colors.card, dp(24));
        drawSoftCircle(c, preset.left+dp(36), preset.top+dp(38), dp(24), colors.cyan);
        drawIcon(c, "preset", preset.left+dp(36), preset.top+dp(38), dp(13), Color.WHITE);
        text(c, "Presets", preset.left+dp(72), preset.top+dp(36), 18, colors.text, true);
        text(c, "Save and load EQ presets", preset.left+dp(72), preset.top+dp(59), 12, colors.secondary, false);

        RectF name = new RectF(preset.left+dp(18), preset.top+dp(82), preset.right-dp(170), preset.top+dp(132));
        drawRoundedStroke(c, name, colors.cardSoft, colors.border, dp(14));
        text(c, state.presetName, name.left+dp(14), name.centerY()+dp(5), 13, colors.secondary, false);
        addHit(name, "presetName", 0, 0);
        RectF save = new RectF(preset.right-dp(156), preset.top+dp(82), preset.right-dp(18), preset.top+dp(132));
        drawRounded(c, save, colors.primary, dp(14));
        drawIcon(c, "save", save.left+dp(24), save.centerY(), dp(11), Color.WHITE);
        text(c, "Save Preset", save.left+dp(44), save.centerY()+dp(5), 12, Color.WHITE, true);
        addHit(save, "savePreset", 0, 0);

        text(c, "Load Preset", preset.left+dp(18), preset.top+dp(158), 12, colors.secondary, false);
        RectF chooser = new RectF(preset.left+dp(18), preset.top+dp(174), preset.right-dp(170), preset.top+dp(224));
        drawRoundedStroke(c, chooser, colors.cardSoft, colors.border, dp(14));
        text(c, state.loadChoice, chooser.left+dp(14), chooser.centerY()+dp(5), 13, colors.text, false);
        drawChevronDown(c, chooser.right-dp(18), chooser.centerY(), colors.secondary);
        addHit(chooser, "presetChoice", 0, 0);
        RectF load = new RectF(preset.right-dp(156), preset.top+dp(174), preset.right-dp(18), preset.top+dp(224));
        drawRounded(c, load, colors.cardSoft, dp(14));
        drawIcon(c, "folder", load.left+dp(24), load.centerY(), dp(11), colors.secondary);
        text(c, "Load", load.left+dp(48), load.centerY()+dp(5), 12, colors.secondary, true);
        addHit(load, "loadPreset", 0, 0);
        return preset.bottom + dp(24);
    }

    private void drawTitle(Canvas c, String title, String subtitle, float y) {
        text(c, title, contentLeft+dp(4), y+dp(28), 27, colors.text, true);
        text(c, subtitle, contentLeft+dp(4), y+dp(55), 15, colors.secondary, false);
    }

    private void drawHeaderButtons(Canvas c, float y) {
        RectF search = new RectF(contentRight-dp(92), y, contentRight-dp(48), y+dp(44));
        RectF more = new RectF(contentRight-dp(42), y, contentRight+dp(2), y+dp(44));
        drawRounded(c, search, colors.cardSoft, dp(22));
        drawRounded(c, more, colors.cardSoft, dp(22));
        drawIcon(c, "search", search.centerX(), search.centerY(), dp(12), colors.text);
        drawIcon(c, "more", more.centerX(), more.centerY(), dp(12), colors.text);
        addHit(search, "search", 0, 0);
        addHit(more, "more", 0, 0);
    }

    private void drawMixSliderRow(Canvas c, RectF parent, float y, String label, float value,
                                  float min, float max, String action, int idx, String icon,
                                  int accent, String valueText) {
        float iconX = parent.left+dp(35);
        drawSoftCircle(c, iconX, y, dp(23), blend(accent, colors.card, 0.78f));
        drawIcon(c, icon, iconX, y, dp(13), accent);
        text(c, label, parent.left+dp(70), y-dp(10), 15, colors.text, true);
        RectF track = new RectF(parent.left+dp(72), y+dp(11), parent.right-dp(145), y+dp(17));
        drawSlider(c, track, value, min, max, false, action, idx, -1);
        RectF pill = new RectF(parent.right-dp(125), y-dp(22), parent.right-dp(20), y+dp(26));
        drawRounded(c, pill, colors.cardSoft, dp(13));
        textCenter(c, valueText, pill.centerX(), pill.centerY()+dp(5), 14, colors.text, false);
        if (y < parent.bottom-dp(40)) {
            line(c, parent.left+dp(22), y+dp(40), parent.right-dp(22), y+dp(40), colors.border, dp(1));
        }
    }

    private void drawChannelRow(Canvas c, RectF parent, float y, int ch, int accent) {
        drawSoftCircle(c, parent.left+dp(34), y, dp(23), accent);
        textCenter(c, String.valueOf(ch+1), parent.left+dp(34), y+dp(6), 18, Color.WHITE, true);
        text(c, "Volume Ch"+(ch+1), parent.left+dp(72), y-dp(10), 15, colors.text, true);
        RectF track = new RectF(parent.left+dp(72), y+dp(11), parent.right-dp(145), y+dp(17));
        drawSlider(c, track, state.channelVolume[ch], -60f, 12f, false, "channel", ch, -1);
        RectF pill = new RectF(parent.right-dp(125), y-dp(22), parent.right-dp(20), y+dp(26));
        drawRounded(c, pill, colors.cardSoft, dp(13));
        textCenter(c, formatDb(state.channelVolume[ch]), pill.centerX(), pill.centerY()+dp(5), 14, colors.text, false);
        if (ch < 6) line(c, parent.left+dp(22), y+dp(36), parent.right-dp(22), y+dp(36), colors.border, dp(1));
    }

    private void drawEqEditorSlider(Canvas c, RectF parent, float y, String label, float value,
                                    float min, float max, boolean log, String action, String icon,
                                    String valueText, String minText, String maxText) {
        drawSoftCircle(c, parent.left+dp(34), y, dp(18), colors.cardSoft);
        if ("q".equals(icon)) {
            textCenter(c, "Q", parent.left+dp(34), y+dp(5), 13, colors.secondary, true);
        } else {
            drawIcon(c, icon, parent.left+dp(34), y, dp(11), colors.secondary);
        }
        text(c, label, parent.left+dp(62), y-dp(9), 14, colors.text, true);
        RectF val = new RectF(parent.right-dp(130), y-dp(23), parent.right-dp(18), y+dp(14));
        drawRounded(c, val, colors.cardSoft, dp(13));
        textCenter(c, valueText, val.centerX(), val.centerY()+dp(5), 12, colors.text, false);
        RectF track = new RectF(parent.left+dp(62), y+dp(19), parent.right-dp(22), y+dp(25));
        drawSlider(c, track, value, min, max, log, action, state.selectedChannel, state.selectedBand);
        text(c, minText, track.left, y+dp(45), 10, colors.secondary, false);
        textRight(c, maxText, track.right, y+dp(45), 10, colors.secondary, false);
    }

    private void drawSlider(Canvas c, RectF track, float value, float min, float max, boolean log,
                            String action, int a, int b) {
        drawRounded(c, track, colors.border, track.height()/2f);
        float t;
        if (log) {
            t = (float)((Math.log(value)-Math.log(min))/(Math.log(max)-Math.log(min)));
        } else {
            t = (value-min)/(max-min);
        }
        t = clamp(t, 0f, 1f);
        RectF active = new RectF(track.left, track.top, track.left+track.width()*t, track.bottom);
        drawRounded(c, active, colors.primary, track.height()/2f);
        float cx = track.left+track.width()*t;
        p.setStyle(Paint.Style.FILL); p.setColor(colors.card); c.drawCircle(cx, track.centerY(), dp(10), p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1)); p.setColor(colors.border); c.drawCircle(cx, track.centerY(), dp(10), p); p.setStyle(Paint.Style.FILL);
        RectF hit = new RectF(track.left-dp(8), track.centerY()-dp(22), track.right+dp(8), track.centerY()+dp(22));
        RectF mapped = scrollMapped(hit);
        hits.add(new Hit(mapped, action, a, b).slider(mapped, action, a, b, min, max, log));
    }

    private void drawEqGraph(Canvas c, RectF card) {
        RectF g = new RectF(card.left+dp(42), card.top+dp(84), card.right-dp(22), card.bottom-dp(44));
        for (int i=0;i<=4;i++) {
            float yy = g.top + g.height()*i/4f;
            line(c, g.left, yy, g.right, yy, colors.border, dp(0.8f));
            float gain = 12f - 6f*i;
            textRight(c, String.format(Locale.US,"%+.0f",gain), g.left-dp(10), yy+dp(4), 9, colors.secondary, false);
        }
        float[] gridFreq = {20,50,100,200,500,1000,2000,5000,10000,20000};
        for (float f: gridFreq) {
            float xx = freqX(f, g);
            line(c, xx, g.top, xx, g.bottom, blend(colors.border, colors.bgBottom, 0.4f), dp(0.7f));
        }
        int ch = state.selectedChannel;
        int sb = state.selectedBand;
        float sx = freqX(state.eqFreq[ch][sb], g);
        float q = state.eqQ[ch][sb];
        float bandWidth = clamp(dp(72)/(float)Math.sqrt(q), dp(14), dp(90));
        p.setColor(withAlpha(colors.primary, 24));
        c.drawRoundRect(new RectF(sx-bandWidth/2f, g.top, sx+bandWidth/2f, g.bottom), dp(6), dp(6), p);

        Integer[] order = new Integer[AppState.BANDS];
        for (int i=0;i<AppState.BANDS;i++) order[i]=i;
        Arrays.sort(order, Comparator.comparingDouble(i -> state.eqFreq[ch][i]));
        path.reset();
        for (int k=0;k<order.length;k++) {
            int b = order[k];
            float x = freqX(state.eqFreq[ch][b], g);
            float y = gainY(state.eqGain[ch][b], g);
            if (k==0) path.moveTo(x,y); else path.lineTo(x,y);
        }
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.6f)); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeJoin(Paint.Join.ROUND); p.setColor(colors.primary);
        c.drawPath(path,p); p.setStyle(Paint.Style.FILL);
        for (int b=0;b<AppState.BANDS;b++) {
            float x=freqX(state.eqFreq[ch][b],g), y=gainY(state.eqGain[ch][b],g);
            float r = b==sb ? dp(7) : dp(4.5f);
            if (b==sb) { p.setColor(colors.card); c.drawCircle(x,y,r+dp(2),p); }
            p.setColor(colors.primary); c.drawCircle(x,y,r,p);
            RectF hr = new RectF(x-dp(13), y-dp(13), x+dp(13), y+dp(13));
            addHit(hr,"eqPoint",b,0);
        }
        String[] labs={"20","50","100","200","500","1K","2K","5K","10K","20K"};
        for(int i=0;i<gridFreq.length;i++) textCenter(c,labs[i],freqX(gridFreq[i],g),g.bottom+dp(18),8.5f,colors.secondary,false);
        text(c,"(dB)",card.left+dp(12),g.bottom+dp(18),8.5f,colors.secondary,false);
        textRight(c,"(Hz)",card.right-dp(12),g.bottom+dp(34),8.5f,colors.secondary,false);
    }

    private void drawBottomNav(Canvas c) {
        RectF nav = new RectF(contentLeft, navTop+dp(8), contentRight, getHeight()-bottomInset-dp(8));
        drawRounded(c, nav, colors.card, dp(24));
        float itemW = nav.width()/3f;
        String[] labels={"Home","Mix","Eq"};
        String[] icons={"home","mix","eq"};
        for(int i=0;i<3;i++) {
            RectF item = new RectF(nav.left+i*itemW+dp(8), nav.top+dp(8), nav.left+(i+1)*itemW-dp(8), nav.bottom-dp(8));
            if (state.page==i) {
                RectF hi = new RectF(item.left, item.top, item.right, item.top+dp(44));
                drawRounded(c, hi, colors.blueSoft, dp(18));
            }
            int col = state.page==i ? colors.primary : colors.secondary;
            drawIcon(c, icons[i], item.centerX(), item.top+dp(24), dp(14), col);
            textCenter(c, labels[i], item.centerX(), item.bottom-dp(8), 12, col, state.page==i);
            hits.add(new Hit(item,"nav",i,0));
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float x=e.getX(), y=e.getY();
        switch(e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX=x; downY=y; lastY=y; moved=false; activeSlider=findSlider(x,y);
                if (activeSlider!=null) updateSlider(activeSlider,x);
                return true;
            case MotionEvent.ACTION_MOVE:
                if (activeSlider!=null) {
                    updateSlider(activeSlider,x); moved=true; return true;
                }
                float dy=y-lastY;
                if (Math.abs(y-downY)>dp(6)) moved=true;
                if (moved && y < navTop) {
                    scrollY=clamp(scrollY-dy,0,maxScroll);
                    invalidate();
                }
                lastY=y;
                return true;
            case MotionEvent.ACTION_UP:
                if (activeSlider!=null) { updateSlider(activeSlider,x); activeSlider=null; performClick(); return true; }
                if (!moved) {
                    Hit h=findHit(x,y);
                    if(h!=null) handleHit(h);
                }
                performClick(); return true;
            case MotionEvent.ACTION_CANCEL:
                activeSlider=null; return true;
        }
        return super.onTouchEvent(e);
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    private Hit findSlider(float x,float y) {
        for(int i=hits.size()-1;i>=0;i--) {
            Hit h=hits.get(i);
            if(h.min!=h.max && h.rect.contains(x,y)) return h;
        }
        return null;
    }

    private Hit findHit(float x,float y) {
        for(int i=hits.size()-1;i>=0;i--) {
            Hit h=hits.get(i);
            if(h.rect.contains(x,y)) return h;
        }
        return null;
    }

    private void updateSlider(Hit h,float x) {
        float left = h.rect.left + dp(8);
        float right = h.rect.right - dp(8);
        float t=clamp((x-left)/Math.max(dp(1), right-left),0f,1f);
        float value;
        if(h.log) value=(float)Math.exp(Math.log(h.min)+t*(Math.log(h.max)-Math.log(h.min)));
        else value=h.min+t*(h.max-h.min);
        switch(h.action) {
            case "master": state.setMaster(value); break;
            case "bass": state.setBass(value); break;
            case "cutoff": state.setCutoff(value); break;
            case "channel": state.setChannelVolume(h.a,value); break;
            case "eqFreq": state.setBandFrequency(h.a,h.b,value); break;
            case "eqQ": state.setBandQ(h.a,h.b,value); break;
            case "eqGain": state.setBandGain(h.a,h.b,value); break;
        }
        invalidate();
    }

    private void handleHit(Hit h) {
        switch(h.action) {
            case "nav": setPage(h.a); break;
            case "quick": setPage(PAGE_MIX); break;
            case "eqChannel": state.setSelectedChannel(h.a); scrollY=0; invalidate(); break;
            case "eqPoint": state.setSelectedBand(h.a); invalidate(); break;
            case "bandPrev": state.setSelectedBand((state.selectedBand+AppState.BANDS-1)%AppState.BANDS); invalidate(); break;
            case "bandNext": state.setSelectedBand((state.selectedBand+1)%AppState.BANDS); invalidate(); break;
            case "resetEq": state.resetEq(state.selectedChannel); invalidate(); toast("Channel "+(state.selectedChannel+1)+" EQ reset"); break;
            case "more": showThemeDialog(); break;
            case "search": showSearchDialog(); break;
            case "presetName": showPresetNameDialog(); break;
            case "savePreset": state.savePreset(state.presetName); toast("Preset saved: "+state.presetName); invalidate(); break;
            case "presetChoice": cyclePresetChoice(); break;
            case "loadPreset":
                if(!"Flat".equals(state.loadChoice) && !state.hasPreset()) toast("No saved preset yet");
                else { state.loadPreset(); toast("Loaded: "+state.loadChoice); invalidate(); }
                break;
            case "status": toast("Phase 1 UI is running. Hardware connection will be added in Phase 2."); break;
            case "homeRow": toast("Phase 1 UI item: hardware action will be connected in Phase 2."); break;
        }
    }

    private void setPage(int p) {
        if(state.page==p) return;
        state.setPage(p); scrollY=0; invalidate();
    }

    private void showThemeDialog() {
        String[] items={"Light","Dark","Ocean"};
        new AlertDialog.Builder(getContext())
                .setTitle("Theme")
                .setSingleChoiceItems(items,state.theme,(d,which)->{
                    state.setTheme(which); colors=paletteFor(which); setBackgroundColor(colors.bgTop);
                    if(getContext() instanceof MainActivity) ((MainActivity)getContext()).applySystemBarAppearance(isDarkTheme());
                    d.dismiss(); invalidate();
                }).show();
    }

    private void showSearchDialog() {
        String[] items={"Home","Mix controls","15-band EQ","Theme"};
        new AlertDialog.Builder(getContext()).setTitle("Go to")
                .setItems(items,(d,w)->{
                    if(w<=2) setPage(w); else showThemeDialog();
                }).show();
    }

    private void showPresetNameDialog() {
        EditText input=new EditText(getContext());
        input.setSingleLine(true); input.setInputType(InputType.TYPE_CLASS_TEXT); input.setText(state.presetName); input.selectAll();
        int m=(int)dp(20); input.setPadding(m,m/2,m,m/2);
        new AlertDialog.Builder(getContext()).setTitle("Preset name").setView(input)
                .setPositiveButton("Save name",(d,w)->{ state.setPresetName(input.getText().toString()); invalidate(); })
                .setNegativeButton("Cancel",null).show();
    }

    private void cyclePresetChoice() {
        if(state.hasPreset()) {
            String user=state.savedPresetName();
            state.setLoadChoice("Flat".equals(state.loadChoice)?user:"Flat");
        } else state.setLoadChoice("Flat");
        invalidate();
    }

    private void toast(String msg) { Toast.makeText(getContext(),msg,Toast.LENGTH_SHORT).show(); }

    private Palette paletteFor(int theme) {
        Palette x=new Palette();
        if(theme==AppState.THEME_DARK) {
            x.bgTop=Color.rgb(10,15,28); x.bgBottom=Color.rgb(18,27,48); x.card=Color.rgb(22,31,50); x.cardSoft=Color.rgb(31,42,65);
            x.text=Color.rgb(245,248,255); x.secondary=Color.rgb(158,170,194); x.primary=Color.rgb(42,150,255); x.border=Color.rgb(53,65,88);
            x.green=Color.rgb(47,214,105); x.orange=Color.rgb(255,164,51); x.pink=Color.rgb(255,94,126); x.purple=Color.rgb(131,102,255); x.cyan=Color.rgb(36,206,219);
            x.blueSoft=Color.rgb(31,55,83); x.danger=Color.rgb(255,82,82);
        } else if(theme==AppState.THEME_OCEAN) {
            x.bgTop=Color.rgb(2,31,85); x.bgBottom=Color.rgb(0,96,155); x.card=Color.rgb(8,39,86); x.cardSoft=Color.rgb(12,61,110);
            x.text=Color.WHITE; x.secondary=Color.rgb(183,216,239); x.primary=Color.rgb(0,200,255); x.border=Color.rgb(35,89,132);
            x.green=Color.rgb(60,230,130); x.orange=Color.rgb(255,177,57); x.pink=Color.rgb(255,105,143); x.purple=Color.rgb(151,121,255); x.cyan=Color.rgb(47,226,233);
            x.blueSoft=Color.rgb(12,76,130); x.danger=Color.rgb(255,93,93);
        } else {
            x.bgTop=Color.rgb(248,250,253); x.bgBottom=Color.rgb(238,244,250); x.card=Color.rgb(255,255,255); x.cardSoft=Color.rgb(244,247,251);
            x.text=Color.rgb(12,16,24); x.secondary=Color.rgb(111,125,149); x.primary=Color.rgb(0,132,255); x.border=Color.rgb(226,233,241);
            x.green=Color.rgb(40,210,90); x.orange=Color.rgb(255,159,28); x.pink=Color.rgb(245,81,121); x.purple=Color.rgb(126,92,250); x.cyan=Color.rgb(20,195,214);
            x.blueSoft=Color.rgb(229,242,255); x.danger=Color.rgb(236,76,76);
        }
        return x;
    }

    private RectF card(float l,float t,float w,float h){return new RectF(l,t,l+w,t+h);}    
    private void addHit(RectF r,String action,int a,int b){hits.add(new Hit(scrollMapped(r),action,a,b));}
    private RectF scrollMapped(RectF r){RectF x=new RectF(r); if(drawingScrollablePage) x.offset(0,-scrollY); return x;}
    private float dp(float v){return v*density;}
    private float sp(float v){return v*scaledDensity;}
    private static float clamp(float v,float min,float max){return Math.max(min,Math.min(max,v));}

    private void text(Canvas c,String s,float x,float y,float size,int color,boolean bold){
        p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(color); p.setTextSize(sp(size));
        p.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL)); p.setTextAlign(Paint.Align.LEFT); c.drawText(s,x,y,p);
    }
    private void textRight(Canvas c,String s,float x,float y,float size,int color,boolean bold){
        p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(color); p.setTextSize(sp(size));
        p.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL)); p.setTextAlign(Paint.Align.RIGHT); c.drawText(s,x,y,p); p.setTextAlign(Paint.Align.LEFT);
    }
    private void textCenter(Canvas c,String s,float x,float y,float size,int color,boolean bold){
        p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(color); p.setTextSize(sp(size));
        p.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL)); p.setTextAlign(Paint.Align.CENTER); c.drawText(s,x,y,p); p.setTextAlign(Paint.Align.LEFT);
    }
    private void drawRounded(Canvas c,RectF r,int color,float radius){p.setShader(null);p.setStyle(Paint.Style.FILL);p.setColor(color);c.drawRoundRect(r,radius,radius,p);}
    private void drawRoundedStroke(Canvas c,RectF r,int fill,int stroke,float radius){drawRounded(c,r,fill,radius);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1));p.setColor(stroke);c.drawRoundRect(r,radius,radius,p);p.setStyle(Paint.Style.FILL);}
    private void line(Canvas c,float x1,float y1,float x2,float y2,int color,float width){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(width);p.setStrokeCap(Paint.Cap.ROUND);p.setColor(color);c.drawLine(x1,y1,x2,y2,p);p.setStyle(Paint.Style.FILL);}
    private void drawDot(Canvas c,float x,float y,float r,int color){p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawCircle(x,y,r,p);}
    private void drawSoftCircle(Canvas c,float x,float y,float r,int color){p.setStyle(Paint.Style.FILL);p.setColor(color);c.drawCircle(x,y,r,p);}
    private void drawCheck(Canvas c,float x,float y,int color,float size){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(3));p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);p.setColor(color);path.reset();path.moveTo(x-size*.7f,y);path.lineTo(x-size*.15f,y+size*.55f);path.lineTo(x+size*.8f,y-size*.55f);c.drawPath(path,p);p.setStyle(Paint.Style.FILL);}
    private void drawChevron(Canvas c,float x,float y,int color,boolean left){float s=dp(6);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1.7f));p.setStrokeCap(Paint.Cap.ROUND);p.setColor(color);path.reset();if(left){path.moveTo(x+s/2,y-s);path.lineTo(x-s/2,y);path.lineTo(x+s/2,y+s);}else{path.moveTo(x-s/2,y-s);path.lineTo(x+s/2,y);path.lineTo(x-s/2,y+s);}c.drawPath(path,p);p.setStyle(Paint.Style.FILL);}
    private void drawChevronDown(Canvas c,float x,float y,int color){float s=dp(5);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1.4f));p.setColor(color);path.reset();path.moveTo(x-s,y-s/2);path.lineTo(x,y+s/2);path.lineTo(x+s,y-s/2);c.drawPath(path,p);p.setStyle(Paint.Style.FILL);}

    private void drawIcon(Canvas c,String icon,float x,float y,float s,int color){
        p.setShader(null);p.setColor(color);p.setStrokeWidth(dp(1.8f));p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);p.setStyle(Paint.Style.STROKE);
        path.reset();
        switch(icon){
            case "search": c.drawCircle(x-s*.18f,y-s*.18f,s*.58f,p); c.drawLine(x+s*.25f,y+s*.25f,x+s*.78f,y+s*.78f,p); break;
            case "more": p.setStyle(Paint.Style.FILL); c.drawCircle(x,y-s*.65f,dp(1.6f),p);c.drawCircle(x,y,dp(1.6f),p);c.drawCircle(x,y+s*.65f,dp(1.6f),p);break;
            case "home": path.moveTo(x-s*.78f,y);path.lineTo(x,y-s*.72f);path.lineTo(x+s*.78f,y);path.lineTo(x+s*.62f,y+s*.75f);path.lineTo(x+s*.12f,y+s*.75f);path.lineTo(x+s*.12f,y+s*.2f);path.lineTo(x-s*.12f,y+s*.2f);path.lineTo(x-s*.12f,y+s*.75f);path.lineTo(x-s*.62f,y+s*.75f);path.close();c.drawPath(path,p);break;
            case "mix": for(int i=-1;i<=1;i++){float xx=x+i*s*.55f;c.drawLine(xx,y-s*.75f,xx,y+s*.75f,p);float yy=y+i*s*.22f;c.drawCircle(xx,yy,s*.12f,p);}break;
            case "eq": for(int i=-1;i<=1;i++){float xx=x+i*s*.55f;float h=(i==0?1f:.65f)*s*.7f;c.drawLine(xx,y+h,xx,y-h,p);}break;
            case "volume": path.moveTo(x-s*.7f,y-s*.25f);path.lineTo(x-s*.35f,y-s*.25f);path.lineTo(x+s*.05f,y-s*.6f);path.lineTo(x+s*.05f,y+s*.6f);path.lineTo(x-s*.35f,y+s*.25f);path.lineTo(x-s*.7f,y+s*.25f);path.close();c.drawPath(path,p);c.drawArc(new RectF(x-s*.05f,y-s*.45f,x+s*.65f,y+s*.45f),-55,110,false,p);break;
            case "speaker": path.moveTo(x-s*.65f,y-s*.3f);path.lineTo(x-s*.25f,y-s*.3f);path.lineTo(x+s*.15f,y-s*.62f);path.lineTo(x+s*.15f,y+s*.62f);path.lineTo(x-s*.25f,y+s*.3f);path.lineTo(x-s*.65f,y+s*.3f);path.close();c.drawPath(path,p);c.drawArc(new RectF(x,y-s*.45f,x+s*.65f,y+s*.45f),-55,110,false,p);break;
            case "audio": for(int i=-2;i<=2;i++){float xx=x+i*s*.32f;float h=(i==0?0.75f:(i%2==0?0.35f:0.55f))*s;c.drawLine(xx,y-h,xx,y+h,p);}break;
            case "filter": path.moveTo(x-s*.75f,y-s*.65f);path.lineTo(x+s*.75f,y-s*.65f);path.lineTo(x+s*.18f,y);path.lineTo(x+s*.18f,y+s*.65f);path.lineTo(x-s*.18f,y+s*.45f);path.lineTo(x-s*.18f,y);path.close();c.drawPath(path,p);break;
            case "bt": path.moveTo(x,y-s*.8f);path.lineTo(x+s*.5f,y-s*.3f);path.lineTo(x-s*.35f,y+s*.45f);path.moveTo(x,y+s*.8f);path.lineTo(x+s*.5f,y+s*.3f);path.lineTo(x-s*.35f,y-s*.45f);path.moveTo(x,y-s*.8f);path.lineTo(x,y+s*.8f);c.drawPath(path,p);break;
            case "chip": c.drawRect(new RectF(x-s*.48f,y-s*.48f,x+s*.48f,y+s*.48f),p);for(int i=-1;i<=1;i++){float off=i*s*.35f;c.drawLine(x-s*.7f,y+off,x-s*.5f,y+off,p);c.drawLine(x+s*.5f,y+off,x+s*.7f,y+off,p);c.drawLine(x+off,y-s*.7f,x+off,y-s*.5f,p);c.drawLine(x+off,y+s*.5f,x+off,y+s*.7f,p);}break;
            case "preset": c.drawRoundRect(new RectF(x-s*.55f,y-s*.7f,x+s*.55f,y+s*.7f),s*.12f,s*.12f,p);for(int i=-1;i<=1;i++)c.drawLine(x-s*.3f,y+i*s*.3f,x+s*.3f,y+i*s*.3f,p);break;
            case "gear": c.drawCircle(x,y,s*.55f,p);c.drawCircle(x,y,s*.2f,p);for(int i=0;i<8;i++){double a=i*Math.PI/4;float x1=(float)(x+Math.cos(a)*s*.65f),y1=(float)(y+Math.sin(a)*s*.65f),x2=(float)(x+Math.cos(a)*s*.85f),y2=(float)(y+Math.sin(a)*s*.85f);c.drawLine(x1,y1,x2,y2,p);}break;
            case "reset": c.drawArc(new RectF(x-s*.6f,y-s*.6f,x+s*.6f,y+s*.6f),-55,290,false,p);path.moveTo(x-s*.52f,y-s*.58f);path.lineTo(x-s*.72f,y-s*.18f);path.lineTo(x-s*.28f,y-s*.2f);c.drawPath(path,p);break;
            case "wave": path.moveTo(x-s*.75f,y);path.cubicTo(x-s*.5f,y-s*.65f,x-s*.25f,y+s*.65f,x,y);path.cubicTo(x+s*.25f,y-s*.65f,x+s*.5f,y+s*.65f,x+s*.75f,y);c.drawPath(path,p);break;
            case "save": c.drawRect(new RectF(x-s*.65f,y-s*.65f,x+s*.65f,y+s*.65f),p);c.drawRect(new RectF(x-s*.34f,y-s*.65f,x+s*.28f,y-s*.18f),p);c.drawRect(new RectF(x-s*.34f,y+s*.12f,x+s*.34f,y+s*.65f),p);break;
            case "folder": path.moveTo(x-s*.72f,y-s*.4f);path.lineTo(x-s*.18f,y-s*.4f);path.lineTo(x+s*.02f,y-s*.62f);path.lineTo(x+s*.72f,y-s*.62f);path.lineTo(x+s*.72f,y+s*.55f);path.lineTo(x-s*.72f,y+s*.55f);path.close();c.drawPath(path,p);break;
            default: c.drawCircle(x,y,s*.6f,p);break;
        }
        p.setStyle(Paint.Style.FILL);
    }

    private float freqX(float f,RectF g){double t=(Math.log(f)-Math.log(20d))/(Math.log(20000d)-Math.log(20d));return g.left+(float)t*g.width();}
    private float gainY(float gain,RectF g){return g.top+(12f-clamp(gain,-12,12))/24f*g.height();}
    private static int withAlpha(int color,int a){return Color.argb(a,Color.red(color),Color.green(color),Color.blue(color));}
    private static int blend(int a,int b,float t){int r=(int)(Color.red(a)*(1-t)+Color.red(b)*t),g=(int)(Color.green(a)*(1-t)+Color.green(b)*t),bl=(int)(Color.blue(a)*(1-t)+Color.blue(b)*t);return Color.rgb(r,g,bl);}
    private static String channelName(int ch){String[] n={"Front Left","Front Right","Rear Left","Rear Right","Center","Subwoofer","Aux"};return n[Math.max(0,Math.min(n.length-1,ch))];}
    private static String formatDb(float v){if(Math.abs(v)<.05f)return "0 dB";return String.format(Locale.US,"%+.1f dB",v);}
    private static String formatHz(float f){if(f>=1000f)return String.format(Locale.US,f>=10000?"%.1f kHz":"%.2f kHz",f/1000f);return String.format(Locale.US,"%.0f Hz",f);}
}
