package com.okn.dsp;

import android.app.AlertDialog;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.text.InputType;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * OKN DSP V1 / Phase 1
 * Entire UI is drawn from native primitives and text. No screenshot/reference image is used as a screen background.
 */
public final class DspUiView extends View {
    private static final int HIT_THEME = 1;
    private static final int HIT_HOME = 2;
    private static final int HIT_MIX = 3;
    private static final int HIT_EQ = 4;
    private static final int HIT_QUICK_MIX = 5;
    private static final int HIT_CHANNEL = 6;
    private static final int HIT_BAND_PREV = 7;
    private static final int HIT_BAND_NEXT = 8;
    private static final int HIT_RESET_EQ = 9;
    private static final int HIT_PRESET_NAME = 10;
    private static final int HIT_PRESET_SAVE = 11;
    private static final int HIT_PRESET_LOAD = 12;
    private static final int HIT_PRESET_DELETE = 13;
    private static final int HIT_INFO = 14;

    private static final int SL_MASTER = 100;
    private static final int SL_BASS = 101;
    private static final int SL_CUTOFF = 102;
    private static final int SL_CHANNEL = 103;
    private static final int SL_FREQ = 104;
    private static final int SL_Q = 105;
    private static final int SL_GAIN = 106;

    private final UiState state;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path graphPath = new Path();
    private final List<Hit> hits = new ArrayList<>();
    private final float density;
    private final Bitmap logo;
    private final float[] scroll = new float[3];

    private Palette palette;
    private SliderHit activeSlider;
    private GraphHit activeGraph;
    private boolean scrollCandidate;
    private boolean didScroll;
    private float downX, downY, lastY;
    private float contentHeight;
    private float navTop;
    private float safeLeft, safeTop, safeRight, safeBottom;
    private float contentLeft, contentRight, contentWidth;
    private int lastWidth, lastHeight;

    private final int[] accents = {
            Color.rgb(255, 42, 100),   // pink
            Color.rgb(23, 202, 211),   // cyan
            Color.rgb(43, 202, 124),   // green
            Color.rgb(255, 68, 92),    // red
            Color.rgb(167, 83, 255),   // violet
            Color.rgb(35, 191, 179),   // teal
            Color.rgb(236, 56, 182)    // magenta
    };

    public DspUiView(Context context, UiState state) {
        super(context);
        this.state = state;
        density = getResources().getDisplayMetrics().density;
        logo = BitmapFactory.decodeResource(getResources(), R.drawable.okn_icon);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        setFocusable(true);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    public void setSafeInsets(int left, int top, int right, int bottom) {
        safeLeft = left;
        safeTop = top;
        safeRight = right;
        safeBottom = bottom;
        invalidate();
    }

    public void refreshTheme() {
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        lastWidth = w;
        lastHeight = h;
        for (int i = 0; i < scroll.length; i++) scroll[i] = 0f;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        hits.clear();
        activePalette();

        canvas.drawColor(palette.bg);
        float side = dp(14);
        float usable = getWidth() - safeLeft - safeRight - side * 2f;
        float max = dp(getWidth() / density >= 900 ? 1040 : 760);
        contentWidth = Math.min(usable, max);
        contentLeft = safeLeft + (getWidth() - safeLeft - safeRight - contentWidth) / 2f;
        contentRight = contentLeft + contentWidth;

        float navH = dp(70) + safeBottom;
        navTop = getHeight() - navH;

        float y = safeTop + dp(12) - scroll[state.screen];
        y = drawHeader(canvas, y);
        if (state.screen == UiState.SCREEN_HOME) {
            contentHeight = drawHome(canvas, y) + scroll[state.screen];
        } else if (state.screen == UiState.SCREEN_MIX) {
            contentHeight = drawMix(canvas, y) + scroll[state.screen];
        } else {
            contentHeight = drawEq(canvas, y) + scroll[state.screen];
        }

        drawBottomNav(canvas, navTop, navH);
        clampScroll();
    }

    private void activePalette() {
        boolean dark;
        if (state.themeMode == UiState.THEME_LIGHT) dark = false;
        else if (state.themeMode == UiState.THEME_DARK) dark = true;
        else dark = state.screen == UiState.SCREEN_MIX;
        palette = dark ? Palette.dark() : Palette.light();
    }

    private float drawHeader(Canvas c, float y) {
        float h = dp(60);
        float icon = dp(40);
        RectF ir = new RectF(contentLeft, y + dp(4), contentLeft + icon, y + dp(4) + icon);
        c.drawBitmap(logo, null, ir, paint);

        text(c, "OKN DSP", contentLeft + icon + dp(12), y + dp(22), sp(18), palette.text, true);
        String sub = state.screen == UiState.SCREEN_HOME ? "DSP Controller · Phase 1 UI"
                : state.screen == UiState.SCREEN_MIX ? "Channel and bass controls"
                : "15-band equalizer · 7 channels";
        text(c, sub, contentLeft + icon + dp(12), y + dp(42), sp(10.5f), palette.muted, false);

        float bw = dp(66), bh = dp(34);
        RectF theme = new RectF(contentRight - bw, y + dp(7), contentRight, y + dp(7) + bh);
        roundRect(c, theme, bh / 2f, palette.card, palette.border);
        textCenter(c, state.themeLabel(), theme.centerX(), theme.centerY() + dp(0.7f), sp(9.5f), palette.text, true);
        addHit(HIT_THEME, -1, theme);
        return y + h;
    }

    private float drawHome(Canvas c, float y) {
        y += dp(4);
        RectF status = new RectF(contentLeft, y, contentRight, y + dp(92));
        roundRect(c, status, dp(18), palette.card, palette.border);
        float cx = status.left + dp(37), cy = status.centerY();
        paint.setStyle(Paint.Style.FILL); paint.setColor(Color.rgb(37, 211, 117));
        c.drawCircle(cx, cy, dp(22), paint);
        stroke.setColor(Color.WHITE); stroke.setStrokeWidth(dp(3));
        c.drawLine(cx - dp(8), cy, cx - dp(2), cy + dp(6), stroke);
        c.drawLine(cx - dp(2), cy + dp(6), cx + dp(10), cy - dp(8), stroke);
        text(c, "SYSTEM STATUS", status.left + dp(72), y + dp(28), sp(9), palette.muted, true);
        text(c, "UI System Ready", status.left + dp(72), y + dp(49), sp(15), palette.text, true);
        text(c, "Local state + theme persistence active", status.left + dp(72), y + dp(69), sp(10.5f), palette.muted, false);
        y += dp(108);

        text(c, "Connection & Status", contentLeft, y, sp(14), palette.text, true);
        textRight(c, "Phase 1", contentRight, y, sp(10.5f), accents[2], true);
        y += dp(15);

        y = homeRow(c, y, accents[1], "Bluetooth", "Transport is added in Phase 2", "Pending");
        y = homeRow(c, y, accents[0], "DSP Device", "Protocol file not attached yet", "Pending");
        y = homeRow(c, y, accents[3], "Audio Input", "Interactive UI preview", "Active");
        y = homeRow(c, y, accents[2], "Preset Sync", "Saved locally in real time", "Local");
        y = homeRow(c, y, accents[4], "Firmware / App", "OKN DSP Version 1 · Phase 1", "Ready");

        y += dp(8);
        RectF quick = new RectF(contentLeft, y, contentRight, y + dp(76));
        roundRect(c, quick, dp(16), palette.card, palette.border);
        paint.setColor(withAlpha(accents[0], 28)); paint.setStyle(Paint.Style.FILL);
        c.drawRoundRect(new RectF(quick.left + dp(12), quick.top + dp(12), quick.left + dp(56), quick.bottom - dp(12)), dp(12), dp(12), paint);
        // Mini sliders icon
        stroke.setStrokeWidth(dp(2)); stroke.setColor(accents[0]);
        for (int i = 0; i < 3; i++) {
            float xx = quick.left + dp(23 + i * 10);
            c.drawLine(xx, quick.top + dp(24), xx, quick.bottom - dp(24), stroke);
            paint.setColor(accents[0]); c.drawCircle(xx, quick.top + dp(30 + i * 5), dp(3), paint);
        }
        text(c, "Quick Control", quick.left + dp(70), quick.top + dp(31), sp(13.5f), palette.text, true);
        text(c, "Open Mix controls", quick.left + dp(70), quick.top + dp(52), sp(10.5f), palette.muted, false);
        chevron(c, quick.right - dp(23), quick.centerY(), palette.muted);
        addHit(HIT_QUICK_MIX, -1, quick);
        y += dp(92);

        RectF note = new RectF(contentLeft, y, contentRight, y + dp(74));
        roundRect(c, note, dp(16), withAlpha(accents[1], palette.dark ? 20 : 14), withAlpha(accents[1], 70));
        text(c, "Phase 1 UI only", note.left + dp(16), note.top + dp(27), sp(12.5f), palette.text, true);
        text(c, "No DSP packets are transmitted until Phase 2 protocol data is supplied.", note.left + dp(16), note.top + dp(50), sp(9.8f), palette.muted, false);
        addHit(HIT_INFO, -1, note);
        return y + dp(94);
    }

    private float homeRow(Canvas c, float y, int accent, String title, String subtitle, String status) {
        RectF r = new RectF(contentLeft, y + dp(6), contentRight, y + dp(64));
        roundRect(c, r, dp(14), palette.card, palette.border);
        paint.setStyle(Paint.Style.FILL); paint.setColor(accent);
        c.drawCircle(r.left + dp(27), r.centerY(), dp(15), paint);
        stroke.setColor(Color.WHITE); stroke.setStrokeWidth(dp(2));
        c.drawLine(r.left + dp(21), r.centerY(), r.left + dp(33), r.centerY(), stroke);
        c.drawLine(r.left + dp(27), r.centerY() - dp(6), r.left + dp(27), r.centerY() + dp(6), stroke);
        text(c, title, r.left + dp(52), r.top + dp(24), sp(11.5f), palette.text, true);
        text(c, subtitle, r.left + dp(52), r.top + dp(42), sp(8.8f), palette.muted, false);
        textRight(c, status, r.right - dp(23), r.centerY() + dp(1), sp(9.5f), accent, true);
        chevron(c, r.right - dp(11), r.centerY(), palette.muted);
        addHit(HIT_INFO, -1, r);
        return y + dp(66);
    }

    private float drawMix(Canvas c, float y) {
        y += dp(2);
        text(c, "Global", contentLeft, y + dp(15), sp(14), palette.text, true);
        textRight(c, "Overall output and bass settings", contentRight, y + dp(15), sp(9.3f), palette.muted, false);
        y += dp(27);
        RectF global = new RectF(contentLeft, y, contentRight, y + dp(214));
        roundRect(c, global, dp(18), palette.card, palette.border);
        float rowY = y + dp(16);
        rowY = drawSliderRow(c, rowY, global.left + dp(12), global.right - dp(12), accents[0], "Master Volume", state.masterDb, -60, 6, SL_MASTER, -1, false, formatDb(state.masterDb));
        rowY = drawSliderRow(c, rowY, global.left + dp(12), global.right - dp(12), accents[1], "Bass Volume", state.bassDb, -12, 12, SL_BASS, -1, false, formatDb(state.bassDb));
        drawSliderRow(c, rowY, global.left + dp(12), global.right - dp(12), accents[3], "Bass Cutoff", state.bassCutoffHz, 40, 250, SL_CUTOFF, -1, true, UiState.formatFrequency(state.bassCutoffHz));
        y = global.bottom + dp(18);

        text(c, "Channels", contentLeft, y + dp(15), sp(14), palette.text, true);
        textRight(c, "Individual channel levels", contentRight, y + dp(15), sp(9.3f), palette.muted, false);
        y += dp(28);
        RectF channels = new RectF(contentLeft, y, contentRight, y + dp(7 * 61 + 24));
        roundRect(c, channels, dp(18), palette.card, palette.border);
        rowY = y + dp(12);
        for (int ch = 0; ch < UiState.CHANNELS; ch++) {
            rowY = drawSliderRow(c, rowY, channels.left + dp(12), channels.right - dp(12), accents[ch], "Volume Ch" + (ch + 1), state.channelDb[ch], -60, 6, SL_CHANNEL, ch, false, formatDb(state.channelDb[ch]));
        }
        y = channels.bottom + dp(20);

        RectF hint = new RectF(contentLeft, y, contentRight, y + dp(58));
        roundRect(c, hint, dp(15), withAlpha(accents[0], 18), withAlpha(accents[0], 60));
        text(c, "REAL-TIME LOCAL STATE", hint.left + dp(15), hint.top + dp(23), sp(9), accents[0], true);
        text(c, "Drag any slider — the number and saved value update immediately.", hint.left + dp(15), hint.top + dp(42), sp(9.5f), palette.muted, false);
        return hint.bottom + dp(18);
    }

    private float drawSliderRow(Canvas c, float y, float left, float right, int accent, String title,
                                float value, float min, float max, int sliderType, int index,
                                boolean logarithmic, String valueText) {
        float h = dp(59);
        float bubble = dp(36);
        paint.setStyle(Paint.Style.FILL); paint.setColor(withAlpha(accent, palette.dark ? 45 : 26));
        c.drawCircle(left + dp(19), y + dp(21), dp(15), paint);
        textCenter(c, index >= 0 ? String.valueOf(index + 1) : "•", left + dp(19), y + dp(21), sp(index >= 0 ? 10.5f : 16), accent, true);
        text(c, title, left + dp(43), y + dp(15), sp(10.6f), palette.text, false);

        RectF valueBox = new RectF(right - dp(48), y + dp(5), right, y + dp(31));
        roundRect(c, valueBox, dp(8), palette.valueBox, palette.border);
        textCenter(c, valueText, valueBox.centerX(), valueBox.centerY() + dp(.5f), sp(8.5f), palette.text, true);

        float trackLeft = left + dp(44);
        float trackRight = right - dp(60);
        float trackY = y + dp(37);
        drawSlider(c, trackLeft, trackRight, trackY, value, min, max, accent, sliderType, index, logarithmic);
        return y + h;
    }

    private void drawSlider(Canvas c, float left, float right, float y, float value, float min, float max,
                            int accent, int type, int index, boolean logarithmic) {
        stroke.setStrokeWidth(dp(4)); stroke.setColor(palette.track); stroke.setStrokeCap(Paint.Cap.ROUND);
        c.drawLine(left, y, right, y, stroke);
        float t = logarithmic ? logNorm(value, min, max) : norm(value, min, max);
        float x = lerp(left, right, t);
        stroke.setColor(accent); c.drawLine(left, y, x, y, stroke);
        paint.setStyle(Paint.Style.FILL); paint.setColor(palette.thumbOuter); c.drawCircle(x, y, dp(7.5f), paint);
        paint.setColor(accent); c.drawCircle(x, y, dp(4.3f), paint);
        RectF hit = new RectF(left - dp(10), y - dp(16), right + dp(10), y + dp(16));
        addSlider(type, index, hit, left, right, min, max, logarithmic);
    }

    private float drawEq(Canvas c, float y) {
        y += dp(2);
        y = drawChannelChips(c, y);
        y += dp(12);

        RectF graphCard = new RectF(contentLeft, y, contentRight, y + dp(252));
        roundRect(c, graphCard, dp(18), palette.card, palette.border);
        text(c, "Channel " + (state.selectedChannel + 1), graphCard.left + dp(14), graphCard.top + dp(25), sp(13.5f), palette.text, true);
        text(c, "Front Left · 15-band EQ", graphCard.left + dp(14), graphCard.top + dp(44), sp(8.8f), palette.muted, false);
        RectF reset = new RectF(graphCard.right - dp(82), graphCard.top + dp(12), graphCard.right - dp(12), graphCard.top + dp(42));
        roundRect(c, reset, dp(12), withAlpha(accents[0], 18), withAlpha(accents[0], 65));
        textCenter(c, "Reset EQ", reset.centerX(), reset.centerY(), sp(8.7f), accents[0], true);
        addHit(HIT_RESET_EQ, -1, reset);

        RectF graph = new RectF(graphCard.left + dp(25), graphCard.top + dp(62), graphCard.right - dp(13), graphCard.bottom - dp(28));
        drawEqGraph(c, graph);
        activeGraph = null; // drawing registers via hit list, active is touch-only
        hits.add(new GraphHit(graph));
        y = graphCard.bottom + dp(12);

        RectF bandCard = new RectF(contentLeft, y, contentRight, y + dp(206));
        roundRect(c, bandCard, dp(18), palette.card, palette.border);
        float by = bandCard.top + dp(20);
        paint.setColor(withAlpha(accents[0], 28)); paint.setStyle(Paint.Style.FILL);
        c.drawCircle(bandCard.left + dp(25), by, dp(14), paint);
        textCenter(c, String.valueOf(state.selectedBand + 1), bandCard.left + dp(25), by, sp(10.5f), accents[0], true);
        text(c, "Band " + (state.selectedBand + 1), bandCard.left + dp(48), by - dp(3), sp(12.2f), palette.text, true);
        text(c, "Adjust selected band parameters", bandCard.left + dp(48), by + dp(14), sp(8.7f), palette.muted, false);

        RectF prev = new RectF(bandCard.right - dp(78), bandCard.top + dp(9), bandCard.right - dp(45), bandCard.top + dp(42));
        RectF next = new RectF(bandCard.right - dp(39), bandCard.top + dp(9), bandCard.right - dp(6), bandCard.top + dp(42));
        roundRect(c, prev, dp(12), palette.valueBox, palette.border); roundRect(c, next, dp(12), palette.valueBox, palette.border);
        chevronLeft(c, prev.centerX(), prev.centerY(), palette.text); chevron(c, next.centerX(), next.centerY(), palette.text);
        addHit(HIT_BAND_PREV, -1, prev); addHit(HIT_BAND_NEXT, -1, next);

        int ch = state.selectedChannel, b = state.selectedBand;
        float row = bandCard.top + dp(59);
        row = drawParamSlider(c, row, bandCard, accents[1], "Frequency", UiState.formatFrequency(state.eqFrequencyHz[ch][b]), state.eqFrequencyHz[ch][b], 20, 20000, SL_FREQ, true);
        row = drawParamSlider(c, row, bandCard, accents[4], "Q (Quality Factor)", String.format(Locale.US, "%.2f", state.eqQ[ch][b]), state.eqQ[ch][b], .1f, 10f, SL_Q, false);
        drawParamSlider(c, row, bandCard, accents[2], "Gain Band", formatDb(state.eqGainDb[ch][b]), state.eqGainDb[ch][b], -12f, 12f, SL_GAIN, false);
        y = bandCard.bottom + dp(12);

        RectF preset = new RectF(contentLeft, y, contentRight, y + dp(148));
        roundRect(c, preset, dp(18), palette.card, palette.border);
        text(c, "Presets", preset.left + dp(14), preset.top + dp(22), sp(12.5f), palette.text, true);
        text(c, "Save and load EQ + mix state", preset.left + dp(14), preset.top + dp(39), sp(8.5f), palette.muted, false);

        RectF name = new RectF(preset.left + dp(14), preset.top + dp(54), preset.right - dp(14), preset.top + dp(84));
        roundRect(c, name, dp(9), palette.valueBox, palette.border);
        text(c, state.hasPreset ? state.presetName : "Tap to name preset", name.left + dp(10), name.centerY() + dp(1), sp(9.2f), state.hasPreset ? palette.text : palette.muted, false);
        addHit(HIT_PRESET_NAME, -1, name);

        float gap = dp(7); float bw = (name.width() - gap * 2) / 3f; float top = preset.top + dp(95);
        RectF save = new RectF(name.left, top, name.left + bw, top + dp(36));
        RectF load = new RectF(save.right + gap, top, save.right + gap + bw, top + dp(36));
        RectF del = new RectF(load.right + gap, top, name.right, top + dp(36));
        button(c, save, "Save", accents[0], true); button(c, load, "Load", accents[1], false); button(c, del, "Delete", accents[3], false);
        addHit(HIT_PRESET_SAVE, -1, save); addHit(HIT_PRESET_LOAD, -1, load); addHit(HIT_PRESET_DELETE, -1, del);
        return preset.bottom + dp(20);
    }

    private float drawChannelChips(Canvas c, float y) {
        text(c, "EQ Channels", contentLeft, y + dp(13), sp(11.5f), palette.text, true);
        y += dp(22);
        float gap = dp(5);
        float chipW = (contentWidth - gap * 6f) / 7f;
        float chipH = dp(34);
        for (int ch = 0; ch < 7; ch++) {
            float l = contentLeft + ch * (chipW + gap);
            RectF r = new RectF(l, y, l + chipW, y + chipH);
            int fill = ch == state.selectedChannel ? accents[0] : palette.valueBox;
            int border = ch == state.selectedChannel ? accents[0] : palette.border;
            roundRect(c, r, chipH / 2f, fill, border);
            textCenter(c, "Ch" + (ch + 1), r.centerX(), r.centerY(), sp(8.4f), ch == state.selectedChannel ? Color.WHITE : palette.muted, true);
            addHit(HIT_CHANNEL, ch, r);
        }
        return y + chipH;
    }

    private float drawParamSlider(Canvas c, float y, RectF card, int accent, String title, String valueText,
                                  float value, float min, float max, int type, boolean log) {
        text(c, title, card.left + dp(16), y + dp(8), sp(9.7f), palette.text, true);
        textRight(c, valueText, card.right - dp(16), y + dp(8), sp(8.8f), palette.text, true);
        float left = card.left + dp(17), right = card.right - dp(17), ty = y + dp(28);
        drawSlider(c, left, right, ty, value, min, max, accent, type, -1, log);
        return y + dp(47);
    }

    private void drawEqGraph(Canvas c, RectF graph) {
        // grid
        stroke.setStrokeWidth(dp(.8f)); stroke.setColor(palette.grid);
        for (int i = 0; i <= 6; i++) {
            float yy = lerp(graph.top, graph.bottom, i / 6f);
            c.drawLine(graph.left, yy, graph.right, yy, stroke);
        }
        for (int i = 0; i <= 9; i++) {
            float xx = lerp(graph.left, graph.right, i / 9f);
            c.drawLine(xx, graph.top, xx, graph.bottom, stroke);
        }

        // zero line
        stroke.setStrokeWidth(dp(1.5f)); stroke.setColor(withAlpha(palette.muted, 100));
        float zeroY = gainToY(0, graph);
        c.drawLine(graph.left, zeroY, graph.right, zeroY, stroke);

        int ch = state.selectedChannel;
        graphPath.reset();
        for (int b = 0; b < UiState.BANDS; b++) {
            float x = freqToX(state.eqFrequencyHz[ch][b], graph);
            float y = gainToY(state.eqGainDb[ch][b], graph);
            if (b == 0) graphPath.moveTo(x, y); else graphPath.lineTo(x, y);
        }
        stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(dp(2.3f)); stroke.setColor(accents[1]);
        c.drawPath(graphPath, stroke);

        for (int b = 0; b < UiState.BANDS; b++) {
            float x = freqToX(state.eqFrequencyHz[ch][b], graph);
            float gy = gainToY(state.eqGainDb[ch][b], graph);
            int color = b == state.selectedBand ? accents[0] : (b < state.selectedBand ? accents[1] : accents[2]);
            if (b == state.selectedBand) {
                paint.setStyle(Paint.Style.FILL); paint.setColor(withAlpha(accents[0], 40)); c.drawCircle(x, gy, dp(11), paint);
            }
            paint.setColor(color); c.drawCircle(x, gy, dp(b == state.selectedBand ? 5.5f : 3.8f), paint);
            paint.setColor(palette.bg); c.drawCircle(x, gy, dp(b == state.selectedBand ? 2.4f : 1.4f), paint);
        }

        text(c, "+12", graph.left - dp(22), graph.top + dp(2), sp(6.8f), palette.muted, false);
        text(c, "0", graph.left - dp(15), zeroY + dp(2), sp(6.8f), palette.muted, false);
        text(c, "-12", graph.left - dp(22), graph.bottom, sp(6.8f), palette.muted, false);
        String[] labels = {"20", "100", "500", "1K", "5K", "20K"};
        float[] hz = {20, 100, 500, 1000, 5000, 20000};
        for (int i = 0; i < labels.length; i++) {
            float x = freqToX(hz[i], graph);
            textCenter(c, labels[i], x, graph.bottom + dp(13), sp(6.6f), palette.muted, false);
        }
    }

    private void drawBottomNav(Canvas c, float top, float navH) {
        paint.setStyle(Paint.Style.FILL); paint.setColor(palette.nav); c.drawRect(0, top, getWidth(), getHeight(), paint);
        stroke.setColor(palette.border); stroke.setStrokeWidth(dp(1)); c.drawLine(0, top, getWidth(), top, stroke);

        float w = getWidth() / 3f;
        drawNavItem(c, new RectF(0, top, w, getHeight()), UiState.SCREEN_HOME, "Home");
        drawNavItem(c, new RectF(w, top, w * 2, getHeight()), UiState.SCREEN_MIX, "Mix");
        drawNavItem(c, new RectF(w * 2, top, getWidth(), getHeight()), UiState.SCREEN_EQ, "EQ");
    }

    private void drawNavItem(Canvas c, RectF r, int screen, String label) {
        boolean selected = state.screen == screen;
        float top = r.top + dp(7);
        if (selected) {
            RectF pill = new RectF(r.centerX() - dp(40), top, r.centerX() + dp(40), top + dp(44));
            roundRect(c, pill, dp(14), withAlpha(accents[0], palette.dark ? 55 : 30), Color.TRANSPARENT);
        }
        int color = selected ? accents[0] : palette.muted;
        float cx = r.centerX(), iy = top + dp(14);
        stroke.setStrokeWidth(dp(2.2f)); stroke.setColor(color);
        if (screen == UiState.SCREEN_HOME) {
            Path house = new Path();
            house.moveTo(cx - dp(8), iy); house.lineTo(cx, iy - dp(7)); house.lineTo(cx + dp(8), iy); house.lineTo(cx + dp(6), iy); house.lineTo(cx + dp(6), iy + dp(8)); house.lineTo(cx - dp(6), iy + dp(8)); house.close();
            c.drawPath(house, stroke);
        } else if (screen == UiState.SCREEN_MIX) {
            for (int i = -1; i <= 1; i++) {
                float x = cx + i * dp(7); c.drawLine(x, iy - dp(8), x, iy + dp(8), stroke);
                paint.setColor(color); c.drawCircle(x, iy + i * dp(3), dp(2.5f), paint);
            }
        } else {
            for (int i = -1; i <= 1; i++) {
                float x = cx + i * dp(7); c.drawLine(x, iy - dp(7 + i * 2), x, iy + dp(7 + i * 2), stroke);
            }
        }
        textCenter(c, label, cx, top + dp(36), sp(8.5f), color, selected);
        addHit(screen == UiState.SCREEN_HOME ? HIT_HOME : screen == UiState.SCREEN_MIX ? HIT_MIX : HIT_EQ, -1, r);
    }

    private void button(Canvas c, RectF r, String label, int accent, boolean solid) {
        int fill = solid ? accent : withAlpha(accent, palette.dark ? 22 : 14);
        int border = solid ? accent : withAlpha(accent, 90);
        roundRect(c, r, dp(10), fill, border);
        textCenter(c, label, r.centerX(), r.centerY(), sp(9), solid ? Color.WHITE : accent, true);
    }

    private void roundRect(Canvas c, RectF r, float radius, int fill, int border) {
        paint.setStyle(Paint.Style.FILL); paint.setColor(fill); c.drawRoundRect(r, radius, radius, paint);
        if (Color.alpha(border) > 0) {
            stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(dp(1)); stroke.setColor(border);
            c.drawRoundRect(r, radius, radius, stroke);
        }
    }

    private void chevron(Canvas c, float cx, float cy, int color) {
        stroke.setStrokeWidth(dp(1.8f)); stroke.setColor(color); stroke.setStrokeCap(Paint.Cap.ROUND);
        c.drawLine(cx - dp(2), cy - dp(4), cx + dp(2), cy, stroke);
        c.drawLine(cx + dp(2), cy, cx - dp(2), cy + dp(4), stroke);
    }

    private void chevronLeft(Canvas c, float cx, float cy, int color) {
        stroke.setStrokeWidth(dp(1.8f)); stroke.setColor(color); stroke.setStrokeCap(Paint.Cap.ROUND);
        c.drawLine(cx + dp(2), cy - dp(4), cx - dp(2), cy, stroke);
        c.drawLine(cx - dp(2), cy, cx + dp(2), cy + dp(4), stroke);
    }

    private void text(Canvas c, String s, float x, float baselineY, float size, int color, boolean bold) {
        paint.setStyle(Paint.Style.FILL); paint.setColor(color); paint.setTextSize(size); paint.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT); paint.setTextAlign(Paint.Align.LEFT);
        Paint.FontMetrics fm = paint.getFontMetrics();
        c.drawText(s, x, baselineY - (fm.ascent + fm.descent) * 0.18f, paint);
    }

    private void textRight(Canvas c, String s, float x, float baselineY, float size, int color, boolean bold) {
        paint.setStyle(Paint.Style.FILL); paint.setColor(color); paint.setTextSize(size); paint.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT); paint.setTextAlign(Paint.Align.RIGHT);
        Paint.FontMetrics fm = paint.getFontMetrics();
        c.drawText(s, x, baselineY - (fm.ascent + fm.descent) * 0.18f, paint);
    }

    private void textCenter(Canvas c, String s, float x, float y, float size, int color, boolean bold) {
        paint.setStyle(Paint.Style.FILL); paint.setColor(color); paint.setTextSize(size); paint.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT); paint.setTextAlign(Paint.Align.CENTER);
        Paint.FontMetrics fm = paint.getFontMetrics();
        c.drawText(s, x, y - (fm.ascent + fm.descent) / 2f, paint);
    }

    private void addHit(int type, int index, RectF r) {
        hits.add(new Hit(type, index, new RectF(r)));
    }

    private void addSlider(int type, int index, RectF hit, float left, float right, float min, float max, boolean log) {
        hits.add(new SliderHit(type, index, new RectF(hit), left, right, min, max, log));
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX(), y = event.getY();
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = x; downY = y; lastY = y; didScroll = false; scrollCandidate = false;
                activeSlider = null; activeGraph = null;
                Hit h = findHit(x, y);
                if (h instanceof SliderHit) {
                    activeSlider = (SliderHit) h;
                    updateSlider(activeSlider, x);
                    getParent().requestDisallowInterceptTouchEvent(true);
                } else if (h instanceof GraphHit) {
                    activeGraph = (GraphHit) h;
                    updateGraph(activeGraph, x, y);
                    getParent().requestDisallowInterceptTouchEvent(true);
                } else {
                    scrollCandidate = y < navTop;
                }
                return true;

            case MotionEvent.ACTION_MOVE:
                if (activeSlider != null) {
                    updateSlider(activeSlider, x);
                    return true;
                }
                if (activeGraph != null) {
                    updateGraph(activeGraph, x, y);
                    return true;
                }
                if (scrollCandidate) {
                    float dy = y - lastY;
                    if (Math.abs(y - downY) > dp(5)) didScroll = true;
                    scroll[state.screen] -= dy;
                    clampScroll();
                    lastY = y;
                    invalidate();
                    return true;
                }
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (activeSlider != null || activeGraph != null) {
                    state.flushRealtimeState();
                    activeSlider = null; activeGraph = null;
                    invalidate();
                    return true;
                }
                if (!didScroll && event.getActionMasked() == MotionEvent.ACTION_UP) {
                    Hit up = findHit(x, y);
                    if (up != null) handleClick(up);
                }
                scrollCandidate = false;
                return true;
        }
        return super.onTouchEvent(event);
    }

    private Hit findHit(float x, float y) {
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (h.rect.contains(x, y)) return h;
        }
        return null;
    }

    private void handleClick(Hit h) {
        switch (h.type) {
            case HIT_THEME:
                state.setThemeMode((state.themeMode + 1) % 3);
                toast("Theme: " + state.themeLabel());
                invalidate();
                break;
            case HIT_HOME:
                go(UiState.SCREEN_HOME); break;
            case HIT_MIX:
            case HIT_QUICK_MIX:
                go(UiState.SCREEN_MIX); break;
            case HIT_EQ:
                go(UiState.SCREEN_EQ); break;
            case HIT_CHANNEL:
                state.setSelectedChannel(h.index); invalidate(); break;
            case HIT_BAND_PREV:
                state.setSelectedBand((state.selectedBand + UiState.BANDS - 1) % UiState.BANDS); invalidate(); break;
            case HIT_BAND_NEXT:
                state.setSelectedBand((state.selectedBand + 1) % UiState.BANDS); invalidate(); break;
            case HIT_RESET_EQ:
                state.resetCurrentEq(); toast("Channel " + (state.selectedChannel + 1) + " EQ reset"); invalidate(); break;
            case HIT_PRESET_NAME:
                showPresetDialog(false); break;
            case HIT_PRESET_SAVE:
                if (state.presetName == null || state.presetName.trim().isEmpty() || "Flat".equals(state.presetName)) showPresetDialog(true);
                else { state.savePreset(state.presetName); toast("Saved: " + state.presetName); invalidate(); }
                break;
            case HIT_PRESET_LOAD:
                if (state.loadPreset()) toast("Loaded: " + state.presetName); else toast("No saved preset yet");
                invalidate(); break;
            case HIT_PRESET_DELETE:
                state.deletePreset(); toast("Preset deleted"); invalidate(); break;
            case HIT_INFO:
                toast("Phase 1: UI + local real-time state. DSP transport starts in Phase 2."); break;
        }
    }

    private void go(int screen) {
        state.setScreen(screen);
        scroll[screen] = 0f;
        invalidate();
    }

    private void showPresetDialog(boolean saveAfter) {
        final EditText input = new EditText(getContext());
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setHint("Preset name");
        input.setText(state.hasPreset ? state.presetName : "");
        input.setSelectAllOnFocus(true);
        int pad = (int) dp(18);
        input.setPadding(pad, pad / 2, pad, pad / 2);
        AlertDialog dialog = new AlertDialog.Builder(getContext())
                .setTitle("Preset name")
                .setView(input)
                .setNegativeButton("Cancel", null)
                .setPositiveButton(saveAfter ? "Save" : "Apply", (d, which) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) name = "Preset";
                    state.presetName = name;
                    if (saveAfter) {
                        state.savePreset(name);
                        toast("Saved: " + name);
                    } else {
                        state.savePreset(name);
                        toast("Preset name: " + name);
                    }
                    invalidate();
                }).create();
        dialog.setOnShowListener(d -> {
            input.requestFocus();
            InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT);
        });
        dialog.show();
    }

    private void updateSlider(SliderHit s, float x) {
        float t = norm(x, s.left, s.right);
        float value = s.logarithmic ? expLerp(s.min, s.max, t) : lerp(s.min, s.max, t);
        switch (s.type) {
            case SL_MASTER: state.setMasterDb(value); break;
            case SL_BASS: state.setBassDb(value); break;
            case SL_CUTOFF: state.setBassCutoffHz(value); break;
            case SL_CHANNEL: state.setChannelDb(s.index, value); break;
            case SL_FREQ: state.setEqFrequency(state.selectedChannel, state.selectedBand, value); break;
            case SL_Q: state.setEqQ(state.selectedChannel, state.selectedBand, value); break;
            case SL_GAIN: state.setEqGain(state.selectedChannel, state.selectedBand, value); break;
        }
        invalidate();
    }

    private void updateGraph(GraphHit graph, float x, float y) {
        RectF r = graph.rect;
        int ch = state.selectedChannel;
        int nearest = 0;
        float best = Float.MAX_VALUE;
        for (int b = 0; b < UiState.BANDS; b++) {
            float bx = freqToX(state.eqFrequencyHz[ch][b], r);
            float d = Math.abs(bx - x);
            if (d < best) { best = d; nearest = b; }
        }
        state.setSelectedBand(nearest);
        float gain = 12f - norm(y, r.top, r.bottom) * 24f;
        state.setEqGain(ch, nearest, gain);
        invalidate();
    }

    private void clampScroll() {
        float visible = navTop - safeTop;
        float max = Math.max(0f, contentHeight - visible + dp(12));
        if (scroll[state.screen] < 0) scroll[state.screen] = 0;
        if (scroll[state.screen] > max) scroll[state.screen] = max;
    }

    private float freqToX(float hz, RectF r) {
        return lerp(r.left, r.right, logNorm(hz, 20f, 20000f));
    }

    private float gainToY(float gain, RectF r) {
        return lerp(r.bottom, r.top, norm(gain, -12f, 12f));
    }

    private static float norm(float value, float min, float max) {
        if (max <= min) return 0f;
        return Math.max(0f, Math.min(1f, (value - min) / (max - min)));
    }

    private static float logNorm(float value, float min, float max) {
        value = Math.max(min, Math.min(max, value));
        return (float) ((Math.log(value) - Math.log(min)) / (Math.log(max) - Math.log(min)));
    }

    private static float expLerp(float min, float max, float t) {
        return (float) Math.exp(Math.log(min) + (Math.log(max) - Math.log(min)) * Math.max(0f, Math.min(1f, t)));
    }

    private static float lerp(float a, float b, float t) {
        return a + (b - a) * Math.max(0f, Math.min(1f, t));
    }

    private String formatDb(float v) {
        if (Math.abs(v) < .05f) return "0 dB";
        return String.format(Locale.US, "%+.1f dB", v);
    }

    private float dp(float v) { return v * density; }
    private float sp(float v) { return v * getResources().getDisplayMetrics().scaledDensity; }

    private int withAlpha(int color, int alpha) {
        return Color.argb(Math.max(0, Math.min(255, alpha)), Color.red(color), Color.green(color), Color.blue(color));
    }

    private void toast(String text) {
        Toast.makeText(getContext(), text, Toast.LENGTH_SHORT).show();
    }

    private static class Hit {
        final int type;
        final int index;
        final RectF rect;
        Hit(int type, int index, RectF rect) { this.type = type; this.index = index; this.rect = rect; }
    }

    private static final class SliderHit extends Hit {
        final float left, right, min, max;
        final boolean logarithmic;
        SliderHit(int type, int index, RectF rect, float left, float right, float min, float max, boolean logarithmic) {
            super(type, index, rect);
            this.left = left; this.right = right; this.min = min; this.max = max; this.logarithmic = logarithmic;
        }
    }

    private static final class GraphHit extends Hit {
        GraphHit(RectF rect) { super(999, -1, new RectF(rect)); }
    }

    private static final class Palette {
        final boolean dark;
        final int bg, card, valueBox, nav, text, muted, border, track, grid, thumbOuter;
        Palette(boolean dark, int bg, int card, int valueBox, int nav, int text, int muted, int border, int track, int grid, int thumbOuter) {
            this.dark = dark; this.bg = bg; this.card = card; this.valueBox = valueBox; this.nav = nav; this.text = text; this.muted = muted;
            this.border = border; this.track = track; this.grid = grid; this.thumbOuter = thumbOuter;
        }
        static Palette light() {
            return new Palette(false,
                    Color.rgb(246, 248, 252), Color.WHITE, Color.rgb(247, 249, 252), Color.argb(250, 255,255,255),
                    Color.rgb(15, 24, 42), Color.rgb(104, 118, 143), Color.rgb(228, 233, 241),
                    Color.rgb(217, 224, 234), Color.rgb(232, 236, 243), Color.WHITE);
        }
        static Palette dark() {
            return new Palette(true,
                    Color.rgb(10, 13, 20), Color.rgb(23, 28, 38), Color.rgb(35, 42, 55), Color.rgb(17, 21, 29),
                    Color.rgb(247, 249, 253), Color.rgb(159, 170, 191), Color.rgb(52, 61, 77),
                    Color.rgb(69, 80, 99), Color.rgb(47, 55, 69), Color.rgb(245, 247, 251));
        }
    }
}
