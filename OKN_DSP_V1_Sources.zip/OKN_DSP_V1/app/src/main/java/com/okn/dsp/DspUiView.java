package com.okn.dsp;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Build;
import android.text.InputType;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * OKN DSP Version 1 - Phase 1 UI.
 *
 * Everything visible is drawn from code (Canvas primitives, text, paths and controls).
 * The uploaded UI screenshots are references only and are never used as a screen background.
 */
public final class DspUiView extends View {
    private static final int HOME = 0;
    private static final int MIX = 1;
    private static final int EQ = 2;

    private static final int BLUE = Color.rgb(8, 139, 255);
    private static final int BLUE2 = Color.rgb(43, 113, 255);
    private static final int TEXT = Color.rgb(11, 15, 25);
    private static final int MUTED = Color.rgb(112, 126, 150);
    private static final int TRACK = Color.rgb(219, 227, 239);
    private static final int GREEN = Color.rgb(28, 205, 80);
    private static final int CYAN = Color.rgb(28, 202, 218);
    private static final int ORANGE = Color.rgb(255, 153, 36);
    private static final int PINK = Color.rgb(243, 76, 119);
    private static final int PURPLE = Color.rgb(125, 91, 246);

    private static final float DESIGN_W = 390f;
    private static final float NAV_H = 72f;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final List<Hit> hits = new ArrayList<>();
    private final SharedPreferences prefs;

    private float scale = 1f;
    private float originX = 0f;
    private float topInsetPx = 0f;
    private float bottomInsetPx = 0f;
    private float navTopD = 760f;
    private float topInsetD = 0f;
    private float bottomInsetD = 0f;

    private int screen = HOME;
    private final float[] scroll = new float[]{0f, 0f, 0f};
    private float contentBottom = 820f;

    private float masterDb = -6f;
    private float bassDb = 2f;
    private float bassCutoff = 80f;
    private final float[] channelDb = new float[]{-3f, -6f, -2f, -8f, 0f, -4f, -10f};

    private int selectedChannel = 0;
    private int selectedBand = 0;
    private final float[][] eqGain = new float[7][15];
    private final float[][] eqFreq = new float[7][15];
    private final float[][] eqQ = new float[7][15];
    private final float[] channelEqVolume = new float[7];
    private String presetName = "";
    private String selectedLoadPreset = "Flat";

    private Hit activeHit;
    private float downX;
    private float downY;
    private float lastY;
    private boolean scrolling;

    private float graphPlotTop;
    private float graphPlotBottom;

    public DspUiView(Context context) {
        super(context);
        setFocusable(true);
        setClickable(true);
        setLayerType(LAYER_TYPE_SOFTWARE, null);
        prefs = context.getSharedPreferences("okn_dsp_v1_presets", Context.MODE_PRIVATE);
        initEq();
        if (Build.VERSION.SDK_INT >= 26) {
            setDefaultFocusHighlightEnabled(false);
        }
    }

    private void initEq() {
        float[] frequencies = new float[]{
                100f, 20f, 31.5f, 50f, 80f,
                200f, 315f, 500f, 800f, 1000f,
                2000f, 3150f, 5000f, 10000f, 20000f
        };
        float[] gains = new float[]{
                4f, -2f, -1f, 1.5f, 2.8f,
                2f, 0.2f, -1.2f, -1.8f, -0.1f,
                2.2f, 3.0f, 2.6f, 1.0f, -1.4f
        };
        for (int c = 0; c < 7; c++) {
            for (int b = 0; b < 15; b++) {
                eqFreq[c][b] = frequencies[b];
                eqQ[c][b] = 1.0f;
                eqGain[c][b] = gains[b] * (1f - c * 0.035f);
            }
            channelEqVolume[c] = 0f;
        }
    }

    public void setSystemInsets(int top, int bottom) {
        topInsetPx = top;
        bottomInsetPx = bottom;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        hits.clear();
        drawWindowBackground(canvas);

        float maxContentPx = Math.min(getWidth(), dp(700f));
        scale = maxContentPx / DESIGN_W;
        if (scale <= 0f) scale = 1f;
        originX = (getWidth() - maxContentPx) / 2f;
        topInsetD = topInsetPx / scale;
        bottomInsetD = bottomInsetPx / scale;
        float viewHD = getHeight() / scale;
        navTopD = viewHD - bottomInsetD - NAV_H - 8f;

        canvas.save();
        canvas.translate(originX, 0f);
        canvas.scale(scale, scale);

        // Scrollable page content.
        canvas.save();
        canvas.clipRect(0f, topInsetD, DESIGN_W, navTopD - 6f);
        canvas.translate(0f, -scroll[screen]);
        if (screen == HOME) {
            drawHome(canvas);
        } else if (screen == MIX) {
            drawMix(canvas);
        } else {
            drawEq(canvas);
        }
        canvas.restore();

        drawBottomNav(canvas);
        canvas.restore();

        clampScroll();
    }

    private void drawWindowBackground(Canvas c) {
        p.setShader(new LinearGradient(0, 0, getWidth(), getHeight(),
                new int[]{Color.rgb(250, 252, 255), Color.rgb(241, 246, 252), Color.rgb(249, 251, 254)},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, getWidth(), getHeight(), p);
        p.setShader(null);
    }

    private void drawHome(Canvas c) {
        float y0 = topInsetD + 22f;
        drawHeader(c, "OKN DSP", "DSP Controller", y0);

        float sy = y0 + 77f;
        RectF status = new RectF(16, sy, 374, sy + 94);
        drawSoftCard(c, status, Color.argb(170, 241, 255, 246), 22f);
        drawCircleGradient(c, 63, sy + 47, 27, Color.rgb(45, 216, 91), Color.rgb(42, 201, 80));
        drawCheck(c, 63, sy + 47, Color.WHITE);
        text(c, "SYSTEM STATUS", 108, sy + 31, 10.5f, MUTED, false);
        text(c, "System Ready", 108, sy + 55, 18f, Color.BLACK, true);
        text(c, "All devices connected and running normally.", 108, sy + 75, 11.5f, MUTED, false);
        drawChevron(c, 350, sy + 47, MUTED);
        addClick("home_status", status, false);

        float sectionY = sy + 130f;
        text(c, "Connection & Status", 18, sectionY, 17f, Color.BLACK, true);
        text(c, "All Good", 307, sectionY, 12.5f, BLUE, true);
        circle(c, 363, sectionY - 4, 5, GREEN);

        float rowY = sectionY + 16f;
        drawStatusRow(c, rowY, "Bluetooth", "Phone connected", "Connected", BLUE, GREEN, Icon.BLUETOOTH, "row_bluetooth");
        rowY += 60f;
        drawStatusRow(c, rowY, "DSP Device", "OKN DSP-8 Pro", "Connected", PURPLE, GREEN, Icon.CHIP, "row_dsp");
        rowY += 60f;
        drawStatusRow(c, rowY, "Audio Input", "AUX (Analog)", "Active", ORANGE, BLUE, Icon.AUDIO, "row_input");
        rowY += 60f;
        drawStatusRow(c, rowY, "Amplifier Link", "External Amplifier", "Connected", PINK, GREEN, Icon.SPEAKER, "row_amp");
        rowY += 60f;
        drawStatusRow(c, rowY, "Preset Sync", "User presets", "Synced", CYAN, GREEN, Icon.DOC, "row_preset");
        rowY += 60f;
        drawStatusRow(c, rowY, "Firmware Status", "v1.0.0 (Phase 1)", "Up to date", PURPLE, BLUE, Icon.GEAR, "row_firmware");

        rowY += 70f;
        RectF quick = new RectF(16, rowY, 374, rowY + 58f);
        drawSoftCard(c, quick, Color.argb(225, 255, 255, 255), 18f);
        drawIconBubble(c, 45, rowY + 29, BLUE, Icon.EQ);
        text(c, "Quick Control", 76, rowY + 25, 14.5f, Color.BLACK, true);
        text(c, "Adjust volume, presets and more", 76, rowY + 43, 10.5f, MUTED, false);
        drawChevron(c, 349, rowY + 29, MUTED);
        addClick("quick_control", quick, false);

        contentBottom = rowY + 74f;
    }

    private void drawStatusRow(Canvas c, float y, String title, String subtitle, String status,
                               int iconColor, int statusColor, Icon icon, String action) {
        RectF r = new RectF(16, y, 374, y + 54f);
        drawSoftCard(c, r, Color.argb(235, 255, 255, 255), 17f);
        drawIconBubble(c, 45, y + 27, iconColor, icon);
        text(c, title, 76, y + 25, 13.5f, TEXT, true);
        text(c, subtitle, 76, y + 42, 10.5f, MUTED, false);
        circle(c, 264, y + 26, 5, statusColor);
        text(c, status, 278, y + 30, 11.5f, statusColor, true);
        drawChevron(c, 351, y + 27, MUTED);
        addClick(action, r, false);
    }

    private void drawMix(Canvas c) {
        float y0 = topInsetD + 22f;
        drawHeader(c, "Mix", "Channel and bass controls", y0);

        float y = y0 + 78f;
        RectF global = new RectF(16, y, 374, y + 205f);
        drawSoftCard(c, global, Color.argb(235, 255, 255, 255), 20f);
        text(c, "Global", 30, y + 27, 16.5f, Color.BLACK, true);
        text(c, "Overall output and bass settings", 219, y + 25, 10f, MUTED, false);

        drawMixSliderRow(c, y + 42f, "Master Volume", Icon.SPEAKER, BLUE, masterDb,
                -18f, 6f, formatDb(masterDb), "master", -1);
        divider(c, 30, 360, y + 98f);
        drawMixSliderRow(c, y + 103f, "Bass Volume", Icon.AUDIO, ORANGE, bassDb,
                -12f, 12f, formatDb(bassDb), "bass", -1);
        divider(c, 30, 360, y + 159f);
        drawMixSliderRow(c, y + 164f, "Bass Cutoff", Icon.FILTER, PURPLE, bassCutoff,
                20f, 200f, Math.round(bassCutoff) + " Hz", "cutoff", -1);

        float cy = y + 218f;
        RectF channels = new RectF(16, cy, 374, cy + 414f);
        drawSoftCard(c, channels, Color.argb(235, 255, 255, 255), 20f);
        text(c, "Channels", 30, cy + 28, 16.5f, Color.BLACK, true);
        text(c, "Individual channel levels", 254, cy + 26, 10f, MUTED, false);

        float ry = cy + 42f;
        int[] colors = new int[]{BLUE, GREEN, ORANGE, PINK, PURPLE, CYAN, PURPLE};
        for (int i = 0; i < 7; i++) {
            drawChannelRow(c, ry, i, colors[i]);
            if (i < 6) divider(c, 73, 360, ry + 50f);
            ry += 53f;
        }

        contentBottom = cy + 428f;
    }

    private void drawMixSliderRow(Canvas c, float y, String label, Icon icon, int iconColor,
                                  float value, float min, float max, String valueText,
                                  String action, int index) {
        drawIconBubble(c, 44, y + 27, iconColor, icon);
        text(c, label, 75, y + 24, 12f, TEXT, true);
        float x1 = 76, x2 = 285, ty = y + 38;
        slider(c, x1, x2, ty, norm(value, min, max), BLUE);
        RectF valueBox = new RectF(300, y + 8, 362, y + 48);
        roundRect(c, valueBox, 9f, Color.rgb(247, 249, 252));
        textCentered(c, valueText, valueBox.centerX(), y + 33, 12f, TEXT, false);
        addSlider(action, new RectF(x1, y + 24, x2, y + 51), false, min, max, index, false);
    }

    private void drawChannelRow(Canvas c, float y, int index, int color) {
        drawCircleGradient(c, 44, y + 28, 16, mix(color, Color.WHITE, 0.30f), color);
        textCentered(c, String.valueOf(index + 1), 44, y + 34, 13f, Color.WHITE, true);
        text(c, "Volume Ch" + (index + 1), 76, y + 24, 11.5f, TEXT, true);
        float x1 = 76, x2 = 285, ty = y + 38;
        slider(c, x1, x2, ty, norm(channelDb[index], -12f, 6f), BLUE);
        RectF valueBox = new RectF(300, y + 8, 362, y + 48);
        roundRect(c, valueBox, 9f, Color.rgb(247, 249, 252));
        textCentered(c, formatDb(channelDb[index]), valueBox.centerX(), y + 33, 11.5f, TEXT, false);
        addSlider("channel", new RectF(x1, y + 24, x2, y + 51), false,
                -12f, 6f, index, false);
    }

    private void drawEq(Canvas c) {
        float y0 = topInsetD + 22f;
        drawHeader(c, "Eq", "15-band equalizer", y0);

        float tabsY = y0 + 70f;
        float tabW = 46f;
        for (int i = 0; i < 7; i++) {
            float x = 18 + i * 51f;
            RectF r = new RectF(x, tabsY, x + tabW, tabsY + 28f);
            if (i == selectedChannel) {
                p.setShader(new LinearGradient(r.left, r.top, r.right, r.bottom, BLUE, BLUE2, Shader.TileMode.CLAMP));
                c.drawRoundRect(r, 14f, 14f, p);
                p.setShader(null);
                textCentered(c, "Ch" + (i + 1), r.centerX(), tabsY + 19, 10.5f, Color.WHITE, false);
            } else {
                roundRectStroke(c, r, 14f, Color.argb(120, 220, 226, 236), 0.8f, Color.argb(150, 248, 250, 253));
                textCentered(c, "Ch" + (i + 1), r.centerX(), tabsY + 19, 10.5f, MUTED, false);
            }
            addClick("eq_channel_" + i, r, false);
        }

        float gy = tabsY + 40f;
        RectF graphCard = new RectF(16, gy, 374, gy + 224f);
        drawSoftCard(c, graphCard, Color.argb(238, 255, 255, 255), 20f);
        text(c, "Channel " + (selectedChannel + 1), 28, gy + 26, 15.5f, Color.BLACK, true);
        text(c, channelPositionName(selectedChannel) + "  •  15-band EQ", 28, gy + 43, 10f, MUTED, false);

        RectF reset = new RectF(282, gy + 11, 360, gy + 43);
        roundRect(c, reset, 16f, Color.rgb(247, 249, 252));
        drawResetIcon(c, 298, gy + 27, MUTED);
        text(c, "Reset EQ", 311, gy + 31, 9.5f, MUTED, false);
        addClick("reset_eq", reset, false);

        drawEqGraph(c, gy + 54f, gy + 204f);

        float py = gy + 236f;
        RectF paramCard = new RectF(16, py, 374, py + 209f);
        drawSoftCard(c, paramCard, Color.argb(238, 255, 255, 255), 20f);
        drawCircleGradient(c, 44, py + 28, 17, Color.rgb(229, 242, 255), Color.rgb(211, 233, 255));
        textCentered(c, String.valueOf(selectedBand + 1), 44, py + 34, 13.5f, BLUE, true);
        text(c, "Band " + (selectedBand + 1), 75, py + 27, 14f, TEXT, true);
        text(c, "Adjust the selected band parameters", 75, py + 43, 9.5f, MUTED, false);

        RectF left = new RectF(292, py + 11, 323, py + 43);
        RectF right = new RectF(329, py + 11, 360, py + 43);
        roundRect(c, left, 16f, Color.rgb(248, 250, 253));
        roundRect(c, right, 16f, Color.rgb(248, 250, 253));
        drawArrow(c, left.centerX(), left.centerY(), false, TEXT);
        drawArrow(c, right.centerX(), right.centerY(), true, TEXT);
        addClick("band_prev", left, false);
        addClick("band_next", right, false);

        float row = py + 58f;
        drawEqParamRow(c, row, "Frequency", Icon.FREQ,
                eqFreq[selectedChannel][selectedBand], 20f, 20000f,
                formatFreq(eqFreq[selectedChannel][selectedBand]), "eq_freq", true,
                "20 Hz", "20 kHz");
        row += 49f;
        drawEqParamRow(c, row, "Q (Quality Factor)", Icon.Q,
                eqQ[selectedChannel][selectedBand], 0.1f, 10f,
                String.format(Locale.US, "%.1f", eqQ[selectedChannel][selectedBand]), "eq_q", true,
                "0.1", "10.0");
        row += 49f;
        // The reference labels this control as Ch Volume. In Phase 1 it also drives the selected
        // graph band's vertical gain so the graph responds immediately while dragging.
        drawEqParamRow(c, row, "Ch Volume", Icon.SPEAKER,
                eqGain[selectedChannel][selectedBand], -12f, 12f,
                String.format(Locale.US, "%.1f dB", eqGain[selectedChannel][selectedBand]), "eq_gain", false,
                "-12 dB", "+12 dB");

        float pry = py + 221f;
        RectF presetCard = new RectF(16, pry, 374, pry + 190f);
        drawSoftCard(c, presetCard, Color.argb(238, 255, 255, 255), 20f);
        drawIconBubble(c, 44, pry + 27, CYAN, Icon.DOC);
        text(c, "Presets", 74, pry + 25, 13.5f, TEXT, true);
        text(c, "Save and load EQ presets", 74, pry + 42, 9.5f, MUTED, false);
        drawMore(c, 351, pry + 28, MUTED);
        addClick("preset_more", new RectF(335, pry + 12, 368, pry + 46), false);

        RectF nameBox = new RectF(28, pry + 60, 248, pry + 93);
        roundRectStroke(c, nameBox, 8f, Color.rgb(220, 227, 237), 0.8f, Color.WHITE);
        text(c, presetName.isEmpty() ? "Preset name" : presetName, 37, pry + 81, 10f,
                presetName.isEmpty() ? Color.rgb(148, 160, 178) : TEXT, false);
        addClick("preset_name", nameBox, false);

        RectF save = new RectF(258, pry + 60, 362, pry + 93);
        p.setShader(new LinearGradient(save.left, save.top, save.right, save.bottom, BLUE, Color.rgb(0, 104, 247), Shader.TileMode.CLAMP));
        c.drawRoundRect(save, 9f, 9f, p);
        p.setShader(null);
        drawSaveIcon(c, 278, pry + 76, Color.WHITE);
        text(c, "Save Preset", 291, pry + 80, 9.5f, Color.WHITE, false);
        addClick("preset_save", save, false);

        text(c, "Load Preset", 28, pry + 112, 9.5f, MUTED, false);
        RectF chooser = new RectF(28, pry + 121, 263, pry + 158);
        roundRectStroke(c, chooser, 8f, Color.rgb(220, 227, 237), 0.8f, Color.WHITE);
        text(c, selectedLoadPreset, 38, pry + 145, 10.5f, TEXT, false);
        drawDownChevron(c, 246, pry + 140, MUTED);
        addClick("preset_choose", chooser, false);

        RectF load = new RectF(271, pry + 121, 362, pry + 158);
        roundRect(c, load, 9f, Color.rgb(242, 247, 253));
        drawFolderIcon(c, 291, pry + 140, MUTED);
        text(c, "Load", 306, pry + 144, 10f, MUTED, false);
        addClick("preset_load", load, false);

        contentBottom = pry + 205f;
    }

    private void drawEqGraph(Canvas c, float top, float bottom) {
        float left = 46f;
        float right = 356f;
        float plotTop = top + 10f;
        float plotBottom = bottom - 23f;
        graphPlotTop = plotTop;
        graphPlotBottom = plotBottom;

        // Plot background.
        RectF plot = new RectF(left, plotTop, right, plotBottom);
        roundRect(c, plot, 5f, Color.argb(95, 250, 252, 255));

        int[] yVals = new int[]{12, 6, 0, -6, -12};
        for (int val : yVals) {
            float yy = gainToY(val, plotTop, plotBottom);
            line(c, left, yy, right, yy, Color.rgb(229, 234, 242), 0.55f);
            textRight(c, (val > 0 ? "+" : "") + val, left - 8, yy + 3, 8f, MUTED, false);
        }

        float[] labels = new float[]{20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000};
        for (float f : labels) {
            float xx = freqToX(f, left, right);
            line(c, xx, plotTop, xx, plotBottom, Color.rgb(234, 238, 245), 0.45f);
            String label = f >= 1000 ? (f == 1000 ? "1K" : (int) (f / 1000) + "K") : String.valueOf((int) f);
            textCentered(c, label, xx, plotBottom + 15, 7.5f, MUTED, false);
        }
        text(c, "(dB)", 20, plotBottom + 17, 7.5f, MUTED, false);
        textRight(c, "(Hz)", 358, plotBottom + 27, 7.5f, MUTED, false);

        int[] order = sortedBandIndices();
        float[] xs = new float[15];
        float[] ys = new float[15];
        for (int i = 0; i < 15; i++) {
            int b = order[i];
            xs[i] = freqToX(eqFreq[selectedChannel][b], left, right);
            ys[i] = gainToY(eqGain[selectedChannel][b], plotTop, plotBottom);
        }

        // Fill under the response line.
        path.reset();
        path.moveTo(xs[0], plotBottom);
        path.lineTo(xs[0], ys[0]);
        for (int i = 1; i < 15; i++) path.lineTo(xs[i], ys[i]);
        path.lineTo(xs[14], plotBottom);
        path.close();
        p.setShader(new LinearGradient(0, plotTop, 0, plotBottom,
                Color.argb(55, 30, 149, 255), Color.argb(6, 30, 149, 255), Shader.TileMode.CLAMP));
        c.drawPath(path, p);
        p.setShader(null);

        // Response line.
        path.reset();
        path.moveTo(xs[0], ys[0]);
        for (int i = 1; i < 15; i++) path.lineTo(xs[i], ys[i]);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.35f);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setColor(BLUE);
        c.drawPath(path, p);
        p.setStyle(Paint.Style.FILL);

        for (int b = 0; b < 15; b++) {
            float xx = freqToX(eqFreq[selectedChannel][b], left, right);
            float yy = gainToY(eqGain[selectedChannel][b], plotTop, plotBottom);
            if (b == selectedBand) {
                circle(c, xx, yy, 8.5f, Color.argb(45, 8, 139, 255));
                circle(c, xx, yy, 6.2f, Color.WHITE);
                circle(c, xx, yy, 4.7f, BLUE);
            } else {
                circle(c, xx, yy, 4.6f, Color.WHITE);
                circle(c, xx, yy, 3.8f, BLUE);
            }
            addGraph("graph_band", new RectF(xx - 9, yy - 10, xx + 9, yy + 10), b);
        }
    }

    private int[] sortedBandIndices() {
        int[] order = new int[15];
        for (int i = 0; i < 15; i++) order[i] = i;
        for (int i = 0; i < 14; i++) {
            int best = i;
            for (int j = i + 1; j < 15; j++) {
                if (eqFreq[selectedChannel][order[j]] < eqFreq[selectedChannel][order[best]]) best = j;
            }
            int tmp = order[i];
            order[i] = order[best];
            order[best] = tmp;
        }
        return order;
    }

    private void drawEqParamRow(Canvas c, float y, String title, Icon icon,
                                float value, float min, float max, String valueText,
                                String action, boolean logarithmic,
                                String leftLabel, String rightLabel) {
        drawSmallIcon(c, 42, y + 18, icon);
        text(c, title, 61, y + 17, 10.5f, TEXT, true);
        RectF valueBox = new RectF(294, y + 3, 360, y + 24);
        roundRect(c, valueBox, 10.5f, Color.rgb(247, 249, 252));
        textCentered(c, valueText, valueBox.centerX(), y + 17, 9.5f, TEXT, false);

        float x1 = 61, x2 = 357, ty = y + 30;
        float ratio = logarithmic ? logNorm(value, min, max) : norm(value, min, max);
        slider(c, x1, x2, ty, ratio, BLUE);
        text(c, leftLabel, x1, y + 45, 7.5f, MUTED, false);
        textRight(c, rightLabel, x2, y + 45, 7.5f, MUTED, false);
        addSlider(action, new RectF(x1, y + 21, x2, y + 38), false, min, max, selectedBand, logarithmic);
    }

    private void drawHeader(Canvas c, String title, String subtitle, float y) {
        text(c, title, 20, y + 22, title.equals("OKN DSP") ? 25f : 26f, TEXT, true);
        text(c, subtitle, 20, y + 42, 12f, MUTED, false);

        RectF search = new RectF(292, y + 3, 326, y + 37);
        RectF more = new RectF(336, y + 3, 370, y + 37);
        roundRect(c, search, 17f, Color.argb(165, 242, 246, 251));
        roundRect(c, more, 17f, Color.argb(165, 242, 246, 251));
        drawSearch(c, search.centerX(), search.centerY(), TEXT);
        drawMore(c, more.centerX(), more.centerY(), TEXT);
        addClick("search", search, false);
        addClick("more", more, false);
    }

    private void drawBottomNav(Canvas c) {
        RectF nav = new RectF(16, navTopD, 374, navTopD + NAV_H);
        drawSoftCard(c, nav, Color.argb(242, 255, 255, 255), 20f);

        float itemW = 358f / 3f;
        for (int i = 0; i < 3; i++) {
            float left = 16 + i * itemW;
            RectF item = new RectF(left + 5, navTopD + 6, left + itemW - 5, navTopD + 64);
            boolean sel = screen == i;
            if (sel) {
                roundRect(c, new RectF(item.left + 2, item.top, item.right - 2, item.top + 31), 15f,
                        Color.rgb(232, 243, 255));
            }
            float cx = (item.left + item.right) / 2f;
            int color = sel ? BLUE : Color.rgb(101, 118, 143);
            if (i == 0) drawHomeIcon(c, cx, navTopD + 22, color);
            if (i == 1) drawMixIcon(c, cx, navTopD + 22, color);
            if (i == 2) drawEqIcon(c, cx, navTopD + 22, color);
            textCentered(c, i == 0 ? "Home" : i == 1 ? "Mix" : "Eq", cx, navTopD + 55, 11f, color, sel);
            addClick("nav_" + i, item, true);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (scale <= 0f) return true;
        float x = (e.getX() - originX) / scale;
        float y = e.getY() / scale;
        if (x < -20 || x > DESIGN_W + 20) return true;

        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = x;
                downY = y;
                lastY = y;
                scrolling = false;
                activeHit = findHit(x, y);
                if (activeHit != null && (activeHit.slider || activeHit.graph)) {
                    updateActiveControl(x, y);
                }
                return true;

            case MotionEvent.ACTION_MOVE:
                float dy = y - lastY;
                if (activeHit != null && (activeHit.slider || activeHit.graph)) {
                    updateActiveControl(x, y);
                } else {
                    if (!scrolling && Math.hypot(x - downX, y - downY) > 5f) scrolling = true;
                    if (scrolling && y < navTopD + 4f) {
                        scroll[screen] -= dy;
                        clampScroll();
                        invalidate();
                    }
                }
                lastY = y;
                return true;

            case MotionEvent.ACTION_UP:
                if (!scrolling && activeHit != null && !activeHit.slider && !activeHit.graph) {
                    performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
                    handleClick(activeHit.action);
                }
                activeHit = null;
                scrolling = false;
                return true;

            case MotionEvent.ACTION_CANCEL:
                activeHit = null;
                scrolling = false;
                return true;
        }
        return true;
    }

    private void updateActiveControl(float x, float yScreen) {
        if (activeHit == null) return;
        if (activeHit.graph) {
            selectedBand = activeHit.index;
            float yContent = yScreen + scroll[screen];
            float gain = 12f - ((yContent - graphPlotTop) / (graphPlotBottom - graphPlotTop)) * 24f;
            eqGain[selectedChannel][selectedBand] = clamp(gain, -12f, 12f);
            invalidate();
            return;
        }

        float ratio = clamp((x - activeHit.r.left) / Math.max(1f, activeHit.r.width()), 0f, 1f);
        float value;
        if (activeHit.logarithmic) {
            double lmin = Math.log(activeHit.min);
            double lmax = Math.log(activeHit.max);
            value = (float) Math.exp(lmin + (lmax - lmin) * ratio);
        } else {
            value = activeHit.min + (activeHit.max - activeHit.min) * ratio;
        }

        switch (activeHit.action) {
            case "master":
                masterDb = roundStep(value, 1f);
                break;
            case "bass":
                bassDb = roundStep(value, 1f);
                break;
            case "cutoff":
                bassCutoff = roundStep(value, 1f);
                break;
            case "channel":
                channelDb[activeHit.index] = roundStep(value, 1f);
                break;
            case "eq_freq":
                eqFreq[selectedChannel][selectedBand] = clamp(roundFrequency(value), 20f, 20000f);
                break;
            case "eq_q":
                eqQ[selectedChannel][selectedBand] = clamp(roundStep(value, 0.1f), 0.1f, 10f);
                break;
            case "eq_gain":
                eqGain[selectedChannel][selectedBand] = clamp(roundStep(value, 0.1f), -12f, 12f);
                channelEqVolume[selectedChannel] = eqGain[selectedChannel][selectedBand];
                break;
        }
        invalidate();
    }

    private void handleClick(String action) {
        if (action.startsWith("nav_")) {
            screen = Integer.parseInt(action.substring(4));
            invalidate();
            return;
        }
        if (action.startsWith("eq_channel_")) {
            selectedChannel = Integer.parseInt(action.substring("eq_channel_".length()));
            selectedBand = 0;
            invalidate();
            return;
        }

        switch (action) {
            case "search":
                showSearchDialog();
                break;
            case "more":
                showMoreDialog();
                break;
            case "home_status":
                showInfo("System Ready", "Phase 1 UI is running normally. DSP transport will be connected in Phase 2.");
                break;
            case "row_bluetooth":
                showInfo("Bluetooth", "Interactive UI is ready. BLE scan/connect and protocol traffic are reserved for Phase 2.");
                break;
            case "row_dsp":
                showInfo("DSP Device", "UI target: OKN DSP-8 Pro. Real device identification will use the DSP data you upload for Phase 2.");
                break;
            case "row_input":
                showInfo("Audio Input", "Current Phase 1 display source: AUX (Analog).");
                break;
            case "row_amp":
                showInfo("Amplifier Link", "Amplifier link screen is interactive; hardware commands will be added in Phase 2.");
                break;
            case "row_preset":
                screen = EQ;
                invalidate();
                break;
            case "row_firmware":
                showInfo("Firmware Status", "App UI Version 1.0.0 • Phase 1");
                break;
            case "quick_control":
                screen = MIX;
                invalidate();
                break;
            case "reset_eq":
                Arrays.fill(eqGain[selectedChannel], 0f);
                Arrays.fill(eqQ[selectedChannel], 1f);
                invalidate();
                break;
            case "band_prev":
                selectedBand = (selectedBand + 14) % 15;
                invalidate();
                break;
            case "band_next":
                selectedBand = (selectedBand + 1) % 15;
                invalidate();
                break;
            case "preset_name":
                editPresetName();
                break;
            case "preset_save":
                if (presetName.trim().isEmpty()) editPresetNameAndSave();
                else savePreset(presetName.trim());
                break;
            case "preset_choose":
                choosePreset(false);
                break;
            case "preset_load":
                loadPreset(selectedLoadPreset);
                break;
            case "preset_more":
                showPresetMenu();
                break;
        }
    }

    private void showSearchDialog() {
        String[] items = new String[]{"Home", "Mix", "Eq"};
        new AlertDialog.Builder(getContext())
                .setTitle("Go to")
                .setItems(items, (d, which) -> {
                    screen = which;
                    scroll[screen] = 0f;
                    invalidate();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showMoreDialog() {
        String[] items = new String[]{"About Version 1", "Reset Phase 1 UI values"};
        new AlertDialog.Builder(getContext())
                .setTitle("OKN DSP")
                .setItems(items, (d, which) -> {
                    if (which == 0) {
                        showInfo("OKN DSP Version 1", "Phase 1: responsive UI only.\nPhase 2: real DSP control.\nPhase 3: release list.");
                    } else {
                        masterDb = -6f;
                        bassDb = 2f;
                        bassCutoff = 80f;
                        float[] defaults = {-3f, -6f, -2f, -8f, 0f, -4f, -10f};
                        System.arraycopy(defaults, 0, channelDb, 0, 7);
                        initEq();
                        selectedChannel = 0;
                        selectedBand = 0;
                        presetName = "";
                        selectedLoadPreset = "Flat";
                        invalidate();
                        toast("UI values reset");
                    }
                })
                .show();
    }

    private void editPresetName() {
        EditText input = new EditText(getContext());
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setText(presetName);
        input.setSelection(input.length());
        new AlertDialog.Builder(getContext())
                .setTitle("Preset name")
                .setView(input)
                .setPositiveButton("OK", (d, w) -> {
                    presetName = input.getText().toString().trim();
                    invalidate();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void editPresetNameAndSave() {
        EditText input = new EditText(getContext());
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        new AlertDialog.Builder(getContext())
                .setTitle("Preset name")
                .setView(input)
                .setPositiveButton("Save", (d, w) -> {
                    presetName = input.getText().toString().trim();
                    if (!presetName.isEmpty()) savePreset(presetName);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showPresetMenu() {
        String[] items = new String[]{"Choose preset", "Delete selected custom preset"};
        new AlertDialog.Builder(getContext())
                .setTitle("Presets")
                .setItems(items, (d, which) -> {
                    if (which == 0) choosePreset(false);
                    else deleteSelectedPreset();
                }).show();
    }

    private void choosePreset(boolean loadImmediately) {
        List<String> names = allPresetNames();
        String[] array = names.toArray(new String[0]);
        new AlertDialog.Builder(getContext())
                .setTitle("Load Preset")
                .setItems(array, (d, which) -> {
                    selectedLoadPreset = array[which];
                    if (loadImmediately) loadPreset(selectedLoadPreset);
                    invalidate();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private List<String> allPresetNames() {
        List<String> names = new ArrayList<>();
        names.add("Flat");
        names.add("Vocal");
        names.add("Bass Boost");
        Set<String> custom = prefs.getStringSet("preset_names", new LinkedHashSet<>());
        if (custom != null) names.addAll(custom);
        return names;
    }

    private void savePreset(String name) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 15; i++) {
            if (i > 0) sb.append(';');
            sb.append(eqFreq[selectedChannel][i]).append(',')
                    .append(eqQ[selectedChannel][i]).append(',')
                    .append(eqGain[selectedChannel][i]);
        }
        Set<String> names = new LinkedHashSet<>(prefs.getStringSet("preset_names", new LinkedHashSet<>()));
        names.add(name);
        prefs.edit().putString("preset_" + name, sb.toString()).putStringSet("preset_names", names).apply();
        selectedLoadPreset = name;
        toast("Preset saved: " + name);
        invalidate();
    }

    private void loadPreset(String name) {
        if ("Flat".equals(name)) {
            Arrays.fill(eqGain[selectedChannel], 0f);
            Arrays.fill(eqQ[selectedChannel], 1f);
            toast("Loaded Flat");
            invalidate();
            return;
        }
        if ("Vocal".equals(name)) {
            for (int i = 0; i < 15; i++) {
                float f = eqFreq[selectedChannel][i];
                eqGain[selectedChannel][i] = (f >= 500 && f <= 5000) ? 2.5f : (f < 100 ? -1.5f : 0f);
            }
            toast("Loaded Vocal");
            invalidate();
            return;
        }
        if ("Bass Boost".equals(name)) {
            for (int i = 0; i < 15; i++) {
                float f = eqFreq[selectedChannel][i];
                eqGain[selectedChannel][i] = f <= 200 ? 4f : (f <= 500 ? 2f : 0f);
            }
            toast("Loaded Bass Boost");
            invalidate();
            return;
        }

        String data = prefs.getString("preset_" + name, null);
        if (data == null) {
            toast("Preset not found");
            return;
        }
        String[] bands = data.split(";");
        if (bands.length != 15) {
            toast("Preset data is invalid");
            return;
        }
        try {
            for (int i = 0; i < 15; i++) {
                String[] parts = bands[i].split(",");
                eqFreq[selectedChannel][i] = Float.parseFloat(parts[0]);
                eqQ[selectedChannel][i] = Float.parseFloat(parts[1]);
                eqGain[selectedChannel][i] = Float.parseFloat(parts[2]);
            }
            toast("Loaded " + name);
            invalidate();
        } catch (Exception ex) {
            toast("Preset data is invalid");
        }
    }

    private void deleteSelectedPreset() {
        if ("Flat".equals(selectedLoadPreset) || "Vocal".equals(selectedLoadPreset) || "Bass Boost".equals(selectedLoadPreset)) {
            toast("Built-in presets cannot be deleted");
            return;
        }
        Set<String> names = new LinkedHashSet<>(prefs.getStringSet("preset_names", new LinkedHashSet<>()));
        if (names.remove(selectedLoadPreset)) {
            prefs.edit().remove("preset_" + selectedLoadPreset).putStringSet("preset_names", names).apply();
            toast("Preset deleted");
            selectedLoadPreset = "Flat";
            invalidate();
        } else {
            toast("Custom preset not found");
        }
    }

    private void showInfo(String title, String message) {
        new AlertDialog.Builder(getContext())
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }

    private void toast(String s) {
        Toast.makeText(getContext(), s, Toast.LENGTH_SHORT).show();
    }

    private Hit findHit(float x, float yScreen) {
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            float yy = h.fixed ? yScreen : yScreen + scroll[screen];
            if (h.r.contains(x, yy)) return h;
        }
        return null;
    }

    private void clampScroll() {
        float visible = Math.max(120f, navTopD - topInsetD - 2f);
        float max = Math.max(0f, contentBottom - topInsetD - visible + 12f);
        scroll[screen] = clamp(scroll[screen], 0f, max);
    }

    private void addClick(String action, RectF r, boolean fixed) {
        hits.add(new Hit(action, new RectF(r), fixed, false, false, 0f, 0f, -1, false));
    }

    private void addSlider(String action, RectF r, boolean fixed, float min, float max, int index, boolean logarithmic) {
        hits.add(new Hit(action, new RectF(r), fixed, true, false, min, max, index, logarithmic));
    }

    private void addGraph(String action, RectF r, int index) {
        hits.add(new Hit(action, new RectF(r), false, false, true, -12f, 12f, index, false));
    }

    private static final class Hit {
        final String action;
        final RectF r;
        final boolean fixed;
        final boolean slider;
        final boolean graph;
        final float min;
        final float max;
        final int index;
        final boolean logarithmic;

        Hit(String action, RectF r, boolean fixed, boolean slider, boolean graph,
            float min, float max, int index, boolean logarithmic) {
            this.action = action;
            this.r = r;
            this.fixed = fixed;
            this.slider = slider;
            this.graph = graph;
            this.min = min;
            this.max = max;
            this.index = index;
            this.logarithmic = logarithmic;
        }
    }

    private enum Icon {BLUETOOTH, CHIP, AUDIO, SPEAKER, DOC, GEAR, EQ, FILTER, FREQ, Q}

    // ---------- Drawing helpers ----------

    private void drawSoftCard(Canvas c, RectF r, int fill, float radius) {
        p.setShadowLayer(14f, 0f, 6f, Color.argb(22, 68, 91, 125));
        roundRect(c, r, radius, fill);
        p.clearShadowLayer();
    }

    private void roundRect(Canvas c, RectF r, float radius, int color) {
        p.setStyle(Paint.Style.FILL);
        p.setShader(null);
        p.setColor(color);
        c.drawRoundRect(r, radius, radius, p);
    }

    private void roundRectStroke(Canvas c, RectF r, float radius, int stroke, float strokeW, int fill) {
        roundRect(c, r, radius, fill);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(strokeW);
        p.setColor(stroke);
        c.drawRoundRect(r, radius, radius, p);
        p.setStyle(Paint.Style.FILL);
    }

    private void divider(Canvas c, float x1, float x2, float y) {
        line(c, x1, y, x2, y, Color.rgb(235, 239, 245), 0.7f);
    }

    private void line(Canvas c, float x1, float y1, float x2, float y2, int color, float width) {
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(width);
        p.setColor(color);
        c.drawLine(x1, y1, x2, y2, p);
        p.setStyle(Paint.Style.FILL);
    }

    private void circle(Canvas c, float x, float y, float radius, int color) {
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        c.drawCircle(x, y, radius, p);
    }

    private void drawCircleGradient(Canvas c, float x, float y, float radius, int c1, int c2) {
        p.setShader(new LinearGradient(x - radius, y - radius, x + radius, y + radius, c1, c2, Shader.TileMode.CLAMP));
        c.drawCircle(x, y, radius, p);
        p.setShader(null);
    }

    private void text(Canvas c, String s, float x, float baseline, float size, int color, boolean bold) {
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        p.setTextSize(size);
        p.setTypeface(android.graphics.Typeface.create("sans-serif", bold ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL));
        p.setTextAlign(Paint.Align.LEFT);
        c.drawText(s, x, baseline, p);
    }

    private void textCentered(Canvas c, String s, float x, float baseline, float size, int color, boolean bold) {
        p.setShader(null);
        p.setColor(color);
        p.setTextSize(size);
        p.setTypeface(android.graphics.Typeface.create("sans-serif", bold ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL));
        p.setTextAlign(Paint.Align.CENTER);
        c.drawText(s, x, baseline, p);
        p.setTextAlign(Paint.Align.LEFT);
    }

    private void textRight(Canvas c, String s, float x, float baseline, float size, int color, boolean bold) {
        p.setShader(null);
        p.setColor(color);
        p.setTextSize(size);
        p.setTypeface(android.graphics.Typeface.create("sans-serif", bold ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL));
        p.setTextAlign(Paint.Align.RIGHT);
        c.drawText(s, x, baseline, p);
        p.setTextAlign(Paint.Align.LEFT);
    }

    private void slider(Canvas c, float x1, float x2, float y, float ratio, int activeColor) {
        ratio = clamp(ratio, 0f, 1f);
        line(c, x1, y, x2, y, TRACK, 4f);
        float knob = x1 + (x2 - x1) * ratio;
        line(c, x1, y, knob, y, activeColor, 4f);
        p.setShadowLayer(3f, 0f, 1.5f, Color.argb(45, 0, 0, 0));
        circle(c, knob, y, 7.3f, Color.WHITE);
        p.clearShadowLayer();
        circle(c, knob, y, 5.2f, Color.rgb(248, 250, 253));
    }

    private void drawIconBubble(Canvas c, float x, float y, int color, Icon icon) {
        drawCircleGradient(c, x, y, 18f, mix(color, Color.WHITE, 0.15f), color);
        drawIcon(c, x, y, icon, Color.WHITE, 1f);
    }

    private void drawSmallIcon(Canvas c, float x, float y, Icon icon) {
        circle(c, x, y, 12.5f, Color.rgb(244, 248, 253));
        drawIcon(c, x, y, icon, Color.rgb(67, 91, 132), 0.75f);
    }

    private void drawIcon(Canvas c, float x, float y, Icon icon, int color, float k) {
        switch (icon) {
            case BLUETOOTH:
                drawBluetooth(c, x, y, color, k);
                break;
            case CHIP:
                drawChip(c, x, y, color, k);
                break;
            case AUDIO:
                drawAudio(c, x, y, color, k);
                break;
            case SPEAKER:
                drawSpeaker(c, x, y, color, k);
                break;
            case DOC:
                drawDoc(c, x, y, color, k);
                break;
            case GEAR:
                drawGear(c, x, y, color, k);
                break;
            case EQ:
                drawEqIcon(c, x, y, color);
                break;
            case FILTER:
                drawFilter(c, x, y, color, k);
                break;
            case FREQ:
                drawFreq(c, x, y, color, k);
                break;
            case Q:
                textCentered(c, "Q", x, y + 4f * k, 12f * k, color, true);
                break;
        }
    }

    private void drawSearch(Canvas c, float x, float y, int color) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.5f);
        p.setColor(color);
        c.drawCircle(x - 2, y - 2, 5.5f, p);
        c.drawLine(x + 2.2f, y + 2.2f, x + 7f, y + 7f, p);
        p.setStyle(Paint.Style.FILL);
    }

    private void drawMore(Canvas c, float x, float y, int color) {
        circle(c, x, y - 6, 1.4f, color);
        circle(c, x, y, 1.4f, color);
        circle(c, x, y + 6, 1.4f, color);
    }

    private void drawChevron(Canvas c, float x, float y, int color) {
        line(c, x - 3, y - 5, x + 1, y, color, 1.2f);
        line(c, x + 1, y, x - 3, y + 5, color, 1.2f);
    }

    private void drawDownChevron(Canvas c, float x, float y, int color) {
        line(c, x - 4, y - 2, x, y + 2, color, 1.1f);
        line(c, x, y + 2, x + 4, y - 2, color, 1.1f);
    }

    private void drawArrow(Canvas c, float x, float y, boolean right, int color) {
        float s = right ? 1f : -1f;
        line(c, x - 2.5f * s, y - 4, x + 1.5f * s, y, color, 1.2f);
        line(c, x + 1.5f * s, y, x - 2.5f * s, y + 4, color, 1.2f);
    }

    private void drawCheck(Canvas c, float x, float y, int color) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(3.0f);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setColor(color);
        path.reset();
        path.moveTo(x - 8, y);
        path.lineTo(x - 2, y + 6);
        path.lineTo(x + 10, y - 7);
        c.drawPath(path, p);
        p.setStyle(Paint.Style.FILL);
    }

    private void drawBluetooth(Canvas c, float x, float y, int color, float k) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.5f * k);
        p.setColor(color);
        path.reset();
        path.moveTo(x, y - 10 * k);
        path.lineTo(x + 6 * k, y - 4 * k);
        path.lineTo(x - 5 * k, y + 5 * k);
        path.moveTo(x, y + 10 * k);
        path.lineTo(x + 6 * k, y + 4 * k);
        path.lineTo(x - 5 * k, y - 5 * k);
        path.moveTo(x, y - 10 * k);
        path.lineTo(x, y + 10 * k);
        c.drawPath(path, p);
        p.setStyle(Paint.Style.FILL);
    }

    private void drawChip(Canvas c, float x, float y, int color, float k) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.4f * k);
        p.setColor(color);
        RectF r = new RectF(x - 7 * k, y - 7 * k, x + 7 * k, y + 7 * k);
        c.drawRoundRect(r, 1.5f * k, 1.5f * k, p);
        for (int i = -1; i <= 1; i++) {
            float o = i * 5f * k;
            c.drawLine(x - 10 * k, y + o, x - 7 * k, y + o, p);
            c.drawLine(x + 7 * k, y + o, x + 10 * k, y + o, p);
            c.drawLine(x + o, y - 10 * k, x + o, y - 7 * k, p);
            c.drawLine(x + o, y + 7 * k, x + o, y + 10 * k, p);
        }
        p.setStyle(Paint.Style.FILL);
    }

    private void drawAudio(Canvas c, float x, float y, int color, float k) {
        float[] h = {5, 10, 15, 9, 13, 6};
        for (int i = 0; i < h.length; i++) {
            float xx = x + (i - 2.5f) * 3.3f * k;
            line(c, xx, y - h[i] * 0.5f * k, xx, y + h[i] * 0.5f * k, color, 1.8f * k);
        }
    }

    private void drawSpeaker(Canvas c, float x, float y, int color, float k) {
        p.setColor(color);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.5f * k);
        path.reset();
        path.moveTo(x - 8 * k, y - 4 * k);
        path.lineTo(x - 4 * k, y - 4 * k);
        path.lineTo(x + 1 * k, y - 8 * k);
        path.lineTo(x + 1 * k, y + 8 * k);
        path.lineTo(x - 4 * k, y + 4 * k);
        path.lineTo(x - 8 * k, y + 4 * k);
        path.close();
        c.drawPath(path, p);
        path.reset();
        path.moveTo(x + 4 * k, y - 4 * k);
        path.quadTo(x + 9 * k, y, x + 4 * k, y + 4 * k);
        c.drawPath(path, p);
        p.setStyle(Paint.Style.FILL);
    }

    private void drawDoc(Canvas c, float x, float y, int color, float k) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.4f * k);
        p.setColor(color);
        RectF r = new RectF(x - 7 * k, y - 9 * k, x + 7 * k, y + 9 * k);
        c.drawRoundRect(r, 1.2f * k, 1.2f * k, p);
        c.drawLine(x - 4 * k, y - 3 * k, x + 4 * k, y - 3 * k, p);
        c.drawLine(x - 4 * k, y + 1 * k, x + 3 * k, y + 1 * k, p);
        c.drawLine(x - 4 * k, y + 5 * k, x + 1 * k, y + 5 * k, p);
        p.setStyle(Paint.Style.FILL);
    }

    private void drawGear(Canvas c, float x, float y, int color, float k) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2.0f * k);
        p.setColor(color);
        c.drawCircle(x, y, 6 * k, p);
        c.drawCircle(x, y, 2 * k, p);
        for (int i = 0; i < 8; i++) {
            double a = i * Math.PI / 4;
            float x1 = x + (float) Math.cos(a) * 7f * k;
            float y1 = y + (float) Math.sin(a) * 7f * k;
            float x2 = x + (float) Math.cos(a) * 10f * k;
            float y2 = y + (float) Math.sin(a) * 10f * k;
            c.drawLine(x1, y1, x2, y2, p);
        }
        p.setStyle(Paint.Style.FILL);
    }

    private void drawFilter(Canvas c, float x, float y, int color, float k) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.6f * k);
        p.setColor(color);
        path.reset();
        path.moveTo(x - 9 * k, y - 7 * k);
        path.lineTo(x + 9 * k, y - 7 * k);
        path.lineTo(x + 3 * k, y);
        path.lineTo(x + 3 * k, y + 8 * k);
        path.lineTo(x - 2 * k, y + 5 * k);
        path.lineTo(x - 2 * k, y);
        path.close();
        c.drawPath(path, p);
        p.setStyle(Paint.Style.FILL);
    }

    private void drawFreq(Canvas c, float x, float y, int color, float k) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.4f * k);
        p.setColor(color);
        path.reset();
        path.moveTo(x - 9 * k, y);
        path.cubicTo(x - 6 * k, y - 8 * k, x - 4 * k, y + 8 * k, x - 1 * k, y);
        path.cubicTo(x + 2 * k, y - 8 * k, x + 4 * k, y + 8 * k, x + 8 * k, y);
        c.drawPath(path, p);
        p.setStyle(Paint.Style.FILL);
    }

    private void drawResetIcon(Canvas c, float x, float y, int color) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.2f);
        p.setColor(color);
        RectF r = new RectF(x - 5, y - 5, x + 5, y + 5);
        c.drawArc(r, -65, 280, false, p);
        p.setStyle(Paint.Style.FILL);
        path.reset();
        path.moveTo(x - 5, y - 4);
        path.lineTo(x - 8, y - 1);
        path.lineTo(x - 4, y);
        path.close();
        c.drawPath(path, p);
    }

    private void drawSaveIcon(Canvas c, float x, float y, int color) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.2f);
        p.setColor(color);
        RectF r = new RectF(x - 6, y - 7, x + 6, y + 7);
        c.drawRoundRect(r, 1, 1, p);
        c.drawRect(x - 3, y - 6, x + 3, y - 1, p);
        c.drawRect(x - 3, y + 2, x + 3, y + 6, p);
        p.setStyle(Paint.Style.FILL);
    }

    private void drawFolderIcon(Canvas c, float x, float y, int color) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.2f);
        p.setColor(color);
        path.reset();
        path.moveTo(x - 7, y - 5);
        path.lineTo(x - 1, y - 5);
        path.lineTo(x + 1, y - 2);
        path.lineTo(x + 7, y - 2);
        path.lineTo(x + 7, y + 6);
        path.lineTo(x - 7, y + 6);
        path.close();
        c.drawPath(path, p);
        p.setStyle(Paint.Style.FILL);
    }

    private void drawHomeIcon(Canvas c, float x, float y, int color) {
        p.setColor(color);
        path.reset();
        path.moveTo(x - 8, y);
        path.lineTo(x, y - 8);
        path.lineTo(x + 8, y);
        path.lineTo(x + 6, y);
        path.lineTo(x + 6, y + 8);
        path.lineTo(x + 1, y + 8);
        path.lineTo(x + 1, y + 2);
        path.lineTo(x - 1, y + 2);
        path.lineTo(x - 1, y + 8);
        path.lineTo(x - 6, y + 8);
        path.lineTo(x - 6, y);
        path.close();
        c.drawPath(path, p);
    }

    private void drawMixIcon(Canvas c, float x, float y, int color) {
        float[] offs = {-7, 0, 7};
        float[] knobs = {-3, 4, -1};
        for (int i = 0; i < 3; i++) {
            float xx = x + offs[i];
            line(c, xx, y - 9, xx, y + 9, color, 1.4f);
            circle(c, xx, y + knobs[i], 2.2f, color);
        }
    }

    private void drawEqIcon(Canvas c, float x, float y, int color) {
        float[] h = {8, 15, 11};
        for (int i = 0; i < 3; i++) {
            float xx = x + (i - 1) * 7f;
            line(c, xx, y + 8, xx, y + 8 - h[i], color, 2.0f);
        }
    }

    private float freqToX(float f, float left, float right) {
        double min = Math.log10(20.0);
        double max = Math.log10(20000.0);
        double v = Math.log10(clamp(f, 20f, 20000f));
        return left + (float) ((v - min) / (max - min)) * (right - left);
    }

    private float gainToY(float gain, float top, float bottom) {
        return top + (12f - clamp(gain, -12f, 12f)) / 24f * (bottom - top);
    }

    private static float norm(float value, float min, float max) {
        return (value - min) / (max - min);
    }

    private static float logNorm(float value, float min, float max) {
        double lmin = Math.log(min);
        double lmax = Math.log(max);
        return (float) ((Math.log(clamp(value, min, max)) - lmin) / (lmax - lmin));
    }

    private static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    private static float roundStep(float v, float step) {
        return Math.round(v / step) * step;
    }

    private static float roundFrequency(float v) {
        if (v < 100f) return Math.round(v);
        if (v < 1000f) return Math.round(v / 5f) * 5f;
        return Math.round(v / 50f) * 50f;
    }

    private static String formatDb(float v) {
        int n = Math.round(v);
        return n + " dB";
    }

    private static String formatFreq(float f) {
        if (f < 1000f) return Math.round(f) + " Hz";
        if (f < 10000f) return String.format(Locale.US, "%.2g kHz", f / 1000f);
        return String.format(Locale.US, "%.0f kHz", f / 1000f);
    }

    private static String channelPositionName(int ch) {
        String[] names = {"Front Left", "Front Right", "Rear Left", "Rear Right", "Center", "Subwoofer", "Aux"};
        return names[Math.max(0, Math.min(ch, names.length - 1))];
    }

    private int mix(int a, int b, float t) {
        t = clamp(t, 0f, 1f);
        int ar = Color.red(a), ag = Color.green(a), ab = Color.blue(a), aa = Color.alpha(a);
        int br = Color.red(b), bg = Color.green(b), bb = Color.blue(b), ba = Color.alpha(b);
        return Color.argb(
                (int) (aa + (ba - aa) * t),
                (int) (ar + (br - ar) * t),
                (int) (ag + (bg - ag) * t),
                (int) (ab + (bb - ab) * t)
        );
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }
}
