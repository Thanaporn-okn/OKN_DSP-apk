package com.okn.dsp;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Entire Phase-1 interface is rendered from code. No screenshot is used as a UI background.
 * The uploaded visuals are design references only.
 */
public final class DspUiView extends View {
    public interface UiActions { void requestPresetName(); }

    private static final int A_NAV_HOME = 1;
    private static final int A_NAV_MIX = 2;
    private static final int A_NAV_EQ = 3;
    private static final int A_MENU = 4;
    private static final int A_SEARCH = 5;
    private static final int A_THEME_SYSTEM = 6;
    private static final int A_THEME_LIGHT = 7;
    private static final int A_THEME_DARK = 8;
    private static final int A_QUICK = 9;
    private static final int A_HOME_INFO = 10;
    private static final int A_CHIP = 20;
    private static final int A_RESET_EQ = 21;
    private static final int A_BAND_PREV = 22;
    private static final int A_BAND_NEXT = 23;
    private static final int A_PRESET_NAME = 24;
    private static final int A_PRESET_SAVE = 25;
    private static final int A_PRESET_LOAD = 26;
    private static final int A_PRESET_DELETE = 27;
    private static final int A_SLIDER_MASTER = 40;
    private static final int A_SLIDER_BASS = 41;
    private static final int A_SLIDER_CUTOFF = 42;
    private static final int A_SLIDER_CHANNEL = 43;
    private static final int A_SLIDER_FREQ = 44;
    private static final int A_SLIDER_Q = 45;
    private static final int A_SLIDER_GAIN = 46;
    private static final int A_GRAPH = 47;

    private final DspState state;
    private final UiActions uiActions;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final List<Hit> hits = new ArrayList<>();
    private final float density;

    private Hit activeHit;
    private boolean themeMenu;
    private String message;
    private long messageUntil;

    // Current palette
    private int bg, surface, surface2, text, muted, line, pink, cyan, green, blue, danger;

    public DspUiView(Context context, DspState state, UiActions uiActions) {
        super(context);
        this.state = state;
        this.uiActions = uiActions;
        density = getResources().getDisplayMetrics().density;
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        setFocusable(true);
    }

    private float d(float dp) { return dp * density; }

    private boolean dark() {
        if (state.getThemeMode() == DspState.THEME_DARK) return true;
        if (state.getThemeMode() == DspState.THEME_LIGHT) return false;
        int night = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return night == Configuration.UI_MODE_NIGHT_YES;
    }

    private void palette() {
        if (dark()) {
            bg = Color.rgb(8, 14, 25);
            surface = Color.rgb(18, 28, 43);
            surface2 = Color.rgb(27, 39, 57);
            text = Color.rgb(246, 249, 253);
            muted = Color.rgb(155, 169, 190);
            line = Color.rgb(55, 71, 93);
        } else {
            bg = Color.rgb(246, 248, 252);
            surface = Color.WHITE;
            surface2 = Color.rgb(238, 243, 249);
            text = Color.rgb(14, 23, 39);
            muted = Color.rgb(104, 118, 139);
            line = Color.rgb(220, 226, 235);
        }
        pink = Color.rgb(255, 45, 111);
        cyan = Color.rgb(18, 198, 211);
        green = Color.rgb(30, 199, 112);
        blue = Color.rgb(44, 137, 246);
        danger = Color.rgb(255, 72, 92);
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        palette();
        hits.clear();
        c.drawColor(bg);
        boolean wide = getWidth() > getHeight() * 1.18f || getWidth() / density >= 700f;
        drawHeader(c, wide);
        float top = d(76);
        float bottom = getHeight() - d(74);
        if (state.getScreen() == DspState.SCREEN_HOME) drawHome(c, top, bottom, wide);
        else if (state.getScreen() == DspState.SCREEN_MIX) drawMix(c, top, bottom, wide);
        else drawEq(c, top, bottom, wide);
        drawBottomNav(c);
        if (themeMenu) drawThemeMenu(c);
        drawToast(c);
    }

    private void drawHeader(Canvas c, boolean wide) {
        float y = d(12);
        drawLogo(c, d(18), y, d(44));
        text(c, "OKN DSP", d(76), y + d(19), d(19), text, true, Paint.Align.LEFT);
        text(c, "V1 • Phase 1 UI", d(76), y + d(39), d(11), muted, false, Paint.Align.LEFT);
        float right = getWidth() - d(18);
        circleButton(c, right - d(19), y + d(22), d(18), surface2, A_MENU, 0);
        p.setColor(muted); p.setStrokeWidth(d(2));
        c.drawCircle(right - d(19), y + d(15), d(1.4f), p);
        c.drawCircle(right - d(19), y + d(22), d(1.4f), p);
        c.drawCircle(right - d(19), y + d(29), d(1.4f), p);
        circleButton(c, right - d(64), y + d(22), d(18), surface2, A_SEARCH, 0);
        stroke.setColor(muted); stroke.setStrokeWidth(d(2));
        c.drawCircle(right - d(66), y + d(20), d(6), stroke);
        c.drawLine(right - d(61), y + d(25), right - d(57), y + d(29), stroke);
    }

    private void drawLogo(Canvas c, float x, float y, float s) {
        round(c, x, y, x+s, y+s, d(11), Color.rgb(7, 19, 38));
        float cy = y + s*0.5f;
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(s*0.09f);
        p.setColor(Color.rgb(81, 132, 204));
        c.drawLine(x+s*.13f, cy-s*.10f, x+s*.13f, cy+s*.10f, p);
        c.drawLine(x+s*.23f, cy-s*.20f, x+s*.23f, cy+s*.20f, p);
        p.setColor(Color.rgb(18, 206, 231));
        c.drawLine(x+s*.34f, cy-s*.30f, x+s*.34f, cy+s*.30f, p);
        p.setStrokeWidth(s*.16f);
        c.drawLine(x+s*.47f, y+s*.21f, x+s*.47f, y+s*.78f, p);
        p.setColor(Color.rgb(46, 121, 247));
        c.drawLine(x+s*.49f, cy, x+s*.72f, y+s*.29f, p);
        c.drawLine(x+s*.49f, cy, x+s*.72f, y+s*.72f, p);
        p.setStrokeWidth(s*.08f); p.setColor(Color.rgb(18, 206, 231));
        c.drawLine(x+s*.84f, cy-s*.28f, x+s*.84f, cy+s*.28f, p);
        p.setStrokeWidth(d(1)); p.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawHome(Canvas c, float top, float bottom, boolean wide) {
        float margin = d(18), gap = d(10);
        if (!wide) {
            float y = top;
            drawSystemCard(c, margin, y, getWidth()-margin, y+d(88));
            y += d(106);
            text(c, "Connection & Status", margin, y, d(16), text, true, Paint.Align.LEFT);
            text(c, "Phase 1 / local UI", getWidth()-margin, y, d(11), cyan, true, Paint.Align.RIGHT);
            y += d(14);
            String[] title = {"Bluetooth", "DSP Device", "Audio Input", "Amplifier Link", "Preset Sync", "Firmware Status", "Quick Control"};
            String[] sub = {"Transport will be wired in Phase 2", "Protocol data required for Phase 2", "UI control surface ready", "UI control surface ready", "Local presets are persistent", "Version 1 • Phase 1", "Adjust volume, channels and EQ"};
            int[] colors = {blue, pink, cyan, pink, cyan, Color.rgb(142,83,255), pink};
            float available = bottom - y - d(8);
            float rowH = Math.min(d(58), (available - gap*6) / 7f);
            rowH = Math.max(d(45), rowH);
            for (int i=0;i<7;i++) {
                float y0 = y + i*(rowH+gap);
                drawStatusRow(c, margin, y0, getWidth()-margin, y0+rowH, title[i], sub[i], colors[i], i==6, i);
            }
        } else {
            float contentW = getWidth()-margin*2;
            float leftW = contentW*.38f;
            drawSystemCard(c, margin, top, margin+leftW, bottom-d(8));
            float x = margin+leftW+gap;
            float colW = (getWidth()-margin-x-gap)/2f;
            String[] title = {"Bluetooth", "DSP Device", "Audio Input", "Amplifier Link", "Preset Sync", "Firmware Status", "Quick Control"};
            String[] sub = {"Phase 2 transport", "Phase 2 protocol", "UI ready", "UI ready", "Persistent local presets", "V1 • Phase 1", "Open Mix controls"};
            int[] colors = {blue,pink,cyan,pink,cyan,Color.rgb(142,83,255),pink};
            float rowH = (bottom-top-gap*3)/4f;
            for (int i=0;i<7;i++) {
                int col=i%2, row=i/2;
                float x0=x+col*(colW+gap), y0=top+row*(rowH+gap);
                drawStatusRow(c,x0,y0,x0+colW,y0+rowH,title[i],sub[i],colors[i],i==6,i);
            }
        }
    }

    private void drawSystemCard(Canvas c, float l, float t, float r, float b) {
        int card = dark() ? Color.rgb(18, 43, 35) : Color.rgb(238, 253, 244);
        round(c,l,t,r,b,d(18),card);
        float cx=l+d(42), cy=t+d(43), rr=Math.min(d(24),(b-t)*.30f);
        p.setColor(Color.argb(42,30,199,112)); c.drawCircle(cx,cy,rr+d(8),p);
        p.setColor(green); c.drawCircle(cx,cy,rr,p);
        stroke.setColor(Color.WHITE); stroke.setStrokeWidth(d(2.6f));
        path.reset(); path.moveTo(cx-d(8),cy); path.lineTo(cx-d(2),cy+d(6)); path.lineTo(cx+d(10),cy-d(8)); c.drawPath(path,stroke);
        text(c,"SYSTEM STATUS",l+d(82),t+d(25),d(10),muted,true,Paint.Align.LEFT);
        text(c,"System Ready",l+d(82),t+d(47),d(16),text,true,Paint.Align.LEFT);
        text(c,"UI state is live and auto-saved",l+d(82),t+d(66),d(11),muted,false,Paint.Align.LEFT);
        if (b-t>d(150)) {
            text(c,"Phase 1 scope",l+d(24),t+d(112),d(13),text,true,Paint.Align.LEFT);
            paragraph(c,"Home, Mix and 15-band EQ are rebuilt from native drawing code. No screenshot is embedded as a background. DSP commands intentionally remain disabled until verified control data is supplied for Phase 2.",l+d(24),t+d(136),r-l-d(48),d(12),muted,d(18));
        }
    }

    private void drawStatusRow(Canvas c,float l,float t,float r,float b,String title,String sub,int accent,boolean quick,int index){
        round(c,l,t,r,b,d(14),surface);
        float cy=(t+b)/2f;
        p.setColor(Color.argb(dark()?45:28,Color.red(accent),Color.green(accent),Color.blue(accent))); c.drawCircle(l+d(27),cy,d(17),p);
        p.setColor(accent); p.setStrokeWidth(d(2.4f)); p.setStrokeCap(Paint.Cap.ROUND);
        if (quick) {
            c.drawLine(l+d(20),cy+d(7),l+d(20),cy-d(3),p); c.drawLine(l+d(27),cy+d(7),l+d(27),cy-d(9),p); c.drawLine(l+d(34),cy+d(7),l+d(34),cy-d(5),p);
        } else {
            c.drawCircle(l+d(27),cy,d(5),p);
        }
        p.setStrokeCap(Paint.Cap.BUTT);
        text(c,title,l+d(53),cy-d(3),d(13),text,true,Paint.Align.LEFT);
        text(c,sub,l+d(53),cy+d(13),d(9.5f),muted,false,Paint.Align.LEFT);
        text(c,quick?"Open":"Ready",r-d(34),cy+d(4),d(10),quick?pink:green,true,Paint.Align.RIGHT);
        text(c,"›",r-d(14),cy+d(5),d(20),muted,false,Paint.Align.CENTER);
        hit(new RectF(l,t,r,b),quick?A_QUICK:A_HOME_INFO,index);
    }

    private void drawMix(Canvas c,float top,float bottom,boolean wide){
        float m=d(18), gap=d(12);
        if(!wide){
            float y=top;
            text(c,"Global",m,y+d(12),d(16),text,true,Paint.Align.LEFT);
            text(c,"Overall output and bass settings",getWidth()-m,y+d(12),d(10),muted,false,Paint.Align.RIGHT);
            y+=d(24);
            float globalH=d(154);
            round(c,m,y,getWidth()-m,y+globalH,d(16),surface);
            drawSliderRow(c,m+d(12),y+d(12),getWidth()-m-d(12),y+d(52),"Master Volume",state.getMasterDb(),-60,6,pink,A_SLIDER_MASTER,0,fmtDb(state.getMasterDb()));
            drawSliderRow(c,m+d(12),y+d(57),getWidth()-m-d(12),y+d(97),"Bass Volume",state.getBassDb(),-12,12,cyan,A_SLIDER_BASS,0,fmtDb(state.getBassDb()));
            drawSliderRow(c,m+d(12),y+d(102),getWidth()-m-d(12),y+d(142),"Bass Cutoff",state.getBassCutoffHz(),20,300,pink,A_SLIDER_CUTOFF,0,String.format(Locale.US,"%.0f Hz",state.getBassCutoffHz()));
            y+=globalH+d(18);
            text(c,"Channels",m,y+d(10),d(16),text,true,Paint.Align.LEFT);
            text(c,"Individual channel levels",getWidth()-m,y+d(10),d(10),muted,false,Paint.Align.RIGHT);
            y+=d(20);
            float avail=bottom-y-d(6); float rowH=Math.max(d(42),Math.min(d(52),(avail-d(6)*6)/7f));
            int[] cols={pink,cyan,green,pink,green,cyan,danger};
            for(int i=0;i<7;i++){
                float t=y+i*(rowH+d(6));
                round(c,m,t,getWidth()-m,t+rowH,d(12),surface);
                drawChannelBadge(c,m+d(24),t+rowH/2f,i+1,cols[i]);
                drawSliderRow(c,m+d(48),t+d(2),getWidth()-m-d(10),t+rowH-d(2),"Volume Ch"+(i+1),state.getChannelDb(i),-60,6,cols[i],A_SLIDER_CHANNEL,i,fmtDb(state.getChannelDb(i)));
            }
        } else {
            float contentW=getWidth()-m*2; float leftW=contentW*.40f; float rightL=m+leftW+gap;
            text(c,"Global",m,top+d(12),d(16),text,true,Paint.Align.LEFT);
            round(c,m,top+d(26),m+leftW, bottom-d(8),d(16),surface);
            float panelTop=top+d(36), rowH=(bottom-panelTop-d(22))/3f;
            drawSliderRow(c,m+d(14),panelTop,m+leftW-d(14),panelTop+rowH,"Master Volume",state.getMasterDb(),-60,6,pink,A_SLIDER_MASTER,0,fmtDb(state.getMasterDb()));
            drawSliderRow(c,m+d(14),panelTop+rowH,m+leftW-d(14),panelTop+2*rowH,"Bass Volume",state.getBassDb(),-12,12,cyan,A_SLIDER_BASS,0,fmtDb(state.getBassDb()));
            drawSliderRow(c,m+d(14),panelTop+2*rowH,m+leftW-d(14),bottom-d(18),"Bass Cutoff",state.getBassCutoffHz(),20,300,pink,A_SLIDER_CUTOFF,0,String.format(Locale.US,"%.0f Hz",state.getBassCutoffHz()));
            text(c,"Channels",rightL,top+d(12),d(16),text,true,Paint.Align.LEFT);
            float colGap=d(8); float colW=(getWidth()-m-rightL-colGap)/2f; float start=top+d(26); float rh=(bottom-start-colGap*3-d(8))/4f;
            int[] cols={pink,cyan,green,pink,green,cyan,danger};
            for(int i=0;i<7;i++){
                int col=i%2,row=i/2; float l=rightL+col*(colW+colGap), t=start+row*(rh+colGap);
                round(c,l,t,l+colW,t+rh,d(12),surface);
                drawChannelBadge(c,l+d(22),t+rh/2f,i+1,cols[i]);
                drawSliderRow(c,l+d(42),t+d(2),l+colW-d(8),t+rh-d(2),"Ch"+(i+1),state.getChannelDb(i),-60,6,cols[i],A_SLIDER_CHANNEL,i,fmtDb(state.getChannelDb(i)));
            }
        }
    }

    private void drawEq(Canvas c,float top,float bottom,boolean wide){
        float m=d(18), gap=d(10);
        float chipsY=top;
        float chipGap=d(6), chipW=(getWidth()-m*2-chipGap*6)/7f;
        if (wide) chipW=Math.min(d(56),chipW);
        for(int i=0;i<7;i++){
            float l=m+i*(chipW+chipGap); boolean sel=i==state.getSelectedChannel();
            round(c,l,chipsY,l+chipW,chipsY+d(31),d(15),sel?pink:surface2);
            text(c,"Ch"+(i+1),l+chipW/2,chipsY+d(20),d(10),sel?Color.WHITE:muted,true,Paint.Align.CENTER);
            hit(new RectF(l,chipsY,l+chipW,chipsY+d(31)),A_CHIP,i);
        }
        if(!wide){
            float y=chipsY+d(42);
            float graphH=Math.min(d(235),(bottom-y)*.39f);
            drawEqGraph(c,m,y,getWidth()-m,y+graphH);
            y+=graphH+d(8);
            drawBandHeader(c,m,y,getWidth()-m,y+d(46)); y+=d(52);
            float controlH=Math.min(d(51),(bottom-y-d(125))/3f);
            controlH=Math.max(d(42),controlH);
            int ch=state.getSelectedChannel(), b=state.getSelectedBand();
            drawParamRow(c,m,y,getWidth()-m,y+controlH,"Frequency","Hz",freqToNorm(state.getEqFreq(ch,b)),cyan,A_SLIDER_FREQ,String.format(Locale.US,"%s",fmtHz(state.getEqFreq(ch,b)))); y+=controlH+d(6);
            drawParamRow(c,m,y,getWidth()-m,y+controlH,"Q (Quality Factor)","0.1 – 10.0",(state.getEqQ(ch,b)-.1f)/9.9f,cyan,A_SLIDER_Q,String.format(Locale.US,"%.2f",state.getEqQ(ch,b))); y+=controlH+d(6);
            drawParamRow(c,m,y,getWidth()-m,y+controlH,"Gain Band","-12 – +12 dB",(state.getEqGain(ch,b)+12f)/24f,green,A_SLIDER_GAIN,String.format(Locale.US,"%.1f dB",state.getEqGain(ch,b))); y+=controlH+d(10);
            drawPreset(c,m,y,getWidth()-m,bottom-d(4));
        }else{
            float y=chipsY+d(42); float contentH=bottom-y-d(5); float leftW=(getWidth()-m*2-gap)*.57f;
            drawEqGraph(c,m,y,m+leftW,bottom-d(5));
            float rL=m+leftW+gap, rR=getWidth()-m;
            drawBandHeader(c,rL,y,rR,y+d(44));
            int ch=state.getSelectedChannel(), b=state.getSelectedBand();
            float py=y+d(52), ph=Math.max(d(42),Math.min(d(58),(contentH-d(52)-d(104)-d(18))/3f));
            drawParamRow(c,rL,py,rR,py+ph,"Frequency","20 Hz – 20 kHz",freqToNorm(state.getEqFreq(ch,b)),cyan,A_SLIDER_FREQ,fmtHz(state.getEqFreq(ch,b))); py+=ph+d(6);
            drawParamRow(c,rL,py,rR,py+ph,"Q (Quality Factor)","0.1 – 10.0",(state.getEqQ(ch,b)-.1f)/9.9f,cyan,A_SLIDER_Q,String.format(Locale.US,"%.2f",state.getEqQ(ch,b))); py+=ph+d(6);
            drawParamRow(c,rL,py,rR,py+ph,"Gain Band","-12 – +12 dB",(state.getEqGain(ch,b)+12f)/24f,green,A_SLIDER_GAIN,String.format(Locale.US,"%.1f dB",state.getEqGain(ch,b))); py+=ph+d(8);
            drawPreset(c,rL,py,rR,bottom-d(5));
        }
    }

    private void drawEqGraph(Canvas c,float l,float t,float r,float b){
        round(c,l,t,r,b,d(15),surface);
        float left=l+d(38), right=r-d(12), top=t+d(32), bottom=b-d(28);
        int ch=state.getSelectedChannel();
        text(c,"Channel "+(ch+1),l+d(12),t+d(18),d(13),text,true,Paint.Align.LEFT);
        text(c,"15-band EQ • drag points directly",r-d(12),t+d(18),d(9.5f),muted,false,Paint.Align.RIGHT);
        stroke.setStrokeWidth(d(1)); stroke.setColor(line);
        for(int i=0;i<5;i++){ float y=top+(bottom-top)*i/4f; c.drawLine(left,y,right,y,stroke); float db=12f-6f*i; text(c,String.format(Locale.US,"%+.0f",db),left-d(7),y+d(4),d(8),muted,false,Paint.Align.RIGHT); }
        float[] grid={20,100,1000,10000,20000};
        for(float f:grid){ float x=left+(right-left)*freqToNorm(f); c.drawLine(x,top,x,bottom,stroke); text(c,fmtHz(f),x,bottom+d(14),d(7.5f),muted,false,Paint.Align.CENTER); }
        path.reset();
        for(int i=0;i<DspState.BANDS;i++){
            float x=left+(right-left)*freqToNorm(state.getEqFreq(ch,i));
            float y=top+(12f-state.getEqGain(ch,i))/24f*(bottom-top);
            if(i==0)path.moveTo(x,y); else path.lineTo(x,y);
        }
        stroke.setStrokeWidth(d(2.2f)); stroke.setColor(cyan); c.drawPath(path,stroke);
        for(int i=0;i<DspState.BANDS;i++){
            float x=left+(right-left)*freqToNorm(state.getEqFreq(ch,i));
            float y=top+(12f-state.getEqGain(ch,i))/24f*(bottom-top);
            boolean sel=i==state.getSelectedBand();
            if(sel){p.setColor(Color.argb(50,255,45,111));c.drawCircle(x,y,d(11),p);} p.setColor(sel?pink:cyan); c.drawCircle(x,y,sel?d(5):d(3.6f),p); p.setColor(surface); c.drawCircle(x,y,sel?d(2.2f):d(1.5f),p);
        }
        hit(new RectF(left-d(8),top-d(8),right+d(8),bottom+d(8)),A_GRAPH,0);
    }

    private void drawBandHeader(Canvas c,float l,float t,float r,float b){
        round(c,l,t,r,b,d(13),surface);
        float cy=(t+b)/2f;
        round(c,l+d(10),cy-d(14),l+d(38),cy+d(14),d(14),Color.argb(35,255,45,111));
        text(c,String.valueOf(state.getSelectedBand()+1),l+d(24),cy+d(5),d(14),pink,true,Paint.Align.CENTER);
        text(c,"Band "+(state.getSelectedBand()+1),l+d(48),cy-d(1),d(12),text,true,Paint.Align.LEFT);
        text(c,"Live controls",l+d(48),cy+d(14),d(9),muted,false,Paint.Align.LEFT);
        float bx=r-d(90); button(c,bx,cy-d(14),bx+d(28),cy+d(14),surface2,"‹",A_BAND_PREV,0,muted);
        button(c,bx+d(34),cy-d(14),bx+d(62),cy+d(14),surface2,"›",A_BAND_NEXT,0,muted);
        button(c,r-d(22),cy-d(14),r-d(2),cy+d(14),Color.argb(35,255,72,92),"↺",A_RESET_EQ,0,danger);
    }

    private void drawParamRow(Canvas c,float l,float t,float r,float b,String title,String hint,float norm,int accent,int action,String value){
        round(c,l,t,r,b,d(12),surface);
        float cy=(t+b)/2f;
        text(c,title,l+d(12),t+d(18),d(10.5f),text,true,Paint.Align.LEFT);
        text(c,value,r-d(12),t+d(18),d(10.5f),text,true,Paint.Align.RIGHT);
        float x0=l+d(12), x1=r-d(12), y=Math.max(t+d(28),b-d(13));
        drawTrack(c,x0,x1,y,norm,accent);
        hit(new Hit(new RectF(x0-d(5),y-d(13),x1+d(5),y+d(13)),action,0,x0,x1));
    }

    private void drawPreset(Canvas c,float l,float t,float r,float b){
        if(b-t<d(70))return;
        round(c,l,t,r,b,d(13),surface);
        text(c,"Presets",l+d(12),t+d(20),d(12),text,true,Paint.Align.LEFT);
        text(c,"Auto-saved UI + manual snapshot",r-d(12),t+d(20),d(9),muted,false,Paint.Align.RIGHT);
        float row=t+d(30), h=Math.min(d(34),(b-row-d(7))/2f);
        if(h<d(22))h=d(22);
        round(c,l+d(10),row,r-d(10),row+h,d(9),surface2);
        text(c,state.getPresetName(),l+d(20),row+h/2+d(4),d(10),text,false,Paint.Align.LEFT);
        text(c,"✎",r-d(24),row+h/2+d(4),d(12),muted,false,Paint.Align.CENTER);
        hit(new RectF(l+d(10),row,r-d(10),row+h),A_PRESET_NAME,0);
        float y=row+h+d(6), gap=d(6), bw=(r-l-d(20)-gap*2)/3f;
        button(c,l+d(10),y,l+d(10)+bw,Math.min(b-d(6),y+h),pink,"Save",A_PRESET_SAVE,0,Color.WHITE);
        button(c,l+d(10)+bw+gap,y,l+d(10)+2*bw+gap,Math.min(b-d(6),y+h),surface2,"Load",A_PRESET_LOAD,0,text);
        button(c,l+d(10)+2*(bw+gap),y,r-d(10),Math.min(b-d(6),y+h),Color.argb(35,255,72,92),"Delete",A_PRESET_DELETE,0,danger);
    }

    private void drawSliderRow(Canvas c,float l,float t,float r,float b,String label,float value,float min,float max,int accent,int action,int index,String valueText){
        float h=b-t, cy=(t+b)/2f;
        text(c,label,l,t+d(15),d(10.5f),text,true,Paint.Align.LEFT);
        text(c,valueText,r,t+d(15),d(10.5f),text,true,Paint.Align.RIGHT);
        float x0=l, x1=r, y=t+Math.max(d(27),h*.72f);
        float norm=(value-min)/(max-min);
        drawTrack(c,x0,x1,y,norm,accent);
        hit(new Hit(new RectF(x0-d(4),y-d(14),x1+d(4),y+d(14)),action,index,x0,x1));
    }

    private void drawTrack(Canvas c,float x0,float x1,float y,float norm,int accent){
        norm=Math.max(0,Math.min(1,norm));
        p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeWidth(d(4)); p.setColor(line); c.drawLine(x0,y,x1,y,p);
        if(x1>x0){ p.setShader(new LinearGradient(x0,y,x1,y,accent,lighten(accent),Shader.TileMode.CLAMP)); c.drawLine(x0,y,x0+(x1-x0)*norm,y,p); p.setShader(null); }
        float tx=x0+(x1-x0)*norm; p.setColor(Color.WHITE); c.drawCircle(tx,y,d(6),p); stroke.setColor(Color.argb(90,0,0,0)); stroke.setStrokeWidth(d(1)); c.drawCircle(tx,y,d(6),stroke); p.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawChannelBadge(Canvas c,float x,float y,int n,int color){ p.setColor(color); c.drawCircle(x,y,d(13),p); text(c,String.valueOf(n),x,y+d(5),d(11),Color.WHITE,true,Paint.Align.CENTER); }

    private void drawBottomNav(Canvas c){
        float h=d(64), t=getHeight()-h-d(4), m=d(14);
        round(c,m,t,getWidth()-m,getHeight()-d(8),d(19),surface);
        float total=getWidth()-m*2; float cell=total/3f;
        navItem(c,m,t,cell,"Home",DspState.SCREEN_HOME,A_NAV_HOME);
        navItem(c,m+cell,t,cell,"Mix",DspState.SCREEN_MIX,A_NAV_MIX);
        navItem(c,m+2*cell,t,cell,"EQ",DspState.SCREEN_EQ,A_NAV_EQ);
    }

    private void navItem(Canvas c,float l,float t,float w,String label,int screen,int action){
        boolean sel=state.getScreen()==screen; float r=l+w, b=getHeight()-d(8), cx=(l+r)/2f;
        if(sel)round(c,l+d(8),t+d(6),r-d(8),b-d(6),d(14),Color.argb(dark()?70:30,255,45,111));
        p.setColor(sel?pink:muted); p.setStrokeWidth(d(2.2f)); p.setStrokeCap(Paint.Cap.ROUND);
        float iy=t+d(18);
        if(screen==DspState.SCREEN_HOME){ path.reset();path.moveTo(cx-d(7),iy+d(4));path.lineTo(cx,iy-d(2));path.lineTo(cx+d(7),iy+d(4)); c.drawPath(path,p); c.drawRect(cx-d(5),iy+d(4),cx+d(5),iy+d(12),p); }
        else if(screen==DspState.SCREEN_MIX){ c.drawLine(cx-d(7),iy, cx-d(7),iy+d(13),p);c.drawLine(cx,iy-d(2),cx,iy+d(13),p);c.drawLine(cx+d(7),iy+d(2),cx+d(7),iy+d(13),p); c.drawCircle(cx-d(7),iy+d(5),d(2),p);c.drawCircle(cx,iy+d(3),d(2),p);c.drawCircle(cx+d(7),iy+d(8),d(2),p); }
        else { c.drawLine(cx-d(8),iy+d(10),cx-d(8),iy+d(2),p);c.drawLine(cx,iy+d(10),cx,iy-d(2),p);c.drawLine(cx+d(8),iy+d(10),cx+d(8),iy+d(4),p); }
        p.setStrokeCap(Paint.Cap.BUTT);
        text(c,label,cx,t+d(48),d(10),sel?pink:muted,sel,Paint.Align.CENTER);
        hit(new RectF(l,t,r,b),action,0);
    }

    private void drawThemeMenu(Canvas c){
        float w=d(176), r=getWidth()-d(16), l=r-w, t=d(62), row=d(43), b=t+row*3+d(16);
        round(c,l,t,r,b,d(16),surface);
        text(c,"Theme",l+d(14),t+d(20),d(11),muted,true,Paint.Align.LEFT);
        themeRow(c,l+d(8),t+d(27),r-d(8),t+d(27)+row,"System",DspState.THEME_SYSTEM,A_THEME_SYSTEM);
        themeRow(c,l+d(8),t+d(27)+row,r-d(8),t+d(27)+row*2,"Light",DspState.THEME_LIGHT,A_THEME_LIGHT);
        themeRow(c,l+d(8),t+d(27)+row*2,r-d(8),t+d(27)+row*3,"Dark",DspState.THEME_DARK,A_THEME_DARK);
    }

    private void themeRow(Canvas c,float l,float t,float r,float b,String label,int mode,int action){
        boolean sel=state.getThemeMode()==mode; if(sel)round(c,l,t,r,b,d(11),surface2);
        p.setColor(sel?pink:line); c.drawCircle(l+d(16),(t+b)/2,d(5),p);
        text(c,label,l+d(32),(t+b)/2+d(4),d(11),text,sel,Paint.Align.LEFT);
        hit(new RectF(l,t,r,b),action,0);
    }

    private void drawToast(Canvas c){
        if(message==null || SystemClock.uptimeMillis()>messageUntil){message=null;return;}
        float w=Math.min(getWidth()-d(36),d(330)), h=d(38), l=(getWidth()-w)/2f, b=getHeight()-d(82), t=b-h;
        int color=dark()?Color.rgb(236,241,248):Color.rgb(25,34,49);
        round(c,l,t,l+w,b,d(19),color); text(c,message,l+w/2,t+d(24),d(10.5f),dark()?Color.rgb(20,28,40):Color.WHITE,false,Paint.Align.CENTER);
        postInvalidateDelayed(120);
    }

    public void showMessage(String m){message=m;messageUntil=SystemClock.uptimeMillis()+1800;invalidate();}

    @Override
    public boolean onTouchEvent(MotionEvent e){
        float x=e.getX(), y=e.getY();
        switch(e.getActionMasked()){
            case MotionEvent.ACTION_DOWN:
                activeHit=findHit(x,y);
                if(activeHit!=null && isContinuous(activeHit.action)){ updateContinuous(activeHit,x,y); getParent().requestDisallowInterceptTouchEvent(true); }
                return true;
            case MotionEvent.ACTION_MOVE:
                if(activeHit!=null && isContinuous(activeHit.action)){ updateContinuous(activeHit,x,y); return true; }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if(activeHit!=null){
                    if(isContinuous(activeHit.action)) updateContinuous(activeHit,x,y);
                    else if(e.getActionMasked()==MotionEvent.ACTION_UP && activeHit.rect.contains(x,y)) handleTap(activeHit);
                    activeHit=null; getParent().requestDisallowInterceptTouchEvent(false); return true;
                }
                if(themeMenu && e.getActionMasked()==MotionEvent.ACTION_UP){themeMenu=false;invalidate();}
                return true;
        }
        return true;
    }

    private boolean isContinuous(int a){return a>=A_SLIDER_MASTER && a<=A_GRAPH;}

    private void updateContinuous(Hit h,float x,float y){
        float norm=(x-h.trackStart)/(h.trackEnd-h.trackStart); norm=Math.max(0,Math.min(1,norm));
        int ch=state.getSelectedChannel(), b=state.getSelectedBand();
        switch(h.action){
            case A_SLIDER_MASTER: state.setMasterDb(-60f+66f*norm); break;
            case A_SLIDER_BASS: state.setBassDb(-12f+24f*norm); break;
            case A_SLIDER_CUTOFF: state.setBassCutoffHz(20f+280f*norm); break;
            case A_SLIDER_CHANNEL: state.setChannelDb(h.index,-60f+66f*norm); break;
            case A_SLIDER_FREQ: state.setEqFreq(ch,b,normToFreq(norm)); break;
            case A_SLIDER_Q: state.setEqQ(ch,b,.1f+9.9f*norm); break;
            case A_SLIDER_GAIN: state.setEqGain(ch,b,-12f+24f*norm); break;
            case A_GRAPH:
                float gx=Math.max(h.rect.left,Math.min(h.rect.right,x));
                float gy=Math.max(h.rect.top,Math.min(h.rect.bottom,y));
                // select closest existing point on initial/continuous x, then move selected point in both axes
                int best=state.getSelectedBand(); float bestDx=Float.MAX_VALUE;
                for(int i=0;i<DspState.BANDS;i++){float px=h.rect.left+h.rect.width()*freqToNorm(state.getEqFreq(ch,i));float dx=Math.abs(px-gx);if(dx<bestDx){bestDx=dx;best=i;}}
                state.setSelectedBand(best); b=best;
                float nx=(gx-h.rect.left)/h.rect.width(); float ny=(gy-h.rect.top)/h.rect.height();
                state.setEqFreq(ch,b,normToFreq(nx)); state.setEqGain(ch,b,12f-24f*ny);
                break;
        }
        invalidate();
    }

    private void handleTap(Hit h){
        switch(h.action){
            case A_NAV_HOME: state.setScreen(DspState.SCREEN_HOME); break;
            case A_NAV_MIX: state.setScreen(DspState.SCREEN_MIX); break;
            case A_NAV_EQ: state.setScreen(DspState.SCREEN_EQ); break;
            case A_MENU: themeMenu=!themeMenu; invalidate(); return;
            case A_SEARCH: showMessage("Device discovery will connect in Phase 2"); return;
            case A_THEME_SYSTEM: state.setThemeMode(DspState.THEME_SYSTEM); themeMenu=false; break;
            case A_THEME_LIGHT: state.setThemeMode(DspState.THEME_LIGHT); themeMenu=false; break;
            case A_THEME_DARK: state.setThemeMode(DspState.THEME_DARK); themeMenu=false; break;
            case A_QUICK: state.setScreen(DspState.SCREEN_MIX); break;
            case A_HOME_INFO: showMessage("Phase 1 UI is active • DSP transport not connected yet"); return;
            case A_CHIP: state.setSelectedChannel(h.index); break;
            case A_RESET_EQ: state.resetEqChannel(state.getSelectedChannel()); showMessage("Channel EQ reset"); break;
            case A_BAND_PREV: state.setSelectedBand((state.getSelectedBand()+DspState.BANDS-1)%DspState.BANDS); break;
            case A_BAND_NEXT: state.setSelectedBand((state.getSelectedBand()+1)%DspState.BANDS); break;
            case A_PRESET_NAME: if(uiActions!=null)uiActions.requestPresetName(); return;
            case A_PRESET_SAVE: state.savePresetSnapshot(); showMessage("Preset saved: "+state.getPresetName()); break;
            case A_PRESET_LOAD: if(state.loadPresetSnapshot())showMessage("Preset loaded"); else showMessage("No saved preset yet"); break;
            case A_PRESET_DELETE: state.deletePresetSnapshot(); showMessage("Preset deleted"); break;
        }
        invalidate();
    }

    private Hit findHit(float x,float y){for(int i=hits.size()-1;i>=0;i--){Hit h=hits.get(i);if(h.rect.contains(x,y))return h;}return null;}
    private void hit(RectF r,int action,int index){hits.add(new Hit(r,action,index,0,1));}
    private void hit(Hit h){hits.add(h);}

    private void circleButton(Canvas c,float cx,float cy,float rr,int color,int action,int index){p.setColor(color);c.drawCircle(cx,cy,rr,p);hit(new RectF(cx-rr,cy-rr,cx+rr,cy+rr),action,index);}
    private void button(Canvas c,float l,float t,float r,float b,int color,String label,int action,int index,int labelColor){round(c,l,t,r,b,d(9),color);text(c,label,(l+r)/2,(t+b)/2+d(4),d(10.5f),labelColor,true,Paint.Align.CENTER);hit(new RectF(l,t,r,b),action,index);}
    private void round(Canvas c,float l,float t,float r,float b,float radius,int color){p.setStyle(Paint.Style.FILL);p.setColor(color);c.drawRoundRect(new RectF(l,t,r,b),radius,radius,p);}
    private void text(Canvas c,String s,float x,float y,float size,int color,boolean bold,Paint.Align align){p.setShader(null);p.setStyle(Paint.Style.FILL);p.setColor(color);p.setTextSize(size);p.setTextAlign(align);p.setTypeface(bold?android.graphics.Typeface.create("sans",android.graphics.Typeface.BOLD):android.graphics.Typeface.create("sans",android.graphics.Typeface.NORMAL));c.drawText(s,x,y,p);}
    private void paragraph(Canvas c,String s,float x,float y,float width,float size,int color,float lineH){String[] words=s.split(" ");StringBuilder line=new StringBuilder();float yy=y;for(String w:words){String next=line.length()==0?w:line+" "+w;p.setTextSize(size);if(p.measureText(next)>width&&line.length()>0){text(c,line.toString(),x,yy,size,color,false,Paint.Align.LEFT);yy+=lineH;line=new StringBuilder(w);}else line=new StringBuilder(next);}if(line.length()>0)text(c,line.toString(),x,yy,size,color,false,Paint.Align.LEFT);}
    private int lighten(int color){int r=Math.min(255,Color.red(color)+50),g=Math.min(255,Color.green(color)+50),b=Math.min(255,Color.blue(color)+50);return Color.rgb(r,g,b);}
    private String fmtDb(float v){return String.format(Locale.US,"%+.1f dB",v);}
    private String fmtHz(float f){if(f>=1000f)return String.format(Locale.US,f>=10000?"%.0f kHz":"%.1f kHz",f/1000f);return String.format(Locale.US,"%.0f Hz",f);}
    private float freqToNorm(float f){double lo=Math.log10(20.0), hi=Math.log10(20000.0);return (float)((Math.log10(Math.max(20,Math.min(20000,f)))-lo)/(hi-lo));}
    private float normToFreq(float n){n=Math.max(0,Math.min(1,n));double lo=Math.log10(20.0),hi=Math.log10(20000.0);return (float)Math.pow(10,lo+(hi-lo)*n);}

    private static final class Hit{
        final RectF rect; final int action,index; final float trackStart,trackEnd;
        Hit(RectF r,int a,int i,float s,float e){rect=r;action=a;index=i;trackStart=s;trackEnd=e;}
    }
}
