package com.okn.dsp;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.BluetoothStatusCodes;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * V1 15-Band Graphic EQ + inherited V1 original-app scheduler and TrebleBoost safe-slew transport.
 * The remaining first-band filter is handled in its native type: Tone Control on CH1/2/4-7,
 * General Low-pass on CH3. No filter-type conversion is performed.
 *
 * The 250401 BTSnoop reference shows one AB01 application command about every
 * 380 ms. When no user write is pending it cycles UFE reads for sensor IDs
 * 19, 20, 0 and 21. Scalar writes replace a scheduler slot rather than forming
 * a high-rate write stream. This class reproduces that observed cadence.
 *
 * BLE profile and application framing are taken only from the project's
 * real-device evidence: AB00 service, AB01 TX, AB02 RX, pre-auth 16-byte
 * request, AES-CFB8 authenticated stream, UFE 0x57 actuator writes.
 */
final class BleManager {
    interface Listener {
        void onBleStatus(String status, String deviceName, boolean dspReady);
        void onBleMessage(String message);
        void onScalarValue(int actuatorId, float value);
        void onEqValue(int channel0, int uiBand0, float frequency, float gainDb, float q, boolean writable);
    }

    static final UUID AB00 = UUID.fromString("0000ab00-0000-1000-8000-00805f9b34fb");
    static final UUID AB01 = UUID.fromString("0000ab01-0000-1000-8000-00805f9b34fb");
    static final UUID AB02 = UUID.fromString("0000ab02-0000-1000-8000-00805f9b34fb");
    static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

    /** Median/mean command spacing in the official 250401 BTSnoop trace is about 380 ms. */
    private static final long ORIGINAL_COMMAND_CADENCE_MS = 380L;
    private static final int[] ORIGINAL_POLL_IDS = {19, 20, 0, 21};
    private static final int[] ORIGINAL_POLL_LENGTHS = {1, 1, 4, 4};
    private static final long LIVE_WRITE_TIMEOUT_MS = 1500L;
    /** V1: real V1 hardware evidence isolated audible pumping to TrebleBoost / ID11. */
    private static final float TREBLE_MAX_STEP_DB = 0.5f;
    private static final long DESCRIPTOR_TIMEOUT_MS = 15000L;

    private final Context context;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final BluetoothAdapter adapter;

    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic ab01;
    private BluetoothGattCharacteristic ab02;

    private boolean scanning;
    private boolean transportConnected;
    private boolean dspReady;
    private boolean closed;
    private boolean waitingAuth;
    private boolean readingDescriptor;
    private String deviceName = "OKN-DSP_7CH";

    private DspProtocol.StreamCipher txCipher;
    private DspProtocol.StreamCipher rxCipher;
    private int descriptorExpected = -1;
    private final ByteArrayOutputStream descriptorBytes = new ByteArrayOutputStream(19000);
    private Runnable descriptorTimeout;

    private final Map<Integer, Float> scalarValues = new LinkedHashMap<>();
    private final DspProtocol.EqBand[][] eqBands = new DspProtocol.EqBand[7][15];

    private final LinkedHashMap<String, PendingCommand> pending = new LinkedHashMap<>();
    private PendingCommand liveInflight;
    private boolean liveWriteBusy;
    private Runnable liveWriteTimeout;
    private final ArrayDeque<WriteTicket> writeTickets = new ArrayDeque<>();

    /** Latest UI targets for verified scalar actuators. */
    private final Map<Integer, Float> scalarTargets = new LinkedHashMap<>();
    private Runnable originalCommandScheduler;
    private int originalPollIndex;
    /** Latest requested Treble target. Only the final touch target is committed by DspView. */
    private Float trebleTarget;

    private static final class PendingCommand {
        final String key;
        final byte[] plain;
        final int scalarId;
        final float scalarValue;
        final int channel0;
        final int uiBand0;
        final int hwBand1;
        final DspProtocol.EqBand eqTarget;

        private PendingCommand(String key, byte[] plain, int scalarId, float scalarValue,
                               int channel0, int uiBand0, int hwBand1, DspProtocol.EqBand eqTarget) {
            this.key = key;
            this.plain = plain;
            this.scalarId = scalarId;
            this.scalarValue = scalarValue;
            this.channel0 = channel0;
            this.uiBand0 = uiBand0;
            this.hwBand1 = hwBand1;
            this.eqTarget = eqTarget;
        }

        static PendingCommand scalar(int id, float value) {
            return new PendingCommand("S:" + id, DspProtocol.encodeFloatWrite(id, value), id, value,
                    -1, -1, -1, null);
        }

        static PendingCommand eq(int ch, int uiBand, int hwBand, DspProtocol.EqBand target) {
            return new PendingCommand("E:" + ch + ":" + uiBand,
                    DspProtocol.encodeEqWrite(ch, hwBand, target), -1, Float.NaN,
                    ch, uiBand, hwBand, target);
        }
    }

    private static final class WriteTicket {
        final String label;
        final PendingCommand command;
        WriteTicket(String label, PendingCommand command) {
            this.label = label;
            this.command = command;
        }
    }

    BleManager(Context context, Listener listener) {
        this.context = context.getApplicationContext();
        this.listener = listener;
        BluetoothAdapter found = null;
        try {
            BluetoothManager manager = (BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE);
            found = manager == null ? null : manager.getAdapter();
        } catch (RuntimeException ignored) {
        }
        adapter = found;
    }

    boolean isConnected() {
        return transportConnected;
    }

    boolean isDspReady() {
        return dspReady;
    }

    void startScan() {
        if (closed) return;
        if (!hasPermissions()) {
            postStatus("รอสิทธิ์ Bluetooth", deviceName, false);
            return;
        }
        if (adapter == null) {
            postStatus("ไม่พบ Bluetooth", deviceName, false);
            return;
        }
        if (!adapter.isEnabled()) {
            postStatus("กรุณาเปิด Bluetooth", deviceName, false);
            return;
        }
        if (dspReady) {
            postStatus("เชื่อมต่อแล้ว", deviceName, true);
            return;
        }
        if (transportConnected) {
            postStatus("กำลังยืนยัน DSP", deviceName, false);
            return;
        }
        try {
            scanner = adapter.getBluetoothLeScanner();
            if (scanner == null) {
                postStatus("สแกน BLE ไม่ได้", deviceName, false);
                return;
            }
            if (scanning) scanner.stopScan(scanCallback);
            scanning = true;
            postStatus("กำลังค้นหา DSP...", deviceName, false);
            scanner.startScan(scanCallback);
            main.postDelayed(this::stopScan, 10000L);
        } catch (SecurityException e) {
            postStatus("สิทธิ์ Bluetooth ไม่ครบ", deviceName, false);
        } catch (RuntimeException e) {
            scanning = false;
            postStatus("เริ่ม BLE ไม่สำเร็จ", deviceName, false);
            postMessage("BLE error: " + e.getClass().getSimpleName());
        }
    }

    void stopScan() {
        if (!scanning || scanner == null || !hasPermissions()) return;
        try { scanner.stopScan(scanCallback); } catch (SecurityException ignored) {}
        scanning = false;
    }

    /** Re-read the real DSP descriptor in the current authenticated session. */
    void requestDspRefresh() {
        main.post(() -> {
            if (!dspReady || txCipher == null || rxCipher == null) {
                postMessage("DSP ยังไม่ READY — รอเชื่อมต่อให้สมบูรณ์ก่อน");
                if (!transportConnected) startScan();
                return;
            }
            if (liveWriteBusy || !pending.isEmpty()) {
                postMessage("กำลังส่งค่า Real-time — รอสักครู่แล้วกดโหลดจากอุปกรณ์อีกครั้ง");
                return;
            }
            startDescriptorRequest("REFRESH");
        });
    }

    /** Compatibility name used by the V1 UI button. */
    void readKnownCharacteristic() {
        requestDspRefresh();
    }

    void setScalarRealtime(int actuatorId, float requestedValue) {
        main.post(() -> setScalarRealtimeOnMain(actuatorId, requestedValue));
    }

    /** Final-value hook. The latest value is already waiting for the next 380 ms scheduler slot. */
    void flushScalarRealtime(int actuatorId) {
        // Intentionally no-op. Never create a second packet on finger release.
    }

    private void setScalarRealtimeOnMain(int actuatorId, float requestedValue) {
        if (!dspReady || txCipher == null) return;
        float safe = DspProtocol.sanitizeScalar(actuatorId, requestedValue);
        if (!Float.isFinite(safe)) return;

        scalarTargets.put(actuatorId, safe);

        if (actuatorId == DspProtocol.ID_TREBLE_BOOST) {
            // V1 Treble-only policy. V1 proved Master/Bass/Middle stable with the 380 ms
            // scheduler, but ID11 still produced severe pumping while dragging. Never feed
            // the raw target directly to ID11. Walk from the last successful hardware value
            // toward the newest target in <=0.5 dB confirmed steps.
            pending.remove("S:" + actuatorId);
            trebleTarget = safe;
            // Do not transmit here. ID11 gets at most one <=0.5 dB step in each existing
            // 380 ms official-style scheduler slot. This keeps the proven V1 cadence while
            // eliminating the large direct target jumps that caused pumping.
            return;
        }

        // Original-app behavior for all other scalar controls: UI can update as often as it
        // wants, but only the newest target is retained and emitted by the shared 380 ms
        // scheduler.
        String key = "S:" + actuatorId;
        pending.remove(key);
        pending.put(key, PendingCommand.scalar(actuatorId, safe));
    }

    void setEqRealtime(int channel0, int uiBand0, float frequency, float gainDb, float q) {
        main.post(() -> {
            if (!dspReady || txCipher == null) return;
            if (channel0 < 0 || channel0 >= 7 || uiBand0 < 0 || uiBand0 >= DspProtocol.EQ_BANDS) return;

            // V1 remains a 15-band 1:1 hardware-record UI. Bands 2..15 use the already
            // runtime-qualified PEAKING writer. The one remaining first band is special on
            // the real DSP and is handled without changing its native filter type.
            int hwBand1 = uiBand0 + 1;
            DspProtocol.EqBand current = eqBands[channel0][uiBand0];
            if (current == null || !isGraphicWritable(uiBand0, current)) return;
            if (!Float.isFinite(gainDb) || gainDb < -12f || gainDb > 12f) return;

            try {
                DspProtocol.EqBand target = (uiBand0 == 0 && current.writableFirstBandSpecial())
                        ? DspProtocol.firstBandGainFromCurrent(current, gainDb)
                        : DspProtocol.peakingFromCurrent(current, gainDb);
                enqueueLatest(PendingCommand.eq(channel0, uiBand0, hwBand1, target));
            } catch (IllegalArgumentException ignored) {
            }
        });
    }

    void reportUnverifiedControl(String name) {
        postMessage(name + " เปลี่ยนค่า UI แล้ว • hardware write ยังล็อกเพราะยังไม่มี packet ที่ยืนยัน");
    }

    void close() {
        closed = true;
        stopScan();
        main.removeCallbacksAndMessages(null);
        resetSessionState();
        if (gatt != null) {
            try { gatt.close(); } catch (Exception ignored) {}
            gatt = null;
        }
        transportConnected = false;
    }

    private boolean hasPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            return context.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
                    context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult result) {
            if (result == null || result.getDevice() == null || closed) return;
            String name = null;
            try {
                if (result.getScanRecord() != null) name = result.getScanRecord().getDeviceName();
                if (name == null) name = result.getDevice().getName();
            } catch (SecurityException ignored) {}
            if (name == null) return;
            String upper = name.toUpperCase(Locale.ROOT);
            if (!(upper.contains("GOLOPINE") || upper.contains("DSP") || upper.contains("OKN"))) return;
            deviceName = name;
            stopScan();
            postStatus("กำลังเชื่อมต่อ...", deviceName, false);
            try {
                closeGattOnly();
                gatt = result.getDevice().connectGatt(context, false, gattCallback, BluetoothDevice.TRANSPORT_LE);
            } catch (SecurityException e) {
                postStatus("เชื่อมต่อไม่ได้: สิทธิ์ไม่ครบ", deviceName, false);
            } catch (RuntimeException e) {
                postStatus("เชื่อมต่อไม่ได้", deviceName, false);
                postMessage("connectGatt error: " + e.getClass().getSimpleName());
            }
        }

        @Override public void onScanFailed(int errorCode) {
            scanning = false;
            postStatus("สแกน BLE ล้มเหลว " + errorCode, deviceName, false);
        }
    };

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt callbackGatt, int status, int newState) {
            if (callbackGatt != gatt) return;
            main.post(() -> {
                if (callbackGatt != gatt) return;
                if (status != BluetoothGatt.GATT_SUCCESS) {
                    transportConnected = false;
                    resetSessionState();
                    postStatus("BLE error " + status + " • กำลังเชื่อมใหม่", deviceName, false);
                    closeGattOnly();
                    if (!closed) main.postDelayed(BleManager.this::startScan, 1500L);
                    return;
                }
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    transportConnected = true;
                    resetSessionState();
                    postStatus("กำลังเตรียม DSP", deviceName, false);
                    try {
                        callbackGatt.requestConnectionPriority(BluetoothGatt.CONNECTION_PRIORITY_BALANCED);
                        callbackGatt.requestMtu(517);
                    } catch (SecurityException ignored) {}
                    main.postDelayed(() -> {
                        if (gatt != callbackGatt || closed) return;
                        try { callbackGatt.discoverServices(); } catch (SecurityException ignored) {}
                    }, 250L);
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    transportConnected = false;
                    resetSessionState();
                    postStatus("ตัดการเชื่อมต่อ • กำลังค้นหาใหม่", deviceName, false);
                    closeGattOnly();
                    if (!closed) main.postDelayed(BleManager.this::startScan, 1500L);
                }
            });
        }

        @Override public void onMtuChanged(BluetoothGatt callbackGatt, int mtu, int status) {
            // Service discovery is scheduled independently so an OEM missing this callback cannot stall startup.
        }

        @Override public void onServicesDiscovered(BluetoothGatt callbackGatt, int status) {
            if (callbackGatt != gatt) return;
            main.post(() -> {
                if (callbackGatt != gatt) return;
                BluetoothGattService service = callbackGatt.getService(AB00);
                ab01 = service == null ? null : service.getCharacteristic(AB01);
                ab02 = service == null ? null : service.getCharacteristic(AB02);
                if (status != BluetoothGatt.GATT_SUCCESS || ab01 == null || ab02 == null) {
                    postStatus("ไม่พบโปรไฟล์ DSP AB00/AB01/AB02", deviceName, false);
                    return;
                }
                postStatus("กำลังเปิดข้อมูล DSP", deviceName, false);
                enableAb02Notifications(callbackGatt, ab02);
            });
        }

        @Override public void onDescriptorWrite(BluetoothGatt callbackGatt, BluetoothGattDescriptor descriptor, int status) {
            if (callbackGatt != gatt) return;
            main.post(() -> {
                if (callbackGatt != gatt) return;
                if (!CCCD.equals(descriptor.getUuid())) return;
                if (status != BluetoothGatt.GATT_SUCCESS) {
                    postStatus("เปิด AB02 Notify ไม่สำเร็จ", deviceName, false);
                    return;
                }
                postStatus("กำลังยืนยัน DSP", deviceName, false);
                main.postDelayed(BleManager.this::startAuthenticatedSession, 120L);
            });
        }

        @Override public void onCharacteristicWrite(BluetoothGatt callbackGatt, BluetoothGattCharacteristic characteristic, int status) {
            if (callbackGatt != gatt || !AB01.equals(characteristic.getUuid())) return;
            final WriteTicket ticket;
            synchronized (writeTickets) {
                ticket = writeTickets.pollFirst();
            }
            main.post(() -> handleWriteResult(ticket, status));
        }

        @Override public void onCharacteristicChanged(BluetoothGatt callbackGatt, BluetoothGattCharacteristic characteristic, byte[] value) {
            if (callbackGatt != gatt || !AB02.equals(characteristic.getUuid())) return;
            byte[] copy = value == null ? new byte[0] : value.clone();
            main.post(() -> handleAb02(copy));
        }

        @SuppressWarnings("deprecation")
        @Override public void onCharacteristicChanged(BluetoothGatt callbackGatt, BluetoothGattCharacteristic characteristic) {
            if (Build.VERSION.SDK_INT >= 33) return;
            if (callbackGatt != gatt || !AB02.equals(characteristic.getUuid())) return;
            byte[] value = characteristic.getValue();
            byte[] copy = value == null ? new byte[0] : value.clone();
            main.post(() -> handleAb02(copy));
        }
    };

    private void enableAb02Notifications(BluetoothGatt g, BluetoothGattCharacteristic ch) {
        if (!hasPermissions()) return;
        try {
            boolean local = g.setCharacteristicNotification(ch, true);
            BluetoothGattDescriptor cccd = ch.getDescriptor(CCCD);
            if (!local || cccd == null) {
                postStatus("เปิด Notify AB02 ไม่สำเร็จ", deviceName, false);
                return;
            }
            if (Build.VERSION.SDK_INT >= 33) {
                int rc = g.writeDescriptor(cccd, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                if (rc != BluetoothStatusCodes.SUCCESS) postStatus("ส่ง CCCD ไม่สำเร็จ " + rc, deviceName, false);
            } else {
                //noinspection deprecation
                cccd.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                //noinspection deprecation
                if (!g.writeDescriptor(cccd)) postStatus("ส่ง CCCD ไม่สำเร็จ", deviceName, false);
            }
        } catch (SecurityException e) {
            postStatus("สิทธิ์ Bluetooth ไม่ครบ", deviceName, false);
        }
    }

    private void startAuthenticatedSession() {
        if (gatt == null || ab01 == null || closed) return;
        resetSessionState();
        waitingAuth = true;
        postStatus("กำลังยืนยัน DSP", deviceName, false);
        if (!writeNoResponse(DspProtocol.AUTH16, "AUTH16", null)) {
            waitingAuth = false;
            postStatus("ส่ง Authentication ไม่สำเร็จ", deviceName, false);
        }
    }

    private void handleAb02(byte[] value) {
        if (waitingAuth) {
            if (value.length != 32) return;
            try {
                DspProtocol.PreAuth auth = DspProtocol.decodeAuth32(value);
                txCipher = new DspProtocol.StreamCipher(auth.randKey, true);
                rxCipher = new DspProtocol.StreamCipher(auth.randKey, false);
                waitingAuth = false;
                postStatus("กำลังโหลดค่า DSP", deviceName, false);
                startDescriptorRequest("INITIAL");
            } catch (Exception e) {
                waitingAuth = false;
                txCipher = null;
                rxCipher = null;
                postStatus("Authentication ไม่ผ่าน", deviceName, false);
                postMessage("Auth decode error: " + e.getClass().getSimpleName());
            }
            return;
        }

        if (rxCipher == null) return;
        final byte[] plain;
        try {
            plain = rxCipher.next(value);
        } catch (RuntimeException e) {
            sessionFault("RX decrypt error");
            return;
        }
        if (readingDescriptor) collectDescriptor(plain);
    }

    private void startDescriptorRequest(String reason) {
        if (txCipher == null || gatt == null || ab01 == null || readingDescriptor) return;
        readingDescriptor = true;
        dspReady = false;
        descriptorExpected = -1;
        descriptorBytes.reset();
        postStatus("กำลังอ่านค่า DSP", deviceName, false);
        byte[] encrypted;
        try { encrypted = txCipher.next(DspProtocol.DEVICE_DESCRIPTION_REQUEST); }
        catch (RuntimeException e) { sessionFault("TX cipher error"); return; }
        if (!writeNoResponse(encrypted, "DESC_" + reason, null)) {
            readingDescriptor = false;
            sessionFault("ส่งคำขอ Device Description ไม่สำเร็จ");
            return;
        }
        cancelDescriptorTimeout();
        descriptorTimeout = () -> {
            if (!readingDescriptor) return;
            readingDescriptor = false;
            descriptorExpected = -1;
            descriptorBytes.reset();
            sessionFault("อ่าน Device Description timeout");
        };
        main.postDelayed(descriptorTimeout, DESCRIPTOR_TIMEOUT_MS);
    }

    private void collectDescriptor(byte[] plain) {
        if (plain == null || plain.length == 0) return;
        if (descriptorExpected < 0) {
            if (plain.length < 4 || (plain[0] & 0xff) != 0x86) return;
            descriptorExpected = (plain[1] & 0xff) | ((plain[2] & 0xff) << 8) | ((plain[3] & 0xff) << 16);
            if (descriptorExpected <= 0 || descriptorExpected > 1024 * 1024) {
                sessionFault("Device Description length ผิดปกติ");
                return;
            }
            descriptorBytes.reset();
            descriptorBytes.write(plain, 4, plain.length - 4);
        } else {
            if ((plain[0] & 0xff) != 0x82) return;
            descriptorBytes.write(plain, 1, plain.length - 1);
        }

        if (descriptorExpected > 0 && descriptorBytes.size() >= descriptorExpected) {
            byte[] all = descriptorBytes.toByteArray();
            byte[] json = new byte[descriptorExpected];
            System.arraycopy(all, 0, json, 0, descriptorExpected);
            readingDescriptor = false;
            descriptorExpected = -1;
            descriptorBytes.reset();
            cancelDescriptorTimeout();
            try {
                loadDescriptor(new JSONObject(new String(json, StandardCharsets.UTF_8)));
            } catch (Exception e) {
                sessionFault("Device Description JSON อ่านไม่ได้: " + e.getClass().getSimpleName());
            }
        }
    }

    private void loadDescriptor(JSONObject obj) {
        scalarValues.clear();
        for (int ch = 0; ch < 7; ch++) {
            for (int b = 0; b < 15; b++) eqBands[ch][b] = null;
        }

        JSONArray actuators = obj.optJSONArray("actuators");
        if (actuators == null) {
            sessionFault("Device Description ไม่มี actuators");
            return;
        }

        int eqCount = 0;
        for (int i = 0; i < actuators.length(); i++) {
            JSONObject a = actuators.optJSONObject(i);
            if (a == null) continue;
            int id = a.optInt("ID", -1);
            int type = a.optInt("type", -1);
            if (DspProtocol.scalarAllowed(id) && type == DspProtocol.TYPE_FLOAT32 && a.has("UFE_TYPE_FLOAT32")) {
                double d = a.optDouble("UFE_TYPE_FLOAT32", Double.NaN);
                if (Double.isFinite(d)) scalarValues.put(id, (float) d);
            }
            int ch = channelForEqActuator(id);
            if (ch >= 0 && type == DspProtocol.TYPE_BIQUAD_CASCADE15_F) {
                JSONArray arr = a.optJSONArray("UFE_TYPE_BIQUAD_CASCADE15_F");
                if (arr != null) {
                    for (int b = 0; b < Math.min(15, arr.length()); b++) {
                        DspProtocol.EqBand band = parseBand(arr.optJSONObject(b));
                        eqBands[ch][b] = band;
                        if (band != null) eqCount++;
                    }
                }
            }
        }

        JSONArray sensors = obj.optJSONArray("sensors");
        int sensorCount = sensors == null ? 0 : sensors.length();
        boolean scalarOk = scalarValues.size() == DspProtocol.VERIFIED_SCALARS.length;
        boolean eqOk = eqCount == 105;
        boolean sensorOk = sensorCount >= 4;

        if (!scalarOk || !eqOk || !sensorOk) {
            dspReady = false;
            postStatus("DSP ข้อมูลไม่ครบ • S" + scalarValues.size() + "/7 EQ" + eqCount + "/105", deviceName, false);
            postMessage("Health Gate ไม่ผ่าน — ยังไม่ส่งคำสั่งเสียง");
            return;
        }

        dspReady = true;
        try {
            BluetoothGatt active = gatt;
            if (active != null) active.requestConnectionPriority(BluetoothGatt.CONNECTION_PRIORITY_BALANCED);
        } catch (Exception ignored) {}
        postStatus("เชื่อมต่อแล้ว", deviceName, true);
        publishDescriptorToUi();
        startOriginalCommandScheduler();
        postMessage("V1 READY • 15-Band EQ • Band 1 filter-aware LIVE on CH1–CH7");
    }

    private DspProtocol.EqBand parseBand(JSONObject b) {
        if (b == null) return null;
        try {
            int type = b.optInt("typ", -1);
            float f = finiteFloat(b, "F");
            float f2 = finiteFloat(b, "F2");
            float q = finiteFloat(b, "Q");
            float boost = finiteFloat(b, "B");
            float gain = finiteFloat(b, "G");
            float r = finiteFloat(b, "R");
            float b0 = finiteFloat(b, "B0");
            float b1 = finiteFloat(b, "B1");
            float b2 = finiteFloat(b, "B2");
            float a1 = finiteFloat(b, "A1");
            float a2 = finiteFloat(b, "A2");
            if (!allFinite(f, f2, q, boost, gain, r, b0, b1, b2, a1, a2)) return null;
            return new DspProtocol.EqBand(type, f, f2, q, boost, gain, r, b0, b1, b2, a1, a2);
        } catch (RuntimeException e) {
            return null;
        }
    }

    private void publishDescriptorToUi() {
        for (Map.Entry<Integer, Float> e : scalarValues.entrySet()) {
            final int id = e.getKey();
            final float value = e.getValue();
            post(() -> listener.onScalarValue(id, value));
        }

        // V1 exposes all 15 real Device-Description records per channel, 1:1.
        // No six-band nearest-frequency remap remains.
        for (int ch = 0; ch < 7; ch++) {
            for (int band0 = 0; band0 < DspProtocol.EQ_BANDS; band0++) {
                DspProtocol.EqBand b = eqBands[ch][band0];
                if (b == null) continue;
                final int fch = ch, fb = band0;
                final float ff = b.frequency, fg = b.graphicGainDb(), fq = b.q;
                final boolean writable = isGraphicWritable(band0, b);
                post(() -> listener.onEqValue(fch, fb, ff, fg, fq, writable));
            }
        }
        scalarTargets.clear();
        scalarTargets.putAll(scalarValues);
    }


    private boolean isGraphicWritable(int band0, DspProtocol.EqBand b) {
        if (b == null) return false;
        if (b.writablePeaking()) return true;
        return band0 == 0 && b.writableFirstBandSpecial();
    }

    private int channelForEqActuator(int id) {
        for (int ch = 0; ch < DspProtocol.EQ_ACTUATORS.length; ch++) if (DspProtocol.EQ_ACTUATORS[ch] == id) return ch;
        return -1;
    }

    private void enqueueLatest(PendingCommand c) {
        if (!dspReady || txCipher == null) return;
        pending.remove(c.key);
        pending.put(c.key, c);
        // Do not transmit here. The official 250401 app serializes all AB01 application
        // traffic through one ~380 ms scheduler.
    }

    private void startOriginalCommandScheduler() {
        stopOriginalCommandScheduler();
        trebleTarget = null;
        originalPollIndex = 0;
        originalCommandScheduler = new Runnable() {
            @Override public void run() {
                if (originalCommandScheduler != this || closed) return;
                if (dspReady && txCipher != null) originalCommandSchedulerTick();
                if (originalCommandScheduler == this && !closed) {
                    main.postDelayed(this, ORIGINAL_COMMAND_CADENCE_MS);
                }
            }
        };
        main.postDelayed(originalCommandScheduler, ORIGINAL_COMMAND_CADENCE_MS);
    }

    private void stopOriginalCommandScheduler() {
        if (originalCommandScheduler != null) main.removeCallbacks(originalCommandScheduler);
        originalCommandScheduler = null;
        originalPollIndex = 0;
    }

    private void originalCommandSchedulerTick() {
        if (!dspReady || txCipher == null || readingDescriptor || liveWriteBusy) return;

        // V1 Treble safety: preserve the exact shared 380 ms command cadence, but never
        // send the raw ID11 target. Advance by at most 0.5 dB from the last successful live
        // value. A Treble step occupies the same single scheduler slot that a normal control
        // write would occupy; no extra high-rate stream is created.
        if (trebleTarget != null) {
            Float currentObj = scalarValues.get(DspProtocol.ID_TREBLE_BOOST);
            if (currentObj != null && Float.isFinite(currentObj)) {
                float diff = trebleTarget - currentObj;
                if (Math.abs(diff) <= 0.001f) {
                    trebleTarget = null;
                } else {
                    float step = Math.min(TREBLE_MAX_STEP_DB, Math.abs(diff));
                    float nextValue = currentObj + Math.copySign(step, diff);
                    nextValue = DspProtocol.sanitizeScalar(DspProtocol.ID_TREBLE_BOOST, nextValue);
                    if (!Float.isFinite(nextValue)) {
                        sessionFault("Treble target out of range");
                        return;
                    }
                    sendScheduledControl(PendingCommand.scalar(DspProtocol.ID_TREBLE_BOOST, nextValue));
                    return;
                }
            }
        }

        PendingCommand next = null;
        if (!pending.isEmpty()) {
            Iterator<Map.Entry<String, PendingCommand>> it = pending.entrySet().iterator();
            next = it.next().getValue();
            it.remove();
        }

        if (next != null) {
            sendScheduledControl(next);
            return;
        }

        // Exact poll cycle decrypted from the official app trace:
        // 58 + ID19 len1, ID20 len1, ID0 len4, ID21 len4, repeating.
        int idx = originalPollIndex % ORIGINAL_POLL_IDS.length;
        int id = ORIGINAL_POLL_IDS[idx];
        int len = ORIGINAL_POLL_LENGTHS[idx];
        originalPollIndex = (originalPollIndex + 1) % ORIGINAL_POLL_IDS.length;
        byte[] plain = DspProtocol.encodeRead(id, 0, len);
        final byte[] encrypted;
        try {
            encrypted = txCipher.next(plain);
        } catch (RuntimeException e) {
            sessionFault("TX poll encryption failed");
            return;
        }
        if (!writeNoResponse(encrypted, "POLL_" + id, null)) {
            sessionFault("BLE ไม่รับ sensor keepalive");
        }
    }

    private void sendScheduledControl(PendingCommand next) {
        final byte[] encrypted;
        try {
            encrypted = txCipher.next(next.plain);
        } catch (RuntimeException e) {
            sessionFault("TX encryption failed");
            return;
        }
        liveWriteBusy = true;
        liveInflight = next;
        if (!writeNoResponse(encrypted, "SCHEDULED_" + next.key, next)) {
            liveWriteBusy = false;
            liveInflight = null;
            sessionFault("BLE ไม่รับคำสั่ง DSP");
            return;
        }
        cancelLiveTimeout();
        final PendingCommand expected = next;
        liveWriteTimeout = () -> {
            if (!liveWriteBusy || liveInflight != expected) return;
            sessionFault("DSP command callback timeout");
        };
        main.postDelayed(liveWriteTimeout, LIVE_WRITE_TIMEOUT_MS);
    }

    private void handleWriteResult(WriteTicket ticket, int status) {
        if (ticket == null || ticket.command == null) return;
        PendingCommand cmd = ticket.command;
        if (liveInflight != cmd) return;
        cancelLiveTimeout();
        liveWriteBusy = false;
        liveInflight = null;
        if (status != BluetoothGatt.GATT_SUCCESS) {
            sessionFault("GATT write failed " + status);
            return;
        }

        if (cmd.scalarId >= 0) {
            scalarValues.put(cmd.scalarId, cmd.scalarValue);
            if (cmd.scalarId == DspProtocol.ID_TREBLE_BOOST) {
                // Keep only the final target; the next <=0.5 dB step, if still needed, waits
                // for the next 380 ms scheduler slot. No callback-triggered immediate write.
                if (trebleTarget != null && Math.abs(trebleTarget - cmd.scalarValue) <= 0.001f) {
                    trebleTarget = null;
                }
                return;
            }
        } else if (cmd.eqTarget != null && cmd.channel0 >= 0 && cmd.hwBand1 > 0) {
            eqBands[cmd.channel0][cmd.hwBand1 - 1] = cmd.eqTarget;
        }
        // Non-Treble commands wait for the next official-style 380 ms scheduler slot.
    }

    private boolean writeNoResponse(byte[] bytes, String label, PendingCommand liveCommand) {
        BluetoothGatt g = gatt;
        BluetoothGattCharacteristic ch = ab01;
        if (g == null || ch == null || !hasPermissions()) return false;
        WriteTicket ticket = new WriteTicket(label, liveCommand);
        synchronized (writeTickets) { writeTickets.addLast(ticket); }
        boolean ok = false;
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                ok = g.writeCharacteristic(ch, bytes, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE) == BluetoothStatusCodes.SUCCESS;
            } else {
                //noinspection deprecation
                ch.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE);
                //noinspection deprecation
                ch.setValue(bytes);
                //noinspection deprecation
                ok = g.writeCharacteristic(ch);
            }
        } catch (RuntimeException ignored) {
            ok = false;
        }
        if (!ok) {
            synchronized (writeTickets) {
                if (!writeTickets.isEmpty() && writeTickets.peekLast() == ticket) writeTickets.removeLast();
            }
        }
        return ok;
    }

    private void sessionFault(String reason) {
        dspReady = false;
        readingDescriptor = false;
        waitingAuth = false;
        pending.clear();
        liveWriteBusy = false;
        liveInflight = null;
        cancelDescriptorTimeout();
        cancelLiveTimeout();
        stopOriginalCommandScheduler();
        trebleTarget = null;
        scalarTargets.clear();
        postStatus("DSP session หยุด • กำลังเชื่อมใหม่", deviceName, false);
        postMessage(reason);
        // CFB8 is a continuous stream. Once ordering is uncertain, fail closed and
        // make a fresh GATT/auth session instead of trying to reuse any cipher state.
        txCipher = null;
        rxCipher = null;
        transportConnected = false;
        BluetoothGatt old = gatt;
        gatt = null;
        ab01 = null;
        ab02 = null;
        if (old != null) {
            try { old.disconnect(); } catch (RuntimeException ignored) {}
            try { old.close(); } catch (RuntimeException ignored) {}
        }
        if (!closed) main.postDelayed(this::startScan, 900L);
    }

    private void resetSessionState() {
        dspReady = false;
        waitingAuth = false;
        readingDescriptor = false;
        txCipher = null;
        rxCipher = null;
        descriptorExpected = -1;
        descriptorBytes.reset();
        scalarValues.clear();
        pending.clear();
        liveWriteBusy = false;
        liveInflight = null;
        synchronized (writeTickets) { writeTickets.clear(); }
        cancelDescriptorTimeout();
        cancelLiveTimeout();
        stopOriginalCommandScheduler();
        trebleTarget = null;
        scalarTargets.clear();
    }

    private void closeGattOnly() {
        BluetoothGatt old = gatt;
        gatt = null;
        ab01 = null;
        ab02 = null;
        if (old != null) try { old.close(); } catch (Exception ignored) {}
    }

    private void cancelDescriptorTimeout() {
        if (descriptorTimeout != null) main.removeCallbacks(descriptorTimeout);
        descriptorTimeout = null;
    }

    private void cancelLiveTimeout() {
        if (liveWriteTimeout != null) main.removeCallbacks(liveWriteTimeout);
        liveWriteTimeout = null;
    }

    private float finiteFloat(JSONObject o, String key) {
        double d = o.optDouble(key, Double.NaN);
        return Double.isFinite(d) ? (float) d : Float.NaN;
    }

    private boolean allFinite(float... values) {
        for (float v : values) if (!Float.isFinite(v)) return false;
        return true;
    }

    private void postStatus(String status, String name, boolean ready) {
        post(() -> listener.onBleStatus(status, name, ready));
    }

    private void postMessage(String message) {
        post(() -> listener.onBleMessage(message));
    }

    private void post(Runnable r) {
        if (Looper.myLooper() == Looper.getMainLooper()) r.run();
        else main.post(r);
    }
}
