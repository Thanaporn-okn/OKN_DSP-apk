package com.okn.dsp;

import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.Locale;

/**
 * OKN DSP — Version 1 / Phase 1 UI.
 *
 * The entire interface is built with Android views and custom drawing. The uploaded screenshots
 * are reference material only and are not used as page backgrounds or runtime UI bitmaps.
 */
public final class MainActivity extends Activity {
    private static final int PAGE_HOME = 0;
    private static final int PAGE_MIX = 1;
    private static final int PAGE_EQ = 2;

    private AppState state;
    private ThemeColors c;
    private FrameLayout pageHost;
    private int currentPage = PAGE_HOME;
    private float density;

    // EQ live bindings. These are intentionally kept as direct references so graph/slider changes
    // can update each other immediately without rebuilding the page or adding artificial delay.
    private EqGraphView eqGraph;
    private TextView bandTitle;
    private EqControl freqControl;
    private EqControl qControl;
    private EqControl gainControl;
    private EqControl chVolumeControl;
    private boolean bindingEqControls;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        density = getResources().getDisplayMetrics().density;
        state = new AppState(this);
        buildApp();
    }

    private void buildApp() {
        c = new ThemeColors(state.isDarkTheme());
        applySystemBars();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(c.bg);

        pageHost = new FrameLayout(this);
        LinearLayout.LayoutParams hostLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        root.addView(pageHost, hostLp);
        root.addView(buildBottomNav(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(84)));

        setContentView(root);
        showPage(currentPage);
    }

    private void applySystemBars() {
        Window w = getWindow();
        w.setStatusBarColor(c.bg);
        w.setNavigationBarColor(c.bg);
        int flags = 0;
        if (!c.dark) flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        w.getDecorView().setSystemUiVisibility(flags);
    }

    private void showPage(int page) {
        currentPage = page;
        eqGraph = null;
        freqControl = null;
        qControl = null;
        gainControl = null;
        chVolumeControl = null;

        pageHost.removeAllViews();
        View pageView;
        if (page == PAGE_MIX) pageView = buildMixPage();
        else if (page == PAGE_EQ) pageView = buildEqPage();
        else pageView = buildHomePage();
        pageHost.addView(pageView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        ViewGroup root = (ViewGroup) pageHost.getParent();
        if (root != null && root.getChildCount() > 1) {
            root.removeViewAt(1);
            root.addView(buildBottomNav(), new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(84)));
        }
    }

    private View buildHomePage() {
        LinearLayout body = newPageBody();
        body.addView(buildHeader("OKN DSP", "DSP Controller"));
        addSpace(body, 18);

        LinearLayout ready = card(true);
        ready.setPadding(dp(18), dp(18), dp(18), dp(18));
        ready.setOrientation(LinearLayout.HORIZONTAL);
        ready.setGravity(Gravity.CENTER_VERTICAL);

        TextView check = bubble("✓", c.green, 54, 25);
        ready.addView(check, new LinearLayout.LayoutParams(dp(64), dp(64)));
        LinearLayout readyText = column();
        readyText.setPadding(dp(14), 0, dp(8), 0);
        readyText.addView(label("SYSTEM STATUS", 12, c.secondary, false));
        TextView r1 = label("UI Ready", 23, c.text, true);
        readyText.addView(r1);
        readyText.addView(label("Phase 1 controls active • values auto-saved", 14, c.secondary, false));
        ready.addView(readyText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        ready.addView(label("›", 34, c.secondary, false));
        ready.setOnClickListener(v -> showPhaseInfo());
        body.addView(ready, matchCardLp());

        addSpace(body, 28);
        LinearLayout sectionRow = row();
        sectionRow.setGravity(Gravity.CENTER_VERTICAL);
        sectionRow.addView(label("Connection & Status", 23, c.text, true), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView allGood = label("Phase 1  ●", 14, c.blue, true);
        sectionRow.addView(allGood);
        body.addView(sectionRow, matchCardLpNoTop());
        addSpace(body, 12);

        body.addView(statusRow("B", c.blue, "Bluetooth", "Open Android Bluetooth settings", "Setup", c.blue,
                () -> openBluetoothSettings()), matchCardLp());
        addSpace(body, 10);
        body.addView(statusRow("DSP", c.purple, "DSP Device", "Protocol integration starts in Phase 2", "Pending", c.orange,
                this::showPhaseInfo), matchCardLp());
        addSpace(body, 10);
        body.addView(statusRow("≋", c.orange, "Audio Input", "UI path prepared for real-time input state", "UI Active", c.blue,
                this::showPhaseInfo), matchCardLp());
        addSpace(body, 10);
        body.addView(statusRow("◀", c.pink, "Amplifier Link", "External amplifier integration", "Phase 2", c.secondary,
                this::showPhaseInfo), matchCardLp());
        addSpace(body, 10);
        body.addView(statusRow("≡", c.cyan, "Preset Sync", "Local presets persist automatically", "Local", c.green,
                () -> showPage(PAGE_EQ)), matchCardLp());
        addSpace(body, 10);
        body.addView(statusRow("⚙", c.purple, "Firmware Status", "Hardware query is reserved for Phase 2", "N/A", c.secondary,
                this::showPhaseInfo), matchCardLp());

        addSpace(body, 18);
        body.addView(statusRow("▥", c.blue, "Quick Control", "Adjust volume, bass, channels and EQ", "›", c.secondary,
                () -> showPage(PAGE_MIX)), matchCardLp());
        addSpace(body, 28);
        return wrapScrollable(body);
    }

    private View buildMixPage() {
        LinearLayout body = newPageBody();
        body.addView(buildHeader("Mix", "Channel and bass controls"));
        addSpace(body, 18);

        LinearLayout global = card(false);
        global.setOrientation(LinearLayout.VERTICAL);
        addCardSectionHeader(global, "Global", "Overall output and bass settings");
        global.addView(divider());
        global.addView(sliderRow("♪", c.blue, "Master Volume", -60f, 12f, 0.5f,
                state.getMasterVolume(), this::formatDb, state::setMasterVolume));
        global.addView(dividerWithMargins());
        global.addView(sliderRow("≋", c.orange, "Bass Volume", -12f, 12f, 0.5f,
                state.getBassVolume(), this::formatDb, state::setBassVolume));
        global.addView(dividerWithMargins());
        global.addView(sliderRow("▼", c.purple, "Bass Cutoff", 40f, 250f, 1f,
                state.getBassCutoff(), v -> Math.round(v) + " Hz", state::setBassCutoff));
        body.addView(global, matchCardLp());

        addSpace(body, 20);
        LinearLayout channels = card(false);
        channels.setOrientation(LinearLayout.VERTICAL);
        addCardSectionHeader(channels, "Channels", "Individual channel levels");
        int[] chColors = {c.blue, c.green, c.orange, c.pink, c.purple, c.cyan, c.purple};
        for (int ch = 0; ch < AppState.CHANNELS; ch++) {
            if (ch > 0) channels.addView(dividerWithMargins());
            final int channel = ch;
            channels.addView(sliderRow(Integer.toString(ch + 1), chColors[ch], "Volume Ch" + (ch + 1),
                    -12f, 12f, 0.5f, state.getChannelVolume(ch), this::formatDb,
                    value -> state.setChannelVolume(channel, value)));
        }
        body.addView(channels, matchCardLp());
        addSpace(body, 28);
        return wrapScrollable(body);
    }

    private View buildEqPage() {
        LinearLayout body = newPageBody();
        body.addView(buildHeader("Eq", "15-band equalizer • 7 channels"));
        addSpace(body, 14);
        body.addView(buildChannelTabs(), matchCardLpNoTop());
        addSpace(body, 14);

        int channel = state.getSelectedChannel();
        int band = state.getSelectedBand();

        LinearLayout graphCard = card(false);
        graphCard.setOrientation(LinearLayout.VERTICAL);
        LinearLayout graphHeader = row();
        graphHeader.setGravity(Gravity.CENTER_VERTICAL);
        graphHeader.setPadding(dp(18), dp(16), dp(14), dp(8));
        LinearLayout graphTitle = column();
        graphTitle.addView(label("Channel " + (channel + 1), 22, c.text, true));
        graphTitle.addView(label(channelName(channel) + "  •  15-band EQ", 13, c.secondary, false));
        graphHeader.addView(graphTitle, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button reset = softButton("↻  Reset EQ", false);
        reset.setOnClickListener(v -> {
            state.resetEq(state.getSelectedChannel());
            updateEqControlValues();
            if (eqGraph != null) eqGraph.refresh();
            toast("Channel EQ reset");
        });
        graphHeader.addView(reset, new LinearLayout.LayoutParams(dp(132), dp(46)));
        graphCard.addView(graphHeader);

        eqGraph = new EqGraphView(this, state, channel, band, c.dark);
        eqGraph.setListener(new EqGraphView.Listener() {
            @Override public void onBandSelected(int newBand) {
                state.setSelectedBand(newBand);
                if (bandTitle != null) bandTitle.setText("Band " + (newBand + 1));
                updateEqControlValues();
            }

            @Override public void onBandDragged(int b, float frequencyHz, float gainDb) {
                state.setSelectedBand(b);
                if (bandTitle != null) bandTitle.setText("Band " + (b + 1));
                updateEqControlValues();
            }
        });
        graphCard.addView(eqGraph, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(isTablet() ? 350 : 292)));
        body.addView(graphCard, matchCardLp());

        addSpace(body, 16);
        body.addView(buildBandControlCard(), matchCardLp());

        addSpace(body, 16);
        body.addView(buildPresetCard(), matchCardLp());
        addSpace(body, 28);
        return wrapScrollable(body);
    }

    private View buildBandControlCard() {
        int band = state.getSelectedBand();
        LinearLayout card = card(false);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(16));

        LinearLayout header = row();
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView bandBubble = bubble(Integer.toString(band + 1), c.blue, 48, 20);
        header.addView(bandBubble, new LinearLayout.LayoutParams(dp(52), dp(52)));
        LinearLayout titleCol = column();
        titleCol.setPadding(dp(12), 0, 0, 0);
        bandTitle = label("Band " + (band + 1), 20, c.text, true);
        titleCol.addView(bandTitle);
        titleCol.addView(label("Drag a graph point or use the controls below", 13, c.secondary, false));
        header.addView(titleCol, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button prev = roundTextButton("‹");
        Button next = roundTextButton("›");
        prev.setOnClickListener(v -> selectBand(Math.max(0, state.getSelectedBand() - 1)));
        next.setOnClickListener(v -> selectBand(Math.min(AppState.BANDS - 1, state.getSelectedBand() + 1)));
        header.addView(prev, new LinearLayout.LayoutParams(dp(46), dp(46)));
        addSpaceHorizontal(header, 7);
        header.addView(next, new LinearLayout.LayoutParams(dp(46), dp(46)));
        card.addView(header);
        addSpace(card, 12);

        freqControl = addEqFrequencyControl(card);
        addSpace(card, 12);
        qControl = addEqLinearControl(card, "Q", "Q (Quality Factor)", 0.1f, 10f, 0.01f,
                state.getBandQ(state.getSelectedChannel(), state.getSelectedBand()),
                v -> String.format(Locale.US, "%.2f", v),
                v -> state.setBandQ(state.getSelectedChannel(), state.getSelectedBand(), v));
        addSpace(card, 12);
        gainControl = addEqLinearControl(card, "G", "Band Gain", -12f, 12f, 0.1f,
                state.getBandGain(state.getSelectedChannel(), state.getSelectedBand()),
                this::formatDbOne,
                v -> state.setBandGain(state.getSelectedChannel(), state.getSelectedBand(), v));
        addSpace(card, 12);
        chVolumeControl = addEqLinearControl(card, "♪", "Ch Volume", -12f, 12f, 0.1f,
                state.getChannelVolume(state.getSelectedChannel()),
                this::formatDbOne,
                v -> state.setChannelVolume(state.getSelectedChannel(), v));
        return card;
    }

    private View buildPresetCard() {
        LinearLayout card = card(false);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));

        LinearLayout top = row();
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(bubble("≡", c.cyan, 46, 20), new LinearLayout.LayoutParams(dp(50), dp(50)));
        LinearLayout t = column();
        t.setPadding(dp(10), 0, 0, 0);
        t.addView(label("Presets", 20, c.text, true));
        t.addView(label("Save and load all UI control values", 13, c.secondary, false));
        top.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        card.addView(top);
        addSpace(card, 14);

        LinearLayout saveRow = row();
        EditText name = new EditText(this);
        name.setHint("Preset name");
        name.setTextColor(c.text);
        name.setHintTextColor(c.secondary);
        name.setSingleLine(true);
        name.setTextSize(14);
        name.setPadding(dp(14), 0, dp(14), 0);
        name.setBackground(rounded(c.field, dp(14), c.border, 1));
        saveRow.addView(name, new LinearLayout.LayoutParams(0, dp(52), 1f));
        addSpaceHorizontal(saveRow, 10);
        Button save = primaryButton("Save Preset");
        save.setOnClickListener(v -> {
            String presetName = name.getText().toString().trim();
            if (presetName.isEmpty()) {
                toast("Enter a preset name");
                return;
            }
            if ("Flat".equalsIgnoreCase(presetName)) {
                toast("Flat is the built-in reset preset; choose another name");
                return;
            }
            state.savePreset(presetName);
            toast("Preset saved: " + presetName);
            showPage(PAGE_EQ);
        });
        saveRow.addView(save, new LinearLayout.LayoutParams(dp(isTablet() ? 190 : 150), dp(52)));
        card.addView(saveRow);

        addSpace(card, 14);
        card.addView(label("Load Preset", 13, c.secondary, false));
        addSpace(card, 6);
        LinearLayout loadRow = row();
        List<String> names = state.listPresets();
        names.add(0, "Flat");
        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, names) {
            @Override public View getView(int position, View convertView, ViewGroup parent) {
                TextView v = (TextView) super.getView(position, convertView, parent);
                v.setTextColor(c.text);
                v.setTextSize(14);
                v.setPadding(dp(12), 0, dp(12), 0);
                return v;
            }
        };
        spinner.setAdapter(adapter);
        spinner.setBackground(rounded(c.field, dp(14), c.border, 1));
        loadRow.addView(spinner, new LinearLayout.LayoutParams(0, dp(52), 1f));
        addSpaceHorizontal(loadRow, 10);
        Button load = softButton("Load", false);
        load.setOnClickListener(v -> {
            String selected = String.valueOf(spinner.getSelectedItem());
            boolean ok;
            if ("Flat".equals(selected)) {
                state.resetControlsKeepThemeAndPresets();
                ok = true;
            } else {
                ok = state.loadPreset(selected);
            }
            if (ok) {
                toast("Preset loaded: " + selected);
                showPage(PAGE_EQ);
            } else toast("Preset could not be loaded");
        });
        loadRow.addView(load, new LinearLayout.LayoutParams(dp(112), dp(52)));
        card.addView(loadRow);
        return card;
    }

    private EqControl addEqFrequencyControl(LinearLayout parent) {
        int ch = state.getSelectedChannel();
        int band = state.getSelectedBand();
        EqControl control = eqControlShell(parent, "∿", "Frequency", "20 Hz", "20 kHz");
        control.seek.setMax(1000);
        control.seek.setProgress(freqToProgress(state.getBandFrequency(ch, band)));
        control.value.setText(formatHz(state.getBandFrequency(ch, band)));
        control.seek.setOnSeekBarChangeListener(new SimpleSeekListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser || bindingEqControls) return;
                float freq = progressToFreq(progress);
                state.setBandFrequency(state.getSelectedChannel(), state.getSelectedBand(), freq);
                control.value.setText(formatHz(state.getBandFrequency(state.getSelectedChannel(), state.getSelectedBand())));
                if (eqGraph != null) eqGraph.refresh();
            }
        });
        return control;
    }

    private EqControl addEqLinearControl(LinearLayout parent, String icon, String title,
                                         float min, float max, float step, float initial,
                                         ValueFormatter formatter, ValueConsumer consumer) {
        EqControl control = eqControlShell(parent, icon, title, formatter.format(min), formatter.format(max));
        int steps = Math.round((max - min) / step);
        control.seek.setMax(steps);
        control.seek.setProgress(Math.round((initial - min) / step));
        control.value.setText(formatter.format(initial));
        control.seek.setOnSeekBarChangeListener(new SimpleSeekListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser || bindingEqControls) return;
                float value = min + progress * step;
                value = Math.round(value / step) * step;
                consumer.accept(value);
                control.value.setText(formatter.format(value));
                if (eqGraph != null) eqGraph.refresh();
            }
        });
        return control;
    }

    private EqControl eqControlShell(LinearLayout parent, String icon, String title, String minText, String maxText) {
        LinearLayout row = row();
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView bubble = bubble(icon, c.field, 38, 16);
        bubble.setTextColor(c.secondary);
        row.addView(bubble, new LinearLayout.LayoutParams(dp(42), dp(42)));

        LinearLayout center = column();
        center.setPadding(dp(10), 0, 0, 0);
        TextView titleV = label(title, 14, c.text, true);
        center.addView(titleV);

        SeekBar seek = new SeekBar(this);
        styleSeekBar(seek);
        center.addView(seek, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(34)));
        LinearLayout scale = row();
        TextView min = label(minText, 11, c.secondary, false);
        TextView max = label(maxText, 11, c.secondary, false);
        scale.addView(min, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        max.setGravity(Gravity.END);
        scale.addView(max, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        center.addView(scale);
        row.addView(center, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView value = label("", 14, c.text, false);
        value.setGravity(Gravity.CENTER);
        value.setBackground(rounded(c.field, dp(13), 0, 0));
        LinearLayout.LayoutParams valueLp = new LinearLayout.LayoutParams(dp(104), dp(40));
        valueLp.setMargins(dp(10), 0, 0, 0);
        row.addView(value, valueLp);
        parent.addView(row);
        return new EqControl(seek, value);
    }

    private void selectBand(int band) {
        state.setSelectedBand(band);
        if (bandTitle != null) bandTitle.setText("Band " + (band + 1));
        if (eqGraph != null) eqGraph.setSelectedBand(band);
        updateEqControlValues();
    }

    private void updateEqControlValues() {
        if (freqControl == null || qControl == null || gainControl == null || chVolumeControl == null) return;
        bindingEqControls = true;
        try {
            int ch = state.getSelectedChannel();
            int band = state.getSelectedBand();
            float f = state.getBandFrequency(ch, band);
            float q = state.getBandQ(ch, band);
            float g = state.getBandGain(ch, band);
            float cv = state.getChannelVolume(ch);

            freqControl.seek.setProgress(freqToProgress(f));
            freqControl.value.setText(formatHz(f));
            qControl.seek.setProgress(Math.round((q - 0.1f) / 0.01f));
            qControl.value.setText(String.format(Locale.US, "%.2f", q));
            gainControl.seek.setProgress(Math.round((g + 12f) / 0.1f));
            gainControl.value.setText(formatDbOne(g));
            chVolumeControl.seek.setProgress(Math.round((cv + 12f) / 0.1f));
            chVolumeControl.value.setText(formatDbOne(cv));
            if (eqGraph != null) {
                eqGraph.setSelectedBand(band);
                eqGraph.refresh();
            }
        } finally {
            bindingEqControls = false;
        }
    }

    private View buildChannelTabs() {
        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        LinearLayout row = row();
        row.setPadding(0, dp(2), 0, dp(2));
        int selected = state.getSelectedChannel();
        for (int ch = 0; ch < AppState.CHANNELS; ch++) {
            final int channel = ch;
            TextView pill = label("Ch" + (ch + 1), 14, ch == selected ? Color.WHITE : c.secondary, ch == selected);
            pill.setGravity(Gravity.CENTER);
            pill.setBackground(rounded(ch == selected ? c.blue : c.card, dp(24), c.border, ch == selected ? 0 : 1));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(78), dp(48));
            if (ch > 0) lp.setMargins(dp(8), 0, 0, 0);
            row.addView(pill, lp);
            pill.setOnClickListener(v -> {
                state.setSelectedChannel(channel);
                showPage(PAGE_EQ);
            });
        }
        scroll.addView(row, new HorizontalScrollView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return scroll;
    }

    private View buildHeader(String title, String subtitle) {
        LinearLayout header = row();
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(4), dp(18), dp(4), 0);
        LinearLayout titles = column();
        titles.addView(label(title, isTablet() ? 38 : 32, c.text, true));
        titles.addView(label(subtitle, 15, c.secondary, false));
        header.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        ImageButton search = iconButton(com.okn.dsp.R.drawable.ic_search);
        search.setContentDescription("Search");
        search.setOnClickListener(v -> showSearchDialog());
        header.addView(search, new LinearLayout.LayoutParams(dp(50), dp(50)));
        addSpaceHorizontal(header, 8);
        ImageButton more = iconButton(com.okn.dsp.R.drawable.ic_more);
        more.setContentDescription("More options");
        more.setOnClickListener(this::showMoreMenu);
        header.addView(more, new LinearLayout.LayoutParams(dp(50), dp(50)));
        return header;
    }

    private View statusRow(String icon, int iconColor, String title, String subtitle,
                           String status, int statusColor, Runnable action) {
        LinearLayout card = card(false);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        card.addView(bubble(icon, iconColor, 48, icon.length() > 1 ? 12 : 20), new LinearLayout.LayoutParams(dp(54), dp(54)));
        LinearLayout texts = column();
        texts.setPadding(dp(12), 0, dp(8), 0);
        texts.addView(label(title, 17, c.text, true));
        texts.addView(label(subtitle, 13, c.secondary, false));
        card.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView s = label(status, 13, statusColor, true);
        s.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        card.addView(s, new LinearLayout.LayoutParams(dp(88), ViewGroup.LayoutParams.WRAP_CONTENT));
        TextView arrow = label("›", 28, c.secondary, false);
        arrow.setGravity(Gravity.CENTER);
        card.addView(arrow, new LinearLayout.LayoutParams(dp(24), dp(44)));
        card.setOnClickListener(v -> action.run());
        return card;
    }

    private View sliderRow(String icon, int iconColor, String title,
                           float min, float max, float step, float initial,
                           ValueFormatter formatter, ValueConsumer consumer) {
        LinearLayout outer = row();
        outer.setGravity(Gravity.CENTER_VERTICAL);
        outer.setPadding(dp(14), dp(10), dp(14), dp(10));
        outer.addView(bubble(icon, soften(iconColor), 46, icon.length() > 1 ? 14 : 18),
                new LinearLayout.LayoutParams(dp(52), dp(52)));
        LinearLayout center = column();
        center.setPadding(dp(10), 0, 0, 0);
        center.addView(label(title, 15, c.text, true));
        SeekBar seek = new SeekBar(this);
        int steps = Math.max(1, Math.round((max - min) / step));
        seek.setMax(steps);
        seek.setProgress(Math.round((initial - min) / step));
        styleSeekBar(seek);
        center.addView(seek, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38)));
        outer.addView(center, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView value = label(formatter.format(initial), 14, c.text, false);
        value.setGravity(Gravity.CENTER);
        value.setBackground(rounded(c.field, dp(13), 0, 0));
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(dp(100), dp(48));
        vp.setMargins(dp(8), 0, 0, 0);
        outer.addView(value, vp);
        seek.setOnSeekBarChangeListener(new SimpleSeekListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser) return;
                float v = min + progress * step;
                v = Math.round(v / step) * step;
                consumer.accept(v);
                value.setText(formatter.format(v));
            }
        });
        return outer;
    }

    private View buildBottomNav() {
        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.HORIZONTAL);
        shell.setGravity(Gravity.CENTER);
        shell.setPadding(dp(18), dp(6), dp(18), dp(12));
        shell.setBackgroundColor(c.bg);

        LinearLayout bar = row();
        bar.setGravity(Gravity.CENTER);
        bar.setPadding(dp(8), dp(6), dp(8), dp(6));
        bar.setBackground(rounded(c.card, dp(26), c.border, 1));
        bar.setElevation(dpF(4));
        shell.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(66)));

        addNavItem(bar, PAGE_HOME, com.okn.dsp.R.drawable.ic_home, "Home");
        addNavItem(bar, PAGE_MIX, com.okn.dsp.R.drawable.ic_mix, "Mix");
        addNavItem(bar, PAGE_EQ, com.okn.dsp.R.drawable.ic_eq, "Eq");
        return shell;
    }

    private void addNavItem(LinearLayout bar, int page, int iconRes, String text) {
        boolean selected = currentPage == page;
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        item.setPadding(dp(5), dp(4), dp(5), dp(3));
        if (selected) item.setBackground(rounded(c.selected, dp(20), 0, 0));
        ImageView icon = new ImageView(this);
        icon.setImageResource(iconRes);
        icon.setColorFilter(selected ? c.blue : c.secondary);
        item.addView(icon, new LinearLayout.LayoutParams(dp(25), dp(25)));
        TextView title = label(text, 12, selected ? c.blue : c.secondary, selected);
        title.setGravity(Gravity.CENTER);
        item.addView(title);
        item.setOnClickListener(v -> showPage(page));
        bar.addView(item, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
    }

    private void addCardSectionHeader(LinearLayout card, String title, String subtitle) {
        LinearLayout row = row();
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(15), dp(16), dp(13));
        row.addView(label(title, 21, c.text, true), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView sub = label(subtitle, 12, c.secondary, false);
        sub.setGravity(Gravity.END);
        row.addView(sub);
        card.addView(row);
    }

    private void showMoreMenu(View anchor) {
        PopupMenu popup = new PopupMenu(this, anchor);
        popup.getMenu().add(state.isDarkTheme() ? "Switch to Light theme" : "Switch to Dark theme");
        popup.getMenu().add("Reset local controls");
        popup.getMenu().add("About Version 1");
        popup.setOnMenuItemClickListener(item -> {
            String title = item.getTitle().toString();
            if (title.startsWith("Switch")) {
                state.setDarkTheme(!state.isDarkTheme());
                buildApp();
            } else if (title.startsWith("Reset")) {
                new AlertDialog.Builder(this)
                        .setTitle("Reset controls?")
                        .setMessage("Master, bass, channels and EQ values will return to defaults. Saved presets and theme are kept.")
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("Reset", (d, w) -> {
                            state.resetControlsKeepThemeAndPresets();
                            showPage(currentPage);
                            toast("Controls reset");
                        }).show();
            } else showPhaseInfo();
            return true;
        });
        popup.show();
    }

    private void showSearchDialog() {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setHint("Try: master, bass, channel, EQ, Q, preset");
        input.setPadding(dp(18), dp(4), dp(18), dp(4));
        new AlertDialog.Builder(this)
                .setTitle("Search controls")
                .setView(input)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Go", (d, w) -> {
                    String q = input.getText().toString().trim().toLowerCase(Locale.US);
                    if (q.contains("eq") || q.contains("frequency") || q.equals("q") || q.contains("preset") || q.contains("band")) {
                        showPage(PAGE_EQ);
                    } else if (q.contains("volume") || q.contains("bass") || q.contains("mix") || q.contains("channel")) {
                        showPage(PAGE_MIX);
                    } else {
                        showPage(PAGE_HOME);
                        if (!q.isEmpty()) toast("Showing Home; no closer control match");
                    }
                }).show();
    }

    private void showPhaseInfo() {
        new AlertDialog.Builder(this)
                .setTitle("OKN DSP • Version 1")
                .setMessage("Phase 1 is the real interactive UI foundation. Sliders, channel tabs, 15-band EQ graph dragging, theme, presets and automatic local persistence are active now. Hardware DSP/BLE commands are intentionally not faked; they will be wired to the uploaded protocol data in Phase 2.")
                .setPositiveButton("OK", null)
                .show();
    }

    private void openBluetoothSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
        } catch (Exception e) {
            try { startActivity(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)); }
            catch (Exception ignored) { toast("Bluetooth settings unavailable on this device"); }
        }
    }

    private ScrollView wrapScrollable(LinearLayout body) {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        FrameLayout holder = new FrameLayout(this);
        holder.setPadding(0, 0, 0, dp(8));
        int width = contentWidthPx();
        FrameLayout.LayoutParams bodyLp = new FrameLayout.LayoutParams(width, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        holder.addView(body, bodyLp);
        scroll.addView(holder, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return scroll;
    }

    private LinearLayout newPageBody() {
        LinearLayout body = column();
        body.setPadding(dp(isTablet() ? 26 : 16), 0, dp(isTablet() ? 26 : 16), 0);
        return body;
    }

    private int contentWidthPx() {
        int screenDp = getResources().getConfiguration().screenWidthDp;
        int maxDp = isTablet() ? 980 : screenDp;
        int targetDp = Math.min(screenDp, maxDp);
        return dp(targetDp);
    }

    private boolean isTablet() { return getResources().getConfiguration().smallestScreenWidthDp >= 600; }

    private LinearLayout card(boolean greenTint) {
        LinearLayout v = new LinearLayout(this);
        v.setBackground(rounded(greenTint ? c.ready : c.card, dp(24), c.border, greenTint ? 0 : 1));
        v.setElevation(dpF(1.5f));
        return v;
    }

    private LinearLayout row() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.HORIZONTAL);
        return v;
    }

    private LinearLayout column() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        return v;
    }

    private TextView label(String text, float sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(color);
        v.setTextSize(sp);
        v.setIncludeFontPadding(false);
        v.setTypeface(Typeface.create("sans", bold ? Typeface.BOLD : Typeface.NORMAL));
        return v;
    }

    private TextView bubble(String text, int background, int sizeDp, float textSp) {
        TextView v = label(text, textSp, Color.WHITE, true);
        v.setGravity(Gravity.CENTER);
        v.setBackground(rounded(background, dp(sizeDp / 2f), 0, 0));
        return v;
    }

    private ImageButton iconButton(int res) {
        ImageButton b = new ImageButton(this);
        b.setImageResource(res);
        b.setColorFilter(c.text);
        b.setScaleType(ImageView.ScaleType.CENTER);
        b.setPadding(dp(13), dp(13), dp(13), dp(13));
        b.setBackground(rounded(c.field, dp(25), 0, 0));
        return b;
    }

    private Button primaryButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setTypeface(Typeface.create("sans", Typeface.BOLD));
        b.setBackground(rounded(c.blue, dp(14), 0, 0));
        b.setPadding(dp(8), 0, dp(8), 0);
        return b;
    }

    private Button softButton(String text, boolean selected) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(selected ? Color.WHITE : c.secondary);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setBackground(rounded(selected ? c.blue : c.field, dp(14), 0, 0));
        b.setPadding(dp(8), 0, dp(8), 0);
        return b;
    }

    private Button roundTextButton(String text) {
        Button b = softButton(text, false);
        b.setTextSize(28);
        b.setGravity(Gravity.CENTER);
        b.setPadding(0, -dp(2), 0, 0);
        return b;
    }

    private View divider() {
        View v = new View(this);
        v.setBackgroundColor(c.border);
        v.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)));
        return v;
    }

    private View dividerWithMargins() {
        View v = new View(this);
        v.setBackgroundColor(c.border);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
        lp.setMargins(dp(16), 0, dp(16), 0);
        v.setLayoutParams(lp);
        return v;
    }

    private void styleSeekBar(SeekBar seek) {
        seek.setProgressTintList(ColorStateList.valueOf(c.blue));
        seek.setProgressBackgroundTintList(ColorStateList.valueOf(c.track));
        seek.setThumbTintList(ColorStateList.valueOf(c.blue));
        seek.setPadding(0, 0, 0, 0);
    }

    private GradientDrawable rounded(int color, float radiusPx, int strokeColor, int strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radiusPx);
        if (strokeDp > 0) d.setStroke(dp(strokeDp), strokeColor);
        return d;
    }

    private LinearLayout.LayoutParams matchCardLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        return lp;
    }

    private LinearLayout.LayoutParams matchCardLpNoTop() { return matchCardLp(); }

    private void addSpace(LinearLayout parent, float dp) {
        View s = new View(this);
        parent.addView(s, new LinearLayout.LayoutParams(1, this.dp(dp)));
    }

    private void addSpaceHorizontal(LinearLayout parent, float dp) {
        View s = new View(this);
        parent.addView(s, new LinearLayout.LayoutParams(this.dp(dp), 1));
    }

    private int dp(float value) { return Math.round(value * density); }
    private float dpF(float value) { return value * density; }

    private int soften(int color) {
        if (c.dark) {
            int r = Color.red(color), g = Color.green(color), b = Color.blue(color);
            return Color.rgb((r + 30) / 2, (g + 35) / 2, (b + 45) / 2);
        }
        int r = (Color.red(color) + 255 * 3) / 4;
        int g = (Color.green(color) + 255 * 3) / 4;
        int b = (Color.blue(color) + 255 * 3) / 4;
        return Color.rgb(r, g, b);
    }

    private String formatDb(float value) {
        if (Math.abs(value - Math.round(value)) < 0.001f) return Math.round(value) + " dB";
        return String.format(Locale.US, "%.1f dB", value);
    }

    private String formatDbOne(float value) { return String.format(Locale.US, "%.1f dB", value); }

    private String formatHz(float value) {
        if (value >= 1000f) {
            float k = value / 1000f;
            if (Math.abs(k - Math.round(k)) < 0.01f) return Math.round(k) + " kHz";
            return String.format(Locale.US, "%.2f kHz", k);
        }
        if (value < 100f) return String.format(Locale.US, "%.1f Hz", value);
        return Math.round(value) + " Hz";
    }

    private int freqToProgress(float frequency) {
        double min = Math.log10(20.0), max = Math.log10(20000.0);
        double t = (Math.log10(Math.max(20.0, Math.min(20000.0, frequency))) - min) / (max - min);
        return (int)Math.round(t * 1000.0);
    }

    private float progressToFreq(int progress) {
        double min = Math.log10(20.0), max = Math.log10(20000.0);
        double t = Math.max(0, Math.min(1000, progress)) / 1000.0;
        return (float)Math.pow(10.0, min + t * (max - min));
    }

    private String channelName(int channel) {
        String[] names = {"Front Left", "Front Right", "Rear Left", "Rear Right", "Center", "Sub / Bass", "Aux"};
        return names[Math.max(0, Math.min(names.length - 1, channel))];
    }

    private void toast(String text) { Toast.makeText(this, text, Toast.LENGTH_SHORT).show(); }

    private interface ValueConsumer { void accept(float value); }
    private interface ValueFormatter { String format(float value); }

    private static final class EqControl {
        final SeekBar seek;
        final TextView value;
        EqControl(SeekBar seek, TextView value) { this.seek = seek; this.value = value; }
    }

    private abstract static class SimpleSeekListener implements SeekBar.OnSeekBarChangeListener {
        @Override public void onStartTrackingTouch(SeekBar seekBar) { }
        @Override public void onStopTrackingTouch(SeekBar seekBar) { }
    }

    private static final class ThemeColors {
        final boolean dark;
        final int bg, card, field, text, secondary, border, selected, ready, track;
        final int blue, green, orange, purple, pink, cyan;

        ThemeColors(boolean dark) {
            this.dark = dark;
            blue = Color.rgb(10, 132, 255);
            green = Color.rgb(34, 197, 94);
            orange = Color.rgb(255, 159, 10);
            purple = Color.rgb(124, 92, 252);
            pink = Color.rgb(240, 90, 126);
            cyan = Color.rgb(17, 197, 217);
            if (dark) {
                bg = Color.rgb(14, 19, 29);
                card = Color.rgb(23, 30, 43);
                field = Color.rgb(34, 43, 58);
                text = Color.rgb(244, 247, 252);
                secondary = Color.rgb(158, 172, 193);
                border = Color.rgb(45, 55, 72);
                selected = Color.rgb(25, 54, 84);
                ready = Color.rgb(21, 48, 38);
                track = Color.rgb(59, 70, 89);
            } else {
                bg = Color.rgb(247, 249, 253);
                card = Color.WHITE;
                field = Color.rgb(241, 245, 250);
                text = Color.rgb(10, 16, 32);
                secondary = Color.rgb(116, 131, 155);
                border = Color.rgb(230, 235, 242);
                selected = Color.rgb(226, 240, 255);
                ready = Color.rgb(239, 253, 244);
                track = Color.rgb(215, 224, 236);
            }
        }
    }
}
