package com.okn.dsp;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;

public final class MainActivity extends Activity implements DspUiView.Host {
    private UiStateStore store;
    private DspUiView ui;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        store = new UiStateStore(this);
        applySystemBars();

        ui = new DspUiView(this, store, new NoOpDspTransport(), this);
        setContentView(ui);
    }

    @Override
    public void onThemeChanged() {
        applySystemBars();
    }

    private void applySystemBars() {
        Window window = getWindow();
        boolean dark = store != null && store.theme == UiStateStore.THEME_DARK;
        int barColor = Color.parseColor(dark ? "#0B111B" : "#F5F7FB");
        window.setStatusBarColor(barColor);
        window.setNavigationBarColor(barColor);

        if (android.os.Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = window.getInsetsController();
            if (c != null) {
                int appearance = dark ? 0 :
                        (WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS |
                         WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
                c.setSystemBarsAppearance(
                        appearance,
                        WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS |
                        WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
                );
            }
        } else {
            int flags = window.getDecorView().getSystemUiVisibility();
            if (dark) {
                flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                if (android.os.Build.VERSION.SDK_INT >= 26) {
                    flags &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                }
            } else {
                flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                if (android.os.Build.VERSION.SDK_INT >= 26) {
                    flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                }
            }
            window.getDecorView().setSystemUiVisibility(flags);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (store != null) store.commitFinal();
    }

    @Override
    public void onBackPressed() {
        if (store != null && store.page != UiStateStore.PAGE_HOME) {
            store.page = UiStateStore.PAGE_HOME;
            store.savePageAsync();
            if (ui != null) ui.resetScrollAndRefresh();
            return;
        }
        super.onBackPressed();
    }
}
