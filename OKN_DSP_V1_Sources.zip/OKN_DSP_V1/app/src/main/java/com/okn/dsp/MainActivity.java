package com.okn.dsp;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.content.res.Configuration;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.text.InputType;

public final class MainActivity extends Activity implements DspUiView.UiActions {
    private DspState state;
    private DspUiView dspView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.TRANSPARENT);
        window.setNavigationBarColor(Color.TRANSPARENT);
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        hideSystemUi();

        state = new DspState(this);
        dspView = new DspUiView(this, state, this);
        setContentView(dspView);
    }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (dspView != null) dspView.invalidate();
        hideSystemUi();
    }

    @Override
    public void requestPresetName() {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setText(state.getPresetName());
        input.setSelection(input.getText().length());
        input.setHint("Preset name");

        new AlertDialog.Builder(this)
                .setTitle("Preset name")
                .setView(input)
                .setPositiveButton("Save name", (dialog, which) -> {
                    String value = input.getText().toString().trim();
                    if (value.isEmpty()) value = "Custom 1";
                    state.setPresetName(value);
                    dspView.showMessage("Preset name: " + value);
                    dspView.invalidate();
                    hideSystemUi();
                })
                .setNegativeButton("Cancel", (dialog, which) -> hideSystemUi())
                .setOnDismissListener(dialog -> hideSystemUi())
                .show();
    }
}
