package com.okn.dsp;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.EditText;
import android.widget.Toast;

public final class MainActivity extends Activity implements DspView.Host {
    private DspView dspView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dspView = new DspView(this);
        setContentView(dspView);
        applySystemBars(dspView.getThemeIndex());
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (dspView != null) dspView.flushState();
    }

    @Override
    public void requestThemePicker(int currentTheme) {
        String[] items = {"Light", "Dark", "Midnight"};
        new AlertDialog.Builder(this)
                .setTitle("Theme")
                .setSingleChoiceItems(items, currentTheme, (dialog, which) -> {
                    dspView.setThemeIndex(which);
                    applySystemBars(which);
                    dialog.dismiss();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    @Override
    public void requestPresetName(String currentName) {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setText(currentName == null ? "Preset" : currentName);
        input.setSelection(input.getText().length());
        int pad = (int) (20f * getResources().getDisplayMetrics().density);
        input.setPadding(pad, pad / 2, pad, pad / 2);

        new AlertDialog.Builder(this)
                .setTitle("Preset name")
                .setView(input)
                .setPositiveButton("Save", (dialog, which) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) name = "Preset";
                    dspView.savePreset(name);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    @Override
    public void showMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private void applySystemBars(int themeIndex) {
        boolean light = themeIndex == 0;
        int bg;
        if (themeIndex == 0) bg = 0xFFF4F7FB;
        else if (themeIndex == 1) bg = 0xFF0D1320;
        else bg = 0xFF050A13;

        Window window = getWindow();
        window.setStatusBarColor(bg);
        window.setNavigationBarColor(bg);

        if (android.os.Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = window.getInsetsController();
            if (c != null) {
                int mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                        | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                c.setSystemBarsAppearance(light ? mask : 0, mask);
            }
        } else {
            int flags = window.getDecorView().getSystemUiVisibility();
            if (light) {
                flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                if (android.os.Build.VERSION.SDK_INT >= 26) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            } else {
                flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                if (android.os.Build.VERSION.SDK_INT >= 26) flags &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            }
            window.getDecorView().setSystemUiVisibility(flags);
        }
    }
}
