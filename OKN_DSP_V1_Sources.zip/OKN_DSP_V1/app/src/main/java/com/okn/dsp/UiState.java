package com.okn.dsp;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Locale;

/**
 * Phase 1 local UI state. Every user-visible parameter is restored after restart.
 * Phase 2 will attach these setters to the real DSP transport/protocol layer.
 */
public final class UiState {
    public static final int SCREEN_HOME = 0;
    public static final int SCREEN_MIX = 1;
    public static final int SCREEN_EQ = 2;

    // AUTO = reference look (Home/EQ light, Mix dark), LIGHT = all light, DARK = all dark.
    public static final int THEME_AUTO = 0;
    public static final int THEME_LIGHT = 1;
    public static final int THEME_DARK = 2;

    public static final int CHANNELS = 7;
    public static final int BANDS = 15;
    public static final float[] DEFAULT_FREQUENCIES = {
            25f, 40f, 63f, 100f, 160f, 250f, 400f, 630f,
            1000f, 1600f, 2500f, 4000f, 6300f, 10000f, 16000f
    };

    private final SharedPreferences prefs;

    public int screen;
    public int themeMode;
    public int selectedChannel;
    public int selectedBand;

    public float masterDb;
    public float bassDb;
    public float bassCutoffHz;
    public final float[] channelDb = new float[CHANNELS];
    public final float[][] eqGainDb = new float[CHANNELS][BANDS];
    public final float[][] eqQ = new float[CHANNELS][BANDS];
    public final float[][] eqFrequencyHz = new float[CHANNELS][BANDS];

    public String presetName;
    public boolean hasPreset;

    public UiState(Context context) {
        prefs = context.getSharedPreferences("okn_dsp_v1_ui", Context.MODE_PRIVATE);
        load();
    }

    private void load() {
        screen = clampInt(prefs.getInt("screen", SCREEN_HOME), SCREEN_HOME, SCREEN_EQ);
        themeMode = clampInt(prefs.getInt("theme", THEME_AUTO), THEME_AUTO, THEME_DARK);
        selectedChannel = clampInt(prefs.getInt("selected_channel", 0), 0, CHANNELS - 1);
        selectedBand = clampInt(prefs.getInt("selected_band", 3), 0, BANDS - 1);

        masterDb = prefs.getFloat("master_db", -6f);
        bassDb = prefs.getFloat("bass_db", 2f);
        bassCutoffHz = prefs.getFloat("bass_cutoff_hz", 80f);

        float[] defaults = {-3f, -6f, -2f, -8f, 0f, -4f, -10f};
        for (int ch = 0; ch < CHANNELS; ch++) {
            channelDb[ch] = prefs.getFloat("ch_" + ch + "_db", defaults[ch]);
            for (int band = 0; band < BANDS; band++) {
                eqGainDb[ch][band] = prefs.getFloat(eqKey(ch, band, "gain"), 0f);
                eqQ[ch][band] = prefs.getFloat(eqKey(ch, band, "q"), 1f);
                eqFrequencyHz[ch][band] = prefs.getFloat(eqKey(ch, band, "freq"), DEFAULT_FREQUENCIES[band]);
            }
        }

        presetName = prefs.getString("preset_name", "Flat");
        if (presetName == null || presetName.trim().isEmpty()) presetName = "Flat";
        hasPreset = prefs.getBoolean("has_preset", false);
    }

    public void setScreen(int value) {
        screen = clampInt(value, SCREEN_HOME, SCREEN_EQ);
        prefs.edit().putInt("screen", screen).apply();
    }

    public void setThemeMode(int value) {
        themeMode = clampInt(value, THEME_AUTO, THEME_DARK);
        prefs.edit().putInt("theme", themeMode).commit();
    }

    public void setSelectedChannel(int value) {
        selectedChannel = clampInt(value, 0, CHANNELS - 1);
        prefs.edit().putInt("selected_channel", selectedChannel).apply();
    }

    public void setSelectedBand(int value) {
        selectedBand = clampInt(value, 0, BANDS - 1);
        prefs.edit().putInt("selected_band", selectedBand).apply();
    }

    public void setMasterDb(float value) {
        masterDb = clamp(value, -60f, 6f);
        prefs.edit().putFloat("master_db", masterDb).apply();
    }

    public void setBassDb(float value) {
        bassDb = clamp(value, -12f, 12f);
        prefs.edit().putFloat("bass_db", bassDb).apply();
    }

    public void setBassCutoffHz(float value) {
        bassCutoffHz = clamp(value, 40f, 250f);
        prefs.edit().putFloat("bass_cutoff_hz", bassCutoffHz).apply();
    }

    public void setChannelDb(int channel, float value) {
        int ch = clampInt(channel, 0, CHANNELS - 1);
        channelDb[ch] = clamp(value, -60f, 6f);
        prefs.edit().putFloat("ch_" + ch + "_db", channelDb[ch]).apply();
    }

    public void setEqGain(int channel, int band, float value) {
        int ch = clampInt(channel, 0, CHANNELS - 1);
        int b = clampInt(band, 0, BANDS - 1);
        eqGainDb[ch][b] = clamp(value, -12f, 12f);
        prefs.edit().putFloat(eqKey(ch, b, "gain"), eqGainDb[ch][b]).apply();
    }

    public void setEqQ(int channel, int band, float value) {
        int ch = clampInt(channel, 0, CHANNELS - 1);
        int b = clampInt(band, 0, BANDS - 1);
        eqQ[ch][b] = clamp(value, 0.1f, 10f);
        prefs.edit().putFloat(eqKey(ch, b, "q"), eqQ[ch][b]).apply();
    }

    public void setEqFrequency(int channel, int band, float value) {
        int ch = clampInt(channel, 0, CHANNELS - 1);
        int b = clampInt(band, 0, BANDS - 1);
        eqFrequencyHz[ch][b] = clamp(value, 20f, 20000f);
        prefs.edit().putFloat(eqKey(ch, b, "freq"), eqFrequencyHz[ch][b]).apply();
    }

    public void resetCurrentEq() {
        int ch = selectedChannel;
        SharedPreferences.Editor e = prefs.edit();
        for (int b = 0; b < BANDS; b++) {
            eqGainDb[ch][b] = 0f;
            eqQ[ch][b] = 1f;
            eqFrequencyHz[ch][b] = DEFAULT_FREQUENCIES[b];
            e.putFloat(eqKey(ch, b, "gain"), 0f);
            e.putFloat(eqKey(ch, b, "q"), 1f);
            e.putFloat(eqKey(ch, b, "freq"), DEFAULT_FREQUENCIES[b]);
        }
        e.commit();
    }

    public void flushRealtimeState() {
        SharedPreferences.Editor e = prefs.edit();
        e.putFloat("master_db", masterDb)
                .putFloat("bass_db", bassDb)
                .putFloat("bass_cutoff_hz", bassCutoffHz)
                .putInt("screen", screen)
                .putInt("theme", themeMode)
                .putInt("selected_channel", selectedChannel)
                .putInt("selected_band", selectedBand);
        for (int ch = 0; ch < CHANNELS; ch++) {
            e.putFloat("ch_" + ch + "_db", channelDb[ch]);
            for (int b = 0; b < BANDS; b++) {
                e.putFloat(eqKey(ch, b, "gain"), eqGainDb[ch][b]);
                e.putFloat(eqKey(ch, b, "q"), eqQ[ch][b]);
                e.putFloat(eqKey(ch, b, "freq"), eqFrequencyHz[ch][b]);
            }
        }
        e.commit();
    }

    public void savePreset(String name) {
        String clean = name == null ? "Preset" : name.trim();
        if (clean.isEmpty()) clean = "Preset";
        if (clean.length() > 28) clean = clean.substring(0, 28);
        presetName = clean;
        hasPreset = true;

        SharedPreferences.Editor e = prefs.edit();
        e.putString("preset_name", presetName).putBoolean("has_preset", true);
        e.putFloat("preset_master_db", masterDb)
                .putFloat("preset_bass_db", bassDb)
                .putFloat("preset_bass_cutoff_hz", bassCutoffHz);
        for (int ch = 0; ch < CHANNELS; ch++) {
            e.putFloat("preset_ch_" + ch + "_db", channelDb[ch]);
            for (int b = 0; b < BANDS; b++) {
                e.putFloat(presetEqKey(ch, b, "gain"), eqGainDb[ch][b]);
                e.putFloat(presetEqKey(ch, b, "q"), eqQ[ch][b]);
                e.putFloat(presetEqKey(ch, b, "freq"), eqFrequencyHz[ch][b]);
            }
        }
        e.commit();
    }

    public boolean loadPreset() {
        if (!hasPreset || !prefs.getBoolean("has_preset", false)) return false;
        masterDb = prefs.getFloat("preset_master_db", masterDb);
        bassDb = prefs.getFloat("preset_bass_db", bassDb);
        bassCutoffHz = prefs.getFloat("preset_bass_cutoff_hz", bassCutoffHz);
        for (int ch = 0; ch < CHANNELS; ch++) {
            channelDb[ch] = prefs.getFloat("preset_ch_" + ch + "_db", channelDb[ch]);
            for (int b = 0; b < BANDS; b++) {
                eqGainDb[ch][b] = prefs.getFloat(presetEqKey(ch, b, "gain"), eqGainDb[ch][b]);
                eqQ[ch][b] = prefs.getFloat(presetEqKey(ch, b, "q"), eqQ[ch][b]);
                eqFrequencyHz[ch][b] = prefs.getFloat(presetEqKey(ch, b, "freq"), eqFrequencyHz[ch][b]);
            }
        }
        flushRealtimeState();
        return true;
    }

    public void deletePreset() {
        hasPreset = false;
        presetName = "Flat";
        SharedPreferences.Editor e = prefs.edit();
        e.putBoolean("has_preset", false).putString("preset_name", "Flat");
        for (String key : prefs.getAll().keySet()) {
            if (key.startsWith("preset_")) e.remove(key);
        }
        e.putBoolean("has_preset", false).putString("preset_name", "Flat");
        e.commit();
    }

    public String themeLabel() {
        if (themeMode == THEME_LIGHT) return "LIGHT";
        if (themeMode == THEME_DARK) return "DARK";
        return "AUTO";
    }

    public static String formatFrequency(float hz) {
        if (hz >= 1000f) {
            float k = hz / 1000f;
            if (Math.abs(k - Math.round(k)) < 0.05f) return String.format(Locale.US, "%.0f kHz", k);
            return String.format(Locale.US, "%.1f kHz", k);
        }
        return String.format(Locale.US, "%.0f Hz", hz);
    }

    private static String eqKey(int ch, int band, String field) {
        return "eq_" + ch + "_" + band + "_" + field;
    }

    private static String presetEqKey(int ch, int band, String field) {
        return "preset_eq_" + ch + "_" + band + "_" + field;
    }

    private static int clampInt(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}
