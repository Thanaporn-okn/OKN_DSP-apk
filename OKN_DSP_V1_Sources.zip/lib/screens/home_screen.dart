import 'package:flutter/material.dart';
import 'package:flutter_reactive_ble/flutter_reactive_ble.dart';

import '../controllers/dsp_controller.dart';
import '../theme/app_theme.dart';
import '../widgets/dropdown_field.dart';
import '../widgets/glass_card.dart';
import '../widgets/neon_controls.dart';
import '../widgets/responsive.dart';
import '../widgets/top_header.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({required this.controller, super.key});

  final DspController controller;

  @override
  Widget build(BuildContext context) {
    return ResponsivePage(
      maxWidth: 950,
      child: Padding(
        padding: const EdgeInsets.only(bottom: 104),
        child: Column(
          children: [
            TopHeader(controller: controller, homeBrand: true),
            _HomeControlCard(
              icon: Icons.volume_up_rounded,
              title: 'Master Volume',
              subtitle: 'ปรับระดับเสียงรวม',
              color: AppColors.blue,
              listenable: controller.masterVolumeDb,
              min: -60,
              max: 12,
              suffix: 'dB',
              divisions: 72,
              onChanged: (v) => controller.setHomeValue('masterVolumeDb', v),
            ),
            _HomeControlCard(
              icon: Icons.album_rounded,
              title: 'Bass Volume',
              subtitle: 'ปรับระดับเสียงเบส',
              color: AppColors.cyan,
              listenable: controller.bassVolumeDb,
              min: -12,
              max: 12,
              suffix: 'dB',
              divisions: 48,
              onChanged: (v) => controller.setHomeValue('bassVolumeDb', v),
            ),
            _HomeControlCard(
              icon: Icons.show_chart_rounded,
              title: 'Bass Cutoff',
              subtitle: 'ตั้งค่าความถี่ตัดเบส',
              color: AppColors.purple,
              listenable: controller.bassCutoffHz,
              min: 20,
              max: 500,
              suffix: 'Hz',
              divisions: 96,
              onChanged: (v) => controller.setHomeValue('bassCutoffHz', v),
            ),
            _HomeControlCard(
              icon: Icons.equalizer_rounded,
              title: 'Bass Boost',
              subtitle: 'เพิ่มความหนักแน่นของเบส',
              color: AppColors.pink,
              listenable: controller.bassBoostDb,
              min: -10,
              max: 12,
              suffix: 'dB',
              divisions: 44,
              onChanged: (v) => controller.setHomeValue('bassBoostDb', v),
            ),
            _HomeControlCard(
              icon: Icons.monitor_heart_outlined,
              title: 'Middle Boost',
              subtitle: 'เพิ่มความชัดเจนย่านกลาง',
              color: AppColors.blue,
              listenable: controller.middleBoostDb,
              min: -12,
              max: 12,
              suffix: 'dB',
              divisions: 48,
              onChanged: (v) => controller.setHomeValue('middleBoostDb', v),
            ),
            _HomeControlCard(
              icon: Icons.auto_awesome_rounded,
              title: 'Treble Boost',
              subtitle: 'เพิ่มความใสย่านแหลม',
              color: AppColors.purple,
              listenable: controller.trebleBoostDb,
              min: -12,
              max: 12,
              suffix: 'dB',
              divisions: 48,
              onChanged: (v) => controller.setHomeValue('trebleBoostDb', v),
            ),
            const SizedBox(height: 8),
            AdaptiveColumns(
              breakpoint: 720,
              children: [
                Column(
                  children: [
                    _AudioSourceCard(controller: controller),
                    const SizedBox(height: 12),
                    _PresetCard(controller: controller),
                  ],
                ),
                _DeviceStatusCard(controller: controller),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _HomeControlCard extends StatelessWidget {
  const _HomeControlCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.listenable,
    required this.min,
    required this.max,
    required this.suffix,
    required this.onChanged,
    this.divisions,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final ValueListenable<double> listenable;
  final double min;
  final double max;
  final String suffix;
  final ValueChanged<double> onChanged;
  final int? divisions;

  String _format(double value) {
    if (suffix == 'Hz') return '${value.round()} Hz';
    return '${value.toStringAsFixed(1)} dB';
  }

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      margin: const EdgeInsets.only(bottom: 12),
      glowColor: color,
      padding: const EdgeInsets.all(14),
      child: ValueListenableBuilder<double>(
        valueListenable: listenable,
        builder: (context, value, _) {
          return LayoutBuilder(
            builder: (context, constraints) {
              final compact = constraints.maxWidth < 560;
              final iconBox = Container(
                width: compact ? 56 : 70,
                height: compact ? 56 : 70,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: color, width: 2),
                  boxShadow: [
                    BoxShadow(color: color.withValues(alpha: 0.30), blurRadius: 18),
                  ],
                  color: color.withValues(alpha: 0.07),
                ),
                child: Icon(icon, color: color, size: compact ? 28 : 36),
              );
              final label = Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: compact ? 17 : 20,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: const TextStyle(color: AppColors.textMuted, fontSize: 12),
                  ),
                ],
              );
              final slider = Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  NeonSlider(
                    value: value,
                    min: min,
                    max: max,
                    divisions: divisions,
                    color: color,
                    onChanged: onChanged,
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(_axisLabel(min), style: const TextStyle(fontSize: 10, color: AppColors.textMuted)),
                        Text(_axisLabel((min + max) / 2), style: const TextStyle(fontSize: 10, color: AppColors.textMuted)),
                        Text(_axisLabel(max), style: const TextStyle(fontSize: 10, color: AppColors.textMuted)),
                      ],
                    ),
                  ),
                ],
              );

              if (compact) {
                return Column(
                  children: [
                    Row(
                      children: [
                        iconBox,
                        const SizedBox(width: 12),
                        Expanded(child: label),
                        ValuePill(text: _format(value), color: color),
                      ],
                    ),
                    const SizedBox(height: 7),
                    slider,
                  ],
                );
              }
              return Row(
                children: [
                  iconBox,
                  const SizedBox(width: 16),
                  SizedBox(width: 190, child: label),
                  Expanded(child: slider),
                  const SizedBox(width: 12),
                  SizedBox(width: 104, child: ValuePill(text: _format(value), color: color)),
                ],
              );
            },
          );
        },
      ),
    );
  }

  String _axisLabel(double value) {
    if (suffix == 'Hz') return value.round().toString();
    if (value > 0) return '+${value.round()}';
    return value.round().toString();
  }
}

class _AudioSourceCard extends StatelessWidget {
  const _AudioSourceCard({required this.controller});

  final DspController controller;

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const _SquareIcon(icon: Icons.music_note_rounded),
          const SizedBox(width: 12),
          Expanded(
            child: ValueListenableBuilder<String>(
              valueListenable: controller.audioSource,
              builder: (context, value, _) {
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Audio Source', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
                    const Text('แหล่งสัญญาณเสียง', style: TextStyle(color: AppColors.textMuted, fontSize: 12)),
                    const SizedBox(height: 8),
                    DspDropdown<String>(
                      value: value,
                      items: const ['High Level (Speaker)', 'Low Level (RCA)', 'Bluetooth'],
                      labelBuilder: (v) => v,
                      onChanged: controller.setAudioSource,
                    ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _PresetCard extends StatelessWidget {
  const _PresetCard({required this.controller});

  final DspController controller;

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const _SquareIcon(icon: Icons.menu_rounded),
          const SizedBox(width: 12),
          Expanded(
            child: ValueListenableBuilder<String>(
              valueListenable: controller.systemPreset,
              builder: (context, value, _) {
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('System Preset', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
                    const Text('พรีเซ็ตระบบ', style: TextStyle(color: AppColors.textMuted, fontSize: 12)),
                    const SizedBox(height: 8),
                    DspDropdown<String>(
                      value: value,
                      items: const ['Flat', 'Music', 'Vocal', 'Bass', 'Custom 1'],
                      labelBuilder: (v) => v,
                      onChanged: controller.setSystemPreset,
                    ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _DeviceStatusCard extends StatelessWidget {
  const _DeviceStatusCard({required this.controller});

  final DspController controller;

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              _SquareIcon(icon: Icons.memory_rounded),
              SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Device Status', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
                    Text('สถานะอุปกรณ์', style: TextStyle(color: AppColors.textMuted, fontSize: 12)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ValueListenableBuilder<DeviceConnectionState>(
            valueListenable: controller.bleService.connectionState,
            builder: (context, state, _) {
              final connected = state == DeviceConnectionState.connected;
              return _StatusRow(
                icon: Icons.circle,
                color: connected ? AppColors.green : AppColors.orange,
                label: connected ? 'Connected' : 'Disconnected',
                value: controller.bleService.connectedDeviceName.value,
              );
            },
          ),
          ValueListenableBuilder<double>(
            valueListenable: controller.voltage,
            builder: (_, value, __) => _StatusRow(
              icon: Icons.battery_5_bar_rounded,
              color: AppColors.green,
              label: 'Voltage',
              value: '${value.toStringAsFixed(1)} V',
            ),
          ),
          ValueListenableBuilder<double>(
            valueListenable: controller.temperatureC,
            builder: (_, value, __) => _StatusRow(
              icon: Icons.device_thermostat_rounded,
              color: AppColors.cyan,
              label: 'Temperature',
              value: '${value.round()} °C',
            ),
          ),
          const _StatusRow(
            icon: Icons.check_circle_outline,
            color: AppColors.green,
            label: 'System',
            value: 'Normal',
          ),
        ],
      ),
    );
  }
}

class _SquareIcon extends StatelessWidget {
  const _SquareIcon({required this.icon});

  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 52,
      height: 52,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        color: AppColors.blue.withValues(alpha: 0.18),
        border: Border.all(color: AppColors.border),
        boxShadow: [BoxShadow(color: AppColors.blue.withValues(alpha: 0.18), blurRadius: 14)],
      ),
      child: Icon(icon, color: AppColors.cyan, size: 28),
    );
  }
}

class _StatusRow extends StatelessWidget {
  const _StatusRow({
    required this.icon,
    required this.color,
    required this.label,
    required this.value,
  });

  final IconData icon;
  final Color color;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: Color(0x33285A80))),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(width: 10),
          Expanded(child: Text(label, style: const TextStyle(color: AppColors.textMuted))),
          Text(value, style: TextStyle(color: color == AppColors.green ? AppColors.green : AppColors.text)),
        ],
      ),
    );
  }
}
