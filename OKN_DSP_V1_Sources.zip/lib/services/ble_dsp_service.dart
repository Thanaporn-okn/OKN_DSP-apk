import 'dart:async';
import 'dart:typed_data';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter_reactive_ble/flutter_reactive_ble.dart';
import 'package:permission_handler/permission_handler.dart';

class BleDspService {
  BleDspService({FlutterReactiveBle? ble}) : _ble = ble ?? FlutterReactiveBle() {
    _statusSub = _ble.statusStream.listen((status) {
      bleStatus.value = status;
    });
  }

  static final Uuid targetCharacteristicUuid =
      Uuid.parse('0000ab01-0000-1000-8000-00805f9b34fb');

  final FlutterReactiveBle _ble;

  final ValueNotifier<BleStatus> bleStatus = ValueNotifier(BleStatus.unknown);
  final ValueNotifier<DeviceConnectionState> connectionState =
      ValueNotifier(DeviceConnectionState.disconnected);
  final ValueNotifier<String?> connectedDeviceId = ValueNotifier(null);
  final ValueNotifier<String> connectedDeviceName = ValueNotifier('DSP-7900');
  final ValueNotifier<String?> errorMessage = ValueNotifier(null);
  final ValueNotifier<Uint8List> lastNotification = ValueNotifier(Uint8List(0));

  StreamSubscription<BleStatus>? _statusSub;
  StreamSubscription<ConnectionStateUpdate>? _connectionSub;
  StreamSubscription<List<int>>? _notificationSub;
  QualifiedCharacteristic? _targetCharacteristic;
  bool _canWriteWithResponse = false;
  bool _canWriteWithoutResponse = false;

  Future<void> _ensurePermissions() async {
    if (Platform.isAndroid) {
      final statuses = await <Permission>[
        Permission.bluetoothScan,
        Permission.bluetoothConnect,
        Permission.locationWhenInUse,
      ].request();

      final bluetoothGranted =
          (statuses[Permission.bluetoothScan]?.isGranted ?? false) &&
          (statuses[Permission.bluetoothConnect]?.isGranted ?? false);
      final legacyLocationGranted =
          statuses[Permission.locationWhenInUse]?.isGranted ?? false;

      if (!bluetoothGranted && !legacyLocationGranted) {
        final permanentlyDenied =
            statuses.values.any((status) => status.isPermanentlyDenied);
        throw StateError(
          permanentlyDenied
              ? 'Bluetooth permission is permanently denied. Enable it in Android app settings.'
              : 'Bluetooth permission is required to discover the DSP.',
        );
      }
    }

    var status = _ble.status;
    if (status == BleStatus.unknown) {
      status = await _ble.statusStream
          .firstWhere((value) => value != BleStatus.unknown)
          .timeout(const Duration(seconds: 5));
    }
    if (status != BleStatus.ready) {
      throw StateError('Bluetooth is not ready: ${status.name}.');
    }
  }

  Stream<DiscoveredDevice> scan({Duration timeout = const Duration(seconds: 8)}) async* {
    errorMessage.value = null;
    await _ensurePermissions();
    yield* _ble
        .scanForDevices(
          withServices: const [],
          scanMode: ScanMode.lowLatency,
          requireLocationServicesEnabled: false,
        )
        .timeout(timeout);
  }

  Future<void> connect(DiscoveredDevice device) async {
    await _ensurePermissions();
    await disconnect();
    errorMessage.value = null;
    connectedDeviceName.value = device.name.trim().isEmpty ? 'DSP Device' : device.name.trim();
    connectedDeviceId.value = device.id;
    connectionState.value = DeviceConnectionState.connecting;

    final completer = Completer<void>();
    _connectionSub = _ble
        .connectToDevice(
          id: device.id,
          connectionTimeout: const Duration(seconds: 12),
        )
        .listen(
      (update) async {
        connectionState.value = update.connectionState;
        if (update.connectionState == DeviceConnectionState.connected) {
          try {
            await _bindTargetCharacteristic(device.id);
            if (!completer.isCompleted) {
              completer.complete();
            }
          } catch (error, stackTrace) {
            errorMessage.value = 'Connected, but DSP characteristic AB01 is unavailable: $error';
            connectionState.value = DeviceConnectionState.disconnected;
            if (!completer.isCompleted) {
              completer.completeError(error, stackTrace);
            }
          }
        } else if (update.connectionState == DeviceConnectionState.disconnected) {
          _targetCharacteristic = null;
          _canWriteWithResponse = false;
          _canWriteWithoutResponse = false;
          await _notificationSub?.cancel();
          _notificationSub = null;
        }
      },
      onError: (Object error, StackTrace stackTrace) {
        connectionState.value = DeviceConnectionState.disconnected;
        errorMessage.value = 'BLE connection failed: $error';
        if (!completer.isCompleted) {
          completer.completeError(error, stackTrace);
        }
      },
      cancelOnError: false,
    );

    return completer.future.timeout(
      const Duration(seconds: 15),
      onTimeout: () {
        throw TimeoutException('DSP connection timed out.');
      },
    );
  }

  Future<void> _bindTargetCharacteristic(String deviceId) async {
    final services = await _ble.discoverServices(deviceId);
    DiscoveredCharacteristic? found;
    for (final service in services) {
      for (final characteristic in service.characteristics) {
        if (characteristic.characteristicId == targetCharacteristicUuid) {
          found = characteristic;
          break;
        }
      }
      if (found != null) {
        break;
      }
    }

    if (found == null) {
      _targetCharacteristic = null;
      _canWriteWithResponse = false;
      _canWriteWithoutResponse = false;
      throw StateError('Characteristic ${targetCharacteristicUuid.toString()} was not found.');
    }

    final qualified = QualifiedCharacteristic(
      serviceId: found.serviceId,
      characteristicId: found.characteristicId,
      deviceId: deviceId,
    );
    _targetCharacteristic = qualified;
    _canWriteWithResponse = found.isWritableWithResponse;
    _canWriteWithoutResponse = found.isWritableWithoutResponse;

    if (!_canWriteWithResponse && !_canWriteWithoutResponse) {
      _targetCharacteristic = null;
      throw StateError('Characteristic AB01 is not writable on this device.');
    }

    await _notificationSub?.cancel();
    if (found.isNotifiable || found.isIndicatable) {
      _notificationSub = _ble.subscribeToCharacteristic(qualified).listen(
        (data) => lastNotification.value = Uint8List.fromList(data),
        onError: (Object error) {
          errorMessage.value = 'DSP notification error: $error';
        },
      );
    }
  }

  Future<void> writeRaw(List<int> bytes, {bool withResponse = false}) async {
    final characteristic = _targetCharacteristic;
    if (characteristic == null) {
      throw StateError('DSP characteristic AB01 is not available.');
    }
    if (withResponse && _canWriteWithResponse) {
      await _ble.writeCharacteristicWithResponse(characteristic, value: bytes);
      return;
    }
    if (!withResponse && _canWriteWithoutResponse) {
      await _ble.writeCharacteristicWithoutResponse(characteristic, value: bytes);
      return;
    }
    if (_canWriteWithResponse) {
      await _ble.writeCharacteristicWithResponse(characteristic, value: bytes);
      return;
    }
    if (_canWriteWithoutResponse) {
      await _ble.writeCharacteristicWithoutResponse(characteristic, value: bytes);
      return;
    }
    throw StateError('DSP characteristic AB01 has no supported write mode.');
  }

  Future<void> disconnect() async {
    await _notificationSub?.cancel();
    _notificationSub = null;
    await _connectionSub?.cancel();
    _connectionSub = null;
    _targetCharacteristic = null;
    _canWriteWithResponse = false;
    _canWriteWithoutResponse = false;
    connectionState.value = DeviceConnectionState.disconnected;
    connectedDeviceId.value = null;
  }

  void dispose() {
    _notificationSub?.cancel();
    _connectionSub?.cancel();
    _statusSub?.cancel();
    bleStatus.dispose();
    connectionState.dispose();
    connectedDeviceId.dispose();
    connectedDeviceName.dispose();
    errorMessage.dispose();
    lastNotification.dispose();
  }
}
