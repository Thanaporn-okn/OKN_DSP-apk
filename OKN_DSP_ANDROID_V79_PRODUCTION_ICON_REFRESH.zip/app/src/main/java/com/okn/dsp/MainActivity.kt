package com.okn.dsp

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/** V79 production direct-reconnect connection-epoch health-gate-binding launcher: open the verified DSP control UI directly. */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startActivity(Intent(this, UnifiedControlActivity::class.java))
        finish()
    }
}
