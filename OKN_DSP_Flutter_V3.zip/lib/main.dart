import 'package:flutter/material.dart';

void main()=>runApp(const OKNDSP());

class OKNDSP extends StatelessWidget{
 const OKNDSP({super.key});
 @override
 Widget build(BuildContext c)=>MaterialApp(
  debugShowCheckedModeBanner:false,
  theme:ThemeData.dark(useMaterial3:true),
  home:const Home());
}

class Home extends StatelessWidget{
 const Home({super.key});
 final ch=const ['CH1\nFront L','CH2\nFront R','CH3\nSUB','CH4\nRear L','CH5\nRear R','CH6\nAUX L','CH7\nAUX R'];

 @override
 Widget build(BuildContext c){
 return Scaffold(
 backgroundColor:const Color(0xff0c1016),
 body:SafeArea(
 child:Column(children:[
  Container(
   margin:const EdgeInsets.all(10),
   padding:const EdgeInsets.all(14),
   decoration:BoxDecoration(
    color:const Color(0xff202631),
    borderRadius:BorderRadius.circular(15)),
   child:const Row(children:[
    Icon(Icons.bluetooth,color:Colors.cyan,size:35),
    SizedBox(width:15),
    Text('Connected\nBP1048P4 7CH DSP\nFW: 1.2.6',
    style:TextStyle(fontSize:18))
   ])),
  const Text('Master Volume   -12.5 dB',
  style:TextStyle(fontSize:22)),
  const SizedBox(height:8),
  Expanded(
   child:Row(
    children:ch.map((x)=>Expanded(
     child:Channel(title:x))).toList()))
 ,
  Container(
   height:55,
   alignment:Alignment.center,
   child:const Text(
   '⌂ MAIN   EQ   CROSSOVER   DELAY   MIXER   PRESET   SETTINGS',
   style:TextStyle(color:Colors.cyan,fontSize:14)))
 ])));
 }
}

class Channel extends StatelessWidget{
 final String title;
 const Channel({super.key,required this.title});

 @override
 Widget build(BuildContext c){
 return Container(
 margin:const EdgeInsets.all(4),
 decoration:BoxDecoration(
  color:const Color(0xff171d25),
  borderRadius:BorderRadius.circular(12)),
 child:Column(children:[
  Container(height:4,color:Colors.cyan),
  const SizedBox(height:8),
  Text(title,textAlign:TextAlign.center,
  style:const TextStyle(fontSize:14)),
  const Text('-2.0 dB'),
  Expanded(
   child:SliderTheme(
    data:SliderTheme.of(c).copyWith(
     trackHeight:5,
     thumbShape:const RoundSliderThumbShape(enabledThumbRadius:11)),
    child:RotatedBox(
     quarterTurns:3,
     child:Slider(
      value:.7,min:0,max:1,
      onChanged:(v){})))) ,
  SizedBox(
   width:70,
   child:ElevatedButton(
    onPressed:(){},
    child:const Text('Mute')))
 ]));
 }
}
