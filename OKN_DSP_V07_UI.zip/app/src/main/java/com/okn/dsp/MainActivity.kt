package com.okn.dsp

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class MainActivity: Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(16,16,16,16)
        root.setBackgroundColor(Color.BLACK)

        fun txt(s:String, size:Float): TextView {
            val t=TextView(this)
            t.text=s
            t.textSize=size
            t.setTextColor(Color.WHITE)
            t.setPadding(8,8,8,8)
            return t
        }

        root.addView(txt("🔵 Connected\nBP1048P4 7CH DSP\nFW: 1.2.6",18f))

        root.addView(txt("Master Volume     -12.5 dB",20f))
        val master=SeekBar(this)
        master.max=60
        master.progress=35
        root.addView(master)

        val channels=arrayOf(
            "CH1  Front L",
            "CH2  Front R",
            "CH3  SUB",
            "CH4  Rear L",
            "CH5  Rear R",
            "CH6  AUX L",
            "CH7  AUX R"
        )

        for(c in channels){
            val box=LinearLayout(this)
            box.orientation=LinearLayout.VERTICAL
            box.setPadding(8,8,8,8)
            box.addView(txt(c,16f))
            val f=SeekBar(this)
            f.max=66
            f.progress=30
            box.addView(f)
            val m=Button(this)
            m.text="Mute"
            box.addView(m)
            root.addView(box)
        }

        root.addView(txt("MAIN     EQ     CROSSOVER     DELAY     MIXER     PRESET     SETTINGS",14f))
        setContentView(root)
    }
}
