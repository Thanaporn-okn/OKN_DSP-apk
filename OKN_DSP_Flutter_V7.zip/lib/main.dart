import 'package:flutter/material.dart';

void main()=>runApp(const OKNDSP());

class OKNDSP extends StatelessWidget{
 const OKNDSP({super.key});
 Widget build(BuildContext c)=>MaterialApp(
  debugShowCheckedModeBanner:false,
  theme:ThemeData.dark(useMaterial3:true),
  home:const DSPHome());
}

class DSPHome extends StatefulWidget{
 const DSPHome({super.key});
 State<DSPHome> createState()=>_DSPHome();
}

class _DSPHome extends State<DSPHome>{
 int page=0;
 final menu=['MAIN','EQ','XOVER','DELAY','MIXER','PRESET','BT'];

 Widget build(BuildContext c)=>Scaffold(
 backgroundColor:const Color(0xff090d12),
 body:SafeArea(child:Column(children:[
 Expanded(child:content()),
 nav()
 ])));

 Widget content(){
 if(page==1)return eq();
 if(page==2)return xover();
 if(page==3)return delay();
 if(page==4)return mixer();
 if(page==5)return preset();
 if(page==6)return bluetooth();
 return main();
 }

 Widget box(String t,Widget w)=>Container(
 margin:const EdgeInsets.all(10),
 padding:const EdgeInsets.all(15),
 decoration:BoxDecoration(
 color:const Color(0xff19212b),
 borderRadius:BorderRadius.circular(15)),
 child:Column(children:[
 Text(t,style:const TextStyle(fontSize:22,color:Colors.cyan)),
 w
 ]));

 Widget main()=>box('BP1048P4 7CH DSP',
 Expanded(child:Row(children:List.generate(7,(i)=>
 Expanded(child:Column(children:[
 Text('CH${i+1}'),
 Expanded(child:RotatedBox(
 quarterTurns:3,
 child:Slider(value:.6,onChanged:null))),
 Text('-12 dB')
 ]))))));

 Widget eq()=>box('EQ 15 BAND',
 Expanded(child:ListView(children:List.generate(15,(i)=>
 Slider(value:.5,onChanged:null)))));

 Widget xover()=>box('CROSSOVER',
 const Column(children:[
 Text('HPF'),
 Slider(value:.4,onChanged:null),
 Text('LPF'),
 Slider(value:.7,onChanged:null)
 ]));

 Widget delay()=>box('CHANNEL DELAY',
 Expanded(child:ListView(children:List.generate(7,(i)=>
 ListTile(title:Text('CH${i+1} Delay ms'),
 trailing:const Text('0 ms'))))));

 Widget mixer()=>box('MIXER ROUTING',
 const Text('7CH Input / Output Matrix'));

 Widget preset()=>box('PRESET',
 const Column(children:[
 Text('User Preset 1'),
 Text('Save DSP'),
 Text('Load DSP')
 ]));

 Widget bluetooth()=>box('BLUETOOTH',
 const Text('BP1048P4 Command Interface Ready'));

 Widget nav()=>SizedBox(
 height:55,
 child:Row(
 mainAxisAlignment:MainAxisAlignment.spaceAround,
 children:List.generate(menu.length,(i)=>GestureDetector(
 onTap:()=>setState(()=>page=i),
 child:Text(menu[i],
 style:TextStyle(color:i==page?Colors.cyan:Colors.white))))));
}
