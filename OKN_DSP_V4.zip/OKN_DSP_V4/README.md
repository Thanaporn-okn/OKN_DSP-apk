# OKN DSP — Version.4 / Phase 1

Phase 1 is a clean Android/Jetpack Compose UI build. It intentionally does **not** send commands to the physical DSP yet.

## UI included
- Full-screen responsive layout for phones and tablets.
- Bottom navigation: Home / Mix / Eq.
- Home: interactive simulated Bluetooth/DSP status cards.
- Mix: Master Volume, Bass Volume, Bass Cutoff and Volume Ch1–Ch7.
- Mix sliders and numeric values share the same live state.
- Eq: 15 bands × 7 channels.
- Frequency, Q (Quality Factor), Gain and Ch Volume controls.
- Interactive EQ graph updates immediately when controls move.
- EQ graph points are draggable and update Frequency/Gain immediately.
- Reset EQ.
- Named local preset Save / Load / Delete for Phase 1 UI testing.
- Adaptive two-column layouts on larger tablet widths.

## Phase boundaries
- Phase 1: UI only — current phase.
- Phase 2: Real DSP transport/protocol is implemented only from the DSP control files supplied by the user.
- Phase 3: Release list and release packaging.

## Version history rule
- V1 is preserved as the first rewrite draft.
- V2 fixed EQ nested state so controls redraw the graph through Compose snapshot state.
- V3 fixes empty Home-card interactions and locks EQ drag gestures to the point touched at drag start.
- V4 fixes the GitHub Actions Kotlin compile errors: `enableEdgeToEdge` now imports from `androidx.activity`, and `horizontalScroll` is explicitly imported from `androidx.compose.foundation`.
- Any later source/build error must create the next version rather than overwrite this version.

## Mobile GitHub build
Keep the workflow file at `.github/workflows/OKN_DSP_V4_auto_build.yml`. After that, upload a version ZIP such as `OKN_DSP_V4.zip` to the repository root. A push of `OKN_DSP_V*.zip` starts the APK build automatically.
