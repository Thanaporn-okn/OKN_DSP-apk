import 'package:flutter/material.dart';

void main() {
  runApp(const OKNDSP());
}

class OKNDSP extends StatelessWidget {
  const OKNDSP({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: const Text('OKN_DSP BP1048P4 V40.7'),
        ),
        body: const Padding(
          padding: EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Bluetooth DSP Controller',
                  style: TextStyle(fontSize: 24)),
              SizedBox(height: 20),
              Text('Device Scan'),
              Text('Connect Device'),
              Text('TX / RX Packet'),
              Text('HEX Monitor'),
              Text('7 Channel EQ'),
              Text('Delay Control'),
              Text('HPF / LPF'),
            ],
          ),
        ),
      ),
    );
  }
}