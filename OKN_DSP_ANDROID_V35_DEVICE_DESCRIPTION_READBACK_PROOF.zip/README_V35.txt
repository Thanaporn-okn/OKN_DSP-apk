OKN DSP V35 — VERIFIED DEVICE DESCRIPTION + READBACK PROOF

New evidence from official GoloPine session 2026-09-06 20:45:55
- AUTH16 sent to AB01 and AUTH32 received from AB02.
- Runtime log exposes the same-session RandKey.
- Verified independent post-auth AES-CFB8 TX and RX streams with IV=01 repeated 16 bytes.
- Device-description request decrypts 5DFCB7E5 -> 661C0624.
- Decrypted the complete device-description transfer.
- First RX frame plaintext header: 86 E6 46 00 = marker 0x86 + U24LE payload length 18150.
- Continuation RX frames start with marker 0x82.
- 78 notifications / 18,231 encrypted bytes reconstruct exactly 18,150 UTF-8 JSON bytes.
- JSON parses as GoloPine_DSP_Amplifier with 4 sensors and 15 actuators.
- Verified readback polling: command 0x58 and response 0x60, 83 matched request/response pairs.
- Sensor values confirm FLOAT32 payload is little-endian.

Actuator IDs from the real decoded Device Description
7 SaveParams
2 MasterVolume
3 RemindSoundVolume
8 BassVolume
9 BassCutoff
10 BassBoost
13 MiddleBoost
11 TrebleBoost
4 Left EQ
5 Right EQ
6 Bass EQ
14 Channel 4 EQ
15 Channel 5 EQ
16 Channel 6 EQ
17 Channel 7 EQ

Safety / remaining blocker
- LIVE WRITE remains locked.
- The remaining blocker is standalone extraction of the current-session RandKey from the 32-byte pre-auth response.
- No fixed pre-auth key/IV/KDF is guessed in V35.
