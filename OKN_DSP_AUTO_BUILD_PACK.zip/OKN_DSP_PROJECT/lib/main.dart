import 'package:flutter/material.dart';

void main()=>runApp(const App());

class App extends StatelessWidget{
 const App({super.key});
 @override
 Widget build(BuildContext c)=>MaterialApp(
 debugShowCheckedModeBanner:false,
 home:Scaffold(
 body:Center(
 child:Text('OKN_DSP BP1048P4 BUILD OK',
 style:TextStyle(fontSize:24))
 )));
}
