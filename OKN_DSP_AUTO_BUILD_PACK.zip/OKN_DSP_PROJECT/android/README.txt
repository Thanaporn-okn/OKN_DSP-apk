Android project placeholder
