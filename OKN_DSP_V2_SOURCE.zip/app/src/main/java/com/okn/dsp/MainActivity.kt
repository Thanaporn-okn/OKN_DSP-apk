package com.okn.dsp

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

private val Bg = Color(0xFF00111F)
private val Panel = Color(0xFF06243A)
private val Panel2 = Color(0xFF031B2C)
private val Line = Color(0xFF0A4F7A)
private val Cyan = Color(0xFF00E5FF)
private val Blue = Color(0xFF078BFF)
private val Magenta = Color(0xFFFF35E8)
private val Green = Color(0xFF00F58B)
private val Orange = Color(0xFFFF9D2E)
private val Red = Color(0xFFFF3B6A)
private val Yellow = Color(0xFFFFE62D)
private val Purple = Color(0xFFB72CFF)
private val Muted = Color(0xFF9EC5E5)
private val TextWhite = Color(0xFFF5FAFF)
private val channelColors = listOf(Blue, Cyan, Green, Yellow, Orange, Red, Purple)
private val channelNames = listOf("Front L", "Front R", "Rear L", "Rear R", "Center", "Sub L", "Sub R")

enum class Screen { Home, EQ, Crossover, Delay, Output }

class EqBand(
    type: String,
    frequency: Float,
    gain: Float,
    q: Float,
    enabled: Boolean = true
) {
    var type by mutableStateOf(type)
    var frequency by mutableFloatStateOf(frequency)
    var gain by mutableFloatStateOf(gain)
    var q by mutableFloatStateOf(q)
    var enabled by mutableStateOf(enabled)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
                    OknDspApp()
                }
            }
        }
    }
}

@Composable
fun OknDspApp() {
    val context = LocalContext.current
    val ble = remember { BleController(context.applicationContext) }
    var screen by rememberSaveable { mutableStateOf(Screen.Home) }
    var channel by rememberSaveable { mutableIntStateOf(0) }
    var showDevices by remember { mutableStateOf(false) }

    val permissions = remember {
        if (Build.VERSION.SDK_INT >= 31) arrayOf(
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_CONNECT
        ) else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        if (grants.values.all { it }) {
            ble.startScan()
            showDevices = true
        }
    }

    fun openBlePicker() {
        val missing = permissions.any { context.checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing) launcher.launch(permissions) else {
            ble.startScan()
            showDevices = true
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF001321), Color(0xFF00101C), Color(0xFF000B13))
                )
            )
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Header(ble = ble, home = screen == Screen.Home, onConnectionClick = ::openBlePicker)
            if (screen != Screen.Home) ChannelStrip(selected = channel, onSelect = { channel = it })
            Box(modifier = Modifier.weight(1f)) {
                when (screen) {
                    Screen.Home -> HomeScreen(ble)
                    Screen.EQ -> EqScreen(channel, ble)
                    Screen.Crossover -> CrossoverScreen(channel, ble)
                    Screen.Delay -> DelayScreen(ble)
                    Screen.Output -> OutputScreen(ble)
                }
            }
            BottomNav(screen = screen, onScreen = { screen = it })
        }
    }

    if (showDevices) {
        DeviceDialog(
            ble = ble,
            onDismiss = {
                ble.stopScan()
                showDevices = false
            },
            onSelect = {
                ble.connect(it)
                showDevices = false
            }
        )
    }
}

@Composable
private fun Header(ble: BleController, home: Boolean, onConnectionClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        WaveLogo(54.dp, Cyan)
        Spacer(Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(if (home) "OKN_DSP" else "DSP Control", color = TextWhite, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text("Professional Audio Processor", color = Muted, fontSize = 13.sp)
        }
        val connected = ble.state == BleController.State.Connected
        Row(
            modifier = Modifier
                .border(1.dp, Line, RoundedCornerShape(12.dp))
                .background(Color(0x44002A46), RoundedCornerShape(12.dp))
                .clickable { onConnectionClick() }
                .padding(horizontal = 13.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(13.dp)
                    .shadow(10.dp, CircleShape)
                    .background(if (connected) Green else if (ble.state == BleController.State.Scanning) Yellow else Color(0xFF6D8292), CircleShape)
            )
            Spacer(Modifier.width(10.dp))
            Column {
                Text(
                    when (ble.state) {
                        BleController.State.Connected -> "Connected"
                        BleController.State.Scanning -> "Scanning"
                        BleController.State.Connecting -> "Connecting"
                        else -> "Tap to Connect"
                    },
                    color = if (connected) Green else Muted,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp
                )
                Text(ble.deviceName, color = Muted, fontSize = 12.sp)
            }
            Spacer(Modifier.width(8.dp))
            Text("›", color = Muted, fontSize = 28.sp)
        }
        Spacer(Modifier.width(10.dp))
        NeonIcon("⚙", Cyan, 48.dp)
    }
}

@Composable
private fun DeviceDialog(ble: BleController, onDismiss: () -> Unit, onSelect: (BleController.DeviceItem) -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text("Bluetooth DSP", color = TextWhite, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text(ble.lastInfo, color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                if (ble.devices.isEmpty()) {
                    Text("กำลังค้นหาอุปกรณ์ BLE…", color = TextWhite)
                } else {
                    ble.devices.take(12).forEach { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelect(item) }
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.size(10.dp).background(Cyan, CircleShape))
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(item.name, color = TextWhite)
                                Text(item.address, color = Muted, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = { ble.startScan() }, colors = ButtonDefaults.buttonColors(containerColor = Blue)) {
                Text("Scan")
            }
        },
        dismissButton = {
            Button(onClick = onDismiss, colors = ButtonDefaults.buttonColors(containerColor = Panel2)) {
                Text("Close")
            }
        }
    )
}

@Composable
private fun ChannelStrip(selected: Int, onSelect: (Int) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        repeat(7) { i ->
            val active = selected == i
            Column(
                modifier = Modifier
                    .width(108.dp)
                    .background(
                        if (active) Brush.verticalGradient(listOf(Blue, Cyan.copy(alpha = .7f)))
                        else Brush.verticalGradient(listOf(Panel, Panel2)),
                        RoundedCornerShape(10.dp)
                    )
                    .border(1.dp, if (active) Cyan else Line, RoundedCornerShape(10.dp))
                    .clickable { onSelect(i) }
                    .padding(vertical = 9.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("CH${i + 1}", color = TextWhite, fontWeight = FontWeight.Bold)
                Text(channelNames[i], color = TextWhite, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun BottomNav(screen: Screen, onScreen: (Screen) -> Unit) {
    val items = listOf(
        Triple(Screen.Home, "⌂", "Home"),
        Triple(Screen.EQ, "≋", "EQ"),
        Triple(Screen.Crossover, "⌁", "Crossover"),
        Triple(Screen.Delay, "◷", "Delay"),
        Triple(Screen.Output, "▥", "Output")
    )
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .background(Panel2, RoundedCornerShape(16.dp))
            .border(1.dp, Line, RoundedCornerShape(16.dp))
            .padding(4.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        items.forEach { (target, icon, label) ->
            val active = screen == target
            Column(
                modifier = Modifier
                    .weight(1f)
                    .background(
                        if (active) Brush.verticalGradient(listOf(Color(0xFF0C66E9), Color(0xFF003EAE)))
                        else Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent)),
                        RoundedCornerShape(12.dp)
                    )
                    .clickable { onScreen(target) }
                    .padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(icon, color = if (active) Cyan else Muted, fontSize = 28.sp)
                Text(label, color = if (active) TextWhite else Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun HomeScreen(ble: BleController) {
    var master by remember { mutableFloatStateOf(-3f) }
    var bass by remember { mutableFloatStateOf(4f) }
    var cutoff by remember { mutableFloatStateOf(100f) }
    var bassBoost by remember { mutableFloatStateOf(3f) }
    var middle by remember { mutableFloatStateOf(-2f) }
    var treble by remember { mutableFloatStateOf(1f) }
    var source by remember { mutableStateOf("High Level (Speaker)") }
    var preset by remember { mutableStateOf("Flat") }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            HomeControl("🔊", "Master Volume", "ปรับระดับเสียงรวม", Blue, master, -60f..12f, "dB") {
                master = it; ble.parameterChanged(DspProtocol.Change("home", parameter = "master_volume", numericValue = it))
            }
        }
        item {
            HomeControl("◎", "Bass Volume", "ปรับระดับเสียงเบส", Cyan, bass, -12f..12f, "dB") {
                bass = it; ble.parameterChanged(DspProtocol.Change("home", parameter = "bass_volume", numericValue = it))
            }
        }
        item {
            HomeControl("⌁", "Bass Cutoff", "ตั้งค่าความถี่ตัดเบส", Magenta, cutoff, 20f..500f, "Hz", 0) {
                cutoff = it; ble.parameterChanged(DspProtocol.Change("home", parameter = "bass_cutoff", numericValue = it))
            }
        }
        item {
            HomeControl("▥", "Bass Boost", "เพิ่มความหนักแน่นของเบส", Red, bassBoost, -10f..12f, "dB") {
                bassBoost = it; ble.parameterChanged(DspProtocol.Change("home", parameter = "bass_boost", numericValue = it))
            }
        }
        item {
            HomeControl("≋", "Middle Boost", "เพิ่มความชัดเจนย่านกลาง", Blue, middle, -12f..12f, "dB") {
                middle = it; ble.parameterChanged(DspProtocol.Change("home", parameter = "middle_boost", numericValue = it))
            }
        }
        item {
            HomeControl("✦", "Treble Boost", "เพิ่มความใสย่านแหลม", Magenta, treble, -12f..12f, "dB") {
                treble = it; ble.parameterChanged(DspProtocol.Change("home", parameter = "treble_boost", numericValue = it))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PanelCard(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        NeonIcon("♫", Blue, 54.dp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Audio Source", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text("แหล่งสัญญาณเสียง", color = Muted, fontSize = 12.sp)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    NeonDropdown(source, listOf("High Level (Speaker)", "Low Level (RCA)", "Bluetooth")) {
                        source = it; ble.parameterChanged(DspProtocol.Change("home", parameter = "audio_source", textValue = it))
                    }
                }
                PanelCard(Modifier.weight(1f)) {
                    Text("Device Status", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("สถานะอุปกรณ์", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(10.dp))
                    StatusLine("●", if (ble.state == BleController.State.Connected) "Connected" else "Disconnected", ble.deviceName, if (ble.state == BleController.State.Connected) Green else Muted)
                    StatusLine("▣", "Voltage", "--.- V", Green)
                    StatusLine("♨", "Temperature", "-- °C", Cyan)
                    StatusLine("✓", "System", if (ble.state == BleController.State.Connected) "Normal" else "Standby", Green)
                }
            }
        }
        item {
            PanelCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    NeonIcon("☰", Blue, 54.dp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("System Preset", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("พรีเซ็ตระบบ", color = Muted, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(8.dp))
                NeonDropdown(preset, listOf("Flat", "Driver", "SQL", "Bass", "Custom 1")) {
                    preset = it; ble.parameterChanged(DspProtocol.Change("home", parameter = "system_preset", textValue = it))
                }
            }
        }
    }
}

@Composable
private fun HomeControl(
    icon: String,
    title: String,
    subtitle: String,
    color: Color,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    unit: String,
    decimals: Int = 1,
    onValue: (Float) -> Unit
) {
    PanelCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            NeonIcon(icon, color, 70.dp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.width(190.dp)) {
                Text(title, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 21.sp)
                Text(subtitle, color = Muted, fontSize = 13.sp)
            }
            Slider(
                value = value,
                onValueChange = onValue,
                valueRange = range,
                modifier = Modifier.weight(1f),
                colors = SliderDefaults.colors(
                    thumbColor = TextWhite,
                    activeTrackColor = color,
                    inactiveTrackColor = Color(0xFF244967),
                    activeTickColor = color,
                    inactiveTickColor = Color(0xFF4E7390)
                )
            )
            Spacer(Modifier.width(10.dp))
            ValueBox("${format(value, decimals)} $unit", 104.dp)
        }
    }
}

@Composable
private fun EqScreen(channel: Int, ble: BleController) {
    val bands = remember {
        mutableStateListOf<EqBand>().apply {
            add(EqBand("PEQ", 32f, -3f, .70f))
            add(EqBand("Low Shelf", 100f, 2.5f, 1f))
            add(EqBand("PEQ", 200f, 6f, 1.2f))
            add(EqBand("PEQ", 500f, -4f, 1f))
            add(EqBand("PEQ", 2000f, 3f, 1f))
            add(EqBand("High Shelf", 10000f, -2f, .70f))
            repeat(9) { i -> add(EqBand("PEQ", 1000f + i * 1000f, 0f, 1f)) }
        }
    }
    var group by remember { mutableIntStateOf(0) }
    val range = when (group) { 0 -> 0..5; 1 -> 6..11; else -> 12..14 }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            PanelCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    WaveLogo(62.dp, Cyan)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Parametric EQ", color = TextWhite, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        Text("ปรับแต่งความถี่เสียงอย่างละเอียด", color = Muted, fontSize = 14.sp)
                    }
                    ValueBox("CH${channel + 1} - ${channelNames[channel]}", 165.dp)
                    Spacer(Modifier.width(10.dp))
                    NeonButton("⟳  รีเซ็ต EQ", Cyan) {
                        bands.forEach { it.gain = 0f; it.enabled = true }
                        ble.parameterChanged(DspProtocol.Change("eq", channel, "reset_eq", boolValue = true))
                    }
                }
                Spacer(Modifier.height(12.dp))
                EqGraph(bands)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Bands 1 - 6", "Bands 7 - 12", "Bands 13 - 15").forEachIndexed { i, label ->
                    TabButton(label, group == i, Modifier.weight(1f)) { group = i }
                }
            }
        }
        item {
            PanelCard {
                EqHeader()
                range.forEach { i ->
                    EqRow(i, bands[i], channel, ble)
                    if (i != range.last) Spacer(Modifier.height(6.dp))
                }
            }
        }
        item {
            PanelCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    NeonIcon("□", Blue, 54.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Preset", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("ชุดค่าที่ใช้งานอยู่", color = Muted, fontSize = 12.sp)
                    }
                    ValueBox("Custom 1", 140.dp)
                    Spacer(Modifier.width(10.dp))
                    NeonButton("▣\nSave", Blue) { ble.parameterChanged(DspProtocol.Change("eq", channel, "preset_save", textValue = "Custom 1")) }
                    Spacer(Modifier.width(10.dp))
                    NeonButton("□\nManage", Blue) { ble.parameterChanged(DspProtocol.Change("eq", channel, "preset_manage", textValue = "Custom 1")) }
                }
            }
        }
    }
}

@Composable
private fun EqGraph(bands: List<EqBand>) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(280.dp)
            .background(Color(0xFF001827), RoundedCornerShape(8.dp))
            .border(1.dp, Line, RoundedCornerShape(8.dp))
    ) {
        Canvas(Modifier.fillMaxSize().padding(18.dp)) {
            val w = size.width
            val h = size.height
            repeat(10) { x ->
                val px = w * x / 9f
                drawLine(Color(0x332A6B8D), Offset(px, 0f), Offset(px, h), 1f)
            }
            repeat(7) { y ->
                val py = h * y / 6f
                drawLine(Color(0x332A6B8D), Offset(0f, py), Offset(w, py), 1f)
            }
            val active = bands.take(8)
            if (active.isNotEmpty()) {
                val path = Path()
                active.forEachIndexed { i, b ->
                    val x = logX(b.frequency, 20f, 20000f) * w
                    val y = (1f - ((b.gain + 12f) / 24f)) * h
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                drawPath(path, Brush.horizontalGradient(channelColors + Magenta), style = Stroke(4f, cap = StrokeCap.Round))
                active.forEachIndexed { i, b ->
                    val x = logX(b.frequency, 20f, 20000f) * w
                    val y = (1f - ((b.gain + 12f) / 24f)) * h
                    drawCircle(channelColors[i % channelColors.size], 10f, Offset(x, y))
                    drawCircle(TextWhite, 5f, Offset(x, y))
                }
            }
        }
        Text("dB", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(6.dp))
        Text("20     50      100      200      500      1k       2k       5k      10k     20k   Hz", color = Muted, fontSize = 10.sp, modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 2.dp))
    }
}

@Composable
private fun EqHeader() {
    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("#", color = Muted, modifier = Modifier.width(60.dp), textAlign = TextAlign.Center)
        Text("Type", color = TextWhite, modifier = Modifier.width(150.dp))
        Text("Frequency", color = TextWhite, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
        Text("Gain", color = TextWhite, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
        Text("Q", color = TextWhite, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
        Text("Power", color = TextWhite, modifier = Modifier.width(80.dp), textAlign = TextAlign.Center)
    }
}

@Composable
private fun EqRow(index: Int, band: EqBand, channel: Int, ble: BleController) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Row(Modifier.width(60.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(18.dp).background(channelColors[index % channelColors.size], CircleShape))
            Spacer(Modifier.width(8.dp))
            Text("${index + 1}", color = TextWhite)
        }
        Box(Modifier.width(150.dp)) {
            NeonDropdown(band.type, listOf("PEQ", "Low Shelf", "High Shelf")) {
                band.type = it
                ble.parameterChanged(DspProtocol.Change("eq", channel, "band_${index + 1}_type", textValue = it))
            }
        }
        StepperBox(formatFreq(band.frequency), Modifier.weight(1f), onMinus = {
            band.frequency = max(20f, band.frequency / 1.12f)
            ble.parameterChanged(DspProtocol.Change("eq", channel, "band_${index + 1}_frequency", numericValue = band.frequency))
        }, onPlus = {
            band.frequency = min(20000f, band.frequency * 1.12f)
            ble.parameterChanged(DspProtocol.Change("eq", channel, "band_${index + 1}_frequency", numericValue = band.frequency))
        })
        StepperBox("${format(band.gain, 1)} dB", Modifier.weight(1f), onMinus = {
            band.gain = max(-12f, band.gain - .5f)
            ble.parameterChanged(DspProtocol.Change("eq", channel, "band_${index + 1}_gain", numericValue = band.gain))
        }, onPlus = {
            band.gain = min(12f, band.gain + .5f)
            ble.parameterChanged(DspProtocol.Change("eq", channel, "band_${index + 1}_gain", numericValue = band.gain))
        })
        StepperBox(format(band.q, 2), Modifier.weight(1f), onMinus = {
            band.q = max(.1f, band.q - .1f)
            ble.parameterChanged(DspProtocol.Change("eq", channel, "band_${index + 1}_q", numericValue = band.q))
        }, onPlus = {
            band.q = min(10f, band.q + .1f)
            ble.parameterChanged(DspProtocol.Change("eq", channel, "band_${index + 1}_q", numericValue = band.q))
        })
        Box(Modifier.width(80.dp), contentAlignment = Alignment.Center) {
            Switch(
                checked = band.enabled,
                onCheckedChange = {
                    band.enabled = it
                    ble.parameterChanged(DspProtocol.Change("eq", channel, "band_${index + 1}_power", boolValue = it))
                },
                colors = SwitchDefaults.colors(checkedTrackColor = Blue, checkedThumbColor = TextWhite, uncheckedTrackColor = Color(0xFF233F59))
            )
        }
    }
}

@Composable
private fun CrossoverScreen(channel: Int, ble: BleController) {
    var hpfBypass by remember { mutableStateOf(false) }
    var lpfBypass by remember { mutableStateOf(false) }
    var hpfType by remember { mutableStateOf("Linkwitz-Riley") }
    var lpfType by remember { mutableStateOf("Linkwitz-Riley") }
    var hpfFreq by remember { mutableStateOf("100 Hz") }
    var lpfFreq by remember { mutableStateOf("1.0 kHz") }
    var hpfSlope by remember { mutableStateOf("24 dB/Oct") }
    var lpfSlope by remember { mutableStateOf("24 dB/Oct") }
    var phase by remember { mutableStateOf("0°") }
    var polarity by remember { mutableStateOf("Normal") }
    var link by remember { mutableStateOf(true) }
    var mode by remember { mutableStateOf("Stereo") }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            PanelCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    NeonIcon("⌁", Magenta, 70.dp)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Crossover", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 28.sp)
                        Text("ตั้งค่าการแบ่งความถี่", color = Muted, fontSize = 14.sp)
                    }
                    ValueBox("Magnitude", 120.dp)
                    Spacer(Modifier.width(8.dp))
                    NeonButton("⟳ Reset", Cyan) {
                        hpfBypass = false; lpfBypass = false
                        hpfType = "Linkwitz-Riley"; lpfType = "Linkwitz-Riley"
                        hpfFreq = "100 Hz"; lpfFreq = "1.0 kHz"
                        hpfSlope = "24 dB/Oct"; lpfSlope = "24 dB/Oct"
                        ble.parameterChanged(DspProtocol.Change("crossover", channel, "reset", boolValue = true))
                    }
                }
                Spacer(Modifier.height(12.dp))
                CrossoverGraph()
            }
        }
        item {
            FilterPanel(
                title = "High Pass Filter (HPF)", subtitle = "กรองความถี่ต่ำออก", color = Cyan,
                bypass = hpfBypass, onBypass = {
                    hpfBypass = it; ble.parameterChanged(DspProtocol.Change("crossover", channel, "hpf_bypass", boolValue = it))
                }, type = hpfType, onType = {
                    hpfType = it; ble.parameterChanged(DspProtocol.Change("crossover", channel, "hpf_type", textValue = it))
                }, frequency = hpfFreq, onFrequency = {
                    hpfFreq = it; ble.parameterChanged(DspProtocol.Change("crossover", channel, "hpf_frequency", textValue = it))
                }, slope = hpfSlope, onSlope = {
                    hpfSlope = it; ble.parameterChanged(DspProtocol.Change("crossover", channel, "hpf_slope", textValue = it))
                }
            )
        }
        item {
            FilterPanel(
                title = "Low Pass Filter (LPF)", subtitle = "กรองความถี่สูงออก", color = Magenta,
                bypass = lpfBypass, onBypass = {
                    lpfBypass = it; ble.parameterChanged(DspProtocol.Change("crossover", channel, "lpf_bypass", boolValue = it))
                }, type = lpfType, onType = {
                    lpfType = it; ble.parameterChanged(DspProtocol.Change("crossover", channel, "lpf_type", textValue = it))
                }, frequency = lpfFreq, onFrequency = {
                    lpfFreq = it; ble.parameterChanged(DspProtocol.Change("crossover", channel, "lpf_frequency", textValue = it))
                }, slope = lpfSlope, onSlope = {
                    lpfSlope = it; ble.parameterChanged(DspProtocol.Change("crossover", channel, "lpf_slope", textValue = it))
                }
            )
        }
        item {
            PanelCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    NeonIcon("⚙", Blue, 52.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Advanced Settings", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("ตั้งค่าขั้นสูง", color = Muted, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    LabeledDrop("Phase", phase, listOf("0°", "90°", "180°", "270°"), Modifier.weight(1f)) {
                        phase = it; ble.parameterChanged(DspProtocol.Change("crossover", channel, "phase", textValue = it))
                    }
                    LabeledDrop("Polarity", polarity, listOf("Normal", "Invert"), Modifier.weight(1f)) {
                        polarity = it; ble.parameterChanged(DspProtocol.Change("crossover", channel, "polarity", textValue = it))
                    }
                    Column(
                        modifier = Modifier.weight(1f).border(1.dp, Line, RoundedCornerShape(10.dp)).padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Link L/R", color = TextWhite, fontSize = 12.sp)
                        Switch(checked = link, onCheckedChange = {
                            link = it; ble.parameterChanged(DspProtocol.Change("crossover", channel, "link_lr", boolValue = it))
                        }, colors = SwitchDefaults.colors(checkedTrackColor = Blue))
                    }
                    LabeledDrop("Output Mode", mode, listOf("Stereo", "Mono"), Modifier.weight(1f)) {
                        mode = it; ble.parameterChanged(DspProtocol.Change("crossover", channel, "output_mode", textValue = it))
                    }
                }
            }
        }
    }
}

@Composable
private fun CrossoverGraph() {
    Box(
        Modifier.fillMaxWidth().height(285.dp)
            .background(Color(0xFF001827), RoundedCornerShape(8.dp))
            .border(1.dp, Line, RoundedCornerShape(8.dp))
    ) {
        Canvas(Modifier.fillMaxSize().padding(18.dp)) {
            val w = size.width; val h = size.height
            repeat(10) { x -> drawLine(Color(0x332A6B8D), Offset(w*x/9f,0f), Offset(w*x/9f,h), 1f) }
            repeat(6) { y -> drawLine(Color(0x332A6B8D), Offset(0f,h*y/5f), Offset(w,h*y/5f), 1f) }
            val hpf = Path().apply {
                moveTo(0f, h*.98f)
                cubicTo(w*.25f,h*.8f, w*.38f,h*.25f, w*.50f,h*.34f)
                cubicTo(w*.60f,h*.34f, w*.75f,h*.34f, w,h*.34f)
            }
            val lpf = Path().apply {
                moveTo(0f,h*.34f)
                cubicTo(w*.45f,h*.34f,w*.55f,h*.34f,w*.62f,h*.42f)
                cubicTo(w*.72f,h*.60f,w*.85f,h*.9f,w,h*.98f)
            }
            drawPath(hpf, Cyan, style = Stroke(4f, cap = StrokeCap.Round))
            drawPath(lpf, Magenta, style = Stroke(4f, cap = StrokeCap.Round))
            drawCircle(Cyan, 10f, Offset(w*.49f,h*.34f)); drawCircle(TextWhite, 5f, Offset(w*.49f,h*.34f))
            drawCircle(Magenta, 10f, Offset(w*.58f,h*.34f)); drawCircle(TextWhite, 5f, Offset(w*.58f,h*.34f))
        }
        Row(Modifier.align(Alignment.TopEnd).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("●", color = Cyan); Text(" High Pass (HPF)  ", color = Muted, fontSize = 11.sp)
            Text("●", color = Magenta); Text(" Low Pass (LPF)", color = Muted, fontSize = 11.sp)
        }
        Text("20    50    100    200    500    1k    2k    5k    10k    20k  Hz", color = Muted, fontSize = 10.sp, modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 2.dp))
    }
}

@Composable
private fun FilterPanel(
    title: String, subtitle: String, color: Color,
    bypass: Boolean, onBypass: (Boolean)->Unit,
    type: String, onType: (String)->Unit,
    frequency: String, onFrequency: (String)->Unit,
    slope: String, onSlope: (String)->Unit
) {
    PanelCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            NeonIcon("⌁", color, 70.dp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = TextWhite, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text(subtitle, color = Muted, fontSize = 13.sp)
            }
            Text("Bypass", color = Muted)
            Spacer(Modifier.width(8.dp))
            Switch(checked = bypass, onCheckedChange = onBypass, colors = SwitchDefaults.colors(checkedTrackColor = color))
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            LabeledDrop("Type", type, listOf("Linkwitz-Riley", "Butterworth", "Bessel"), Modifier.weight(1f), onType)
            LabeledDrop("Frequency", frequency, listOf("20 Hz", "50 Hz", "80 Hz", "100 Hz", "200 Hz", "500 Hz", "1.0 kHz", "2.0 kHz", "5.0 kHz", "10.0 kHz", "20.0 kHz"), Modifier.weight(1f), onFrequency)
            LabeledDrop("Slope", slope, listOf("6 dB/Oct", "12 dB/Oct", "18 dB/Oct", "24 dB/Oct", "36 dB/Oct", "48 dB/Oct"), Modifier.weight(1f), onSlope)
        }
    }
}

@Composable
private fun DelayScreen(ble: BleController) {
    val delays = remember { mutableStateListOf(0f, 1.25f, 2.60f, 2.30f, .80f, 3.10f, 1.90f) }
    var unitMs by remember { mutableStateOf(true) }
    var seat by remember { mutableStateOf("Driver (Left)") }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            PanelCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    NeonIcon("◷", Green, 70.dp)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Delay", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 28.sp)
                        Text("ตั้งค่าหน่วงเวลาเพื่อการจัดตำแหน่งเสียง", color = Muted, fontSize = 13.sp)
                    }
                    Row(
                        Modifier.border(1.dp, Line, RoundedCornerShape(9.dp)).padding(3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TabButton("ms", unitMs, Modifier.width(58.dp)) { unitMs = true }
                        TabButton("cm", !unitMs, Modifier.width(58.dp)) { unitMs = false }
                    }
                    Spacer(Modifier.width(8.dp))
                    NeonButton("⟳ ซิงค์ทุกช่อง", Cyan) {
                        val mx = delays.maxOrNull() ?: 0f
                        delays.indices.forEach { delays[it] = mx }
                        ble.parameterChanged(DspProtocol.Change("delay", parameter = "sync_all", numericValue = mx))
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CarDelayGraphic(delays, Modifier.weight(1.35f))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        MiniInfo("Seat Preset", "ตำแหน่งการฟัง") {
                            NeonDropdown(seat, listOf("Driver (Left)", "Passenger (Right)", "Front Center", "All Seats")) {
                                seat = it; ble.parameterChanged(DspProtocol.Change("delay", parameter = "seat_preset", textValue = it))
                            }
                        }
                        MiniInfo("Distance Reference", "อ้างอิงระยะทางเสียง") {
                            Text("Speed of Sound (20°C)\n343 m/s (34.3 cm/ms)", color = Muted, fontSize = 12.sp)
                        }
                        MiniInfo("Total Delay Range", "ช่วงหน่วงเวลาทั้งหมด") {
                            Text("0.00 ms                 ${format(delays.maxOrNull() ?: 0f,2)} ms", color = TextWhite, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
        itemsIndexed(delays) { i, value ->
            DelayRow(i, value, unitMs) { new ->
                delays[i] = new
                ble.parameterChanged(DspProtocol.Change("delay", i, "delay_ms", numericValue = new))
            }
        }
    }
}

@Composable
private fun CarDelayGraphic(delays: List<Float>, modifier: Modifier = Modifier) {
    Box(
        modifier.height(330.dp)
            .background(Color(0xFF001827), RoundedCornerShape(12.dp))
            .border(1.dp, Line, RoundedCornerShape(12.dp))
    ) {
        Canvas(Modifier.fillMaxSize().padding(20.dp)) {
            val r = Rect(size.width*.18f, size.height*.06f, size.width*.82f, size.height*.94f)
            drawRoundRect(Color(0xFF063255), topLeft = r.topLeft, size = r.size, cornerRadius = androidx.compose.ui.geometry.CornerRadius(45f,45f), style = Stroke(4f))
            drawRoundRect(Color(0xFF0A5BA0).copy(alpha=.25f), topLeft = Offset(size.width*.30f,size.height*.23f), size = androidx.compose.ui.geometry.Size(size.width*.17f,size.height*.20f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(18f,18f))
            drawRoundRect(Color(0xFF0A5BA0).copy(alpha=.25f), topLeft = Offset(size.width*.53f,size.height*.23f), size = androidx.compose.ui.geometry.Size(size.width*.17f,size.height*.20f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(18f,18f))
            drawRoundRect(Color(0xFF0A5BA0).copy(alpha=.25f), topLeft = Offset(size.width*.30f,size.height*.57f), size = androidx.compose.ui.geometry.Size(size.width*.17f,size.height*.20f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(18f,18f))
            drawRoundRect(Color(0xFF0A5BA0).copy(alpha=.25f), topLeft = Offset(size.width*.53f,size.height*.57f), size = androidx.compose.ui.geometry.Size(size.width*.17f,size.height*.20f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(18f,18f))
            val pts = listOf(
                Offset(size.width*.18f,size.height*.30f), Offset(size.width*.82f,size.height*.30f),
                Offset(size.width*.18f,size.height*.66f), Offset(size.width*.82f,size.height*.66f),
                Offset(size.width*.50f,size.height*.08f), Offset(size.width*.50f,size.height*.90f), Offset(size.width*.50f,size.height*.82f)
            )
            pts.forEachIndexed { i,p ->
                drawCircle(channelColors[i], 16f, p); drawCircle(TextWhite, 7f, p)
            }
        }
        Text("${format(delays.getOrElse(4){0f},2)} ms", color = TextWhite, fontSize = 11.sp, modifier = Modifier.align(Alignment.TopCenter).padding(top = 4.dp))
        Text("${format(delays.getOrElse(0){0f},2)} ms", color = TextWhite, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterStart).padding(start = 4.dp))
        Text("${format(delays.getOrElse(1){0f},2)} ms", color = TextWhite, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterEnd).padding(end = 4.dp))
        Text("${format(delays.getOrElse(5){0f},2)} ms", color = TextWhite, fontSize = 11.sp, modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 5.dp))
    }
}

@Composable
private fun DelayRow(index: Int, value: Float, unitMs: Boolean, onValue: (Float)->Unit) {
    PanelCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(24.dp).background(channelColors[index], CircleShape))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.width(90.dp)) {
                Text("CH${index+1}", color = TextWhite, fontWeight = FontWeight.Bold)
                Text(channelNames[index], color = Muted, fontSize = 11.sp)
            }
            Slider(
                value = value,
                onValueChange = onValue,
                valueRange = 0f..10f,
                modifier = Modifier.weight(1f),
                colors = SliderDefaults.colors(thumbColor = TextWhite, activeTrackColor = channelColors[index], inactiveTrackColor = Color(0xFF244967))
            )
            Spacer(Modifier.width(10.dp))
            val cm = value * 34.3f
            ValueBox(if (unitMs) "${format(value,2)} ms\n${format(cm,1)} cm" else "${format(cm,1)} cm\n${format(value,2)} ms", 112.dp)
        }
    }
}

@Composable
private fun OutputScreen(ble: BleController) {
    var master by remember { mutableFloatStateOf(-1f) }
    val gains = remember { mutableStateListOf(-3f, -2.5f, -4f, -1f, -2f, -3.5f, -4.5f) }
    val mute = remember { mutableStateListOf(false,false,false,false,false,false,false) }
    val solo = remember { mutableStateListOf(false,false,false,false,false,false,false) }
    val phase = remember { mutableStateListOf(false,false,false,false,false,false,false) }
    val link = remember { mutableStateListOf(true,true,false,false,false,false,false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            PanelCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    NeonIcon("🔊", Orange, 70.dp)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Output", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 28.sp)
                        Text("ปรับระดับเอาต์พุตแต่ละช่อง", color = Muted, fontSize = 13.sp)
                    }
                    NeonButton("🔇 All Mute Off", Cyan) { mute.indices.forEach { mute[it] = false }; ble.parameterChanged(DspProtocol.Change("output", parameter = "all_mute_off", boolValue = true)) }
                    Spacer(Modifier.width(8.dp))
                    NeonButton("⟳ Reset Levels", Cyan) {
                        master = -1f
                        gains.indices.forEach { gains[it] = listOf(-3f,-2.5f,-4f,-1f,-2f,-3.5f,-4.5f)[it] }
                        ble.parameterChanged(DspProtocol.Change("output", parameter = "reset_levels", boolValue = true))
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PanelCard(Modifier.weight(1.4f)) {
                        Text("Output Level Overview", color = TextWhite, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(6.dp))
                        OutputMeters(gains)
                    }
                    PanelCard(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Master Output", color = TextWhite, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                            ValueBox("${format(master,1)} dB", 86.dp)
                        }
                        Slider(
                            value = master, onValueChange = {
                                master = it; ble.parameterChanged(DspProtocol.Change("output", parameter="master_output", numericValue=it))
                            }, valueRange = -60f..12f,
                            colors = SliderDefaults.colors(thumbColor = TextWhite, activeTrackColor = Blue, inactiveTrackColor = Color(0xFF244967))
                        )
                    }
                }
            }
        }
        itemsIndexed(gains) { i, gain ->
            OutputRow(
                index = i, gain = gain, muted = mute[i], soloed = solo[i], phased = phase[i], linked = link[i],
                onGain = { gains[i] = it; ble.parameterChanged(DspProtocol.Change("output", i, "gain", numericValue = it)) },
                onMute = { mute[i] = it; ble.parameterChanged(DspProtocol.Change("output", i, "mute", boolValue = it)) },
                onSolo = { solo[i] = it; ble.parameterChanged(DspProtocol.Change("output", i, "solo", boolValue = it)) },
                onPhase = { phase[i] = it; ble.parameterChanged(DspProtocol.Change("output", i, "phase", boolValue = it)) },
                onLink = { link[i] = it; ble.parameterChanged(DspProtocol.Change("output", i, "link", boolValue = it)) }
            )
        }
    }
}

@Composable
private fun OutputMeters(gains: List<Float>) {
    Row(Modifier.fillMaxWidth().height(120.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Bottom) {
        gains.forEachIndexed { i,g ->
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.width(18.dp).height(82.dp).background(Color(0xFF062943), RoundedCornerShape(3.dp)), contentAlignment = Alignment.BottomCenter) {
                    Box(Modifier.fillMaxWidth().height(((g + 60f)/72f * 82f).coerceIn(8f,82f).dp).background(channelColors[i], RoundedCornerShape(3.dp)))
                }
                Text("CH${i+1}", color = TextWhite, fontSize = 9.sp)
                Text(channelNames[i], color = Muted, fontSize = 8.sp)
            }
        }
    }
}

@Composable
private fun OutputRow(
    index: Int, gain: Float, muted: Boolean, soloed: Boolean, phased: Boolean, linked: Boolean,
    onGain: (Float)->Unit, onMute:(Boolean)->Unit, onSolo:(Boolean)->Unit, onPhase:(Boolean)->Unit, onLink:(Boolean)->Unit
) {
    PanelCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).border(3.dp, channelColors[index], CircleShape), contentAlignment = Alignment.Center) {
                Text("${index+1}", color = TextWhite, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.width(78.dp)) {
                Text("CH${index+1}", color = TextWhite, fontWeight = FontWeight.Bold)
                Text(channelNames[index], color = Muted, fontSize = 11.sp)
            }
            Slider(
                value = gain, onValueChange = onGain, valueRange = -60f..12f, modifier = Modifier.weight(1f),
                colors = SliderDefaults.colors(thumbColor = TextWhite, activeTrackColor = channelColors[index], inactiveTrackColor = Color(0xFF244967))
            )
            ValueBox("${format(gain,1)} dB", 82.dp)
            Spacer(Modifier.width(6.dp))
            ToggleSquare("🔇", "Mute", muted, onMute)
            ToggleSquare("♬", "Solo", soloed, onSolo)
            ToggleSquare("Ø", "Phase", phased, onPhase)
            if (index < 2) ToggleSquare("🔗", "Link", linked, onLink)
        }
    }
}

@Composable
private fun ToggleSquare(icon: String, label: String, checked: Boolean, onChecked: (Boolean)->Unit) {
    Column(
        modifier = Modifier
            .padding(start = 4.dp)
            .width(54.dp)
            .background(if (checked) Color(0xFF064B88) else Panel2, RoundedCornerShape(8.dp))
            .border(1.dp, if (checked) Cyan else Line, RoundedCornerShape(8.dp))
            .clickable { onChecked(!checked) }
            .padding(vertical = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(icon, color = if (checked) Cyan else TextWhite, fontSize = 17.sp)
        Text(label, color = Muted, fontSize = 8.sp)
    }
}

@Composable
private fun PanelCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth().border(1.dp, Line, RoundedCornerShape(14.dp)),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Panel.copy(alpha = .90f))
    ) {
        Column(Modifier.padding(12.dp), content = content)
    }
}

@Composable
private fun NeonIcon(text: String, color: Color, size: androidx.compose.ui.unit.Dp) {
    Box(
        modifier = Modifier
            .size(size)
            .shadow(16.dp, CircleShape)
            .background(Brush.radialGradient(listOf(color.copy(alpha=.28f), Color.Transparent)), CircleShape)
            .border(2.dp, color, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = color, fontSize = (size.value * .43f).sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
    }
}

@Composable
private fun WaveLogo(size: androidx.compose.ui.unit.Dp, color: Color) {
    Canvas(Modifier.size(size)) {
        val xs = listOf(.18f,.34f,.50f,.66f,.82f)
        val heights = listOf(.45f,.75f,1f,.72f,.45f)
        xs.forEachIndexed { i,x ->
            drawLine(
                color = color,
                start = Offset(this.size.width*x, this.size.height*(.5f-heights[i]*.35f)),
                end = Offset(this.size.width*x, this.size.height*(.5f+heights[i]*.35f)),
                strokeWidth = this.size.width*.09f,
                cap = StrokeCap.Round
            )
        }
    }
}

@Composable
private fun ValueBox(text: String, width: androidx.compose.ui.unit.Dp) {
    Box(
        modifier = Modifier
            .width(width)
            .border(1.dp, Color(0xFF315D82), RoundedCornerShape(9.dp))
            .background(Color(0x44000A12), RoundedCornerShape(9.dp))
            .padding(horizontal = 8.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = TextWhite, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, fontSize = 13.sp)
    }
}

@Composable
private fun NeonButton(text: String, color: Color, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        shape = RoundedCornerShape(9.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Color(0x44061F34), contentColor = TextWhite),
        modifier = Modifier.border(1.dp, color.copy(alpha=.65f), RoundedCornerShape(9.dp)),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 9.dp)
    ) {
        Text(text, textAlign = TextAlign.Center, fontSize = 12.sp)
    }
}

@Composable
private fun NeonDropdown(value: String, options: List<String>, onValue: (String)->Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFF315D82), RoundedCornerShape(8.dp))
                .clickable { open = true }
                .padding(horizontal = 10.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(value, color = TextWhite, fontSize = 12.sp, modifier = Modifier.weight(1f), maxLines = 1)
            Text("⌄", color = Muted)
        }
        DropdownMenu(
            expanded = open,
            onDismissRequest = { open = false },
            modifier = Modifier.background(Panel2)
        ) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option, color = TextWhite) },
                    onClick = { onValue(option); open = false }
                )
            }
        }
    }
}

@Composable
private fun TabButton(label: String, active: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .height(44.dp)
            .background(
                if (active) Brush.verticalGradient(listOf(Color(0xFF0B78FF), Color(0xFF05D4FF)))
                else Brush.verticalGradient(listOf(Panel, Panel2)),
                RoundedCornerShape(9.dp)
            )
            .border(1.dp, if (active) Cyan else Line, RoundedCornerShape(9.dp))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = TextWhite, fontWeight = if (active) FontWeight.Bold else FontWeight.Normal, fontSize = 12.sp)
    }
}

@Composable
private fun StepperBox(text: String, modifier: Modifier = Modifier, onMinus: ()->Unit, onPlus: ()->Unit) {
    Row(
        modifier = modifier
            .padding(horizontal = 2.dp)
            .border(1.dp, Color(0xFF315D82), RoundedCornerShape(7.dp)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("‹", color = Muted, fontSize = 20.sp, modifier = Modifier.clickable { onMinus() }.padding(horizontal = 6.dp, vertical = 5.dp))
        Text(text, color = TextWhite, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f), maxLines = 1)
        Text("›", color = Muted, fontSize = 20.sp, modifier = Modifier.clickable { onPlus() }.padding(horizontal = 6.dp, vertical = 5.dp))
    }
}

@Composable
private fun LabeledDrop(label: String, value: String, options: List<String>, modifier: Modifier = Modifier, onValue: (String)->Unit) {
    Column(modifier = modifier.border(1.dp, Line, RoundedCornerShape(9.dp)).padding(8.dp)) {
        Text(label, color = TextWhite, fontSize = 11.sp)
        Spacer(Modifier.height(4.dp))
        NeonDropdown(value, options, onValue)
    }
}

@Composable
private fun StatusLine(icon: String, left: String, right: String, color: Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(icon, color = color, modifier = Modifier.width(24.dp))
        Text(left, color = Muted, fontSize = 11.sp, modifier = Modifier.weight(1f))
        Text(right, color = if (right == "Normal") Green else Muted, fontSize = 11.sp)
    }
}

@Composable
private fun MiniInfo(title: String, subtitle: String, content: @Composable ColumnScope.()->Unit) {
    Column(
        Modifier.fillMaxWidth().border(1.dp, Line, RoundedCornerShape(10.dp)).background(Color(0x330A3551), RoundedCornerShape(10.dp)).padding(10.dp)
    ) {
        Text(title, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text(subtitle, color = Muted, fontSize = 10.sp)
        Spacer(Modifier.height(6.dp))
        content()
    }
}

private fun format(value: Float, decimals: Int): String = String.format(Locale.US, "% .${decimals}f", value).trim()
private fun formatFreq(value: Float): String = if (value >= 1000f) "${format(value/1000f,1)} kHz" else "${format(value,0)} Hz"
private fun logX(value: Float, minV: Float, maxV: Float): Float {
    val v = value.coerceIn(minV, maxV)
    return ((ln(v) - ln(minV)) / (ln(maxV) - ln(minV))).coerceIn(0f,1f)
}
