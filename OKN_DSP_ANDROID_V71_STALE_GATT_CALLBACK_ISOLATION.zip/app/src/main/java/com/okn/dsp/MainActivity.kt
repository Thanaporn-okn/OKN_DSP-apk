package com.okn.dsp

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * V71 production stale-GATT callback isolation control hub.
 *
 * V71 preserves the runtime-qualified V70 writer scope, PRE/POST SaveParams guards, and
 * power-cycle/reconnect persistence proof. New in V71, every BLE GATT callback must belong
 * to the current active BluetoothGatt instance before it can touch session state. No new
 * write family is enabled.
 */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
    }

    private fun buildUi(): ScrollView {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 32)
        }

        root.addView(TextView(this).apply {
            text = "OKN DSP V71 — PRODUCTION STALE-GATT CALLBACK ISOLATION"
            textSize = 22f
        })

        root.addView(TextView(this).apply {
            text = "REAL DSP CONTROLS ONLY • NO MOCK EQ • NO LOCAL PRESET WRITE • GENERIC WRITES LOCKED"
            textSize = 14f
            setPadding(0, 8, 0, 12)
        })

        root.addView(TextView(this).apply {
            text = "Verified coverage\n" +
                "• Global FLOAT32: IDs 2,3,8,9,10,13,11\n" +
                "• EQ 7CH: actuator IDs 4,5,6,14,15,16,17 • 15 bands/channel\n" +
                "• SaveParams: ID7 exact trigger 570000000700000000\n" +
                "• V71 unified dashboard: V70-qualified Global + safe-PEAKING EQ writes, PRE/POST Save guards, and power-cycle proof preserved; stale GATT callbacks are isolated before state mutation.\n" +
                "• REFRESH ALL now visibly reports START/COMPLETE + time + changed counts even when values are unchanged.\n" +
                "• Preset, Delay and unknown writes remain locked."
            textSize = 13f
            setPadding(0, 0, 0, 16)
        })

        root.addView(Button(this).apply {
            text = "UNIFIED V71 • V70 VERIFIED SCOPE + STALE-GATT CALLBACK ISOLATION"
            setOnClickListener { startActivity(Intent(this@MainActivity, UnifiedControlActivity::class.java)) }
        })
        root.addView(TextView(this).apply {
            text = "V71 Phase 5: all V70 scalar/EQ write/verify/rollback, PRE/POST Save guards, and 7+105 power-cycle proof remain unchanged. New hardening rejects every callback whose BluetoothGatt object is not the active gatt before it can touch connection/session/crypto/ticket state. No protocol writer is added."
            textSize = 12f
            setPadding(0, 2, 0, 12)
        })

        root.addView(Button(this).apply {
            text = "GLOBAL CONTROLS • 7 VERIFIED REAL DSP CONTROLS • APPLY + VERIFY + PERMANENT SAVE"
            setOnClickListener { startActivity(Intent(this@MainActivity, ScalarControlActivity::class.java)) }
        })
        root.addView(TextView(this).apply {
            text = "Production Global Controls: every APPLY uses WRITE 0x57 → fresh Device Description verify → automatic rollback if verify fails. Permanent Save remains a separate guarded action."
            textSize = 12f
            setPadding(0, 2, 0, 12)
        })

        root.addView(Button(this).apply {
            text = "LIVE EQ 7CH • REAL DSP • APPLY + VERIFY + PERMANENT SAVE"
            setOnClickListener { startActivity(Intent(this@MainActivity, LiveEqActivity::class.java)) }
        })
        root.addView(TextView(this).apply {
            text = "7CH real EQ from live Device Description • 105 bands • writes only verified safe PEAKING bands • automatic rollback when readback does not match."
            textSize = 12f
            setPadding(0, 2, 0, 12)
        })

        root.addView(Button(this).apply {
            text = "ADVANCED • EVIDENCE / CAPTURE LAB (READ-ONLY / PROOF TOOLS)"
            setOnClickListener { startActivity(Intent(this@MainActivity, EvidenceLabActivity::class.java)) }
        })

        return ScrollView(this).apply { addView(root) }
    }
}
