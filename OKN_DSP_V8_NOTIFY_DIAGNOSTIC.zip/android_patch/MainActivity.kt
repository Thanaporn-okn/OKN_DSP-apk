package com.okn.okn_dsp

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.BluetoothLeScanner
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.app.ActivityCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : FlutterActivity() {
    private val methods = "okn_dsp/methods"
    private val events = "okn_dsp/events"
    private var sink: EventChannel.EventSink? = null
    private var gatt: BluetoothGatt? = null

    private val serviceUuid = "0000ab00-0000-1000-8000-00805f9b34fb"
    private val rxUuids = setOf(
        "0000ab02-0000-1000-8000-00805f9b34fb",
        "0000ab03-0000-1000-8000-00805f9b34fb"
    )
    private val cccdUuid = "00002902-0000-1000-8000-00805f9b34fb"

    override fun configureFlutterEngine(engine: FlutterEngine) {
        super.configureFlutterEngine(engine)
        EventChannel(engine.dartExecutor.binaryMessenger, events)
            .setStreamHandler(object : EventChannel.StreamHandler {
                override fun onListen(a: Any?, s: EventChannel.EventSink?) { sink = s }
                override fun onCancel(a: Any?) { sink = null }
            })

        MethodChannel(engine.dartExecutor.binaryMessenger, methods)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "connect" -> {
                        val address = call.argument<String>("address")
                        if (address == null) result.error("ADDRESS", "Missing address", null)
                        else { connect(address); result.success(null) }
                    }
                    else -> result.notImplemented()
                }
            }
    }

    private fun emit(m: Map<String, Any?>) = runOnUiThread { sink?.success(m) }

    private fun permissionOk(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
        (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) ==
            PackageManager.PERMISSION_GRANTED)

    @SuppressLint("MissingPermission")
    private fun connect(address: String) {
        if (!permissionOk()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 3001)
            emit(mapOf("type" to "status", "message" to "ต้องอนุญาต Bluetooth ก่อน"))
            return
        }
        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val device = manager.adapter.getRemoteDevice(address)
        gatt?.close()
        emit(mapOf("type" to "status", "message" to "กำลังเชื่อมต่อ $address ..."))
        gatt = device.connectGatt(this, false, callback, BluetoothDevice.TRANSPORT_LE)
    }

    private val callback = object : BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, state: Int) {
            if (state == BluetoothProfile.STATE_CONNECTED) {
                emit(mapOf("type" to "connected"))
                emit(mapOf("type" to "status", "message" to "เชื่อมต่อแล้ว — กำลังค้นหา Service"))
                g.discoverServices()
            } else if (state == BluetoothProfile.STATE_DISCONNECTED) {
                emit(mapOf("type" to "disconnected"))
                emit(mapOf("type" to "status", "message" to "ตัดการเชื่อมต่อ status=$status"))
            }
        }

        @SuppressLint("MissingPermission")
        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            val out = StringBuilder("GATT STATUS: $status\nSERVICES: ${g.services.size}\n\n")
            for ((si, s) in g.services.withIndex()) {
                out.append("SERVICE ${si + 1}: ${s.uuid}\n")
                for ((ci, c) in s.characteristics.withIndex()) {
                    val p = c.properties
                    val props = mutableListOf<String>()
                    if (p and BluetoothGattCharacteristic.PROPERTY_READ != 0) props.add("READ")
                    if (p and BluetoothGattCharacteristic.PROPERTY_WRITE != 0) props.add("WRITE")
                    if (p and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0) props.add("WRITE_NR")
                    if (p and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0) props.add("NOTIFY")
                    if (p and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0) props.add("INDICATE")
                    out.append("  CHAR ${ci + 1}: ${c.uuid}\n")
                    out.append("    PROPERTIES: ${props.joinToString(", ")}\n")
                    for (d in c.descriptors) out.append("    DESC: ${d.uuid}\n")
                }
            }
            emit(mapOf("type" to "gatt", "text" to out.toString()))

            val s = g.getService(java.util.UUID.fromString(serviceUuid))
            if (s == null) {
                emit(mapOf("type" to "status", "message" to "ไม่พบ AB00"))
                return
            }
            var enabled = 0
            for (uuidText in rxUuids) {
                val c = s.getCharacteristic(java.util.UUID.fromString(uuidText)) ?: continue
                val p = c.properties
                if (p and BluetoothGattCharacteristic.PROPERTY_NOTIFY == 0 &&
                    p and BluetoothGattCharacteristic.PROPERTY_INDICATE == 0) continue
                val local = g.setCharacteristicNotification(c, true)
                val d = c.getDescriptor(java.util.UUID.fromString(cccdUuid))
                var remote = false
                if (d != null) {
                    d.value = if (p and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0)
                        BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
                    else BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                    remote = g.writeDescriptor(d)
                }
                if (local && remote) enabled++
                emit(mapOf(
                    "type" to "notify",
                    "message" to "${uuidText.substring(4, 8).uppercase()}: local=$local CCCD-write=$remote"
                ))
            }
            emit(mapOf("type" to "status",
                "message" to "ตั้งค่า Notify แล้ว $enabled ช่อง — ยังไม่ส่ง Write ไป AB01"))
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            val b = c.value ?: byteArrayOf()
            val hex = b.joinToString(" ") { "%02X".format(it.toInt() and 0xFF) }
            val now = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date())
            emit(mapOf(
                "type" to "rx",
                "characteristic" to c.uuid.toString(),
                "data" to hex,
                "length" to b.size,
                "time" to now
            ))
        }
    }
}
