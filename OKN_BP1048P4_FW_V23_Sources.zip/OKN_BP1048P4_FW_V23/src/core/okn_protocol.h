#ifndef OKN_PROTOCOL_H
#define OKN_PROTOCOL_H

#include "okn_controller.h"
#include "okn_version.h"
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define OKN_PROTO_MAGIC0 0x4Fu /* O */
#define OKN_PROTO_MAGIC1 0x4Bu /* K */
#define OKN_PROTO_MAX_PAYLOAD 128u

#define OKN_CAPABILITIES_SCHEMA 1u
#define OKN_CAPABILITIES_PAYLOAD_LEN 27u

#define OKN_CAP_READBACK_STATE            (1u << 0)
#define OKN_CAP_ATOMIC_MUTATION           (1u << 1)
#define OKN_CAP_NEGATIVE_ACK              (1u << 2)
#define OKN_CAP_IDEMPOTENT_RETRY          (1u << 3)
#define OKN_CAP_STREAM_IDLE_RESET         (1u << 4)
#define OKN_CAP_EXTERNAL_DELAY_ARENA      (1u << 5)
#define OKN_CAP_PERSISTENCE_AB            (1u << 6)
#define OKN_CAP_SAFE_BOOT_GATE            (1u << 7)
#define OKN_CAP_FLASH_FAIL_CLOSED         (1u << 8)
#define OKN_CAP_CAPABILITY_QUERY          (1u << 9)
#define OKN_CAP_EXACT_BOARD_REQUIRED      (1u << 10)

#define OKN_CAPABILITIES_FEATURES ( \
    OKN_CAP_READBACK_STATE | OKN_CAP_ATOMIC_MUTATION | OKN_CAP_NEGATIVE_ACK | \
    OKN_CAP_IDEMPOTENT_RETRY | OKN_CAP_STREAM_IDLE_RESET | \
    OKN_CAP_EXTERNAL_DELAY_ARENA | OKN_CAP_PERSISTENCE_AB | \
    OKN_CAP_SAFE_BOOT_GATE | OKN_CAP_FLASH_FAIL_CLOSED | \
    OKN_CAP_CAPABILITY_QUERY | OKN_CAP_EXACT_BOARD_REQUIRED)


typedef enum {
    OKN_CMD_PING = 0x01,
    OKN_CMD_GET_INFO = 0x02,
    OKN_CMD_GET_MASTER_STATE = 0x03,
    OKN_CMD_GET_CHANNEL_STATE = 0x04,
    OKN_CMD_GET_PEQ_STATE = 0x05,
    OKN_CMD_GET_CAPABILITIES = 0x06,
    OKN_CMD_SET_MASTER_GAIN = 0x10,
    OKN_CMD_SET_CH_GAIN = 0x11,
    OKN_CMD_SET_CH_MUTE = 0x12,
    OKN_CMD_SET_CH_PHASE = 0x13,
    OKN_CMD_SET_CH_DELAY = 0x14,
    OKN_CMD_SET_PEQ = 0x20,
    OKN_CMD_SET_HPF = 0x21,
    OKN_CMD_SET_LPF = 0x22,
    OKN_CMD_MASTER_STATE = 0x73,
    OKN_CMD_CHANNEL_STATE = 0x74,
    OKN_CMD_PEQ_STATE = 0x75,
    OKN_CMD_CAPABILITIES = 0x76,
    OKN_CMD_ACK = 0x7E,
    OKN_CMD_INFO = 0x7F
} okn_command_t;

/*
 * V13 separates transport/framing/encoding success from application command
 * success. A valid frame can therefore produce a negative ACK while the
 * transport itself remains OK.
 */
typedef struct {
    okn_status_t transport_status;
    okn_status_t command_status;
    size_t response_len;
    bool command_evaluated;
} okn_protocol_result_t;

uint16_t okn_crc16_ccitt(const uint8_t *data, size_t len);
okn_status_t okn_protocol_apply(okn_controller_t *ctl, const uint8_t *packet, size_t len);
okn_protocol_result_t okn_protocol_execute_ex(okn_controller_t *ctl,
                                              const uint8_t *packet, size_t len,
                                              uint8_t *response, size_t response_cap);
okn_status_t okn_protocol_execute(okn_controller_t *ctl, const uint8_t *packet, size_t len,
                                  uint8_t *response, size_t response_cap, size_t *response_len);

#endif
