# OKN_BP1048P4_FW_V23

V23 preserves the V22 read-only Android discovery capture and multi-session transport fingerprint path, then adds a content-bound **Discovery Review Packet** boundary. A repeated transport identity can become `OBSERVED_STABLE`, but it still cannot become exact BP1048P4/GoloPine evidence or hardware authorization automatically.

## What V23 adds

- `discovery_review_manifest.json`
- `tools/discovery_review.py`
- `tools/verify_discovery_review.py`
- `tests/test_discovery_review.py`
- review packets are derived only from `OBSERVED_STABLE` fingerprints
- review manifest is SHA-256 bound to both transport fingerprint and hardware discovery manifests
- stable USB/serial observations may only be presented as `android_host_transport_observation` review scope
- stable BLE observations may only be presented as `ble_transport_observation` review scope
- exact chip, board, programmer, image, linker, and flash claims are never granted by this layer
- editing a derived packet to `reviewed/approved` is rejected as stale/tampered
- human review, content-bound exact evidence, and explicit authorization remain separate mandatory gates
- fixes capability payload storage to 27 bytes so the documented controller revision at offsets 23..26 is in-bounds; wire frame remains Protocol V2 / capability schema 1

The wire frame remains Protocol V2. DSP/core behavior is unchanged. V23 intentionally contains no destructive executor, programmer packet, bootloader command, target address/pin sequence, or flash image.

Run:

```sh
make verify
make test
make demo
```

See `docs/DISCOVERY_REVIEW_V23.md`, `docs/DISCOVERY_FINGERPRINT_V23.md`, `docs/ANDROID_DISCOVERY_CAPTURE_V23.md`, `docs/HARDWARE_DISCOVERY_V23.md`, `docs/MOBILE_FLASH_TRANSACTION_V19.md`, and `docs/PORT_INTEGRATION_PLAN_V18.md`.
