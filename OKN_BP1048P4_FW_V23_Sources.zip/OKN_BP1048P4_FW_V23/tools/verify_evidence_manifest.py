#!/usr/bin/env python3
from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'evidence_manifest.json').read_text())
errors=[]
if m.get('schema')!=4: errors.append('evidence schema must be 4')
if m.get('project_version')!=23: errors.append('project_version must be 23')
if m.get('target')!='BP1048P4' or m.get('board')!='GoloPine 7CH': errors.append('target/board mismatch')
if m.get('policy')!='FAIL_CLOSED_NO_INFERENCE': errors.append('policy mismatch')
if m.get('hardware_authorized') is not False: errors.append('hardware_authorized must be false')
req=m.get('required_exact_evidence',{})
if any(bool(v) for v in req.values()): errors.append('V23 exact evidence flags must all remain false')
prov=m.get('provenance',{})
if prov.get('previous_source_sha256')!='4e24f7d82b64dd2c30226bba8be8d51d2a8d136a8659f4911d30e506c789f402': errors.append('V22 source provenance mismatch')
if prov.get('validation_zip_sha256')!='4871b92782a76f98bf7e96b21391398812a3e3f2afefad7731bf0d15b85bbc80': errors.append('V22 validation provenance mismatch')
if not any(o.get('id')=='v22-ci-validation' for o in m.get('observations',[])): errors.append('V22 CI observation missing')
for ob in m.get('observations',[]):
    if ob.get('authorizes') not in ([],None): errors.append('observations may not authorize hardware in V23')
if errors:
    [print('BLOCKED:',e) for e in errors]; sys.exit(1)
print('PASS: V23 evidence manifest is internally consistent and non-authorizing')
