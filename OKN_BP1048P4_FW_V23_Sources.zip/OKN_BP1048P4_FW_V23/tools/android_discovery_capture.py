#!/usr/bin/env python3
"""V23 Android read-only discovery capture contract.

This validates data already collected by an Android host. It has no USB/BLE/
serial device I/O and contains no function that can issue a target command.
"""
from __future__ import annotations
from pathlib import Path
import argparse, hashlib, json, re

PROJECT_VERSION = 23
SCHEMA = 1
FORMAT = "OKN_ANDROID_DISCOVERY_CAPTURE"
FORMAT_VERSION = 1
POLICY = "READ_ONLY_ENUMERATION_CANONICAL_HASH_NO_COMMANDS_NO_AUTHORIZATION"
ALLOWED_TRANSPORTS = {"usb_host", "ble", "serial_enumeration"}
ALLOWED_OPERATIONS = {"enumerate", "read_descriptor", "discover_services", "read_metadata"}
TRANSPORT_KINDS = {
    "usb_host": {"usb_device", "usb_interface", "usb_endpoint", "usb_descriptor"},
    "ble": {"ble_advertisement", "ble_service", "ble_characteristic", "ble_descriptor"},
    "serial_enumeration": {"serial_device", "serial_port_metadata"},
}
HEX64 = re.compile(r"^[0-9a-f]{64}$")


def canonical_bytes(capture: dict) -> bytes:
    core = {k: v for k, v in capture.items() if k != "canonical_sha256"}
    return json.dumps(core, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def canonical_sha256(capture: dict) -> str:
    return hashlib.sha256(canonical_bytes(capture)).hexdigest()


def validate_capture(capture: dict) -> dict:
    errors: list[str] = []
    if not isinstance(capture, dict):
        return {"ok": False, "errors": ["capture must be object"]}
    if capture.get("schema") != SCHEMA: errors.append("capture schema mismatch")
    if capture.get("project_version") != PROJECT_VERSION: errors.append("capture project_version mismatch")
    if capture.get("format") != FORMAT or capture.get("format_version") != FORMAT_VERSION: errors.append("capture format mismatch")
    if capture.get("target") != "BP1048P4" or capture.get("board") != "GoloPine 7CH": errors.append("target/board mismatch")
    if capture.get("policy") != POLICY: errors.append("capture policy mismatch")
    transport = capture.get("transport")
    if transport not in ALLOWED_TRANSPORTS: errors.append("unsupported transport")
    if capture.get("read_only") is not True: errors.append("read_only must be true")
    if capture.get("write_attempted") is not False: errors.append("write_attempted must be false")
    if capture.get("commands_sent") != []: errors.append("commands_sent must be empty")
    source = capture.get("source", {})
    if not isinstance(source, dict): errors.append("source must be object")
    else:
        if source.get("platform") != "android": errors.append("source.platform must be android")
        if not isinstance(source.get("collector"), str) or not source.get("collector"): errors.append("source.collector missing")
        if not isinstance(source.get("permission_granted"), bool): errors.append("source.permission_granted must be boolean")
    observations = capture.get("observations")
    if not isinstance(observations, list):
        errors.append("observations must be list"); observations=[]
    if len(observations) > 256: errors.append("too many observations")
    kinds = TRANSPORT_KINDS.get(transport, set())
    for i, rec in enumerate(observations):
        pre=f"observation[{i}]"
        if not isinstance(rec, dict): errors.append(pre+": must be object"); continue
        if rec.get("kind") not in kinds: errors.append(pre+": kind not allowed for transport")
        if rec.get("operation") not in ALLOWED_OPERATIONS: errors.append(pre+": operation is not read-only/allowed")
        if "command" in rec or "write_payload" in rec or "programmer_packet" in rec:
            errors.append(pre+": command/write/programmer fields are forbidden")
        meta=rec.get("metadata", {})
        if not isinstance(meta, dict): errors.append(pre+": metadata must be object")
    transcript=capture.get("transcript", [])
    if not isinstance(transcript, list):
        errors.append("transcript must be list"); transcript=[]
    if len(transcript) > 1024: errors.append("transcript too long")
    for i, ev in enumerate(transcript):
        pre=f"transcript[{i}]"
        if not isinstance(ev, dict): errors.append(pre+": must be object"); continue
        if ev.get("operation") not in ALLOWED_OPERATIONS: errors.append(pre+": operation is not read-only/allowed")
        if ev.get("direction") not in ("metadata", "device_to_host", None): errors.append(pre+": outbound direction forbidden")
        if "command" in ev or "write_payload" in ev or "programmer_packet" in ev:
            errors.append(pre+": command/write/programmer fields are forbidden")
    declared=capture.get("canonical_sha256")
    actual=canonical_sha256(capture)
    if not isinstance(declared,str) or not HEX64.fullmatch(declared): errors.append("canonical_sha256 invalid")
    elif declared != actual: errors.append("canonical_sha256 mismatch")
    return {
        "ok": not errors,
        "transport": transport,
        "observation_count": len(observations),
        "canonical_sha256": actual,
        "hardware_authorized": False,
        "mobile_flash_authorized": False,
        "programmer_io_available": False,
        "errors": errors,
    }


def validate_capture_file(path: Path) -> dict:
    path=Path(path)
    if path.is_symlink(): return {"ok":False,"errors":["symlink capture file forbidden"]}
    if not path.is_file(): return {"ok":False,"errors":["capture file missing"]}
    try: capture=json.loads(path.read_text(encoding="utf-8"))
    except Exception as e: return {"ok":False,"errors":["capture JSON invalid: "+str(e)]}
    return validate_capture(capture)


def main() -> int:
    ap=argparse.ArgumentParser(description="Validate an Android read-only discovery capture; performs no hardware I/O.")
    ap.add_argument("capture")
    a=ap.parse_args(); r=validate_capture_file(Path(a.capture))
    print("ANDROID_DISCOVERY_CAPTURE="+("VALID_READ_ONLY" if r.get("ok") else "BLOCKED"))
    print("PROGRAMMER_IO=NOT_IMPLEMENTED")
    for e in r.get("errors",[]): print("BLOCKED:"+e)
    return 0 if r.get("ok") else 1

if __name__ == "__main__": raise SystemExit(main())
