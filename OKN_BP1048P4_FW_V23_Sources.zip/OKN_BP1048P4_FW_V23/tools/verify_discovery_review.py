#!/usr/bin/env python3
from pathlib import Path
import json, sys
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'tools'))
from discovery_review import verify
m=json.loads((root/'discovery_review_manifest.json').read_text())
r=verify(root,m)
errors=list(r['errors'])
if m.get('schema')!=1 or m.get('project_version')!=23: errors.append('review schema/version mismatch')
if m.get('state')!='LOCKED_NO_STABLE_OBSERVATION': errors.append('shipped V23 review state must remain locked/no stable observation')
if m.get('review_packets')!=[]: errors.append('shipped V23 review packet list must be empty')
if m.get('automatic_promotion') is not False: errors.append('automatic promotion must remain false')
if m.get('hardware_authorized') is not False or m.get('mobile_flash_authorized') is not False: errors.append('review layer may not authorize hardware')
if errors:
    for e in errors: print('BLOCKED:',e)
    sys.exit(1)
print('PASS: V23 discovery review packet is content-bound, human-review-only, and non-authorizing')
