# V23 Discovery Review Boundary

`OBSERVED_STABLE` means only that the same structural transport fingerprint was seen in at least two independent read-only captures. It does **not** prove that the observed transport is the BP1048P4 programmer, the GoloPine board boot interface, or a safe flash path.

V23 derives `discovery_review_manifest.json` from the current `transport_fingerprint_manifest.json` and `hardware_discovery_manifest.json`. The manifest stores SHA-256 bindings to both inputs and emits pending review packets only for stable observations.

A derived packet cannot grant exact target claims, cannot set hardware or mobile-flash authorization, and cannot expose programmer I/O. Manual edits that mark a derived packet approved are rejected because the file no longer equals the derivation from its bound inputs.

Future promotion of any observation into a target qualification claim requires a separate reviewed, content-bound artifact and explicit authorization. No hardware address, pin sequence, register, boot command, programmer packet, image layout, or destructive operation is introduced here.
