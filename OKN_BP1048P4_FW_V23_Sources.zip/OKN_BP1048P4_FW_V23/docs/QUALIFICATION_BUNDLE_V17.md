# V17 Qualification Evidence Bundle

V17 adds content binding to the V16 reviewed-evidence policy. A typed SHA256 in
a JSON claim is no longer sufficient. The SHA must correspond to a concrete
regular file in the declared evidence bundle and the verifier recomputes the
hash before the target-qualification policy can see the artifact.

## Files

- `qualification_bundle_manifest.json` — content inventory and declared hashes.
- `qualification_evidence/` — local bundle root for reviewed evidence files.
- `tools/qualification_bundle.py` — path and hash verifier; never talks to hardware.
- `target_qualification_manifest.json` — claim-to-artifact bindings and explicit authorization flags.

## Artifact record

A bundle artifact has an ID, safe relative path, SHA256, provenance source,
reviewed flag and one or more evidence classifications. The verifier refuses
absolute paths, `..` traversal, symlink evidence, missing/non-regular files,
invalid hashes, hash mismatch and duplicate artifact IDs.

An unreviewed artifact can be stored and hash-checked, but it is deliberately
excluded from the verified index. This means intake/staging cannot authorize
hardware by itself.

## Claim binding

Each exact target claim must reference `artifact_id`, `artifact_sha256`, source,
classification and an evidence locator. The qualification policy requires the
claim SHA/source/classification to match the verified artifact entry exactly.
A valid artifact cannot be substituted by another file with a similar name.

## Authorization boundary

Even a complete set of content-bound reviewed claims does not automatically
make a hardware image flashable. `hardware_authorized` and
`mobile_flash_authorized` remain separate explicit decisions after evidence
review. V17 ships both false and ships no target `.bin`.
