# V19 Mobile Flash Transaction Contract

V19 adds a **non-executing** transaction envelope for the future Android USB-OTG or verified vendor-OTA host path. It does not implement a BP1048P4 programmer, bootloader command, USB protocol, pin sequence, memory address, erase command, or image layout.

The envelope is SHA256-bound to the current `port_integration_plan.json` and `flash_session_manifest.json`. If either readiness input changes, the transaction becomes stale and validation fails. A future candidate image and original-firmware backup must also be real local files whose hashes are recomputed before the envelope can become armable.

The required order is: preflight, original-firmware backup, backup hash verification, image hash verification, explicit arm of an external verified executor, external programming, external readback, readback verification, then complete. Recovery is mandatory after an external programming failure.

`ARMABLE_EXTERNAL_EXECUTOR_NOT_IMPLEMENTED` means only that all abstract preconditions are satisfied in the reference model. V19 intentionally contains no destructive executor. The shipped transaction is `LOCKED`, contains no image or backup file, and can emit no programmer packet.
