# OKN Control Protocol V2

Replacement-firmware protocol. It is intentionally independent of GoloPine UFE.

Frame:
- byte 0 = 0x4F ('O')
- byte 1 = 0x4B ('K')
- byte 2 = protocol version 0x02
- byte 3 = command
- bytes 4..5 = payload length, uint16 little-endian
- payload
- final 2 bytes = CRC-16/CCITT-FALSE, little-endian

Channel index on wire: 0..6 = CH1..CH7. PEQ band index: 0..14.

Read/query commands:
- 0x01 PING
- 0x02 GET_INFO
- 0x03 GET_MASTER_STATE
- 0x04 GET_CHANNEL_STATE
- 0x05 GET_PEQ_STATE
- 0x06 GET_CAPABILITIES (V16+, payload length must be zero)

Mutation commands:
- 0x10 SET_MASTER_GAIN
- 0x11 SET_CH_GAIN
- 0x12 SET_CH_MUTE
- 0x13 SET_CH_PHASE
- 0x14 SET_CH_DELAY
- 0x20 SET_PEQ
- 0x21 SET_HPF
- 0x22 SET_LPF

Responses:
- 0x73 MASTER_STATE
- 0x74 CHANNEL_STATE
- 0x75 PEQ_STATE
- 0x76 CAPABILITIES
- 0x7E ACK
- 0x7F INFO

V2 validates CRC and ranges before mutating state. Bad CRC/format framing is a
transport error and cannot mutate revision/state. A valid frame with a command
error produces a negative ACK so the transport can send the application error.

`GET_INFO` and V16 `GET_CAPABILITIES` both report hardware readiness as false
until an authentic exact BP1048P4 + GoloPine hardware port is reviewed and
integrated. Adding the V16 query does not change the V2 frame version.
