# V16 Target Qualification Bundle

V16 does not add a BP1048P4 flash command. It adds the evidence boundary required before any such command can be accepted.

`target_qualification_manifest.json` contains one record per exact claim needed for the GoloPine BP1048P4 hardware port. A claim is qualified only when all of these are present:

- an exact-evidence classification allowed for that claim;
- a SHA256 of the reviewed artifact;
- a provenance/source string;
- a precise evidence locator inside the artifact/document/test record;
- an explicit human `reviewed=true` decision;
- an explicit `verified=true` claim decision.

A filename containing `BP1048P4`, a text search hit, a family/B1/B2 SDK, or a community statement never authorizes hardware by itself. `qualification_intake.py` only hashes incoming files and emits `UNREVIEWED_INPUT`; it cannot unlock a claim.

Hardware and mobile-flash authorization remain separate explicit decisions even after all evidence claims are complete. V16 ships both authorization flags false.

## Public research status, 2026-09-15

The public MVsB1 SDK remains family evidence only. A renewed public search did not identify a verified BP1048P4 + GoloPine exact programmer/image-format package. Community discussion specific to the 7-channel BP1048P4 board says the available GoloPine/DSTech software is for tuning/control and is not established as a firmware creation/flashing tool. This is non-authorizing research evidence, not proof that no private/vendor tool exists.
