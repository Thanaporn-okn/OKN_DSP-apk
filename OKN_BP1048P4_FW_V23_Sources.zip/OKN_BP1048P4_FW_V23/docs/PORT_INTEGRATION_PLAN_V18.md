# V18 Port Integration Plan

V18 derives a machine-readable readiness plan from the content-bound qualification
bundle and target qualification manifest. The plan is not a hardware configuration.
It contains no target addresses, register values, pin assignments, programmer
packets, boot pins, or flash offsets.

The plan separates evidence completeness from authorization. A subsystem can have
all required claims satisfied and still remain not ready until explicit hardware
authorization is present. Mobile flashing additionally requires explicit mobile
flash authorization.

Subsystem groups: identity, startup/linker, flash programming, safe boot, audio,
BLE runtime, NVM, memory, and mobile flash. `missing_claims` is the authoritative
portable checklist for the next evidence intake.

The shipped V18 plan is derived from an empty qualification evidence bundle, so all
subsystems remain locked. This is intentional. No `.bin` is generated and no vendor
programmer command is emitted.
