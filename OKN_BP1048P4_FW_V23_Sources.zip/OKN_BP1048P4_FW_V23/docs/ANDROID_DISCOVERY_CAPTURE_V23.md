# V23 Android Read-Only Discovery Capture

V23 defines a portable JSON capture format for observations already collected by an Android host. The portable firmware project itself does not open USB, BLE, or serial devices.

The capture can describe USB descriptor enumeration, BLE advertisement/service/characteristic discovery, or serial-port metadata. Every event is restricted to `enumerate`, `read_descriptor`, `discover_services`, or `read_metadata`. `commands_sent` must be empty and `write_attempted` must be false.

Each capture carries a canonical SHA-256 over compact sorted-key UTF-8 JSON excluding the `canonical_sha256` field. When imported, the outer hardware-discovery manifest also binds the exact raw file SHA-256. This gives two checks: semantic/canonical identity and exact-file identity.

`tools/import_android_discovery.py` only copies a validated local capture into `hardware_probe_evidence/` and updates the local manifest. It has no device-I/O code. Imported captures remain unreviewed and never set `android_host_transport_verified`, `hardware_authorized`, or `mobile_flash_authorized`.

This format intentionally contains no programmer packet, vendor write request, boot-mode command, target address, register value, or pin sequence.
