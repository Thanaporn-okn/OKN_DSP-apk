# V23 Multi-Capture Transport Fingerprint

V23 derives a structural transport fingerprint from already validated Android read-only discovery captures.

A single phone capture is never treated as proof. Two or more independent captures must produce the same structural fingerprint before a transport can be labelled `OBSERVED_STABLE`. That label is observational only and does **not** set `android_host_transport_verified`, `hardware_authorized`, or `mobile_flash_authorized`.

The fingerprint intentionally excludes volatile or privacy-sensitive identifiers such as USB serial numbers, BLE addresses, RSSI, timestamps, and opaque transcript payloads. It uses only a small whitelist of enumeration structure such as USB VID/PID/interface classes or BLE service/characteristic UUID structure.

States are:

- `LOCKED_NO_CAPTURE`: no fingerprintable Android captures.
- `OBSERVED_ONCE`: one valid session only.
- `OBSERVED_STABLE`: at least two sessions with the same structural fingerprint.
- `INCONSISTENT`: repeated sessions disagree.

No USB/BLE/serial I/O, vendor command, programmer packet, boot command, target write, or flash operation is implemented by this layer.
