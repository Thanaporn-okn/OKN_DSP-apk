#!/usr/bin/env python3
from pathlib import Path
import copy, hashlib, json, sys, tempfile
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'tools'))
from mobile_flash_transaction import base_manifest,evaluate,sha256_file

# Shipped transaction is locked and cannot execute anything.
r=evaluate(root)
assert r['ok'] and not r['armable'] and not r['destructive_execution_available']

# Synthetic, fully authorized inputs can make the envelope ARMABLE, but V23 still
# has no destructive executor. No hardware commands or packets are generated.
with tempfile.TemporaryDirectory() as td:
    td=Path(td)
    plan=json.loads((root/'port_integration_plan.json').read_text())
    for s in plan['subsystems'].values():
        s['evidence_complete']=True; s['authorized']=True; s['ready_for_integration']=True; s['missing_claims']=[]
    plan['hardware_authorized']=True; plan['mobile_flash_authorized']=True
    plan['hardware_integration_ready']=True; plan['mobile_flash_integration_ready']=True
    (td/'port_integration_plan.json').write_text(json.dumps(plan,indent=2)+'\n')

    session=json.loads((root/'flash_session_manifest.json').read_text())
    session['execution_authorized']=True; session['state']='READY'
    for k in session['preflight']: session['preflight'][k]=True
    (td/'flash_session_manifest.json').write_text(json.dumps(session,indent=2)+'\n')

    (td/'candidate.img').write_bytes(b'V23 synthetic image unit-test only\n')
    (td/'original-backup.bin').write_bytes(b'V23 synthetic original backup unit-test only\n')
    tx=base_manifest(td)
    tx['execution_authorized']=True
    tx['state']='ARMABLE_EXTERNAL_EXECUTOR_NOT_IMPLEMENTED'
    tx['image']={'path':'candidate.img','sha256':sha256_file(td/'candidate.img'),'hash_verified':True}
    tx['backup']={'path':'original-backup.bin','sha256':sha256_file(td/'original-backup.bin'),'hash_verified':True}
    rr=evaluate(td,tx)
    assert rr['ok'] and rr['armable'] and not rr['destructive_execution_available']

    # Hash mismatch blocks arming.
    bad=copy.deepcopy(tx); bad['image']['sha256']='0'*64; bad['state']='LOCKED'
    rr=evaluate(td,bad); assert rr['ok'] and not rr['armable'] and not rr['content_verified']

    # Stale readiness binding is rejected, not merely locked.
    (td/'port_integration_plan.json').write_text((td/'port_integration_plan.json').read_text()+'\n')
    rr=evaluate(td,tx); assert not rr['ok']; assert any('stale port' in e for e in rr['errors'])

print('ALL V23 MOBILE FLASH TRANSACTION TESTS PASS')
