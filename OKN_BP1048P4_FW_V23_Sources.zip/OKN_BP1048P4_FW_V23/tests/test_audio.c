#include "../src/dsp/okn_audio_engine.h"
#include "../src/core/okn_controller.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

static void zero_frame(float x[OKN_CHANNELS]) { memset(x, 0, sizeof(float) * OKN_CHANNELS); }
static float delay_arena[OKN_AUDIO_REF_DELAY_ARENA_SAMPLES];

int main(void) {
    okn_biquad_coeff_t q;
    assert(okn_biquad_design(OKN_BIQUAD_BYPASS, 48000.0f, 1000.0f, 0.0f, 1.0f, &q) == OKN_OK);
    assert(fabsf(q.b0 - 1.0f) < 1.0e-7f && q.b1 == 0.0f && q.a1 == 0.0f);
    assert(okn_biquad_design(OKN_BIQUAD_PEQ, 48000.0f, 24000.0f, 3.0f, 1.0f, &q) == OKN_ERR_RANGE);

    okn_controller_t ctl; okn_controller_init(&ctl);
    okn_audio_engine_t e;
    assert(okn_audio_engine_init(&e, 48000u) == OKN_OK);
    assert(okn_audio_engine_init(&e, 48001u) == OKN_ERR_RANGE);
    assert(okn_audio_engine_init(&e, 48000u) == OKN_OK);

    /* Bypass lane: -6 dB is a deterministic project-defined gain. */
    assert(okn_set_channel_gain(&ctl.state, 0, -6.0f) == OKN_OK);
    okn_controller_touch_channel(&ctl, 0);
    assert(okn_audio_engine_prepare(&e, &ctl.state, ctl.revision) == OKN_OK);
    float in[OKN_CHANNELS], out[OKN_CHANNELS]; zero_frame(in); zero_frame(out); in[0] = 1.0f;
    okn_audio_engine_process_frame(&e, in, out);
    assert(fabsf(out[0] - okn_db_to_linear(-6.0f)) < 1.0e-5f);

    /* Mute and phase use the same state semantics as control core. */
    assert(okn_set_channel_mute(&ctl.state, 0, true) == OKN_OK); okn_controller_touch_channel(&ctl, 0);
    assert(okn_audio_engine_prepare(&e, &ctl.state, ctl.revision) == OKN_OK); zero_frame(in); in[0]=1.0f;
    okn_audio_engine_process_frame(&e, in, out); assert(out[0] == 0.0f);
    assert(okn_set_channel_mute(&ctl.state, 0, false) == OKN_OK);
    assert(okn_set_channel_gain(&ctl.state, 0, 0.0f) == OKN_OK);
    assert(okn_set_channel_phase(&ctl.state, 0, true) == OKN_OK); okn_controller_touch_channel(&ctl, 0);
    assert(okn_audio_engine_prepare(&e, &ctl.state, ctl.revision) == OKN_OK); zero_frame(in); in[0]=0.5f;
    okn_audio_engine_process_frame(&e, in, out); assert(fabsf(out[0] + 0.5f) < 1.0e-6f);

    /* Exact integer-sample delay test: 1 ms at 48 kHz = 48 samples. */
    assert(okn_set_channel_phase(&ctl.state, 0, false) == OKN_OK);
    assert(okn_set_channel_delay(&ctl.state, 0, 1.0f) == OKN_OK); okn_controller_touch_channel(&ctl, 0);
    /* V13: delay is fail-closed unless caller supplies the full external arena. */
    assert(okn_audio_engine_init(&e, 48000u) == OKN_OK);
    assert(okn_audio_engine_prepare(&e, &ctl.state, ctl.revision) == OKN_ERR_BUFFER);
    assert(okn_audio_engine_init_with_delay_arena(&e, 48000u,
                                                  delay_arena,
                                                  OKN_AUDIO_REF_DELAY_ARENA_SAMPLES) == OKN_OK);
    assert(okn_audio_engine_prepare(&e, &ctl.state, ctl.revision) == OKN_OK);
    for (unsigned n = 0; n < 48u; ++n) {
        zero_frame(in); in[0] = (n == 0u) ? 1.0f : 0.0f;
        okn_audio_engine_process_frame(&e, in, out);
        assert(fabsf(out[0]) < 1.0e-7f);
    }
    zero_frame(in); okn_audio_engine_process_frame(&e, in, out);
    assert(fabsf(out[0] - 1.0f) < 1.0e-6f);

    /* Exercise HPF + LPF + all supported PEQ kinds and ensure stable finite output. */
    okn_controller_init(&ctl);
    assert(okn_set_hpf(&ctl.state, 0, true, 80.0f, 0.70710678f) == OKN_OK);
    assert(okn_set_lpf(&ctl.state, 0, true, 12000.0f, 0.70710678f) == OKN_OK);
    assert(okn_set_peq_band(&ctl.state,0,0,true,OKN_FILTER_PEQ,1000.0f,3.0f,1.0f)==OKN_OK);
    assert(okn_set_peq_band(&ctl.state,0,1,true,OKN_FILTER_NOTCH,3000.0f,0.0f,2.0f)==OKN_OK);
    assert(okn_set_peq_band(&ctl.state,0,2,true,OKN_FILTER_LOW_SHELF,200.0f,2.0f,1.0f)==OKN_OK);
    assert(okn_set_peq_band(&ctl.state,0,3,true,OKN_FILTER_HIGH_SHELF,8000.0f,-2.0f,1.0f)==OKN_OK);
    okn_controller_touch_channel(&ctl,0);
    assert(okn_audio_engine_init(&e,48000u)==OKN_OK);
    assert(okn_audio_engine_prepare(&e,&ctl.state,ctl.revision)==OKN_OK);
    for (unsigned n=0;n<8192u;++n) {
        zero_frame(in); in[0] = (n==0u)?1.0f:0.0f;
        okn_audio_engine_process_frame(&e,in,out);
        assert(isfinite(out[0]));
        assert(fabsf(out[0]) < 8.0f);
    }

    puts("ALL V23 AUDIO TESTS PASS");
    return 0;
}
