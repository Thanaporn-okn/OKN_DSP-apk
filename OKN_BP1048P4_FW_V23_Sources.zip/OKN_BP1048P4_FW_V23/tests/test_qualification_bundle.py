#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,sys,tempfile,os
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'tools'))
from qualification_bundle import verify_bundle
# Shipped bundle is empty and valid.
m=json.loads((root/'qualification_bundle_manifest.json').read_text())
r=verify_bundle(m,root); assert r['ok'] and r['verified_index']=={}
with tempfile.TemporaryDirectory() as td:
    td=Path(td); ev=td/'evidence'; ev.mkdir(); f=ev/'vendor.pkg'; f.write_bytes(b'abc123')
    sha=hashlib.sha256(b'abc123').hexdigest()
    base={'schema':1,'project_version':23,'target':'BP1048P4','board':'GoloPine 7CH','policy':'CONTENT_BOUND_HASH_VERIFIED_REVIEW_REQUIRED','state':'TEST','bundle_root':'evidence','artifacts':[{'id':'vendor','path':'vendor.pkg','sha256':sha,'source':'vendor package','classifications':['EXACT_TARGET'],'reviewed':True}]}
    ok=verify_bundle(base,td); assert ok['ok'] and ok['verified_index']['vendor']['sha256']==sha
    # Tamper after manifest creation.
    f.write_bytes(b'tampered')
    bad=verify_bundle(base,td); assert not bad['ok'] and any('sha256 mismatch' in e for e in bad['errors'])
    # Traversal is forbidden.
    trav=json.loads(json.dumps(base)); trav['artifacts'][0]['path']='../outside.bin'
    assert not verify_bundle(trav,td)['ok']
    # Duplicate ids are forbidden.
    dup=json.loads(json.dumps(base)); dup['artifacts'].append(dict(dup['artifacts'][0]))
    assert not verify_bundle(dup,td)['ok']
    # Unreviewed file may hash-verify but never enters the policy-visible verified index.
    f.write_bytes(b'abc123'); un=json.loads(json.dumps(base)); un['artifacts'][0]['reviewed']=False
    ur=verify_bundle(un,td); assert ur['ok'] and ur['verified_index']=={}
print('ALL V23 QUALIFICATION BUNDLE TESTS PASS')
