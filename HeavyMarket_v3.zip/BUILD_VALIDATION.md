# BUILD VALIDATION — Heavy Market v3

วันที่ตรวจ: 2026-09-20

## สาเหตุที่แก้ใน v3

GitHub Actions v2 ผ่านขั้นติดตั้ง Android 36 แล้ว แต่ล้มที่ `:app:checkDebugAarMetadata` เพราะ AndroidX/Compose ที่ใช้อยู่กำหนดให้ compile against Android API 37 ขึ้นไป

โปรเจกต์ v3 จึงใช้:

- `compileSdk = 37`
- `compileSdkMinor = 2`
- `targetSdk = 36`
- `minSdk = 26`

Workflow จะอ่านทั้ง major/minor แล้วติดตั้ง `platforms;android-37.2` โดยอัตโนมัติ และเลือก Build Tools stable ที่ตรงกับ API แทนการ hard-code เลขไว้ใน YAML

## ตรวจแล้วใน environment นี้

- ตรวจ syntax/โครงสร้าง YAML ของ GitHub Actions
- ตรวจ logic parse `compileSdk = 37` และ `compileSdkMinor = 2`
- ตรวจว่า workflow สร้าง package id เป็น `platforms;android-37.2`
- ตรวจ Android XML หลัก parse สำเร็จ
- ตรวจ Gradle bootstrap JAR และ shell wrapper
- ตรวจ Kotlin domain logic compile โดยใช้ annotation stubs เฉพาะ `javax.inject` เพื่อไม่ต้องพึ่ง Android/Hilt jars
- ตรวจ Backend TypeScript syntax/transpile
- ตรวจ ZIP ด้วย `unzip -t` หลังสร้าง archive

## ข้อจำกัดการตรวจใน environment นี้

container นี้ไม่มี Android SDK/Gradle dependency cache ครบและไม่มี outbound network สำหรับ build Android เต็มรูปแบบ จึงไม่อ้างว่า APK v3 build สำเร็จในเครื่องนี้

GitHub Actions จะเป็นการทดสอบจริงด้วยคำสั่ง:

```bash
./gradlew --no-daemon clean testDebugUnitTest assembleDebug --stacktrace
```

เมื่อ build สำเร็จ workflow จะค้นหา APK จริงใน `app/build/outputs/apk/debug` และ upload เป็น Artifact อัตโนมัติ
