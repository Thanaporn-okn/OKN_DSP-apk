import 'package:flutter/material.dart';

void main() {
  runApp(const OKNDSPApp());
}

class OKNDSPApp extends StatelessWidget {
  const OKNDSPApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'OKN DSP Controller V5.9',
      theme: ThemeData.dark(),
      home: Scaffold(
        appBar: AppBar(title: const Text('OKN DSP Controller V5.9')),
        body: const Center(
          child: Text('BP1048P4 DSP Ready'),
        ),
      ),
    );
  }
}
