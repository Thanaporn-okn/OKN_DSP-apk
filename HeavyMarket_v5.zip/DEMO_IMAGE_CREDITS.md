# Demo Image Notes — Heavy Market v5

v5 no longer depends on remote demo photos.

The files under `app/src/main/res/drawable-nodpi/demo_*.png` are original local demo illustrations created specifically for this project. They are bundled in the APK so Demo Mode still shows a meaningful vehicle/machinery image when the device is offline or a remote provider image fails.

They do not copy Facebook/Marketplace branding, screenshots, seller photos, cookies, sessions, or user content.

For live/imported listings, the app still accepts an authorized provider image URL. If Coil cannot load that URL, the UI falls back to the closest local category illustration instead of leaving a blank white area.
