# BUILD VALIDATION — Heavy Market v5

วันที่ตรวจ: 2026-09-20

## สิ่งที่แก้จากวิดีโอ v4

- Demo image ไม่ใช้ remote URL แล้ว; bundle `demo_*.png` 10 ชุดไว้ใน APK
- Feed / Marketplace / Detail ใช้ local resource ได้โดยตรง และมี category fallback เมื่อ remote image fail
- Demo data เพิ่มเป็น 26 รายการและครอบคลุมทุก built-in category แบบ exact category match
- `seedIfNeeded()` เปลี่ยนเป็น idempotent upsert สำหรับ Demo data เพื่อรองรับการติดตั้งทับ v4 โดยไม่ล้างฐานข้อมูล
- Category strip ไม่ตัดไว้ 10 หมวด
- เพิ่ม Active Filter bar + Clear filters ใน Latest และ Marketplace

## Android compatibility set

- `compileSdk = 37`
- `compileSdkMinor = 2`
- `targetSdk = 36`
- AGP `9.4.0` / Gradle `9.6.1` / JDK 17
- dependency set เดียวกับ v4

v5 ไม่เปลี่ยน Android toolchain/dependency จาก v4 ที่ถูก build และเปิดใช้งานจริงในวิดีโอของผู้ใช้ เพื่อลดความเสี่ยงจากการแก้ UI แล้วกระทบ build โดยไม่จำเป็น

## Workflow hardening

- เลือกเลขสูงสุดจาก `HeavyMarket_v<number>.zip` โดยตรง ไม่ใช้ชื่อทั่วไปมาปะปนในการ sort
- fallback `HeavyMarket_Source.zip` เฉพาะเมื่อไม่มี versioned ZIP
- versioned ZIP ต้องมี `PROJECT_VERSION.txt` ตรงกับชื่อ ZIP
- แสดง SHA-256 ของ source ZIP ก่อนแตก
- อ่าน `compileSdk` จากโปรเจกต์และติดตั้ง Android platform ตามนั้น
- รัน `clean testDebugUnitTest assembleDebug --stacktrace`
- ตรวจ output และ upload Debug APK; signed Release เป็น optional ผ่าน GitHub Secrets

## Validation ใน environment นี้

- ตรวจ local demo resources 10 ไฟล์ว่ามีอยู่และชื่อ resource ถูกต้อง
- ตรวจ Demo category coverage เทียบกับ `defaultCategories`
- ตรวจ `res://...` image keys ทุกตัว map ไป `R.drawable...`
- ตรวจ Kotlin domain logic / classifier / price parser / search parser แบบ offline
- ตรวจ Android XML parse
- ตรวจ GitHub Actions YAML parse
- ตรวจ workflow source selection/version guard แบบจำลอง
- ตรวจ Backend TypeScript syntax/transpile ตามเครื่องมือที่มี
- ตรวจ ZIP ด้วย `unzip -t`

## ข้อจำกัด

container นี้ไม่มี Android SDK/Google Maven dependency cache ครบสำหรับทำ full `assembleDebug` แบบ offline จึงไม่อ้างว่า APK v5 build สำเร็จในเครื่องนี้ Full Android build จริงถูกตั้งให้ GitHub Actions ทำและหากมี build log error รอบใหม่ให้แก้ต่อจาก v5 โดยไม่ย้อน feature/UI.
