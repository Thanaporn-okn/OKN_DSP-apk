package com.okn.heavymarket.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import coil3.compose.AsyncImage
import com.okn.heavymarket.R
import com.okn.heavymarket.data.local.ProductEntity
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.distinctUntilChanged
import java.text.NumberFormat
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab("latest", "ล่าสุด", Icons.Default.Home),
    Tab("groups", "กลุ่ม", Icons.Default.Groups),
    Tab("market", "Marketplace", Icons.Default.Storefront),
    Tab("saved", "บันทึก", Icons.Default.Bookmark),
    Tab("settings", "ตั้งค่า", Icons.Default.Settings)
)

@Composable
fun HeavyMarketAppUi(vm: MainViewModel) {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val showBottomBar = tabs.any { it.route == route }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp
                ) {
                    tabs.forEach { tab ->
                        NavigationBarItem(
                            selected = route == tab.route,
                            onClick = {
                                nav.navigate(tab.route) {
                                    launchSingleTop = true
                                    restoreState = true
                                    popUpTo("latest") { saveState = true }
                                }
                            },
                            icon = { Icon(tab.icon, null) },
                            label = { Text(tab.label, maxLines = 1, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = HeavyBlue,
                                selectedTextColor = HeavyBlue,
                                indicatorColor = MaterialTheme.colorScheme.primaryContainer
                            )
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = nav,
            startDestination = "splash",
            modifier = Modifier.padding(padding)
        ) {
            composable("splash") { SplashScreen(nav) }
            composable("latest") { LatestScreen(vm, nav) }
            composable("groups") { GroupsScreen(vm, nav) }
            composable("market") { MarketplaceScreen(vm, nav) }
            composable("saved") { SavedScreen(vm, nav) }
            composable("settings") { SettingsScreen(vm) }
            composable("detail/{id}") { DetailScreen(nav) }
        }
    }
}

@Composable
private fun SplashScreen(nav: NavHostController) {
    LaunchedEffect(Unit) {
        delay(850)
        nav.navigate("latest") { popUpTo("splash") { inclusive = true } }
    }
    Box(
        Modifier.fillMaxSize().background(HeavyNavyDeep).padding(28.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Surface(
                modifier = Modifier.size(116.dp),
                shape = RoundedCornerShape(30.dp),
                color = HeavyYellow
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        Icons.Default.Construction,
                        contentDescription = null,
                        tint = HeavyNavyDeep,
                        modifier = Modifier.size(72.dp)
                    )
                }
            }
            Spacer(Modifier.height(28.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Heavy", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(7.dp))
                Text("Market", color = HeavyYellow, fontSize = 34.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(10.dp))
            Text("ตลาดรถและเครื่องจักรมือสอง", color = Color(0xFFD5E0EB), fontSize = 16.sp)
            Spacer(Modifier.height(42.dp))
            LinearProgressIndicator(
                modifier = Modifier.width(150.dp).clip(CircleShape),
                color = HeavyYellow,
                trackColor = Color.White.copy(alpha = 0.16f)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LatestScreen(vm: MainViewModel, nav: NavHostController) {
    val products by vm.filtered.collectAsState()
    val favorites by vm.favoriteProducts.collectAsState()
    val favoriteIds = remember(favorites) { favorites.mapTo(hashSetOf()) { it.id } }
    val visible by vm.visibleCount.collectAsState()
    val refreshing by vm.refreshing.collectAsState()
    val listState = rememberLazyListState()

    LaunchedEffect(listState, products.size, visible) {
        snapshotFlow { listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0 }
            .distinctUntilChanged()
            .collect { index ->
                if (products.isNotEmpty() && index >= minOf(products.size, visible) - 4) vm.loadMore()
            }
    }

    PullToRefreshBox(isRefreshing = refreshing, onRefresh = vm::refresh) {
        LazyColumn(
            state = listState,
            contentPadding = PaddingValues(bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item { BrandHeader("ล่าสุด") }
            item { Box(Modifier.padding(horizontal = 14.dp)) { SearchBar(vm) } }
            item { CategoryStrip(vm) }
            item { ActiveFilterBar(vm) }
            item { Box(Modifier.padding(horizontal = 14.dp)) { DemoBanner() } }
            item {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("ประกาศล่าสุด", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                    Text("${products.size} รายการ", style = MaterialTheme.typography.bodySmall, color = HeavyMuted)
                }
            }
            if (products.isEmpty()) item { EmptyState("ยังไม่พบประกาศขายที่ตรงตัวกรอง") }
            items(products.take(visible), key = { it.id }) { product ->
                Box(Modifier.padding(horizontal = 14.dp)) {
                    ProductCard(
                        product = product,
                        favorite = product.id in favoriteIds,
                        onFavorite = { vm.toggleFavorite(product.id) },
                        onClick = { nav.navigate("detail/${product.id}") }
                    )
                }
            }
        }
    }
}

@Composable
private fun BrandHeader(section: String) {
    Surface(color = HeavyNavyDeep, shadowElevation = 3.dp) {
        Column(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = RoundedCornerShape(12.dp), color = HeavyYellow, modifier = Modifier.size(42.dp)) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Construction, null, tint = HeavyNavyDeep, modifier = Modifier.size(28.dp))
                    }
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Row {
                        Text("Heavy", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        Spacer(Modifier.width(4.dp))
                        Text("Market", color = HeavyYellow, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    }
                    Text(section, color = Color(0xFFB9CBDA), style = MaterialTheme.typography.labelSmall)
                }
                IconButton(onClick = {}) { Icon(Icons.Default.NotificationsNone, "แจ้งเตือน", tint = Color.White) }
            }
        }
    }
}

@Composable
private fun SearchBar(vm: MainViewModel) {
    val query by vm.query.collectAsState()
    OutlinedTextField(
        value = query,
        onValueChange = vm::search,
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        shape = RoundedCornerShape(18.dp),
        leadingIcon = { Icon(Icons.Default.Search, null, tint = HeavyMuted) },
        placeholder = { Text("ค้นหารถ, เครื่องจักร, รุ่น, จังหวัด...") },
        trailingIcon = if (query.isNotBlank()) {
            { IconButton(onClick = { vm.search("") }) { Icon(Icons.Default.Close, null) } }
        } else null,
        colors = OutlinedTextFieldDefaults.colors(
            unfocusedContainerColor = MaterialTheme.colorScheme.surface,
            focusedContainerColor = MaterialTheme.colorScheme.surface,
            unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.65f),
            focusedBorderColor = HeavyBlue
        )
    )
}

@Composable
private fun CategoryStrip(vm: MainViewModel) {
    val categories by vm.categories.collectAsState()
    val selected by vm.category.collectAsState()
    var filterOpen by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        LazyRow(
            contentPadding = PaddingValues(horizontal = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            item {
                CategoryButton("ทั้งหมด", Icons.Default.Apps, selected == null) { vm.category.value = null }
            }
            items(categories, key = { it.name }) { category ->
                CategoryButton(category.name, categoryIcon(category.name), selected == category.name) {
                    vm.category.value = category.name
                }
            }
            item {
                CategoryButton("ตัวกรอง", Icons.Default.Tune, false) { filterOpen = true }
            }
        }
        if (filterOpen) FilterSheet(vm) { filterOpen = false }
    }
}

@Composable
private fun ActiveFilterBar(vm: MainViewModel) {
    val category by vm.category.collectAsState()
    val province by vm.province.collectAsState()
    val minPrice by vm.minPrice.collectAsState()
    val maxPrice by vm.maxPrice.collectAsState()
    val source by vm.sourceType.collectAsState()
    val sort by vm.sort.collectAsState()
    val parts = listOfNotNull(
        category,
        province.takeIf { it.isNotBlank() },
        minPrice?.let { "≥ ${formatPrice(it)}" },
        maxPrice?.let { "≤ ${formatPrice(it)}" },
        source,
        when (sort) { Sort.NEWEST -> null; Sort.PRICE_LOW -> "ราคาต่ำ→สูง"; Sort.PRICE_HIGH -> "ราคาสูง→ต่ำ" }
    )
    if (parts.isEmpty()) return
    Surface(
        modifier = Modifier.padding(horizontal = 14.dp).fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
    ) {
        Row(Modifier.padding(start = 12.dp, end = 6.dp, top = 5.dp, bottom = 5.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.FilterAlt, null, tint = HeavyBlue, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text(parts.joinToString(" • "), modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            TextButton(onClick = vm::clearFilters) { Text("ล้าง") }
        }
    }
}

@Composable
private fun CategoryButton(label: String, icon: ImageVector, selected: Boolean, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.width(72.dp).clickable(onClick = onClick)
    ) {
        Surface(
            shape = CircleShape,
            color = if (selected) HeavyBlue else MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, if (selected) HeavyBlue else MaterialTheme.colorScheme.outline.copy(alpha = 0.55f)),
            shadowElevation = if (selected) 2.dp else 0.dp,
            modifier = Modifier.size(48.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = if (selected) Color.White else HeavyNavy, modifier = Modifier.size(25.dp))
            }
        }
        Spacer(Modifier.height(5.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

private fun categoryIcon(name: String): ImageVector = when {
    name.contains("ขุด") || name.contains("แบคโฮ") || name.contains("Backhoe", true) -> Icons.Default.Construction
    name.contains("ไถ") || name.contains("เกษตร") || name.contains("เกี่ยว") -> Icons.Default.Agriculture
    name.contains("อะไหล่") || name.contains("อุปกรณ์") -> Icons.Default.Handyman
    name.contains("โฟล์คลิฟท์") || name.contains("เครื่องจักร") || name.contains("Loader", true) -> Icons.Default.PrecisionManufacturing
    name.contains("รถ") || name.contains("ล้อ") || name.contains("ดั้ม") || name.contains("พ่วง") -> Icons.Default.LocalShipping
    else -> Icons.Default.Category
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FilterSheet(vm: MainViewModel, close: () -> Unit) {
    val sheet = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var province by remember { mutableStateOf(vm.province.value) }
    var minPrice by remember { mutableStateOf(vm.minPrice.value?.toString().orEmpty()) }
    var maxPrice by remember { mutableStateOf(vm.maxPrice.value?.toString().orEmpty()) }
    val sort by vm.sort.collectAsState()
    val source by vm.sourceType.collectAsState()

    ModalBottomSheet(onDismissRequest = close, sheetState = sheet) {
        Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
            Text("ตัวกรอง", style = MaterialTheme.typography.headlineSmall)
            OutlinedTextField(
                province,
                { province = it },
                label = { Text("จังหวัด/พื้นที่") },
                leadingIcon = { Icon(Icons.Default.LocationOn, null) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(minPrice, { minPrice = it.filter(Char::isDigit) }, label = { Text("ราคาต่ำสุด") }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp))
                OutlinedTextField(maxPrice, { maxPrice = it.filter(Char::isDigit) }, label = { Text("ราคาสูงสุด") }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp))
            }
            Text("แหล่งข้อมูล", fontWeight = FontWeight.SemiBold)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                item { FilterChip(selected = source == null, onClick = { vm.sourceType.value = null }, label = { Text("ทั้งหมด") }) }
                items(listOf("DEMO", "IMPORTED", "BACKEND", "FACEBOOK_PAGE")) { type ->
                    FilterChip(selected = source == type, onClick = { vm.sourceType.value = type }, label = { Text(type) })
                }
            }
            Text("เรียงตาม", fontWeight = FontWeight.SemiBold)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                item { FilterChip(selected = sort == Sort.NEWEST, onClick = { vm.sort.value = Sort.NEWEST }, label = { Text("ล่าสุด") }) }
                item { FilterChip(selected = sort == Sort.PRICE_LOW, onClick = { vm.sort.value = Sort.PRICE_LOW }, label = { Text("ราคาต่ำ-สูง") }) }
                item { FilterChip(selected = sort == Sort.PRICE_HIGH, onClick = { vm.sort.value = Sort.PRICE_HIGH }, label = { Text("ราคาสูง-ต่ำ") }) }
            }
            Text("ระยะทางจะแสดงเมื่อ provider มีพิกัดจริงและผู้ใช้อนุญาตตำแหน่ง", style = MaterialTheme.typography.bodySmall, color = HeavyMuted)
            Button(
                onClick = {
                    vm.province.value = province
                    vm.minPrice.value = minPrice.toLongOrNull()
                    vm.maxPrice.value = maxPrice.toLongOrNull()
                    close()
                },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(14.dp)
            ) { Text("ดูผลลัพธ์") }
            TextButton(onClick = { vm.clearFilters(); close() }, modifier = Modifier.fillMaxWidth()) { Text("ล้างตัวกรอง") }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun GroupsScreen(vm: MainViewModel, nav: NavHostController) {
    val groups by vm.groups.collectAsState()
    val products by vm.filtered.collectAsState()
    val favorites by vm.favoriteProducts.collectAsState()
    val favoriteIds = remember(favorites) { favorites.mapTo(hashSetOf()) { it.id } }
    var url by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var groupQuery by remember { mutableStateOf("") }
    var importText by remember { mutableStateOf("") }
    val visibleGroups = groups.filter { groupQuery.isBlank() || it.name.contains(groupQuery, true) || it.url.contains(groupQuery, true) }

    LazyColumn(contentPadding = PaddingValues(bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { BrandHeader("กลุ่ม") }
        item {
            Box(Modifier.padding(horizontal = 14.dp)) {
                InfoCard(
                    "เชื่อมข้อมูลอย่างถูกสิทธิ์",
                    "บันทึก URL กลุ่ม, Share-to-App และ Import URL/ข้อความได้ ส่วน Sync จะทำงานเมื่อมี authorized provider เท่านั้น"
                )
            }
        }
        item {
            Column(Modifier.padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedTextField(groupQuery, { groupQuery = it }, label = { Text("ค้นหากลุ่ม") }, leadingIcon = { Icon(Icons.Default.Search, null) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp))
                OutlinedTextField(name, { name = it }, label = { Text("ชื่อกลุ่ม") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp))
                OutlinedTextField(url, { url = it }, label = { Text("Facebook Group URL") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp))
                OutlinedButton(
                    onClick = { vm.addGroup(name, url); name = ""; url = "" },
                    enabled = url.isNotBlank(),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.Add, null)
                    Spacer(Modifier.width(6.dp))
                    Text("เพิ่มกลุ่มด้วย URL")
                }
            }
        }
        if (visibleGroups.isNotEmpty()) {
            item { SectionTitle("กลุ่มที่บันทึก", Modifier.padding(horizontal = 14.dp)) }
            items(visibleGroups, key = { it.id }) { group ->
                Card(
                    Modifier.padding(horizontal = 14.dp).fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    ListItem(
                        headlineContent = { Text(group.name, fontWeight = FontWeight.SemiBold) },
                        supportingContent = {
                            Column {
                                Text(group.url, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(if (group.syncEnabled) "Sync พร้อมเมื่อ provider อนุญาต" else "Sync ปิด", style = MaterialTheme.typography.labelSmall, color = HeavyMuted)
                            }
                        },
                        leadingContent = {
                            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(42.dp)) {
                                Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Groups, null, tint = HeavyBlue) }
                            }
                        },
                        trailingContent = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = { vm.setGroupFavorite(group.id, !group.favorite) }) {
                                    Icon(if (group.favorite) Icons.Default.Star else Icons.Default.StarBorder, "Favorite group", tint = if (group.favorite) HeavyYellow else HeavyMuted)
                                }
                                Switch(checked = group.syncEnabled, onCheckedChange = { vm.setGroupSync(group.id, it) })
                            }
                        },
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                    )
                }
            }
        }
        item {
            Card(Modifier.padding(horizontal = 14.dp).fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Import Post", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(importText, { importText = it }, label = { Text("วาง URL หรือข้อความโพสต์") }, modifier = Modifier.fillMaxWidth(), minLines = 2, shape = RoundedCornerShape(14.dp))
                    Button(
                        onClick = { vm.importText(importText); importText = "" },
                        enabled = importText.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    ) { Text("นำเข้าและคัดกรองประกาศขาย") }
                }
            }
        }
        item { CategoryStrip(vm) }
        item { SectionTitle("ประกาศขายในแอป", Modifier.padding(horizontal = 14.dp)) }
        items(products.take(20), key = { it.id }) { product ->
            Box(Modifier.padding(horizontal = 14.dp)) {
                ProductCard(product, product.id in favoriteIds, { vm.toggleFavorite(product.id) }) { nav.navigate("detail/${product.id}") }
            }
        }
    }
}

@Composable
private fun MarketplaceScreen(vm: MainViewModel, nav: NavHostController) {
    val products by vm.filtered.collectAsState()
    val favorites by vm.favoriteProducts.collectAsState()
    val favoriteIds = remember(favorites) { favorites.mapTo(hashSetOf()) { it.id } }
    val history by vm.history.collectAsState()
    val recentlyViewed by vm.recentlyViewed.collectAsState()
    var grid by remember { mutableStateOf(true) }

    LazyColumn(contentPadding = PaddingValues(bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { BrandHeader("Marketplace") }
        item {
            Row(Modifier.padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) { SearchBar(vm) }
                Spacer(Modifier.width(8.dp))
                FilledTonalIconButton(onClick = { grid = !grid }) {
                    Icon(if (grid) Icons.Default.ViewList else Icons.Default.GridView, "สลับรูปแบบ")
                }
            }
        }
        item { CategoryStrip(vm) }
        item { ActiveFilterBar(vm) }
        item {
            Box(Modifier.padding(horizontal = 14.dp)) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
                ) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.VerifiedUser, null, tint = HeavyBlue, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("แสดงเฉพาะ Demo / Imported / provider ที่ได้รับอนุญาต", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        if (history.isNotEmpty()) {
            item {
                Column(Modifier.padding(horizontal = 14.dp)) {
                    SectionTitle("ค้นหาล่าสุด")
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(history.take(8), key = { it.query }) { item ->
                            AssistChip(onClick = { vm.search(item.query) }, label = { Text(item.query) })
                        }
                    }
                }
            }
        }
        if (recentlyViewed.isNotEmpty()) {
            item {
                Column(Modifier.padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    SectionTitle("ดูล่าสุด")
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(recentlyViewed.take(8), key = { it.id }) { product ->
                            CompactProductCard(
                                product,
                                favorite = product.id in favoriteIds,
                                modifier = Modifier.width(210.dp),
                                onFavorite = { vm.toggleFavorite(product.id) },
                                onClick = { nav.navigate("detail/${product.id}") }
                            )
                        }
                    }
                }
            }
        }
        item {
            Row(Modifier.padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("สินค้าแนะนำ", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                Text("${products.size} รายการ", style = MaterialTheme.typography.bodySmall, color = HeavyMuted)
            }
        }
        if (grid) {
            items(products.chunked(2)) { row ->
                Row(
                    Modifier.padding(horizontal = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    row.forEach { product ->
                        CompactProductCard(
                            product,
                            favorite = product.id in favoriteIds,
                            modifier = Modifier.weight(1f),
                            onFavorite = { vm.toggleFavorite(product.id) },
                            onClick = { nav.navigate("detail/${product.id}") }
                        )
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        } else {
            items(products, key = { it.id }) { product ->
                Box(Modifier.padding(horizontal = 14.dp)) {
                    ProductCard(product, product.id in favoriteIds, { vm.toggleFavorite(product.id) }) { nav.navigate("detail/${product.id}") }
                }
            }
        }
        item {
            OutlinedButton(
                onClick = vm::saveCurrentSearch,
                modifier = Modifier.padding(horizontal = 14.dp).fillMaxWidth(),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.NotificationsActive, null)
                Spacer(Modifier.width(8.dp))
                Text("บันทึกการค้นหานี้และแจ้งเตือน")
            }
        }
    }
}

@Composable
private fun SavedScreen(vm: MainViewModel, nav: NavHostController) {
    val products by vm.favoriteProducts.collectAsState()
    val searches by vm.savedSearches.collectAsState()
    LazyColumn(contentPadding = PaddingValues(bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { BrandHeader("บันทึก") }
        item {
            Box(Modifier.padding(horizontal = 14.dp)) {
                Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)) {
                    Row(Modifier.padding(5.dp)) {
                        Surface(shape = RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.surface, modifier = Modifier.weight(1f)) {
                            Text("สินค้าที่บันทึก", Modifier.padding(10.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center, color = HeavyBlue, fontWeight = FontWeight.SemiBold)
                        }
                        Text("การค้นหาที่บันทึก", Modifier.weight(1f).padding(10.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center, color = HeavyMuted)
                    }
                }
            }
        }
        if (products.isEmpty()) item { EmptyState("ยังไม่มีสินค้าที่บันทึก") }
        items(products, key = { it.id }) { product ->
            Box(Modifier.padding(horizontal = 14.dp)) {
                ProductCard(product, true, { vm.toggleFavorite(product.id) }) { nav.navigate("detail/${product.id}") }
            }
        }
        item { SectionTitle("การค้นหาที่บันทึก", Modifier.padding(horizontal = 14.dp)) }
        if (searches.isEmpty()) item { Box(Modifier.padding(horizontal = 14.dp)) { Text("ยังไม่มี Saved Search", color = HeavyMuted) } }
        items(searches, key = { it.id }) { search ->
            Card(Modifier.padding(horizontal = 14.dp).fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                ListItem(
                    headlineContent = { Text(search.name, fontWeight = FontWeight.SemiBold) },
                    supportingContent = {
                        Text(
                            listOfNotNull(
                                search.keyword.takeIf { it.isNotBlank() }, search.category, search.province,
                                search.minPrice?.let { "ตั้งแต่ ${formatPrice(it)}" },
                                search.maxPrice?.let { "ไม่เกิน ${formatPrice(it)}" }, search.sourceType
                            ).joinToString(" • ")
                        )
                    },
                    leadingContent = { Icon(Icons.Default.NotificationsActive, null, tint = HeavyBlue) },
                    colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                )
            }
        }
    }
}

@Composable
private fun SettingsScreen(vm: MainViewModel) {
    val categories by vm.categories.collectAsState()
    val keywordRules by vm.keywordRules.collectAsState()
    val dark by vm.darkMode.collectAsState()
    val notifications by vm.notificationsEnabled.collectAsState()
    var categoryName by remember { mutableStateOf("") }
    var rule by remember { mutableStateOf("") }

    LazyColumn(contentPadding = PaddingValues(bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { BrandHeader("ตั้งค่า") }
        item {
            SettingsCard {
                SettingsRow(Icons.Default.DarkMode, "โหมดสี", if (dark) "มืด" else "สว่าง") {
                    Switch(checked = dark, onCheckedChange = vm::setDarkMode)
                }
                HorizontalDivider()
                SettingsRow(Icons.Default.Notifications, "การแจ้งเตือน", "Saved Search / WorkManager") {
                    Switch(checked = notifications, onCheckedChange = vm::setNotificationsEnabled)
                }
                HorizontalDivider()
                SettingsRow(Icons.Default.Sync, "การซิงก์ข้อมูล", "ตามสิทธิ์ของแต่ละ provider") { Icon(Icons.Default.ChevronRight, null, tint = HeavyMuted) }
            }
        }
        item {
            SettingsCard {
                Text("หมวดหมู่สินค้า", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(categoryName, { categoryName = it }, modifier = Modifier.weight(1f), label = { Text("เพิ่มหมวดหมู่") }, shape = RoundedCornerShape(14.dp))
                    Spacer(Modifier.width(6.dp))
                    FilledIconButton(onClick = { vm.addCategory(categoryName); categoryName = "" }, enabled = categoryName.isNotBlank()) { Icon(Icons.Default.Add, null) }
                }
                Spacer(Modifier.height(8.dp))
                Text(categories.joinToString(" • ") { it.name }, style = MaterialTheme.typography.bodySmall, color = HeavyMuted)
            }
        }
        item {
            SettingsCard {
                Text("คำค้นหาที่รวม/ไม่รวม", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(rule, { rule = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Keyword") }, shape = RoundedCornerShape(14.dp))
                Spacer(Modifier.height(8.dp))
                Row {
                    Button(onClick = { vm.addKeywordRule(rule, true); rule = "" }, enabled = rule.isNotBlank()) { Text("Include") }
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton(onClick = { vm.addKeywordRule(rule, false); rule = "" }, enabled = rule.isNotBlank()) { Text("Exclude") }
                }
                if (keywordRules.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text(keywordRules.joinToString(" • ") { (if (it.include) "+" else "−") + it.keyword }, style = MaterialTheme.typography.bodySmall, color = HeavyMuted)
                }
            }
        }
        item {
            Box(Modifier.padding(horizontal = 14.dp)) {
                InfoCard("โหมดข้อมูลและความปลอดภัย", "Demo ติดป้ายชัดเจน ข้อมูล Live ต้องมาจาก provider/API ที่ได้รับอนุญาต และ Secret/Keystore ไม่ถูกฝังใน APK")
            }
        }
    }
}

@Composable
private fun SettingsCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.padding(horizontal = 14.dp).fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        content = { Column(Modifier.padding(14.dp), content = content) }
    )
}

@Composable
private fun SettingsRow(icon: ImageVector, title: String, subtitle: String, trailing: @Composable () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(40.dp)) {
            Box(contentAlignment = Alignment.Center) { Icon(icon, null, tint = HeavyBlue, modifier = Modifier.size(21.dp)) }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = HeavyMuted)
        }
        trailing()
    }
}

@Composable
private fun DetailScreen(nav: NavHostController, vm: DetailViewModel = hiltViewModel()) {
    val productState by vm.product.collectAsState()
    val favorite by vm.favorite.collectAsState()
    val related by vm.related.collectAsState()
    val context = LocalContext.current
    val product = productState
    if (product == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        return
    }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(0.dp)) {
        item {
            Box(Modifier.fillMaxWidth().height(300.dp)) {
                AsyncImage(
                    model = imageModel(product),
                    contentDescription = product.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    placeholder = painterResource(fallbackDrawable(product)),
                    error = painterResource(fallbackDrawable(product))
                )
                Row(
                    Modifier.fillMaxWidth().statusBarsPadding().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    FloatingIconButton(Icons.Default.ArrowBack, "ย้อนกลับ", onClick = nav::popBackStack)
                    Row {
                        FloatingIconButton(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "บันทึก", tint = if (favorite) HeavyRed else HeavyNavy, onClick = vm::toggleFavorite)
                        Spacer(Modifier.width(8.dp))
                        FloatingIconButton(Icons.Default.Share, "แชร์") {
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, "${product.title}\n${product.originalUrl}")
                            }
                            context.startActivity(Intent.createChooser(intent, "แชร์ประกาศ"))
                        }
                    }
                }
                Surface(
                    modifier = Modifier.align(Alignment.BottomEnd).padding(12.dp),
                    shape = RoundedCornerShape(10.dp),
                    color = Color.Black.copy(alpha = 0.65f)
                ) {
                    Text("1/${maxOf(1, product.imageUrls.split('|').count { it.isNotBlank() })}", Modifier.padding(horizontal = 9.dp, vertical = 5.dp), color = Color.White, style = MaterialTheme.typography.labelMedium)
                }
            }
        }
        item {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (product.isDemo) DemoBadge()
                Text(product.title, style = MaterialTheme.typography.headlineSmall)
                Text(product.price?.let(::formatPrice) ?: "ไม่ระบุราคา", color = HeavyRed, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                product.originalPrice?.let { Text("ราคาเดิม ${formatPrice(it)}", style = MaterialTheme.typography.bodyMedium, color = HeavyMuted) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocationOn, null, tint = HeavyMuted, modifier = Modifier.size(17.dp))
                    Text(" ${product.province}", style = MaterialTheme.typography.bodySmall, color = HeavyMuted)
                    Spacer(Modifier.width(14.dp))
                    Icon(Icons.Default.Schedule, null, tint = HeavyMuted, modifier = Modifier.size(17.dp))
                    Text(" ${formatRelativeDate(product.postedAt)}", style = MaterialTheme.typography.bodySmall, color = HeavyMuted)
                }
            }
        }
        item { HorizontalDivider() }
        item {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("รายละเอียด", style = MaterialTheme.typography.titleLarge)
                Text(product.description, lineHeight = 21.sp)
                Spacer(Modifier.height(4.dp))
                DetailGrid(product)
            }
        }
        item {
            if (!product.sellerName.isNullOrBlank()) {
                Card(Modifier.padding(horizontal = 16.dp).fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(48.dp)) {
                            Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Person, null, tint = HeavyBlue) }
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("ผู้ขาย", style = MaterialTheme.typography.labelSmall, color = HeavyMuted)
                            Text(product.sellerName.orEmpty(), fontWeight = FontWeight.SemiBold)
                            product.groupOrPageName?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = HeavyMuted) }
                        }
                        OutlinedButton(
                            onClick = { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(product.originalUrl))) } },
                            enabled = product.originalUrl.startsWith("http")
                        ) { Text("ดูต้นฉบับ") }
                    }
                }
            }
        }
        item {
            Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = vm::toggleFavorite, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) {
                    Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (favorite) HeavyRed else HeavyBlue)
                    Spacer(Modifier.width(6.dp))
                    Text(if (favorite) "บันทึกแล้ว" else "บันทึก")
                }
                Button(
                    onClick = { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(product.originalUrl))) } },
                    enabled = product.originalUrl.startsWith("http"),
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.OpenInNew, null)
                    Spacer(Modifier.width(6.dp))
                    Text("เปิดโพสต์")
                }
            }
        }
        if (related.isNotEmpty()) {
            item {
                Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SectionTitle("สินค้าที่เกี่ยวข้อง")
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(related, key = { it.id }) { relatedProduct ->
                            CompactProductCard(relatedProduct, modifier = Modifier.width(220.dp), onClick = { nav.navigate("detail/${relatedProduct.id}") })
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailGrid(product: ProductEntity) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.padding(12.dp)) {
            KeyValue("หมวดหมู่", product.category)
            KeyValue("ยี่ห้อ / รุ่น", listOfNotNull(product.brand, product.model).joinToString(" ").ifBlank { "ไม่ระบุ" })
            KeyValue("ปี", product.year?.toString() ?: "ไม่ระบุ")
            KeyValue("เลขไมล์ / ชั่วโมง", product.mileageOrHours ?: "ไม่ระบุ")
            KeyValue("สภาพ", product.conditionText)
            KeyValue("แหล่งข้อมูล", product.sourceName)
        }
    }
}

@Composable
private fun FloatingIconButton(icon: ImageVector, description: String, tint: Color = HeavyNavy, onClick: () -> Unit) {
    Surface(
        shape = CircleShape,
        color = Color.White.copy(alpha = 0.94f),
        shadowElevation = 4.dp,
        modifier = Modifier.size(42.dp).clickable(onClick = onClick)
    ) {
        Box(contentAlignment = Alignment.Center) { Icon(icon, description, tint = tint, modifier = Modifier.size(23.dp)) }
    }
}

@Composable
private fun ProductCard(
    product: ProductEntity,
    favorite: Boolean = false,
    onFavorite: () -> Unit = {},
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
    ) {
        Row(Modifier.height(142.dp)) {
            Box(Modifier.width(132.dp).fillMaxHeight().heightIn(min = 132.dp)) {
                AsyncImage(
                    model = imageModel(product),
                    contentDescription = product.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    placeholder = painterResource(fallbackDrawable(product)),
                    error = painterResource(fallbackDrawable(product))
                )
                if (product.isDemo) {
                    Surface(
                        modifier = Modifier.align(Alignment.BottomStart).padding(7.dp),
                        shape = RoundedCornerShape(8.dp),
                        color = Color.White.copy(alpha = 0.9f)
                    ) { Text("ตัวอย่าง", Modifier.padding(horizontal = 6.dp, vertical = 3.dp), style = MaterialTheme.typography.labelSmall, color = HeavyBlue) }
                }
            }
            Column(Modifier.padding(12.dp).weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Row(verticalAlignment = Alignment.Top) {
                    Text(product.title, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    IconButton(onClick = onFavorite, modifier = Modifier.size(32.dp)) {
                        Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "บันทึก", tint = if (favorite) HeavyRed else HeavyMuted, modifier = Modifier.size(21.dp))
                    }
                }
                Text(product.price?.let(::formatPrice) ?: "ไม่ระบุราคา", color = HeavyRed, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocationOn, null, tint = HeavyMuted, modifier = Modifier.size(15.dp))
                    Text(" ${product.province}", style = MaterialTheme.typography.bodySmall, color = HeavyMuted, maxLines = 1)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = RoundedCornerShape(7.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                        Text(product.category, Modifier.padding(horizontal = 6.dp, vertical = 2.dp), style = MaterialTheme.typography.labelSmall, color = HeavyBlue)
                    }
                    Spacer(Modifier.width(6.dp))
                    Text(formatRelativeDate(product.postedAt), style = MaterialTheme.typography.labelSmall, color = HeavyMuted, maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun CompactProductCard(
    product: ProductEntity,
    favorite: Boolean = false,
    modifier: Modifier = Modifier,
    onFavorite: () -> Unit = {},
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(17.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.42f))
    ) {
        Column {
            Box(Modifier.fillMaxWidth().height(128.dp)) {
                AsyncImage(
                    model = imageModel(product),
                    contentDescription = product.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    placeholder = painterResource(fallbackDrawable(product)),
                    error = painterResource(fallbackDrawable(product))
                )
                Surface(
                    modifier = Modifier.align(Alignment.TopEnd).padding(7.dp).size(34.dp).clickable(onClick = onFavorite),
                    shape = CircleShape,
                    color = Color.White.copy(alpha = 0.93f)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "บันทึก", tint = if (favorite) HeavyRed else HeavyNavy, modifier = Modifier.size(19.dp))
                    }
                }
                if (product.isDemo) {
                    Surface(modifier = Modifier.align(Alignment.BottomStart).padding(7.dp), shape = RoundedCornerShape(7.dp), color = Color.White.copy(alpha = 0.9f)) {
                        Text("ตัวอย่าง", Modifier.padding(horizontal = 6.dp, vertical = 3.dp), style = MaterialTheme.typography.labelSmall, color = HeavyBlue)
                    }
                }
            }
            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(product.title, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis, minLines = 2)
                Text(product.price?.let(::formatPrice) ?: "ไม่ระบุราคา", color = HeavyRed, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocationOn, null, tint = HeavyMuted, modifier = Modifier.size(14.dp))
                    Text(" ${product.province}", style = MaterialTheme.typography.labelSmall, color = HeavyMuted, maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun DemoBanner() {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = Color(0xFFFFF6D6),
        border = BorderStroke(1.dp, Color(0xFFF3D77C))
    ) {
        Row(Modifier.padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Info, null, tint = Color(0xFF9A6A00), modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Text("กำลังใช้ข้อมูลตัวอย่าง — ไม่ใช่ข้อมูล Facebook จริง", style = MaterialTheme.typography.bodySmall, color = Color(0xFF6F5200))
        }
    }
}

@Composable
private fun DemoBadge() {
    Surface(color = Color(0xFFFFF2BF), shape = RoundedCornerShape(8.dp)) {
        Text("ข้อมูลตัวอย่าง", Modifier.padding(horizontal = 7.dp, vertical = 3.dp), style = MaterialTheme.typography.labelSmall, color = Color(0xFF7A5700))
    }
}

@Composable
private fun InfoCard(title: String, body: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
            Icon(Icons.Default.Info, null, tint = HeavyBlue, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Column {
                Text(title, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(2.dp))
                Text(body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.8f))
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, modifier = modifier, style = MaterialTheme.typography.titleLarge)
}

@Composable
private fun EmptyState(text: String) {
    Column(Modifier.fillMaxWidth().padding(42.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.SearchOff, null, tint = HeavyMuted, modifier = Modifier.size(42.dp))
        Spacer(Modifier.height(8.dp))
        Text(text, color = HeavyMuted)
    }
}

@Composable
private fun KeyValue(key: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
        Text(key, modifier = Modifier.width(126.dp), color = HeavyMuted, style = MaterialTheme.typography.bodySmall)
        Text(value, modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium, style = MaterialTheme.typography.bodySmall)
    }
}

private fun firstImage(product: ProductEntity): String? = product.imageUrls.split('|').firstOrNull()?.trim()?.takeIf { it.isNotBlank() }

private fun imageModel(product: ProductEntity): Any {
    return when (firstImage(product)) {
        "res://demo_truck" -> R.drawable.demo_truck
        "res://demo_excavator" -> R.drawable.demo_excavator
        "res://demo_tractor" -> R.drawable.demo_tractor
        "res://demo_loader" -> R.drawable.demo_loader
        "res://demo_crane" -> R.drawable.demo_crane
        "res://demo_forklift" -> R.drawable.demo_forklift
        "res://demo_mixer" -> R.drawable.demo_mixer
        "res://demo_pickup" -> R.drawable.demo_pickup
        "res://demo_dump" -> R.drawable.demo_dump
        "res://demo_parts" -> R.drawable.demo_parts
        null -> fallbackDrawable(product)
        else -> firstImage(product) ?: fallbackDrawable(product)
    }
}

private fun fallbackDrawable(product: ProductEntity): Int = when {
    product.category.contains("ขุด", true) || product.category.contains("แม็คโคร", true) -> R.drawable.demo_excavator
    product.category.contains("Backhoe", true) || product.category.contains("ตัก", true) || product.category.contains("Loader", true) || product.category.contains("ก่อสร้าง", true) -> R.drawable.demo_loader
    product.category.contains("ไถ", true) || product.category.contains("แทรกเตอร์", true) || product.category.contains("เกี่ยว", true) || product.category.contains("เกษตร", true) -> R.drawable.demo_tractor
    product.category.contains("เครน", true) -> R.drawable.demo_crane
    product.category.contains("โฟล์คลิฟท์", true) -> R.drawable.demo_forklift
    product.category.contains("โม่", true) -> R.drawable.demo_mixer
    product.category.contains("กระบะ", true) || product.category.contains("รถมือสอง", true) -> R.drawable.demo_pickup
    product.category.contains("ดั้ม", true) -> R.drawable.demo_dump
    product.category.contains("อะไหล่", true) || product.category.contains("อุปกรณ์", true) || product.category == "อื่นๆ" -> R.drawable.demo_parts
    else -> R.drawable.demo_truck
}

private fun formatPrice(value: Long): String = "฿${NumberFormat.getNumberInstance(Locale("th", "TH")).format(value)}"

private fun formatRelativeDate(ms: Long): String {
    val minutes = ((System.currentTimeMillis() - ms).coerceAtLeast(0L) / 60_000L)
    return when {
        minutes < 1 -> "เมื่อสักครู่"
        minutes < 60 -> "$minutes นาทีที่แล้ว"
        minutes < 24 * 60 -> "${minutes / 60} ชม.ที่แล้ว"
        minutes < 7 * 24 * 60 -> "${minutes / (24 * 60)} วันที่แล้ว"
        else -> DateTimeFormatter.ofPattern("dd/MM/yyyy").withZone(ZoneId.systemDefault()).format(Instant.ofEpochMilli(ms))
    }
}
