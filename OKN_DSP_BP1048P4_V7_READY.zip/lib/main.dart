
import 'package:flutter/material.dart';

void main()=>runApp(const App());

class App extends StatelessWidget{
 const App({super.key});
 Widget build(BuildContext c)=>MaterialApp(
  theme:ThemeData.dark(),
  home:const Home());
}

class Home extends StatefulWidget{
 const Home({super.key});
 State<Home> createState()=>_HomeState();
}

class _HomeState extends State<Home>{
 int channel=1;
 double volume=50;
 bool bluetooth=false;
 final preset=['Flat','Music','Vocal','Bass'];

 Widget build(BuildContext c)=>Scaffold(
 appBar:AppBar(title:const Text('OKN_DSP BP1048P4 V7')),
 body:ListView(
 padding:const EdgeInsets.all(16),
 children:[
 Text('Channel CH$channel'),
 DropdownButton<int>(
 value:channel,
 items:List.generate(7,(i)=>DropdownMenuItem(
 value:i+1,child:Text('CH${i+1}'))),
 onChanged:(v)=>setState(()=>channel=v!)),
 Text('Master Volume ${volume.toInt()}'),
 Slider(value:volume,min:0,max:100,
 onChanged:(v)=>setState(()=>volume=v)),
 SwitchListTile(
 title:const Text('Bluetooth / DSP Link'),
 value:bluetooth,
 onChanged:(v)=>setState(()=>bluetooth=v)),
 const Text('Preset'),
 ...preset.map((e)=>ListTile(
 title:Text(e),
 trailing:const Icon(Icons.save))),
 ElevatedButton(
 onPressed:(){},
 child:const Text('Send To BP1048P4'))
 ]));
}
