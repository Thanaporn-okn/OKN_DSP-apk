import 'package:flutter/material.dart';
void main()=>runApp(const App());
class App extends StatelessWidget{
 const App({super.key});
 Widget build(BuildContext c)=>MaterialApp(
 home:Scaffold(
 appBar:AppBar(title:const Text('OKN_DSP BP1048P4 V39')),
 body:const Center(child:Text('Bluetooth DSP Controller\nCH1-CH7\nEQ Delay HPF LPF',style:TextStyle(fontSize:22)))
 ));
}
