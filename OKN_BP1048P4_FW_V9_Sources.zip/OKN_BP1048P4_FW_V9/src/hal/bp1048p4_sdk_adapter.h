#ifndef BP1048P4_SDK_ADAPTER_H
#define BP1048P4_SDK_ADAPTER_H

#include "bp1048p4_hal.h"
#include <stdbool.h>
#include <stdint.h>

#define BP1048P4_SDK_ADAPTER_ABI 3u

typedef enum {
    BP1048P4_SDK_EVIDENCE_NONE = 0,
    BP1048P4_SDK_EVIDENCE_FAMILY_ONLY = 1,
    BP1048P4_SDK_EVIDENCE_EXACT_CHIP = 2,
    BP1048P4_SDK_EVIDENCE_EXACT_BOARD = 3
} bp1048p4_sdk_evidence_level_t;

typedef struct {
    uint16_t abi_version;
    bp1048p4_sdk_evidence_level_t evidence_level;
    bool exact_bp1048p4_identity_verified;
    bool exact_golopine_board_verified;
    bool startup_verified;
    bool linker_verified;
    bool flash_programmer_verified;
    bool image_layout_verified;
    bool image_format_verified;
    bool programmer_transport_verified;
    bool recovery_path_verified;
    bool power_safety_verified;
    bool audio_api_verified;
    bool board_audio_route_verified;
    bool output_safety_mute_verified;
    bool ble_api_verified;
    bool board_ble_route_verified;
    bool nvm_api_verified;
    bool board_nvm_layout_verified;
} bp1048p4_sdk_capabilities_t;

typedef enum {
    BP1048P4_SDK_USE_RUNTIME_AUDIO = 0,
    BP1048P4_SDK_USE_RUNTIME_BLE = 1,
    BP1048P4_SDK_USE_RUNTIME_NVM = 2,
    BP1048P4_SDK_USE_FLASH_IMAGE = 3
} bp1048p4_sdk_use_t;

/* Evidence-only authorization. This function never probes, writes, or infers
 * hardware. EXACT_CHIP is intentionally insufficient for a GoloPine runtime. */
okn_status_t bp1048p4_sdk_adapter_authorize(const bp1048p4_sdk_capabilities_t *caps,
                                             bp1048p4_sdk_use_t use);

/* Shipped defaults remain locked until exact chip + exact board evidence is
 * integrated in a new reviewed firmware version. */
const bp1048p4_sdk_capabilities_t *bp1048p4_sdk_capabilities_get(void);

#endif
