#!/usr/bin/env python3
from pathlib import Path
import json, sys
root = Path(__file__).resolve().parents[1]
m = json.loads((root / 'target_port_manifest.json').read_text())
errors=[]
if m.get('schema') != 3: errors.append('target port schema must be 3')
if m.get('target') != 'BP1048P4': errors.append('target must be BP1048P4')
if m.get('board') != 'GoloPine 7CH': errors.append('board must be GoloPine 7CH')
ev=m.get('evidence',{})
required=[
'exact_bp1048p4_sdk','exact_chip_identity','exact_golopine_board_identity','startup',
'linker_memory_map','flash_programmer','programmer_transport','image_layout','image_format',
'recovery_path','power_safety','audio_path','output_safety_mute','ble_api','board_ble_route',
'nvm_api','board_nvm_layout','board_pin_map']
if any(k not in ev for k in required): errors.append('missing exact evidence fields')
if any(bool(ev.get(k)) for k in required): errors.append('V9 exact evidence must remain locked')
if m.get('hardware_flashable') is not False: errors.append('V9 hardware_flashable must be false')
pub=m.get('public_family_evidence',{})
if pub.get('classification') != 'FAMILY_ONLY_NOT_P4_PROOF': errors.append('public evidence must remain family-only')
if pub.get('p4_use_authorized') is not False: errors.append('family evidence must not authorize P4 use')
if errors:
    for e in errors: print('BLOCKED:',e)
    sys.exit(1)
print('PASS: V9 exact-target + flash-path gate remains fail-closed')
