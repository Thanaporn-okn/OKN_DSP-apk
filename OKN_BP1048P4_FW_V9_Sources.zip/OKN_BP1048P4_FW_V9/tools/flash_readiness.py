#!/usr/bin/env python3
from pathlib import Path
import argparse, json, sys

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description='Report BP1048P4/GoloPine flash readiness without probing hardware.')
parser.add_argument('--expect-locked', action='store_true')
args = parser.parse_args()

m = json.loads((root / 'target_port_manifest.json').read_text())
ev = m.get('evidence', {})
required = [
    'exact_bp1048p4_sdk','exact_chip_identity','exact_golopine_board_identity',
    'startup','linker_memory_map','flash_programmer','programmer_transport',
    'image_layout','image_format','recovery_path','power_safety',
    'board_pin_map'
]
missing = [k for k in required if not bool(ev.get(k))]
ready = not missing and bool(m.get('hardware_flashable'))
print('FLASH_READINESS=' + ('READY' if ready else 'LOCKED'))
print('TARGET=' + str(m.get('target')))
print('BOARD=' + str(m.get('board')))
for k in required:
    print(f'{k}={"PASS" if bool(ev.get(k)) else "BLOCKED"}')
if args.expect_locked and ready:
    print('ERROR: V9 must not become flash-ready without a reviewed exact-target evidence transition.')
    sys.exit(1)
if args.expect_locked and not missing:
    print('ERROR: all flash evidence unexpectedly true in locked V9.')
    sys.exit(1)
