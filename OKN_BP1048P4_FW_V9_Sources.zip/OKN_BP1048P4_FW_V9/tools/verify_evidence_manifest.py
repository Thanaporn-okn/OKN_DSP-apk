#!/usr/bin/env python3
from pathlib import Path
import json, re, sys
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'evidence_manifest.json').read_text())
errors=[]
if m.get('schema') != 2: errors.append('evidence schema must be 2')
if m.get('project_version') != 9: errors.append('project_version must be 9')
if m.get('policy') != 'FAIL_CLOSED_NO_INFERENCE': errors.append('policy mismatch')
prov=m.get('provenance',{})
sha_re=re.compile(r'^[0-9a-f]{64}$')
for k in ('previous_source_sha256','validation_zip_sha256'):
    if not sha_re.match(str(prov.get(k,''))): errors.append(f'invalid {k}')
req=m.get('required_exact_evidence',{})
if not req: errors.append('missing required_exact_evidence')
if any(bool(v) for v in req.values()): errors.append('V9 exact evidence flags must all remain false')
if m.get('hardware_authorized') is not False: errors.append('hardware_authorized must be false')
for ob in m.get('observations',[]):
    if ob.get('authorizes') not in ([],None): errors.append('observations may not authorize hardware in V9')
if errors:
    for e in errors: print('BLOCKED:',e)
    sys.exit(1)
print('PASS: V9 evidence manifest is internally consistent and non-authorizing')
