# Exact-target evidence intake — V9

V9 separates three evidence levels:

1. **FAMILY_ONLY** — useful for architecture/toolchain context but authorizes no
   BP1048P4 operation.
2. **EXACT_CHIP** — authentic BP1048P4-specific material. This still does not
   authorize GoloPine runtime or flashing because board routing/layout is not
   implied by the chip SDK.
3. **EXACT_BOARD** — authentic evidence that binds BP1048P4 behavior to this
   GoloPine 7CH board and the specific subsystem being enabled.

Before a future hardware-enabled version can be reviewed, collect authoritative
artifacts for the exact chip and board. Each artifact must be inventoried with
its SHA256. Acceptable evidence must explicitly establish the relevant item; a
file name, similar family part, string match, or successful host test is not
proof of register addresses, pins, linker layout, flash commands, audio route,
BLE route, or NVM layout.

Required evidence remains listed in `evidence_manifest.json` and
`target_port_manifest.json`. V9 deliberately ships every hardware field false.
`tools/evidence_inventory.py` can hash supplied vendor files without changing
those fields or authorizing hardware.

Example inventory command:

```sh
python3 tools/evidence_inventory.py vendor_file_1 vendor_file_2 > intake.json
```

A future version must cite/review the exact artifacts before changing any gate.
