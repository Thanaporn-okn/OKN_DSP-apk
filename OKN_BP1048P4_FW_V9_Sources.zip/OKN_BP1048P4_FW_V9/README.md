# OKN_BP1048P4_FW_V9

Clean-room replacement-firmware architecture for the GoloPine 7CH / BP1048P4 project.

V9 keeps all V1-V8 portable functionality and adds **flash-readiness gating**. It does not claim that the public B1 SDK, its NDS32 linker script, or BP1048B2 programming documentation applies to BP1048P4. Those are family-level research evidence only.

Implemented portable layers: 7-channel state, 15-band PEQ/channel, HPF/LPF, Gain/Mute/Phase/Delay, reference DSP, Protocol V2/readback, BLE-like stream framing, A/B CRC32 state persistence model, safe-boot contract, SDK evidence adapter, exact-chip/exact-board authorization gate.

New in V9: verified-programmer-transport gate, image-format gate, recovery-path gate, power-safety gate, no-flash-artifact CI guard, vendor evidence inventory tool, and mobile-flash readiness documentation.

Run `make verify`, `make test`, and `make demo` on a host. V9 intentionally remains `hardware_flashable=false` and contains no target firmware image.
