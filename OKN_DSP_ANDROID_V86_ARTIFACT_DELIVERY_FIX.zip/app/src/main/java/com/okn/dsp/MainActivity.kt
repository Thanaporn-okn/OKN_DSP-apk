package com.okn.dsp

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/** V86 all-status disconnect fail-closed unification launcher; V85/V84 writer/protocol behavior carried unchanged; V86 fixes artifact delivery path only. */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startActivity(Intent(this, UnifiedControlActivity::class.java))
        finish()
    }
}
