package com.okn.okn_dsp

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.app.ActivityCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class MainActivity : FlutterActivity() {
    private val methods = "okn_dsp/methods"
    private val events = "okn_dsp/events"
    private var sink: EventChannel.EventSink? = null
    private var gatt: BluetoothGatt? = null
    private var scanCallback: ScanCallback? = null

    private val serviceUuid = UUID.fromString("0000ab00-0000-1000-8000-00805f9b34fb")
    private val ab01Uuid = UUID.fromString("0000ab01-0000-1000-8000-00805f9b34fb")
    private val ab02Uuid = UUID.fromString("0000ab02-0000-1000-8000-00805f9b34fb")
    private val ab03Uuid = UUID.fromString("0000ab03-0000-1000-8000-00805f9b34fb")
    private val cccdUuid = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    private val handler = Handler(Looper.getMainLooper())

    private var notifyQueue: MutableList<BluetoothGattCharacteristic> = mutableListOf()
    private var notifyIndex = 0
    private var waitingDescriptor = false
    private var fullTestRunning = false

    override fun configureFlutterEngine(engine: FlutterEngine) {
        super.configureFlutterEngine(engine)

        EventChannel(engine.dartExecutor.binaryMessenger, events)
            .setStreamHandler(object : EventChannel.StreamHandler {
                override fun onListen(arguments: Any?, eventSink: EventChannel.EventSink?) {
                    sink = eventSink
                }
                override fun onCancel(arguments: Any?) {
                    sink = null
                }
            })

        MethodChannel(engine.dartExecutor.binaryMessenger, methods)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "scan" -> {
                        scan()
                        result.success(null)
                    }
                    "connect" -> {
                        val address = call.argument<String>("address")
                        if (address == null) result.error("ADDRESS", "Missing address", null)
                        else {
                            connect(address)
                            result.success(null)
                        }
                    }
                    "readAb01" -> {
                        val g = gatt
                        if (g == null) result.error("GATT", "Not connected", null)
                        else {
                            readAb01(g, "AB01 READ")
                            result.success(null)
                        }
                    }
                    "startFullTest" -> {
                        val g = gatt
                        if (g == null) result.error("GATT", "Not connected", null)
                        else {
                            startFullTest(g)
                            result.success(null)
                        }
                    }
                    else -> result.notImplemented()
                }
            }
    }

    private fun emit(m: Map<String, Any?>) {
        runOnUiThread { sink?.success(m) }
    }

    private fun hasScanPermission(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
        ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) ==
        PackageManager.PERMISSION_GRANTED

    private fun hasConnectPermission(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
        ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) ==
        PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    private fun scan() {
        if (!hasScanPermission()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_SCAN), 3002)
            emit(mapOf("type" to "status", "message" to "ต้องอนุญาต Bluetooth Scan ก่อน"))
            return
        }
        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val adapter = manager.adapter
        if (adapter == null || !adapter.isEnabled) {
            emit(mapOf("type" to "status", "message" to "กรุณาเปิด Bluetooth ของโทรศัพท์"))
            return
        }

        scanCallback?.let { adapter.bluetoothLeScanner?.stopScan(it) }
        val cb = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val device = result.device
                val name = result.scanRecord?.deviceName ?: device.name ?: ""
                emit(mapOf(
                    "type" to "scan",
                    "name" to name,
                    "address" to device.address,
                    "rssi" to result.rssi
                ))
            }

            override fun onScanFailed(errorCode: Int) {
                emit(mapOf("type" to "status", "message" to "Bluetooth scan failed=$errorCode"))
                emit(mapOf("type" to "scan_done"))
            }
        }
        scanCallback = cb
        adapter.bluetoothLeScanner?.startScan(cb)
        emit(mapOf("type" to "status", "message" to "กำลังค้นหา Bluetooth..."))
        handler.postDelayed({
            adapter.bluetoothLeScanner?.stopScan(cb)
            emit(mapOf("type" to "scan_done"))
        }, 7000)
    }

    @SuppressLint("MissingPermission")
    private fun connect(address: String) {
        if (!hasConnectPermission()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 3001)
            emit(mapOf("type" to "status", "message" to "ต้องอนุญาต Bluetooth Connect ก่อน"))
            return
        }

        gatt?.close()
        gatt = null
        notifyQueue.clear()
        notifyIndex = 0
        waitingDescriptor = false
        fullTestRunning = false

        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val device = manager.adapter.getRemoteDevice(address)
        emit(mapOf("type" to "status", "message" to "กำลังเชื่อมต่อ $address ..."))
        gatt = device.connectGatt(this, false, callback, BluetoothDevice.TRANSPORT_LE)
    }

    @SuppressLint("MissingPermission")
    private fun startFullTest(g: BluetoothGatt) {
        if (fullTestRunning) return
        fullTestRunning = true
        emit(mapOf("type" to "test", "message" to "ขั้นที่ 1/3: READ AB01"))
        readAb01(g, "STEP 1 — AB01 READ")

        handler.postDelayed({
            if (fullTestRunning) {
                emit(mapOf("type" to "test", "message" to "ขั้นที่ 2/3: รอ AB02 Notify"))
                emit(mapOf("type" to "status", "message" to "กำลังเก็บข้อมูล AB02 Notify 4 วินาที"))
            }
        }, 1200)

        handler.postDelayed({
            if (fullTestRunning) {
                emit(mapOf("type" to "test", "message" to "ขั้นที่ 3/3: รอ AB03 Notify"))
                emit(mapOf("type" to "status", "message" to "กำลังเก็บข้อมูล AB03 Notify 4 วินาที"))
            }
        }, 5200)

        handler.postDelayed({
            if (fullTestRunning) {
                fullTestRunning = false
                emit(mapOf("type" to "test", "message" to "จบการทดสอบ AB01 → AB02 → AB03"))
                emit(mapOf("type" to "status", "message" to "จบการทดสอบ — ไม่มีการส่ง payload ควบคุม DSP"))
            }
        }, 9200)
    }

    @SuppressLint("MissingPermission")
    private fun readAb01(g: BluetoothGatt, stage: String) {
        val service = g.getService(serviceUuid)
        val c = service?.getCharacteristic(ab01Uuid)
        if (c == null) {
            emit(mapOf("type" to "read", "stage" to stage, "data" to "NO AB01",
                "length" to 0, "status" to -1))
            return
        }
        val ok = g.readCharacteristic(c)
        emit(mapOf("type" to "status", "message" to "$stage accepted=$ok"))
    }

    @SuppressLint("MissingPermission")
    private fun enableNotify(g: BluetoothGatt, c: BluetoothGattCharacteristic): Boolean {
        val local = g.setCharacteristicNotification(c, true)
        val d = c.getDescriptor(cccdUuid)
        if (!local || d == null) {
            emit(mapOf("type" to "notify",
                "message" to "${shortUuid(c.uuid)}: local=$local CCCD=${d != null}"))
            return false
        }

        d.value =
            if ((c.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0)
                BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
            else
                BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE

        waitingDescriptor = true
        val ok = g.writeDescriptor(d)
        emit(mapOf("type" to "notify",
            "message" to "${shortUuid(c.uuid)}: CCCD write accepted=$ok"))
        return ok
    }

    @SuppressLint("MissingPermission")
    private fun startNotifyQueue(g: BluetoothGatt) {
        val service = g.getService(serviceUuid)
        if (service == null) {
            emit(mapOf("type" to "status", "message" to "ไม่พบ Service AB00"))
            return
        }

        val a2 = service.getCharacteristic(ab02Uuid)
        val a3 = service.getCharacteristic(ab03Uuid)
        notifyQueue = listOfNotNull(a2, a3).filter {
            val p = it.properties
            (p and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0 ||
            (p and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0
        }.toMutableList()

        notifyIndex = 0
        waitingDescriptor = false

        if (notifyQueue.isEmpty()) {
            emit(mapOf("type" to "notify", "message" to "ไม่พบ AB02/AB03 ที่รองรับ Notify/Indicate"))
            return
        }
        enableNextNotify(g)
    }

    @SuppressLint("MissingPermission")
    private fun enableNextNotify(g: BluetoothGatt) {
        if (notifyIndex >= notifyQueue.size) {
            emit(mapOf("type" to "notify", "message" to "เปิด Notify AB02 / AB03 ครบแล้ว"))
            return
        }

        val c = notifyQueue[notifyIndex]
        val ok = enableNotify(g, c)
        if (!ok) {
            waitingDescriptor = false
            notifyIndex++
            handler.postDelayed({ enableNextNotify(g) }, 300)
        }
    }

    private fun shortUuid(uuid: UUID): String {
        val s = uuid.toString()
        return if (s.startsWith("0000") && s.length >= 8) s.substring(4, 8).uppercase()
        else s
    }

    private val callback = object : BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, state: Int) {
            if (state == BluetoothProfile.STATE_CONNECTED) {
                emit(mapOf("type" to "connected"))
                emit(mapOf("type" to "status", "message" to "เชื่อมต่อแล้ว — กำลังค้นหา Service"))
                g.discoverServices()
            } else if (state == BluetoothProfile.STATE_DISCONNECTED) {
                emit(mapOf("type" to "disconnected"))
                emit(mapOf("type" to "status", "message" to "ตัดการเชื่อมต่อ status=$status"))
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            val out = StringBuilder("GATT STATUS: $status\nSERVICES: ${g.services.size}\n\n")
            for ((si, service) in g.services.withIndex()) {
                out.append("SERVICE ${si + 1}: ${service.uuid}\n")
                for ((ci, c) in service.characteristics.withIndex()) {
                    val p = c.properties
                    val props = mutableListOf<String>()
                    if (p and BluetoothGattCharacteristic.PROPERTY_READ != 0) props.add("READ")
                    if (p and BluetoothGattCharacteristic.PROPERTY_WRITE != 0) props.add("WRITE")
                    if (p and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0) props.add("WRITE_NR")
                    if (p and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0) props.add("NOTIFY")
                    if (p and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0) props.add("INDICATE")
                    out.append("  CHAR ${ci + 1}: ${c.uuid}\n")
                    out.append("    PROPERTIES: ${props.joinToString(", ")}\n")
                    for (d in c.descriptors) out.append("    DESC: ${d.uuid}\n")
                }
            }
            emit(mapOf("type" to "gatt", "text" to out.toString()))
            emit(mapOf("type" to "status", "message" to "พบ GATT — กำลังเปิด Notify AB02 / AB03"))
            startNotifyQueue(g)
        }

        override fun onCharacteristicRead(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            status: Int
        ) {
            val b = characteristic.value ?: byteArrayOf()
            if (characteristic.uuid == ab01Uuid) {
                val hex = b.joinToString(" ") { "%02X".format(it.toInt() and 0xFF) }
                emit(mapOf("type" to "read", "stage" to "AB01 READ",
                    "data" to hex, "length" to b.size, "status" to status))
            }
        }

        @SuppressLint("MissingPermission")
        override fun onDescriptorWrite(
            g: BluetoothGatt,
            descriptor: BluetoothGattDescriptor,
            status: Int
        ) {
            if (!waitingDescriptor) return
            waitingDescriptor = false
            emit(mapOf("type" to "notify",
                "message" to "${shortUuid(descriptor.characteristic.uuid)}: CCCD status=$status"))
            notifyIndex++
            handler.postDelayed({ enableNextNotify(g) }, 250)
        }

        override fun onCharacteristicChanged(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic
        ) {
            val b = characteristic.value ?: byteArrayOf()
            emitRx(characteristic, b)
        }

        override fun onCharacteristicChanged(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            value: ByteArray
        ) {
            emitRx(characteristic, value)
        }
    }

    private fun emitRx(c: BluetoothGattCharacteristic, b: ByteArray) {
        val hex = b.joinToString(" ") { "%02X".format(it.toInt() and 0xFF) }
        val now = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date())
        emit(mapOf(
            "type" to "rx",
            "characteristic" to c.uuid.toString(),
            "data" to hex,
            "length" to b.size,
            "time" to now
        ))
    }
}
