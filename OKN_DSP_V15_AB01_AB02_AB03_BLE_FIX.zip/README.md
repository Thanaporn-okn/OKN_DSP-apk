# OKN DSP V15 — BLE compile fix + AB01 → AB02 → AB03

V15 fixes the V14 Android release-build failure.

Root cause:
`MainActivity.kt` used Android BLE classes `ScanCallback` and `ScanResult`,
but the `android.bluetooth.le` imports were missing. This made Gradle report
`Unresolved reference 'ScanCallback'`, followed by cascading type errors.

V15 explicitly imports:
- android.bluetooth.le.BluetoothLeScanner
- android.bluetooth.le.ScanCallback
- android.bluetooth.le.ScanResult

The diagnostic flow remains:
1. Connect to the real DSP.
2. Discover GATT.
3. Enable AB02 Notify.
4. Enable AB03 Notify.
5. READ AB01.
6. Capture raw AB02/AB03 RX.
7. Do not send guessed DSP-control payloads.

Known GATT:
Service 0000AB00-0000-1000-8000-00805F9B34FB
AB01 0000AB01-0000-1000-8000-00805F9B34FB  READ/WRITE
AB02 0000AB02-0000-1000-8000-00805F9B34FB  NOTIFY
AB03 0000AB03-0000-1000-8000-00805F9B34FB  NOTIFY
