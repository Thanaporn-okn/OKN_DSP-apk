package com.okn.dsp.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun MainScreen() {

    val channels = listOf(
        "CH1 Front L",
        "CH2 Front R",
        "CH3 SUB",
        "CH4 Rear L",
        "CH5 Rear R",
        "CH6 AUX L",
        "CH7 AUX R"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp)
    ) {

        Text(
            "OKN_DSP BP1048P4 7CH Controller",
            style = MaterialTheme.typography.headlineSmall
        )

        Text("● Connected   BP1048P4 DSP")

        Spacer(modifier = Modifier.height(12.dp))

        Text("MASTER VOLUME")
        Slider(value = 0.7f, onValueChange = {})

        channels.forEach {
            Text(it)
            Slider(value = 0.5f, onValueChange = {})
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row {
            listOf("MAIN","EQ","CROSSOVER","DELAY","MIXER").forEach {
                Button(onClick = {}) {
                    Text(it)
                }
            }
        }
    }
}