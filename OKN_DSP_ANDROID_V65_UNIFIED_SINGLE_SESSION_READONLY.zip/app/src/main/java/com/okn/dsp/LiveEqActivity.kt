package com.okn.dsp

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.ContentValues
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.widget.*
import androidx.core.app.ActivityCompat
import com.okn.dsp.protocol.*
import com.okn.dsp.transport.BleProfile
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * V65: first real 7CH live EQ editor.
 * - Reads all 7 x 15 bands from the live Device Description.
 * - Exposes only standard PEAKING(type=12, F2/G/R=0) bands as writable.
 * - One WRITE 0x57 at a time, followed by a full Device Description readback.
 * - Verification failure automatically restores the previous 48-byte band record.
 * - Verified EQ changes remain RAM/live until the user explicitly presses permanent SAVE.
 * - Permanent SAVE emits only the V57-proven SaveParams trigger: 57 00000007 0000 0000.
 * - Save is guarded: it is allowed only after at least one verified V65 EQ change in the current session,
 *   while no write/descriptor operation is active. SaveParams persists all current turning parameters.
 */
class LiveEqActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private val ts = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    private val startupProbe16 = ByteCodec.hexToBytes("631C062443FD3844558001F3EDA0CCF8")

    private lateinit var status: TextView
    private lateinit var deviceList: LinearLayout
    private lateinit var startSessionButton: Button
    private lateinit var refreshButton: Button
    private lateinit var permanentSaveButton: Button
    private lateinit var channelSpinner: Spinner
    private lateinit var bandsHost: LinearLayout
    private lateinit var logView: TextView

    private var scanner: android.bluetooth.le.BluetoothLeScanner? = null
    private val found = LinkedHashMap<String, BluetoothDevice>()
    private var gatt: BluetoothGatt? = null
    private var ab01: BluetoothGattCharacteristic? = null
    private var ab02: BluetoothGattCharacteristic? = null
    private var connectedName: String? = null

    private var waitingAuth = false
    private var sessionReady = false
    private var txCipher: SessionTxCipher? = null
    private var rxCipher: SessionRxCipher? = null

    private enum class DescMode { INITIAL, REFRESH, VERIFY_TARGET, VERIFY_RESTORE }
    private var descMode: DescMode? = null
    private var descExpected = -1
    private val descBytes = ByteArrayOutputStream()

    private val bands = Array(7) { arrayOfNulls<EqBand48>(15) }
    private var selectedChannel = 1

    private var pendingChannel = 0
    private var pendingBand = 0
    private var pendingPrevious: EqBand48? = null
    private var pendingTarget: EqBand48? = null
    private var targetWritten = false
    private var restoreAttempt = 0
    private var pendingTimeout: Runnable? = null

    private var unsavedVerifiedChanges = false
    private var verifiedChangeCount = 0
    private var saveInFlight = false
    private var saveGattOk = false
    private var saveSettleRunnable: Runnable? = null
    private val saveCommitSettleMs = 5000L

    private val targetVerifyDelayMs = 3000L
    private val restoreVerifyDelayMs = 3000L
    private val restoreRetryDelayMs = 2500L

    private val captureLines = mutableListOf<String>()
    private var packetNo = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestBlePermissions()
        record("META", "V65_LIVE_EQ_ACTIVITY_START")
        record("META", "V65_RUNTIME_MAP_EVIDENCE ch1Id4=true ch2Id5=true ch3Id6=true ch4Id14=true ch5Id15=true ch6Id16=true ch7Id17=true source=V49+V50")
        record("META", "V65_SAVEPARAMS_PERSISTENCE_EVIDENCE trigger=570000000700000000 actuator=7 targetPersisted=true originalRestoredPersisted=true powerCycles=2 source=V57")
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (pendingPrevious != null || saveInFlight) {
            Toast.makeText(this, "V65 กำลัง verify/rollback/save กรุณารอให้จบก่อน", Toast.LENGTH_LONG).show()
            return
        }
        super.onBackPressed()
    }

    override fun onDestroy() {
        cancelPendingTimeout()
        cancelSaveSettle()
        try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
        try { gatt?.close() } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 22, 22, 28)
        }
        root.addView(TextView(this).apply {
            text = "OKN DSP V65 — LIVE EQ 7CH + PERMANENT SAVE"
            textSize = 22f
        })
        status = TextView(this).apply {
            text = "DISCONNECTED • LIVE EQ + GUARDED PERMANENT SAVE"
            textSize = 14f
            setPadding(0, 8, 0, 10)
        }
        root.addView(status)
        root.addView(TextView(this).apply {
            text = "V65 ใช้ actuator map ที่พิสูจน์จริงครบ 7CH จาก V49/V50. อ่าน EQ 15 band สดจาก DSP และเปิด WRITE เฉพาะ PEAKING type=12 ที่ F2=0, G=0, R=0 เท่านั้น. ทุก APPLY = WRITE 0x57 → รอ 3s → Device Description verify; ถ้า verify ไม่ผ่านจะ rollback 48-byte record เดิมอัตโนมัติ. หลังมีการเปลี่ยน EQ ที่ verify ผ่าน ผู้ใช้จึงกด SAVE TO DSP (PERMANENT) ได้. SaveParams ID7 / trigger 570000000700000000 ถูกพิสูจน์ด้วย power-cycle 2 รอบใน V57 แล้ว และจะส่งเฉพาะเมื่อ session idle + มี verified change ในรอบนี้."
            textSize = 13f
        })

        root.addView(Button(this).apply {
            text = "SCAN DSP"
            setOnClickListener { startScan() }
        })
        deviceList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(deviceList)

        startSessionButton = Button(this).apply {
            text = "START V65 VERIFIED LIVE EQ SESSION"
            isEnabled = false
            setOnClickListener { confirmStartSession() }
        }
        root.addView(startSessionButton)

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        channelSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@LiveEqActivity, android.R.layout.simple_spinner_dropdown_item, (1..7).map { "CH$it / ID${LiveEqPolicy.actuatorForChannel(it)}" })
            onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                    selectedChannel = position + 1
                    renderBands()
                }
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
            }
        }
        row.addView(channelSpinner, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        refreshButton = Button(this).apply {
            text = "REFRESH LIVE EQ"
            isEnabled = false
            setOnClickListener {
                if (sessionReady && pendingPrevious == null && descMode == null && !saveInFlight) requestDescriptor(DescMode.REFRESH)
                else Toast.makeText(this@LiveEqActivity, "V65 protocol busy/not ready", Toast.LENGTH_SHORT).show()
            }
        }
        row.addView(refreshButton)
        root.addView(row)

        bandsHost = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(bandsHost)

        permanentSaveButton = Button(this).apply {
            text = "SAVE TO DSP (PERMANENT) • GUARDED"
            isEnabled = true
            setOnClickListener { confirmPermanentSave() }
        }
        root.addView(permanentSaveButton)

        root.addView(TextView(this).apply {
            text = "SAVE จะเรียก SaveParams ID7 ที่ V57 พิสูจน์แล้ว และบันทึก turning parameters ปัจจุบันของ DSP ทั้งชุด ไม่ใช่เฉพาะ band ล่าสุด. ปุ่มกดได้เสมอแต่ guard จะไม่ยอมส่งถ้ายังไม่มี verified EQ change ใน session นี้หรือ protocol ยัง busy."
            textSize = 12f
        })

        root.addView(Button(this).apply {
            text = "SAVE V65 CAPTURE TO DOWNLOADS"
            setOnClickListener { saveCapture() }
        })
        logView = TextView(this).apply { textSize = 11f; setPadding(0, 12, 0, 0) }
        root.addView(logView)

        setContentView(ScrollView(this).apply { addView(root) })
        renderBands()
    }

    private fun renderBands() {
        if (!::bandsHost.isInitialized) return
        bandsHost.removeAllViews()
        val ch = selectedChannel
        bandsHost.addView(TextView(this).apply {
            text = "CH$ch • Actuator ID ${LiveEqPolicy.actuatorForChannel(ch)} • 15 bands"
            textSize = 19f
            setPadding(0, 12, 0, 8)
        })
        if (!sessionReady) {
            bandsHost.addView(TextView(this).apply {
                text = "เชื่อม DSP แล้วกด START V65 VERIFIED LIVE EQ SESSION เพื่ออ่านค่าจริงก่อน"
                textSize = 14f
            })
            return
        }

        for (band1 in 1..15) {
            val b = bands[ch - 1][band1 - 1]
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, 8, 0, 12)
            }
            if (b == null) {
                box.addView(TextView(this).apply { text = "Band $band1 • MISSING/READ ONLY"; textSize = 15f })
                bandsHost.addView(box)
                continue
            }
            val writable = LiveEqPolicy.isWritable(b)
            box.addView(TextView(this).apply {
                text = "Band $band1 • offset=${LiveEqPolicy.offsetForBand(band1)} • type=${b.type} • F=${fmt(b.frequency)}Hz • Q=${fmt(b.q)} • B=${fmt(b.boostDb)}dB • R=${fmt(b.r)} • ${if (writable) "LIVE WRITABLE" else "READ ONLY"}"
                textSize = 14f
            })
            if (writable) {
                val edit = EditText(this).apply {
                    inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED
                    setText(String.format(Locale.US, "%.1f", b.boostDb))
                    hint = "-12.0 .. +12.0 dB"
                }
                val actionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                actionRow.addView(edit, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                actionRow.addView(Button(this).apply {
                    text = "APPLY + VERIFY"
                    isEnabled = pendingPrevious == null
                    setOnClickListener {
                        val requested = edit.text.toString().toFloatOrNull()
                        if (requested == null) {
                            Toast.makeText(this@LiveEqActivity, "กรอกค่า dB ก่อน", Toast.LENGTH_SHORT).show()
                        } else confirmApply(ch, band1, requested)
                    }
                })
                box.addView(actionRow)
            } else {
                box.addView(TextView(this).apply {
                    text = "ล็อกไว้: V65 ไม่เขียน type/non-standard band ที่ semantics ยังไม่พิสูจน์"
                    textSize = 12f
                })
            }
            bandsHost.addView(box)
        }
    }

    private fun confirmStartSession() {
        if (pendingPrevious != null || descMode != null || saveInFlight) {
            Toast.makeText(this, "V65 กำลัง verify/rollback/save กรุณารอให้จบก่อน", Toast.LENGTH_LONG).show(); return
        }
        if (gatt == null || ab01 == null || ab02 == null) {
            Toast.makeText(this, "เชื่อม AB00/AB01/AB02 ก่อน", Toast.LENGTH_LONG).show(); return
        }
        AlertDialog.Builder(this)
            .setTitle("Start V65 verified live EQ")
            .setMessage("AUTH16 → derive RandKey → อ่าน Device Description สดครบ 7CH × 15 bands\n\nขั้นนี้ยังไม่เขียน EQ และยังไม่ส่ง SaveParams")
            .setNegativeButton("ยกเลิก", null)
            .setPositiveButton("START READ-ONLY LIVE EQ LOAD") { _, _ -> startSession() }
            .show()
    }

    private fun startSession() {
        cancelPendingTimeout()
        val g = gatt ?: return
        val w = ab01 ?: return
        waitingAuth = true
        sessionReady = false
        txCipher = null
        rxCipher = null
        descMode = null
        descExpected = -1
        descBytes.reset()
        clearPending(false)
        cancelSaveSettle()
        unsavedVerifiedChanges = false
        verifiedChangeCount = 0
        saveInFlight = false
        saveGattOk = false
        for (c in bands.indices) for (b in bands[c].indices) bands[c][b] = null
        refreshButton.isEnabled = false
        record("META", "V65_LIVE_EQ_SESSION_START")
        if (!writeNoResponse(g, w, startupProbe16, "TX_AUTH16_V65")) {
            waitingAuth = false
            status.text = "AUTH16 queue failed"
        } else status.text = "AUTH16 sent • waiting 32B auth response"
    }

    private fun confirmApply(channel1: Int, band1: Int, requested: Float) {
        if (!sessionReady || pendingPrevious != null || descMode != null || saveInFlight) {
            Toast.makeText(this, "Session ไม่พร้อมหรือกำลัง verify/save ค่าอื่น", Toast.LENGTH_LONG).show(); return
        }
        if (!WriteGate.liveEqEditorEnabled) {
            Toast.makeText(this, "V65 live EQ gate disabled", Toast.LENGTH_LONG).show(); return
        }
        val current = bands[channel1 - 1][band1 - 1] ?: return
        if (!LiveEqPolicy.isWritable(current)) {
            Toast.makeText(this, "Band นี้ถูกล็อก READ ONLY", Toast.LENGTH_LONG).show(); return
        }
        val targetDb = LiveEqPolicy.sanitizeBoost(requested)
        if (targetDb == null) {
            Toast.makeText(this, "ช่วงที่อนุญาต ${LiveEqPolicy.MIN_BOOST_DB}..${LiveEqPolicy.MAX_BOOST_DB} dB", Toast.LENGTH_LONG).show(); return
        }
        if (kotlin.math.abs(targetDb - current.boostDb) < 0.0001f) {
            Toast.makeText(this, "ค่าเท่ากับ DSP ปัจจุบันแล้ว", Toast.LENGTH_SHORT).show(); return
        }
        AlertDialog.Builder(this)
            .setTitle("V65 LIVE EQ WRITE + VERIFY")
            .setMessage("CH$channel1 / ID${LiveEqPolicy.actuatorForChannel(channel1)} / Band$band1\n${fmt(current.boostDb)} → ${fmt(targetDb)} dB\n\nจะเขียน 48-byte band record แล้วอ่าน Device Description กลับมาตรวจ. ถ้าตรวจไม่ผ่านจะ rollback ค่าเดิมอัตโนมัติ.\nรอบ APPLY นี้ยังไม่ส่ง SaveParams; ต้องกด SAVE TO DSP (PERMANENT) แยกหลัง verify")
            .setNegativeButton("ยกเลิก", null)
            .setPositiveButton("WRITE LIVE + VERIFY") { _, _ -> applyBand(channel1, band1, current, targetDb) }
            .show()
    }

    private fun applyBand(channel1: Int, band1: Int, previous: EqBand48, targetDb: Float) {
        val g = gatt ?: return
        val w = ab01 ?: return
        val tx = txCipher ?: return
        val target = try { LiveEqPolicy.targetFromCurrent(previous, targetDb) } catch (e: Exception) {
            Toast.makeText(this, "Target invalid: ${e.message}", Toast.LENGTH_LONG).show(); return
        }
        pendingChannel = channel1
        pendingBand = band1
        pendingPrevious = previous
        pendingTarget = target
        targetWritten = false
        restoreAttempt = 0
        val plain = LiveEqPolicy.encodeWrite(channel1, band1, target)
        val enc = tx.encryptNext(plain)
        record("META", "V65_LIVE_EQ_WRITE_PLAIN=${ByteCodec.run { plain.toHex() }} channel=$channel1 actuator=${LiveEqPolicy.actuatorForChannel(channel1)} band=$band1 offset=${LiveEqPolicy.offsetForBand(band1)} previousBoost=${previous.boostDb} targetBoost=${target.boostDb} saveParams=false")
        if (!writeNoResponse(g, w, enc, "TX_EQ_CH${channel1}_B${band1}_LIVE_V65")) {
            clearPending(true)
            status.text = "V65 write queue failed • no verified change"
            return
        }
        targetWritten = true
        armPendingTimeout()
        startSessionButton.isEnabled = false
        refreshButton.isEnabled = false
        status.text = "V65 WRITE sent CH$channel1 Band$band1=${fmt(target.boostDb)}dB • verifying"
        renderBands()
        record("META", "V65_TARGET_VERIFY_DELAY_MS=$targetVerifyDelayMs channel=$channel1 band=$band1")
        handler.postDelayed({ requestDescriptor(DescMode.VERIFY_TARGET) }, targetVerifyDelayMs)
    }

    private fun requestDescriptor(mode: DescMode) {
        val g = gatt ?: return
        val w = ab01 ?: return
        val tx = txCipher ?: return
        if (descMode != null) return
        descMode = mode
        descExpected = -1
        descBytes.reset()
        val plain = SessionCryptoFacts.DEVICE_DESCRIPTION_REQUEST
        val enc = tx.encryptNext(plain)
        record("META", "V65_DESC_REQUEST mode=$mode plain=${ByteCodec.run { plain.toHex() }} channel=$pendingChannel band=$pendingBand")
        if (!writeNoResponse(g, w, enc, "TX_DESC_V65_${mode.name}")) {
            descMode = null
            if (mode == DescMode.VERIFY_TARGET && targetWritten) restorePrevious("target-desc-request-failed")
            else status.text = "Descriptor request queue failed"
        }
    }

    private fun handleAb02(value: ByteArray) {
        record("RX_NOTIFY", "len=${value.size} hex=${ByteCodec.run { value.toHex() }}")
        if (waitingAuth) {
            if (value.size != 32) return
            try {
                val d = PreAuthRandKeyDecoder.decode(value)
                txCipher = SessionTxCipher(d.randKey)
                rxCipher = SessionRxCipher(d.randKey)
                waitingAuth = false
                record("META", "V65_RANDKEY_DERIVED type=${d.typeId} ver=${d.versionId} rand=${ByteCodec.run { d.randKey.toHex() }}")
                requestDescriptor(DescMode.INITIAL)
            } catch (e: Exception) {
                waitingAuth = false
                record("META", "V65_AUTH_DECODE_ERROR ${e.javaClass.simpleName}:${e.message}")
                status.text = "Auth decode failed"
            }
            return
        }
        val rx = rxCipher ?: return
        val plain = try { rx.decryptNext(value) } catch (e: Exception) {
            record("META", "V65_RX_DECRYPT_ERROR ${e.javaClass.simpleName}:${e.message}")
            sessionReady = false
            return
        }
        record("RX_PLAIN", "len=${plain.size} hex=${ByteCodec.run { plain.toHex() }}")
        if (descMode != null) collectDescriptor(plain)
    }

    private fun collectDescriptor(plain: ByteArray) {
        val mode = descMode ?: return
        if (descExpected < 0) {
            if (plain.size < 4 || (plain[0].toInt() and 0xff) != 0x86) {
                record("META", "V65_DESC_NONHEADER mode=$mode marker=${plain.firstOrNull()?.toInt()?.and(0xff)} len=${plain.size}")
                return
            }
            descExpected = (plain[1].toInt() and 0xff) or ((plain[2].toInt() and 0xff) shl 8) or ((plain[3].toInt() and 0xff) shl 16)
            descBytes.reset()
            descBytes.write(plain, 4, plain.size - 4)
            record("META", "V65_DESC_HEADER mode=$mode jsonLen=$descExpected")
        } else {
            if (plain.isEmpty() || (plain[0].toInt() and 0xff) != 0x82) {
                record("META", "V65_DESC_NONCONT mode=$mode marker=${plain.firstOrNull()?.toInt()?.and(0xff)} len=${plain.size}")
                return
            }
            descBytes.write(plain, 1, plain.size - 1)
        }
        if (descExpected > 0 && descBytes.size() >= descExpected) {
            val bytes = descBytes.toByteArray().copyOf(descExpected)
            val obj = try { JSONObject(bytes.toString(Charsets.UTF_8)) } catch (e: Exception) {
                record("META", "V65_DESC_JSON_ERROR ${e.javaClass.simpleName}:${e.message}")
                descMode = null; descExpected = -1; descBytes.reset(); sessionReady = false; return
            }
            record("META", "V65_DESC_COMPLETE mode=$mode bytes=${bytes.size}")
            descMode = null
            descExpected = -1
            descBytes.reset()
            // V65: BluetoothGatt notifications may arrive off the main thread.
            // onDescriptorComplete mutates Android Views (status + dynamic control rows),
            // so dispatch it to the main looper before touching the UI hierarchy.
            handler.post { onDescriptorComplete(mode, obj) }
        }
    }

    private fun onDescriptorComplete(mode: DescMode, obj: JSONObject) {
        when (mode) {
            DescMode.INITIAL, DescMode.REFRESH -> loadAllBands(mode, obj)
            DescMode.VERIFY_TARGET -> verifyTarget(obj)
            DescMode.VERIFY_RESTORE -> verifyRestore(obj)
        }
    }

    private fun loadAllBands(mode: DescMode, obj: JSONObject) {
        var total = 0
        var writable = 0
        for (ch in 1..7) {
            val actuator = LiveEqPolicy.actuatorForChannel(ch)
            for (b in 1..15) {
                val band = extractBand(obj, actuator, b)
                bands[ch - 1][b - 1] = band
                if (band != null) {
                    total++
                    if (LiveEqPolicy.isWritable(band)) writable++
                }
            }
        }
        val ok = total == 105
        sessionReady = ok
        record("META", "V65_LIVE_EQ_LOAD mode=$mode totalBands=$total writablePeakingBands=$writable expected=105 ready=$ok saveParamsSent=false")
        runOnUiThread {
            status.text = if (ok) "V65 LIVE EQ READY • 7CH×15 loaded • writable=$writable • no unsaved V65 change yet" else "V65 BLOCKED • descriptor did not contain all 105 EQ bands"
            refreshButton.isEnabled = ok && pendingPrevious == null
            renderBands()
        }
    }

    private fun verifyTarget(obj: JSONObject) {
        val ch = pendingChannel
        val band1 = pendingBand
        val expected = pendingTarget ?: run { failHard("missing-target") ; return }
        val actual = extractBand(obj, LiveEqPolicy.actuatorForChannel(ch), band1)
        val ok = actual != null && LiveEqPolicy.semanticMatches(actual, expected)
        record("META", "V65_TARGET_DESCRIPTOR_VERIFY channel=$ch actuator=${LiveEqPolicy.actuatorForChannel(ch)} band=$band1 expectedBoost=${expected.boostDb} actualBoost=${actual?.boostDb ?: Float.NaN} verified=$ok")
        if (ok) {
            bands[ch - 1][band1 - 1] = actual
            targetWritten = false
            cancelPendingTimeout()
            unsavedVerifiedChanges = true
            verifiedChangeCount += 1
            record("META", "V65_LIVE_EQ_WRITE_COMPLETE channel=$ch actuator=${LiveEqPolicy.actuatorForChannel(ch)} band=$band1 appliedBoost=${actual!!.boostDb} verified=true saveParamsSent=false persistence=RAM_DIRTY verifiedChangeCount=$verifiedChangeCount")
            clearPending(false)
            runOnUiThread {
                status.text = "V65 VERIFIED • CH$ch Band$band1=${fmt(actual.boostDb)}dB • UNSAVED • กด SAVE TO DSP เมื่อพร้อม"
                refreshButton.isEnabled = true
                startSessionButton.isEnabled = true
                renderBands()
            }
        } else {
            record("META", "V65_TARGET_VERIFY_FAILED channel=$ch band=$band1 rollbackRequired=true")
            restorePrevious("target-verify-failed")
        }
    }

    private fun restorePrevious(reason: String) {
        val previous = pendingPrevious ?: return
        val ch = pendingChannel
        val band1 = pendingBand
        if (descMode != null) {
            record("META", "V65_ROLLBACK_DEFERRED mode=$descMode reason=$reason")
            handler.postDelayed({ restorePrevious(reason) }, 500L)
            return
        }
        val g = gatt ?: run { failHard("rollback-no-gatt"); return }
        val w = ab01 ?: run { failHard("rollback-no-ab01"); return }
        val tx = txCipher ?: run { failHard("rollback-no-cipher"); return }
        restoreAttempt++
        val plain = LiveEqPolicy.encodeRestore(ch, band1, previous)
        val enc = tx.encryptNext(plain)
        record("META", "V65_EQ_ROLLBACK_WRITE_PLAIN=${ByteCodec.run { plain.toHex() }} attempt=$restoreAttempt channel=$ch actuator=${LiveEqPolicy.actuatorForChannel(ch)} band=$band1 offset=${LiveEqPolicy.offsetForBand(band1)} previousBoost=${previous.boostDb} reason=$reason saveParams=false")
        if (!writeNoResponse(g, w, enc, "TX_EQ_CH${ch}_B${band1}_ROLLBACK_V65_A$restoreAttempt")) {
            failHard("rollback-queue-failed")
            return
        }
        record("META", "V65_ROLLBACK_VERIFY_DELAY_MS=$restoreVerifyDelayMs attempt=$restoreAttempt")
        handler.postDelayed({ requestDescriptor(DescMode.VERIFY_RESTORE) }, restoreVerifyDelayMs)
    }

    private fun verifyRestore(obj: JSONObject) {
        val previous = pendingPrevious ?: run { failHard("missing-rollback-baseline"); return }
        val ch = pendingChannel
        val band1 = pendingBand
        val actual = extractBand(obj, LiveEqPolicy.actuatorForChannel(ch), band1)
        val ok = actual != null && LiveEqPolicy.semanticMatches(actual, previous)
        record("META", "V65_ROLLBACK_DESCRIPTOR_VERIFY attempt=$restoreAttempt channel=$ch actuator=${LiveEqPolicy.actuatorForChannel(ch)} band=$band1 expectedBoost=${previous.boostDb} actualBoost=${actual?.boostDb ?: Float.NaN} verified=$ok")
        if (ok) {
            bands[ch - 1][band1 - 1] = actual
            targetWritten = false
            cancelPendingTimeout()
            record("META", "V65_LIVE_EQ_WRITE_ABORTED_AND_ROLLED_BACK channel=$ch band=$band1 restored=true restoreAttempts=$restoreAttempt saveParamsSent=false")
            clearPending(false)
            runOnUiThread {
                status.text = "V65 TARGET VERIFY FAILED • rollback สำเร็จ • ค่าเดิมถูกคืน • save capture"
                refreshButton.isEnabled = true
                startSessionButton.isEnabled = true
                renderBands()
            }
        } else if (restoreAttempt < 2) {
            record("META", "V65_ROLLBACK_RETRY_SCHEDULED nextAttempt=${restoreAttempt + 1} delayMs=$restoreRetryDelayMs")
            handler.postDelayed({ restorePrevious("rollback-verify-retry") }, restoreRetryDelayMs)
        } else {
            failHard("rollback-verify-failed-after-retry")
        }
    }

    private fun armPendingTimeout() {
        cancelPendingTimeout()
        pendingTimeout = Runnable {
            if (pendingPrevious != null && targetWritten) {
                record("META", "V65_FAILSAFE_ROLLBACK_TRIGGERED channel=$pendingChannel band=$pendingBand mode=$descMode attempt=$restoreAttempt")
                if (descMode == null && restoreAttempt < 2) restorePrevious("failsafe-timeout")
            }
        }.also { handler.postDelayed(it, 45000L) }
        record("META", "V65_FAILSAFE_WINDOW_MS=45000")
    }

    private fun cancelPendingTimeout() {
        pendingTimeout?.let { handler.removeCallbacks(it) }
        pendingTimeout = null
    }

    private fun clearPending(cancelTimeout: Boolean) {
        if (cancelTimeout) cancelPendingTimeout()
        pendingChannel = 0
        pendingBand = 0
        pendingPrevious = null
        pendingTarget = null
        targetWritten = false
        restoreAttempt = 0
    }

    private fun failHard(reason: String) {
        cancelPendingTimeout()
        record("META", "V65_LIVE_EQ_STOPPED reason=$reason channel=$pendingChannel band=$pendingBand saveParamsSent=false")
        sessionReady = false
        runOnUiThread {
            status.text = "V65 STOPPED: $reason • save capture • do not write again"
            refreshButton.isEnabled = false
            renderBands()
        }
    }

    private fun extractBand(obj: JSONObject, actuatorId: Int, bandIndex1: Int): EqBand48? {
        val arr = obj.optJSONArray("actuators") ?: return null
        for (i in 0 until arr.length()) {
            val a = arr.optJSONObject(i) ?: continue
            if (a.optInt("ID", -1) != actuatorId || a.optInt("type", -1) != 4084) continue
            val bandArr = a.optJSONArray("UFE_TYPE_BIQUAD_CASCADE15_F") ?: return null
            val b = bandArr.optJSONObject(bandIndex1 - 1) ?: return null
            fun f(key: String): Float = b.optDouble(key, Double.NaN).toFloat()
            val out = EqBand48(
                type = b.optInt("typ", -1),
                frequency = f("F"), frequency2 = f("F2"), q = f("Q"), boostDb = f("B"),
                gain = f("G"), r = f("R"), b0 = f("B0"), b1 = f("B1"), b2 = f("B2"),
                a1 = f("A1"), a2 = f("A2"),
            )
            if (listOf(out.frequency, out.frequency2, out.q, out.boostDb, out.gain, out.r, out.b0, out.b1, out.b2, out.a1, out.a2).any { !it.isFinite() }) return null
            return out
        }
        return null
    }

    private fun confirmPermanentSave() {
        if (!WriteGate.liveEqPersistentSaveEnabled) {
            Toast.makeText(this, "V65 persistent-save gate disabled", Toast.LENGTH_LONG).show(); return
        }
        if (!sessionReady || gatt == null || ab01 == null || txCipher == null) {
            Toast.makeText(this, "เชื่อม DSP และ START V65 session ก่อน", Toast.LENGTH_LONG).show(); return
        }
        if (saveInFlight || pendingPrevious != null || descMode != null || waitingAuth) {
            Toast.makeText(this, "Protocol กำลัง busy/verify อยู่ กรุณารอให้จบก่อน SAVE", Toast.LENGTH_LONG).show(); return
        }
        if (!unsavedVerifiedChanges || verifiedChangeCount <= 0) {
            Toast.makeText(this, "ยังไม่มี EQ change ที่ V65 verify ผ่านใน session นี้ จึงยังไม่ส่ง SaveParams", Toast.LENGTH_LONG).show(); return
        }
        if (!SaveParamsPolicy.triggerIsExact()) {
            record("META", "V65_SAVE_BLOCKED reason=saveparams-trigger-not-exact")
            Toast.makeText(this, "SaveParams trigger policy mismatch • blocked", Toast.LENGTH_LONG).show(); return
        }
        AlertDialog.Builder(this)
            .setTitle("SAVE V65 TO DSP PERMANENTLY")
            .setMessage("มี verified EQ changes = $verifiedChangeCount\n\nV65 จะส่ง SaveParams ID7 trigger ที่พิสูจน์ด้วย power-cycle 2 รอบแล้ว:\n57 00000007 0000 0000\n\nSaveParams จะบันทึก turning parameters ปัจจุบันของ DSP ทั้งชุด ไม่ใช่เฉพาะ band ล่าสุด. ห้ามปิด DSP ระหว่างช่วง commit 5 วินาที")
            .setNegativeButton("ยกเลิก", null)
            .setPositiveButton("SAVE PERMANENTLY") { _, _ -> sendPermanentSave() }
            .show()
    }

    private fun sendPermanentSave() {
        val g = gatt ?: return
        val w = ab01 ?: return
        val tx = txCipher ?: return
        if (!sessionReady || saveInFlight || pendingPrevious != null || descMode != null || waitingAuth || !unsavedVerifiedChanges) {
            record("META", "V65_SAVE_BLOCKED reason=guard-race sessionReady=$sessionReady saveInFlight=$saveInFlight pendingEq=${pendingPrevious != null} descMode=$descMode waitingAuth=$waitingAuth dirty=$unsavedVerifiedChanges")
            Toast.makeText(this, "SAVE guard ไม่พร้อม • ไม่มีการส่ง SaveParams", Toast.LENGTH_LONG).show(); return
        }
        val plain = SaveParamsPolicy.encodeTrigger()
        if (ByteCodec.run { plain.toHex() } != "570000000700000000") {
            record("META", "V65_SAVE_BLOCKED reason=unexpected-trigger plain=${ByteCodec.run { plain.toHex() }}")
            return
        }
        saveInFlight = true
        saveGattOk = false
        val enc = tx.encryptNext(plain)
        record("META", "V65_SAVEPARAMS_TRIGGER_PLAIN=${ByteCodec.run { plain.toHex() }} actuator=7 offset=0 length=0 payload=none verifiedChanges=$verifiedChangeCount evidence=V57_two_power_cycles")
        if (!writeNoResponse(g, w, enc, "TX_SAVEPARAMS_ID7_V65")) {
            saveInFlight = false
            record("META", "V65_SAVEPARAMS_QUEUE_FAILED changesRemainUnsaved=true")
            status.text = "V65 SAVE queue failed • changes remain UNSAVED"
            return
        }
        record("META", "V65_SAVEPARAMS_QUEUE_OK settleMs=$saveCommitSettleMs")
        status.text = "V65 SaveParams sent • DO NOT POWER OFF • waiting ${saveCommitSettleMs}ms commit window"
        cancelSaveSettle()
        saveSettleRunnable = Runnable {
            if (!saveInFlight) return@Runnable
            if (saveGattOk) {
                val savedCount = verifiedChangeCount
                unsavedVerifiedChanges = false
                verifiedChangeCount = 0
                saveInFlight = false
                record("META", "V65_PERSISTENT_SAVE_COMPLETE saveParamsActuator=7 savedVerifiedChanges=$savedCount trigger=570000000700000000 gattStatus=0 settleMs=$saveCommitSettleMs persistenceBasis=V57_TWO_POWER_CYCLE_PROOF")
                runOnUiThread { status.text = "V65 SAVED TO DSP PERMANENTLY • SaveParams ID7 verified/proven • safe to power off" }
            } else {
                saveInFlight = false
                record("META", "V65_PERSISTENT_SAVE_UNCONFIRMED reason=no-success-gatt-callback changesRemainUnsaved=true")
                runOnUiThread { status.text = "V65 SAVE UNCONFIRMED • changes remain UNSAVED • save capture" }
            }
        }.also { handler.postDelayed(it, saveCommitSettleMs) }
    }

    private fun cancelSaveSettle() {
        saveSettleRunnable?.let { handler.removeCallbacks(it) }
        saveSettleRunnable = null
    }

    private fun startScan() {
        if (saveInFlight) { Toast.makeText(this, "V65 กำลัง SAVE • ห้ามเปลี่ยน connection", Toast.LENGTH_LONG).show(); return }
        if (!hasBlePermission()) { requestBlePermissions(); return }
        val adapter = getSystemService(BluetoothManager::class.java)?.adapter ?: return
        if (!adapter.isEnabled) { Toast.makeText(this, "เปิด Bluetooth ก่อน", Toast.LENGTH_SHORT).show(); return }
        found.clear(); deviceList.removeAllViews()
        scanner = adapter.bluetoothLeScanner
        status.text = "SCANNING"
        try { scanner?.startScan(scanCallback) } catch (_: SecurityException) { return }
        handler.postDelayed({ try { scanner?.stopScan(scanCallback) } catch (_: Exception) {} }, 10000L)
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val d = result.device
            val name = result.scanRecord?.deviceName ?: try { d.name } catch (_: SecurityException) { null }
            if (name?.contains("GOLOPINE", true) != true && name?.contains("DSP", true) != true) return
            if (found.putIfAbsent(d.address, d) != null) return
            runOnUiThread {
                deviceList.addView(Button(this@LiveEqActivity).apply {
                    text = "${name ?: "DSP"} • ${d.address}\nแตะเพื่อเชื่อมต่อ"
                    setOnClickListener { connect(d, name ?: "DSP") }
                })
            }
        }
    }

    private fun connect(device: BluetoothDevice, name: String) {
        if (!hasBlePermission()) return
        try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
        try { gatt?.close() } catch (_: Exception) {}
        connectedName = name
        status.text = "CONNECTING $name"
        record("META", "V65_CONNECT_START name=$name address=${device.address}")
        try { gatt = device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE) }
        catch (_: SecurityException) { status.text = "CONNECT permission error" }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, statusCode: Int, newState: Int) {
            record("META", "GATT_STATE status=$statusCode newState=$newState")
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                runOnUiThread { status.text = "CONNECTED ${connectedName ?: "DSP"} • discovering" }
                try {
                    g.requestMtu(517)
                    handler.postDelayed({ try { g.discoverServices() } catch (_: SecurityException) {} }, 250L)
                } catch (_: SecurityException) {}
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                sessionReady = false; waitingAuth = false; txCipher = null; rxCipher = null
                cancelPendingTimeout()
                cancelSaveSettle()
                unsavedVerifiedChanges = false
                verifiedChangeCount = 0
                saveInFlight = false
                saveGattOk = false
                runOnUiThread { status.text = "DISCONNECTED • reconnect + START before editing"; startSessionButton.isEnabled = false; refreshButton.isEnabled = false; renderBands() }
            }
        }

        override fun onMtuChanged(g: BluetoothGatt, mtu: Int, statusCode: Int) { record("META", "MTU_CHANGED mtu=$mtu status=$statusCode") }

        override fun onServicesDiscovered(g: BluetoothGatt, statusCode: Int) {
            val service = g.getService(BleProfile.AB00_SERVICE)
            ab01 = service?.getCharacteristic(BleProfile.AB01_WRITE)
            ab02 = service?.getCharacteristic(BleProfile.AB02_NOTIFY)
            val ok = statusCode == BluetoothGatt.GATT_SUCCESS && ab01 != null && ab02 != null
            record("META", "SERVICES_DISCOVERED status=$statusCode AB01=${ab01 != null} AB02=${ab02 != null}")
            if (!ok) { runOnUiThread { status.text = "AB00/AB01/AB02 profile not found" }; return }
            subscribeAb02(g, ab02!!)
            runOnUiThread { status.text = "CONNECTED • enabling AB02 notifications"; startSessionButton.isEnabled = false }
        }

        override fun onDescriptorWrite(g: BluetoothGatt, descriptor: BluetoothGattDescriptor, statusCode: Int) {
            record("META", "CCCD_WRITE status=$statusCode")
            runOnUiThread {
                if (statusCode == BluetoothGatt.GATT_SUCCESS) {
                    status.text = "CONNECTED • AB02 notifications READY"
                    startSessionButton.isEnabled = true
                } else {
                    status.text = "CCCD notification enable failed: $statusCode"
                    startSessionButton.isEnabled = false
                }
            }
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, statusCode: Int) {
            record("META", "TX_WRITE_RESULT status=$statusCode uuid=${characteristic.uuid}")
            if (saveInFlight && characteristic.uuid == BleProfile.AB01_WRITE) {
                saveGattOk = statusCode == BluetoothGatt.GATT_SUCCESS
                record("META", "V65_SAVEPARAMS_GATT_RESULT status=$statusCode ok=$saveGattOk")
                if (!saveGattOk) {
                    cancelSaveSettle()
                    saveInFlight = false
                    runOnUiThread { status.text = "V65 SAVE FAILED • GATT status=$statusCode • changes remain UNSAVED" }
                }
            }
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            if (characteristic.uuid == BleProfile.AB02_NOTIFY) handleAb02(value)
        }

        @Suppress("DEPRECATION")
        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            if (android.os.Build.VERSION.SDK_INT < 33 && characteristic.uuid == BleProfile.AB02_NOTIFY) handleAb02(characteristic.value ?: byteArrayOf())
        }
    }

    private fun subscribeAb02(g: BluetoothGatt, ch: BluetoothGattCharacteristic) {
        if (!hasBlePermission()) return
        try {
            g.setCharacteristicNotification(ch, true)
            val cccd = ch.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")) ?: return
            val v = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            if (android.os.Build.VERSION.SDK_INT >= 33) g.writeDescriptor(cccd, v)
            else {
                @Suppress("DEPRECATION") cccd.value = v
                @Suppress("DEPRECATION") g.writeDescriptor(cccd)
            }
        } catch (e: Exception) { record("META", "SUBSCRIBE_ERROR ${e.javaClass.simpleName}:${e.message}") }
    }

    private fun writeNoResponse(g: BluetoothGatt, ch: BluetoothGattCharacteristic, bytes: ByteArray, label: String): Boolean {
        if (!hasBlePermission()) return false
        record("TX", "$label len=${bytes.size} hex=${ByteCodec.run { bytes.toHex() }}")
        return try {
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                g.writeCharacteristic(ch, bytes, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE) == BluetoothStatusCodes.SUCCESS
            } else {
                @Suppress("DEPRECATION") ch.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                @Suppress("DEPRECATION") ch.value = bytes
                @Suppress("DEPRECATION") g.writeCharacteristic(ch)
            }
        } catch (e: Exception) {
            record("META", "$label ERROR ${e.javaClass.simpleName}:${e.message}")
            false
        }
    }

    private fun record(kind: String, text: String) {
        val line = "${ts.format(Date())}\t#${++packetNo}\t$kind\t$text"
        synchronized(captureLines) { captureLines.add(line) }
        runOnUiThread { logView.text = (logView.text.toString() + line + "\n").takeLast(16000) }
    }

    private fun saveCapture() {
        val text = buildString {
            append("=== OKN DSP V65 LIVE EQ 7CH + PERMANENT SAVE CAPTURE ===\n")
            synchronized(captureLines) { captureLines.forEach { append(it).append('\n') } }
        }
        val name = "OKN_DSP_V65_CAPTURE_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.txt"
        try {
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: error("insert failed")
                contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) }
                Toast.makeText(this, "Saved Downloads/$name", Toast.LENGTH_LONG).show()
            } else {
                val f = java.io.File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), name)
                f.writeText(text)
                Toast.makeText(this, "Saved ${f.absolutePath}", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) { Toast.makeText(this, "Save failed: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun requestBlePermissions() {
        val perms = if (android.os.Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (perms.any { ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }) {
            ActivityCompat.requestPermissions(this, perms, 1051)
        }
    }

    private fun hasBlePermission(): Boolean = if (android.os.Build.VERSION.SDK_INT >= 31) {
        ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
    } else ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun fmt(v: Float): String = String.format(Locale.US, "%.3f", v)
}
