package com.okn.dsp

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.ContentValues
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import com.okn.dsp.protocol.*
import com.okn.dsp.transport.BleProfile
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * V65 unified single-session integration proof.
 *
 * One BLE connection/auth/RandKey/device-description session loads, in one pass:
 * - seven verified scalar controls (IDs 2,3,8,9,10,13,11),
 * - all 7 x 15 EQ bands (IDs 4,5,6,14,15,16,17), and
 * - the four known read-only sensors from the same live Device Description.
 *
 * This activity is intentionally READ ONLY. It exists to prove that Global + EQ + sensor
 * data can share one authenticated session before production write actions are migrated
 * onto the shared session. Existing V65 production Global and Live EQ screens retain the
 * already-proved write -> readback verify -> rollback -> explicit SaveParams behavior.
 */
class UnifiedControlActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private val ts = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    private val startupProbe16 = ByteCodec.hexToBytes("631C062443FD3844558001F3EDA0CCF8")

    private lateinit var status: TextView
    private lateinit var deviceList: LinearLayout
    private lateinit var startSessionButton: Button
    private lateinit var refreshButton: Button
    private lateinit var scalarHost: LinearLayout
    private lateinit var sensorHost: LinearLayout
    private lateinit var channelSpinner: Spinner
    private lateinit var eqHost: LinearLayout
    private lateinit var logView: TextView

    private var scanner: android.bluetooth.le.BluetoothLeScanner? = null
    private val found = LinkedHashMap<String, BluetoothDevice>()
    private var gatt: BluetoothGatt? = null
    private var ab01: BluetoothGattCharacteristic? = null
    private var ab02: BluetoothGattCharacteristic? = null
    private var connectedName: String? = null

    private var waitingAuth = false
    private var sessionReady = false
    private var txCipher: SessionTxCipher? = null
    private var rxCipher: SessionRxCipher? = null

    private enum class DescMode { INITIAL, REFRESH }
    private var descMode: DescMode? = null
    private var descExpected = -1
    private val descBytes = ByteArrayOutputStream()

    private val scalarValues = LinkedHashMap<Int, Float>()
    private val bands = Array(7) { arrayOfNulls<EqBand48>(15) }
    private val sensors = mutableListOf<SensorSnapshot>()
    private var selectedChannel = 1

    private data class SensorSnapshot(val id: Int, val name: String, val valueText: String)

    private val captureLines = mutableListOf<String>()
    private var packetNo = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestBlePermissions()
        record("META", "V65_UNIFIED_ACTIVITY_START")
        record("META", "V65_UNIFIED_POLICY readOnly=true genericWrites=false saveParams=false scalarIds=2,3,8,9,10,13,11 eqIds=4,5,6,14,15,16,17 expectedScalars=7 expectedEqBands=105 expectedSensors=4")
        record("META", "V65_UNIFIED_RUNTIME_EVIDENCE scalarProduction=V64 eqProduction=V62/V64 saveParamsPersistence=V57")
    }

    override fun onDestroy() {
        try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
        try { gatt?.close() } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 22, 22, 28)
        }
        root.addView(TextView(this).apply {
            text = "OKN DSP V65 — UNIFIED SINGLE-SESSION DASHBOARD"
            textSize = 22f
        })
        status = TextView(this).apply {
            text = "DISCONNECTED • one BLE session • READ ONLY integration proof"
            textSize = 14f
            setPadding(0, 8, 0, 10)
        }
        root.addView(status)
        root.addView(TextView(this).apply {
            text = "V65 ขั้นนี้รวม Global 7 controls + EQ 7CH×15 + 4 sensors ให้อ่านผ่าน AUTH/RandKey/Device Description session เดียว. หน้านี้ READ ONLY เท่านั้น: ไม่มี WRITE 0x57 และไม่มี SaveParams. Production write/save ที่พิสูจน์แล้วจาก V64/V62 ยังอยู่ในหน้าของมันตามเดิม."
            textSize = 13f
        })

        root.addView(Button(this).apply {
            text = "SCAN DSP"
            setOnClickListener { startScan() }
        })
        deviceList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(deviceList)

        startSessionButton = Button(this).apply {
            text = "START V65 UNIFIED READ-ONLY SESSION"
            isEnabled = false
            setOnClickListener { confirmStartSession() }
        }
        root.addView(startSessionButton)

        refreshButton = Button(this).apply {
            text = "REFRESH ALL • SAME SESSION • READ ONLY"
            isEnabled = false
            setOnClickListener {
                if (sessionReady && descMode == null && !waitingAuth) requestDescriptor(DescMode.REFRESH)
                else Toast.makeText(this@UnifiedControlActivity, "V65 session busy/not ready", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(refreshButton)

        root.addView(TextView(this).apply {
            text = "GLOBAL • 7 VERIFIED SCALAR VALUES"
            textSize = 19f
            setPadding(0, 18, 0, 4)
        })
        scalarHost = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(scalarHost)

        root.addView(TextView(this).apply {
            text = "SENSORS • READ ONLY"
            textSize = 19f
            setPadding(0, 18, 0, 4)
        })
        sensorHost = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(sensorHost)

        root.addView(TextView(this).apply {
            text = "EQ • 7 CHANNELS × 15 BANDS • LIVE READ ONLY"
            textSize = 19f
            setPadding(0, 18, 0, 4)
        })
        channelSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@UnifiedControlActivity, android.R.layout.simple_spinner_dropdown_item,
                (1..7).map { "CH$it / ID${LiveEqPolicy.actuatorForChannel(it)}" })
            onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                    selectedChannel = position + 1
                    renderEq()
                }
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
            }
        }
        root.addView(channelSpinner)
        eqHost = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(eqHost)

        root.addView(Button(this).apply {
            text = "SAVE V65 UNIFIED CAPTURE TO DOWNLOADS"
            setOnClickListener { saveCapture() }
        })
        logView = TextView(this).apply { textSize = 11f; setPadding(0, 12, 0, 0) }
        root.addView(logView)

        setContentView(ScrollView(this).apply { addView(root) })
        renderAll()
    }

    private fun confirmStartSession() {
        if (gatt == null || ab01 == null || ab02 == null) {
            Toast.makeText(this, "เชื่อม DSP และรอ AB02 READY ก่อน", Toast.LENGTH_LONG).show(); return
        }
        AlertDialog.Builder(this)
            .setTitle("Start V65 unified read-only session")
            .setMessage("AUTH16 → derive RandKey → อ่าน Device Description สด 1 ชุด → โหลด Global 7 + EQ 105 bands + sensors จาก session เดียว\n\nขั้นนี้ไม่มี WRITE 0x57 และไม่มี SaveParams")
            .setNegativeButton("ยกเลิก", null)
            .setPositiveButton("START READ ONLY") { _, _ -> startSession() }
            .show()
    }

    private fun startSession() {
        val g = gatt ?: return
        val w = ab01 ?: return
        waitingAuth = true
        sessionReady = false
        txCipher = null
        rxCipher = null
        descMode = null
        descExpected = -1
        descBytes.reset()
        scalarValues.clear()
        sensors.clear()
        for (c in bands.indices) for (b in bands[c].indices) bands[c][b] = null
        refreshButton.isEnabled = false
        renderAll()
        record("META", "V65_UNIFIED_SESSION_START")
        if (!writeNoResponse(g, w, startupProbe16, "TX_AUTH16_V65_UNIFIED")) {
            waitingAuth = false
            status.text = "AUTH16 queue failed"
        } else status.text = "AUTH16 sent • waiting 32B auth response"
    }

    private fun requestDescriptor(mode: DescMode) {
        val g = gatt ?: return
        val w = ab01 ?: return
        val tx = txCipher ?: return
        if (descMode != null) return
        descMode = mode
        descExpected = -1
        descBytes.reset()
        val plain = SessionCryptoFacts.DEVICE_DESCRIPTION_REQUEST
        val enc = tx.encryptNext(plain)
        record("META", "V65_UNIFIED_DESC_REQUEST mode=$mode plain=${ByteCodec.run { plain.toHex() }} readOnly=true")
        if (!writeNoResponse(g, w, enc, "TX_DESC_V65_UNIFIED_${mode.name}")) {
            descMode = null
            status.text = "Descriptor request queue failed"
        }
    }

    private fun handleAb02(value: ByteArray) {
        record("RX_NOTIFY", "len=${value.size} hex=${ByteCodec.run { value.toHex() }}")
        if (waitingAuth) {
            if (value.size != 32) return
            try {
                val d = PreAuthRandKeyDecoder.decode(value)
                txCipher = SessionTxCipher(d.randKey)
                rxCipher = SessionRxCipher(d.randKey)
                waitingAuth = false
                record("META", "V65_UNIFIED_RANDKEY_DERIVED type=${d.typeId} ver=${d.versionId} rand=${ByteCodec.run { d.randKey.toHex() }}")
                requestDescriptor(DescMode.INITIAL)
            } catch (e: Exception) {
                waitingAuth = false
                record("META", "V65_UNIFIED_AUTH_DECODE_ERROR ${e.javaClass.simpleName}:${e.message}")
                runOnUiThread { status.text = "Auth decode failed" }
            }
            return
        }
        val rx = rxCipher ?: return
        val plain = try { rx.decryptNext(value) } catch (e: Exception) {
            record("META", "V65_UNIFIED_RX_DECRYPT_ERROR ${e.javaClass.simpleName}:${e.message}")
            sessionReady = false
            return
        }
        record("RX_PLAIN", "len=${plain.size} hex=${ByteCodec.run { plain.toHex() }}")
        if (descMode != null) collectDescriptor(plain)
    }

    private fun collectDescriptor(plain: ByteArray) {
        val mode = descMode ?: return
        if (descExpected < 0) {
            if (plain.size < 4 || (plain[0].toInt() and 0xff) != 0x86) {
                record("META", "V65_UNIFIED_DESC_NONHEADER mode=$mode marker=${plain.firstOrNull()?.toInt()?.and(0xff)} len=${plain.size}")
                return
            }
            descExpected = (plain[1].toInt() and 0xff) or
                ((plain[2].toInt() and 0xff) shl 8) or
                ((plain[3].toInt() and 0xff) shl 16)
            descBytes.reset()
            descBytes.write(plain, 4, plain.size - 4)
            record("META", "V65_UNIFIED_DESC_HEADER mode=$mode jsonLen=$descExpected")
        } else {
            if (plain.isEmpty() || (plain[0].toInt() and 0xff) != 0x82) {
                record("META", "V65_UNIFIED_DESC_NONCONT mode=$mode marker=${plain.firstOrNull()?.toInt()?.and(0xff)} len=${plain.size}")
                return
            }
            descBytes.write(plain, 1, plain.size - 1)
        }
        if (descExpected > 0 && descBytes.size() >= descExpected) {
            val bytes = descBytes.toByteArray().copyOf(descExpected)
            val obj = try { JSONObject(bytes.toString(Charsets.UTF_8)) } catch (e: Exception) {
                record("META", "V65_UNIFIED_DESC_JSON_ERROR ${e.javaClass.simpleName}:${e.message}")
                descMode = null
                descExpected = -1
                descBytes.reset()
                sessionReady = false
                return
            }
            record("META", "V65_UNIFIED_DESC_COMPLETE mode=$mode bytes=${bytes.size}")
            descMode = null
            descExpected = -1
            descBytes.reset()
            handler.post { loadUnified(mode, obj) }
        }
    }

    private fun loadUnified(mode: DescMode, obj: JSONObject) {
        scalarValues.clear()
        val acts = obj.optJSONArray("actuators")
        if (acts != null) {
            for (i in 0 until acts.length()) {
                val a = acts.optJSONObject(i) ?: continue
                val id = a.optInt("ID", -1)
                if (VerifiedScalarControls.allowed(id) && a.has("UFE_TYPE_FLOAT32")) {
                    val v = a.optDouble("UFE_TYPE_FLOAT32", Double.NaN).toFloat()
                    if (v.isFinite()) scalarValues[id] = v
                }
            }
        }

        var eqCount = 0
        var writableCount = 0
        for (ch in 1..7) {
            val actuator = LiveEqPolicy.actuatorForChannel(ch)
            for (band1 in 1..15) {
                val band = extractBand(obj, actuator, band1)
                bands[ch - 1][band1 - 1] = band
                if (band != null) {
                    eqCount++
                    if (LiveEqPolicy.isWritable(band)) writableCount++
                }
            }
        }

        sensors.clear()
        val sArr = obj.optJSONArray("sensors")
        if (sArr != null) {
            for (i in 0 until sArr.length()) {
                val s = sArr.optJSONObject(i) ?: continue
                val id = s.optInt("ID", -999)
                val name = s.optString("name", "Sensor$id")
                val valueText = when {
                    s.has("UFE_TYPE_FLOAT32") -> {
                        val v = s.optDouble("UFE_TYPE_FLOAT32", Double.NaN)
                        if (v.isFinite()) String.format(Locale.US, "%.3f", v) else "NaN"
                    }
                    s.has("UFE_TYPE_BOOLEAN_INDICATE") -> s.optBoolean("UFE_TYPE_BOOLEAN_INDICATE").toString()
                    else -> "unknown"
                }
                sensors.add(SensorSnapshot(id, name, valueText))
            }
        }

        val scalarOk = scalarValues.size == VerifiedScalarControls.controls.size
        val eqOk = eqCount == 105
        val sensorOk = sensors.size == 4
        sessionReady = scalarOk && eqOk && sensorOk
        record("META", "V65_UNIFIED_LOAD mode=$mode scalarCount=${scalarValues.size} expectedScalars=7 eqBands=$eqCount expectedEqBands=105 writablePeakingBands=$writableCount sensors=${sensors.size} expectedSensors=4 ready=$sessionReady genericWrites=false saveParamsSent=false")
        renderAll()
        refreshButton.isEnabled = sessionReady
        status.text = if (sessionReady) {
            "V65 UNIFIED READY • one session • 7 scalars + 105 EQ bands + 4 sensors • READ ONLY"
        } else {
            "V65 UNIFIED BLOCKED • scalar=${scalarValues.size}/7 EQ=$eqCount/105 sensors=${sensors.size}/4"
        }
        record("META", "V65_UNIFIED_RENDER_COMPLETE scalarRows=${scalarValues.size} eqRows=${bands[selectedChannel - 1].count { it != null }} sensorRows=${sensors.size} mainThread=${Looper.myLooper() == Looper.getMainLooper()}")
    }

    private fun renderAll() {
        renderScalars()
        renderSensors()
        renderEq()
    }

    private fun renderScalars() {
        if (!::scalarHost.isInitialized) return
        scalarHost.removeAllViews()
        if (!sessionReady && scalarValues.isEmpty()) {
            scalarHost.addView(TextView(this).apply { text = "START V65 unified session เพื่อโหลดค่าจริง"; textSize = 14f })
            return
        }
        for (c in VerifiedScalarControls.controls) {
            val v = scalarValues[c.id]
            scalarHost.addView(TextView(this).apply {
                text = "${c.name} • ID ${c.id} • ${v?.let { fmt(it) } ?: "MISSING"} ${c.unit} • READ ONLY"
                textSize = 15f
                setPadding(0, 4, 0, 4)
            })
        }
    }

    private fun renderSensors() {
        if (!::sensorHost.isInitialized) return
        sensorHost.removeAllViews()
        if (sensors.isEmpty()) {
            sensorHost.addView(TextView(this).apply { text = "ยังไม่ได้โหลด sensor จาก Device Description"; textSize = 14f })
            return
        }
        sensors.forEach { s ->
            sensorHost.addView(TextView(this).apply {
                text = "${s.name} • ID ${s.id} • ${s.valueText} • READ ONLY"
                textSize = 15f
                setPadding(0, 4, 0, 4)
            })
        }
    }

    private fun renderEq() {
        if (!::eqHost.isInitialized) return
        eqHost.removeAllViews()
        val ch = selectedChannel
        eqHost.addView(TextView(this).apply {
            text = "CH$ch • Actuator ID ${LiveEqPolicy.actuatorForChannel(ch)}"
            textSize = 17f
            setPadding(0, 8, 0, 6)
        })
        if (!sessionReady && bands[ch - 1].all { it == null }) {
            eqHost.addView(TextView(this).apply { text = "START V65 unified session เพื่อโหลด EQ จริง"; textSize = 14f })
            return
        }
        for (band1 in 1..15) {
            val b = bands[ch - 1][band1 - 1]
            eqHost.addView(TextView(this).apply {
                text = if (b == null) {
                    "Band $band1 • MISSING"
                } else {
                    val safe = if (LiveEqPolicy.isWritable(b)) "SAFE-PEAKING" else "READ-ONLY-SHAPE"
                    "Band $band1 • typ=${b.type} • F=${fmt(b.frequency)}Hz • Q=${fmt(b.q)} • B=${fmt(b.boostDb)}dB • $safe • V65 dashboard READ ONLY"
                }
                textSize = 13f
                setPadding(0, 3, 0, 3)
            })
        }
    }

    private fun extractBand(obj: JSONObject, actuatorId: Int, bandIndex1: Int): EqBand48? {
        val arr = obj.optJSONArray("actuators") ?: return null
        for (i in 0 until arr.length()) {
            val a = arr.optJSONObject(i) ?: continue
            if (a.optInt("ID", -1) != actuatorId || a.optInt("type", -1) != 4084) continue
            val bandArr = a.optJSONArray("UFE_TYPE_BIQUAD_CASCADE15_F") ?: return null
            val b = bandArr.optJSONObject(bandIndex1 - 1) ?: return null
            fun f(key: String): Float = b.optDouble(key, Double.NaN).toFloat()
            val out = EqBand48(
                type = b.optInt("typ", -1),
                frequency = f("F"), frequency2 = f("F2"), q = f("Q"), boostDb = f("B"),
                gain = f("G"), r = f("R"), b0 = f("B0"), b1 = f("B1"), b2 = f("B2"),
                a1 = f("A1"), a2 = f("A2")
            )
            if (listOf(out.frequency, out.frequency2, out.q, out.boostDb, out.gain, out.r, out.b0, out.b1, out.b2, out.a1, out.a2).any { !it.isFinite() }) return null
            return out
        }
        return null
    }

    private fun startScan() {
        if (!hasBlePermission()) { requestBlePermissions(); return }
        val adapter = getSystemService(BluetoothManager::class.java)?.adapter ?: return
        if (!adapter.isEnabled) { Toast.makeText(this, "เปิด Bluetooth ก่อน", Toast.LENGTH_SHORT).show(); return }
        found.clear(); deviceList.removeAllViews()
        scanner = adapter.bluetoothLeScanner
        status.text = "SCANNING"
        try { scanner?.startScan(scanCallback) } catch (_: SecurityException) { return }
        handler.postDelayed({ try { scanner?.stopScan(scanCallback) } catch (_: Exception) {} }, 10000L)
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val d = result.device
            val name = result.scanRecord?.deviceName ?: try { d.name } catch (_: SecurityException) { null }
            if (name?.contains("GOLOPINE", true) != true && name?.contains("DSP", true) != true) return
            if (found.putIfAbsent(d.address, d) != null) return
            runOnUiThread {
                deviceList.addView(Button(this@UnifiedControlActivity).apply {
                    text = "${name ?: "DSP"} • ${d.address}\nแตะเพื่อเชื่อมต่อ"
                    setOnClickListener { connect(d, name ?: "DSP") }
                })
            }
        }
    }

    private fun connect(device: BluetoothDevice, name: String) {
        if (!hasBlePermission()) return
        try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
        try { gatt?.close() } catch (_: Exception) {}
        connectedName = name
        status.text = "CONNECTING $name"
        record("META", "V65_UNIFIED_CONNECT_START name=$name address=${device.address}")
        try { gatt = device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE) }
        catch (_: SecurityException) { status.text = "CONNECT permission error" }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, statusCode: Int, newState: Int) {
            record("META", "GATT_STATE status=$statusCode newState=$newState")
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                runOnUiThread { status.text = "CONNECTED ${connectedName ?: "DSP"} • discovering" }
                try {
                    g.requestMtu(517)
                    handler.postDelayed({ try { g.discoverServices() } catch (_: SecurityException) {} }, 250L)
                } catch (_: SecurityException) {}
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                sessionReady = false
                waitingAuth = false
                txCipher = null
                rxCipher = null
                descMode = null
                runOnUiThread {
                    status.text = "DISCONNECTED • reconnect + START"
                    startSessionButton.isEnabled = false
                    refreshButton.isEnabled = false
                    renderAll()
                }
            }
        }

        override fun onMtuChanged(g: BluetoothGatt, mtu: Int, statusCode: Int) {
            record("META", "MTU_CHANGED mtu=$mtu status=$statusCode")
        }

        override fun onServicesDiscovered(g: BluetoothGatt, statusCode: Int) {
            val service = g.getService(BleProfile.AB00_SERVICE)
            ab01 = service?.getCharacteristic(BleProfile.AB01_WRITE)
            ab02 = service?.getCharacteristic(BleProfile.AB02_NOTIFY)
            val ok = statusCode == BluetoothGatt.GATT_SUCCESS && ab01 != null && ab02 != null
            record("META", "SERVICES_DISCOVERED status=$statusCode AB01=${ab01 != null} AB02=${ab02 != null}")
            if (!ok) { runOnUiThread { status.text = "AB00/AB01/AB02 profile not found" }; return }
            subscribeAb02(g, ab02!!)
            runOnUiThread { status.text = "CONNECTED • enabling AB02 notifications"; startSessionButton.isEnabled = false }
        }

        override fun onDescriptorWrite(g: BluetoothGatt, descriptor: BluetoothGattDescriptor, statusCode: Int) {
            record("META", "CCCD_WRITE status=$statusCode")
            runOnUiThread {
                if (statusCode == BluetoothGatt.GATT_SUCCESS) {
                    status.text = "CONNECTED • AB02 notifications READY"
                    startSessionButton.isEnabled = true
                } else {
                    status.text = "CCCD notification enable failed: $statusCode"
                    startSessionButton.isEnabled = false
                }
            }
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, statusCode: Int) {
            record("META", "TX_WRITE_RESULT status=$statusCode uuid=${characteristic.uuid}")
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            if (characteristic.uuid == BleProfile.AB02_NOTIFY) handleAb02(value)
        }

        @Suppress("DEPRECATION")
        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            if (android.os.Build.VERSION.SDK_INT < 33 && characteristic.uuid == BleProfile.AB02_NOTIFY) handleAb02(characteristic.value ?: byteArrayOf())
        }
    }

    private fun subscribeAb02(g: BluetoothGatt, ch: BluetoothGattCharacteristic) {
        if (!hasBlePermission()) return
        try {
            g.setCharacteristicNotification(ch, true)
            val cccd = ch.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")) ?: return
            val v = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            if (android.os.Build.VERSION.SDK_INT >= 33) g.writeDescriptor(cccd, v)
            else {
                @Suppress("DEPRECATION") cccd.value = v
                @Suppress("DEPRECATION") g.writeDescriptor(cccd)
            }
        } catch (e: Exception) {
            record("META", "V65_UNIFIED_SUBSCRIBE_ERROR ${e.javaClass.simpleName}:${e.message}")
        }
    }

    private fun writeNoResponse(g: BluetoothGatt, ch: BluetoothGattCharacteristic, bytes: ByteArray, label: String): Boolean {
        if (!hasBlePermission()) return false
        record("TX", "$label len=${bytes.size} hex=${ByteCodec.run { bytes.toHex() }}")
        return try {
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                g.writeCharacteristic(ch, bytes, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE) == BluetoothStatusCodes.SUCCESS
            } else {
                @Suppress("DEPRECATION") ch.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                @Suppress("DEPRECATION") ch.value = bytes
                @Suppress("DEPRECATION") g.writeCharacteristic(ch)
            }
        } catch (e: Exception) {
            record("META", "$label ERROR ${e.javaClass.simpleName}:${e.message}")
            false
        }
    }

    private fun record(kind: String, text: String) {
        val line = "${ts.format(Date())}\t#${++packetNo}\t$kind\t$text"
        synchronized(captureLines) { captureLines.add(line) }
        if (::logView.isInitialized) runOnUiThread { logView.text = (logView.text.toString() + line + "\n").takeLast(16000) }
    }

    private fun saveCapture() {
        val text = buildString {
            append("=== OKN DSP V65 UNIFIED SINGLE-SESSION READ-ONLY CAPTURE ===\n")
            synchronized(captureLines) { captureLines.forEach { append(it).append('\n') } }
        }
        val name = "OKN_DSP_V65_UNIFIED_CAPTURE_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.txt"
        try {
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: error("insert failed")
                contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) }
                Toast.makeText(this, "Saved Downloads/$name", Toast.LENGTH_LONG).show()
            } else {
                val f = java.io.File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), name)
                f.writeText(text)
                Toast.makeText(this, "Saved ${f.absolutePath}", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Save failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun requestBlePermissions() {
        val perms = if (android.os.Build.VERSION.SDK_INT >= 31) {
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        } else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (perms.any { ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }) {
            ActivityCompat.requestPermissions(this, perms, 1065)
        }
    }

    private fun hasBlePermission(): Boolean = if (android.os.Build.VERSION.SDK_INT >= 31) {
        ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
    } else ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun fmt(v: Float): String = String.format(Locale.US, "%.3f", v)
}
