// V30 bluetooth manager
