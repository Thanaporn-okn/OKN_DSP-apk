// V30 BP1048P4 DSP command builder
