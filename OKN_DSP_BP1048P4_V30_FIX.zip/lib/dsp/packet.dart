// V30 packet format
