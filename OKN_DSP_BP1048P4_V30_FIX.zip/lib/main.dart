import 'package:flutter/material.dart';

void main()=>runApp(const OKN());

class OKN extends StatelessWidget{
 const OKN({super.key});
 @override
 Widget build(BuildContext c){
  return MaterialApp(
   debugShowCheckedModeBanner:false,
   theme:ThemeData.dark(),
   home:const Home());
 }
}

class Home extends StatelessWidget{
 const Home({super.key});
 @override
 Widget build(BuildContext c){
  return Scaffold(
   appBar:AppBar(title:const Text('OKN_DSP BP1048P4 V30')),
   backgroundColor:const Color(0xff101018),
   body:ListView(
    padding:const EdgeInsets.all(20),
    children:const [
     Text('DSP Mixer Controller',
     style:TextStyle(color:Colors.cyan,fontSize:28)),
     SizedBox(height:20),
     Text(
     'CH1-CH7 Select\n'
     'Volume Control\n'
     '15 Band EQ\n'
     'Delay ms\n'
     'HPF / LPF Crossover\n'
     'DSP Command Builder\n'
     'Bluetooth TX RX Ready',
     style:TextStyle(fontSize:18))
    ],
   ),
  );
 }
}
