# OKN BP1048P4 R23

R23 ทดสอบเฉพาะสมมติฐาน `AppResourceUsbDevice` จาก SDK ที่ผู้ใช้อัปโหลด: ให้บอร์ดบูตก่อน แล้วค่อยเสียบ USB-C หลังแอปเปิด เพื่อบังคับให้เกิด fresh USB attach event ก่อนลอง handoff `0x55` เพียงครั้งเดียว.

อ่าน `docs/R23_LATE_ATTACH_RESOURCE_GATE_TH.md` ก่อนทดสอบ.

ห้ามใช้ R23 เป็นตัว Flash: รุ่นนี้ไม่มี MVA/erase/program/commit.
