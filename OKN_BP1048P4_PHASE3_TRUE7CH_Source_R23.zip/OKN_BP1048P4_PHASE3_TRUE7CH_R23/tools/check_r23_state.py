#!/usr/bin/env python3
import json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
d=json.loads((root/'config/R23_LATE_ATTACH_RESOURCE_GATE_STATE.json').read_text())
assert d['release']=='R23'
assert d['requires_fresh_attach_after_app_launch'] is True
assert d['minimum_attach_settle_ms'] >= 5000
assert d['precondition_board_boot_before_usb_attach_ms'] >= 10000
assert d['one_shot_feature_set_report_hex']=='55 DE AD BE EF 00 00 00'
assert d['feature_get_report_trigger'] is True
assert d['post_ack_mode']=='passive_enumeration_only'
for x in ['AA','MVA transfer','erase','program','commit','flash payload','bulkTransfer','claimInterface','endpoint OUT']:
    assert x in d['forbidden']
print('R23 state policy: PASS')
