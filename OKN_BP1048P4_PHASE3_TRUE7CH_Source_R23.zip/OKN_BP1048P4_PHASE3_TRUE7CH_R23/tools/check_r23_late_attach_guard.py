#!/usr/bin/env python3
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'android-usb-probe/app/src/main/java/com/okn/dsp/usbprobe/MainActivity.java'
s=p.read_text()
need=[
 'lastNormalAttachElapsed',
 'R23 LATE-ATTACH TOKEN: ARMED',
 'lastNormalAttachElapsed <= activityStartedElapsed',
 'age < 5000',
 '55 DE AD BE EF 00 00 00',
 'R23 POST55 DONE',
]
for x in need:
    assert x in s, x
for x in ['bulkTransfer(', 'claimInterface(']:
    assert x not in s, x
# Exactly one state-changing Feature SET_REPORT call remains in R23 Java.
needle='controlTransfer(0x21,0x09,0x0300,4,req,req.length,1200)'
assert s.count(needle)==1, s.count(needle)
print('R23 late-attach guard PASS')
