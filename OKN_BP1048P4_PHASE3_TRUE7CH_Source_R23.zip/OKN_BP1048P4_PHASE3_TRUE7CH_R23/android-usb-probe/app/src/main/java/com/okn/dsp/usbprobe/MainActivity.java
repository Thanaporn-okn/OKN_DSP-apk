package com.okn.dsp.usbprobe;

import android.app.*;
import android.os.*;
import android.content.*;
import android.hardware.usb.*;
import android.widget.*;
import java.util.*;
import java.text.SimpleDateFormat;

/**
 * R23 keeps all flash operations disabled. It tests one evidence-backed hypothesis from
 * the uploaded MVSilicon SDK: PCTool MVA handoff requires the USB-device resource to
 * have been detected/registered before start_up_grate(AppResourceUsbDevice) can jump
 * to address 0. R23 therefore requires a fresh USB ATTACH broadcast after app launch
 * (board booted first, cable connected later), waits for the resource to settle, and
 * then permits the same single 0x55 handoff request already proven to ACK. No MVA,
 * erase, program, flash payload, endpoint OUT, bulk transfer, or bootloader command.
 */
public final class MainActivity extends Activity {
    private static final String ACTION_USB_PERMISSION = "com.okn.dsp.usbprobe.USB_PERMISSION";

    // User's confirmed GoloPine/JMDSTECH normal application identity.
    private static final int TARGET_NORMAL_VID = 0x6324;
    private static final int TARGET_NORMAL_PID = 0x1719;

    // Public BP10X flash_boot.c reference fingerprint.  This is a FAMILY reference,
    // not an assumption that the user's BP1048P4 must enumerate identically.
    private static final int PUBLIC_FLASHBOOT_VID = 0x0000;
    private static final int PUBLIC_FLASHBOOT_PID = 0x2244;

    private static final byte[] TARGET_NORMAL_DEVICE = hx(
            "12 01 10 01 00 00 00 40 24 63 19 17 00 01 01 02 03 01");
    private static final byte[] TARGET_NORMAL_IF4_REPORT = hx(
            "06 00 FF 0A AA 55 A1 01 15 00 26 FF 00 75 08 96 00 01 09 01 81 02 " +
            "96 00 01 09 01 91 02 95 08 09 01 B1 02 C0");

    // Extracted from public Mv_BP10X/.../device/flash_boot.c (build 2019-06-25).
    private static final byte[] PUBLIC_FLASHBOOT_DEVICE = hx(
            "12 01 10 01 00 00 00 40 00 00 44 22 00 01 00 00 00 01");
    private static final byte[] PUBLIC_FLASHBOOT_CONFIG = hx(
            "09 02 1B 00 01 01 00 80 32 " +
            "09 04 00 00 00 03 00 00 00 " +
            "09 21 00 01 00 01 22 24 00");
    private static final byte[] PUBLIC_FLASHBOOT_REPORT = hx(
            "06 00 FF 0A 55 AA A1 01 15 00 26 FF 00 75 08 96 00 01 09 01 81 02 " +
            "96 00 01 09 01 91 02 95 01 09 01 B1 02 C0");

    private UsbManager usb;
    private TextView log;
    private UsbDevice selected;
    private volatile boolean watchStop;
    private Capture lastCapture;
    private volatile boolean boot55ProbeUsed;
    private long activityStartedElapsed;
    private volatile long lastNormalAttachElapsed = -1;

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            String a = i.getAction();
            if (ACTION_USB_PERMISSION.equals(a)) {
                UsbDevice d = i.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                if (!i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false) || d == null) {
                    add("USB permission denied");
                    return;
                }
                selected = d;
                add("USB permission granted: " + sig(d));
                inspectReadOnly(d);
                return;
            }
            if (UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(a)) {
                UsbDevice d = i.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                add("USB ATTACHED: " + (d == null ? "<unknown>" : sig(d) + " class=" + shallowClass(d)));
                if (d != null && d.getVendorId()==TARGET_NORMAL_VID && d.getProductId()==TARGET_NORMAL_PID) {
                    lastNormalAttachElapsed = SystemClock.elapsedRealtime();
                    add("R23 LATE-ATTACH TOKEN: ARMED at elapsed=" + lastNormalAttachElapsed + " ms. Wait at least 5 seconds before button 7.");
                }
                return;
            }
            if (UsbManager.ACTION_USB_DEVICE_DETACHED.equals(a)) {
                UsbDevice d = i.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                add("USB DETACHED: " + (d == null ? "<unknown>" : sig(d)));
                if (selected != null && d != null && selected.getDeviceId() == d.getDeviceId()) selected = null;
            }
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        activityStartedElapsed = SystemClock.elapsedRealtime();
        usb = (UsbManager)getSystemService(USB_SERVICE);
        buildUi();
        IntentFilter f = new IntentFilter(ACTION_USB_PERMISSION);
        f.addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED);
        f.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, RECEIVER_NOT_EXPORTED);
        else registerReceiver(receiver, f);
        readExitHistory();
    }

    @Override protected void onDestroy() {
        watchStop = true;
        super.onDestroy();
        try { unregisterReceiver(receiver); } catch (Exception ignored) {}
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24,24,24,24);

        TextView title = new TextView(this);
        title.setText("OKN MVSilicon Direct USB-C Probe R23\n" +
                "S25+ ↔ GoloPine BP1048P4\n" +
                "LATE-ATTACH resource-gate test → one-shot 0x55 handoff — NO ERASE / NO PROGRAM");
        title.setTextSize(18);

        Button exits = new Button(this); exits.setText("1) READ APP EXIT HISTORY");
        Button scan = new Button(this); scan.setText("2) SCAN USB + CLASSIFY (PASSIVE)");
        Button inspect = new Button(this); inspect.setText("3) INSPECT GOLOPINE/FLASHBOOT CANDIDATE (READ-ONLY)");
        Button sole = new Button(this); sole.setText("4) INSPECT SOLE USB DEVICE (READ-ONLY)");
        Button watch = new Button(this); watch.setText("5) WATCH ENUMERATION 30s (PASSIVE)");
        Button compare = new Button(this); compare.setText("6) SHOW LATE-ATTACH READINESS / LAST FINGERPRINT");
        Button boot55 = new Button(this); boot55.setText("7) ONE-SHOT 0x55 AFTER FRESH LATE-ATTACH (NO FLASH)");
        Button copy = new Button(this); copy.setText("8) COPY WHOLE LOG");
        Button clear = new Button(this); clear.setText("CLEAR LOG");

        log = new TextView(this);
        log.setTextIsSelectable(true);
        ScrollView sv = new ScrollView(this);
        sv.addView(log);

        root.addView(title); root.addView(exits); root.addView(scan); root.addView(inspect);
        root.addView(sole); root.addView(watch); root.addView(compare); root.addView(boot55); root.addView(copy); root.addView(clear);
        root.addView(sv, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);

        exits.setOnClickListener(v -> readExitHistory());
        scan.setOnClickListener(v -> scanPassive());
        inspect.setOnClickListener(v -> selectAndInspect(true));
        sole.setOnClickListener(v -> selectAndInspect(false));
        watch.setOnClickListener(v -> watchEnumeration30s());
        compare.setOnClickListener(v -> showLastResult());
        boot55.setOnClickListener(v -> confirmBoot55Probe());
        copy.setOnClickListener(v -> copyLog());
        clear.setOnClickListener(v -> log.setText(""));
    }

    private void readExitHistory() {
        add("=== ANDROID APP EXIT HISTORY ===");
        add("Model: " + Build.MANUFACTURER + " " + Build.MODEL + " SDK=" + Build.VERSION.SDK_INT);
        if (Build.VERSION.SDK_INT < 30) { add("ApplicationExitInfo unavailable below API 30."); return; }
        try {
            ActivityManager am = (ActivityManager)getSystemService(ACTIVITY_SERVICE);
            List<ApplicationExitInfo> infos = am.getHistoricalProcessExitReasons(getPackageName(), 0, 8);
            add("Historical exits: " + infos.size());
            SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS Z", Locale.US);
            int idx = 0;
            for (ApplicationExitInfo info : infos) {
                idx++;
                add("EXIT #" + idx + ": time=" + fmt.format(new Date(info.getTimestamp())) +
                        " reason=" + info.getReason() + " status=" + info.getStatus());
                String desc = info.getDescription();
                if (desc != null && !desc.isEmpty()) add("  description=" + desc);
            }
        } catch (Throwable t) {
            add("Exit-history read failed: " + t.getClass().getSimpleName() + ": " + safe(t.getMessage()));
        }
        add("=== END EXIT HISTORY ===");
    }

    private void scanPassive() {
        add("=== R23 PASSIVE USB SCAN ===");
        Map<String,UsbDevice> devices = usb.getDeviceList();
        add("USB devices: " + devices.size());
        selected = null;
        for (UsbDevice d : devices.values()) {
            addDeviceSummary(d);
            if (selected == null && isInteresting(d)) selected = d;
        }
        if (selected != null) add("Selected candidate: " + sig(selected) + " class=" + shallowClass(selected));
        else add("No exact GoloPine/public-flashboot candidate. If exactly one USB device is attached, button 4 can inspect it read-only.");
        add("PASSIVE means Android enumeration only; no UsbDeviceConnection opened.");
        add("=== END R23 PASSIVE USB SCAN ===");
    }

    private void selectAndInspect(boolean interestingOnly) {
        Map<String,UsbDevice> devices = usb.getDeviceList();
        UsbDevice d = null;
        if (interestingOnly) {
            for (UsbDevice x : devices.values()) if (isInteresting(x)) { d = x; break; }
            if (d == null) {
                add("No exact 6324:1719 or public 0000:2244 candidate found. Run button 2 first; use button 4 only if the board is the sole attached USB device.");
                return;
            }
        } else {
            if (devices.size() != 1) {
                add("BLOCKED: button 4 requires exactly one attached USB device; found " + devices.size() + ".");
                return;
            }
            d = devices.values().iterator().next();
        }
        selected = d;
        if (usb.hasPermission(d)) inspectReadOnly(d); else requestPermission(d);
    }

    private void requestPermission(UsbDevice d) {
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0);
        PendingIntent pi = PendingIntent.getBroadcast(this, 0,
                new Intent(ACTION_USB_PERMISSION).setPackage(getPackageName()), flags);
        add("Requesting Android USB permission for " + sig(d));
        usb.requestPermission(d, pi);
    }

    private boolean isInteresting(UsbDevice d) {
        if (d == null) return false;
        return (d.getVendorId()==TARGET_NORMAL_VID && d.getProductId()==TARGET_NORMAL_PID) ||
                (d.getVendorId()==PUBLIC_FLASHBOOT_VID && d.getProductId()==PUBLIC_FLASHBOOT_PID);
    }

    private String shallowClass(UsbDevice d) {
        if (d.getVendorId()==TARGET_NORMAL_VID && d.getProductId()==TARGET_NORMAL_PID)
            return "KNOWN GOLOPINE NORMAL-APP VID:PID";
        if (d.getVendorId()==PUBLIC_FLASHBOOT_VID && d.getProductId()==PUBLIC_FLASHBOOT_PID)
            return "PUBLIC BP10X FLASHBOOT REFERENCE VID:PID";
        if (d.getInterfaceCount()==1 && d.getInterface(0).getInterfaceClass()==UsbConstants.USB_CLASS_HID)
            return "UNKNOWN SINGLE-HID / FLASHBOOT-LIKE CANDIDATE";
        return "UNKNOWN/NON-TARGET";
    }

    private void addDeviceSummary(UsbDevice d) {
        add(sig(d) + " shallow=" + shallowClass(d));
        add("  devClass=" + d.getDeviceClass() + " sub=" + d.getDeviceSubclass() + " proto=" + d.getDeviceProtocol());
        for (int i=0; i<d.getInterfaceCount(); i++) {
            UsbInterface x = d.getInterface(i);
            add("  IDX" + i + " IF" + x.getId() + " alt=" + x.getAlternateSetting() +
                    " class=" + x.getInterfaceClass() + " sub=" + x.getInterfaceSubclass() +
                    " proto=" + x.getInterfaceProtocol() + " ep=" + x.getEndpointCount() +
                    " name=" + safe(x.getName()));
            for (int e=0; e<x.getEndpointCount(); e++) {
                UsbEndpoint ep = x.getEndpoint(e);
                add("    EP addr=0x" + String.format(Locale.US,"%02X",ep.getAddress()) +
                        " dir=" + (ep.getDirection()==UsbConstants.USB_DIR_IN?"IN":"OUT") +
                        " type=" + ep.getType() + " max=" + ep.getMaxPacketSize() +
                        " interval=" + ep.getInterval());
            }
        }
    }

    private void inspectReadOnly(UsbDevice d) {
        new Thread(() -> {
            ui("=== R23 DIRECT USB-C READ-ONLY INSPECTION ===");
            ui("Target: " + sig(d));
            ui("Shallow class: " + shallowClass(d));
            UsbDeviceConnection c = usb.openDevice(d);
            if (c == null) { ui("openDevice: FAILED"); return; }
            try {
                Capture cap = new Capture();
                cap.androidSig = sig(d);
                cap.vid = d.getVendorId(); cap.pid = d.getProductId(); cap.interfaces = d.getInterfaceCount();
                ui("openDevice: OK");
                ui("Android strings: manufacturer=" + safe(d.getManufacturerName()) +
                        " product=" + safe(d.getProductName()) + " serial=" + safe(d.getSerialNumber()) +
                        " version=" + safe(d.getVersion()));

                byte[] dd = new byte[18];
                int dn = c.controlTransfer(0x80, 0x06, 0x0100, 0, dd, dd.length, 1500);
                ui("GET_DESCRIPTOR DEVICE => " + dn + " bytes");
                if (dn > 0) {
                    cap.device = Arrays.copyOf(dd,dn);
                    ui("  DEVICE: " + hex(dd,dn));
                    decodeDeviceDescriptor(dd,dn);
                }

                int lang = readLanguageId(c);
                if (dn >= 18) {
                    int iMan=dd[14]&0xFF, iProd=dd[15]&0xFF, iSer=dd[16]&0xFF;
                    ui(String.format(Locale.US,"String indices: manufacturer=%d product=%d serial=%d lang=0x%04X",iMan,iProd,iSer,lang));
                    if (iMan != 0) ui("  RAW manufacturer: " + readUsbString(c,iMan,lang));
                    if (iProd != 0) ui("  RAW product: " + readUsbString(c,iProd,lang));
                    if (iSer != 0) ui("  RAW serial: " + readUsbString(c,iSer,lang));
                }

                byte[] cfg9 = new byte[9];
                int c9 = c.controlTransfer(0x80,0x06,0x0200,0,cfg9,cfg9.length,1500);
                ui("GET_DESCRIPTOR CONFIG header => " + c9 + " bytes" + (c9>0?"\n  "+hex(cfg9,c9):""));
                if (c9 >= 4) {
                    int total=(cfg9[2]&0xFF)|((cfg9[3]&0xFF)<<8);
                    int capLen=Math.max(9,Math.min(total,4096));
                    byte[] cfg=new byte[capLen];
                    int cn=c.controlTransfer(0x80,0x06,0x0200,0,cfg,cfg.length,1500);
                    ui("GET_DESCRIPTOR CONFIG full requested=" + capLen + " => " + cn + " bytes");
                    if (cn > 0) {
                        cap.config=Arrays.copyOf(cfg,cn);
                        ui("  CONFIG: " + hex(cfg,cn));
                    }
                }

                for (int i=0; i<d.getInterfaceCount(); i++) {
                    UsbInterface x=d.getInterface(i);
                    if (x.getInterfaceClass()==UsbConstants.USB_CLASS_HID) {
                        byte[] rd=new byte[512];
                        int rn=c.controlTransfer(0x81,0x06,0x2200,x.getId(),rd,rd.length,1500);
                        ui("IF"+x.getId()+" HID GET_DESCRIPTOR REPORT => "+rn+" bytes" + (rn>0?"\n  REPORT: "+hex(rd,rn):""));
                        if (rn > 0) cap.hidReports.put(x.getId(),Arrays.copyOf(rd,rn));
                    }
                }

                cap.result = classifyDeep(cap);
                lastCapture = cap;
                ui("R23 FINGERPRINT RESULT: " + cap.result);
                ui("R23 SAFETY RESULT: descriptor-only inspection complete.");
                ui("NO AA, NO Feature SET_REPORT, NO endpoint OUT, NO claimInterface, NO bulkTransfer, NO flash command, NO erase/program.");
            } catch (Throwable t) {
                ui("R23 inspection exception: " + t.getClass().getSimpleName() + ": " + safe(t.getMessage()));
            } finally {
                c.close();
                ui("=== END R23 READ-ONLY INSPECTION ===");
            }
        }, "okn-r23-direct-usb-readonly").start();
    }

    private String classifyDeep(Capture c) {
        boolean normalDev = eq(c.device,TARGET_NORMAL_DEVICE);
        boolean normalReport = false;
        for (byte[] r : c.hidReports.values()) if (eq(r,TARGET_NORMAL_IF4_REPORT)) normalReport = true;
        if (c.vid==TARGET_NORMAL_VID && c.pid==TARGET_NORMAL_PID && normalDev && normalReport)
            return "EXACT-KNOWN-NORMAL-APP (6324:1719 + known HID report)";

        boolean bootDev = eq(c.device,PUBLIC_FLASHBOOT_DEVICE);
        boolean bootCfg = eq(c.config,PUBLIC_FLASHBOOT_CONFIG);
        boolean bootReport = false;
        for (byte[] r : c.hidReports.values()) if (eq(r,PUBLIC_FLASHBOOT_REPORT)) bootReport = true;
        if (bootDev && bootCfg && bootReport)
            return "EXACT-PUBLIC-BP10X-FLASHBOOT-REFERENCE (0000:2244 / one HID / control-only)";
        if (bootReport)
            return "FLASHBOOT-REPORT-FINGERPRINT-MATCH (VID/PID/config differs from public reference)";
        if (c.interfaces==1 && !c.hidReports.isEmpty())
            return "SINGLE-HID-UNKNOWN — preserve log for comparison; do not send commands";
        if (c.vid==TARGET_NORMAL_VID && c.pid==TARGET_NORMAL_PID)
            return "GOLOPINE-NORMAL-ID-BUT-DESCRIPTORS-DIFFER — preserve log";
        return "UNKNOWN/NON-MATCH";
    }


    private void confirmBoot55Probe() {
        if (boot55ProbeUsed) {
            add("BLOCKED: R23 0x55 probe is one-shot per app launch. Power-cycle the board before any later experiment.");
            return;
        }
        long now = SystemClock.elapsedRealtime();
        if (lastNormalAttachElapsed <= activityStartedElapsed) {
            add("BLOCKED: no fresh 6324:1719 USB ATTACH was observed after R23 launched. Required sequence: disconnect USB-C, boot/power the DSP normally, wait 10 seconds, then connect USB-C to S25+ while R23 is open.");
            return;
        }
        long age = now - lastNormalAttachElapsed;
        if (age < 5000) {
            add("BLOCKED: fresh attach is only " + age + " ms old. Wait " + (5000-age) + " ms or more so AppResourceUsbDevice can settle, then press button 7 once.");
            return;
        }
        UsbDevice d = null;
        for (UsbDevice x : usb.getDeviceList().values()) {
            if (x.getVendorId()==TARGET_NORMAL_VID && x.getProductId()==TARGET_NORMAL_PID) { d=x; break; }
        }
        if (d == null) {
            add("BLOCKED: exact normal device 6324:1719 is not attached.");
            return;
        }
        if (!usb.hasPermission(d)) {
            add("BLOCKED: grant USB permission first with button 3. R23 will not auto-run the state-changing probe after permission.");
            requestPermission(d);
            return;
        }
        final UsbDevice target=d;
        new AlertDialog.Builder(this)
                .setTitle("R23 late-attach resource-gate one-shot")
                .setMessage("Uploaded MVSilicon SDK says PCTool MVA upgrade requires USB-device detection and start_up_grate() only jumps when AppResourceUsbDevice is registered. R23 saw a fresh attach after app launch and waited at least 5 seconds. It will send exactly one Feature SET_REPORT 55 DE AD BE EF, then one Feature GET_REPORT. After ACK it closes the normal-app connection and watches USB enumeration only. NO MVA, NO erase, NO program, NO flash data. Run once?")
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("RUN ONCE", (dlg,which) -> executeBoot55Probe(target))
                .show();
    }

    private void executeBoot55Probe(UsbDevice d) {
        if (boot55ProbeUsed) { add("BLOCKED: one-shot already consumed."); return; }
        boot55ProbeUsed = true;
        new Thread(() -> {
            ui("=== R23 LATE-ATTACH ONE-SHOT 0x55 RESOURCE-GATE PROBE ===");
            ui("Target: " + sig(d));
            ui("SAFETY: exactly one Feature SET_REPORT is permitted; no endpoint OUT / no flash payload / no erase / no program.");
            UsbDeviceConnection c = usb.openDevice(d);
            if (c == null) { ui("openDevice: FAILED"); return; }
            try {
                if (d.getVendorId()!=TARGET_NORMAL_VID || d.getProductId()!=TARGET_NORMAL_PID || d.getInterfaceCount()!=7) {
                    ui("GATE FAIL: target identity/interface count is not exact known normal app.");
                    return;
                }
                byte[] dd=new byte[18];
                int dn=c.controlTransfer(0x80,0x06,0x0100,0,dd,dd.length,1200);
                ui("Gate DEVICE => "+dn+" bytes: "+(dn>0?hex(dd,dn):"<none>"));
                if (dn!=18 || !eq(dd,TARGET_NORMAL_DEVICE)) {
                    ui("GATE FAIL: raw device descriptor differs from exact known normal app.");
                    return;
                }
                UsbInterface x4=null;
                for(int i=0;i<d.getInterfaceCount();i++) {
                    UsbInterface x=d.getInterface(i);
                    if(x.getId()==4 && x.getInterfaceClass()==UsbConstants.USB_CLASS_HID) { x4=x; break; }
                }
                if(x4==null) { ui("GATE FAIL: IF4 HID not found."); return; }
                byte[] rd=new byte[128];
                int rn=c.controlTransfer(0x81,0x06,0x2200,4,rd,rd.length,1200);
                ui("Gate IF4 REPORT => "+rn+" bytes: "+(rn>0?hex(rd,rn):"<none>"));
                if(rn!=TARGET_NORMAL_IF4_REPORT.length || !eq(Arrays.copyOf(rd,rn),TARGET_NORMAL_IF4_REPORT)) {
                    ui("GATE FAIL: IF4 report descriptor differs from exact known normal app.");
                    return;
                }
                byte[] before=new byte[8];
                int bn=c.controlTransfer(0xA1,0x01,0x0300,4,before,before.length,1200);
                ui("Feature baseline => "+bn+" bytes: "+(bn>0?hex(before,bn):"<none>"));
                if(bn!=8 || (before[0]&0xFF)!=0x00) {
                    ui("GATE FAIL: clean baseline first byte is not 00. Power-cycle board and inspect again; no SET_REPORT sent.");
                    return;
                }

                ui("GATE PASS. Waiting 3000 ms so the normal USB-device resource has time to settle.");
                SystemClock.sleep(3000);
                byte[] req=hx("55 DE AD BE EF 00 00 00");
                ui("TX Feature SET_REPORT: 55 DE AD BE EF 00 00 00");
                int wn=c.controlTransfer(0x21,0x09,0x0300,4,req,req.length,1200);
                ui("SET_REPORT FEATURE => "+wn+" bytes");
                if(wn!=8) {
                    ui("STOP: SET_REPORT was not accepted as 8 bytes. No GET trigger is sent.");
                    return;
                }
                SystemClock.sleep(80);
                byte[] after=new byte[8];
                int an=c.controlTransfer(0xA1,0x01,0x0300,4,after,after.length,1200);
                ui("GET_REPORT FEATURE trigger => "+an+" bytes: "+(an>0?hex(after,an):"<none>"));
                if(an==8 && (after[0]&0xFF)==0x55) {
                    ui("ARM ACK observed: Feature first byte became 55. Closing normal-app connection immediately; from here R23 is PASSIVE only.");
                } else {
                    ui("No 55 arm ACK observed. Stop; do not retry in this app launch.");
                }
            } catch(Throwable t) {
                ui("R23 0x55 probe exception: "+t.getClass().getSimpleName()+": "+safe(t.getMessage()));
            } finally {
                try { c.close(); } catch(Throwable ignored) {}
            }

            ui("--- R23 post-0x55 enumeration watch 30s / 50ms poll ---");
            long end=SystemClock.elapsedRealtime()+30000;
            String prev="";
            int change=0;
            while(SystemClock.elapsedRealtime()<end) {
                String now=snapshotShallow();
                if(!now.equals(prev)) {
                    change++;
                    ui("POST55 CHANGE #"+change+" t="+SystemClock.elapsedRealtime()+"ms\n"+now);
                    prev=now;
                }
                SystemClock.sleep(50);
            }
            ui("R23 POST55 DONE. changes="+change);
            ui("NO flash payload, erase, program, commit, or MVA transfer was sent.");
            ui("If anything other than 6324:1719 appeared, use button 3/4 to inspect it read-only. If normal app remains, power-cycle once before normal use.");
            ui("=== END R23 LATE-ATTACH ONE-SHOT 0x55 PROBE ===");
        },"okn-r23-boot55-once").start();
    }

    private void rawDescriptorSnapshot(UsbDeviceConnection c, String label, long sleepMs) {
        SystemClock.sleep(sleepMs);
        ui("--- R21 RAW DESCRIPTOR SNAPSHOT " + label + " ---");
        try {
            byte[] dd = new byte[18];
            int dn = c.controlTransfer(0x80, 0x06, 0x0100, 0, dd, dd.length, 1200);
            ui("DEVICE => " + dn + " bytes: " + (dn>0?hex(dd,dn):"<none>"));

            byte[] cfg9 = new byte[9];
            int c9 = c.controlTransfer(0x80, 0x06, 0x0200, 0, cfg9, cfg9.length, 1200);
            ui("CONFIG9 => " + c9 + " bytes: " + (c9>0?hex(cfg9,c9):"<none>"));
            byte[] cfg = null;
            int cn = -1;
            if (c9 >= 4) {
                int total=(cfg9[2]&0xFF)|((cfg9[3]&0xFF)<<8);
                int capLen=Math.max(9,Math.min(total,1024));
                cfg=new byte[capLen];
                cn=c.controlTransfer(0x80,0x06,0x0200,0,cfg,cfg.length,1200);
                ui("CONFIG full => " + cn + " bytes: " + (cn>0?hex(cfg,cn):"<none>"));
            }

            if (dn==18 && eq(Arrays.copyOf(dd,dn), PUBLIC_FLASHBOOT_DEVICE))
                ui("R21 SNAPSHOT CLASS: PUBLIC FLASHBOOT DEVICE DESCRIPTOR MATCH");
            else if (dn==18 && eq(Arrays.copyOf(dd,dn), TARGET_NORMAL_DEVICE))
                ui("R21 SNAPSHOT DEVICE CLASS: EXACT NORMAL DEVICE DESCRIPTOR");
            else if (dn>0)
                ui("R21 SNAPSHOT DEVICE CLASS: CHANGED/UNKNOWN DEVICE DESCRIPTOR");
            else
                ui("R21 SNAPSHOT DEVICE CLASS: CONTROL READ FAILED / DEVICE MAY HAVE RESET");

            if (cn>0 && cfg!=null) {
                byte[] got=Arrays.copyOf(cfg,cn);
                if (eq(got, PUBLIC_FLASHBOOT_CONFIG)) ui("R21 SNAPSHOT CONFIG CLASS: PUBLIC FLASHBOOT CONFIG MATCH");
                else if (cn==250) ui("R21 SNAPSHOT CONFIG CLASS: 250-byte normal-app-sized config");
                else ui("R21 SNAPSHOT CONFIG CLASS: CHANGED/UNKNOWN CONFIG length="+cn);

                // Parse interface descriptors from the RAW config and issue only standard HID report GET_DESCRIPTOR reads.
                for (int off=0; off+1<cn;) {
                    int len=cfg[off]&0xFF;
                    int type=cfg[off+1]&0xFF;
                    if (len<2 || off+len>cn) break;
                    if (type==0x04 && len>=9) {
                        int ifNum=cfg[off+2]&0xFF;
                        int ifClass=cfg[off+5]&0xFF;
                        if (ifClass==0x03) {
                            byte[] rd=new byte[512];
                            int rn=c.controlTransfer(0x81,0x06,0x2200,ifNum,rd,rd.length,1200);
                            ui("RAW IF"+ifNum+" HID REPORT => "+rn+" bytes: "+(rn>0?hex(rd,rn):"<none>"));
                            if (rn>0 && eq(Arrays.copyOf(rd,rn), PUBLIC_FLASHBOOT_REPORT))
                                ui("R21 SNAPSHOT REPORT CLASS: PUBLIC FLASHBOOT REPORT MATCH");
                            else if (rn>0 && eq(Arrays.copyOf(rd,rn), TARGET_NORMAL_IF4_REPORT))
                                ui("R21 SNAPSHOT REPORT CLASS: EXACT NORMAL IF4 REPORT");
                        }
                    }
                    off += len;
                }
            }
        } catch(Throwable t) {
            ui("R21 snapshot " + label + " exception: " + t.getClass().getSimpleName() + ": " + safe(t.getMessage()));
        }
        ui("--- END R21 RAW DESCRIPTOR SNAPSHOT " + label + " ---");
    }

    private void watchEnumeration30s() {
        watchStop = false;
        add("=== R23 30s PASSIVE ENUMERATION WATCH ===");
        add("During this watch you may ONLY manually power-cycle the board or change its physical input/mode. R23 passive watch sends nothing to USB.");
        new Thread(() -> {
            long end=SystemClock.elapsedRealtime()+30000;
            String prev="";
            int change=0;
            while (!watchStop && SystemClock.elapsedRealtime()<end) {
                String now=snapshotShallow();
                if (!now.equals(prev)) {
                    change++;
                    ui("WATCH CHANGE #"+change+" t="+SystemClock.elapsedRealtime()+"ms\n"+now);
                    prev=now;
                }
                SystemClock.sleep(250);
            }
            ui("R23 WATCH DONE. changes="+change);
            ui("If a new VID:PID/interface shape appeared, run button 3 or 4 to capture its descriptors read-only.");
            ui("=== END R23 WATCH ===");
        },"okn-r23-passive-watch").start();
    }

    private String snapshotShallow() {
        List<UsbDevice> ds=new ArrayList<>(usb.getDeviceList().values());
        ds.sort(Comparator.comparingInt(UsbDevice::getVendorId).thenComparingInt(UsbDevice::getProductId).thenComparingInt(UsbDevice::getDeviceId));
        StringBuilder s=new StringBuilder();
        s.append("devices=").append(ds.size());
        for (UsbDevice d:ds) s.append("\n  ").append(sig(d)).append(" shallow=").append(shallowClass(d));
        return s.toString();
    }

    private void showLastResult() {
        long now=SystemClock.elapsedRealtime();
        add("=== R23 LATE-ATTACH READINESS ===");
        add("App started elapsed="+activityStartedElapsed+" ms");
        add("Last normal attach elapsed="+lastNormalAttachElapsed+" ms");
        if(lastNormalAttachElapsed>activityStartedElapsed) add("Fresh attach age="+(now-lastNormalAttachElapsed)+" ms; >=5000 required for button 7.");
        else add("Fresh late-attach token NOT ARMED.");
        Capture c=lastCapture;
        if (c==null) { add("No deep capture yet. Run button 3 or 4 first."); return; }
        add("=== LAST R23 FINGERPRINT ===");
        add("Android: " + c.androidSig);
        add("Result: " + c.result);
        add("Device: " + hex(c.device,c.device==null?0:c.device.length));
        add("Config: " + hex(c.config,c.config==null?0:c.config.length));
        for (Map.Entry<Integer,byte[]> e:c.hidReports.entrySet()) add("IF"+e.getKey()+" report: "+hex(e.getValue(),e.getValue().length));
        add("Public flashboot reference device: " + hex(PUBLIC_FLASHBOOT_DEVICE,PUBLIC_FLASHBOOT_DEVICE.length));
        add("Public flashboot reference config: " + hex(PUBLIC_FLASHBOOT_CONFIG,PUBLIC_FLASHBOOT_CONFIG.length));
        add("Public flashboot reference report: " + hex(PUBLIC_FLASHBOOT_REPORT,PUBLIC_FLASHBOOT_REPORT.length));
        add("=== END LAST R23 FINGERPRINT ===");
    }

    private int readLanguageId(UsbDeviceConnection c) {
        byte[] b=new byte[255];
        int n=c.controlTransfer(0x80,0x06,0x0300,0,b,b.length,1500);
        if (n>=4 && (b[1]&0xFF)==0x03) {
            int lang=(b[2]&0xFF)|((b[3]&0xFF)<<8);
            ui("STRING0 LANGID descriptor => "+n+" bytes: "+hex(b,n));
            return lang;
        }
        ui("STRING0 LANGID descriptor => "+n+" bytes");
        return 0x0409;
    }

    private String readUsbString(UsbDeviceConnection c,int index,int lang) {
        byte[] b=new byte[255];
        int n=c.controlTransfer(0x80,0x06,0x0300|(index&0xFF),lang,b,b.length,1500);
        if (n<2 || (b[1]&0xFF)!=0x03) return "<read failed n="+n+">";
        int end=Math.min(n,b[0]&0xFF);
        StringBuilder s=new StringBuilder();
        for(int i=2;i+1<end;i+=2) s.append((char)((b[i]&0xFF)|((b[i+1]&0xFF)<<8)));
        return s+" [raw "+hex(b,n)+"]";
    }

    private void decodeDeviceDescriptor(byte[] b,int n) {
        if (n<18) return;
        int usbBcd=(b[2]&0xFF)|((b[3]&0xFF)<<8);
        int vid=(b[8]&0xFF)|((b[9]&0xFF)<<8);
        int pid=(b[10]&0xFF)|((b[11]&0xFF)<<8);
        int devBcd=(b[12]&0xFF)|((b[13]&0xFF)<<8);
        ui(String.format(Locale.US,"  decoded: bcdUSB=%04X class=%d sub=%d proto=%d ep0Max=%d VID:PID=%04X:%04X bcdDevice=%04X configs=%d",
                usbBcd,b[4]&0xFF,b[5]&0xFF,b[6]&0xFF,b[7]&0xFF,vid,pid,devBcd,b[17]&0xFF));
    }

    private void copyLog() {
        ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("OKN direct USB-C R23 log",log.getText()));
        Toast.makeText(this,"Log copied",Toast.LENGTH_SHORT).show();
    }

    private static String sig(UsbDevice d) {
        return String.format(Locale.US,"VID:PID=%04X:%04X interfaces=%d deviceId=%d name=%s",
                d.getVendorId(),d.getProductId(),d.getInterfaceCount(),d.getDeviceId(),safe(d.getDeviceName()));
    }

    private static boolean eq(byte[] a,byte[] b) { return a!=null && b!=null && Arrays.equals(a,b); }
    private static String safe(String s) { return s==null?"<null>":s; }
    private static String hex(byte[] b,int n) {
        if (b==null || n<=0) return "<none>";
        StringBuilder s=new StringBuilder();
        for(int i=0;i<n && i<b.length;i++) { if(i>0)s.append(' '); s.append(String.format(Locale.US,"%02X",b[i]&0xFF)); }
        return s.toString();
    }
    private static byte[] hx(String s) {
        String[] p=s.trim().split("\\s+"); byte[] out=new byte[p.length];
        for(int i=0;i<p.length;i++) out[i]=(byte)Integer.parseInt(p[i],16);
        return out;
    }
    private void add(String s) { runOnUiThread(() -> log.append(s+"\n")); }
    private void ui(String s) { runOnUiThread(() -> log.append(s+"\n")); }

    private static final class Capture {
        String androidSig;
        int vid,pid,interfaces;
        byte[] device,config;
        final Map<Integer,byte[]> hidReports=new LinkedHashMap<>();
        String result="<not classified>";
    }
}
