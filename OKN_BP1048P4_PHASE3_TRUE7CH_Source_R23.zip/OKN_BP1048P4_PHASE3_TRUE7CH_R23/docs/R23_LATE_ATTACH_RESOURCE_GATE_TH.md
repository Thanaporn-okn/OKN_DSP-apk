# R23 — Late-Attach USB Resource Gate Probe

เป้าหมายของ R23 คือทดสอบสมมติฐานจาก SDK ที่ผู้ใช้อัปโหลด โดยไม่ส่งเฟิร์มแวร์หรือคำสั่ง Flash ใด ๆ

หลักฐานจาก SDK `MVsB1_BT_Audio_SDK_v0.1.11+P01+P02+P03+P04+P05+P06.zip`:

- `flash_boot.h` เป็น Flashboot V2.1.6 (2020-08-13), `FLASH_BOOT_EN=1`, `JUDGEMENT_STANDARD=0x55`, `PCTOOL_ON=0x08`.
- `app_config.h` ระบุว่า PCTool MVA upgrade ต้องเปิด USB-device mode/detection.
- `otg_device_standard_request.c` รับ Feature SET_REPORT ที่ byte 0 = `0x55`; GET_REPORT ตอบ byte แรก `0x55` และภายใต้ `FLASH_BOOT_EN` เรียก `start_up_grate(AppResourceUsbDevice)`.
- `upgrade.c` จะตั้ง PC/updata และ jump ไป address 0 เฉพาะเมื่อ `ResourceValue(AppResourceUsbDevice)` เป็นจริง.
- `device_service.c` จะ `ResourceRegister(AppResourceUsbDevice)` เมื่อ USB_DEVICE_EVENT/STATE ถูกตรวจพบ.

ดังนั้น R20/R21 ที่ ACK `0x55` แต่ไม่เข้า flashboot ยังเข้ากับกรณี resource gate ไม่พร้อมได้ โดยเฉพาะถ้าสาย USB ถูกเสียบอยู่ตั้งแต่ก่อนแอป/โหมดของบอร์ดพร้อม.

R23 จึงบังคับลำดับใหม่:

1. เปิด R23 โดยยังไม่เสียบ USB-C ระหว่าง S25+ กับบอร์ด
2. เปิดไฟบอร์ดตามปกติและรออย่างน้อย 10 วินาที
3. เสียบ USB-C เข้าหา S25+ ขณะที่ R23 เปิดอยู่ เพื่อให้ Android เห็น ATTACH ใหม่
4. R23 จะบันทึก late-attach token และบล็อกปุ่ม 7 จนผ่านอย่างน้อย 5 วินาที
5. ตรวจ read-only ด้วยปุ่ม 3 ก่อน
6. ปุ่ม 7 ส่งเพียง Feature SET_REPORT `55 DE AD BE EF 00 00 00` หนึ่งครั้ง และ Feature GET_REPORT หนึ่งครั้ง
7. หลัง ACK ปิด connection และเฝ้าดู enumeration แบบ passive 30 วินาที

R23 ไม่มี MVA transfer, endpoint OUT, bulk transfer, erase, program, commit หรือ flash payload.

หากเห็น USB identity เปลี่ยนจาก `6324:1719 / 7 interfaces` ไปเป็น single-HID หรือ descriptor ที่ตรงกับ Flashboot reference ให้หยุดและส่ง log ทั้งหมดมา ก่อนทำคำสั่ง bootloader ใด ๆ.
