# BUILD VALIDATION — Heavy Market v7

วันที่ตรวจ: 2026-09-20

## ผ่านแล้วใน environment นี้

- Domain Kotlin smoke test: classifier / PriceParser / SearchQueryParser — PASS
- DemoData Kotlin compile + runtime smoke — PASS
- Demo products: 52 รายการ — PASS
- Built-in categories: 26 หมวด และทุกหมวดมีอย่างน้อย 2 รายการ — PASS
- Demo image resource URI ทุกตัวเป็น `res://demo_*` — PASS
- XML parse ทุกไฟล์ resource/manifest — PASS
- GitHub Actions YAML parse — PASS
- Workflow ZIP selector เลือก HeavyMarket_v<number>.zip ที่เลขสูงสุด — PASS
- ZIP integrity (`unzip -t`) — PASS หลังแพ็ก

## การแก้จากวิดีโอ v6

- NavHost ตั้ง `EnterTransition.None` / `ExitTransition.None` และ pop transition เป็น None เพื่อลดภาพหน้าซ้อนขณะสลับแท็บ
- Top-level browse tabs reset transient browse state เมื่อเปลี่ยนแท็บ
- Search History debounce 700 ms และกรองคำสั้น/ซ้ำก่อนแสดง
- Demo catalog ขยายเป็น 52 รายการโดย seed แบบ idempotent

## ข้อจำกัดการตรวจ

Container นี้ไม่มี Android SDK/dependency cache ครบ จึงไม่อ้างว่า APK ถูก build สำเร็จในเครื่องนี้ การ build จริงให้ GitHub Actions รัน `./gradlew clean testDebugUnitTest assembleDebug --stacktrace` ตาม workflow
