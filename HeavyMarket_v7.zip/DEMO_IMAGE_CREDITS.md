# Demo Image Notes — Heavy Market v6

v6 does not depend on remote demo photos.

The current Demo dataset uses **26 distinct original local illustrations**, one per demo listing/category, under `app/src/main/res/drawable-nodpi/`. They are bundled in the APK so Demo Mode remains visually useful offline. The 10 earlier v5 fallback assets are retained only for backward/fallback compatibility.

These illustrations were created specifically for this project. They do not copy Facebook/Marketplace branding, seller photos, sessions, cookies, tokens, or user content.

For live/imported listings the app may still display an image URL supplied by an authorized provider. If that image fails, the UI selects the closest local category illustration instead of leaving a blank area.
