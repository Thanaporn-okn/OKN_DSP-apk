package com.okn.heavymarket.data

import com.okn.heavymarket.data.local.*
import com.okn.heavymarket.domain.ClassificationResult
import com.okn.heavymarket.domain.Deduplicator
import com.okn.heavymarket.domain.PostClassifier
import com.okn.heavymarket.domain.PostType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class HeavyMarketRepository @Inject constructor(
    private val productDao: ProductDao,
    private val favoriteDao: FavoriteDao,
    private val groupDao: GroupDao,
    private val categoryDao: CategoryDao,
    private val keywordRuleDao: KeywordRuleDao,
    private val savedSearchDao: SavedSearchDao,
    private val searchHistoryDao: SearchHistoryDao,
    private val recentlyViewedDao: RecentlyViewedDao,
    private val classifier: PostClassifier
) {
    val products = productDao.observeSales()
    val groups = groupDao.observeAll()
    val categories = categoryDao.observeEnabled()
    val keywordRules = keywordRuleDao.observeEnabled()
    val savedSearches = savedSearchDao.observeAll()
    val history = searchHistoryDao.observeRecent()

    fun favoriteProducts(): Flow<List<ProductEntity>> = combine(products, favoriteDao.observeAll()) { productList, favs ->
        val ids = favs.filter { it.type == "PRODUCT" }.map { it.targetId }.toSet()
        productList.filter { it.id in ids }
    }

    fun recentlyViewedProducts(): Flow<List<ProductEntity>> = combine(products, recentlyViewedDao.observeRecent()) { productList, recent ->
        val byId = productList.associateBy { it.id }
        recent.mapNotNull { byId[it.productId] }
    }

    fun relatedProducts(id: String): Flow<List<ProductEntity>> = combine(productDao.observeById(id), products) { item, list ->
        if (item == null) emptyList() else list
            .asSequence()
            .filter { it.id != id }
            .map { candidate ->
                val textScore = Deduplicator.similarity(item.title + " " + item.description, candidate.title + " " + candidate.description)
                val categoryBoost = if (candidate.category.equals(item.category, true)) 0.35 else 0.0
                candidate to (textScore + categoryBoost)
            }
            .sortedByDescending { it.second }
            .map { it.first }
            .take(8)
            .toList()
    }

    fun product(id: String) = productDao.observeById(id)
    fun isFavorite(id: String) = favoriteDao.observeIsFavorite("PRODUCT", id)

    suspend fun seedIfNeeded() {
        if (categoryDao.count() == 0) {
            categoryDao.insertAll(defaultCategories.map { CategoryEntity(it, builtIn = true) })
        }
        // Demo seed is idempotent so upgrading the APK refreshes local demo images/data without clearing app storage.
        productDao.upsert(DemoData.products())
    }

    suspend fun toggleFavorite(id: String, current: Boolean) = toggleFavoriteType("PRODUCT", id, current)

    suspend fun toggleFavoriteType(type: String, targetId: String, current: Boolean) {
        if (current) favoriteDao.delete(type, targetId) else favoriteDao.insert(FavoriteEntity(type, targetId))
    }

    suspend fun markViewed(id: String) {
        recentlyViewedDao.upsert(RecentlyViewedEntity(id))
    }

    suspend fun addGroup(name: String, url: String) {
        groupDao.upsert(GroupSourceEntity(UUID.randomUUID().toString(), name.ifBlank { "กลุ่มที่เพิ่มเอง" }, url.trim()))
    }

    suspend fun setGroupFavorite(id: String, favorite: Boolean) = groupDao.setFavorite(id, favorite)
    suspend fun setGroupSync(id: String, enabled: Boolean) = groupDao.setSyncEnabled(id, enabled)

    suspend fun importSharedText(text: String): Boolean {
        val trimmed = text.trim()
        if (trimmed.isBlank()) return false
        val base = classifier.classify(trimmed)
        val classification = applyKeywordRules(trimmed, base, keywordRuleDao.enabledOnce())
        val url = Regex("https?://\\S+").find(trimmed)?.value?.trimEnd('.', ',', ')') ?: "import://" + UUID.randomUUID()
        val title = trimmed.lineSequence().firstOrNull()?.take(100)?.ifBlank { "โพสต์ที่นำเข้า" } ?: "โพสต์ที่นำเข้า"
        val price = classification.detectedPrice
        val hash = Deduplicator.normalizedHash(title, trimmed, price, url)

        val existing = productDao.getAllOnce().firstOrNull { old ->
            old.normalizedHash == hash ||
                old.originalUrl.substringBefore('?') == url.substringBefore('?') ||
                (old.price == price && Deduplicator.similarity(old.title + " " + old.description, title + " " + trimmed) >= 0.86)
        }
        if (existing != null) return existing.classification == PostType.SALE.name

        val entity = ProductEntity(
            id = "import-" + hash.take(20),
            title = title,
            description = trimmed,
            price = price,
            category = inferCategory(trimmed),
            location = "ไม่ระบุ",
            province = inferProvince(trimmed),
            postedAt = System.currentTimeMillis(),
            sourceId = "imported",
            sourceName = "นำเข้าโดยผู้ใช้",
            sourceType = "IMPORTED",
            imageUrls = "",
            originalUrl = url,
            classification = classification.type.name,
            classificationScore = classification.score,
            normalizedHash = hash,
            isDemo = false
        )
        productDao.upsert(entity)
        return classification.type == PostType.SALE
    }

    private fun applyKeywordRules(text: String, base: ClassificationResult, rules: List<KeywordRuleEntity>): ClassificationResult {
        val normalized = text.lowercase()
        val includeHits = rules.filter { it.include && normalized.contains(it.keyword.lowercase()) }.sumOf { it.weight }
        val excludeHits = rules.filter { !it.include && normalized.contains(it.keyword.lowercase()) }.sumOf { it.weight }
        if (excludeHits > includeHits) {
            return base.copy(type = PostType.OTHER, score = (base.score - excludeHits * 2.0).coerceAtLeast(0.0), reasons = base.reasons + "custom-exclude")
        }
        if (includeHits > 0 && base.type == PostType.OTHER && base.detectedPrice != null) {
            return base.copy(type = PostType.SALE, score = base.score + includeHits, reasons = base.reasons + "custom-include")
        }
        return base.copy(score = base.score + includeHits * 0.5)
    }

    suspend fun addCategory(name: String) {
        val clean = name.trim()
        if (clean.isNotBlank()) categoryDao.upsert(CategoryEntity(clean))
    }

    suspend fun addKeywordRule(keyword: String, include: Boolean) {
        val clean = keyword.trim()
        if (clean.isNotBlank()) keywordRuleDao.insert(KeywordRuleEntity(keyword = clean, include = include))
    }

    suspend fun saveSearch(
        name: String,
        query: String,
        category: String? = null,
        province: String? = null,
        minPrice: Long? = null,
        maxPrice: Long? = null,
        sourceType: String? = null
    ) {
        savedSearchDao.upsert(
            SavedSearchEntity(
                name = name,
                keyword = query,
                category = category,
                province = province,
                minPrice = minPrice,
                maxPrice = maxPrice,
                sourceType = sourceType
            )
        )
    }

    suspend fun recordSearch(query: String) {
        val clean = query.trim()
        if (clean.isNotBlank()) searchHistoryDao.upsert(SearchHistoryEntity(clean))
    }

    suspend fun allProductsOnce() = productDao.getAllOnce()
    suspend fun enabledSavedSearches() = savedSearchDao.enabledOnce()
    suspend fun markSearchNotified(id: Long, timestamp: Long) = savedSearchDao.markNotified(id, timestamp)

    private fun inferCategory(text: String): String {
        val lower = text.lowercase()
        val candidates = defaultCategories.filterNot { it == "อื่นๆ" }
        return candidates.firstOrNull { lower.contains(it.lowercase()) }
            ?: when {
                lower.contains("excavator") || lower.contains("pc200") || lower.contains("cat 320") -> "รถขุด"
                lower.contains("wheel loader") -> "Wheel Loader"
                lower.contains("tractor") -> "รถแทรกเตอร์"
                else -> "อื่นๆ"
            }
    }

    private fun inferProvince(text: String): String {
        val provinces = listOf("ขอนแก่น", "นครราชสีมา", "อุดรธานี", "อุบลราชธานี", "เชียงใหม่", "เชียงราย", "พิษณุโลก", "กรุงเทพ", "ชลบุรี", "ระยอง", "สระบุรี", "สุราษฎร์ธานี", "สงขลา")
        return provinces.firstOrNull { text.contains(it, true) } ?: "ไม่ระบุ"
    }

    companion object {
        val defaultCategories = listOf(
            "รถบรรทุก", "รถหกล้อ", "รถสิบล้อ", "รถสิบสองล้อ", "รถพ่วง", "รถเทรลเลอร์",
            "รถดั้ม", "รถขุด", "รถแม็คโคร", "Backhoe", "รถตัก", "Wheel Loader", "รถไถ",
            "รถแทรกเตอร์", "รถเครน", "รถโม่ปูน", "รถเกี่ยว", "รถโฟล์คลิฟท์", "รถกระบะ",
            "รถมือสอง", "เครื่องจักรก่อสร้าง", "เครื่องจักรการเกษตร", "อะไหล่รถ", "อะไหล่เครื่องจักร", "อุปกรณ์มือสอง", "อื่นๆ"
        )
    }
}
