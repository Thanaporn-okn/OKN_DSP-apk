package com.okn.heavymarket.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.okn.heavymarket.data.HeavyMarketRepository
import com.okn.heavymarket.data.SettingsRepository
import com.okn.heavymarket.data.local.ProductEntity
import com.okn.heavymarket.domain.SearchQueryParser
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor(
    private val repository: HeavyMarketRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {
    val query = MutableStateFlow("")
    val category = MutableStateFlow<String?>(null)
    val province = MutableStateFlow("")
    val minPrice = MutableStateFlow<Long?>(null)
    val maxPrice = MutableStateFlow<Long?>(null)
    val sourceType = MutableStateFlow<String?>(null)
    val sort = MutableStateFlow(Sort.NEWEST)
    val visibleCount = MutableStateFlow(20)
    val refreshing = MutableStateFlow(false)
    private var searchRecordJob: Job? = null

    val categories = repository.categories.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val groups = repository.groups.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val keywordRules = repository.keywordRules.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val savedSearches = repository.savedSearches.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val history = repository.history.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val darkMode = settingsRepository.darkMode.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)
    val notificationsEnabled = settingsRepository.notificationsEnabled.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), true)

    private data class FilterState(
        val query: String,
        val category: String?,
        val province: String,
        val minPrice: Long?,
        val maxPrice: Long?,
        val sourceType: String? = null
    )

    private val filterState = combine(query, category, province, minPrice, maxPrice) { q, cat, prov, min, max ->
        FilterState(q, cat, prov, min, max)
    }.combine(sourceType) { state, source -> state.copy(sourceType = source) }

    val filtered: StateFlow<List<ProductEntity>> = combine(repository.products, filterState) { products, filter ->
        val parsed = SearchQueryParser.parse(filter.query)
        products.filter { p ->
            val hay = listOf(
                p.title, p.description, p.brand.orEmpty(), p.model.orEmpty(), p.year?.toString().orEmpty(),
                p.price?.toString().orEmpty(), p.province, p.category, p.groupOrPageName.orEmpty(), p.sourceName, p.sourceType
            ).joinToString(" ").lowercase()
            val effectiveMin = maxOfNullable(filter.minPrice, parsed.minPrice)
            val effectiveMax = minOfNullable(filter.maxPrice, parsed.maxPrice)
            parsed.terms.all { hay.contains(it) } &&
                (filter.category.isNullOrBlank() || p.category.equals(filter.category, true)) &&
                (filter.province.isBlank() || p.province.contains(filter.province, true) || p.location.contains(filter.province, true)) &&
                (effectiveMin == null || (p.price ?: Long.MIN_VALUE) >= effectiveMin) &&
                (effectiveMax == null || (p.price ?: Long.MAX_VALUE) <= effectiveMax) &&
                (filter.sourceType.isNullOrBlank() || p.sourceType.equals(filter.sourceType, true))
        }
    }.combine(sort) { list, s ->
        when (s) {
            Sort.NEWEST -> list.sortedByDescending { it.postedAt }
            Sort.PRICE_LOW -> list.sortedBy { it.price ?: Long.MAX_VALUE }
            Sort.PRICE_HIGH -> list.sortedByDescending { it.price ?: Long.MIN_VALUE }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val favoriteProducts = repository.favoriteProducts().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val recentlyViewed = repository.recentlyViewedProducts().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init { viewModelScope.launch { repository.seedIfNeeded() } }

    fun refresh() = viewModelScope.launch {
        refreshing.value = true
        repository.seedIfNeeded()
        refreshing.value = false
    }

    fun loadMore() { visibleCount.value += 20 }
    fun search(text: String) {
        query.value = text
        searchRecordJob?.cancel()
        val clean = text.trim()
        if (clean.length >= 2) {
            searchRecordJob = viewModelScope.launch {
                delay(700)
                if (query.value.trim() == clean) repository.recordSearch(clean)
            }
        }
    }

    fun resetBrowseState() {
        searchRecordJob?.cancel()
        query.value = ""
        category.value = null
        province.value = ""
        minPrice.value = null
        maxPrice.value = null
        sourceType.value = null
        sort.value = Sort.NEWEST
        visibleCount.value = 20
    }
    fun clearFilters() { category.value = null; province.value = ""; minPrice.value = null; maxPrice.value = null; sourceType.value = null; sort.value = Sort.NEWEST }
    fun addGroup(name: String, url: String) = viewModelScope.launch { repository.addGroup(name, url) }
    fun setGroupFavorite(id: String, value: Boolean) = viewModelScope.launch { repository.setGroupFavorite(id, value) }
    fun setGroupSync(id: String, value: Boolean) = viewModelScope.launch { repository.setGroupSync(id, value) }
    fun importText(text: String) = viewModelScope.launch { repository.importSharedText(text) }
    fun addCategory(name: String) = viewModelScope.launch { repository.addCategory(name) }
    fun addKeywordRule(keyword: String, include: Boolean) = viewModelScope.launch { repository.addKeywordRule(keyword, include) }
    fun setDarkMode(value: Boolean) = viewModelScope.launch { settingsRepository.setDarkMode(value) }
    fun setNotificationsEnabled(value: Boolean) = viewModelScope.launch { settingsRepository.setNotificationsEnabled(value) }
    fun toggleFavorite(id: String) = viewModelScope.launch {
        val current = favoriteProducts.value.any { it.id == id }
        repository.toggleFavorite(id, current)
    }

    fun saveCurrentSearch() = viewModelScope.launch {
        val q = query.value
        repository.saveSearch(
            name = q.ifBlank { "ค้นหาที่บันทึก" },
            query = q,
            category = category.value,
            province = province.value.takeIf { it.isNotBlank() },
            minPrice = minPrice.value,
            maxPrice = maxPrice.value,
            sourceType = sourceType.value
        )
    }

    private fun maxOfNullable(a: Long?, b: Long?): Long? = when { a == null -> b; b == null -> a; else -> maxOf(a, b) }
    private fun minOfNullable(a: Long?, b: Long?): Long? = when { a == null -> b; b == null -> a; else -> minOf(a, b) }
}

enum class Sort { NEWEST, PRICE_LOW, PRICE_HIGH }
