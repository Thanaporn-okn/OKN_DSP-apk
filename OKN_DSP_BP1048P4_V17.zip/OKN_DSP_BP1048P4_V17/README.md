OKN_DSP_BP1048P4 V17
Bluetooth + DSP Command Core + CH1-CH7 control
