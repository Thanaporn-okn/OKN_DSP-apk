// Bluetooth scan/connect module V17
