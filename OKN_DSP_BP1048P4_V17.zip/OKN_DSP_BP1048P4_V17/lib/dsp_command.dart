// BP1048P4 TX RX command module V17
