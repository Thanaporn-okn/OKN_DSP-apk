package com.okn.okn_dsp

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.app.ActivityCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class MainActivity : FlutterActivity() {
    private val methods = "okn_dsp/methods"
    private val events = "okn_dsp/events"

    private var sink: EventChannel.EventSink? = null
    private var gatt: BluetoothGatt? = null
    private var scanCallback: ScanCallback? = null
    private val handler = Handler(Looper.getMainLooper())

    private val serviceUuid =
        UUID.fromString("0000ab00-0000-1000-8000-00805f9b34fb")
    private val ab01Uuid =
        UUID.fromString("0000ab01-0000-1000-8000-00805f9b34fb")
    private val ab02Uuid =
        UUID.fromString("0000ab02-0000-1000-8000-00805f9b34fb")
    private val ab03Uuid =
        UUID.fromString("0000ab03-0000-1000-8000-00805f9b34fb")
    private val cccdUuid =
        UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")

    private var notifyCharacteristics: List<BluetoothGattCharacteristic> = emptyList()
    private var notifyIndex = 0
    private var descriptorBusy = false
    private var captureRunning = false

    override fun configureFlutterEngine(engine: FlutterEngine) {
        super.configureFlutterEngine(engine)

        EventChannel(engine.dartExecutor.binaryMessenger, events)
            .setStreamHandler(object : EventChannel.StreamHandler {
                override fun onListen(
                    arguments: Any?,
                    eventSink: EventChannel.EventSink?
                ) {
                    sink = eventSink
                }

                override fun onCancel(arguments: Any?) {
                    sink = null
                }
            })

        MethodChannel(engine.dartExecutor.binaryMessenger, methods)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "scan" -> {
                        scan()
                        result.success(null)
                    }

                    "connect" -> {
                        val address = call.argument<String>("address")
                        if (address.isNullOrBlank()) {
                            result.error("ADDRESS", "Missing Bluetooth address", null)
                        } else {
                            connect(address)
                            result.success(null)
                        }
                    }

                    "readAb01" -> {
                        val current = gatt
                        if (current == null) {
                            result.error("GATT", "Not connected", null)
                        } else {
                            readAb01(current, "AB01 READ")
                            result.success(null)
                        }
                    }

                    "startCaptureTest" -> {
                        val current = gatt
                        if (current == null) {
                            result.error("GATT", "Not connected", null)
                        } else {
                            startCaptureTest(current)
                            result.success(null)
                        }
                    }

                    else -> result.notImplemented()
                }
            }
    }

    private fun emit(map: Map<String, Any?>) {
        runOnUiThread { sink?.success(map) }
    }

    private fun hasScanPermission(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            ActivityCompat.checkSelfPermission(
                this, Manifest.permission.BLUETOOTH_SCAN
            ) == PackageManager.PERMISSION_GRANTED

    private fun hasConnectPermission(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            ActivityCompat.checkSelfPermission(
                this, Manifest.permission.BLUETOOTH_CONNECT
            ) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    private fun scan() {
        if (!hasScanPermission()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                requestPermissions(
                    arrayOf(Manifest.permission.BLUETOOTH_SCAN),
                    3002
                )
            }
            emit(mapOf(
                "type" to "status",
                "message" to "ต้องอนุญาต Bluetooth Scan ก่อน"
            ))
            return
        }

        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val adapter: BluetoothAdapter = manager.adapter
        if (!adapter.isEnabled) {
            emit(mapOf(
                "type" to "status",
                "message" to "กรุณาเปิด Bluetooth ของโทรศัพท์"
            ))
            return
        }

        val scanner: BluetoothLeScanner? = adapter.bluetoothLeScanner
        if (scanner == null) {
            emit(mapOf(
                "type" to "status",
                "message" to "โทรศัพท์ไม่พบ BLE scanner"
            ))
            return
        }

        scanCallback?.let { old ->
            try {
                scanner.stopScan(old)
            } catch (_: Exception) {
            }
        }

        val callback = object : ScanCallback() {
            override fun onScanResult(
                callbackType: Int,
                result: ScanResult
            ) {
                val device = result.device
                val name = result.scanRecord?.deviceName
                    ?: try { device.name } catch (_: Exception) { null }
                    ?: ""

                emit(mapOf(
                    "type" to "scan",
                    "name" to name,
                    "address" to device.address,
                    "rssi" to result.rssi
                ))
            }

            override fun onScanFailed(errorCode: Int) {
                emit(mapOf(
                    "type" to "status",
                    "message" to "Bluetooth scan failed=$errorCode"
                ))
                emit(mapOf("type" to "scan_done"))
            }
        }

        scanCallback = callback
        scanner.startScan(callback)
        emit(mapOf(
            "type" to "status",
            "message" to "กำลังค้นหา Bluetooth..."
        ))

        handler.postDelayed({
            try {
                scanner.stopScan(callback)
            } catch (_: Exception) {
            }
            emit(mapOf("type" to "scan_done"))
        }, 8000)
    }

    @SuppressLint("MissingPermission")
    private fun connect(address: String) {
        if (!hasConnectPermission()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                requestPermissions(
                    arrayOf(Manifest.permission.BLUETOOTH_CONNECT),
                    3001
                )
            }
            emit(mapOf(
                "type" to "status",
                "message" to "ต้องอนุญาต Bluetooth Connect ก่อน"
            ))
            return
        }

        gatt?.close()
        gatt = null
        notifyCharacteristics = emptyList()
        notifyIndex = 0
        descriptorBusy = false
        captureRunning = false

        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val device = manager.adapter.getRemoteDevice(address)

        emit(mapOf(
            "type" to "status",
            "message" to "กำลังเชื่อมต่อ $address ..."
        ))

        gatt = device.connectGatt(
            this,
            false,
            callback,
            BluetoothDevice.TRANSPORT_LE
        )
    }

    @SuppressLint("MissingPermission")
    private fun startCaptureTest(g: BluetoothGatt) {
        if (captureRunning) return

        captureRunning = true
        emit(mapOf(
            "type" to "test",
            "message" to "STEP 1/3 — READ AB01",
            "done" to false
        ))

        readAb01(g, "STEP 1 — AB01 READ")

        handler.postDelayed({
            if (!captureRunning) return@postDelayed
            emit(mapOf(
                "type" to "test",
                "message" to "STEP 2/3 — เก็บ AB02 Notify",
                "done" to false
            ))
            emit(mapOf(
                "type" to "status",
                "message" to "กำลังเก็บ RAW จาก AB02/AB03"
            ))
        }, 1500)

        handler.postDelayed({
            if (!captureRunning) return@postDelayed
            emit(mapOf(
                "type" to "test",
                "message" to "STEP 3/3 — เก็บ AB03 Notify",
                "done" to false
            ))
        }, 6000)

        handler.postDelayed({
            if (!captureRunning) return@postDelayed
            captureRunning = false
            emit(mapOf(
                "type" to "test",
                "message" to "จบการเก็บหลักฐาน AB01 → AB02 → AB03",
                "done" to true
            ))
            emit(mapOf(
                "type" to "status",
                "message" to "จบการทดสอบ — ไม่มี payload ควบคุม DSP"
            ))
        }, 12000)
    }

    @SuppressLint("MissingPermission")
    private fun readAb01(g: BluetoothGatt, stage: String) {
        val service = g.getService(serviceUuid)
        val characteristic = service?.getCharacteristic(ab01Uuid)

        if (characteristic == null) {
            emit(mapOf(
                "type" to "read",
                "stage" to stage,
                "data" to "NO AB01",
                "length" to 0,
                "status" to -1
            ))
            return
        }

        val accepted = g.readCharacteristic(characteristic)
        emit(mapOf(
            "type" to "status",
            "message" to "$stage accepted=$accepted"
        ))
    }

    @SuppressLint("MissingPermission")
    private fun enableNotify(
        g: BluetoothGatt,
        characteristic: BluetoothGattCharacteristic
    ): Boolean {
        val local = g.setCharacteristicNotification(characteristic, true)
        val descriptor = characteristic.getDescriptor(cccdUuid)

        if (!local || descriptor == null) {
            emit(mapOf(
                "type" to "notify",
                "message" to "${shortUuid(characteristic.uuid)}: local=$local CCCD=${descriptor != null}"
            ))
            return false
        }

        descriptor.value =
            if ((characteristic.properties and
                    BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) {
                BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
            } else {
                BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            }

        descriptorBusy = true
        val accepted = g.writeDescriptor(descriptor)

        emit(mapOf(
            "type" to "notify",
            "message" to "${shortUuid(characteristic.uuid)}: CCCD write accepted=$accepted"
        ))
        return accepted
    }

    @SuppressLint("MissingPermission")
    private fun prepareNotifyQueue(g: BluetoothGatt) {
        val service = g.getService(serviceUuid)
        if (service == null) {
            emit(mapOf(
                "type" to "status",
                "message" to "ไม่พบ Service AB00"
            ))
            return
        }

        val a2 = service.getCharacteristic(ab02Uuid)
        val a3 = service.getCharacteristic(ab03Uuid)

        notifyCharacteristics = listOfNotNull(a2, a3).filter {
            val p = it.properties
            (p and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0 ||
                (p and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0
        }

        notifyIndex = 0
        descriptorBusy = false

        if (notifyCharacteristics.isEmpty()) {
            emit(mapOf(
                "type" to "notify",
                "message" to "ไม่พบ AB02/AB03 ที่รองรับ Notify/Indicate"
            ))
            return
        }

        enableNextNotify(g)
    }

    @SuppressLint("MissingPermission")
    private fun enableNextNotify(g: BluetoothGatt) {
        if (descriptorBusy) return

        if (notifyIndex >= notifyCharacteristics.size) {
            emit(mapOf(
                "type" to "notify",
                "message" to "เปิด Notify AB02 / AB03 ครบแล้ว"
            ))
            emit(mapOf(
                "type" to "status",
                "message" to "พร้อมเก็บ RAW AB02 / AB03"
            ))
            return
        }

        val characteristic = notifyCharacteristics[notifyIndex]
        val accepted = enableNotify(g, characteristic)

        if (!accepted) {
            descriptorBusy = false
            notifyIndex++
            handler.postDelayed({ enableNextNotify(g) }, 300)
        }
    }

    private fun shortUuid(uuid: UUID): String {
        val text = uuid.toString()
        return if (text.startsWith("0000") && text.length >= 8) {
            text.substring(4, 8).uppercase(Locale.US)
        } else {
            text
        }
    }

    private fun hex(bytes: ByteArray): String =
        bytes.joinToString(" ") {
            "%02X".format(Locale.US, it.toInt() and 0xFF)
        }

    private fun now(): String =
        SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date())

    private val callback = object : BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(
            g: BluetoothGatt,
            status: Int,
            newState: Int
        ) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                emit(mapOf(
                    "type" to "connected"
                ))
                emit(mapOf(
                    "type" to "status",
                    "message" to "เชื่อมต่อแล้ว — กำลังค้นหา GATT"
                ))
                g.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                captureRunning = false
                emit(mapOf("type" to "disconnected"))
                emit(mapOf(
                    "type" to "status",
                    "message" to "ตัดการเชื่อมต่อ status=$status"
                ))
            }
        }

        override fun onServicesDiscovered(
            g: BluetoothGatt,
            status: Int
        ) {
            val out = StringBuilder()
            out.append("GATT STATUS: $status\n")
            out.append("SERVICES: ${g.services.size}\n\n")

            for ((si, service) in g.services.withIndex()) {
                out.append("SERVICE ${si + 1}: ${service.uuid}\n")
                for ((ci, characteristic) in service.characteristics.withIndex()) {
                    val p = characteristic.properties
                    val props = mutableListOf<String>()

                    if ((p and BluetoothGattCharacteristic.PROPERTY_READ) != 0)
                        props.add("READ")
                    if ((p and BluetoothGattCharacteristic.PROPERTY_WRITE) != 0)
                        props.add("WRITE")
                    if ((p and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0)
                        props.add("WRITE_NR")
                    if ((p and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0)
                        props.add("NOTIFY")
                    if ((p and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0)
                        props.add("INDICATE")

                    out.append("  CHAR ${ci + 1}: ${characteristic.uuid}\n")
                    out.append("    PROPERTIES: ${props.joinToString(", ")}\n")

                    for (descriptor in characteristic.descriptors) {
                        out.append("    DESC: ${descriptor.uuid}\n")
                    }
                }
            }

            emit(mapOf("type" to "gatt", "text" to out.toString()))
            emit(mapOf(
                "type" to "status",
                "message" to "พบ GATT — กำลังเปิด Notify AB02 / AB03"
            ))
            prepareNotifyQueue(g)
        }

        override fun onCharacteristicRead(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            status: Int
        ) {
            val value = characteristic.value ?: byteArrayOf()
            if (characteristic.uuid == ab01Uuid) {
                emit(mapOf(
                    "type" to "read",
                    "stage" to "AB01 READ",
                    "data" to hex(value),
                    "length" to value.size,
                    "status" to status
                ))
            }
        }

        override fun onDescriptorWrite(
            g: BluetoothGatt,
            descriptor: BluetoothGattDescriptor,
            status: Int
        ) {
            if (!descriptorBusy) return

            descriptorBusy = false
            emit(mapOf(
                "type" to "notify",
                "message" to "${shortUuid(descriptor.characteristic.uuid)}: CCCD status=$status"
            ))

            notifyIndex++
            handler.postDelayed({ enableNextNotify(g) }, 250)
        }

        override fun onCharacteristicChanged(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic
        ) {
            val value = characteristic.value ?: byteArrayOf()
            emit(mapOf(
                "type" to "rx",
                "characteristic" to characteristic.uuid.toString(),
                "data" to hex(value),
                "length" to value.size,
                "time" to now()
            ))
        }

        @Suppress("DEPRECATION")
        override fun onCharacteristicChanged(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            value: ByteArray
        ) {
            emit(mapOf(
                "type" to "rx",
                "characteristic" to characteristic.uuid.toString(),
                "data" to hex(value),
                "length" to value.size,
                "time" to now()
            ))
        }
    }

    override fun onDestroy() {
        captureRunning = false
        scanCallback?.let { callback ->
            if (hasScanPermission()) {
                try {
                    val manager =
                        getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
                    manager.adapter.bluetoothLeScanner?.stopScan(callback)
                } catch (_: Exception) {
                }
            }
        }
        gatt?.close()
        gatt = null
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
