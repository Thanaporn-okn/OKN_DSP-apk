import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() => runApp(const OknDspApp());

class OknDspApp extends StatelessWidget {
  const OknDspApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'OKN DSP Packet Capture V16',
        theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.blue),
        home: const HomePage(),
      );
}

class DeviceInfo {
  final String name;
  final String address;
  final int rssi;
  const DeviceInfo(this.name, this.address, this.rssi);
}

class Packet {
  final String channel;
  final String hex;
  final String time;
  final int length;
  const Packet(this.channel, this.hex, this.time, this.length);
}

class ReadResult {
  final String stage;
  final String hex;
  final int length;
  final int status;
  const ReadResult(this.stage, this.hex, this.length, this.status);
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  static const methods = MethodChannel('okn_dsp/methods');
  static const events = EventChannel('okn_dsp/events');

  StreamSubscription? subscription;
  final devices = <String, DeviceInfo>{};
  final packets = <Packet>[];
  final reads = <ReadResult>[];

  DeviceInfo? selected;
  String status = 'กด Bluetooth เพื่อค้นหา';
  String notifyStatus = 'ยังไม่ได้เปิด Notify';
  String stage = 'ยังไม่ได้เริ่ม';
  String gatt = '';

  bool scanning = false;
  bool connected = false;
  bool testing = false;

  @override
  void initState() {
    super.initState();
    subscription = events.receiveBroadcastStream().listen(_onEvent);
  }

  void _onEvent(dynamic event) {
    if (!mounted || event is! Map) return;
    final type = event['type']?.toString() ?? '';

    if (type == 'scan') {
      final address = event['address']?.toString() ?? '';
      if (address.isNotEmpty) {
        setState(() {
          devices[address] = DeviceInfo(
            (event['name']?.toString().isNotEmpty ?? false)
                ? event['name'].toString()
                : '(บอร์ดไม่ส่งชื่อ)',
            address,
            int.tryParse('${event['rssi']}') ?? 0,
          );
        });
      }
    } else if (type == 'scan_done') {
      setState(() {
        scanning = false;
        status = 'ค้นหาเสร็จแล้ว — พบ ${devices.length} อุปกรณ์';
      });
    } else if (type == 'status') {
      setState(() => status = event['message']?.toString() ?? '');
    } else if (type == 'connected') {
      setState(() {
        connected = true;
        status = 'เชื่อมต่อ DSP แล้ว';
      });
    } else if (type == 'disconnected') {
      setState(() {
        connected = false;
        testing = false;
        stage = 'หลุดการเชื่อมต่อ';
      });
    } else if (type == 'gatt') {
      setState(() => gatt = event['text']?.toString() ?? '');
    } else if (type == 'notify') {
      setState(() => notifyStatus = event['message']?.toString() ?? '');
    } else if (type == 'rx') {
      setState(() {
        packets.insert(
          0,
          Packet(
            event['characteristic']?.toString() ?? '',
            event['data']?.toString() ?? '',
            event['time']?.toString() ?? '',
            int.tryParse('${event['length']}') ?? 0,
          ),
        );
        if (packets.length > 500) packets.removeLast();
      });
    } else if (type == 'read') {
      setState(() {
        reads.insert(
          0,
          ReadResult(
            event['stage']?.toString() ?? 'AB01 READ',
            event['data']?.toString() ?? '',
            int.tryParse('${event['length']}') ?? 0,
            int.tryParse('${event['status']}') ?? -1,
          ),
        );
      });
    } else if (type == 'test') {
      setState(() {
        stage = event['message']?.toString() ?? '';
        if (event['done'] == true) testing = false;
      });
    }
  }

  Future<void> scan() async {
    setState(() {
      scanning = true;
      devices.clear();
      status = 'กำลังค้นหา Bluetooth...';
    });
    try {
      await methods.invokeMethod('scan');
    } catch (e) {
      if (mounted) {
        setState(() {
          scanning = false;
          status = 'สแกนไม่ได้: $e';
        });
      }
    }
  }

  Future<void> connect(DeviceInfo device) async {
    setState(() {
      selected = device;
      connected = false;
      packets.clear();
      reads.clear();
      gatt = '';
      notifyStatus = 'กำลังเชื่อมต่อ';
      stage = 'กำลังเชื่อมต่อ...';
    });
    try {
      await methods.invokeMethod('connect', {'address': device.address});
    } catch (e) {
      if (mounted) setState(() => status = 'เชื่อมต่อไม่ได้: $e');
    }
  }

  Future<void> startCapture() async {
    if (!connected || testing) return;
    setState(() {
      testing = true;
      packets.clear();
      reads.clear();
      stage = 'AB01 → AB02 → AB03';
      status = 'เริ่มเก็บหลักฐาน RAW — ไม่ส่ง payload ควบคุม';
    });
    try {
      await methods.invokeMethod('startCaptureTest');
    } catch (e) {
      if (mounted) {
        setState(() {
          testing = false;
          stage = 'ทดสอบไม่สำเร็จ: $e';
        });
      }
    }
  }

  Future<void> readAb01() async {
    if (!connected) return;
    try {
      await methods.invokeMethod('readAb01');
    } catch (e) {
      if (mounted) setState(() => stage = 'AB01 READ ไม่สำเร็จ: $e');
    }
  }

  Future<void> clearCapture() async {
    setState(() {
      packets.clear();
      reads.clear();
      stage = 'ล้างข้อมูลแล้ว';
    });
  }

  Future<void> copyAll() async {
    final lines = <String>[
      'OKN DSP V16 PACKET CAPTURE LAB',
      'FLOW: AB01 READ -> AB02 NOTIFY -> AB03 NOTIFY',
      'SAFETY: NO GUESSED DSP CONTROL PAYLOAD',
      '',
      if (selected != null)
        'DEVICE: ${selected!.name} | ${selected!.address} | RSSI ${selected!.rssi}',
      'STATUS: $status',
      'STAGE: $stage',
      'NOTIFY: $notifyStatus',
      '',
      'GATT:',
      gatt,
      '',
      'AB01 READ RESPONSE:',
      ...reads.reversed.map(
        (r) => '${r.stage} | STATUS=${r.status} | LEN=${r.length} | ${r.hex}',
      ),
      '',
      'AB02 / AB03 RAW RX:',
      ...packets.reversed.map(
        (p) => '${p.time} | ${p.channel} | LEN=${p.length} | ${p.hex}',
      ),
    ];

    await Clipboard.setData(ClipboardData(text: lines.join('\n')));
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('คัดลอกหลักฐาน RAW ทั้งหมดแล้ว')),
      );
    }
  }

  String shortChannel(String value) {
    final v = value.toUpperCase();
    if (v.contains('0000AB02')) return 'AB02';
    if (v.contains('0000AB03')) return 'AB03';
    return v;
  }

  Widget verifiedInfo() => Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [
              Text('V16 Packet Capture Lab',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              SizedBox(height: 8),
              Text(
                'เก็บหลักฐานจริงจาก DSP โดยไม่เดาคำสั่งควบคุม',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 12),
              Text(
                '• Service AB00\n'
                '• AB01 = READ / WRITE, value handle 0x0006\n'
                '• AB02 = NOTIFY, value handle 0x0008, CCCD 0x0009\n'
                '• AB03 = NOTIFY, CCCD 0x000C\n'
                '• TX ที่พบ 16 bytes / RX ที่พบ 32 bytes\n'
                '• bulk 18,252 bytes = 77×235 + 157',
              ),
              SizedBox(height: 10),
              Text(
                'ยังไม่สรุป opcode, header, checksum/MAC, encryption, '
                'coefficient, endian, padding หรือ address formula',
                style: TextStyle(fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ),
      );

  Widget actionCard() => Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('สถานะ: $status'),
              const SizedBox(height: 5),
              Text('ขั้นตอน: $stage'),
              const SizedBox(height: 5),
              Text('Notify: $notifyStatus'),
              const SizedBox(height: 12),
              FilledButton.icon(
                onPressed: connected && !testing ? startCapture : null,
                icon: const Icon(Icons.science),
                label: Text(testing
                    ? 'กำลังเก็บหลักฐาน AB01 → AB02 → AB03...'
                    : 'เริ่มทดสอบ AB01 → AB02 → AB03'),
              ),
              const SizedBox(height: 6),
              OutlinedButton.icon(
                onPressed: connected ? readAb01 : null,
                icon: const Icon(Icons.download),
                label: const Text('อ่าน AB01 (READ เท่านั้น)'),
              ),
              const SizedBox(height: 6),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: copyAll,
                      icon: const Icon(Icons.copy),
                      label: const Text('คัดลอก RAW ทั้งหมด'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton(
                    tooltip: 'ล้างข้อมูล',
                    onPressed: clearCapture,
                    icon: const Icon(Icons.delete_outline),
                  ),
                ],
              ),
            ],
          ),
        ),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('OKN DSP Controller V16'),
          actions: [
            IconButton(
              onPressed: scanning ? null : scan,
              icon: const Icon(Icons.bluetooth_searching),
            ),
          ],
        ),
        body: ListView(
          padding: const EdgeInsets.all(12),
          children: [
            verifiedInfo(),
            if (selected != null)
              Card(
                child: ListTile(
                  leading: const Icon(Icons.developer_board),
                  title: Text(selected!.name),
                  subtitle:
                      Text('${selected!.address}\nRSSI ${selected!.rssi} dBm'),
                  trailing: connected
                      ? const Icon(Icons.bluetooth_connected)
                      : FilledButton(
                          onPressed: () => connect(selected!),
                          child: const Text('เชื่อมต่อ'),
                        ),
                ),
              ),
            if (!connected)
              Card(
                child: Column(
                  children: [
                    const ListTile(
                      title: Text('เลือกอุปกรณ์ช่องควบคุม DSP'),
                    ),
                    ...devices.values.map(
                      (d) => ListTile(
                        leading: const Icon(Icons.bluetooth),
                        title: Text(d.name),
                        subtitle: Text('${d.address}  RSSI ${d.rssi}'),
                        trailing: OutlinedButton(
                          onPressed: () => connect(d),
                          child: const Text('ใช้เป็น DSP'),
                        ),
                      ),
                    ),
                    if (devices.isEmpty)
                      const Padding(
                        padding: EdgeInsets.all(16),
                        child: Text('ยังไม่พบอุปกรณ์ กด Bluetooth ด้านบน'),
                      ),
                  ],
                ),
              ),
            actionCard(),
            if (gatt.isNotEmpty)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: SelectableText(
                    gatt,
                    style: const TextStyle(
                        fontFamily: 'monospace', fontSize: 11),
                  ),
                ),
              ),
            ListTile(
              title: const Text('AB01 READ RESPONSE',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text('${reads.length} รายการ'),
            ),
            if (reads.isEmpty)
              const Padding(
                padding: EdgeInsets.all(18),
                child: Text('ยังไม่มีผล AB01 READ'),
              ),
            ...reads.map(
              (r) => Card(
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: SelectableText(
                    '${r.stage}\nSTATUS=${r.status}  LEN=${r.length}\n${r.hex}',
                    style: const TextStyle(fontFamily: 'monospace'),
                  ),
                ),
              ),
            ),
            ListTile(
              title: const Text('RX จาก AB02 / AB03',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text('${packets.length} packets'),
            ),
            if (packets.isEmpty)
              const Padding(
                padding: EdgeInsets.all(18),
                child: Text('ยังไม่มี packet — เชื่อมต่อ DSP แล้วเริ่มทดสอบ'),
              ),
            ...packets.take(120).map(
              (p) => Card(
                child: Padding(
                  padding: const EdgeInsets.all(8),
                  child: SelectableText(
                    '${p.time} | ${shortChannel(p.channel)} | LEN=${p.length}\n${p.hex}',
                    style: const TextStyle(
                        fontFamily: 'monospace', fontSize: 12),
                  ),
                ),
              ),
            ),
            const Card(
              child: Padding(
                padding: EdgeInsets.all(14),
                child: Text(
                  '🛑 V16: Capture-only. เปิด CCCD เพื่อรับ Notify และ READ AB01 '
                  'เท่านั้น ไม่มีการสร้างหรือส่ง payload ควบคุม DSP ที่ยังไม่พิสูจน์',
                  style: TextStyle(fontWeight: FontWeight.w600),
                ),
              ),
            ),
          ],
        ),
      );

  @override
  void dispose() {
    subscription?.cancel();
    super.dispose();
  }
}
