# OKN DSP V16 — Packet Capture Lab

V16 is the next reverse-engineering step after confirming the real GATT layout.

Flow:
1. Scan and select the real DSP BLE device.
2. Connect.
3. Discover Service AB00.
4. Enable AB02 Notify via CCCD 0x0009.
5. Enable AB03 Notify via CCCD 0x000C.
6. READ AB01.
7. Capture every AB02/AB03 notification as timestamp + length + raw HEX.
8. Copy the complete capture for protocol analysis.

Safety:
- No guessed DSP-control payload is sent.
- No AB01 WRITE is performed.
- The app only performs AB01 READ and CCCD writes needed to enable Notify.

Known:
- Service 0000AB00-0000-1000-8000-00805F9B34FB
- AB01 0000AB01-0000-1000-8000-00805F9B34FB READ/WRITE
- AB02 0000AB02-0000-1000-8000-00805F9B34FB NOTIFY, CCCD 00002902...
- AB03 0000AB03-0000-1000-8000-00805F9B34FB NOTIFY, CCCD 00002902...
- Observed TX 16 bytes / RX 32 bytes
- Observed bulk 18,252 bytes = 77*235 + 157

The 235-byte size is not treated as an application packet until raw captures prove it.
