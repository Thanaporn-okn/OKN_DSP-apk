package com.okn.okn_dsp

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.app.ActivityCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.util.Locale
import java.util.UUID

class MainActivity : FlutterActivity() {
    private val methods = "okn_dsp/methods"
    private val events = "okn_dsp/events"
    private var sink: EventChannel.EventSink? = null
    private var scanner: BluetoothLeScanner? = null
    private var gatt: BluetoothGatt? = null
    private var ab01: BluetoothGattCharacteristic? = null
    private var ab02: BluetoothGattCharacteristic? = null
    private var ab03: BluetoothGattCharacteristic? = null
    private var polling = false
    private val handler = Handler(Looper.getMainLooper())

    private val pollTask = object : Runnable {
        override fun run() {
            if (!polling) return
            readAb01()
            handler.postDelayed(this, 1000L)
        }
    }

    private val scanCallback: ScanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val d = result.device
            emit(mapOf(
                "type" to "scan",
                "name" to (d.name ?: result.scanRecord?.deviceName ?: ""),
                "address" to d.address,
                "rssi" to result.rssi
            ))
        }

        override fun onScanFailed(errorCode: Int) {
            emit(mapOf("type" to "status", "message" to "Scan failed: $errorCode"))
        }
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        EventChannel(flutterEngine.dartExecutor.binaryMessenger, events)
            .setStreamHandler(object : EventChannel.StreamHandler {
                override fun onListen(arguments: Any?, eventSink: EventChannel.EventSink?) {
                    sink = eventSink
                }
                override fun onCancel(arguments: Any?) {
                    sink = null
                }
            })

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, methods)
            .setMethodCallHandler { call: MethodCall, result: MethodChannel.Result ->
                when (call.method) {
                    "scan" -> { startScan(); result.success(true) }
                    "connect" -> {
                        val address = call.argument<String>("address")
                        if (address.isNullOrBlank()) {
                            result.error("BAD_ADDRESS", "Missing Bluetooth address", null)
                        } else {
                            connect(address)
                            result.success(true)
                        }
                    }
                    "enableCapture" -> { enableCapture(); result.success(true) }
                    "readAB01" -> { readAb01(); result.success(true) }
                    "startAB01Polling" -> { startPolling(); result.success(true) }
                    "stopAB01Polling" -> { stopPolling(); result.success(true) }
                    "disconnect" -> { stopPolling(); closeGatt(); result.success(true) }
                    else -> result.notImplemented()
                }
            }

        requestPermissionsForBle()
    }

    private fun requestPermissionsForBle() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val p = arrayOf(
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_CONNECT
            )
            val missing = p.filter {
                ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
            }
            if (missing.isNotEmpty()) {
                ActivityCompat.requestPermissions(this, missing.toTypedArray(), 7001)
            }
        } else if (ActivityCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 7002
            )
        }
    }

    @SuppressLint("MissingPermission")
    private fun startScan() {
        val adapter = BluetoothAdapter.getDefaultAdapter()
        scanner = adapter?.bluetoothLeScanner
        if (scanner == null) {
            emit(mapOf("type" to "status", "message" to "BLE scanner unavailable"))
            return
        }
        try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
        scanner?.startScan(scanCallback)
        emit(mapOf("type" to "status", "message" to "กำลังค้นหา Bluetooth..."))
        handler.postDelayed({
            try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
            emit(mapOf("type" to "status", "message" to "ค้นหาเสร็จแล้ว"))
        }, 8000L)
    }

    @SuppressLint("MissingPermission")
    private fun connect(address: String) {
        stopPolling()
        closeGatt()
        val device = try {
            BluetoothAdapter.getDefaultAdapter().getRemoteDevice(address)
        } catch (_: Exception) {
            emit(mapOf("type" to "status", "message" to "Bluetooth address ไม่ถูกต้อง"))
            return
        }
        emit(mapOf("type" to "status", "message" to "กำลังเชื่อมต่อ..."))
        gatt = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
        } else {
            device.connectGatt(this, false, gattCallback)
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(
            g: BluetoothGatt, status: Int, newState: Int
        ) {
            if (newState == BluetoothGatt.STATE_CONNECTED) {
                emit(mapOf("type" to "status", "message" to "เชื่อมต่อแล้ว กำลังค้นหา Services..."))
                g.discoverServices()
            } else if (newState == BluetoothGatt.STATE_DISCONNECTED) {
                stopPolling()
                emit(mapOf("type" to "status", "message" to "ตัดการเชื่อมต่อ DSP"))
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            val lines = mutableListOf<String>()
            ab01 = null
            ab02 = null
            ab03 = null

            for (service in g.services) {
                lines.add("SERVICE: ${service.uuid}")
                for (c in service.characteristics) {
                    lines.add("  CHAR: ${c.uuid}  PROPERTIES: ${properties(c.properties)}")
                    when (c.uuid.toString().lowercase(Locale.US)) {
                        "0000ab01-0000-1000-8000-00805f9b34fb" -> ab01 = c
                        "0000ab02-0000-1000-8000-00805f9b34fb" -> ab02 = c
                        "0000ab03-0000-1000-8000-00805f9b34fb" -> ab03 = c
                    }
                }
            }
            emit(mapOf("type" to "gatt", "text" to lines.joinToString("\n")))
        }

        override fun onCharacteristicRead(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            value: ByteArray,
            status: Int
        ) {
            if (characteristic.uuid == ab01?.uuid) {
                emit(mapOf(
                    "type" to "read",
                    "status" to status,
                    "len" to value.size,
                    "hex" to hex(value)
                ))
            }
        }

        override fun onCharacteristicChanged(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            value: ByteArray
        ) {
            val channel = when (characteristic.uuid.toString().lowercase(Locale.US)) {
                "0000ab02-0000-1000-8000-00805f9b34fb" -> "AB02"
                "0000ab03-0000-1000-8000-00805f9b34fb" -> "AB03"
                else -> characteristic.uuid.toString()
            }
            emit(mapOf(
                "type" to "notify",
                "channel" to channel,
                "len" to value.size,
                "hex" to hex(value)
            ))
        }
    }

    @SuppressLint("MissingPermission")
    private fun enableCapture() {
        val g = gatt ?: return
        var count = 0
        if (ab02 != null && enableNotify(g, ab02!!)) count++
        if (ab03 != null && enableNotify(g, ab03!!)) count++
        emit(mapOf("type" to "notify_ready", "count" to count))
    }

    @SuppressLint("MissingPermission")
    private fun enableNotify(
        g: BluetoothGatt,
        c: BluetoothGattCharacteristic
    ): Boolean {
        val local = g.setCharacteristicNotification(c, true)
        val d = c.getDescriptor(
            UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
        ) ?: return false

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            g.writeDescriptor(
                d, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            ) == BluetoothGatt.GATT_SUCCESS && local
        } else {
            d.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            g.writeDescriptor(d) && local
        }
    }

    @SuppressLint("MissingPermission")
    private fun readAb01() {
        val g = gatt
        val c = ab01
        if (g == null || c == null) {
            emit(mapOf("type" to "status", "message" to "ยังไม่พบ AB01"))
            return
        }
        g.readCharacteristic(c)
    }

    private fun startPolling() {
        if (polling) return
        polling = true
        handler.removeCallbacks(pollTask)
        handler.post(pollTask)
        emit(mapOf("type" to "polling", "enabled" to true))
    }

    private fun stopPolling() {
        polling = false
        handler.removeCallbacks(pollTask)
        emit(mapOf("type" to "polling", "enabled" to false))
    }

    @SuppressLint("MissingPermission")
    private fun closeGatt() {
        try { gatt?.disconnect() } catch (_: Exception) {}
        try { gatt?.close() } catch (_: Exception) {}
        gatt = null
        ab01 = null
        ab02 = null
        ab03 = null
    }

    private fun properties(p: Int): String {
        val out = mutableListOf<String>()
        if ((p and BluetoothGattCharacteristic.PROPERTY_READ) != 0) out.add("READ")
        if ((p and BluetoothGattCharacteristic.PROPERTY_WRITE) != 0) out.add("WRITE")
        if ((p and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0) out.add("WRITE_NR")
        if ((p and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0) out.add("NOTIFY")
        if ((p and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) out.add("INDICATE")
        return out.joinToString(", ")
    }

    private fun hex(bytes: ByteArray): String =
        bytes.joinToString(" ") { String.format("%02X", it.toInt() and 0xFF) }

    private fun emit(data: Map<String, Any?>) {
        runOnUiThread { sink?.success(data) }
    }
}
