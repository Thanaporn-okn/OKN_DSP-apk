import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

const _method = MethodChannel('okn_dsp/methods');
const _events = EventChannel('okn_dsp/events');

void main() => runApp(const OknDspApp());

class OknDspApp extends StatelessWidget {
  const OknDspApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'OKN DSP Controller V17',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.blue),
      home: const CapturePage(),
    );
  }
}

class CapturePage extends StatefulWidget {
  const CapturePage({super.key});

  @override
  State<CapturePage> createState() => _CapturePageState();
}

class _CapturePageState extends State<CapturePage> {
  StreamSubscription<dynamic>? _sub;
  final List<String> _raw = [];
  final List<String> _ab01 = [];
  final List<String> _ab02 = [];
  final List<String> _ab03 = [];

  bool _scanning = false;
  bool _connected = false;
  bool _notifyReady = false;
  bool _polling = false;
  String _status = 'กด Bluetooth ด้านบนเพื่อค้นหา';
  String? _name;
  String? _address;
  String _gatt = '';
  int _packets = 0;

  @override
  void initState() {
    super.initState();
    _sub = _events.receiveBroadcastStream().listen(
      _onEvent,
      onError: (Object e) {
        if (mounted) setState(() => _status = 'Event error: $e');
      },
    );
  }

  @override
  void dispose() {
    _sub?.cancel();
    _method.invokeMethod('disconnect');
    super.dispose();
  }

  void _onEvent(dynamic event) {
    if (event is! Map) return;
    final m = Map<String, dynamic>.from(event);
    final type = '${m['type'] ?? ''}';

    if (type == 'scan') {
      final name = '${m['name'] ?? ''}';
      final address = '${m['address'] ?? ''}';
      final rssi = '${m['rssi'] ?? ''}';
      if (name.isNotEmpty && address.isNotEmpty && mounted) {
        setState(() {
          _name = name;
          _address = address;
          _status = 'พบอุปกรณ์: $name  RSSI $rssi dBm';
        });
      }
      return;
    }

    if (type == 'status') {
      if (mounted) setState(() => _status = '${m['message'] ?? ''}');
      return;
    }

    if (type == 'gatt') {
      if (mounted) {
        setState(() {
          _connected = true;
          _gatt = '${m['text'] ?? ''}';
          _status = 'เชื่อมต่อ GATT แล้ว';
        });
      }
      return;
    }

    if (type == 'notify') {
      final ch = '${m['channel'] ?? ''}';
      final hex = '${m['hex'] ?? ''}';
      final len = m['len'] ?? 0;
      final line = '${_time()}  $ch  LEN=$len  $hex';
      if (mounted) {
        setState(() {
          _packets++;
          _raw.insert(0, line);
          if (ch == 'AB02') {
            _ab02.insert(0, line);
          } else if (ch == 'AB03') {
            _ab03.insert(0, line);
          }
        });
      }
      return;
    }

    if (type == 'read') {
      final hex = '${m['hex'] ?? ''}';
      final len = m['len'] ?? 0;
      final line = '${_time()}  AB01 READ  LEN=$len  $hex';
      if (mounted) {
        setState(() {
          _ab01.insert(0, line);
          _raw.insert(0, line);
        });
      }
      return;
    }

    if (type == 'notify_ready') {
      if (mounted) {
        setState(() {
          _notifyReady = true;
          _status = 'เปิด Notify AB02 / AB03 แล้ว';
        });
      }
      return;
    }

    if (type == 'polling' && mounted) {
      setState(() {
        _polling = m['enabled'] == true;
        if (_polling) {
          _status = 'กำลังอ่าน AB01 แบบ READ-only ทุก 1 วินาที';
        }
      });
    }
  }

  String _time() {
    final n = DateTime.now();
    String p(int x, [int w = 2]) => x.toString().padLeft(w, '0');
    return '${p(n.hour)}:${p(n.minute)}:${p(n.second)}.${p(n.millisecond, 3)}';
  }

  Future<void> _scan() async {
    setState(() {
      _scanning = true;
      _status = 'กำลังค้นหา Bluetooth...';
    });
    await _method.invokeMethod('scan');
    if (mounted) setState(() => _scanning = false);
  }

  Future<void> _connect() async {
    final a = _address;
    if (a == null || a.isEmpty) return;
    setState(() => _status = 'กำลังเชื่อมต่อ $_name ...');
    await _method.invokeMethod('connect', {'address': a});
  }

  Future<void> _startCapture() async {
    if (!_connected) {
      setState(() => _status = 'ต้องเชื่อมต่อ DSP ก่อน');
      return;
    }
    await _method.invokeMethod('enableCapture');
  }

  Future<void> _readOnce() async {
    if (_connected) await _method.invokeMethod('readAB01');
  }

  Future<void> _poll() async {
    if (_connected) await _method.invokeMethod('startAB01Polling');
  }

  Future<void> _stopPoll() async {
    await _method.invokeMethod('stopAB01Polling');
    if (mounted) setState(() => _polling = false);
  }

  Future<void> _copyRaw() async {
    await Clipboard.setData(ClipboardData(text: _raw.reversed.join('\n')));
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('คัดลอก RAW ทั้งหมดแล้ว')),
      );
    }
  }

  void _clear() {
    setState(() {
      _raw.clear();
      _ab01.clear();
      _ab02.clear();
      _ab03.clear();
      _packets = 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('OKN DSP Controller V17'),
        actions: [
          IconButton(
            tooltip: 'Bluetooth',
            onPressed: _scanning ? null : _scan,
            icon: const Icon(Icons.bluetooth),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text('V17 Packet Capture Lab',
                      style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                  SizedBox(height: 12),
                  Text('โหมดเก็บหลักฐานเท่านั้น — ไม่ส่ง payload ควบคุม DSP'),
                  SizedBox(height: 8),
                  Text('AB01 = READ เท่านั้น'),
                  Text('AB02 = NOTIFY'),
                  Text('AB03 = NOTIFY'),
                  SizedBox(height: 8),
                  Text('เป้าหมาย: จับ RAW จริงเพื่อแกะ protocol ก่อนทำคำสั่งควบคุม'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 10),
          if (_name != null)
            Card(
              child: ListTile(
                leading: const Icon(Icons.memory),
                title: Text(_name!),
                subtitle: Text('${_address ?? ''}\n$_status'),
                trailing: FilledButton(
                  onPressed: _connected ? null : _connect,
                  child: Text(_connected ? 'เชื่อมต่อแล้ว' : 'เชื่อมต่อ'),
                ),
              ),
            ),
          const SizedBox(height: 8),
          Text('สถานะ: $_status'),
          if (_gatt.isNotEmpty)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: SelectableText(_gatt,
                    style: const TextStyle(fontFamily: 'monospace', fontSize: 12)),
              ),
            ),
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: _connected ? _startCapture : null,
            icon: const Icon(Icons.science),
            label: const Text('เปิด Capture AB01 → AB02 → AB03'),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: _notifyReady ? _readOnce : null,
            icon: const Icon(Icons.download),
            label: const Text('อ่าน AB01 1 ครั้ง (READ เท่านั้น)'),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _notifyReady && !_polling ? _poll : null,
                  icon: const Icon(Icons.repeat),
                  label: const Text('Poll AB01'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _polling ? _stopPoll : null,
                  icon: const Icon(Icons.stop),
                  label: const Text('หยุด Poll'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _copyRaw,
                  icon: const Icon(Icons.copy),
                  label: const Text('คัดลอก RAW'),
                ),
              ),
              IconButton(
                onPressed: _clear,
                icon: const Icon(Icons.delete_outline),
                tooltip: 'ล้างข้อมูล',
              ),
            ],
          ),
          const SizedBox(height: 14),
          Text('AB01 READ RESPONSE  (${_ab01.length} รายการ)',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          if (_ab01.isEmpty)
            const Padding(
              padding: EdgeInsets.all(20),
              child: Center(child: Text('ยังไม่มีผล AB01 READ')),
            )
          else
            ..._ab01.take(20).map(_rawCard),
          const SizedBox(height: 12),
          Text('RX จาก AB02 / AB03  ($_packets packets)',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          if (_ab02.isEmpty && _ab03.isEmpty)
            const Padding(
              padding: EdgeInsets.all(20),
              child: Center(child: Text('ยังไม่มี packet จาก Notify')),
            ),
          ..._ab02.take(20).map(_rawCard),
          ..._ab03.take(20).map(_rawCard),
          const SizedBox(height: 20),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Text(
                '🛑 V17: READ/NOTIFY capture-only\n'
                'ไม่มี WRITE payload ควบคุม DSP และไม่เดา opcode/header/checksum',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _rawCard(String text) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: SelectableText(text,
            style: const TextStyle(fontFamily: 'monospace', fontSize: 12)),
      ),
    );
  }
}
