# OKN DSP Controller V17

V17 is a passive BLE packet-capture laboratory.

Confirmed GATT evidence:
- Service: 0000AB00-0000-1000-8000-00805F9B34FB
- AB01: 0000AB01-0000-1000-8000-00805F9B34FB — READ / WRITE / WRITE_NR
- AB02: 0000AB02-0000-1000-8000-00805F9B34FB — NOTIFY
- AB03: 0000AB03-0000-1000-8000-00805F9B34FB — NOTIFY
- CCCD: 00002902-0000-1000-8000-00805F9B34FB

V17 safety rule:
- No application WRITE payload is sent.
- AB01 is used only with READ.
- AB02 and AB03 are captured as notifications.
- RAW can be copied from the app.

Build from phone:
1. Upload this ZIP to repository root.
2. Upload build-okn-dsp-v17.yml into .github/workflows/
3. Run GitHub Actions.
4. Install the APK.
5. Press Bluetooth.
6. Select the actual DSP device shown by the board.
7. Connect.
8. Press "เปิด Capture AB01 → AB02 → AB03".
9. Press "อ่าน AB01 1 ครั้ง" or "Poll AB01".
10. Copy RAW and return the data for protocol analysis.

Do not invent opcode, header, checksum, encryption, coefficient format, endian, padding, or address formulas without packet evidence.
