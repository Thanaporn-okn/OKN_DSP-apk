# OKN DSP V11 — Phase 1

V11 fixes the top-screen overlap seen in the V10 test video. The app now uses the device's real Android **WindowInsets safe area** instead of assuming the status bar has zero height.

- Header starts below the status bar / punch-hole / display cutout.
- Phone status icons (time, Wi-Fi, signal, battery) remain visible.
- Bottom navigation also stays above gesture/navigation-bar insets.
- Left/right safe insets are respected for cutouts and wider tablet layouts.
- No fixed status-bar pixel value is used, so the behavior adapts across phones and tablets.
- V10 color policy is preserved: no purple; EQ Frequency blue, Q cyan/teal, Gain Band mint green.
- Preset behavior is unchanged: popup Preset name dialog, multiple presets, Load and Delete.

Version: **11.0.0** (`versionCode 1011`)
