OKN_DSP V11 — Phase 1 UI Matching Pass

Based on the V10 real-device video review.
Changes in V11:
- Adds two bundled original raster artworks created specifically for this app: a dark mountain banner and a transparent DSP unit render.
- The uploaded four-screen UI reference image is still NOT bundled, copied, or painted as a background.
- Replaces the geometric mountain ridge background with a richer image asset blended into the Canvas UI.
- Uses the new DSP render on Home with a vector fallback if decoding ever fails.
- Keeps the V10 system-Roboto lock, real-time controls, responsive layout, session/presets, and fixed V5+ signing identity.
- Phase 2 hardware DSP transport remains intentionally disabled.
