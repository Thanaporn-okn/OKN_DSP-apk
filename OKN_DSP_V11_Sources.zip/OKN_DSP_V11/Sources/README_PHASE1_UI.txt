OKN_DSP Version 11 - Phase 1 UI

Purpose
- Rebuild the interface from code to visually approach the supplied four-screen reference.
- The supplied reference image is NOT embedded or copied as an app background.
- Phase 2 DSP/BLE transport remains disabled until the Phase 1 UI is accepted.

Pages
- Home
- Mix
- Eq
- Crossover

V11 focus
- Correct visual differences observed in the running V10 recording (30557.mp4).
- Limit tall-screen vertical growth so cards, knobs and graphs stay close to the supplied 432x768 reference proportions while the background remains full-screen.
- Keep full-screen support on shorter phones and tablets with adaptive fit protection.
- Keep platform-Roboto UI typography and use an in-app code-drawn transient notice so system display fonts do not leak into feedback messages.
- Use a heavier/wider OKN_DSP wordmark and a shallower bottom navigation closer to the supplied reference.
- Rebalance Mix, EQ and Crossover vertical proportions while keeping every visible control interactive in real time.
- Preserve the stable development signing identity for update-in-place builds.

Signing / update path
V3 introduced a stable DEVELOPMENT signing key. V4, V5, V6, V7, V8, V9, V10 and V11 preserve the same key, so V3 and later development builds can update in place.
If moving from V1/V2 and Android reports an incompatible update, uninstall the old V1/V2 app once. V3 and later use the stable key.

Build
Use OKN_DSP_AutoBuild.yml. The workflow automatically selects the highest OKN_DSP_V*_Sources.zip in the repository root, verifies Sources/SHA256SUMS.txt, verifies the signing key, builds the signed debug APK and uploads the APK artifact.
