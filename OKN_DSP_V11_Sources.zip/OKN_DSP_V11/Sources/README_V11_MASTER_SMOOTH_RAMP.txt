OKN_DSP V11 — MASTER VOLUME FAST CONFIRMED SMOOTH RAMP

Why V11 exists
- V6..V9 changed MasterVolume but the real DSP audibly pumped/stuttered.
- V10 changed to one final Master commit. The user still heard the fault and the DSP then rebooted.
- A single distant Master jump is therefore removed from production use.

V11 Master policy
1. UI follows the finger immediately.
2. Every MOVE replaces only the latest target; old touch positions are not queued.
3. DSP output never jumps directly to a distant target.
4. Each hardware write moves at most 0.5 dB from the last confirmed DSP value.
5. The next step is scheduled only after the previous GATT write callback succeeds, with 12 ms nominal continuation delay.
6. Direction changes use the newest target on the next confirmed step.
7. Session/GATT uncertainty stops the ramp, clears pending writes, and reconnects/authenticates fresh.
8. No automatic SaveParams.

Safety reason
V10 could apply a large final gain jump in one write, which can create a severe acoustic/power transient. V11 removes that path while also eliminating the slow 85+ ms stepping cadence that made V7-style ramps audibly pulse.

Testing
- Start with moderate playback level.
- Test Master from current value down by about 6 dB, then back up slowly.
- Do not jump from minimum directly to maximum during the first test.
- If the DSP reboots again, stop Master testing; do not keep repeating the fault.
