// V21 CH1-CH7 control framework
