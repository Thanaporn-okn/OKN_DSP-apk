import 'package:flutter/material.dart';

void main()=>runApp(const OKNDSP());

class OKNDSP extends StatelessWidget{
 const OKNDSP({super.key});

 @override
 Widget build(BuildContext context){
  return MaterialApp(
   debugShowCheckedModeBanner:false,
   theme:ThemeData.dark(),
   home:const V21Page(),
  );
 }
}

class V21Page extends StatelessWidget{
 const V21Page({super.key});

 @override
 Widget build(BuildContext context){
  return Scaffold(
   backgroundColor:const Color(0xff101018),
   appBar:AppBar(title:const Text('OKN_DSP BP1048P4 V21')),
   body:const Center(
    child:Text(
     'Bluetooth Scan Ready\n'
     'Connect / Disconnect\n'
     'BP1048P4 Command Queue\n'
     'CH1-CH7 Control\n'
     'TX RX Log',
     textAlign:TextAlign.center,
     style:TextStyle(color:Colors.cyan,fontSize:24),
    ),
   ),
  );
 }
}
