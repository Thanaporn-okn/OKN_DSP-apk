// V21 HEX TX RX monitor framework
