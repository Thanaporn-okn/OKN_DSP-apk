// V21 BP1048P4 command queue TX RX framework
