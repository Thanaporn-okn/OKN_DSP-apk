// V21 Bluetooth scan and connection framework
