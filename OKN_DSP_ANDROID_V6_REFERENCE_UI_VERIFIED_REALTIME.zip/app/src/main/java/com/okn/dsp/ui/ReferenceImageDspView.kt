package com.okn.dsp.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import android.widget.Toast
import com.okn.dsp.R
import com.okn.dsp.protocol.EqBand48
import com.okn.dsp.protocol.LiveEqPolicy
import com.okn.dsp.state.ConnectionState
import com.okn.dsp.state.DspState
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * Visual master = the exact Home/EQ reference images uploaded by the user in this turn.
 * The bitmap is fit-center without aspect distortion. Only dynamic value/status regions
 * are repainted so the rest of the visual language stays identical to the supplied UI.
 */
class ReferenceImageDspView(
    context: Context,
    private val actions: DspUiActions,
    initialPage: Int,
) : View(context) {

    companion object {
        private const val RW = 864f
        private const val RH = 1536f
        private const val PAGE_HOME = 0
        private const val PAGE_EQ = 1

        private val HOME_IDS = intArrayOf(2, 8, 9, 10, 13, 11)
        private val HOME_Y = floatArrayOf(374f, 503f, 631f, 759f, 889f, 1019f)
        private val HOME_FALLBACK = floatArrayOf(-3f, 4f, 100f, 3f, -2f, 1f)
        // Visual scales are taken from the supplied Home reference. Hardware-safe maxima
        // are enforced separately so the artwork never forces an unverified value.
        private val VISUAL_MIN = floatArrayOf(-60f, -12f, 20f, -12f, -12f, -12f)
        private val VISUAL_MAX = floatArrayOf(12f, 12f, 500f, 12f, 12f, 12f)
        private val SAFE_MIN = floatArrayOf(-60f, -12f, 20f, -12f, -12f, -12f)
        private val SAFE_MAX = floatArrayOf(6f, 6f, 250f, 12f, 12f, 12f)

        private val BAND_COLORS = intArrayOf(
            Color.rgb(255, 73, 78),
            Color.rgb(255, 207, 61),
            Color.rgb(48, 229, 106),
            Color.rgb(56, 211, 241),
            Color.rgb(161, 75, 237),
            Color.rgb(244, 91, 162),
        )
        private val BAND_ANCHORS = floatArrayOf(50f, 100f, 500f, 2000f, 5000f, 10000f)
        private val CH_SHORT = arrayOf("FL", "FR", "RL", "RR", "CEN", "SUB", "AUX")
        private val CH_LONG = arrayOf(
            "Front Left", "Front Right", "Rear Left", "Rear Right", "Center", "Sub", "AUX"
        )
    }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val regular = Typeface.create("sans-serif", Typeface.NORMAL)
    private val bold = Typeface.create("sans-serif", Typeface.BOLD)

    private val homeBitmap: Bitmap = BitmapFactory.decodeResource(resources, R.drawable.ui_home_reference)
    private val eqBitmap: Bitmap = BitmapFactory.decodeResource(resources, R.drawable.ui_eq_reference)

    private var state = DspState()
    private var currentPage = initialPage.coerceIn(PAGE_HOME, PAGE_EQ)
    private var presetLabel = "Preset"
    private var activeHomeSlot = -1
    private var activeEqBand = -1
    private var activeEqField = -1 // -1=select only, 0=graph, 1=frequency, 2=gain, 3=Q
    private var downRefX = 0f
    private var downRefY = 0f
    private var moved = false

    private var drawScale = 1f
    private var drawDx = 0f
    private var drawDy = 0f

    private val bg = Color.rgb(0, 16, 29)
    private val panel = Color.rgb(2, 29, 46)
    private val panelDark = Color.rgb(2, 23, 38)
    private val rail = Color.rgb(35, 70, 106)
    private val border = Color.rgb(34, 78, 116)
    private val white = Color.rgb(241, 246, 255)
    private val muted = Color.rgb(170, 194, 229)
    private val cyan = Color.rgb(0, 153, 255)
    private val green = Color.rgb(67, 240, 105)
    private val fail = Color.rgb(255, 84, 120)

    fun bindState(s: DspState) {
        state = s
        invalidate()
    }

    fun page(): Int = currentPage

    fun setPresetLabel(name: String) {
        presetLabel = name.ifBlank { "Preset" }
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0) return

        canvas.drawColor(bg)
        drawScale = min(width / RW, height / RH)
        drawDx = (width - RW * drawScale) * 0.5f
        drawDy = (height - RH * drawScale) * 0.5f

        val save = canvas.save()
        canvas.translate(drawDx, drawDy)
        canvas.scale(drawScale, drawScale)
        val bitmap = if (currentPage == PAGE_HOME) homeBitmap else eqBitmap
        canvas.drawBitmap(bitmap, null, RectF(0f, 0f, RW, RH), p)
        if (currentPage == PAGE_HOME) drawHomeDynamic(canvas) else drawEqDynamic(canvas)
        canvas.restoreToCount(save)
    }

    private fun drawHomeDynamic(c: Canvas) {
        drawConnectionStatus(c, 176f, 204f, 360f, 291f, home = true)
        HOME_IDS.forEachIndexed { slot, id ->
            val value = state.scalars[id] ?: HOME_FALLBACK[slot]
            drawHomeSlider(c, slot, value)
        }
    }

    private fun drawConnectionStatus(c: Canvas, l: Float, t: Float, r: Float, b: Float, home: Boolean) {
        p.style = Paint.Style.FILL
        p.color = Color.rgb(2, 29, 46)
        c.drawRoundRect(RectF(l, t, r, b), 8f, 8f, p)

        val ready = state.connection == ConnectionState.READY && state.healthGatePass
        val color = when {
            ready -> green
            state.connection == ConnectionState.FAILED -> fail
            state.connection == ConnectionState.DISCONNECTED -> muted
            else -> cyan
        }
        val title = when (state.connection) {
            ConnectionState.READY -> if (state.healthGatePass) "เชื่อมต่อแล้ว" else "ตรวจสอบ DSP"
            ConnectionState.SCANNING -> "กำลังสแกนหา"
            ConnectionState.CONNECTING, ConnectionState.RECONNECTING -> "กำลังเชื่อมต่อ"
            ConnectionState.DISCOVERING, ConnectionState.ENABLING_NOTIFICATIONS,
            ConnectionState.AUTHENTICATING, ConnectionState.ESTABLISHING_SESSION,
            ConnectionState.READING_DEVICE_DESCRIPTION, ConnectionState.READING_DSP_STATE -> "กำลังซิงก์ DSP"
            ConnectionState.FAILED -> "เชื่อมต่อไม่สำเร็จ"
            else -> "ยังไม่เชื่อมต่อ"
        }
        val name = state.device.bluetoothName?.takeIf { it.isNotBlank() } ?: "OKN DSP"
        text(c, title, l + 4f, if (home) t + 24f else t + 27f, 21f, white, bold = true)
        p.color = color
        c.drawCircle(r - 14f, if (home) t + 20f else t + 21f, 7f, p)
        text(c, name, l + 4f, if (home) t + 55f else t + 57f, 17f, white)
        if (home) {
            val detail = if (ready) "● อุปกรณ์พร้อมใช้งาน" else state.connectionMessage
            text(c, detail.take(24), l + 4f, t + 80f, 13.5f, if (ready) muted else color)
        }
    }

    private fun drawHomeSlider(c: Canvas, slot: Int, value: Float) {
        val y = HOME_Y[slot]
        val visualMin = VISUAL_MIN[slot]
        val visualMax = VISUAL_MAX[slot]
        val x1 = 352f
        val x2 = 684f

        // Preserve the reference artwork/tick labels. Repaint only the rail/knob/value.
        p.style = Paint.Style.FILL
        p.color = Color.rgb(2, 31, 49)
        c.drawRect(344f, y - 13f, 694f, y + 13f, p)
        p.color = panelDark
        c.drawRoundRect(RectF(714f, y - 26f, 823f, y + 27f), 12f, 12f, p)
        stroke.color = border
        stroke.strokeWidth = 1.4f
        c.drawRoundRect(RectF(714f, y - 26f, 823f, y + 27f), 12f, 12f, stroke)

        val clamped = value.coerceIn(visualMin, visualMax)
        val ratio = if (slot == 2) {
            val lo = kotlin.math.ln(visualMin.toDouble())
            val hi = kotlin.math.ln(visualMax.toDouble())
            ((kotlin.math.ln(clamped.coerceAtLeast(visualMin).toDouble()) - lo) / (hi - lo)).toFloat()
        } else if (visualMax == visualMin) 0f else (clamped - visualMin) / (visualMax - visualMin)
        val knobX = x1 + ratio.coerceIn(0f, 1f) * (x2 - x1)
        val accent = when (slot) {
            0, 4 -> Color.rgb(16, 139, 255)
            1 -> Color.rgb(23, 210, 230)
            2, 5 -> Color.rgb(207, 71, 242)
            else -> Color.rgb(255, 70, 145)
        }
        p.color = rail
        c.drawRoundRect(RectF(x1, y - 5.5f, x2, y + 5.5f), 7f, 7f, p)
        p.color = accent
        c.drawRoundRect(RectF(x1, y - 5.5f, knobX, y + 5.5f), 7f, 7f, p)
        p.color = Color.rgb(243, 247, 252)
        c.drawCircle(knobX, y, 14.5f, p)

        val valueText = if (slot == 2) String.format(Locale.US, "%.0f Hz", value)
        else String.format(Locale.US, "%.1f dB", value)
        text(c, valueText, 768.5f, y + 7f, 18f, white, Paint.Align.CENTER)
    }

    private fun drawEqDynamic(c: Canvas) {
        drawConnectionStatus(c, 136f, 167f, 326f, 229f, home = false)
        drawEqChannelHeader(c)
        val bands = visibleBands()
        drawEqGraph(c, bands)
        drawEqCards(c, bands)
        drawChannelButtons(c)
        // The uploaded reference used the old Thai word in this spot; user previously
        // requested that it read EQ. Repaint only the text while keeping the supplied nav.
        p.color = bg
        c.drawRect(255f, 1450f, 405f, 1498f, p)
        text(c, "EQ", 324f, 1478f, 19f, cyan, Paint.Align.CENTER, bold = true)
    }

    private fun drawEqChannelHeader(c: Canvas) {
        p.color = panelDark
        c.drawRoundRect(RectF(417f, 402f, 700f, 448f), 10f, 10f, p)
        stroke.color = border
        stroke.strokeWidth = 1.2f
        c.drawRoundRect(RectF(417f, 402f, 700f, 448f), 10f, 10f, stroke)
        val ch = state.selectedChannel.coerceIn(1, 7)
        text(c, "CH $ch : ${CH_LONG[ch - 1]}", 437f, 432f, 17f, white)
        text(c, "‹", 627f, 434f, 33f, muted, Paint.Align.CENTER)
        text(c, "›", 677f, 434f, 33f, muted, Paint.Align.CENTER)
    }

    private fun visibleBands(): List<Int> {
        val ch = state.selectedChannel.coerceIn(1, 7)
        val row = state.eq.getOrNull(ch - 1) ?: return emptyList()
        val writable = row.mapIndexedNotNull { index, band ->
            if (band != null && LiveEqPolicy.isWritable(band)) index + 1 else null
        }
        if (writable.size <= 6) return writable

        val remaining = writable.toMutableSet()
        val chosen = ArrayList<Int>(6)
        for (anchor in BAND_ANCHORS) {
            val best = remaining.minByOrNull { band1 ->
                val f = row[band1 - 1]?.frequency?.coerceAtLeast(20f) ?: anchor
                abs(ln(f / anchor))
            } ?: continue
            chosen += best
            remaining.remove(best)
        }
        return chosen.sortedBy { row[it - 1]?.frequency ?: Float.MAX_VALUE }.take(6)
    }

    private data class DisplayBand(val band1: Int, val frequency: Float, val q: Float, val gain: Float)

    private fun displayBands(indices: List<Int>): List<DisplayBand> {
        val ch = state.selectedChannel.coerceIn(1, 7)
        val row = state.eq.getOrNull(ch - 1)
        if (indices.isNotEmpty() && row != null) {
            val out = indices.mapNotNull { band1 ->
                row.getOrNull(band1 - 1)?.let { DisplayBand(band1, it.frequency, it.q, it.boostDb) }
            }
            if (out.isNotEmpty()) return out
        }
        val gains = floatArrayOf(-3f, 0f, 4f, -2f, -4f, 2f)
        return BAND_ANCHORS.mapIndexed { i, f -> DisplayBand(i + 1, f, 1f, gains[i]) }
    }

    private fun drawEqGraph(c: Canvas, indices: List<Int>) {
        val l = 80f
        val t = 470f
        val r = 832f
        val b = 708f
        p.color = Color.rgb(1, 22, 36)
        c.drawRect(l, t, r, b, p)
        stroke.color = Color.rgb(35, 75, 103)
        stroke.strokeWidth = 1f
        c.drawRect(l, t, r, b, stroke)
        for (i in 0..12) {
            val x = l + (r - l) * i / 12f
            stroke.color = Color.argb(95, 44, 84, 108)
            stroke.strokeWidth = 0.8f
            c.drawLine(x, t, x, b, stroke)
        }
        for (i in 0..8) {
            val y = t + (b - t) * i / 8f
            stroke.color = Color.argb(85, 44, 84, 108)
            c.drawLine(l, y, r, y, stroke)
        }

        val ds = displayBands(indices)
        val points = ds.take(6).map { band -> graphPoint(band.frequency, band.gain, l, t, r, b) }
        if (points.isEmpty()) return
        val path = Path().apply { moveTo(l, graphY(0f, t, b)) }
        points.forEachIndexed { i, pt ->
            if (i == 0) {
                cubicTo(l + 25f, graphY(0f, t, b), pt.first - 30f, pt.second, pt.first, pt.second)
            } else {
                val prev = points[i - 1]
                val dx = (pt.first - prev.first) * 0.45f
                cubicTo(prev.first + dx, prev.second, pt.first - dx, pt.second, pt.first, pt.second)
            }
        }
        val last = points.last()
        cubicTo(last.first + 25f, last.second, r - 20f, graphY(1f, t, b), r, graphY(1f, t, b))

        stroke.color = cyan
        stroke.strokeWidth = 3.4f
        c.drawPath(path, stroke)
        points.forEachIndexed { i, pt ->
            p.color = BAND_COLORS[i.coerceAtMost(BAND_COLORS.lastIndex)]
            c.drawCircle(pt.first, pt.second, 9.8f, p)
            stroke.color = white
            stroke.strokeWidth = 1.5f
            c.drawCircle(pt.first, pt.second, 9.8f, stroke)
        }
    }

    private fun graphPoint(freq: Float, gain: Float, l: Float, t: Float, r: Float, b: Float): Pair<Float, Float> =
        graphX(freq, l, r) to graphY(gain, t, b)

    private fun graphX(freq: Float, l: Float, r: Float): Float {
        val f = freq.coerceIn(20f, 20000f)
        val ratio = (log10(f) - log10(20f)) / (log10(20000f) - log10(20f))
        return l + ratio * (r - l)
    }

    private fun graphY(gain: Float, t: Float, b: Float): Float {
        val g = gain.coerceIn(-12f, 12f)
        return t + (12f - g) / 24f * (b - t)
    }

    private fun drawEqCards(c: Canvas, indices: List<Int>) {
        val xs = arrayOf(
            29f to 170f, 179f to 298f, 309f to 429f,
            439f to 560f, 572f to 696f, 706f to 834f,
        )
        val ds = displayBands(indices)
        xs.forEachIndexed { i, pair ->
            val band = ds.getOrNull(i) ?: return@forEachIndexed
            val (l, r) = pair
            p.color = panelDark
            c.drawRect(l + 7f, 818f, r - 7f, 969f, p)
            text(c, formatFreq(band.frequency), (l + r) / 2f, 850f, 16f, white, Paint.Align.CENTER, bold = true)
            text(c, String.format(Locale.US, "%.1f dB", band.gain), (l + r) / 2f, 892f, 15f, white, Paint.Align.CENTER)
            text(c, String.format(Locale.US, "%.2g", band.q), (l + r) / 2f, 931f, 15f, white, Paint.Align.CENTER)
            val selected = state.selectedEqBand == band.band1
            if (selected) {
                stroke.color = cyan
                stroke.strokeWidth = 2f
                c.drawRoundRect(RectF(l, 775f, r, 984f), 12f, 12f, stroke)
            }
        }
    }

    private fun formatFreq(freq: Float): String = when {
        freq >= 1000f -> String.format(Locale.US, "%.1f kHz", freq / 1000f)
        else -> String.format(Locale.US, "%.0f Hz", freq)
    }

    private fun drawChannelButtons(c: Canvas) {
        p.color = Color.rgb(2, 28, 45)
        c.drawRect(28f, 1052f, 837f, 1124f, p)
        val gap = 7f
        val l0 = 32f
        val totalW = 803f
        val w = (totalW - gap * 6f) / 7f
        val ch = state.selectedChannel.coerceIn(1, 7)
        for (i in 0 until 7) {
            val l = l0 + i * (w + gap)
            val r = l + w
            val selected = i + 1 == ch
            p.color = if (selected) Color.rgb(0, 139, 255) else panelDark
            c.drawRoundRect(RectF(l, 1055f, r, 1118f), 10f, 10f, p)
            stroke.color = if (selected) Color.rgb(51, 184, 255) else border
            stroke.strokeWidth = 1.2f
            c.drawRoundRect(RectF(l, 1055f, r, 1118f), 10f, 10f, stroke)
            text(c, "CH${i + 1}", (l + r) / 2f, 1083f, 14f, white, Paint.Align.CENTER)
            text(c, CH_SHORT[i], (l + r) / 2f, 1106f, 13f, white, Paint.Align.CENTER)
        }
    }

    private fun text(
        c: Canvas,
        s: String,
        x: Float,
        y: Float,
        size: Float,
        color: Int,
        align: Paint.Align = Paint.Align.LEFT,
        bold: Boolean = false,
    ) {
        p.shader = null
        p.style = Paint.Style.FILL
        p.color = color
        p.textSize = size
        p.textAlign = align
        p.typeface = if (bold) this.bold else regular
        c.drawText(s, x, y, p)
    }

    private fun toRefX(x: Float): Float = (x - drawDx) / drawScale
    private fun toRefY(y: Float): Float = (y - drawDy) / drawScale
    private fun insideRef(x: Float, y: Float): Boolean = x in 0f..RW && y in 0f..RH

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (drawScale <= 0f) return true
        val x = toRefX(event.x)
        val y = toRefY(event.y)
        if (!insideRef(x, y)) return true

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                moved = false
                downRefX = x
                downRefY = y
                if (currentPage == PAGE_HOME) return handleHomeDown(x, y)
                return handleEqDown(x, y)
            }
            MotionEvent.ACTION_MOVE -> {
                if (abs(x - downRefX) > 5f || abs(y - downRefY) > 5f) moved = true
                if (activeHomeSlot >= 0) {
                    updateHome(activeHomeSlot, x)
                    return true
                }
                if (activeEqBand > 0) {
                    if (activeEqField == 0) updateEqFromGraph(activeEqBand, x, y)
                    else if (activeEqField > 0 && moved) updateEqFromCard(activeEqBand, activeEqField, x)
                    return true
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                activeHomeSlot = -1
                activeEqBand = -1
                activeEqField = -1
                performClick()
                return true
            }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private fun handleHomeDown(x: Float, y: Float): Boolean {
        if (x in 760f..850f && y in 50f..125f) {
            actions.showMainMenu(); return true
        }
        if (x in 585f..825f && y in 205f..285f) {
            actions.scanConnect(); return true
        }
        if (x in 25f..145f && y in 325f..435f) {
            actions.toggleMasterMute(); return true
        }
        if (x in 665f..828f && y in 1100f..1185f) {
            actions.loadPreset(); return true
        }
        for (slot in HOME_Y.indices) {
            if (x in 335f..700f && abs(y - HOME_Y[slot]) <= 32f) {
                activeHomeSlot = slot
                updateHome(slot, x)
                return true
            }
        }
        if (y in 1190f..1275f) {
            when {
                x in 43f..224f -> {
                    actions.flatEq()
                    actions.scalarChanged(10, 0f)
                    actions.scalarChanged(13, 0f)
                    actions.scalarChanged(11, 0f)
                }
                x in 230f..424f -> toast("Pop: ยังไม่มีค่าพรีเซ็ตที่ยืนยัน — ใช้บันทึกพรีเซ็ตของคุณ")
                x in 432f..625f -> toast("Rock: ยังไม่มีค่าพรีเซ็ตที่ยืนยัน — ใช้บันทึกพรีเซ็ตของคุณ")
                x in 633f..826f -> toast("Jazz: ยังไม่มีค่าพรีเซ็ตที่ยืนยัน — ใช้บันทึกพรีเซ็ตของคุณ")
            }
            return true
        }
        if (y in 1294f..1373f) {
            if (x < 432f) actions.savePreset() else actions.loadPreset()
            return true
        }
        if (y >= 1390f) {
            when {
                x < 288f -> currentPage = PAGE_HOME
                x < 576f -> currentPage = PAGE_EQ
                else -> actions.showMainMenu()
            }
            invalidate(); return true
        }
        return true
    }

    private fun updateHome(slot: Int, x: Float) {
        val ratio = ((x - 352f) / (684f - 352f)).coerceIn(0f, 1f)
        val raw = if (slot == 2) {
            val lo = kotlin.math.ln(VISUAL_MIN[slot].toDouble())
            val hi = kotlin.math.ln(VISUAL_MAX[slot].toDouble())
            kotlin.math.exp(lo + (hi - lo) * ratio).toFloat()
        } else {
            VISUAL_MIN[slot] + ratio * (VISUAL_MAX[slot] - VISUAL_MIN[slot])
        }
        val safe = raw.coerceIn(SAFE_MIN[slot], SAFE_MAX[slot])
        val value = if (slot == 2) kotlin.math.round(safe) else (kotlin.math.round(safe * 10f) / 10f)
        actions.scalarChanged(HOME_IDS[slot], value)
    }

    private fun handleEqDown(x: Float, y: Float): Boolean {
        if (x in 696f..765f && y in 55f..126f) {
            actions.showMainMenu(); return true
        }
        if (x in 775f..850f && y in 55f..126f) {
            actions.showLogs(); return true
        }
        if (y in 157f..239f) {
            when {
                x in 415f..620f -> actions.scanConnect()
                x in 625f..840f -> actions.disconnect()
            }
            return true
        }
        if (y in 267f..366f) {
            when {
                x < 175f -> Unit // EQ active
                x < 350f -> toastLocked("Delay")
                x < 520f -> toastLocked("Crossover")
                x < 695f -> toastLocked("Output")
                else -> actions.loadPreset()
            }
            return true
        }
        if (y in 395f..454f) {
            if (x in 410f..705f) {
                val current = state.selectedChannel.coerceIn(1, 7)
                val next = when {
                    x < 651f -> if (current <= 1) 7 else current - 1
                    else -> if (current >= 7) 1 else current + 1
                }
                actions.channelSelected(next)
                return true
            }
            if (x >= 710f) {
                actions.flatEq(); return true
            }
        }
        if (x in 76f..838f && y in 466f..713f) {
            val indices = visibleBands()
            if (indices.isEmpty()) {
                toast("เชื่อมต่อ DSP และอ่านค่า EQ ก่อน")
                return true
            }
            val ds = displayBands(indices).take(6)
            val nearest = ds.minByOrNull { abs(graphX(it.frequency, 80f, 832f) - x) }
            if (nearest != null) {
                activeEqBand = nearest.band1
                activeEqField = 0
                actions.bandSelected(nearest.band1)
                updateEqFromGraph(nearest.band1, x, y)
            }
            return true
        }
        if (y in 770f..990f) {
            val idx = eqCardAt(x)
            if (idx >= 0) {
                val bands = visibleBands()
                val band1 = bands.getOrNull(idx)
                if (band1 != null) {
                    actions.bandSelected(band1)
                    activeEqBand = band1
                    activeEqField = when {
                        y in 815f..865f -> 1
                        y in 866f..910f -> 2
                        y in 911f..955f -> 3
                        else -> -1
                    }
                } else toast("แบนด์นี้ยังไม่มีข้อมูลจาก DSP")
                return true
            }
        }
        if (y in 1048f..1127f) {
            val ch = channelAt(x)
            if (ch > 0) actions.channelSelected(ch)
            return true
        }
        if (y in 1144f..1272f) {
            toast("Output / Mute / Phase ยังล็อกอยู่จนกว่าจะมีแพ็กเก็ตฮาร์ดแวร์ที่ยืนยัน")
            return true
        }
        if (y in 1280f..1372f) {
            when {
                x < 295f -> actions.refresh()
                x < 568f -> actions.saveParams()
                else -> actions.savePreset()
            }
            return true
        }
        if (y >= 1380f) {
            when {
                x < 216f -> currentPage = PAGE_HOME
                x < 432f -> currentPage = PAGE_EQ
                x < 648f -> actions.loadPreset()
                else -> actions.showMainMenu()
            }
            invalidate(); return true
        }
        return true
    }

    private fun updateEqFromGraph(band1: Int, x: Float, y: Float) {
        val ch = state.selectedChannel.coerceIn(1, 7)
        val current: EqBand48 = state.eq.getOrNull(ch - 1)?.getOrNull(band1 - 1) ?: return
        if (!LiveEqPolicy.isWritable(current)) return
        val l = 80f; val t = 470f; val r = 832f; val b = 708f
        val xr = ((x - l) / (r - l)).coerceIn(0f, 1f)
        val freq = (20.0 * (1000.0.pow(xr.toDouble()))).toFloat().coerceIn(20f, 20000f)
        val gain = (12f - ((y - t) / (b - t)).coerceIn(0f, 1f) * 24f)
        actions.eqChanged(ch, band1, freq, current.q, gain)
    }

    /** Horizontal drag directly on a card value row: F / Gain / Q. */
    private fun updateEqFromCard(band1: Int, field: Int, x: Float) {
        val ch = state.selectedChannel.coerceIn(1, 7)
        val current: EqBand48 = state.eq.getOrNull(ch - 1)?.getOrNull(band1 - 1) ?: return
        if (!LiveEqPolicy.isWritable(current)) return
        val idx = visibleBands().indexOf(band1)
        if (idx !in 0..5) return
        val xs = arrayOf(
            29f to 170f, 179f to 298f, 309f to 429f,
            439f to 560f, 572f to 696f, 706f to 834f,
        )
        val (l0, r0) = xs[idx]
        val ratio = ((x - (l0 + 10f)) / ((r0 - 10f) - (l0 + 10f))).coerceIn(0f, 1f)
        var f = current.frequency
        var q = current.q
        var g = current.boostDb
        when (field) {
            1 -> f = (20.0 * 1000.0.pow(ratio.toDouble())).toFloat().coerceIn(20f, 20000f)
            2 -> g = (-12f + 24f * ratio).coerceIn(-12f, 12f)
            3 -> {
                val lo = kotlin.math.ln(0.05)
                val hi = kotlin.math.ln(20.0)
                q = kotlin.math.exp(lo + (hi - lo) * ratio).toFloat().coerceIn(0.05f, 20f)
            }
        }
        actions.eqChanged(ch, band1, f, q, g)
    }

    private fun eqCardAt(x: Float): Int {
        val xs = arrayOf(
            29f to 170f, 179f to 298f, 309f to 429f,
            439f to 560f, 572f to 696f, 706f to 834f,
        )
        return xs.indexOfFirst { x in it.first..it.second }
    }

    private fun channelAt(x: Float): Int {
        val gap = 7f
        val l0 = 32f
        val totalW = 803f
        val w = (totalW - gap * 6f) / 7f
        for (i in 0 until 7) {
            val l = l0 + i * (w + gap)
            if (x in l..(l + w)) return i + 1
        }
        return -1
    }

    private fun toastLocked(name: String) {
        toast("$name ยังแสดงตาม UI เท่านั้น — hardware write ถูกล็อกเพราะยังไม่มี packet ที่ยืนยัน")
    }

    private fun toast(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }
}
