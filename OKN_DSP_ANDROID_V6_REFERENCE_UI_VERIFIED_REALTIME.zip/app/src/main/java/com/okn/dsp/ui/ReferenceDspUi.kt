package com.okn.dsp.ui

import android.content.Context
import android.view.View
import com.okn.dsp.state.DspStateStore

/**
 * UI command boundary. The UI can only call verified repository actions exposed here.
 * Crossover/Delay/Output hardware writes are intentionally not present.
 */
interface DspUiActions {
    fun scanConnect()
    fun showMainMenu()
    fun scalarChanged(id: Int, value: Float)
    fun toggleMasterMute()
    fun channelSelected(channel: Int)
    fun bandSelected(band: Int)
    fun eqChanged(channel: Int, band: Int, frequency: Float, q: Float, gain: Float)
    fun resetGlobal()
    fun savePreset()
    fun loadPreset()
    fun flatEq()
    fun copyEq()
    fun pasteEq()
    fun reconnect()
    fun disconnect()
    fun refresh()
    fun saveParams()
    fun showLogs()
}

data class UiSnapshot(val tab: Int = 0, val parametricMode: Boolean = false)

/**
 * V6 image-locked UI shell.
 * The two supplied portrait references are used as the only visual master for Home/EQ.
 * Dynamic overlays update connection/value/graph data without changing the supplied design.
 */
class ReferenceDspUi(
    context: Context,
    store: DspStateStore,
    actions: DspUiActions,
    initial: UiSnapshot = UiSnapshot(),
) {
    private val canvas = ReferenceImageDspView(context, actions, initial.tab.coerceIn(0, 1))
    private var unsubscribe: (() -> Unit)? = store.subscribe { canvas.bindState(it) }

    val view: View get() = canvas

    fun dispose() {
        unsubscribe?.invoke()
        unsubscribe = null
    }

    fun snapshot(): UiSnapshot = UiSnapshot(tab = canvas.page(), parametricMode = false)

    fun setPresetLabel(name: String) {
        canvas.setPresetLabel(name)
    }
}
