package com.okn.dsp.smoothing

import android.os.Handler
import android.os.Looper
import com.okn.dsp.protocol.EqBand48
import com.okn.dsp.protocol.EqBandCodec
import com.okn.dsp.protocol.LiveEqPolicy
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.sign

/**
 * Callback-gated PEAKING EQ interpolation.
 * Gain is bounded to 0.5 dB/step; frequency moves in log space; Q moves smoothly.
 */
class EqSlewController(
    private val sender: (Int, Int, EqBand48, (Boolean) -> Unit) -> Boolean,
) {
    private val main = Handler(Looper.getMainLooper())
    private data class Key(val ch: Int, val band: Int)
    private val current = mutableMapOf<Key, EqBand48>()
    private val target = mutableMapOf<Key, EqBand48>()
    private val running = mutableSetOf<Key>()

    fun seed(ch: Int, band: Int, value: EqBand48) {
        if (LiveEqPolicy.isWritable(value)) current[Key(ch, band)] = value
    }

    fun clear() { current.clear(); target.clear(); running.clear() }

    fun setTarget(ch: Int, band: Int, value: EqBand48) {
        if (!LiveEqPolicy.isWritable(value)) return
        val k = Key(ch, band)
        target[k] = value
        if (k !in running) drive(k)
    }

    private fun drive(k: Key) {
        val t = target[k] ?: return
        val c = current[k] ?: t.also { current[k] = it }
        val gainDone = abs(t.boostDb - c.boostDb) <= 0.051f
        val freqDone = abs(ln(t.frequency.toDouble()) - ln(c.frequency.toDouble())) <= 0.012
        val qDone = abs(t.q - c.q) <= 0.021f
        if (gainDone && freqDone && qDone) {
            current[k] = t; running.remove(k); return
        }

        val nextGain = moveLinear(c.boostDb, t.boostDb, 0.5f)
        val nextQ = moveLinear(c.q, t.q, 0.22f).coerceIn(LiveEqPolicy.MIN_Q, LiveEqPolicy.MAX_Q)
        val lc = ln(c.frequency.toDouble())
        val lt = ln(t.frequency.toDouble())
        val lf = moveLinear(lc.toFloat(), lt.toFloat(), 0.085f).toDouble()
        val nextF = exp(lf).toFloat().coerceIn(LiveEqPolicy.MIN_FREQUENCY_HZ, LiveEqPolicy.MAX_FREQUENCY_HZ)
        val next = EqBandCodec.peaking(nextF.toDouble(), nextQ.toDouble(), nextGain.toDouble())
        running += k
        val accepted = sender(k.ch, k.band, next) { ok ->
            main.post {
                if (!ok) { running.remove(k); return@post }
                current[k] = next
                main.postDelayed({ drive(k) }, 110L)
            }
        }
        if (!accepted) running.remove(k)
    }

    private fun moveLinear(current: Float, target: Float, maxStep: Float): Float {
        val d = target - current
        return if (abs(d) <= maxStep) target else current + sign(d) * maxStep
    }
}
