package com.okn.dsp

import android.app.Application
import com.okn.dsp.core.DspRuntime

/**
 * Process-scoped owner for the verified DSP session.
 * Activity/UI recreation never owns or tears down Bluetooth/GATT state.
 */
class OknDspApplication : Application() {
    lateinit var runtime: DspRuntime
        private set

    override fun onCreate() {
        super.onCreate()
        runtime = DspRuntime(this)
    }
}
