package com.okn.dsp.state

import com.okn.dsp.protocol.EqBand48

enum class ConnectionState {
    DISCONNECTED,
    SCANNING,
    CONNECTING,
    DISCOVERING,
    ENABLING_NOTIFICATIONS,
    AUTHENTICATING,
    ESTABLISHING_SESSION,
    READING_DEVICE_DESCRIPTION,
    READING_DSP_STATE,
    READY,
    RECONNECTING,
    FAILED
}

data class DeviceInfo(
    val bluetoothName: String? = null,
    val address: String? = null,
    val typeId: Int? = null,
    val versionId: Int? = null,
    val firmwareText: String? = null,
)

data class SensorValue(
    val id: Int,
    val name: String,
    val raw: String,
)

data class ChannelInfo(
    val index: Int,
    val shortName: String,
    val displayName: String,
)

data class DspState(
    val connection: ConnectionState = ConnectionState.DISCONNECTED,
    val connectionMessage: String = "Disconnected",
    val connectionEpoch: Long = 0L,
    val device: DeviceInfo = DeviceInfo(),
    val healthGatePass: Boolean = false,
    val writesSent: Long = 0,
    val protocolIdle: Boolean = true,
    val scalars: Map<Int, Float> = emptyMap(),
    val eq: List<List<EqBand48?>> = List(7) { List(15) { null } },
    val sensors: Map<Int, SensorValue> = emptyMap(),
    val selectedChannel: Int = 1,
    val selectedEqBand: Int = 1,
    val linkAllEq: Boolean = false,
    val dirtyLocal: Boolean = false,
    val saveInFlight: Boolean = false,
    val lastError: String? = null,
) {
    companion object {
        // User-facing labels follow the supplied V6 UI reference. The verified hardware
        // write mapping remains strictly numeric CH1..CH7 -> actuator IDs 4,5,6,14,15,16,17.
        val CHANNELS = listOf(
            ChannelInfo(1, "CH1", "Front Left"),
            ChannelInfo(2, "CH2", "Front Right"),
            ChannelInfo(3, "CH3", "Rear Left"),
            ChannelInfo(4, "CH4", "Rear Right"),
            ChannelInfo(5, "CH5", "Center"),
            ChannelInfo(6, "CH6", "Sub"),
            ChannelInfo(7, "CH7", "AUX"),
        )
    }
}
