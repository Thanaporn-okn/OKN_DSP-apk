package com.okn.dsp.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.roundToInt

/** Touch-enabled decorative/functional knob used by the Global page. */
class KnobView(context: Context) : View(context) {
    init {
        isSoundEffectsEnabled = false
        isHapticFeedbackEnabled = false
    }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var min = 0f
    private var max = 1f
    private var value = 0f
    private var startY = 0f
    private var startValue = 0f
    private var onChange: ((Float) -> Unit)? = null

    fun configure(min: Float, max: Float, value: Float, onChange: (Float) -> Unit) {
        this.min = min
        this.max = max
        this.value = value.coerceIn(min, max)
        this.onChange = onChange
        invalidate()
    }

    fun bindValue(v: Float) {
        value = v.coerceIn(min, max)
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val wanted = context.dp(64)
        setMeasuredDimension(resolveSize(wanted, widthMeasureSpec), resolveSize(wanted, heightMeasureSpec))
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val size = minOf(width, height).toFloat()
        val cx = width / 2f
        val cy = height / 2f
        val r = size * .39f
        val ring = RectF(cx-r, cy-r, cx+r, cy+r)

        p.style = Paint.Style.STROKE
        p.strokeWidth = context.dp(3).toFloat()
        p.strokeCap = Paint.Cap.ROUND
        p.color = Color.rgb(43, 61, 72)
        c.drawArc(ring, 135f, 270f, false, p)
        val t = ((value-min)/(max-min)).coerceIn(0f,1f)
        p.color = OknColors.CYAN
        c.drawArc(ring, 135f, 270f*t, false, p)

        p.style = Paint.Style.FILL
        p.color = Color.rgb(29, 36, 41)
        c.drawCircle(cx, cy, r*0.84f, p)
        p.color = Color.rgb(47, 53, 57)
        c.drawCircle(cx-r*.18f, cy-r*.16f, r*.52f, p)

        val angle = Math.toRadians((135f + 270f*t).toDouble())
        val x1 = cx + kotlin.math.cos(angle).toFloat()*r*.46f
        val y1 = cy + kotlin.math.sin(angle).toFloat()*r*.46f
        val x2 = cx + kotlin.math.cos(angle).toFloat()*r*.72f
        val y2 = cy + kotlin.math.sin(angle).toFloat()*r*.72f
        p.style = Paint.Style.STROKE
        p.strokeWidth = context.dp(2).toFloat()
        p.color = Color.WHITE
        c.drawLine(x1,y1,x2,y2,p)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                startY = event.y
                startValue = value
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dy = startY - event.y
                val span = (height.coerceAtLeast(context.dp(48)) * 2.2f)
                val delta = (dy/span)*(max-min)
                val v = (startValue+delta).coerceIn(min,max)
                if (kotlin.math.abs(v-value) > (max-min)/1200f) {
                    value = v
                    invalidate()
                    onChange?.invoke(v)
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                performClick()
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun performClick(): Boolean = super.performClick()
}
