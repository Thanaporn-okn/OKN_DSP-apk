package com.okn.dsp.queue

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.util.LinkedHashMap
import java.util.ArrayDeque

/**
 * One-inflight BLE queue.
 * - Realtime commands coalesce by key (latest value wins).
 * - Critical commands preserve FIFO order and are never coalesced.
 * - Plain packets are kept unencrypted until actual send, preserving continuous CFB8 state.
 */
class RealtimeCommandQueue(
    private val minPacingMs: Long = 90L,
    private val sender: (Command) -> Boolean,
    private val onIdleChanged: (Boolean) -> Unit,
    private val onWriteTimeout: (Command) -> Unit = {},
) {
    data class Command(
        val key: String,
        val plain: ByteArray,
        val label: String,
        val epoch: Long,
        val critical: Boolean = false,
        val encrypt: Boolean = true,
        val onComplete: ((Boolean) -> Unit)? = null,
    )

    private val main = Handler(Looper.getMainLooper())
    private val realtime = LinkedHashMap<String, Command>()
    private val critical = ArrayDeque<Command>()
    private var inflight: Command? = null
    private var lastSendAt = 0L
    private var realtimePaused = false
    private var timeoutRunnable: Runnable? = null
    private val writeTimeoutMs = 2500L

    fun setRealtimePaused(value: Boolean) {
        main.post {
            realtimePaused = value
            drain()
            emitIdle()
        }
    }

    fun enqueueLatest(command: Command) {
        main.post {
            realtime[command.key] = command
            emitIdle()
            drain()
        }
    }

    fun enqueueCritical(command: Command) {
        require(command.critical) { "critical command flag required" }
        main.post {
            critical.addLast(command)
            emitIdle()
            drain()
        }
    }

    /** Call from BluetoothGattCallback.onCharacteristicWrite. */
    fun onGattResult(success: Boolean) {
        main.post {
            val done = inflight ?: return@post
            timeoutRunnable?.let(main::removeCallbacks)
            timeoutRunnable = null
            inflight = null
            done.onComplete?.invoke(success)
            emitIdle()
            val elapsed = SystemClock.elapsedRealtime() - lastSendAt
            val wait = (minPacingMs - elapsed).coerceAtLeast(0L)
            if (wait == 0L) drain() else main.postDelayed({ drain() }, wait)
        }
    }

    fun clear(reasonCallbackFailure: Boolean = true) {
        main.post {
            timeoutRunnable?.let(main::removeCallbacks)
            timeoutRunnable = null
            if (reasonCallbackFailure) inflight?.onComplete?.invoke(false)
            inflight = null
            critical.forEach { if (reasonCallbackFailure) it.onComplete?.invoke(false) }
            realtime.values.forEach { if (reasonCallbackFailure) it.onComplete?.invoke(false) }
            critical.clear(); realtime.clear()
            emitIdle()
        }
    }

    fun isIdle(): Boolean = inflight == null && critical.isEmpty() && realtime.isEmpty()
    fun depth(): Int = (if (inflight == null) 0 else 1) + critical.size + realtime.size

    private fun drain() {
        if (inflight != null) return
        val next = if (critical.isNotEmpty()) {
            critical.removeFirst()
        } else if (!realtimePaused) {
            realtime.entries.firstOrNull()?.let { e -> realtime.remove(e.key); e.value }
        } else null
        if (next == null) { emitIdle(); return }
        inflight = next
        lastSendAt = SystemClock.elapsedRealtime()
        emitIdle()
        if (!sender(next)) {
            inflight = null
            next.onComplete?.invoke(false)
            main.postDelayed({ drain() }, minPacingMs)
        } else {
            timeoutRunnable = Runnable {
                val timedOut = inflight ?: return@Runnable
                if (timedOut !== next) return@Runnable
                inflight = null
                timeoutRunnable = null
                timedOut.onComplete?.invoke(false)
                onWriteTimeout(timedOut)
                emitIdle()
            }.also { main.postDelayed(it, writeTimeoutMs) }
        }
    }

    private fun emitIdle() = onIdleChanged(isIdle())
}
