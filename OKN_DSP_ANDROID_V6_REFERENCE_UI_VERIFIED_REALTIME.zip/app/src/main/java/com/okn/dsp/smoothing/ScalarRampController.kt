package com.okn.dsp.smoothing

import android.os.Handler
import android.os.Looper
import com.okn.dsp.protocol.VerifiedScalarControls
import kotlin.math.abs
import kotlin.math.sign
import kotlin.math.min
import kotlin.math.max

/** Callback-gated latest-target ramp for every verified scalar. ID11 uses the strict Treble profile. */
class ScalarRampController(
    private val sender: (Int, Float, (Boolean) -> Unit) -> Boolean,
) {
    private val main = Handler(Looper.getMainLooper())
    private val current = mutableMapOf<Int, Float>()
    private val target = mutableMapOf<Int, Float>()
    private val running = mutableSetOf<Int>()

    fun seed(id: Int, value: Float) { current[id] = value }
    fun clear() { current.clear(); target.clear(); running.clear() }

    fun setTarget(id: Int, requested: Float) {
        val v = VerifiedScalarControls.sanitize(id, requested) ?: return
        target[id] = v
        if (id !in running) drive(id)
    }

    private fun drive(id: Int) {
        val t = target[id] ?: return
        val c = current[id] ?: t.also { current[id] = it }
        val delta = t - c
        val cfg = VerifiedScalarControls.byId(id) ?: return
        val step = when {
            id == 11 -> 0.5f              // TrebleBoost: strict small-step anti-pop profile
            cfg.unit == "Hz" -> min(12.0f, max(3.0f, abs(delta) * 0.18f))
            else -> min(2.0f, max(0.5f, abs(delta) * 0.18f))
        }
        // Hardware writes are intentionally slower than UI updates. This keeps A2DP/audio
        // bandwidth stable while still tracking the latest finger target in real time.
        val delay = if (id == 11) 96L else 90L
        if (abs(delta) < 0.0005f) { running.remove(id); current[id] = t; return }
        val next = if (abs(delta) <= step) t else c + sign(delta) * step
        running += id
        val accepted = sender(id, next) { ok ->
            main.post {
                if (!ok) { running.remove(id); return@post }
                current[id] = next
                main.postDelayed({ drive(id) }, delay)
            }
        }
        if (!accepted) running.remove(id)
    }
}
