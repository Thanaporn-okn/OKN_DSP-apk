package com.okn.dsp.ble

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.BluetoothLeScanner
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import com.okn.dsp.logging.DspLogger
import com.okn.dsp.protocol.ByteCodec
import com.okn.dsp.protocol.PreAuthRandKeyDecoder
import com.okn.dsp.protocol.SessionCryptoFacts
import com.okn.dsp.protocol.SessionRxCipher
import com.okn.dsp.protocol.SessionTxCipher
import com.okn.dsp.queue.RealtimeCommandQueue
import com.okn.dsp.state.ConnectionState
import org.json.JSONObject
import java.io.ByteArrayOutputStream

@SuppressLint("MissingPermission")
class BleDspManager(
    private val context: Context,
    private val logger: DspLogger,
    private val listener: Listener,
) {
    interface Listener {
        fun onConnection(state: ConnectionState, message: String)
        fun onDeviceFound(device: BluetoothDevice, name: String, rssi: Int)
        fun onAuthInfo(typeId: Int, versionId: Int)
        fun onDeviceDescription(mode: DescriptorMode, json: JSONObject)
        fun onQueueIdle(idle: Boolean)
        fun onWriteSent(total: Long)
        fun onFatalError(message: String)
    }

    enum class DescriptorMode { INITIAL, REFRESH, SAVE_PRECHECK, SAVE_POSTCHECK }

    private val main = Handler(Looper.getMainLooper())
    private val manager = context.getSystemService(BluetoothManager::class.java)
    private val adapter: BluetoothAdapter? get() = manager?.adapter
    private var scanner: BluetoothLeScanner? = null
    private var gatt: BluetoothGatt? = null
    private var writeCh: BluetoothGattCharacteristic? = null
    private var notifyCh: BluetoothGattCharacteristic? = null
    private var notifyChSecondary: BluetoothGattCharacteristic? = null
    @Volatile private var connectionEpoch: Long = 0L
    private var stageWatchdog: Runnable? = null
    private var txCipher: SessionTxCipher? = null
    private var rxCipher: SessionRxCipher? = null
    private var waitingAuth = false
    private var descriptorMode: DescriptorMode? = null
    private var descriptorExpected = -1
    private val descriptorBytes = ByteArrayOutputStream()
    private var descriptorTimeout: Runnable? = null
    private var writeCount = 0L
    private var activeDevice: BluetoothDevice? = null

    private val startupProbe16 = ByteCodec.hexToBytes("631C062443FD3844558001F3EDA0CCF8")

    private val queue = RealtimeCommandQueue(
        minPacingMs = 90L,
        sender = { sendQueued(it) },
        onIdleChanged = { listener.onQueueIdle(it) },
        onWriteTimeout = { cmd -> main.post { failSession("GATT write callback timeout ${cmd.label}") } },
    )

    fun bluetoothEnabled(): Boolean = adapter?.isEnabled == true
    fun currentEpoch(): Long = connectionEpoch
    fun connectedDevice(): BluetoothDevice? = activeDevice
    fun isAuthenticated(): Boolean = txCipher != null && rxCipher != null && !waitingAuth
    fun isDescriptorBusy(): Boolean = descriptorMode != null
    fun queueDepth(): Int = queue.depth()
    fun queueIdle(): Boolean = queue.isIdle()

    fun startScan() {
        if (!bluetoothEnabled()) {
            listener.onConnection(ConnectionState.FAILED, "Bluetooth Off")
            return
        }
        stopScan()
        scanner = adapter?.bluetoothLeScanner
        listener.onConnection(ConnectionState.SCANNING, "Scanning")
        logger.log("SCAN", "start")
        try {
            scanner?.startScan(scanCallback)
            main.postDelayed({ stopScan(keepState = true) }, 10_000L)
        } catch (t: Throwable) {
            logger.log("ERROR", "scan start ${t.javaClass.simpleName}:${t.message}")
            listener.onConnection(ConnectionState.FAILED, "Scan Failed")
        }
    }

    fun stopScan(keepState: Boolean = false) {
        try { scanner?.stopScan(scanCallback) } catch (_: Throwable) {}
        scanner = null
        if (!keepState && gatt == null) listener.onConnection(ConnectionState.DISCONNECTED, "Disconnected")
    }

    fun connect(device: BluetoothDevice, reconnect: Boolean = false) {
        stopScan(keepState = true)
        disconnectInternal(notify = false)
        connectionEpoch += 1L
        activeDevice = device
        listener.onConnection(if (reconnect) ConnectionState.RECONNECTING else ConnectionState.CONNECTING, if (reconnect) "Reconnecting" else "Connecting")
        logger.log("CONNECT", "address=${device.address} reconnect=$reconnect epoch=$connectionEpoch")
        armStageWatchdog("connect")
        try {
            gatt = device.connectGatt(context, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
        } catch (t: Throwable) {
            failSession("connect ${t.javaClass.simpleName}:${t.message}")
        }
    }

    fun disconnect() {
        logger.log("DISCONNECT", "manual")
        disconnectInternal(notify = true)
    }

    fun refreshDescriptor(mode: DescriptorMode = DescriptorMode.REFRESH): Boolean {
        if (!isAuthenticated() || descriptorMode != null) return false
        descriptorMode = mode
        descriptorExpected = -1
        descriptorBytes.reset()
        queue.setRealtimePaused(true)
        listener.onConnection(ConnectionState.READING_DEVICE_DESCRIPTION, "Reading Device Description")
        armStageWatchdog("descriptor-${mode.name}")
        val plain = SessionCryptoFacts.DEVICE_DESCRIPTION_REQUEST.copyOf()
        val cmd = RealtimeCommandQueue.Command(
            key = "DESC:${mode.name}", plain = plain, label = "DESC_${mode.name}", epoch = connectionEpoch, critical = true, encrypt = true,
            onComplete = { ok ->
                if (!ok) failSession("descriptor write failed") else armDescriptorTimeout(mode)
            }
        )
        queue.enqueueCritical(cmd)
        logger.log("PARAMETER", "descriptor request mode=$mode")
        return true
    }

    fun sendRealtime(key: String, plain: ByteArray, label: String, onComplete: ((Boolean) -> Unit)? = null): Boolean {
        if (!isAuthenticated() || descriptorMode != null || gatt == null || writeCh == null) return false
        queue.enqueueLatest(RealtimeCommandQueue.Command(key, plain, label, epoch = connectionEpoch, critical = false, encrypt = true, onComplete = onComplete))
        return true
    }

    fun sendCritical(key: String, plain: ByteArray, label: String, onComplete: ((Boolean) -> Unit)? = null): Boolean {
        if (!isAuthenticated() || descriptorMode != null || gatt == null || writeCh == null) return false
        queue.enqueueCritical(RealtimeCommandQueue.Command(key, plain, label, epoch = connectionEpoch, critical = true, encrypt = true, onComplete = onComplete))
        return true
    }

    private fun startAuthenticatedSession() {
        if (gatt == null || writeCh == null || notifyCh == null) return
        waitingAuth = true
        txCipher = null
        rxCipher = null
        descriptorMode = null
        descriptorExpected = -1
        descriptorBytes.reset()
        queue.clear(reasonCallbackFailure = true)
        queue.setRealtimePaused(true)
        listener.onConnection(ConnectionState.AUTHENTICATING, "Authenticating")
        armStageWatchdog("authentication")
        logger.log("PARAMETER", "AUTH16 start len=${startupProbe16.size} epoch=$connectionEpoch")
        queue.enqueueCritical(
            RealtimeCommandQueue.Command(
                key = "AUTH16", plain = startupProbe16.copyOf(), label = "AUTH16", epoch = connectionEpoch,
                critical = true, encrypt = false,
                onComplete = { ok -> if (!ok) failSession("AUTH16 write failed") }
            )
        )
    }

    private fun sendQueued(command: RealtimeCommandQueue.Command): Boolean {
        if (command.epoch != connectionEpoch) {
            logger.log("ERROR", "stale command blocked label=${command.label} commandEpoch=${command.epoch} activeEpoch=$connectionEpoch")
            return false
        }
        val g = gatt ?: return false
        val ch = writeCh ?: return false
        val bytes = if (command.encrypt) {
            val tx = txCipher ?: return false
            try { tx.encryptNext(command.plain) } catch (t: Throwable) {
                failSession("encrypt ${t.javaClass.simpleName}:${t.message}")
                return false
            }
        } else command.plain
        logger.log("TX", "${command.label} uuid=${ch.uuid} len=${bytes.size} hex=${ByteCodec.run { bytes.toHex() }}", verboseOnly = true)
        val accepted = try {
            if (Build.VERSION.SDK_INT >= 33) {
                // V1: one encrypted packet -> one GATT write. Never duplicate this call.
                val status = g.writeCharacteristic(
                    ch,
                    bytes,
                    BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE,
                )
                status == BluetoothStatusCodes.SUCCESS
            } else {
                @Suppress("DEPRECATION") ch.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                @Suppress("DEPRECATION") ch.value = bytes
                @Suppress("DEPRECATION") g.writeCharacteristic(ch)
            }
        } catch (t: Throwable) {
            logger.log("ERROR", "write ${t.javaClass.simpleName}:${t.message}")
            false
        }
        if (!accepted) {
            // Cipher state has already advanced, therefore reconnect/reauth is mandatory.
            main.post { failSession("GATT write not accepted; cipher stream invalidated") }
            return false
        }
        writeCount += 1
        listener.onWriteSent(writeCount)
        return true
    }

    private fun handleNotify(value: ByteArray) {
        logger.log("NOTIFY", "uuid=${BleProfile.AB02_NOTIFY} len=${value.size} hex=${ByteCodec.run { value.toHex() }}", verboseOnly = true)
        if (waitingAuth) {
            if (value.size != 32) return
            try {
                val decoded = PreAuthRandKeyDecoder.decode(value)
                txCipher = SessionTxCipher(decoded.randKey)
                rxCipher = SessionRxCipher(decoded.randKey)
                waitingAuth = false
                listener.onAuthInfo(decoded.typeId, decoded.versionId)
                listener.onConnection(ConnectionState.ESTABLISHING_SESSION, "Establishing Session")
                logger.log("PARAMETER", "auth OK type=${decoded.typeId} version=${decoded.versionId} epoch=$connectionEpoch")
                refreshDescriptor(DescriptorMode.INITIAL)
            } catch (t: Throwable) {
                failSession("auth decode ${t.javaClass.simpleName}:${t.message}")
            }
            return
        }
        val rx = rxCipher ?: return
        val plain = try { rx.decryptNext(value) } catch (t: Throwable) {
            failSession("RX decrypt ${t.javaClass.simpleName}:${t.message}")
            return
        }
        logger.log("RX", "len=${plain.size} hex=${ByteCodec.run { plain.toHex() }}", verboseOnly = true)
        collectDescriptor(plain)
    }

    private fun collectDescriptor(plain: ByteArray) {
        val mode = descriptorMode ?: return
        if (descriptorExpected < 0) {
            if (plain.size < 4 || (plain[0].toInt() and 0xff) != 0x86) return
            descriptorExpected = (plain[1].toInt() and 0xff) or
                ((plain[2].toInt() and 0xff) shl 8) or
                ((plain[3].toInt() and 0xff) shl 16)
            descriptorBytes.reset()
            if (plain.size > 4) descriptorBytes.write(plain, 4, plain.size - 4)
            logger.log("RX", "descriptor header mode=$mode expected=$descriptorExpected")
        } else {
            if (plain.isEmpty() || (plain[0].toInt() and 0xff) != 0x82) return
            if (plain.size > 1) descriptorBytes.write(plain, 1, plain.size - 1)
        }
        if (descriptorExpected > 0 && descriptorBytes.size() >= descriptorExpected) {
            val raw = descriptorBytes.toByteArray().copyOf(descriptorExpected)
            val obj = try { JSONObject(raw.toString(Charsets.UTF_8)) } catch (t: Throwable) {
                failSession("descriptor JSON ${t.javaClass.simpleName}:${t.message}")
                return
            }
            cancelDescriptorTimeout()
            cancelStageWatchdog()
            descriptorMode = null
            descriptorExpected = -1
            descriptorBytes.reset()
            queue.setRealtimePaused(false)
            logger.log("RX", "descriptor complete mode=$mode bytes=${raw.size}")
            listener.onDeviceDescription(mode, obj)
        }
    }

    private fun armDescriptorTimeout(mode: DescriptorMode) {
        cancelDescriptorTimeout()
        descriptorTimeout = Runnable {
            if (descriptorMode == mode) failSession("descriptor timeout $mode")
        }.also { main.postDelayed(it, 15_000L) }
    }

    private fun cancelDescriptorTimeout() {
        descriptorTimeout?.let(main::removeCallbacks)
        descriptorTimeout = null
    }

    private fun subscribe(g: BluetoothGatt, ch: BluetoothGattCharacteristic, label: String) {
        try {
            g.setCharacteristicNotification(ch, true)
            val cccd = ch.getDescriptor(BleProfile.CCCD) ?: run { failSession("$label CCCD missing"); return }
            val value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            if (Build.VERSION.SDK_INT >= 33) g.writeDescriptor(cccd, value)
            else {
                @Suppress("DEPRECATION") cccd.value = value
                @Suppress("DEPRECATION") g.writeDescriptor(cccd)
            }
        } catch (t: Throwable) {
            failSession("$label notify setup ${t.javaClass.simpleName}:${t.message}")
        }
    }

    private fun armStageWatchdog(stage: String) {
        cancelStageWatchdog()
        val epoch = connectionEpoch
        stageWatchdog = Runnable {
            if (epoch == connectionEpoch && gatt != null) failSession("connection watchdog timeout stage=$stage epoch=$epoch")
        }.also { main.postDelayed(it, 15_000L) }
    }

    private fun cancelStageWatchdog() {
        stageWatchdog?.let(main::removeCallbacks)
        stageWatchdog = null
    }

    private fun failSession(message: String) {
        logger.log("ERROR", message)
        listener.onFatalError(message)
        listener.onConnection(ConnectionState.FAILED, "Connection Failed")
        disconnectInternal(notify = false)
    }

    private fun disconnectInternal(notify: Boolean) {
        cancelDescriptorTimeout()
        cancelStageWatchdog()
        connectionEpoch += 1L
        queue.clear(reasonCallbackFailure = true)
        queue.setRealtimePaused(true)
        waitingAuth = false
        descriptorMode = null
        txCipher = null
        rxCipher = null
        writeCh = null
        notifyCh = null
        notifyChSecondary = null
        val old = gatt
        gatt = null
        try { old?.disconnect() } catch (_: Throwable) {}
        try { old?.close() } catch (_: Throwable) {}
        if (notify) listener.onConnection(ConnectionState.DISCONNECTED, "Disconnected")
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val d = result.device
            val name = result.scanRecord?.deviceName ?: runCatching { d.name }.getOrNull() ?: return
            if (!name.contains("GOLOPINE", true) && !name.contains("DSP", true)) return
            logger.log("SCAN", "found name=$name address=${d.address} rssi=${result.rssi}")
            listener.onDeviceFound(d, name, result.rssi)
        }
        override fun onScanFailed(errorCode: Int) {
            logger.log("ERROR", "scan failed code=$errorCode")
            listener.onConnection(ConnectionState.FAILED, "Scan Failed ($errorCode)")
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (g !== gatt) return
            logger.log("CONNECT", "gatt state status=$status newState=$newState")
            if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                main.post {
                    disconnectInternal(notify = false)
                    listener.onConnection(ConnectionState.DISCONNECTED, "Disconnected")
                }
                return
            }
            if (status != BluetoothGatt.GATT_SUCCESS) { main.post { failSession("GATT status=$status") }; return }
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                listener.onConnection(ConnectionState.DISCOVERING, "Discovering Services")
                armStageWatchdog("service-discovery")
                try {
                    g.requestMtu(517)
                    main.postDelayed({ if (g === gatt) runCatching { g.discoverServices() }.onFailure { failSession("discover ${it.message}") } }, 220L)
                } catch (t: Throwable) { main.post { failSession("MTU/discover ${t.message}") } }
            }
        }

        override fun onMtuChanged(g: BluetoothGatt, mtu: Int, status: Int) {
            if (g === gatt) logger.log("SERVICE", "MTU=$mtu status=$status")
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            if (g !== gatt) return
            val svc = g.getService(BleProfile.AB00_SERVICE)
            writeCh = svc?.getCharacteristic(BleProfile.AB01_WRITE)
            notifyCh = svc?.getCharacteristic(BleProfile.AB02_NOTIFY)
            notifyChSecondary = svc?.getCharacteristic(BleProfile.AB03_NOTIFY)
            logger.log("SERVICE", "discover status=$status AB00=${svc != null} AB01=${writeCh != null} AB02=${notifyCh != null} AB03=${notifyChSecondary != null}")
            if (status != BluetoothGatt.GATT_SUCCESS || writeCh == null || notifyCh == null) {
                main.post { failSession("verified AB00/AB01/AB02 profile missing") }; return
            }
            listener.onConnection(ConnectionState.ENABLING_NOTIFICATIONS, "Enabling Notifications")
            armStageWatchdog("enable-notifications")
            subscribe(g, notifyCh!!, "AB02")
        }

        override fun onDescriptorWrite(g: BluetoothGatt, descriptor: BluetoothGattDescriptor, status: Int) {
            if (g !== gatt) return
            val owner = runCatching { descriptor.characteristic.uuid }.getOrNull()
            logger.log("CHARACTERISTIC", "CCCD status=$status owner=$owner uuid=${descriptor.uuid}")
            if (descriptor.uuid != BleProfile.CCCD) return
            if (status != BluetoothGatt.GATT_SUCCESS) { main.post { failSession("CCCD write status=$status owner=$owner") }; return }
            when (owner) {
                BleProfile.AB02_NOTIFY -> {
                    val secondary = notifyChSecondary
                    if (secondary != null) main.post { subscribe(g, secondary, "AB03") } else main.post { startAuthenticatedSession() }
                }
                BleProfile.AB03_NOTIFY -> main.post { startAuthenticatedSession() }
                else -> main.post { startAuthenticatedSession() }
            }
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, status: Int) {
            if (g !== gatt || characteristic.uuid != BleProfile.AB01_WRITE) return
            logger.log("TX", "callback status=$status uuid=${characteristic.uuid}")
            val ok = status == BluetoothGatt.GATT_SUCCESS
            queue.onGattResult(ok)
            if (!ok) main.post { failSession("GATT write callback status=$status") }
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            if (g !== gatt) return
            when (characteristic.uuid) {
                BleProfile.AB02_NOTIFY -> handleNotify(value)
                BleProfile.AB03_NOTIFY -> logger.log("NOTIFY", "AB03 secondary len=${value.size} hex=${ByteCodec.run { value.toHex() }}", verboseOnly = true)
            }
        }

        @Suppress("DEPRECATION")
        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            if (Build.VERSION.SDK_INT >= 33 || g !== gatt) return
            val value = characteristic.value ?: byteArrayOf()
            when (characteristic.uuid) {
                BleProfile.AB02_NOTIFY -> handleNotify(value)
                BleProfile.AB03_NOTIFY -> logger.log("NOTIFY", "AB03 secondary len=${value.size} hex=${ByteCodec.run { value.toHex() }}", verboseOnly = true)
            }
        }

        override fun onCharacteristicRead(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray, status: Int) {
            if (g === gatt) logger.log("RX", "READ uuid=${characteristic.uuid} status=$status len=${value.size}", verboseOnly = true)
        }
    }
}
