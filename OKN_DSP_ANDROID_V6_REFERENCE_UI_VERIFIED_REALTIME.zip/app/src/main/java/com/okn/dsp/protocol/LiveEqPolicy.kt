package com.okn.dsp.protocol

import kotlin.math.abs
import kotlin.math.round

/**
 * OKN_DSP V1 safe live-EQ boundary. The seven-channel actuator map is verified; only
 * standard PEAKING(type=12) records with the expected zero auxiliary fields are writable.
 * Every write serializes a complete 48-byte band record.
 */
object LiveEqPolicy {
    const val MIN_BOOST_DB = -12.0f
    const val MAX_BOOST_DB = 12.0f
    const val MIN_FREQUENCY_HZ = 20.0f
    const val MAX_FREQUENCY_HZ = 20000.0f
    const val MIN_Q = 0.05f
    const val MAX_Q = 20.0f
    const val STEP_DB = 0.1f
    const val FIELD_TOL = 0.0065f
    const val ZERO_TOL = 0.02f

    fun actuatorForChannel(channel1: Int): Int = ConfirmedDspMap.eqActuator(channel1 - 1)
    fun offsetForBand(band1: Int): Int = ConfirmedDspMap.eqBandOffset(band1)

    fun isWritable(b: EqBand48): Boolean =
        b.type == EqBandCodec.PEAKING_TYPE &&
            b.frequency in 20f..20000f &&
            b.q in 0.05f..20f &&
            abs(b.frequency2) <= ZERO_TOL &&
            abs(b.gain) <= ZERO_TOL &&
            abs(b.r) <= ZERO_TOL &&
            b.boostDb.isFinite()

    fun sanitizeBoost(v: Float): Float? {
        if (!v.isFinite() || v < MIN_BOOST_DB || v > MAX_BOOST_DB) return null
        return (round(v / STEP_DB) * STEP_DB).toFloat()
    }


    fun sanitizeFrequency(v: Float): Float? {
        if (!v.isFinite() || v < MIN_FREQUENCY_HZ || v > MAX_FREQUENCY_HZ) return null
        return v
    }

    fun sanitizeQ(v: Float): Float? {
        if (!v.isFinite() || v < MIN_Q || v > MAX_Q) return null
        return v
    }

    fun targetFromParameters(current: EqBand48, frequencyHz: Float, q: Float, requestedBoostDb: Float): EqBand48 {
        require(isWritable(current)) { "band not writable" }
        val f = sanitizeFrequency(frequencyHz) ?: error("frequency out of range")
        val qq = sanitizeQ(q) ?: error("Q out of range")
        val boost = sanitizeBoost(requestedBoostDb) ?: error("boost out of range")
        return EqBandCodec.peaking(frequencyHz = f.toDouble(), q = qq.toDouble(), boostDb = boost.toDouble())
    }

    fun targetFromCurrent(current: EqBand48, requestedBoostDb: Float): EqBand48 {
        require(isWritable(current)) { "band not writable" }
        val target = sanitizeBoost(requestedBoostDb) ?: error("boost out of range")
        return EqBandCodec.peaking(
            frequencyHz = current.frequency.toDouble(),
            q = current.q.toDouble(),
            boostDb = target.toDouble(),
        )
    }

    fun semanticMatches(actual: EqBand48, expected: EqBand48): Boolean =
        actual.type == expected.type &&
            abs(actual.frequency - expected.frequency) <= FIELD_TOL &&
            abs(actual.frequency2 - expected.frequency2) <= FIELD_TOL &&
            abs(actual.q - expected.q) <= FIELD_TOL &&
            abs(actual.boostDb - expected.boostDb) <= FIELD_TOL &&
            abs(actual.gain - expected.gain) <= FIELD_TOL &&
            abs(actual.r - expected.r) <= FIELD_TOL &&
            abs(actual.b0 - expected.b0) <= FIELD_TOL &&
            abs(actual.b1 - expected.b1) <= FIELD_TOL &&
            abs(actual.b2 - expected.b2) <= FIELD_TOL &&
            abs(actual.a1 - expected.a1) <= FIELD_TOL &&
            abs(actual.a2 - expected.a2) <= FIELD_TOL

    fun encodeWrite(channel1: Int, band1: Int, target: EqBand48): ByteArray =
        UfeCodec.encodeWrite(actuatorForChannel(channel1), offsetForBand(band1), EqBandCodec.encode(target))

    fun encodeRestore(channel1: Int, band1: Int, previous: EqBand48): ByteArray =
        UfeCodec.encodeWrite(actuatorForChannel(channel1), offsetForBand(band1), EqBandCodec.encode(previous))
}
