package com.okn.dsp.ui

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.roundToInt

object OknColors {
    val BG = Color.rgb(4, 15, 22)
    val BG2 = Color.rgb(5, 20, 29)
    val CARD = Color.rgb(8, 29, 40)
    val CARD2 = Color.rgb(9, 35, 48)
    val BORDER = Color.rgb(23, 59, 74)
    val BORDER_SOFT = Color.rgb(18, 48, 61)
    val CYAN = Color.rgb(19, 166, 255)
    val CYAN_BRIGHT = Color.rgb(27, 184, 255)
    val TRACK = Color.rgb(39, 67, 82)
    val TEXT = Color.rgb(242, 247, 250)
    val MUTED = Color.rgb(142, 165, 181)
    val GREEN = Color.rgb(39, 210, 105)
    val RED = Color.rgb(255, 91, 91)
    val WHITE = Color.WHITE
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()

fun rounded(color: Int, radius: Float, stroke: Int? = null, strokeWidth: Int = 1): GradientDrawable =
    GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        setColor(color)
        cornerRadius = radius
        if (stroke != null) setStroke(strokeWidth, stroke)
    }

fun Context.txt(
    value: String,
    size: Int = 14,
    color: Int = OknColors.TEXT,
    bold: Boolean = false,
    gravity: Int = Gravity.START or Gravity.CENTER_VERTICAL,
): TextView = TextView(this).apply {
    text = value
    textSize = size.toFloat()
    setTextColor(color)
    includeFontPadding = false
    this.gravity = gravity
    if (bold) setTypeface(typeface, Typeface.BOLD)
    // Do not route Android touch-click feedback into the connected audio path while tuning.
    isSoundEffectsEnabled = false
    isHapticFeedbackEnabled = false
}

fun Context.card(paddingH: Int = 12, paddingV: Int = 11): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    background = rounded(OknColors.CARD, dp(12).toFloat(), OknColors.BORDER, dp(1))
    setPadding(dp(paddingH), dp(paddingV), dp(paddingH), dp(paddingV))
}

fun Context.row(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.HORIZONTAL
    gravity = Gravity.CENTER_VERTICAL
}

fun Context.button(label: String, active: Boolean = false, onClick: () -> Unit): TextView =
    txt(label, 12, if (active) OknColors.WHITE else OknColors.TEXT, true, Gravity.CENTER).apply {
        background = rounded(
            if (active) OknColors.CYAN else OknColors.CARD2,
            dp(9).toFloat(),
            if (active) OknColors.CYAN_BRIGHT else OknColors.BORDER,
            dp(1)
        )
        setPadding(dp(10), dp(10), dp(10), dp(10))
        isClickable = true
        isFocusable = true
        setOnClickListener { onClick() }
    }

fun Context.seek(min: Float, max: Float, value: Float, onChange: (Float) -> Unit): SeekBar = SeekBar(this).apply {
    isSoundEffectsEnabled = false
    isHapticFeedbackEnabled = false
    this.max = 1000
    progressTintList = ColorStateList.valueOf(OknColors.CYAN)
    progressBackgroundTintList = ColorStateList.valueOf(OknColors.TRACK)
    thumbTintList = ColorStateList.valueOf(OknColors.WHITE)
    fun setValue(v: Float) {
        progress = (((v - min) / (max - min)).coerceIn(0f, 1f) * 1000f).roundToInt()
    }
    setValue(value)
    setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, p: Int, fromUser: Boolean) {
            if (!fromUser) return
            onChange(min + (max - min) * (p / 1000f))
        }
        override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
        override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
    })
    tag = Pair(min, max)
}

fun SeekBar.bindValue(v: Float) {
    val p = tag as? Pair<*, *> ?: return
    val min = p.first as? Float ?: return
    val max = p.second as? Float ?: return
    progress = (((v - min) / (max - min)).coerceIn(0f, 1f) * 1000f).roundToInt()
}

fun View.lp(width: Int = ViewGroup.LayoutParams.MATCH_PARENT, height: Int = ViewGroup.LayoutParams.WRAP_CONTENT): LinearLayout.LayoutParams =
    LinearLayout.LayoutParams(width, height)
