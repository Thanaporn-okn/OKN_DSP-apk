OKN_DSP V6 — REFERENCE-IMAGE UI + VERIFIED REAL DSP CORE
=========================================================

IDENTITY
- App: OKN_DSP
- package/applicationId: com.okn.dsp
- versionCode: 6
- versionName: 1.0.0-v6
- Android: minSdk 26 / targetSdk 35 / compileSdk 35
- JDK: 17
- Build: Android Gradle Plugin 8.7.3, Gradle 8.9 workflow

UI CONTRACT
- Home visual master is exactly the user-supplied 864x1536 image.
- EQ visual master is exactly the user-supplied 864x1536 image.
- The two 1536x864 presentation images are retained as evidence only.
- App renders the Home/EQ reference images without aspect-ratio distortion, then repaints
  only dynamic status/value/graph/channel regions needed for real operation.
- Portrait is locked because the supplied operational references are portrait.
- The old bottom-nav label on the EQ artwork is repainted to "EQ" to preserve the user's
  previously selected navigation wording; no other UI concept is substituted.

REAL HARDWARE SCOPE — VERIFIED AND ENABLED
- BLE service AB00
- AB01 write
- AB02 primary notify
- AB03 secondary notify path when present
- Scan -> tap device -> connect -> notifications -> auth -> session -> fresh Device
  Description -> Health Gate -> READY
- Scalar actuator allow-list only: 2,3,8,9,10,13,11
  * 2 Master Volume
  * 3 Remind Sound Volume (available from settings/menu; main image remains unchanged)
  * 8 Bass Volume
  * 9 Bass Cutoff
  * 10 Bass Boost
  * 13 Middle Boost
  * 11 Treble Boost
- Master Volume is bridged with Android STREAM_MUSIC / physical volume keys.
- EQ channel actuator IDs: CH1..CH7 = 4,5,6,14,15,16,17
- Device Description must contain 15 EQ records x 7 channels (105 total).
- Only descriptor-validated PEAKING type=12 records can be written.
- EQ write is the complete verified 48-byte record wrapped in the proven UFE write.
- Graph drag adjusts Frequency + Gain. Horizontal drag on card value rows adjusts
  Frequency / Gain / Q while staying within verified PEAKING policy.
- Local preset save/load contains only verified scalar values and writable PEAKING EQ.
- "Save to DSP" uses the exact manual-only SaveParams ID7 path with fresh pre/post gate.

REALTIME / AUDIO-SAFETY BEHAVIOR
- UI state changes immediately; BLE follows the latest target.
- One GATT write in flight.
- Realtime commands coalesce by parameter key: latest target wins.
- Global write pacing: 90 ms baseline.
- TrebleBoost ID11: callback-gated <=0.5 dB steps, 96 ms spacing.
- EQ: callback-gated gain <=0.5 dB/step, log-frequency/Q smoothing, 110 ms spacing.
- GATT callback timeout: 2.5 s, fail closed.
- Connection epoch blocks stale queued commands after reconnect.
- Local verified state persists and can replay only after a fresh Health Gate.
- Master/phone-volume synchronization steps are paced to reduce abrupt audio changes.

FAIL-CLOSED / NOT GUESSED
- Hardware Crossover writes: LOCKED
- Hardware Delay writes: LOCKED
- Hardware Preset recall/write packet: LOCKED (app-local presets are enabled)
- Per-channel Output/Mute/Phase/routing hardware writes: LOCKED
- Non-PEAKING EQ writes: LOCKED
- Generic/unknown actuator writes: LOCKED
- No AA55 placeholder/fake protocol is used.

REFERENCE-UI INTERACTION MAP
HOME
- Bluetooth/manage connection: scan/connect/disconnect flow.
- Master/Bass/Cutoff/BassBoost/MiddleBoost/TrebleBoost sliders: verified realtime writes.
- Master speaker icon: verified Master Volume mute/unmute using -70 dB and remembered level.
- Flat: zero current channel writable EQ + verified tone-boost controls.
- Pop/Rock/Jazz: intentionally do not invent preset values; app explains that a user preset
  must be saved first.
- Save/Load preset: app-local verified state only.
- Bottom Home / EQ / More: navigation/menu.

EQ
- Scan / disconnect: real BLE session actions.
- EQ graph: real selected-channel PEAKING EQ Frequency/Gain drag.
- Six visible cards are selected from real writable descriptor records nearest the six
  reference frequencies; no fake band record is created. Drag F/Gain/Q rows horizontally.
- CH1..CH7 labels: FL, FR, RL, RR, CEN, SUB, AUX.
- Reset: flat current channel writable PEAKING bands.
- Load from device: fresh verified descriptor refresh.
- Save to device: manual guarded SaveParams only.
- Save preset: local preset.
- Delay/Crossover/Output/Mute/Phase remain visible exactly because they are in the supplied
  UI, but taps are blocked from hardware writes until packet evidence exists.

BUILD STATUS
- Source preflight: run preflight_v6.py
- Protocol JVM smoke: tools/ProtocolJvmSmoke.kt
- GitHub Actions is the authoritative Android APK compile/sign path for this delivery.
- Real target-DSP acoustic/no-stutter qualification is still required after installing the APK.
