#!/usr/bin/env python3
from pathlib import Path
import hashlib, re, struct, xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
HOME_HASH = '92ba628fb0db0c4124f1a53152d5cdb180406e02fe557ca02606d7e950d0764d'
EQ_HASH = '16b233e40121b4950ed75bf5267143c5f025f9bbcbc271d2730ec8003fb09bf1'
EQ_PRESENTATION_HASH = 'f47ff16676dd1654473e798a59ebf11d30f299a314a6872afcf04aa4469cb289'
HOME_PRESENTATION_HASH = '18232362ff4cf56b25358d046cfa96d3fca4d312bdf3cbeafca868267a5af295'
KEYSTORE_HASH = 'ba1c52f2607c09953c52fdd79c5f72026aaf0adb8aa44bcba277f7d9b49d9511'


def die(msg):
    print('ERROR:', msg)
    raise SystemExit(1)


def ok(msg):
    print('OK:', msg)


def text(rel):
    p = ROOT / rel
    if not p.is_file():
        die(f'missing {rel}')
    return p.read_text(encoding='utf-8')


def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def must(s, marker, where):
    if marker not in s:
        die(f'missing marker {marker!r} in {where}')


def jpeg_size(path):
    data = Path(path).read_bytes()
    if len(data) < 4 or data[:2] != b"\xff\xd8":
        die(f"not JPEG: {path}")
    i = 2
    while i + 9 < len(data):
        if data[i] != 0xFF:
            i += 1
            continue
        while i < len(data) and data[i] == 0xFF:
            i += 1
        if i >= len(data):
            break
        marker = data[i]
        i += 1
        if marker in (0xD8, 0xD9):
            continue
        if i + 2 > len(data):
            break
        seglen = int.from_bytes(data[i:i+2], "big")
        if seglen < 2 or i + seglen > len(data):
            break
        if marker in (0xC0,0xC1,0xC2,0xC3,0xC5,0xC6,0xC7,0xC9,0xCA,0xCB,0xCD,0xCE,0xCF):
            if seglen < 7:
                break
            h = int.from_bytes(data[i+3:i+5], "big")
            w = int.from_bytes(data[i+5:i+7], "big")
            return w, h
        i += seglen
    die(f"JPEG dimensions not found: {path}")


required = [
    'README_V6.txt', 'settings.gradle.kts', 'build.gradle.kts', 'app/build.gradle.kts',
    'app/src/main/AndroidManifest.xml', 'app/okn_dsp_stable_debug.keystore',
    'app/src/main/java/com/okn/dsp/MainActivity.kt',
    'app/src/main/java/com/okn/dsp/OknDspApplication.kt',
    'app/src/main/java/com/okn/dsp/core/DspRuntime.kt',
    'app/src/main/java/com/okn/dsp/state/DspModels.kt',
    'app/src/main/java/com/okn/dsp/state/DspStateStore.kt',
    'app/src/main/java/com/okn/dsp/ble/BleDspManager.kt',
    'app/src/main/java/com/okn/dsp/ble/BleProfile.kt',
    'app/src/main/java/com/okn/dsp/repository/DspRepository.kt',
    'app/src/main/java/com/okn/dsp/persistence/DspPreferences.kt',
    'app/src/main/java/com/okn/dsp/preset/AppPresetStore.kt',
    'app/src/main/java/com/okn/dsp/queue/RealtimeCommandQueue.kt',
    'app/src/main/java/com/okn/dsp/smoothing/ScalarRampController.kt',
    'app/src/main/java/com/okn/dsp/smoothing/EqSlewController.kt',
    'app/src/main/java/com/okn/dsp/smoothing/PhoneVolumeBridge.kt',
    'app/src/main/java/com/okn/dsp/ui/ReferenceDspUi.kt',
    'app/src/main/java/com/okn/dsp/ui/ReferenceImageDspView.kt',
    'app/src/main/java/com/okn/dsp/protocol/ConfirmedDspMap.kt',
    'app/src/main/java/com/okn/dsp/protocol/VerifiedScalarControls.kt',
    'app/src/main/java/com/okn/dsp/protocol/LiveEqPolicy.kt',
    'app/src/main/java/com/okn/dsp/protocol/WriteGate.kt',
    'app/src/main/java/com/okn/dsp/protocol/SaveParamsPolicy.kt',
    'app/src/main/res/drawable-nodpi/ui_home_reference.jpg',
    'app/src/main/res/drawable-nodpi/ui_eq_reference.jpg',
    'evidence/OKN_DSP_V6_UI_HOME_REFERENCE.jpg',
    'evidence/OKN_DSP_V6_UI_EQ_REFERENCE.jpg',
    'evidence/OKN_DSP_V6_UI_EQ_PRESENTATION_REFERENCE.jpg',
    'evidence/OKN_DSP_V6_UI_HOME_PRESENTATION_REFERENCE.jpg',
    'evidence/OKN_DSP_V6_VERIFIED_HARDWARE_BOUNDARY.txt',
    'evidence/OKN_DSP_V6_UI_REFERENCE_SHA256.txt',
    'tools/ProtocolJvmSmoke.kt',
]
for f in required:
    if not (ROOT / f).is_file():
        die(f'missing {f}')
ok(f'{len(required)} required files exist')

settings = text('settings.gradle.kts')
must(settings, 'rootProject.name = "OKN_DSP_ANDROID_V6"', 'settings.gradle.kts')
gradle = text('app/build.gradle.kts')
for m in [
    'applicationId = "com.okn.dsp"', 'versionCode = 6', 'versionName = "1.0.0-v6"',
    'compileSdk = 35', 'targetSdk = 35', 'minSdk = 26', 'jvmToolchain(17)',
    'signingConfig = signingConfigs.getByName("stableDebug")'
]:
    must(gradle, m, 'app/build.gradle.kts')
ok('V6 identity / SDK / stable signing configuration')

manifest_path = ROOT / 'app/src/main/AndroidManifest.xml'
try:
    ET.parse(manifest_path)
except Exception as e:
    die(f'AndroidManifest invalid: {e}')
manifest = manifest_path.read_text(encoding='utf-8')
for m in [
    'android:name=".OknDspApplication"', 'android:screenOrientation="portrait"',
    'android:configChanges="orientation|screenSize|smallestScreenSize|keyboardHidden"',
    'android:label="OKN_DSP"', 'android.permission.BLUETOOTH_SCAN', 'android.permission.BLUETOOTH_CONNECT'
]:
    must(manifest, m, 'AndroidManifest.xml')
ok('portrait reference UI + process-scoped application + BLE permissions')

# Exact user-supplied UI bytes are mandatory.
for rel, expected, dims in [
    ('evidence/OKN_DSP_V6_UI_HOME_REFERENCE.jpg', HOME_HASH, (864, 1536)),
    ('evidence/OKN_DSP_V6_UI_EQ_REFERENCE.jpg', EQ_HASH, (864, 1536)),
    ('evidence/OKN_DSP_V6_UI_EQ_PRESENTATION_REFERENCE.jpg', EQ_PRESENTATION_HASH, (1536, 864)),
    ('evidence/OKN_DSP_V6_UI_HOME_PRESENTATION_REFERENCE.jpg', HOME_PRESENTATION_HASH, (1536, 864)),
    ('app/src/main/res/drawable-nodpi/ui_home_reference.jpg', HOME_HASH, (864, 1536)),
    ('app/src/main/res/drawable-nodpi/ui_eq_reference.jpg', EQ_HASH, (864, 1536)),
]:
    p = ROOT / rel
    if sha(p) != expected:
        die(f'UI reference hash mismatch: {rel}')
    if jpeg_size(p) != dims:
        die(f'UI reference dimensions changed: {rel} got={jpeg_size(p)} expected={dims}')
if sha(ROOT / 'app/okn_dsp_stable_debug.keystore') != KEYSTORE_HASH:
    die('stable debug keystore hash changed')
ok('exact Home/EQ UI references + presentation evidence + stable keystore')

profile = text('app/src/main/java/com/okn/dsp/ble/BleProfile.kt')
for m in [
    '0000ab00-0000-1000-8000-00805f9b34fb',
    '0000ab01-0000-1000-8000-00805f9b34fb',
    '0000ab02-0000-1000-8000-00805f9b34fb',
    '0000ab03-0000-1000-8000-00805f9b34fb',
]:
    must(profile, m, 'BleProfile.kt')
ble = text('app/src/main/java/com/okn/dsp/ble/BleDspManager.kt')
for m in [
    '631C062443FD3844558001F3EDA0CCF8',
    'ConnectionState.ENABLING_NOTIFICATIONS', 'ConnectionState.AUTHENTICATING',
    'ConnectionState.ESTABLISHING_SESSION', 'ConnectionState.READING_DEVICE_DESCRIPTION',
    'notifyChSecondary', 'subscribe(g, secondary, "AB03")',
    'command.epoch != connectionEpoch', 'main.postDelayed(it, 15_000L)',
    'refreshDescriptor(DescriptorMode.INITIAL)',
]:
    must(ble, m, 'BleDspManager.kt')
ok('AB00/01/02/03 transport + auth/session + epoch + watchdog preserved')

confirmed = text('app/src/main/java/com/okn/dsp/protocol/ConfirmedDspMap.kt')
for m in [
    'MASTER_VOLUME = 2', 'REMIND_SOUND_VOLUME = 3', 'BASS_VOLUME = 8', 'BASS_CUTOFF = 9',
    'BASS_BOOST = 10', 'TREBLE_BOOST = 11', 'MIDDLE_BOOST = 13', 'SAVE_PARAMS = 7',
    'intArrayOf(4, 5, 6, 14, 15, 16, 17)', 'EQ_BAND_COUNT = 15', 'EQ_BAND_BYTES = 48',
]:
    must(confirmed, m, 'ConfirmedDspMap.kt')
scalar = text('app/src/main/java/com/okn/dsp/protocol/VerifiedScalarControls.kt')
ids = [int(x) for x in re.findall(r'VerifiedScalarControl\((\d+),', scalar)]
if ids != [2, 3, 8, 9, 10, 13, 11]:
    die(f'scalar allow-list changed: {ids}')
for m in [
    'VerifiedScalarControl(2, "MasterVolume", -70f, 6f',
    'VerifiedScalarControl(8, "BassVolume", -70f, 6f',
    'VerifiedScalarControl(9, "BassCutoff", 20f, 250f',
    'VerifiedScalarControl(11, "TrebleBoost", -12f, 12f',
]:
    must(scalar, m, 'VerifiedScalarControls.kt')
policy = text('app/src/main/java/com/okn/dsp/protocol/LiveEqPolicy.kt')
for m in ['b.type == EqBandCodec.PEAKING_TYPE', 'MIN_FREQUENCY_HZ = 20.0f', 'MAX_FREQUENCY_HZ = 20000.0f', 'MIN_BOOST_DB = -12.0f', 'MAX_BOOST_DB = 12.0f', 'MIN_Q = 0.05f', 'MAX_Q = 20.0f']:
    must(policy, m, 'LiveEqPolicy.kt')
ok('verified scalar map + 7-channel 15x48 PEAKING EQ boundary')

queue = text('app/src/main/java/com/okn/dsp/queue/RealtimeCommandQueue.kt')
for m in [
    'private val minPacingMs: Long = 90L', 'private var inflight: Command? = null',
    'realtime[command.key] = command', 'private val writeTimeoutMs = 2500L', 'val epoch: Long',
]:
    must(queue, m, 'RealtimeCommandQueue.kt')
ramp = text('app/src/main/java/com/okn/dsp/smoothing/ScalarRampController.kt')
for m in ['id == 11 -> 0.5f', 'if (id == 11) 96L else 90L', 'target[id] = v']:
    must(ramp, m, 'ScalarRampController.kt')
eq_slew = text('app/src/main/java/com/okn/dsp/smoothing/EqSlewController.kt')
for m in ['moveLinear(c.boostDb, t.boostDb, 0.5f)', 'main.postDelayed({ drive(k) }, 110L)']:
    must(eq_slew, m, 'EqSlewController.kt')
prefs = text('app/src/main/java/com/okn/dsp/persistence/DspPreferences.kt')
for m in ['debounceMs: Long = 60L', 'never emits SaveParams or any BLE command']:
    must(prefs, m, 'DspPreferences.kt')
ok('latest-target one-inflight queue + callback-gated scalar/EQ slew + local persistence')

repo = text('app/src/main/java/com/okn/dsp/repository/DspRepository.kt')
for m in [
    'VerifiedScalarControls.sanitize(id, requested) ?: return',
    'if (!LiveEqPolicy.isWritable(current)) return',
    'if (!store.value().healthGatePass) return',
    'if (store.value().healthGatePass) eqSlew.setTarget',
    'parsed.scalars.size == 7', 'eqCount == 105', 'restoreLocalAfterHealthGate(parsed)',
    'fun saveParamsManual(): Boolean', 'SAVE_PRECHECK', 'SAVE_POSTCHECK', 'scheduleReconnect()',
]:
    must(repo, m, 'DspRepository.kt')
ok('repository health gate + 105-record read + safe replay/reconnect + manual SaveParams')

ui_shell = text('app/src/main/java/com/okn/dsp/ui/ReferenceDspUi.kt')
for m in [
    'ReferenceImageDspView', 'fun scalarChanged(id: Int, value: Float)',
    'fun eqChanged(channel: Int, band: Int, frequency: Float, q: Float, gain: Float)',
]:
    must(ui_shell, m, 'ReferenceDspUi.kt')
ui = text('app/src/main/java/com/okn/dsp/ui/ReferenceImageDspView.kt')
for m in [
    'R.drawable.ui_home_reference', 'R.drawable.ui_eq_reference',
    'HOME_IDS = intArrayOf(2, 8, 9, 10, 13, 11)',
    'actions.toggleMasterMute()', 'actions.scalarChanged(HOME_IDS[slot], value)',
    'visibleBands()', 'LiveEqPolicy.isWritable', 'updateEqFromGraph', 'updateEqFromCard',
    'actions.eqChanged(ch, band1, f, q, g)', 'CH_SHORT = arrayOf("FL", "FR", "RL", "RR", "CEN", "SUB", "AUX")',
    'toastLocked("Delay")', 'toastLocked("Crossover")',
    'Output / Mute / Phase', 'actions.refresh()', 'actions.saveParams()', 'text(c, "EQ"',
]:
    must(ui, m, 'ReferenceImageDspView.kt')
main = text('app/src/main/java/com/okn/dsp/MainActivity.kt')
for m in [
    'showRemindSoundVolume()', 'runtime.dsp.setScalar(3,db,"remind-volume-dialog")',
    'runtime.dsp.setScalar(2,phoneVolume.masterDbFromPhone(),"phone-volume-key")',
    'runtime.dsp.saveParamsManual()', 'applyImmersive()', 'OKN_DSP v1.0.0 • build V6',
]:
    must(main, m, 'MainActivity.kt')
ok('supplied Home/EQ visual shell is wired to verified realtime actions')

gate = text('app/src/main/java/com/okn/dsp/protocol/WriteGate.kt')
for m in [
    'const val enabled: Boolean = false',
    'const val presetHardwareWritesEnabled: Boolean = false',
    'const val crossoverWritesEnabled: Boolean = false',
    'const val delayWritesEnabled: Boolean = false',
    'const val unknownOutputWritesEnabled: Boolean = false',
]:
    must(gate, m, 'WriteGate.kt')
all_kt = '\n'.join(p.read_text(errors='ignore') for p in (ROOT / 'app/src/main/java').rglob('*.kt'))
if '0xAA, 0x55' in all_kt or 'AA 55' in all_kt:
    die('conceptual AA55 packet leaked into production source')
if re.search(r'fun\s+(setDelay|writeDelay|setCrossover|writeCrossover|setOutput|writeOutput)\s*\(', all_kt):
    die('unverified hardware write API surfaced')
ok('generic/preset/delay/crossover/output unknown write surfaces remain fail-closed')

# Local preset layer may store/apply only already-verified values.
preset = text('app/src/main/java/com/okn/dsp/preset/AppPresetStore.kt')
for m in ['VerifiedScalarControls.controls.forEach', 'if (!LiveEqPolicy.isWritable(b)) continue', 'App-local presets. Never emits a DSP packet by itself.']:
    must(preset, m, 'AppPresetStore.kt')
ok('local preset store remains protocol-safe')

print('PREFLIGHT_V6_PASS')
