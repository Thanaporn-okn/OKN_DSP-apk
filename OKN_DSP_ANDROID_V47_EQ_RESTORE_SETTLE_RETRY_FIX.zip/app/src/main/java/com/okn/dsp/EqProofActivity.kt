package com.okn.dsp

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.ContentValues
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.widget.*
import androidx.core.app.ActivityCompat
import com.okn.dsp.protocol.*
import com.okn.dsp.transport.BleProfile
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * V47 controlled CH1 Band4 EQ write proof.
 * Baseline comes from the live Device Description. Only actuator ID4 / Band4 /
 * offset144 is writable. Target lowers PEAKING boost by 0.5 dB, descriptor is
 * refreshed and verified, then the baseline band parameters are re-encoded to a 48-byte record, restored
 * after a device-settle delay, and verified. One timed retry is allowed if the first restore is not reflected. SaveParams ID7 is never sent.
 */
class EqProofActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private val ts = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    private val startupProbe16 = ByteCodec.hexToBytes("631C062443FD3844558001F3EDA0CCF8")

    private lateinit var status: TextView
    private lateinit var logView: TextView
    private lateinit var deviceList: LinearLayout
    private lateinit var startSessionButton: Button
    private lateinit var runProofButton: Button
    private lateinit var baselineView: TextView

    private var scanner: android.bluetooth.le.BluetoothLeScanner? = null
    private val found = LinkedHashMap<String, BluetoothDevice>()
    private var gatt: BluetoothGatt? = null
    private var ab01: BluetoothGattCharacteristic? = null
    private var ab02: BluetoothGattCharacteristic? = null
    private var connectedName: String? = null

    private var waitingAuth = false
    private var sessionReady = false
    private var txCipher: SessionTxCipher? = null
    private var rxCipher: SessionRxCipher? = null

    private enum class DescMode { INITIAL, VERIFY_TARGET, VERIFY_RESTORE }
    private var descMode: DescMode? = null
    private var descExpected = -1
    private val descBytes = ByteArrayOutputStream()

    private var baselineBand: EqBand48? = null
    private var targetBand: EqBand48? = null
    private var proofRunning = false
    private var targetWasWritten = false
    private var proofTimeout: Runnable? = null
    private var restoreAttempt = 0
    private val restoreSettleBeforeWriteMs = 1500L
    private val restoreVerifyDelayMs = 1500L
    private val restoreRetryDelayMs = 2000L

    private val captureLines = mutableListOf<String>()
    private var packetNo = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestBlePermissions()
        record("META", "V47_EQ_PROOF_ACTIVITY_START")
    }

    override fun onDestroy() {
        proofTimeout?.let { handler.removeCallbacks(it) }
        try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
        try { gatt?.close() } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 22, 22, 28)
        }
        root.addView(TextView(this).apply {
            text = "OKN DSP V47 — CONTROLLED EQ BAND WRITE PROOF"
            textSize = 22f
        })
        status = TextView(this).apply {
            text = "DISCONNECTED • SaveParams + normal EQ writes LOCKED"
            textSize = 14f
            setPadding(0, 8, 0, 10)
        }
        root.addView(status)
        root.addView(TextView(this).apply {
            text = "Proof scope ONLY: CH1 actuator ID4 • Band4 • offset144 • 48 bytes. Baseline is read live; PEAKING boost is lowered by 0.5 dB, verified by Device Description, then the baseline band parameters are re-encoded, restored after a settle delay, and verified. SaveParams ID7 is never sent."
            textSize = 13f
        })

        root.addView(Button(this).apply {
            text = "SCAN DSP"
            setOnClickListener { startScan() }
        })
        deviceList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(deviceList)

        startSessionButton = Button(this).apply {
            text = "START V47 EQ PROOF SESSION"
            isEnabled = false
            setOnClickListener { confirmStartSession() }
        }
        root.addView(startSessionButton)

        baselineView = TextView(this).apply {
            text = "Baseline: not loaded"
            textSize = 14f
            setPadding(0, 10, 0, 10)
        }
        root.addView(baselineView)

        runProofButton = Button(this).apply {
            text = "RUN CONTROLLED CH1 BAND4 PROOF (-0.5 dB → RESTORE)"
            isEnabled = false
            setOnClickListener { confirmRunProof() }
        }
        root.addView(runProofButton)

        root.addView(Button(this).apply {
            text = "SAVE V47 CAPTURE TO DOWNLOADS"
            setOnClickListener { saveCapture() }
        })

        logView = TextView(this).apply { textSize = 11f; setPadding(0, 12, 0, 0) }
        root.addView(logView)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun confirmStartSession() {
        if (gatt == null || ab01 == null || ab02 == null) {
            Toast.makeText(this, "เชื่อม AB00/AB01/AB02 ก่อน", Toast.LENGTH_LONG).show(); return
        }
        AlertDialog.Builder(this)
            .setTitle("Start V47 EQ proof session")
            .setMessage("จะทำ AUTH16 → derive RandKey → อ่าน Device Description สด → ตรวจ CH1 ID4 Band4 ก่อนอนุญาต proof\n\nยังไม่เขียน EQ ในขั้นนี้")
            .setNegativeButton("ยกเลิก", null)
            .setPositiveButton("START READ-ONLY BASELINE") { _, _ -> startSession() }
            .show()
    }

    private fun startSession() {
        val g = gatt ?: return
        val w = ab01 ?: return
        waitingAuth = true
        sessionReady = false
        txCipher = null
        rxCipher = null
        descMode = null
        descExpected = -1
        descBytes.reset()
        baselineBand = null
        targetBand = null
        proofRunning = false
        targetWasWritten = false
        restoreAttempt = 0
        runProofButton.isEnabled = false
        baselineView.text = "Baseline: loading..."
        record("META", "V47_EQ_PROOF_SESSION_START")
        if (!writeNoResponse(g, w, startupProbe16, "TX_AUTH16_V47")) {
            waitingAuth = false
            status.text = "AUTH16 queue failed"
        } else status.text = "AUTH16 sent • waiting 32B auth response"
    }

    private fun confirmRunProof() {
        val original = baselineBand ?: return
        val reason = ControlledEqBandProof.validateBaseline(original)
        if (reason != null) {
            Toast.makeText(this, "Proof blocked: $reason", Toast.LENGTH_LONG).show(); return
        }
        val target = ControlledEqBandProof.targetFrom(original)
        AlertDialog.Builder(this)
            .setTitle("V47 controlled EQ proof")
            .setMessage(
                "CH1 • Actuator ID4 • Band4 • offset144\n" +
                    "F=${fmt(original.frequency)}Hz Q=${fmt(original.q)}\n" +
                    "Boost ${fmt(original.boostDb)} → ${fmt(target.boostDb)} dB\n\n" +
                    "จะ WRITE 0x57 48-byte band → verify descriptor → restore baseline 48-byte record after settle delay → verify restore\n" +
                    "SaveParams ID7 จะไม่ถูกส่ง"
            )
            .setNegativeButton("ยกเลิก", null)
            .setPositiveButton("RUN PROOF") { _, _ -> runProof(original, target) }
            .show()
    }

    private fun runProof(original: EqBand48, target: EqBand48) {
        if (!sessionReady || proofRunning || descMode != null) {
            Toast.makeText(this, "Session ไม่พร้อมหรือ proof กำลังทำงาน", Toast.LENGTH_LONG).show(); return
        }
        if (!WriteGate.controlledEqBandProofEnabled) {
            Toast.makeText(this, "V47 EQ proof gate disabled", Toast.LENGTH_LONG).show(); return
        }
        val g = gatt ?: return
        val w = ab01 ?: return
        val tx = txCipher ?: return

        baselineBand = original
        targetBand = target
        proofRunning = true
        targetWasWritten = true
        restoreAttempt = 0
        runProofButton.isEnabled = false
        armGlobalFailsafe()

        val plain = ControlledEqBandProof.encodeWrite(target)
        val enc = tx.encryptNext(plain)
        record("META", "V47_EQ_TARGET_WRITE_PLAIN=${ByteCodec.run { plain.toHex() }} actuator=4 band=4 offset=144 originalBoost=${original.boostDb} targetBoost=${target.boostDb} saveParams=false")
        if (!writeNoResponse(g, w, enc, "TX_EQ_CH1_BAND4_MINUS0P5DB_V47")) {
            proofRunning = false
            targetWasWritten = false
            cancelGlobalFailsafe()
            status.text = "Target write queue failed"
            return
        }
        status.text = "EQ target sent • verifying live descriptor"
        handler.postDelayed({ requestDescriptor(DescMode.VERIFY_TARGET) }, 500L)
    }

    private fun requestDescriptor(mode: DescMode) {
        val g = gatt ?: return
        val w = ab01 ?: return
        val tx = txCipher ?: return
        descMode = mode
        descExpected = -1
        descBytes.reset()
        val plain = SessionCryptoFacts.DEVICE_DESCRIPTION_REQUEST
        val enc = tx.encryptNext(plain)
        record("META", "V47_DESC_REQUEST mode=$mode plain=${ByteCodec.run { plain.toHex() }}")
        if (!writeNoResponse(g, w, enc, "TX_DESC_V47_${mode.name}")) {
            if (mode == DescMode.VERIFY_TARGET) restoreOriginal("descriptor-request-failed")
            else finishFailed("restore-descriptor-request-failed")
        }
    }

    private fun handleAb02(value: ByteArray) {
        record("RX_NOTIFY", "len=${value.size} hex=${ByteCodec.run { value.toHex() }}")
        if (waitingAuth) {
            if (value.size != 32) return
            try {
                val d = PreAuthRandKeyDecoder.decode(value)
                txCipher = SessionTxCipher(d.randKey)
                rxCipher = SessionRxCipher(d.randKey)
                waitingAuth = false
                record("META", "V47_RANDKEY_DERIVED type=${d.typeId} ver=${d.versionId} rand=${ByteCodec.run { d.randKey.toHex() }}")
                requestDescriptor(DescMode.INITIAL)
            } catch (e: Exception) {
                waitingAuth = false
                record("META", "V47_AUTH_DECODE_ERROR ${e.javaClass.simpleName}:${e.message}")
                status.text = "Auth decode failed"
            }
            return
        }

        val rx = rxCipher ?: return
        val plain = try { rx.decryptNext(value) } catch (e: Exception) {
            record("META", "V47_RX_DECRYPT_ERROR ${e.javaClass.simpleName}:${e.message}")
            sessionReady = false
            return
        }
        record("RX_PLAIN", "len=${plain.size} hex=${ByteCodec.run { plain.toHex() }}")
        if (descMode != null) collectDescriptor(plain)
    }

    private fun collectDescriptor(plain: ByteArray) {
        val mode = descMode ?: return
        if (descExpected < 0) {
            if (plain.size < 4 || (plain[0].toInt() and 0xff) != 0x86) {
                record("META", "V47_DESC_NONHEADER mode=$mode marker=${plain.firstOrNull()?.toInt()?.and(0xff)} len=${plain.size}")
                return
            }
            descExpected = (plain[1].toInt() and 0xff) or
                ((plain[2].toInt() and 0xff) shl 8) or
                ((plain[3].toInt() and 0xff) shl 16)
            descBytes.reset()
            descBytes.write(plain, 4, plain.size - 4)
            record("META", "V47_DESC_HEADER mode=$mode jsonLen=$descExpected")
        } else {
            if (plain.isEmpty() || (plain[0].toInt() and 0xff) != 0x82) {
                record("META", "V47_DESC_NONCONT mode=$mode marker=${plain.firstOrNull()?.toInt()?.and(0xff)} len=${plain.size}")
                return
            }
            descBytes.write(plain, 1, plain.size - 1)
        }
        if (descExpected > 0 && descBytes.size() >= descExpected) {
            val bytes = descBytes.toByteArray().copyOf(descExpected)
            val obj = JSONObject(bytes.toString(Charsets.UTF_8))
            record("META", "V47_DESC_COMPLETE mode=$mode bytes=${bytes.size}")
            descMode = null
            descExpected = -1
            descBytes.reset()
            onDescriptorComplete(mode, obj)
        }
    }

    private fun onDescriptorComplete(mode: DescMode, obj: JSONObject) {
        val band = extractBand(obj, ControlledEqBandProof.ACTUATOR_ID, ControlledEqBandProof.BAND_INDEX_1)
        when (mode) {
            DescMode.INITIAL -> {
                if (band == null) {
                    sessionReady = false
                    status.text = "CH1 ID4 Band4 missing in live descriptor"
                    record("META", "V47_BASELINE_ABORT reason=band-missing")
                    return
                }
                val reason = ControlledEqBandProof.validateBaseline(band)
                if (reason != null) {
                    sessionReady = false
                    baselineBand = band
                    baselineView.text = "Baseline blocked: $reason"
                    status.text = "Baseline not safe for controlled proof"
                    record("META", "V47_BASELINE_ABORT reason=$reason")
                    return
                }
                baselineBand = band
                sessionReady = true
                val target = ControlledEqBandProof.targetFrom(band)
                baselineView.text = "CH1 ID4 Band4 • F=${fmt(band.frequency)} Hz • Q=${fmt(band.q)} • Boost=${fmt(band.boostDb)} dB • target=${fmt(target.boostDb)} dB"
                status.text = "V47 EQ BASELINE READY • controlled proof enabled"
                runProofButton.isEnabled = true
                record("META", "V47_BASELINE_READY actuator=4 band=4 offset=144 type=${band.type} f=${band.frequency} q=${band.q} boost=${band.boostDb} targetBoost=${target.boostDb}")
            }
            DescMode.VERIFY_TARGET -> {
                val expected = targetBand
                val ok = band != null && expected != null && ControlledEqBandProof.matches(band, expected)
                record("META", "V47_TARGET_DESCRIPTOR_VERIFY actuator=4 band=4 expectedBoost=${expected?.boostDb ?: Float.NaN} actualBoost=${band?.boostDb ?: Float.NaN} verified=$ok")
                val reason = if (ok) "target-descriptor-verified" else "target-verify-failed"
                record("META", "V47_RESTORE_SETTLE_BEFORE_WRITE_MS=$restoreSettleBeforeWriteMs reason=$reason")
                status.text = "Target descriptor complete • settling DSP before restore"
                handler.postDelayed({ restoreOriginal(reason) }, restoreSettleBeforeWriteMs)
            }
            DescMode.VERIFY_RESTORE -> {
                val expected = baselineBand
                val ok = band != null && expected != null && ControlledEqBandProof.matches(band, expected)
                record("META", "V47_RESTORE_DESCRIPTOR_VERIFY attempt=$restoreAttempt actuator=4 band=4 expectedBoost=${expected?.boostDb ?: Float.NaN} actualBoost=${band?.boostDb ?: Float.NaN} verified=$ok")
                if (ok) {
                    targetWasWritten = false
                    proofRunning = false
                    cancelGlobalFailsafe()
                    sessionReady = true
                    runProofButton.isEnabled = true
                    status.text = "V47 COMPLETE • EQ target verified + original restored • SaveParams NOT sent"
                    record("META", "V47_CONTROLLED_EQ_WRITE_PROOF_COMPLETE actuator=4 band=4 offset=144 write57=true targetDescriptorVerified=true restored=true restoreAttempts=$restoreAttempt saveParamsSent=false")
                } else if (restoreAttempt < 2) {
                    record("META", "V47_RESTORE_RETRY_SCHEDULED nextAttempt=${restoreAttempt + 1} delayMs=$restoreRetryDelayMs")
                    status.text = "Restore not reflected yet • one timed retry scheduled"
                    handler.postDelayed({ restoreOriginal("restore-verify-retry") }, restoreRetryDelayMs)
                } else {
                    targetWasWritten = false
                    proofRunning = false
                    cancelGlobalFailsafe()
                    sessionReady = false
                    runProofButton.isEnabled = false
                    status.text = "RESTORE VERIFY FAILED AFTER RETRY — stop and save capture"
                    record("META", "V47_CONTROLLED_EQ_WRITE_PROOF_FAILED stage=restore-verify attempts=$restoreAttempt")
                }
            }
        }
    }

    private fun restoreOriginal(reason: String) {
        val original = baselineBand ?: run { finishFailed("missing-original") ; return }
        val g = gatt ?: run { finishFailed("missing-gatt") ; return }
        val w = ab01 ?: run { finishFailed("missing-ab01") ; return }
        val tx = txCipher ?: run { finishFailed("missing-tx") ; return }
        if (descMode != null) {
            record("META", "V47_RESTORE_DEFERRED reason=descriptor-active mode=$descMode")
            handler.postDelayed({ restoreOriginal(reason) }, 500L)
            return
        }
        restoreAttempt += 1
        val plain = ControlledEqBandProof.encodeWrite(original)
        val enc = tx.encryptNext(plain)
        record("META", "V47_EQ_RESTORE_WRITE_PLAIN=${ByteCodec.run { plain.toHex() }} attempt=$restoreAttempt actuator=4 band=4 offset=144 originalBoost=${original.boostDb} reason=$reason saveParams=false")
        if (!writeNoResponse(g, w, enc, "TX_EQ_CH1_BAND4_RESTORE_V47_A$restoreAttempt")) {
            finishFailed("restore-write-queue-failed")
            return
        }
        status.text = "Restore attempt $restoreAttempt sent • waiting before descriptor verify"
        record("META", "V47_RESTORE_VERIFY_DELAY_MS=$restoreVerifyDelayMs attempt=$restoreAttempt")
        handler.postDelayed({ requestDescriptor(DescMode.VERIFY_RESTORE) }, restoreVerifyDelayMs)
    }

    private fun armGlobalFailsafe() {
        cancelGlobalFailsafe()
        proofTimeout = Runnable {
            if (proofRunning && targetWasWritten) {
                record("META", "V47_FAILSAFE_RESTORE_TRIGGERED currentAttempt=$restoreAttempt")
                if (descMode == null && restoreAttempt < 2) restoreOriginal("global-failsafe-timeout")
                else record("META", "V47_FAILSAFE_RESTORE_DEFERRED mode=$descMode attempt=$restoreAttempt")
            }
        }.also { handler.postDelayed(it, 45000L) }
        record("META", "V47_FAILSAFE_WINDOW_MS=45000")
    }

    private fun cancelGlobalFailsafe() {
        proofTimeout?.let { handler.removeCallbacks(it) }
        proofTimeout = null
    }

    private fun finishFailed(reason: String) {
        record("META", "V47_PROOF_FAILED reason=$reason")
        proofRunning = false
        sessionReady = false
        runProofButton.isEnabled = false
        cancelGlobalFailsafe()
        status.text = "V47 proof failed: $reason • save capture"
    }

    private fun extractBand(obj: JSONObject, actuatorId: Int, bandIndex1: Int): EqBand48? {
        val arr = obj.optJSONArray("actuators") ?: return null
        for (i in 0 until arr.length()) {
            val a = arr.optJSONObject(i) ?: continue
            if (a.optInt("ID", -1) != actuatorId || a.optInt("type", -1) != 4084) continue
            val bands = a.optJSONArray("UFE_TYPE_BIQUAD_CASCADE15_F") ?: return null
            val b = bands.optJSONObject(bandIndex1 - 1) ?: return null
            fun f(key: String): Float = b.optDouble(key, Double.NaN).toFloat()
            val out = EqBand48(
                type = b.optInt("typ", -1),
                frequency = f("F"),
                frequency2 = f("F2"),
                q = f("Q"),
                boostDb = f("B"),
                gain = f("G"),
                r = f("R"),
                b0 = f("B0"),
                b1 = f("B1"),
                b2 = f("B2"),
                a1 = f("A1"),
                a2 = f("A2"),
            )
            if (listOf(out.frequency, out.frequency2, out.q, out.boostDb, out.gain, out.r, out.b0, out.b1, out.b2, out.a1, out.a2).any { !it.isFinite() }) return null
            return out
        }
        return null
    }

    private fun startScan() {
        if (!hasBlePermission()) { requestBlePermissions(); return }
        val adapter = getSystemService(BluetoothManager::class.java)?.adapter ?: return
        if (!adapter.isEnabled) { Toast.makeText(this, "เปิด Bluetooth ก่อน", Toast.LENGTH_SHORT).show(); return }
        found.clear(); deviceList.removeAllViews()
        scanner = adapter.bluetoothLeScanner
        status.text = "SCANNING"
        try { scanner?.startScan(scanCallback) } catch (_: SecurityException) { return }
        handler.postDelayed({ try { scanner?.stopScan(scanCallback) } catch (_: Exception) {} }, 10000L)
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val d = result.device
            val name = result.scanRecord?.deviceName ?: try { d.name } catch (_: SecurityException) { null }
            if (name?.contains("GOLOPINE", true) != true && name?.contains("DSP", true) != true) return
            if (found.putIfAbsent(d.address, d) != null) return
            runOnUiThread {
                deviceList.addView(Button(this@EqProofActivity).apply {
                    text = "${name ?: "DSP"} • ${d.address}\nแตะเพื่อเชื่อมต่อ"
                    setOnClickListener { connect(d, name ?: "DSP") }
                })
            }
        }
    }

    private fun connect(device: BluetoothDevice, name: String) {
        if (!hasBlePermission()) return
        try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
        try { gatt?.close() } catch (_: Exception) {}
        connectedName = name
        status.text = "CONNECTING $name"
        record("META", "V47_CONNECT_START name=$name address=${device.address}")
        try {
            gatt = device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
        } catch (_: SecurityException) { status.text = "CONNECT permission error" }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, statusCode: Int, newState: Int) {
            record("META", "GATT_STATE status=$statusCode newState=$newState")
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                runOnUiThread { status.text = "CONNECTED ${connectedName ?: "DSP"} • discovering" }
                try {
                    g.requestMtu(517)
                    handler.postDelayed({ try { g.discoverServices() } catch (_: SecurityException) {} }, 250L)
                } catch (_: SecurityException) {}
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                sessionReady = false; waitingAuth = false; txCipher = null; rxCipher = null
                proofRunning = false; targetWasWritten = false; cancelGlobalFailsafe()
                runOnUiThread { status.text = "DISCONNECTED"; startSessionButton.isEnabled = false; runProofButton.isEnabled = false }
            }
        }

        override fun onMtuChanged(g: BluetoothGatt, mtu: Int, statusCode: Int) { record("META", "MTU_CHANGED mtu=$mtu status=$statusCode") }

        override fun onServicesDiscovered(g: BluetoothGatt, statusCode: Int) {
            val service = g.getService(BleProfile.AB00_SERVICE)
            ab01 = service?.getCharacteristic(BleProfile.AB01_WRITE)
            ab02 = service?.getCharacteristic(BleProfile.AB02_NOTIFY)
            val ok = statusCode == BluetoothGatt.GATT_SUCCESS && ab01 != null && ab02 != null
            record("META", "SERVICES_DISCOVERED status=$statusCode AB01=${ab01 != null} AB02=${ab02 != null}")
            if (!ok) { runOnUiThread { status.text = "AB00/AB01/AB02 profile not found" }; return }
            subscribeAb02(g, ab02!!)
            runOnUiThread { status.text = "CONNECTED • enabling AB02 notifications"; startSessionButton.isEnabled = false }
        }

        override fun onDescriptorWrite(g: BluetoothGatt, descriptor: BluetoothGattDescriptor, statusCode: Int) {
            record("META", "CCCD_WRITE status=$statusCode")
            runOnUiThread {
                if (statusCode == BluetoothGatt.GATT_SUCCESS) {
                    status.text = "CONNECTED • AB02 notifications READY"
                    startSessionButton.isEnabled = true
                } else {
                    status.text = "CCCD notification enable failed: $statusCode"
                    startSessionButton.isEnabled = false
                }
            }
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, statusCode: Int) {
            record("META", "TX_WRITE_RESULT status=$statusCode uuid=${characteristic.uuid}")
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            if (characteristic.uuid == BleProfile.AB02_NOTIFY) handleAb02(value)
        }

        @Suppress("DEPRECATION")
        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            if (android.os.Build.VERSION.SDK_INT < 33 && characteristic.uuid == BleProfile.AB02_NOTIFY) handleAb02(characteristic.value ?: byteArrayOf())
        }
    }

    private fun subscribeAb02(g: BluetoothGatt, ch: BluetoothGattCharacteristic) {
        if (!hasBlePermission()) return
        try {
            g.setCharacteristicNotification(ch, true)
            val cccd = ch.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")) ?: return
            val v = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            if (android.os.Build.VERSION.SDK_INT >= 33) g.writeDescriptor(cccd, v)
            else {
                @Suppress("DEPRECATION") cccd.value = v
                @Suppress("DEPRECATION") g.writeDescriptor(cccd)
            }
        } catch (e: Exception) { record("META", "SUBSCRIBE_ERROR ${e.javaClass.simpleName}:${e.message}") }
    }

    private fun writeNoResponse(g: BluetoothGatt, ch: BluetoothGattCharacteristic, bytes: ByteArray, label: String): Boolean {
        if (!hasBlePermission()) return false
        record("TX", "$label len=${bytes.size} hex=${ByteCodec.run { bytes.toHex() }}")
        return try {
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                g.writeCharacteristic(ch, bytes, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE) == BluetoothStatusCodes.SUCCESS
            } else {
                @Suppress("DEPRECATION") ch.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                @Suppress("DEPRECATION") ch.value = bytes
                @Suppress("DEPRECATION") g.writeCharacteristic(ch)
            }
        } catch (e: Exception) {
            record("META", "$label ERROR ${e.javaClass.simpleName}:${e.message}")
            false
        }
    }

    private fun record(kind: String, text: String) {
        val line = "${ts.format(Date())}\t#${++packetNo}\t$kind\t$text"
        synchronized(captureLines) { captureLines.add(line) }
        runOnUiThread { logView.text = (logView.text.toString() + line + "\n").takeLast(14000) }
    }

    private fun saveCapture() {
        val text = buildString {
            append("=== OKN DSP V47 CONTROLLED EQ BAND WRITE PROOF CAPTURE ===\n")
            synchronized(captureLines) { captureLines.forEach { append(it).append('\n') } }
        }
        val name = "OKN_DSP_V47_CAPTURE_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.txt"
        try {
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: error("insert failed")
                contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) }
                Toast.makeText(this, "Saved Downloads/$name", Toast.LENGTH_LONG).show()
            } else {
                val f = java.io.File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), name)
                f.writeText(text)
                Toast.makeText(this, "Saved ${f.absolutePath}", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Save failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun requestBlePermissions() {
        val perms = if (android.os.Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (perms.any { ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }) {
            ActivityCompat.requestPermissions(this, perms, 1001)
        }
    }

    private fun hasBlePermission(): Boolean = if (android.os.Build.VERSION.SDK_INT >= 31) {
        ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
    } else ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun fmt(v: Float): String = String.format(Locale.US, "%.3f", v)
}
