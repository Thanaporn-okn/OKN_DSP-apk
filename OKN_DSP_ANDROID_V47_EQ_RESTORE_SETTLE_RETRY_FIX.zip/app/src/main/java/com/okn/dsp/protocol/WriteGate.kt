package com.okn.dsp.protocol

/**
 * V47 gate.
 * Generic writes remain disabled. V45 scalar controls stay enabled because they
 * are runtime verified. V47 additionally enables one constrained, self-restoring
 * CH1 Band4 EQ proof only. SaveParams ID=7, normal EQ writes, presets, delay and
 * unknown actuator writes remain blocked.
 */
object WriteGate {
    const val enabled: Boolean = false
    const val controlledMasterVolumeProofEnabled: Boolean = true
    const val verifiedScalarControlsEnabled: Boolean = true
    const val controlledEqBandProofEnabled: Boolean = true
}
