package com.okn.dsp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import java.util.Locale;

final class DspView extends View {
    private static final float W = 786f;
    private static final float H = 1536f;
    private static final float NAV_H = 145f;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final DspState state = new DspState();
    private BleManager ble;

    private int page = 0; // 0 Home, 1 EQ
    private int draggingHomeSlider = -1;
    private boolean draggingEqPoint = false;
    private boolean draggingFader = false;
    private float scale = 1f;
    private float offsetX = 0f;
    private float offsetY = 0f;
    private float viewportH = H;
    private String bleStatus = "กำลังค้นหา...";
    private String bleDevice = "OKN-DSP_7CH";
    private boolean bleConnected = false;
    private String diagnostic = "";

    private final int CYAN = Color.rgb(0, 216, 255);
    private final int BLUE = Color.rgb(0, 132, 255);
    private final int PANEL = Color.rgb(3, 27, 48);
    private final int PANEL2 = Color.rgb(2, 19, 36);
    private final int BORDER = Color.rgb(13, 67, 112);
    private final int WHITE = Color.rgb(238, 245, 255);
    private final int SUB = Color.rgb(155, 184, 222);
    private final int GREEN = Color.rgb(0, 236, 123);

    private final int[] bandColors = {
            Color.rgb(255, 70, 80), Color.rgb(255, 191, 58), Color.rgb(52, 231, 91),
            Color.rgb(24, 203, 237), Color.rgb(157, 73, 235), Color.rgb(255, 103, 172)
    };

    DspView(Context context, BleManager ble) {
        super(context);
        this.ble = ble;
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        setFocusable(true);
        setClickable(true);
        setHapticFeedbackEnabled(false);
    }

    void setBleManager(BleManager ble) {
        this.ble = ble;
    }

    void setBleStatus(String status, String deviceName, boolean connected) {
        bleStatus = status == null ? "" : status;
        if (deviceName != null && !deviceName.isEmpty()) bleDevice = deviceName;
        bleConnected = connected;
        invalidate();
    }

    void setDiagnostic(String message) {
        diagnostic = message == null ? "" : message;
        invalidate();
    }

    void setScalarFromDsp(int actuatorId, float value) {
        switch (actuatorId) {
            case DspProtocol.ID_MASTER_VOLUME: state.masterVolume = value; break;
            case DspProtocol.ID_BASS_VOLUME: state.bassVolume = value; break;
            case DspProtocol.ID_BASS_CUTOFF: state.bassCutoff = value; break;
            case DspProtocol.ID_BASS_BOOST: state.bassBoost = value; break;
            case DspProtocol.ID_MIDDLE_BOOST: state.middleBoost = value; break;
            case DspProtocol.ID_TREBLE_BOOST: state.trebleBoost = value; break;
            default: return;
        }
        invalidate();
    }

    void setEqFromDsp(int channel0, int uiBand0, float frequency, float gainDb, float q) {
        if (channel0 < 0 || channel0 >= DspState.CHANNELS || uiBand0 < 0 || uiBand0 >= DspState.BANDS) return;
        state.freq[channel0][uiBand0] = frequency;
        state.gain[channel0][uiBand0] = gainDb;
        state.q[channel0][uiBand0] = q;
        invalidate();
    }

    private void sendHomeScalar(int idx) {
        if (ble == null) return;
        if (idx == 0) ble.setScalarRealtime(DspProtocol.ID_MASTER_VOLUME, state.masterVolume);
        else if (idx == 1) ble.setScalarRealtime(DspProtocol.ID_BASS_VOLUME, state.bassVolume);
        else if (idx == 2) ble.setScalarRealtime(DspProtocol.ID_BASS_CUTOFF, state.bassCutoff);
        else if (idx == 3) ble.setScalarRealtime(DspProtocol.ID_BASS_BOOST, state.bassBoost);
        else if (idx == 4) ble.setScalarRealtime(DspProtocol.ID_MIDDLE_BOOST, state.middleBoost);
        else if (idx == 5) ble.setScalarRealtime(DspProtocol.ID_TREBLE_BOOST, state.trebleBoost);
    }

    private void sendAllHomeTonal() {
        for (int i = 1; i < 6; i++) sendHomeScalar(i);
    }

    private void sendAllHome() {
        for (int i = 0; i < 6; i++) sendHomeScalar(i);
    }

    private void sendEqBand(int channel0, int band0) {
        if (ble == null) return;
        ble.setEqRealtime(channel0, band0, state.freq[channel0][band0], state.gain[channel0][band0], state.q[channel0][band0]);
    }

    private void sendEqChannel(int channel0) {
        for (int b = 0; b < DspState.BANDS; b++) sendEqBand(channel0, b);
    }

    private void sendAllEq() {
        for (int c = 0; c < DspState.CHANNELS; c++) sendEqChannel(c);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        // V4 responsive rule: preserve the 786 px reference width and use the
        // full physical screen height. Tall 19.5:9 / 20:9 Samsung displays no
        // longer get top/bottom letterboxing and circles remain true circles.
        float widthScale = getWidth() / W;
        float heightAtWidthScale = getHeight() / widthScale;
        if (heightAtWidthScale >= H) {
            scale = widthScale;
            viewportH = heightAtWidthScale;
            offsetX = 0f;
            offsetY = 0f;
        } else {
            scale = Math.min(widthScale, getHeight() / H);
            viewportH = H;
            offsetX = (getWidth() - W * scale) * 0.5f;
            offsetY = (getHeight() - H * scale) * 0.5f;
        }

        canvas.drawColor(Color.rgb(0, 6, 17));
        canvas.save();
        canvas.translate(offsetX, offsetY);
        canvas.scale(scale, scale);
        drawBackdrop(canvas);
        drawHeader(canvas);
        if (page == 0) drawHome(canvas); else drawEq(canvas);
        drawBottomNav(canvas);
        canvas.restore();
    }

    private void drawBackdrop(Canvas c) {
        p.setShader(new LinearGradient(0, 0, W, viewportH,
                Color.rgb(0, 13, 28), Color.rgb(0, 4, 12), Shader.TileMode.CLAMP));
        c.drawRect(0, 0, W, viewportH, p);
        p.setShader(null);
    }

    private float extraH() {
        return Math.max(0f, viewportH - H);
    }

    private float navTop() {
        return viewportH - NAV_H;
    }

    private float homeRowY(int index) {
        float[] base = {132f, 277f, 422f, 569f, 715f, 861f};
        float[] stretch = {0.06f, 0.13f, 0.20f, 0.27f, 0.34f, 0.41f};
        return base[index] + extraH() * stretch[index];
    }

    private float homePresetY() {
        return 1014f + extraH() * 0.57f;
    }

    private float eqMainHeight() { return 784f + extraH() * 0.35f; }
    private float eqGraphHeight() { return 314f + extraH() * 0.20f; }
    private float eqBandY() { return 626f + extraH() * 0.22f; }
    private float eqChannelY() { return 908f + extraH() * 0.42f; }
    private float eqControlY() { return 1072f + extraH() * 0.58f; }
    private float eqActionY() { return 1249f + extraH() * 0.74f; }

    private void drawHeader(Canvas c) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(bleConnected ? GREEN : Color.rgb(255, 191, 44));
        p.setShadowLayer(14, 0, 0, p.getColor());
        c.drawCircle(36, 64, 12, p);
        p.clearShadowLayer();

        text(c, bleConnected ? "เชื่อมต่อแล้ว" : bleStatus, 66, 60, 24, bleConnected ? GREEN : WHITE, true, Paint.Align.LEFT);
        text(c, bleDevice, 66, 92, 20, SUB, false, Paint.Align.LEFT);
        text(c, "›", 214, 91, 40, SUB, false, Paint.Align.CENTER);

        p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        p.setTextSkewX(-0.14f);
        text(c, "OKN_", 242, 58, 47, WHITE, true, Paint.Align.LEFT);
        float a = textWidth("OKN_", 47, true);
        text(c, "DSP", 242 + a, 58, 47, CYAN, true, Paint.Align.LEFT);
        p.setTextSkewX(0f);
        text(c, "DIGITAL SOUND PROCESSOR", 258, 84, 14, CYAN, true, Paint.Align.LEFT);

        // gear approximation
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(4);
        p.setColor(Color.rgb(176, 201, 244));
        c.drawCircle(718, 64, 23, p);
        c.drawCircle(718, 64, 8, p);
        for (int i = 0; i < 8; i++) {
            double a1 = i * Math.PI / 4.0;
            float x1 = 718 + (float) Math.cos(a1) * 25;
            float y1 = 64 + (float) Math.sin(a1) * 25;
            float x2 = 718 + (float) Math.cos(a1) * 31;
            float y2 = 64 + (float) Math.sin(a1) * 31;
            c.drawLine(x1, y1, x2, y2, p);
        }
        p.setStyle(Paint.Style.FILL);
    }

    private void drawHome(Canvas c) {
        String[] title = {"Master Volume", "Bass Volume", "Bass Cutoff", "Bass Boost", "Middle Boost", "Treble Boost"};
        String[] sub = {"ปรับระดับเสียงรวม", "ปรับระดับเสียงเบส", "ตั้งค่าความถี่ตัดเบส", "เพิ่มความหนักแน่นของเบส", "เพิ่มความชัดเจนย่านกลาง", "เพิ่มความใสย่านแหลม"};
        int[] colors = {Color.rgb(0, 139, 255), Color.rgb(0, 219, 239), Color.rgb(218, 45, 238), Color.rgb(255, 39, 111), Color.rgb(0, 151, 255), Color.rgb(209, 53, 241)};
        for (int i = 0; i < title.length; i++) {
            float y = homeRowY(i);
            roundPanel(c, 6, y, 764, 130, 22, PANEL, BORDER);
            drawHomeIcon(c, 76, y + 64, colors[i], i);
            text(c, title[i], 148, y + 56, 27, WHITE, true, Paint.Align.LEFT);
            text(c, sub[i], 148, y + 91, 18, SUB, false, Paint.Align.LEFT);
            drawHomeSlider(c, i, y + 58, colors[i]);
        }

        // Preset panel is kept visually identical to the reference, but moves
        // down on tall screens so the page fills the display naturally.
        float py = homePresetY();
        roundPanel(c, 6, py, 764, 342, 24, PANEL, BORDER);
        drawBookmark(c, 52, py + 48, CYAN);
        text(c, "พรีเซ็ตเสียง", 110, py + 46, 29, WHITE, true, Paint.Align.LEFT);
        text(c, "เลือกโทนเสียงที่คุณชอบ", 110, py + 82, 18, SUB, false, Paint.Align.LEFT);
        outlineButton(c, 578, py + 19, 172, 56, "ดูเพิ่มเติม  ›", false);

        String[] presets = {"Flat", "Pop", "Rock", "Jazz"};
        for (int i = 0; i < 4; i++) {
            float x = 27 + i * 184;
            boolean sel = state.homePreset == i;
            roundPanel(c, x, py + 117, 170, 94, 16,
                    sel ? Color.rgb(0, 137, 255) : PANEL2,
                    sel ? CYAN : BORDER);
            if (sel) glowRect(c, x, py + 117, 170, 94, 16, CYAN);
            drawPresetIcon(c, x + 52, py + 164, i, sel ? WHITE : Color.rgb(190, 213, 245));
            text(c, presets[i], x + 96, py + 174, 21, WHITE, false, Paint.Align.CENTER);
        }

        outlineButton(c, 27, py + 234, 354, 85, "⇩   บันทึกเป็นพรีเซ็ต", false);
        outlineButton(c, 394, py + 234, 356, 85, "⇧   โหลดพรีเซ็ต", false);
    }

    private void drawHomeSlider(Canvas c, int idx, float cy, int accent) {
        float min, max, value;
        if (idx == 0) { min = -70; max = 6; value = state.masterVolume; }
        else if (idx == 1) { min = -70; max = 6; value = state.bassVolume; }
        else if (idx == 2) { min = 20; max = 250; value = state.bassCutoff; }
        else {
            min = -12; max = 12;
            value = idx == 3 ? state.bassBoost : idx == 4 ? state.middleBoost : state.trebleBoost;
        }
        float x0 = 343, x1 = 612;
        float frac;
        if (idx == 2) frac = (float) ((Math.log(value) - Math.log(min)) / (Math.log(max) - Math.log(min)));
        else frac = (value - min) / (max - min);
        frac = clamp(frac, 0, 1);
        float knob = x0 + frac * (x1 - x0);

        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(14);
        p.setColor(Color.rgb(29, 63, 100));
        c.drawLine(x0, cy, x1, cy, p);
        if (Math.abs(knob - x0) > 0.5f) {
            p.setShader(new LinearGradient(x0, cy, knob, cy, accent, CYAN, Shader.TileMode.CLAMP));
        } else {
            p.setShader(null);
            p.setColor(accent);
        }
        p.setShadowLayer(8, 0, 0, accent);
        c.drawLine(x0, cy, knob, cy, p);
        p.clearShadowLayer();
        p.setShader(null);
        p.setColor(Color.rgb(242, 247, 253));
        c.drawCircle(knob, cy, 18, p);
        p.setStrokeCap(Paint.Cap.BUTT);

        String[] labels = (idx == 0 || idx == 1) ? new String[]{"-70", "-50", "-30", "-10", "+6"}
                : idx == 2 ? new String[]{"20", "50", "100", "150", "250"}
                : new String[]{"-12", "-6", "0", "+6", "+12"};
        for (int i = 0; i < labels.length; i++) {
            float tx = x0 + i * (x1 - x0) / (labels.length - 1f);
            p.setColor(Color.rgb(24, 101, 170));
            c.drawRect(tx - 1, cy + 17, tx + 1, cy + 28, p);
            text(c, labels[i], tx, cy + 51, 17, SUB, false, Paint.Align.CENTER);
        }
        String valueText = idx == 2 ? String.format(Locale.US, "%.0f Hz", value) : DspState.db(value);
        roundPanel(c, 637, cy - 34, 114, 62, 13, Color.rgb(2, 18, 35), Color.rgb(24, 74, 128));
        text(c, valueText, 694, cy + 8, 22, WHITE, false, Paint.Align.CENTER);
    }

    private void drawEq(Canvas c) {
        float channelY = eqChannelY();
        float controlY = eqControlY();
        float actionY = eqActionY();

        roundPanel(c, 6, 110, 774, eqMainHeight(), 23, PANEL, BORDER);
        text(c, "กราฟิก EQ", 32, 169, 38, WHITE, true, Paint.Align.LEFT);
        text(c, "ปรับแต่งความถี่ เสียงของคุณ", 32, 202, 19, SUB, false, Paint.Align.LEFT);

        roundPanel(c, 315, 137, 304, 58, 14, PANEL2, BORDER);
        text(c, DspState.CHANNEL_LONG[state.channel], 337, 176, 20, WHITE, false, Paint.Align.LEFT);
        text(c, "‹", 541, 178, 44, SUB, false, Paint.Align.CENTER);
        text(c, "›", 595, 178, 44, SUB, false, Paint.Align.CENTER);
        outlineButton(c, 630, 137, 139, 58, "↻  Reset", false);

        drawEqGraph(c);
        drawBandCards(c);

        roundPanel(c, 7, channelY, 772, 150, 20, PANEL, BORDER);
        text(c, "เลือกช่องสัญญาณ", 27, channelY + 37, 22, WHITE, true, Paint.Align.LEFT);
        for (int ch = 0; ch < DspState.CHANNELS; ch++) {
            float x = 26 + ch * 106.5f;
            boolean sel = ch == state.channel;
            roundPanel(c, x, channelY + 58, 100, 80, 14, sel ? Color.rgb(0, 132, 255) : PANEL2, sel ? CYAN : BORDER);
            if (sel) glowRect(c, x, channelY + 58, 100, 80, 14, CYAN);
            String[] parts = DspState.CHANNEL_SHORT[ch].split("\n");
            text(c, parts[0], x + 50, channelY + 93, 18, WHITE, false, Paint.Align.CENTER);
            text(c, parts[1], x + 50, channelY + 119, 16, WHITE, false, Paint.Align.CENTER);
        }

        // Fader / mute / phase row
        roundPanel(c, 8, controlY, 418, 162, 18, PANEL, BORDER);
        text(c, "เฟดเดอร์ (ระดับเสียง)", 27, controlY + 39, 20, WHITE, true, Paint.Align.LEFT);
        drawSpeaker(c, 49, controlY + 98, SUB);
        drawEqFader(c, 91, controlY + 92, 300, state.fader[state.channel]);
        roundPanel(c, 315, controlY + 62, 95, 55, 12, PANEL2, BORDER);
        text(c, DspState.db(state.fader[state.channel]), 362, controlY + 98, 19, WHITE, false, Paint.Align.CENTER);

        roundPanel(c, 432, controlY, 166, 162, 18, PANEL, BORDER);
        text(c, "มิวท์", 451, controlY + 39, 20, WHITE, true, Paint.Align.LEFT);
        drawMuteToggle(c, 483, controlY + 88, state.mute[state.channel]);

        roundPanel(c, 607, controlY, 171, 162, 18, PANEL, BORDER);
        text(c, "เฟส", 624, controlY + 39, 20, WHITE, true, Paint.Align.LEFT);
        phaseButton(c, 624, controlY + 68, 73, 64, "0°", !state.phase180[state.channel]);
        phaseButton(c, 700, controlY + 68, 64, 64, "180°", state.phase180[state.channel]);

        outlineButton(c, 12, actionY, 254, 96, "⇩  โหลดจากอุปกรณ์\nดึงค่าปัจจุบันจาก DSP", false);
        outlineButton(c, 273, actionY, 246, 96, "⇧  โหลดพรีเซ็ต\nโหลดพรีเซ็ตจากไฟล์", false);
        outlineButton(c, 526, actionY, 252, 96, "▣  บันทึกเป็นพรีเซ็ต\nเก็บไว้ใช้งานภายหลัง", false);

        if (!diagnostic.isEmpty()) {
            float diagY = Math.min(navTop() - 14f, actionY + 125f);
            text(c, diagnostic.length() > 52 ? diagnostic.substring(0, 52) + "…" : diagnostic,
                    18, diagY, 13, Color.rgb(91, 143, 194), false, Paint.Align.LEFT);
        }
    }

    private void drawEqGraph(Canvas c) {
        float gx = 80, gy = 226, gw = 688, gh = eqGraphHeight();
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.rgb(0, 12, 24));
        c.drawRoundRect(new RectF(gx, gy, gx + gw, gy + gh), 8, 8, p);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(1);
        stroke.setColor(Color.rgb(15, 56, 91));
        for (int i = 0; i <= 12; i++) {
            float x = gx + gw * i / 12f;
            c.drawLine(x, gy, x, gy + gh, stroke);
        }
        for (int i = 0; i <= 6; i++) {
            float y = gy + gh * i / 6f;
            c.drawLine(gx, y, gx + gw, y, stroke);
        }
        stroke.setStrokeWidth(2);
        stroke.setColor(Color.rgb(82, 117, 158));
        c.drawRoundRect(new RectF(gx, gy, gx + gw, gy + gh), 8, 8, stroke);

        String[] gl = {"+12", "+6", "0", "-6", "-12"};
        for (int i = 0; i < gl.length; i++) {
            float y = gy + gh * i / 4f;
            text(c, gl[i], 58, y + 7, 17, SUB, false, Paint.Align.RIGHT);
        }
        text(c, "Gain", 25, 256, 18, SUB, false, Paint.Align.LEFT);
        text(c, "(dB)", 25, 284, 17, SUB, false, Paint.Align.LEFT);

        float[] ticks = {20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000};
        String[] tickText = {"20", "50", "100", "200", "500", "1K", "2K", "5K", "10K", "20K"};
        for (int i = 0; i < ticks.length; i++) {
            float x = freqX(ticks[i], gx, gw);
            text(c, tickText[i], x, gy + gh + 39, 16, SUB, false, Paint.Align.CENTER);
        }
        text(c, "Frequency (Hz)", gx + gw, gy + gh + 69, 15, SUB, false, Paint.Align.RIGHT);

        int ch = state.channel;
        Path line = new Path();
        Path fill = new Path();
        float firstX = gx;
        float firstY = gainY(state.gain[ch][0], gy, gh);
        line.moveTo(firstX, firstY);
        fill.moveTo(gx, gy + gh);
        fill.lineTo(firstX, firstY);
        for (int b = 0; b < DspState.BANDS; b++) {
            float x = freqX(state.freq[ch][b], gx, gw);
            float y = gainY(state.gain[ch][b], gy, gh);
            if (b == 0) {
                line.moveTo(x, y);
            } else {
                float px = freqX(state.freq[ch][b - 1], gx, gw);
                float py = gainY(state.gain[ch][b - 1], gy, gh);
                float mx = (px + x) * 0.5f;
                line.cubicTo(mx, py, mx, y, x, y);
            }
        }
        float lastX = freqX(state.freq[ch][DspState.BANDS - 1], gx, gw);
        float lastY = gainY(state.gain[ch][DspState.BANDS - 1], gy, gh);
        fill.reset();
        fill.moveTo(gx, gy + gh);
        fill.lineTo(freqX(state.freq[ch][0], gx, gw), gainY(state.gain[ch][0], gy, gh));
        for (int b = 1; b < DspState.BANDS; b++) {
            float x = freqX(state.freq[ch][b], gx, gw);
            float y = gainY(state.gain[ch][b], gy, gh);
            float px = freqX(state.freq[ch][b - 1], gx, gw);
            float py = gainY(state.gain[ch][b - 1], gy, gh);
            float mx = (px + x) * 0.5f;
            fill.cubicTo(mx, py, mx, y, x, y);
        }
        fill.lineTo(gx + gw, lastY);
        fill.lineTo(gx + gw, gy + gh);
        fill.close();
        p.setShader(new LinearGradient(0, gy, 0, gy + gh, Color.argb(100, 0, 110, 255), Color.argb(0, 0, 110, 255), Shader.TileMode.CLAMP));
        c.drawPath(fill, p);
        p.setShader(null);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(4);
        stroke.setColor(Color.rgb(0, 128, 255));
        stroke.setShadowLayer(10, 0, 0, BLUE);
        c.drawPath(line, stroke);
        stroke.clearShadowLayer();

        for (int b = 0; b < DspState.BANDS; b++) {
            float x = freqX(state.freq[ch][b], gx, gw);
            float y = gainY(state.gain[ch][b], gy, gh);
            p.setColor(bandColors[b]);
            p.setShadowLayer(12, 0, 0, bandColors[b]);
            c.drawCircle(x, y, 12, p);
            p.clearShadowLayer();
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(3);
            stroke.setColor(WHITE);
            c.drawCircle(x, y, b == state.selectedBand ? 14 : 12, stroke);
        }
    }

    private void drawBandCards(Canvas c) {
        int ch = state.channel;
        float y = eqBandY();
        for (int b = 0; b < DspState.BANDS; b++) {
            float x = 20 + b * 124.3f;
            boolean sel = b == state.selectedBand;
            roundPanel(c, x, y, 113, 252, 15, Color.rgb(2, 18, 33), sel ? CYAN : Color.rgb(17, 58, 94));
            if (sel) glowRect(c, x, y, 113, 252, 15, CYAN);
            p.setColor(bandColors[b]);
            c.drawCircle(x + 32, y + 30, 12, p);
            text(c, Integer.toString(b + 1), x + 64, y + 38, 17, WHITE, false, Paint.Align.LEFT);
            divider(c, x + 15, y + 62, x + 98, y + 62);
            text(c, "Freq", x + 16, y + 95, 16, SUB, false, Paint.Align.LEFT);
            text(c, DspState.hz(state.freq[ch][b]), x + 69, y + 96, 17, WHITE, false, Paint.Align.CENTER);
            divider(c, x + 15, y + 119, x + 98, y + 119);
            text(c, "Gain", x + 16, y + 150, 16, SUB, false, Paint.Align.LEFT);
            text(c, DspState.db(state.gain[ch][b]), x + 69, y + 151, 16, WHITE, false, Paint.Align.CENTER);
            divider(c, x + 15, y + 177, x + 98, y + 177);
            text(c, "Q", x + 16, y + 205, 16, SUB, false, Paint.Align.LEFT);
            text(c, String.format(Locale.US, "%.1f", state.q[ch][b]), x + 70, y + 206, 17, WHITE, false, Paint.Align.CENTER);
            drawBell(c, x + 56, y + 230, WHITE);
        }
    }

    private void drawBottomNav(Canvas c) {
        float ny = navTop();
        roundPanel(c, 0, ny, 786, NAV_H, 42, Color.rgb(1, 14, 27), Color.rgb(13, 52, 83));
        String[] labels = {"Home", "EQ", "Crossover", "Delay", "Settings"};
        for (int i = 0; i < 5; i++) {
            float cx = 78.6f + i * 157.2f;
            boolean sel = (page == 0 && i == 0) || (page == 1 && i == 1);
            int color = sel ? CYAN : Color.rgb(170, 198, 244);
            float iconY = ny + 53f;
            if (i == 0) drawHomeNavIcon(c, cx, iconY, color, sel);
            else if (i == 1) drawEqNavIcon(c, cx, iconY, color, sel);
            else if (i == 2) drawCrossoverIcon(c, cx, iconY, color);
            else if (i == 3) drawClock(c, cx, iconY, color);
            else drawGearSmall(c, cx, iconY, color);
            text(c, labels[i], cx, ny + 112f, 20, color, false, Paint.Align.CENTER);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (scale <= 0f || Float.isNaN(scale) || Float.isInfinite(scale)) return true;
        float x = (event.getX() - offsetX) / scale;
        float y = (event.getY() - offsetY) / scale;
        if (x < 0 || x > W || y < 0 || y > viewportH) return true;

        if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
            // Device status / top-right gear: retry BLE immediately. This keeps
            // the visible control useful without inventing a Settings page.
            if (y < 110 && (x < 245 || x > 675)) {
                tapFeedback();
                if (ble != null) ble.startScan();
                else toast("Bluetooth กำลังเตรียมพร้อม");
                return true;
            }
            if (y >= navTop()) {
                tapFeedback();
                int tab = Math.min(4, Math.max(0, (int) (x / (W / 5f))));
                if (tab == 0) page = 0;
                else if (tab == 1) page = 1;
                else toast("ยังไม่มีภาพ UI อ้างอิงสำหรับหน้านี้ จึงไม่สร้างหน้าจอเดาเอง");
                invalidate();
                return true;
            }
            if (page == 0) return handleHomeDown(x, y);
            else return handleEqDown(x, y);
        }

        if (event.getActionMasked() == MotionEvent.ACTION_MOVE) {
            if (page == 0 && draggingHomeSlider >= 0) {
                updateHomeSlider(draggingHomeSlider, x);
                invalidate();
                return true;
            }
            if (page == 1 && draggingEqPoint) {
                updateEqPoint(x, y);
                invalidate();
                return true;
            }
            if (page == 1 && draggingFader) {
                updateFader(x);
                invalidate();
                return true;
            }
        }

        if (event.getActionMasked() == MotionEvent.ACTION_UP || event.getActionMasked() == MotionEvent.ACTION_CANCEL) {
            int releasedHomeSlider = draggingHomeSlider;
            draggingHomeSlider = -1;
            draggingEqPoint = false;
            draggingFader = false;
            if (ble != null) {
                if (releasedHomeSlider == 0) {
                    // Master already follows the V13 original-app scheduler. Re-submit only
                    // the latest target; the queue coalesces it without a duplicate burst.
                    ble.setScalarRealtime(DspProtocol.ID_MASTER_VOLUME, state.masterVolume);
                } else if (releasedHomeSlider == 5) {
                    // V14 Treble safety: do NOT write ID11 while the finger is moving.
                    // Commit the final target on release, then BleManager applies a small
                    // callback-gated hardware slew so the DSP never receives a large jump.
                    ble.setScalarRealtime(DspProtocol.ID_TREBLE_BOOST, state.trebleBoost);
                }
            }
            performClick();
            return true;
        }
        return true;
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    private void tapFeedback() {
        // V11 audio-safe: no Android haptic/click feedback while tuning over Bluetooth audio.
    }

    private boolean handleHomeDown(float x, float y) {
        for (int i = 0; i < 6; i++) {
            float sliderY = homeRowY(i) + 58f;
            if (x >= 320 && x <= 630 && Math.abs(y - sliderY) < 42f) {
                draggingHomeSlider = i;
                updateHomeSlider(i, x);
                invalidate();
                return true;
            }
        }

        float py = homePresetY();
        if (y >= py + 108f && y <= py + 220f) {
            int i = (int) ((x - 20) / 184f);
            if (i >= 0 && i < 4) {
                tapFeedback();
                state.applyHomePreset(i);
                sendAllHomeTonal();
                invalidate();
                return true;
            }
        }
        if (x >= 27 && x <= 381 && y >= py + 226f && y <= py + 329f) {
            tapFeedback();
            state.saveHome(getContext());
            toast("บันทึกพรีเซ็ตแล้ว");
            return true;
        }
        if (x >= 394 && x <= 750 && y >= py + 226f && y <= py + 329f) {
            tapFeedback();
            boolean ok = state.loadHome(getContext());
            if (ok) sendAllHome();
            toast(ok ? "โหลดพรีเซ็ตแล้ว • กำลังส่งเข้า DSP" : "ยังไม่มีพรีเซ็ตที่บันทึกไว้");
            invalidate();
            return true;
        }
        if (x >= 570 && y >= py + 10f && y <= py + 88f) {
            tapFeedback();
            toast("รายการพรีเซ็ตเพิ่มเติมจะใช้ UI อ้างอิงเท่านั้น");
            return true;
        }
        return true;
    }

    private void updateHomeSlider(int idx, float x) {
        float frac = clamp((x - 343f) / (612f - 343f), 0f, 1f);
        if (idx == 0) state.masterVolume = round1(-70f + frac * 76f);
        else if (idx == 1) state.bassVolume = round1(-70f + frac * 76f);
        else if (idx == 2) {
            double v = Math.exp(Math.log(20) + frac * (Math.log(250) - Math.log(20)));
            state.bassCutoff = Math.round((float) v);
        } else if (idx == 3) state.bassBoost = round1(-12f + frac * 24f);
        else if (idx == 4) state.middleBoost = round1(-12f + frac * 24f);
        else state.trebleBoost = round1(-12f + frac * 24f);
        // V14: Master/Bass/Cutoff/BassBoost/Middle keep the V13 original-app scheduler.
        // TrebleBoost is the only control that showed a real acoustic incident in V13, so
        // while dragging ID11 is UI-preview only. The final Treble target is committed on
        // ACTION_UP and applied by a bounded callback-gated hardware slew.
        if (idx != 5) sendHomeScalar(idx);
    }

    private boolean handleEqDown(float x, float y) {
        if (x >= 630 && y >= 132 && y <= 205) {
            tapFeedback();
            state.flattenEq(state.channel);
            sendEqChannel(state.channel);
            invalidate();
            return true;
        }
        if (x >= 520 && x <= 570 && y >= 132 && y <= 205) {
            tapFeedback();
            state.channel = (state.channel + DspState.CHANNELS - 1) % DspState.CHANNELS;
            invalidate();
            return true;
        }
        if (x >= 570 && x <= 620 && y >= 132 && y <= 205) {
            tapFeedback();
            state.channel = (state.channel + 1) % DspState.CHANNELS;
            invalidate();
            return true;
        }

        float bandY = eqBandY();
        if (x >= 20 && x <= 770 && y >= bandY - 8f && y <= bandY + 260f) {
            tapFeedback();
            int b = Math.min(DspState.BANDS - 1, Math.max(0, (int) ((x - 20) / 124.3f)));
            state.selectedBand = b;
            invalidate();
            return true;
        }

        float gh = eqGraphHeight();
        if (x >= 80 && x <= 768 && y >= 220 && y <= 226f + gh + 10f) {
            int nearest = nearestBand(x, y);
            if (nearest >= 0) {
                tapFeedback();
                state.selectedBand = nearest;
                draggingEqPoint = true;
                updateEqPoint(x, y);
                invalidate();
            }
            return true;
        }

        float channelY = eqChannelY();
        if (y >= channelY + 50f && y <= channelY + 145f) {
            int ch = (int) ((x - 22) / 106.5f);
            if (ch >= 0 && ch < DspState.CHANNELS) {
                tapFeedback();
                state.channel = ch;
                invalidate();
            }
            return true;
        }

        float controlY = eqControlY();
        if (x >= 82 && x <= 306 && y >= controlY + 52f && y <= controlY + 132f) {
            tapFeedback();
            draggingFader = true;
            updateFader(x);
            if (ble != null) ble.reportUnverifiedControl("Fader");
            invalidate();
            return true;
        }
        if (x >= 450 && x <= 598 && y >= controlY + 48f && y <= controlY + 140f) {
            tapFeedback();
            state.mute[state.channel] = !state.mute[state.channel];
            if (ble != null) ble.reportUnverifiedControl("Mute");
            invalidate();
            return true;
        }
        if (x >= 620 && x <= 700 && y >= controlY + 58f && y <= controlY + 142f) {
            tapFeedback();
            state.phase180[state.channel] = false;
            if (ble != null) ble.reportUnverifiedControl("Phase");
            invalidate();
            return true;
        }
        if (x >= 700 && x <= 775 && y >= controlY + 58f && y <= controlY + 142f) {
            tapFeedback();
            state.phase180[state.channel] = true;
            if (ble != null) ble.reportUnverifiedControl("Phase");
            invalidate();
            return true;
        }

        float actionY = eqActionY();
        if (x >= 12 && x <= 266 && y >= actionY - 8f && y <= actionY + 108f) {
            tapFeedback();
            if (ble != null) ble.readKnownCharacteristic();
            else toast("Bluetooth ยังไม่พร้อม");
            return true;
        }
        if (x >= 273 && x <= 519 && y >= actionY - 8f && y <= actionY + 108f) {
            tapFeedback();
            boolean ok = state.loadEq(getContext());
            if (ok) sendAllEq();
            toast(ok ? "โหลดพรีเซ็ต EQ แล้ว • กำลังส่งเข้า DSP" : "ยังไม่มีพรีเซ็ต EQ ที่บันทึกไว้");
            invalidate();
            return true;
        }
        if (x >= 526 && x <= 780 && y >= actionY - 8f && y <= actionY + 108f) {
            tapFeedback();
            state.saveEq(getContext());
            toast("บันทึกพรีเซ็ต EQ แล้ว");
            return true;
        }
        return true;
    }

    private int nearestBand(float x, float y) {
        float gx = 80, gy = 226, gw = 688, gh = eqGraphHeight();
        int best = -1;
        float bestDist = Float.MAX_VALUE;
        for (int b = 0; b < DspState.BANDS; b++) {
            float px = freqX(state.freq[state.channel][b], gx, gw);
            float py = gainY(state.gain[state.channel][b], gy, gh);
            float dx = px - x, dy = py - y;
            float d = dx * dx + dy * dy;
            if (d < bestDist) { bestDist = d; best = b; }
        }
        return bestDist <= 58f * 58f ? best : -1;
    }

    private void updateEqPoint(float x, float y) {
        float gx = 80, gy = 226, gw = 688, gh = eqGraphHeight();
        int b = state.selectedBand;
        float fracX = clamp((x - gx) / gw, 0f, 1f);
        float f = (float) Math.exp(Math.log(20) + fracX * (Math.log(20000) - Math.log(20)));
        if (b > 0) f = Math.max(f, state.freq[state.channel][b - 1] * 1.08f);
        if (b < DspState.BANDS - 1) f = Math.min(f, state.freq[state.channel][b + 1] / 1.08f);
        state.freq[state.channel][b] = Math.round(f);
        float gain = 12f - clamp((y - gy) / gh, 0f, 1f) * 24f;
        state.gain[state.channel][b] = round1(gain);
        sendEqBand(state.channel, b);
    }

    private void updateFader(float x) {
        float frac = clamp((x - 91f) / (300f - 91f), 0f, 1f);
        state.fader[state.channel] = round1(-60f + frac * 72f);
    }

    private void drawHomeIcon(Canvas c, float cx, float cy, int color, int type) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.argb(20, Color.red(color), Color.green(color), Color.blue(color)));
        p.setShadowLayer(18, 0, 0, color);
        c.drawCircle(cx, cy, 49, p);
        p.clearShadowLayer();
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(3);
        stroke.setColor(color);
        c.drawCircle(cx, cy, 49, stroke);
        if (type == 0) drawSpeaker(c, cx - 5, cy, color);
        else if (type == 1) {
            stroke.setStrokeWidth(5); c.drawCircle(cx, cy, 20, stroke); c.drawCircle(cx, cy, 8, stroke);
        } else if (type == 2) {
            stroke.setStrokeWidth(4); c.drawLine(cx - 25, cy - 18, cx + 25, cy - 18, stroke); c.drawLine(cx - 10, cy - 18, cx - 10, cy + 24, stroke); c.drawLine(cx - 10, cy - 18, cx + 20, cy + 2, stroke);
        } else if (type == 3) {
            p.setColor(color); for (int i = 0; i < 6; i++) c.drawRoundRect(new RectF(cx - 25 + i * 9, cy + 22 - i * 8, cx - 19 + i * 9, cy + 26), 3, 3, p);
        } else if (type == 4) {
            Path path = new Path(); path.moveTo(cx - 28, cy); path.lineTo(cx - 18, cy); path.lineTo(cx - 10, cy - 18); path.lineTo(cx, cy + 20); path.lineTo(cx + 11, cy - 8); path.lineTo(cx + 20, cy + 6); path.lineTo(cx + 28, cy + 6); stroke.setStrokeWidth(4); c.drawPath(path, stroke);
        } else {
            p.setColor(color); Path star = new Path(); for (int i = 0; i < 8; i++) { double a = -Math.PI/2 + i*Math.PI/4; float r = (i%2==0)?24:9; float xx=cx+(float)Math.cos(a)*r; float yy=cy+(float)Math.sin(a)*r; if(i==0)star.moveTo(xx,yy);else star.lineTo(xx,yy);} star.close(); c.drawPath(star,p);
        }
    }

    private void drawSpeaker(Canvas c, float cx, float cy, int color) {
        p.setColor(color);
        Path tri = new Path(); tri.moveTo(cx - 22, cy - 8); tri.lineTo(cx - 8, cy - 8); tri.lineTo(cx + 7, cy - 21); tri.lineTo(cx + 7, cy + 21); tri.lineTo(cx - 8, cy + 8); tri.lineTo(cx - 22, cy + 8); tri.close(); c.drawPath(tri, p);
        stroke.setColor(color); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(3); c.drawArc(new RectF(cx, cy - 17, cx + 31, cy + 17), -55, 110, false, stroke); c.drawArc(new RectF(cx - 1, cy - 25, cx + 45, cy + 25), -50, 100, false, stroke);
    }

    private void drawBookmark(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(6);
        Path path = new Path(); path.moveTo(cx - 14, cy - 24); path.lineTo(cx + 14, cy - 24); path.lineTo(cx + 14, cy + 24); path.lineTo(cx, cy + 14); path.lineTo(cx - 14, cy + 24); path.close(); c.drawPath(path, stroke);
    }

    private void drawPresetIcon(Canvas c, float cx, float cy, int type, int color) {
        stroke.setColor(color); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(3);
        if (type == 0) { for (int i = -2; i <= 2; i++) c.drawLine(cx + i*8, cy - 15 + Math.abs(i)*5, cx + i*8, cy + 15 - Math.abs(i)*5, stroke); }
        else if (type == 1) { c.drawCircle(cx-10,cy-3,6,stroke);c.drawCircle(cx+6,cy-7,6,stroke);c.drawCircle(cx+20,cy-1,6,stroke);c.drawLine(cx-16,cy+13,cx+26,cy+13,stroke); }
        else if (type == 2) { c.drawLine(cx-20,cy+15,cx+17,cy-20,stroke);c.drawCircle(cx-14,cy+11,8,stroke); }
        else { Path path = new Path(); path.moveTo(cx-8,cy+18);path.lineTo(cx-8,cy-20);path.lineTo(cx+14,cy-25);path.lineTo(cx+14,cy+8);c.drawPath(path,stroke);c.drawCircle(cx-13,cy+18,8,stroke);c.drawCircle(cx+9,cy+8,8,stroke); }
    }

    private void drawEqFader(Canvas c, float x0, float cy, float x1, float value) {
        float frac = clamp((value + 60f) / 72f, 0, 1);
        float knob = x0 + frac * (x1 - x0);
        p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeWidth(12); p.setColor(Color.rgb(32, 67, 100)); c.drawLine(x0, cy, x1, cy, p);
        if (Math.abs(knob - x0) > 0.5f) p.setShader(new LinearGradient(x0, cy, knob, cy, BLUE, CYAN, Shader.TileMode.CLAMP)); else { p.setShader(null); p.setColor(BLUE); } p.setShadowLayer(8,0,0,CYAN); c.drawLine(x0,cy,knob,cy,p); p.clearShadowLayer();p.setShader(null);p.setColor(WHITE);c.drawCircle(knob,cy,17,p);p.setStrokeCap(Paint.Cap.BUTT);
        String[] labels={"-60","-40","-20","0","+12"};for(int i=0;i<labels.length;i++){float tx=x0+i*(x1-x0)/4f;text(c,labels[i],tx,cy+47,15,SUB,false,Paint.Align.CENTER);}    }

    private void drawMuteToggle(Canvas c, float cx, float cy, boolean on) {
        roundPanel(c, cx, cy-25, 96, 50, 25, on ? Color.rgb(0, 118, 190) : Color.rgb(45, 72, 102), on ? CYAN : Color.rgb(60, 91, 126));
        float kx = on ? cx + 69 : cx + 27; p.setColor(WHITE);c.drawCircle(kx,cy,20,p);
        drawSpeaker(c, cx-24, cy, SUB);
        if (on) { stroke.setColor(Color.rgb(255,90,100));stroke.setStrokeWidth(3);c.drawLine(cx-37,cy-15,cx-12,cy+15,stroke); }
    }

    private void phaseButton(Canvas c,float x,float y,float w,float h,String label,boolean selected){roundPanel(c,x,y,w,h,12,selected?Color.rgb(0,132,255):PANEL2,selected?CYAN:BORDER);if(selected)glowRect(c,x,y,w,h,12,CYAN);text(c,label,x+w/2,y+h/2+8,19,WHITE,false,Paint.Align.CENTER);}

    private void drawBell(Canvas c, float cx, float cy, int color) { stroke.setStyle(Paint.Style.STROKE);stroke.setStrokeWidth(2.5f);stroke.setColor(color);Path b=new Path();b.moveTo(cx-19,cy+8);b.cubicTo(cx-10,cy+8,cx-10,cy-15,cx,cy-15);b.cubicTo(cx+10,cy-15,cx+10,cy+8,cx+19,cy+8);c.drawPath(b,stroke); }

    private void drawHomeNavIcon(Canvas c,float cx,float cy,int color,boolean selected){p.setColor(selected?Color.argb(60,0,216,255):Color.TRANSPARENT);if(selected){p.setShadowLayer(18,0,0,color);c.drawCircle(cx,cy,30,p);p.clearShadowLayer();}stroke.setColor(color);stroke.setStrokeWidth(4);stroke.setStyle(Paint.Style.STROKE);Path h=new Path();h.moveTo(cx-24,cy);h.lineTo(cx,cy-22);h.lineTo(cx+24,cy);h.lineTo(cx+19,cy);h.lineTo(cx+19,cy+23);h.lineTo(cx+4,cy+23);h.lineTo(cx+4,cy+7);h.lineTo(cx-5,cy+7);h.lineTo(cx-5,cy+23);h.lineTo(cx-19,cy+23);h.lineTo(cx-19,cy);h.close();c.drawPath(h,stroke);}
    private void drawEqNavIcon(Canvas c,float cx,float cy,int color,boolean selected){stroke.setColor(color);stroke.setStrokeWidth(3);for(int i=-1;i<=1;i++){float xx=cx+i*17;c.drawLine(xx,cy-25,xx,cy+25,stroke);float ky=cy+(i==0?-8:i==-1?8:3);c.drawLine(xx-7,ky,xx+7,ky,stroke);c.drawCircle(xx,ky,5,stroke);}if(selected){p.setColor(Color.argb(50,0,216,255));p.setShadowLayer(12,0,0,color);c.drawCircle(cx,cy,31,p);p.clearShadowLayer();}}
    private void drawCrossoverIcon(Canvas c,float cx,float cy,int color){stroke.setColor(color);stroke.setStrokeWidth(3);c.drawCircle(cx,cy-20,6,stroke);c.drawCircle(cx-22,cy+20,6,stroke);c.drawCircle(cx+22,cy+20,6,stroke);c.drawLine(cx,cy-14,cx,cy,stroke);c.drawLine(cx,cy,cx-22,cy+14,stroke);c.drawLine(cx,cy,cx+22,cy+14,stroke);}
    private void drawClock(Canvas c,float cx,float cy,int color){stroke.setColor(color);stroke.setStrokeWidth(3);c.drawCircle(cx,cy,24,stroke);c.drawLine(cx,cy,cx,cy-14,stroke);c.drawLine(cx,cy,cx+10,cy+8,stroke);}
    private void drawGearSmall(Canvas c,float cx,float cy,int color){stroke.setColor(color);stroke.setStrokeWidth(3);c.drawCircle(cx,cy,20,stroke);c.drawCircle(cx,cy,7,stroke);for(int i=0;i<8;i++){double a=i*Math.PI/4;float x1=cx+(float)Math.cos(a)*21,y1=cy+(float)Math.sin(a)*21,x2=cx+(float)Math.cos(a)*27,y2=cy+(float)Math.sin(a)*27;c.drawLine(x1,y1,x2,y2,stroke);}}

    private void roundPanel(Canvas c, float x, float y, float w, float h, float r, int fill, int border) { p.setStyle(Paint.Style.FILL);p.setColor(fill);c.drawRoundRect(new RectF(x,y,x+w,y+h),r,r,p);stroke.setStyle(Paint.Style.STROKE);stroke.setStrokeWidth(1.5f);stroke.setColor(border);c.drawRoundRect(new RectF(x,y,x+w,y+h),r,r,stroke); }
    private void glowRect(Canvas c,float x,float y,float w,float h,float r,int color){stroke.setStyle(Paint.Style.STROKE);stroke.setStrokeWidth(2.5f);stroke.setColor(color);stroke.setShadowLayer(15,0,0,color);c.drawRoundRect(new RectF(x,y,x+w,y+h),r,r,stroke);stroke.clearShadowLayer();}
    private void outlineButton(Canvas c,float x,float y,float w,float h,String label,boolean selected){roundPanel(c,x,y,w,h,15,selected?Color.rgb(0,128,240):PANEL2,selected?CYAN:Color.rgb(11,115,183));String[] lines=label.split("\\n");if(lines.length==1)text(c,lines[0],x+w/2,y+h/2+7,20,WHITE,false,Paint.Align.CENTER);else{ text(c,lines[0],x+w/2,y+h/2-3,19,WHITE,true,Paint.Align.CENTER); text(c,lines[1],x+w/2,y+h/2+25,14,SUB,false,Paint.Align.CENTER);}}
    private void divider(Canvas c,float x1,float y1,float x2,float y2){stroke.setColor(Color.rgb(20,50,78));stroke.setStrokeWidth(1);c.drawLine(x1,y1,x2,y2,stroke);}
    private void text(Canvas c,String s,float x,float y,float size,int color,boolean bold,Paint.Align align){p.setShader(null);p.setStyle(Paint.Style.FILL);p.setColor(color);p.setTextSize(size);p.setTextAlign(align);p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));c.drawText(s,x,y,p);}
    private float textWidth(String s,float size,boolean bold){p.setTextSize(size);p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));return p.measureText(s);}
    private float freqX(float freq,float gx,float gw){double frac=(Math.log(Math.max(20f,freq))-Math.log(20))/(Math.log(20000)-Math.log(20));return gx+(float)frac*gw;}
    private float gainY(float gain,float gy,float gh){return gy+(12f-clamp(gain,-12f,12f))/24f*gh;}
    private float clamp(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}
    private float round1(float v){return Math.round(v*10f)/10f;}
    private void toast(String s){Toast.makeText(getContext(),s,Toast.LENGTH_SHORT).show();}
}
