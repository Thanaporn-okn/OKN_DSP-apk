package com.okn.dsp;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Locale;

final class DspState {
    static final int CHANNELS = 7;
    static final int BANDS = 6;

    float masterVolume = -3f;
    float bassVolume = 4f;
    float bassCutoff = 100f;
    float bassBoost = 3f;
    float middleBoost = -2f;
    float trebleBoost = 1f;
    int homePreset = 0;

    final float[][] freq = new float[CHANNELS][BANDS];
    final float[][] gain = new float[CHANNELS][BANDS];
    final float[][] q = new float[CHANNELS][BANDS];
    final float[] fader = new float[CHANNELS];
    final boolean[] mute = new boolean[CHANNELS];
    final boolean[] phase180 = new boolean[CHANNELS];

    int channel = 0;
    int selectedBand = 0;

    static final String[] CHANNEL_SHORT = {"CH1\nFL", "CH2\nFR", "CH3\nRL", "CH4\nRR", "CH5\nCEN", "CH6\nSUB", "CH7\nAUX"};
    static final String[] CHANNEL_LONG = {"CH 1 : Front Left", "CH 2 : Front Right", "CH 3 : Rear Left", "CH 4 : Rear Right", "CH 5 : Center", "CH 6 : Sub", "CH 7 : AUX"};

    DspState() {
        for (int c = 0; c < CHANNELS; c++) {
            resetEq(c);
            fader[c] = -3f;
            mute[c] = false;
            phase180[c] = false;
        }
    }

    void resetEq(int c) {
        float[] f = {50f, 100f, 500f, 2000f, 5000f, 10000f};
        float[] g = {-3f, 0f, 4f, -2f, -4f, 2f};
        for (int b = 0; b < BANDS; b++) {
            freq[c][b] = f[b];
            gain[c][b] = g[b];
            q[c][b] = 1f;
        }
    }

    void flattenEq(int c) {
        for (int b = 0; b < BANDS; b++) gain[c][b] = 0f;
    }

    void applyHomePreset(int preset) {
        homePreset = preset;
        switch (preset) {
            case 1: // Pop
                bassVolume = 2f;
                bassCutoff = 100f;
                bassBoost = 2f;
                middleBoost = 1f;
                trebleBoost = 3f;
                break;
            case 2: // Rock
                bassVolume = 4f;
                bassCutoff = 90f;
                bassBoost = 4f;
                middleBoost = 2f;
                trebleBoost = 2f;
                break;
            case 3: // Jazz
                bassVolume = 2f;
                bassCutoff = 110f;
                bassBoost = 1f;
                middleBoost = 2f;
                trebleBoost = 3f;
                break;
            default: // Flat (reference values retained for master/cutoff)
                bassVolume = 0f;
                bassCutoff = 100f;
                bassBoost = 0f;
                middleBoost = 0f;
                trebleBoost = 0f;
                break;
        }
    }

    void saveHome(Context context) {
        SharedPreferences.Editor e = context.getSharedPreferences("okn_dsp_home", Context.MODE_PRIVATE).edit();
        e.putFloat("master", masterVolume)
                .putFloat("bass", bassVolume)
                .putFloat("cutoff", bassCutoff)
                .putFloat("bassboost", bassBoost)
                .putFloat("middle", middleBoost)
                .putFloat("treble", trebleBoost)
                .putInt("preset", homePreset)
                .apply();
    }

    boolean loadHome(Context context) {
        SharedPreferences p = context.getSharedPreferences("okn_dsp_home", Context.MODE_PRIVATE);
        if (!p.contains("master")) return false;
        masterVolume = p.getFloat("master", -3f);
        bassVolume = p.getFloat("bass", 4f);
        bassCutoff = p.getFloat("cutoff", 100f);
        bassBoost = p.getFloat("bassboost", 3f);
        middleBoost = p.getFloat("middle", -2f);
        trebleBoost = p.getFloat("treble", 1f);
        homePreset = p.getInt("preset", 0);
        return true;
    }

    void saveEq(Context context) {
        SharedPreferences.Editor e = context.getSharedPreferences("okn_dsp_eq", Context.MODE_PRIVATE).edit();
        for (int c = 0; c < CHANNELS; c++) {
            e.putFloat("fader_" + c, fader[c]);
            e.putBoolean("mute_" + c, mute[c]);
            e.putBoolean("phase_" + c, phase180[c]);
            for (int b = 0; b < BANDS; b++) {
                e.putFloat("freq_" + c + "_" + b, freq[c][b]);
                e.putFloat("gain_" + c + "_" + b, gain[c][b]);
                e.putFloat("q_" + c + "_" + b, q[c][b]);
            }
        }
        e.putBoolean("saved", true).apply();
    }

    boolean loadEq(Context context) {
        SharedPreferences p = context.getSharedPreferences("okn_dsp_eq", Context.MODE_PRIVATE);
        if (!p.getBoolean("saved", false)) return false;
        for (int c = 0; c < CHANNELS; c++) {
            fader[c] = p.getFloat("fader_" + c, -3f);
            mute[c] = p.getBoolean("mute_" + c, false);
            phase180[c] = p.getBoolean("phase_" + c, false);
            for (int b = 0; b < BANDS; b++) {
                freq[c][b] = p.getFloat("freq_" + c + "_" + b, freq[c][b]);
                gain[c][b] = p.getFloat("gain_" + c + "_" + b, gain[c][b]);
                q[c][b] = p.getFloat("q_" + c + "_" + b, 1f);
            }
        }
        return true;
    }

    static String db(float v) {
        return String.format(Locale.US, "%.1f dB", v);
    }

    static String hz(float v) {
        if (v >= 1000f) return String.format(Locale.US, "%.1f kHz", v / 1000f);
        return String.format(Locale.US, "%.0f Hz", v);
    }
}
