# OKN DSP V14 — Phase 1

V14 removes the unwanted warm colors across the full UI rather than only replacing them in Mix.

- Orange removed everywhere.
- Amber/yellow removed everywhere.
- Remaining warm decorative channel/band accents removed.
- Mix uses mint / teal / green family accents only and keeps blue out of its controls.
- EQ keeps Frequency blue, Q cyan/teal, Gain Band mint green.
- EQ graph/channel decorative palette uses blue / cyan / teal / green only.
- Red remains only where it has a semantic destructive/alert meaning (Reset EQ / Delete).
- V12 launcher icon, WindowInsets safe area, persistent real-time values and preset features are preserved.

Version: **14.0.0** (`versionCode 1014`)
