OKN_DSP Version 14 - Phase 1 UI

Purpose
- Rebuild the interface from code to match the supplied four-screen 432 x 768 reference as closely as possible.
- The supplied reference image is NOT embedded, packaged, copied or painted as the app background.
- Phase 2 DSP/BLE transport remains disabled until Phase 1 UI is accepted.

Pages
- Home
- Mix
- Eq
- Crossover

V14 focus
- Reconstruct page geometry from the supplied reference rather than continuing incremental free-form scaling.
- Use the 430-wide reference coordinate system for horizontal geometry.
- Map reference Y coordinates into the available full-screen body so tall phones remain full-screen without stretching text, icons or circular knobs.
- Use page-specific bottom-navigation height matching the supplied reference composition.
- Pin the OKN_DSP wordmark to a platform sans-serif-black font independent of the phone display font.
- Keep all sliders, knobs, EQ points, crossover filters and delay controls interactive with immediate redraw.
- Preserve the stable development signing identity for update-in-place builds.

Signing / update path
V3 introduced a stable DEVELOPMENT signing key. V4 through V14 preserve the same key, so V3 and later development builds can update in place.
If moving from V1/V2 and Android reports an incompatible update, uninstall the old V1/V2 app once. V3 and later use the stable key.

Build
Use OKN_DSP_AutoBuild.yml. The workflow automatically selects the highest OKN_DSP_V*_Sources.zip in the repository root, verifies Sources/SHA256SUMS.txt, verifies the signing key, builds the signed debug APK and uploads the APK artifact.
