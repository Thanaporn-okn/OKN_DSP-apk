package com.okn.dsp

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.widget.*

class MainActivity: Activity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)

  val root=LinearLayout(this)
  root.orientation=LinearLayout.VERTICAL
  root.setPadding(16,16,16,16)
  root.setBackgroundColor(Color.BLACK)

  fun label(s:String){
   val t=TextView(this)
   t.text=s
   t.textSize=18f
   t.setTextColor(Color.WHITE)
   t.setPadding(8,8,8,8)
   root.addView(t)
  }

  label("🔵 Connected")
  label("BP1048P4 7CH DSP   FW:1.2.6")
  label("Master Volume")
  root.addView(SeekBar(this))

  val channels=arrayOf(
   "CH1 Front L","CH2 Front R","CH3 SUB",
   "CH4 Rear L","CH5 Rear R","CH6 AUX L","CH7 AUX R"
  )

  for(c in channels){
   label(c)
   root.addView(SeekBar(this))
   val b=Button(this)
   b.text="MUTE"
   root.addView(b)
  }

  label("MAIN   EQ   CROSSOVER   DELAY   MIXER   PRESET   SETTINGS")
  setContentView(root)
 }
}
