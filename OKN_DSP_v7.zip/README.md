# OKN_DSP v6

UI remains locked to the supplied OKN_DSP reference screens. No new custom screen is added.

v6 changes:
- Keeps Home and EQ layout/visual proportions from v5 unchanged.
- Hardens BLE GATT discovery around the proven characteristic UUID 0000ab01-0000-1000-8000-00805f9b34fb.
- Records the complete discovered service/characteristic map and AB01 property flags.
- Enables AB01 notification/indication through CCCD when the real characteristic supports it.
- Performs a safe AB01 READ probe only when the READ property is advertised; READ does not modify DSP settings.
- Captures exact READ/NOTIFY payload length, status and hexadecimal bytes for protocol research.
- Does NOT transmit guessed DSP control commands. Raw write support remains dormant until command bytes are proven.
- The existing connection badge can now connect/disconnect from Home or EQ.
- The existing gear icon exports/copies the BLE diagnostic report through the Android share sheet, without adding a new app UI.

Target: Android 8.0+ (minSdk 26), compile/target SDK 35.

## v7 update-signing fix
- Keeps applicationId com.okn.dsp.
- Adds one persistent signing key used by both debug and release builds.
- GitHub Actions fresh runners now produce APKs with the same signer from v7 onward.
- Because v6 and older debug APKs may have been signed by ephemeral runner keys, uninstall the currently installed old build once before installing v7. Future v8+ builds derived from v7 can update over v7 without uninstalling.
- Keep app/okn_dsp_update.jks unchanged in all future versions.
