import 'package:flutter/material.dart';

void main()=>runApp(const OKNDSP());

class OKNDSP extends StatelessWidget{
 const OKNDSP({super.key});
 Widget build(BuildContext c)=>MaterialApp(
  debugShowCheckedModeBanner:false,
  theme:ThemeData.dark(useMaterial3:true),
  home:const DSPHome());
}

class DSPHome extends StatelessWidget{
 const DSPHome({super.key});
 final channels=const ['Front L','Front R','SUB','Rear L','Rear R','AUX L','AUX R'];
 @override
 Widget build(BuildContext c){
  return Scaffold(
   backgroundColor:const Color(0xff0d1117),
   body:SafeArea(child:Column(children:[
    Container(
     margin:const EdgeInsets.all(12),
     padding:const EdgeInsets.all(16),
     decoration:BoxDecoration(color:const Color(0xff202631),borderRadius:BorderRadius.circular(14)),
     child:const Row(children:[
      Icon(Icons.bluetooth,color:Colors.cyan,size:32),
      SizedBox(width:15),
      Text('Connected\nBP1048P4 7CH DSP\nFW: 1.2.6',
      style:TextStyle(fontSize:18))
     ])),
    Row(mainAxisAlignment:MainAxisAlignment.center,children:[
     const Text('Master Volume  ',style:TextStyle(fontSize:20)),
     Text('-12.5 dB',style:TextStyle(fontSize:22,color:Colors.cyan))
    ]),
    Expanded(child:Row(
     children:channels.map((e)=>Expanded(child:Channel(title:e))).toList()
    )),
    Container(
     height:55,
     alignment:Alignment.center,
     color:const Color(0xff151a21),
     child:const Text('⌂ MAIN   EQ   CROSSOVER   DELAY   MIXER   PRESET   SETTINGS',
     style:TextStyle(color:Colors.cyan,fontSize:15))
    )
   ])));
 }
}

class Channel extends StatelessWidget{
 final String title;
 const Channel({super.key,required this.title});
 Widget build(BuildContext c)=>Container(
  margin:const EdgeInsets.all(5),
  decoration:BoxDecoration(color:const Color(0xff171d25),
  borderRadius:BorderRadius.circular(12)),
  child:Column(children:[
   Container(height:4,color:Colors.cyan),
   Padding(padding:const EdgeInsets.all(8),child:Text(title)),
   const Text('-2.0 dB'),
   const Expanded(child:RotatedBox(
    quarterTurns:3,
    child:Slider(value:0.75,onChanged:null,min:0,max:1)
   )),
   ElevatedButton(onPressed:null,child:const Text('Mute'))
  ])
 );
}
