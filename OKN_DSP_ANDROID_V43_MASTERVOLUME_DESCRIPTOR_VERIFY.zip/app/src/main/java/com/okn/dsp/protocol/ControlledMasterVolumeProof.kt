package com.okn.dsp.protocol

import kotlin.math.abs
import kotlin.math.max

/** V43 constrained actuator-write proof. Never persists parameters. */
object ControlledMasterVolumeProof {
    const val ACTUATOR_ID = ConfirmedDspMap.MASTER_VOLUME
    const val MIN_DB = -70.0f
    const val MAX_DB = 6.0f
    const val STEP_DOWN_DB = 1.0f
    const val VERIFY_TOLERANCE_DB = 0.06f

    fun targetFor(originalDb: Float): Float? {
        if (!originalDb.isFinite() || originalDb < MIN_DB || originalDb > MAX_DB) return null
        val target = max(MIN_DB, originalDb - STEP_DOWN_DB)
        if (abs(target - originalDb) < 0.25f) return null
        return target
    }

    fun matches(actual: Float, expected: Float): Boolean =
        actual.isFinite() && abs(actual - expected) <= VERIFY_TOLERANCE_DB

    fun encodeRead(): ByteArray = UfeCodec.encodeRead(ACTUATOR_ID, 0, 4)
    fun encodeWrite(valueDb: Float): ByteArray = UfeCodec.encodeFloat32Write(ACTUATOR_ID, valueDb)
}
