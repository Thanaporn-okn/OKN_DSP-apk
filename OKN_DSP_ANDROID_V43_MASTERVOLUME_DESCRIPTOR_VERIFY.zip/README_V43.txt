OKN DSP V43 — MasterVolume Descriptor Verify

Reason for V43
- V42 successfully released the controlled-write flow and started a second authenticated session.
- V42 successfully rebuilt the 18,143-byte Device Description and validated MasterVolume ID 2.
- The DSP did NOT respond to direct READ 0x58 for actuator ID 2.
- Earlier verified 0x58/0x60 readback evidence applies to sensors. Direct actuator read is therefore no longer assumed.

V43 controlled proof
1. AUTH16 -> derive current-session RandKey.
2. Read Device Description and take MasterVolume ID2 UFE_TYPE_FLOAT32 as baseline.
3. WRITE 0x57 to baseline -1 dB.
4. Refresh Device Description and compare ID2 with target.
5. Restore original baseline using WRITE 0x57.
6. Refresh Device Description and verify original value is restored.

Safety
- Normal UI writes remain locked.
- Only MasterVolume ID 2 may be written.
- Target can only move downward by 1 dB.
- SaveParams ID 7 is never sent.
- EQ/Preset/Delay writes remain locked.
- Failsafe restore remains armed while target verification is pending.
