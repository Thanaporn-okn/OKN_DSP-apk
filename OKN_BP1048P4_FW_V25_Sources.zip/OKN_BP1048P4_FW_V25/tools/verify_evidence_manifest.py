#!/usr/bin/env python3
from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'evidence_manifest.json').read_text())
errors=[]
if m.get('schema')!=4: errors.append('evidence schema must be 4')
if m.get('project_version')!=25: errors.append('project_version must be 25')
if m.get('target')!='BP1048P4' or m.get('board')!='GoloPine 7CH': errors.append('target/board mismatch')
if m.get('policy')!='FAIL_CLOSED_NO_INFERENCE': errors.append('policy mismatch')
if m.get('hardware_authorized') is not False: errors.append('hardware_authorized must be false')
req=m.get('required_exact_evidence',{})
if any(bool(v) for v in req.values()): errors.append('V25 exact evidence flags must all remain false')
prov=m.get('provenance',{})
if prov.get('previous_source_sha256')!='6373bbdfb25b8dbf3a07f506695107d7323f222a76ce86eb2c5ad91b72cfd57d': errors.append('V24 source provenance mismatch')
if prov.get('validation_zip_sha256')!='711e5a7038f36c942e45f5694027f6de1eb0da724aa8f5951bff3a0480b54c06': errors.append('V24 validation provenance mismatch')
if not any(o.get('id')=='v24-ci-validation' for o in m.get('observations',[])): errors.append('V24 CI observation missing')
for ob in m.get('observations',[]):
    if ob.get('authorizes') not in ([],None): errors.append('observations may not authorize hardware in V25')
if errors:
    [print('BLOCKED:',e) for e in errors]; sys.exit(1)
print('PASS: V25 evidence manifest is internally consistent and non-authorizing')
