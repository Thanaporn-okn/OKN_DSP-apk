#!/usr/bin/env python3
"""V25 non-executing mobile flash transaction contract.

This module prepares/verifies a transaction envelope only. It does not know
BP1048P4 programmer commands, packets, addresses, pins, boot modes, or image
layout values and has no function that can program hardware.
"""
from __future__ import annotations
from pathlib import Path
import argparse, hashlib, json, re

PROJECT_VERSION = 25
SCHEMA = 1
POLICY = "BOUND_PREFLIGHT_BACKUP_IMAGE_NO_PROGRAMMER_IO"
HEX64 = re.compile(r"^[0-9a-f]{64}$")
SEQUENCE = [
    "PREFLIGHT",
    "BACKUP_ORIGINAL",
    "VERIFY_BACKUP_HASH",
    "VERIFY_IMAGE_HASH",
    "ARM_EXTERNAL_EXECUTOR",
    "EXTERNAL_PROGRAM",
    "EXTERNAL_READBACK",
    "VERIFY_READBACK",
    "COMPLETE",
]


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _safe_file(root: Path, rel: str | None) -> tuple[Path | None, str | None]:
    if not rel or not isinstance(rel, str):
        return None, "path missing"
    p = Path(rel)
    if p.is_absolute() or ".." in p.parts:
        return None, "path must be relative and traversal-free"
    full = root / p
    try:
        full.resolve().relative_to(root.resolve())
    except ValueError:
        return None, "path escapes transaction root"
    if full.is_symlink():
        return None, "symlink transaction files are forbidden"
    if not full.is_file():
        return None, "file missing"
    return full, None


def base_manifest(root: Path) -> dict:
    return {
        "schema": SCHEMA,
        "project_version": PROJECT_VERSION,
        "target": "BP1048P4",
        "board": "GoloPine 7CH",
        "policy": POLICY,
        "state": "LOCKED",
        "execution_authorized": False,
        "destructive_executor_implemented": False,
        "no_programmer_packets": True,
        "bindings": {
            "port_integration_plan_sha256": sha256_file(root / "port_integration_plan.json"),
            "flash_session_manifest_sha256": sha256_file(root / "flash_session_manifest.json"),
        },
        "image": {"path": None, "sha256": None, "hash_verified": False},
        "backup": {"path": None, "sha256": None, "hash_verified": False},
        "required_sequence": list(SEQUENCE),
        "safety": {
            "backup_must_precede_program": True,
            "verified_image_required_before_arm": True,
            "readback_required_after_program": True,
            "abort_on_hash_mismatch": True,
            "recovery_required_on_external_program_failure": True,
            "external_executor_boundary_explicit": True,
        },
    }


def _all_true(d: dict) -> bool:
    return bool(d) and all(v is True for v in d.values())


def evaluate(root: Path, tx: dict | None = None) -> dict:
    root = root.resolve()
    if tx is None:
        tx = json.loads((root / "mobile_flash_transaction.json").read_text())
    plan = json.loads((root / "port_integration_plan.json").read_text())
    session = json.loads((root / "flash_session_manifest.json").read_text())
    errors: list[str] = []

    if tx.get("schema") != SCHEMA: errors.append("transaction schema mismatch")
    if tx.get("project_version") != PROJECT_VERSION: errors.append("transaction project_version mismatch")
    if tx.get("target") != "BP1048P4" or tx.get("board") != "GoloPine 7CH": errors.append("target/board mismatch")
    if tx.get("policy") != POLICY: errors.append("transaction policy mismatch")
    if tx.get("destructive_executor_implemented") is not False: errors.append("V25 must not implement destructive executor")
    if tx.get("no_programmer_packets") is not True: errors.append("programmer packet guard must remain true")
    if tx.get("required_sequence") != SEQUENCE: errors.append("transaction sequence mismatch")

    bindings = tx.get("bindings", {})
    if bindings.get("port_integration_plan_sha256") != sha256_file(root / "port_integration_plan.json"):
        errors.append("stale port integration plan binding")
    if bindings.get("flash_session_manifest_sha256") != sha256_file(root / "flash_session_manifest.json"):
        errors.append("stale flash session binding")

    plan_ready = plan.get("mobile_flash_integration_ready") is True
    pf = session.get("preflight", {})
    session_ready = session.get("execution_authorized") is True and _all_true(pf)

    content_ok = True
    for key in ("image", "backup"):
        rec = tx.get(key, {})
        path, err = _safe_file(root, rec.get("path"))
        if err:
            content_ok = False
            continue
        declared = rec.get("sha256")
        if not isinstance(declared, str) or not HEX64.fullmatch(declared):
            content_ok = False
            continue
        actual = sha256_file(path)
        if actual != declared:
            content_ok = False
            continue
        if rec.get("hash_verified") is not True:
            content_ok = False

    armable = (
        not errors and plan_ready and session_ready and content_ok and
        tx.get("execution_authorized") is True and
        tx.get("destructive_executor_implemented") is False
    )
    expected_state = "ARMABLE_EXTERNAL_EXECUTOR_NOT_IMPLEMENTED" if armable else "LOCKED"
    if tx.get("state") != expected_state:
        errors.append("transaction state is stale or inconsistent")
        armable = False

    return {
        "ok": not errors,
        "state": tx.get("state"),
        "plan_ready": plan_ready,
        "session_ready": session_ready,
        "content_verified": content_ok,
        "armable": armable,
        "destructive_execution_available": False,
        "errors": errors,
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="Verify V25 mobile flash transaction envelope; never programs hardware.")
    ap.add_argument("--root", default=".")
    ap.add_argument("--write", action="store_true", help="write a locked manifest bound to current readiness inputs")
    ap.add_argument("--expect-locked", action="store_true")
    a = ap.parse_args()
    root = Path(a.root).resolve()
    if a.write:
        (root / "mobile_flash_transaction.json").write_text(json.dumps(base_manifest(root), indent=2) + "\n")
    r = evaluate(root)
    print("MOBILE_FLASH_TRANSACTION=" + ("ARMABLE" if r["armable"] else "LOCKED"))
    print("DESTRUCTIVE_EXECUTOR=NOT_IMPLEMENTED")
    for e in r["errors"]:
        print("BLOCKED:" + e)
    if a.expect_locked and (r["armable"] or r["destructive_execution_available"]):
        print("ERROR: shipped V25 transaction unexpectedly became executable")
        return 1
    return 0 if r["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
