#!/usr/bin/env python3
from pathlib import Path
import json, sys
root=Path(__file__).resolve().parents[1]
h=(root/"src/core/okn_protocol.h").read_text()
c=(root/"src/core/okn_protocol.c").read_text()
fm=json.loads((root/"firmware_manifest.json").read_text())
doc=(root/"docs/CAPABILITY_HANDSHAKE_V16.md").read_text()
errors=[]
required=[
    "OKN_CMD_GET_CAPABILITIES = 0x06",
    "OKN_CMD_CAPABILITIES = 0x76",
    "#define OKN_CAPABILITIES_SCHEMA 1u",
    "#define OKN_CAPABILITIES_PAYLOAD_LEN 27u",
    "OKN_CAP_CAPABILITY_QUERY",
    "OKN_CAP_EXACT_BOARD_REQUIRED",
]
for x in required:
    if x not in h: errors.append("missing protocol capability declaration: "+x)
if "if (cmd == OKN_CMD_GET_CAPABILITIES)" not in c: errors.append("capability response branch missing")
for x in [
    "d[18] = 0u; /* hardware_ready",
    "d[19] = 0u; /* hardware_flashable",
    "d[20] = 0u; /* mobile_flashable",
]:
    if x not in c: errors.append("fail-closed capability field missing: "+x)
cp=fm.get("control_plane",{})
if cp.get("capability_handshake") is not True: errors.append("manifest capability_handshake must be true")
if cp.get("capability_schema") != 1: errors.append("manifest capability schema must be 1")
if cp.get("capability_query_read_only") is not True: errors.append("manifest query must be read-only")
if fm.get("hardware_flashable") is not False: errors.append("hardware_flashable must remain false")
if "wire frame remains Protocol V2" not in (root/"README.md").read_text(): errors.append("README must preserve V2 frame statement")
if "hardware ready" not in doc.lower() or "mobile flashable" not in doc.lower(): errors.append("capability doc incomplete")
if errors:
    for e in errors: print("BLOCKED:",e)
    sys.exit(1)
print("PASS: V25 capability handshake is fixed-schema, read-only, V2-compatible, and fail-closed")
