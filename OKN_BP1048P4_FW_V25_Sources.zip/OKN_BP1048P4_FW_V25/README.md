# OKN_BP1048P4_FW_V25

V25 is a release-candidate hardening revision of the portable clean-room firmware foundation.
It preserves all V24 fail-closed target, board, flash, mobile-discovery and provenance gates.

## What V25 adds

- Deterministic `source_inventory.json` with SHA-256 for every shipped source/config/test file except the inventory itself.
- Inventory verifier that detects edited, missing, extra, or renamed shipped files.
- Deterministic protocol/stream corruption fuzz regression exercising malformed lengths, CRC failures, noise, fragmentation and valid-frame recovery without hardware I/O.
- Deterministic persistence corruption fuzz regression exercising truncation, header/schema corruption, payload corruption and valid-image recovery.
- Immediate-predecessor provenance now binds V24 source + uploaded V24 GitHub validation artifact.

The wire frame remains Protocol V2; V25 changes host validation and persistence schema only.

## Safety status

- Exact BP1048P4/GoloPine hardware integration: LOCKED.
- Hardware flashable: NO.
- Mobile flashable: NO.
- Programmer I/O: NOT IMPLEMENTED.
- Destructive executor: NOT IMPLEMENTED.
- Target `.bin/.img`: NONE.
- No guessed register/address/pin/programmer packet is introduced by V25.

The fuzz and inventory work is host-side software validation only. It does not authorize target hardware use.
