#!/usr/bin/env python3
from pathlib import Path
import copy, json, sys, tempfile
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/"tools"))
from android_discovery_capture import canonical_sha256
from import_android_discovery import import_capture
from discovery_fingerprint import derive

def usb_capture(product_id=0x5678, nonce="a"):
    c={
      "schema":1,"project_version":25,"format":"OKN_ANDROID_DISCOVERY_CAPTURE","format_version":1,
      "target":"BP1048P4","board":"GoloPine 7CH",
      "policy":"READ_ONLY_ENUMERATION_CANONICAL_HASH_NO_COMMANDS_NO_AUTHORIZATION",
      "transport":"usb_host","read_only":True,"write_attempted":False,"commands_sent":[],
      "source":{"platform":"android","collector":"synthetic-v22-"+nonce,"permission_granted":True},
      "observations":[
        {"kind":"usb_device","operation":"enumerate","metadata":{
          "vendor_id":0x1234,"product_id":product_id,"device_class":0,
          "manufacturer":"synthetic","product":"synthetic-board",
          "serial_number":"VOLATILE-"+nonce,"session_nonce":nonce}},
        {"kind":"usb_interface","operation":"read_descriptor","metadata":{
          "interface_number":0,"interface_class":255,"interface_subclass":0,"interface_protocol":0}}
      ],
      "transcript":[{"operation":"enumerate","direction":"metadata","note":"session-"+nonce}],
    }
    c["canonical_sha256"]=canonical_sha256(c)
    return c

with tempfile.TemporaryDirectory() as td:
    td=Path(td)
    (td/"hardware_probe_evidence").mkdir()
    base=json.loads((root/"hardware_discovery_manifest.json").read_text())
    (td/"hardware_discovery_manifest.json").write_text(json.dumps(base,indent=2)+"\n")

    # One session is only an observation, never stable/authorized.
    c1=td/"c1.json"; c1.write_text(json.dumps(usb_capture(nonce="one"),indent=2)+"\n")
    import_capture(td,c1,"usb-session-1")
    r=derive(td)
    u=r["transports"]["usb_host"]
    assert u["state"]=="OBSERVED_ONCE" and u["session_count"]==1
    assert not u["hardware_authorized"] and not u["mobile_flash_authorized"]
    assert not r["android_host_transport_verified"] and not r["programmer_io_available"]

    # A second independent capture with only volatile changes yields the same
    # structural fingerprint and becomes OBSERVED_STABLE, still non-authorizing.
    c2=td/"c2.json"; c2.write_text(json.dumps(usb_capture(nonce="two"),indent=2)+"\n")
    import_capture(td,c2,"usb-session-2")
    r=derive(td); u=r["transports"]["usb_host"]
    assert u["state"]=="OBSERVED_STABLE" and u["session_count"]==2
    assert u["unique_fingerprint_count"]==1 and u["stable_fingerprint_sha256"]
    assert not r["android_host_transport_verified"] and not u["hardware_authorized"]

    # A structural identity change is detected as inconsistent.
    c3=td/"c3.json"; c3.write_text(json.dumps(usb_capture(product_id=0x9999,nonce="three"),indent=2)+"\n")
    import_capture(td,c3,"usb-session-3")
    r=derive(td); u=r["transports"]["usb_host"]
    assert u["state"]=="INCONSISTENT" and u["unique_fingerprint_count"]==2
    assert r["state"]=="INCONSISTENT" and not u["mobile_flash_authorized"]

print("ALL V25 DISCOVERY FINGERPRINT TESTS PASS")
