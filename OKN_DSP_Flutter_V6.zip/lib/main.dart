import 'package:flutter/material.dart';

void main()=>runApp(const OKNDSP());

class OKNDSP extends StatelessWidget{
 const OKNDSP({super.key});
 Widget build(BuildContext c)=>MaterialApp(
 debugShowCheckedModeBanner:false,
 theme:ThemeData.dark(useMaterial3:true),
 home:const DSP());
}

class DSP extends StatefulWidget{
 const DSP({super.key});
 State<DSP> createState()=>_DSP();
}

class _DSP extends State<DSP>{
 int tab=0;
 final menu=['MAIN','EQ','CROSSOVER','DELAY','MIXER','PRESET','SETTINGS'];

 Widget build(BuildContext c)=>Scaffold(
 backgroundColor:const Color(0xff0b1016),
 body:SafeArea(child:Column(children:[
 Expanded(child:body()),
 nav()
 ])));

 Widget body(){
 if(tab==1)return eq();
 if(tab==2)return crossover();
 if(tab==3)return delay();
 if(tab==4)return mixer();
 return main();
 }

 Widget panel(String title,Widget child)=>Container(
 margin:const EdgeInsets.all(10),
 padding:const EdgeInsets.all(15),
 decoration:BoxDecoration(
 color:const Color(0xff1b222c),
 borderRadius:BorderRadius.circular(15)),
 child:Column(children:[
 Text(title,style:const TextStyle(fontSize:22,color:Colors.cyan)),
 child
 ]));

 Widget main()=>panel('BP1048P4 7CH DSP',
 const Expanded(child:Center(child:Text('7 Channel Control'))));

 Widget eq()=>panel('EQ 15 BAND',
 Expanded(child:ListView(children:List.generate(15,(i)=>Slider(
 value:.5,onChanged:null)))));

 Widget crossover()=>panel('CROSSOVER HPF / LPF',
 const Column(children:[
 Text('HPF Frequency'),
 Slider(value:.5,onChanged:null),
 Text('LPF Frequency'),
 Slider(value:.5,onChanged:null)
 ]));

 Widget delay()=>panel('DELAY ms',
 const Slider(value:.3,onChanged:null));

 Widget mixer()=>panel('MIXER ROUTING',
 const Text('Input / Output Channel Matrix'));

 Widget nav()=>SizedBox(
 height:55,
 child:Row(
 mainAxisAlignment:MainAxisAlignment.spaceAround,
 children:List.generate(menu.length,(i)=>GestureDetector(
 onTap:()=>setState(()=>tab=i),
 child:Text(menu[i],
 style:TextStyle(color:i==tab?Colors.cyan:Colors.white))))));

}
