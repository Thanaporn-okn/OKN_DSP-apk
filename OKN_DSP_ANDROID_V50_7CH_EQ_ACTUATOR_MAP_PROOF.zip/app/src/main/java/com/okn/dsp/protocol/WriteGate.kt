package com.okn.dsp.protocol

/**
 * V50 gate. Generic writes stay disabled. V45 scalar controls remain enabled.
 * V49 already proved CH1 EQ target + restore. V50 enables only the guarded
 * multi-channel actuator-map proof for CH2..CH7, one channel at a time, with
 * live preflight, target verification, restore verification and one restore retry.
 * SaveParams ID7, presets, delay and unknown writes remain blocked.
 */
object WriteGate {
    const val enabled: Boolean = false
    const val controlledMasterVolumeProofEnabled: Boolean = true
    const val verifiedScalarControlsEnabled: Boolean = true
    const val controlledEqBandProofEnabled: Boolean = false
    const val eqBandRecoveryEnabled: Boolean = false
    const val finalEqWriteRestoreProofEnabled: Boolean = false
    const val sevenChannelEqMapProofEnabled: Boolean = true
}
