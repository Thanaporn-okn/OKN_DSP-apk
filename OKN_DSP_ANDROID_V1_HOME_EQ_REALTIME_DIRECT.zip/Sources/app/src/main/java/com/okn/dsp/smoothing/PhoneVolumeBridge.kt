package com.okn.dsp.smoothing

import android.content.Context
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import kotlin.math.roundToInt

/**
 * Bidirectional STREAM_MUSIC <-> MasterVolume bridge.
 *
 * V1 phone-volume bridge rule: DSP UI updates are continuous, but Android system-volume mirroring
 * advances at most one phone-volume index per step.  This avoids a large, coarse
 * STREAM_MUSIC jump occurring at the same instant as the DSP MasterVolume ramp.
 */
class PhoneVolumeBridge(context: Context) {
    private val audio = context.getSystemService(AudioManager::class.java)
    private val main = Handler(Looper.getMainLooper())

    @Volatile private var programmatic = false
    @Volatile private var suppressObserverUntil = 0L
    @Volatile private var targetIndex: Int? = null
    @Volatile private var running = false

    fun masterDbFromPhone(): Float {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val cur = audio.getStreamVolume(AudioManager.STREAM_MUSIC).coerceIn(0, max)
        return -70f + (cur.toFloat() / max.toFloat()) * 76f
    }

    /** Latest target wins; the phone volume itself moves one index at a time. */
    fun syncPhoneFromMaster(masterDb: Float) {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val normalized = ((masterDb.coerceIn(-70f, 6f) + 70f) / 76f)
        targetIndex = (normalized * max).roundToInt().coerceIn(0, max)
        if (!running) {
            running = true
            main.post { drive() }
        }
    }

    /** Physical volume keys are user intent and must take priority over an old mirror target. */
    fun cancelPendingSync() {
        targetIndex = null
        running = false
        main.removeCallbacksAndMessages(PHONE_RAMP_TOKEN)
    }

    fun isProgrammatic(): Boolean = programmatic

    /** ContentObserver callbacks arrive after setStreamVolume() returns, so a bool alone is insufficient. */
    fun shouldIgnoreObserver(): Boolean = programmatic || SystemClock.elapsedRealtime() < suppressObserverUntil

    private fun drive() {
        if (!running) return
        val target = targetIndex ?: run { running = false; return }
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val cur = audio.getStreamVolume(AudioManager.STREAM_MUSIC).coerceIn(0, max)
        if (cur == target) {
            running = false
            return
        }
        val next = if (target > cur) cur + 1 else cur - 1
        programmatic = true
        suppressObserverUntil = SystemClock.elapsedRealtime() + OBSERVER_GUARD_MS
        try {
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, next.coerceIn(0, max), 0)
        } finally {
            programmatic = false
        }
        main.postAtTime({ drive() }, PHONE_RAMP_TOKEN, SystemClock.uptimeMillis() + PHONE_STEP_INTERVAL_MS)
    }

    companion object {
        private const val PHONE_STEP_INTERVAL_MS = 110L
        private const val OBSERVER_GUARD_MS = 260L
        private val PHONE_RAMP_TOKEN = Any()
    }
}
