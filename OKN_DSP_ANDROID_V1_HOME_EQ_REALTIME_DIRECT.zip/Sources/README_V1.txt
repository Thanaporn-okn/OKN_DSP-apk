OKN_DSP V1 — FRESH UI-REFERENCE DIRECT CONTROL BUILD
=====================================================
App: OKN_DSP
Package: com.okn.dsp
versionCode: 1
versionName: 1.0.0-v1

UI MASTER
- Runtime Home screen uses only the exact unannotated Home PNG uploaded by the user.
- Runtime EQ screen uses only the exact unannotated EQ PNG uploaded by the user.
- The two annotated button-description uploads are preserved under evidence only.
- No invented Crossover/Delay/Settings visual screen is added.

V1 REALTIME / DIRECT INPUT BEHAVIOR
- UI value follows the finger immediately; no Apply/OK/Confirm step.
- Each verified scalar/EQ change is submitted directly to AB01 with WRITE_TYPE_NO_RESPONSE.
- No app-level relay queue, no latest-target coalescing, no fixed 38 ms pacing, no Treble slew limiter.
- AES-CFB8 TX state stays synchronized inside the direct write function.
- If Android rejects an encrypted write after cipher state advances, the session fails closed and requires reconnect/auth; bytes are never guessed/reused.

VERIFIED HARDWARE WRITE SCOPE
- BLE AB00 service / AB01 write / AB02 primary notify / AB03 secondary notify.
- Verified Auth16 / RandKey / AES-CFB8 continuous session.
- Verified scalar IDs: 2,3,8,9,10,13,11.
- EQ actuators CH1..CH7: 4,5,6,14,15,16,17.
- 15 EQ records/channel; only PEAKING type=12 is writable; a verified EQ write is always a full 48-byte band record.
- SaveParams ID7 remains manual-only after Health Gate.

BUTTON/TAP COVERAGE
- Home: device/connect, settings, all six verified scalar sliders, ดูเพิ่มเติม, Flat, Pop/Rock/Jazz response, local Save Preset, local Load Preset, Home/EQ/Crossover/Delay/Settings navigation response.
- EQ: device/connect, settings, channel previous/next, Reset, EQ graph drag, six band cards, CH1..CH7 selection, fader/mute/phase guarded response, load from DSP, local load preset, local save preset, bottom navigation response.
- Buttons whose hardware packet is not verified respond in-app but remain fail-closed instead of transmitting guessed bytes.

LOCKED / NOT GUESSED
- hardware Crossover writes
- hardware Delay writes
- hardware Preset recall/write packet
- per-channel Output/Fader/Mute/Phase/routing packets
- generic/unknown actuator writes
- non-PEAKING EQ writes

BUILD
Use the separately delivered build-okn-dsp-v1.yml once in .github/workflows/.
The workflow auto-runs on every root-level OKN_DSP_ANDROID_V*.zip push, detects the highest version automatically, builds that version, and uploads APK + SHA256 artifact files.
For V2 and later, keep the same workflow file in the repository; only upload the new versioned Source ZIP.
