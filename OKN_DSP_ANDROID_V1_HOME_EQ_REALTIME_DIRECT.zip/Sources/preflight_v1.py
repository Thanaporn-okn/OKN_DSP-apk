#!/usr/bin/env python3
from pathlib import Path
import hashlib, re, xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
HOME_HASH = '4b36c253ca41f2cf01f492dab0416094a84019b3fe458a552994072ad2eb6b6d'
EQ_HASH = '6103897128d0707f79fdc7db905e80e38949de2c131fab06eee6595c2c911d16'
HOME_MAP_HASH = '46ea92a85597ee51dff44b1753208bea9f1c3e2ab940227c3483ffe973c9ad8f'
EQ_MAP_HASH = '7201bbdc87cb9f98b4092f39651bb39eb8557bb19e4d9343c9819aed7132084e'
KEYSTORE_HASH = 'ba1c52f2607c09953c52fdd79c5f72026aaf0adb8aa44bcba277f7d9b49d9511'


def die(msg):
    print('ERROR:', msg)
    raise SystemExit(1)

def ok(msg): print('OK:', msg)

def text(rel):
    p = ROOT / rel
    if not p.is_file(): die(f'missing {rel}')
    return p.read_text(encoding='utf-8')

def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''): h.update(chunk)
    return h.hexdigest()

def must(s, marker, where):
    if marker not in s: die(f'missing marker {marker!r} in {where}')

required = [
    'app/build.gradle.kts', 'app/src/main/AndroidManifest.xml', 'app/okn_dsp_stable_debug.keystore',
    'app/src/main/java/com/okn/dsp/MainActivity.kt', 'app/src/main/java/com/okn/dsp/OknDspApplication.kt',
    'app/src/main/java/com/okn/dsp/ui/ReferenceDspUi.kt',
    'app/src/main/res/drawable-nodpi/okn_home_reference.png', 'app/src/main/res/drawable-nodpi/okn_eq_reference.png',
    'evidence/OKN_DSP_V1_HOME_REFERENCE.png', 'evidence/OKN_DSP_V1_EQ_REFERENCE.png', 'evidence/OKN_DSP_V1_HOME_BUTTON_MAP.png', 'evidence/OKN_DSP_V1_EQ_BUTTON_MAP.png',
    'app/src/main/java/com/okn/dsp/ble/BleDspManager.kt', 'app/src/main/java/com/okn/dsp/ble/BleProfile.kt',
    'app/src/main/java/com/okn/dsp/protocol/VerifiedScalarControls.kt', 'app/src/main/java/com/okn/dsp/protocol/WriteGate.kt',
    'app/src/main/java/com/okn/dsp/protocol/SaveParamsPolicy.kt', 'app/src/main/java/com/okn/dsp/protocol/EqBandCodec.kt',
    'app/src/main/java/com/okn/dsp/repository/DspRepository.kt', 'README_V1.txt', 'tools/ProtocolJvmSmoke.kt',
]
for f in required:
    if not (ROOT / f).is_file(): die(f'missing {f}')
ok(f'{len(required)} required files exist')

for forbidden in [
    'app/src/main/java/com/okn/dsp/queue/RealtimeCommandQueue.kt',
    'app/src/main/java/com/okn/dsp/smoothing/ScalarRampController.kt',
    'app/src/main/java/com/okn/dsp/smoothing/EqSlewController.kt',
]:
    if (ROOT / forbidden).exists(): die(f'obsolete V2 realtime limiter still exists: {forbidden}')
ok('obsolete app-level DSP queue/slew source files are absent')

gradle = text('app/build.gradle.kts')
for m in ['applicationId = "com.okn.dsp"', 'versionCode = 1', 'versionName = "1.0.0-v1"', 'compileSdk = 35', 'targetSdk = 35', 'minSdk = 26']:
    must(gradle, m, 'app/build.gradle.kts')
ok('V1 identity/build targets')

try: ET.parse(ROOT / 'app/src/main/AndroidManifest.xml')
except Exception as e: die(f'AndroidManifest invalid: {e}')
manifest = text('app/src/main/AndroidManifest.xml')
for m in ['android:name=".OknDspApplication"', 'android:screenOrientation="portrait"', 'android:label="OKN_DSP"']:
    must(manifest, m, 'AndroidManifest.xml')
ok('manifest contract')

for rel, expected in [
    ('app/src/main/res/drawable-nodpi/okn_home_reference.png', HOME_HASH),
    ('app/src/main/res/drawable-nodpi/okn_eq_reference.png', EQ_HASH),
    ('evidence/OKN_DSP_V1_HOME_REFERENCE.png', HOME_HASH),
    ('evidence/OKN_DSP_V1_EQ_REFERENCE.png', EQ_HASH),
    ('evidence/OKN_DSP_V1_HOME_BUTTON_MAP.png', HOME_MAP_HASH),
    ('evidence/OKN_DSP_V1_EQ_BUTTON_MAP.png', EQ_MAP_HASH),
]:
    if sha(ROOT / rel) != expected: die(f'reference image hash mismatch: {rel}')
if sha(ROOT / 'app/okn_dsp_stable_debug.keystore') != KEYSTORE_HASH: die('stable debug keystore hash changed')
ok('exact Home/EQ references + stable signing identity')

ui = text('app/src/main/java/com/okn/dsp/ui/ReferenceDspUi.kt')
for m in ['R.drawable.okn_home_reference', 'R.drawable.okn_eq_reference', 'HomeReferenceView', 'EqReferenceView', 'initial.tab.coerceIn(0, 1)', 'private val ids = intArrayOf(2, 8, 9, 10, 13, 11)']:
    must(ui, m, 'ReferenceDspUi.kt')
if 'LockedPanel(' in ui or 'ChannelPanel(' in ui or 'OutputPanel(' in ui: die('invented third reference screen leaked into V1 UI')
ok('UI remains limited to two supplied reference screens')

profile = text('app/src/main/java/com/okn/dsp/ble/BleProfile.kt')
for m in ['0000ab00-0000-1000-8000-00805f9b34fb','0000ab01-0000-1000-8000-00805f9b34fb','0000ab02-0000-1000-8000-00805f9b34fb','0000ab03-0000-1000-8000-00805f9b34fb']:
    must(profile, m, 'BleProfile.kt')
ble = text('app/src/main/java/com/okn/dsp/ble/BleDspManager.kt')
for m in ['631C062443FD3844558001F3EDA0CCF8', '@Synchronized', 'private fun sendDirect(', 'WRITE_TYPE_NO_RESPONSE', 'connectionEpoch', 'main.postDelayed(it, 15_000L)']:
    must(ble, m, 'BleDspManager.kt')
for old in ['RealtimeCommandQueue', 'enqueueLatest', 'minPacingMs = 38L', 'queue.onGattResult', 'setRealtimePaused']:
    if old in ble: die(f'obsolete V2 queue marker remains in BleDspManager.kt: {old}')
ok('V1 immediate direct BLE write path is present; V2 queue/pacing path absent')

scalar = text('app/src/main/java/com/okn/dsp/protocol/VerifiedScalarControls.kt')
ids = [int(x) for x in re.findall(r'VerifiedScalarControl\((\d+),', scalar)]
if ids != [2,3,8,9,10,13,11]: die(f'scalar allow-list changed: {ids}')
repo = text('app/src/main/java/com/okn/dsp/repository/DspRepository.kt')
for m in ['ble.sendRealtime("S:$id"', 'LiveEqPolicy.encodeWrite(channel1, band1, target)', 'V1 deliberately does not auto-replay remembered values after reconnect', 'fun saveParamsManual(): Boolean']:
    must(repo, m, 'DspRepository.kt')
for old in ['scalarRamp', 'eqSlew', 'ScalarRampController', 'EqSlewController']:
    if old in repo: die(f'obsolete ramp/slew marker remains in DspRepository.kt: {old}')
ok('verified scalar/EQ controls write directly; reconnect auto-replay burst disabled')

gate = text('app/src/main/java/com/okn/dsp/protocol/WriteGate.kt')
for m in ['const val enabled: Boolean = false','const val presetHardwareWritesEnabled: Boolean = false','const val crossoverWritesEnabled: Boolean = false','const val delayWritesEnabled: Boolean = false','const val unknownOutputWritesEnabled: Boolean = false']:
    must(gate, m, 'WriteGate.kt')
ok('unverified hardware write surfaces remain fail-closed')

all_kt = '\n'.join(p.read_text(errors='ignore') for p in (ROOT / 'app/src/main/java').rglob('*.kt'))
if '0xAA, 0x55' in all_kt or 'AA 55' in all_kt: die('fake AA55 protocol leaked into source')
if 'id == 11 -> 0.5f' in all_kt or 'val delay = if (id == 11) 48L else 38L' in all_kt: die('removed Treble pacing limiter still present')
if all_kt.count('saveParamsManual()') != 2: die('SaveParams manual call/definition count changed')
ok('removed DSP timing policy absent; manual SaveParams boundary preserved')

print('PREFLIGHT_V1_PASS')
