package com.okn.dsp.protocol

/**
 * V49 gate.
 * Generic writes remain disabled. V45 scalar controls remain available because
 * they are already runtime verified. V49 enables exactly one final combined EQ
 * proof for CH1 / ID4 / Band4 using the exact target and exact restore records
 * already verified by V46 and V48. SaveParams ID7, normal EQ writes, presets,
 * delay and unknown actuator writes remain blocked.
 */
object WriteGate {
    const val enabled: Boolean = false
    const val controlledMasterVolumeProofEnabled: Boolean = true
    const val verifiedScalarControlsEnabled: Boolean = true
    const val controlledEqBandProofEnabled: Boolean = false
    const val eqBandRecoveryEnabled: Boolean = false
    const val finalEqWriteRestoreProofEnabled: Boolean = true
}
