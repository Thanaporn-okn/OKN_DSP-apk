#!/usr/bin/env python3
from pathlib import Path
import binascii, re
ROOT=Path(__file__).resolve().parents[1]

def load(rel):
    t=''.join((ROOT/rel).read_text().split())
    assert re.fullmatch(r'[0-9a-f]+',t)
    return bytes.fromhex(t)

info=load('tests/golden/get_info_rsp.vec')
assert info[:6] == bytes.fromhex('4f4b027f0a00')
assert info[6:8] == (33).to_bytes(2,'little')
assert info[8] == 2 and info[9] == 7 and info[10] == 15 and info[11] == 0

caps=load('tests/golden/get_capabilities_rsp.vec')
assert len(caps)==35 and caps[:6] == bytes.fromhex('4f4b02761b00')
assert caps[6] == 1 and caps[7] == 7 and caps[8] == 15 and caps[9] == 2
assert caps[10:12] == (33).to_bytes(2,'little')
assert caps[24:27] == b'\x00\x00\x00'  # HW/mobile readiness bits remain locked.

img=load('tests/golden/persist_default_gen01020304.vec')
assert len(img)==1690
assert img[:4] == b'OKNS'
assert img[4:6] == (2).to_bytes(2,'little')
assert img[6:8] == b'\x00\x00'
assert img[8:12] == (0x01020304).to_bytes(4,'little')
assert img[12:16] == (1670).to_bytes(4,'little')
crc_expected=int.from_bytes(img[16:20],'little')
crc=binascii.crc32(img[:16])
crc=binascii.crc32(img[20:],crc) & 0xffffffff
assert crc==crc_expected
print('ALL V33 WIRE/PERSISTENCE PORTABILITY TESTS PASS')
