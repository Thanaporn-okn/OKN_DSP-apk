#!/usr/bin/env python3
import importlib.util, tempfile, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def load(name,path):
    s=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
tdi=load('tdi',ROOT/'tools/target_document_intake.py')
tcm=load('tcm',ROOT/'tools/target_claim_mapping.py')

with tempfile.TemporaryDirectory() as td:
    td=Path(td)
    doc=td/'vendor.pdf'
    doc.write_bytes(b'%PDF synthetic exact model BP1048P4 document unit-test only\n')
    text=td/'reviewed.txt'
    text.write_text('BP1048P4 reviewed extraction: SRAM capacity is documented in this synthetic test.\n')
    intake=tdi.build_record(doc,'synthetic vendor source','EXACT_TARGET_CANDIDATE',True,text)
    assert intake['review_ready_for_claim_mapping'] is True

    # Valid narrow mapping is supporting evidence only.
    m=tcm.build_mapping(intake,doc,'exact_ram_capacity','EXACT_CHIP_DOCUMENT',
                        'reviewed text line 1','unit-test-reviewer',text)
    assert m['state']=='REVIEWED_SUPPORT_MAPPING_NON_AUTHORIZING'
    assert m['supported_non_authorizing'] is True
    assert m['promoted_to_target_qualification'] is False
    assert m['authorizes_hardware'] is False and m['authorizes_mobile_flash'] is False

    # A chip datasheet can never be re-labeled into a board-routing claim.
    try:
        tcm.build_mapping(intake,doc,'board_audio_route','EXACT_CHIP_DOCUMENT',
                          'line 1','unit-test-reviewer',text)
        raise AssertionError('scope escape unexpectedly accepted')
    except ValueError as e:
        assert 'not allowed for this evidence scope' in str(e)

    # Tampered bytes break the content binding.
    doc.write_bytes(doc.read_bytes()+b'tamper')
    try:
        tcm.build_mapping(intake,doc,'exact_chip_identity','EXACT_CHIP_DOCUMENT',
                          'cover','unit-test-reviewer',text)
        raise AssertionError('tampered document unexpectedly accepted')
    except ValueError as e:
        assert 'SHA256 mismatch' in str(e)

    # Filename/content candidates that were never review-ready cannot be mapped.
    f=td/'BP1048P4_fake.pdf'; f.write_bytes(b'unrelated family bytes')
    not_ready=tdi.build_record(f,'synthetic','EXACT_TARGET_CANDIDATE',True)
    try:
        tcm.build_mapping(not_ready,f,'exact_chip_identity','EXACT_CHIP_DOCUMENT',
                          'filename','unit-test-reviewer')
        raise AssertionError('non-review-ready intake unexpectedly accepted')
    except ValueError as e:
        assert 'not review-ready' in str(e)

print('ALL V33 TARGET CLAIM MAPPING TESTS PASS')
