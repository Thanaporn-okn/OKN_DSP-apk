#!/usr/bin/env python3
from pathlib import Path
import json, subprocess, sys
ROOT=Path(__file__).resolve().parents[1]
m=json.loads((ROOT/"vendor_sdk_binding_manifest.json").read_text())
assert m["project_version"]==33 and m["state"]=="LOCKED_NO_EXACT_VENDOR_BINDING"
assert m["authorizes_hardware"] is False and m["authorizes_mobile_flash"] is False
for cc in ("gcc","clang"):
    cp=subprocess.run([sys.executable,"tools/vendor_sdk_conformance.py","--cc",cc,"--self-test"],cwd=ROOT,text=True,capture_output=True)
    if cp.returncode not in (0,):
        print(cp.stdout); print(cp.stderr); raise SystemExit(cp.returncode)
print("ALL V33 VENDOR SDK CONFORMANCE TESTS PASS")
