#!/usr/bin/env python3
from pathlib import Path
import copy, hashlib, json, os, sys, tempfile
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'tools'))
from hardware_discovery import load_and_verify

# Shipped V33 manifest is empty and locked.
r=load_and_verify(root/'hardware_discovery_manifest.json',root)
assert r['ok'] and r['capture_count']==0 and not r['review_ready']
assert not r['hardware_authorized'] and not r['mobile_flash_authorized'] and not r['programmer_io_available']

with tempfile.TemporaryDirectory() as td:
    td=Path(td); (td/'hardware_probe_evidence').mkdir()
    payload=b'{"transport":"usb_host_enumeration","vid":"synthetic","pid":"synthetic","commands_sent":[]}\n'
    cap=td/'hardware_probe_evidence'/'usb-enumeration.json'; cap.write_bytes(payload)
    sha=hashlib.sha256(payload).hexdigest()
    base={
      'schema':1,'project_version':33,'target':'BP1048P4','board':'GoloPine 7CH',
      'policy':'READ_ONLY_DISCOVERY_NO_VENDOR_COMMANDS_NO_AUTHORIZATION',
      'state':'CAPTURE_READY_FOR_REVIEW_NOT_AUTHORIZED','bundle_root':'hardware_probe_evidence',
      'automatic_authorization':False,'android_host_transport_verified':False,'android_capture_schema':'android_discovery_capture_schema.json','android_capture_importer':'tools/import_android_discovery.py',
      'captures':[{'id':'usb0','kind':'android_usb_enumeration','path':'usb-enumeration.json','sha256':sha,
                   'source':'synthetic-unit-test','reviewed':False,'read_only':True,'commands_sent':[],'write_attempted':False}],
      'safety':{'read_only_only':True,'vendor_commands_allowed':False,'programmer_packets_allowed':False,
                'destructive_io_allowed':False,'capture_does_not_authorize':True,'canonical_capture_hash_required':True}
    }
    mp=td/'hardware_discovery_manifest.json'; mp.write_text(json.dumps(base,indent=2)+'\n')
    rr=load_and_verify(mp,td)
    assert rr['ok'] and rr['review_ready'] and rr['valid_capture_count']==1
    assert not rr['hardware_authorized'] and not rr['mobile_flash_authorized'] and not rr['programmer_io_available']

    bad=copy.deepcopy(base); bad['captures'][0]['sha256']='0'*64; mp.write_text(json.dumps(bad))
    rr=load_and_verify(mp,td); assert not rr['ok'] and any('sha256 mismatch' in e for e in rr['errors'])

    bad=copy.deepcopy(base); bad['captures'][0]['commands_sent']=['vendor-probe']; mp.write_text(json.dumps(bad))
    rr=load_and_verify(mp,td); assert not rr['ok'] and any('commands_sent' in e for e in rr['errors'])

    bad=copy.deepcopy(base); bad['captures'][0]['write_attempted']=True; mp.write_text(json.dumps(bad))
    rr=load_and_verify(mp,td); assert not rr['ok'] and any('write_attempted' in e for e in rr['errors'])

    bad=copy.deepcopy(base); bad['android_host_transport_verified']=True; mp.write_text(json.dumps(bad))
    rr=load_and_verify(mp,td); assert not rr['ok'] and any('may not directly verify' in e for e in rr['errors'])

    outside=td/'outside.txt'; outside.write_text('x')
    bad=copy.deepcopy(base); bad['captures'][0]['path']='../outside.txt'; mp.write_text(json.dumps(bad))
    rr=load_and_verify(mp,td); assert not rr['ok'] and any('traversal' in e for e in rr['errors'])

    # A symlink capture is rejected even when its target content hash matches.
    link=td/'hardware_probe_evidence'/'link.json'
    try:
        link.symlink_to(cap.name)
        bad=copy.deepcopy(base); bad['captures'][0]['path']='link.json'; mp.write_text(json.dumps(bad))
        rr=load_and_verify(mp,td); assert not rr['ok'] and any('symlink' in e for e in rr['errors'])
    except (OSError, NotImplementedError):
        pass

print('ALL V33 HARDWARE DISCOVERY TESTS PASS')
