#!/usr/bin/env python3
import importlib.util, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('tdi',ROOT/'tools/target_document_intake.py')
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
with tempfile.TemporaryDirectory() as td:
    td=Path(td)
    # Filename-only match is explicitly insufficient.
    fake=td/'BP1048P4_datasheet.pdf'; fake.write_bytes(b'%PDF synthetic unrelated family document\nBP1048B2\n')
    r=m.build_record(fake,'synthetic test','EXACT_TARGET_CANDIDATE',True)
    assert r['document']['filename_mentions_target'] is True
    assert r['content_anchor_observed'] is False
    assert r['review_ready_for_claim_mapping'] is False
    assert r['authorizes_hardware'] is False
    # Family document remains non-authorizing even if it happens to mention P4 in comparison text.
    fam=td/'family.txt'; fam.write_text('BP1048B2 family notes compare BP1048P4 by name only\n')
    r=m.build_record(fam,'synthetic test','FAMILY_OR_OTHER',True)
    assert r['content_anchor_observed'] is True
    assert r['review_ready_for_claim_mapping'] is False
    # A separately content-bound reviewed text extraction can make an exact-target candidate
    # review-ready, but still cannot promote any claim or authorize hardware.
    opaque=td/'vendor.pdf'; opaque.write_bytes(b'%PDF opaque compressed bytes\n')
    text=td/'vendor-reviewed.txt'; text.write_text('Reviewed extraction: BP1048P4 exact-model document\n')
    r=m.build_record(opaque,'synthetic vendor source','EXACT_TARGET_CANDIDATE',True,text)
    assert r['document']['filename_mentions_target'] is False
    assert r['text_evidence']['target_token_observed'] is True
    assert r['review_ready_for_claim_mapping'] is True
    assert r['promoted_claims']==[]
    assert r['exact_chip_identity_verified'] is False
    assert r['programmer_transport_verified'] is False
    assert r['authorizes_hardware'] is False and r['authorizes_mobile_flash'] is False
print('ALL V33 TARGET DOCUMENT INTAKE TESTS PASS')
