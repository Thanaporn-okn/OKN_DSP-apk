#!/usr/bin/env python3
from pathlib import Path
import copy, json, sys, tempfile
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'tools'))
from android_discovery_capture import canonical_sha256
from import_android_discovery import import_capture
from discovery_fingerprint import derive
from discovery_review import build_manifest, verify


def usb_capture(nonce):
    c={
      'schema':1,'project_version':33,'format':'OKN_ANDROID_DISCOVERY_CAPTURE','format_version':1,
      'target':'BP1048P4','board':'GoloPine 7CH',
      'policy':'READ_ONLY_ENUMERATION_CANONICAL_HASH_NO_COMMANDS_NO_AUTHORIZATION',
      'transport':'usb_host','read_only':True,'write_attempted':False,'commands_sent':[],
      'source':{'platform':'android','collector':'synthetic-v23-'+nonce,'permission_granted':True},
      'observations':[
        {'kind':'usb_device','operation':'enumerate','metadata':{
          'vendor_id':0x1234,'product_id':0x5678,'device_class':0,
          'manufacturer':'synthetic','product':'synthetic-board','serial_number':'volatile-'+nonce}},
        {'kind':'usb_interface','operation':'read_descriptor','metadata':{
          'interface_number':0,'interface_class':255,'interface_subclass':0,'interface_protocol':0}}
      ],
      'transcript':[{'operation':'enumerate','direction':'metadata','note':'session-'+nonce}],
    }
    c['canonical_sha256']=canonical_sha256(c)
    return c

# Shipped tree must have no review packets and no authorization.
shipped=json.loads((root/'discovery_review_manifest.json').read_text())
r=verify(root,shipped)
assert r['ok'] and shipped['state']=='LOCKED_NO_STABLE_OBSERVATION'
assert shipped['review_packets']==[]
assert not shipped['automatic_promotion'] and not shipped['hardware_authorized']

with tempfile.TemporaryDirectory() as td:
    td=Path(td)
    (td/'hardware_probe_evidence').mkdir()
    hd=json.loads((root/'hardware_discovery_manifest.json').read_text())
    (td/'hardware_discovery_manifest.json').write_text(json.dumps(hd,indent=2)+'\n')

    # Two independent read-only sessions produce OBSERVED_STABLE only.
    for i,nonce in enumerate(('one','two'),1):
        p=td/f'capture-{i}.json'
        p.write_text(json.dumps(usb_capture(nonce),indent=2)+'\n')
        import_capture(td,p,f'usb-session-{i}')

    fp=derive(td)
    assert fp['transports']['usb_host']['state']=='OBSERVED_STABLE'
    (td/'transport_fingerprint_manifest.json').write_text(json.dumps(fp,indent=2)+'\n')

    review=build_manifest(td)
    assert review['state']=='REVIEW_PACKET_AVAILABLE_NOT_AUTHORIZED'
    assert len(review['review_packets'])==1
    pkt=review['review_packets'][0]
    assert pkt['transport']=='usb_host'
    assert pkt['review_state']=='PENDING_HUMAN_REVIEW'
    assert pkt['review_scope']==['android_host_transport_observation']
    assert pkt['exact_target_claims_granted']==[]
    assert pkt['can_promote_target_qualification'] is False
    assert review['hardware_authorized'] is False and review['mobile_flash_authorized'] is False

    (td/'discovery_review_manifest.json').write_text(json.dumps(review,indent=2)+'\n')
    assert verify(td)['ok']

    # Merely editing the derived packet to "approved" is invalid and cannot be promotion.
    tampered=copy.deepcopy(review)
    tampered['review_packets'][0]['reviewed']=True
    tampered['review_packets'][0]['approved']=True
    tampered['review_packets'][0]['exact_target_claims_granted']=['exact_chip_identity']
    assert not verify(td,tampered)['ok']

print('ALL V33 DISCOVERY REVIEW TESTS PASS')
