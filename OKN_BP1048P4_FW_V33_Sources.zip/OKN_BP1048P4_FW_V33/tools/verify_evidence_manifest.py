#!/usr/bin/env python3
from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'evidence_manifest.json').read_text())
errors=[]
if m.get('schema')!=4: errors.append('evidence schema must be 4')
if m.get('project_version')!=33: errors.append('project_version must be 33')
if m.get('target')!='BP1048P4' or m.get('board')!='GoloPine 7CH': errors.append('target/board mismatch')
if m.get('policy')!='FAIL_CLOSED_NO_INFERENCE': errors.append('policy mismatch')
if m.get('hardware_authorized') is not False: errors.append('hardware_authorized must be false')
req=m.get('required_exact_evidence',{})
if any(bool(v) for v in req.values()): errors.append('V33 exact evidence flags must all remain false')
prov=m.get('provenance',{})
if prov.get('previous_source_sha256')!='091f7811091869bac50fd0fb3c49a1e18fbcfb7772b596add1efb16a0ac4a6ad': errors.append('V32 source provenance mismatch')
if prov.get('validation_zip_sha256')!='fe677e0fb0ea5fd404ffe371f7f2cbd075055bcf744a691426185bc936115911': errors.append('V32 validation provenance mismatch')
if not any(o.get('id')=='v32-ci-validation' for o in m.get('observations',[])): errors.append('V32 CI observation missing')
for ob in m.get('observations',[]):
    if ob.get('authorizes') not in ([],None): errors.append('observations may not authorize hardware in V33')
if errors:
    [print('BLOCKED:',e) for e in errors]; sys.exit(1)
print('PASS: V33 evidence manifest is internally consistent and non-authorizing')
