#!/usr/bin/env python3
"""Create a non-authorizing V33 intake record for a supplied artifact.

The output is a candidate bundle entry only. It does not copy the file, mark it
reviewed, bind any target claim, or authorize hardware.
"""
from pathlib import Path
import argparse,hashlib,json,re,sys
p=argparse.ArgumentParser()
p.add_argument('artifact')
p.add_argument('--source',required=True,help='provenance, e.g. vendor URL/email/package label')
p.add_argument('--id',dest='artifact_id',help='stable artifact id; default is sha256 prefix')
a=p.parse_args(); path=Path(a.artifact)
if not path.is_file(): print('not a regular file: '+str(path),file=sys.stderr); sys.exit(2)
h=hashlib.sha256()
with path.open('rb') as f:
    for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
sha=h.hexdigest(); aid=a.artifact_id or ('artifact-'+sha[:16])
if not re.fullmatch(r'[A-Za-z0-9._-]+',aid): print('invalid artifact id',file=sys.stderr); sys.exit(2)
print(json.dumps({
  'schema':1,
  'classification':'UNREVIEWED_INPUT',
  'artifact_id':aid,
  'file_name':path.name,
  'size':path.stat().st_size,
  'sha256':sha,
  'source':a.source,
  'reviewed':False,
  'classifications':[],
  'suggested_bundle_path':'incoming/'+sha+'-'+path.name,
  'verified_claims':[],
  'authorizes':[]
},indent=2))
