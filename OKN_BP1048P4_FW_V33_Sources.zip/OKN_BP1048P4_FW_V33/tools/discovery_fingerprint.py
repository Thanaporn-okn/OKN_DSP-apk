#!/usr/bin/env python3
"""V33 multi-capture transport fingerprint derivation.

This module analyzes already-validated Android read-only discovery captures.
It performs no USB/BLE/serial I/O, sends no commands, excludes volatile
identifiers, and never authorizes hardware or mobile flashing.
"""
from __future__ import annotations
from pathlib import Path
import argparse, hashlib, json
from hardware_discovery import load_and_verify, _safe_capture
from android_discovery_capture import validate_capture_file

PROJECT_VERSION = 33
SCHEMA = 1
POLICY = "MULTI_CAPTURE_STABILITY_OBSERVATION_NO_AUTHORIZATION"
MIN_STABLE_SESSIONS = 2

# Deliberately excludes USB serial numbers, BLE addresses, RSSI, timestamps,
# and opaque transcript bytes. Only structural enumeration metadata is used.
STABLE_FIELDS = {
    "usb_device": ("vendor_id","product_id","device_class","device_subclass","device_protocol","manufacturer","product"),
    "usb_interface": ("interface_number","interface_class","interface_subclass","interface_protocol"),
    "usb_endpoint": ("address","direction","transfer_type","attributes","max_packet_size"),
    "usb_descriptor": ("descriptor_type","descriptor_subtype"),
    "ble_advertisement": ("service_uuids","manufacturer_id"),
    "ble_service": ("uuid","primary"),
    "ble_characteristic": ("service_uuid","uuid","properties"),
    "ble_descriptor": ("characteristic_uuid","uuid"),
    "serial_device": ("vendor_id","product_id","driver","device_class"),
    "serial_port_metadata": ("port_index","port_type","driver"),
}


def _normalize(v):
    if isinstance(v, dict):
        return {str(k): _normalize(v[k]) for k in sorted(v)}
    if isinstance(v, list):
        vals=[_normalize(x) for x in v]
        try:
            return sorted(vals, key=lambda x: json.dumps(x, sort_keys=True, separators=(",",":")))
        except Exception:
            return vals
    if isinstance(v, (str,int,float,bool)) or v is None:
        return v
    return str(v)


def identity_tokens(capture: dict) -> list[dict]:
    tokens=[]
    for rec in capture.get("observations",[]):
        if not isinstance(rec,dict):
            continue
        kind=rec.get("kind")
        fields=STABLE_FIELDS.get(kind)
        if not fields:
            continue
        meta=rec.get("metadata",{})
        if not isinstance(meta,dict):
            continue
        selected={k:_normalize(meta[k]) for k in fields if k in meta}
        if selected:
            tokens.append({"kind":kind,"metadata":selected})
    tokens.sort(key=lambda x: json.dumps(x,sort_keys=True,separators=(",",":")))
    return tokens


def fingerprint_sha256(tokens: list[dict]) -> str:
    raw=json.dumps(tokens,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def derive(root: Path) -> dict:
    root=Path(root).resolve()
    manifest_path=root/"hardware_discovery_manifest.json"
    vr=load_and_verify(manifest_path,root)
    if not vr["ok"]:
        raise ValueError("hardware discovery manifest invalid: "+"; ".join(vr["errors"]))
    hm=json.loads(manifest_path.read_text())
    bundle_root=hm.get("bundle_root")
    sessions={"usb_host":[],"ble":[],"serial_enumeration":[]}
    skipped=[]
    for rec in hm.get("captures",[]):
        if rec.get("capture_format")!="android_discovery_capture_v1":
            skipped.append(rec.get("id"))
            continue
        full,err=_safe_capture(root,bundle_root,rec.get("path"))
        if err:
            raise ValueError("capture path invalid: "+err)
        inner=validate_capture_file(full)
        if not inner.get("ok"):
            raise ValueError("Android capture invalid: "+"; ".join(inner.get("errors",[])))
        cap=json.loads(full.read_text())
        transport=inner["transport"]
        tokens=identity_tokens(cap)
        fp=fingerprint_sha256(tokens)
        sessions[transport].append({
            "capture_id":rec.get("id"),
            "raw_sha256":rec.get("sha256"),
            "canonical_sha256":rec.get("canonical_sha256"),
            "fingerprint_sha256":fp,
            "identity_token_count":len(tokens),
        })

    summaries={}
    any_capture=False
    any_inconsistent=False
    for transport,items in sessions.items():
        n=len(items); any_capture |= n>0
        unique=sorted({x["fingerprint_sha256"] for x in items})
        if n==0:
            state="LOCKED_NO_CAPTURE"; stable=None
        elif n==1:
            state="OBSERVED_ONCE"; stable=None
        elif len(unique)==1:
            state="OBSERVED_STABLE"; stable=unique[0]
        else:
            state="INCONSISTENT"; stable=None; any_inconsistent=True
        summaries[transport]={
            "state":state,
            "session_count":n,
            "unique_fingerprint_count":len(unique),
            "minimum_sessions_for_observed_stable":MIN_STABLE_SESSIONS,
            "stable_fingerprint_sha256":stable,
            "capture_bindings":items,
            "hardware_authorized":False,
            "mobile_flash_authorized":False,
        }

    overall = "LOCKED_NO_CAPTURE"
    if any_capture:
        overall = "INCONSISTENT" if any_inconsistent else "OBSERVATION_AVAILABLE_NOT_AUTHORIZED"
    return {
        "schema":SCHEMA,
        "project_version":PROJECT_VERSION,
        "target":"BP1048P4",
        "board":"GoloPine 7CH",
        "policy":POLICY,
        "state":overall,
        "minimum_sessions_for_observed_stable":MIN_STABLE_SESSIONS,
        "volatile_identifiers_excluded":["usb_serial_number","ble_address","rssi","timestamp","opaque_transcript_payload"],
        "automatic_authorization":False,
        "android_host_transport_verified":False,
        "programmer_io_available":False,
        "skipped_non_android_capture_ids":skipped,
        "transports":summaries,
    }


def main() -> int:
    ap=argparse.ArgumentParser(description="Derive V33 read-only multi-capture transport fingerprints; performs no hardware I/O.")
    ap.add_argument("--root",default=".")
    ap.add_argument("--write")
    ap.add_argument("--expect-empty",action="store_true")
    a=ap.parse_args()
    root=Path(a.root).resolve()
    report=derive(root)
    if a.write:
        (root/a.write).write_text(json.dumps(report,indent=2)+"\n")
    else:
        print(json.dumps(report,indent=2))
    if a.expect_empty:
        if report["state"]!="LOCKED_NO_CAPTURE":
            print("ERROR: shipped V33 fingerprint report must remain empty/locked")
            return 1
        if any(v["session_count"] for v in report["transports"].values()):
            print("ERROR: shipped V33 fingerprint report contains sessions")
            return 1
    return 0

if __name__=="__main__":
    raise SystemExit(main())
