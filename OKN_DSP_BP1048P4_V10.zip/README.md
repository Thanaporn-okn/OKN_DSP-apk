# OKN_DSP BP1048P4 V10

Next step:
- Device Scan
- Bluetooth device selection
- BP1048P4 command packet structure
- TX/RX log preparation
