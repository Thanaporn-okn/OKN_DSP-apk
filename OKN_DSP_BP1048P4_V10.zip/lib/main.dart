
// OKN_DSP BP1048P4 V10
// Device Scan + Bluetooth communication stage
void main() {
  print('OKN DSP V10');
}
