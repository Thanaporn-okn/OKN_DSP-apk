
class DSPCommand {
  static List<int> volume(int ch, int value) {
    return [0xAA, 0x55, 0x01, ch, value, checksum([0x01,ch,value])];
  }

  static int checksum(List<int> data) {
    return data.fold(0, (a,b) => (a+b) & 0xFF);
  }
}
