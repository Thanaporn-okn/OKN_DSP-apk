# Heavy Market v5

แอป Android สำหรับรวมประกาศขายสินค้ามือสอง โดยเน้นรถบรรทุก รถหกล้อ รถดั้ม รถแม็คโค รถไถ หัวลาก เครื่องจักร และอะไหล่มือสอง

## สิ่งที่ปรับใน v5
- UI ใหม่ตามแบบ Heavy Market: หัวแอปสีน้ำเงิน การ์ดสินค้าแบบมีรูป ราคา จังหวัด เวลา และป้าย “มือสอง”
- หน้าแรกแสดงโพสต์ล่าสุดและรีเฟรชอัตโนมัติทุก 30 วินาที
- หน้าสินค้าในกลุ่มมีแถบกลุ่มที่ติดตาม และรายการจากแหล่งกลุ่ม
- หน้า Marketplace มีเมนูหมวดหมู่แบบ grid และตัวกรองมือสอง/หมวดรถ
- รองรับ `imageUrl` จาก backend; ถ้าไม่มีรูปจะใช้รูปตัวอย่างตามหมวด
- รองรับ Share ข้อความ/ลิงก์จาก Facebook เข้า Heavy Market
- ถ้าไม่ได้ตั้ง `DATA_API_BASE` แอปจะแสดงข้อมูลตัวอย่างเพื่อทดสอบ UI

## Backend
ตั้ง GitHub Actions Repository Variable ชื่อ `DATA_API_BASE` ให้เป็น URL backend เช่น `https://example.com/api`

แอปเรียก:
`GET {DATA_API_BASE}/feed?source=latest|groups|marketplace&q=...`

ดูรูปแบบ JSON เพิ่มเติมใน `docs/BACKEND_API_TH.md`

## หมายเหตุ Facebook
การอ่านข้อมูล Facebook/Groups/Marketplace ต้องใช้แหล่งข้อมูลและสิทธิ์ที่ Meta อนุญาต แอปนี้ไม่ฝังรหัสผ่าน Facebook และไม่ทำ automated scraping โดยตรง
