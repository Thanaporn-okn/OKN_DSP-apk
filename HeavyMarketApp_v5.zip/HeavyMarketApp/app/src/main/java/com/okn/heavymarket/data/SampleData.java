package com.okn.heavymarket.data;

import com.okn.heavymarket.model.Listing;
import java.util.ArrayList;
import java.util.List;

public final class SampleData {
    private SampleData() {}

    public static List<Listing> create(String source) {
        long now = System.currentTimeMillis();
        List<Listing> a = new ArrayList<>();
        if ("groups".equals(source)) {
            a.add(new Listing("g1", "HINO FM1A 10 ล้อดั้ม ปี 2558", "เจ้าของขายเอง รถพร้อมทำงาน เอกสารครบ", 1480000, "ขอนแก่น", "รถดั้ม", "groups", "ซื้อขายรถบรรทุกมือสอง", "drawable:demo_dump", "", now - 2 * 60_000));
            a.add(new Listing("g2", "CAT 320D2 ปี 2013", "แม็คโคมือสอง ช่วงล่างดี เครื่องแน่น พร้อมใช้งาน", 890000, "อุดรธานี", "รถแม็คโค", "groups", "ซื้อขายเครื่องจักรหนัก", "drawable:demo_excavator", "", now - 5 * 60_000));
            a.add(new Listing("g3", "ISUZU DECA 270 รถดั้ม", "มือสอง สภาพพร้อมใช้งาน สนใจนัดดูรถได้", 1050000, "นครราชสีมา", "รถดั้ม", "groups", "ตลาดรถดั้ม รถหกล้อ", "drawable:demo_dump", "", now - 11 * 60_000));
            a.add(new Listing("g4", "Kubota M6040 พร้อมใบดัน", "รถไถมือสอง เจ้าของขายเอง พร้อมอุปกรณ์", 420000, "ร้อยเอ็ด", "รถไถ", "groups", "รถไถมือสองภาคอีสาน", "drawable:demo_tractor", "", now - 18 * 60_000));
            a.add(new Listing("g5", "ชุดเฟืองท้าย Hino มือสอง", "อะไหล่ถอดจากรถใช้งานได้ปกติ ส่งทั่วไทย", 38000, "กรุงเทพมหานคร", "อะไหล่", "groups", "อะไหล่รถบรรทุกมือสอง", "drawable:demo_parts", "", now - 28 * 60_000));
        } else if ("marketplace".equals(source)) {
            a.add(new Listing("m1", "ISUZU GIGA 360 ปี 2016", "รถบรรทุกมือสอง สภาพพร้อมวิ่ง เอกสารครบ", 1750000, "กรุงเทพมหานคร", "รถบรรทุก", "marketplace", "", "drawable:demo_truck", "", now - 30 * 60_000));
            a.add(new Listing("m2", "KOBELCO SK200-10", "รถขุดมือสอง พร้อมทำงาน สนใจนัดดูเครื่อง", 1250000, "ระยอง", "รถแม็คโค", "marketplace", "", "drawable:demo_excavator", "", now - 60 * 60_000));
            a.add(new Listing("m3", "HINO VICTOR 344 สิบล้อ", "รถบ้านมือสอง พร้อมใช้งาน", 1920000, "ชลบุรี", "รถบรรทุก", "marketplace", "", "drawable:demo_truck", "", now - 90 * 60_000));
            a.add(new Listing("m4", "รถไถ Kubota L5018", "รถไถมือสอง พร้อมใบดันและผาน", 480000, "ขอนแก่น", "รถไถ", "marketplace", "", "drawable:demo_tractor", "", now - 115 * 60_000));
            a.add(new Listing("m5", "ดั้ม 6 ล้อ ISUZU", "พร้อมทำงาน เจ้าของขายเอง", 980000, "นครราชสีมา", "รถดั้ม", "marketplace", "", "drawable:demo_dump", "", now - 145 * 60_000));
        } else {
            a.add(new Listing("l1", "HINO 500 10 ล้อ ดั้ม ปี 2559", "รถมือสองพร้อมใช้งาน เอกสารครบ เจ้าของขายเอง", 1650000, "กรุงเทพมหานคร", "รถดั้ม", "latest", "เพจรถบรรทุกมือสอง", "drawable:demo_dump", "", now - 2 * 60_000));
            a.add(new Listing("l2", "KOMATSU PC200-8", "แม็คโคมือสอง ช่วงล่างแน่น พร้อมทำงาน", 950000, "ชลบุรี", "รถแม็คโค", "latest", "เพจเครื่องจักรหนัก", "drawable:demo_excavator", "", now - 8 * 60_000));
            a.add(new Listing("l3", "ISUZU FTR 240 หกล้อ", "รถหกล้อมือสอง เจ้าของขายเอง พร้อมวิ่ง", 980000, "นครราชสีมา", "หกล้อ", "latest", "เพจรถบรรทุกมือสอง", "drawable:demo_truck", "", now - 12 * 60_000));
            a.add(new Listing("l4", "รถไถ Kubota L5018", "มือสอง พร้อมอุปกรณ์ สนใจนัดดูรถ", 480000, "ขอนแก่น", "รถไถ", "latest", "ตลาดรถไถมือสอง", "drawable:demo_tractor", "", now - 15 * 60_000));
            a.add(new Listing("l5", "หัวลาก HINO 700", "รถมือสองพร้อมลาก เอกสารครบ", 1350000, "สระบุรี", "หัวลาก", "latest", "รถหัวลากมือสอง", "drawable:demo_truck", "", now - 25 * 60_000));
            a.add(new Listing("l6", "ยางพร้อมกะทะ 10 ล้อ", "อะไหล่มือสอง สภาพดี 6 ชุด", 45000, "อยุธยา", "อะไหล่", "latest", "อะไหล่รถบรรทุก", "drawable:demo_parts", "", now - 35 * 60_000));
        }
        return a;
    }
}
