package com.okn.heavymarket;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.okn.heavymarket.data.ListingRepository;
import com.okn.heavymarket.data.LocalImportStore;
import com.okn.heavymarket.data.SaleClassifier;
import com.okn.heavymarket.model.Listing;
import com.okn.heavymarket.ui.Ui;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int BLUE = Color.rgb(18, 84, 154);
    private static final int BLUE_DARK = Color.rgb(10, 61, 120);
    private static final int GREEN = Color.rgb(0, 146, 83);
    private static final int BG = Color.rgb(244, 246, 248);
    private static final int TEXT = Color.rgb(17, 24, 39);
    private static final int MUTED = Color.rgb(100, 116, 139);
    private static final int BORDER = Color.rgb(226, 232, 240);

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService imageExecutor = Executors.newFixedThreadPool(3);
    private final Map<String, Bitmap> imageCache = new ConcurrentHashMap<>();
    private final Map<String, TextView> navButtons = new HashMap<>();

    private ListingRepository repository;
    private LinearLayout root;
    private LinearLayout content;
    private LinearLayout listContainer;
    private TextView status;
    private EditText search;
    private ProgressBar progress;
    private String currentSource = "latest";
    private String categoryFilter = "ทั้งหมด";
    private String conditionFilter = "มือสองเด่น";
    private List<Listing> currentItems = new ArrayList<>();

    private final Runnable autoRefresh = new Runnable() {
        @Override public void run() {
            refresh(false);
            handler.postDelayed(this, 30_000);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        repository = new ListingRepository(this);
        handleShareIntent(getIntent());
        buildShell();
        selectPage("latest");
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleShareIntent(intent);
        selectPage("latest");
    }

    @Override protected void onResume() {
        super.onResume();
        handler.removeCallbacks(autoRefresh);
        handler.postDelayed(autoRefresh, 30_000);
    }

    @Override protected void onPause() {
        handler.removeCallbacks(autoRefresh);
        super.onPause();
    }

    @Override protected void onDestroy() {
        imageExecutor.shutdownNow();
        super.onDestroy();
    }

    private void handleShareIntent(Intent intent) {
        if (intent == null || !Intent.ACTION_SEND.equals(intent.getAction())) return;
        String text = intent.getStringExtra(Intent.EXTRA_TEXT);
        if (text != null && !text.trim().isEmpty()) {
            LocalImportStore.addSharedPost(this, text);
            Toast.makeText(this, "บันทึกโพสต์ที่แชร์เข้า Heavy Market แล้ว", Toast.LENGTH_LONG).show();
        }
    }

    private void buildShell() {
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().setNavigationBarColor(Color.WHITE);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        setContentView(root);

        root.addView(buildTopBar(), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, 0, 0, Ui.dp(this, 10));
        ScrollView scroller = new ScrollView(this);
        scroller.setFillViewport(true);
        scroller.setClipToPadding(false);
        scroller.addView(content, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroller, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        root.addView(buildBottomNav(), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 68)));
    }

    private View buildTopBar() {
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL);
        top.setBackgroundColor(Color.WHITE);
        Ui.pad(top, 14, 10, 14, 8);
        top.setElevation(Ui.dp(this, 2));

        LinearLayout brandRow = new LinearLayout(this);
        brandRow.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(brandRow, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 46)));

        TextView logo = Ui.text(this, "🚚", 24, false);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(Ui.rounded(Color.rgb(232, 241, 251), 12, this));
        brandRow.addView(logo, new LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 44)));

        LinearLayout brandText = new LinearLayout(this);
        brandText.setOrientation(LinearLayout.VERTICAL);
        brandText.setPadding(Ui.dp(this, 10), 0, 0, 0);
        brandRow.addView(brandText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        TextView title = Ui.text(this, "Heavy Market", 21, true);
        title.setTextColor(BLUE_DARK);
        brandText.addView(title);
        TextView sub = Ui.text(this, "รถมือสอง • เครื่องจักรมือสอง", 11, false);
        sub.setTextColor(MUTED);
        brandText.addView(sub);

        TextView bell = Ui.text(this, "♡", 27, false);
        bell.setGravity(Gravity.CENTER);
        brandRow.addView(bell, new LinearLayout.LayoutParams(Ui.dp(this, 46), Ui.dp(this, 44)));

        LinearLayout searchRow = new LinearLayout(this);
        searchRow.setGravity(Gravity.CENTER_VERTICAL);
        searchRow.setBackground(Ui.roundedStroke(Color.rgb(248, 250, 252), BORDER, 1, 24, this));
        Ui.pad(searchRow, 12, 0, 6, 0);
        LinearLayout.LayoutParams srLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 46));
        srLp.topMargin = Ui.dp(this, 9);
        top.addView(searchRow, srLp);

        TextView searchIcon = Ui.text(this, "⌕", 25, false);
        searchIcon.setTextColor(MUTED);
        searchRow.addView(searchIcon, new LinearLayout.LayoutParams(Ui.dp(this, 30), ViewGroup.LayoutParams.MATCH_PARENT));

        search = new EditText(this);
        search.setHint("ค้นหา เช่น รถดั้ม Hino ขอนแก่น");
        search.setTextSize(14);
        search.setSingleLine(true);
        search.setBackgroundColor(Color.TRANSPARENT);
        search.setPadding(0, 0, 0, 0);
        search.setOnEditorActionListener((v, actionId, event) -> { refresh(true); return true; });
        searchRow.addView(search, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1));

        TextView go = Ui.text(this, "ค้นหา", 13, true);
        go.setTextColor(Color.WHITE);
        go.setGravity(Gravity.CENTER);
        go.setBackground(Ui.rounded(BLUE, 18, this));
        go.setOnClickListener(v -> refresh(true));
        searchRow.addView(go, new LinearLayout.LayoutParams(Ui.dp(this, 70), Ui.dp(this, 36)));

        LinearLayout stateRow = new LinearLayout(this);
        stateRow.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(stateRow, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 27)));

        status = Ui.text(this, "กำลังเตรียมข้อมูล…", 10, false);
        status.setTextColor(MUTED);
        stateRow.addView(status, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        TextView live = Ui.text(this, "● LIVE", 10, true);
        live.setTextColor(Color.rgb(220, 38, 38));
        stateRow.addView(live);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setIndeterminate(true);
        progress.setVisibility(View.GONE);
        top.addView(progress, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 2)));
        return top;
    }

    private View buildBottomNav() {
        LinearLayout nav = new LinearLayout(this);
        nav.setBackgroundColor(Color.WHITE);
        nav.setGravity(Gravity.CENTER);
        nav.setElevation(Ui.dp(this, 10));
        addNav(nav, "⌂", "หน้าแรก", "latest");
        addNav(nav, "♟", "สินค้าในกลุ่ม", "groups");
        addNav(nav, "▣", "Marketplace", "marketplace");
        return nav;
    }

    private void addNav(LinearLayout nav, String icon, String label, String source) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        item.setClickable(true);
        item.setOnClickListener(v -> selectPage(source));

        TextView i = Ui.text(this, icon, 24, true);
        i.setGravity(Gravity.CENTER);
        item.addView(i, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 31)));
        TextView t = Ui.text(this, label, 11, false);
        t.setGravity(Gravity.CENTER);
        item.addView(t, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 26)));
        nav.addView(item, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1));
        navButtons.put(source + ":icon", i);
        navButtons.put(source + ":text", t);
    }

    private void updateBottomNav() {
        String[] sources = {"latest", "groups", "marketplace"};
        for (String s : sources) {
            int c = s.equals(currentSource) ? Color.rgb(25, 118, 210) : Color.rgb(55, 65, 81);
            TextView i = navButtons.get(s + ":icon");
            TextView t = navButtons.get(s + ":text");
            if (i != null) i.setTextColor(c);
            if (t != null) {
                t.setTextColor(c);
                t.setTypeface(Typeface.DEFAULT, s.equals(currentSource) ? Typeface.BOLD : Typeface.NORMAL);
            }
        }
    }

    private void selectPage(String source) {
        currentSource = source;
        categoryFilter = "ทั้งหมด";
        conditionFilter = "มือสองเด่น";
        updateBottomNav();
        buildPage();
        refresh(true);
    }

    private void buildPage() {
        content.removeAllViews();
        if ("latest".equals(currentSource)) addLatestHeader();
        if ("groups".equals(currentSource)) addGroupsHeader();
        if ("marketplace".equals(currentSource)) addMarketplaceHeader();
        addConditionFilters();
        addCategoryFilters();

        listContainer = new LinearLayout(this);
        listContainer.setOrientation(LinearLayout.VERTICAL);
        content.addView(listContainer, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        renderItems();
    }

    private void addLatestHeader() {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        Ui.pad(row, 16, 14, 16, 4);
        content.addView(row);
        TextView h = Ui.text(this, "โพสต์และสินค้าล่าสุด", 20, true);
        row.addView(h, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        TextView refresh = Ui.text(this, "↻  รีเฟรช", 12, true);
        refresh.setTextColor(BLUE);
        refresh.setOnClickListener(v -> refresh(true));
        row.addView(refresh);
        TextView p = Ui.text(this, "คัดโพสต์ขายสินค้ามือสองเกี่ยวกับรถบรรทุกและเครื่องจักรขึ้นก่อน", 12, false);
        p.setTextColor(MUTED);
        Ui.pad(p, 16, 0, 16, 6);
        content.addView(p);
    }

    private void addGroupsHeader() {
        TextView h = Ui.text(this, "สินค้าในกลุ่ม", 20, true);
        Ui.pad(h, 16, 14, 16, 2);
        content.addView(h);
        TextView p = Ui.text(this, "รวมประกาศจากกลุ่มที่เชื่อมต่อหรือโพสต์ที่คุณแชร์เข้า Heavy Market", 12, false);
        p.setTextColor(MUTED);
        Ui.pad(p, 16, 0, 16, 8);
        content.addView(p);

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Ui.pad(row, 12, 2, 12, 8);
        hsv.addView(row);
        addGroupTile(row, "🚚", "ซื้อขายรถบรรทุก", "รถบรรทุก • ดั้ม • หกล้อ");
        addGroupTile(row, "🏗", "เครื่องจักรหนัก", "แม็คโค • รถตัก • แบคโฮ");
        addGroupTile(row, "🚜", "รถไถมือสอง", "รถไถ • อุปกรณ์เกษตร");
        content.addView(hsv);
    }

    private void addGroupTile(LinearLayout row, String icon, String name, String subtitle) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setBackground(Ui.rounded(Color.WHITE, 14, this));
        tile.setElevation(Ui.dp(this, 1));
        Ui.pad(tile, 12, 10, 12, 10);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(this, 185), Ui.dp(this, 96));
        lp.setMargins(Ui.dp(this, 4), 0, Ui.dp(this, 4), 0);
        row.addView(tile, lp);
        TextView i = Ui.text(this, icon + "  " + name, 13, true);
        i.setTextColor(BLUE_DARK);
        tile.addView(i);
        TextView s = Ui.text(this, subtitle, 11, false);
        s.setTextColor(MUTED);
        s.setPadding(0, Ui.dp(this, 6), 0, 0);
        tile.addView(s);
        TextView badge = Ui.text(this, "กำลังติดตาม", 10, true);
        badge.setTextColor(GREEN);
        badge.setPadding(0, Ui.dp(this, 7), 0, 0);
        tile.addView(badge);
    }

    private void addMarketplaceHeader() {
        TextView h = Ui.text(this, "Marketplace", 22, true);
        Ui.pad(h, 16, 14, 16, 2);
        content.addView(h);
        TextView p = Ui.text(this, "ค้นหารถและเครื่องจักรมือสองตามหมวด ราคา จังหวัด และยี่ห้อ", 12, false);
        p.setTextColor(MUTED);
        Ui.pad(p, 16, 0, 16, 8);
        content.addView(p);

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(4);
        grid.setAlignmentMode(GridLayout.ALIGN_BOUNDS);
        Ui.pad(grid, 10, 2, 10, 8);
        content.addView(grid, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        addMarketMenu(grid, "🚚", "รถบรรทุก", "รถบรรทุก");
        addMarketMenu(grid, "🚛", "รถดั้ม", "รถดั้ม");
        addMarketMenu(grid, "🏗", "แม็คโค", "แม็คโค");
        addMarketMenu(grid, "🚜", "รถไถ", "รถไถ");
        addMarketMenu(grid, "▰", "หัวลาก", "หัวลาก");
        addMarketMenu(grid, "⚙", "อะไหล่", "อะไหล่");
        addMarketMenu(grid, "◫", "เครื่องจักร", "เครื่องจักร");
        addMarketMenu(grid, "•••", "ทั้งหมด", "ทั้งหมด");
    }

    private void addMarketMenu(GridLayout grid, String icon, String label, String cat) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.CENTER);
        tile.setBackground(Ui.rounded(Color.WHITE, 14, this));
        tile.setOnClickListener(v -> { categoryFilter = cat; buildPage(); });
        GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
        lp.width = 0;
        lp.height = Ui.dp(this, 80);
        lp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        lp.setMargins(Ui.dp(this, 4), Ui.dp(this, 4), Ui.dp(this, 4), Ui.dp(this, 4));
        grid.addView(tile, lp);
        TextView i = Ui.text(this, icon, 22, false);
        i.setGravity(Gravity.CENTER);
        tile.addView(i, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 40)));
        TextView t = Ui.text(this, label, 11, cat.equals(categoryFilter));
        t.setGravity(Gravity.CENTER);
        t.setTextColor(cat.equals(categoryFilter) ? BLUE : TEXT);
        tile.addView(t, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 26)));
    }

    private void addConditionFilters() {
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        Ui.pad(chips, 12, 5, 12, 2);
        hsv.addView(chips);
        String[] conditions = {"มือสองเด่น", "มือสองเท่านั้น", "ดูทั้งหมด"};
        for (String condition : conditions) {
            TextView b = chip(condition, condition.equals(conditionFilter));
            b.setOnClickListener(v -> { conditionFilter = condition; buildPage(); });
            chips.addView(b);
        }
        content.addView(hsv);
    }

    private void addCategoryFilters() {
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        Ui.pad(chips, 12, 4, 12, 8);
        hsv.addView(chips);
        String[] cats = {"ทั้งหมด", "รถบรรทุก", "หกล้อ", "รถดั้ม", "แม็คโค", "รถไถ", "หัวลาก", "อะไหล่", "อื่นๆ"};
        for (String cat : cats) {
            TextView b = chip(iconFor(cat) + " " + cat, cat.equals(categoryFilter));
            b.setOnClickListener(v -> { categoryFilter = cat; buildPage(); });
            chips.addView(b);
        }
        content.addView(hsv);
    }

    private TextView chip(String text, boolean selected) {
        TextView b = Ui.text(this, text, 12, selected);
        b.setGravity(Gravity.CENTER);
        b.setTextColor(selected ? Color.WHITE : Color.rgb(51, 65, 85));
        b.setBackground(selected ? Ui.rounded(BLUE, 18, this) : Ui.roundedStroke(Color.WHITE, BORDER, 1, 18, this));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, Ui.dp(this, 38));
        lp.setMargins(Ui.dp(this, 3), 0, Ui.dp(this, 3), 0);
        b.setLayoutParams(lp);
        Ui.pad(b, 14, 0, 14, 0);
        return b;
    }

    private String iconFor(String cat) {
        if ("รถบรรทุก".equals(cat) || "หกล้อ".equals(cat)) return "🚚";
        if ("รถดั้ม".equals(cat)) return "🚛";
        if ("แม็คโค".equals(cat)) return "🏗";
        if ("รถไถ".equals(cat)) return "🚜";
        if ("หัวลาก".equals(cat)) return "▰";
        if ("อะไหล่".equals(cat)) return "⚙";
        if ("ทั้งหมด".equals(cat)) return "▦";
        return "•••";
    }

    private void refresh(boolean showSpinner) {
        if (showSpinner) progress.setVisibility(View.VISIBLE);
        final String q = search == null ? "" : search.getText().toString();
        repository.load(currentSource, q, (items, message) -> runOnUiThread(() -> {
            progress.setVisibility(View.GONE);
            currentItems = items;
            status.setText(message + " • " + new SimpleDateFormat("HH:mm:ss", new Locale("th", "TH")).format(new Date()));
            renderItems();
        }));
    }

    private void renderItems() {
        if (listContainer == null) return;
        listContainer.removeAllViews();

        List<Listing> visible = new ArrayList<>();
        for (Listing i : currentItems) {
            if (!matchesCategory(i, categoryFilter)) continue;
            if ("มือสองเท่านั้น".equals(conditionFilter) && !SaleClassifier.isLikelyUsed(i)) continue;
            if ("มือสองเด่น".equals(conditionFilter) && SaleClassifier.isExplicitlyNew(i)) continue;
            visible.add(i);
        }
        visible.sort((a, b) -> {
            if (!"ดูทั้งหมด".equals(conditionFilter)) {
                int used = Integer.compare(SaleClassifier.usedPriority(b), SaleClassifier.usedPriority(a));
                if (used != 0) return used;
            }
            return Long.compare(b.createdAt, a.createdAt);
        });

        LinearLayout heading = new LinearLayout(this);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        Ui.pad(heading, 16, 8, 16, 5);
        listContainer.addView(heading);
        TextView count = Ui.text(this, titleForSource() + "  " + visible.size() + " รายการ", 16, true);
        heading.addView(count, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        TextView sort = Ui.text(this, "ล่าสุด ▾", 12, true);
        sort.setTextColor(BLUE);
        heading.addView(sort);

        if (visible.isEmpty()) {
            TextView empty = Ui.text(this, "ยังไม่มีรายการที่ตรงกับตัวกรอง\nลองเลือกหมวดอื่นหรือกด “ดูทั้งหมด”", 14, false);
            empty.setGravity(Gravity.CENTER);
            empty.setTextColor(MUTED);
            Ui.pad(empty, 20, 70, 20, 70);
            listContainer.addView(empty);
            return;
        }

        for (Listing item : visible) listContainer.addView(card(item));
    }

    private String titleForSource() {
        if ("groups".equals(currentSource)) return "โพสต์ล่าสุดในกลุ่ม";
        if ("marketplace".equals(currentSource)) return "สินค้า Marketplace";
        return "โพสต์ล่าสุด";
    }

    private boolean matchesCategory(Listing i, String filter) {
        if ("ทั้งหมด".equals(filter)) return true;
        String text = (i.category + " " + i.title + " " + i.description).toLowerCase();
        if ("เครื่องจักร".equals(filter)) return text.contains("แม็ค") || text.contains("รถขุด") || text.contains("เครื่องจักร") || text.contains("รถตัก") || text.contains("แบคโฮ");
        if ("รถบรรทุก".equals(filter)) return text.contains("บรรทุก") || text.contains("หกล้อ") || text.contains("หก ล้อ") || text.contains("สิบล้อ") || text.contains("ดั้ม") || text.contains("หัวลาก");
        return text.contains(filter.toLowerCase());
    }

    private View card(Listing item) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.TOP);
        card.setBackground(Ui.rounded(Color.WHITE, 14, this));
        card.setElevation(Ui.dp(this, 1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 138));
        lp.setMargins(Ui.dp(this, 12), Ui.dp(this, 5), Ui.dp(this, 12), Ui.dp(this, 5));
        card.setLayoutParams(lp);
        Ui.pad(card, 8, 8, 8, 8);

        FrameLayout photo = new FrameLayout(this);
        LinearLayout.LayoutParams photoLp = new LinearLayout.LayoutParams(Ui.dp(this, 128), ViewGroup.LayoutParams.MATCH_PARENT);
        photoLp.rightMargin = Ui.dp(this, 10);
        card.addView(photo, photoLp);

        ImageView image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        image.setBackground(Ui.rounded(Color.rgb(226, 232, 240), 11, this));
        photo.addView(image, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setListingImage(image, item);

        if (SaleClassifier.isLikelyUsed(item)) {
            TextView used = Ui.text(this, "มือสอง", 10, true);
            used.setTextColor(Color.WHITE);
            used.setGravity(Gravity.CENTER);
            used.setBackground(Ui.rounded(GREEN, 10, this));
            FrameLayout.LayoutParams ulp = new FrameLayout.LayoutParams(Ui.dp(this, 52), Ui.dp(this, 24));
            ulp.gravity = Gravity.TOP | Gravity.LEFT;
            ulp.setMargins(Ui.dp(this, 6), Ui.dp(this, 6), 0, 0);
            photo.addView(used, ulp);
        }

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        card.addView(info, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1));

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setGravity(Gravity.TOP);
        info.addView(titleRow, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        TextView title = Ui.text(this, item.title, 15, true);
        title.setMaxLines(2);
        titleRow.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        TextView heart = Ui.text(this, "♡", 24, false);
        heart.setGravity(Gravity.CENTER);
        heart.setTextColor(Color.rgb(51, 65, 85));
        titleRow.addView(heart, new LinearLayout.LayoutParams(Ui.dp(this, 34), Ui.dp(this, 30)));

        if (item.price > 0) {
            TextView price = Ui.text(this, "฿ " + NumberFormat.getIntegerInstance(new Locale("th", "TH")).format(item.price), 18, true);
            price.setTextColor(GREEN);
            price.setPadding(0, Ui.dp(this, 3), 0, 0);
            info.addView(price);
        }

        TextView meta = Ui.text(this, "📍 " + (item.location.isEmpty() ? "ไม่ระบุจังหวัด" : item.location) + "  •  " + relativeTime(item.createdAt), 11, false);
        meta.setTextColor(MUTED);
        meta.setPadding(0, Ui.dp(this, 4), 0, 0);
        info.addView(meta);

        String source = sourceLabel(item);
        TextView s = Ui.text(this, source, 10, false);
        s.setTextColor(BLUE);
        s.setMaxLines(1);
        s.setPadding(0, Ui.dp(this, 5), 0, 0);
        info.addView(s);

        if (!item.postUrl.isEmpty()) {
            card.setClickable(true);
            card.setOnClickListener(v -> openUrl(item.postUrl));
        }
        return card;
    }

    private String sourceLabel(Listing item) {
        if ("groups".equals(item.source)) return "● จากกลุ่ม" + (item.groupName.isEmpty() ? " Facebook" : " • " + item.groupName);
        if ("marketplace".equals(item.source)) return "● Marketplace";
        if ("shared".equals(item.source)) return "● โพสต์ที่คุณแชร์เข้าแอป";
        return item.groupName.isEmpty() ? "● โพสต์ล่าสุด" : "● " + item.groupName;
    }

    private void setListingImage(ImageView image, Listing item) {
        image.setTag(item.id + ":" + item.imageUrl);
        if (item.imageUrl != null && item.imageUrl.startsWith("drawable:")) {
            String name = item.imageUrl.substring("drawable:".length());
            int id = getResources().getIdentifier(name, "drawable", getPackageName());
            if (id != 0) image.setImageResource(id);
            else image.setImageResource(android.R.drawable.ic_menu_gallery);
            return;
        }
        if (item.imageUrl == null || item.imageUrl.trim().isEmpty()) {
            int id = getResources().getIdentifier(drawableForCategory(item.category), "drawable", getPackageName());
            if (id != 0) image.setImageResource(id);
            return;
        }

        Bitmap cached = imageCache.get(item.imageUrl);
        if (cached != null) {
            image.setImageBitmap(cached);
            return;
        }
        int placeholder = getResources().getIdentifier(drawableForCategory(item.category), "drawable", getPackageName());
        if (placeholder != 0) image.setImageResource(placeholder);
        final String url = item.imageUrl;
        final Object expectedTag = image.getTag();
        imageExecutor.execute(() -> {
            Bitmap bmp = downloadBitmap(url);
            if (bmp == null) return;
            imageCache.put(url, bmp);
            runOnUiThread(() -> {
                if (expectedTag.equals(image.getTag())) image.setImageBitmap(bmp);
            });
        });
    }

    private Bitmap downloadBitmap(String url) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(7000);
            c.setReadTimeout(9000);
            c.setInstanceFollowRedirects(true);
            InputStream in = c.getInputStream();
            Bitmap bmp = BitmapFactory.decodeStream(in);
            in.close();
            return bmp;
        } catch (Exception ignored) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private String drawableForCategory(String cat) {
        String s = cat == null ? "" : cat;
        if (s.contains("แม็ค") || s.contains("ขุด") || s.contains("เครื่องจักร")) return "demo_excavator";
        if (s.contains("รถไถ")) return "demo_tractor";
        if (s.contains("ดั้ม")) return "demo_dump";
        if (s.contains("อะไหล่")) return "demo_parts";
        return "demo_truck";
    }

    private void openUrl(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "ไม่พบแอปสำหรับเปิดลิงก์", Toast.LENGTH_SHORT).show();
        }
    }

    private String relativeTime(long when) {
        long seconds = Math.max(0, (System.currentTimeMillis() - when) / 1000);
        if (seconds < 60) return Math.max(1, seconds) + " วินาทีที่แล้ว";
        if (seconds < 3600) return (seconds / 60) + " นาทีที่แล้ว";
        if (seconds < 86400) return (seconds / 3600) + " ชม.ที่แล้ว";
        return (seconds / 86400) + " วันที่แล้ว";
    }
}
