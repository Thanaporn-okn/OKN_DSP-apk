OKN DSP V41 CONTROLLED MASTERVOLUME WRITE PROOF

Basis from the successful V40 real-device capture:
- AB00/AB01/AB02/AB03 live connection confirmed.
- Current-session RandKey derived from the 32-byte auth response.
- AES-CFB8 continuous TX/RX streams verified.
- Device Description reassembled and parsed: 18,143 JSON bytes, 4 sensors, 15 actuators.
- UFE READ 0x58 -> RESPONSE 0x60 verified against sensor ID 0.

V41 adds exactly one constrained actuator-write proof in Evidence Lab:
1. Authenticate and derive the current-session RandKey.
2. Read/validate the live Device Description.
3. Verify actuator ID 2 is FLOAT32 MasterVolume.
4. READ ID 2 to capture the current value.
5. If safe, WRITE 0x57 a value exactly 1 dB lower (never higher).
6. READ ID 2 and verify the lowered value.
7. WRITE the original value back automatically.
8. READ ID 2 and verify restoration.

Safety gates:
- Normal REAL CONTROLS remain locked.
- No SaveParams ID 7 is ever sent.
- No EQ, preset, delay, crossover, or persistent write is enabled.
- If the current MasterVolume is too near the -70 dB minimum or outside descriptor range, the proof aborts before writing.
- A failsafe restoration is scheduled after the temporary -1 dB write.

Expected success marker in capture:
V41_CONTROLLED_WRITE_PROOF_COMPLETE actuator=2 write57=true read58=true response60=true restored=true saveParamsSent=false
