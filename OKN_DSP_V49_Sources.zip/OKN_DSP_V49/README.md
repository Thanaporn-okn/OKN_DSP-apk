# OKN DSP V49 — BP1048P4 ACP Catalog Read Qualification

V49 follows the real V45 and V48 hardware evidence.

- V45 proved that even a 12-byte numerator-only biquad update still clicks, so CH1/CH2/CH4/CH5/CH6/CH7 output-volume writes stay disabled.
- CH3 continues to use the hardware-qualified `BassVolume` scalar actuator ID8.
- V48 proved the real board is `VID 0x6324 / PID 0x1719`, HID interface 4, vendor Usage Page `0xFF00`, Usage `0x55AA`, with 256-byte Input and Output reports.

## V49 purpose

V49 performs the first state-preserving ACP request over the real wired transport. The Mix-page button is:

`ACP READ CATALOG (1 QUERY)`

After explicit Android USB permission and a successful non-forcing claim of HID IF4, V49 re-reads the HID report descriptor. It must reproduce the V48 vendor-HID shape before any output transfer is allowed.

If and only if that gate passes, V49 sends exactly one 256-byte HID Output Report. The only non-zero protocol frame at its start is:

`A5 5A 80 01 00 16`

This is the Generic BP10/BP1048 ACP effect-catalog selector-0 read query. V49 never retries SET_REPORT. It then uses HID GET_REPORT only to wait for the matching `CTRL=0x80` response and rejects stale/non-catalog cached reports.

## Safety boundary

V49 contains no ACP effect-node write, gain write, EQ write, actuator write, OTA request or SaveParams action in the USB probe. It does not sweep ACP addresses. It does not send `0xFB`, `0xFD` or `0xFE`. The normal CH1/2/4/5/6/7 output sliders remain fail-closed; CH3/ID8 is unchanged.

A successful selector-0 catalog reply is printed as raw hex and decoded only as selector, effect count and little-endian effect types. Names/addresses are not guessed in V49.
