# OKN DSP V49

V49 keeps the V48 EQ channel order and V47 BassVolume ID8 +24 dB behavior. It fixes BassVolume persistence so +24 dB is retained everywhere and adds an ID8 integrity check after MasterVolume changes.

When Master Volume (ID2) is adjusted, V49 does not touch Band EQ, channel volume, cutoff, or any synthetic gain. It waits for the BLE queue to settle, reads BassVolume (ID8) from the DSP, and restores only ID8 if firmware changed it unexpectedly.

EQ order remains: Ch1 Left, Ch2 Right, Ch3 Bass/Subwoofer, Ch4 4th, Ch5 5th, Ch6 6th, Ch7 7th.
