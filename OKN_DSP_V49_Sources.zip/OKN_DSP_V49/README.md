# OKN DSP V49

V49 is based directly on the real-board-validated V48 build. It keeps the verified Bass Volume controller range and adds dedicated one-tap Bass adjustment buttons.

## V49 change
- Bass Volume remains UFE scalar actuator **ID 8 / BassVolume**.
- Bass Volume range remains **`0..+40 dB`**.
- New **`−1 dB`** and **`+1 dB`** buttons are shown beside Bass Volume.
- Each button changes BassVolume by exactly 1 dB from the current value, clamps at 0 / +40 dB, and uses the same verified ID8 realtime write path as the slider.
- The existing Bass slider remains available and retains its 0.1 dB step behavior.
- Default/Reset Bass Volume remains `+2 dB`.
- Master Volume remains `-70..+6 dB`.
- **BassBoost ID10 is not used or repurposed.**
- **No EQ actuator mapping, EQ gain/F/Q range, coefficient formula, 48-byte EQ writer, EQ cadence, or Safe Reset behavior is changed.**
- Save DSP / SaveParams ID7 behavior is unchanged.

The stock device descriptor in `Sources/ProtocolEvidence/` is kept unchanged.

## Build
GitHub Actions workflow: `.github/workflows/OKN_DSP_AutoBuild.yml`. It validates SHA256 + DSP safety invariants, installs the current Android SDK tooling, builds the signed Release APK and uploads APK + SHA256.
