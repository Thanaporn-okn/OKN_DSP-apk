package com.okn.dsp;

import android.content.Context;
import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * V49 USB/HID ACP catalog qualification for the real OKN BP1048P4 board.
 *
 * Hardware evidence from V46/V48:
 *   VID 0x6324, PID 0x1719, HID interface 4, no interrupt endpoints.
 *   IF4 HID report descriptor = vendor page 0xFF00 / usage 0x55AA,
 *   256-byte Input report + 256-byte Output report + 8-byte Feature report.
 *
 * V49 is state-preserving by construction:
 *   - exactly one HID SET_REPORT may be sent, and only after descriptor verification;
 *   - the only permitted output payload begins A5 5A 80 01 00 16 (ACP catalog READ query);
 *   - no effect-node address, actuator write, gain write, EQ write, OTA, or SaveParams exists here;
 *   - GET_REPORT may be repeated only to wait for the matching CTRL=0x80 catalog reply;
 *   - no force-detach (claimInterface(..., false) only).
 */
public final class UsbAcpDiscovery {
    public static final int TARGET_VID = 0x6324;
    public static final int TARGET_PID = 0x1719;
    public static final int TARGET_INTERFACE = 4;
    public static final int GENERIC_REPORT_SIZE = 256;

    private static final int USB_RECIP_INTERFACE = 0x01;
    private static final int USB_REQ_GET_DESCRIPTOR = 0x06;
    private static final int HID_REQ_GET_REPORT = 0x01;
    private static final int HID_REQ_SET_REPORT = 0x09;
    private static final int HID_DT_REPORT = 0x22;
    private static final int HID_REPORT_TYPE_INPUT = 0x01;
    private static final int HID_REPORT_TYPE_OUTPUT = 0x02;
    private static final int IO_TIMEOUT_MS = 1000;
    private static final int GET_TIMEOUT_MS = 350;
    private static final int GET_ATTEMPTS = 6;

    // Confirmed Generic-BP10/BP1048 ACP catalog selector-0 query.
    // This asks for the effect catalog; it does not change DSP state.
    private static final byte[] ACP_CATALOG_QUERY = new byte[] {
            (byte) 0xA5, 0x5A, (byte) 0x80, 0x01, 0x00, 0x16
    };

    private UsbAcpDiscovery() {}

    public static UsbDevice findTarget(Context context) {
        UsbManager manager = (UsbManager) context.getSystemService(Context.USB_SERVICE);
        if (manager == null) return null;
        Map<String, UsbDevice> map = manager.getDeviceList();
        if (map == null || map.isEmpty()) return null;

        UsbDevice pid1719Fallback = null;
        for (UsbDevice d : map.values()) {
            if (d == null) continue;
            if (d.getVendorId() == TARGET_VID && d.getProductId() == TARGET_PID && hasTargetHidInterface(d)) {
                return d;
            }
            if (d.getProductId() == TARGET_PID && hasTargetHidInterface(d)) pid1719Fallback = d;
        }
        return pid1719Fallback;
    }

    public static String summary(Context context) {
        UsbManager manager = (UsbManager) context.getSystemService(Context.USB_SERVICE);
        if (manager == null) return "UsbManager unavailable";
        UsbDevice d = findTarget(context);
        if (d == null) return "target 0x6324:0x1719 IF4 not detected";
        return String.format(Locale.US, "%04X:%04X IF4 HID permission=%s",
                d.getVendorId(), d.getProductId(), manager.hasPermission(d) ? "yes" : "no");
    }

    public static String buildEnumerationReport(Context context) {
        UsbManager manager = (UsbManager) context.getSystemService(Context.USB_SERVICE);
        StringBuilder out = new StringBuilder(3072);
        out.append("OKN DSP V49 — USB ACP catalog qualification\n")
                .append("No gain/EQ/effect-node write. No SaveParams.\n\n");
        if (manager == null) return out.append("UsbManager unavailable on this device.").toString();

        Map<String, UsbDevice> map = manager.getDeviceList();
        if (map == null || map.isEmpty()) {
            return out.append("No USB device detected.\n")
                    .append("Connect the powered DSP through USB host/OTG and scan again.")
                    .toString();
        }

        List<String> keys = new ArrayList<>(map.keySet());
        Collections.sort(keys);
        out.append("Detected devices: ").append(keys.size()).append("\n\n");
        int n = 0;
        for (String key : keys) {
            UsbDevice d = map.get(key);
            if (d == null) continue;
            n++;
            out.append('#').append(n).append(' ')
                    .append(String.format(Locale.US, "VID=%04X PID=%04X", d.getVendorId(), d.getProductId()))
                    .append(" devClass=").append(d.getDeviceClass())
                    .append(" ifaces=").append(d.getInterfaceCount())
                    .append(" permission=").append(manager.hasPermission(d) ? "yes" : "no")
                    .append(isExactTarget(d) ? "  <V49 TARGET>" : (isTransportCandidate(d) ? "  <candidate>" : ""))
                    .append('\n');
            appendInterfaces(out, d);
            out.append('\n');
        }
        return out.toString();
    }

    /**
     * Requires explicit Android USB permission.
     * Sends exactly one known ACP catalog READ query, then only HID GET_REPORT requests.
     */
    public static String buildAcpCatalogProbe(Context context, UsbDevice requestedDevice) {
        UsbManager manager = (UsbManager) context.getSystemService(Context.USB_SERVICE);
        StringBuilder out = new StringBuilder(12288);
        out.append("OKN DSP V49 — BP1048 ACP CATALOG READ probe\n")
                .append("SAFETY: exactly 1 ACP read-query TX allowed. Gain/EQ/effect-node writes=0. SaveParams=0.\n")
                .append("Permitted query: A55A80010016 only.\n\n");
        if (manager == null) return out.append("UsbManager unavailable.").toString();

        UsbDevice d = requestedDevice != null ? requestedDevice : findTarget(context);
        if (d == null) return out.append("Target 0x6324:0x1719 IF4 HID not detected.").toString();
        out.append(String.format(Locale.US, "Target VID=%04X PID=%04X interfaces=%d\n",
                d.getVendorId(), d.getProductId(), d.getInterfaceCount()));

        if (d.getProductId() != TARGET_PID || !hasTargetHidInterface(d)) {
            return out.append("FAIL-CLOSED: PID/IF4 profile mismatch. No SET_REPORT sent.\n").toString();
        }
        if (!manager.hasPermission(d)) {
            return out.append("USB permission=no. No device connection opened.\n").toString();
        }
        out.append("USB permission=yes\n");

        UsbInterface hid = findInterface(d, TARGET_INTERFACE);
        if (hid == null || hid.getInterfaceClass() != UsbConstants.USB_CLASS_HID) {
            return out.append("FAIL-CLOSED: interface 4 is missing or not HID. No SET_REPORT sent.\n").toString();
        }
        out.append("IF4 class=HID sub=").append(hid.getInterfaceSubclass())
                .append(" proto=").append(hid.getInterfaceProtocol())
                .append(" endpoints=").append(hid.getEndpointCount()).append('\n');

        UsbDeviceConnection conn = manager.openDevice(d);
        if (conn == null) return out.append("openDevice failed. No SET_REPORT sent.\n").toString();

        boolean claimed = false;
        try {
            claimed = conn.claimInterface(hid, false);
            out.append("claim IF4 force=false => ").append(claimed ? "OK" : "FAILED")
                    .append(" (force=true forbidden)\n");
            if (!claimed) {
                return out.append("FAIL-CLOSED: IF4 not claimed. No SET_REPORT sent.\n").toString();
            }

            // Gate #1: re-read HID report descriptor and require the exact transport shape
            // that the user's V48 report proved on this physical board.
            byte[] reportDescriptor = new byte[128];
            int reportLen = conn.controlTransfer(
                    UsbConstants.USB_DIR_IN | UsbConstants.USB_TYPE_STANDARD | USB_RECIP_INTERFACE,
                    USB_REQ_GET_DESCRIPTOR,
                    HID_DT_REPORT << 8,
                    TARGET_INTERFACE,
                    reportDescriptor,
                    reportDescriptor.length,
                    IO_TIMEOUT_MS);
            out.append("\n[1] HID transport gate\n")
                    .append("GET_DESCRIPTOR(report) result=").append(reportLen).append('\n');
            if (reportLen > 0) {
                out.append("reportDescriptor=").append(hex(reportDescriptor, reportLen)).append('\n');
            }
            boolean transportOk = looksLikeExpectedAcpHid(reportDescriptor, reportLen);
            out.append("vendorPageFF00_usage55AA_input256_output256=")
                    .append(transportOk ? "YES" : "NO").append('\n');
            if (!transportOk) {
                return out.append("FAIL-CLOSED: V48 HID shape not reproduced. ACP query NOT sent.\n").toString();
            }

            // Gate #2: the only OUT payload in V49 is the selector-0 catalog READ request.
            byte[] output = new byte[GENERIC_REPORT_SIZE];
            System.arraycopy(ACP_CATALOG_QUERY, 0, output, 0, ACP_CATALOG_QUERY.length);
            out.append("\n[2] Single ACP catalog READ request\n")
                    .append("queryFrame=").append(hex(ACP_CATALOG_QUERY, ACP_CATALOG_QUERY.length)).append('\n')
                    .append("SET_REPORT count planned=1 reportBytes=").append(GENERIC_REPORT_SIZE).append('\n');

            int sent = conn.controlTransfer(
                    UsbConstants.USB_DIR_OUT | UsbConstants.USB_TYPE_CLASS | USB_RECIP_INTERFACE,
                    HID_REQ_SET_REPORT,
                    HID_REPORT_TYPE_OUTPUT << 8,
                    TARGET_INTERFACE,
                    output,
                    output.length,
                    IO_TIMEOUT_MS);
            out.append("SET_REPORT result=").append(sent).append(" (this was the one permitted read-query TX)\n");
            if (sent < 0) {
                return out.append("Catalog query transfer failed. No retry SET_REPORT is performed.\n")
                        .append("DSP state-changing writes remain 0.\n").toString();
            }

            out.append("\n[3] Wait for matching CTRL=0x80 reply (GET_REPORT only)\n");
            byte[] accepted = null;
            int acceptedLen = 0;
            for (int attempt = 1; attempt <= GET_ATTEMPTS; attempt++) {
                try { Thread.sleep(10L); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); }
                byte[] input = new byte[GENERIC_REPORT_SIZE];
                int got = conn.controlTransfer(
                        UsbConstants.USB_DIR_IN | UsbConstants.USB_TYPE_CLASS | USB_RECIP_INTERFACE,
                        HID_REQ_GET_REPORT,
                        HID_REPORT_TYPE_INPUT << 8,
                        TARGET_INTERFACE,
                        input,
                        input.length,
                        GET_TIMEOUT_MS);
                out.append("GET_REPORT attempt=").append(attempt).append(" result=").append(got);
                if (got > 0) {
                    int ctrl = got >= 3 ? (input[2] & 0xFF) : -1;
                    out.append(" prefix=").append(hex(input, Math.min(got, 24)))
                            .append(" ctrl=").append(ctrl < 0 ? "n/a" : String.format(Locale.US, "0x%02X", ctrl));
                    if (isValidCatalogReply(input, got)) {
                        accepted = input;
                        acceptedLen = got;
                        out.append(" MATCH");
                    } else {
                        out.append(" stale/non-catalog");
                    }
                }
                out.append('\n');
                if (accepted != null) break;
            }

            if (accepted == null) {
                return out.append("No valid A5 5A / CTRL=0x80 catalog reply observed.\n")
                        .append("SET_REPORT was NOT retried. Gain/EQ/effect-node writes=0.\n")
                        .append("V49 COMPLETE. Copy this full report.\n").toString();
            }

            int bodyLen = accepted[3] & 0xFF;
            int frameLen = bodyLen + 5;
            out.append("\n[4] Accepted catalog reply\n")
                    .append("replyUsbBytes=").append(acceptedLen).append('\n')
                    .append("replyFrameBytes=").append(frameLen).append('\n')
                    .append("replyFrame=").append(hex(accepted, frameLen)).append('\n');
            appendCatalogDecode(out, accepted, frameLen);

            out.append("\nV49 COMPLETE: ACP catalog read succeeded.\n")
                    .append("State-changing DSP writes=0; SaveParams=0; SET_REPORT count=1 (catalog read query only).\n")
                    .append("Copy this full report for gain-node mapping.");
            return out.toString();
        } catch (RuntimeException e) {
            out.append("\nProbe exception: ").append(e.getClass().getSimpleName()).append('\n')
                    .append("No effect-node/gain/EQ/SaveParams write code exists in V49.\n");
            return out.toString();
        } finally {
            if (claimed) {
                try { conn.releaseInterface(hid); } catch (RuntimeException ignored) { }
            }
            conn.close();
        }
    }

    private static boolean looksLikeExpectedAcpHid(byte[] d, int len) {
        if (d == null || len < 30) return false;
        // V48 proved this exact prefix: Usage Page FF00, Usage 55AA, Application Collection.
        byte[] prefix = new byte[] {0x06, 0x00, (byte) 0xFF, 0x0A, (byte) 0xAA, 0x55, (byte) 0xA1, 0x01};
        for (int i = 0; i < prefix.length; i++) if (d[i] != prefix[i]) return false;

        // Report size 8, report count 0x0100, Input; then count 0x0100, Output.
        return contains(d, len, new byte[] {0x75, 0x08, (byte) 0x96, 0x00, 0x01, 0x09, 0x01, (byte) 0x81, 0x02})
                && contains(d, len, new byte[] {(byte) 0x96, 0x00, 0x01, 0x09, 0x01, (byte) 0x91, 0x02});
    }

    private static boolean isValidCatalogReply(byte[] input, int got) {
        if (input == null || got < 6) return false;
        if ((input[0] & 0xFF) != 0xA5 || (input[1] & 0xFF) != 0x5A || (input[2] & 0xFF) != 0x80) return false;
        int bodyLen = input[3] & 0xFF;
        int frameLen = bodyLen + 5;
        return frameLen >= 6 && frameLen <= got && frameLen <= input.length && (input[frameLen - 1] & 0xFF) == 0x16;
    }

    private static void appendCatalogDecode(StringBuilder out, byte[] frame, int frameLen) {
        int bodyLen = frame[3] & 0xFF;
        if (bodyLen < 2 || frameLen < 7) {
            out.append("catalogDecode=body too short\n");
            return;
        }
        int selector = frame[4] & 0xFF;
        int count = frame[5] & 0xFF;
        out.append("selector=").append(selector).append(" effectCount=").append(count).append('\n');
        if (selector != 0) {
            out.append("catalogDecode=unexpected selector; raw frame preserved above\n");
            return;
        }
        int availablePairs = Math.max(0, (bodyLen - 2) / 2);
        int n = Math.min(count, availablePairs);
        out.append("effectTypesLE[").append(n).append("]=");
        for (int i = 0; i < n; i++) {
            int off = 6 + i * 2;
            int type = (frame[off] & 0xFF) | ((frame[off + 1] & 0xFF) << 8);
            if (i > 0) out.append(',');
            out.append(type);
        }
        out.append('\n');
        if (count != availablePairs) {
            out.append("countVsBodyPairs=").append(count).append('/').append(availablePairs)
                    .append(" (copy raw reply; do not infer missing entries)\n");
        }
    }

    private static boolean contains(byte[] data, int len, byte[] needle) {
        if (data == null || needle == null || needle.length == 0) return false;
        int n = Math.min(len, data.length);
        for (int i = 0; i + needle.length <= n; i++) {
            boolean ok = true;
            for (int j = 0; j < needle.length; j++) {
                if (data[i + j] != needle[j]) { ok = false; break; }
            }
            if (ok) return true;
        }
        return false;
    }

    private static void appendInterfaces(StringBuilder out, UsbDevice d) {
        for (int i = 0; i < d.getInterfaceCount(); i++) {
            UsbInterface f = d.getInterface(i);
            out.append("  IF ").append(f.getId())
                    .append(" class=").append(f.getInterfaceClass())
                    .append(" sub=").append(f.getInterfaceSubclass())
                    .append(" proto=").append(f.getInterfaceProtocol())
                    .append(" eps=").append(f.getEndpointCount());
            if (f.getInterfaceClass() == UsbConstants.USB_CLASS_HID) out.append(" HID");
            if (f.getInterfaceClass() == UsbConstants.USB_CLASS_VENDOR_SPEC) out.append(" VENDOR");
            out.append('\n');
            for (int e = 0; e < f.getEndpointCount(); e++) {
                UsbEndpoint ep = f.getEndpoint(e);
                out.append("    EP ").append(String.format(Locale.US, "0x%02X", ep.getAddress()))
                        .append(' ')
                        .append(ep.getDirection() == UsbConstants.USB_DIR_IN ? "IN" : "OUT")
                        .append(" type=").append(ep.getType())
                        .append(" maxPacket=").append(ep.getMaxPacketSize())
                        .append('\n');
            }
        }
    }

    private static UsbInterface findInterface(UsbDevice d, int id) {
        for (int i = 0; i < d.getInterfaceCount(); i++) {
            UsbInterface f = d.getInterface(i);
            if (f.getId() == id) return f;
        }
        return null;
    }

    private static boolean hasTargetHidInterface(UsbDevice d) {
        UsbInterface f = findInterface(d, TARGET_INTERFACE);
        return f != null && f.getInterfaceClass() == UsbConstants.USB_CLASS_HID;
    }

    private static boolean isExactTarget(UsbDevice d) {
        return d.getVendorId() == TARGET_VID && d.getProductId() == TARGET_PID && hasTargetHidInterface(d);
    }

    private static boolean isTransportCandidate(UsbDevice d) {
        return d.getProductId() == TARGET_PID && hasTargetHidInterface(d);
    }

    private static String hex(byte[] data, int length) {
        if (data == null || length <= 0) return "";
        int n = Math.min(length, data.length);
        StringBuilder s = new StringBuilder(n * 2);
        for (int i = 0; i < n; i++) s.append(String.format(Locale.US, "%02X", data[i] & 0xFF));
        return s.toString();
    }
}
