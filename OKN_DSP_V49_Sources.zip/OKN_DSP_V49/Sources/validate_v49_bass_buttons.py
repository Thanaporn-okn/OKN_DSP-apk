#!/usr/bin/env python3
from pathlib import Path
import hashlib

root = Path(__file__).resolve().parents[1]
ble_path = root/'app/src/main/java/com/okn/dsp/BleManager.java'
view_path = root/'app/src/main/java/com/okn/dsp/DspView.java'
proto_path = root/'app/src/main/java/com/okn/dsp/DspProtocol.java'
state_path = root/'app/src/main/java/com/okn/dsp/DspState.java'
ble = ble_path.read_text()
view = view_path.read_text()
proto = proto_path.read_text()
state = state_path.read_text()
gradle = (root/'app/build.gradle').read_text()

def method(text, marker):
    i = text.index(marker)
    b = text.index('{', i)
    depth = 0
    for j in range(b, len(text)):
        if text[j] == '{': depth += 1
        elif text[j] == '}':
            depth -= 1
            if depth == 0: return text[i:j+1]
    raise AssertionError('unclosed method ' + marker)

def sha_text(s):
    return hashlib.sha256(s.encode()).hexdigest()

def sha_file(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

button_method = method(view, '    private void adjustBassVolumeBy(')
draw_bass = method(view, '    private void drawBassVolumeRow(')

checks = {
    'V49 version': "versionCode 1049" in gradle and "versionName '49.0.0'" in gradle,
    'BassVolume remains ID8': 'static final int ID_BASS_VOLUME = 8;' in proto,
    'BassBoost remains separate ID10': 'static final int ID_BASS_BOOST = 10;' in proto,
    'Bass range remains 0..+40': 'static final float BASS_VOLUME_MIN_DB = 0f;' in proto and 'static final float BASS_VOLUME_EXTENDED_MAX_DB = 40f;' in proto,
    'ID8 sanitizer retains V48 range': 'case ID_BASS_VOLUME:' in proto and 'lo = BASS_VOLUME_MIN_DB; hi = BASS_VOLUME_EXTENDED_MAX_DB; break;' in proto,
    'state setter retains V48 clamp': 'bassVolume = clamp(value, DspProtocol.BASS_VOLUME_MIN_DB, DspProtocol.BASS_VOLUME_EXTENDED_MAX_DB);' in state,
    'Bass custom row rendered': 'drawBassVolumeRow(c, left, right, y);' in view,
    'minus button registered': 'addHit("bassMinus1", minus);' in draw_bass,
    'plus button registered': 'addHit("bassPlus1", plus);' in draw_bass,
    'minus hit is exactly -1 dB': 'adjustBassVolumeBy(-1f);' in view,
    'plus hit is exactly +1 dB': 'adjustBassVolumeBy(1f);' in view,
    'button math uses current BassVolume': 'state.bassVolume + deltaDb' in button_method,
    'button clamp uses Bass-only range': 'DspProtocol.BASS_VOLUME_MIN_DB, DspProtocol.BASS_VOLUME_EXTENDED_MAX_DB' in button_method,
    'button writes verified ID8': 'sendVerifiedScalar(DspProtocol.ID_BASS_VOLUME, state.bassVolume);' in button_method,
    'button does not write BassBoost ID10': 'ID_BASS_BOOST' not in button_method,
    'slider still writes verified ID8': 'sendVerifiedScalar(DspProtocol.ID_BASS_VOLUME, state.bassVolume);' in method(view, '    private void applySlider('),
    'no fake channel-volume slider': 'SL_CHANNEL' not in view,
    'CH gain stays locked': 'GAIN LOCKED' in view,
    'SaveParams remains manual ID7': 'static final int ID_SAVE_PARAMS = 7;' in proto and 'void requestPersistentSave()' in ble,
}

# These three runtime files must stay byte-identical to the real-board-validated V48.
# V49 intentionally changes only DspView + metadata/docs/workflow.
expected_files = {
    'BleManager.java': '15cfc4bd64723e7508694d19ab271f173b91fc78acd5118ddcbbfae90e50bff9',
    'DspProtocol.java': '8b1e30b525d5a2aad85a836ad43a20ed9416d121afb9bafef7e02b224380b45f',
    'DspState.java': 'e5576eec8a37280d7794ba85c3704f2f2640dd2774ad03eb0ac399ae7e609577',
}
for name, expected in expected_files.items():
    p = root/'app/src/main/java/com/okn/dsp'/name
    checks['V48 frozen file '+name] = sha_file(p) == expected

# Freeze UI-side EQ rendering/writer dispatch and slider logic to V48 as well.
expected_view_methods = {
    'drawEq': ('    private void drawEq(', 'a26a9e5b41745532a3d16030eefb9bd60b9428dd54a840d35d19aaedbb9697c5'),
    'applySlider': ('    private void applySlider(', '49f1de6685fc7687f3096984ca32b8d635e8b32f50594c83231c27ba620bbc35'),
    'sendVerifiedEqGain': ('    private void sendVerifiedEqGain(', '3104545feddc6b916d75dfc2aa95750fea3e240cc5126584b7371c08b78864ab'),
    'sendVerifiedEqShape': ('    private void sendVerifiedEqShape(', 'bda3a29f7629eb9a93a6ee553bdfd16793a32075059e94c15ede9710c29467e3'),
}
for name, (marker, expected) in expected_view_methods.items():
    checks['V48 frozen DspView.'+name] = sha_text(method(view, marker)) == expected

# Retain the established V48/V44 EQ transport/encoder/reset invariants.
expected_eq = {
    'BleManager.setEqRealtime':'f4f738c886298e476dad58135a5d29b36937aaa7dbf7eabe7853dc8d9e761c9a',
    'BleManager.setEqShapeRealtime':'e702693eccb788da71d156db94dc21824f1dacab20d19e1d89aaedceb94a6110',
    'BleManager.sendScheduledControl':'8c39c0643084615777997900f428e3c32971bdd5e2afa0d768c04c4dbfedf777',
    'BleManager.writeNoResponse':'e6895bee7c3f2d12c2531d7d48346559d6b00a4c227b38ecfc63f2ce2a9d9256',
    'BleManager.resetEqSafe':'eab920cc4b25b018c9e263f1a43bf4391569119663db101954a2661803864d18',
    'DspProtocol.peakingFromCurrent':'18f6cb0577c711ea817c8441f4b3b2fc91a4a5d5bae0d61051926074858b95ae',
    'DspProtocol.peakingShapeFromCurrent':'e3f8d840e116bc3d32bad459db3883867f8afc62a87c8553131397ee133e4e86',
    'DspProtocol.firstBandGainFromCurrent':'89f089d8d8bc6bfd54074e35e949fa393719d64d3884fc8ce133b99bc100ddee',
    'DspProtocol.encodeEqWrite':'9de90148f2e6f390f9144ffc8f6c029a00ca6276bdeb8696aa319609573001e5',
}
for name, text, marker in [
    ('BleManager.setEqRealtime', ble, '    void setEqRealtime('),
    ('BleManager.setEqShapeRealtime', ble, '    void setEqShapeRealtime('),
    ('BleManager.sendScheduledControl', ble, '    private void sendScheduledControl('),
    ('BleManager.writeNoResponse', ble, '    private boolean writeNoResponse('),
    ('BleManager.resetEqSafe', ble, '    int resetEqSafe('),
    ('DspProtocol.peakingFromCurrent', proto, '    static EqBand peakingFromCurrent('),
    ('DspProtocol.peakingShapeFromCurrent', proto, '    static EqBand peakingShapeFromCurrent('),
    ('DspProtocol.firstBandGainFromCurrent', proto, '    static EqBand firstBandGainFromCurrent('),
    ('DspProtocol.encodeEqWrite', proto, '    static byte[] encodeEqWrite('),
]:
    body = method(text, marker)
    if name in ('BleManager.setEqRealtime','BleManager.setEqShapeRealtime','BleManager.resetEqSafe'):
        body = body.replace(' || saveActive', '')
    checks['frozen '+name] = sha_text(body) == expected_eq[name]

failed = [k for k,v in checks.items() if not v]
for k,v in checks.items():
    print(('PASS' if v else 'FAIL'), k)
if failed:
    raise SystemExit('V49 validation failed: ' + ', '.join(failed))
print('V49_BASS_VOLUME_ID8_PLUS_MINUS_1DB_PASS')
