from pathlib import Path
root=Path(__file__).resolve().parents[1]
state=(root/'app/src/main/java/com/okn/dsp/DspState.java').read_text()
view=(root/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
ble=(root/'app/src/main/java/com/okn/dsp/BleManager.java').read_text()
proto=(root/'app/src/main/java/com/okn/dsp/DspProtocol.java').read_text()
build=(root/'app/build.gradle').read_text()
checks={
 'version': 'versionCode 1049' in build and "versionName '49.0.0'" in build,
 'setter_cap_24': 'bassVolume = clamp(value, -70f, 24f);' in state,
 'load_cap_24': 'prefs.getFloat("bassVolume", 2f), -70f, 24f' in state,
 'preset_cap_24': 'Float.parseFloat(parts[1]), -70f, 24f' in state,
 'protocol_id8_cap_24': 'case ID_BASS_VOLUME:' in proto and 'lo = -70f; hi = 24f;' in proto,
 'master_writes_id2': 'sendVerifiedScalar(DspProtocol.ID_MASTER_VOLUME, state.masterVolume);' in view,
 'master_verifies_bass': 'ble.verifyBassAfterMaster(state.bassVolume);' in view,
 'id8_verifier_exists': 'void verifyBassAfterMaster(float expectedBassDb)' in ble,
 'verifier_sanitizes_id8': 'DspProtocol.sanitizeScalar(DspProtocol.ID_BASS_VOLUME, expectedBassDb)' in ble,
 'verifier_reads_id8': 'scheduleBassReadback(safe);' in ble,
 'bass_retry_id8_only': 'PendingCommand.scalar(DspProtocol.ID_BASS_VOLUME, target)' in ble,
 'no_v44_fake_gain': 'Bass/Sub DSP Gain' not in view,
}
failed=[k for k,v in checks.items() if not v]
for k,v in checks.items(): print(('PASS' if v else 'FAIL'), k)
if failed: raise SystemExit('V49 validation failed: '+', '.join(failed))
print('V49 validation PASS')
