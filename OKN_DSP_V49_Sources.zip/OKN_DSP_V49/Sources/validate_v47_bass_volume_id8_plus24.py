#!/usr/bin/env python3
from pathlib import Path
import sys
root = Path(__file__).resolve().parent.parent
ble = (root/'app/src/main/java/com/okn/dsp/BleManager.java').read_text()
dsp = (root/'app/src/main/java/com/okn/dsp/DspProtocol.java').read_text()
view = (root/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
state = (root/'app/src/main/java/com/okn/dsp/DspState.java').read_text()
build = (root/'app/build.gradle').read_text()
evidence = (root/'Sources/ProtocolEvidence/GoloPine_DeviceDescription_REAL_20260906_204555.json').read_text()
checks = {
    'version47': 'versionCode 1047' in build and "versionName '47.0.0'" in build,
    'id8': 'static final int ID_BASS_VOLUME = 8;' in dsp,
    'descriptor_preserved': '"name": "BassVolume"' in evidence and 'min=-70,max=6' in evidence,
    'id8_cap_24': 'case ID_BASS_VOLUME:' in dsp and 'lo = -70f; hi = 24f;' in dsp,
    'state_cap_24': 'bassVolume = clamp(value, -70f, 24f);' in state,
    'ui_cap_24': '-70f, 24f, SL_BASS, -1' in view,
    'bass_step_half_db': 'float next = roundTo(v, 0.5f);' in view,
    'direct_id8_write': 'DspProtocol.encodeFloatWrite(id, value)' in ble,
    'direct_id8_readback': 'DspProtocol.encodeRead(DspProtocol.ID_BASS_VOLUME, 0, 4)' in ble,
    'clamp_12_detection': 'clampAt12' in ble and 'target > 12.05f' in ble,
    'no_v44_bass_eq_slider': 'SL_BASS_CHANNEL_GAIN' not in view and 'Bass/Sub DSP Gain' not in view,
    'no_band1_bass_volume_hook': 'sendVerifiedEqGain(2, 0)' not in view,
    'master_range_unchanged': 'masterVolume = clamp(value, -70f, 6f);' in state,
    'hard_isolation': 'BACKGROUND_SENSOR_POLLING_ENABLED = false' in ble,
}
for k,v in checks.items(): print(f'{k}={"PASS" if v else "FAIL"}')
if not all(checks.values()): sys.exit(1)
print('V47_BASS_VOLUME_ID8_PLUS24_STATIC_PASS')
