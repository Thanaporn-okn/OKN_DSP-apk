#!/usr/bin/env python3
from pathlib import Path
import re, sys
root = Path(__file__).resolve().parent.parent
view = (root/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
dsp = (root/'app/src/main/java/com/okn/dsp/DspProtocol.java').read_text()
state = (root/'app/src/main/java/com/okn/dsp/DspState.java').read_text()
ble = (root/'app/src/main/java/com/okn/dsp/BleManager.java').read_text()
build = (root/'app/build.gradle').read_text()
evidence = (root/'Sources/ProtocolEvidence/GoloPine_DeviceDescription_REAL_20260906_204555.json').read_text()
checks = {
    'version48': 'versionCode 1048' in build and "versionName '48.0.0'" in build,
    'actuator_order': 'static final int[] EQ_ACTUATORS = {4, 5, 6, 14, 15, 16, 17};' in dsp,
    'ui_order': 'String[] names = {"Left", "Right", "Bass / Subwoofer", "4th Channel", "5th Channel", "6th Channel", "7th Channel"};' in view,
    'no_wrong_old_names': '"Rear Left", "Rear Right", "Center", "Subwoofer", "Aux"' not in view,
    'evidence_left': '"name": "BiquadCascadeLeftChannel"' in evidence,
    'evidence_right': '"name": "BiquadCascadeRightChannel"' in evidence,
    'evidence_bass': '"name": "BiquadCascadeBassChannel"' in evidence,
    'evidence_4': '"name": "BiquadCascade4thChannel"' in evidence,
    'evidence_5': '"name": "BiquadCascade5thChannel"' in evidence,
    'evidence_6': '"name": "BiquadCascade6thChannel"' in evidence,
    'evidence_7': '"name": "BiquadCascade7thChannel"' in evidence,
    'bass_id8': 'static final int ID_BASS_VOLUME = 8;' in dsp,
    'bass_cap_24': 'case ID_BASS_VOLUME:' in dsp and 'lo = -70f; hi = 24f;' in dsp,
    'state_bass_cap_24': 'bassVolume = clamp(value, -70f, 24f);' in state,
    'no_fake_bass_eq_gain': 'SL_BASS_CHANNEL_GAIN' not in view and 'Bass/Sub DSP Gain' not in view,
    'id8_readback': 'DspProtocol.encodeRead(DspProtocol.ID_BASS_VOLUME, 0, 4)' in ble,
    'hard_isolation': 'BACKGROUND_SENSOR_POLLING_ENABLED = false' in ble,
}
for k,v in checks.items(): print(f'{k}={"PASS" if v else "FAIL"}')
if not all(checks.values()): sys.exit(1)
print('V48_EQ_CHANNEL_ORDER_STATIC_PASS')
