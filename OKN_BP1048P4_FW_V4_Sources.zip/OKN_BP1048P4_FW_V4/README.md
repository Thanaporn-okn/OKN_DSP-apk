# OKN_BP1048P4_FW_V4

Clean-room replacement firmware foundation for GoloPine / BP1048P4 7CH.

V4 preserves the V3 reference DSP and adds a deterministic, corruption-detecting
persistence layer without guessing any BP1048P4 flash address or vendor NVM API.

## V4 additions
- Stable binary state image independent of C struct padding
- CRC-32/IEEE protected payload
- schema versioning
- generation counter
- two-slot A/B save model
- read-after-write verification
- rollback to older valid slot if newest image is corrupt
- safe-default boot behavior when storage is missing/corrupt
- separate locked BP1048P4 storage HAL
- host persistence tests

## Existing DSP core
- 7 independent channels
- gain / mute / phase / 0-50 ms delay
- 15-band PEQ per channel
- notch / low shelf / high shelf
- HPF / LPF
- CRC-framed OKN control protocol
- dirty transactional apply
- portable 48 kHz reference audio engine

## Hardware safety
This source is intentionally **not hardware-flashable**. No BP1048P4 MMIO,
flash page, boot packet, GPIO number, clock register, codec route or undocumented
vendor call is guessed. Both audio HAL and storage HAL fail closed until verified
SDK / board evidence is available.

Validation:
```sh
make verify
make test
make demo
```
