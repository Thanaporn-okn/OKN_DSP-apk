# R10 — R9 Exit History + USB READ-ONLY Diagnostic

เป้าหมาย: วิเคราะห์เหตุการณ์ที่ R9 หาย/ถูกส่งกลับหน้า Home หลังเริ่ม `claimInterface(IF3,true)` โดยไม่ทำ force-detach ซ้ำและไม่ส่ง USB OUT ใด ๆ

- อ่าน `ApplicationExitInfo` ของ package เดิม (Android 11+)
- แสดง reason/status/description/trace ที่ระบบอนุญาต
- USB probe เป็น IN/read-only เท่านั้น
- ไม่มี `claimInterface(force=true)`
- ไม่มี `SET_REPORT`, class OUT, endpoint OUT
- ไม่มี DSP parameter write / erase / program / reboot

สำคัญ: ติดตั้ง R10 แบบ UPDATE ทับ R9 อย่า uninstall R9 ก่อน เพื่อรักษา historical exit records ของ package เดิมไว้ให้มากที่สุด
