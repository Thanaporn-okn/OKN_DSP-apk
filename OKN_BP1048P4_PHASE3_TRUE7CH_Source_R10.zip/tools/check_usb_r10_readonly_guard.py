from pathlib import Path
p=Path('android-usb-probe/app/src/main/java/com/okn/dsp/usbprobe/MainActivity.java')
s=p.read_text()
for bad in [
    'claimInterface(x3,true)', 'claimInterface(x3, true)',
    'controlTransfer(0x21', 'controlTransfer(0x01',
    'bulkTransfer(', 'new UsbRequest(',
    'out[0]=(byte)0xA5', 'SET_REPORT result'
]:
    if bad in s:
        raise SystemExit(f'R10 safety guard FAIL: forbidden transport token {bad!r}')
if 'ApplicationExitInfo' not in s:
    raise SystemExit('R10 safety guard FAIL: exit history code missing')
if 'R10 READ-ONLY complete' not in s:
    raise SystemExit('R10 safety guard FAIL: completion marker missing')
print('R10 exit-history + USB read-only guard: PASS')
