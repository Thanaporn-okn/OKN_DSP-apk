# OKN DSP V55 — BLE Hidden-ID READ-ONLY Probe

V55 returns the investigation to the production transport: Bluetooth LE only.

The real 18,141-byte GoloPine Device Description currently declares these global IDs:

- Actuators: 2,3,4,5,6,7,8,9,10,11,13,14,15,16,17
- Sensors: 0,19,20,21

Inside the observed global range 0..21, the only unassigned IDs are 1, 12, and 18. V55 performs a narrowly-scoped read-only hypothesis test for those IDs. ID2 (MasterVolume) is read first as a positive control for the authenticated UFE read path.

## V55 probe

Button: `BLE HIDDEN-ID READ PROBE (0 DSP WRITES)`

Probe order:

1. ID2 — positive control
2. ID1 — unassigned descriptor gap
3. ID12 — unassigned descriptor gap
4. ID18 — unassigned descriptor gap

Every request is exactly:

- opcode `0x58` UFE READ
- offset `0`
- requested length `4`
- transmitted once only
- no automatic retry

The four-byte request length is explicitly only a FLOAT32-sized hypothesis. A returned four-byte payload is shown as raw hex and as a little-endian FLOAT32 interpretation, but V55 does **not** classify any candidate as Gain/Mixer/Volume from that alone.

## Safety boundary

During the probe V55 stops the normal 380 ms poll/control scheduler and marks DSP READY false, preventing normal UI writers from using the authenticated CFB8 stream. After the probe it restores the normal scheduler.

The V55 probe itself performs:

- UFE WRITE `0x57`: 0
- EQ/Biquad writes: 0
- SaveParams: 0
- USB I/O: 0
- USB host feature: removed from current manifest

A no-reply result does not prove an ID is absent. A reply does not prove the value is a channel gain. Any candidate must be classified with additional evidence before a write is ever enabled.
