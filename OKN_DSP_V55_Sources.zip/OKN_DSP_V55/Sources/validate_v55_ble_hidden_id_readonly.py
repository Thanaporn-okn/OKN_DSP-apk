#!/usr/bin/env python3
from pathlib import Path
import re
ROOT=Path(__file__).resolve().parents[1]
BLE=(ROOT/'app/src/main/java/com/okn/dsp/BleManager.java').read_text()
MAIN=(ROOT/'app/src/main/java/com/okn/dsp/MainActivity.java').read_text()
VIEW=(ROOT/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
MAN=(ROOT/'app/src/main/AndroidManifest.xml').read_text()
GRAD=(ROOT/'app/build.gradle').read_text()

def req(ok,msg):
    if not ok: raise SystemExit('FAIL: '+msg)

req('versionCode 1055' in GRAD and "versionName '55.0.0'" in GRAD, 'V55 version mismatch')
req('private static final int[] V55_READ_ONLY_IDS = {2, 1, 12, 18};' in BLE, 'exact V55 ID set/order missing')
req('private static final int V55_READ_ONLY_LENGTH = 4;' in BLE, 'exact V55 read length missing')
req('DspProtocol.encodeRead(id, 0, V55_READ_ONLY_LENGTH)' in BLE, 'probe is not built with verified read encoder')
req('handleV55ReadProbePlain(plain)' in BLE, 'probe RX handler missing')
req('(plain[0] & 0xff) != 0x60' in BLE, '0x60 response gate missing')
req('v55ReadProbeIndex++' in BLE, 'probe does not advance one-shot sequence')
req('stopOriginalCommandScheduler();' in BLE, 'probe scheduler isolation missing')
req('dspReady = false; // blocks every normal UI writer' in BLE, 'normal writer block missing')
req('startOriginalCommandScheduler();' in BLE, 'scheduler restore missing')

start=BLE.index('void runV55HiddenActuatorReadProbe()')
end=BLE.index('/** Re-read the real DSP descriptor', start)
probe=BLE[start:end]
req('encodeWrite(' not in probe, 'probe section contains encodeWrite')
req('encodeFloatWrite(' not in probe, 'probe section contains scalar write')
req('encodeEqWrite(' not in probe, 'probe section contains EQ write')
req('encodeSaveParamsTrigger' not in probe, 'probe section contains SaveParams')
req('CMD_WRITE_ACTUATOR' not in probe, 'probe section references 0x57 writer')
req('Usb' not in probe and 'USB' not in probe.replace('USB=0',''), 'probe contains USB API/path')
req('android.hardware.usb.host' not in MAN, 'USB host feature remains in current manifest')
req('UsbAcpDiscovery' not in MAIN and 'UsbAcpDiscovery' not in VIEW, 'USB diagnostic still wired into current UI')
req('requestV55HiddenActuatorReadProbe' in VIEW and 'BLE HIDDEN-ID READ PROBE (0 DSP WRITES)' in VIEW, 'V55 UI action missing')
req('onV55ReadOnlyProbeReport' in MAIN, 'V55 copyable report callback missing')
req('no automatic retry' in BLE.lower(), 'explicit no-retry report text missing')
print('V55_BLE_HIDDEN_ID_READ_ONLY_VALIDATION: PASS')
