package com.okn.dsp;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.BluetoothStatusCodes;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * V32 15-Band Graphic EQ transport: verified EQ Gain runs in a serialized low-latency fast lane;
 * scalar controls/polls keep the inherited original-app cadence and TrebleBoost safe-slew transport.
 * The remaining first-band filter is handled in its native type: Tone Control on CH1/2/4-7,
 * General Low-pass on CH3. No filter-type conversion is performed.
 *
 * The 250401 BTSnoop reference shows scalar/poll application traffic around 380 ms.
 * V31 real-hardware testing confirmed the EQ writer is correct but exposed audible latency
 * at that cadence. V32 therefore keeps scalar/poll timing intact while sending only verified
 * EQ Gain changes through a one-at-a-time, latest-value 45 ms path.
 *
 * BLE profile and application framing are taken only from the project's
 * real-device evidence: AB00 service, AB01 TX, AB02 RX, pre-auth 16-byte
 * request, AES-CFB8 authenticated stream, UFE 0x57 actuator writes.
 */
final class BleManager {
    interface Listener {
        void onBleStatus(String status, String deviceName, boolean dspReady);
        void onBleMessage(String message);
        void onScalarValue(int actuatorId, float value);
        void onEqValue(int channel0, int uiBand0, float frequency, float gainDb, float q,
                       boolean gainWritable, boolean shapeWritable);
        void onOutputVolumeValue(int channel0, float valueDb);
        void onDspSyncComplete(String source, int scalarCount, int eqCount, int safePeakingRows);
        void onV55ReadOnlyProbeReport(String report);
    }

    static final UUID AB00 = UUID.fromString("0000ab00-0000-1000-8000-00805f9b34fb");
    static final UUID AB01 = UUID.fromString("0000ab01-0000-1000-8000-00805f9b34fb");
    static final UUID AB02 = UUID.fromString("0000ab02-0000-1000-8000-00805f9b34fb");
    static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

    /** Median/mean command spacing in the official 250401 BTSnoop trace is about 380 ms. */
    private static final long ORIGINAL_COMMAND_CADENCE_MS = 380L;
    /** V32/V37: proven EQ Gain lane. */
    private static final long EQ_REALTIME_MIN_GAP_MS = 45L;
    /** V44 legacy lane retained in source for rollback comparison; V45 UI no longer calls it. */
    private static final long OUTPUT_GAIN_RELEASE_MIN_GAP_MS = 110L;
    /** V45: one tiny CH1 diagnostic attenuation, automatically restored. */
    private static final float V45_PROBE_DELTA_DB = -0.5f;
    private static final long V45_PROBE_AUTO_RESTORE_MS = 2600L;
    /** V38: conservative F/Q lane from the previously qualified safe-EQ pacing policy. */
    private static final long EQ_SHAPE_MIN_GAP_MS = 110L;
    /** V39: multi-band Safe Reset uses the same proven Gain writer, but deliberately slower. */
    private static final long EQ_RESET_MIN_GAP_MS = 110L;
    private static final long EQ_BUSY_RETRY_MS = 8L;
    private static final int EXPECTED_SAFE_PEAKING_ROWS = 55;
    private static final int[] ORIGINAL_POLL_IDS = {19, 20, 0, 21};
    private static final int[] ORIGINAL_POLL_LENGTHS = {1, 1, 4, 4};
    private static final long LIVE_WRITE_TIMEOUT_MS = 1500L;
    /** V55 BLE-only read probe: one known control plus only the three gaps in IDs 0..21. */
    private static final int[] V55_READ_ONLY_IDS = {2, 1, 12, 18};
    private static final int V55_READ_ONLY_LENGTH = 4;
    private static final long V55_READ_ONLY_TIMEOUT_MS = 1200L;
    /** V14: real V13 hardware evidence isolated audible pumping to TrebleBoost / ID11. */
    private static final float TREBLE_MAX_STEP_DB = 0.5f;
    private static final long DESCRIPTOR_TIMEOUT_MS = 15000L;
    /** V44 guarded persistent-save boundary/callback timeout. */
    private static final long SAVE_GUARD_TIMEOUT_MS = 1500L;

    private final Context context;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final BluetoothAdapter adapter;

    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic ab01;
    private BluetoothGattCharacteristic ab02;

    private boolean scanning;
    private boolean transportConnected;
    private boolean dspReady;
    private boolean closed;
    private boolean waitingAuth;
    private boolean readingDescriptor;
    private String deviceName = "OKN-DSP_7CH";

    private DspProtocol.StreamCipher txCipher;
    private DspProtocol.StreamCipher rxCipher;
    private int descriptorExpected = -1;
    private final ByteArrayOutputStream descriptorBytes = new ByteArrayOutputStream(19000);
    private Runnable descriptorTimeout;
    /** V40: identifies whether the authoritative snapshot came from connect/reconnect or manual refresh. */
    private String descriptorReason = "INITIAL";

    private final Map<Integer, Float> scalarValues = new LinkedHashMap<>();
    private final DspProtocol.EqBand[][] eqBands = new DspProtocol.EqBand[7][15];

    private final LinkedHashMap<String, PendingCommand> pending = new LinkedHashMap<>();
    /** V44: UI may move freely; non-CH3 hardware receives only the newest target on release. */
    private final LinkedHashMap<Integer, Float> outputGainTargets = new LinkedHashMap<>();
    private final LinkedHashSet<Integer> outputGainCommitRequested = new LinkedHashSet<>();
    private Runnable outputGainPump;
    private boolean outputGainPumpPosted;
    private long lastOutputGainWriteUptimeMs;
    /** V45 guarded CH1 numerator-only probe. Never persisted and auto-restored. */
    private DspProtocol.EqBand v45ProbeOriginal;
    private boolean v45ProbeActive;
    private boolean v45ProbeWritePending;
    private Runnable v45ProbeAutoRestore;
    /** V32: Gain writes are isolated from the 380 ms scalar/poll cadence. Latest value wins per band. */
    private final LinkedHashMap<String, PendingCommand> eqRealtimePending = new LinkedHashMap<>();
    private Runnable eqRealtimePump;
    private boolean eqRealtimePumpPosted;
    private long lastEqWriteUptimeMs;
    /** V38: F/Q target queue is separately paced at 110 ms but shares the single GATT/TX stream. */
    private final LinkedHashMap<String, EqShapeTarget> eqShapePending = new LinkedHashMap<>();
    private Runnable eqShapePump;
    private boolean eqShapePumpPosted;
    private long lastEqShapeWriteUptimeMs;
    /** Enabled only when the fresh descriptor contains the exact 55 safe PEAKING rows. */
    private boolean eqShapeHealthGate;
    private int safePeakingRows;
    /** V39 Safe Reset: Gain-only, one serialized full-record write at a time. */
    private boolean eqResetActive;
    /** V44: manual-only guarded persistent save. */
    private boolean saveActive;
    private boolean saveWritePending;
    private VerifiedSnapshot saveIntendedSnapshot;
    private long saveBoundaryDeadlineUptimeMs;
    private Runnable saveBoundaryWait;
    private Runnable saveWriteTimeout;
    private int eqResetChannel = -1;
    private int eqResetTotal;
    private int eqResetCompleted;
    private PendingCommand liveInflight;
    private boolean liveWriteBusy;
    private Runnable liveWriteTimeout;
    private final ArrayDeque<WriteTicket> writeTickets = new ArrayDeque<>();

    /** Latest UI targets for verified scalar actuators. */
    private final Map<Integer, Float> scalarTargets = new LinkedHashMap<>();
    private Runnable originalCommandScheduler;
    private int originalPollIndex;
    /** Latest requested Treble target. Only the final touch target is committed by DspView. */
    private Float trebleTarget;

    /** V55 read-only hidden-ID hypothesis probe. No 0x57 writes are permitted here. */
    private boolean v55ReadProbeActive;
    private int v55ReadProbeIndex;
    private int v55AwaitingReadId = -1;
    private StringBuilder v55ReadProbeReport;
    private Runnable v55ReadProbeTimeout;

    private static final class PendingCommand {
        final String key;
        final byte[] plain;
        final int scalarId;
        final float scalarValue;
        final int channel0;
        final int uiBand0;
        final int hwBand1;
        final DspProtocol.EqBand eqTarget;

        private PendingCommand(String key, byte[] plain, int scalarId, float scalarValue,
                               int channel0, int uiBand0, int hwBand1, DspProtocol.EqBand eqTarget) {
            this.key = key;
            this.plain = plain;
            this.scalarId = scalarId;
            this.scalarValue = scalarValue;
            this.channel0 = channel0;
            this.uiBand0 = uiBand0;
            this.hwBand1 = hwBand1;
            this.eqTarget = eqTarget;
        }

        static PendingCommand scalar(int id, float value) {
            return new PendingCommand("S:" + id, DspProtocol.encodeFloatWrite(id, value), id, value,
                    -1, -1, -1, null);
        }

        static PendingCommand eq(int ch, int uiBand, int hwBand, DspProtocol.EqBand target) {
            return new PendingCommand("E:" + ch + ":" + uiBand,
                    DspProtocol.encodeEqWrite(ch, hwBand, target), -1, Float.NaN,
                    ch, uiBand, hwBand, target);
        }

        static PendingCommand output(int ch, DspProtocol.EqBand target) {
            return new PendingCommand("O:" + ch, DspProtocol.encodeEqWrite(ch, 1, target),
                    -1, Float.NaN, ch, 0, 1, target);
        }

        static PendingCommand raw(String key, byte[] plain) {
            return new PendingCommand(key, plain, -1, Float.NaN, -1, -1, -1, null);
        }
    }

    private static final class EqShapeTarget {
        final String key;
        final int channel0;
        final int uiBand0;
        final int hwBand1;
        final float frequency;
        final float q;

        EqShapeTarget(int channel0, int uiBand0, float frequency, float q) {
            this.key = "E:" + channel0 + ":" + uiBand0;
            this.channel0 = channel0;
            this.uiBand0 = uiBand0;
            this.hwBand1 = uiBand0 + 1;
            this.frequency = frequency;
            this.q = q;
        }
    }

    private static final class WriteTicket {
        final String label;
        final PendingCommand command;
        WriteTicket(String label, PendingCommand command) {
            this.label = label;
            this.command = command;
        }
    }

    private static final class VerifiedSnapshot {
        final LinkedHashMap<Integer, Float> scalars = new LinkedHashMap<>();
        final DspProtocol.EqBand[][] eq = new DspProtocol.EqBand[7][DspProtocol.EQ_BANDS];

        VerifiedSnapshot(Map<Integer, Float> sourceScalars, DspProtocol.EqBand[][] sourceEq) {
            scalars.putAll(sourceScalars);
            for (int ch = 0; ch < 7; ch++) {
                System.arraycopy(sourceEq[ch], 0, eq[ch], 0, DspProtocol.EQ_BANDS);
            }
        }

        String firstMismatch(Map<Integer, Float> nowScalars, DspProtocol.EqBand[][] nowEq) {
            for (int id : DspProtocol.VERIFIED_SCALARS) {
                Float a = scalars.get(id), b = nowScalars.get(id);
                if (a == null || b == null || !near(a, b)) return "scalar ID" + id;
            }
            for (int ch = 0; ch < 7; ch++) {
                for (int band = 0; band < DspProtocol.EQ_BANDS; band++) {
                    if (!sameBand(eq[ch][band], nowEq[ch][band])) {
                        return "CH" + (ch + 1) + " Band" + (band + 1);
                    }
                }
            }
            return null;
        }

        private static boolean sameBand(DspProtocol.EqBand a, DspProtocol.EqBand b) {
            if (a == null || b == null || a.type != b.type) return false;
            return near(a.frequency, b.frequency) && near(a.frequency2, b.frequency2) &&
                    near(a.q, b.q) && near(a.boostDb, b.boostDb) && near(a.gain, b.gain) &&
                    near(a.r, b.r) && near(a.b0, b.b0) && near(a.b1, b.b1) &&
                    near(a.b2, b.b2) && near(a.a1, b.a1) && near(a.a2, b.a2);
        }

        private static boolean near(float a, float b) {
            if (!Float.isFinite(a) || !Float.isFinite(b)) return false;
            float tolerance = Math.max(0.0001f, Math.max(Math.abs(a), Math.abs(b)) * 0.00001f);
            return Math.abs(a - b) <= tolerance;
        }
    }

    BleManager(Context context, Listener listener) {
        this.context = context.getApplicationContext();
        this.listener = listener;
        BluetoothAdapter found = null;
        try {
            BluetoothManager manager = (BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE);
            found = manager == null ? null : manager.getAdapter();
        } catch (RuntimeException ignored) {
        }
        adapter = found;
    }

    boolean isConnected() {
        return transportConnected;
    }

    boolean isDspReady() {
        return dspReady;
    }

    void startScan() {
        if (closed) return;
        if (!hasPermissions()) {
            postStatus("รอสิทธิ์ Bluetooth", deviceName, false);
            return;
        }
        if (adapter == null) {
            postStatus("ไม่พบ Bluetooth", deviceName, false);
            return;
        }
        if (!adapter.isEnabled()) {
            postStatus("กรุณาเปิด Bluetooth", deviceName, false);
            return;
        }
        if (dspReady) {
            postStatus("เชื่อมต่อแล้ว", deviceName, true);
            return;
        }
        if (transportConnected) {
            postStatus("กำลังยืนยัน DSP", deviceName, false);
            return;
        }
        try {
            scanner = adapter.getBluetoothLeScanner();
            if (scanner == null) {
                postStatus("สแกน BLE ไม่ได้", deviceName, false);
                return;
            }
            if (scanning) scanner.stopScan(scanCallback);
            scanning = true;
            postStatus("กำลังค้นหา DSP...", deviceName, false);
            scanner.startScan(scanCallback);
            main.postDelayed(this::stopScan, 10000L);
        } catch (SecurityException e) {
            postStatus("สิทธิ์ Bluetooth ไม่ครบ", deviceName, false);
        } catch (RuntimeException e) {
            scanning = false;
            postStatus("เริ่ม BLE ไม่สำเร็จ", deviceName, false);
            postMessage("BLE error: " + e.getClass().getSimpleName());
        }
    }

    void stopScan() {
        if (!scanning || scanner == null || !hasPermissions()) return;
        try { scanner.stopScan(scanCallback); } catch (SecurityException ignored) {}
        scanning = false;
    }

    /**
     * V55 targeted BLE read-only probe. The fresh descriptor declares global IDs
     * 0,2..11,13..17,19..21; only 1,12,18 are gaps inside that observed range.
     * ID2 is a positive control. Every request is 0x58 / offset0 / length4 and is
     * transmitted exactly once. No 0x57 write, EQ write, or SaveParams is issued.
     */
    void runV55HiddenActuatorReadProbe() {
        main.post(this::runV55HiddenActuatorReadProbeOnMain);
    }

    private void runV55HiddenActuatorReadProbeOnMain() {
        if (v55ReadProbeActive) {
            postMessage("V55 read-only probe already running");
            return;
        }
        if (!dspReady || txCipher == null || rxCipher == null || readingDescriptor || saveActive) {
            postMessage("V55 probe unavailable • wait for BLE DSP READY");
            return;
        }
        boolean ticketsBusy;
        synchronized (writeTickets) { ticketsBusy = !writeTickets.isEmpty(); }
        if (eqResetActive || liveWriteBusy || ticketsBusy || !pending.isEmpty() ||
                !outputGainTargets.isEmpty() || !outputGainCommitRequested.isEmpty() ||
                !eqRealtimePending.isEmpty() || !eqShapePending.isEmpty() || trebleTarget != null ||
                v45ProbeActive || v45ProbeWritePending) {
            postMessage("V55 probe blocked • wait until BLE command queue is idle");
            return;
        }

        stopOriginalCommandScheduler();
        v55ReadProbeActive = true;
        v55ReadProbeIndex = 0;
        v55AwaitingReadId = -1;
        v55ReadProbeReport = new StringBuilder(1800);
        v55ReadProbeReport.append("OKN DSP V55 — BLE HIDDEN-ID READ-ONLY probe\n")
                .append("SAFETY: BLE only; UFE READ 0x58 only; UFE WRITE 0x57=0; EQ writes=0; SaveParams=0; USB=0.\n")
                .append("Fresh descriptor inventory: actuators=2,3,4,5,6,7,8,9,10,11,13,14,15,16,17; sensors=0,19,20,21.\n")
                .append("Observed global-ID gaps inside 0..21: 1,12,18.\n")
                .append("Probe order: ID2 positive control, then ID1, ID12, ID18.\n")
                .append("Each request: opcode=0x58 offset=0 length=4; exactly once; no automatic retry.\n")
                .append("Length 4 is a FLOAT32-sized read hypothesis only; any reply is NOT classified as gain without further proof.\n\n");
        dspReady = false; // blocks every normal UI writer while the probe owns the CFB8 stream
        postStatus("V55 BLE READ-ONLY probe", deviceName, false);
        sendV55NextRead();
    }

    private void sendV55NextRead() {
        if (!v55ReadProbeActive) return;
        if (v55ReadProbeIndex >= V55_READ_ONLY_IDS.length) {
            finishV55ReadProbe("COMPLETE");
            return;
        }
        final int id = V55_READ_ONLY_IDS[v55ReadProbeIndex];
        final byte[] plain = DspProtocol.encodeRead(id, 0, V55_READ_ONLY_LENGTH);
        v55AwaitingReadId = id;
        v55ReadProbeReport.append("TX ID").append(id).append(" plain=").append(v55Hex(plain)).append('\n');
        final byte[] encrypted;
        try {
            encrypted = txCipher.next(plain);
        } catch (RuntimeException e) {
            abortV55ReadProbe("TX_CIPHER_ERROR ID" + id);
            sessionFault("V55 TX cipher error");
            return;
        }
        if (!writeNoResponse(encrypted, "V55_READ_ID" + id, null)) {
            abortV55ReadProbe("GATT_TX_FAILED ID" + id);
            sessionFault("V55 BLE read request failed");
            return;
        }
        cancelV55ReadProbeTimeout();
        v55ReadProbeTimeout = () -> {
            if (!v55ReadProbeActive || v55AwaitingReadId != id) return;
            v55ReadProbeReport.append("RX ID").append(id).append(" = NO_REPLY within guarded window\n\n");
            v55AwaitingReadId = -1;
            v55ReadProbeIndex++;
            main.postDelayed(this::sendV55NextRead, ORIGINAL_COMMAND_CADENCE_MS);
        };
        main.postDelayed(v55ReadProbeTimeout, V55_READ_ONLY_TIMEOUT_MS);
    }

    private void handleV55ReadProbePlain(byte[] plain) {
        if (!v55ReadProbeActive || plain == null || plain.length == 0) return;
        v55ReadProbeReport.append("RX raw=").append(v55Hex(plain)).append('\n');
        if ((plain[0] & 0xff) != 0x60 || plain.length < 9) {
            v55ReadProbeReport.append("RX classification=UNEXPECTED_PLAINTEXT (waiting for ID")
                    .append(v55AwaitingReadId).append(")\n");
            return;
        }
        int id = ((plain[1] & 0xff) << 24) | ((plain[2] & 0xff) << 16) |
                ((plain[3] & 0xff) << 8) | (plain[4] & 0xff);
        int offset = ((plain[5] & 0xff) << 8) | (plain[6] & 0xff);
        int declared = ((plain[7] & 0xff) << 8) | (plain[8] & 0xff);
        int available = Math.max(0, plain.length - 9);
        v55ReadProbeReport.append("RX decoded id=").append(id).append(" offset=").append(offset)
                .append(" declaredLen=").append(declared).append(" actualPayload=").append(available).append('\n');
        if (id != v55AwaitingReadId) {
            v55ReadProbeReport.append("RX does not match awaiting ID").append(v55AwaitingReadId).append("; not consumed as result\n");
            return;
        }
        if (declared == 4 && available >= 4) {
            int bits = (plain[9] & 0xff) | ((plain[10] & 0xff) << 8) |
                    ((plain[11] & 0xff) << 16) | ((plain[12] & 0xff) << 24);
            float f = Float.intBitsToFloat(bits);
            v55ReadProbeReport.append("payload4=").append(v55Hex(new byte[]{plain[9],plain[10],plain[11],plain[12]}))
                    .append(" float32LE=").append(Float.isFinite(f) ? Float.toString(f) : "NON_FINITE")
                    .append(" (interpretation only; NOT proven gain)\n");
        }
        v55ReadProbeReport.append('\n');
        cancelV55ReadProbeTimeout();
        v55AwaitingReadId = -1;
        v55ReadProbeIndex++;
        main.postDelayed(this::sendV55NextRead, ORIGINAL_COMMAND_CADENCE_MS);
    }

    private void finishV55ReadProbe(String status) {
        if (!v55ReadProbeActive) return;
        cancelV55ReadProbeTimeout();
        if (v55ReadProbeReport != null) {
            v55ReadProbeReport.append("V55 ").append(status).append("\n")
                    .append("Interpretation rules: ID2 reply proves the read path/control only. A candidate reply does not prove Gain/Mixer semantics. No reply does not prove the ID is absent.\n")
                    .append("DSP state writes=0; SaveParams=0; probe requests were not retried.\n");
        }
        String report = v55ReadProbeReport == null ? "V55 report unavailable" : v55ReadProbeReport.toString();
        v55ReadProbeActive = false;
        v55AwaitingReadId = -1;
        v55ReadProbeReport = null;
        dspReady = true;
        postStatus("เชื่อมต่อแล้ว", deviceName, true);
        startOriginalCommandScheduler();
        post(() -> listener.onV55ReadOnlyProbeReport(report));
    }

    private void abortV55ReadProbe(String reason) {
        if (!v55ReadProbeActive) return;
        cancelV55ReadProbeTimeout();
        if (v55ReadProbeReport != null) {
            v55ReadProbeReport.append("V55 ABORTED: ").append(reason).append('\n')
                    .append("DSP state writes=0; SaveParams=0; no retry. Re-authentication required if transport ordering is uncertain.\n");
            String report = v55ReadProbeReport.toString();
            post(() -> listener.onV55ReadOnlyProbeReport(report));
        }
        v55ReadProbeActive = false;
        v55AwaitingReadId = -1;
        v55ReadProbeReport = null;
    }

    private void cancelV55ReadProbeTimeout() {
        if (v55ReadProbeTimeout != null) main.removeCallbacks(v55ReadProbeTimeout);
        v55ReadProbeTimeout = null;
    }

    private static String v55Hex(byte[] bytes) {
        if (bytes == null) return "";
        StringBuilder out = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) out.append(String.format(Locale.US, "%02X", b & 0xff));
        return out.toString();
    }

    /** Re-read the real DSP descriptor in the current authenticated session. */
    void requestDspRefresh() {
        main.post(() -> {
            if (saveActive) {
                postMessage("DSP Save verification is already running");
                return;
            }
            if (v45ProbeActive || v45ProbeWritePending) {
                postMessage("V45 CH1 probe active • wait for automatic restore first");
                return;
            }
            if (!dspReady || txCipher == null || rxCipher == null) {
                postMessage("DSP ยังไม่ READY — รอเชื่อมต่อให้สมบูรณ์ก่อน");
                if (!transportConnected) startScan();
                return;
            }
            if (eqResetActive || liveWriteBusy || !pending.isEmpty() || !outputGainTargets.isEmpty() || !eqRealtimePending.isEmpty() || !eqShapePending.isEmpty()) {
                postMessage("กำลังส่งค่า Real-time — รอสักครู่แล้วกดโหลดจากอุปกรณ์อีกครั้ง");
                return;
            }
            startDescriptorRequest("REFRESH");
        });
    }

    /** Compatibility name used by the V5 UI button. */
    void readKnownCharacteristic() {
        requestDspRefresh();
    }

    /** V44 Restore is readback-only: never replay local state to hardware. */
    void requestVerifiedRestore() {
        main.post(() -> {
            if (saveActive) {
                postMessage("DSP Save verification is already running");
                return;
            }
            if (v45ProbeActive || v45ProbeWritePending) {
                postMessage("V45 CH1 probe active • use Restore CH1 / wait for auto-restore");
                return;
            }
            if (!dspReady || txCipher == null || rxCipher == null) {
                postMessage("DSP ยังไม่ READY — Restore ต้องอ่านสถานะจริงจาก DSP");
                if (!transportConnected) startScan();
                return;
            }
            if (eqResetActive || liveWriteBusy || !pending.isEmpty() || !outputGainTargets.isEmpty() || !eqRealtimePending.isEmpty() || !eqShapePending.isEmpty()) {
                postMessage("กำลังส่งค่า Real-time — Restore ถูกบล็อกจนคิวว่าง");
                return;
            }
            startDescriptorRequest("RESTORE");
        });
    }

    /** V44 manual-only persistent SaveParams transaction. No caller invokes this automatically. */
    void requestPersistentSave() {
        main.post(this::requestPersistentSaveOnMain);
    }

    private void requestPersistentSaveOnMain() {
        if (saveActive) {
            postMessage("DSP Save verification is already running");
            return;
        }
        if (v45ProbeActive || v45ProbeWritePending || v45ProbeOriginal != null) {
            postMessage("SAVE BLOCKED • V45 diagnostic probe must be restored first");
            return;
        }
        if (!dspReady || txCipher == null || rxCipher == null) {
            postMessage("SAVE BLOCKED • DSP not READY");
            return;
        }
        if (!realtimeQueuesIdleForSave()) {
            postMessage("SAVE BLOCKED • realtime/GATT queue not idle");
            return;
        }

        saveActive = true;
        saveWritePending = false;
        saveIntendedSnapshot = null;
        stopOriginalCommandScheduler();
        stopOutputGainPump();
        stopEqRealtimePump();
        stopEqShapePump();
        postMessage("V49 SAVE PRECHECK • fresh authenticated DSP readback");
        startDescriptorRequest("SAVE_PRECHECK");
    }

    private boolean realtimeQueuesIdleForSave() {
        if (readingDescriptor || eqResetActive || liveWriteBusy || saveWritePending || v45ProbeActive || v45ProbeWritePending) return false;
        if (!pending.isEmpty() || !outputGainTargets.isEmpty() || !eqRealtimePending.isEmpty() || !eqShapePending.isEmpty()) return false;
        if (trebleTarget != null) return false;
        synchronized (writeTickets) { return writeTickets.isEmpty(); }
    }

    void setScalarRealtime(int actuatorId, float requestedValue) {
        main.post(() -> setScalarRealtimeOnMain(actuatorId, requestedValue));
    }

    /** Final-value hook. The latest value is already waiting for the next 380 ms scheduler slot. */
    void flushScalarRealtime(int actuatorId) {
        // Intentionally no-op. Never create a second packet on finger release.
    }

    private void setScalarRealtimeOnMain(int actuatorId, float requestedValue) {
        if (!dspReady || txCipher == null || saveActive) return;
        float safe = DspProtocol.sanitizeScalar(actuatorId, requestedValue);
        if (!Float.isFinite(safe)) return;

        scalarTargets.put(actuatorId, safe);

        if (actuatorId == DspProtocol.ID_TREBLE_BOOST) {
            // V14 Treble-only policy. V13 proved Master/Bass/Middle stable with the 380 ms
            // scheduler, but ID11 still produced severe pumping while dragging. Never feed
            // the raw target directly to ID11. Walk from the last successful hardware value
            // toward the newest target in <=0.5 dB confirmed steps.
            pending.remove("S:" + actuatorId);
            trebleTarget = safe;
            // Do not transmit here. ID11 gets at most one <=0.5 dB step in each existing
            // 380 ms official-style scheduler slot. This keeps the proven V13 cadence while
            // eliminating the large direct target jumps that caused pumping.
            return;
        }

        // Original-app behavior for all other scalar controls: UI can update as often as it
        // wants, but only the newest target is retained and emitted by the shared 380 ms
        // scheduler.
        String key = "S:" + actuatorId;
        pending.remove(key);
        pending.put(key, PendingCommand.scalar(actuatorId, safe));
    }

    /**
     * V45 production-safe behavior: only CH3 has a hardware-qualified output level
     * (BassVolume / actuator ID8). V44 proved that using the first Tone-Control row
     * as a normal fader clicks, so CH1/2/4/5/6/7 are locked out of the normal slider
     * path until a true output gain mapping is proven.
     */
    void setOutputVolumeRealtime(int channel0, float requestedDb) {
        main.post(() -> {
            if (!dspReady || txCipher == null || saveActive) return;
            if (channel0 != 2) return;
            float safe = DspProtocol.sanitizeOutputGain(requestedDb);
            if (Float.isFinite(safe)) setScalarRealtimeOnMain(DspProtocol.ID_BASS_VOLUME, safe);
        });
    }

    void flushOutputVolumeRealtime(int channel0) {
        // V45: no non-CH3 full-record output write exists anymore.
    }

    /**
     * V45 guarded proof: CH1 only, first native type-17 row only, B0/B1/B2 only.
     * The write is a tiny -0.5 dB relative attenuation and is automatically restored.
     * It never touches G/type/F/F2/Q/B/R/A1/A2 and never invokes SaveParams.
     */
    void runV45Ch1GainProbe() {
        main.post(this::runV45Ch1GainProbeOnMain);
    }

    private void runV45Ch1GainProbeOnMain() {
        if (!dspReady || txCipher == null || rxCipher == null || readingDescriptor || saveActive) {
            postMessage("V45 probe unavailable • wait for DSP READY");
            return;
        }
        if (v45ProbeActive || v45ProbeWritePending || v45ProbeOriginal != null) {
            postMessage("V45 CH1 probe already active • Restore CH1 first");
            return;
        }
        if (eqResetActive || liveWriteBusy || !pending.isEmpty() || !eqRealtimePending.isEmpty() ||
                !eqShapePending.isEmpty() || !outputGainCommitRequested.isEmpty()) {
            postMessage("V45 probe blocked • realtime/GATT queue is busy");
            return;
        }
        DspProtocol.EqBand current = eqBands[0][0];
        if (current == null || current.type != DspProtocol.EQ_TONE_CONTROL_TYPE || !current.outputGainWritable()) {
            postMessage("V45 probe blocked • CH1 native Tone-Control row not verified");
            return;
        }
        try {
            byte[] plain = DspProtocol.encodeEqNumeratorScaleProbe(0, 1, current, V45_PROBE_DELTA_DB);
            v45ProbeOriginal = current;
            v45ProbeWritePending = true;
            sendScheduledControl(PendingCommand.raw("V45P:TARGET", plain));
            postMessage("V45 CH1 probe sending • B0/B1/B2 only • -0.5 dB • NO SAVE");
        } catch (IllegalArgumentException e) {
            v45ProbeOriginal = null;
            v45ProbeWritePending = false;
            postMessage("V45 probe blocked • invalid live CH1 row");
        }
    }

    void restoreV45Ch1GainProbe() {
        main.post(this::restoreV45Ch1GainProbeOnMain);
    }

    private void restoreV45Ch1GainProbeOnMain() {
        if (v45ProbeOriginal == null) {
            postMessage("V45 CH1 probe is not active");
            return;
        }
        if (!dspReady || txCipher == null || liveWriteBusy || saveActive || readingDescriptor) {
            // Keep the original snapshot; auto-restore will retry while the authenticated session lives.
            scheduleV45ProbeAutoRestore(180L);
            return;
        }
        try {
            byte[] plain = DspProtocol.encodeEqNumeratorRestore(0, 1, v45ProbeOriginal);
            v45ProbeWritePending = true;
            sendScheduledControl(PendingCommand.raw("V45P:RESTORE", plain));
        } catch (IllegalArgumentException e) {
            postMessage("V45 restore failed to build • power-cycle DSP before Save");
        }
    }

    private void scheduleV45ProbeAutoRestore(long delayMs) {
        cancelV45ProbeAutoRestore();
        v45ProbeAutoRestore = () -> {
            v45ProbeAutoRestore = null;
            if (closed || v45ProbeOriginal == null) return;
            restoreV45Ch1GainProbeOnMain();
        };
        main.postDelayed(v45ProbeAutoRestore, Math.max(0L, delayMs));
    }

    private void cancelV45ProbeAutoRestore() {
        if (v45ProbeAutoRestore != null) main.removeCallbacks(v45ProbeAutoRestore);
        v45ProbeAutoRestore = null;
    }

    private void clearV45ProbeState() {
        cancelV45ProbeAutoRestore();
        v45ProbeOriginal = null;
        v45ProbeActive = false;
        v45ProbeWritePending = false;
    }

    void setEqRealtime(int channel0, int uiBand0, float frequency, float gainDb, float q) {
        main.post(() -> {
            if (!dspReady || txCipher == null || eqResetActive || saveActive) return;
            if ((v45ProbeActive || v45ProbeWritePending) && channel0 == 0) return;
            if (channel0 < 0 || channel0 >= 7 || uiBand0 < 0 || uiBand0 >= DspProtocol.EQ_BANDS) return;

            int hwBand1 = uiBand0 + 1;
            DspProtocol.EqBand current = eqBands[channel0][uiBand0];
            if (current == null || !isGainWritable(uiBand0, current)) return;
            if (!Float.isFinite(gainDb) || gainDb < -12f || gainDb > 12f) return;

            try {
                DspProtocol.EqBand target = (uiBand0 == 0 && current.writableFirstBandSpecial())
                        ? DspProtocol.firstBandGainFromCurrent(current, gainDb)
                        : DspProtocol.peakingFromCurrent(current, gainDb);
                enqueueEqLatest(PendingCommand.eq(channel0, uiBand0, hwBand1, target));
            } catch (IllegalArgumentException ignored) {
            }
        });
    }

    /**
     * V38 Frequency/Q path. This is deliberately narrower than the old V33-V36 path:
     * only the exact descriptor-safe PEAKING rows are accepted, and only after the
     * fresh-descriptor gate sees all 55 expected safe rows. Each write remains a full
     * 48-byte band record on the single serialized CFB8/GATT stream.
     */
    void setEqShapeRealtime(int channel0, int uiBand0, float frequency, float gainDb, float q) {
        main.post(() -> {
            if (!dspReady || txCipher == null || !eqShapeHealthGate || eqResetActive || saveActive) return;
            if ((v45ProbeActive || v45ProbeWritePending) && channel0 == 0) return;
            if (channel0 < 0 || channel0 >= 7 || uiBand0 < 0 || uiBand0 >= DspProtocol.EQ_BANDS) return;
            DspProtocol.EqBand current = eqBands[channel0][uiBand0];
            if (!isShapeWritable(uiBand0, current)) return;
            if (!Float.isFinite(frequency) || frequency < 20f || frequency > 20000f) return;
            if (!Float.isFinite(q) || q < 0.05f || q > 20f) return;
            enqueueEqShapeLatest(new EqShapeTarget(channel0, uiBand0, frequency, q));
        });
    }

    /**
     * V39 Safe Reset EQ. This intentionally resets Gain only and preserves every live
     * Frequency/Q/type/metadata field. It uses the exact V32/V37 proven full-48-byte Gain
     * writer, serialized at a slower 110 ms cadence. No bulk packet and no F/Q rewrite.
     *
     * @return number of hardware Gain rows queued, 0 when already flat, -1 when unavailable,
     *         -2 when another Safe Reset is already running, -3 when a live write is still
     *         in flight. Must be called on the main thread.
     */
    int resetEqSafe(int channel0) {
        if (Looper.myLooper() != Looper.getMainLooper()) throw new IllegalStateException("main thread required");
        if (!dspReady || txCipher == null || saveActive || channel0 < 0 || channel0 >= 7) return -1;
        if (eqResetActive) return -2;
        // Never snapshot a 48-byte reset target while an older EQ/scalar record is still in
        // flight. Waiting one tap is safer than rebuilding from stale live metadata.
        if (liveWriteBusy) return -3;

        // Drop all stale touch targets before reset. An already in-flight safe record is allowed
        // to finish, then this queue takes over on the same serialized CFB8/GATT stream.
        stopEqRealtimePump();
        stopEqShapePump();

        int queued = 0;
        for (int band0 = 0; band0 < DspProtocol.EQ_BANDS; band0++) {
            DspProtocol.EqBand current = eqBands[channel0][band0];
            if (!isGainWritable(band0, current)) continue;
            if (Math.abs(current.graphicGainDb()) <= 0.001f) continue;
            try {
                DspProtocol.EqBand target = (band0 == 0 && current.writableFirstBandSpecial())
                        ? DspProtocol.firstBandGainFromCurrent(current, 0f)
                        : DspProtocol.peakingFromCurrent(current, 0f);
                PendingCommand cmd = PendingCommand.eq(channel0, band0, band0 + 1, target);
                eqRealtimePending.put(cmd.key, cmd);
                queued++;
            } catch (IllegalArgumentException ignored) {
                // Fail closed for any row whose live descriptor no longer satisfies the proven writer.
            }
        }

        if (queued == 0) {
            postMessage("Safe Reset EQ • CH" + (channel0 + 1) + " already flat • F/Q preserved");
            return 0;
        }

        eqResetActive = true;
        eqResetChannel = channel0;
        eqResetTotal = queued;
        eqResetCompleted = 0;
        postMessage("Safe Reset EQ • CH" + (channel0 + 1) + " • " + queued + " Gain rows → 0 dB • F/Q preserved");
        scheduleEqRealtimePump(0L);
        return queued;
    }

    private void clearEqResetState() {
        eqResetActive = false;
        eqResetChannel = -1;
        eqResetTotal = 0;
        eqResetCompleted = 0;
    }

    void reportUnverifiedControl(String name) {
        postMessage(name + " เปลี่ยนค่า UI แล้ว • hardware write ยังล็อกเพราะยังไม่มี packet ที่ยืนยัน");
    }

    void close() {
        closed = true;
        stopScan();
        main.removeCallbacksAndMessages(null);
        resetSessionState();
        if (gatt != null) {
            try { gatt.close(); } catch (Exception ignored) {}
            gatt = null;
        }
        transportConnected = false;
    }

    private boolean hasPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            return context.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
                    context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult result) {
            if (result == null || result.getDevice() == null || closed) return;
            String name = null;
            try {
                if (result.getScanRecord() != null) name = result.getScanRecord().getDeviceName();
                if (name == null) name = result.getDevice().getName();
            } catch (SecurityException ignored) {}
            if (name == null) return;
            String upper = name.toUpperCase(Locale.ROOT);
            if (!(upper.contains("GOLOPINE") || upper.contains("DSP") || upper.contains("OKN"))) return;
            deviceName = name;
            stopScan();
            postStatus("กำลังเชื่อมต่อ...", deviceName, false);
            try {
                closeGattOnly();
                gatt = result.getDevice().connectGatt(context, false, gattCallback, BluetoothDevice.TRANSPORT_LE);
            } catch (SecurityException e) {
                postStatus("เชื่อมต่อไม่ได้: สิทธิ์ไม่ครบ", deviceName, false);
            } catch (RuntimeException e) {
                postStatus("เชื่อมต่อไม่ได้", deviceName, false);
                postMessage("connectGatt error: " + e.getClass().getSimpleName());
            }
        }

        @Override public void onScanFailed(int errorCode) {
            scanning = false;
            postStatus("สแกน BLE ล้มเหลว " + errorCode, deviceName, false);
        }
    };

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt callbackGatt, int status, int newState) {
            if (callbackGatt != gatt) return;
            main.post(() -> {
                if (callbackGatt != gatt) return;
                if (status != BluetoothGatt.GATT_SUCCESS) {
                    transportConnected = false;
                    resetSessionState();
                    postStatus("BLE error " + status + " • กำลังเชื่อมใหม่", deviceName, false);
                    closeGattOnly();
                    if (!closed) main.postDelayed(BleManager.this::startScan, 1500L);
                    return;
                }
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    transportConnected = true;
                    resetSessionState();
                    postStatus("กำลังเตรียม DSP", deviceName, false);
                    try {
                        callbackGatt.requestConnectionPriority(BluetoothGatt.CONNECTION_PRIORITY_BALANCED);
                        callbackGatt.requestMtu(517);
                    } catch (SecurityException ignored) {}
                    main.postDelayed(() -> {
                        if (gatt != callbackGatt || closed) return;
                        try { callbackGatt.discoverServices(); } catch (SecurityException ignored) {}
                    }, 250L);
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    transportConnected = false;
                    resetSessionState();
                    postStatus("ตัดการเชื่อมต่อ • กำลังค้นหาใหม่", deviceName, false);
                    closeGattOnly();
                    if (!closed) main.postDelayed(BleManager.this::startScan, 1500L);
                }
            });
        }

        @Override public void onMtuChanged(BluetoothGatt callbackGatt, int mtu, int status) {
            // Service discovery is scheduled independently so an OEM missing this callback cannot stall startup.
        }

        @Override public void onServicesDiscovered(BluetoothGatt callbackGatt, int status) {
            if (callbackGatt != gatt) return;
            main.post(() -> {
                if (callbackGatt != gatt) return;
                BluetoothGattService service = callbackGatt.getService(AB00);
                ab01 = service == null ? null : service.getCharacteristic(AB01);
                ab02 = service == null ? null : service.getCharacteristic(AB02);
                if (status != BluetoothGatt.GATT_SUCCESS || ab01 == null || ab02 == null) {
                    postStatus("ไม่พบโปรไฟล์ DSP AB00/AB01/AB02", deviceName, false);
                    return;
                }
                postStatus("กำลังเปิดข้อมูล DSP", deviceName, false);
                enableAb02Notifications(callbackGatt, ab02);
            });
        }

        @Override public void onDescriptorWrite(BluetoothGatt callbackGatt, BluetoothGattDescriptor descriptor, int status) {
            if (callbackGatt != gatt) return;
            main.post(() -> {
                if (callbackGatt != gatt) return;
                if (!CCCD.equals(descriptor.getUuid())) return;
                if (status != BluetoothGatt.GATT_SUCCESS) {
                    postStatus("เปิด AB02 Notify ไม่สำเร็จ", deviceName, false);
                    return;
                }
                postStatus("กำลังยืนยัน DSP", deviceName, false);
                main.postDelayed(BleManager.this::startAuthenticatedSession, 120L);
            });
        }

        @Override public void onCharacteristicWrite(BluetoothGatt callbackGatt, BluetoothGattCharacteristic characteristic, int status) {
            if (callbackGatt != gatt || !AB01.equals(characteristic.getUuid())) return;
            final WriteTicket ticket;
            synchronized (writeTickets) {
                ticket = writeTickets.pollFirst();
            }
            main.post(() -> handleWriteResult(ticket, status));
        }

        @Override public void onCharacteristicChanged(BluetoothGatt callbackGatt, BluetoothGattCharacteristic characteristic, byte[] value) {
            if (callbackGatt != gatt || !AB02.equals(characteristic.getUuid())) return;
            byte[] copy = value == null ? new byte[0] : value.clone();
            main.post(() -> handleAb02(copy));
        }

        @SuppressWarnings("deprecation")
        @Override public void onCharacteristicChanged(BluetoothGatt callbackGatt, BluetoothGattCharacteristic characteristic) {
            if (Build.VERSION.SDK_INT >= 33) return;
            if (callbackGatt != gatt || !AB02.equals(characteristic.getUuid())) return;
            byte[] value = characteristic.getValue();
            byte[] copy = value == null ? new byte[0] : value.clone();
            main.post(() -> handleAb02(copy));
        }
    };

    private void enableAb02Notifications(BluetoothGatt g, BluetoothGattCharacteristic ch) {
        if (!hasPermissions()) return;
        try {
            boolean local = g.setCharacteristicNotification(ch, true);
            BluetoothGattDescriptor cccd = ch.getDescriptor(CCCD);
            if (!local || cccd == null) {
                postStatus("เปิด Notify AB02 ไม่สำเร็จ", deviceName, false);
                return;
            }
            if (Build.VERSION.SDK_INT >= 33) {
                int rc = g.writeDescriptor(cccd, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                if (rc != BluetoothStatusCodes.SUCCESS) postStatus("ส่ง CCCD ไม่สำเร็จ " + rc, deviceName, false);
            } else {
                //noinspection deprecation
                cccd.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                //noinspection deprecation
                if (!g.writeDescriptor(cccd)) postStatus("ส่ง CCCD ไม่สำเร็จ", deviceName, false);
            }
        } catch (SecurityException e) {
            postStatus("สิทธิ์ Bluetooth ไม่ครบ", deviceName, false);
        }
    }

    private void startAuthenticatedSession() {
        if (gatt == null || ab01 == null || closed) return;
        resetSessionState();
        waitingAuth = true;
        postStatus("กำลังยืนยัน DSP", deviceName, false);
        if (!writeNoResponse(DspProtocol.AUTH16, "AUTH16", null)) {
            waitingAuth = false;
            postStatus("ส่ง Authentication ไม่สำเร็จ", deviceName, false);
        }
    }

    private void handleAb02(byte[] value) {
        if (waitingAuth) {
            if (value.length != 32) return;
            try {
                DspProtocol.PreAuth auth = DspProtocol.decodeAuth32(value);
                txCipher = new DspProtocol.StreamCipher(auth.randKey, true);
                rxCipher = new DspProtocol.StreamCipher(auth.randKey, false);
                waitingAuth = false;
                postStatus("กำลังโหลดค่า DSP", deviceName, false);
                startDescriptorRequest("INITIAL");
            } catch (Exception e) {
                waitingAuth = false;
                txCipher = null;
                rxCipher = null;
                postStatus("Authentication ไม่ผ่าน", deviceName, false);
                postMessage("Auth decode error: " + e.getClass().getSimpleName());
            }
            return;
        }

        if (rxCipher == null) return;
        final byte[] plain;
        try {
            plain = rxCipher.next(value);
        } catch (RuntimeException e) {
            sessionFault("RX decrypt error");
            return;
        }
        if (readingDescriptor) collectDescriptor(plain);
        else if (v55ReadProbeActive) handleV55ReadProbePlain(plain);
    }

    private void startDescriptorRequest(String reason) {
        if (txCipher == null || gatt == null || ab01 == null || readingDescriptor) return;
        descriptorReason = (reason == null || reason.trim().isEmpty()) ? "UNKNOWN" : reason.trim();
        readingDescriptor = true;
        dspReady = false;
        descriptorExpected = -1;
        descriptorBytes.reset();
        postStatus("กำลังอ่านค่า DSP", deviceName, false);
        byte[] encrypted;
        try { encrypted = txCipher.next(DspProtocol.DEVICE_DESCRIPTION_REQUEST); }
        catch (RuntimeException e) { sessionFault("TX cipher error"); return; }
        if (!writeNoResponse(encrypted, "DESC_" + reason, null)) {
            readingDescriptor = false;
            sessionFault("ส่งคำขอ Device Description ไม่สำเร็จ");
            return;
        }
        cancelDescriptorTimeout();
        descriptorTimeout = () -> {
            if (!readingDescriptor) return;
            readingDescriptor = false;
            descriptorExpected = -1;
            descriptorBytes.reset();
            sessionFault("อ่าน Device Description timeout");
        };
        main.postDelayed(descriptorTimeout, DESCRIPTOR_TIMEOUT_MS);
    }

    private void collectDescriptor(byte[] plain) {
        if (plain == null || plain.length == 0) return;
        if (descriptorExpected < 0) {
            if (plain.length < 4 || (plain[0] & 0xff) != 0x86) return;
            descriptorExpected = (plain[1] & 0xff) | ((plain[2] & 0xff) << 8) | ((plain[3] & 0xff) << 16);
            if (descriptorExpected <= 0 || descriptorExpected > 1024 * 1024) {
                sessionFault("Device Description length ผิดปกติ");
                return;
            }
            descriptorBytes.reset();
            descriptorBytes.write(plain, 4, plain.length - 4);
        } else {
            if ((plain[0] & 0xff) != 0x82) return;
            descriptorBytes.write(plain, 1, plain.length - 1);
        }

        if (descriptorExpected > 0 && descriptorBytes.size() >= descriptorExpected) {
            byte[] all = descriptorBytes.toByteArray();
            byte[] json = new byte[descriptorExpected];
            System.arraycopy(all, 0, json, 0, descriptorExpected);
            readingDescriptor = false;
            descriptorExpected = -1;
            descriptorBytes.reset();
            cancelDescriptorTimeout();
            try {
                loadDescriptor(new JSONObject(new String(json, StandardCharsets.UTF_8)));
            } catch (Exception e) {
                sessionFault("Device Description JSON อ่านไม่ได้: " + e.getClass().getSimpleName());
            }
        }
    }

    private void loadDescriptor(JSONObject obj) {
        scalarValues.clear();
        for (int ch = 0; ch < 7; ch++) {
            for (int b = 0; b < 15; b++) eqBands[ch][b] = null;
        }

        JSONArray actuators = obj.optJSONArray("actuators");
        if (actuators == null) {
            sessionFault("Device Description ไม่มี actuators");
            return;
        }

        int eqCount = 0;
        for (int i = 0; i < actuators.length(); i++) {
            JSONObject a = actuators.optJSONObject(i);
            if (a == null) continue;
            int id = a.optInt("ID", -1);
            int type = a.optInt("type", -1);
            if (DspProtocol.scalarAllowed(id) && type == DspProtocol.TYPE_FLOAT32 && a.has("UFE_TYPE_FLOAT32")) {
                double d = a.optDouble("UFE_TYPE_FLOAT32", Double.NaN);
                if (Double.isFinite(d)) scalarValues.put(id, (float) d);
            }
            int ch = channelForEqActuator(id);
            if (ch >= 0 && type == DspProtocol.TYPE_BIQUAD_CASCADE15_F) {
                JSONArray arr = a.optJSONArray("UFE_TYPE_BIQUAD_CASCADE15_F");
                if (arr != null) {
                    for (int b = 0; b < Math.min(15, arr.length()); b++) {
                        DspProtocol.EqBand band = parseBand(arr.optJSONObject(b));
                        eqBands[ch][b] = band;
                        if (band != null) eqCount++;
                    }
                }
            }
        }

        JSONArray sensors = obj.optJSONArray("sensors");
        int sensorCount = sensors == null ? 0 : sensors.length();
        safePeakingRows = 0;
        for (int ch = 0; ch < 7; ch++) {
            for (int b = 0; b < DspProtocol.EQ_BANDS; b++) {
                DspProtocol.EqBand row = eqBands[ch][b];
                if (row != null && row.safePeakingDescriptor()) safePeakingRows++;
            }
        }
        eqShapeHealthGate = safePeakingRows == EXPECTED_SAFE_PEAKING_ROWS;

        boolean scalarOk = scalarValues.size() == DspProtocol.VERIFIED_SCALARS.length;
        boolean eqOk = eqCount == 105;
        boolean sensorOk = sensorCount >= 4;

        if (!scalarOk || !eqOk || !sensorOk) {
            dspReady = false;
            postStatus("DSP ข้อมูลไม่ครบ • S" + scalarValues.size() + "/7 EQ" + eqCount + "/105", deviceName, false);
            if (saveActive) {
                String saveHealthFailure = "SAVE_POSTCHECK".equals(descriptorReason)
                        ? "SAVE UNCONFIRMED • postcheck health failed • DO NOT RETRY automatically"
                        : "SAVE BLOCKED • precheck health failed • reconnect/re-auth required";
                sessionFault(saveHealthFailure);
            } else {
                postMessage("Health Gate ไม่ผ่าน — ยังไม่ส่งคำสั่งเสียง");
            }
            return;
        }

        try {
            BluetoothGatt active = gatt;
            if (active != null) active.requestConnectionPriority(BluetoothGatt.CONNECTION_PRIORITY_BALANCED);
        } catch (Exception ignored) {}

        if (saveActive && "SAVE_PRECHECK".equals(descriptorReason)) {
            publishDescriptorToUi(descriptorReason, eqCount);
            if (!eqShapeHealthGate) {
                dspReady = true;
                abortSaveWithoutRetry("SAVE BLOCKED • strict-safe PEQ " + safePeakingRows + "/55", true);
                return;
            }
            saveIntendedSnapshot = new VerifiedSnapshot(scalarValues, eqBands);
            dspReady = false;
            postStatus("กำลังตรวจสอบก่อนบันทึก", deviceName, false);
            postMessage("V49 SAVE PRECHECK PASS • S7/7 EQ105/105 sensors>=4 safe PEQ 55/55");
            waitForCleanSaveBoundary();
            return;
        }

        if (saveActive && "SAVE_POSTCHECK".equals(descriptorReason)) {
            publishDescriptorToUi(descriptorReason, eqCount);
            String mismatch = !eqShapeHealthGate ? "strict-safe PEQ " + safePeakingRows + "/55"
                    : (saveIntendedSnapshot == null ? "missing intended snapshot"
                    : saveIntendedSnapshot.firstMismatch(scalarValues, eqBands));
            saveWritePending = false;
            saveActive = false;
            saveIntendedSnapshot = null;
            cancelSaveTimers();
            dspReady = true;
            postStatus("เชื่อมต่อแล้ว", deviceName, true);
            startOriginalCommandScheduler();
            if (mismatch == null) {
                postMessage("SAVE VERIFIED • ID7 sent once • postcheck matches intended DSP state");
            } else {
                postMessage("SAVE UNCONFIRMED • " + mismatch + " • DO NOT RETRY automatically");
            }
            return;
        }

        dspReady = true;
        postStatus("เชื่อมต่อแล้ว", deviceName, true);
        publishDescriptorToUi(descriptorReason, eqCount);
        startOriginalCommandScheduler();
        postMessage(eqShapeHealthGate
                ? "V49 SYNCED • " + descriptorReason + " • S7/7 EQ105/105 • safe PEQ 55/55"
                : "V49 SYNCED • " + descriptorReason + " • safe PEQ " + safePeakingRows + "/55 • F/Q SAFE LOCK");
    }

    private DspProtocol.EqBand parseBand(JSONObject b) {
        if (b == null) return null;
        try {
            int type = b.optInt("typ", -1);
            float f = finiteFloat(b, "F");
            float f2 = finiteFloat(b, "F2");
            float q = finiteFloat(b, "Q");
            float boost = finiteFloat(b, "B");
            float gain = finiteFloat(b, "G");
            float r = finiteFloat(b, "R");
            float b0 = finiteFloat(b, "B0");
            float b1 = finiteFloat(b, "B1");
            float b2 = finiteFloat(b, "B2");
            float a1 = finiteFloat(b, "A1");
            float a2 = finiteFloat(b, "A2");
            if (!allFinite(f, f2, q, boost, gain, r, b0, b1, b2, a1, a2)) return null;
            return new DspProtocol.EqBand(type, f, f2, q, boost, gain, r, b0, b1, b2, a1, a2);
        } catch (RuntimeException e) {
            return null;
        }
    }

    private void publishDescriptorToUi(String source, int eqCount) {
        for (Map.Entry<Integer, Float> e : scalarValues.entrySet()) {
            final int id = e.getKey();
            final float value = e.getValue();
            post(() -> listener.onScalarValue(id, value));
        }

        // V15 exposes all 15 real Device-Description records per channel, 1:1.
        // No six-band nearest-frequency remap remains.
        for (int ch = 0; ch < 7; ch++) {
            for (int band0 = 0; band0 < DspProtocol.EQ_BANDS; band0++) {
                DspProtocol.EqBand b = eqBands[ch][band0];
                if (b == null) continue;
                final int fch = ch, fb = band0;
                final float ff = b.frequency, fg = b.graphicGainDb(), fq = b.q;
                final boolean gainWritable = isGainWritable(band0, b);
                final boolean shapeWritable = eqShapeHealthGate && isShapeWritable(band0, b);
                post(() -> listener.onEqValue(fch, fb, ff, fg, fq, gainWritable, shapeWritable));
            }
        }
        // V44 authoritative Out Volume readback. CH3 comes from BassVolume ID8; the
        // other six channels come from the first native EQ record's G cell-gain field.
        for (int ch = 0; ch < 7; ch++) {
            final int fch = ch;
            Float out = null;
            if (ch == 2) {
                out = scalarValues.get(DspProtocol.ID_BASS_VOLUME);
            } else {
                DspProtocol.EqBand first = eqBands[ch][0];
                if (first != null && first.outputGainWritable()) out = first.outputGainDb();
            }
            if (out != null && Float.isFinite(out)) {
                final float fout = out;
                post(() -> listener.onOutputVolumeValue(fch, fout));
            }
        }

        scalarTargets.clear();
        scalarTargets.putAll(scalarValues);

        final String syncSource = source == null ? "UNKNOWN" : source;
        final int scalarCount = scalarValues.size();
        final int publishedEqCount = eqCount;
        final int safeCount = safePeakingRows;
        // Posted after every scalar/EQ callback above; Handler FIFO ordering guarantees the UI
        // receives the complete authoritative snapshot before it checkpoints local state.
        post(() -> listener.onDspSyncComplete(syncSource, scalarCount, publishedEqCount, safeCount));
    }


    private void waitForCleanSaveBoundary() {
        saveBoundaryDeadlineUptimeMs = SystemClock.uptimeMillis() + SAVE_GUARD_TIMEOUT_MS;
        saveBoundaryWait = new Runnable() {
            @Override public void run() {
                if (!saveActive || saveIntendedSnapshot == null) return;
                boolean empty;
                synchronized (writeTickets) { empty = writeTickets.isEmpty(); }
                if (!liveWriteBusy && empty) {
                    saveBoundaryWait = null;
                    sendSaveParamsOnce();
                    return;
                }
                if (SystemClock.uptimeMillis() >= saveBoundaryDeadlineUptimeMs) {
                    sessionFault("SAVE boundary timeout • TX/GATT stream uncertain");
                    return;
                }
                main.postDelayed(this, EQ_BUSY_RETRY_MS);
            }
        };
        main.post(saveBoundaryWait);
    }

    private void sendSaveParamsOnce() {
        if (!saveActive || saveIntendedSnapshot == null || txCipher == null) return;
        boolean empty;
        synchronized (writeTickets) { empty = writeTickets.isEmpty(); }
        if (liveWriteBusy || !empty) {
            sessionFault("SAVE boundary changed before ID7");
            return;
        }
        final byte[] encrypted;
        try {
            encrypted = txCipher.next(DspProtocol.encodeSaveParamsTrigger());
        } catch (RuntimeException e) {
            sessionFault("SAVE ID7 TX encryption failed");
            return;
        }
        saveWritePending = true;
        postMessage("V49 SaveParams • ID7 trigger • one guarded write");
        if (!writeNoResponse(encrypted, "SAVE_PARAMS_ID7", null)) {
            saveWritePending = false;
            sessionFault("SAVE ID7 rejected by GATT");
            return;
        }
        if (saveWriteTimeout != null) main.removeCallbacks(saveWriteTimeout);
        saveWriteTimeout = () -> {
            if (!saveActive || !saveWritePending) return;
            sessionFault("SAVE ID7 callback timeout • TX stream uncertain");
        };
        main.postDelayed(saveWriteTimeout, SAVE_GUARD_TIMEOUT_MS);
    }

    private void handleSaveParamsWriteResult(int status) {
        if (!saveActive || !saveWritePending) return;
        if (saveWriteTimeout != null) main.removeCallbacks(saveWriteTimeout);
        saveWriteTimeout = null;
        saveWritePending = false;
        if (status != BluetoothGatt.GATT_SUCCESS) {
            sessionFault("SAVE ID7 GATT write failed " + status);
            return;
        }
        postMessage("V49 SaveParams accepted • starting fresh post-save readback");
        startDescriptorRequest("SAVE_POSTCHECK");
    }

    private void abortSaveWithoutRetry(String message, boolean resumeReadySession) {
        saveActive = false;
        saveWritePending = false;
        saveIntendedSnapshot = null;
        cancelSaveTimers();
        if (resumeReadySession) {
            dspReady = true;
            postStatus("เชื่อมต่อแล้ว", deviceName, true);
            startOriginalCommandScheduler();
        }
        postMessage(message);
    }

    private void cancelSaveTimers() {
        if (saveBoundaryWait != null) main.removeCallbacks(saveBoundaryWait);
        saveBoundaryWait = null;
        if (saveWriteTimeout != null) main.removeCallbacks(saveWriteTimeout);
        saveWriteTimeout = null;
    }

    private boolean isGainWritable(int band0, DspProtocol.EqBand b) {
        if (b == null) return false;
        if (b.safePeakingDescriptor()) return true;
        return band0 == 0 && b.writableFirstBandSpecial();
    }

    private boolean isShapeWritable(int band0, DspProtocol.EqBand b) {
        return band0 > 0 && b != null && b.safePeakingDescriptor();
    }

    private int channelForEqActuator(int id) {
        for (int ch = 0; ch < DspProtocol.EQ_ACTUATORS.length; ch++) if (DspProtocol.EQ_ACTUATORS[ch] == id) return ch;
        return -1;
    }

    private void enqueueLatest(PendingCommand c) {
        if (!dspReady || txCipher == null) return;
        pending.remove(c.key);
        pending.put(c.key, c);
    }

    /**
     * V32 EQ real-time lane. The UI may generate many MotionEvents, but only the newest
     * value for each band is retained. AB01 is still serialized through liveWriteBusy and
     * the same continuous CFB8 TX stream; this only removes the old 380 ms audible lag.
     */
    private void enqueueEqLatest(PendingCommand c) {
        if (!dspReady || txCipher == null) return;
        eqRealtimePending.remove(c.key);
        eqRealtimePending.put(c.key, c);
        scheduleEqRealtimePump(0L);
    }

    private void enqueueEqShapeLatest(EqShapeTarget c) {
        if (!dspReady || txCipher == null || !eqShapeHealthGate) return;
        eqShapePending.remove(c.key);
        eqShapePending.put(c.key, c);
        scheduleEqShapePump(0L);
    }

    /**
     * V44 release-only output lane. V44 hardware testing showed that even 1 dB / 45 ms
     * full-record Tone-Control rewrites produce repeated audible interruptions. Keep all MOVE
     * events local and send exactly one already-qualified 48-byte record after finger release.
     */
    private void scheduleOutputGainPump(long delayMs) {
        if (closed) return;
        if (outputGainPump == null) {
            outputGainPump = () -> {
                outputGainPumpPosted = false;
                if (closed || !dspReady || txCipher == null || readingDescriptor || saveActive) return;
                if (outputGainCommitRequested.isEmpty()) return;

                // Proven EQ edits/reset always win the single encrypted/GATT stream.
                if (eqResetActive || liveWriteBusy || !eqRealtimePending.isEmpty() || !eqShapePending.isEmpty()) {
                    if (!eqRealtimePending.isEmpty()) scheduleEqRealtimePump(0L);
                    else if (!eqShapePending.isEmpty()) scheduleEqShapePump(0L);
                    scheduleOutputGainPump(EQ_BUSY_RETRY_MS);
                    return;
                }

                long now = SystemClock.uptimeMillis();
                long wait = OUTPUT_GAIN_RELEASE_MIN_GAP_MS - (now - lastOutputGainWriteUptimeMs);
                if (wait > 0L) {
                    scheduleOutputGainPump(wait);
                    return;
                }

                Iterator<Integer> it = outputGainCommitRequested.iterator();
                int ch = it.next();
                it.remove();
                Float requestedObj = outputGainTargets.get(ch);
                if (requestedObj == null) {
                    if (!outputGainCommitRequested.isEmpty()) scheduleOutputGainPump(0L);
                    return;
                }
                float requested = requestedObj;
                DspProtocol.EqBand current = eqBands[ch][0];
                if (current == null || !current.outputGainWritable()) {
                    outputGainTargets.remove(ch);
                    if (!outputGainCommitRequested.isEmpty()) scheduleOutputGainPump(EQ_BUSY_RETRY_MS);
                    return;
                }
                if (Math.abs(requested - current.outputGainDb()) <= 0.001f) {
                    outputGainTargets.remove(ch);
                    if (!outputGainCommitRequested.isEmpty()) scheduleOutputGainPump(0L);
                    return;
                }

                try {
                    DspProtocol.EqBand target = DspProtocol.outputGainFromCurrent(current, requested);
                    lastOutputGainWriteUptimeMs = now;
                    sendScheduledControl(PendingCommand.output(ch, target));
                } catch (IllegalArgumentException ignored) {
                    outputGainTargets.remove(ch);
                    if (!outputGainCommitRequested.isEmpty()) scheduleOutputGainPump(EQ_BUSY_RETRY_MS);
                }
            };
        }
        if (outputGainPumpPosted) return;
        outputGainPumpPosted = true;
        main.postDelayed(outputGainPump, Math.max(0L, delayMs));
    }

    private void stopOutputGainPump() {
        if (outputGainPump != null) main.removeCallbacks(outputGainPump);
        outputGainPumpPosted = false;
        outputGainTargets.clear();
        outputGainCommitRequested.clear();
        lastOutputGainWriteUptimeMs = 0L;
    }

    private void scheduleEqRealtimePump(long delayMs) {
        if (closed) return;
        if (eqRealtimePump == null) {
            eqRealtimePump = () -> {
                eqRealtimePumpPosted = false;
                if (closed || !dspReady || txCipher == null) return;
                if (eqRealtimePending.isEmpty()) return;
                if (liveWriteBusy) {
                    scheduleEqRealtimePump(EQ_BUSY_RETRY_MS);
                    return;
                }

                long now = SystemClock.uptimeMillis();
                long minGap = eqResetActive ? EQ_RESET_MIN_GAP_MS : EQ_REALTIME_MIN_GAP_MS;
                long wait = minGap - (now - lastEqWriteUptimeMs);
                if (wait > 0L) {
                    scheduleEqRealtimePump(wait);
                    return;
                }

                Iterator<Map.Entry<String, PendingCommand>> it = eqRealtimePending.entrySet().iterator();
                PendingCommand next = it.next().getValue();
                it.remove();
                lastEqWriteUptimeMs = now;
                sendScheduledControl(next);
            };
        }
        if (eqRealtimePumpPosted) return;
        eqRealtimePumpPosted = true;
        main.postDelayed(eqRealtimePump, Math.max(0L, delayMs));
    }

    private void scheduleEqShapePump(long delayMs) {
        if (closed) return;
        if (eqShapePump == null) {
            eqShapePump = () -> {
                eqShapePumpPosted = false;
                if (closed || !dspReady || txCipher == null || !eqShapeHealthGate) return;
                if (eqShapePending.isEmpty()) return;
                // Gain retains priority because V32/V37 is the real-hardware stable lane.
                if (liveWriteBusy || !eqRealtimePending.isEmpty()) {
                    if (!eqRealtimePending.isEmpty()) scheduleEqRealtimePump(0L);
                    scheduleEqShapePump(EQ_BUSY_RETRY_MS);
                    return;
                }
                long now = SystemClock.uptimeMillis();
                long waitOwn = EQ_SHAPE_MIN_GAP_MS - (now - lastEqShapeWriteUptimeMs);
                long waitAfterAnyEq = EQ_SHAPE_MIN_GAP_MS - (now - lastEqWriteUptimeMs);
                long wait = Math.max(waitOwn, waitAfterAnyEq);
                if (wait > 0L) {
                    scheduleEqShapePump(wait);
                    return;
                }
                Iterator<Map.Entry<String, EqShapeTarget>> it = eqShapePending.entrySet().iterator();
                EqShapeTarget requested = it.next().getValue();
                it.remove();
                DspProtocol.EqBand current = eqBands[requested.channel0][requested.uiBand0];
                if (!isShapeWritable(requested.uiBand0, current)) {
                    if (!eqShapePending.isEmpty()) scheduleEqShapePump(EQ_BUSY_RETRY_MS);
                    return;
                }
                try {
                    // Build at send time, after all priority Gain writes have completed, so
                    // F/Q can never restore an older Gain or clamp a factory boost.
                    DspProtocol.EqBand target = DspProtocol.peakingShapeFromCurrent(
                            current, requested.frequency, requested.q);
                    lastEqShapeWriteUptimeMs = now;
                    // Also advance the shared EQ clock so the proven Gain lane cannot
                    // start in the same instant as a shape packet.
                    lastEqWriteUptimeMs = now;
                    sendScheduledControl(PendingCommand.eq(requested.channel0, requested.uiBand0,
                            requested.hwBand1, target));
                } catch (IllegalArgumentException ignored) {
                    if (!eqShapePending.isEmpty()) scheduleEqShapePump(EQ_BUSY_RETRY_MS);
                }
            };
        }
        if (eqShapePumpPosted) return;
        eqShapePumpPosted = true;
        main.postDelayed(eqShapePump, Math.max(0L, delayMs));
    }

    private void stopEqShapePump() {
        if (eqShapePump != null) main.removeCallbacks(eqShapePump);
        eqShapePumpPosted = false;
        eqShapePending.clear();
        lastEqShapeWriteUptimeMs = 0L;
    }

    private void stopEqRealtimePump() {
        if (eqRealtimePump != null) main.removeCallbacks(eqRealtimePump);
        eqRealtimePumpPosted = false;
        eqRealtimePending.clear();
        lastEqWriteUptimeMs = 0L;
    }

    private void startOriginalCommandScheduler() {
        stopOriginalCommandScheduler();
        trebleTarget = null;
        originalPollIndex = 0;
        originalCommandScheduler = new Runnable() {
            @Override public void run() {
                if (originalCommandScheduler != this || closed) return;
                if (dspReady && txCipher != null) originalCommandSchedulerTick();
                if (originalCommandScheduler == this && !closed) {
                    main.postDelayed(this, ORIGINAL_COMMAND_CADENCE_MS);
                }
            }
        };
        main.postDelayed(originalCommandScheduler, ORIGINAL_COMMAND_CADENCE_MS);
    }

    private void stopOriginalCommandScheduler() {
        if (originalCommandScheduler != null) main.removeCallbacks(originalCommandScheduler);
        originalCommandScheduler = null;
        originalPollIndex = 0;
    }

    private void originalCommandSchedulerTick() {
        if (!dspReady || txCipher == null || readingDescriptor || liveWriteBusy || saveActive || v55ReadProbeActive) return;
        // Keep the 2.6 s V45 proof window isolated from unrelated scalar/poll writes.
        if (v45ProbeActive || v45ProbeWritePending) return;

        // V32: while the user is actively moving EQ Gain, do not let a 380 ms sensor poll
        // or scalar slot jump ahead of the low-latency EQ queue.
        if (!eqRealtimePending.isEmpty() || !eqShapePending.isEmpty()) {
            if (!eqRealtimePending.isEmpty()) scheduleEqRealtimePump(0L);
            else scheduleEqShapePump(0L);
            return;
        }
        if (!outputGainCommitRequested.isEmpty()) {
            scheduleOutputGainPump(0L);
            return;
        }

        // V14 Treble safety: preserve the exact shared 380 ms command cadence, but never
        // send the raw ID11 target. Advance by at most 0.5 dB from the last successful live
        // value. A Treble step occupies the same single scheduler slot that a normal control
        // write would occupy; no extra high-rate stream is created.
        if (trebleTarget != null) {
            Float currentObj = scalarValues.get(DspProtocol.ID_TREBLE_BOOST);
            if (currentObj != null && Float.isFinite(currentObj)) {
                float diff = trebleTarget - currentObj;
                if (Math.abs(diff) <= 0.001f) {
                    trebleTarget = null;
                } else {
                    float step = Math.min(TREBLE_MAX_STEP_DB, Math.abs(diff));
                    float nextValue = currentObj + Math.copySign(step, diff);
                    nextValue = DspProtocol.sanitizeScalar(DspProtocol.ID_TREBLE_BOOST, nextValue);
                    if (!Float.isFinite(nextValue)) {
                        sessionFault("Treble target out of range");
                        return;
                    }
                    sendScheduledControl(PendingCommand.scalar(DspProtocol.ID_TREBLE_BOOST, nextValue));
                    return;
                }
            }
        }

        PendingCommand next = null;
        if (!pending.isEmpty()) {
            Iterator<Map.Entry<String, PendingCommand>> it = pending.entrySet().iterator();
            next = it.next().getValue();
            it.remove();
        }

        if (next != null) {
            sendScheduledControl(next);
            return;
        }

        // Exact poll cycle decrypted from the official app trace:
        // 58 + ID19 len1, ID20 len1, ID0 len4, ID21 len4, repeating.
        int idx = originalPollIndex % ORIGINAL_POLL_IDS.length;
        int id = ORIGINAL_POLL_IDS[idx];
        int len = ORIGINAL_POLL_LENGTHS[idx];
        originalPollIndex = (originalPollIndex + 1) % ORIGINAL_POLL_IDS.length;
        byte[] plain = DspProtocol.encodeRead(id, 0, len);
        final byte[] encrypted;
        try {
            encrypted = txCipher.next(plain);
        } catch (RuntimeException e) {
            sessionFault("TX poll encryption failed");
            return;
        }
        if (!writeNoResponse(encrypted, "POLL_" + id, null)) {
            sessionFault("BLE ไม่รับ sensor keepalive");
        }
    }

    private void sendScheduledControl(PendingCommand next) {
        final byte[] encrypted;
        try {
            encrypted = txCipher.next(next.plain);
        } catch (RuntimeException e) {
            sessionFault("TX encryption failed");
            return;
        }
        liveWriteBusy = true;
        liveInflight = next;
        if (!writeNoResponse(encrypted, "SCHEDULED_" + next.key, next)) {
            liveWriteBusy = false;
            liveInflight = null;
            sessionFault("BLE ไม่รับคำสั่ง DSP");
            return;
        }
        cancelLiveTimeout();
        final PendingCommand expected = next;
        liveWriteTimeout = () -> {
            if (!liveWriteBusy || liveInflight != expected) return;
            sessionFault("DSP command callback timeout");
        };
        main.postDelayed(liveWriteTimeout, LIVE_WRITE_TIMEOUT_MS);
    }

    private void handleWriteResult(WriteTicket ticket, int status) {
        if (ticket == null) return;
        if ("SAVE_PARAMS_ID7".equals(ticket.label)) {
            handleSaveParamsWriteResult(status);
            return;
        }
        if (ticket.command == null) {
            if (saveActive && status != BluetoothGatt.GATT_SUCCESS) {
                sessionFault("GATT write failed during save verification: " + ticket.label + " status=" + status);
            }
            return;
        }
        PendingCommand cmd = ticket.command;
        if (liveInflight != cmd) return;
        cancelLiveTimeout();
        liveWriteBusy = false;
        liveInflight = null;
        if (status != BluetoothGatt.GATT_SUCCESS) {
            sessionFault("GATT write failed " + status);
            return;
        }

        if ("V45P:TARGET".equals(cmd.key)) {
            v45ProbeWritePending = false;
            v45ProbeActive = true;
            postMessage("V45 CH1 probe ACTIVE • listen for click now • auto-restore in 2.6 s");
            scheduleV45ProbeAutoRestore(V45_PROBE_AUTO_RESTORE_MS);
        } else if ("V45P:RESTORE".equals(cmd.key)) {
            v45ProbeWritePending = false;
            v45ProbeActive = false;
            cancelV45ProbeAutoRestore();
            v45ProbeOriginal = null;
            postMessage("V45 CH1 probe RESTORED • original B0/B1/B2 returned • NOT SAVED");
        } else if (cmd.scalarId >= 0) {
            scalarValues.put(cmd.scalarId, cmd.scalarValue);
            if (cmd.scalarId == DspProtocol.ID_TREBLE_BOOST) {
                // Keep only the final target; the next <=0.5 dB step, if still needed, waits
                // for the next 380 ms scheduler slot. No callback-triggered immediate write.
                if (trebleTarget != null && Math.abs(trebleTarget - cmd.scalarValue) <= 0.001f) {
                    trebleTarget = null;
                }
                if (!eqRealtimePending.isEmpty()) scheduleEqRealtimePump(0L);
                else if (!eqShapePending.isEmpty()) scheduleEqShapePump(0L);
                return;
            }
        } else if (cmd.eqTarget != null && cmd.channel0 >= 0 && cmd.hwBand1 > 0) {
            eqBands[cmd.channel0][cmd.hwBand1 - 1] = cmd.eqTarget;
            if (cmd.key.startsWith("O:") && cmd.hwBand1 == 1) {
                Float requested = outputGainTargets.get(cmd.channel0);
                if (requested != null && Math.abs(requested - cmd.eqTarget.outputGainDb()) <= 0.001f) {
                    outputGainTargets.remove(cmd.channel0);
                }
                // If a first-band EQ touch arrived while this output packet was in flight,
                // rebuild that pending EQ record on top of the newly-confirmed G value.
                String eqKey = "E:" + cmd.channel0 + ":0";
                PendingCommand pendingBand1 = eqRealtimePending.get(eqKey);
                if (pendingBand1 != null && pendingBand1.eqTarget != null) {
                    try {
                        float desiredGraphicGain = pendingBand1.eqTarget.graphicGainDb();
                        DspProtocol.EqBand rebased = DspProtocol.firstBandGainFromCurrent(
                                eqBands[cmd.channel0][0], desiredGraphicGain);
                        eqRealtimePending.put(eqKey, PendingCommand.eq(cmd.channel0, 0, 1, rebased));
                    } catch (IllegalArgumentException ignored) {
                        eqRealtimePending.remove(eqKey);
                    }
                }
            }
            if (eqResetActive && cmd.channel0 == eqResetChannel) eqResetCompleted++;
        }

        if (eqResetActive && eqRealtimePending.isEmpty() && !liveWriteBusy) {
            int ch = eqResetChannel;
            int done = eqResetCompleted;
            int total = eqResetTotal;
            clearEqResetState();
            postMessage("Safe Reset EQ complete • CH" + (ch + 1) + " • " + done + "/" + total + " rows • F/Q unchanged");
        }
        // V32: if another EQ target arrived while this packet was in flight, send the
        // newest value as soon as the short real-time gap permits. Scalars/polls keep their
        // proven 380 ms cadence.
        if (!eqRealtimePending.isEmpty()) scheduleEqRealtimePump(0L);
        else if (!eqShapePending.isEmpty()) scheduleEqShapePump(0L);
        else if (!outputGainCommitRequested.isEmpty()) scheduleOutputGainPump(0L);
    }

    private boolean writeNoResponse(byte[] bytes, String label, PendingCommand liveCommand) {
        BluetoothGatt g = gatt;
        BluetoothGattCharacteristic ch = ab01;
        if (g == null || ch == null || !hasPermissions()) return false;
        WriteTicket ticket = new WriteTicket(label, liveCommand);
        synchronized (writeTickets) { writeTickets.addLast(ticket); }
        boolean ok = false;
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                ok = g.writeCharacteristic(ch, bytes, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE) == BluetoothStatusCodes.SUCCESS;
            } else {
                //noinspection deprecation
                ch.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE);
                //noinspection deprecation
                ch.setValue(bytes);
                //noinspection deprecation
                ok = g.writeCharacteristic(ch);
            }
        } catch (RuntimeException ignored) {
            ok = false;
        }
        if (!ok) {
            synchronized (writeTickets) {
                if (!writeTickets.isEmpty() && writeTickets.peekLast() == ticket) writeTickets.removeLast();
            }
        }
        return ok;
    }

    private void sessionFault(String reason) {
        dspReady = false;
        readingDescriptor = false;
        waitingAuth = false;
        pending.clear();
        stopOutputGainPump();
        stopEqRealtimePump();
        stopEqShapePump();
        eqShapeHealthGate = false;
        safePeakingRows = 0;
        clearEqResetState();
        saveActive = false;
        saveWritePending = false;
        saveIntendedSnapshot = null;
        cancelSaveTimers();
        liveWriteBusy = false;
        liveInflight = null;
        cancelDescriptorTimeout();
        cancelLiveTimeout();
        stopOriginalCommandScheduler();
        trebleTarget = null;
        scalarTargets.clear();
        clearV45ProbeState();
        postStatus("DSP session หยุด • กำลังเชื่อมใหม่", deviceName, false);
        postMessage(reason);
        // CFB8 is a continuous stream. Once ordering is uncertain, fail closed and
        // make a fresh GATT/auth session instead of trying to reuse any cipher state.
        txCipher = null;
        rxCipher = null;
        transportConnected = false;
        BluetoothGatt old = gatt;
        gatt = null;
        ab01 = null;
        ab02 = null;
        if (old != null) {
            try { old.disconnect(); } catch (RuntimeException ignored) {}
            try { old.close(); } catch (RuntimeException ignored) {}
        }
        if (!closed) main.postDelayed(this::startScan, 900L);
    }

    private void resetSessionState() {
        dspReady = false;
        waitingAuth = false;
        readingDescriptor = false;
        txCipher = null;
        rxCipher = null;
        descriptorExpected = -1;
        descriptorBytes.reset();
        scalarValues.clear();
        pending.clear();
        stopOutputGainPump();
        stopEqRealtimePump();
        stopEqShapePump();
        eqShapeHealthGate = false;
        safePeakingRows = 0;
        clearEqResetState();
        saveActive = false;
        saveWritePending = false;
        saveIntendedSnapshot = null;
        cancelSaveTimers();
        liveWriteBusy = false;
        liveInflight = null;
        synchronized (writeTickets) { writeTickets.clear(); }
        cancelDescriptorTimeout();
        cancelLiveTimeout();
        stopOriginalCommandScheduler();
        trebleTarget = null;
        scalarTargets.clear();
        clearV45ProbeState();
        cancelV55ReadProbeTimeout();
        v55ReadProbeActive = false;
        v55AwaitingReadId = -1;
        v55ReadProbeReport = null;
    }

    private void closeGattOnly() {
        BluetoothGatt old = gatt;
        gatt = null;
        ab01 = null;
        ab02 = null;
        if (old != null) try { old.close(); } catch (Exception ignored) {}
    }

    private void cancelDescriptorTimeout() {
        if (descriptorTimeout != null) main.removeCallbacks(descriptorTimeout);
        descriptorTimeout = null;
    }

    private void cancelLiveTimeout() {
        if (liveWriteTimeout != null) main.removeCallbacks(liveWriteTimeout);
        liveWriteTimeout = null;
    }

    private float finiteFloat(JSONObject o, String key) {
        double d = o.optDouble(key, Double.NaN);
        return Double.isFinite(d) ? (float) d : Float.NaN;
    }

    private boolean allFinite(float... values) {
        for (float v : values) if (!Float.isFinite(v)) return false;
        return true;
    }

    private void postStatus(String status, String name, boolean ready) {
        post(() -> listener.onBleStatus(status, name, ready));
    }

    private void postMessage(String message) {
        post(() -> listener.onBleMessage(message));
    }

    private void post(Runnable r) {
        if (Looper.myLooper() == Looper.getMainLooper()) r.run();
        else main.post(r);
    }
}
