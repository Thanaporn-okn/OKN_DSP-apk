# OKN DSP V91 — EQ Gain +/- + GitHub Actions Android SDK Fix (Base V41)

V91 retains the V90/V89 EQ Band Gain `- / +` controls for CH1–CH7. Each press changes only the selected EQ band Gain by 0.5 dB through the existing verified realtime EQ writer, and only when BLE is READY and DSP readback marks that row gain-writable.

Safety remains unchanged: no invented actuator ID, no channel-output-volume mapping, no automatic SaveParams, and no unknown DSP write.

V91 fixes the GitHub Actions failure seen on current hosted runners. The workflow no longer uses `android-actions/setup-android`, which attempted to install the retired SDK package `tools`. Instead it validates and uses the Android SDK already present on `ubuntu-latest`, then installs only `platform-tools`, `platforms;android-35`, and `build-tools;35.0.0`. GitHub actions used by the workflow are also advanced to Node 24-compatible major versions.
