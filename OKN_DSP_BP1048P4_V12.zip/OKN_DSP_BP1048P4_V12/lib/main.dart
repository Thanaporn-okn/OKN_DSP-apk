
import 'package:flutter/material.dart';

void main(){
  runApp(const OKNV12());
}

class OKNV12 extends StatelessWidget{
  const OKNV12({super.key});

  @override
  Widget build(BuildContext context){
    return MaterialApp(
      debugShowCheckedModeBanner:false,
      theme:ThemeData.dark(),
      home:const DSPHome(),
    );
  }
}

class DSPHome extends StatefulWidget{
  const DSPHome({super.key});
  @override
  State<DSPHome> createState()=>_DSPHomeState();
}

class _DSPHomeState extends State<DSPHome>{
  double volume=50;
  List<double> eq=List.filled(15,0);
  String log="TX/RX LOG";

  void send(String data){
    setState(()=>log+="\nTX: $data");
  }

  @override
  Widget build(BuildContext context){
    return Scaffold(
      backgroundColor:const Color(0xff111017),
      appBar:AppBar(title:const Text("OKN_DSP BP1048P4 V12")),
      body:SingleChildScrollView(
        padding:const EdgeInsets.all(16),
        child:Column(
          children:[
            Text("Volume ${volume.toInt()}"),
            Slider(
              value:volume,
              min:0,max:100,
              onChanged:(v)=>setState(()=>volume=v),
            ),
            ElevatedButton(
              onPressed:()=>send("AA 55 VOL CH1 ${volume.toInt()}"),
              child:const Text("SEND VOLUME"),
            ),
            const Text("15 Band EQ"),
            ...List.generate(15,(i)=>Slider(
              value:eq[i],
              min:-12,max:12,
              onChanged:(v)=>setState(()=>eq[i]=v),
            )),
            ElevatedButton(
              onPressed:()=>send("AA 55 EQ CH1 15BAND"),
              child:const Text("SEND EQ"),
            ),
            ElevatedButton(
              onPressed:()=>send("AA 55 CROSSOVER HPF LPF"),
              child:const Text("SEND HPF/LPF"),
            ),
            Text(log)
          ],
        ),
      ),
    );
  }
}
