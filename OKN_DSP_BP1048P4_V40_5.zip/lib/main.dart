import 'package:flutter/material.dart';

void main()=>runApp(const App());

class App extends StatelessWidget{
 const App({super.key});

 @override
 Widget build(BuildContext context){
  return MaterialApp(
   debugShowCheckedModeBanner:false,
   theme:ThemeData.dark(),
   home:Scaffold(
    appBar:AppBar(title:const Text('OKN_DSP BP1048P4 V40.5')),
    body:const Padding(
     padding:EdgeInsets.all(20),
     child:Column(
      crossAxisAlignment:CrossAxisAlignment.start,
      children:[
       Text('BUILD ID: V40.5',
       style:TextStyle(fontSize:28,color:Colors.cyan)),
       Text('OKN DSP CONTROLLER'),
       SizedBox(height:20),
       Text('Bluetooth Scanner'),
       Text('Connect / Disconnect'),
       Text('CH1 - CH7 Mixer'),
       Text('Volume Control'),
       Text('15 Band EQ'),
       Text('Delay'),
       Text('HPF / LPF'),
       Text('BP1048P4 Packet'),
       Text('TX RX Monitor'),
      ],
     ),
    ),
   ),
  );
 }
}
