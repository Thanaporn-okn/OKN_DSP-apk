import 'package:flutter/material.dart';

void main() {
  runApp(const OKNDSPApp());
}

class OKNDSPApp extends StatelessWidget {
  const OKNDSPApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'OKN DSP BP1048P4 V40.5',
      theme: ThemeData.dark(),
      home: const Home(),
    );
  }
}

class Home extends StatelessWidget {
  const Home({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('OKN_DSP BP1048P4 V40.5'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: const [
          Text('Bluetooth DSP Controller',
              style: TextStyle(fontSize: 24)),
          SizedBox(height: 25),
          Text('Device Scan'),
          Text('Connect Device'),
          Text('MAC / Name'),
          Text('TX BP1048P4 Packet'),
          Text('RX Response Parser'),
          Text('HEX Monitor'),
          Text('Volume Control'),
          Text('7 Channel EQ'),
          Text('Delay'),
          Text('HPF / LPF Control'),
        ],
      ),
    );
  }
}