package com.okn.dsp
import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.widget.*

class MainActivity:Activity(){
 override fun onCreate(b:Bundle?){
  super.onCreate(b)
  val root=LinearLayout(this)
  root.orientation=LinearLayout.VERTICAL
  root.setPadding(20,20,20,20)
  root.setBackgroundColor(Color.BLACK)

  val head=TextView(this)
  head.text="🔵 Connected\nBP1048P4 7CH DSP\nFW:1.2.6\n\nMaster Volume"
  head.textSize=22f
  head.setTextColor(Color.WHITE)
  root.addView(head)

  val names=arrayOf("Front L","Front R","SUB","Rear L","Rear R","AUX L","AUX R")
  for(i in 0..6){
   val card=TextView(this)
   card.text="CH${i+1}  ${names[i]}"
   card.textSize=20f
   card.setTextColor(Color.WHITE)
   root.addView(card)

   val db=TextView(this)
   db.text="-0.0 dB"
   db.setTextColor(Color.CYAN)
   root.addView(db)

   val bar=SeekBar(this)
   root.addView(bar)

   val mute=Button(this)
   mute.text="MUTE"
   root.addView(mute)
  }

  val nav=TextView(this)
  nav.text="MAIN    EQ    CROSSOVER    DELAY    MIXER    PRESET    SETTINGS"
  nav.textSize=16f
  nav.setTextColor(Color.WHITE)
  root.addView(nav)

  setContentView(root)
 }
}