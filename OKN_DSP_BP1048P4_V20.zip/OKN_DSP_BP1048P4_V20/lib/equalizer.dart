// 15 Band EQ Control V20
