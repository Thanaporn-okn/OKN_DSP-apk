#ifndef OKN_RUNTIME_H
#define OKN_RUNTIME_H

#include "../core/okn_controller.h"
#include "../hal/bp1048p4_hal.h"

/* Apply only dirty state. A failed write remains dirty so callers can fail closed
 * or retry only after transport/platform health is re-established. */
okn_status_t okn_runtime_apply_dirty(okn_controller_t *ctl, const bp1048p4_hal_t *hal);

#endif
