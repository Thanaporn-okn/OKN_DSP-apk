#include "okn_runtime.h"

okn_status_t okn_runtime_apply_dirty(okn_controller_t *ctl, const bp1048p4_hal_t *hal) {
    if (!ctl || !hal || !hal->apply_master_gain || !hal->apply_channel_state) return OKN_ERR_ARG;
    if (okn_validate_state(&ctl->state) != OKN_OK) return OKN_ERR_RANGE;

    if (ctl->master_dirty) {
        const int rc = hal->apply_master_gain(ctl->state.master_gain_db);
        if (rc != OKN_OK) return rc == OKN_ERR_HAL_LOCKED ? OKN_ERR_HAL_LOCKED : OKN_ERR_HAL;
        ctl->master_dirty = false;
    }

    for (unsigned c = 0; c < OKN_CHANNELS; ++c) {
        const uint8_t bit = (uint8_t)(1u << c);
        if ((ctl->channel_dirty_mask & bit) == 0u) continue;
        const int rc = hal->apply_channel_state(c, &ctl->state.ch[c]);
        if (rc != OKN_OK) return rc == OKN_ERR_HAL_LOCKED ? OKN_ERR_HAL_LOCKED : OKN_ERR_HAL;
        ctl->channel_dirty_mask &= (uint8_t)~bit;
    }
    return OKN_OK;
}
