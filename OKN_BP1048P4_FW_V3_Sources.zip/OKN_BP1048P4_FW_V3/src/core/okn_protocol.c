#include "okn_protocol.h"
#include <string.h>

static float read_f32_le(const uint8_t *p) {
    uint32_t u = ((uint32_t)p[0]) | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
    float f;
    memcpy(&f, &u, sizeof(f));
    return f;
}

static void write_u16_le(uint8_t *p, uint16_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); }
static void write_u32_le(uint8_t *p, uint32_t v) {
    p[0]=(uint8_t)v; p[1]=(uint8_t)(v>>8); p[2]=(uint8_t)(v>>16); p[3]=(uint8_t)(v>>24);
}

uint16_t okn_crc16_ccitt(const uint8_t *data, size_t len) {
    uint16_t crc = 0xFFFFu;
    for (size_t i = 0; i < len; ++i) {
        crc ^= (uint16_t)data[i] << 8;
        for (unsigned b = 0; b < 8; ++b)
            crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
    }
    return crc;
}

static okn_status_t validate_packet(const uint8_t *p, size_t len, uint8_t *cmd, uint16_t *plen) {
    if (!p || !cmd || !plen || len < 8u) return OKN_ERR_ARG;
    if (p[0] != OKN_PROTO_MAGIC0 || p[1] != OKN_PROTO_MAGIC1 || p[2] != OKN_PROTO_VERSION) return OKN_ERR_FORMAT;
    *cmd = p[3];
    *plen = (uint16_t)p[4] | ((uint16_t)p[5] << 8);
    if (*plen > OKN_PROTO_MAX_PAYLOAD || len != (size_t)(6u + *plen + 2u)) return OKN_ERR_FORMAT;
    const uint16_t got_crc = (uint16_t)p[len - 2] | ((uint16_t)p[len - 1] << 8);
    return okn_crc16_ccitt(p, len - 2u) == got_crc ? OKN_OK : OKN_ERR_CRC;
}

static okn_status_t make_packet(uint8_t cmd, const uint8_t *payload, uint16_t plen,
                                uint8_t *out, size_t cap, size_t *out_len) {
    if (!out || !out_len || (plen && !payload)) return OKN_ERR_ARG;
    const size_t n = (size_t)plen + 8u;
    if (cap < n || plen > OKN_PROTO_MAX_PAYLOAD) return OKN_ERR_BUFFER;
    out[0]=OKN_PROTO_MAGIC0; out[1]=OKN_PROTO_MAGIC1; out[2]=OKN_PROTO_VERSION; out[3]=cmd;
    write_u16_le(&out[4], plen);
    if (plen) memcpy(&out[6], payload, plen);
    const uint16_t crc = okn_crc16_ccitt(out, 6u + plen);
    write_u16_le(&out[6u + plen], crc);
    *out_len = n;
    return OKN_OK;
}

static okn_status_t mutate(okn_controller_t *ctl, uint8_t cmd, const uint8_t *d, uint16_t plen) {
    okn_status_t rc;
    unsigned ch;
    if (!ctl) return OKN_ERR_ARG;
    switch (cmd) {
        case OKN_CMD_SET_MASTER_GAIN:
            if (plen != 4u) return OKN_ERR_FORMAT;
            rc = okn_set_master_gain(&ctl->state, read_f32_le(d));
            if (rc == OKN_OK) okn_controller_touch_master(ctl);
            return rc;
        case OKN_CMD_SET_CH_GAIN:
            if (plen != 5u) return OKN_ERR_FORMAT;
            ch = d[0]; rc = okn_set_channel_gain(&ctl->state, ch, read_f32_le(&d[1]));
            if (rc == OKN_OK) okn_controller_touch_channel(ctl, ch);
            return rc;
        case OKN_CMD_SET_CH_MUTE:
            if (plen != 2u || d[1] > 1u) return OKN_ERR_FORMAT;
            ch = d[0]; rc = okn_set_channel_mute(&ctl->state, ch, d[1] != 0u);
            if (rc == OKN_OK) okn_controller_touch_channel(ctl, ch);
            return rc;
        case OKN_CMD_SET_CH_PHASE:
            if (plen != 2u || d[1] > 1u) return OKN_ERR_FORMAT;
            ch = d[0]; rc = okn_set_channel_phase(&ctl->state, ch, d[1] != 0u);
            if (rc == OKN_OK) okn_controller_touch_channel(ctl, ch);
            return rc;
        case OKN_CMD_SET_CH_DELAY:
            if (plen != 5u) return OKN_ERR_FORMAT;
            ch = d[0]; rc = okn_set_channel_delay(&ctl->state, ch, read_f32_le(&d[1]));
            if (rc == OKN_OK) okn_controller_touch_channel(ctl, ch);
            return rc;
        case OKN_CMD_SET_PEQ:
            if (plen != 16u || d[2] > 1u) return OKN_ERR_FORMAT;
            ch = d[0];
            rc = okn_set_peq_band(&ctl->state, ch, d[1], d[2] != 0u, (okn_filter_type_t)d[3],
                                  read_f32_le(&d[4]), read_f32_le(&d[8]), read_f32_le(&d[12]));
            if (rc == OKN_OK) okn_controller_touch_channel(ctl, ch);
            return rc;
        case OKN_CMD_SET_HPF:
        case OKN_CMD_SET_LPF:
            if (plen != 10u || d[1] > 1u) return OKN_ERR_FORMAT;
            ch = d[0];
            rc = (cmd == OKN_CMD_SET_HPF)
                ? okn_set_hpf(&ctl->state, ch, d[1] != 0u, read_f32_le(&d[2]), read_f32_le(&d[6]))
                : okn_set_lpf(&ctl->state, ch, d[1] != 0u, read_f32_le(&d[2]), read_f32_le(&d[6]));
            if (rc == OKN_OK) okn_controller_touch_channel(ctl, ch);
            return rc;
        default:
            return OKN_ERR_UNSUPPORTED;
    }
}

okn_status_t okn_protocol_apply(okn_controller_t *ctl, const uint8_t *p, size_t len) {
    uint8_t cmd=0u; uint16_t plen=0u;
    const okn_status_t valid = validate_packet(p, len, &cmd, &plen);
    if (valid != OKN_OK) return valid;
    if (cmd == OKN_CMD_PING) return plen == 0u ? OKN_OK : OKN_ERR_FORMAT;
    if (cmd == OKN_CMD_GET_INFO) return plen == 0u ? OKN_OK : OKN_ERR_FORMAT;
    return mutate(ctl, cmd, &p[6], plen);
}

okn_status_t okn_protocol_execute(okn_controller_t *ctl, const uint8_t *p, size_t len,
                                  uint8_t *response, size_t cap, size_t *response_len) {
    uint8_t cmd=0u; uint16_t plen=0u;
    if (!ctl || !response || !response_len) return OKN_ERR_ARG;
    *response_len = 0u;
    okn_status_t rc = validate_packet(p, len, &cmd, &plen);
    if (rc != OKN_OK) return rc;

    if (cmd == OKN_CMD_GET_INFO) {
        if (plen != 0u) return OKN_ERR_FORMAT;
        uint8_t info[10];
        write_u16_le(&info[0], OKN_FW_VERSION);
        info[2] = OKN_PROTO_VERSION;
        info[3] = (uint8_t)OKN_CHANNELS;
        info[4] = (uint8_t)OKN_PEQ_BANDS;
        info[5] = 0u; /* hardware-ready flag: 0 until authentic HAL is integrated */
        write_u32_le(&info[6], ctl->revision);
        return make_packet(OKN_CMD_INFO, info, sizeof(info), response, cap, response_len);
    }

    rc = okn_protocol_apply(ctl, p, len);
    uint8_t ack[7];
    ack[0] = cmd;
    write_u16_le(&ack[1], (uint16_t)(int16_t)rc);
    write_u32_le(&ack[3], ctl->revision);
    const okn_status_t enc = make_packet(OKN_CMD_ACK, ack, sizeof(ack), response, cap, response_len);
    return enc == OKN_OK ? rc : enc;
}
