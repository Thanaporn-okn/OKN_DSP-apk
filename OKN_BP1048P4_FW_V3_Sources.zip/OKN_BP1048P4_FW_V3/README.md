# OKN_BP1048P4_FW_V3

Clean-room replacement firmware foundation for the GoloPine/BP1048P4 7-channel DSP project.

V3 adds an **OKN-native portable reference audio engine** so the actual signal-processing behavior can be tested before a verified BP1048P4 SDK/HAL exists. V3 is intentionally **NOT hardware-flashable** and contains no guessed BP1048P4 registers, flash addresses, boot packets, GPIO numbers or undocumented vendor calls.

## V3 additions
- RBJ-style floating-point biquad coefficient generator
- PEQ / notch / low-shelf / high-shelf reference processing
- 2nd-order HPF / LPF reference processing
- per-channel gain / mute / phase processing
- per-channel 0-50 ms reference delay line
- 7 independent reference processing lanes
- separate audio-engine unit test suite
- stability/finite-output checks
- firmware version 3 while keeping OKN protocol version 2 packet compatibility

## Important scope
The reference engine defines **our replacement firmware DSP semantics**. It is not a claim about GoloPine's original coefficient format, BP1048P4 internal DSP blocks, sample routing, memory map, or SDK API. Final board I/O routing and optimized DSP integration remain locked behind the HAL until verified vendor/board evidence exists.

## Validation
```sh
make verify
make test
make demo
```

## Hardware policy
`src/hal/bp1048p4_hal_stub.c` remains fail-closed. Replace it only from verified BP1048P4 SDK / board evidence.
