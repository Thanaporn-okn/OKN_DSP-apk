# BP1048P4 hardware port status — V2

V2 deliberately remains non-flashable.

## Completed before hardware port
- 7 independent output channels
- master + per-channel gain/mute/phase/delay model
- 15 PEQ bands per channel
- HPF / LPF model
- range and finite-number validation
- versioned CRC-framed BLE-ready protocol
- ACK / INFO responses
- revision counter + per-channel dirty tracking
- transactional dirty apply abstraction
- fail-closed HAL

## Hard gate
Do not add startup code, linker script, memory map, debug pins, flash algorithm,
BLE stack calls, DSP effect IDs, pin mux, codec route or clock configuration from guesses.
The hardware port opens only when authentic BP1048P4 SDK/example headers or equivalent
board evidence is available.
