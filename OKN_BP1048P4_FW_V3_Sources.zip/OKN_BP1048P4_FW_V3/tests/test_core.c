#include "../src/core/okn_controller.h"
#include "../src/core/okn_protocol.h"
#include "../src/runtime/okn_runtime.h"
#include <assert.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

static void write_f32_le(uint8_t *p, float f) {
    uint32_t u; memcpy(&u, &f, sizeof(u));
    p[0]=(uint8_t)u; p[1]=(uint8_t)(u>>8); p[2]=(uint8_t)(u>>16); p[3]=(uint8_t)(u>>24);
}
static size_t finish_pkt(uint8_t *p, uint8_t cmd, uint16_t plen) {
    p[0]='O'; p[1]='K'; p[2]=OKN_PROTO_VERSION; p[3]=cmd; p[4]=(uint8_t)plen; p[5]=(uint8_t)(plen>>8);
    uint16_t crc=okn_crc16_ccitt(p, 6u+plen); p[6u+plen]=(uint8_t)crc; p[7u+plen]=(uint8_t)(crc>>8); return 8u+plen;
}
static size_t make_set_gain(uint8_t *p, uint8_t ch, float db) {
    p[6]=ch; write_f32_le(&p[7], db); return finish_pkt(p, OKN_CMD_SET_CH_GAIN, 5u);
}
static size_t make_set_peq(uint8_t *p, uint8_t ch, uint8_t band, float hz, float gain, float q) {
    p[6]=ch; p[7]=band; p[8]=1; p[9]=OKN_FILTER_PEQ;
    write_f32_le(&p[10],hz); write_f32_le(&p[14],gain); write_f32_le(&p[18],q);
    return finish_pkt(p, OKN_CMD_SET_PEQ, 16u);
}

static unsigned mock_master_calls, mock_channel_calls;
static int mock_init(void){return OKN_OK;} static int mock_audio(void){return OKN_OK;}
static int mock_master(float db){(void)db; ++mock_master_calls; return OKN_OK;}
static int mock_channel(unsigned ch,const okn_channel_state_t *s){(void)ch;(void)s;++mock_channel_calls;return OKN_OK;}
static int mock_notify(const uint8_t *p,size_t n){(void)p;(void)n;return OKN_OK;}
static const bp1048p4_hal_t MOCK_HAL={mock_init,mock_audio,mock_master,mock_channel,mock_notify};

int main(void) {
    okn_controller_t ctl; okn_controller_init(&ctl);
    assert(OKN_CHANNELS==7u && OKN_PEQ_BANDS==15u);
    assert(okn_validate_state(&ctl.state)==OKN_OK);
    assert(okn_crc16_ccitt((const uint8_t*)"123456789",9)==0x29B1u);

    assert(okn_set_channel_gain(&ctl.state,0,-6.0f)==OKN_OK);
    assert(okn_set_channel_gain(&ctl.state,7,-6.0f)==OKN_ERR_ARG);
    assert(okn_set_channel_delay(&ctl.state,6,50.0f)==OKN_OK);
    assert(okn_set_channel_delay(&ctl.state,6,50.1f)==OKN_ERR_RANGE);
    assert(okn_set_peq_band(&ctl.state,0,14,true,OKN_FILTER_PEQ,1000.0f,3.0f,1.2f)==OKN_OK);
    assert(okn_set_peq_band(&ctl.state,0,15,true,OKN_FILTER_PEQ,1000.0f,3.0f,1.2f)==OKN_ERR_ARG);
    assert(okn_set_hpf(&ctl.state,0,true,80.0f,0.707f)==OKN_OK);
    assert(okn_set_lpf(&ctl.state,0,true,18000.0f,0.707f)==OKN_OK);

    uint8_t pkt[128], rsp[160]; size_t n,rn=0;
    n=make_set_gain(pkt,2,-9.5f);
    uint32_t rev0=ctl.revision;
    assert(okn_protocol_execute(&ctl,pkt,n,rsp,sizeof(rsp),&rn)==OKN_OK);
    assert(fabsf(ctl.state.ch[2].gain_db+9.5f)<0.0001f);
    assert(ctl.revision==rev0+1u && (ctl.channel_dirty_mask&(1u<<2))!=0u);
    assert(rn>8u && rsp[3]==OKN_CMD_ACK);

    n=make_set_peq(pkt,3,5,1250.0f,-2.5f,1.1f);
    assert(okn_protocol_apply(&ctl,pkt,n)==OKN_OK);
    assert(fabsf(ctl.state.ch[3].peq[5].freq_hz-1250.0f)<0.01f);

    /* Bad CRC must not mutate state/revision. */
    n=make_set_gain(pkt,1,-4.0f); rev0=ctl.revision; pkt[n-1]^=1u;
    assert(okn_protocol_apply(&ctl,pkt,n)==OKN_ERR_CRC && ctl.revision==rev0);

    /* GET_INFO explicitly reports hardware_ready=0 in V3. */
    n=finish_pkt(pkt,OKN_CMD_GET_INFO,0u);
    assert(okn_protocol_execute(&ctl,pkt,n,rsp,sizeof(rsp),&rn)==OKN_OK);
    assert(rsp[3]==OKN_CMD_INFO && rsp[6+5]==0u);

    /* Dirty apply is transactional per item: successful items clear. */
    okn_controller_mark_all_dirty(&ctl); mock_master_calls=mock_channel_calls=0;
    assert(okn_runtime_apply_dirty(&ctl,&MOCK_HAL)==OKN_OK);
    assert(!ctl.master_dirty && ctl.channel_dirty_mask==0u);
    assert(mock_master_calls==1u && mock_channel_calls==7u);

    okn_controller_mark_all_dirty(&ctl);
    assert(okn_runtime_apply_dirty(&ctl,bp1048p4_hal_get())==OKN_ERR_HAL_LOCKED);
    assert(ctl.master_dirty); /* fail closed; nothing is silently considered applied */

    ctl.state.ch[0].mute=true;
    assert(okn_effective_channel_linear_gain(&ctl.state,0)==0.0f);
    puts("ALL V3 CORE TESTS PASS");
    return 0;
}
