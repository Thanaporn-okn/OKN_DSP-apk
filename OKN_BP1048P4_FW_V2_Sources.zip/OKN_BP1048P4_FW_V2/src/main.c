#include "core/okn_controller.h"
#include "runtime/okn_runtime.h"
#include <stdio.h>

int main(void) {
    okn_controller_t ctl;
    okn_controller_init(&ctl);
    okn_set_channel_gain(&ctl.state, 0, -3.0f);
    okn_controller_touch_channel(&ctl, 0);
    okn_set_peq_band(&ctl.state, 0, 0, true, OKN_FILTER_PEQ, 1000.0f, 2.0f, 1.0f);
    okn_controller_touch_channel(&ctl, 0);
    printf("OKN_BP1048P4_FW_V2 host demo\n");
    printf("CH1 effective gain = %.6f\n", okn_effective_channel_linear_gain(&ctl.state, 0));
    printf("revision=%u dirtyMask=0x%02X\n", (unsigned)ctl.revision, ctl.channel_dirty_mask);
    printf("HAL apply status = %d (expected locked until authentic BP1048P4 SDK port)\n",
           okn_runtime_apply_dirty(&ctl, bp1048p4_hal_get()));
    return 0;
}
