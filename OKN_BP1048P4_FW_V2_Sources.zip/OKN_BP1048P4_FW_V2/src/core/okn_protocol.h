#ifndef OKN_PROTOCOL_H
#define OKN_PROTOCOL_H

#include "okn_controller.h"
#include <stddef.h>
#include <stdint.h>

#define OKN_PROTO_MAGIC0 0x4Fu /* O */
#define OKN_PROTO_MAGIC1 0x4Bu /* K */
#define OKN_PROTO_VERSION 0x02u
#define OKN_PROTO_MAX_PAYLOAD 128u
#define OKN_FW_VERSION 2u

typedef enum {
    OKN_CMD_PING = 0x01,
    OKN_CMD_GET_INFO = 0x02,
    OKN_CMD_SET_MASTER_GAIN = 0x10,
    OKN_CMD_SET_CH_GAIN = 0x11,
    OKN_CMD_SET_CH_MUTE = 0x12,
    OKN_CMD_SET_CH_PHASE = 0x13,
    OKN_CMD_SET_CH_DELAY = 0x14,
    OKN_CMD_SET_PEQ = 0x20,
    OKN_CMD_SET_HPF = 0x21,
    OKN_CMD_SET_LPF = 0x22,
    OKN_CMD_ACK = 0x7E,
    OKN_CMD_INFO = 0x7F
} okn_command_t;

uint16_t okn_crc16_ccitt(const uint8_t *data, size_t len);
okn_status_t okn_protocol_apply(okn_controller_t *ctl, const uint8_t *packet, size_t len);
okn_status_t okn_protocol_execute(okn_controller_t *ctl, const uint8_t *packet, size_t len,
                                  uint8_t *response, size_t response_cap, size_t *response_len);

#endif
