# OKN_BP1048P4_FW_V2

Clean-room replacement firmware foundation for the GoloPine/BP1048P4 7-channel DSP project.

V2 advances the portable firmware core but intentionally remains **NOT hardware-flashable**.
There are no guessed BP1048P4 registers, boot packets, flash addresses, GPIO numbers or vendor calls.

## V2 additions
- 15-band PEQ setters for each of 7 channels
- HPF/LPF state setters
- NaN/Inf and range rejection
- controller revision counter
- master/per-channel dirty tracking
- transactional `apply_dirty()` hardware boundary
- OKN protocol V2 with SET_PEQ / SET_HPF / SET_LPF
- ACK and GET_INFO/INFO responses
- hardware-ready flag remains false
- expanded unit and CRC vector tests

## Validation
```sh
make verify
make test
make demo
```

## Hardware policy
`src/hal/bp1048p4_hal_stub.c` remains fail-closed. Replace it only from verified BP1048P4 SDK / board evidence.
