OKN_DSP V0.8.0 UI REAL
Phase 3.2 UI Upgrade
- DSP dark theme
- 7 channel layout base
- Ready for GitHub Actions build
