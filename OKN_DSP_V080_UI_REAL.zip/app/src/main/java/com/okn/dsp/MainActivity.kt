package com.okn.dsp

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.widget.*

class MainActivity: Activity(){
 override fun onCreate(savedInstanceState:Bundle?){
  super.onCreate(savedInstanceState)

  val root=LinearLayout(this)
  root.orientation=LinearLayout.VERTICAL
  root.setPadding(12,12,12,12)
  root.setBackgroundColor(Color.BLACK)

  fun add(text:String){
   val t=TextView(this)
   t.text=text
   t.textSize=18f
   t.setTextColor(Color.WHITE)
   t.setPadding(8,8,8,8)
   root.addView(t)
  }

  add("🔵 Connected")
  add("BP1048P4 7CH DSP   FW:1.2.6")
  add("MASTER VOLUME")

  val volume=SeekBar(this)
  volume.max=60
  volume.progress=35
  root.addView(volume)

  val ch=arrayOf(
   "CH1 Front L",
   "CH2 Front R",
   "CH3 SUB",
   "CH4 Rear L",
   "CH5 Rear R",
   "CH6 AUX L",
   "CH7 AUX R"
  )

  for(x in ch){
   val box=LinearLayout(this)
   box.orientation=LinearLayout.VERTICAL
   box.setBackgroundColor(Color.rgb(25,25,25))
   add(x)
   val f=SeekBar(this)
   f.max=66
   f.progress=30
   root.addView(f)
   val b=Button(this)
   b.text="MUTE"
   root.addView(b)
  }

  add("MAIN   EQ   CROSSOVER   DELAY   MIXER   PRESET   SETTINGS")
  setContentView(root)
 }
}
