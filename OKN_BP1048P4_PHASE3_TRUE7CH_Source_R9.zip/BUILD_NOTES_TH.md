# R9 build notes

ผล R8 บนบอร์ดจริง:
- exact target 6324:1719 = PASS
- IF4 report descriptor = PASS
- IF4 Feature `00 01 00 03 04 00 08 00` = PASS
- IF3 EP81 IN/interrupt/max64 topology = PASS
- IF3 HID report descriptor without claim = -1
- IF3 GET_REPORT without claim = -1 ทั้งก่อน/หลัง query
- IF4 SET_REPORT 256 bytes = success
- IF4 GET_REPORT INPUT หลัง query = 0 bytes

ข้อสรุป: Android kernel HID driver เป็นตัวกั้น raw IF3 access ที่ชัดเจน. R9 จึงทดสอบ temporary `claimInterface(IF3,true)` เพียง interface เดียว แล้วฟัง EP81 ด้วย `UsbRequest` ซึ่งเป็น IN-only. Query เดิมไม่เปลี่ยนและมีได้มากที่สุดหนึ่งครั้งต่อการกด.
