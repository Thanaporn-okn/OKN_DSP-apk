# OKN BP1048P4 Phase3 TRUE7CH — R9

R9 เป็น diagnostic probe สำหรับบอร์ดจริง JMDSTECH / DSTech DSP ComboDigitalArchitect VID:PID `6324:1719` ต่อจากผล R8 ที่ยืนยันว่า IF3 ถูก Android kernel HID driver จับอยู่: no-claim HID descriptor/GET_REPORT ได้ `-1` และ R7 `claim(force=false)` ล้มเหลว.

## จุดประสงค์
ทดสอบเพียงสมมติฐานเดียว: version/info query ที่ส่งทาง IF4 อาจตอบกลับทาง HID IF3 interrupt-IN endpoint `0x81` แต่ Android driver กิน packet นั้นอยู่.

## ลำดับ R9
1. ปุ่ม 1 ทำ read-only qualification เหมือนเดิม: VID/PID, IF4 descriptor, IF4 Feature, IF3 EP81 topology.
2. ปุ่ม 2 จะ re-check gate ก่อน แล้ว `claimInterface(IF3, force=true)` เพื่อ detach kernel HID driver ชั่วคราว.
3. ถ้า force-claim ไม่สำเร็จ: BLOCK ทันทีและส่ง OUT = 0.
4. ถ้าสำเร็จ: อ่าน IF3 report descriptor, drain EP81 แบบ IN สั้น ๆ, claim IF4 แบบ `force=false`.
5. arm IF3 EP81 listener ก่อนส่ง เพื่อไม่พลาด response ที่มาเร็ว.
6. ส่ง OUT เพียงหนึ่งครั้ง: `A5 5A 00 00 16` + zero padding ถึง 256 bytes ผ่าน IF4 HID SET_REPORT.
7. ฟัง IF3 EP81 แบบ IN-only และ cross-check IF4 GET_REPORT INPUT.
8. release IF4/IF3 แล้วปิด connection.

## Safety boundary
- ไม่มี UFE `0x57`, actuator/EQ/SaveParams write
- ไม่มี erase / program / commit / reboot-to-bootloader
- ไม่มี endpoint OUT transfer
- force detach ใช้กับ IF3 เท่านั้น และเกิดหลัง exact board gate ผ่าน
- ถ้า Android audio/HID behavior เปลี่ยนหลังจบ ให้ถอดเสียบ USB-C ใหม่หนึ่งครั้งเพื่อให้ kernel bind IF3 กลับ
