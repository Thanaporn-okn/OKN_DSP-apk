// BP1048P4 command core V17 FIX
