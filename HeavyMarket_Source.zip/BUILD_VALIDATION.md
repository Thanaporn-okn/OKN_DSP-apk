# BUILD VALIDATION — Heavy Market v1

วันที่ตรวจ: 2026-09-20

## ตรวจแล้วใน environment นี้

- Kotlin domain logic (`PostClassifier`, `PriceParser`, `Deduplicator`, `SearchQueryParser`) compile ด้วย `kotlinc` สำเร็จ
- ชุด behavior smoke test ของ classifier/price parser/search parser/dedup ผ่าน
- GitHub Actions YAML parse ด้วย PyYAML สำเร็จ
- Android XML หลัก parse สำเร็จ
- Gradle bootstrap JAR compile ด้วย Java 17 และ `jar tf` อ่านได้
- `./gradlew` ทดสอบการ delegate argument/cwd กับ Gradle executable จำลองใน cache สำเร็จ
- Backend TypeScript ตรวจ syntax/transpile ทุกไฟล์สำเร็จ
- ตรวจ archive หลังสร้าง ZIP ด้วย `unzip -t`

## สิ่งที่ environment นี้ทำไม่ได้

เครื่องทำงานนี้ไม่มี Android SDK/Gradle distribution ที่ติดตั้งไว้ และ outbound network ของ container ถูกปิด จึง **ไม่ได้อ้างว่า Debug APK build สำเร็จในเครื่องนี้**

Repository มี GitHub Actions สำหรับรันของจริงด้วย JDK 17 + Android SDK 37 และคำสั่ง:

```bash
./gradlew clean testDebugUnitTest assembleDebug --stacktrace
```

เมื่อ CI สำเร็จจะตรวจไฟล์จริงใต้ `app/build/outputs` แล้วอัปโหลด APK เป็น artifact โดยอัตโนมัติ
