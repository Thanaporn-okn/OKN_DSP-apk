#!/usr/bin/env python3
from pathlib import Path
import json, sys
root = Path(__file__).resolve().parents[1]
m = json.loads((root / 'target_port_manifest.json').read_text())
errors = []
if m.get('target') != 'BP1048P4': errors.append('target must be BP1048P4')
if m.get('board') != 'GoloPine 7CH': errors.append('board must be GoloPine 7CH')
ev = m.get('evidence', {})
required = ['exact_bp1048p4_sdk','exact_chip_identity','startup','linker_memory_map','flash_programmer','audio_path','ble_api','nvm_api','board_pin_map']
if any(k not in ev for k in required): errors.append('missing evidence fields')
# V7 intentionally ships locked. If any target evidence is flipped to true,
# require human review and a new version rather than silently enabling hardware.
if any(bool(ev.get(k)) for k in required): errors.append('V7 target evidence must remain locked')
if m.get('hardware_flashable') is not False: errors.append('V7 hardware_flashable must be false')
pub = m.get('public_family_sdk', {})
if pub.get('classification') != 'FAMILY_ONLY_NOT_P4_PROOF': errors.append('family SDK must remain family-only')
if pub.get('p4_use_authorized') is not False: errors.append('family SDK must not authorize P4 use')
if errors:
    for e in errors: print('BLOCKED:', e)
    sys.exit(1)
print('PASS: V7 exact-target evidence gate remains fail-closed')
