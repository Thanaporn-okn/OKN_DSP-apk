#ifndef BP1048P4_SDK_ADAPTER_H
#define BP1048P4_SDK_ADAPTER_H

#include "bp1048p4_hal.h"
#include <stdbool.h>
#include <stdint.h>

#define BP1048P4_SDK_ADAPTER_ABI 1u

typedef enum {
    BP1048P4_SDK_EVIDENCE_NONE = 0,
    BP1048P4_SDK_EVIDENCE_FAMILY_ONLY = 1,
    BP1048P4_SDK_EVIDENCE_EXACT_TARGET = 2
} bp1048p4_sdk_evidence_level_t;

typedef struct {
    uint16_t abi_version;
    bp1048p4_sdk_evidence_level_t evidence_level;
    bool exact_bp1048p4_identity_verified;
    bool startup_verified;
    bool linker_verified;
    bool flash_programmer_verified;
    bool audio_api_verified;
    bool ble_api_verified;
    bool nvm_api_verified;
} bp1048p4_sdk_capabilities_t;

typedef enum {
    BP1048P4_SDK_USE_RUNTIME_AUDIO = 0,
    BP1048P4_SDK_USE_RUNTIME_BLE = 1,
    BP1048P4_SDK_USE_RUNTIME_NVM = 2,
    BP1048P4_SDK_USE_FLASH_IMAGE = 3
} bp1048p4_sdk_use_t;

/* Validates evidence only; it never probes, writes, or infers hardware. */
okn_status_t bp1048p4_sdk_adapter_authorize(const bp1048p4_sdk_capabilities_t *caps,
                                             bp1048p4_sdk_use_t use);

/* Built-in default remains locked until exact P4 evidence is supplied. */
const bp1048p4_sdk_capabilities_t *bp1048p4_sdk_capabilities_get(void);

#endif
