#include "bp1048p4_sdk_adapter.h"

static const bp1048p4_sdk_capabilities_t LOCKED_CAPS = {
    .abi_version = BP1048P4_SDK_ADAPTER_ABI,
    .evidence_level = BP1048P4_SDK_EVIDENCE_FAMILY_ONLY,
    .exact_bp1048p4_identity_verified = false,
    .startup_verified = false,
    .linker_verified = false,
    .flash_programmer_verified = false,
    .audio_api_verified = false,
    .ble_api_verified = false,
    .nvm_api_verified = false
};

okn_status_t bp1048p4_sdk_adapter_authorize(const bp1048p4_sdk_capabilities_t *caps,
                                             bp1048p4_sdk_use_t use) {
    if (!caps) return OKN_ERR_ARG;
    if (caps->abi_version != BP1048P4_SDK_ADAPTER_ABI) return OKN_ERR_FORMAT;
    if (caps->evidence_level != BP1048P4_SDK_EVIDENCE_EXACT_TARGET ||
        !caps->exact_bp1048p4_identity_verified) return OKN_ERR_HAL_LOCKED;

    switch (use) {
        case BP1048P4_SDK_USE_RUNTIME_AUDIO:
            if (!caps->startup_verified || !caps->linker_verified ||
                !caps->audio_api_verified) return OKN_ERR_HAL_LOCKED;
            return OKN_OK;
        case BP1048P4_SDK_USE_RUNTIME_BLE:
            if (!caps->startup_verified || !caps->linker_verified ||
                !caps->ble_api_verified) return OKN_ERR_HAL_LOCKED;
            return OKN_OK;
        case BP1048P4_SDK_USE_RUNTIME_NVM:
            if (!caps->startup_verified || !caps->linker_verified ||
                !caps->nvm_api_verified) return OKN_ERR_HAL_LOCKED;
            return OKN_OK;
        case BP1048P4_SDK_USE_FLASH_IMAGE:
            if (!caps->startup_verified || !caps->linker_verified ||
                !caps->flash_programmer_verified) return OKN_ERR_HAL_LOCKED;
            return OKN_OK;
        default:
            return OKN_ERR_ARG;
    }
}

const bp1048p4_sdk_capabilities_t *bp1048p4_sdk_capabilities_get(void) {
    return &LOCKED_CAPS;
}
