#include "../src/hal/bp1048p4_sdk_adapter.h"
#include <assert.h>
#include <stdio.h>

int main(void) {
    const bp1048p4_sdk_capabilities_t *locked = bp1048p4_sdk_capabilities_get();
    assert(bp1048p4_sdk_adapter_authorize(locked, BP1048P4_SDK_USE_RUNTIME_AUDIO) == OKN_ERR_HAL_LOCKED);
    assert(bp1048p4_sdk_adapter_authorize(locked, BP1048P4_SDK_USE_FLASH_IMAGE) == OKN_ERR_HAL_LOCKED);

    /* Family/B1 evidence must never authorize a P4 operation. */
    bp1048p4_sdk_capabilities_t family = {
        .abi_version = BP1048P4_SDK_ADAPTER_ABI,
        .evidence_level = BP1048P4_SDK_EVIDENCE_FAMILY_ONLY,
        .exact_bp1048p4_identity_verified = false,
        .startup_verified = true,
        .linker_verified = true,
        .flash_programmer_verified = true,
        .audio_api_verified = true,
        .ble_api_verified = true,
        .nvm_api_verified = true
    };
    assert(bp1048p4_sdk_adapter_authorize(&family, BP1048P4_SDK_USE_RUNTIME_AUDIO) == OKN_ERR_HAL_LOCKED);
    assert(bp1048p4_sdk_adapter_authorize(&family, BP1048P4_SDK_USE_FLASH_IMAGE) == OKN_ERR_HAL_LOCKED);

    /* Exact-target evidence is granular: one proven subsystem does not unlock another. */
    bp1048p4_sdk_capabilities_t exact = {
        .abi_version = BP1048P4_SDK_ADAPTER_ABI,
        .evidence_level = BP1048P4_SDK_EVIDENCE_EXACT_TARGET,
        .exact_bp1048p4_identity_verified = true,
        .startup_verified = true,
        .linker_verified = true,
        .flash_programmer_verified = false,
        .audio_api_verified = true,
        .ble_api_verified = false,
        .nvm_api_verified = false
    };
    assert(bp1048p4_sdk_adapter_authorize(&exact, BP1048P4_SDK_USE_RUNTIME_AUDIO) == OKN_OK);
    assert(bp1048p4_sdk_adapter_authorize(&exact, BP1048P4_SDK_USE_RUNTIME_BLE) == OKN_ERR_HAL_LOCKED);
    assert(bp1048p4_sdk_adapter_authorize(&exact, BP1048P4_SDK_USE_RUNTIME_NVM) == OKN_ERR_HAL_LOCKED);
    assert(bp1048p4_sdk_adapter_authorize(&exact, BP1048P4_SDK_USE_FLASH_IMAGE) == OKN_ERR_HAL_LOCKED);

    exact.flash_programmer_verified = true;
    assert(bp1048p4_sdk_adapter_authorize(&exact, BP1048P4_SDK_USE_FLASH_IMAGE) == OKN_OK);

    puts("ALL V7 SDK-ADAPTER GATE TESTS PASS");
    return 0;
}
