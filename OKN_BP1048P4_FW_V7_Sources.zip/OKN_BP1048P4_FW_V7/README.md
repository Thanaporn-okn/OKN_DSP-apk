# OKN_BP1048P4_FW_V7

Clean-room replacement firmware foundation for GoloPine / BP1048P4 7CH.

V7 preserves the V6 DSP, persistence, protocol, stream transport, and safe-boot
core, and adds an **SDK-adapter authorization gate**. The gate prevents the
public MVsB1/BP1048-family SDK from being accidentally used as proof for the
exact BP1048P4/GoloPine target.

## V7 additions
- subsystem-granular SDK capability authorization
- FAMILY_ONLY vs EXACT_TARGET evidence classification
- family/B1 evidence cannot unlock any P4 hardware operation
- exact-target audio proof cannot implicitly unlock BLE/NVM/flash
- machine-readable `target_port_manifest.json`
- validation script forces V7 to remain hardware-locked
- host unit tests for SDK evidence boundaries

## Existing core
- 7 independent channels
- gain / mute / phase / 0-50 ms delay
- 15-band PEQ per channel
- notch / low shelf / high shelf
- HPF / LPF
- CRC-framed OKN Protocol V2 + state readback
- BLE-like fragmented stream reassembly/resync
- portable 48 kHz reference audio engine
- CRC32 A/B persistence with rollback/read-after-write verification
- evidence-gated safe boot with output safety mute

## Hardware safety
V7 is **not hardware-flashable**. No BP1048P4 register, boot address, pin,
linker memory map, MMIO write, vendor BLE call or flash command is guessed.
The public B1-family SDK is evidence about the family/toolchain only.

Validation:
```sh
make verify
make test
make demo
```
