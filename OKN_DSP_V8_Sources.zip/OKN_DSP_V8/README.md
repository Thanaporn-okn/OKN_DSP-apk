# OKN DSP V8 — Phase 1

V8 removes the modal preset-name popup. On the EQ page, tap **New preset name…** and type directly inside that field. The keyboard appears, but the app stays on the EQ screen. Press **Save Preset** or the keyboard **Done** action to save. Multiple named presets can still be selected, loaded and deleted.

This version keeps the V7/V6 themes, real-time sliders, EQ graph, 7 channels, 15 bands, Frequency/Q/Gain Band controls, and automatic local persistence.
