OKN_DSP V8 - Phase 1 UI Fidelity Pass

V8 is based on the working V7 build and remains Phase 1 only.
The uploaded reference image is used only as a visual target; it is NOT bundled or painted as a background.

Changes in V8:
- Reworked procedural mountain background for stronger reference-like depth.
- Enlarged/retuned header branding and connection chip proportions.
- Rebuilt the Home DSP enclosure as a detailed vector-only 3D device with bezel, display glow, vents, labels, screws and feet.
- Reduced secondary EQ response overlay so the 15 editable colored band curve visually matches the reference more closely.
- Preserved all V7 real-time touch behavior, EQ graph dragging, crossover/delay controls, persistence and fixed signing key.

Phase 2 DSP/BLE transport is intentionally not implemented yet.
