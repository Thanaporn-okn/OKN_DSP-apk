OKN_DSP Version 8 - Phase 1 UI

Purpose
- Rebuild the interface from code to visually approach the supplied four-screen reference.
- The supplied reference image is NOT embedded or copied as an app background.
- Phase 2 DSP/BLE transport remains disabled until the Phase 1 UI is accepted.

Pages
- Home
- Mix
- Eq
- Crossover

V8 focus
- Correct visual differences observed in the running V7 recording (30534.mp4).
- Keep full-screen support on tall phones/tablets while preventing oversized Mix knob cards.
- Make app typography less dependent on the phone's custom system font.
- Replace Home and Mix placeholder glyphs with code-drawn vector icons.
- Rebalance EQ and Crossover vertical proportions toward the supplied reference.
- Keep sliders, knobs, EQ points and crossover controls updating immediately while dragging.
- Preserve the stable development signing identity for update-in-place builds.

Signing / update path
V3 introduced a stable DEVELOPMENT signing key. V4, V5, V6, V7 and V8 preserve the same key, so V3 -> V4 -> V5 -> V6 -> V7 -> V8 -> later development builds can update in place.
If moving from V1/V2 and Android reports an incompatible update, uninstall the old V1/V2 app once. V3 and later use the stable key.

Build
Use OKN_DSP_AutoBuild.yml. The workflow automatically selects the highest OKN_DSP_V*_Sources.zip in the repository root, verifies Sources/SHA256SUMS.txt, verifies the signing key, builds the signed debug APK and uploads the APK artifact.
