OKN_DSP V8 — MASTER VOLUME REAL-DEVICE STABILITY FIX
====================================================

Real device evidence from V7:
- DSP control is real and MasterVolume changes sound.
- V7 bounded 0.5..2.0 dB / 90 ms ramp did NOT solve the user's audible stutter/pumping.

V8 change is intentionally narrow:
- UI remains immediate and visually unchanged.
- MasterVolume ID2 no longer generates an intermediate ramp train.
- While dragging: latest target only, first write immediate, then max one Master write every 240 ms.
- Drag samples are quantized to 0.5 dB to remove tiny finger jitter.
- ACTION_UP/ACTION_CANCEL requests one exact final 0.1 dB target after the sparse stream.
- One GATT write in flight and encrypt-at-actual-send remain unchanged.
- Other verified Global controls retain V7 ramp behavior.
- EQ path unchanged.
- No new/guessed actuator or packet was added.

Reason for this revision:
The real hardware result shows that adding more intermediate gain writes can itself create audible pumping or Bluetooth coexistence pressure. V8 therefore reduces Master write density instead of increasing smoothing writes.
