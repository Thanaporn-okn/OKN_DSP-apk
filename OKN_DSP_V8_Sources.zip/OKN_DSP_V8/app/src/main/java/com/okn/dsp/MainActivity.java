package com.okn.dsp;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsetsController;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;

public final class MainActivity extends Activity implements DspView.Host {
    private DspView dspView;
    private FrameLayout root;
    private EditText presetNameInput;
    private boolean presetEditorVisible;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        root = new FrameLayout(this);
        dspView = new DspView(this);
        root.addView(dspView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        presetNameInput = new EditText(this);
        presetNameInput.setSingleLine(true);
        presetNameInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        presetNameInput.setImeOptions(EditorInfo.IME_ACTION_DONE);
        presetNameInput.setTextSize(13f);
        presetNameInput.setTypeface(AppFonts.REGULAR);
        presetNameInput.setGravity(Gravity.CENTER_VERTICAL);
        presetNameInput.setHint("New preset name…");
        presetNameInput.setPadding(dp(12), 0, dp(12), 0);
        presetNameInput.setVisibility(View.GONE);
        presetNameInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                saveInlinePresetName();
                return true;
            }
            return false;
        });
        root.addView(presetNameInput, new FrameLayout.LayoutParams(1, 1));

        setContentView(root);
        applySystemBars(dspView.getThemeIndex());
    }

    @Override
    protected void onPause() {
        // Synchronous lifecycle checkpoint so an app swipe-away/relaunch restores
        // the last visible values instead of an earlier asynchronous snapshot.
        if (dspView != null) dspView.flushState();
        super.onPause();
    }

    @Override
    protected void onStop() {
        if (dspView != null) dspView.flushState();
        super.onStop();
    }

    @Override
    public void requestThemePicker(int currentTheme) {
        String[] items = {"Light", "Dark", "Midnight"};
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Theme")
                .setSingleChoiceItems(items, currentTheme, null)
                .setNegativeButton("Cancel", null)
                .create();

        dialog.setOnShowListener(ignored -> {
            lockDialogTypeface(dialog);
            dialog.getListView().setOnItemClickListener((parent, view, position, id) -> {
                dspView.setThemeIndex(position);
                dspView.flushState();
                applySystemBars(position);
                dialog.dismiss();
            });
        });
        dialog.show();
    }

    @Override
    public void showPresetNameEditor(RectF bounds, int textColor, int hintColor, int fillColor) {
        presetEditorVisible = true;
        presetNameInput.setVisibility(View.VISIBLE);
        presetNameInput.setTextColor(textColor);
        presetNameInput.setHintTextColor(hintColor);
        presetNameInput.setBackground(roundedBackground(fillColor, 12f));
        updatePresetNameEditor(bounds, textColor, hintColor, fillColor);
        presetNameInput.bringToFront();
        presetNameInput.requestFocus();
        presetNameInput.setSelection(presetNameInput.length());
        presetNameInput.post(() -> {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.showSoftInput(presetNameInput, InputMethodManager.SHOW_IMPLICIT);
        });
    }

    @Override
    public void updatePresetNameEditor(RectF bounds, int textColor, int hintColor, int fillColor) {
        if (!presetEditorVisible || bounds == null) return;
        presetNameInput.setTextColor(textColor);
        presetNameInput.setHintTextColor(hintColor);
        presetNameInput.setBackground(roundedBackground(fillColor, 12f));

        int width = Math.max(1, Math.round(bounds.width()));
        int height = Math.max(1, Math.round(bounds.height()));
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) presetNameInput.getLayoutParams();
        if (lp.width != width || lp.height != height) {
            lp.width = width;
            lp.height = height;
            presetNameInput.setLayoutParams(lp);
        }
        presetNameInput.setX(bounds.left);
        presetNameInput.setY(bounds.top);
    }

    @Override
    public boolean isPresetNameEditorVisible() {
        return presetEditorVisible;
    }

    @Override
    public String getPresetNameInput() {
        return presetNameInput == null ? "" : presetNameInput.getText().toString().trim();
    }

    @Override
    public void finishPresetNameEditor(boolean clearText) {
        if (presetNameInput == null) return;
        if (clearText) presetNameInput.setText("");
        presetNameInput.clearFocus();
        presetNameInput.setVisibility(View.GONE);
        presetEditorVisible = false;
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(presetNameInput.getWindowToken(), 0);
        if (dspView != null) dspView.invalidate();
    }

    private void saveInlinePresetName() {
        String name = getPresetNameInput();
        if (name.isEmpty()) {
            showMessage("Enter a preset name");
            return;
        }
        dspView.savePreset(name);
        dspView.flushState();
        finishPresetNameEditor(true);
    }

    private GradientDrawable roundedBackground(int color, float radiusDp) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(radiusDp));
        return bg;
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    public void requestPresetPicker(String currentName) {
        String[] names = dspView.getPresetNames();
        if (names.length == 0) {
            showMessage("No saved presets");
            return;
        }
        int checked = -1;
        for (int i = 0; i < names.length; i++) {
            if (names[i].equals(currentName)) {
                checked = i;
                break;
            }
        }
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Saved Presets")
                .setSingleChoiceItems(names, checked, null)
                .setNegativeButton("Cancel", null)
                .create();
        dialog.setOnShowListener(ignored -> {
            lockDialogTypeface(dialog);
            dialog.getListView().setOnItemClickListener((parent, view, position, id) -> {
                dspView.selectPreset(names[position]);
                dspView.flushState();
                dialog.dismiss();
            });
        });
        dialog.show();
    }

    @Override
    public void requestDeletePreset(String currentName) {
        String[] names = dspView.getPresetNames();
        if (names.length == 0) {
            showMessage("No saved presets");
            return;
        }
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Delete preset")
                .setMessage("Delete preset ‘" + currentName + "’?")
                .setPositiveButton("Delete", (d, which) -> {
                    dspView.deletePreset(currentName);
                    dspView.flushState();
                })
                .setNegativeButton("Cancel", null)
                .create();
        dialog.setOnShowListener(ignored -> lockDialogTypeface(dialog));
        dialog.show();
    }

    @Override
    public void showMessage(String message) {
        Toast toast = Toast.makeText(this, message, Toast.LENGTH_SHORT);
        toast.show();
    }

    private void lockDialogTypeface(AlertDialog dialog) {
        Window w = dialog.getWindow();
        if (w == null) return;
        applyTypefaceRecursive(w.getDecorView());
    }

    private void applyTypefaceRecursive(View view) {
        if (view instanceof TextView) {
            TextView tv = (TextView) view;
            int style = tv.getTypeface() == null ? 0 : tv.getTypeface().getStyle();
            tv.setTypeface((style & android.graphics.Typeface.BOLD) != 0 ? AppFonts.BOLD : AppFonts.REGULAR);
        }
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                applyTypefaceRecursive(group.getChildAt(i));
            }
        }
    }

    private void applySystemBars(int themeIndex) {
        boolean light = themeIndex == 0;
        int bg;
        if (themeIndex == 0) bg = 0xFFF4F7FB;
        else if (themeIndex == 1) bg = 0xFF0D1320;
        else bg = 0xFF050A13;

        Window window = getWindow();
        window.setStatusBarColor(bg);
        window.setNavigationBarColor(bg);

        if (android.os.Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = window.getInsetsController();
            if (c != null) {
                int mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                        | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                c.setSystemBarsAppearance(light ? mask : 0, mask);
            }
        } else {
            int flags = window.getDecorView().getSystemUiVisibility();
            if (light) {
                flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                if (android.os.Build.VERSION.SDK_INT >= 26) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            } else {
                flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                if (android.os.Build.VERSION.SDK_INT >= 26) flags &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            }
            window.getDecorView().setSystemUiVisibility(flags);
        }
    }
}
