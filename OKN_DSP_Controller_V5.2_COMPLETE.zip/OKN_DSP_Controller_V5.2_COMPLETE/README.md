OKN DSP Controller V5.2 COMPLETE

Fixed:
- Android Gradle Plugin 8.5
- Gradle 8.7
- Kotlin plugin
- Flutter Android structure
- GitHub Actions APK build

Version:
5.2.0
