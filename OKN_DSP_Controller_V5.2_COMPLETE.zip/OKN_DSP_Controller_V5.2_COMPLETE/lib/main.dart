import 'package:flutter/material.dart';

void main(){
  runApp(const OKNDSP());
}

class OKNDSP extends StatelessWidget{
  const OKNDSP({super.key});

  @override
  Widget build(BuildContext context){
    return MaterialApp(
      debugShowCheckedModeBanner:false,
      theme: ThemeData.dark(),
      home: const Home(),
    );
  }
}

class Home extends StatelessWidget{
  const Home({super.key});

  @override
  Widget build(BuildContext context){
    return const Scaffold(
      body: Center(
        child: Text(
          'OKN DSP Controller V5.2\nBP1048P4 7CH',
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
