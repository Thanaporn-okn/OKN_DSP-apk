#!/usr/bin/env python3
from pathlib import Path
import json,re,sys
root=Path(__file__).resolve().parents[1]
h=(root/'src/core/okn_version.h').read_text()
def macro(name):
    m=re.search(r'^#define\s+'+re.escape(name)+r'\s+(0x[0-9A-Fa-f]+|[0-9]+)u?\s*$',h,re.M)
    if not m: raise SystemExit('missing macro '+name)
    return int(m.group(1),0)
project=macro('OKN_PROJECT_VERSION'); fw=macro('OKN_FW_VERSION'); proto=macro('OKN_PROTO_VERSION')
files=['firmware_manifest.json','evidence_manifest.json','flash_session_manifest.json','resource_requirements.json','target_qualification_manifest.json','qualification_bundle_manifest.json','port_integration_plan.json']
d={f:json.loads((root/f).read_text()) for f in files}
errors=[]
if project!=18 or fw!=18: errors.append('C project/firmware version must be 18')
if proto!=2: errors.append('protocol version must remain 2')
if d['firmware_manifest.json'].get('version')!=project: errors.append('firmware_manifest version mismatch')
if d['firmware_manifest.json'].get('protocol_version')!=proto: errors.append('protocol manifest mismatch')
for f in files[1:]:
    if d[f].get('project_version')!=project: errors.append(f+' project_version mismatch')
if errors:
    [print('BLOCKED:',e) for e in errors]; sys.exit(1)
print('PASS: V18 version constants and manifests are consistent (FW=18, protocol=2)')
