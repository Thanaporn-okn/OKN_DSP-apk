#!/usr/bin/env python3
from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'evidence_manifest.json').read_text())
errors=[]
if m.get('schema')!=4: errors.append('evidence schema must be 4')
if m.get('project_version')!=18: errors.append('project_version must be 18')
if m.get('target')!='BP1048P4' or m.get('board')!='GoloPine 7CH': errors.append('target/board mismatch')
if m.get('policy')!='FAIL_CLOSED_NO_INFERENCE': errors.append('policy mismatch')
if m.get('hardware_authorized') is not False: errors.append('hardware_authorized must be false')
req=m.get('required_exact_evidence',{})
if any(bool(v) for v in req.values()): errors.append('V18 exact evidence flags must all remain false')
prov=m.get('provenance',{})
if prov.get('previous_source_sha256')!='ef793dcdcdb26c3d89d1791256b86c7ce52c863eef519f4e55907e846a006884': errors.append('V17 source provenance mismatch')
if prov.get('validation_zip_sha256')!='7e485563d80a0fc3bc6dfceed8c41ceb07e9493417ca9933631789509d9adf60': errors.append('V17 validation provenance mismatch')
if not any(o.get('id')=='v17-ci-validation' for o in m.get('observations',[])): errors.append('V17 CI observation missing')
for ob in m.get('observations',[]):
    if ob.get('authorizes') not in ([],None): errors.append('observations may not authorize hardware in V18')
if errors:
    [print('BLOCKED:',e) for e in errors]; sys.exit(1)
print('PASS: V18 evidence manifest is internally consistent and non-authorizing')
