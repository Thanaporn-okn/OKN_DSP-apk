# OKN_BP1048P4_FW_V18

V18 is the derived port-integration planning release built on the V17 content-bound
qualification bundle. The portable DSP/control/runtime foundation remains unchanged
at the wire level: firmware version 18, protocol version 2.

The wire frame remains Protocol V2; V18 changes readiness metadata only and does not change packet framing.

## What V18 adds

`port_integration_plan.json` is generated from the exact current qualification
manifest plus the hash-verified evidence bundle. It divides target bring-up into
identity, startup/linker, flash programming, safe boot, audio, BLE runtime, NVM,
memory, and Android/mobile flash readiness.

Each subsystem reports required, qualified, and missing claims. Evidence completeness
is intentionally separate from authorization: even a complete evidence set does not
make a subsystem ready until explicit hardware authorization is present. Mobile flash
also requires a separate mobile authorization.

The plan is readiness metadata only. It contains no BP1048P4 register addresses,
GoloPine pin values, boot pins, programmer packets, flash offsets, or target image
layout values. V18 still produces no target `.bin` and invokes no vendor programmer.

## Safety state

The shipped qualification evidence bundle is empty, all exact target/board claims are
false, hardware authorization is false, mobile authorization is false, and every
integration subsystem is therefore locked. Family-only B1/B2 information remains
non-authorizing.

V17 content binding remains mandatory: a claim must point to a concrete regular file
inside the evidence bundle, its SHA256 must re-verify, provenance/classification must
match, and review must be explicit before the claim can become qualified.

See `docs/PORT_INTEGRATION_PLAN_V18.md`, `docs/QUALIFICATION_BUNDLE_V17.md`, and
`docs/TARGET_QUALIFICATION_V16.md`.
