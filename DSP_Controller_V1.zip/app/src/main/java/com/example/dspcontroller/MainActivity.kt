package com.example.dspcontroller

import android.app.Activity
import android.os.Bundle
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val log = TextView(this)
        val send = Button(this)
        val hex = EditText(this)

        send.text = "SEND HEX"
        hex.hint = "73 F6 60 00 FF..."

        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL
        layout.addView(TextView(this).apply { text="DSP BP1048P4 Controller V1" })
        layout.addView(Button(this).apply { text="CONNECT Bluetooth" })
        layout.addView(hex)
        layout.addView(send)
        layout.addView(log)

        send.setOnClickListener {
            log.text = "TX: " + hex.text.toString()
        }

        setContentView(layout)
    }
}
