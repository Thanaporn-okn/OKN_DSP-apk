package com.okn.dsp

import android.Manifest
import android.app.Activity
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.*
import androidx.core.app.ActivityCompat
import java.util.UUID

class MainActivity : Activity() {
    private lateinit var log: TextView
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val found = LinkedHashMap<String, BluetoothDevice>()
    private var scanner: BluetoothLeScanner? = null
    private var gatt: BluetoothGatt? = null
    private val notifyQueue = ArrayDeque<BluetoothGattCharacteristic>()
    private var descriptorWriteInProgress = false
    private val logLines = StringBuilder()

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        buildUi()
        requestBlePermissions()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }

        val title = TextView(this).apply {
            text = "OKN DSP Controller\nV7 PACKET LOGGER"
            textSize = 22f
        }

        status = TextView(this).apply {
            text = "WRITE DISABLED — capture/read/notify only"
            textSize = 15f
        }

        val scan = Button(this).apply {
            text = "SCAN DSP"
            setOnClickListener { startScan() }
        }

        val clear = Button(this).apply {
            text = "CLEAR LOG"
            setOnClickListener {
                logLines.clear()
                log.text = "Log:\n"
            }
        }

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        log = TextView(this).apply {
            text = "Log:\n"
            textSize = 13f
        }

        root.addView(title)
        root.addView(status)
        root.addView(scan)
        root.addView(clear)
        root.addView(list)
        root.addView(log)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun requestBlePermissions() {
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT
                ),
                100
            )
        }
    }

    private fun startScan() {
        if (!hasBlePermission()) {
            append("Bluetooth permission not granted")
            return
        }

        val manager = getSystemService(BluetoothManager::class.java)
        val adapter = manager?.adapter
        if (adapter == null) {
            append("Bluetooth adapter not available")
            return
        }
        if (!adapter.isEnabled) {
            append("Bluetooth is OFF — turn Bluetooth ON and scan again")
            return
        }

        scanner = adapter.bluetoothLeScanner
        if (scanner == null) {
            append("BLE scanner not available")
            return
        }

        found.clear()
        list.removeAllViews()
        append("Scanning for LE-GOLOPINE DSP ...")

        try {
            scanner?.startScan(callback)
        } catch (_: SecurityException) {
            append("Bluetooth permission denied")
            return
        }

        handler.postDelayed({
            try { scanner?.stopScan(callback) } catch (_: Exception) {}
            append("Scan finished")
        }, 10000)
    }

    private fun hasBlePermission(): Boolean =
        android.os.Build.VERSION.SDK_INT < 31 ||
        (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
         checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED)

    private val callback = object : ScanCallback() {
        override fun onScanResult(type: Int, result: ScanResult) {
            val device = result.device
            val name = result.scanRecord?.deviceName
                ?: try { device.name } catch (_: SecurityException) { null }

            if (name?.contains("GOLOPINE", true) == true ||
                name?.contains("DSP", true) == true) {
                if (!found.containsKey(device.address)) {
                    found[device.address] = device
                    runOnUiThread {
                        val b = Button(this@MainActivity).apply {
                            text = "${name ?: "DSP"}\n${device.address}\nTAP TO CONNECT"
                            setOnClickListener { connect(device, name ?: "DSP") }
                        }
                        list.addView(b)
                    }
                }
            }
        }

        override fun onScanFailed(errorCode: Int) {
            append("BLE scan failed: $errorCode")
        }
    }

    private fun connect(device: BluetoothDevice, name: String) {
        if (!hasBlePermission()) {
            append("Bluetooth permission not granted")
            return
        }

        try {
            gatt?.close()
            gatt = null
            notifyQueue.clear()
            descriptorWriteInProgress = false
            status.text = "CONNECTING — $name"
            append("Connecting to $name ${device.address} ...")
            gatt = device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
        } catch (_: SecurityException) {
            append("Bluetooth permission denied")
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, statusCode: Int, newState: Int) {
            append("GATT state=$newState status=$statusCode")
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                status.text = "CONNECTED — discovery/read/notify only"
                append("Connected — discovering services")
                try { g.discoverServices() }
                catch (_: SecurityException) { append("Service discovery permission denied") }
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                status.text = "DISCONNECTED"
                append("Disconnected")
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, statusCode: Int) {
            append("Services discovered: status=$statusCode")
            if (statusCode != BluetoothGatt.GATT_SUCCESS) return

            notifyQueue.clear()

            g.services.forEachIndexed { si, service ->
                append("SERVICE[$si] ${service.uuid}")
                service.characteristics.forEachIndexed { ci, ch ->
                    val props = properties(ch)
                    append("  CHAR[$ci] ${ch.uuid} [$props]")
                    ch.descriptors.forEach { d ->
                        append("    DESC ${d.uuid}")
                    }

                    if ((ch.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0 ||
                        (ch.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) {
                        notifyQueue.addLast(ch)
                    }
                }
            }

            append("NOTIFY TARGETS=${notifyQueue.size}")
            processNextNotificationSubscription(g)

            // Read one characteristic at a time to avoid GATT_BUSY.
            handler.postDelayed({ readNextReadable(g) }, 500)
        }

        override fun onDescriptorWrite(
            g: BluetoothGatt,
            descriptor: BluetoothGattDescriptor,
            statusCode: Int
        ) {
            append("CCCD WRITE ${descriptor.uuid} status=$statusCode")
            descriptorWriteInProgress = false
            handler.postDelayed({ processNextNotificationSubscription(g) }, 250)
        }

        override fun onCharacteristicChanged(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            value: ByteArray
        ) {
            append("NOTIFY ${shortUuid(characteristic.uuid)} len=${value.size} HEX=${value.toHex()}")
        }

        override fun onCharacteristicRead(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            value: ByteArray,
            statusCode: Int
        ) {
            append("READ ${shortUuid(characteristic.uuid)} status=$statusCode len=${value.size} HEX=${value.toHex()}")
            handler.postDelayed({ readNextReadable(g) }, 250)
        }

        @Suppress("DEPRECATION")
        override fun onCharacteristicRead(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            statusCode: Int
        ) {
            append("READ ${shortUuid(characteristic.uuid)} status=$statusCode len=${characteristic.value?.size ?: 0} HEX=${(characteristic.value ?: byteArrayOf()).toHex()}")
            handler.postDelayed({ readNextReadable(g) }, 250)
        }
    }

    private var readableQueue = ArrayDeque<BluetoothGattCharacteristic>()

    private fun readNextReadable(g: BluetoothGatt) {
        if (!hasBlePermission()) return
        if (readableQueue.isEmpty()) {
            readableQueue.addAll(
                g.services.flatMap { it.characteristics }
                    .filter { it.properties and BluetoothGattCharacteristic.PROPERTY_READ != 0 }
            )
        }
        val ch = readableQueue.removeFirstOrNull() ?: return
        append("READ REQUEST ${shortUuid(ch.uuid)}")
        try {
            g.readCharacteristic(ch)
        } catch (_: Exception) {
            handler.postDelayed({ readNextReadable(g) }, 300)
        }
    }

    private fun processNextNotificationSubscription(g: BluetoothGatt) {
        if (descriptorWriteInProgress) return
        val ch = notifyQueue.removeFirstOrNull() ?: return
        subscribeToNotifications(g, ch)
    }

    private fun subscribeToNotifications(g: BluetoothGatt, ch: BluetoothGattCharacteristic) {
        if (!hasBlePermission()) return

        try {
            val localOk = g.setCharacteristicNotification(ch, true)
            append("SUBSCRIBE ${shortUuid(ch.uuid)} local=$localOk")

            val cccd = ch.getDescriptor(
                UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
            )

            if (cccd == null) {
                append("  CCCD NOT FOUND")
                handler.postDelayed({ processNextNotificationSubscription(g) }, 250)
                return
            }

            val value =
                if ((ch.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0)
                    BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
                else
                    BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE

            descriptorWriteInProgress = true

            if (android.os.Build.VERSION.SDK_INT >= 33) {
                val rc = g.writeDescriptor(cccd, value)
                append("  CCCD REQUEST rc=$rc")
                if (rc != BluetoothGatt.GATT_SUCCESS) {
                    descriptorWriteInProgress = false
                    handler.postDelayed({ processNextNotificationSubscription(g) }, 500)
                }
            } else {
                @Suppress("DEPRECATION")
                cccd.value = value
                @Suppress("DEPRECATION")
                val ok = g.writeDescriptor(cccd)
                append("  CCCD REQUEST ok=$ok")
                if (!ok) {
                    descriptorWriteInProgress = false
                    handler.postDelayed({ processNextNotificationSubscription(g) }, 500)
                }
            }
        } catch (_: SecurityException) {
            append("  CCCD permission denied")
            descriptorWriteInProgress = false
        } catch (e: Exception) {
            append("  CCCD error=${e.message}")
            descriptorWriteInProgress = false
        }
    }

    private fun properties(ch: BluetoothGattCharacteristic): String {
        val p = mutableListOf<String>()
        if (ch.properties and BluetoothGattCharacteristic.PROPERTY_READ != 0) p.add("READ")
        if (ch.properties and BluetoothGattCharacteristic.PROPERTY_WRITE != 0) p.add("WRITE")
        if (ch.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0) p.add("WRITE_NR")
        if (ch.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0) p.add("NOTIFY")
        if (ch.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0) p.add("INDICATE")
        return p.joinToString(",")
    }

    private fun shortUuid(uuid: UUID): String = uuid.toString()

    private fun ByteArray.toHex(): String =
        take(128).joinToString(" ") { "%02X".format(it.toInt() and 0xFF) }

    private fun append(message: String) {
        runOnUiThread {
            logLines.append(message).append('\n')
            log.text = "Log:\n$logLines"
        }
    }

    override fun onDestroy() {
        try { scanner?.stopScan(callback) } catch (_: Exception) {}
        try { gatt?.close() } catch (_: Exception) {}
        gatt = null
        super.onDestroy()
    }
}
