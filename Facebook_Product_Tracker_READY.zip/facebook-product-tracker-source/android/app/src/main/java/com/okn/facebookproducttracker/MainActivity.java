package com.okn.facebookproducttracker;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public final class MainActivity extends Activity {
    private static final String PREFS = "tracker_prefs";
    private static final String KEY_URL = "tracker_url";

    private WebView webView;
    private ProgressBar progress;
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        configureWebView();
        loadConfiguredUrl();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(11, 15, 20));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(14), dp(8), dp(8), dp(8));
        bar.setBackgroundColor(Color.rgb(17, 25, 35));

        TextView title = new TextView(this);
        title.setText("Facebook Product Tracker");
        title.setTextColor(Color.WHITE);
        title.setTextSize(16);
        title.setSingleLine(true);
        bar.addView(title, new LinearLayout.LayoutParams(0, dp(48), 1f));

        Button reload = new Button(this);
        reload.setText(getString(R.string.reload));
        reload.setOnClickListener(v -> webView.reload());
        bar.addView(reload, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(48)));

        Button settings = new Button(this);
        settings.setText(getString(R.string.settings));
        settings.setOnClickListener(v -> showUrlDialog());
        bar.addView(settings, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(48)));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setVisibility(View.GONE);

        status = new TextView(this);
        status.setTextColor(Color.rgb(174, 188, 204));
        status.setTextSize(11);
        status.setPadding(dp(12), dp(4), dp(12), dp(4));
        status.setSingleLine(true);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(11, 15, 20));

        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(progress, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)));
        root.addView(status, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(webView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
    }

    private void configureWebView() {
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setAllowFileAccess(false);
        webView.getSettings().setAllowContentAccess(false);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(true);
        webView.getSettings().setBuiltInZoomControls(false);
        webView.getSettings().setDisplayZoomControls(false);

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progress.setProgress(newProgress);
                progress.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
                String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT);

                if (host.equals("facebook.com") || host.endsWith(".facebook.com") ||
                    host.equals("messenger.com") || host.endsWith(".messenger.com")) {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    return true;
                }
                if (!scheme.equals("https") && !isAllowedLocalDevUri(uri)) {
                    Toast.makeText(MainActivity.this, "อนุญาตเฉพาะ HTTPS หรือ 10.0.2.2/localhost สำหรับทดสอบ", Toast.LENGTH_LONG).show();
                    return true;
                }
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (url != null && url.startsWith("file:///android_asset/")) {
                    status.setText("LOCAL DEMO • พร้อมใช้งาน");
                } else {
                    status.setText(url == null ? "" : url);
                }
            }
        });
    }

    private boolean isAllowedLocalDevUri(Uri uri) {
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
        String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT);
        return scheme.equals("http") && (host.equals("10.0.2.2") || host.equals("localhost"));
    }

    private void loadConfiguredUrl() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String stored = prefs.getString(KEY_URL, "");
        String configured = stored == null || stored.trim().isEmpty() ? BuildConfig.TRACKER_WEB_URL : stored;
        configured = configured == null ? "" : configured.trim();
        if (configured.isEmpty()) {
            showLocalApp();
            return;
        }
        if (!isAllowedTrackerUrl(configured)) {
            Toast.makeText(this, "URL ไม่ถูกต้อง จึงกลับเข้าโหมด LOCAL DEMO", Toast.LENGTH_LONG).show();
            showLocalApp();
            return;
        }
        status.setText(configured);
        webView.getSettings().setAllowFileAccess(false);
        webView.loadUrl(configured);
    }

    private void showLocalApp() {
        status.setText("LOCAL DEMO • พร้อมใช้งาน");
        webView.getSettings().setAllowFileAccess(true);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private boolean isAllowedTrackerUrl(String value) {
        try {
            Uri uri = Uri.parse(value);
            String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
            return scheme.equals("https") || isAllowedLocalDevUri(uri);
        } catch (Exception ignored) {
            return false;
        }
    }

    private void showUrlDialog() {
        final EditText input = new EditText(this);
        input.setHint(getString(R.string.url_hint));
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setSingleLine(true);
        input.setText(getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_URL, BuildConfig.TRACKER_WEB_URL));
        input.setSelection(input.getText().length());

        int pad = dp(18);
        LinearLayout wrap = new LinearLayout(this);
        wrap.setPadding(pad, 0, pad, 0);
        wrap.addView(input, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        new AlertDialog.Builder(this)
            .setTitle(getString(R.string.url_title))
            .setView(wrap)
            .setPositiveButton(getString(R.string.save), (dialog, which) -> {
                String value = input.getText().toString().trim();
                if (!value.isEmpty() && !isAllowedTrackerUrl(value)) {
                    Toast.makeText(this, "URL ไม่ถูกต้อง: ใช้ HTTPS", Toast.LENGTH_LONG).show();
                    return;
                }
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_URL, value).apply();
                loadConfiguredUrl();
            })
            .setNegativeButton(getString(R.string.cancel), null)
            .show();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
