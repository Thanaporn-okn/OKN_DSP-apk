package com.okn.dsp;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.text.InputType;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowInsets;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/**
 * OKN DSP Rebuild - Version 1 / Phase 1 UI.
 *
 * The complete interface is drawn from native Android Canvas primitives.
 * No uploaded screenshot is used as a background or fake UI layer.
 */
public final class DspUiView extends View {

    private static final int PAGE_HOME = 0;
    private static final int PAGE_MIX = 1;
    private static final int PAGE_EQ = 2;

    private static final int BG = Color.rgb(247, 249, 253);
    private static final int CARD = Color.WHITE;
    private static final int TEXT = Color.rgb(15, 20, 31);
    private static final int MUTED = Color.rgb(124, 136, 157);
    private static final int LINE = Color.rgb(226, 232, 241);
    private static final int TRACK = Color.rgb(220, 228, 239);
    private static final int BLUE = Color.rgb(10, 143, 255);
    private static final int GREEN = Color.rgb(33, 202, 80);
    private static final int ORANGE = Color.rgb(255, 157, 36);
    private static final int PURPLE = Color.rgb(117, 88, 246);
    private static final int PINK = Color.rgb(245, 82, 121);
    private static final int CYAN = Color.rgb(29, 197, 211);

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final Typeface regular = Typeface.create("sans-serif", Typeface.NORMAL);
    private final Typeface medium = Typeface.create("sans-serif-medium", Typeface.NORMAL);
    private final Typeface bold = Typeface.create("sans-serif", Typeface.BOLD);

    private final float density;
    private final float scaledDensity;
    private final int touchSlop;

    private int topInset;
    private int bottomInset;
    private int page = PAGE_HOME;
    private float scrollY;
    private float maxScroll;
    private float contentLeft;
    private float contentRight;
    private float contentWidth;
    private float navTop;

    private final java.util.ArrayList<Hit> hits = new java.util.ArrayList<>();
    private Hit activeHit;
    private Hit pendingClick;
    private boolean scrolling;
    private float downX;
    private float downY;
    private float startScroll;

    private float masterVolume = -6f;
    private float bassVolume = 2f;
    private float bassCutoff = 80f;
    private final float[] channelVolume = {-3f, -6f, -2f, -8f, 0f, -4f, -10f};

    private int selectedChannel = 0;
    private int selectedBand = 4;
    private final float[][] eqFreq = new float[7][15];
    private final float[][] eqQ = new float[7][15];
    private final float[][] eqGain = new float[7][15];
    private final Map<String, Preset> presets = new LinkedHashMap<>();
    private String lastPreset = "Flat";

    private final int[] channelColors = {BLUE, GREEN, ORANGE, PINK, PURPLE, CYAN, Color.rgb(119, 94, 245)};
    private final float[] defaultFreqs = {20f, 31.5f, 50f, 80f, 100f, 160f, 250f, 400f, 630f, 1000f, 2000f, 3150f, 5000f, 10000f, 20000f};
    private final float[] demoCurve = {-2f, -1f, 1.5f, 3.8f, 2f, 0.2f, -1f, -1.6f, 0f, 2.2f, 3.1f, 2.6f, 1.4f, -0.5f, -1.5f};

    public DspUiView(Context context) {
        super(context);
        density = getResources().getDisplayMetrics().density;
        scaledDensity = getResources().getDisplayMetrics().scaledDensity;
        touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
        setBackgroundColor(BG);
        setFocusable(true);
        setClickable(true);

        for (int ch = 0; ch < 7; ch++) {
            for (int b = 0; b < 15; b++) {
                eqFreq[ch][b] = defaultFreqs[b];
                eqQ[ch][b] = 1f;
                eqGain[ch][b] = ch == 0 ? demoCurve[b] : 0f;
            }
        }
        createBuiltInPresets();

        setOnApplyWindowInsetsListener((v, insets) -> {
            topInset = insets.getSystemWindowInsetTop();
            bottomInset = insets.getSystemWindowInsetBottom();
            invalidate();
            return insets;
        });
    }

    private float dp(float v) { return v * density; }
    private float sp(float v) { return v * scaledDensity; }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        hits.clear();
        canvas.drawColor(BG);

        float w = getWidth();
        float h = getHeight();
        float side = dp(18);
        contentWidth = Math.min(w - side * 2f, dp(840));
        contentLeft = (w - contentWidth) * 0.5f;
        contentRight = contentLeft + contentWidth;

        float navHeight = dp(92);
        navTop = h - bottomInset - navHeight - dp(8);
        float clipTop = Math.max(0, topInset);
        float clipBottom = Math.max(clipTop, navTop - dp(4));

        canvas.save();
        canvas.clipRect(0, clipTop, w, clipBottom);
        canvas.translate(0, -scrollY);

        float bottom;
        if (page == PAGE_HOME) bottom = drawHome(canvas);
        else if (page == PAGE_MIX) bottom = drawMix(canvas);
        else bottom = drawEq(canvas);

        canvas.restore();

        float viewportHeight = clipBottom - clipTop;
        float contentBottomOnZeroScroll = bottom - clipTop;
        maxScroll = Math.max(0f, contentBottomOnZeroScroll - viewportHeight + dp(24));
        if (scrollY > maxScroll) scrollY = maxScroll;

        drawBottomNav(canvas, navTop, navHeight);
    }

    private float drawHeader(Canvas c, String title, String subtitle) {
        float x = contentLeft + dp(8);
        float y = topInset + dp(36);
        text(c, title, x, y + sp(30), 32, TEXT, bold, Paint.Align.LEFT);
        text(c, subtitle, x, y + sp(56), 17, MUTED, regular, Paint.Align.LEFT);

        float r = dp(26);
        float cy = y + dp(28);
        float menuCx = contentRight - dp(10) - r;
        float searchCx = menuCx - dp(64);
        circleButton(c, searchCx, cy, r, "search", "search");
        circleButton(c, menuCx, cy, r, "menu", "menu");
        return y + dp(86);
    }

    private float drawHome(Canvas c) {
        float y = drawHeader(c, "OKN DSP", "DSP Controller");
        float x = contentLeft;
        float w = contentWidth;

        RectF status = new RectF(x, y, x + w, y + dp(116));
        drawShadowCard(c, status, Color.rgb(245, 255, 247), dp(28));
        drawSoftCircle(c, status.left + dp(58), status.centerY(), dp(34), GREEN, 0.17f);
        p.setColor(GREEN); c.drawCircle(status.left + dp(58), status.centerY(), dp(25), p);
        drawCheck(c, status.left + dp(58), status.centerY(), Color.WHITE, dp(3.8f));
        text(c, "SYSTEM STATUS", status.left + dp(112), status.top + dp(41), 14, MUTED, medium, Paint.Align.LEFT);
        text(c, "System Ready", status.left + dp(112), status.top + dp(70), 23, TEXT, bold, Paint.Align.LEFT);
        text(c, "All devices connected and running normally.", status.left + dp(112), status.top + dp(95), 15, MUTED, regular, Paint.Align.LEFT);
        drawChevron(c, status.right - dp(28), status.centerY(), MUTED);
        addClick("status:System Ready", status);

        y = status.bottom + dp(34);
        text(c, "Connection & Status", x + dp(4), y, 23, TEXT, bold, Paint.Align.LEFT);
        p.setColor(GREEN); c.drawCircle(contentRight - dp(10), y - dp(7), dp(6), p);
        text(c, "All Good", contentRight - dp(28), y, 16, BLUE, medium, Paint.Align.RIGHT);
        y += dp(22);

        y = drawHomeRow(c, y, "Bluetooth", "Phone connected", "Connected", "bluetooth", BLUE, GREEN);
        y = drawHomeRow(c, y, "DSP Device", "OKN DSP-8 Pro", "Connected", "chip", PURPLE, GREEN);
        y = drawHomeRow(c, y, "Audio Input", "AUX (Analog)", "Active", "wave", ORANGE, BLUE);
        y = drawHomeRow(c, y, "Amplifier Link", "External Amplifier", "Connected", "speaker", PINK, GREEN);
        y = drawHomeRow(c, y, "Preset Sync", "User presets", "Synced", "preset", CYAN, GREEN);
        y = drawHomeRow(c, y, "Firmware Status", "v1.0.0 (UI Phase)", "Up to date", "gear", Color.rgb(135, 111, 247), BLUE);

        RectF quick = new RectF(x, y + dp(4), contentRight, y + dp(104));
        drawShadowCard(c, quick, CARD, dp(26));
        drawSoftCircle(c, quick.left + dp(54), quick.centerY(), dp(30), BLUE, 0.10f);
        drawMiniEq(c, quick.left + dp(54), quick.centerY(), BLUE);
        text(c, "Quick Control", quick.left + dp(104), quick.top + dp(43), 19, TEXT, bold, Paint.Align.LEFT);
        text(c, "Adjust volume, presets and more", quick.left + dp(104), quick.top + dp(67), 14, MUTED, regular, Paint.Align.LEFT);
        drawChevron(c, quick.right - dp(28), quick.centerY(), MUTED);
        addClick("quick", quick);
        return quick.bottom + dp(24);
    }

    private float drawHomeRow(Canvas c, float y, String title, String sub, String state,
                              String icon, int iconColor, int stateColor) {
        RectF r = new RectF(contentLeft, y + dp(10), contentRight, y + dp(101));
        drawShadowCard(c, r, CARD, dp(25));
        drawSoftCircle(c, r.left + dp(52), r.centerY(), dp(29), iconColor, 0.14f);
        drawGlyph(c, icon, r.left + dp(52), r.centerY(), iconColor);
        text(c, title, r.left + dp(104), r.top + dp(38), 19, TEXT, bold, Paint.Align.LEFT);
        text(c, sub, r.left + dp(104), r.top + dp(62), 14, MUTED, regular, Paint.Align.LEFT);
        float stateX = r.right - dp(62);
        p.setColor(stateColor); c.drawCircle(stateX - dp(96), r.centerY(), dp(6), p);
        text(c, state, stateX, r.centerY() + dp(6), 15, stateColor, medium, Paint.Align.RIGHT);
        drawChevron(c, r.right - dp(28), r.centerY(), MUTED);
        addClick("status:" + title, r);
        return r.bottom;
    }

    private float drawMix(Canvas c) {
        float y = drawHeader(c, "Mix", "Channel and bass controls");
        RectF global = new RectF(contentLeft, y, contentRight, y + dp(342));
        drawShadowCard(c, global, CARD, dp(28));
        text(c, "Global", global.left + dp(22), global.top + dp(42), 23, TEXT, bold, Paint.Align.LEFT);
        text(c, "Overall output and bass settings", global.right - dp(22), global.top + dp(40), 13, MUTED, regular, Paint.Align.RIGHT);

        float rowY = global.top + dp(88);
        rowY = drawSliderRow(c, rowY, "Master Volume", "speaker", BLUE, masterVolume, -60f, 0f,
                formatDb(masterVolume), "master", false);
        rowY = drawSliderRow(c, rowY, "Bass Volume", "wave", ORANGE, bassVolume, -12f, 12f,
                formatDb(bassVolume), "bass", false);
        drawSliderRow(c, rowY, "Bass Cutoff", "funnel", PURPLE, bassCutoff, 40f, 200f,
                Math.round(bassCutoff) + " Hz", "cutoff", false);

        y = global.bottom + dp(26);
        float channelsHeight = dp(82 + 7 * 83);
        RectF channels = new RectF(contentLeft, y, contentRight, y + channelsHeight);
        drawShadowCard(c, channels, CARD, dp(28));
        text(c, "Channels", channels.left + dp(22), channels.top + dp(43), 23, TEXT, bold, Paint.Align.LEFT);
        text(c, "Individual channel levels", channels.right - dp(22), channels.top + dp(40), 13, MUTED, regular, Paint.Align.RIGHT);

        rowY = channels.top + dp(74);
        for (int i = 0; i < 7; i++) {
            rowY = drawChannelSlider(c, rowY, i);
        }
        return channels.bottom + dp(24);
    }

    private float drawSliderRow(Canvas c, float y, String title, String icon, int iconColor,
                                float value, float min, float max, String display,
                                String key, boolean log) {
        float left = contentLeft + dp(24);
        float right = contentRight - dp(24);
        float iconCx = left + dp(29);
        float cy = y + dp(31);
        drawSoftCircle(c, iconCx, cy, dp(26), iconColor, 0.12f);
        drawGlyph(c, icon, iconCx, cy, iconColor);
        text(c, title, left + dp(76), y + dp(24), 17, TEXT, medium, Paint.Align.LEFT);

        float valueW = dp(106);
        RectF valueBox = new RectF(right - valueW, y + dp(5), right, y + dp(53));
        fillRound(c, valueBox, Color.rgb(247, 249, 252), dp(13));
        text(c, display, valueBox.centerX(), valueBox.centerY() + dp(6), 15, TEXT, medium, Paint.Align.CENTER);

        float trackL = left + dp(76);
        float trackR = valueBox.left - dp(24);
        float trackY = y + dp(48);
        drawSlider(c, trackL, trackR, trackY, value, min, max, BLUE, log);
        addSlider(key, new RectF(trackL - dp(8), trackY - dp(23), trackR + dp(8), trackY + dp(23)), min, max, log);

        p.setColor(LINE);
        c.drawRect(left + dp(6), y + dp(76), right - dp(6), y + dp(77), p);
        return y + dp(83);
    }

    private float drawChannelSlider(Canvas c, float y, int ch) {
        float left = contentLeft + dp(24);
        float right = contentRight - dp(24);
        float cy = y + dp(35);
        p.setColor(channelColors[ch]); c.drawCircle(left + dp(27), cy, dp(25), p);
        text(c, Integer.toString(ch + 1), left + dp(27), cy + dp(7), 18, Color.WHITE, bold, Paint.Align.CENTER);
        text(c, "Volume Ch" + (ch + 1), left + dp(79), y + dp(27), 16, TEXT, medium, Paint.Align.LEFT);

        float valueW = dp(106);
        RectF valueBox = new RectF(right - valueW, y + dp(8), right, y + dp(57));
        fillRound(c, valueBox, Color.rgb(247, 249, 252), dp(13));
        text(c, formatDb(channelVolume[ch]), valueBox.centerX(), valueBox.centerY() + dp(6), 15, TEXT, medium, Paint.Align.CENTER);

        float trackL = left + dp(79);
        float trackR = valueBox.left - dp(24);
        float trackY = y + dp(50);
        drawSlider(c, trackL, trackR, trackY, channelVolume[ch], -20f, 6f, BLUE, false);
        addSlider("ch:" + ch, new RectF(trackL - dp(8), trackY - dp(22), trackR + dp(8), trackY + dp(22)), -20f, 6f, false);
        if (ch < 6) {
            p.setColor(LINE);
            c.drawRect(left + dp(6), y + dp(79), right - dp(6), y + dp(80), p);
        }
        return y + dp(83);
    }

    private float drawEq(Canvas c) {
        float y = drawHeader(c, "Eq", "15-band equalizer");
        float gap = dp(8);
        float tabW = (contentWidth - gap * 6f) / 7f;
        float tabH = dp(50);
        for (int i = 0; i < 7; i++) {
            RectF t = new RectF(contentLeft + i * (tabW + gap), y, contentLeft + i * (tabW + gap) + tabW, y + tabH);
            fillRound(c, t, i == selectedChannel ? BLUE : Color.rgb(248, 250, 253), dp(22));
            if (i != selectedChannel) strokeRound(c, t, LINE, dp(22), dp(1));
            text(c, "Ch" + (i + 1), t.centerX(), t.centerY() + dp(6), 14,
                    i == selectedChannel ? Color.WHITE : MUTED, medium, Paint.Align.CENTER);
            addClick("eqch:" + i, t);
        }

        y += tabH + dp(20);
        RectF chartCard = new RectF(contentLeft, y, contentRight, y + dp(426));
        drawShadowCard(c, chartCard, CARD, dp(28));
        text(c, "Channel " + (selectedChannel + 1), chartCard.left + dp(22), chartCard.top + dp(41), 22, TEXT, bold, Paint.Align.LEFT);
        text(c, channelName(selectedChannel) + "  •  15-band EQ", chartCard.left + dp(22), chartCard.top + dp(65), 14, MUTED, regular, Paint.Align.LEFT);
        RectF reset = new RectF(chartCard.right - dp(150), chartCard.top + dp(18), chartCard.right - dp(18), chartCard.top + dp(64));
        fillRound(c, reset, Color.rgb(246, 249, 253), dp(18));
        drawReset(c, reset.left + dp(27), reset.centerY(), MUTED);
        text(c, "Reset EQ", reset.centerX() + dp(12), reset.centerY() + dp(6), 14, MUTED, medium, Paint.Align.CENTER);
        addClick("resetEq", reset);

        RectF plot = new RectF(chartCard.left + dp(58), chartCard.top + dp(100), chartCard.right - dp(24), chartCard.bottom - dp(52));
        drawEqGraph(c, plot);
        addSlider("chart", plot, 0f, 1f, false);

        y = chartCard.bottom + dp(22);
        RectF bandCard = new RectF(contentLeft, y, contentRight, y + dp(398));
        drawShadowCard(c, bandCard, CARD, dp(28));
        drawSoftCircle(c, bandCard.left + dp(53), bandCard.top + dp(51), dp(28), BLUE, 0.09f);
        text(c, Integer.toString(selectedBand + 1), bandCard.left + dp(53), bandCard.top + dp(58), 20, BLUE, bold, Paint.Align.CENTER);
        text(c, "Band " + (selectedBand + 1), bandCard.left + dp(105), bandCard.top + dp(42), 19, TEXT, bold, Paint.Align.LEFT);
        text(c, "Adjust the selected band parameters", bandCard.left + dp(105), bandCard.top + dp(65), 13, MUTED, regular, Paint.Align.LEFT);

        RectF prev = new RectF(bandCard.right - dp(130), bandCard.top + dp(20), bandCard.right - dp(76), bandCard.top + dp(74));
        RectF next = new RectF(bandCard.right - dp(66), bandCard.top + dp(20), bandCard.right - dp(12), bandCard.top + dp(74));
        fillRound(c, prev, Color.rgb(247, 249, 253), dp(27));
        fillRound(c, next, Color.rgb(247, 249, 253), dp(27));
        drawChevronDirection(c, prev.centerX(), prev.centerY(), TEXT, false);
        drawChevronDirection(c, next.centerX(), next.centerY(), TEXT, true);
        addClick("prevBand", prev);
        addClick("nextBand", next);

        float row = bandCard.top + dp(105);
        row = drawEqControl(c, bandCard, row, "Frequency", "freq", BLUE,
                eqFreq[selectedChannel][selectedBand], 20f, 20000f, formatHz(eqFreq[selectedChannel][selectedBand]), true,
                "20 Hz", "20 kHz");
        row = drawEqControl(c, bandCard, row, "Q (Quality Factor)", "q", BLUE,
                eqQ[selectedChannel][selectedBand], 0.1f, 10f, formatOne(eqQ[selectedChannel][selectedBand]), true,
                "0.1", "10.0");
        drawEqControl(c, bandCard, row, "Ch Volume", "gain", BLUE,
                eqGain[selectedChannel][selectedBand], -12f, 12f, formatSignedDb(eqGain[selectedChannel][selectedBand]), false,
                "-12 dB", "+12 dB");

        y = bandCard.bottom + dp(22);
        RectF presetCard = new RectF(contentLeft, y, contentRight, y + dp(260));
        drawShadowCard(c, presetCard, CARD, dp(28));
        drawSoftCircle(c, presetCard.left + dp(50), presetCard.top + dp(48), dp(26), CYAN, 0.12f);
        drawGlyph(c, "preset", presetCard.left + dp(50), presetCard.top + dp(48), CYAN);
        text(c, "Presets", presetCard.left + dp(94), presetCard.top + dp(42), 19, TEXT, bold, Paint.Align.LEFT);
        text(c, "Save and load EQ presets", presetCard.left + dp(94), presetCard.top + dp(64), 13, MUTED, regular, Paint.Align.LEFT);
        circleButton(c, presetCard.right - dp(30), presetCard.top + dp(42), dp(18), "smallmenu", "presetMenu");

        float innerL = presetCard.left + dp(22);
        float innerR = presetCard.right - dp(22);
        RectF nameBox = new RectF(innerL, presetCard.top + dp(90), innerR - dp(180), presetCard.top + dp(144));
        strokeRound(c, nameBox, LINE, dp(14), dp(1));
        text(c, "Preset name", nameBox.left + dp(14), nameBox.centerY() + dp(6), 14, Color.rgb(149, 159, 177), regular, Paint.Align.LEFT);
        addClick("savePreset", nameBox);
        RectF save = new RectF(nameBox.right + dp(14), nameBox.top, innerR, nameBox.bottom);
        fillRound(c, save, BLUE, dp(14));
        drawSave(c, save.left + dp(28), save.centerY(), Color.WHITE);
        text(c, "Save Preset", save.centerX() + dp(14), save.centerY() + dp(6), 14, Color.WHITE, medium, Paint.Align.CENTER);
        addClick("savePreset", save);

        text(c, "Load Preset", innerL, presetCard.top + dp(172), 13, MUTED, regular, Paint.Align.LEFT);
        RectF choose = new RectF(innerL, presetCard.top + dp(184), innerR - dp(180), presetCard.top + dp(238));
        strokeRound(c, choose, LINE, dp(14), dp(1));
        text(c, lastPreset, choose.left + dp(14), choose.centerY() + dp(6), 14, TEXT, regular, Paint.Align.LEFT);
        drawChevronDown(c, choose.right - dp(24), choose.centerY(), MUTED);
        addClick("loadPreset", choose);
        RectF load = new RectF(choose.right + dp(14), choose.top, innerR, choose.bottom);
        fillRound(c, load, Color.rgb(244, 247, 251), dp(14));
        drawFolder(c, load.left + dp(30), load.centerY(), MUTED);
        text(c, "Load", load.centerX() + dp(14), load.centerY() + dp(6), 14, MUTED, medium, Paint.Align.CENTER);
        addClick("loadPreset", load);

        return presetCard.bottom + dp(24);
    }

    private float drawEqControl(Canvas c, RectF card, float y, String title, String key, int color,
                                float value, float min, float max, String display, boolean log,
                                String leftLabel, String rightLabel) {
        float left = card.left + dp(28);
        float right = card.right - dp(28);
        drawSoftCircle(c, left + dp(19), y + dp(22), dp(20), color, 0.09f);
        if ("q".equals(key)) {
            text(c, "Q", left + dp(19), y + dp(29), 15, MUTED, bold, Paint.Align.CENTER);
        } else if ("freq".equals(key)) {
            drawWave(c, left + dp(19), y + dp(22), MUTED);
        } else {
            drawSpeaker(c, left + dp(19), y + dp(22), MUTED);
        }
        text(c, title, left + dp(55), y + dp(20), 15, TEXT, medium, Paint.Align.LEFT);
        RectF val = new RectF(right - dp(116), y - dp(2), right, y + dp(38));
        fillRound(c, val, Color.rgb(247, 249, 252), dp(14));
        text(c, display, val.centerX(), val.centerY() + dp(6), 14, TEXT, medium, Paint.Align.CENTER);

        float trackL = left + dp(55);
        float trackR = right;
        float trackY = y + dp(54);
        drawSlider(c, trackL, trackR, trackY, value, min, max, color, log);
        addSlider(key, new RectF(trackL - dp(8), trackY - dp(22), trackR + dp(8), trackY + dp(22)), min, max, log);
        text(c, leftLabel, trackL, y + dp(82), 12, MUTED, regular, Paint.Align.LEFT);
        text(c, rightLabel, trackR, y + dp(82), 12, MUTED, regular, Paint.Align.RIGHT);
        return y + dp(96);
    }

    private void drawEqGraph(Canvas c, RectF plot) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.rgb(252, 253, 255));
        c.drawRect(plot, p);

        for (int i = 0; i <= 4; i++) {
            float yy = plot.top + i * plot.height() / 4f;
            p.setColor(LINE); p.setStrokeWidth(dp(1));
            c.drawLine(plot.left, yy, plot.right, yy, p);
            int db = 12 - i * 6;
            text(c, (db > 0 ? "+" : "") + db, plot.left - dp(14), yy + dp(4), 11, MUTED, regular, Paint.Align.RIGHT);
        }

        float[] axisFreq = {20f, 50f, 100f, 200f, 500f, 1000f, 2000f, 5000f, 10000f, 20000f};
        String[] axisLabel = {"20", "50", "100", "200", "500", "1K", "2K", "5K", "10K", "20K"};
        for (int i = 0; i < axisFreq.length; i++) {
            float xx = freqToX(axisFreq[i], plot);
            p.setColor(Color.rgb(236, 240, 246)); p.setStrokeWidth(dp(1));
            c.drawLine(xx, plot.top, xx, plot.bottom, p);
            text(c, axisLabel[i], xx, plot.bottom + dp(22), 10, MUTED, regular, Paint.Align.CENTER);
        }
        text(c, "(dB)", plot.left - dp(13), plot.bottom + dp(22), 10, MUTED, regular, Paint.Align.RIGHT);
        text(c, "(Hz)", plot.right, plot.bottom + dp(41), 10, MUTED, regular, Paint.Align.RIGHT);

        float f = eqFreq[selectedChannel][selectedBand];
        float q = eqQ[selectedChannel][selectedBand];
        double octHalf = 1.0 / Math.max(0.2, 2.0 * q);
        float lf = (float) (f / Math.pow(2.0, octHalf));
        float rf = (float) (f * Math.pow(2.0, octHalf));
        float hl = freqToX(Math.max(20f, lf), plot);
        float hr = freqToX(Math.min(20000f, rf), plot);
        Paint band = new Paint(Paint.ANTI_ALIAS_FLAG);
        band.setShader(new LinearGradient(hl, 0, hr, 0,
                new int[]{Color.argb(5, 10, 143, 255), Color.argb(43, 10, 143, 255), Color.argb(5, 10, 143, 255)},
                new float[]{0f, .5f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(hl, plot.top, hr, plot.bottom, band);

        int[] order = new int[15];
        for (int i = 0; i < 15; i++) order[i] = i;
        for (int i = 1; i < 15; i++) {
            int v = order[i];
            int j = i - 1;
            while (j >= 0 && eqFreq[selectedChannel][order[j]] > eqFreq[selectedChannel][v]) {
                order[j + 1] = order[j];
                j--;
            }
            order[j + 1] = v;
        }

        path.reset();
        for (int n = 0; n < 15; n++) {
            int b = order[n];
            float xx = freqToX(eqFreq[selectedChannel][b], plot);
            float yy = gainToY(eqGain[selectedChannel][b], plot);
            if (n == 0) path.moveTo(xx, yy);
            else path.lineTo(xx, yy);
        }
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2)); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeJoin(Paint.Join.ROUND); p.setColor(BLUE);
        c.drawPath(path, p);
        p.setStyle(Paint.Style.FILL);

        for (int b = 0; b < 15; b++) {
            float xx = freqToX(eqFreq[selectedChannel][b], plot);
            float yy = gainToY(eqGain[selectedChannel][b], plot);
            if (b == selectedBand) {
                p.setColor(Color.WHITE); c.drawCircle(xx, yy, dp(10), p);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(3)); p.setColor(BLUE); c.drawCircle(xx, yy, dp(10), p); p.setStyle(Paint.Style.FILL);
            } else {
                p.setColor(BLUE); c.drawCircle(xx, yy, dp(6.5f), p);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.4f)); p.setColor(Color.WHITE); c.drawCircle(xx, yy, dp(6.5f), p); p.setStyle(Paint.Style.FILL);
            }
        }
    }

    private void drawBottomNav(Canvas c, float top, float height) {
        float x = contentLeft;
        RectF nav = new RectF(x, top, contentRight, top + height);
        drawShadowCard(c, nav, Color.WHITE, dp(28));
        float itemW = nav.width() / 3f;
        String[] labels = {"Home", "Mix", "Eq"};
        for (int i = 0; i < 3; i++) {
            float cx = nav.left + itemW * (i + .5f);
            boolean on = page == i;
            if (on) {
                RectF pill = new RectF(cx - itemW * .38f, nav.top + dp(9), cx + itemW * .38f, nav.top + dp(57));
                fillRound(c, pill, Color.rgb(234, 244, 255), dp(22));
            }
            int color = on ? BLUE : MUTED;
            if (i == 0) drawHomeIcon(c, cx, nav.top + dp(33), color);
            else if (i == 1) drawMixIcon(c, cx, nav.top + dp(33), color);
            else drawEqIcon(c, cx, nav.top + dp(33), color);
            text(c, labels[i], cx, nav.top + dp(76), 14, color, on ? medium : regular, Paint.Align.CENTER);
            addRawClick("nav:" + i, new RectF(nav.left + itemW * i, nav.top, nav.left + itemW * (i + 1), nav.bottom));
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX();
        float y = event.getY();
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = x;
                downY = y;
                startScroll = scrollY;
                activeHit = findHit(x, y, true);
                pendingClick = activeHit == null ? findHit(x, y, false) : null;
                scrolling = activeHit == null && pendingClick == null && y < navTop;
                if (activeHit != null) {
                    if ("chart".equals(activeHit.key)) selectNearestBandFromChart(x, activeHit.rect);
                    updateSlider(activeHit, x, y);
                    getParent().requestDisallowInterceptTouchEvent(true);
                }
                return true;

            case MotionEvent.ACTION_MOVE:
                if (activeHit != null) {
                    updateSlider(activeHit, x, y);
                    return true;
                }
                if (pendingClick != null) {
                    if (Math.hypot(x - downX, y - downY) > touchSlop) {
                        pendingClick = null;
                        scrolling = y < navTop;
                    }
                }
                if (scrolling) {
                    scrollY = clamp(startScroll + (downY - y), 0f, maxScroll);
                    invalidate();
                    return true;
                }
                return true;

            case MotionEvent.ACTION_UP:
                if (activeHit != null) {
                    updateSlider(activeHit, x, y);
                    activeHit = null;
                    getParent().requestDisallowInterceptTouchEvent(false);
                    performClick();
                    return true;
                }
                if (pendingClick != null && pendingClick.rect.contains(x, y)) {
                    String key = pendingClick.key;
                    pendingClick = null;
                    performAction(key);
                    performClick();
                    return true;
                }
                pendingClick = null;
                scrolling = false;
                performClick();
                return true;

            case MotionEvent.ACTION_CANCEL:
                activeHit = null;
                pendingClick = null;
                scrolling = false;
                getParent().requestDisallowInterceptTouchEvent(false);
                return true;
            default:
                return super.onTouchEvent(event);
        }
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    private Hit findHit(float x, float y, boolean slider) {
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (h.slider == slider && h.rect.contains(x, y)) return h;
        }
        return null;
    }

    private void updateSlider(Hit h, float x, float y) {
        if ("chart".equals(h.key)) {
            float t = clamp((x - h.rect.left) / h.rect.width(), 0f, 1f);
            double logMin = Math.log10(20.0);
            double logMax = Math.log10(20000.0);
            float freq = (float) Math.pow(10.0, logMin + t * (logMax - logMin));
            float gy = clamp((y - h.rect.top) / h.rect.height(), 0f, 1f);
            float gain = 12f - gy * 24f;
            eqFreq[selectedChannel][selectedBand] = quantizeFrequency(freq);
            eqGain[selectedChannel][selectedBand] = quantize(gain, 0.1f);
            invalidate();
            return;
        }

        float t = clamp((x - h.rect.left) / h.rect.width(), 0f, 1f);
        float value;
        if (h.log) {
            double lo = Math.log10(h.min);
            double hi = Math.log10(h.max);
            value = (float) Math.pow(10.0, lo + t * (hi - lo));
        } else {
            value = h.min + t * (h.max - h.min);
        }

        if ("master".equals(h.key)) masterVolume = quantize(value, 1f);
        else if ("bass".equals(h.key)) bassVolume = quantize(value, 0.5f);
        else if ("cutoff".equals(h.key)) bassCutoff = quantize(value, 1f);
        else if (h.key.startsWith("ch:")) {
            int ch = Integer.parseInt(h.key.substring(3));
            channelVolume[ch] = quantize(value, 0.5f);
        } else if ("freq".equals(h.key)) {
            eqFreq[selectedChannel][selectedBand] = quantizeFrequency(value);
        } else if ("q".equals(h.key)) {
            eqQ[selectedChannel][selectedBand] = clamp(quantize(value, 0.1f), 0.1f, 10f);
        } else if ("gain".equals(h.key)) {
            eqGain[selectedChannel][selectedBand] = quantize(value, 0.1f);
        }
        invalidate();
    }

    private void selectNearestBandFromChart(float x, RectF plotScreen) {
        float best = Float.MAX_VALUE;
        int bestBand = selectedBand;
        for (int b = 0; b < 15; b++) {
            float sx = plotScreen.left + (float) ((Math.log10(eqFreq[selectedChannel][b]) - Math.log10(20.0)) /
                    (Math.log10(20000.0) - Math.log10(20.0))) * plotScreen.width();
            float d = Math.abs(sx - x);
            if (d < best) {
                best = d;
                bestBand = b;
            }
        }
        selectedBand = bestBand;
    }

    private void performAction(String key) {
        if (key.startsWith("nav:")) {
            page = Integer.parseInt(key.substring(4));
            scrollY = 0f;
            invalidate();
            return;
        }
        if (key.startsWith("eqch:")) {
            selectedChannel = Integer.parseInt(key.substring(5));
            selectedBand = Math.min(selectedBand, 14);
            invalidate();
            return;
        }
        if (key.startsWith("status:")) {
            String title = key.substring(7);
            showStatusDialog(title);
            return;
        }
        switch (key) {
            case "search":
                new AlertDialog.Builder(getContext())
                        .setTitle("Search / Device Scan")
                        .setMessage("Version 1 is Phase 1 UI. The button is active, while real BLE/DSP discovery will be connected in Phase 2 using your protocol files.")
                        .setPositiveButton("OK", null)
                        .show();
                break;
            case "menu":
                showMainMenu();
                break;
            case "quick":
                page = PAGE_MIX;
                scrollY = 0f;
                invalidate();
                break;
            case "resetEq":
                Arrays.fill(eqGain[selectedChannel], 0f);
                for (int i = 0; i < 15; i++) {
                    eqFreq[selectedChannel][i] = defaultFreqs[i];
                    eqQ[selectedChannel][i] = 1f;
                }
                selectedBand = 4;
                Toast.makeText(getContext(), "Channel " + (selectedChannel + 1) + " EQ reset", Toast.LENGTH_SHORT).show();
                invalidate();
                break;
            case "prevBand":
                selectedBand = (selectedBand + 14) % 15;
                invalidate();
                break;
            case "nextBand":
                selectedBand = (selectedBand + 1) % 15;
                invalidate();
                break;
            case "savePreset":
                promptSavePreset();
                break;
            case "loadPreset":
            case "presetMenu":
                showPresetPicker();
                break;
            case "smallmenu":
                showPresetPicker();
                break;
            default:
                break;
        }
    }

    private void showStatusDialog(String title) {
        String message;
        switch (title) {
            case "Bluetooth": message = "UI state: Connected. Real Bluetooth transport is scheduled for Phase 2."; break;
            case "DSP Device": message = "UI state: OKN DSP-8 Pro. Device identification will use the Phase 2 protocol implementation."; break;
            case "Audio Input": message = "UI state: AUX (Analog) is active."; break;
            case "Amplifier Link": message = "UI state: External Amplifier connected."; break;
            case "Preset Sync": message = "Local Phase 1 preset controls are ready."; break;
            case "Firmware Status": message = "OKN DSP rebuild Version 1.0.0 — Phase 1 UI."; break;
            default: message = "All Phase 1 UI components are ready. DSP communication is intentionally deferred to Phase 2."; break;
        }
        new AlertDialog.Builder(getContext()).setTitle(title).setMessage(message).setPositiveButton("OK", null).show();
    }

    private void showMainMenu() {
        String[] items = {"About Version 1", "Reset UI values"};
        new AlertDialog.Builder(getContext())
                .setTitle("OKN DSP")
                .setItems(items, (dialog, which) -> {
                    if (which == 0) {
                        new AlertDialog.Builder(getContext())
                                .setTitle("OKN DSP Version 1")
                                .setMessage("Phase 1 UI rebuild\nNative Android Canvas UI\nNo screenshot background\nDSP/BLE control will be added in Phase 2.")
                                .setPositiveButton("OK", null).show();
                    } else {
                        resetAllUiState();
                        Toast.makeText(getContext(), "UI values reset", Toast.LENGTH_SHORT).show();
                    }
                }).show();
    }

    private void resetAllUiState() {
        masterVolume = -6f;
        bassVolume = 2f;
        bassCutoff = 80f;
        float[] vols = {-3f, -6f, -2f, -8f, 0f, -4f, -10f};
        System.arraycopy(vols, 0, channelVolume, 0, 7);
        for (int ch = 0; ch < 7; ch++) {
            for (int b = 0; b < 15; b++) {
                eqFreq[ch][b] = defaultFreqs[b];
                eqQ[ch][b] = 1f;
                eqGain[ch][b] = ch == 0 ? demoCurve[b] : 0f;
            }
        }
        selectedChannel = 0;
        selectedBand = 4;
        lastPreset = "Flat";
        invalidate();
    }

    private void promptSavePreset() {
        EditText input = new EditText(getContext());
        input.setSingleLine(true);
        input.setHint("Preset name");
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        int pad = (int) dp(18);
        input.setPadding(pad, pad / 2, pad, pad / 2);
        new AlertDialog.Builder(getContext())
                .setTitle("Save EQ Preset")
                .setView(input)
                .setPositiveButton("Save", (d, w) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) name = "Custom " + (presets.size() + 1);
                    presets.put(name, new Preset(eqFreq, eqQ, eqGain));
                    lastPreset = name;
                    Toast.makeText(getContext(), "Saved: " + name, Toast.LENGTH_SHORT).show();
                    invalidate();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showPresetPicker() {
        String[] names = presets.keySet().toArray(new String[0]);
        new AlertDialog.Builder(getContext())
                .setTitle("Load EQ Preset")
                .setItems(names, (dialog, which) -> {
                    String name = names[which];
                    Preset preset = presets.get(name);
                    if (preset != null) {
                        preset.apply(eqFreq, eqQ, eqGain);
                        lastPreset = name;
                        Toast.makeText(getContext(), "Loaded: " + name, Toast.LENGTH_SHORT).show();
                        invalidate();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void createBuiltInPresets() {
        presets.put("Flat", new Preset(7, defaultFreqs, null));
        float[] bassBoost = {4, 4, 3.5f, 3, 2, 1, 0, 0, 0, 0, 0, -0.5f, -1, -1, -1};
        float[] vocal = {-2, -2, -1.5f, -1, 0, 1, 2, 2.5f, 3, 2.5f, 2, 1, 0, -0.5f, -1};
        presets.put("Bass Boost", new Preset(7, defaultFreqs, bassBoost));
        presets.put("Vocal", new Preset(7, defaultFreqs, vocal));
    }

    private void addClick(String key, RectF contentRect) {
        RectF r = new RectF(contentRect.left, contentRect.top - scrollY, contentRect.right, contentRect.bottom - scrollY);
        hits.add(new Hit(key, r, false, 0, 0, false));
    }

    private void addRawClick(String key, RectF screenRect) {
        hits.add(new Hit(key, new RectF(screenRect), false, 0, 0, false));
    }

    private void addSlider(String key, RectF contentRect, float min, float max, boolean log) {
        RectF r = new RectF(contentRect.left, contentRect.top - scrollY, contentRect.right, contentRect.bottom - scrollY);
        hits.add(new Hit(key, r, true, min, max, log));
    }

    private static final class Hit {
        final String key;
        final RectF rect;
        final boolean slider;
        final float min;
        final float max;
        final boolean log;
        Hit(String key, RectF rect, boolean slider, float min, float max, boolean log) {
            this.key = key; this.rect = rect; this.slider = slider; this.min = min; this.max = max; this.log = log;
        }
    }

    private static final class Preset {
        final float[][] f = new float[7][15];
        final float[][] q = new float[7][15];
        final float[][] g = new float[7][15];

        Preset(float[][] srcF, float[][] srcQ, float[][] srcG) {
            for (int ch = 0; ch < 7; ch++) {
                System.arraycopy(srcF[ch], 0, f[ch], 0, 15);
                System.arraycopy(srcQ[ch], 0, q[ch], 0, 15);
                System.arraycopy(srcG[ch], 0, g[ch], 0, 15);
            }
        }

        Preset(int channels, float[] freqs, float[] gains) {
            for (int ch = 0; ch < channels; ch++) {
                for (int b = 0; b < 15; b++) {
                    f[ch][b] = freqs[b];
                    q[ch][b] = 1f;
                    g[ch][b] = gains == null ? 0f : gains[b];
                }
            }
        }

        void apply(float[][] dstF, float[][] dstQ, float[][] dstG) {
            for (int ch = 0; ch < 7; ch++) {
                System.arraycopy(f[ch], 0, dstF[ch], 0, 15);
                System.arraycopy(q[ch], 0, dstQ[ch], 0, 15);
                System.arraycopy(g[ch], 0, dstG[ch], 0, 15);
            }
        }
    }

    private void drawSlider(Canvas c, float left, float right, float y, float value, float min, float max, int color, boolean log) {
        float t;
        if (log) {
            t = (float) ((Math.log10(Math.max(min, value)) - Math.log10(min)) / (Math.log10(max) - Math.log10(min)));
        } else {
            t = (value - min) / (max - min);
        }
        t = clamp(t, 0f, 1f);
        float knobX = left + t * (right - left);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(dp(6));
        p.setColor(TRACK); c.drawLine(left, y, right, y, p);
        p.setColor(color); c.drawLine(left, y, knobX, y, p);
        p.setStyle(Paint.Style.FILL); p.setColor(Color.argb(40, 0, 0, 0)); c.drawCircle(knobX, y + dp(1.5f), dp(13), p);
        p.setColor(Color.WHITE); c.drawCircle(knobX, y, dp(11), p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1)); p.setColor(Color.rgb(219, 226, 235)); c.drawCircle(knobX, y, dp(11), p); p.setStyle(Paint.Style.FILL);
        p.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawShadowCard(Canvas c, RectF r, int color, float radius) {
        RectF shadow = new RectF(r.left, r.top + dp(3), r.right, r.bottom + dp(5));
        fillRound(c, shadow, Color.argb(18, 49, 78, 112), radius);
        fillRound(c, r, color, radius);
    }

    private void fillRound(Canvas c, RectF r, int color, float radius) {
        p.setStyle(Paint.Style.FILL); p.setColor(color); p.setShader(null); c.drawRoundRect(r, radius, radius, p);
    }

    private void strokeRound(Canvas c, RectF r, int color, float radius, float width) {
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(width); p.setColor(color); p.setShader(null); c.drawRoundRect(r, radius, radius, p); p.setStyle(Paint.Style.FILL);
    }

    private void text(Canvas c, String s, float x, float baseline, float sizeSp, int color, Typeface face, Paint.Align align) {
        p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(color); p.setTypeface(face); p.setTextSize(sp(sizeSp)); p.setTextAlign(align);
        c.drawText(s, x, baseline, p);
    }

    private void drawSoftCircle(Canvas c, float cx, float cy, float r, int color, float alpha) {
        int a = Math.round(255f * alpha);
        p.setColor(Color.argb(a, Color.red(color), Color.green(color), Color.blue(color)));
        p.setStyle(Paint.Style.FILL);
        c.drawCircle(cx, cy, r, p);
    }

    private void circleButton(Canvas c, float cx, float cy, float r, String icon, String key) {
        RectF rr = new RectF(cx-r, cy-r, cx+r, cy+r);
        fillRound(c, rr, Color.rgb(244, 247, 251), r);
        if ("search".equals(icon)) drawSearch(c, cx, cy, TEXT);
        else if ("menu".equals(icon) || "smallmenu".equals(icon)) drawDots(c, cx, cy, MUTED);
        if (key != null) addClick(key, rr);
    }

    private void drawGlyph(Canvas c, String type, float cx, float cy, int color) {
        switch (type) {
            case "speaker": drawSpeaker(c, cx, cy, color); break;
            case "wave": drawWave(c, cx, cy, color); break;
            case "preset": drawPreset(c, cx, cy, color); break;
            case "gear": drawGear(c, cx, cy, color); break;
            case "funnel": drawFunnel(c, cx, cy, color); break;
            case "bluetooth": drawBluetooth(c, cx, cy, color); break;
            case "chip": drawChip(c, cx, cy, color); break;
            default: drawMiniEq(c, cx, cy, color); break;
        }
    }

    private void drawSearch(Canvas c, float cx, float cy, int color) {
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2.4f)); p.setColor(color);
        c.drawCircle(cx - dp(3), cy - dp(3), dp(9), p);
        c.drawLine(cx + dp(4), cy + dp(4), cx + dp(11), cy + dp(11), p);
        p.setStyle(Paint.Style.FILL);
    }

    private void drawDots(Canvas c, float cx, float cy, int color) {
        p.setColor(color); for (int i=-1; i<=1; i++) c.drawCircle(cx, cy + i*dp(8), dp(2.1f), p);
    }

    private void drawCheck(Canvas c, float cx, float cy, int color, float width) {
        p.setStyle(Paint.Style.STROKE); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeJoin(Paint.Join.ROUND); p.setStrokeWidth(width); p.setColor(color);
        path.reset(); path.moveTo(cx-dp(10), cy); path.lineTo(cx-dp(2), cy+dp(8)); path.lineTo(cx+dp(13), cy-dp(9)); c.drawPath(path, p);
        p.setStyle(Paint.Style.FILL); p.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawChevron(Canvas c, float cx, float cy, int color) { drawChevronDirection(c, cx, cy, color, true); }

    private void drawChevronDirection(Canvas c, float cx, float cy, int color, boolean right) {
        float s = right ? 1f : -1f;
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2.3f)); p.setStrokeCap(Paint.Cap.ROUND); p.setColor(color);
        c.drawLine(cx - s*dp(4), cy-dp(8), cx + s*dp(4), cy, p);
        c.drawLine(cx + s*dp(4), cy, cx - s*dp(4), cy+dp(8), p);
        p.setStyle(Paint.Style.FILL); p.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawChevronDown(Canvas c, float cx, float cy, int color) {
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2)); p.setStrokeCap(Paint.Cap.ROUND); p.setColor(color);
        c.drawLine(cx-dp(6), cy-dp(3), cx, cy+dp(3), p); c.drawLine(cx, cy+dp(3), cx+dp(6), cy-dp(3), p);
        p.setStyle(Paint.Style.FILL); p.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawSpeaker(Canvas c, float cx, float cy, int color) {
        p.setColor(color); p.setStyle(Paint.Style.FILL);
        path.reset(); path.moveTo(cx-dp(11), cy-dp(5)); path.lineTo(cx-dp(5), cy-dp(5)); path.lineTo(cx+dp(3), cy-dp(12)); path.lineTo(cx+dp(3), cy+dp(12)); path.lineTo(cx-dp(5), cy+dp(5)); path.lineTo(cx-dp(11), cy+dp(5)); path.close(); c.drawPath(path, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2)); p.setStrokeCap(Paint.Cap.ROUND);
        c.drawArc(new RectF(cx-dp(1), cy-dp(9), cx+dp(12), cy+dp(9)), -48, 96, false, p);
        c.drawArc(new RectF(cx+dp(1), cy-dp(13), cx+dp(17), cy+dp(13)), -48, 96, false, p);
        p.setStyle(Paint.Style.FILL); p.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawWave(Canvas c, float cx, float cy, int color) {
        p.setColor(color); p.setStrokeWidth(dp(2.8f)); p.setStrokeCap(Paint.Cap.ROUND);
        float[] hs = {7, 13, 19, 12, 7};
        for (int i = 0; i < 5; i++) {
            float x = cx + (i-2)*dp(5);
            c.drawLine(x, cy-dp(hs[i]/2), x, cy+dp(hs[i]/2), p);
        }
        p.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawMiniEq(Canvas c, float cx, float cy, int color) {
        p.setColor(color); p.setStrokeWidth(dp(3)); p.setStrokeCap(Paint.Cap.ROUND);
        c.drawLine(cx-dp(10), cy+dp(9), cx-dp(10), cy-dp(3), p);
        c.drawLine(cx, cy+dp(9), cx, cy-dp(12), p);
        c.drawLine(cx+dp(10), cy+dp(9), cx+dp(10), cy-dp(7), p);
        p.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawPreset(Canvas c, float cx, float cy, int color) {
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2)); p.setColor(color);
        RectF r = new RectF(cx-dp(9), cy-dp(12), cx+dp(9), cy+dp(12)); c.drawRoundRect(r, dp(2), dp(2), p);
        c.drawLine(cx-dp(5), cy-dp(6), cx+dp(5), cy-dp(6), p); c.drawLine(cx-dp(5), cy, cx+dp(4), cy, p); c.drawLine(cx-dp(5), cy+dp(6), cx+dp(2), cy+dp(6), p);
        p.setStyle(Paint.Style.FILL);
    }

    private void drawGear(Canvas c, float cx, float cy, int color) {
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(3)); p.setColor(color); c.drawCircle(cx, cy, dp(8), p); c.drawCircle(cx, cy, dp(2.5f), p);
        for (int i=0;i<8;i++) { double a=i*Math.PI/4; float x1=cx+(float)Math.cos(a)*dp(9); float y1=cy+(float)Math.sin(a)*dp(9); float x2=cx+(float)Math.cos(a)*dp(13); float y2=cy+(float)Math.sin(a)*dp(13); c.drawLine(x1,y1,x2,y2,p); }
        p.setStyle(Paint.Style.FILL);
    }

    private void drawFunnel(Canvas c, float cx, float cy, int color) {
        p.setColor(color); path.reset(); path.moveTo(cx-dp(12),cy-dp(10)); path.lineTo(cx+dp(12),cy-dp(10)); path.lineTo(cx+dp(4),cy); path.lineTo(cx+dp(4),cy+dp(9)); path.lineTo(cx-dp(3),cy+dp(13)); path.lineTo(cx-dp(3),cy); path.close(); c.drawPath(path,p);
    }

    private void drawBluetooth(Canvas c, float cx, float cy, int color) {
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2.2f)); p.setColor(color); p.setStrokeCap(Paint.Cap.ROUND);
        path.reset(); path.moveTo(cx,cy-dp(15)); path.lineTo(cx+dp(8),cy-dp(7)); path.lineTo(cx-dp(8),cy+dp(7)); path.lineTo(cx,cy+dp(15)); path.lineTo(cx,cy-dp(15)); path.lineTo(cx-dp(8),cy-dp(7)); path.lineTo(cx+dp(8),cy+dp(7)); c.drawPath(path,p);
        p.setStyle(Paint.Style.FILL); p.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawChip(Canvas c, float cx, float cy, int color) {
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2)); p.setColor(color); RectF r = new RectF(cx-dp(9),cy-dp(9),cx+dp(9),cy+dp(9)); c.drawRoundRect(r,dp(2),dp(2),p);
        for(int i=-1;i<=1;i++){ float o=i*dp(6); c.drawLine(cx-dp(14),cy+o,cx-dp(9),cy+o,p); c.drawLine(cx+dp(9),cy+o,cx+dp(14),cy+o,p); c.drawLine(cx+o,cy-dp(14),cx+o,cy-dp(9),p); c.drawLine(cx+o,cy+dp(9),cx+o,cy+dp(14),p); }
        p.setStyle(Paint.Style.FILL);
    }

    private void drawReset(Canvas c, float cx, float cy, int color) {
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2)); p.setStrokeCap(Paint.Cap.ROUND); p.setColor(color);
        c.drawArc(new RectF(cx-dp(8),cy-dp(8),cx+dp(8),cy+dp(8)),-70,285,false,p);
        path.reset(); path.moveTo(cx-dp(9),cy-dp(8)); path.lineTo(cx-dp(2),cy-dp(9)); path.lineTo(cx-dp(5),cy-dp(2)); c.drawPath(path,p);
        p.setStyle(Paint.Style.FILL); p.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawSave(Canvas c, float cx, float cy, int color) {
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2)); p.setColor(color); RectF r=new RectF(cx-dp(9),cy-dp(10),cx+dp(9),cy+dp(10)); c.drawRoundRect(r,dp(2),dp(2),p); c.drawRect(cx-dp(5),cy-dp(8),cx+dp(4),cy-dp(2),p); c.drawRect(cx-dp(5),cy+dp(2),cx+dp(5),cy+dp(8),p); p.setStyle(Paint.Style.FILL);
    }

    private void drawFolder(Canvas c, float cx, float cy, int color) {
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2)); p.setColor(color); path.reset(); path.moveTo(cx-dp(11),cy-dp(8)); path.lineTo(cx-dp(2),cy-dp(8)); path.lineTo(cx+dp(1),cy-dp(4)); path.lineTo(cx+dp(11),cy-dp(4)); path.lineTo(cx+dp(11),cy+dp(8)); path.lineTo(cx-dp(11),cy+dp(8)); path.close(); c.drawPath(path,p); p.setStyle(Paint.Style.FILL);
    }

    private void drawHomeIcon(Canvas c, float cx, float cy, int color) {
        p.setColor(color); path.reset(); path.moveTo(cx-dp(12),cy); path.lineTo(cx,cy-dp(11)); path.lineTo(cx+dp(12),cy); path.lineTo(cx+dp(9),cy); path.lineTo(cx+dp(9),cy+dp(11)); path.lineTo(cx-dp(9),cy+dp(11)); path.lineTo(cx-dp(9),cy); path.close(); c.drawPath(path,p);
    }

    private void drawMixIcon(Canvas c, float cx, float cy, int color) {
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2.2f)); p.setColor(color); p.setStrokeCap(Paint.Cap.ROUND);
        float[] xs={cx-dp(10),cx,cx+dp(10)}; float[] knobs={cy-dp(6),cy+dp(7),cy-dp(1)};
        for(int i=0;i<3;i++){ c.drawLine(xs[i],cy-dp(13),xs[i],cy+dp(13),p); p.setStyle(Paint.Style.FILL); c.drawCircle(xs[i],knobs[i],dp(3),p); p.setStyle(Paint.Style.STROKE); }
        p.setStyle(Paint.Style.FILL); p.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawEqIcon(Canvas c, float cx, float cy, int color) {
        p.setColor(color); p.setStrokeWidth(dp(3)); p.setStrokeCap(Paint.Cap.ROUND);
        c.drawLine(cx-dp(11),cy+dp(10),cx-dp(11),cy-dp(1),p); c.drawLine(cx,cy+dp(10),cx,cy-dp(12),p); c.drawLine(cx+dp(11),cy+dp(10),cx+dp(11),cy-dp(6),p); p.setStrokeCap(Paint.Cap.BUTT);
    }

    private float freqToX(float freq, RectF plot) {
        double t = (Math.log10(clamp(freq, 20f, 20000f)) - Math.log10(20.0)) / (Math.log10(20000.0) - Math.log10(20.0));
        return plot.left + (float)t * plot.width();
    }

    private float gainToY(float gain, RectF plot) {
        float t = (12f - clamp(gain, -12f, 12f)) / 24f;
        return plot.top + t * plot.height();
    }

    private String channelName(int ch) {
        String[] names = {"Front Left", "Front Right", "Rear Left", "Rear Right", "Center", "Subwoofer", "Aux"};
        return names[Math.max(0, Math.min(ch, names.length - 1))];
    }

    private static float clamp(float v, float min, float max) { return Math.max(min, Math.min(max, v)); }
    private static float quantize(float v, float step) { return Math.round(v / step) * step; }

    private static float quantizeFrequency(float v) {
        v = clamp(v, 20f, 20000f);
        float step = v < 100f ? 1f : (v < 1000f ? 5f : (v < 5000f ? 10f : 50f));
        return quantize(v, step);
    }

    private String formatDb(float v) {
        float q = quantize(v, 0.5f);
        if (Math.abs(q - Math.round(q)) < 0.01f) return Math.round(q) + " dB";
        return String.format(Locale.US, "%.1f dB", q);
    }

    private String formatSignedDb(float v) {
        if (Math.abs(v) < 0.05f) return "0.0 dB";
        return String.format(Locale.US, "%+.1f dB", v);
    }

    private String formatOne(float v) { return String.format(Locale.US, "%.1f", v); }

    private String formatHz(float v) {
        if (v >= 1000f) {
            float k = v / 1000f;
            return Math.abs(k - Math.round(k)) < 0.01f ? Math.round(k) + " kHz" : String.format(Locale.US, "%.2g kHz", k);
        }
        return Math.round(v) + " Hz";
    }
}
