# Changelog

## 1.0.0+1
- Reset project numbering and created the production-oriented Flutter scaffold.
- Added responsive design baseline for the five supplied 9:16 UI references.
- Added central DSP state model and core calculations.
- Added CI-ready versioning and SHA-256 support scripts.
