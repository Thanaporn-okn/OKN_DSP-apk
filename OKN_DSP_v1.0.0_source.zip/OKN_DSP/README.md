# OKN DSP Control — Stage 1 Scaffold

Flutter scaffold for a 7-channel DSP control application.

## Design baseline
The supplied references are 864 x 1536 pixels (9:16). The app uses a 432 x 768 logical design canvas and responsive scaling utilities so later screens can preserve proportions on phones and tablets.

## State architecture
- `provider` + `ChangeNotifier`
- Central controller: `lib/state/dsp_controller.dart`
- Immediate `notifyListeners()` updates for sliders, toggles, dropdowns and channel selection.
- UI screens are compile-safe placeholders in Stage 1. The detailed neon UI is implemented screen-by-screen in Stage 2.

## Build model
The source archive intentionally omits native Flutter platform folders so it stays small and easy to upload from a phone.
The GitHub Actions workflow creates Android platform files automatically with `flutter create` before building.

Upload these two items to GitHub:
1. This source ZIP in the repository root.
2. The separate `build.yml` once at `.github/workflows/build.yml`.

After that, future source ZIP pushes trigger builds automatically; the workflow file does not need to be re-uploaded.
