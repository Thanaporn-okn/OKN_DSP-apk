# OKN_BP1048P4_FW_V6

Clean-room replacement firmware foundation for GoloPine / BP1048P4 7CH.

V6 preserves the V5 DSP, persistence, protocol and stream core, then moves the
project from a generic locked HAL to an **evidence-gated hardware port contract**.
The public BP1048-family SDK is now documented as family/toolchain evidence only;
it is not treated as proof that BP1048P4 or the GoloPine board uses identical
startup, memory, audio routing, BLE or flash definitions.

## V6 additions
- explicit BP1048P4 hardware-port evidence ABI
- exact-target + exact-board verification gates
- mandatory output safety-mute HAL boundary
- fail-closed safe boot state machine
- audio starts while safety mute is asserted
- full DSP state is applied before unmute
- any post-mute boot failure re-asserts mute
- host tests verify startup order and failure behavior
- documented public MVsB1 SDK evidence without copying vendor code

## Existing core
- 7 independent channels
- gain / mute / phase / 0-50 ms delay
- 15-band PEQ per channel
- notch / low shelf / high shelf
- HPF / LPF
- CRC-framed OKN Protocol V2
- state readback commands
- BLE-like fragmented stream reassembly and resync
- portable 48 kHz reference audio engine
- CRC32 A/B persistence with rollback and read-after-write verification

## Hardware safety
V6 is still **not hardware-flashable**. The stub evidence explicitly reports that
BP1048P4 target, GoloPine board profile, audio path, BLE path and storage path are
unverified. No P4 register, boot address, pin number, MMIO write, BLE vendor API or
flash command has been invented.

Validation:
```sh
make verify
make test
make demo
```
