# Changelog

## v8 — 2026-09-20

- แก้บั๊กจากวิดีโอ v7: ข้อมูล Demo จะไม่เปิด `example.com` หรือ URL ภายนอกปลอมอีกต่อไป
- เปลี่ยน `originalUrl` ของ Demo ทั้ง 52 รายการเป็น scheme ภายใน `demo://...` และเพิ่ม unit test ป้องกัน regression
- หน้า Product Detail ปิดปุ่ม “ดูต้นฉบับ/เปิดโพสต์” สำหรับ Demo พร้อมข้อความชัดเจนว่าไม่มีโพสต์ต้นฉบับภายนอก
- การ Share ข้อมูล Demo จะส่งเฉพาะชื่อ/ราคา/ข้อความว่าเป็นข้อมูลตัวอย่าง ไม่แนบ URL ปลอม
- หน้า “บันทึก” เปลี่ยนเป็นแท็บที่กดสลับได้จริงระหว่างสินค้าที่บันทึกกับการค้นหาที่บันทึก พร้อมจำนวนรายการ
- Saved Search แตะแล้วเปิด Marketplace พร้อมคืนค่า keyword/category/province/ช่วงราคา/source เดิม
- ปรับ label เพิ่มกลุ่มเป็น “ลิงก์กลุ่ม (URL)” เพื่อลดความสับสนเรื่องแหล่งข้อมูล
- คง Navigation no-crossfade, filter isolation, 52 Demo items และ toolchain/dependency ชุดเดิมจาก v7

## v7 — 2026-09-20

- แก้ภาพหน้าจอซ้อน/จางระหว่างสลับแท็บ โดยปิด Navigation crossfade สำหรับเส้นทางหลัก
- รีเซ็ต query/category/province/price/source/sort เมื่อผู้ใช้เปลี่ยนไปแท็บ browse อื่น เพื่อไม่ให้ตัวกรองจากหน้าก่อนติดข้ามหน้า
- ปรับการบันทึก Search History เป็น debounce 700 ms และบันทึกเฉพาะคำค้นตั้งแต่ 2 ตัวอักษร ลดประวัติจากการพิมพ์ทีละตัว
- ซ่อนคำค้นสั้น/ซ้ำจากส่วน “ค้นหาล่าสุด” ใน Marketplace
- เพิ่ม Demo catalog จาก 26 เป็น 52 รายการ: 26 หมวดมีอย่างน้อย 2 รายการต่อหมวด
- Demo seed ยังเป็น idempotent ติดตั้งทับ v6 ได้โดยไม่ต้อง Clear Data
- ไม่เปลี่ยน Android/Gradle dependency จาก v6

## v6 — 2026-09-20

- ตรวจจากวิดีโอ v5 และปรับ UI ต่อโดยไม่ย้อนฟีเจอร์เดิม
- เปลี่ยน Demo ปัจจุบันจาก 10 fallback illustrations ที่ถูกใช้ซ้ำ เป็น 26 local illustrations แยกตามรายการ/หมวดจริง; ยังคง asset v5 ไว้เพื่อ backward fallback compatibility
- เพิ่มภาพเฉพาะสำหรับ 6 ล้อ, 10 ล้อ, 12 ล้อ, รถพ่วง, flatbed trailer, รถดั้ม, excavator, แม็คโคร, Backhoe, loader, Wheel Loader, tractor, crane, mixer, harvester, forklift, pickup, used car, construction/agri machine, parts/equipment และ generator
- ปรับ `imageModel()` และ `fallbackDrawable()` ให้เลือกภาพละเอียดขึ้นตามหมวด ไม่ย้อนเป็น truck/tractor รูปเดียว
- หน้า Groups เปลี่ยน Add Group/Import Post เป็น expandable actions ลดฟอร์มยาวที่กินพื้นที่ตลอดเวลา
- หน้า Settings เปลี่ยนรายการ 26 หมวดจากข้อความยาวเป็น chip เลื่อนแนวนอนพร้อมจำนวนหมวด
- เพิ่ม display-name mapping ภาษาไทยสำหรับ Backhoe/Wheel Loader และ source labels ใน filter
- ปรับ ProductCard/Marketplace card ratio และ typography ให้การ์ดอ่านง่ายขึ้นบนจอมือถือ
- บังคับ Material typography ไปทาง sans-serif system family เพื่อลดความแปรผันจากฟอนต์ตกแต่งของเครื่อง
- `PROJECT_VERSION.txt = v6`; workflow เดิมเลือก ZIP version สูงสุดอัตโนมัติ จึงไม่ต้องแก้ชื่อเวอร์ชันใน YAML

## v5 — 2026-09-20

- แก้รูปสินค้า Demo ที่เคยเป็นช่องว่าง: เพิ่มภาพ local bundled 10 ชุดใน APK และไม่พึ่ง remote URL สำหรับ Demo Mode
- เพิ่ม fallback image ตามหมวดสินค้าให้ Live/Imported card ไม่พังเป็นพื้นที่ขาวเมื่อ URL รูปโหลดไม่ได้
- ขยาย Demo data เป็น 26 รายการ ครบทุก built-in category เช่น รถหกล้อ/สิบล้อ/สิบสองล้อ/พ่วง/ดั้ม/รถขุด/Backhoe/Wheel Loader/รถไถ/เครน/รถโม่/รถเกี่ยว/โฟล์คลิฟท์/กระบะ/อะไหล่/อุปกรณ์
- เปลี่ยน Demo seeding เป็น idempotent upsert: ติดตั้ง v5 ทับ v4 แล้วข้อมูล/รูป Demo ใหม่เข้าได้โดยไม่ต้อง Clear Data
- Category strip แสดงทุกหมวดแทนการตัดไว้ 10 หมวด และยังเลื่อนแนวนอนได้
- เพิ่ม Active Filter bar พร้อมปุ่ม `ล้าง` ใน Latest/Marketplace เพื่อให้เห็นชัดว่าหน้าถูกกรองด้วยหมวด/จังหวัด/ราคา/source/sort ใดอยู่
- Marketplace grid ยังคง 2 คอลัมน์ แต่มีข้อมูลมากพอให้หน้าดูเต็มและใช้ Favorite/Recent/Saved Search ได้จริง
- Product Detail/Feed/Marketplace ใช้ image model เดียวกัน พร้อม local placeholder/error image ตามหมวด
- คง toolchain/dependency ชุดเดียวกับ v4 ที่ผู้ใช้ทดสอบ APK จริงแล้ว: `compileSdk = 37`, `compileSdkMinor = 2`, `targetSdk = 36` พร้อม dependency versions เดิม
- เพิ่ม `PROJECT_VERSION.txt = v5` และ harden workflow ให้เลือกเลข `HeavyMarket_v<number>.zip` สูงสุดจริง, ตรวจ version ภายใน ZIP และ fallback `HeavyMarket_Source.zip` เฉพาะเมื่อไม่มี versioned ZIP

## v4 — 2026-09-20

- ปรับ UI จริงของแอปให้เป็น Heavy Market design system โทนน้ำเงินเข้ม + เหลือง แทน Material 3 ค่าเริ่มต้น
- เพิ่ม Splash screen พร้อมแบรนด์ Heavy Market และซ่อน Bottom Navigation ใน Splash/Product Detail
- ปรับหน้า “ล่าสุด” ให้มี branded header, search, category icon strip, demo warning แบบกระชับ และ product card ใหม่
- ปรับราคาจากรูปแบบ currency ที่มีทศนิยม เช่น `฿650,000.00` เป็น `฿650,000`
- เพิ่ม Favorite จากหน้า feed/Marketplace โดยตรง และแสดงสถานะหัวใจตาม Room favorites
- ปรับ Marketplace เป็น grid/list สองคอลัมน์แบบการ์ดสินค้า, recent search/recently viewed และ saved-search action
- ปรับ Product Detail เป็น hero image + overlay back/favorite/share, ราคาเด่น, seller card, specs และ related products
- ปรับ Settings/Groups/Saved ให้ใช้ visual language เดียวกันและลดความแน่นของ UI
- เปลี่ยน Demo image URLs ให้ตรงประเภทรถ/เครื่องจักรมากขึ้น และเพิ่ม `DEMO_IMAGE_CREDITS.md`
- เปลี่ยน launcher icon เป็นพื้นน้ำเงินเข้ม + รถสีเหลืองให้ตรงแบรนด์
- คง SDK fix จาก v3: `compileSdk = 37`, `compileSdkMinor = 2`, `targetSdk = 36` และ workflow ติดตั้ง `platforms;android-37.2` อัตโนมัติ

## v3 — 2026-09-20

- แก้ `checkDebugAarMetadata` ที่เกิดจาก AndroidX/Compose รุ่นปัจจุบันต้อง compile against API 37 ขึ้นไป
- ใช้ Android 17 minor SDK แบบใหม่: `compileSdk = 37` + `compileSdkMinor = 2` ขณะที่คง `targetSdk = 36` เพื่อไม่เปลี่ยน runtime opt-in โดยไม่จำเป็น
- Workflow อ่านทั้ง `compileSdk` และ `compileSdkMinor` แล้วติดตั้งแพ็กเกจ SDK แบบเต็ม เช่น `platforms;android-37.2` แทน `platforms;android-37` ที่ไม่มีใน repository รุ่นปัจจุบัน
- Workflow ตรวจรายการ stable packages จาก `sdkmanager --list --channel=0` ก่อนติดตั้ง และแสดงรายการ API ที่พบถ้าแพ็กเกจที่โปรเจกต์ต้องการไม่มี
- Build Tools ไม่ hard-code เป็น 36.0.0 อีกต่อไป; workflow เลือกรุ่น stable สูงสุดที่ตรงกับ compile SDK โดยอัตโนมัติ
- คงการเลือก Source ZIP เวอร์ชันใหม่สุด, auto version, unit tests, Debug APK และ optional signed Release APK

## v2 — 2026-09-20

- แก้ GitHub Actions ล้มที่ `platforms;android-37` โดยย้ายแอปไปใช้ Android 16 stable (`compileSdk = 36`, `targetSdk = 36`).
- Workflow ไม่ hard-code platform API อีกต่อไป แต่ตรวจ `compileSdk` จาก `app/build.gradle(.kts)` แล้วติดตั้ง SDK ที่ตรงกับโปรเจกต์อัตโนมัติ.
- ตรึง Android Command-line Tools revision 15859902 เพื่อหลีกเลี่ยง `sdkmanager` รุ่นเก่าที่ preinstalled บน runner.
- คงระบบเลือก ZIP เวอร์ชันใหม่สุด, auto version จาก GitHub Run Number, Unit Test, Debug APK และ optional signed Release APK.

## v1 — 2026-09-20

- สร้าง Native Android app ด้วย Kotlin, Jetpack Compose, Material 3, MVVM, Repository, Coroutines/Flow และ Hilt
- เพิ่ม Room database พร้อม Product, Source, GroupSource, Seller, Favorite, SavedSearch, SearchHistory, RecentlyViewed, SyncState, Category, KeywordRule และ PostClassification
- เพิ่ม Unified SALE Feed, Pull-to-refresh, incremental/infinite display, search/filter/sort และ offline cache
- เพิ่ม Groups fallback: Group URL list, search, Favorite, sync flag, Android Share-to-App และ Import URL/text
- เพิ่ม Marketplace-style screen: grid/list, search history, recently viewed, saved items/search, filters และ related products
- เพิ่ม Product Detail พร้อม seller/source/group fields, Favorite, Share, Open Original และ Report Incorrect Data
- เพิ่ม Rule-based `PostClassifier` สำหรับ SALE/RENTAL/WANTED/SERVICE/OTHER
- เพิ่ม `PriceParser` รองรับ 650,000 / 650000 / 650k / 6.5 แสน / 1.2 ล้าน / ฿
- เพิ่ม Include/Exclude keyword rules ที่ถูกนำไปใช้ตอน import/classify
- เพิ่ม normalized SHA-256 dedup + URL canonicalization + similarity scoring
- เพิ่ม natural-language price search เช่น `รถไถไม่เกิน 300000`
- เพิ่ม Saved Search notification ผ่าน WorkManager และ `lastNotifiedAt` ป้องกันแจ้งซ้ำ
- เพิ่ม DataStore สำหรับ Dark Mode / Notification settings
- เพิ่ม Retrofit/OkHttp API contract, Thai API error mapper และ WebSocket realtime client
- เพิ่ม Node.js + TypeScript backend reference พร้อม auth hook, normalization, classification, deduplication, pagination, saved searches, source adapters และ realtime events
- เพิ่ม Facebook Groups/Marketplace unavailable adapters โดยไม่สร้าง fake endpoint; Page provider ปิดไว้จนได้รับ Meta permissions/features จริง
- เพิ่ม GitHub Actions สำหรับ test + Debug APK, non-interactive SDK install, automatic versioning, artifact verification/upload และ optional signed Release
- ใช้ AGP 9.4.0 built-in Kotlin + Compose compiler plugin, KSP 2.3.10, Room 2.8.5, AndroidX Hilt 1.4.0
- เพิ่ม repository-local Gradle bootstrap สำหรับ Gradle 9.6.1 พร้อมตรวจ official distribution SHA-256
- เพิ่ม `BUILD_VALIDATION.md` ระบุผลตรวจจริงและข้อจำกัด environment โดยไม่อ้าง APK build สำเร็จเกินจริง
