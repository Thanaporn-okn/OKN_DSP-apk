# BUILD VALIDATION — Heavy Market v8

วันที่ตรวจ: 2026-09-20

## ผ่านแล้วใน environment นี้

- Domain Kotlin smoke test: classifier / PriceParser / SearchQueryParser — PASS
- DemoData Kotlin compile + runtime smoke — PASS
- Demo products: 52 รายการ — PASS
- Built-in categories: 26 หมวด และทุกหมวดมีอย่างน้อย 2 รายการ — PASS
- Demo image resource URI ทุกตัวเป็น `res://demo_*` — PASS
- Demo original URL ทุกตัวเป็น `demo://...` และไม่มี `http://` / `https://` — PASS
- เพิ่ม JUnit `DemoDataTest` ป้องกัน Demo เปิด URL ภายนอกปลอม — ADDED
- Product Detail แยก Demo กับโพสต์จริง: open-original disabled สำหรับ Demo และ Share ไม่แนบ URL ปลอม — STATIC CHECK PASS
- Saved screen มีแท็บสินค้า/การค้นหาที่บันทึก และ Saved Search คืนค่า filter ไป Marketplace — STATIC CHECK PASS
- XML parse ทุกไฟล์ resource/manifest — PASS
- GitHub Actions YAML parse — PASS
- Workflow ภายใน ZIP ตรงกับ `android-build.yml` ที่ส่งแยก — PASS
- `PROJECT_VERSION.txt = v8` — PASS
- ZIP integrity (`unzip -t`) — PASS หลังแพ็ก

## การแก้จากวิดีโอ v7

- แก้ปุ่ม “เปิดโพสต์” ของ Demo ที่เคยเปิด `example.com`
- ปิด “ดูต้นฉบับ/เปิดโพสต์” สำหรับข้อมูลตัวอย่าง พร้อมข้อความว่าไม่มีโพสต์ต้นฉบับจริง
- Share Demo ส่งชื่อ/ราคา/สถานะข้อมูลตัวอย่างเท่านั้น
- ทำหน้า “บันทึก” ให้แท็บกดสลับได้จริง
- Saved Search แตะแล้วเปิด Marketplace พร้อม keyword/category/province/price/source เดิม
- คง Navigation no-crossfade, filter isolation และ Demo catalog 52 รายการจาก v7

## ข้อจำกัดการตรวจ

Container นี้ไม่มี Android SDK/dependency cache ครบ จึงไม่อ้างว่า APK ถูก build สำเร็จในเครื่องนี้ การ build จริงให้ GitHub Actions รัน `./gradlew clean testDebugUnitTest assembleDebug --stacktrace` ตาม workflow
