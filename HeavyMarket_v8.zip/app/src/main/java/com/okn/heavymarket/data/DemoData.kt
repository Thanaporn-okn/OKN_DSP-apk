package com.okn.heavymarket.data

import com.okn.heavymarket.data.local.ProductEntity
import com.okn.heavymarket.domain.Deduplicator

object DemoData {
    private val now = System.currentTimeMillis()

    fun products(): List<ProductEntity> {
        val primary = listOf(
        item("demo-hino-6w", "Hino 6 ล้อ FC ตู้แห้ง ปี 2018", 650_000, "รถหกล้อ", "ขอนแก่น", "Hino", "FC", 2018, 18, "res://demo_truck_6w", "เครื่องดี ช่วงล่างแน่น ตู้แห้งพร้อมใช้งาน เอกสารครบพร้อมโอน", "250,000 กม.", "สมชาย วงศ์ดี", "ตลาดรถบรรทุกมือสอง"),
        item("demo-isuzu-10w", "Isuzu 10 ล้อ FYH พร้อมวิ่งงาน", 1_150_000, "รถสิบล้อ", "นครราชสีมา", "Isuzu", "FYH", 2019, 34, "res://demo_truck_10w", "รถสิบล้อสภาพดี พร้อมวิ่งงาน เครื่องเกียร์ปกติ ยางพร้อมใช้", "310,000 กม.", "โคราชทรัค", "ซื้อขายรถสิบล้อทั่วไทย"),
        item("demo-hino-12w", "Hino 12 ล้อ 2 เพลา ปี 2020", 1_480_000, "รถสิบสองล้อ", "ชลบุรี", "Hino", "500", 2020, 52, "res://demo_truck_12w", "รถบรรทุก 12 ล้อ เหมาะงานขนส่งหนัก ตรวจเช็กแล้ว พร้อมส่งมอบ", "220,000 กม.", "Eastern Truck", "ตลาดรถบรรทุกภาคตะวันออก"),
        item("demo-truck-general", "รถบรรทุก Hino 500 มือสอง", 890_000, "รถบรรทุก", "กรุงเทพมหานคร", "Hino", "500", 2017, 65, "res://demo_truck_box", "รถบรรทุกมือสองใช้งานประจำ ดูแลตามระยะ เอกสารพร้อม", "340,000 กม.", "Truck Hub", "รถบรรทุกมือสองทั่วไทย"),
        item("demo-trailer", "หางพ่วง 3 เพลา พร้อมทะเบียน", 420_000, "รถพ่วง", "สระบุรี", "Thai Trailer", "3 Axle", 2021, 80, "res://demo_trailer", "หางพ่วง 3 เพลา โครงสร้างดี พื้นแน่น ระบบไฟใช้งานได้", null, "พ่วงสระบุรี", "ซื้อขายรถพ่วง"),
        item("demo-semitrailer", "เทรลเลอร์พื้นเรียบ 3 เพลา", 520_000, "รถเทรลเลอร์", "ระยอง", "Trailer", "Flatbed", 2020, 95, "res://demo_flatbed", "เทรลเลอร์พื้นเรียบ เหมาะบรรทุกเครื่องจักร ช่วงล่างแน่น", null, "ระยองเทรลเลอร์", "ตลาดเทรลเลอร์"),
        item("demo-dump", "Hino 10 ล้อ ดั้ม พร้อมใช้งาน", 980_000, "รถดั้ม", "สระบุรี", "Hino", "Ranger", 2016, 110, "res://demo_dump_v6", "กระบะดั้มแข็งแรง ปั๊มดั้มทำงานดี เหมาะงานดินและก่อสร้าง", "290,000 กม.", "สระบุรีทรัคมือสอง", "ซื้อขายรถดั้มทั่วประเทศ"),
        item("demo-komatsu", "Komatsu PC200-8 รถขุด", 1_200_000, "รถขุด", "นครราชสีมา", "Komatsu", "PC200-8", 2015, 128, "res://demo_excavator_yellow", "ระบบไฮดรอลิกดี ช่วงล่างพร้อมลงงาน ทดลองเครื่องได้", "8,900 ชม.", "ร้านเครื่องจักรโคราช", "ซื้อขายรถขุดและเครื่องจักร"),
        item("demo-macro", "รถแม็คโคร CAT 320D", 1_650_000, "รถแม็คโคร", "ชลบุรี", "CAT", "320D", 2014, 145, "res://demo_excavator_orange", "เครื่องแน่น ปั๊มดี พร้อมตรวจสภาพและทดลองงาน", "10,200 ชม.", "Eastern Heavy Machine", "ตลาดรถแม็คโคร"),
        item("demo-backhoe", "JCB Backhoe 3CX มือสอง", 1_050_000, "Backhoe", "เชียงใหม่", "JCB", "3CX", 2016, 162, "res://demo_backhoe_v6", "แบคโฮอเนกประสงค์ ระบบขุดและบุ้งกี๋หน้าใช้งานได้ครบ", "7,100 ชม.", "Northern Machine", "แบคโฮมือสอง"),
        item("demo-loader-th", "รถตัก CAT 950H", 1_780_000, "รถตัก", "ระยอง", "CAT", "950H", 2013, 179, "res://demo_loader_yellow", "รถตักล้อยาง บุ้งกี๋ดี ระบบเกียร์และไฮดรอลิกพร้อมทำงาน", "11,400 ชม.", "Rayong Heavy", "ตลาดรถตัก"),
        item("demo-wheel-loader", "Komatsu WA200 Wheel Loader", 1_390_000, "Wheel Loader", "ขอนแก่น", "Komatsu", "WA200", 2015, 196, "res://demo_loader_orange", "Wheel Loader พร้อมใช้งาน ยางดี ระบบยกปกติ", "8,250 ชม.", "KK Heavy", "ซื้อขาย Wheel Loader"),
        item("demo-tractor-th", "Kubota M7040 รถไถ", 295_000, "รถไถ", "อุดรธานี", "Kubota", "M7040", 2017, 214, "res://demo_tractor_red", "รถไถพร้อมใช้งาน ระบบปกติ ยางสภาพดี เหมาะงานไร่และสวน", "3,800 ชม.", "เกษตรมือสองอีสาน", "ตลาดรถไถและอุปกรณ์เกษตร"),
        item("demo-tractor", "New Holland TT75 รถแทรกเตอร์", 520_000, "รถแทรกเตอร์", "พิษณุโลก", "New Holland", "TT75", 2019, 232, "res://demo_tractor_blue", "รถแทรกเตอร์ 75 แรงม้า พร้อมอุปกรณ์พื้นฐาน เอกสารครบ", "2,900 ชม.", "เกษตรภาคกลาง", "ตลาดรถแทรกเตอร์"),
        item("demo-crane", "รถเครน Tadano 25 ตัน", 2_450_000, "รถเครน", "สมุทรปราการ", "Tadano", "TR-250", 2012, 250, "res://demo_crane_v6", "เครน 25 ตัน ระบบยกปกติ ตรวจเช็กสายสลิงและระบบแล้ว", "12,500 ชม.", "Crane Center", "ซื้อขายรถเครน"),
        item("demo-mixer", "รถโม่ปูน Hino 6 คิว", 1_350_000, "รถโม่ปูน", "กรุงเทพมหานคร", "Hino", "Mixer 6Q", 2018, 268, "res://demo_mixer_v6", "โม่ 6 คิว ระบบหมุนดี ถังไม่รั่ว พร้อมใช้งานไซต์งาน", "260,000 กม.", "Concrete Truck", "รถโม่ปูนมือสอง"),
        item("demo-harvester", "รถเกี่ยวข้าว Kubota DC-70", 690_000, "รถเกี่ยว", "สุรินทร์", "Kubota", "DC-70", 2019, 286, "res://demo_harvester", "รถเกี่ยวพร้อมลงนา ระบบตัดและช่วงล่างตรวจเช็กแล้ว", "2,100 ชม.", "เกษตรสุรินทร์", "ตลาดรถเกี่ยว"),
        item("demo-forklift", "Toyota Forklift 3 ตัน", 280_000, "รถโฟล์คลิฟท์", "สมุทรสาคร", "Toyota", "3T", 2018, 304, "res://demo_forklift_v6", "โฟล์คลิฟท์ 3 ตัน เสาสูง เครื่องดี เหมาะโรงงานและคลังสินค้า", "4,600 ชม.", "Warehouse Machine", "ซื้อขายโฟล์คลิฟท์"),
        item("demo-pickup", "Toyota Hilux Revo 4 ประตู", 485_000, "รถกระบะ", "ขอนแก่น", "Toyota", "Hilux Revo", 2019, 322, "res://demo_pickup_blue", "รถกระบะมือสอง เจ้าของเดียว ใช้งานทั่วไป เอกสารครบ", "98,000 กม.", "รถบ้านขอนแก่น", "ตลาดรถกระบะมือสอง"),
        item("demo-usedcar", "Isuzu D-Max มือสอง พร้อมใช้", 395_000, "รถมือสอง", "อุบลราชธานี", "Isuzu", "D-Max", 2017, 340, "res://demo_pickup_gray", "รถบ้านสภาพพร้อมใช้ ตรวจเช็กระบบพื้นฐานแล้ว", "135,000 กม.", "รถบ้านอุบล", "รถมือสองอีสาน"),
        item("demo-construction", "เครื่องจักรก่อสร้าง รถตักพร้อมงาน", 1_290_000, "เครื่องจักรก่อสร้าง", "ระยอง", "Komatsu", "WA180", 2014, 358, "res://demo_construction", "เครื่องจักรก่อสร้างพร้อมทำงาน เหมาะไซต์ดินและวัสดุ", "9,300 ชม.", "Construction Machine", "เครื่องจักรก่อสร้างมือสอง"),
        item("demo-agri-machine", "เครื่องจักรการเกษตร พร้อมชุดพ่วง", 345_000, "เครื่องจักรการเกษตร", "ร้อยเอ็ด", "Kubota", "Agri Set", 2018, 376, "res://demo_agri", "ชุดเครื่องจักรเกษตรมือสอง พร้อมอุปกรณ์ต่อพ่วงพื้นฐาน", "3,200 ชม.", "เกษตรร้อยเอ็ด", "เครื่องจักรเกษตร"),
        item("demo-truck-parts", "ชุดอะไหล่รถบรรทุก Hino / Isuzu", 38_000, "อะไหล่รถ", "กรุงเทพมหานคร", "OEM", "Truck Parts", 2022, 394, "res://demo_truck_parts", "ชุดอะไหล่รถบรรทุกมือสองและอะไหล่เทียบ สอบถามรายการได้", null, "Truck Parts BKK", "อะไหล่รถบรรทุก"),
        item("demo-machine-parts", "ปั๊มไฮดรอลิกและอะไหล่รถขุด", 65_000, "อะไหล่เครื่องจักร", "ชลบุรี", "Hydraulic", "Pump", 2021, 412, "res://demo_machine_parts", "อะไหล่ระบบไฮดรอลิกสำหรับรถขุดและรถตัก มีหลายรุ่น", null, "Heavy Parts", "อะไหล่เครื่องจักรหนัก"),
        item("demo-equipment", "อุปกรณ์มือสอง ชุดเครื่องมือช่างหนัก", 22_000, "อุปกรณ์มือสอง", "ขอนแก่น", "Mixed", "Workshop", 2023, 430, "res://demo_equipment", "ชุดเครื่องมือและอุปกรณ์เวิร์กช็อปมือสอง ใช้งานได้", null, "Workshop KK", "อุปกรณ์มือสอง"),
        item("demo-other", "เครื่องปั่นไฟดีเซล 60 kVA", 165_000, "อื่นๆ", "นครราชสีมา", "Denyo", "60kVA", 2018, 448, "res://demo_generator", "เครื่องปั่นไฟดีเซลมือสอง ทดสอบโหลดแล้ว พร้อมใช้งาน", "4,200 ชม.", "Power Machine", "เครื่องจักรและอุปกรณ์" )
        )

        val provinces = listOf(
            "ขอนแก่น", "นครราชสีมา", "ชลบุรี", "ระยอง", "สระบุรี", "อุดรธานี",
            "เชียงใหม่", "พิษณุโลก", "กรุงเทพมหานคร", "สุรินทร์", "สมุทรปราการ", "ร้อยเอ็ด"
        )
        val secondary = primary.mapIndexed { index, product ->
            val id = "${product.id}-alt"
            val year = product.year?.let { (it - if (index % 2 == 0) 1 else 0).coerceAtLeast(2000) }
            val displayCategory = when (product.category) {
                "Backhoe" -> "แบคโฮ"
                "Wheel Loader" -> "รถตักล้อยาง"
                else -> product.category
            }
            val titlePrefix = listOfNotNull(product.brand, product.model, year?.toString())
                .filter { it.isNotBlank() }
                .joinToString(" ")
            val title = "$titlePrefix $displayCategory สภาพพร้อมใช้".trim()
            val price = product.price?.let { raw ->
                val percent = 91 + (index % 8)
                ((raw * percent / 100) / 1_000).coerceAtLeast(1) * 1_000
            }
            val province = provinces[(index + 3) % provinces.size]
            val url = "demo://$id"
            val description = "อีกหนึ่งตัวเลือกในหมวด $displayCategory ตรวจสภาพพื้นฐานแล้ว พร้อมนัดดูสินค้า • ${product.description}"
            product.copy(
                id = id,
                title = title,
                description = description,
                price = price,
                location = province,
                province = province,
                postedAt = now - (480 + index * 13) * 60_000L,
                groupOrPageName = product.groupOrPageName?.let { "$it • คัดสภาพ" },
                sellerId = "seller-$id",
                sellerName = product.sellerName?.let { "$it • สาขา 2" },
                year = year,
                originalUrl = url,
                normalizedHash = Deduplicator.normalizedHash(title, description, price, url),
                createdAt = now
            )
        }
        return primary + secondary
    }

    private fun item(
        id: String,
        title: String,
        price: Long,
        category: String,
        province: String,
        brand: String,
        model: String,
        year: Int,
        minutesAgo: Int,
        image: String,
        desc: String,
        hours: String? = null,
        seller: String,
        group: String
    ): ProductEntity {
        val url = "demo://$id"
        return ProductEntity(
            id = id,
            title = title,
            description = desc,
            price = price,
            category = category,
            location = province,
            province = province,
            postedAt = now - minutesAgo * 60_000L,
            sourceId = "demo",
            sourceName = "ข้อมูลตัวอย่าง",
            sourceType = "DEMO",
            groupOrPageName = group,
            sellerId = "seller-$id",
            sellerName = seller,
            brand = brand,
            model = model,
            year = year,
            mileageOrHours = hours,
            imageUrls = image,
            originalUrl = url,
            classification = "SALE",
            classificationScore = 5.0,
            normalizedHash = Deduplicator.normalizedHash(title, desc, price, url),
            isDemo = true
        )
    }
}
