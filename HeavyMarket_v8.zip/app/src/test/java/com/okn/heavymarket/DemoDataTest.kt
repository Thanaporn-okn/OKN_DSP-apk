package com.okn.heavymarket

import com.okn.heavymarket.data.DemoData
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DemoDataTest {
    @Test
    fun demoCatalogIsCompleteAndUsesLocalOnlyOriginalLinks() {
        val items = DemoData.products()
        assertEquals(52, items.size)
        assertEquals(26, items.groupBy { it.category }.size)
        assertTrue(items.groupBy { it.category }.values.all { it.size >= 2 })
        assertTrue(items.all { it.isDemo })
        assertTrue(items.all { it.imageUrls.startsWith("res://demo_") })
        assertTrue(items.all { it.originalUrl.startsWith("demo://") })
        assertFalse(items.any { it.originalUrl.startsWith("http://") || it.originalUrl.startsWith("https://") })
    }
}
