# Heavy Market

Heavy Market คือ Native Android Application ภาษาไทยสำหรับรวบรวม ค้นหา กรอง จัดหมวดหมู่ และบันทึก **ประกาศขายสินค้ามือสอง** โดยเน้นรถบรรทุก รถหกล้อ รถสิบล้อ รถดั้ม รถขุด/รถแม็คโคร รถไถ เครื่องจักรก่อสร้าง เครื่องจักรการเกษตร อะไหล่ และอุปกรณ์มือสอง

โปรเจกต์นี้เป็น repository-ready source code ไม่ใช่ Demo UI อย่างเดียว: มี Room database, rule-based classifier, duplicate detection, Share-to-App/import, saved search notification, backend reference, WebSocket client, GitHub Actions และ automatic CI versioning

### UI v6

- Heavy Market design system โทนน้ำเงินเข้ม + เหลือง พร้อม Light/Dark mode
- Splash screen, branded header และ Bottom Navigation แบบใหม่
- Product card และ Marketplace grid ที่เน้นรูปสินค้า/ราคา/จังหวัด/หมวดหมู่
- ราคาแสดงแบบจำนวนเต็ม เช่น `฿650,000` ไม่มี `.00`
- Product Detail ใช้ hero image พร้อม Favorite/Share/Open original
- Demo feed ใช้ภาพรถ/เครื่องจักรที่ตรงประเภทมากขึ้น; ดูเครดิตที่ `DEMO_IMAGE_CREDITS.md`

### Build compatibility v6

v6 คง Android toolchain/dependency ชุดเดียวกับ v4/v5 ที่ผู้ใช้ build และเปิด APK ได้จริงแล้ว: `compileSdk = 37`, `compileSdkMinor = 2`, `targetSdk = 36` เพื่อให้รอบนี้เปลี่ยนเฉพาะ UI/data/image robustness โดยไม่เพิ่มความเสี่ยงด้าน dependency


### ปรับจากวิดีโอ v5

- Demo ปัจจุบันใช้ **26 ภาพ local แยกตาม 26 รายการ/หมวด** แทนการวนภาพ fallback ชุดเดิม จึงเห็นรถ 6 ล้อ/10 ล้อ/12 ล้อ/พ่วง/เทรลเลอร์/Backhoe/รถเกี่ยว/อะไหล่ ฯลฯ แตกต่างกันชัดเจน
- หน้า “กลุ่ม” ยุบฟอร์ม Add Group และ Import Post ไว้หลังปุ่ม เพื่อลดพื้นที่ว่างและเปิดเฉพาะตอนใช้งาน
- Settings เปลี่ยนรายชื่อหมวดหมู่ยาว ๆ เป็น chip แนวนอนพร้อมจำนวนหมวด
- ชื่อ `Backhoe` / `Wheel Loader` แสดงเป็น `แบคโฮ` / `รถตักล้อยาง` ใน UI โดยยังเก็บ key เดิมในฐานข้อมูลเพื่อ compatibility
- ปรับสัดส่วนรูป/การ์ด Marketplace และ feed ให้อ่านง่ายขึ้น และแสดง source/filter เป็นคำภาษาไทยมากขึ้น
- ใช้ `FontFamily.SansSerif` ใน Material typography เพื่อลดผลกระทบจากฟอนต์ตกแต่งของเครื่องเมื่อ platform รองรับ

Root มี `PROJECT_VERSION.txt` และ GitHub Actions จะตรวจว่าเลข version ภายใน source ตรงกับชื่อ `HeavyMarket_v<number>.zip` ก่อน build พร้อมแสดง SHA-256 และ dependency fingerprint ใน log


> หลักความปลอดภัย: ไม่ขโมย session/cookie/token/password, ไม่ bypass CAPTCHA/Login Protection/Rate Limit, ไม่ฝัง Facebook App Secret/Server Token/Private Key/Keystore ใน APK และไม่สร้าง Facebook endpoint ปลอม

## สถานะ v8

เวอร์ชัน v8 เก็บปัญหาจากวิดีโอทดสอบ v7: Demo ไม่เปิดลิงก์ภายนอกปลอมอีกต่อไป, Product Detail แยก Demo/โพสต์จริงชัดเจน, Share Demo ไม่แนบ URL ปลอม และหน้า “บันทึก” มีแท็บใช้งานจริงพร้อม Saved Search ที่แตะเพื่อคืนค่าเงื่อนไขกลับเข้า Marketplace ได้ โดยคง no-crossfade, filter isolation และ Demo 52 รายการจาก v7


## สถานะ Meta/Facebook API ที่ยึดใช้

ตรวจล่าสุดวันที่ **20 กันยายน 2026** และต้องตรวจ Meta Developer Documentation ใหม่ทุกครั้งก่อนเปิด provider จริง

- **Facebook Groups:** Meta ประกาศยกเลิก Groups API, `publish_to_groups` และ `groups_access_member_info` โดยมีผลกับทุกเวอร์ชันตั้งแต่ 22 เมษายน 2024 ดังนั้น Heavy Market **ไม่อ้างว่าสามารถอ่านโพสต์ของกลุ่มที่ผู้ใช้เป็นสมาชิกผ่าน official Groups API**
- **Facebook Pages:** Graph API ยังมี Page API แต่ข้อมูลที่อ่านได้ขึ้นกับ token, permissions และ features ที่ Meta อนุมัติ เช่น `pages_read_engagement`, `pages_read_user_content`, Page Public Content Access/Metadata Access ตาม use case
- **Facebook Marketplace:** ณ วันที่ตรวจ ไม่พบ official public Meta Graph API สำหรับดึง/ค้นหา Marketplace listings ทั่วไปของผู้ใช้อื่น จึงไม่มีการสร้าง endpoint ปลอมในโปรเจกต์

เอกสารอ้างอิงหลัก:

- https://developers.facebook.com/docs/graph-api/changelog/version19.0/
- https://developers.facebook.com/docs/graph-api/reference/page/
- https://developers.facebook.com/docs/permissions/reference/
- https://developers.facebook.com/docs/features-reference/

## Data Sources และ fallback

สถาปัตยกรรมแยก provider ออกจาก UI ผ่าน interface เพื่อให้เปลี่ยนแหล่งข้อมูลในอนาคตได้โดยไม่เขียนหน้าแอปใหม่ทั้งหมด

มี interface อย่างน้อย:

- `FacebookPageDataSource`
- `FacebookGroupDataSource`
- `MarketplaceDataSource`
- `ImportedPostDataSource`
- `SharedPostDataSource`
- `MockDataSource`

สิ่งที่ใช้งานได้ทันทีโดยไม่ต้องมี Facebook token:

1. Demo Mode พร้อมป้าย **“ข้อมูลตัวอย่าง”** ทุกจุดที่เกี่ยวข้อง
2. Android Share Sheet: แชร์ข้อความ/URL จากแอปอื่นเข้า Heavy Market
3. Import URL หรือข้อความโพสต์ในหน้า “กลุ่ม”
4. บันทึก Group URL, Favorite Group และเปิด/ปิด flag สำหรับ sync provider ในอนาคต
5. Backend/provider ที่ได้รับอนุญาตสามารถ normalize เป็น `Product` model เดียวกันภายหลัง

`UnavailableFacebookGroupDataSource` และ `UnavailableMarketplaceDataSource` คืนสถานะ unavailable อย่างชัดเจนและคืนรายการว่าง ไม่หลอก UI ว่า sync สำเร็จ

## Feature ที่มีใน v6

### ล่าสุด

- Unified SALE feed จากข้อมูลที่อยู่ใน Room
- ใหม่ที่สุดก่อน
- Pull-to-refresh
- Infinite loading ฝั่ง UI
- Offline cache ด้วย Room
- Search ภาษาไทย/อังกฤษ
- Category / จังหวัด / ช่วงราคา / source / sort
- Natural price query เช่น `รถไถไม่เกิน 300000`
- Demo label ชัดเจน
- เปิด Product Detail

### กลุ่ม

- รายชื่อ Group URL ที่ผู้ใช้เพิ่มเอง
- ค้นหากลุ่ม
- Favorite Group
- เปิด/ปิด Sync flag รายกลุ่มสำหรับ provider ที่ได้รับอนุญาตในอนาคต
- Import URL/ข้อความ
- Share-to-App
- Import ผ่าน classifier + custom keyword rules + duplicate detection ก่อนบันทึก
- แสดงเฉพาะ `SALE` ใน feed หลัก

### Marketplace-style

ใช้ Design System ของ Heavy Market เอง ไม่ copy Facebook branding หรือ UI แบบ pixel-by-pixel

- Search
- Category
- Location/Province
- Min/Max Price
- Newest / Price Low-High / Price High-Low
- Grid/List view
- Saved Items
- Recently Viewed
- Search History
- Saved Search
- Product Detail
- Seller information เมื่อ provider มีสิทธิ์ส่งข้อมูล
- Related Products
- Share / Favorite / Open Original Listing
- มี field พิกัด (`latitude`, `longitude`) และ UI ระบุชัดว่าการกรองระยะทางต้องรอ provider ส่งพิกัดจริง + permission ของผู้ใช้ แอปไม่สร้าง location ปลอม

### Product Detail

- รูป
- ชื่อ / ราคา / ราคาเดิม
- รายละเอียด
- ยี่ห้อ / รุ่น / ปี
- เลขไมล์/ชั่วโมงทำงาน
- สถานะสินค้า
- จังหวัด/สถานที่
- วันที่โพสต์
- แหล่งข้อมูล
- กลุ่ม/เพจ
- Seller name เมื่อข้อมูลอนุญาต
- Favorite
- Share
- Open Original Post
- Report Incorrect Data
- Related Products

### Favorite / Saved Search / Notification

- Favorite Product offline ใน Room
- Favorite Group
- โครง `FavoriteEntity(type,targetId)` รองรับ target type อื่น เช่น Category/Seller ได้โดยไม่เปลี่ยน schema หลัก
- Saved Search เก็บ keyword/category/province/min/max/source
- WorkManager ตรวจรายการใหม่ตาม Saved Search
- `lastNotifiedAt` ป้องกันแจ้งรายการเดิมซ้ำ
- เปิด/ปิด notification ด้วย DataStore

## PostClassifier

Classifier รุ่นแรกไม่เสียค่า AI และทำงาน offline ด้วย Regex + rule-based scoring

ประเภท:

- `SALE`
- `RENTAL`
- `WANTED`
- `SERVICE`
- `OTHER`

รองรับคำสำคัญเช่น `ขาย`, `ขายด่วน`, `ราคา`, `บาท`, `ลดราคา`, `มือสอง`, `พร้อมใช้`, `เจ้าของขายเอง`, `สนใจ`, `โทร`, `Inbox`, `ทักแชท` และลด/เปลี่ยนประเภทเมื่อพบ `รับซื้อ`, `ตามหา`, `ต้องการซื้อ`, `ให้เช่า`, `รับซ่อม`, `รับสมัครงาน` เป็นต้น

Price parser รองรับตัวอย่าง:

- `650,000`
- `650000`
- `650k`
- `6.5 แสน`
- `1.2 ล้าน`
- `฿850,000`

ผู้ใช้เพิ่ม Keyword Include / Exclude จาก Settings ได้ และกฎถูกนำไปใช้ตอน import/classify จริง

## Duplicate Detection

ตรวจจากหลายสัญญาณ:

- canonical Original URL (ตัด query string)
- SHA-256 normalized hash
- title + description normalization
- price
- Jaccard-like token similarity

ตอน import หาก hash/URL ตรง หรือราคาเท่ากันและ similarity สูง จะไม่เพิ่ม duplicate ใหม่

## Database

Room entities:

- `ProductEntity`
- `SourceEntity`
- `GroupSourceEntity`
- `SellerEntity`
- `FavoriteEntity`
- `SavedSearchEntity`
- `SearchHistoryEntity`
- `RecentlyViewedEntity`
- `SyncStateEntity`
- `CategoryEntity`
- `KeywordRuleEntity`
- `PostClassificationEntity`

Room schema export ไปที่ `app/schemas/`

### Migration Strategy

Database เริ่มที่ version 1 จึงยังไม่มี migration ข้ามเวอร์ชัน ใน production เมื่อแก้ schema ต้อง:

1. เพิ่ม database version
2. เพิ่ม `Migration(oldVersion, newVersion)`
3. เก็บ exported schema ใน `app/schemas/`
4. เพิ่ม migration test
5. ห้ามใช้ destructive migration เพื่อกลบปัญหาโดยไม่มีเหตุผล

## Android Tech Stack

- Kotlin + AGP built-in Kotlin
- Jetpack Compose + Material 3
- MVVM + Repository Pattern
- Coroutines / Flow / StateFlow
- Room 2.8.5
- Retrofit 3 + OkHttp 5
- Coil 3
- Navigation Compose
- WorkManager
- DataStore 1.2.1
- Hilt / Dagger 2.60.1 + AndroidX Hilt 1.4.0
- KSP 2.3.10
- Gradle Kotlin DSL
- Compile SDK 37.2 (`compileSdk = 37`, `compileSdkMinor = 2`), Target SDK 36, Min SDK 26
- Java/JDK 17 target

AGP 9 ใช้ built-in Kotlin เป็น default จึงไม่มี `org.jetbrains.kotlin.android` plugin ซ้ำ

## Project Structure

```text
.github/workflows/android-build.yml
app/
  build.gradle.kts
  schemas/
  src/main/
    AndroidManifest.xml
    java/com/okn/heavymarket/
      data/        Room, repository, settings, demo, remote API, source interfaces
      domain/      PostClassifier, PriceParser, Deduplicator, SearchQueryParser
      di/          Hilt modules
      ui/          Compose UI + ViewModels
      worker/      SavedSearchWorker
    res/
  src/test/
backend/
  src/
  .env.example
  package.json
  tsconfig.json
gradle/wrapper/
  gradle-wrapper.properties
  gradle-wrapper.jar
  src/org/gradle/wrapper/GradleWrapperMain.java
BUILD_VALIDATION.md
CHANGELOG.md
README.md
build.gradle.kts
settings.gradle.kts
gradle.properties
gradlew
gradlew.bat
.env.example
.gitignore
```

## Gradle Wrapper / Bootstrap

Repository มี `./gradlew` และ `gradle/wrapper/gradle-wrapper.jar` พร้อมใช้งาน

ใน environment ที่สร้าง ZIP นี้ไม่สามารถดาวน์โหลด binary จากอินเทอร์เน็ตได้อย่างน่าเชื่อถือ จึงใช้ **repository-local Java bootstrapper** ที่ source อยู่ใน `gradle/wrapper/src/` แทนการอ้างว่าเป็น official Gradle wrapper JAR ทั้งก้อน Bootstrapper จะ:

1. อ่าน `gradle-wrapper.properties`
2. ดาวน์โหลด `gradle-9.6.1-bin.zip` จาก HTTPS
3. ตรวจ SHA-256 ของ distribution ก่อนแตกไฟล์
4. cache ใต้ `GRADLE_USER_HOME/wrapper/dists`
5. delegate arguments ทั้งหมดไปยัง Gradle จริง

Pinned official distribution checksum:

`9c0f7faeeb306cb14e4279a3e084ca6b596894089a0638e68a07c945a32c9e14`

คำสั่งที่ใช้จึงยังเป็นมาตรฐานของโปรเจกต์:

```bash
./gradlew clean assembleDebug
./gradlew clean testDebugUnitTest assembleDebug
./gradlew assembleRelease
```

## Build Local

ต้องมี JDK 17+ และ Android SDK Platform 37.2 (หรือ minor SDK ที่ตรงกับค่าใน `app/build.gradle.kts`)

Linux/macOS:

```bash
chmod +x ./gradlew
./gradlew clean testDebugUnitTest assembleDebug
```

Windows:

```bat
gradlew.bat clean testDebugUnitTest assembleDebug
```

APK ปกติจะอยู่ใต้:

```text
app/build/outputs/apk/debug/
app/build/outputs/apk/release/
```

## Backend

Backend reference อยู่ใน `/backend` ใช้ Node.js + TypeScript + Express + WebSocket

มี endpoint หลัก:

- `GET /health`
- `GET /api/products` — search/filter/cursor pagination
- `POST /api/import` — normalize/classify/deduplicate
- `GET /api/sources`
- `POST /api/sources/:id/sync`
- `GET/POST/DELETE /api/saved-searches`
- WebSocket `/api/ws` สำหรับ realtime events

เริ่ม local:

```bash
cd backend
cp .env.example .env
npm install
npm run dev
```

Production ควรใช้ database จริงและ authentication/authorization ที่เหมาะสม ไม่ควรใช้ in-memory reference store เป็นฐานข้อมูลถาวร

### Backend URL ใน Android

ค่า default คือ `https://example.com/` เพื่อป้องกันแอปส่งข้อมูลไป server ที่ไม่ตั้งใจ สามารถ override ตอน build:

```bash
./gradlew assembleDebug -PBACKEND_BASE_URL=https://api.example.org/
```

สำหรับ emulator dev:

```bash
./gradlew assembleDebug -PBACKEND_BASE_URL=http://10.0.2.2:8080/
```

Network security config อนุญาต cleartext เฉพาะ `10.0.2.2` และ `localhost` สำหรับ development

## Meta Credentials

อย่าใส่ secret ลง Android source หรือ BuildConfig

ตัวแปรตัวอย่างฝั่ง backend:

```text
META_APP_ID=
META_APP_SECRET=
META_SYSTEM_USER_TOKEN=
```

เปิด Page provider จริงได้ต่อเมื่อ app/use case ผ่านสิทธิ์และ feature review ที่ Meta ต้องการ ณ เวลานั้น จากนั้นจึง implement `fetch()` กับ endpoint ที่มีอยู่จริง

Groups/Marketplace ต้องตรวจ Meta docs ใหม่เสมอ ห้ามเปลี่ยน unavailable adapter เป็น scraper/session-cookie workaround โดยอัตโนมัติ

## GitHub Actions

Workflow: `.github/workflows/android-build.yml`

Trigger:

- `push`
- `pull_request`
- `workflow_dispatch`

Debug job หลัก:

```bash
./gradlew clean testDebugUnitTest assembleDebug --stacktrace
```

Workflow:

- setup JDK 17
- setup Android SDK ด้วย `android-actions/setup-android@v4` (Node 24)
- accept licenses แบบ non-interactive ผ่าน action input
- อ่าน `compileSdk` + `compileSdkMinor` จากโปรเจกต์ แล้วติดตั้ง Android Platform และ Build Tools stable ที่ตรงกันอัตโนมัติ
- run Unit Tests ก่อน assembleDebug
- ตรวจไฟล์จริงด้วย `find app/build/outputs -maxdepth 8 -type f -print`
- copy APK จริงเป็นชื่อ versioned artifact
- upload artifact

Version อัตโนมัติจาก GitHub Run Number:

```text
versionCode = GITHUB_RUN_NUMBER
versionName = 1.0.<GITHUB_RUN_NUMBER>
```

Local fallback คือ `1.0.1`

Artifact ตัวอย่าง:

```text
HeavyMarket-v1.0.45-debug.apk
HeavyMarket-v1.0.45-release.apk
```

ไม่ต้องแก้ `versionCode`, `versionName` หรือ YAML ทุก build

## Release Signing

ตั้ง GitHub Repository Secrets:

- `KEYSTORE_BASE64`
- `KEYSTORE_PASSWORD`
- `KEY_ALIAS`
- `KEY_PASSWORD`

ถ้าครบทุกตัว workflow จะ decode keystore ลง Runner temp และ build signed Release APK

ถ้าไม่ครบ workflow **ยังต้อง build Debug ได้** และจะข้าม Release โดยไม่ถาม interactive prompt

ห้าม commit `.jks`, `.keystore`, `.pem`, private key, password หรือ `.env` จริง

## วิธีดาวน์โหลด APK จาก GitHub

1. แตก ZIP แล้วนำ **contents ที่อยู่ด้านใน ZIP** ขึ้น repository root
2. ตรวจให้ `.github/workflows/android-build.yml` อยู่จริงใน repository (GitHub Actions ไม่รัน workflow ที่ยังซ่อนอยู่ใน ZIP)
3. Push ไป GitHub
4. เปิดแท็บ **Actions**
5. เปิด run ที่สำเร็จ
6. ดาวน์โหลด artifact `HeavyMarket-v1.0.<run>-debug`

## Demo Mode / Live Mode

- **Demo:** upsert รายการรถ/เครื่องจักรตัวอย่าง 26 รายการลง Room แบบ idempotent ทุกครั้งที่เริ่มแอป พร้อมป้าย “ข้อมูลตัวอย่าง” และรูป local ที่ติดมากับ APK
- **Imported:** ข้อมูลที่ผู้ใช้แชร์/วาง URL หรือข้อความเข้ามา
- **Live:** ต้องเชื่อม backend/provider ที่ได้รับอนุญาตจริง โดยใช้ DTO/DataSource contract ที่เตรียมไว้ และห้ามแสดงสถานะ Facebook success จน provider จริงผ่าน authorization

## Error Handling

มี `ApiErrorMapper` สำหรับข้อความภาษาไทย:

- Timeout
- 401
- 403
- 429 Rate Limit
- 5xx
- ไม่มีอินเทอร์เน็ต / IOException
- fallback error

DataSource ถูกแยกจาก UI เพื่อไม่ให้ source เดียวล้มแล้วทำให้ทั้งแอป crash; Demo/Imported/Room ยังใช้งาน offline ได้

รูปภาพใช้ Coil; Demo ใช้ resource ภายใน APK และข้อมูล Live/Imported มี category fallback image ดังนั้น URL รูปเสีย/ไม่มีอินเทอร์เน็ตจะไม่ทำให้ card กลายเป็นช่องขาวหรือทำให้ process crash

## Security Checklist

`.gitignore` กันอย่างน้อย:

- `.env`
- keystore (`*.jks`, `*.keystore`)
- private key/certificate secret (`*.pem`, `*.p12`, `*.key`)
- `secrets.properties`
- build output/local Android config

Secret ฝั่ง server ใช้ environment variables/GitHub Secrets เท่านั้น

## สิ่งที่ตรวจใน ZIP นี้

อ่าน `BUILD_VALIDATION.md` สำหรับรายละเอียดครบ

สรุป: domain Kotlin logic, classifier behavior, YAML/XML, backend TypeScript syntax และ Gradle bootstrap ถูกตรวจใน environment นี้แล้ว

**ไม่ได้อ้างว่า APK build สำเร็จในเครื่องนี้** เพราะ environment ไม่มี Android SDK/Gradle distribution ที่ติดตั้งและไม่มี outbound network สำหรับดาวน์โหลด dependency; GitHub Actions ถูกจัดไว้ให้ทำ full `testDebugUnitTest + assembleDebug` จริงหลังนำ repository ขึ้น GitHub

## เมื่อ GitHub Actions Build Error

ส่ง Build Log ทั้งหมดกลับมาได้ โดยรักษา ZIP/version ล่าสุดเป็นฐาน จะต้องแก้ root cause ใน source/Gradle/YAML โดยไม่ให้คุณไปแก้เอง แล้วออก version ต่อไป เช่น `HeavyMarket_v6.zip`, `HeavyMarket_v7.zip`, `HeavyMarket_v8.zip` พร้อมอัปเดต `CHANGELOG.md` และรักษา feature เดิม


### หมายเหตุ Demo v8

Demo original links use an internal `demo://` scheme. ปุ่มเปิดโพสต์ภายนอกจะถูกปิดสำหรับข้อมูลตัวอย่าง เพื่อไม่ทำให้ผู้ใช้เข้าใจว่าเป็นประกาศจริงหรือถูกพาไป URL ปลอม
