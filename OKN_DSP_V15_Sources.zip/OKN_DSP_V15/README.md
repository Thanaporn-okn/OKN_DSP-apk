# OKN DSP V15 — Phase 1

V15 rebuilds the visual treatment to match the approved V15 reference image while preserving the real-time Phase 1 control/state layer.

- Uses the user-selected dark OKN DSP K-wave launcher icon.
- Header now uses the OKN DSP icon + OKN DSP title on Home / Mix / EQ.
- Home uses the reference red/pink + teal accents while preserving Bluetooth/status colors.
- Mix uses pink/red, teal and green controls with no orange or amber/yellow controls.
- EQ uses a blue -> pink/red -> teal/green -> pink/red 15-band spectrum.
- Frequency remains blue, Q remains cyan/teal, Gain Band remains mint green.
- Save Preset and selected navigation accents use the V15 hot-pink treatment.
- Fixed bottom navigation touch priority so tapping Mix/Home/EQ cannot activate an EQ/Mix slider hidden under the navigation bar.
- WindowInsets safe area, themes, real-time sliders, real-time EQ graph, persistence and multiple presets remain enabled.

Version: **15.0.0** (`versionCode 1015`)
