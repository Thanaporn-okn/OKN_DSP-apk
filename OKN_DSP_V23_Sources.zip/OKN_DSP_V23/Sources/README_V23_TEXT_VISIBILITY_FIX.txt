OKN_DSP V23 — Phase 1 Text Visibility Fix

Purpose
- Correct text that was visually covered or crowded on the real Samsung device in V22.
- Preserve the V22 reference proportions while adding safe vertical text gutters.

Changes
- Home: increased the 7 / 48 kHz / 32 bit / Bluetooth information band and moved captions upward so the Master Volume panel cannot cover glyph bottoms.
- EQ: reserved a dedicated x-axis label band so all 15 frequency captions remain visible above Band/Frequency/Gain/Q controls.
- EQ: added a little extra top padding to Frequency/Gain/Q captions.
- Firmware UI marker advanced to v23.
- Runtime UI remains 100% Canvas/vector drawn with no uploaded screenshot used as a background.

Phase 2
- Real BLE/DSP transport remains deferred until the control/protocol source data is supplied.
