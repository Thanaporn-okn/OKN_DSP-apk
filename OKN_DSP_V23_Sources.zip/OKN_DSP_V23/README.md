# OKN DSP V23 — Phase 1

V23 is built from V22 and targets the remaining visible hitch when selecting a saved preset or pressing Delete.

## V23 smoothness fix

- Saved Presets opens inside the existing hardware-accelerated DspView instead of creating a separate Android Dialog window.
- Delete confirmation also uses the same in-view modal compositor.
- Selecting a preset no longer queues a full 300+ key state rewrite during the interaction.
- Values still change immediately and are checkpointed when the app leaves the foreground.
- Light / Dark / Midnight styling remains supported.
- Existing Home/Mix/EQ touch protection remains unchanged.

- versionName: 23.0.0
- versionCode: 1023
- Base: V22
- Phase: 1 UI/performance hardening
