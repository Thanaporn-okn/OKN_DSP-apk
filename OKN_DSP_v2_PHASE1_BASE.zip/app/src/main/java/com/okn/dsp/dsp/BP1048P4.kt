package com.okn.dsp.dsp

class BP1048P4 {

    fun connect() {
        // Bluetooth UART - Phase 4
    }

    fun readParameter() {
    }

    fun writeVolume(value: Int) {
    }

    fun writeEQ(channel: Int, band: Int, gain: Float) {
    }

    fun writeDelay(channel: Int, ms: Float) {
    }

    fun writeCrossover(channel: Int) {
    }

    fun savePreset(slot: Int) {
    }
}