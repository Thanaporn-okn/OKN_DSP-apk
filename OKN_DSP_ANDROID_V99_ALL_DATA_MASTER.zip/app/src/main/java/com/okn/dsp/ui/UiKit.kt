package com.okn.dsp.ui

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import kotlin.math.roundToInt

object OknColors {
    val BG = Color.rgb(2, 11, 18)
    val BG2 = Color.rgb(3, 17, 27)
    val CARD = Color.rgb(5, 24, 36)
    val CARD_ALT = Color.rgb(7, 30, 44)
    val BORDER = Color.rgb(13, 61, 84)
    val CYAN = Color.rgb(24, 200, 255)
    val BLUE = Color.rgb(30, 132, 255)
    val TEXT = Color.rgb(235, 249, 255)
    val MUTED = Color.rgb(126, 166, 185)
    val GREEN = Color.rgb(54, 231, 143)
    val RED = Color.rgb(255, 77, 83)
    val YELLOW = Color.rgb(255, 210, 56)
    val PURPLE = Color.rgb(177, 64, 255)
    val PINK = Color.rgb(255, 69, 184)
    val ORANGE = Color.rgb(255, 132, 31)
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()
fun Context.sp(v: Int): Float = v * resources.displayMetrics.scaledDensity

fun roundedBg(color: Int, radius: Float, strokeColor: Int? = null, strokeWidth: Int = 1): GradientDrawable =
    GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        setColor(color)
        cornerRadius = radius
        if (strokeColor != null) setStroke(strokeWidth, strokeColor)
    }

fun View.pad(h: Int, v: Int) {
    val c = context
    setPadding(c.dp(h), c.dp(v), c.dp(h), c.dp(v))
}

fun Context.text(
    value: String,
    size: Int = 14,
    color: Int = OknColors.TEXT,
    bold: Boolean = false,
    gravity: Int = Gravity.START or Gravity.CENTER_VERTICAL,
): TextView = TextView(this).apply {
    text = value
    textSize = size.toFloat()
    setTextColor(color)
    this.gravity = gravity
    if (bold) setTypeface(typeface, Typeface.BOLD)
    includeFontPadding = false
}

fun Context.card(stroke: Int = OknColors.BORDER, fill: Int = OknColors.CARD): LinearLayout =
    LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = roundedBg(fill, dp(15).toFloat(), stroke, dp(1))
        pad(14, 12)
    }

fun Context.row(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.HORIZONTAL
    gravity = Gravity.CENTER_VERTICAL
}

fun View.setMargins(l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0) {
    val p = layoutParams as? ViewGroup.MarginLayoutParams ?: return
    p.setMargins(context.dp(l), context.dp(t), context.dp(r), context.dp(b))
    layoutParams = p
}

fun Context.makeSeek(min: Float, max: Float, initial: Float, onChange: (Float, Boolean) -> Unit): SeekBar =
    SeekBar(this).apply {
        this.max = 1000
        progress = (((initial - min) / (max - min)).coerceIn(0f, 1f) * 1000f).roundToInt()
        if (Build.VERSION.SDK_INT >= 21) {
            progressTintList = android.content.res.ColorStateList.valueOf(OknColors.CYAN)
            thumbTintList = android.content.res.ColorStateList.valueOf(Color.rgb(198, 236, 255))
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(31, 74, 94))
        }
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, p: Int, fromUser: Boolean) {
                val v = min + (max - min) * (p / 1000f)
                onChange(v, fromUser)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
    }

fun Context.appBar(title: String = "OKN_DSP", subtitle: String = "Digital Sound Processor", back: (() -> Unit)? = null): LinearLayout {
    return row().apply {
        setPadding(dp(12), dp(10), dp(12), dp(8))
        if (back != null) {
            addView(text("‹", 35, OknColors.CYAN, false, Gravity.CENTER).apply {
                setOnClickListener { back() }
                isClickable = true
            }, LinearLayout.LayoutParams(dp(36), dp(42)))
        }
        addView(LinearLayout(this@appBar).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            addView(text(title, 18, OknColors.TEXT, true, Gravity.CENTER))
            if (subtitle.isNotBlank()) addView(text(subtitle, 10, OknColors.MUTED, false, Gravity.CENTER))
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (back != null) addView(Space(this@appBar), LinearLayout.LayoutParams(dp(36), dp(42)))
    }
}

fun Context.sectionHeader(title: String, subtitle: String? = null): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    addView(text(title, 18, OknColors.TEXT, true))
    if (!subtitle.isNullOrBlank()) {
        addView(text(subtitle, 12, OknColors.MUTED).apply { setPadding(0, dp(2), 0, 0) })
    }
}

fun Context.neonButton(label: String, red: Boolean = false, onClick: () -> Unit): TextView =
    text(label, 14, Color.WHITE, true, Gravity.CENTER).apply {
        val c = if (red) OknColors.RED else OknColors.CYAN
        background = roundedBg(if (red) Color.rgb(157, 29, 38) else Color.rgb(5, 75, 99), dp(12).toFloat(), c, dp(1))
        pad(14, 12)
        setOnClickListener { onClick() }
        isClickable = true
        isFocusable = true
    }

fun TextView.setValueText(v: String, ok: Boolean = true) {
    text = v
    setTextColor(if (ok) OknColors.CYAN else OknColors.RED)
}
