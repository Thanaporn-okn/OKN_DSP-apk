package com.okn.dsp

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.ContentValues
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.widget.*
import androidx.core.app.ActivityCompat
import com.okn.dsp.protocol.*
import com.okn.dsp.transport.BleProfile
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * V56: guarded SaveParams persistence proof with stale-GATT UI race protection.
 *
 * It never exposes a generic Save button. The only SaveParams ID7 trigger can occur after:
 * 1) CH1 Band4 has been descriptor-verified at the exact 0.0 dB baseline, or
 * 2) that same band has been descriptor-verified restored to the exact baseline.
 *
 * Proof requires two REAL DSP power cycles:
 *   baseline 0.0 -> test -0.1 -> verify -> SaveParams trigger -> reboot -> verify -0.1 persisted
 *   -> restore 0.0 -> verify -> SaveParams trigger -> reboot -> verify 0.0 persisted.
 */
class SaveParamsProofActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private val ts = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    private val startupProbe16 = ByteCodec.hexToBytes("631C062443FD3844558001F3EDA0CCF8")

    private lateinit var status: TextView
    private lateinit var phaseView: TextView
    private lateinit var deviceList: LinearLayout
    private lateinit var startSessionButton: Button
    private lateinit var resumeTargetButton: Button
    private lateinit var prepareButton: Button
    private lateinit var targetSaveButton: Button
    private lateinit var restoreSaveButton: Button
    private lateinit var logView: TextView

    private var scanner: android.bluetooth.le.BluetoothLeScanner? = null
    private val found = LinkedHashMap<String, BluetoothDevice>()
    private var gatt: BluetoothGatt? = null
    private var ab01: BluetoothGattCharacteristic? = null
    private var ab02: BluetoothGattCharacteristic? = null
    private var connectedName: String? = null

    private var waitingAuth = false
    private var sessionReady = false
    private var txCipher: SessionTxCipher? = null
    private var rxCipher: SessionRxCipher? = null

    private enum class DescMode { INITIAL, VERIFY_PREPARE, VERIFY_TARGET, VERIFY_RESTORE }
    private var descMode: DescMode? = null
    private var descExpected = -1
    private val descBytes = ByteArrayOutputStream()

    private enum class Operation { NONE, PREPARE_ORIGINAL, TARGET_SAVE, RESTORE_SAVE }
    private var operation = Operation.NONE
    private var currentBand: EqBand48? = null
    private var pendingExpected: EqBand48? = null

    private enum class Phase {
        IDLE,
        WAIT_TARGET_REBOOT,
        TARGET_PERSISTED,
        WAIT_RESTORE_REBOOT,
        COMPLETE,
        SAVE_NOT_PROVEN,
        RESTORE_NOT_PERSISTED
    }

    private val prefs by lazy { getSharedPreferences("okn_v52_saveparams", MODE_PRIVATE) }
    private var phase: Phase
        get() = try { Phase.valueOf(prefs.getString("phase", Phase.IDLE.name) ?: Phase.IDLE.name) } catch (_: Exception) { Phase.IDLE }
        set(v) {
            prefs.edit().putString("phase", v.name).apply()
            if (::phaseView.isInitialized) runOnUiThread { updatePhaseView() }
        }

    private var saveParamsAwaitingResult = false
    private var saveParamsGattStatus: Int? = null

    private val captureLines = mutableListOf<String>()
    private var packetNo = 0

    private val descriptorDelayMs = 3000L
    private val saveCommitSettleMs = 5000L
    private var savePhaseBeforeQueue: Phase? = null
    private var saveAfterPending: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestBlePermissions()
        record("META", "V56_SAVEPARAMS_ACTIVITY_START localPhase=${phase.name}")
        record("META", "V56_TRIGGER_STATIC_POLICY actuator=7 type=2100 cpar=Trigger plain=${ByteCodec.run { SaveParamsPolicy.encodeTrigger().toHex() }} exact=${SaveParamsPolicy.triggerIsExact()}")
    }

    override fun onDestroy() {
        try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
        try { gatt?.close() } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 22, 22, 28)
        }
        root.addView(TextView(this).apply {
            text = "OKN DSP V56 — SAVEPARAMS PERSISTENCE PROOF"
            textSize = 22f
        })
        status = TextView(this).apply {
            text = "DISCONNECTED • no SaveParams sent"
            textSize = 14f
            setPadding(0, 8, 0, 4)
        }
        root.addView(status)
        phaseView = TextView(this).apply {
            textSize = 13f
            setPadding(0, 0, 0, 10)
        }
        root.addView(phaseView)
        updatePhaseView()

        root.addView(TextView(this).apply {
            text = "V56 พิสูจน์ SaveParams ID7 แบบจำกัดจุดเดียวเท่านั้น: CH1 / ID4 / Band4. ก่อนส่ง SaveParams ต้อง verify baseline/restore ด้วย Device Description. Trigger ที่กำลังทดสอบคือ UFE WRITE 0x57 → ID7 → offset0 → length0 → no payload (plain 570000000700000000). จะถือว่าพิสูจน์สำเร็จต่อเมื่อค่าทดสอบ -0.1 dB อยู่หลังปิด/เปิด DSP จริง และ original 0.0 dB อยู่หลังปิด/เปิดครั้งที่สอง."
            textSize = 13f
        })

        root.addView(Button(this).apply {
            text = "SCAN DSP"
            setOnClickListener { startScan() }
        })
        deviceList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(deviceList)

        startSessionButton = Button(this).apply {
            text = "START V56 PERSISTENCE SESSION"
            isEnabled = false
            setOnClickListener { confirmStartSession() }
        }
        root.addView(startSessionButton)

        resumeTargetButton = Button(this).apply {
            text = "RESUME V54/V55/V56 PENDING -0.1 dB SAVE ATTEMPT (NO WRITE)"
            isEnabled = false
            setOnClickListener { confirmResumePendingTarget() }
        }
        root.addView(resumeTargetButton)

        prepareButton = Button(this).apply {
            text = "PREPARE ORIGINAL CH1 BAND4 = 0.0 dB (NO SAVE)"
            isEnabled = false
            setOnClickListener { confirmPrepareOriginal() }
        }
        root.addView(prepareButton)

        targetSaveButton = Button(this).apply {
            text = "WRITE TEST -0.1 dB + VERIFY + SAVEPARAMS"
            isEnabled = false
            setOnClickListener { confirmTargetAndSave() }
        }
        root.addView(targetSaveButton)

        restoreSaveButton = Button(this).apply {
            text = "RESTORE ORIGINAL 0.0 dB + VERIFY + SAVEPARAMS"
            isEnabled = false
            setOnClickListener { confirmRestoreAndSave() }
        }
        root.addView(restoreSaveButton)

        root.addView(Button(this).apply {
            text = "SAVE V56 CAPTURE TO DOWNLOADS"
            setOnClickListener { saveCapture() }
        })

        logView = TextView(this).apply { textSize = 11f; setPadding(0, 12, 0, 0) }
        root.addView(logView)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun updatePhaseView() {
        if (!::phaseView.isInitialized) return
        phaseView.text = when (phase) {
            Phase.IDLE -> "LOCAL PHASE: IDLE • ยังไม่เริ่ม persistence proof"
            Phase.WAIT_TARGET_REBOOT -> "LOCAL PHASE: WAIT TARGET REBOOT • ต้องปิด/เปิด DSP แล้วเชื่อมใหม่เพื่อตรวจ -0.1 dB"
            Phase.TARGET_PERSISTED -> "LOCAL PHASE: TARGET PERSISTED VERIFIED • พร้อม restore original + SaveParams"
            Phase.WAIT_RESTORE_REBOOT -> "LOCAL PHASE: WAIT RESTORE REBOOT • ต้องปิด/เปิด DSP แล้วเชื่อมใหม่เพื่อตรวจ 0.0 dB"
            Phase.COMPLETE -> "LOCAL PHASE: COMPLETE • target และ original ผ่าน power-cycle persistence proof แล้ว"
            Phase.SAVE_NOT_PROVEN -> "LOCAL PHASE: SAVE NOT PROVEN • test value ไม่อยู่หลัง reboot"
            Phase.RESTORE_NOT_PERSISTED -> "LOCAL PHASE: RESTORE NOT PERSISTED • ต้อง retry restore + SaveParams ก่อนจบ"
        }
    }

    private fun confirmStartSession() {
        if (gatt == null || ab01 == null || ab02 == null) {
            Toast.makeText(this, "เชื่อม AB00/AB01/AB02 ก่อน", Toast.LENGTH_LONG).show(); return
        }
        if (operation != Operation.NONE || descMode != null) {
            Toast.makeText(this, "V56 กำลังทำงาน กรุณารอ", Toast.LENGTH_LONG).show(); return
        }
        AlertDialog.Builder(this)
            .setTitle("Start V56 persistence session")
            .setMessage("AUTH16 → derive RandKey → อ่าน Device Description สด → ตรวจ CH1 Band4 เทียบกับ local proof phase\n\nขั้นนี้ยังไม่ส่ง SaveParams")
            .setNegativeButton("ยกเลิก", null)
            .setPositiveButton("START READ-ONLY PERSISTENCE CHECK") { _, _ -> startSession() }
            .show()
    }

    private fun startSession() {
        val g = gatt ?: return
        val w = ab01 ?: return
        waitingAuth = true
        sessionReady = false
        txCipher = null
        rxCipher = null
        descMode = null
        descExpected = -1
        descBytes.reset()
        operation = Operation.NONE
        pendingExpected = null
        currentBand = null
        setActionButtons(false, false, false)
        record("META", "V56_SESSION_START localPhase=${phase.name}")
        if (!writeNoResponse(g, w, startupProbe16, "TX_AUTH16_V56")) {
            waitingAuth = false
            status.text = "AUTH16 queue failed"
        } else status.text = "AUTH16 sent • waiting 32B auth response"
    }

    private fun confirmResumePendingTarget() {
        val cur = currentBand
        val allowedPhase = phase == Phase.IDLE || phase == Phase.SAVE_NOT_PROVEN
        if (!sessionReady || !allowedPhase || operation != Operation.NONE || descMode != null || cur == null) {
            Toast.makeText(this, "RESUME ยังไม่พร้อม — ต้อง START read-only check ก่อน", Toast.LENGTH_LONG).show(); return
        }
        if (!SaveParamsPolicy.safeBandShape(cur) || !SaveParamsPolicy.boostMatches(cur.boostDb, SaveParamsPolicy.TEST_BOOST_DB)) {
            Toast.makeText(this, "RESUME อนุญาตเฉพาะ live -0.1 dB ที่ตรง V54/V55/V56 pending target", Toast.LENGTH_LONG).show(); return
        }
        AlertDialog.Builder(this)
            .setTitle("Resume pending target-save attempt")
            .setMessage("พบ CH1 Band4 = -0.1 dB แต่ local phase ยัง IDLE จาก V54 settle-hang. ขั้นนี้จะไม่ WRITE และไม่ส่ง SaveParams ซ้ำ; จะบันทึก WAIT_TARGET_REBOOT เท่านั้น เพื่อให้ power-cycle จริงพิสูจน์ว่าค่า -0.1 ถูก SaveParams เก็บไว้หรือไม่")
            .setNegativeButton("ยกเลิก", null)
            .setPositiveButton("ARM POWER-CYCLE VERIFY • NO WRITE") { _, _ ->
                phase = Phase.WAIT_TARGET_REBOOT
                record("META", "V56_RECOVER_V54_PENDING_TARGET_ARMED liveBoost=${cur.boostDb} noWrite=true saveParamsResent=false")
                status.text = "V56 RECOVERY ARMED • -0.1 dB live • NO WRITE / NO RESAVE • NOW POWER-CYCLE DSP, then reconnect + START V56"
                setActionButtons(false, false, false)
            }
            .show()
    }

    private fun confirmPrepareOriginal() {
        val allowedPhase = phase == Phase.IDLE || phase == Phase.SAVE_NOT_PROVEN
        if (!sessionReady || !allowedPhase || operation != Operation.NONE || descMode != null) {
            Toast.makeText(this, "PREPARE ยังไม่พร้อม: ต้องจบ read-only check และอยู่ phase IDLE/SAVE_NOT_PROVEN", Toast.LENGTH_LONG).show(); return
        }
        val cur = currentBand
        if (cur == null) {
            Toast.makeText(this, "ยังไม่มี live CH1 Band4 — กด START V56 PERSISTENCE SESSION ก่อน", Toast.LENGTH_LONG).show(); return
        }
        if (!SaveParamsPolicy.safeBandShape(cur) || !SaveParamsPolicy.boostMatches(cur.boostDb, SaveParamsPolicy.V51_LIVE_BOOST_DB)) {
            Toast.makeText(this, "Prepare อนุญาตเฉพาะ current -0.2 dB จาก V51", Toast.LENGTH_LONG).show(); return
        }
        record("META", "V56_PREPARE_BUTTON_TAP_ACCEPTED boost=${cur.boostDb} phase=${phase.name}")
        AlertDialog.Builder(this)
            .setTitle("Prepare original without SaveParams")
            .setMessage("CH1 Band4 ${fmt(cur.boostDb)} → 0.0 dB\n\nจะ WRITE + descriptor verify เท่านั้น และจะไม่ส่ง SaveParams ID7")
            .setNegativeButton("ยกเลิก", null)
            .setPositiveButton("PREPARE 0.0 • NO SAVE") { _, _ -> writeBand(Operation.PREPARE_ORIGINAL, SaveParamsPolicy.exactOriginalFrom(cur), DescMode.VERIFY_PREPARE) }
            .show()
    }

    private fun confirmTargetAndSave() {
        val cur = currentBand ?: return
        if (phase != Phase.IDLE && phase != Phase.SAVE_NOT_PROVEN) {
            Toast.makeText(this, "Local phase ไม่อนุญาต target test ตอนนี้", Toast.LENGTH_LONG).show(); return
        }
        if (!SaveParamsPolicy.safeBandShape(cur) || !SaveParamsPolicy.boostMatches(cur.boostDb, SaveParamsPolicy.ORIGINAL_BOOST_DB)) {
            Toast.makeText(this, "ต้อง verify exact baseline 0.0 dB ก่อน", Toast.LENGTH_LONG).show(); return
        }
        AlertDialog.Builder(this)
            .setTitle("V56 WRITE TEST + SAVEPARAMS")
            .setMessage("CH1 / ID4 / Band4\n0.0 → -0.1 dB → descriptor verify → SaveParams ID7 trigger\n\nหลัง SaveParams ต้องปิด/เปิด DSP จริง แล้วเชื่อม V56 ใหม่เพื่อตรวจว่าค่า -0.1 dB คงอยู่\n\nนี่เป็นการทดสอบ persistence จริง")
            .setNegativeButton("ยกเลิก", null)
            .setPositiveButton("WRITE -0.1 + VERIFY + SAVE") { _, _ ->
                val target = SaveParamsPolicy.testTargetFrom(cur)
                writeBand(Operation.TARGET_SAVE, target, DescMode.VERIFY_TARGET)
            }
            .show()
    }

    private fun confirmRestoreAndSave() {
        val cur = currentBand ?: return
        if (phase != Phase.TARGET_PERSISTED && phase != Phase.RESTORE_NOT_PERSISTED) {
            Toast.makeText(this, "ต้อง verify target persistence ก่อน restore-save", Toast.LENGTH_LONG).show(); return
        }
        if (!SaveParamsPolicy.safeBandShape(cur) || !SaveParamsPolicy.boostMatches(cur.boostDb, SaveParamsPolicy.TEST_BOOST_DB)) {
            Toast.makeText(this, "DSP ต้องอยู่ที่ persisted test -0.1 dB ก่อน restore", Toast.LENGTH_LONG).show(); return
        }
        AlertDialog.Builder(this)
            .setTitle("V56 RESTORE ORIGINAL + SAVEPARAMS")
            .setMessage("CH1 Band4 -0.1 → original 0.0 dB → descriptor verify → SaveParams ID7 trigger\n\nหลัง SaveParams ต้องปิด/เปิด DSP จริงอีกครั้ง แล้วเชื่อม V56 ใหม่เพื่อยืนยันว่า 0.0 dB คงอยู่")
            .setNegativeButton("ยกเลิก", null)
            .setPositiveButton("RESTORE 0.0 + VERIFY + SAVE") { _, _ ->
                writeBand(Operation.RESTORE_SAVE, SaveParamsPolicy.exactOriginalFrom(cur), DescMode.VERIFY_RESTORE)
            }
            .show()
    }

    private fun writeBand(op: Operation, expected: EqBand48, verifyMode: DescMode) {
        if (!WriteGate.saveParamsPersistenceProofEnabled || operation != Operation.NONE || descMode != null) return
        val g = gatt ?: return
        val w = ab01 ?: return
        val tx = txCipher ?: return
        operation = op
        pendingExpected = expected
        setActionButtons(false, false, false)
        val plain = LiveEqPolicy.encodeWrite(SaveParamsPolicy.TEST_CHANNEL, SaveParamsPolicy.TEST_BAND, expected)
        val enc = tx.encryptNext(plain)
        record("META", "V56_EQ_WRITE_PLAIN=${ByteCodec.run { plain.toHex() }} op=$op channel=1 actuator=4 band=4 offset=144 expectedBoost=${expected.boostDb} saveParams=false")
        if (!writeNoResponse(g, w, enc, "TX_EQ_CH1_B4_${op.name}_V56")) {
            operation = Operation.NONE
            pendingExpected = null
            status.text = "V56 EQ write queue failed"
            return
        }
        status.text = "V56 EQ WRITE sent • waiting descriptor verify"
        record("META", "V56_DESCRIPTOR_VERIFY_DELAY_MS=$descriptorDelayMs op=$op")
        handler.postDelayed({ requestDescriptor(verifyMode) }, descriptorDelayMs)
    }

    private fun requestDescriptor(mode: DescMode) {
        val g = gatt ?: return
        val w = ab01 ?: return
        val tx = txCipher ?: return
        if (descMode != null) return
        descMode = mode
        descExpected = -1
        descBytes.reset()
        val plain = SessionCryptoFacts.DEVICE_DESCRIPTION_REQUEST
        val enc = tx.encryptNext(plain)
        record("META", "V56_DESC_REQUEST mode=$mode plain=${ByteCodec.run { plain.toHex() }} localPhase=${phase.name}")
        if (!writeNoResponse(g, w, enc, "TX_DESC_V56_${mode.name}")) {
            descMode = null
            operation = Operation.NONE
            pendingExpected = null
            status.text = "Descriptor request queue failed"
        }
    }

    private fun handleAb02(value: ByteArray) {
        record("RX_NOTIFY", "len=${value.size} hex=${ByteCodec.run { value.toHex() }}")
        if (waitingAuth) {
            if (value.size != 32) return
            try {
                val d = PreAuthRandKeyDecoder.decode(value)
                txCipher = SessionTxCipher(d.randKey)
                rxCipher = SessionRxCipher(d.randKey)
                waitingAuth = false
                record("META", "V56_RANDKEY_DERIVED type=${d.typeId} ver=${d.versionId} rand=${ByteCodec.run { d.randKey.toHex() }}")
                requestDescriptor(DescMode.INITIAL)
            } catch (e: Exception) {
                waitingAuth = false
                record("META", "V56_AUTH_DECODE_ERROR ${e.javaClass.simpleName}:${e.message}")
                status.text = "Auth decode failed"
            }
            return
        }
        val rx = rxCipher ?: return
        val plain = try { rx.decryptNext(value) } catch (e: Exception) {
            record("META", "V56_RX_DECRYPT_ERROR ${e.javaClass.simpleName}:${e.message}")
            sessionReady = false
            return
        }
        record("RX_PLAIN", "len=${plain.size} hex=${ByteCodec.run { plain.toHex() }}")
        if (descMode != null) collectDescriptor(plain)
    }

    private fun collectDescriptor(plain: ByteArray) {
        val mode = descMode ?: return
        if (descExpected < 0) {
            if (plain.size < 4 || (plain[0].toInt() and 0xff) != 0x86) {
                record("META", "V56_DESC_NONHEADER mode=$mode marker=${plain.firstOrNull()?.toInt()?.and(0xff)} len=${plain.size}")
                return
            }
            descExpected = (plain[1].toInt() and 0xff) or ((plain[2].toInt() and 0xff) shl 8) or ((plain[3].toInt() and 0xff) shl 16)
            descBytes.reset()
            descBytes.write(plain, 4, plain.size - 4)
            record("META", "V56_DESC_HEADER mode=$mode jsonLen=$descExpected")
        } else {
            if (plain.isEmpty() || (plain[0].toInt() and 0xff) != 0x82) {
                record("META", "V56_DESC_NONCONT mode=$mode marker=${plain.firstOrNull()?.toInt()?.and(0xff)} len=${plain.size}")
                return
            }
            descBytes.write(plain, 1, plain.size - 1)
        }
        if (descExpected > 0 && descBytes.size() >= descExpected) {
            val bytes = descBytes.toByteArray().copyOf(descExpected)
            val obj = try { JSONObject(bytes.toString(Charsets.UTF_8)) } catch (e: Exception) {
                record("META", "V56_DESC_JSON_ERROR ${e.javaClass.simpleName}:${e.message}")
                descMode = null; descExpected = -1; descBytes.reset(); sessionReady = false; return
            }
            record("META", "V56_DESC_COMPLETE mode=$mode bytes=${bytes.size}")
            descMode = null
            descExpected = -1
            descBytes.reset()
            onDescriptorComplete(mode, obj)
        }
    }

    private fun onDescriptorComplete(mode: DescMode, obj: JSONObject) {
        val actual = extractBand(obj, SaveParamsPolicy.TEST_ACTUATOR, SaveParamsPolicy.TEST_BAND)
        if (actual == null || !SaveParamsPolicy.safeBandShape(actual)) {
            record("META", "V56_BLOCKED unexpected-or-missing-CH1-B4 mode=$mode")
            sessionReady = false
            operation = Operation.NONE
            pendingExpected = null
            status.text = "V56 BLOCKED • CH1 Band4 shape ไม่ตรง policy"
            setActionButtons(false, false, false)
            return
        }
        currentBand = actual
        when (mode) {
            DescMode.INITIAL -> evaluateInitial(actual)
            DescMode.VERIFY_PREPARE -> verifyPrepared(actual)
            DescMode.VERIFY_TARGET -> verifyTargetThenSave(actual)
            DescMode.VERIFY_RESTORE -> verifyRestoreThenSave(actual)
        }
    }

    private fun evaluateInitial(actual: EqBand48) {
        sessionReady = true
        operation = Operation.NONE
        pendingExpected = null
        val b = actual.boostDb
        record("META", "V56_INITIAL_CHECK localPhase=${phase.name} channel=1 actuator=4 band=4 boost=$b shapeSafe=true")
        when (phase) {
            Phase.IDLE, Phase.SAVE_NOT_PROVEN -> {
                when {
                    SaveParamsPolicy.boostMatches(b, SaveParamsPolicy.ORIGINAL_BOOST_DB) -> {
                        status.text = "V56 READY • exact original 0.0 dB verified • persistence test armed"
                        record("META", "V56_BASELINE_READY boost=$b target=-0.1 saveParamsSent=false")
                        armTargetReadyUi(actual, "initial-original")
                    }
                    SaveParamsPolicy.boostMatches(b, SaveParamsPolicy.V51_LIVE_BOOST_DB) -> {
                        record("META", "V56_V51_RAM_VALUE_DETECTED boost=$b prepareOriginalRequired=true")
                        armPrepareRequiredUi(actual)
                    }
                    SaveParamsPolicy.boostMatches(b, SaveParamsPolicy.TEST_BOOST_DB) -> {
                        record("META", "V56_PENDING_TARGET_RECOVERY_DETECTED boost=$b localPhase=${phase.name} source=V54-settle-hang-compatible")
                        armResumePendingTargetUi(actual)
                    }
                    else -> {
                        status.text = "V56 BLOCKED • baseline must be 0.0, known V51 -0.2 dB, or recoverable pending -0.1 dB"
                        record("META", "V56_BLOCKED unexpectedBaselineBoost=$b")
                        setActionButtons(false, false, false)
                    }
                }
            }
            Phase.WAIT_TARGET_REBOOT -> {
                if (SaveParamsPolicy.boostMatches(b, SaveParamsPolicy.TEST_BOOST_DB)) {
                    phase = Phase.TARGET_PERSISTED
                    record("META", "V56_TARGET_POWER_CYCLE_VERIFY expected=-0.1 actual=$b persisted=true")
                    status.text = "V56 TARGET PERSISTED VERIFIED • -0.1 dB survived DSP power-cycle • restore original next"
                    armRestoreReadyUi(actual, "target-persisted-after-reboot")
                } else {
                    phase = Phase.SAVE_NOT_PROVEN
                    record("META", "V56_TARGET_POWER_CYCLE_VERIFY expected=-0.1 actual=$b persisted=false")
                    status.text = "V56 SAVEPARAMS NOT PROVEN • -0.1 did not survive reboot • no further save"
                    if (SaveParamsPolicy.boostMatches(b, 0.0f)) armTargetReadyUi(actual, "save-not-proven-original")
                    else setActionButtons(false, false, false)
                }
            }
            Phase.TARGET_PERSISTED, Phase.RESTORE_NOT_PERSISTED -> {
                if (SaveParamsPolicy.boostMatches(b, SaveParamsPolicy.TEST_BOOST_DB)) {
                    status.text = "V56 TARGET PERSISTED • -0.1 dB confirmed • ready to restore original + SaveParams"
                    armRestoreReadyUi(actual, "target-persisted-recheck")
                } else if (SaveParamsPolicy.boostMatches(b, 0.0f) && phase == Phase.RESTORE_NOT_PERSISTED) {
                    status.text = "V56 restore currently 0.0 in RAM • reconnect state ambiguous • do not power-cycle yet"
                    setActionButtons(false, false, false)
                } else {
                    status.text = "V56 BLOCKED • target-persisted phase but DSP value=$b"
                    record("META", "V56_BLOCKED phase=${phase.name} unexpectedBoost=$b")
                    setActionButtons(false, false, false)
                }
            }
            Phase.WAIT_RESTORE_REBOOT -> {
                if (SaveParamsPolicy.boostMatches(b, SaveParamsPolicy.ORIGINAL_BOOST_DB)) {
                    phase = Phase.COMPLETE
                    record("META", "V56_RESTORE_POWER_CYCLE_VERIFY expected=0.0 actual=$b persisted=true")
                    record("META", "V56_SAVEPARAMS_PERSISTENCE_PROOF_COMPLETE triggerPlain=570000000700000000 targetPersisted=true originalRestoredPersisted=true saveParamsActuator=7 powerCycles=2")
                    status.text = "V56 COMPLETE • SaveParams persistence proven • original 0.0 dB persisted after second reboot"
                    setActionButtons(false, false, false)
                } else if (SaveParamsPolicy.boostMatches(b, SaveParamsPolicy.TEST_BOOST_DB)) {
                    phase = Phase.RESTORE_NOT_PERSISTED
                    record("META", "V56_RESTORE_POWER_CYCLE_VERIFY expected=0.0 actual=$b persisted=false")
                    status.text = "V56 RESTORE NOT PERSISTED • DSP returned -0.1 dB • retry restore + SaveParams"
                    armRestoreReadyUi(actual, "restore-not-persisted")
                } else {
                    phase = Phase.RESTORE_NOT_PERSISTED
                    record("META", "V56_RESTORE_POWER_CYCLE_VERIFY expected=0.0 actual=$b persisted=false unexpected=true")
                    status.text = "V56 BLOCKED • unexpected value after restore reboot: ${fmt(b)} dB"
                    setActionButtons(false, false, false)
                }
            }
            Phase.COMPLETE -> {
                val ok = SaveParamsPolicy.boostMatches(b, 0.0f)
                record("META", "V56_COMPLETE_RECHECK actual=$b originalStillPresent=$ok")
                status.text = if (ok) "V56 COMPLETE • original 0.0 dB still present" else "V56 COMPLETE STATE MISMATCH • save capture"
                setActionButtons(false, false, false)
            }
        }
    }

    private fun verifyPrepared(actual: EqBand48) {
        val expected = pendingExpected
        val ok = expected != null && LiveEqPolicy.semanticMatches(actual, expected)
        record("META", "V56_PREPARE_DESCRIPTOR_VERIFY expectedBoost=${expected?.boostDb ?: Float.NaN} actualBoost=${actual.boostDb} verified=$ok saveParamsSent=false")
        operation = Operation.NONE
        pendingExpected = null
        if (ok) {
            currentBand = actual
            status.text = "V56 PREPARED • original 0.0 dB verified • NO SaveParams sent • ready for persistence test"
            record("META", "V56_PREPARE_COMPLETE originalBoost=0.0 saveParamsSent=false")
            armTargetReadyUi(actual, "prepare-complete")
        } else {
            status.text = "V56 PREPARE VERIFY FAILED • save capture • stop"
            setActionButtons(false, false, false)
        }
    }

    private fun verifyTargetThenSave(actual: EqBand48) {
        val expected = pendingExpected
        val ok = expected != null && LiveEqPolicy.semanticMatches(actual, expected)
        record("META", "V56_TARGET_DESCRIPTOR_VERIFY expectedBoost=${expected?.boostDb ?: Float.NaN} actualBoost=${actual.boostDb} verified=$ok")
        if (!ok) {
            operation = Operation.NONE
            pendingExpected = null
            status.text = "V56 TARGET VERIFY FAILED • SaveParams NOT sent • stop"
            record("META", "V56_STOPPED stage=target-verify saveParamsSent=false")
            setActionButtons(false, false, false)
            return
        }
        currentBand = actual
        sendSaveParams(after = "TARGET")
    }

    private fun verifyRestoreThenSave(actual: EqBand48) {
        val expected = pendingExpected
        val ok = expected != null && LiveEqPolicy.semanticMatches(actual, expected)
        record("META", "V56_RESTORE_DESCRIPTOR_VERIFY expectedBoost=${expected?.boostDb ?: Float.NaN} actualBoost=${actual.boostDb} verified=$ok")
        if (!ok) {
            operation = Operation.NONE
            pendingExpected = null
            status.text = "V56 RESTORE VERIFY FAILED • SaveParams NOT sent • stop"
            record("META", "V56_STOPPED stage=restore-verify saveParamsSent=false")
            setActionButtons(false, false, false)
            return
        }
        currentBand = actual
        sendSaveParams(after = "RESTORE")
    }

    private fun sendSaveParams(after: String) {
        val g = gatt ?: return
        val w = ab01 ?: return
        val tx = txCipher ?: return
        val plain = SaveParamsPolicy.encodeTrigger()
        if (!SaveParamsPolicy.triggerIsExact()) {
            status.text = "V56 INTERNAL BLOCK • SaveParams trigger bytes mismatch"
            record("META", "V56_BLOCKED triggerEncodingMismatch plain=${ByteCodec.run { plain.toHex() }}")
            return
        }
        val enc = tx.encryptNext(plain)
        saveParamsAwaitingResult = true
        saveParamsGattStatus = null
        savePhaseBeforeQueue = phase
        saveAfterPending = after
        record("META", "V56_SAVEPARAMS_TRIGGER_PLAIN=${ByteCodec.run { plain.toHex() }} after=$after actuator=7 type=2100 offset=0 length=0 payload=none")
        if (!writeNoResponse(g, w, enc, "TX_SAVEPARAMS_ID7_V56_AFTER_$after")) {
            saveParamsAwaitingResult = false
            saveAfterPending = null
            savePhaseBeforeQueue = null
            operation = Operation.NONE
            pendingExpected = null
            status.text = "V56 SaveParams queue failed • DO NOT power-cycle • save capture"
            record("META", "V56_STOPPED stage=saveparams-queue after=$after queued=false")
            setActionButtons(false, false, false)
            return
        }

        // V54 could remain forever on the delayed 3500 ms UI transition. V56 never makes proof state
        // depend on a delayed Handler runnable: persist the reboot-verification phase immediately
        // after Android accepts the exact guarded ID7 write into the GATT queue. This is only an
        // ATTEMPT marker; persistence is still proven exclusively by the later real power-cycle.
        operation = Operation.NONE
        pendingExpected = null
        phase = if (after == "TARGET") Phase.WAIT_TARGET_REBOOT else Phase.WAIT_RESTORE_REBOOT
        record("META", "V56_SAVE_PHASE_PERSISTED_IMMEDIATELY after=$after phase=${phase.name} proofClaimed=false settleMs=$saveCommitSettleMs")
        record("META", "V56_SAVEPARAMS_QUEUE_OK after=$after settleMs=$saveCommitSettleMs")
        status.text = "V56 SaveParams queued after $after • phase persisted • WAIT 5 seconds before power-cycle"
        setActionButtons(false, false, false)

        val expectedPhase = phase
        handler.postDelayed({
            if (saveParamsGattStatus != null && saveParamsGattStatus != BluetoothGatt.GATT_SUCCESS) return@postDelayed
            saveParamsAwaitingResult = false
            saveAfterPending = null
            savePhaseBeforeQueue = null
            if (phase != expectedPhase) return@postDelayed
            if (after == "TARGET") {
                record("META", "V56_TARGET_SAVE_SETTLED expectedAfterReboot=-0.1 userMustPowerCycle=true")
                status.text = "V56 TARGET SAVED ATTEMPT • NOW POWER-CYCLE DSP • then reconnect + START V56 to verify -0.1 dB"
            } else {
                record("META", "V56_RESTORE_SAVE_SETTLED expectedAfterReboot=0.0 userMustPowerCycle=true")
                status.text = "V56 RESTORE SAVED ATTEMPT • NOW POWER-CYCLE DSP • then reconnect + START V56 to verify original 0.0 dB"
            }
        }, saveCommitSettleMs)

        // Independent background watchdog: it does not own proof state (already persisted above),
        // but re-posts the instruction in case a device-specific main Handler delay is lost.
        Thread {
            var slept = true
            try { Thread.sleep(saveCommitSettleMs + 750L) } catch (_: InterruptedException) { slept = false }
            if (slept && phase == expectedPhase && (saveParamsGattStatus == null || saveParamsGattStatus == BluetoothGatt.GATT_SUCCESS)) {
                record("META", "V56_SETTLE_WATCHDOG_FIRED after=$after phase=${phase.name}")
                runOnUiThread {
                    status.text = if (after == "TARGET")
                        "V56 TARGET SAVE ATTEMPT ARMED • >5s elapsed • NOW POWER-CYCLE DSP • reconnect + START V56"
                    else
                        "V56 RESTORE SAVE ATTEMPT ARMED • >5s elapsed • NOW POWER-CYCLE DSP • reconnect + START V56"
                }
            }
        }.start()
    }

    private fun setActionButtons(prepare: Boolean, target: Boolean, restore: Boolean) {
        runOnUiThread {
            if (::resumeTargetButton.isInitialized) {
                resumeTargetButton.isEnabled = false
                resumeTargetButton.isClickable = false
                resumeTargetButton.alpha = 0.45f
            }
            prepareButton.isEnabled = prepare
            prepareButton.isClickable = prepare
            prepareButton.alpha = if (prepare) 1.0f else 0.45f
            targetSaveButton.isEnabled = target
            targetSaveButton.isClickable = target
            targetSaveButton.alpha = if (target) 1.0f else 0.45f
            restoreSaveButton.isEnabled = restore
            restoreSaveButton.isClickable = restore
            restoreSaveButton.alpha = if (restore) 1.0f else 0.45f
            record("META", "V56_ACTION_BUTTONS_UI prepare=$prepare target=$target restore=$restore phase=${phase.name} sessionReady=$sessionReady")
        }
    }

    private fun armTargetReadyUi(actual: EqBand48, reason: String) {
        currentBand = actual
        val applyUi = {
            prepareButton.isEnabled = false
            prepareButton.isClickable = false
            prepareButton.alpha = 0.45f
            targetSaveButton.isEnabled = true
            targetSaveButton.isClickable = true
            targetSaveButton.alpha = 1.0f
            restoreSaveButton.isEnabled = false
            restoreSaveButton.isClickable = false
            restoreSaveButton.alpha = 0.45f
            record("META", "V56_TARGET_UI_ARMED reason=$reason enabled=${targetSaveButton.isEnabled} clickable=${targetSaveButton.isClickable} boost=${actual.boostDb} phase=${phase.name}")
        }
        runOnUiThread(applyUi)
        listOf(250L, 1000L).forEach { delay ->
            handler.postDelayed({
                val cur = currentBand
                val allowedPhase = phase == Phase.IDLE || phase == Phase.SAVE_NOT_PROVEN
                val safe = cur != null && SaveParamsPolicy.safeBandShape(cur) &&
                    SaveParamsPolicy.boostMatches(cur.boostDb, SaveParamsPolicy.ORIGINAL_BOOST_DB)
                if (sessionReady && allowedPhase && safe && operation == Operation.NONE && descMode == null) {
                    runOnUiThread {
                        targetSaveButton.isEnabled = true
                        targetSaveButton.isClickable = true
                        targetSaveButton.alpha = 1.0f
                        record("META", "V56_TARGET_UI_REASSERT delayMs=$delay reason=$reason enabled=${targetSaveButton.isEnabled} clickable=${targetSaveButton.isClickable}")
                    }
                }
            }, delay)
        }
    }

    private fun armRestoreReadyUi(actual: EqBand48, reason: String) {
        currentBand = actual
        val applyUi = {
            prepareButton.isEnabled = false
            prepareButton.isClickable = false
            prepareButton.alpha = 0.45f
            targetSaveButton.isEnabled = false
            targetSaveButton.isClickable = false
            targetSaveButton.alpha = 0.45f
            restoreSaveButton.isEnabled = true
            restoreSaveButton.isClickable = true
            restoreSaveButton.alpha = 1.0f
            record("META", "V56_RESTORE_UI_ARMED reason=$reason enabled=${restoreSaveButton.isEnabled} clickable=${restoreSaveButton.isClickable} boost=${actual.boostDb} phase=${phase.name}")
        }
        runOnUiThread(applyUi)
        listOf(250L, 1000L).forEach { delay ->
            handler.postDelayed({
                val cur = currentBand
                val allowedPhase = phase == Phase.TARGET_PERSISTED || phase == Phase.RESTORE_NOT_PERSISTED
                val safe = cur != null && SaveParamsPolicy.safeBandShape(cur) &&
                    SaveParamsPolicy.boostMatches(cur.boostDb, SaveParamsPolicy.TEST_BOOST_DB)
                if (sessionReady && allowedPhase && safe && operation == Operation.NONE && descMode == null) {
                    runOnUiThread {
                        restoreSaveButton.isEnabled = true
                        restoreSaveButton.isClickable = true
                        restoreSaveButton.alpha = 1.0f
                        record("META", "V56_RESTORE_UI_REASSERT delayMs=$delay reason=$reason enabled=${restoreSaveButton.isEnabled} clickable=${restoreSaveButton.isClickable}")
                    }
                }
            }, delay)
        }
        // Independent from the main Handler; survives the same class of delayed UI race seen in V54/V55.
        reassertRestoreUiFromBackground(reason)
    }

    private fun armResumePendingTargetUi(actual: EqBand48) {
        currentBand = actual
        runOnUiThread {
            status.text = "V56 RECOVERY • live -0.1 dB detected while local phase=${phase.name} • V54 settle-hang compatible • RESUME without re-writing"
            resumeTargetButton.isEnabled = true
            resumeTargetButton.isClickable = true
            resumeTargetButton.alpha = 1.0f
            prepareButton.isEnabled = false
            targetSaveButton.isEnabled = false
            restoreSaveButton.isEnabled = false
            record("META", "V56_PENDING_TARGET_RECOVERY_UI_ARMED enabled=${resumeTargetButton.isEnabled} clickable=${resumeTargetButton.isClickable} boost=${actual.boostDb}")
        }
    }

    private fun armPrepareRequiredUi(actual: EqBand48) {
        currentBand = actual
        val applyUi = {
            status.text = "V56 PREPARE REQUIRED • V51 live -0.2 dB detected • restore 0.0 first (NO SAVE)"
            prepareButton.isEnabled = true
            prepareButton.isClickable = true
            prepareButton.alpha = 1.0f
            targetSaveButton.isEnabled = false
            targetSaveButton.isClickable = false
            targetSaveButton.alpha = 0.45f
            restoreSaveButton.isEnabled = false
            restoreSaveButton.isClickable = false
            restoreSaveButton.alpha = 0.45f
            record("META", "V56_PREPARE_UI_ARMED enabled=${prepareButton.isEnabled} clickable=${prepareButton.isClickable} boost=${actual.boostDb} phase=${phase.name}")
        }
        runOnUiThread(applyUi)
        // Samsung/Android UI state re-assertion: V52 showed PREPARE REQUIRED while the button
        // could remain disabled. Re-apply only while the guarded -0.2 dB precondition still holds.
        listOf(250L, 1000L).forEach { delay ->
            handler.postDelayed({
                val cur = currentBand
                val allowedPhase = phase == Phase.IDLE || phase == Phase.SAVE_NOT_PROVEN
                val safe = cur != null && SaveParamsPolicy.safeBandShape(cur) &&
                    SaveParamsPolicy.boostMatches(cur.boostDb, SaveParamsPolicy.V51_LIVE_BOOST_DB)
                if (sessionReady && allowedPhase && safe && operation == Operation.NONE && descMode == null) {
                    runOnUiThread {
                        prepareButton.isEnabled = true
                        prepareButton.isClickable = true
                        prepareButton.alpha = 1.0f
                        record("META", "V56_PREPARE_UI_REASSERT delayMs=$delay enabled=${prepareButton.isEnabled} clickable=${prepareButton.isClickable}")
                    }
                }
            }, delay)
        }
    }

    private fun extractBand(obj: JSONObject, actuatorId: Int, bandIndex1: Int): EqBand48? {
        val arr = obj.optJSONArray("actuators") ?: return null
        for (i in 0 until arr.length()) {
            val a = arr.optJSONObject(i) ?: continue
            if (a.optInt("ID", -1) != actuatorId || a.optInt("type", -1) != 4084) continue
            val bandArr = a.optJSONArray("UFE_TYPE_BIQUAD_CASCADE15_F") ?: return null
            val b = bandArr.optJSONObject(bandIndex1 - 1) ?: return null
            fun f(key: String): Float = b.optDouble(key, Double.NaN).toFloat()
            val out = EqBand48(
                type = b.optInt("typ", -1),
                frequency = f("F"), frequency2 = f("F2"), q = f("Q"), boostDb = f("B"),
                gain = f("G"), r = f("R"), b0 = f("B0"), b1 = f("B1"), b2 = f("B2"),
                a1 = f("A1"), a2 = f("A2"),
            )
            if (listOf(out.frequency, out.frequency2, out.q, out.boostDb, out.gain, out.r, out.b0, out.b1, out.b2, out.a1, out.a2).any { !it.isFinite() }) return null
            return out
        }
        return null
    }

    private fun startScan() {
        if (!hasBlePermission()) { requestBlePermissions(); return }
        val adapter = getSystemService(BluetoothManager::class.java)?.adapter ?: return
        if (!adapter.isEnabled) { Toast.makeText(this, "เปิด Bluetooth ก่อน", Toast.LENGTH_SHORT).show(); return }
        found.clear(); deviceList.removeAllViews()
        scanner = adapter.bluetoothLeScanner
        status.text = "SCANNING"
        try { scanner?.startScan(scanCallback) } catch (_: SecurityException) { return }
        handler.postDelayed({ try { scanner?.stopScan(scanCallback) } catch (_: Exception) {} }, 10000L)
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val d = result.device
            val name = result.scanRecord?.deviceName ?: try { d.name } catch (_: SecurityException) { null }
            if (name?.contains("GOLOPINE", true) != true && name?.contains("DSP", true) != true) return
            if (found.putIfAbsent(d.address, d) != null) return
            runOnUiThread {
                deviceList.addView(Button(this@SaveParamsProofActivity).apply {
                    text = "${name ?: "DSP"} • ${d.address}\nแตะเพื่อเชื่อมต่อ"
                    setOnClickListener { connect(d, name ?: "DSP") }
                })
            }
        }
    }

    /**
     * V56 root fix for the grey-action-button race seen after a real DSP power-cycle.
     * Android may deliver STATE_DISCONNECTED from the PREVIOUS BluetoothGatt after a new
     * connection has already completed. V55 treated that stale callback as current and could
     * disable every action button after TARGET_PERSISTED had already been verified.
     *
     * Never allow callbacks from a closed/replaced GATT object to mutate protocol/UI state.
     */
    private fun staleGatt(callbackGatt: BluetoothGatt, where: String): Boolean {
        val active = gatt
        if (active != null && callbackGatt !== active) {
            record("META", "V56_STALE_GATT_CALLBACK_IGNORED where=$where callback=${System.identityHashCode(callbackGatt)} active=${System.identityHashCode(active)} phase=${phase.name}")
            return true
        }
        return false
    }

    private fun reassertRestoreUiFromBackground(reason: String) {
        listOf(350L, 1500L, 3500L).forEach { delayMs ->
            Thread {
                try { Thread.sleep(delayMs) } catch (_: InterruptedException) { return@Thread }
                val cur = currentBand
                val allowedPhase = phase == Phase.TARGET_PERSISTED || phase == Phase.RESTORE_NOT_PERSISTED
                val safe = cur != null && SaveParamsPolicy.safeBandShape(cur) &&
                    SaveParamsPolicy.boostMatches(cur.boostDb, SaveParamsPolicy.TEST_BOOST_DB)
                if (sessionReady && allowedPhase && safe && operation == Operation.NONE && descMode == null) {
                    runOnUiThread {
                        restoreSaveButton.isEnabled = true
                        restoreSaveButton.isClickable = true
                        restoreSaveButton.alpha = 1.0f
                        record("META", "V56_RESTORE_UI_BACKGROUND_REASSERT delayMs=$delayMs reason=$reason enabled=${restoreSaveButton.isEnabled} clickable=${restoreSaveButton.isClickable} phase=${phase.name}")
                    }
                }
            }.start()
        }
    }

    private fun connect(device: BluetoothDevice, name: String) {
        if (!hasBlePermission()) return
        try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
        try { gatt?.close() } catch (_: Exception) {}
        connectedName = name
        status.text = "CONNECTING $name"
        record("META", "V56_CONNECT_START name=$name address=${device.address} localPhase=${phase.name}")
        try { gatt = device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE) }
        catch (_: SecurityException) { status.text = "CONNECT permission error" }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, statusCode: Int, newState: Int) {
            if (staleGatt(g, "onConnectionStateChange:$newState")) return
            record("META", "GATT_STATE status=$statusCode newState=$newState")
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                runOnUiThread { status.text = "CONNECTED ${connectedName ?: "DSP"} • discovering" }
                try {
                    g.requestMtu(517)
                    handler.postDelayed({ try { g.discoverServices() } catch (_: SecurityException) {} }, 250L)
                } catch (_: SecurityException) {}
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                sessionReady = false; waitingAuth = false; txCipher = null; rxCipher = null
                runOnUiThread {
                    status.text = when (phase) {
                        Phase.WAIT_TARGET_REBOOT -> "DSP DISCONNECTED • if power-cycling, wait then SCAN/CONNECT and START V56"
                        Phase.WAIT_RESTORE_REBOOT -> "DSP DISCONNECTED • after power-cycle, SCAN/CONNECT and START V56"
                        else -> "DISCONNECTED"
                    }
                    startSessionButton.isEnabled = false
                    setActionButtons(false, false, false)
                }
            }
        }

        override fun onMtuChanged(g: BluetoothGatt, mtu: Int, statusCode: Int) {
            if (staleGatt(g, "onMtuChanged")) return
            record("META", "MTU_CHANGED mtu=$mtu status=$statusCode")
        }

        override fun onServicesDiscovered(g: BluetoothGatt, statusCode: Int) {
            if (staleGatt(g, "onServicesDiscovered")) return
            val service = g.getService(BleProfile.AB00_SERVICE)
            ab01 = service?.getCharacteristic(BleProfile.AB01_WRITE)
            ab02 = service?.getCharacteristic(BleProfile.AB02_NOTIFY)
            val ok = statusCode == BluetoothGatt.GATT_SUCCESS && ab01 != null && ab02 != null
            record("META", "SERVICES_DISCOVERED status=$statusCode AB01=${ab01 != null} AB02=${ab02 != null}")
            if (!ok) { runOnUiThread { status.text = "AB00/AB01/AB02 profile not found" }; return }
            subscribeAb02(g, ab02!!)
            runOnUiThread { status.text = "CONNECTED • enabling AB02 notifications"; startSessionButton.isEnabled = false }
        }

        override fun onDescriptorWrite(g: BluetoothGatt, descriptor: BluetoothGattDescriptor, statusCode: Int) {
            if (staleGatt(g, "onDescriptorWrite")) return
            record("META", "CCCD_WRITE status=$statusCode")
            runOnUiThread {
                if (statusCode == BluetoothGatt.GATT_SUCCESS) {
                    status.text = "CONNECTED • AB02 notifications READY"
                    startSessionButton.isEnabled = true
                } else {
                    status.text = "CCCD notification enable failed: $statusCode"
                    startSessionButton.isEnabled = false
                }
            }
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, statusCode: Int) {
            if (staleGatt(g, "onCharacteristicWrite")) return
            record("META", "TX_WRITE_RESULT status=$statusCode uuid=${characteristic.uuid}")
            if (saveParamsAwaitingResult && characteristic.uuid == BleProfile.AB01_WRITE) {
                saveParamsGattStatus = statusCode
                record("META", "V56_SAVEPARAMS_GATT_RESULT status=$statusCode after=${saveAfterPending ?: "unknown"}")
                if (statusCode != BluetoothGatt.GATT_SUCCESS) {
                    val prior = savePhaseBeforeQueue ?: Phase.IDLE
                    phase = prior
                    saveParamsAwaitingResult = false
                    val after = saveAfterPending ?: "UNKNOWN"
                    saveAfterPending = null
                    savePhaseBeforeQueue = null
                    operation = Operation.NONE
                    pendingExpected = null
                    runOnUiThread {
                        status.text = "V56 SaveParams GATT failed status=$statusCode after=$after • phase rolled back • DO NOT power-cycle"
                        setActionButtons(false, false, false)
                    }
                    record("META", "V56_STOPPED stage=saveparams-gatt-result after=$after status=$statusCode phaseRolledBack=${prior.name}")
                }
            }
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            if (staleGatt(g, "onCharacteristicChanged33")) return
            if (characteristic.uuid == BleProfile.AB02_NOTIFY) handleAb02(value)
        }

        @Suppress("DEPRECATION")
        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            if (staleGatt(g, "onCharacteristicChangedLegacy")) return
            if (android.os.Build.VERSION.SDK_INT < 33 && characteristic.uuid == BleProfile.AB02_NOTIFY) handleAb02(characteristic.value ?: byteArrayOf())
        }
    }

    private fun subscribeAb02(g: BluetoothGatt, ch: BluetoothGattCharacteristic) {
        if (!hasBlePermission()) return
        try {
            g.setCharacteristicNotification(ch, true)
            val cccd = ch.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")) ?: return
            val v = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            if (android.os.Build.VERSION.SDK_INT >= 33) g.writeDescriptor(cccd, v)
            else {
                @Suppress("DEPRECATION") cccd.value = v
                @Suppress("DEPRECATION") g.writeDescriptor(cccd)
            }
        } catch (e: Exception) { record("META", "SUBSCRIBE_ERROR ${e.javaClass.simpleName}:${e.message}") }
    }

    private fun writeNoResponse(g: BluetoothGatt, ch: BluetoothGattCharacteristic, bytes: ByteArray, label: String): Boolean {
        if (!hasBlePermission()) return false
        record("TX", "$label len=${bytes.size} hex=${ByteCodec.run { bytes.toHex() }}")
        return try {
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                g.writeCharacteristic(ch, bytes, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE) == BluetoothStatusCodes.SUCCESS
            } else {
                @Suppress("DEPRECATION") ch.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                @Suppress("DEPRECATION") ch.value = bytes
                @Suppress("DEPRECATION") g.writeCharacteristic(ch)
            }
        } catch (e: Exception) {
            record("META", "$label ERROR ${e.javaClass.simpleName}:${e.message}")
            false
        }
    }

    private fun record(kind: String, text: String) {
        val line = "${ts.format(Date())}\t#${++packetNo}\t$kind\t$text"
        synchronized(captureLines) { captureLines.add(line) }
        runOnUiThread { logView.text = (logView.text.toString() + line + "\n").takeLast(18000) }
    }

    private fun saveCapture() {
        val text = buildString {
            append("=== OKN DSP V56 SAVEPARAMS PERSISTENCE PROOF CAPTURE ===\n")
            append("# localPhase=${phase.name}\n")
            synchronized(captureLines) { captureLines.forEach { append(it).append('\n') } }
        }
        val name = "OKN_DSP_V56_CAPTURE_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.txt"
        try {
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: error("insert failed")
                contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) }
                Toast.makeText(this, "Saved Downloads/$name", Toast.LENGTH_LONG).show()
            } else {
                val f = java.io.File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), name)
                f.writeText(text)
                Toast.makeText(this, "Saved ${f.absolutePath}", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) { Toast.makeText(this, "Save failed: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun requestBlePermissions() {
        val perms = if (android.os.Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (perms.any { ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }) {
            ActivityCompat.requestPermissions(this, perms, 1052)
        }
    }

    private fun hasBlePermission(): Boolean = if (android.os.Build.VERSION.SDK_INT >= 31) {
        ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
    } else ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun fmt(v: Float): String = String.format(Locale.US, "%.3f", v)
}
