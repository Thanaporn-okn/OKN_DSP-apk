package com.okn.peramp;

/**
 * In-memory DSP core. It can be connected to an AudioTrack/AAudio/vendor stream later.
 * This class performs master gain and 15 peaking EQ filters per selected group.
 */
public final class DspEngine {
    private DspEngine() {}

    public static void processInterleavedStereo(float[] pcm, int sampleRate, DspState state, int group) {
        if (pcm == null || state == null || pcm.length < 2) return;
        int g = Math.max(0, Math.min(DspState.GROUPS - 1, group));
        Biquad[] left = new Biquad[DspState.BANDS];
        Biquad[] right = new Biquad[DspState.BANDS];
        for (int i = 0; i < DspState.BANDS; i++) {
            DspState.PeqBand b = state.peq[g][i];
            left[i] = Biquad.peaking(sampleRate, b.frequencyHz, b.q, b.gainDb);
            right[i] = Biquad.peaking(sampleRate, b.frequencyHz, b.q, b.gainDb);
        }

        // HOME master volume is represented as 0..100%. 70% is the default.
        float master = Math.max(0f, Math.min(1f, state.masterVolume / 100f));
        for (int i = 0; i + 1 < pcm.length; i += 2) {
            float l = pcm[i] * master;
            float r = pcm[i + 1] * master;
            for (int b = 0; b < DspState.BANDS; b++) {
                l = left[b].process(l);
                r = right[b].process(r);
            }
            pcm[i] = clamp(l);
            pcm[i + 1] = clamp(r);
        }
    }

    private static float clamp(float v) {
        return Math.max(-1f, Math.min(1f, v));
    }

    private static final class Biquad {
        private final double b0, b1, b2, a1, a2;
        private double z1, z2;

        private Biquad(double b0, double b1, double b2, double a1, double a2) {
            this.b0 = b0;
            this.b1 = b1;
            this.b2 = b2;
            this.a1 = a1;
            this.a2 = a2;
        }

        static Biquad peaking(int sampleRate, float frequencyHz, float q, float gainDb) {
            double f = Math.max(20.0, Math.min(sampleRate * 0.45, frequencyHz));
            double safeQ = Math.max(0.1, Math.min(10.0, q));
            double a = Math.pow(10.0, gainDb / 40.0);
            double w0 = 2.0 * Math.PI * f / sampleRate;
            double alpha = Math.sin(w0) / (2.0 * safeQ);
            double cos = Math.cos(w0);

            double B0 = 1.0 + alpha * a;
            double B1 = -2.0 * cos;
            double B2 = 1.0 - alpha * a;
            double A0 = 1.0 + alpha / a;
            double A1 = -2.0 * cos;
            double A2 = 1.0 - alpha / a;

            return new Biquad(B0 / A0, B1 / A0, B2 / A0, A1 / A0, A2 / A0);
        }

        float process(float in) {
            double out = b0 * in + z1;
            z1 = b1 * in - a1 * out + z2;
            z2 = b2 * in - a2 * out;
            return (float) out;
        }
    }
}
