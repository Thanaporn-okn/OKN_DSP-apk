package com.okn.peramp;

/**
 * Hardware boundary. Implement this interface for the real DSP device protocol
 * (USB serial, Bluetooth, TCP, vendor SDK, etc.). UI state remains independent.
 */
public interface DspTransport {
    boolean isConnected();
    String deviceName();
    void sendFullState(DspState state) throws Exception;
}
