package com.okn.peramp;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity {
    private static final int C_BG = Color.rgb(7, 16, 25);
    private static final int C_TEXT = Color.rgb(246, 249, 255);
    private static final int C_MUTED = Color.rgb(180, 195, 214);
    private static final int C_ACCENT = Color.rgb(55, 206, 196);
    private static final int C_ACCENT2 = Color.rgb(90, 190, 255);
    private static final int C_PANEL = Color.argb(222, 14, 22, 35);
    private static final int C_PANEL2 = Color.argb(205, 22, 34, 50);
    private static final int C_PANEL3 = Color.argb(215, 28, 43, 61);
    private static final int C_BORDER = Color.argb(115, 220, 235, 255);
    private static final int C_DANGER = Color.rgb(255, 123, 123);

    private final DspState state = new DspState();
    private LinearLayout pageHost;
    private LinearLayout navHost;
    private String page = "HOME";
    private int selectedGroup = 0;
    private int selectedBand = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        state.load(this);
        buildShell();
        showPage("HOME");
    }

    private void buildShell() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundResource(com.okn.peramp.R.drawable.app_background);
        root.setPadding(dp(12), dp(12), dp(12), dp(8));

        root.addView(buildHeader(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        pageHost = new LinearLayout(this);
        pageHost.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams hostParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        hostParams.topMargin = dp(10);
        root.addView(pageHost, hostParams);

        navHost = buildBottomNav();
        LinearLayout.LayoutParams navParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(62));
        navParams.topMargin = dp(8);
        root.addView(navHost, navParams);

        setContentView(root);
    }

    private View buildHeader() {
        LinearLayout card = panel(C_PANEL, 18);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));

        TextView logo = text("OKN", 16, C_BG, true);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(round(C_ACCENT, 14, C_ACCENT, 0));
        card.addView(logo, new LinearLayout.LayoutParams(dp(54), dp(54)));

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        titleBox.setPadding(dp(12), 0, dp(8), 0);
        titleBox.addView(text("OKN Peramp", 21, C_TEXT, true));
        titleBox.addView(text("DSP Digital Audio Processor · Preamp", 12, C_MUTED, false));
        card.addView(titleBox, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView offline = text("OFFLINE", 11, C_DANGER, true);
        offline.setGravity(Gravity.CENTER);
        offline.setPadding(dp(10), dp(7), dp(10), dp(7));
        offline.setBackground(round(Color.argb(120, 60, 20, 25), 30, C_DANGER, 1));
        card.addView(offline);
        return card;
    }

    private LinearLayout buildBottomNav() {
        LinearLayout bar = panel(C_PANEL, 18);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setPadding(dp(5), dp(5), dp(5), dp(5));
        String[] items = {"HOME", "PEQ", "OUTPUT", "SET"};
        for (String item : items) {
            Button b = new Button(this);
            b.setAllCaps(false);
            b.setText(item);
            b.setTextSize(12);
            b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            b.setTextColor(C_TEXT);
            b.setPadding(0, 0, 0, 0);
            b.setBackground(round(C_PANEL2, 14, C_BORDER, 1));
            b.setOnClickListener(v -> showPage(item));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
            lp.setMargins(dp(3), 0, dp(3), 0);
            bar.addView(b, lp);
        }
        return bar;
    }

    private void showPage(String target) {
        page = target;
        pageHost.removeAllViews();
        if ("HOME".equals(target)) pageHost.addView(buildHome());
        else if ("PEQ".equals(target)) pageHost.addView(buildPeq());
        else if ("OUTPUT".equals(target)) pageHost.addView(buildOutput());
        else pageHost.addView(buildSettings());
        updateNavVisuals();
    }

    private void updateNavVisuals() {
        for (int i = 0; i < navHost.getChildCount(); i++) {
            View v = navHost.getChildAt(i);
            if (!(v instanceof Button)) continue;
            Button b = (Button) v;
            boolean active = b.getText().toString().equals(page);
            b.setTextColor(active ? C_BG : C_TEXT);
            b.setBackground(round(active ? C_ACCENT : C_PANEL2, 14, active ? C_ACCENT : C_BORDER, 1));
        }
    }

    private View buildHome() {
        ScrollView scroll = scroll();
        LinearLayout body = verticalBody();
        scroll.addView(body);

        body.addView(sectionTitle("Device Status"));
        LinearLayout status = panel(C_PANEL, 16);
        status.setOrientation(LinearLayout.VERTICAL);
        status.setPadding(dp(14), dp(12), dp(14), dp(12));
        status.addView(rowText("DSP Link", "Not connected", C_DANGER));
        status.addView(divider());
        status.addView(rowText("Local Data", "READY", C_ACCENT));
        body.addView(status, blockParams());

        body.addView(sectionTitle("Metrics"));
        GridLayout metrics = new GridLayout(this);
        metrics.setColumnCount(2);
        metrics.addView(metric("Sample rate", "48 kHz"), gridCell());
        metrics.addView(metric("PEQ", "15 × 10"), gridCell());
        metrics.addView(metric("Outputs", "7 CH"), gridCell());
        metrics.addView(metric("Safety", "FAIL-CLOSED"), gridCell());
        body.addView(metrics, blockParams());

        body.addView(sectionTitle("Audio Control"));
        body.addView(controlCard("Master Volume", 0, 100, 1, state.masterVolume, "%", value -> state.masterVolume = value));
        body.addView(controlCard("Remind Sound Volume", 0, 100, 1, state.remindVolume, "%", value -> state.remindVolume = value));
        body.addView(controlCard("Bass Volume", 0, 100, 1, state.bassVolume, "%", value -> state.bassVolume = value));
        body.addView(controlCard("Bass Cutoff", 40, 250, 1, state.bassCutoff, " Hz", value -> state.bassCutoff = value));
        body.addView(controlCard("Bass Boost", 0, 12, 0.5f, state.bassBoost, " dB", value -> state.bassBoost = value));
        body.addView(controlCard("Treble Boost", 0, 12, 0.5f, state.trebleBoost, " dB", value -> state.trebleBoost = value));
        body.addView(controlCard("Virtual Surround", 0, 100, 1, state.surround, "%", value -> state.surround = value));
        return scroll;
    }

    private View buildPeq() {
        ScrollView scroll = scroll();
        LinearLayout body = verticalBody();
        scroll.addView(body);

        body.addView(sectionTitle("PEQ Channel Group"));
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        for (int g = 0; g < DspState.GROUPS; g++) {
            final int group = g;
            Button b = smallButton("G" + (g + 1), g == selectedGroup);
            b.setOnClickListener(v -> {
                selectedGroup = group;
                showPage("PEQ");
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(64), dp(44));
            lp.setMargins(0, 0, dp(7), 0);
            chips.addView(b, lp);
        }
        hs.addView(chips);
        body.addView(hs, blockParams());

        body.addView(sectionTitle("15-Band Parametric EQ"));
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(3);
        for (int b = 0; b < DspState.BANDS; b++) {
            final int bandIndex = b;
            DspState.PeqBand band = state.peq[selectedGroup][b];
            LinearLayout card = panel(b == selectedBand ? Color.argb(220, 55, 206, 196) : C_PANEL2, 14);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setGravity(Gravity.CENTER);
            card.setPadding(dp(8), dp(9), dp(8), dp(9));
            TextView n = text("B" + (b + 1), 11, b == selectedBand ? C_BG : C_MUTED, true);
            TextView f = text(formatNumber(band.frequencyHz) + " Hz", 14, b == selectedBand ? C_BG : C_TEXT, true);
            TextView gain = text(formatSigned(band.gainDb) + " dB", 11, b == selectedBand ? C_BG : C_ACCENT, false);
            card.addView(n);
            card.addView(f);
            card.addView(gain);
            card.setOnClickListener(v -> {
                selectedBand = bandIndex;
                showPage("PEQ");
            });
            grid.addView(card, gridCell());
        }
        body.addView(grid, blockParams());

        DspState.PeqBand edit = state.peq[selectedGroup][selectedBand];
        body.addView(sectionTitle("Band Editor · G" + (selectedGroup + 1) + " / B" + (selectedBand + 1)));
        body.addView(controlCard("Frequency", 20, 20000, 10, edit.frequencyHz, " Hz", value -> edit.frequencyHz = value));
        body.addView(controlCard("Gain", -12, 12, 0.5f, edit.gainDb, " dB", value -> edit.gainDb = value));
        body.addView(controlCard("Q", 0.1f, 10, 0.1f, edit.q, "", value -> edit.q = value));

        Button flat = actionButton("FLAT THIS BAND", false);
        flat.setOnClickListener(v -> {
            edit.gainDb = 0f;
            edit.q = 1f;
            showPage("PEQ");
        });
        body.addView(flat, blockParams());
        return scroll;
    }

    private View buildOutput() {
        ScrollView scroll = scroll();
        LinearLayout body = verticalBody();
        scroll.addView(body);
        body.addView(sectionTitle("Output Trim · CH1–CH7"));
        body.addView(infoCard("Range -70 to +6 dB · Step 0.5 dB", C_ACCENT2));
        for (int i = 0; i < DspState.OUTPUTS; i++) {
            final int ch = i;
            body.addView(controlCard("CH" + (i + 1) + " Output", -70, 6, 0.5f, state.outputTrim[i], " dB", value -> state.outputTrim[ch] = value));
        }
        Button muteAll = actionButton("MUTE ALL OUTPUTS", true);
        muteAll.setOnClickListener(v -> {
            for (int i = 0; i < DspState.OUTPUTS; i++) state.outputTrim[i] = -70f;
            showPage("OUTPUT");
        });
        body.addView(muteAll, blockParams());
        return scroll;
    }

    private View buildSettings() {
        ScrollView scroll = scroll();
        LinearLayout body = verticalBody();
        scroll.addView(body);

        body.addView(sectionTitle("Locale"));
        String[] locales = {
                "English (US)", "ไทย", "中文 (简体)", "中文 (繁體)", "日本語", "한국어",
                "Deutsch", "Français", "Español", "Italiano", "Português", "Русский",
                "Bahasa Indonesia", "Bahasa Melayu", "Tiếng Việt", "हिन्दी", "العربية"
        };
        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, locales) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                TextView v = (TextView) super.getView(position, convertView, parent);
                v.setTextColor(C_TEXT);
                v.setPadding(dp(12), dp(12), dp(12), dp(12));
                return v;
            }

            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                TextView v = (TextView) super.getDropDownView(position, convertView, parent);
                v.setTextColor(Color.BLACK);
                v.setPadding(dp(12), dp(12), dp(12), dp(12));
                return v;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setSelection(Math.max(0, Math.min(locales.length - 1, state.localeIndex)));
        LinearLayout localeCard = panel(C_PANEL, 16);
        localeCard.setPadding(dp(10), dp(8), dp(10), dp(8));
        localeCard.addView(spinner, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        body.addView(localeCard, blockParams());

        body.addView(sectionTitle("Parameters"));
        Button save = actionButton("SAVE PARAMETERS", false);
        save.setOnClickListener(v -> {
            state.localeIndex = spinner.getSelectedItemPosition();
            state.save(this);
            Toast.makeText(this, "Parameters saved locally", Toast.LENGTH_SHORT).show();
        });
        body.addView(save, blockParams());

        Button reset = actionButton("RESET LOCAL VALUES", true);
        reset.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Reset OKN Peramp")
                .setMessage("Reset all local DSP values to defaults?")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Reset", (d, w) -> {
                    state.reset();
                    state.save(this);
                    showPage("SET");
                    Toast.makeText(this, "Local values reset", Toast.LENGTH_SHORT).show();
                }).show());
        body.addView(reset, blockParams());

        body.addView(sectionTitle("Safety"));
        LinearLayout safety = panel(Color.argb(215, 45, 28, 32), 16);
        safety.setOrientation(LinearLayout.VERTICAL);
        safety.setPadding(dp(14), dp(14), dp(14), dp(14));
        safety.addView(text("FAIL-CLOSED", 15, C_DANGER, true));
        TextView desc = text("No hardware transport is connected. The app keeps DSP changes local and will not claim that a device was programmed until a real transport confirms it.", 12, C_MUTED, false);
        desc.setPadding(0, dp(6), 0, 0);
        safety.addView(desc);
        body.addView(safety, blockParams());

        body.addView(infoCard("OKN Peramp 1.0.0 · Native Android UI", C_ACCENT));
        return scroll;
    }

    private View controlCard(String label, float min, float max, float step, float initial, String suffix, ValueChange onChange) {
        LinearLayout card = panel(C_PANEL2, 16);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12), dp(10), dp(12), dp(10));

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        TextView title = text(label, 13, C_TEXT, true);
        TextView valueText = text(formatValue(initial, step, suffix), 13, C_ACCENT, true);
        valueText.setGravity(Gravity.END);
        head.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        head.addView(valueText);
        card.addView(head);

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        controls.setPadding(0, dp(7), 0, 0);

        Button minus = squareButton("−");
        Button plus = squareButton("+");
        SeekBar bar = new SeekBar(this);
        int steps = Math.max(1, Math.round((max - min) / step));
        bar.setMax(steps);
        int p = Math.round((clamp(initial, min, max) - min) / step);
        bar.setProgress(Math.max(0, Math.min(steps, p)));
        bar.setProgressTintList(android.content.res.ColorStateList.valueOf(C_ACCENT));
        bar.setThumbTintList(android.content.res.ColorStateList.valueOf(C_ACCENT2));

        final boolean[] internal = {false};
        SeekBar.OnSeekBarChangeListener listener = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                float value = min + progress * step;
                value = clamp(value, min, max);
                valueText.setText(formatValue(value, step, suffix));
                onChange.changed(value);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        };
        bar.setOnSeekBarChangeListener(listener);

        minus.setOnClickListener(v -> {
            if (bar.getProgress() > 0) bar.setProgress(bar.getProgress() - 1);
        });
        plus.setOnClickListener(v -> {
            if (bar.getProgress() < bar.getMax()) bar.setProgress(bar.getProgress() + 1);
        });

        controls.addView(minus, new LinearLayout.LayoutParams(dp(44), dp(44)));
        LinearLayout.LayoutParams seekLp = new LinearLayout.LayoutParams(0, dp(44), 1f);
        seekLp.setMargins(dp(8), 0, dp(8), 0);
        controls.addView(bar, seekLp);
        controls.addView(plus, new LinearLayout.LayoutParams(dp(44), dp(44)));
        card.addView(controls);

        LinearLayout.LayoutParams lp = blockParams();
        lp.bottomMargin = dp(8);
        card.setLayoutParams(lp);
        return card;
    }

    private TextView sectionTitle(String s) {
        TextView t = text(s, 14, C_MUTED, true);
        t.setPadding(dp(4), dp(10), 0, dp(7));
        return t;
    }

    private View infoCard(String message, int accent) {
        LinearLayout card = panel(C_PANEL3, 14);
        card.setPadding(dp(12), dp(11), dp(12), dp(11));
        TextView t = text(message, 12, accent, true);
        card.addView(t);
        card.setLayoutParams(blockParams());
        return card;
    }

    private View metric(String title, String value) {
        LinearLayout card = panel(C_PANEL2, 14);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12), dp(12), dp(12), dp(12));
        card.addView(text(title, 11, C_MUTED, false));
        TextView v = text(value, 18, C_TEXT, true);
        v.setPadding(0, dp(5), 0, 0);
        card.addView(v);
        return card;
    }

    private View rowText(String left, String right, int rightColor) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        TextView l = text(left, 13, C_TEXT, true);
        TextView r = text(right, 12, rightColor, true);
        r.setGravity(Gravity.END);
        row.addView(l, new LinearLayout.LayoutParams(0, dp(36), 1f));
        row.addView(r, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(36)));
        return row;
    }

    private View divider() {
        View d = new View(this);
        d.setBackgroundColor(Color.argb(50, 220, 235, 255));
        d.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)));
        return d;
    }

    private Button actionButton(String label, boolean danger) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(12);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(danger ? C_DANGER : C_BG);
        b.setBackground(round(danger ? Color.argb(100, 70, 25, 30) : C_ACCENT, 14, danger ? C_DANGER : C_ACCENT, 1));
        b.setMinHeight(dp(52));
        return b;
    }

    private Button smallButton(String label, boolean active) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(12);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setPadding(0, 0, 0, 0);
        b.setTextColor(active ? C_BG : C_TEXT);
        b.setBackground(round(active ? C_ACCENT : C_PANEL2, 12, active ? C_ACCENT : C_BORDER, 1));
        return b;
    }

    private Button squareButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(22);
        b.setTextColor(C_TEXT);
        b.setPadding(0, 0, 0, dp(2));
        b.setBackground(round(C_PANEL3, 12, C_BORDER, 1));
        return b;
    }

    private LinearLayout panel(int color, int radius) {
        LinearLayout l = new LinearLayout(this);
        l.setBackground(round(color, radius, C_BORDER, 1));
        return l;
    }

    private GradientDrawable round(int fill, int radiusDp, int stroke, int strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) g.setStroke(dp(strokeDp), stroke);
        return g;
    }

    private ScrollView scroll() {
        ScrollView s = new ScrollView(this);
        s.setFillViewport(true);
        s.setClipToPadding(false);
        s.setVerticalScrollBarEnabled(false);
        return s;
    }

    private LinearLayout verticalBody() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(0, 0, 0, dp(24));
        return l;
    }

    private TextView text(String value, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout.LayoutParams blockParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(8);
        return lp;
    }

    private GridLayout.LayoutParams gridCell() {
        GridLayout.LayoutParams gp = new GridLayout.LayoutParams();
        gp.width = 0;
        gp.height = ViewGroup.LayoutParams.WRAP_CONTENT;
        gp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        gp.setMargins(dp(4), dp(4), dp(4), dp(4));
        return gp;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    private static String formatValue(float value, float step, String suffix) {
        String n;
        if (Math.abs(step - Math.round(step)) < 0.0001f) n = String.format(Locale.US, "%.0f", value);
        else n = String.format(Locale.US, "%.1f", value);
        if (value > 0 && suffix.contains("dB")) n = "+" + n;
        return n + suffix;
    }

    private static String formatNumber(float v) {
        if (Math.abs(v - Math.round(v)) < 0.001f) return String.format(Locale.US, "%.0f", v);
        return String.format(Locale.US, "%.1f", v);
    }

    private static String formatSigned(float v) {
        if (Math.abs(v) < 0.0001f) return "0.0";
        return String.format(Locale.US, "%+.1f", v);
    }

    private interface ValueChange {
        void changed(float value);
    }
}
