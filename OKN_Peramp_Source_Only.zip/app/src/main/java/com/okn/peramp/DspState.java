package com.okn.peramp;

import android.content.Context;
import android.content.SharedPreferences;

public final class DspState {
    public static final int GROUPS = 10;
    public static final int BANDS = 15;
    public static final int OUTPUTS = 7;

    public float masterVolume = 70f;
    public float remindVolume = 50f;
    public float bassVolume = 50f;
    public float bassCutoff = 80f;
    public float bassBoost = 0f;
    public float trebleBoost = 0f;
    public float surround = 0f;
    public final PeqBand[][] peq = new PeqBand[GROUPS][BANDS];
    public final float[] outputTrim = new float[OUTPUTS];
    public int localeIndex = 0;

    private static final int[] DEFAULT_FREQ = {
            20, 31, 50, 80, 125, 200, 315, 500, 800, 1250, 2000, 3150, 5000, 8000, 12500
    };

    public DspState() {
        reset();
    }

    public void reset() {
        masterVolume = 70f;
        remindVolume = 50f;
        bassVolume = 50f;
        bassCutoff = 80f;
        bassBoost = 0f;
        trebleBoost = 0f;
        surround = 0f;
        localeIndex = 0;
        for (int g = 0; g < GROUPS; g++) {
            for (int b = 0; b < BANDS; b++) {
                peq[g][b] = new PeqBand(DEFAULT_FREQ[b], 0f, 1f);
            }
        }
        for (int i = 0; i < OUTPUTS; i++) outputTrim[i] = 0f;
    }

    public void save(Context context) {
        SharedPreferences.Editor e = context.getSharedPreferences("okn_peramp", Context.MODE_PRIVATE).edit();
        e.putFloat("master", masterVolume);
        e.putFloat("remind", remindVolume);
        e.putFloat("bass_volume", bassVolume);
        e.putFloat("bass_cutoff", bassCutoff);
        e.putFloat("bass_boost", bassBoost);
        e.putFloat("treble_boost", trebleBoost);
        e.putFloat("surround", surround);
        e.putInt("locale", localeIndex);
        for (int g = 0; g < GROUPS; g++) {
            for (int b = 0; b < BANDS; b++) {
                String p = "g" + g + "b" + b;
                e.putFloat(p + "f", peq[g][b].frequencyHz);
                e.putFloat(p + "g", peq[g][b].gainDb);
                e.putFloat(p + "q", peq[g][b].q);
            }
        }
        for (int i = 0; i < OUTPUTS; i++) e.putFloat("out" + i, outputTrim[i]);
        e.apply();
    }

    public void load(Context context) {
        SharedPreferences p = context.getSharedPreferences("okn_peramp", Context.MODE_PRIVATE);
        masterVolume = p.getFloat("master", masterVolume);
        remindVolume = p.getFloat("remind", remindVolume);
        bassVolume = p.getFloat("bass_volume", bassVolume);
        bassCutoff = p.getFloat("bass_cutoff", bassCutoff);
        bassBoost = p.getFloat("bass_boost", bassBoost);
        trebleBoost = p.getFloat("treble_boost", trebleBoost);
        surround = p.getFloat("surround", surround);
        localeIndex = p.getInt("locale", localeIndex);
        for (int g = 0; g < GROUPS; g++) {
            for (int b = 0; b < BANDS; b++) {
                String k = "g" + g + "b" + b;
                peq[g][b].frequencyHz = p.getFloat(k + "f", peq[g][b].frequencyHz);
                peq[g][b].gainDb = p.getFloat(k + "g", peq[g][b].gainDb);
                peq[g][b].q = p.getFloat(k + "q", peq[g][b].q);
            }
        }
        for (int i = 0; i < OUTPUTS; i++) outputTrim[i] = p.getFloat("out" + i, outputTrim[i]);
    }

    public static final class PeqBand {
        public float frequencyHz;
        public float gainDb;
        public float q;

        public PeqBand(float frequencyHz, float gainDb, float q) {
            this.frequencyHz = frequencyHz;
            this.gainDb = gainDb;
            this.q = q;
        }
    }
}
