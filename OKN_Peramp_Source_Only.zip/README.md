# OKN Peramp

Fresh Android implementation of a DSP Digital Audio Processor / Preamp control app.

## UI
- Native Android Views only. No screenshot overlays and no webview.
- Bottom navigation: HOME / PEQ / OUTPUT / SET.
- Dark translucent panel language recreated with native GradientDrawable shapes.
- HOME contains device/local status, metrics, and audio controls with − / slider / +.
- PEQ contains 10 channel groups and 15 bands per group.
- OUTPUT contains CH1–CH7 trims from -70 dB to +6 dB in 0.5 dB steps.
- SET contains 17 locale choices, save, reset, and fail-closed status.

## DSP model
`DspEngine.java` contains a real peaking biquad implementation that can process interleaved floating-point PCM in memory. The app currently does not attach to Android system-wide audio or vendor DSP hardware. Integrate the target USB/Bluetooth/serial/vendor protocol through `DspTransport` for real hardware control.

## Build
GitHub Actions workflow: `.github/workflows/android.yml`

Locally, with Android SDK and Gradle 8.9 installed:

```bash
gradle :app:assembleDebug
```

APK output:
`app/build/outputs/apk/debug/app-debug.apk`
