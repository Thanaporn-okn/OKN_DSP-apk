#!/usr/bin/env python3
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
GRADLE = (ROOT/'app/build.gradle').read_text()
MANIFEST = (ROOT/'app/src/main/AndroidManifest.xml').read_text()
VIEW = (ROOT/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
MAIN = (ROOT/'app/src/main/java/com/okn/dsp/MainActivity.java').read_text()
USB = (ROOT/'app/src/main/java/com/okn/dsp/UsbAcpDiscovery.java').read_text()
BLE = (ROOT/'app/src/main/java/com/okn/dsp/BleManager.java').read_text()
README = (ROOT/'README.md').read_text()

def req(ok,msg):
    if not ok: raise AssertionError(msg)

req('versionCode 1046' in GRADLE and "versionName '46.0.0'" in GRADLE, 'V46 version mismatch')
req('android.hardware.usb.host' in MANIFEST, 'USB host feature declaration missing')
req('USB / ACP READ-ONLY SCAN' in VIEW and 'v46UsbScan' in VIEW, 'V46 USB scan UI missing')
req('host.requestUsbAcpDiscovery()' in VIEW, 'USB scan UI not wired to host')
req('CH1 -0.5 dB Probe' not in VIEW and 'v45GainProbe' not in VIEW, 'V45 risky probe remains reachable in UI')
req('requestUsbAcpDiscovery()' in MAIN and 'UsbAcpDiscovery.buildReadOnlyReport' in MAIN, 'MainActivity USB report missing')
req('UsbManager' in USB and 'getDeviceList()' in USB, 'descriptor enumeration missing')
for forbidden in ['controlTransfer(', 'bulkTransfer(', 'requestPermission(', 'claimInterface(', 'openDevice(', 'UsbDeviceConnection']:
    req(forbidden not in USB, 'forbidden V46 USB I/O primitive present: '+forbidden)
req('0 bytes sent to DSP' in USB, 'read-only report disclosure missing')
req('if (s.index != 2) return;' in VIEW, 'normal non-CH3 output slider must stay locked')
req('if (channel0 != 2) return;' in BLE, 'normal non-CH3 output write must stay fail-closed')
req('zero bytes' in README.lower(), 'README must state zero-byte USB behavior')
print('V46_USB_DISCOVERY_STATIC_PASS')
print('usb_tx_bytes=0')
print('non_ch3_biquad_out_volume=LOCKED')
print('ch3_scalar_id8=UNCHANGED')
