#!/usr/bin/env python3
from pathlib import Path
import re, struct, math
ROOT = Path(__file__).resolve().parents[1]
PROTO = (ROOT/'app/src/main/java/com/okn/dsp/DspProtocol.java').read_text()
BLE = (ROOT/'app/src/main/java/com/okn/dsp/BleManager.java').read_text()
VIEW = (ROOT/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
GRADLE = (ROOT/'app/build.gradle').read_text()
README = (ROOT/'README.md').read_text()

def req(ok, msg):
    if not ok: raise AssertionError(msg)

req('versionCode 1045' in GRADLE and "versionName '45.0.0'" in GRADLE, 'V45 version mismatch')
req('encodeEqNumeratorWrite' in PROTO, 'missing partial numerator builder')
req('eqBandOffset(band1) + 28' in PROTO, 'numerator offset must be 28')
req('ByteBuffer.allocate(12)' in PROTO, 'numerator payload must be 12 bytes')
req('payload.putFloat(b0)' in PROTO and 'payload.putFloat(b1)' in PROTO and 'payload.putFloat(b2)' in PROTO, 'must write B0/B1/B2 only')
req('V45_PROBE_DELTA_DB = -0.5f' in BLE, 'probe delta must be -0.5 dB')
req('V45_PROBE_AUTO_RESTORE_MS = 2600L' in BLE, 'auto restore delay mismatch')
req('encodeEqNumeratorScaleProbe(0, 1, current, V45_PROBE_DELTA_DB)' in BLE, 'probe must be CH1 band1 only')
req('encodeEqNumeratorRestore(0, 1, v45ProbeOriginal)' in BLE, 'restore must use original CH1 numerator')
req('SAVE BLOCKED • V45 diagnostic probe must be restored first' in BLE, 'SaveParams guard missing')
req('if (channel0 != 2) return;' in BLE, 'normal non-CH3 output write must be fail-closed')
req('if (s.index != 2) return;' in VIEW, 'normal non-CH3 output slider must be locked')
req('CH1 -0.5 dB Probe' in VIEW and 'Restore CH1' in VIEW, 'probe UI missing')
req('v45GainProbe' in VIEW and 'runV45Ch1GainProbe' in VIEW, 'probe button wiring missing')
req('v45GainRestore' in VIEW and 'restoreV45Ch1GainProbe' in VIEW, 'restore button wiring missing')
req('if (v45ProbeActive || v45ProbeWritePending) return;' in BLE, 'scheduler isolation missing')
req('never SaveParams' in README or 'never calls SaveParams' in README, 'README persistence warning missing')

# Byte-for-byte proof for CH1 actuator ID4, band1 numerator offset 28, length 12.
header = bytes([0x57]) + (4).to_bytes(4,'big') + (28).to_bytes(2,'big') + (12).to_bytes(2,'big')
req(header.hex().upper() == '5700000004001C000C', 'unexpected UFE probe header')
# Captured CH1 type-17 numerator, scaled by exactly -0.5 dB for diagnostic attenuation.
b0,b1,b2 = -3.019757, 5.721551, -2.681038
scale = 10**(-0.5/20.0)
payload = struct.pack('<fff', b0*scale, b1*scale, b2*scale)
packet = header + payload
req(len(packet) == 21, 'probe plaintext must be 21 bytes')
req(packet[:9].hex().upper() == '5700000004001C000C', 'probe header changed')
# Restore payload must be original coefficients, not metadata or denominator.
restore = header + struct.pack('<fff', b0,b1,b2)
req(len(restore)==21, 'restore plaintext must be 21 bytes')

# Ensure the probe method itself cannot call full-row EQ or SaveParams.
m = re.search(r'private void runV45Ch1GainProbeOnMain\(\) \{(.*?)\n    \}', BLE, re.S)
req(m is not None, 'probe method not found')
body = m.group(1)
req('encodeEqWrite' not in body and 'encodeSaveParamsTrigger' not in body, 'probe contains forbidden full-row/save write')

print('V45_GAIN_PROBE_STATIC_PASS')
print('probe_plain=' + packet.hex().upper())
print('restore_header=' + restore[:9].hex().upper())
print('normal_non_ch3_output=LOCKED')
print('saveparams_during_probe=BLOCKED')
