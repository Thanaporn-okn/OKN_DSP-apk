from pathlib import Path
root=Path(__file__).resolve().parents[1]
ble=(root/'app/src/main/java/com/okn/dsp/BleManager.java').read_text()
main=(root/'app/src/main/java/com/okn/dsp/MainActivity.java').read_text()
view=(root/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
gradle=(root/'app/build.gradle').read_text()
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()

def req(c,m):
    if not c: raise SystemExit('V56_FAIL: '+m)

req('versionCode 1056' in gradle, 'versionCode')
req("versionName '56.0.0'" in gradle, 'versionName')
req('runV56PassiveSensorRxCapture' in ble, 'capture method')
req('V56_RX_CAPTURE_MS = 5000L' in ble, 'capture window')
req('handleV56RxPlain' in ble and '(plain[0] & 0xff) != 0x60' in ble, '0x60 parser')
req('ORIGINAL_POLL_IDS = {19, 20, 0, 21}' in ble, 'original sensor ids')
req('ORIGINAL_POLL_LENGTHS = {1, 1, 4, 4}' in ble, 'original sensor lengths')
# Capture start must not stop/reset/reorder scheduler or encrypt/send a diagnostic packet.
a=ble.index('private void runV56PassiveSensorRxCaptureOnMain()')
b=ble.index('private void handleV56RxPlain', a)
cap=ble[a:b]
for forbidden in ['stopOriginalCommandScheduler()', 'txCipher.next(', 'writeNoResponse(', 'DspProtocol.encodeRead(', 'dspReady = false']:
    req(forbidden not in cap, 'capture injected transport action: '+forbidden)
req('PASSIVE SENSOR RX CAPTURE (0 ADDED TX)' in view, 'UI label')
req('requestV56PassiveSensorRxCapture' in view and 'requestV56PassiveSensorRxCapture' in main, 'UI wiring')
req('requestV55HiddenActuatorReadProbe' not in view and 'requestV55HiddenActuatorReadProbe' not in main, 'V55 UI still exposed')
req('android.hardware.usb.host' not in manifest, 'USB host present')
print('V56_PASSIVE_SENSOR_RX_STATIC_PASS')
