#!/usr/bin/env python3
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
GRADLE = (ROOT/'app/build.gradle').read_text()
MANIFEST = (ROOT/'app/src/main/AndroidManifest.xml').read_text()
VIEW = (ROOT/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
MAIN = (ROOT/'app/src/main/java/com/okn/dsp/MainActivity.java').read_text()
USB = (ROOT/'app/src/main/java/com/okn/dsp/UsbAcpDiscovery.java').read_text()
BLE = (ROOT/'app/src/main/java/com/okn/dsp/BleManager.java').read_text()
README = (ROOT/'README.md').read_text()

def req(ok, msg):
    if not ok: raise AssertionError(msg)

req('versionCode 1049' in GRADLE and "versionName '49.0.0'" in GRADLE, 'V49 version mismatch')
req('android.hardware.usb.host' in MANIFEST, 'USB host feature missing')
req('ACP READ CATALOG (1 QUERY)' in VIEW and 'host.requestUsbAcpDiscovery()' in VIEW, 'V49 catalog UI missing')
req('TARGET_VID = 0x6324' in USB and 'TARGET_PID = 0x1719' in USB, 'real VID/PID lock missing')
req('TARGET_INTERFACE = 4' in USB and 'GENERIC_REPORT_SIZE = 256' in USB, 'IF4/256 profile missing')
req('USB_RECIP_INTERFACE = 0x01' in USB, 'USB interface recipient constant missing')
req('claimInterface(hid, false)' in USB, 'force=false claim missing')
req('claimInterface(hid, true)' not in USB, 'force=true forbidden')
req('HID_REQ_SET_REPORT = 0x09' in USB and 'HID_REQ_GET_REPORT = 0x01' in USB, 'HID request IDs missing')
req('HID_REPORT_TYPE_OUTPUT = 0x02' in USB and 'HID_REPORT_TYPE_INPUT = 0x01' in USB, 'HID report types missing')
req('0x06, 0x00, (byte) 0xFF, 0x0A, (byte) 0xAA, 0x55' in USB, 'V48 FF00/55AA descriptor gate missing')
req('(byte) 0xA5, 0x5A, (byte) 0x80, 0x01, 0x00, 0x16' in USB, 'exact selector-0 catalog query missing')
req('System.arraycopy(ACP_CATALOG_QUERY' in USB, 'catalog query not copied into 256-byte report')
req(USB.count('HID_REQ_SET_REPORT') == 2, 'unexpected SET_REPORT symbol usage; expected declaration + one call')
req(USB.count('UsbConstants.USB_DIR_OUT | UsbConstants.USB_TYPE_CLASS | USB_RECIP_INTERFACE') == 1,
    'must have exactly one HID OUT control-transfer code path')
req('No retry SET_REPORT is performed' in USB, 'no-retry disclosure missing')
req('ctrl=0x80' in USB or 'CTRL=0x80' in USB, 'CTRL=0x80 reply matching missing')
req('isValidCatalogReply' in USB and '(input[2] & 0xFF) != 0x80' in USB, 'catalog reply matcher missing')
req('GET_ATTEMPTS = 6' in USB, 'bounded GET_REPORT retry count missing')
req('if (s.index != 2) return;' in VIEW, 'non-CH3 slider lock missing')
req('if (channel0 != 2) return;' in BLE, 'non-CH3 BLE output lock missing')
req('BassVolume' in BLE and 'ID8' in README, 'CH3 scalar evidence missing')
# Do not allow dangerous ACP controls in executable USB constants/frames. They may appear only in comments/docs.
for forbidden_code in ['(byte) 0xFB', '(byte) 0xFD', '(byte) 0xFE', '0xFB,', '0xFD,', '0xFE,']:
    req(forbidden_code not in USB, 'dangerous ACP control appears in USB code: '+forbidden_code)
for forbidden in ['bulkTransfer(', 'WriteActuator', 'SaveParams(', 'buildWrite', 'outputGainFromCurrent']:
    req(forbidden not in USB, 'forbidden state-changing USB path: '+forbidden)
req('ACTION_USB_PERMISSION_V49' in MAIN and 'requestPermission(device, pending)' in MAIN, 'V49 USB permission flow missing')
req('A5 5A 80 01 00 16' in README and 'exactly one' in README.lower(), 'README catalog safety evidence missing')
print('V49_ACP_CATALOG_READ_STATIC_PASS')
print('target=0x6324:0x1719 IF4 HID report=256')
print('permitted_tx=A55A80010016 count=1')
print('reply_match=CTRL_0x80 bounded_get_attempts=6')
print('state_changing_usb_writes=0')
print('non_ch3_biquad_out_volume=LOCKED')
print('ch3_scalar_id8=UNCHANGED')
