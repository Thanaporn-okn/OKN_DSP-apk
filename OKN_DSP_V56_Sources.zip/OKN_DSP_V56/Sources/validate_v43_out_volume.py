#!/usr/bin/env python3
from pathlib import Path
import json, math, struct

ROOT = Path(__file__).resolve().parents[1]
DSP = (ROOT/'app/src/main/java/com/okn/dsp/DspProtocol.java').read_text()
BLE = (ROOT/'app/src/main/java/com/okn/dsp/BleManager.java').read_text()
VIEW = (ROOT/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
MAIN = (ROOT/'app/src/main/java/com/okn/dsp/MainActivity.java').read_text()
STATE = (ROOT/'app/src/main/java/com/okn/dsp/DspState.java').read_text()
GRADLE = (ROOT/'app/build.gradle').read_text()
DESC = json.loads((ROOT/'Sources/ProtocolEvidence/GoloPine_DeviceDescription_REAL_20260906_204555.json').read_text())

def req(cond, msg):
    if not cond:
        raise AssertionError(msg)

req('versionCode 1043' in GRADLE and "versionName '43.0.0'" in GRADLE, 'V43 version mismatch')
req('OUTPUT_GAIN_MIN_DB = -70f' in DSP and 'OUTPUT_GAIN_MAX_DB = 6f' in DSP, 'output range missing')
req('float rounded = Math.round(safe);' in DSP, 'output writer must use 1 dB grid')
req('OUTPUT_GAIN_MIN_GAP_MS = 45L' in BLE, 'anti-pop cadence missing')
req('OUTPUT_GAIN_MAX_STEP_DB = 1.0f' in BLE, 'anti-pop 1 dB max step missing')
req('scheduleOutputGainPump' in BLE and 'stopOutputGainPump' in BLE, 'output ramp pump missing')
req('Math.min(OUTPUT_GAIN_MAX_STEP_DB, Math.abs(diff))' in BLE, 'bounded output step missing')
req('currentDb + Math.copySign(step, diff)' in BLE, 'output ramp direction missing')
req('DspProtocol.outputGainFromCurrent(current, nextDb)' in BLE, 'send-time stepped target build missing')
req('channel0 == 2' in BLE and 'DspProtocol.ID_BASS_VOLUME' in BLE, 'CH3 must stay BassVolume ID8')
req('roundTo(v, 1.0f)' in VIEW, 'Out Volume UI must use 1 dB increment')
req('listener.onOutputVolumeValue' in BLE, 'output readback publish missing')
req('void onOutputVolumeValue(int channel0, float valueDb)' in MAIN, 'MainActivity output callback missing')
req('void setOutputVolumeFromDsp(int channel0, float valueDb)' in VIEW, 'DspView output readback missing')
req('channelVolume[ch] = clamp(value, -70f, 6f);' in STATE, 'state output range mismatch')

# Descriptor facts including BassVolume min/max/incmt.
act = {a['ID']: a for a in DESC['actuators']}
req(8 in act and act[8].get('name') == 'BassVolume', 'descriptor BassVolume ID8 missing')
cpar = act[8].get('cpar','')
req('min=-70' in cpar and 'max=6' in cpar and 'incmt=1' in cpar, 'BassVolume descriptor range/increment mismatch')
for eq_id in (4,5,6,14,15,16,17):
    req(eq_id in act and act[eq_id].get('type') == 4084, f'EQ actuator {eq_id} missing')

# Prove Tone Control math still reproduces the descriptor at G=0.
tone = act[4]['UFE_TYPE_BIQUAD_CASCADE15_F'][0]
req(tone['typ'] == 17, 'CH1 first record not Tone Control')
F,F2,B,G,R = tone['F'], tone['F2'], tone['B'], tone['G'], tone['R']
SR = 44100.0

def f32(x):
    return struct.unpack('<f', struct.pack('<f', x))[0]

tb=10**(R/20.0); bb=10**(B/20.0)
at=math.tan(math.pi*F2/SR); ab=math.tan(math.pi*F/SR)
knt=2/(1+1/tb); kdt=2/(1+tb); knb=2/(1+1/bb); kdb=2/(1+bb)
a10=at+kdt; b10=at+knt; a11=at-kdt; b11=at-knt
a20=ab*kdb+1; b20=ab*knb-1; a21=ab*kdb-1; b21=ab*knb+1
a0=a10*a20; gl=10**(G/20.0)
calc=[
    f32(((b10*b20)/a0)*gl),
    f32((((b10*b21)+(b11*b20))/a0)*gl),
    f32(((b11*b21)/a0)*gl),
    f32(((a10*a21)+(a11*a20))/a0),
    f32((a11*a21)/a0),
]
obs=[tone[k] for k in ('B0','B1','B2','A1','A2')]
req(max(abs(a-b) for a,b in zip(calc,obs)) < 1e-5, 'Tone Control coefficient math changed')

# Pure ramp invariant: no emitted step may exceed 1 dB and it reaches final target.
def ramp(current, target):
    vals=[]
    while abs(target-current) > 1e-6:
        step=min(1.0, abs(target-current))
        current=current + (step if target>current else -step)
        current=round(current)
        if abs(vals[-1]-current) < 1e-9 if vals else False:
            current=target
        vals.append(current)
        if len(vals)>200: raise AssertionError('ramp did not converge')
    return vals
for start,target in [(0,-70),(-70,6),(6,-33),(-31,0)]:
    vals=ramp(float(start),float(target))
    prev=float(start)
    for v in vals:
        req(abs(v-prev) <= 1.000001, f'ramp jump >1 dB: {prev}->{v}')
        prev=v
    req(abs(prev-target) <= 1e-6, f'ramp did not reach target {target}')

print('V43 Out Volume anti-pop validation: PASS')
print('mapping: CH3=ID8; CH1/2/4/5/6/7=first EQ record G cell gain')
print('range/increment: -70..+6 dB, 1 dB')
print('anti-pop: <=1 dB per 45 ms full-record slot')
