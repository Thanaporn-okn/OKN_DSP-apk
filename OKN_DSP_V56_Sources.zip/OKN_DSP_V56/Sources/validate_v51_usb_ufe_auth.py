#!/usr/bin/env python3
from pathlib import Path
import re, sys
ROOT=Path(__file__).resolve().parents[1]
usb=(ROOT/'app/src/main/java/com/okn/dsp/UsbAcpDiscovery.java').read_text()
main=(ROOT/'app/src/main/java/com/okn/dsp/MainActivity.java').read_text()
view=(ROOT/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
grad=(ROOT/'app/build.gradle').read_text()
code=re.sub(r'/\*.*?\*/','',usb,flags=re.S)
code=re.sub(r'//[^\n]*','',code)
checks={
 'versionCode1051':'versionCode 1051' in grad,
 'versionName51':"versionName '51.0.0'" in grad,
 'targetVid':'TARGET_VID = 0x6324' in usb,
 'targetPid':'TARGET_PID = 0x1719' in usb,
 'targetIf4':'TARGET_INTERFACE = 4' in usb,
 'authExact':'0x63,0x1C,0x06,0x24,0x43,(byte)0xFD,0x38,0x44' in usb and '0x55,(byte)0x80,0x01,(byte)0xF3,(byte)0xED,(byte)0xA0,(byte)0xCC,(byte)0xF8' in usb,
 'outputReport256':'HID_REPORT_SIZE = 256' in usb and 'HID_REPORT_TYPE_OUTPUT = 0x02' in usb,
 'setReportReq':'HID_REQ_SET_REPORT = 0x09' in usb,
 'oneSetCall':code.count('HID_REQ_SET_REPORT, HID_REPORT_TYPE_OUTPUT<<8') == 1 and code.count('HID_REQ_SET_REPORT') == 2,
 'noAcpFrame':'A5 5A' not in code and '0xA5' not in code,
 'noDeviceDesc':'661C0624' not in code and '0x66,0x1C,0x06,0x24' not in code,
 'authResponseGate':'AUTH_RESPONSE_PREFIX' in usb and 'USB_UFE_AUTH_BRIDGE=PROVEN' in usb,
 'claimFalse':'claimInterface(hid,false)' in usb.replace(' ',''),
 'noForceTrue':'claimInterface(hid,true)' not in usb.replace(' ',''),
 'noSaveParamsCall':'saveParams(' not in usb and 'triggerSave' not in usb,
 'noActuatorWriter':'WRITE_ACTUATOR' not in code and 'WriteActuator' not in code,
 'lockedUi':'USB UFE AUTH (1 TX)' in view and 'CH1/2/4-7 locked' in view,
 'v51Ui':'V51' in main and 'V51' in view,
}
for k,v in checks.items(): print(f'{k}: {"PASS" if v else "FAIL"}')
if not all(checks.values()): sys.exit(1)
print('V51 USB UFE AUTH BRIDGE VALIDATION: PASS')
