#!/usr/bin/env python3
from pathlib import Path
import re,sys
ROOT=Path(__file__).resolve().parents[1]
usb=(ROOT/'app/src/main/java/com/okn/dsp/UsbAcpDiscovery.java').read_text()
main=(ROOT/'app/src/main/java/com/okn/dsp/MainActivity.java').read_text()
view=(ROOT/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
grad=(ROOT/'app/build.gradle').read_text()
def scrub(s):
    s=re.sub(r'/\*.*?\*/','',s,flags=re.S); s=re.sub(r'//[^\n]*','',s)
    s=re.sub(r'"(?:\\.|[^"\\])*"','""',s)
    return s
code=scrub(usb+'\n'+main)
checks={
 'versionCode1054':'versionCode 1054' in grad,
 'versionName54':"versionName '54.0.0'" in grad,
 'targetVid':'TARGET_VID = 0x6324' in usb,
 'targetPid':'TARGET_PID = 0x1719' in usb,
 'inputDeviceApi':'InputDevice.getDeviceIds()' in usb and 'getVendorId()' in usb and 'getProductId()' in usb,
 'sources':'getSources()' in usb and 'getKeyboardType()' in usb,
 'hasKeys':'hasKeys(' in usb,
 'noUsbImports':'android.hardware.usb' not in code,
 'noPermissionRequest':'requestPermission(' not in code and 'PendingIntent' not in code,
 'noUsbOpen':'openDevice(' not in code and 'UsbDeviceConnection' not in code,
 'noClaim':'claimInterface(' not in code,
 'noControl':'controlTransfer(' not in code,
 'noBulk':'bulkTransfer(' not in code and 'UsbRequest' not in code,
 'noSetGetReport':'SET_REPORT' not in code and 'GET_REPORT' not in code,
 'noAcp':'0xA5' not in code,
 'noUfeAuth':'631C062443FD3844558001F3EDA0CCF8' not in code,
 'noDesc':'661C0624' not in code,
 'noActuator':'WRITE_ACTUATOR' not in code and 'WriteActuator' not in code,
 'noSave':'saveParams(' not in code and 'triggerSave' not in code,
 'ui':'ANDROID IF3 CLASSIFY (0 USB I/O)' in view and 'CH1/2/4-7 locked' in view,
 'mainV54':'showUsbV54Report' in main and 'buildInputDeviceReport' in main,
}
for k,v in checks.items(): print(f'{k}: {"PASS" if v else "FAIL"}')
if not all(checks.values()): sys.exit(1)
print('V54 ANDROID INPUTDEVICE CLASSIFIER VALIDATION: PASS')
