#!/usr/bin/env python3
from pathlib import Path
import re, sys
ROOT=Path(__file__).resolve().parents[1]
usb=(ROOT/'app/src/main/java/com/okn/dsp/UsbAcpDiscovery.java').read_text()
main=(ROOT/'app/src/main/java/com/okn/dsp/MainActivity.java').read_text()
view=(ROOT/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
grad=(ROOT/'app/build.gradle').read_text()
code=re.sub(r'/\*.*?\*/','',usb,flags=re.S)
code=re.sub(r'//[^\n]*','',code)
code_no_strings=re.sub(r'"(?:\\.|[^"\\])*"','""',code)
compact=re.sub(r'\s+','',code_no_strings)
checks={
 'versionCode1053':'versionCode 1053' in grad,
 'versionName53':"versionName '53.0.0'" in grad,
 'targetVid':'TARGET_VID = 0x6324' in usb,
 'targetPid':'TARGET_PID = 0x1719' in usb,
 'targetIf3':'TARGET_INTERFACE = 3' in usb,
 'noSetReport':'HID_REQ_SET_REPORT' not in code_no_strings and 'setReport(' not in code_no_strings,
 'noGetReport':'HID_REQ_GET_REPORT' not in code_no_strings and 'getReport(' not in code_no_strings,
 'noUsbDirOut':'USB_DIR_OUT' not in code_no_strings,
 'noClaimInterface':'claimInterface(' not in code_no_strings,
 'noBulkTransfer':'bulkTransfer(' not in code_no_strings,
 'noInterruptTransfer':'requestWait(' not in code_no_strings and 'UsbRequest' not in code_no_strings,
 'noAcpFrame':'0xA5' not in code_no_strings and 'A5 5A' not in code_no_strings,
 'noUfeAuth':'631C062443FD3844558001F3EDA0CCF8' not in code_no_strings,
 'noDeviceDesc':'661C0624' not in code_no_strings,
 'oneControlTransfer':code_no_strings.count('controlTransfer(')==1,
 'standardInGetDescriptor':'USB_DIR_IN | UsbConstants.USB_TYPE_STANDARD | USB_RECIP_INTERFACE' in code_no_strings and 'USB_REQ_GET_DESCRIPTOR' in code_no_strings and 'HID_DT_REPORT<<8' in compact,
 'rawDescriptorLen':'findHidReportLength' in code_no_strings and 'getRawDescriptors()' in code_no_strings,
 'noSaveCall':'saveParams(' not in code_no_strings and 'triggerSave' not in code_no_strings,
 'noActuatorWriter':'WRITE_ACTUATOR' not in code_no_strings and 'WriteActuator' not in code_no_strings,
 'lockedUi':'USB IF3 DESCRIPTOR (0 TX)' in view and 'CH1/2/4-7 locked' in view,
 'v53Ui':'V53' in main and 'V53' in view,
 'v53ProbeCall':'buildIf3DescriptorProbe' in main,
 'permissionAction':'USB_PERMISSION_V53' in main,
}
for k,v in checks.items(): print(f'{k}: {"PASS" if v else "FAIL"}')
if not all(checks.values()): sys.exit(1)
print('V53 USB IF3 NO-CLAIM DESCRIPTOR VALIDATION: PASS')
