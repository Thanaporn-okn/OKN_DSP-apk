#!/usr/bin/env python3
from pathlib import Path
import re, sys
ROOT=Path(__file__).resolve().parents[1]
usb=(ROOT/'app/src/main/java/com/okn/dsp/UsbAcpDiscovery.java').read_text()
main=(ROOT/'app/src/main/java/com/okn/dsp/MainActivity.java').read_text()
view=(ROOT/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
grad=(ROOT/'app/build.gradle').read_text()
code=re.sub(r'/\*.*?\*/','',usb,flags=re.S)
code=re.sub(r'//[^\n]*','',code)
compact=code.replace(' ','')
checks={
 'versionCode1052':'versionCode 1052' in grad,
 'versionName52':"versionName '52.0.0'" in grad,
 'targetVid':'TARGET_VID = 0x6324' in usb,
 'targetPid':'TARGET_PID = 0x1719' in usb,
 'targetIf3':'TARGET_INTERFACE = 3' in usb,
 'noSetReportConst':'HID_REQ_SET_REPORT' not in code,
 'noUsbDirOut':'USB_DIR_OUT' not in code,
 'noAcpFrame':'0xA5' not in code and 'A5 5A' not in code,
 'noUfeAuth':'631C062443FD3844558001F3EDA0CCF8' not in code,
 'noDeviceDesc':'661C0624' not in code,
 'getDescriptorIn':'USB_REQ_GET_DESCRIPTOR' in code and 'USB_DIR_IN | UsbConstants.USB_TYPE_STANDARD' in code,
 'getReportInputOnly':'HID_REQ_GET_REPORT' in code and 'HID_REPORT_TYPE_INPUT' in code,
 'claimFalse':'claimInterface(hid,false)' in compact,
 'noForceTrue':'claimInterface(hid,true)' not in compact,
 'expectedEp81':'USB_ENDPOINT_XFER_INT' in code and 'interruptInEndpoint=' in usb,
 'noSaveCall':'saveParams(' not in code and 'triggerSave' not in code,
 'noActuatorWriter':'WRITE_ACTUATOR' not in code and 'WriteActuator' not in code,
 'lockedUi':'USB IF3 READ-ONLY (0 TX)' in view and 'CH1/2/4-7 locked' in view,
 'v52Ui':'V52' in main and 'V52' in view,
 'v52ProbeCall':'buildIf3ReadOnlyProbe' in main,
}
for k,v in checks.items(): print(f'{k}: {"PASS" if v else "FAIL"}')
if not all(checks.values()): sys.exit(1)
print('V52 USB IF3 ZERO-TX VALIDATION: PASS')
