#!/usr/bin/env python3
from pathlib import Path
import json, math, struct, re

ROOT = Path(__file__).resolve().parents[1]
DSP = (ROOT/'app/src/main/java/com/okn/dsp/DspProtocol.java').read_text()
BLE = (ROOT/'app/src/main/java/com/okn/dsp/BleManager.java').read_text()
VIEW = (ROOT/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
MAIN = (ROOT/'app/src/main/java/com/okn/dsp/MainActivity.java').read_text()
STATE = (ROOT/'app/src/main/java/com/okn/dsp/DspState.java').read_text()
GRADLE = (ROOT/'app/build.gradle').read_text()
DESC = json.loads((ROOT/'Sources/ProtocolEvidence/GoloPine_DeviceDescription_REAL_20260906_204555.json').read_text())

def req(cond, msg):
    if not cond:
        raise AssertionError(msg)

def method(src, signature, next_signature):
    a = src.index(signature)
    b = src.index(next_signature, a)
    return src[a:b]

req('versionCode 1044' in GRADLE and "versionName '44.0.0'" in GRADLE, 'V44 version mismatch')
req('OUTPUT_GAIN_MIN_DB = -70f' in DSP and 'OUTPUT_GAIN_MAX_DB = 6f' in DSP, 'output range missing')
req('float rounded = Math.round(safe);' in DSP, 'output writer must use 1 dB grid')
req('OUTPUT_GAIN_RELEASE_MIN_GAP_MS = 110L' in BLE, 'release-only output guard missing')
req('OUTPUT_GAIN_MAX_STEP_DB' not in BLE, 'V43 multi-packet output ramp still present')
req('outputGainCommitRequested' in BLE, 'release commit gate missing')
req('flushOutputVolumeRealtime' in BLE, 'release flush API missing')
req('flushSliderHardware(activeSlider);' in VIEW, 'drag release does not flush output target')
req('flushSliderHardware(pendingSlider);' in VIEW, 'tap release does not flush output target')
req('s.type != SL_CHANNEL || s.index == 2' in VIEW, 'CH3 must bypass biquad release flush')

set_block = method(BLE, 'private void setOutputVolumeRealtimeOnMain', '    void setEqRealtime')
req('outputGainTargets.put(channel0, safe);' in set_block, 'latest output target not retained')
req('scheduleOutputGainPump' not in set_block, 'MOVE path must not schedule non-CH3 hardware writes')
req('channel0 == 2' in set_block and 'DspProtocol.ID_BASS_VOLUME' in set_block, 'CH3 must stay BassVolume ID8')

pump_block = method(BLE, 'private void scheduleOutputGainPump', '    private void scheduleEqRealtimePump')
req('Iterator<Integer> it = outputGainCommitRequested.iterator();' in pump_block, 'pump must consume release commits only')
req('DspProtocol.outputGainFromCurrent(current, requested)' in pump_block, 'release target must be built from latest live record')
req('Math.min(' not in pump_block and 'copySign' not in pump_block, 'old stepped ramp still active in output pump')
req(pump_block.count('sendScheduledControl(PendingCommand.output(ch, target));') == 1, 'release pump must emit one full-record command per commit')

scheduler = method(BLE, 'private void originalCommandSchedulerTick()', '    private void scheduleOriginalCommandScheduler') if '    private void scheduleOriginalCommandScheduler' in BLE else BLE[BLE.index('private void originalCommandSchedulerTick()'):BLE.index('private void sendScheduledControl', BLE.index('private void originalCommandSchedulerTick()'))]
req('if (!outputGainCommitRequested.isEmpty())' in scheduler, '380 ms scheduler may still transmit MOVE-only targets')
req('if (!outputGainTargets.isEmpty())' not in scheduler, 'MOVE target still auto-pumped by original scheduler')

req('roundTo(v, 1.0f)' in VIEW, 'Out Volume UI must use 1 dB increment')
req('listener.onOutputVolumeValue' in BLE, 'output readback publish missing')
req('void onOutputVolumeValue(int channel0, float valueDb)' in MAIN, 'MainActivity output callback missing')
req('void setOutputVolumeFromDsp(int channel0, float valueDb)' in VIEW, 'DspView output readback missing')
req('channelVolume[ch] = clamp(value, -70f, 6f);' in STATE, 'state output range mismatch')

# Descriptor facts including BassVolume min/max/incmt.
act = {a['ID']: a for a in DESC['actuators']}
req(8 in act and act[8].get('name') == 'BassVolume', 'descriptor BassVolume ID8 missing')
cpar = act[8].get('cpar','')
req('min=-70' in cpar and 'max=6' in cpar and 'incmt=1' in cpar, 'BassVolume descriptor range/increment mismatch')
for eq_id in (4,5,6,14,15,16,17):
    req(eq_id in act and act[eq_id].get('type') == 4084, f'EQ actuator {eq_id} missing')

# Prove Tone Control math still reproduces descriptor at G=0.
tone = act[4]['UFE_TYPE_BIQUAD_CASCADE15_F'][0]
req(tone['typ'] == 17, 'CH1 first record not Tone Control')
F,F2,B,G,R = tone['F'], tone['F2'], tone['B'], tone['G'], tone['R']
SR = 44100.0

def f32(x):
    return struct.unpack('<f', struct.pack('<f', x))[0]

tb=10**(R/20.0); bb=10**(B/20.0)
at=math.tan(math.pi*F2/SR); ab=math.tan(math.pi*F/SR)
knt=2/(1+1/tb); kdt=2/(1+tb); knb=2/(1+1/bb); kdb=2/(1+bb)
a10=at+kdt; b10=at+knt; a11=at-kdt; b11=at-knt
a20=ab*kdb+1; b20=ab*knb-1; a21=ab*kdb-1; b21=ab*knb+1
a0=a10*a20; gl=10**(G/20.0)
calc=[
    f32(((b10*b20)/a0)*gl),
    f32((((b10*b21)+(b11*b20))/a0)*gl),
    f32(((b11*b21)/a0)*gl),
    f32(((a10*a21)+(a11*a20))/a0),
    f32((a11*a21)/a0),
]
obs=[tone[k] for k in ('B0','B1','B2','A1','A2')]
req(max(abs(a-b) for a,b in zip(calc,obs)) < 1e-5, 'Tone Control coefficient math changed')

print('V44 Out Volume release-only validation: PASS')
print('mapping: CH3=ID8 scalar live; CH1/2/4/5/6/7=first EQ record G, one write on release')
print('range/increment: -70..+6 dB, 1 dB')
print('MOVE writes for non-CH3: 0; RELEASE writes: <=1 full record per committed gesture')
