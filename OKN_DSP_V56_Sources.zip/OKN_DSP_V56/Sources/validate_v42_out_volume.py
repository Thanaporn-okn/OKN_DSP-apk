#!/usr/bin/env python3
from pathlib import Path
import json, math, struct, sys

ROOT = Path(__file__).resolve().parents[1]
DSP = (ROOT/'app/src/main/java/com/okn/dsp/DspProtocol.java').read_text()
BLE = (ROOT/'app/src/main/java/com/okn/dsp/BleManager.java').read_text()
VIEW = (ROOT/'app/src/main/java/com/okn/dsp/DspView.java').read_text()
MAIN = (ROOT/'app/src/main/java/com/okn/dsp/MainActivity.java').read_text()
STATE = (ROOT/'app/src/main/java/com/okn/dsp/DspState.java').read_text()
GRADLE = (ROOT/'app/build.gradle').read_text()
DESC = json.loads((ROOT/'Sources/ProtocolEvidence/GoloPine_DeviceDescription_REAL_20260906_204555.json').read_text())

def req(cond, msg):
    if not cond:
        raise AssertionError(msg)

req('versionCode 1042' in GRADLE and "versionName '42.0.0'" in GRADLE, 'V42 version mismatch')
req('OUTPUT_GAIN_MIN_DB = -70f' in DSP and 'OUTPUT_GAIN_MAX_DB = 6f' in DSP, 'output range missing')
req('static EqBand outputGainFromCurrent' in DSP, 'output gain builder missing')
req('toneControlCellGainFromCurrent' in DSP, 'tone-control G builder missing')
req('current.boostDb, gainDb, current.r' in DSP, 'output builder must preserve B/R and change G')
req('void setOutputVolumeRealtime(int channel0, float requestedDb)' in BLE, 'output transport entry missing')
req('channel0 == 2' in BLE and 'DspProtocol.ID_BASS_VOLUME' in BLE, 'CH3 must use BassVolume ID8')
req('outputGainTargets' in BLE and 'ORIGINAL_COMMAND_CADENCE_MS = 380L' in BLE, '380 ms output lane missing')
req('DspProtocol.outputGainFromCurrent(current, requested)' in BLE, 'send-time output target build missing')
req('listener.onOutputVolumeValue' in BLE, 'output readback publish missing')
req('void onOutputVolumeValue(int channel0, float valueDb)' in MAIN, 'MainActivity output callback missing')
req('void setOutputVolumeFromDsp(int channel0, float valueDb)' in VIEW, 'DspView output readback missing')
req('ble.setOutputVolumeRealtime(s.index, state.channelVolume[s.index])' in VIEW, 'Out Volume slider hardware write missing')
req('"Out Volume Ch"' in VIEW and '-70f, 6f' in VIEW, 'Out Volume UI range/label missing')
req('state.setChannelVolume(2, value);' in VIEW, 'BassVolume readback must mirror CH3 Out Volume')
req('channelVolume[ch] = clamp(value, -70f, 6f);' in STATE, 'state output range mismatch')

# Descriptor facts: EQ actuator IDs and BassVolume ID8.
act = {a['ID']: a for a in DESC['actuators']}
req(8 in act and act[8].get('name') == 'BassVolume', 'descriptor BassVolume ID8 missing')
for eq_id in (4,5,6,14,15,16,17):
    req(eq_id in act and act[eq_id].get('type') == 4084, f'EQ actuator {eq_id} missing')

# Numerically prove existing Tone Control formula reproduces the real first record at G=0.
tone = act[4]['UFE_TYPE_BIQUAD_CASCADE15_F'][0]
req(tone['typ'] == 17, 'CH1 first record not Tone Control')
F,F2,B,G,R = tone['F'], tone['F2'], tone['B'], tone['G'], tone['R']
SR = 44100.0

def f32(x):
    return struct.unpack('<f', struct.pack('<f', x))[0]

tb=10**(R/20.0); bb=10**(B/20.0)
at=math.tan(math.pi*F2/SR); ab=math.tan(math.pi*F/SR)
knt=2/(1+1/tb); kdt=2/(1+tb); knb=2/(1+1/bb); kdb=2/(1+bb)
a10=at+kdt; b10=at+knt; a11=at-kdt; b11=at-knt
a20=ab*kdb+1; b20=ab*knb-1; a21=ab*kdb-1; b21=ab*knb+1
a0=a10*a20; gl=10**(G/20.0)
calc=[
    f32(((b10*b20)/a0)*gl),
    f32((((b10*b21)+(b11*b20))/a0)*gl),
    f32(((b11*b21)/a0)*gl),
    f32(((a10*a21)+(a11*a20))/a0),
    f32((a11*a21)/a0),
]
obs=[tone[k] for k in ('B0','B1','B2','A1','A2')]
req(max(abs(a-b) for a,b in zip(calc,obs)) < 1e-5, 'Tone Control coefficient math does not reproduce descriptor')

# Changing only cell gain must scale numerators and leave denominator coefficients unchanged.
scale = 10**(-6/20.0)
req(abs((calc[0]*scale)/calc[0] - scale) < 1e-9, 'gain scaling check failed')
req(abs(calc[3]-obs[3]) < 1e-5 and abs(calc[4]-obs[4]) < 1e-5, 'denominator preservation failed')

print('V42 Out Volume validation: PASS')
print('mapping: CH3=ID8; CH1/2/4/5/6/7=first EQ record G cell gain')
print('range: -70..+6 dB; serialized output cadence: 380 ms')
print('tone-control descriptor reproduction: PASS')
