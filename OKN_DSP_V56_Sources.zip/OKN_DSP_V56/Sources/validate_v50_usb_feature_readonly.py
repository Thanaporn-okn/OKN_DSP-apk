#!/usr/bin/env python3
from pathlib import Path
import re, sys
ROOT=Path(__file__).resolve().parents[1]
usb=(ROOT/'app/src/main/java/com/okn/dsp/UsbAcpDiscovery.java').read_text()
grad=(ROOT/'app/build.gradle').read_text()
checks={
 'versionCode1050':'versionCode 1050' in grad,
 'versionName50':"versionName '50.0.0'" in grad,
 'featureType3':'HID_REPORT_TYPE_FEATURE = 0x03' in usb,
 'featureSize8':'FEATURE_REPORT_SIZE = 8' in usb,
 'getReport':'HID_REQ_GET_REPORT = 0x01' in usb,
 'featureValue':'HID_REPORT_TYPE_FEATURE<<8' in usb,
 'claimFalse':'claimInterface(hid,false)' in usb.replace(' ',''),
 'noSetReport':'HID_REQ_SET_REPORT' not in usb,
 'noAcpFrame':'A5' not in re.sub(r'(?s)/\*.*?\*/|//.*','',usb),
 'noDirOut':'USB_DIR_OUT' not in usb,
 'noSaveParamsCall':'saveParams(' not in usb and 'triggerSave' not in usb,
}
for k,v in checks.items(): print(f'{k}: {"PASS" if v else "FAIL"}')
if not all(checks.values()): sys.exit(1)
print('V50 USB FEATURE READ-ONLY VALIDATION: PASS')
