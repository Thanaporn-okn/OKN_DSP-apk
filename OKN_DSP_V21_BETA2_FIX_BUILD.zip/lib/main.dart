import 'package:flutter/material.dart';

void main()=>runApp(const OKNDSP());

class OKNDSP extends StatelessWidget{
 const OKNDSP({super.key});
 Widget build(BuildContext c)=>MaterialApp(
 debugShowCheckedModeBanner:false,
 theme:ThemeData.dark(),
 home:const Home());
}

class Home extends StatelessWidget{
 const Home({super.key});
 Widget build(BuildContext c)=>Scaffold(
 backgroundColor:const Color(0xff0b1016),
 body:SafeArea(child:Column(children:[
 const Text("OKN_DSP V21 FIX BUILD",
 style:TextStyle(fontSize:28,color:Colors.cyan)),
 const Text("BP1048P4 7CH DSP"),
 Expanded(child:Center(
 child:Text("Bluetooth Ready")))
 ])));
}
