# Next after R29

R30 offline targets:
1. Pivot away from package-03 as a readback candidate: the inspected MVA parser only skips it by framed length and does not expose it as a readback helper.
2. Trace every host-facing USB/HID/UDisk/runtime dispatcher that could return bytes produced by an internal `SpiFlashRead` call without arming/resetting/updating.
3. Inspect PC-side updater/downloader binaries only for query/read/upload behavior, clearly separating it from erase/program flows.
4. Continue exact metadata-field recovery for 0xA4..0xA7, 0xBC..0xBF, 0xCC..0xD3, 0xE4..0xEB only where static evidence is sufficient.
5. Keep stock backup/recovery gate closed unless an arbitrary readback path is proven safe and a repeated full-flash dump can be SHA256 matched.

Do not create a live probe from an internal flash-read primitive alone. A primitive is not a host transport, and packet knowledge is not recovery proof.
