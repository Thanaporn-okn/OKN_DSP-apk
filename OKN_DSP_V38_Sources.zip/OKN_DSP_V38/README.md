# OKN DSP V38 — Verified Safe-PEAKING F/Q Re-enable

**Base:** V37 real-hardware-stable rollback. Master Volume and EQ Gain remain on the V37/V32 proven paths.

## Root cause identified

The real 105-band Device Description contains 98 records whose type is PEAKING (type 12), but only **55** are the production-safe active PEAKING rows. Those 55 rows carry `R=0`. The other **43** type-12 rows carry `R=0.12` and behave as bypass/placeholder rows. V33–V36 incorrectly treated all type-12 rows as writable. The failing CH6 / Band 9 test is one of the `R=0.12` rows, which explains why recomputing its biquad could create severe pumping/whistle and a DSP reboot.

## V38 hardware policy

- Master/Bass scalar paths: unchanged from V37.
- Band 1 native Tone-Control/Low-pass: **Gain LIVE only; F/Q locked**.
- PEAKING row is writable only when the fresh descriptor passes the strict safe-row predicate (`type=12`, `R≈0`, valid F/Q/Gain, real non-identity coefficients).
- F/Q hardware enable requires a fresh descriptor count of **exactly 55 safe PEAKING rows**. If the count differs, F/Q stays SAFE LOCK.
- Unsafe/bypass PEAKING rows (`R=0.12`) are read-only; Gain/F/Q are not transmitted.
- Safe F/Q uses a separate latest-target-wins queue at **110 ms minimum spacing**.
- Existing proven Gain queue stays at **45 ms**.
- Both queues share the same one-write-in-flight GATT/AES-CFB8 stream. Gain has priority.
- Every EQ write remains a **full 48-byte record** and preserves live F2/G/R metadata.
- Reset EQ remains **local-only / hardware locked** in V38. No multi-band reset packets.
- No SaveParams is sent automatically.

## First real-hardware qualification

Test only **CH1 / Band 4** first, at low Master Volume. Make small Frequency movements, then small Q movements. Do not start by sweeping the entire 20 Hz–20 kHz range. CH1/Band4 is in the proven safe set and has historical target/restore evidence.

## Version

- versionName: **38.0.0**
- versionCode: **1038**
- applicationId: `com.okn.dsp`

Full Android APK build remains delegated to the supplied GitHub Actions workflow.
