package com.okn.dsp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.OverScroller;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class DspView extends View {
    public interface Host {
        void requestThemePicker(int currentTheme);
        void onThemeChanged(int themeIndex);
        void requestPresetName(String currentName);
        void requestPresetPicker(String currentName);
        void requestDeletePreset(String currentName);
        void showMessage(String message);
    }

    private final Host host;
    private final DspState state;
    // V32: verified V17 BLE/auth/session stack is attached without replacing the V29/V30 UI.
    private BleManager ble;
    private String bleStatus = "กำลังเตรียม Bluetooth";
    private String bleDevice = "OKN-DSP_7CH";
    private boolean bleReady;
    private String bleDiagnostic = "";
    private final boolean[][] eqGainWritable = new boolean[DspState.CHANNELS][DspState.BANDS];
    private final boolean[][] eqShapeWritable = new boolean[DspState.CHANNELS][DspState.BANDS];
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    // V19: frame-local RectF pool. The old renderer created dozens of RectF
    // objects per frame while dragging/scrolling, causing periodic GC pauses.
    private final RectF[] rectPool = new RectF[128];
    private int rectPoolIndex;
    // V2: lock Canvas typography to Android's bundled Roboto instead of the
    // user-selected Samsung/system font.
    private final Typeface normal = AppFonts.REGULAR;
    private final Typeface medium = AppFonts.MEDIUM;
    private final Typeface bold = AppFonts.BOLD;
    private final float density;

    private int bg, card, cardAlt, text, sub, line, accent, accentSoft, green, teal, mintGreen, cyan, red, pink;
    private final List<Hit> hits = new ArrayList<>();
    private final List<SliderHit> sliders = new ArrayList<>();
    private final float[] scrollY = new float[3];
    private final float[] maxScroll = new float[3];
    private SliderHit activeSlider;
    private float downX, downY, startScroll;
    private boolean scrolling;
    private boolean navTouch;
    private boolean collectTouchTargets = true;
    private float contentTop, navTop;
    // V21/V23: modal UI is rendered inside this same hardware-accelerated Canvas.
    // Keeping Theme, Saved Presets and Delete confirmation out of WindowManager
    // avoids the visible hitch caused by creating/dismissing Android Dialog windows
    // on Samsung devices.
    private boolean themePickerOpen;
    private boolean presetPickerOpen;
    private boolean deletePresetOpen;

    // V20 gesture engine: native-feeling direction lock + kinetic scrolling.
    // V19 changed storage/render cadence but still moved content directly with
    // every MotionEvent and stopped dead on ACTION_UP. On slider-heavy screens
    // a vertical swipe could also be captured as a slider gesture immediately.
    private final OverScroller scroller;
    private final int touchSlop;
    private final int minimumFlingVelocity;
    private final int maximumFlingVelocity;
    private VelocityTracker velocityTracker;
    private SliderHit pendingSlider;
    private int flingPage = -1;
    private boolean stoppedFlingOnDown;

    // EQ response cache. Scrolling a static EQ page must not recalculate hundreds
    // of log/exp operations every display frame. The cache is rebuilt only when
    // the selected channel's actual EQ values change.
    private static final int GRAPH_SAMPLES = 96;
    private final float[] graphResponses = new float[GRAPH_SAMPLES];
    private final double[] graphBandLogFc = new double[DspState.BANDS];
    private final double[] graphBandInvWidth = new double[DspState.BANDS];
    private final double[] graphBandGain = new double[DspState.BANDS];
    private long graphCacheSignature = Long.MIN_VALUE;
    private int graphCacheChannel = -1;
    // V11: real system-bar/cutout safe-area insets in physical pixels.
    // Android 15+ enforces edge-to-edge for targetSdk 35, so content must
    // explicitly stay clear of the status and navigation bars.
    private int systemInsetLeftPx, systemInsetTopPx, systemInsetRightPx, systemInsetBottomPx;

    private static final int SL_MASTER = 1;
    private static final int SL_BASS = 2;
    private static final int SL_CUTOFF = 3;
    private static final int SL_CHANNEL = 4;
    private static final int SL_EQ_FREQ = 5;
    private static final int SL_EQ_Q = 6;
    private static final int SL_EQ_GAIN = 7;

    public DspView(Context context) {
        super(context);
        if (!(context instanceof Host)) throw new IllegalArgumentException("Host Activity required");
        host = (Host) context;
        state = new DspState(context);
        density = getResources().getDisplayMetrics().density;
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        ViewConfiguration vc = ViewConfiguration.get(context);
        touchSlop = vc.getScaledTouchSlop();
        minimumFlingVelocity = vc.getScaledMinimumFlingVelocity();
        maximumFlingVelocity = vc.getScaledMaximumFlingVelocity();
        scroller = new OverScroller(context);
        setFocusable(true);
        setClickable(true);
        // Explicitly keep the custom Canvas view on the hardware accelerated path.
        // Android enables this by default for apps, but making it explicit prevents
        // accidental software fallback if a theme/window flag changes later.
        setLayerType(View.LAYER_TYPE_NONE, null);
    }

    void setBleManager(BleManager manager) {
        ble = manager;
    }

    void setBleStatus(String status, String deviceName, boolean ready) {
        bleStatus = status == null ? "" : status;
        if (deviceName != null && !deviceName.trim().isEmpty()) bleDevice = deviceName.trim();
        bleReady = ready;
        requestFrame();
    }

    void setDiagnostic(String message) {
        bleDiagnostic = message == null ? "" : message;
        requestFrame();
    }

    void setScalarFromDsp(int actuatorId, float value) {
        if (!Float.isFinite(value)) return;
        if (actuatorId == DspProtocol.ID_MASTER_VOLUME) {
            state.masterVolume = clamp(value, -70f, 6f);
        } else if (actuatorId == DspProtocol.ID_BASS_VOLUME) {
            state.bassVolume = clamp(value, -70f, 6f);
        } else if (actuatorId == DspProtocol.ID_BASS_CUTOFF) {
            state.bassCutoff = clamp(value, 20f, 250f);
        } else {
            return;
        }
        requestFrame();
    }

    void setEqFromDsp(int channel0, int band0, float frequency, float gainDb, float q,
                      boolean gainWritable, boolean shapeWritable) {
        if (channel0 < 0 || channel0 >= DspState.CHANNELS || band0 < 0 || band0 >= DspState.BANDS) return;
        if (Float.isFinite(frequency)) state.eqFreq[channel0][band0] = clamp(frequency, 20f, 20000f);
        if (Float.isFinite(q)) state.eqQ[channel0][band0] = clamp(q, 0.1f, 10f);
        if (Float.isFinite(gainDb)) state.eqGain[channel0][band0] = clamp(gainDb, -12f, 12f);
        eqGainWritable[channel0][band0] = gainWritable;
        eqShapeWritable[channel0][band0] = shapeWritable;
        graphCacheSignature = Long.MIN_VALUE;
        requestFrame();
    }

    private void sendVerifiedScalar(int actuatorId, float value) {
        if (ble != null && bleReady) ble.setScalarRealtime(actuatorId, value);
    }

    private void sendVerifiedEqGain(int ch, int band) {
        if (ble == null || !bleReady || ch < 0 || ch >= DspState.CHANNELS || band < 0 || band >= DspState.BANDS) return;
        if (!eqGainWritable[ch][band]) return;
        ble.setEqRealtime(ch, band, state.eqFreq[ch][band], state.eqGain[ch][band], state.eqQ[ch][band]);
    }

    private void sendVerifiedEqShape(int ch, int band) {
        if (ble == null || !bleReady || ch < 0 || ch >= DspState.CHANNELS || band < 0 || band >= DspState.BANDS) return;
        if (!eqShapeWritable[ch][band]) return;
        ble.setEqShapeRealtime(ch, band, state.eqFreq[ch][band], state.eqGain[ch][band], state.eqQ[ch][band]);
    }

    private void sendVerifiedGlobal() {
        sendVerifiedScalar(DspProtocol.ID_MASTER_VOLUME, state.masterVolume);
        sendVerifiedScalar(DspProtocol.ID_BASS_VOLUME, state.bassVolume);
        sendVerifiedScalar(DspProtocol.ID_BASS_CUTOFF, state.bassCutoff);
    }

    public int getThemeIndex() {
        return state.theme;
    }

    public void setThemeIndex(int index) {
        state.setTheme(index);
        requestFrame();
    }

    public void flushState(boolean synchronous) {
        if (synchronous) state.persistAll(true);
        else state.flushPending(false);
    }

    private void requestFrame() {
        // V19: synchronize redraws to display vsync. Rapid MotionEvents are
        // coalesced into a single frame instead of forcing uneven redraw bursts.
        postInvalidateOnAnimation();
    }

    /**
     * Receives the current safe drawing area from the Activity. Values are
     * physical pixels because Canvas coordinates are also physical pixels.
     * Keeping this in DspView avoids hard-coded status-bar heights and works
     * with punch-hole cameras, display cutouts, tablets and gesture navigation.
     */
    public void setSystemInsets(int leftPx, int topPx, int rightPx, int bottomPx) {
        leftPx = Math.max(0, leftPx);
        topPx = Math.max(0, topPx);
        rightPx = Math.max(0, rightPx);
        bottomPx = Math.max(0, bottomPx);
        if (systemInsetLeftPx == leftPx && systemInsetTopPx == topPx
                && systemInsetRightPx == rightPx && systemInsetBottomPx == bottomPx) return;
        systemInsetLeftPx = leftPx;
        systemInsetTopPx = topPx;
        systemInsetRightPx = rightPx;
        systemInsetBottomPx = bottomPx;
        requestFrame();
    }

    /**
     * Reads the installed package version at runtime. This deliberately avoids
     * BuildConfig because AGP 8 projects can have BuildConfig generation
     * disabled, which caused the V6 GitHub Actions javac failure.
     */
    private String appVersionName() {
        try {
            String version = getContext().getPackageManager()
                    .getPackageInfo(getContext().getPackageName(), 0).versionName;
            return (version == null || version.trim().isEmpty()) ? "29.0.0" : version;
        } catch (Exception ignored) {
            return "29.0.0";
        }
    }

    public void savePreset(String name) {
        state.savePreset(name);
        host.showMessage("Saved preset: " + state.getDisplayPresetName());
        requestFrame();
    }

    public String[] getPresetNames() {
        return state.getPresetNames();
    }

    public void selectPreset(String name) {
        // V19: choosing a preset remains an immediate action. The picker loads
        // the stored EQ/mix snapshot instead of only changing the selected name.
        // This matches the UI expectation that the graph and controls change as
        // soon as a preset row is tapped.
        if (state.loadPreset(name)) {
            host.showMessage("Loaded preset: " + state.getDisplayPresetName());
            requestFrame();
        } else {
            host.showMessage("Preset could not be loaded");
        }
    }

    public void deletePreset(String name) {
        if (state.deletePreset(name)) {
            host.showMessage("Deleted preset: " + name);
        } else {
            host.showMessage("Preset not found");
        }
        requestFrame();
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        rectPoolIndex = 0;
        updatePalette();
        c.drawColor(bg);

        // Rebuild hit targets only while the UI is idle. During slider drags or
        // scroll gestures their geometry is unchanged (or temporarily unused),
        // so preserving the previous lists avoids dozens of short-lived RectF /
        // Hit allocations on every 60/90/120 Hz frame and reduces GC stutter.
        collectTouchTargets = activeSlider == null && !scrolling && flingPage < 0;
        if (collectTouchTargets) {
            hits.clear();
            sliders.clear();
        }

        float w = getWidth();
        float h = getHeight();
        contentTop = systemInsetTopPx + dp(82);
        navTop = h - systemInsetBottomPx - dp(84);

        drawHeader(c, w);

        int save = c.save();
        c.clipRect(0, contentTop, w, navTop - dp(4));
        if (state.page == 0) drawHome(c, w);
        else if (state.page == 1) drawMix(c, w);
        else drawEq(c, w);
        c.restoreToCount(save);

        drawBottomNav(c, w, h);

        if (themePickerOpen || presetPickerOpen || deletePresetOpen) {
            // The in-view modal owns all input while visible. Remove hit targets
            // behind it so taps can never leak into Mix/EQ controls.
            hits.clear();
            sliders.clear();
            collectTouchTargets = true;
            if (themePickerOpen) drawThemeOverlay(c, w, h);
            else if (presetPickerOpen) drawPresetPickerOverlay(c, w, h);
            else drawDeletePresetOverlay(c, w, h);
        }
    }

    private void drawThemeOverlay(Canvas c, float w, float h) {
        // Same-view modal: one compositor layer, no Dialog/WindowManager hand-off.
        p.setColor(state.theme == 0 ? 0x78000000 : 0x98000000);
        p.setStyle(Paint.Style.FILL);
        c.drawRect(0, 0, w, h, p);

        final float safeLeft = systemInsetLeftPx + dp(18);
        final float safeRight = w - systemInsetRightPx - dp(18);
        final float maxWidth = dp(520);
        final float cardWidth = Math.min(Math.max(dp(280), safeRight - safeLeft), maxWidth);
        final float left = (w - cardWidth) * 0.5f;
        final float topLimit = systemInsetTopPx + dp(72);
        final float bottomLimit = h - systemInsetBottomPx - dp(96);
        final float cardHeight = dp(392);
        final float top = Math.max(topLimit, Math.min((topLimit + bottomLimit - cardHeight) * 0.5f, bottomLimit - cardHeight));
        final float right = left + cardWidth;
        final float bottom = top + cardHeight;

        final int modalCard = state.theme == 0 ? 0xFFFDFEFF : (state.theme == 1 ? 0xFF151E2D : 0xFF0C1421);
        final int modalRow = state.theme == 0 ? 0xFFF2F6FA : (state.theme == 1 ? 0xFF1C283A : 0xFF111F31);
        final int modalSub = state.theme == 0 ? 0xFF748399 : 0xFF9EABBE;
        final int themeAccent = 0xFF10B981;
        final int selectedSoft = state.theme == 0 ? 0xFFE8FAF4 : 0xFF12372F;

        RectF modal = rect(left, top, right, bottom);
        drawRoundRect(c, modal, dp(28), modalCard);

        // Small grabber keeps the visual language close to a modern bottom sheet.
        drawRoundRect(c, rect(w * 0.5f - dp(22), top + dp(11), w * 0.5f + dp(22), top + dp(15)), dp(2),
                state.theme == 0 ? 0xFFD1D9E5 : 0xFF39485D);

        drawCircle(c, left + dp(42), top + dp(58), dp(22), withAlpha(themeAccent, state.theme == 0 ? 28 : 58));
        drawText(c, "T", left + dp(42), top + dp(65), dp(18), themeAccent, bold, Paint.Align.CENTER);
        drawText(c, "Theme", left + dp(78), top + dp(54), dp(22), text, bold, Paint.Align.LEFT);
        drawText(c, "Choose how OKN DSP looks on your device.", left + dp(78), top + dp(76), dp(13), modalSub, normal, Paint.Align.LEFT);

        String[] names = {"Light", "Dark", "Midnight"};
        String[] desc = {"Clean and bright interface", "Easy on the eyes", "Deep dark for low light"};
        String[] symbols = {"L", "D", "M"};
        float rowY = top + dp(100);
        for (int i = 0; i < 3; i++) {
            boolean selected = i == state.theme;
            RectF rowRect = rect(left + dp(18), rowY, right - dp(18), rowY + dp(68));
            drawRoundRect(c, rowRect, dp(18), selected ? selectedSoft : modalRow);
            if (selected) {
                stroke.setStyle(Paint.Style.STROKE);
                stroke.setStrokeWidth(dp(1.2f));
                stroke.setColor(themeAccent);
                c.drawRoundRect(rowRect, dp(18), dp(18), stroke);
            }
            int iconFill = selected ? withAlpha(themeAccent, state.theme == 0 ? 28 : 52)
                    : (state.theme == 0 ? 0xFFEAF0F7 : 0xFF233148);
            drawCircle(c, left + dp(48), rowY + dp(34), dp(20), iconFill);
            drawText(c, symbols[i], left + dp(48), rowY + dp(40), dp(14), selected ? themeAccent : modalSub, bold, Paint.Align.CENTER);
            drawText(c, names[i], left + dp(82), rowY + dp(29), dp(17), text, medium, Paint.Align.LEFT);
            drawText(c, desc[i], left + dp(82), rowY + dp(49), dp(12), modalSub, normal, Paint.Align.LEFT);

            float radioX = right - dp(46);
            float radioY = rowY + dp(34);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(dp(2));
            stroke.setColor(selected ? themeAccent : modalSub);
            c.drawCircle(radioX, radioY, dp(10), stroke);
            if (selected) drawCircle(c, radioX, radioY, dp(5), themeAccent);
            addHit("themeOpt" + i, rowRect);
            rowY += dp(76);
        }

        RectF cancel = rect(left + dp(18), bottom - dp(64), right - dp(18), bottom - dp(16));
        drawRoundRect(c, cancel, dp(16), state.theme == 0 ? 0xFFEAF0F7 : 0xFF1D2A3D);
        drawText(c, "Cancel", cancel.centerX(), cancel.centerY() + dp(5), dp(15), themeAccent, medium, Paint.Align.CENTER);
        addHit("themeCancel", cancel);

        // Tapping the shaded area also dismisses; this is tested last because
        // findHit walks hits from newest to oldest.
        addHit("themeBackdrop", rect(0, 0, w, h));
        // Re-add modal controls after backdrop so they remain topmost.
        for (int i = 0; i < 3; i++) {
            float ry = top + dp(100) + i * dp(76);
            addHit("themeOpt" + i, rect(left + dp(18), ry, right - dp(18), ry + dp(68)));
        }
        addHit("themeCancel", cancel);
    }

    private void drawPresetPickerOverlay(Canvas c, float w, float h) {
        p.setColor(state.theme == 0 ? 0x78000000 : 0x98000000);
        p.setStyle(Paint.Style.FILL);
        c.drawRect(0, 0, w, h, p);

        String[] names = state.getPresetNames();
        final float safeLeft = systemInsetLeftPx + dp(18);
        final float safeRight = w - systemInsetRightPx - dp(18);
        final float maxWidth = dp(520);
        final float cardWidth = Math.min(Math.max(dp(280), safeRight - safeLeft), maxWidth);
        final float left = (w - cardWidth) * 0.5f;
        final float topLimit = systemInsetTopPx + dp(72);
        final float bottomLimit = h - systemInsetBottomPx - dp(96);
        final float rowH = dp(62);
        final float fixedH = dp(166);
        final int maxRows = Math.max(1, Math.min(7, (int) ((bottomLimit - topLimit - fixedH) / rowH)));
        final int visibleRows = Math.min(names.length, maxRows);
        final float cardHeight = fixedH + rowH * visibleRows;
        final float top = Math.max(topLimit, Math.min((topLimit + bottomLimit - cardHeight) * 0.5f, bottomLimit - cardHeight));
        final float right = left + cardWidth;
        final float bottom = top + cardHeight;

        final int modalCard = state.theme == 0 ? 0xFFFDFEFF : (state.theme == 1 ? 0xFF151E2D : 0xFF0C1421);
        final int modalRow = state.theme == 0 ? 0xFFF2F6FA : (state.theme == 1 ? 0xFF1C283A : 0xFF111F31);
        final int modalSub = state.theme == 0 ? 0xFF748399 : 0xFF9EABBE;
        final int pickerAccent = 0xFF12B8C4;
        final int selectedSoft = state.theme == 0 ? 0xFFE9FBFB : 0xFF12363A;

        RectF modal = rect(left, top, right, bottom);
        drawRoundRect(c, modal, dp(28), modalCard);
        drawRoundRect(c, rect(w * 0.5f - dp(22), top + dp(11), w * 0.5f + dp(22), top + dp(15)), dp(2),
                state.theme == 0 ? 0xFFD1D9E5 : 0xFF39485D);

        drawCircle(c, left + dp(42), top + dp(58), dp(22), withAlpha(pickerAccent, state.theme == 0 ? 28 : 58));
        drawText(c, "P", left + dp(42), top + dp(65), dp(18), pickerAccent, bold, Paint.Align.CENTER);
        drawText(c, "Saved Presets", left + dp(78), top + dp(54), dp(22), text, bold, Paint.Align.LEFT);
        drawText(c, "Tap a preset to load it instantly.", left + dp(78), top + dp(76), dp(13), modalSub, normal, Paint.Align.LEFT);

        String current = state.getDisplayPresetName();
        float rowY = top + dp(96);
        for (int i = 0; i < visibleRows; i++) {
            String name = names[i];
            boolean selected = name.equals(current);
            RectF rowRect = rect(left + dp(18), rowY, right - dp(18), rowY + dp(54));
            drawRoundRect(c, rowRect, dp(16), selected ? selectedSoft : modalRow);
            if (selected) {
                stroke.setStyle(Paint.Style.STROKE);
                stroke.setStrokeWidth(dp(1.2f));
                stroke.setColor(pickerAccent);
                c.drawRoundRect(rowRect, dp(16), dp(16), stroke);
            }
            drawCircle(c, left + dp(47), rowY + dp(27), dp(17), withAlpha(pickerAccent, state.theme == 0 ? 28 : 52));
            String initial = name.isEmpty() ? "P" : name.substring(0, 1).toUpperCase(Locale.US);
            drawText(c, initial, left + dp(47), rowY + dp(33), dp(13), pickerAccent, bold, Paint.Align.CENTER);
            drawText(c, name, left + dp(76), rowY + dp(23), dp(16), text, medium, Paint.Align.LEFT);
            drawText(c, selected ? "Currently loaded" : "Load this preset", left + dp(76), rowY + dp(42), dp(11), modalSub, normal, Paint.Align.LEFT);
            drawText(c, selected ? "✓" : "›", right - dp(42), rowY + dp(34), dp(20), selected ? pickerAccent : modalSub, medium, Paint.Align.CENTER);
            addHit("presetOpt" + i, rowRect);
            rowY += rowH;
        }

        if (names.length > visibleRows) {
            drawText(c, "+" + (names.length - visibleRows) + " more presets", left + dp(22), bottom - dp(72), dp(12), modalSub, normal, Paint.Align.LEFT);
        }

        RectF cancel = rect(left + dp(18), bottom - dp(60), right - dp(18), bottom - dp(14));
        drawRoundRect(c, cancel, dp(16), state.theme == 0 ? 0xFFEAF0F7 : 0xFF1D2A3D);
        drawText(c, "Cancel", cancel.centerX(), cancel.centerY() + dp(5), dp(15), pickerAccent, medium, Paint.Align.CENTER);

        addHit("presetBackdrop", rect(0, 0, w, h));
        rowY = top + dp(96);
        for (int i = 0; i < visibleRows; i++) {
            addHit("presetOpt" + i, rect(left + dp(18), rowY, right - dp(18), rowY + dp(54)));
            rowY += rowH;
        }
        addHit("presetCancel", cancel);
    }

    private void drawDeletePresetOverlay(Canvas c, float w, float h) {
        p.setColor(state.theme == 0 ? 0x78000000 : 0x98000000);
        p.setStyle(Paint.Style.FILL);
        c.drawRect(0, 0, w, h, p);

        final float safeLeft = systemInsetLeftPx + dp(18);
        final float safeRight = w - systemInsetRightPx - dp(18);
        final float maxWidth = dp(520);
        final float cardWidth = Math.min(Math.max(dp(280), safeRight - safeLeft), maxWidth);
        final float left = (w - cardWidth) * 0.5f;
        final float topLimit = systemInsetTopPx + dp(72);
        final float bottomLimit = h - systemInsetBottomPx - dp(96);
        final float cardHeight = dp(286);
        final float top = Math.max(topLimit, Math.min((topLimit + bottomLimit - cardHeight) * 0.5f, bottomLimit - cardHeight));
        final float right = left + cardWidth;
        final float bottom = top + cardHeight;

        final int modalCard = state.theme == 0 ? 0xFFFDFEFF : (state.theme == 1 ? 0xFF151E2D : 0xFF0C1421);
        final int modalRow = state.theme == 0 ? 0xFFFFF1F5 : (state.theme == 1 ? 0xFF3B1C2A : 0xFF301421);
        final int modalSub = state.theme == 0 ? 0xFF748399 : 0xFF9EABBE;
        final int danger = 0xFFE91E63;
        final int dangerSoft = state.theme == 0 ? 0xFFFFE7F0 : 0xFF4A1A2D;

        RectF modal = rect(left, top, right, bottom);
        drawRoundRect(c, modal, dp(28), modalCard);
        drawRoundRect(c, rect(w * 0.5f - dp(22), top + dp(11), w * 0.5f + dp(22), top + dp(15)), dp(2),
                state.theme == 0 ? 0xFFD1D9E5 : 0xFF39485D);
        drawCircle(c, left + dp(42), top + dp(58), dp(22), dangerSoft);
        drawText(c, "!", left + dp(42), top + dp(65), dp(20), danger, bold, Paint.Align.CENTER);
        drawText(c, "Delete preset", left + dp(78), top + dp(54), dp(22), text, bold, Paint.Align.LEFT);
        drawText(c, "Remove this EQ preset from your saved presets.", left + dp(78), top + dp(76), dp(12), modalSub, normal, Paint.Align.LEFT);

        String name = state.getDisplayPresetName();
        RectF preset = rect(left + dp(18), top + dp(102), right - dp(18), top + dp(166));
        drawRoundRect(c, preset, dp(16), modalRow);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(dp(1.1f));
        stroke.setColor(danger);
        c.drawRoundRect(preset, dp(16), dp(16), stroke);
        drawCircle(c, left + dp(47), top + dp(134), dp(17), dangerSoft);
        String initial = name.isEmpty() ? "P" : name.substring(0, 1).toUpperCase(Locale.US);
        drawText(c, initial, left + dp(47), top + dp(140), dp(13), danger, bold, Paint.Align.CENTER);
        drawText(c, name, left + dp(76), top + dp(128), dp(16), text, medium, Paint.Align.LEFT);
        drawText(c, "This action cannot be undone.", left + dp(76), top + dp(149), dp(11), modalSub, normal, Paint.Align.LEFT);

        float gap = dp(10);
        float buttonY = bottom - dp(66);
        float half = (cardWidth - dp(36) - gap) * 0.5f;
        RectF cancel = rect(left + dp(18), buttonY, left + dp(18) + half, bottom - dp(16));
        RectF delete = rect(cancel.right + gap, buttonY, right - dp(18), bottom - dp(16));
        drawRoundRect(c, cancel, dp(16), state.theme == 0 ? 0xFFEAF0F7 : 0xFF1D2A3D);
        drawRoundRect(c, delete, dp(16), danger);
        drawText(c, "Cancel", cancel.centerX(), cancel.centerY() + dp(5), dp(15), accent, medium, Paint.Align.CENTER);
        drawText(c, "Delete", delete.centerX(), delete.centerY() + dp(5), dp(15), 0xFFFFFFFF, medium, Paint.Align.CENTER);

        addHit("deleteBackdrop", rect(0, 0, w, h));
        addHit("deleteCancel", cancel);
        addHit("deleteConfirm", delete);
    }

    private void updatePalette() {
        if (state.theme == 0) {
            bg = 0xFFF4F7FB;
            card = 0xFFFFFFFF;
            cardAlt = 0xFFF0F4F9;
            text = 0xFF0C1220;
            sub = 0xFF79869A;
            line = 0xFFE4EAF2;
            accent = 0xFF138CF5;
            accentSoft = 0xFFE7F2FF;
        } else if (state.theme == 1) {
            bg = 0xFF0D1320;
            card = 0xFF151E2D;
            cardAlt = 0xFF1B2638;
            text = 0xFFF3F7FD;
            sub = 0xFF9EABBE;
            line = 0xFF28364A;
            accent = 0xFF2E9BFF;
            accentSoft = 0xFF142C45;
        } else {
            bg = 0xFF050A13;
            card = 0xFF0C1421;
            cardAlt = 0xFF101C2D;
            text = 0xFFF6F8FC;
            sub = 0xFF8E9AAF;
            line = 0xFF1D2B3E;
            accent = 0xFF21B7FF;
            accentSoft = 0xFF09253A;
        }
        green = 0xFF22C55E;
        teal = 0xFF14B8A6;
        mintGreen = 0xFF34D399;
        cyan = 0xFF16C4D7;
        red = 0xFFF43F5E;
        pink = 0xFFEC4899;
    }

    private void drawHeader(Canvas c, float w) {
        float left = contentLeft(w);
        float right = contentRight(w);
        String title = state.page == 0 ? "OKN DSP" : state.page == 1 ? "Mix" : "Eq";
        String subtitle = state.page == 0 ? "DSP Controller" : state.page == 1 ? "Channel and bass controls" : "15-band equalizer";

        float headerTop = systemInsetTopPx;
        drawText(c, title, left, headerTop + dp(34), dp(state.page == 0 ? 28 : 32), text, bold, Paint.Align.LEFT);
        drawText(c, subtitle, left, headerTop + dp(58), dp(16), sub, normal, Paint.Align.LEFT);

        float r = dp(21);
        float cy = headerTop + dp(37);
        float searchX = right - dp(70);
        float menuX = right - dp(22);
        drawCircleButton(c, searchX, cy, r);
        drawSearchIcon(c, searchX, cy);
        addHit("search", rect(searchX - r, cy - r, searchX + r, cy + r));

        drawCircleButton(c, menuX, cy, r);
        drawOverflowIcon(c, menuX, cy);
        addHit("theme", rect(menuX - r, cy - r, menuX + r, cy + r));
    }

    private void drawHome(Canvas c, float w) {
        float left = contentLeft(w), right = contentRight(w);
        float y = contentTop + dp(8) - scrollY[0];
        float fullW = right - left;

        RectF statusCard = rect(left, y, right, y + dp(120));
        drawRoundRect(c, statusCard, dp(24), state.theme == 0 ? 0xFFF0FFF4 : card);
        int liveColor = bleReady ? green : (bleStatus.contains("กำลัง") ? accent : pink);
        drawCircle(c, left + dp(48), y + dp(59), dp(31), withAlpha(liveColor, 40));
        drawCircle(c, left + dp(48), y + dp(59), dp(24), liveColor);
        if (bleReady) drawCheck(c, left + dp(48), y + dp(59), 0xFFFFFFFF);
        else drawMiniHomeIcon(c, 0, left + dp(48), y + dp(59), 0xFFFFFFFF);
        drawText(c, "SYSTEM STATUS", left + dp(92), y + dp(40), dp(13), sub, medium, Paint.Align.LEFT);
        drawText(c, bleReady ? "DSP Ready" : "Connecting DSP", left + dp(92), y + dp(68), dp(22), text, bold, Paint.Align.LEFT);
        drawText(c, bleReady ? "Authenticated session • Live control enabled" : bleStatus, left + dp(92), y + dp(91), dp(14), sub, normal, Paint.Align.LEFT);
        drawChevron(c, right - dp(24), y + dp(60), sub);
        addHit("homeSystem", statusCard);

        y += dp(146);
        drawText(c, "Connection & Status", left + dp(4), y, dp(22), text, bold, Paint.Align.LEFT);
        drawText(c, bleReady ? "Live" : "Connecting", right - dp(24), y, dp(15), bleReady ? accent : pink, medium, Paint.Align.RIGHT);
        drawCircle(c, right - dp(10), y - dp(5), dp(5), bleReady ? green : pink);
        y += dp(18);

        String[] names = {"Bluetooth", "DSP Device", "Audio Input", "Amplifier Link", "Preset Sync", "Firmware Status"};
        String[] details = {bleReady ? "BLE authenticated" : bleStatus, bleDevice, "AUX (Analog)", "External Amplifier", "User presets", "v" + appVersionName() + " (Phase 2)"};
        String[] statuses = {bleReady ? "Connected" : "Waiting", bleReady ? "READY" : "Connecting", "Active", bleReady ? "Connected" : "Waiting", "Synced", "Up to date"};
        int[] iconColors = {accent, pink, red, cyan, green, teal};
        for (int i = 0; i < names.length; i++) {
            y += dp(12);
            RectF row = rect(left, y, right, y + dp(66));
            drawRoundRect(c, row, dp(18), card);
            drawCircle(c, left + dp(35), y + dp(33), dp(23), withAlpha(iconColors[i], state.theme == 0 ? 34 : 70));
            drawMiniHomeIcon(c, i, left + dp(35), y + dp(33), iconColors[i]);
            drawText(c, names[i], left + dp(72), y + dp(28), dp(17), text, medium, Paint.Align.LEFT);
            drawText(c, details[i], left + dp(72), y + dp(48), dp(13), sub, normal, Paint.Align.LEFT);
            int stColor = (i == 0 || i == 1 || i == 3) ? (bleReady ? green : pink) : (i == 2 || i == 5 ? accent : green);
            drawCircle(c, right - dp(116), y + dp(33), dp(5), stColor);
            drawText(c, statuses[i], right - dp(28), y + dp(38), dp(14), stColor, medium, Paint.Align.RIGHT);
            drawChevron(c, right - dp(14), y + dp(33), sub);
            addHit("homeRow" + i, row);
            y += dp(66);
        }

        y += dp(16);
        RectF quick = rect(left, y, right, y + dp(78));
        drawRoundRect(c, quick, dp(20), card);
        drawCircle(c, left + dp(37), y + dp(39), dp(24), withAlpha(pink, state.theme == 0 ? 24 : 48));
        drawEqBarsIcon(c, left + dp(37), y + dp(39), pink);
        drawText(c, "Quick Control", left + dp(76), y + dp(34), dp(18), text, medium, Paint.Align.LEFT);
        drawText(c, "Adjust volume, presets and more", left + dp(76), y + dp(55), dp(13), sub, normal, Paint.Align.LEFT);
        drawChevron(c, right - dp(18), y + dp(39), sub);
        addHit("homeQuick", quick);
        y += dp(90);

        setContentHeight(0, y + scrollY[0] - contentTop);
    }

    private void drawMix(Canvas c, float w) {
        float left = contentLeft(w), right = contentRight(w);
        float y = contentTop + dp(8) - scrollY[1];

        float globalH = dp(266);
        RectF global = rect(left, y, right, y + globalH);
        drawRoundRect(c, global, dp(22), card);
        drawText(c, "Global", left + dp(18), y + dp(31), dp(22), text, bold, Paint.Align.LEFT);

        RectF resetGlobal = rect(right - dp(128), y + dp(13), right - dp(14), y + dp(47));
        drawRoundRect(c, resetGlobal, dp(17), withAlpha(red, state.theme == 0 ? 20 : 44));
        drawText(c, "↻  Reset Global", resetGlobal.centerX(), resetGlobal.centerY() + dp(4),
                dp(11), red, medium, Paint.Align.CENTER);
        addHit("resetGlobal", resetGlobal);

        drawText(c, "Overall output and bass settings", left + dp(18), y + dp(52),
                dp(11), sub, normal, Paint.Align.LEFT);
        y += dp(66);
        drawMixSliderRow(c, left, right, y, "Master Volume", "VOL", 0xFF10B981, state.masterVolume,
                String.format(Locale.US, "%+.0f dB", state.masterVolume).replace("+", "+"), -70f, 6f, SL_MASTER, -1);
        y += dp(64);
        drawMixSliderRow(c, left, right, y, "Bass Volume", "BASS", pink, state.bassVolume,
                String.format(Locale.US, "%+.1f dB", state.bassVolume).replace("+", "+"), -70f, 6f, SL_BASS, -1);
        y += dp(64);
        drawMixSliderRow(c, left, right, y, "Bass Cutoff", "Hz", red, state.bassCutoff,
                String.format(Locale.US, "%.0f Hz", state.bassCutoff), 20f, 250f, SL_CUTOFF, -1);
        y += dp(78);

        float channelsH = dp(66 + DspState.CHANNELS * 64);
        RectF channels = rect(left, y, right, y + channelsH);
        drawRoundRect(c, channels, dp(22), card);
        drawText(c, "Channels", left + dp(18), y + dp(31), dp(22), text, bold, Paint.Align.LEFT);

        RectF resetChannels = rect(right - dp(142), y + dp(13), right - dp(14), y + dp(47));
        drawRoundRect(c, resetChannels, dp(17), withAlpha(pink, state.theme == 0 ? 20 : 44));
        drawText(c, "↻  Reset Channels", resetChannels.centerX(), resetChannels.centerY() + dp(4),
                dp(10.5f), pink, medium, Paint.Align.CENTER);
        addHit("resetChannels", resetChannels);

        drawText(c, "UI channel levels • hardware mapping not verified", left + dp(18), y + dp(52),
                dp(10.5f), sub, normal, Paint.Align.LEFT);
        y += dp(66);
        int[] colors = {
                0xFF10B981, // mint
                0xFF14B8A6, // teal
                0xFFEC4899, // pink
                0xFFF43F5E, // red / rose
                0xFF34D399, // seafoam
                0xFFDB2777, // deep pink
                0xFF059669  // emerald
        };
        for (int ch = 0; ch < DspState.CHANNELS; ch++) {
            if (ch > 0) drawLine(c, left + dp(56), y, right - dp(12), y, line, dp(1));
            drawCircle(c, left + dp(34), y + dp(32), dp(20), colors[ch]);
            drawText(c, Integer.toString(ch + 1), left + dp(34), y + dp(39), dp(17), 0xFFFFFFFF, bold, Paint.Align.CENTER);
            drawText(c, "Volume Ch" + (ch + 1), left + dp(72), y + dp(25), dp(15), text, medium, Paint.Align.LEFT);
            float trackX = left + dp(72), trackW = Math.max(dp(100), right - left - dp(190));
            float trackY = y + dp(43);
            drawSliderColored(c, trackX, trackY, trackW, state.channelVolume[ch], -12f, 12f,
                    SL_CHANNEL, ch, false, colors[ch]);
            RectF pill = rect(right - dp(88), y + dp(14), right - dp(14), y + dp(50));
            drawValuePill(c, pill, String.format(Locale.US, "%.0f dB", state.channelVolume[ch]));
            y += dp(64);
        }
        y += dp(16);
        setContentHeight(1, y + scrollY[1] - contentTop);
    }

    private void drawMixSliderRow(Canvas c, float left, float right, float y, String title, String iconText,
                                  int iconColor, float value, String valueText, float min, float max,
                                  int sliderType, int index) {
        drawCircle(c, left + dp(34), y + dp(31), dp(22), withAlpha(iconColor, state.theme == 0 ? 32 : 70));
        drawText(c, iconText, left + dp(34), y + dp(36), dp(iconText.length() > 2 ? 8 : 11), iconColor, bold, Paint.Align.CENTER);
        drawText(c, title, left + dp(72), y + dp(24), dp(15), text, medium, Paint.Align.LEFT);
        float trackX = left + dp(72), trackW = Math.max(dp(100), right - left - dp(190));
        drawSliderColored(c, trackX, y + dp(42), trackW, value, min, max, sliderType, index, false, iconColor);
        RectF pill = rect(right - dp(88), y + dp(12), right - dp(14), y + dp(50));
        drawValuePill(c, pill, valueText);
        drawLine(c, left + dp(16), y + dp(63), right - dp(16), y + dp(63), line, dp(1));
    }

    private void drawEq(Canvas c, float w) {
        float left = contentLeft(w), right = contentRight(w);
        float y = contentTop + dp(7) - scrollY[2];
        float gap = dp(7);
        float chipW = (right - left - gap * 6f) / 7f;
        for (int ch = 0; ch < 7; ch++) {
            RectF chip = rect(left + ch * (chipW + gap), y, left + ch * (chipW + gap) + chipW, y + dp(36));
            int channelColor = eqChannelColor(ch);
            boolean selected = ch == state.selectedChannel;
            drawRoundRect(c, chip, dp(18), selected ? channelColor
                    : withAlpha(channelColor, state.theme == 0 ? 24 : 48));
            drawText(c, "Ch" + (ch + 1), chip.centerX(), chip.centerY() + dp(5), dp(13),
                    selected ? 0xFFFFFFFF : channelColor, medium, Paint.Align.CENTER);
            addHit("chip" + ch, chip);
        }
        y += dp(52);

        RectF graphCard = rect(left, y, right, y + dp(326));
        drawRoundRect(c, graphCard, dp(22), card);
        int activeChannelColor = eqChannelColor(state.selectedChannel);
        drawRoundRect(c, rect(left + dp(18), y + dp(14), left + dp(23), y + dp(52)), dp(3), activeChannelColor);
        drawText(c, "Channel " + (state.selectedChannel + 1), left + dp(32), y + dp(30), dp(20), activeChannelColor, bold, Paint.Align.LEFT);
        drawText(c, channelPositionName(state.selectedChannel) + "  •  15-band EQ", left + dp(32), y + dp(51), dp(13), sub, normal, Paint.Align.LEFT);
        RectF reset = rect(right - dp(110), y + dp(14), right - dp(14), y + dp(48));
        drawRoundRect(c, reset, dp(17), withAlpha(red, state.theme == 0 ? 22 : 42));
        drawText(c, "↻  Reset EQ", reset.centerX(), reset.centerY() + dp(5), dp(12), red, medium, Paint.Align.CENTER);
        addHit("resetEq", reset);
        drawEqGraph(c, left + dp(42), y + dp(72), right - dp(18), y + dp(288));
        y += dp(342);

        RectF controlCard = rect(left, y, right, y + dp(284));
        drawRoundRect(c, controlCard, dp(22), card);
        int activeBandColor = eqBandColor(state.selectedBand);
        drawCircle(c, left + dp(34), y + dp(35), dp(21), activeBandColor);
        drawText(c, Integer.toString(state.selectedBand + 1), left + dp(34), y + dp(42), dp(20), 0xFFFFFFFF, bold, Paint.Align.CENTER);
        drawText(c, "Band " + (state.selectedBand + 1), left + dp(72), y + dp(29), dp(18), activeBandColor, bold, Paint.Align.LEFT);
        boolean gainLive = eqGainWritable[state.selectedChannel][state.selectedBand];
        boolean shapeLive = eqShapeWritable[state.selectedChannel][state.selectedBand];
        String eqMode = shapeLive ? "F/Q/Gain LIVE • SAFE PEAKING"
                : (gainLive ? "Gain LIVE • native filter • F/Q locked"
                : "Readback only • DSP bypass/unsafe row locked");
        drawText(c, eqMode, left + dp(72), y + dp(48), dp(11.5f), sub, normal, Paint.Align.LEFT);
        RectF prev = rect(right - dp(92), y + dp(14), right - dp(55), y + dp(51));
        RectF next = rect(right - dp(47), y + dp(14), right - dp(10), y + dp(51));
        drawRoundRect(c, prev, dp(18), cardAlt);
        drawRoundRect(c, next, dp(18), cardAlt);
        drawChevronLeft(c, prev.centerX(), prev.centerY(), text);
        drawChevron(c, next.centerX(), next.centerY(), text);
        addHit("bandPrev", prev);
        addHit("bandNext", next);

        int ch = state.selectedChannel, b = state.selectedBand;
        float rowY = y + dp(72);
        drawEqSliderRow(c, left, right, rowY, "Frequency", "F", DspState.formatHz(state.eqFreq[ch][b]),
                state.eqFreq[ch][b], 20f, 20000f, SL_EQ_FREQ, true, "20 Hz", "20 kHz", 0xFF138CF5);
        rowY += dp(68);
        drawEqSliderRow(c, left, right, rowY, "Q (Quality Factor)", "Q", String.format(Locale.US, "%.1f", state.eqQ[ch][b]),
                state.eqQ[ch][b], 0.1f, 10f, SL_EQ_Q, false, "0.1", "10.0", 0xFF16C4D7);
        rowY += dp(68);
        drawEqSliderRow(c, left, right, rowY, "Gain Band", "dB", String.format(Locale.US, "%+.1f dB", state.eqGain[ch][b]).replace("+", "+"),
                state.eqGain[ch][b], -12f, 12f, SL_EQ_GAIN, false, "-12 dB", "+12 dB", 0xFF34D399);
        y += dp(300);

        RectF presetCard = rect(left, y, right, y + dp(205));
        drawRoundRect(c, presetCard, dp(22), card);
        drawCircle(c, left + dp(35), y + dp(35), dp(22), withAlpha(pink, state.theme == 0 ? 28 : 58));
        drawText(c, "P", left + dp(35), y + dp(41), dp(17), pink, bold, Paint.Align.CENTER);
        drawText(c, "Presets", left + dp(72), y + dp(29), dp(18), text, bold, Paint.Align.LEFT);
        drawText(c, "Save, load and delete EQ presets", left + dp(72), y + dp(49), dp(12), sub, normal, Paint.Align.LEFT);

        RectF nameBox = rect(left + dp(18), y + dp(68), right - dp(148), y + dp(110));
        drawRoundRect(c, nameBox, dp(12), cardAlt);
        drawText(c, "New preset name…", nameBox.left + dp(12), nameBox.centerY() + dp(5), dp(13), sub, normal, Paint.Align.LEFT);
        addHit("presetName", nameBox);
        RectF save = rect(right - dp(136), y + dp(68), right - dp(18), y + dp(110));
        drawRoundRect(c, save, dp(13), pink);
        drawText(c, "Save Preset", save.centerX(), save.centerY() + dp(5), dp(13), 0xFFFFFFFF, medium, Paint.Align.CENTER);
        addHit("savePreset", save);

        drawText(c, "Saved Presets", left + dp(18), y + dp(135), dp(12), sub, normal, Paint.Align.LEFT);
        RectF loadName = rect(left + dp(18), y + dp(145), right - dp(148), y + dp(187));
        drawRoundRect(c, loadName, dp(12), cardAlt);
        drawText(c, state.getDisplayPresetName(), loadName.left + dp(12), loadName.centerY() + dp(5), dp(13), text, normal, Paint.Align.LEFT);
        drawText(c, "▼", loadName.right - dp(14), loadName.centerY() + dp(4), dp(10), sub, medium, Paint.Align.CENTER);
        addHit("pickPreset", loadName);

        float actionLeft = right - dp(136);
        float actionGap = dp(6);
        float actionW = (dp(118) - actionGap) / 2f;
        RectF load = rect(actionLeft, y + dp(145), actionLeft + actionW, y + dp(187));
        drawRoundRect(c, load, dp(12), cardAlt);
        drawText(c, "Load", load.centerX(), load.centerY() + dp(5), dp(12), text, medium, Paint.Align.CENTER);
        addHit("loadPreset", load);
        RectF delete = rect(load.right + actionGap, y + dp(145), right - dp(18), y + dp(187));
        drawRoundRect(c, delete, dp(12), withAlpha(red, state.theme == 0 ? 24 : 45));
        drawText(c, "Delete", delete.centerX(), delete.centerY() + dp(5), dp(11), red, medium, Paint.Align.CENTER);
        addHit("deletePreset", delete);
        y += dp(221);

        setContentHeight(2, y + scrollY[2] - contentTop);
    }

    private void drawEqSliderRow(Canvas c, float left, float right, float y, String title, String icon,
                                 String valueText, float value, float min, float max, int type,
                                 boolean logScale, String minLabel, String maxLabel, int rowColor) {
        drawCircle(c, left + dp(32), y + dp(26), dp(18), withAlpha(rowColor, state.theme == 0 ? 28 : 58));
        drawText(c, icon, left + dp(32), y + dp(31), dp(icon.length() > 1 ? 9 : 14), rowColor, bold, Paint.Align.CENTER);
        drawText(c, title, left + dp(59), y + dp(19), dp(13), text, medium, Paint.Align.LEFT);
        RectF pill = rect(right - dp(92), y + dp(3), right - dp(17), y + dp(31));
        drawRoundRect(c, pill, dp(10), withAlpha(rowColor, state.theme == 0 ? 22 : 44));
        drawText(c, valueText, pill.centerX(), pill.centerY() + dp(5), dp(12), rowColor, medium, Paint.Align.CENTER);
        float tx = left + dp(58), tw = right - tx - dp(18);
        drawSliderColored(c, tx, y + dp(40), tw, value, min, max, type, state.selectedBand, logScale, rowColor);
        drawText(c, minLabel, tx, y + dp(60), dp(10), sub, normal, Paint.Align.LEFT);
        drawText(c, maxLabel, tx + tw, y + dp(60), dp(10), sub, normal, Paint.Align.RIGHT);
    }

    private void drawEqGraph(Canvas c, float x1, float y1, float x2, float y2) {
        float plotTop = y1 + dp(4), plotBottom = y2 - dp(18);
        float plotLeft = x1, plotRight = x2;
        int ch = state.selectedChannel;

        int[] dbs = {12, 6, 0, -6, -12};
        for (int db : dbs) {
            float yy = map(db, 12, -12, plotTop, plotBottom);
            drawLine(c, plotLeft, yy, plotRight, yy, line, dp(0.8f));
            drawText(c, (db > 0 ? "+" : "") + db, plotLeft - dp(12), yy + dp(4), dp(9), sub, normal, Paint.Align.RIGHT);
        }
        float[] ticks = {20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000};
        for (float f : ticks) {
            float xx = freqToX(f, plotLeft, plotRight);
            drawLine(c, xx, plotTop, xx, plotBottom, line, dp(0.6f));
            String label = f >= 1000 ? ((int)(f / 1000)) + "K" : Integer.toString((int)f);
            drawText(c, label, xx, plotBottom + dp(15), dp(9), sub, normal, Paint.Align.CENTER);
        }

        int b = state.selectedBand;
        int channelColor = eqChannelColor(ch);
        int selectedBandColor = eqBandColor(b);
        float selectedX = freqToX(state.eqFreq[ch][b], plotLeft, plotRight);
        RectF hi = rect(selectedX - dp(12), plotTop, selectedX + dp(12), plotBottom);
        p.setColor(withAlpha(selectedBandColor, state.theme == 0 ? 24 : 42));
        c.drawRect(hi, p);
        float zeroY = map(0, 12, -12, plotTop, plotBottom);
        drawLine(c, plotLeft, zeroY, plotRight, zeroY, withAlpha(channelColor, state.theme == 0 ? 80 : 120), dp(1.1f));

        ensureGraphCache(ch);
        path.reset();
        for (int i = 0; i < GRAPH_SAMPLES; i++) {
            float t = i / (float) (GRAPH_SAMPLES - 1);
            float xx = plotLeft + (plotRight - plotLeft) * t;
            float yy = map(graphResponses[i], 12, -12, plotTop, plotBottom);
            if (i == 0) path.moveTo(xx, yy); else path.lineTo(xx, yy);
        }
        stroke.setColor(channelColor);
        stroke.setStrokeWidth(dp(2.0f));
        stroke.setStyle(Paint.Style.STROKE);
        c.drawPath(path, stroke);

        for (int band = 0; band < DspState.BANDS; band++) {
            float f = state.eqFreq[ch][band];
            float resp = eqResponsePrepared(f);
            float xx = freqToX(f, plotLeft, plotRight);
            float yy = map(resp, 12, -12, plotTop, plotBottom);
            int bandColor = eqBandColor(band);
            if (band == b) {
                drawCircle(c, xx, yy, dp(9), withAlpha(bandColor, 90));
                drawCircle(c, xx, yy, dp(6.2f), bandColor);
                stroke.setColor(state.theme == 0 ? 0xFFFFFFFF : text);
                stroke.setStrokeWidth(dp(1.5f));
                c.drawCircle(xx, yy, dp(7.2f), stroke);
            } else {
                drawCircle(c, xx, yy, dp(4.3f), bandColor);
                stroke.setColor(card);
                stroke.setStrokeWidth(dp(1.2f));
                c.drawCircle(xx, yy, dp(4.8f), stroke);
            }
        }
        drawText(c, "(dB)", plotLeft - dp(12), plotBottom + dp(16), dp(9), sub, normal, Paint.Align.RIGHT);
        drawText(c, "(Hz)", plotRight, plotBottom + dp(31), dp(9), sub, normal, Paint.Align.RIGHT);
    }

    private long graphSignature(int ch) {
        long h = 0xcbf29ce484222325L;
        for (int b = 0; b < DspState.BANDS; b++) {
            h ^= Float.floatToIntBits(state.eqFreq[ch][b]); h *= 0x100000001b3L;
            h ^= Float.floatToIntBits(state.eqQ[ch][b]); h *= 0x100000001b3L;
            h ^= Float.floatToIntBits(state.eqGain[ch][b]); h *= 0x100000001b3L;
        }
        return h;
    }

    private void ensureGraphCache(int ch) {
        long sig = graphSignature(ch);
        if (graphCacheChannel == ch && graphCacheSignature == sig) return;
        graphCacheChannel = ch;
        graphCacheSignature = sig;

        for (int b = 0; b < DspState.BANDS; b++) {
            double fc = Math.max(20.0, state.eqFreq[ch][b]);
            double q = Math.max(0.1, state.eqQ[ch][b]);
            graphBandLogFc[b] = Math.log(fc);
            graphBandInvWidth[b] = 1.0 / (0.30 / Math.sqrt(q));
            graphBandGain[b] = state.eqGain[ch][b];
        }

        final double log20 = Math.log(20.0);
        final double logRatio = Math.log(1000.0);
        for (int i = 0; i < GRAPH_SAMPLES; i++) {
            double t = i / (double) (GRAPH_SAMPLES - 1);
            graphResponses[i] = eqResponsePreparedLog(log20 + t * logRatio);
        }
    }

    private float eqResponsePrepared(float frequency) {
        return eqResponsePreparedLog(Math.log(Math.max(20.0, frequency)));
    }

    private float eqResponsePreparedLog(double logF) {
        double sum = 0.0;
        for (int b = 0; b < DspState.BANDS; b++) {
            double d = (logF - graphBandLogFc[b]) * graphBandInvWidth[b];
            sum += graphBandGain[b] * Math.exp(-0.5 * d * d);
        }
        return clamp((float) sum, -12f, 12f);
    }

    private void drawBottomNav(Canvas c, float w, float h) {
        float left = contentLeft(w), right = contentRight(w);
        float safeBottom = h - systemInsetBottomPx;
        float top = safeBottom - dp(76), bottom = safeBottom - dp(8);
        RectF panel = rect(left, top, right, bottom);
        drawRoundRect(c, panel, dp(22), card);
        float itemW = panel.width() / 3f;
        String[] labels = {"Home", "Mix", "Eq"};
        for (int i = 0; i < 3; i++) {
            float l = panel.left + i * itemW;
            RectF item = rect(l + dp(5), top + dp(5), l + itemW - dp(5), bottom - dp(5));
            boolean selected = state.page == i;
            int selectedColor = i == 0 ? pink : (i == 1 ? 0xFF10B981 : red);
            int selectedSoft = i == 0
                    ? (state.theme == 0 ? 0xFFFFEDF5 : 0xFF3A1728)
                    : (i == 1
                    ? (state.theme == 0 ? 0xFFE7FAF4 : 0xFF0E3028)
                    : (state.theme == 0 ? 0xFFFFEEF1 : 0xFF3A1820));
            if (selected) drawRoundRect(c, item, dp(18), selectedSoft);
            float cx = item.centerX(), iconY = top + dp(24);
            if (i == 0) drawHomeIcon(c, cx, iconY, selected ? selectedColor : sub);
            else if (i == 1) drawMixIcon(c, cx, iconY, selected ? selectedColor : sub);
            else drawEqBarsIcon(c, cx, iconY, selected ? selectedColor : sub);
            drawText(c, labels[i], cx, bottom - dp(10), dp(13), selected ? selectedColor : sub,
                    selected ? medium : normal, Paint.Align.CENTER);
            addHit("nav" + i, item);
        }
    }

    private void drawSlider(Canvas c, float x, float y, float width, float value, float min, float max,
                            int type, int index, boolean logScale) {
        float t;
        if (logScale) {
            t = (float) ((Math.log(value) - Math.log(min)) / (Math.log(max) - Math.log(min)));
        } else {
            t = (value - min) / (max - min);
        }
        t = clamp(t, 0f, 1f);
        RectF track = rect(x, y - dp(2.5f), x + width, y + dp(2.5f));
        drawRoundRect(c, track, dp(3), state.theme == 0 ? 0xFFDCE4EF : line);
        RectF fill = rect(x, y - dp(2.5f), x + width * t, y + dp(2.5f));
        drawRoundRect(c, fill, dp(3), accent);
        float knobX = x + width * t;
        drawCircle(c, knobX, y, dp(9), state.theme == 0 ? 0xFFFFFFFF : 0xFFEAF2FA);
        stroke.setColor(state.theme == 0 ? 0xFFCBD5E2 : 0xFF53657E);
        stroke.setStrokeWidth(dp(0.7f));
        c.drawCircle(knobX, y, dp(9), stroke);
        if (collectTouchTargets) {
            sliders.add(new SliderHit(type, index, new RectF(x - dp(10), y - dp(18), x + width + dp(10), y + dp(18)),
                    x, x + width, min, max, logScale));
        }
    }

    private void drawSliderColored(Canvas c, float x, float y, float width, float value, float min, float max,
                                   int type, int index, boolean logScale, int fillColor) {
        float t;
        if (logScale) {
            t = (float) ((Math.log(value) - Math.log(min)) / (Math.log(max) - Math.log(min)));
        } else {
            t = (value - min) / (max - min);
        }
        t = clamp(t, 0f, 1f);
        RectF track = rect(x, y - dp(2.5f), x + width, y + dp(2.5f));
        drawRoundRect(c, track, dp(3), state.theme == 0 ? 0xFFDCE4EF : line);
        RectF fill = rect(x, y - dp(2.5f), x + width * t, y + dp(2.5f));
        drawRoundRect(c, fill, dp(3), fillColor);
        float knobX = x + width * t;
        drawCircle(c, knobX, y, dp(10.5f), withAlpha(fillColor, state.theme == 0 ? 34 : 58));
        drawCircle(c, knobX, y, dp(8.5f), state.theme == 0 ? 0xFFFFFFFF : 0xFFEAF2FA);
        stroke.setColor(fillColor);
        stroke.setStrokeWidth(dp(1.3f));
        c.drawCircle(knobX, y, dp(8.5f), stroke);
        if (collectTouchTargets) {
            sliders.add(new SliderHit(type, index, new RectF(x - dp(10), y - dp(18), x + width + dp(10), y + dp(18)),
                    x, x + width, min, max, logScale));
        }
    }

    private int eqChannelColor(int ch) {
        int[] colors = {
                0xFF138CF5, 0xFFEC4899, 0xFF14B8A6, 0xFFF43F5E,
                0xFF22C55E, 0xFFDB2777, 0xFF34D399
        };
        return colors[Math.max(0, Math.min(ch, colors.length - 1))];
    }

    private int eqBandColor(int band) {
        int[] colors = {
                0xFF0EA5E9, 0xFF06B6D4, 0xFF14B8A6, 0xFF10B981, 0xFF22C55E,
                0xFF34D399, 0xFFEC4899, 0xFFF43F5E, 0xFFFB7185, 0xFFDB2777,
                0xFF06B6D4, 0xFF14B8A6, 0xFF22C55E, 0xFFEC4899, 0xFFF43F5E
        };
        return colors[Math.max(0, Math.min(band, colors.length - 1))];
    }

    private void drawValuePill(Canvas c, RectF r, String value) {
        drawRoundRect(c, r, dp(10), cardAlt);
        drawText(c, value, r.centerX(), r.centerY() + dp(5), dp(12), text, medium, Paint.Align.CENTER);
    }

    private void drawCircleButton(Canvas c, float cx, float cy, float r) {
        drawCircle(c, cx, cy, r, cardAlt);
    }

    private void drawSearchIcon(Canvas c, float cx, float cy) {
        stroke.setColor(text);
        stroke.setStrokeWidth(dp(2));
        stroke.setStyle(Paint.Style.STROKE);
        c.drawCircle(cx - dp(3), cy - dp(3), dp(7), stroke);
        c.drawLine(cx + dp(2), cy + dp(2), cx + dp(8), cy + dp(8), stroke);
    }

    private void drawOverflowIcon(Canvas c, float cx, float cy) {
        drawCircle(c, cx, cy - dp(7), dp(1.7f), text);
        drawCircle(c, cx, cy, dp(1.7f), text);
        drawCircle(c, cx, cy + dp(7), dp(1.7f), text);
    }

    private void drawMiniHomeIcon(Canvas c, int type, float cx, float cy, int color) {
        stroke.setColor(color);
        stroke.setStrokeWidth(dp(1.8f));
        stroke.setStyle(Paint.Style.STROKE);
        if (type == 0) {
            path.reset();
            path.moveTo(cx, cy - dp(12)); path.lineTo(cx, cy + dp(12));
            path.moveTo(cx, cy - dp(12)); path.lineTo(cx + dp(8), cy - dp(4)); path.lineTo(cx - dp(7), cy + dp(4)); path.lineTo(cx + dp(8), cy + dp(12));
            c.drawPath(path, stroke);
        } else if (type == 1) {
            RectF chip = rect(cx - dp(8), cy - dp(8), cx + dp(8), cy + dp(8));
            c.drawRoundRect(chip, dp(2), dp(2), stroke);
            for (int i = -1; i <= 1; i++) {
                c.drawLine(cx - dp(12), cy + i * dp(6), cx - dp(8), cy + i * dp(6), stroke);
                c.drawLine(cx + dp(8), cy + i * dp(6), cx + dp(12), cy + i * dp(6), stroke);
            }
        } else if (type == 2) {
            for (int i = -2; i <= 2; i++) {
                float hh = dp(5 + (2 - Math.abs(i)) * 3);
                c.drawLine(cx + i * dp(5), cy - hh, cx + i * dp(5), cy + hh, stroke);
            }
        } else if (type == 3) {
            path.reset();
            path.moveTo(cx - dp(9), cy - dp(4)); path.lineTo(cx - dp(4), cy - dp(4));
            path.lineTo(cx + dp(3), cy - dp(10)); path.lineTo(cx + dp(3), cy + dp(10));
            path.lineTo(cx - dp(4), cy + dp(4)); path.lineTo(cx - dp(9), cy + dp(4)); path.close();
            c.drawPath(path, stroke);
        } else if (type == 4) {
            RectF doc = rect(cx - dp(8), cy - dp(10), cx + dp(8), cy + dp(10));
            c.drawRoundRect(doc, dp(2), dp(2), stroke);
            c.drawLine(cx - dp(4), cy - dp(4), cx + dp(4), cy - dp(4), stroke);
            c.drawLine(cx - dp(4), cy + dp(1), cx + dp(4), cy + dp(1), stroke);
            c.drawLine(cx - dp(4), cy + dp(6), cx + dp(1), cy + dp(6), stroke);
        } else {
            c.drawCircle(cx, cy, dp(8), stroke);
            c.drawCircle(cx, cy, dp(3), stroke);
            for (int i = 0; i < 8; i++) {
                double a = i * Math.PI / 4.0;
                float x1 = cx + (float)Math.cos(a) * dp(10);
                float y1 = cy + (float)Math.sin(a) * dp(10);
                float x2 = cx + (float)Math.cos(a) * dp(13);
                float y2 = cy + (float)Math.sin(a) * dp(13);
                c.drawLine(x1, y1, x2, y2, stroke);
            }
        }
    }

    private void drawHomeIcon(Canvas c, float cx, float cy, int color) {
        p.setColor(color);
        path.reset();
        path.moveTo(cx - dp(10), cy);
        path.lineTo(cx, cy - dp(9));
        path.lineTo(cx + dp(10), cy);
        path.lineTo(cx + dp(8), cy + dp(10));
        path.lineTo(cx + dp(2), cy + dp(10));
        path.lineTo(cx + dp(2), cy + dp(3));
        path.lineTo(cx - dp(2), cy + dp(3));
        path.lineTo(cx - dp(2), cy + dp(10));
        path.lineTo(cx - dp(8), cy + dp(10));
        path.close();
        c.drawPath(path, p);
    }

    private void drawMixIcon(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color);
        stroke.setStrokeWidth(dp(2));
        for (int i = -1; i <= 1; i++) {
            float x = cx + i * dp(8);
            c.drawLine(x, cy - dp(12), x, cy + dp(12), stroke);
            float ky = cy + (i == -1 ? -dp(3) : i == 0 ? dp(5) : -dp(6));
            drawCircle(c, x, ky, dp(3), color);
        }
    }

    private void drawEqBarsIcon(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color);
        stroke.setStrokeWidth(dp(2.4f));
        stroke.setStrokeCap(Paint.Cap.ROUND);
        float[] hs = {dp(6), dp(13), dp(9)};
        for (int i = -1; i <= 1; i++) {
            float x = cx + i * dp(8);
            float h = hs[i + 1];
            c.drawLine(x, cy - h, x, cy + h, stroke);
        }
    }

    private void drawCheck(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color);
        stroke.setStrokeWidth(dp(3.2f));
        stroke.setStrokeCap(Paint.Cap.ROUND);
        path.reset();
        path.moveTo(cx - dp(9), cy);
        path.lineTo(cx - dp(2), cy + dp(7));
        path.lineTo(cx + dp(11), cy - dp(8));
        c.drawPath(path, stroke);
    }

    private void drawChevron(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color);
        stroke.setStrokeWidth(dp(1.8f));
        stroke.setStrokeCap(Paint.Cap.ROUND);
        c.drawLine(cx - dp(3), cy - dp(6), cx + dp(3), cy, stroke);
        c.drawLine(cx + dp(3), cy, cx - dp(3), cy + dp(6), stroke);
    }

    private void drawChevronLeft(Canvas c, float cx, float cy, int color) {
        stroke.setColor(color);
        stroke.setStrokeWidth(dp(1.8f));
        stroke.setStrokeCap(Paint.Cap.ROUND);
        c.drawLine(cx + dp(3), cy - dp(6), cx - dp(3), cy, stroke);
        c.drawLine(cx - dp(3), cy, cx + dp(3), cy + dp(6), stroke);
    }

    private String channelPositionName(int ch) {
        String[] names = {"Front Left", "Front Right", "Rear Left", "Rear Right", "Center", "Subwoofer", "Aux"};
        return names[Math.max(0, Math.min(ch, names.length - 1))];
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        final float x = e.getX();
        final float y = e.getY();
        final int action = e.getActionMasked();

        if (themePickerOpen || presetPickerOpen || deletePresetOpen) {
            // V23: every modal uses the same tiny in-view gesture path. There is
            // no WindowManager hand-off, VelocityTracker or hidden slider lookup.
            if (action == MotionEvent.ACTION_DOWN) {
                downX = x;
                downY = y;
                return true;
            }
            if (action == MotionEvent.ACTION_UP) {
                if (distance(downX, downY, x, y) <= dp(14)) {
                    Hit h = findHit(x, y);
                    if (h != null) {
                        if (themePickerOpen) handleThemeOverlayHit(h.id);
                        else if (presetPickerOpen) handlePresetPickerOverlayHit(h.id);
                        else handleDeletePresetOverlayHit(h.id);
                    }
                }
                return true;
            }
            return true;
        }

        if (action == MotionEvent.ACTION_DOWN) {
            stoppedFlingOnDown = !scroller.isFinished();
            if (stoppedFlingOnDown) {
                scroller.abortAnimation();
                flingPage = -1;
                requestFrame();
            }
            recycleVelocityTracker();
            velocityTracker = VelocityTracker.obtain();
        }
        if (velocityTracker != null) velocityTracker.addMovement(e);

        switch (action) {
            case MotionEvent.ACTION_DOWN:
                downX = x;
                downY = y;
                scrolling = false;
                navTouch = y >= navTop;
                activeSlider = null;
                pendingSlider = null;
                startScroll = scrollY[state.page];

                // Bottom navigation permanently owns its safe-area zone.
                if (navTouch) {
                    Hit nav = findNavHit(x, y);
                    if (nav != null) handleHit(nav.id);
                    recycleVelocityTracker();
                    return true;
                }

                // Do not claim a slider on DOWN. Wait until movement direction is
                // known. This lets a vertical swipe start naturally even when the
                // finger lands directly on one of the many slider rows.
                pendingSlider = stoppedFlingOnDown ? null : findSlider(x, y);
                return true;

            case MotionEvent.ACTION_MOVE: {
                if (navTouch) return true;
                final float dx = x - downX;
                final float dy = y - downY;
                final float absDx = Math.abs(dx);
                final float absDy = Math.abs(dy);

                if (!scrolling && activeSlider == null && pendingSlider != null) {
                    if (absDy > touchSlop && absDy > absDx * 1.10f) {
                        // Vertical intent wins: turn this gesture into page scroll.
                        pendingSlider = null;
                        scrolling = true;
                        getParent().requestDisallowInterceptTouchEvent(true);
                    } else if (absDx > touchSlop && absDx >= absDy) {
                        // Horizontal intent wins: now and only now own the slider.
                        activeSlider = pendingSlider;
                        pendingSlider = null;
                        applySlider(activeSlider, x);
                        getParent().requestDisallowInterceptTouchEvent(true);
                        return true;
                    } else {
                        return true;
                    }
                }

                if (activeSlider != null) {
                    applySlider(activeSlider, x);
                    return true;
                }

                if (!scrolling && y >= contentTop && downY >= contentTop
                        && downY < navTop && absDy > touchSlop) {
                    scrolling = true;
                    pendingSlider = null;
                    getParent().requestDisallowInterceptTouchEvent(true);
                }

                if (scrolling) {
                    float nextScroll = clamp(startScroll - dy, 0f, maxScroll[state.page]);
                    if (Math.abs(nextScroll - scrollY[state.page]) >= 0.15f) {
                        scrollY[state.page] = nextScroll;
                        requestFrame();
                    }
                }
                return true;
            }

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                if (navTouch) {
                    navTouch = false;
                    activeSlider = null;
                    pendingSlider = null;
                    scrolling = false;
                    recycleVelocityTracker();
                    return true;
                }

                if (activeSlider != null) {
                    if (action == MotionEvent.ACTION_UP) applySlider(activeSlider, x);
                    activeSlider = null;
                    pendingSlider = null;
                    getParent().requestDisallowInterceptTouchEvent(false);
                    recycleVelocityTracker();
                    return true;
                }

                // A clean tap on a slider still jumps the thumb to that location.
                if (pendingSlider != null && action == MotionEvent.ACTION_UP
                        && distance(downX, downY, x, y) <= touchSlop) {
                    applySlider(pendingSlider, x);
                    pendingSlider = null;
                    recycleVelocityTracker();
                    return true;
                }
                pendingSlider = null;

                if (scrolling) {
                    if (action == MotionEvent.ACTION_UP && velocityTracker != null) {
                        velocityTracker.computeCurrentVelocity(1000, maximumFlingVelocity);
                        float vy = velocityTracker.getYVelocity();
                        if (Math.abs(vy) >= minimumFlingVelocity && maxScroll[state.page] > 0f) {
                            flingPage = state.page;
                            scroller.fling(0, Math.round(scrollY[flingPage]),
                                    0, Math.round(-vy),
                                    0, 0, 0, Math.round(maxScroll[flingPage]));
                            requestFrame();
                        }
                    }
                    scrolling = false;
                    getParent().requestDisallowInterceptTouchEvent(false);
                    requestFrame(); // rebuild hit targets at the settled/current position
                    recycleVelocityTracker();
                    return true;
                }

                if (action == MotionEvent.ACTION_UP && !stoppedFlingOnDown
                        && distance(downX, downY, x, y) < dp(14)) {
                    Hit h = findHit(x, y);
                    if (h != null) handleHit(h.id);
                }
                stoppedFlingOnDown = false;
                requestFrame();
                recycleVelocityTracker();
                return true;
            }

            default:
                return super.onTouchEvent(e);
        }
    }

    @Override
    public void computeScroll() {
        super.computeScroll();
        if (flingPage >= 0 && scroller.computeScrollOffset()) {
            scrollY[flingPage] = clamp(scroller.getCurrY(), 0f, maxScroll[flingPage]);
            requestFrame();
        } else if (flingPage >= 0) {
            flingPage = -1;
            requestFrame();
        }
    }

    private void recycleVelocityTracker() {
        if (velocityTracker != null) {
            velocityTracker.recycle();
            velocityTracker = null;
        }
    }

    private void handleHit(String id) {
        if (id.startsWith("nav")) {
            if (!scroller.isFinished()) scroller.abortAnimation();
            flingPage = -1;
            state.setPage(Integer.parseInt(id.substring(3)));
            requestFrame();
            return;
        }
        if (id.equals("search")) {
            if (ble != null) {
                ble.startScan();
                host.showMessage("Searching for DSP...");
            } else host.showMessage("Bluetooth is still initializing");
        } else if (id.equals("theme")) {
            // V21: open an in-view overlay instead of a separate Dialog window.
            themePickerOpen = true;
            if (!scroller.isFinished()) scroller.abortAnimation();
            flingPage = -1;
            requestFrame();
        } else if (id.equals("homeQuick")) {
            state.setPage(1);
            requestFrame();
        } else if (id.equals("homeSystem")) {
            if (ble != null && bleReady) {
                ble.requestDspRefresh();
                host.showMessage("Refreshing DSP values...");
            } else if (ble != null) {
                ble.startScan();
                host.showMessage(bleDiagnostic.isEmpty() ? bleStatus : bleDiagnostic);
            } else host.showMessage("Bluetooth is still initializing");
        } else if (id.startsWith("homeRow")) {
            int index = Integer.parseInt(id.substring(7));
            String[] msg = {bleStatus, bleDevice + (bleReady ? " • READY" : " • not ready"), "Audio input: AUX (Analog)",
                    bleReady ? "DSP transport connected" : "DSP transport not ready", "Preset sync status", "Version " + appVersionName() + " • Phase 2"};
            host.showMessage(msg[Math.max(0, Math.min(index, msg.length - 1))]);
        } else if (id.equals("resetGlobal")) {
            state.resetGlobal();
            sendVerifiedGlobal();
            host.showMessage(bleReady ? "Global reset sent to DSP" : "Global controls reset • DSP not connected");
            requestFrame();
        } else if (id.equals("resetChannels")) {
            state.resetChannels();
            host.showMessage("Channel levels reset locally • hardware mapping not verified");
            requestFrame();
        } else if (id.startsWith("chip")) {
            state.setSelectedChannel(Integer.parseInt(id.substring(4)));
            requestFrame();
        } else if (id.equals("resetEq")) {
            int resetCh = state.selectedChannel;
            // V38 keeps Reset local-only. F/Q is re-enabled only per strict safe PEQ row;
            // bulk multi-band reset remains locked after the V33-V36 reboot event.
            state.resetEqGainOnly(resetCh);
            host.showMessage("Channel " + (resetCh + 1) + " EQ reset locally • hardware reset SAFE LOCK");
            requestFrame();
        } else if (id.equals("bandPrev")) {
            state.setSelectedBand((state.selectedBand + DspState.BANDS - 1) % DspState.BANDS);
            requestFrame();
        } else if (id.equals("bandNext")) {
            state.setSelectedBand((state.selectedBand + 1) % DspState.BANDS);
            requestFrame();
        } else if (id.equals("presetName") || id.equals("savePreset")) {
            host.requestPresetName("");
        } else if (id.equals("pickPreset")) {
            if (state.hasPresets()) {
                presetPickerOpen = true;
                if (!scroller.isFinished()) scroller.abortAnimation();
                flingPage = -1;
                requestFrame();
            } else {
                host.showMessage("No saved presets");
            }
        } else if (id.equals("loadPreset")) {
            boolean ok = state.loadSelectedPreset();
            host.showMessage(ok ? "Loaded preset: " + state.getDisplayPresetName() : "No saved preset selected");
            requestFrame();
        } else if (id.equals("deletePreset")) {
            if (state.hasPresets()) {
                deletePresetOpen = true;
                if (!scroller.isFinished()) scroller.abortAnimation();
                flingPage = -1;
                requestFrame();
            } else host.showMessage("No saved presets to delete");
        }
    }

    private void handlePresetPickerOverlayHit(String id) {
        if (id.startsWith("presetOpt")) {
            int index;
            try {
                index = Integer.parseInt(id.substring("presetOpt".length()));
            } catch (Exception ignored) {
                return;
            }
            String[] names = state.getPresetNames();
            if (index >= 0 && index < names.length) {
                presetPickerOpen = false;
                // Loading is applied in memory immediately. DspState V23 avoids
                // scheduling a 300+ key persist on this interactive tap.
                state.loadPreset(names[index]);
                requestFrame();
            }
            return;
        }
        if (id.equals("presetCancel") || id.equals("presetBackdrop")) {
            presetPickerOpen = false;
            requestFrame();
        }
    }

    private void handleDeletePresetOverlayHit(String id) {
        if (id.equals("deleteConfirm")) {
            String name = state.getDisplayPresetName();
            deletePresetOpen = false;
            state.deletePreset(name);
            requestFrame();
            return;
        }
        if (id.equals("deleteCancel") || id.equals("deleteBackdrop")) {
            deletePresetOpen = false;
            requestFrame();
        }
    }

    private void handleThemeOverlayHit(String id) {
        if (id.startsWith("themeOpt")) {
            int index;
            try {
                index = Integer.parseInt(id.substring("themeOpt".length()));
            } catch (Exception ignored) {
                return;
            }
            index = Math.max(0, Math.min(index, 2));
            themePickerOpen = false;
            if (state.theme != index) {
                state.setTheme(index);
                requestFrame();
                final int chosen = index;
                // Split the system-bar appearance update from the Canvas theme
                // redraw by one vsync. Doing both plus Dialog dismissal in the same
                // frame was the visible hitch reported on the top-right theme menu.
                postOnAnimation(() -> host.onThemeChanged(chosen));
            } else {
                requestFrame();
            }
            return;
        }
        if (id.equals("themeCancel") || id.equals("themeBackdrop")) {
            themePickerOpen = false;
            requestFrame();
        }
    }

    private void applySlider(SliderHit s, float x) {
        float t = clamp((x - s.x1) / Math.max(1f, s.x2 - s.x1), 0f, 1f);
        float v;
        if (s.logScale) {
            v = (float) Math.exp(Math.log(s.min) + t * (Math.log(s.max) - Math.log(s.min)));
        } else {
            v = s.min + t * (s.max - s.min);
        }
        int ch = state.selectedChannel;
        int b = state.selectedBand;
        boolean changed = false;

        // Rounded values often remain identical across several high-frequency
        // MotionEvents. Skip redundant state writes and redraws in that case.
        if (s.type == SL_MASTER) {
            float next = roundTo(v, 0.5f);
            if (!sameValue(state.masterVolume, next)) {
                state.setMasterVolume(next); changed = true;
                sendVerifiedScalar(DspProtocol.ID_MASTER_VOLUME, state.masterVolume);
            }
        } else if (s.type == SL_BASS) {
            float next = roundTo(v, 0.1f);
            if (!sameValue(state.bassVolume, next)) {
                state.setBassVolume(next); changed = true;
                sendVerifiedScalar(DspProtocol.ID_BASS_VOLUME, state.bassVolume);
            }
        } else if (s.type == SL_CUTOFF) {
            float next = Math.round(v);
            if (!sameValue(state.bassCutoff, next)) {
                state.setBassCutoff(next); changed = true;
                sendVerifiedScalar(DspProtocol.ID_BASS_CUTOFF, state.bassCutoff);
            }
        } else if (s.type == SL_CHANNEL) {
            float next = roundTo(v, 0.5f);
            if (!sameValue(state.channelVolume[s.index], next)) { state.setChannelVolume(s.index, next); changed = true; }
        } else if (s.type == SL_EQ_FREQ) {
            float step = v < 1000f ? 1f : 10f;
            float next = roundTo(v, step);
            if (!sameValue(state.eqFreq[ch][b], next)) {
                state.setEqFreq(ch, b, next); changed = true;
                sendVerifiedEqShape(ch, b);
            }
        } else if (s.type == SL_EQ_Q) {
            float next = roundTo(v, 0.1f);
            if (!sameValue(state.eqQ[ch][b], next)) {
                state.setEqQ(ch, b, next); changed = true;
                sendVerifiedEqShape(ch, b);
            }
        } else if (s.type == SL_EQ_GAIN) {
            float next = roundTo(v, 0.1f);
            if (!sameValue(state.eqGain[ch][b], next)) {
                state.setEqGain(ch, b, next); changed = true;
                sendVerifiedEqGain(ch, b);
            }
        }
        if (changed) requestFrame();
    }

    private static boolean sameValue(float a, float b) {
        return Math.abs(a - b) < 0.0001f;
    }

    private SliderHit findSlider(float x, float y) {
        // Only the visibly clipped content viewport may own slider gestures.
        // Hidden EQ sliders below navTop must not remain touchable underneath
        // the bottom navigation.
        if (y < contentTop || y >= navTop - dp(4)) return null;
        for (int i = sliders.size() - 1; i >= 0; i--) {
            SliderHit s = sliders.get(i);
            if (s.rect.contains(x, y)) return s;
        }
        return null;
    }

    private Hit findNavHit(float x, float y) {
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (h.id.startsWith("nav") && h.rect.contains(x, y)) return h;
        }
        return null;
    }

    private Hit findHit(float x, float y) {
        // V24 touch-layer isolation. Content is visually clipped between
        // contentTop and navTop, but its hit rectangles are generated from the
        // scrolled layout coordinates. When the EQ page is scrolled, an
        // off-screen channel chip can therefore geometrically overlap the fixed
        // header even though it is not visible. Previously findHit() walked the
        // newest hits first, so that hidden chip could steal a tap intended for
        // Search or the three-dot Theme button and change the selected channel.
        //
        // Modal overlays intentionally own the whole screen, so they bypass the
        // fixed header/content/nav routing below.
        if (themePickerOpen || presetPickerOpen || deletePresetOpen) {
            for (int i = hits.size() - 1; i >= 0; i--) {
                Hit h = hits.get(i);
                if (h.rect.contains(x, y)) return h;
            }
            return null;
        }

        // Fixed header owns everything above the clipped scrolling viewport.
        // Only its two explicit controls may receive a tap in this zone.
        if (y < contentTop) {
            for (int i = hits.size() - 1; i >= 0; i--) {
                Hit h = hits.get(i);
                if ((h.id.equals("search") || h.id.equals("theme"))
                        && h.rect.contains(x, y)) return h;
            }
            return null;
        }

        // Bottom navigation owns its own fixed zone.
        if (y >= navTop - dp(4)) return findNavHit(x, y);

        // Inside the visible content viewport, ignore fixed header/nav targets
        // even if their rectangles ever overlap after a layout change.
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (h.id.equals("search") || h.id.equals("theme") || h.id.startsWith("nav")) continue;
            if (h.rect.contains(x, y)) return h;
        }
        return null;
    }

    private void addHit(String id, RectF r) {
        if (collectTouchTargets) hits.add(new Hit(id, new RectF(r)));
    }

    private void setContentHeight(int page, float contentHeight) {
        float visible = Math.max(dp(100), navTop - contentTop - dp(8));
        maxScroll[page] = Math.max(0f, contentHeight - visible);
        scrollY[page] = clamp(scrollY[page], 0f, maxScroll[page]);
    }

    private float contentLeft(float w) {
        float safeLeft = systemInsetLeftPx;
        float safeRight = Math.max(safeLeft, w - systemInsetRightPx);
        float safeWidth = Math.max(0f, safeRight - safeLeft);
        float maxWidth = dp(760);
        float usable = Math.min(Math.max(0f, safeWidth - dp(24)), maxWidth);
        return safeLeft + (safeWidth - usable) / 2f;
    }

    private float contentRight(float w) {
        float safeRight = Math.max(systemInsetLeftPx, w - systemInsetRightPx);
        float left = contentLeft(w);
        return safeRight - (left - systemInsetLeftPx);
    }

    private float freqToX(float freq, float x1, float x2) {
        float t = (float) ((Math.log(clamp(freq, 20f, 20000f)) - Math.log(20f)) / (Math.log(20000f) - Math.log(20f)));
        return x1 + (x2 - x1) * t;
    }

    private void drawRoundRect(Canvas c, RectF r, float radius, int color) {
        p.setColor(color);
        p.setStyle(Paint.Style.FILL);
        c.drawRoundRect(r, radius, radius, p);
    }

    private void drawCircle(Canvas c, float cx, float cy, float radius, int color) {
        p.setColor(color);
        p.setStyle(Paint.Style.FILL);
        c.drawCircle(cx, cy, radius, p);
    }

    private void drawLine(Canvas c, float x1, float y1, float x2, float y2, int color, float width) {
        stroke.setColor(color);
        stroke.setStrokeWidth(width);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        c.drawLine(x1, y1, x2, y2, stroke);
    }

    private void drawText(Canvas c, String s, float x, float baseline, float size, int color, Typeface tf, Paint.Align align) {
        p.setStyle(Paint.Style.FILL);
        p.setTypeface(tf);
        p.setTextSize(size);
        p.setTextAlign(align);
        p.setColor(color);
        c.drawText(s, x, baseline, p);
    }

    private RectF rect(float left, float top, float right, float bottom) {
        int index = rectPoolIndex++;
        if (index >= rectPool.length) {
            // Safety fallback; normal screens use well under the pool capacity.
            return new RectF(left, top, right, bottom);
        }
        RectF r = rectPool[index];
        if (r == null) {
            r = new RectF();
            rectPool[index] = r;
        }
        r.set(left, top, right, bottom);
        return r;
    }

    private float dp(float v) {
        return v * density;
    }

    private static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    private static float map(float v, float srcMin, float srcMax, float dstMin, float dstMax) {
        float t = (v - srcMin) / (srcMax - srcMin);
        return dstMin + (dstMax - dstMin) * t;
    }

    private static int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | ((alpha & 0xFF) << 24);
    }

    private static float roundTo(float v, float step) {
        return Math.round(v / step) * step;
    }

    private static float distance(float x1, float y1, float x2, float y2) {
        float dx = x2 - x1, dy = y2 - y1;
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    private static final class Hit {
        final String id;
        final RectF rect;
        Hit(String id, RectF rect) { this.id = id; this.rect = rect; }
    }

    private static final class SliderHit {
        final int type;
        final int index;
        final RectF rect;
        final float x1, x2, min, max;
        final boolean logScale;
        SliderHit(int type, int index, RectF rect, float x1, float x2, float min, float max, boolean logScale) {
            this.type = type;
            this.index = index;
            this.rect = rect;
            this.x1 = x1;
            this.x2 = x2;
            this.min = min;
            this.max = max;
            this.logScale = logScale;
        }
    }
}
