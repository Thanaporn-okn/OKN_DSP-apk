# OKN DSP V35 — Phase 2 Smooth-Q real-time control

Base: **V34**. The accepted V29/V30 UI, V31 authenticated BLE session, V32 low-latency EQ lane, V33 Frequency/Q/Gain mapping, and V34 two-stage Reset EQ are retained.

## V35 change
Real-hardware video `32054.mp4` shows audible pumping/warble while sweeping **Q** on a type-12 PEAKING band at approximately 472 Hz with Gain around +12 dB. V35 changes only Q dragging: the newest finger target is retained, while hardware Q converges through bounded multiplicative/log-domain steps on the already proven 45 ms serialized EQ lane. This reduces abrupt biquad pole/coefficient jumps while still reaching the exact final Q target automatically after touch stops.

- Bands 2..15: Frequency + Q + Gain LIVE.
- Q: Smooth-Q de-zipper; no stale MotionEvent replay.
- Frequency/Gain: existing latest-value real-time behavior retained.
- Band 1: Gain LIVE only; native special-filter Frequency/Q remains locked.
- Reset EQ: V34 ordered flatten-first safety sequence retained and clears any active Q glide first.
- BLE/AES/Auth packet format and 45 ms EQ lane are unchanged.

## Still deliberately locked
- Volume Ch1-Ch7 hardware mapping.
- Band 1 generic Frequency/Q writes.
- Automatic permanent SaveParams.

versionName: **35.0.0**
versionCode: **1035**
Phase: **2 — authenticated real-time DSP control**
