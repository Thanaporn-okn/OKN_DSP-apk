# สัญญา API สำหรับ Heavy Market

แอปเรียก:

`GET {DATA_API_BASE}/feed?source=latest|groups|marketplace&q=คำค้น`

ตอบ JSON:

```json
{
  "items": [
    {
      "id": "abc123",
      "title": "ขายรถหกล้อดั้ม Hino",
      "description": "พร้อมใช้งาน เอกสารครบ",
      "price": 690000,
      "location": "ขอนแก่น",
      "category": "รถหกล้อ",
      "source": "groups",
      "groupName": "ตลาดซื้อขายรถบรรทุก",
      "imageUrl": "https://...",
      "postUrl": "https://www.facebook.com/...",
      "createdAt": 1789860000000
    }
  ]
}
```

## หมายเหตุ Facebook

- หน้า Page: ใช้ข้อมูลจาก API/สิทธิ์ที่ Meta อนุญาตสำหรับ Page ที่คุณมีสิทธิ์ หรือจากแหล่งข้อมูลที่ได้รับอนุญาตเท่านั้น
- Groups: Groups API ถูกยกเลิกแล้ว จึงไม่สามารถอ่านโพสต์จากทุกกลุ่มที่บัญชีเข้าร่วมผ่าน Graph API แบบเดิม
- Marketplace: อย่าใช้การจำลองผู้ใช้/ขโมย session/cookie เพื่อ scrape ข้อมูล ให้ต่อเฉพาะ API หรือ feed ที่ได้รับอนุญาต
- ทางเลือกที่ใช้ได้ในแอปนี้: ผู้ใช้กด Share โพสต์จาก Facebook มาที่ Heavy Market แล้วรายการจะถูกเก็บในหน้า “ล่าสุด” แบบ local

## ตั้งค่า GitHub

Repository > Settings > Secrets and variables > Actions > Variables > New repository variable

Name: `DATA_API_BASE`
Value: เช่น `https://api.example.com`

ไม่ต้องแก้ source code เมื่อย้าย server; เปลี่ยน variable นี้แล้วกด Run workflow ใหม่ได้เลย
