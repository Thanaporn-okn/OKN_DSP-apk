package com.okn.heavymarket;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.okn.heavymarket.data.ListingRepository;
import com.okn.heavymarket.data.LocalImportStore;
import com.okn.heavymarket.data.SaleClassifier;
import com.okn.heavymarket.model.Listing;
import com.okn.heavymarket.ui.Ui;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private ListingRepository repository;
    private LinearLayout root;
    private LinearLayout content;
    private TextView status;
    private EditText search;
    private ProgressBar progress;
    private String currentSource = "latest";
    private String categoryFilter = "ทั้งหมด";
    private String conditionFilter = "มือสองเด่น";
    private List<Listing> currentItems = new ArrayList<>();

    private final Runnable autoRefresh = new Runnable() {
        @Override public void run() {
            refresh(false);
            handler.postDelayed(this, 30_000);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        repository = new ListingRepository(this);
        handleShareIntent(getIntent());
        buildShell();
        selectPage("latest");
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleShareIntent(intent);
        selectPage("latest");
    }

    @Override protected void onResume() {
        super.onResume();
        handler.removeCallbacks(autoRefresh);
        handler.postDelayed(autoRefresh, 30_000);
    }

    @Override protected void onPause() {
        handler.removeCallbacks(autoRefresh);
        super.onPause();
    }

    private void handleShareIntent(Intent intent) {
        if (intent == null || !Intent.ACTION_SEND.equals(intent.getAction())) return;
        String text = intent.getStringExtra(Intent.EXTRA_TEXT);
        if (text != null && !text.trim().isEmpty()) {
            LocalImportStore.addSharedPost(this, text);
            Toast.makeText(this, "บันทึกโพสต์ที่แชร์เข้า Heavy Market แล้ว", Toast.LENGTH_LONG).show();
        }
    }

    private void buildShell() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(245, 247, 246));
        setContentView(root);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL);
        top.setBackgroundColor(Color.WHITE);
        Ui.pad(top, 16, 12, 16, 10);
        root.addView(top, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = Ui.text(this, "HEAVY MARKET", 22, true);
        title.setTextColor(Color.rgb(23, 107, 58));
        top.addView(title);
        TextView sub = Ui.text(this, "ตลาดสินค้ามือสอง • รถบรรทุก • แม็คโค • หกล้อ • ดั้ม • รถไถ", 12, false);
        sub.setTextColor(Color.DKGRAY);
        top.addView(sub);

        LinearLayout searchRow = new LinearLayout(this);
        searchRow.setGravity(Gravity.CENTER_VERTICAL);
        searchRow.setPadding(0, Ui.dp(this, 8), 0, 0);
        top.addView(searchRow);

        search = new EditText(this);
        search.setHint("ค้นหามือสอง เช่น รถดั้ม Hino ขอนแก่น");
        search.setSingleLine(true);
        LinearLayout.LayoutParams searchLp = new LinearLayout.LayoutParams(0, Ui.dp(this, 48), 1);
        searchRow.addView(search, searchLp);
        Button go = new Button(this);
        go.setText("ค้นหา");
        go.setOnClickListener(v -> refresh(true));
        searchRow.addView(go, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, Ui.dp(this, 48)));

        status = Ui.text(this, "", 11, false);
        status.setTextColor(Color.GRAY);
        status.setPadding(0, Ui.dp(this, 6), 0, 0);
        top.addView(status);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setIndeterminate(true);
        progress.setVisibility(View.GONE);
        top.addView(progress, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 3)));

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        ScrollView scroller = new ScrollView(this);
        scroller.addView(content, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroller, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        LinearLayout nav = new LinearLayout(this);
        nav.setBackgroundColor(Color.WHITE);
        nav.setGravity(Gravity.CENTER);
        root.addView(nav, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 62)));
        addNavButton(nav, "ล่าสุด", "latest");
        addNavButton(nav, "ในกลุ่ม", "groups");
        addNavButton(nav, "Marketplace", "marketplace");
    }

    private void addNavButton(LinearLayout nav, String label, String source) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setOnClickListener(v -> selectPage(source));
        nav.addView(b, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1));
    }

    private void selectPage(String source) {
        currentSource = source;
        categoryFilter = "ทั้งหมด";
        conditionFilter = "มือสองเด่น";
        content.removeAllViews();
        if ("marketplace".equals(source)) addMarketplaceMenus();
        addConditionFilters();
        addCategoryFilters();
        refresh(true);
    }

    private void addMarketplaceMenus() {
        TextView h = Ui.text(this, "Marketplace", 24, true);
        Ui.pad(h, 16, 16, 16, 4);
        content.addView(h);
        TextView p = Ui.text(this, "เมนูซื้อขายแบบรวมศูนย์ — ค้นหา หมวดหมู่ บันทึก และเปิดประกาศต้นทาง", 13, false);
        p.setTextColor(Color.GRAY);
        Ui.pad(p, 16, 0, 16, 8);
        content.addView(p);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Ui.pad(row, 12, 4, 12, 8);
        content.addView(row);
        addAction(row, "เลือกดูทั้งหมด", v -> { categoryFilter = "ทั้งหมด"; renderItems(); });
        addAction(row, "รถบรรทุก", v -> { categoryFilter = "รถบรรทุก"; renderItems(); });
        addAction(row, "เครื่องจักร", v -> { categoryFilter = "เครื่องจักร"; renderItems(); });

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        Ui.pad(row2, 12, 0, 12, 8);
        content.addView(row2);
        addAction(row2, "รถดั้ม", v -> { categoryFilter = "รถดั้ม"; renderItems(); });
        addAction(row2, "แม็คโค", v -> { categoryFilter = "แม็คโค"; renderItems(); });
        addAction(row2, "รถไถ", v -> { categoryFilter = "รถไถ"; renderItems(); });
    }

    private void addAction(LinearLayout row, String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setOnClickListener(listener);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Ui.dp(this, 52), 1);
        lp.setMargins(Ui.dp(this, 3), 0, Ui.dp(this, 3), 0);
        row.addView(b, lp);
    }

    private void addConditionFilters() {
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        Ui.pad(chips, 12, 8, 12, 0);
        hsv.addView(chips);
        String[] conditions = {"มือสองเด่น", "มือสองเท่านั้น", "ดูทั้งหมด"};
        for (String condition : conditions) {
            Button b = new Button(this);
            b.setText(condition);
            b.setAllCaps(false);
            b.setOnClickListener(v -> { conditionFilter = condition; renderItems(); });
            chips.addView(b, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, Ui.dp(this, 46)));
        }
        content.addView(hsv);
    }

    private void addCategoryFilters() {
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        Ui.pad(chips, 12, 8, 12, 8);
        hsv.addView(chips);
        String[] cats = {"ทั้งหมด", "รถบรรทุก", "หกล้อ", "รถดั้ม", "แม็คโค", "รถไถ", "หัวลาก", "อะไหล่", "อื่นๆ"};
        for (String cat : cats) {
            Button b = new Button(this);
            b.setText(cat);
            b.setAllCaps(false);
            b.setOnClickListener(v -> { categoryFilter = cat; renderItems(); });
            chips.addView(b, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, Ui.dp(this, 46)));
        }
        content.addView(hsv);
    }

    private void refresh(boolean showSpinner) {
        if (showSpinner) progress.setVisibility(View.VISIBLE);
        final String q = search.getText().toString();
        repository.load(currentSource, q, (items, message) -> runOnUiThread(() -> {
            progress.setVisibility(View.GONE);
            currentItems = items;
            status.setText(message + " • " + new SimpleDateFormat("HH:mm:ss", new Locale("th", "TH")).format(new Date()));
            renderItems();
        }));
    }

    private void renderItems() {
        // Keep the marketplace header and filter bars, rebuild only list by re-selecting shell structure.
        int keep = "marketplace".equals(currentSource) ? 6 : 2;
        while (content.getChildCount() > keep) content.removeViewAt(content.getChildCount() - 1);

        List<Listing> visible = new ArrayList<>();
        for (Listing i : currentItems) {
            if (!matchesCategory(i, categoryFilter)) continue;
            if ("มือสองเท่านั้น".equals(conditionFilter) && !SaleClassifier.isLikelyUsed(i)) continue;
            if ("มือสองเด่น".equals(conditionFilter) && SaleClassifier.isExplicitlyNew(i)) continue;
            visible.add(i);
        }
        visible.sort((a, b) -> {
            if (!"ดูทั้งหมด".equals(conditionFilter)) {
                int used = Integer.compare(SaleClassifier.usedPriority(b), SaleClassifier.usedPriority(a));
                if (used != 0) return used;
            }
            return Long.compare(b.createdAt, a.createdAt);
        });

        TextView count = Ui.text(this, visible.size() + " รายการ • " + conditionFilter, 13, true);
        Ui.pad(count, 16, 6, 16, 8);
        content.addView(count);

        if (visible.isEmpty()) {
            TextView empty = Ui.text(this, "ยังไม่มีรายการที่ตรงกับตัวกรอง", 15, false);
            empty.setGravity(Gravity.CENTER);
            Ui.pad(empty, 20, 60, 20, 60);
            content.addView(empty);
            return;
        }

        for (Listing item : visible) content.addView(card(item));
    }

    private boolean matchesCategory(Listing i, String filter) {
        if ("ทั้งหมด".equals(filter)) return true;
        String text = (i.category + " " + i.title + " " + i.description).toLowerCase();
        if ("เครื่องจักร".equals(filter)) return text.contains("แม็ค") || text.contains("รถขุด") || text.contains("เครื่องจักร") || text.contains("รถตัก");
        if ("รถบรรทุก".equals(filter)) return text.contains("บรรทุก") || text.contains("หกล้อ") || text.contains("หก ล้อ") || text.contains("สิบล้อ") || text.contains("ดั้ม") || text.contains("หัวลาก");
        return text.contains(filter.toLowerCase());
    }

    private View card(Listing item) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundColor(Color.WHITE);
        Ui.pad(card, 16, 14, 16, 14);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(Ui.dp(this, 12), Ui.dp(this, 5), Ui.dp(this, 12), Ui.dp(this, 5));
        card.setLayoutParams(lp);

        if (SaleClassifier.isLikelyUsed(item)) {
            TextView used = Ui.text(this, "มือสอง", 12, true);
            used.setTextColor(Color.rgb(23, 107, 58));
            card.addView(used);
        }
        TextView title = Ui.text(this, item.title, 18, true);
        card.addView(title);
        if (item.price > 0) {
            TextView price = Ui.text(this, NumberFormat.getIntegerInstance(new Locale("th", "TH")).format(item.price) + " บาท", 19, true);
            price.setTextColor(Color.rgb(23, 107, 58));
            card.addView(price);
        }
        String meta = join(" • ", item.category, item.location, item.groupName);
        if (!meta.isEmpty()) {
            TextView m = Ui.text(this, meta, 12, false);
            m.setTextColor(Color.GRAY);
            card.addView(m);
        }
        if (!item.description.isEmpty()) {
            TextView d = Ui.text(this, item.description, 14, false);
            d.setMaxLines(3);
            d.setPadding(0, Ui.dp(this, 6), 0, 0);
            card.addView(d);
        }
        TextView time = Ui.text(this, relativeTime(item.createdAt), 11, false);
        time.setTextColor(Color.GRAY);
        time.setPadding(0, Ui.dp(this, 8), 0, 0);
        card.addView(time);

        if (!item.postUrl.isEmpty()) {
            Button open = new Button(this);
            open.setText("เปิดโพสต์ต้นทาง");
            open.setAllCaps(false);
            open.setOnClickListener(v -> openUrl(item.postUrl));
            card.addView(open);
        }
        return card;
    }

    private void openUrl(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "ไม่พบแอปสำหรับเปิดลิงก์", Toast.LENGTH_SHORT).show();
        }
    }

    private String relativeTime(long when) {
        long seconds = Math.max(0, (System.currentTimeMillis() - when) / 1000);
        if (seconds < 60) return seconds + " วินาทีที่แล้ว";
        if (seconds < 3600) return (seconds / 60) + " นาทีที่แล้ว";
        if (seconds < 86400) return (seconds / 3600) + " ชม.ที่แล้ว";
        return (seconds / 86400) + " วันที่แล้ว";
    }

    private String join(String sep, String... values) {
        StringBuilder b = new StringBuilder();
        for (String value : values) {
            if (value == null || value.trim().isEmpty()) continue;
            if (b.length() > 0) b.append(sep);
            b.append(value.trim());
        }
        return b.toString();
    }
}
