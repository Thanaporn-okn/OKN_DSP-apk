package com.okn.heavymarket.model;

import org.json.JSONObject;

public class Listing {
    public final String id;
    public final String title;
    public final String description;
    public final long price;
    public final String location;
    public final String category;
    public final String source;
    public final String groupName;
    public final String imageUrl;
    public final String postUrl;
    public final long createdAt;

    public Listing(String id, String title, String description, long price, String location,
                   String category, String source, String groupName, String imageUrl,
                   String postUrl, long createdAt) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.price = price;
        this.location = location;
        this.category = category;
        this.source = source;
        this.groupName = groupName;
        this.imageUrl = imageUrl;
        this.postUrl = postUrl;
        this.createdAt = createdAt;
    }

    public static Listing fromJson(JSONObject o) {
        return new Listing(
                o.optString("id", String.valueOf(System.nanoTime())),
                o.optString("title", "ประกาศขาย"),
                o.optString("description", ""),
                o.optLong("price", 0),
                o.optString("location", ""),
                o.optString("category", "อื่นๆ"),
                o.optString("source", "latest"),
                o.optString("groupName", ""),
                o.optString("imageUrl", ""),
                o.optString("postUrl", ""),
                o.optLong("createdAt", System.currentTimeMillis())
        );
    }
}
