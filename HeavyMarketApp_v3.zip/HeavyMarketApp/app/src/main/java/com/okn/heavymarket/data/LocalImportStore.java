package com.okn.heavymarket.data;

import android.content.Context;
import android.content.SharedPreferences;
import com.okn.heavymarket.model.Listing;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public final class LocalImportStore {
    private static final String PREF = "heavy_market_imports";
    private static final String KEY = "items";

    private LocalImportStore() {}

    public static void addSharedPost(Context context, String sharedText) {
        if (sharedText == null || sharedText.trim().isEmpty()) return;
        try {
            SharedPreferences p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
            JSONArray old = new JSONArray(p.getString(KEY, "[]"));
            JSONArray next = new JSONArray();
            JSONObject o = new JSONObject();
            String url = extractUrl(sharedText);
            String title = sharedText.replace(url, "").trim();
            if (title.length() > 100) title = title.substring(0, 100) + "…";
            if (title.isEmpty()) title = "โพสต์ที่แชร์จาก Facebook";
            o.put("id", "shared-" + System.currentTimeMillis());
            o.put("title", title);
            o.put("description", sharedText);
            o.put("price", 0);
            o.put("location", "");
            o.put("category", "นำเข้า");
            o.put("source", "shared");
            o.put("groupName", "แชร์จาก Facebook");
            o.put("imageUrl", "");
            o.put("postUrl", url);
            o.put("createdAt", System.currentTimeMillis());
            next.put(o);
            for (int i = 0; i < old.length() && i < 99; i++) next.put(old.get(i));
            p.edit().putString(KEY, next.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    public static List<Listing> load(Context context) {
        List<Listing> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]"));
            for (int i = 0; i < a.length(); i++) out.add(Listing.fromJson(a.getJSONObject(i)));
        } catch (Exception ignored) {
        }
        return out;
    }

    private static String extractUrl(String text) {
        for (String part : text.split("\\s+")) {
            if (part.startsWith("https://") || part.startsWith("http://")) return part;
        }
        return "";
    }
}
