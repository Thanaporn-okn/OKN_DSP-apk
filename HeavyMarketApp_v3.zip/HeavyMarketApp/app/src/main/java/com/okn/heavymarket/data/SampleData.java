package com.okn.heavymarket.data;

import com.okn.heavymarket.model.Listing;
import java.util.ArrayList;
import java.util.List;

public final class SampleData {
    private SampleData() {}

    public static List<Listing> create(String source) {
        long now = System.currentTimeMillis();
        List<Listing> a = new ArrayList<>();
        if ("groups".equals(source)) {
            a.add(new Listing("g1", "ขายรถหกล้อดั้ม Hino มือสอง", "เจ้าของขายเอง พร้อมใช้งาน เอกสารครบ ราคา 690,000 บาท", 690000, "ขอนแก่น", "รถหกล้อ", "groups", "ตลาดซื้อขายรถบรรทุก", "", "", now - 60_000));
            a.add(new Listing("g2", "รถแม็คโค PC120 มือสอง พร้อมขาย", "ผ่านการใช้งาน เครื่องแน่น ช่วงล่างดี สนใจทัก", 890000, "อุดรธานี", "รถแม็คโค", "groups", "ซื้อขายเครื่องจักรหนัก", "", "", now - 180_000));
        } else if ("marketplace".equals(source)) {
            a.add(new Listing("m1", "รถไถ Kubota มือสอง พร้อมอุปกรณ์", "รถบ้าน ขาย 345,000 บาท", 345000, "มหาสารคาม", "รถไถ", "marketplace", "", "", "", now - 45_000));
            a.add(new Listing("m2", "สิบล้อดั้ม 2 เพลา มือสอง", "พร้อมทำงาน ราคา 1,250,000 บาท", 1250000, "นครราชสีมา", "รถดั้ม", "marketplace", "", "", "", now - 240_000));
        } else {
            a.add(new Listing("l1", "ขายรถดั้ม 6 ล้อ Isuzu มือสอง", "เจ้าของขายเอง สภาพพร้อมใช้งาน ราคา 780,000 บาท", 780000, "ขอนแก่น", "รถดั้ม", "latest", "เพจรถบรรทุกมือสอง", "", "", now - 20_000));
            a.add(new Listing("l2", "แม็คโค CAT 320 มือสอง", "ผ่านการใช้งาน ขายพร้อมใช้งาน 1,790,000 บาท", 1790000, "ชัยภูมิ", "รถแม็คโค", "latest", "เพจเครื่องจักรหนัก", "", "", now - 90_000));
            a.add(new Listing("l3", "รถไถมือสอง", "ราคา 298,000 บาท ติดต่อเจ้าของโดยตรง", 298000, "ร้อยเอ็ด", "รถไถ", "latest", "", "", "", now - 300_000));
        }
        return a;
    }
}
