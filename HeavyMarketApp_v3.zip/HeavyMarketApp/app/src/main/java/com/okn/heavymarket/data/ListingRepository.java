package com.okn.heavymarket.data;

import android.content.Context;
import com.okn.heavymarket.BuildConfig;
import com.okn.heavymarket.model.Listing;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ListingRepository {
    public interface Callback {
        void onResult(List<Listing> items, String status);
    }

    private final Context context;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    public ListingRepository(Context context) {
        this.context = context.getApplicationContext();
    }

    public void load(String source, String query, Callback callback) {
        executor.execute(() -> {
            List<Listing> items = new ArrayList<>();
            String status;
            try {
                if (BuildConfig.DATA_API_BASE == null || BuildConfig.DATA_API_BASE.trim().isEmpty()) {
                    items.addAll(SampleData.create(source));
                    status = "โหมดตัวอย่าง — ตั้งค่า DATA_API_BASE เพื่อรับข้อมูลจริง";
                } else {
                    items.addAll(fetchRemote(source, query));
                    status = "อัปเดตจากเซิร์ฟเวอร์แล้ว";
                }
            } catch (Exception e) {
                items.addAll(SampleData.create(source));
                status = "เชื่อมต่อข้อมูลไม่ได้ — แสดงข้อมูลตัวอย่าง";
            }

            if ("latest".equals(source)) {
                items.addAll(0, LocalImportStore.load(context));
            }

            List<Listing> filtered = new ArrayList<>();
            String q = query == null ? "" : query.trim().toLowerCase();
            for (Listing item : items) {
                if (!SaleClassifier.isLikelySale(item) && !"shared".equals(item.source)) continue;
                if (!SaleClassifier.isHeavyEquipmentRelated(item)) continue;
                if (!q.isEmpty()) {
                    String hay = (item.title + " " + item.description + " " + item.category + " " + item.location).toLowerCase();
                    if (!hay.contains(q)) continue;
                }
                filtered.add(item);
            }
            Collections.sort(filtered, (a, b) -> {
                int used = Integer.compare(SaleClassifier.usedPriority(b), SaleClassifier.usedPriority(a));
                if (used != 0) return used;
                return Long.compare(b.createdAt, a.createdAt);
            });
            callback.onResult(filtered, status);
        });
    }

    private List<Listing> fetchRemote(String source, String query) throws Exception {
        String base = BuildConfig.DATA_API_BASE.endsWith("/")
                ? BuildConfig.DATA_API_BASE.substring(0, BuildConfig.DATA_API_BASE.length() - 1)
                : BuildConfig.DATA_API_BASE;
        String u = base + "/feed?source=" + URLEncoder.encode(source, "UTF-8")
                + "&q=" + URLEncoder.encode(query == null ? "" : query, "UTF-8");
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setRequestMethod("GET");
        c.setConnectTimeout(10000);
        c.setReadTimeout(12000);
        c.setRequestProperty("Accept", "application/json");
        int code = c.getResponseCode();
        if (code < 200 || code >= 300) throw new IllegalStateException("HTTP " + code);
        BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8));
        StringBuilder b = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) b.append(line);
        r.close();
        c.disconnect();

        JSONObject root = new JSONObject(b.toString());
        JSONArray a = root.optJSONArray("items");
        List<Listing> out = new ArrayList<>();
        if (a != null) {
            for (int i = 0; i < a.length(); i++) out.add(Listing.fromJson(a.getJSONObject(i)));
        }
        return out;
    }
}
