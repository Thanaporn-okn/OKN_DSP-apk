package com.okn.heavymarket.data;

import com.okn.heavymarket.model.Listing;
import java.util.Locale;

public final class SaleClassifier {
    private static final String[] SALE_WORDS = {
            "ขาย", "ราคา", "บาท", "฿", "สนใจ", "พร้อมขาย", "ปล่อย", "ดาวน์", "ผ่อน"
    };
    private static final String[] HEAVY_WORDS = {
            "รถบรรทุก", "สิบล้อ", "หกล้อ", "6ล้อ", "6 ล้อ", "รถดั้ม", "ดั้ม",
            "แม็คโค", "แมคโคร", "รถขุด", "excavator", "รถไถ", "tractor", "รถเครน",
            "รถตัก", "โฟล์คลิฟท์", "หัวลาก", "พ่วง", "เทรลเลอร์", "เครื่องจักรหนัก"
    };
    private static final String[] USED_WORDS = {
            "มือสอง", "รถบ้าน", "เจ้าของขายเอง", "เจ้าของขาย", "ใช้งานแล้ว", "ผ่านการใช้งาน",
            "พร้อมใช้งาน", "พร้อมทำงาน", "ตามสภาพ", "สภาพเดิม", "ไมล์", "ชั่วโมงทำงาน",
            "ทะเบียน", "เอกสารครบ", "ภาษี", "โอน", "ปี 20", "ปี20"
    };
    private static final String[] NEW_WORDS = {
            "รถใหม่", "มือหนึ่ง", "ป้ายแดง", "ใหม่ 100%", "สินค้าใหม่", "ของใหม่",
            "new unit", "brand new", "รถศูนย์ใหม่", "ออกห้าง"
    };

    private SaleClassifier() {}

    public static boolean isLikelySale(Listing item) {
        if (item.price > 0) return true;
        String text = (item.title + " " + item.description).toLowerCase(Locale.ROOT);
        for (String word : SALE_WORDS) {
            if (text.contains(word.toLowerCase(Locale.ROOT))) return true;
        }
        return false;
    }

    public static boolean isHeavyEquipmentRelated(Listing item) {
        String text = text(item);
        for (String word : HEAVY_WORDS) {
            if (text.contains(word.toLowerCase(Locale.ROOT))) return true;
        }
        return true; // Keep "อื่นๆ" visible; category filters can narrow it later.
    }

    public static boolean isExplicitlyNew(Listing item) {
        String text = text(item);
        for (String word : NEW_WORDS) {
            if (text.contains(word.toLowerCase(Locale.ROOT))) return true;
        }
        return false;
    }

    public static boolean isLikelyUsed(Listing item) {
        if (isExplicitlyNew(item)) return false;
        String text = text(item);
        for (String word : USED_WORDS) {
            if (text.contains(word.toLowerCase(Locale.ROOT))) return true;
        }
        // Heavy vehicles/equipment with an age/year/use signal are commonly second-hand listings.
        if (text.matches(".*\\b(19|20)\\d{2}\\b.*")) return true;
        return false;
    }

    public static int usedPriority(Listing item) {
        if (isExplicitlyNew(item)) return 0;
        return isLikelyUsed(item) ? 2 : 1;
    }

    private static String text(Listing item) {
        return (item.title + " " + item.description + " " + item.category + " "
                + item.groupName).toLowerCase(Locale.ROOT);
    }
}
