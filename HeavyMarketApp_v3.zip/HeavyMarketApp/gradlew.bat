@echo off
setlocal
set GRADLE_VERSION=8.9
set APP_HOME=%~dp0
set DIST_DIR=%APP_HOME%.gradle-bootstrap\gradle-%GRADLE_VERSION%
set ZIP=%APP_HOME%.gradle-bootstrap\gradle-%GRADLE_VERSION%-bin.zip
if not exist "%DIST_DIR%\bin\gradle.bat" (
  if not exist "%APP_HOME%.gradle-bootstrap" mkdir "%APP_HOME%.gradle-bootstrap"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ZIP%'; Expand-Archive -Force '%ZIP%' '%APP_HOME%.gradle-bootstrap'"
  if errorlevel 1 exit /b 1
)
call "%DIST_DIR%\bin\gradle.bat" %*
endlocal
