
OKN_DSP BP1048P4 V11

Added:
- Bluetooth communication base
- Connect switch
- TX/RX log
- BP1048P4 packet command preparation
