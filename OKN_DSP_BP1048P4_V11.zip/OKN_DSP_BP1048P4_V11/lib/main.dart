
import 'package:flutter/material.dart';

void main() {
  runApp(const OKNV11());
}

class OKNV11 extends StatelessWidget {
  const OKNV11({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner:false,
      theme: ThemeData.dark(),
      home: const DSPPage(),
    );
  }
}

class DSPPage extends StatefulWidget {
  const DSPPage({super.key});
  @override
  State<DSPPage> createState()=>_DSPPageState();
}

class _DSPPageState extends State<DSPPage>{
  String log="TX/RX LOG\nReady";
  bool connected=false;

  void sendCommand(String cmd){
    setState(() {
      log += "\nTX: $cmd";
    });
  }

  @override
  Widget build(BuildContext context){
    return Scaffold(
      backgroundColor: const Color(0xff111017),
      appBar: AppBar(title: const Text("OKN_DSP BP1048P4 V11")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children:[
            SwitchListTile(
              title: const Text("Bluetooth Connect"),
              value: connected,
              onChanged:(v)=>setState(()=>connected=v),
            ),
            ElevatedButton(
              onPressed:()=>sendCommand("AA 55 VOL CH1 50"),
              child: const Text("SEND VOLUME"),
            ),
            ElevatedButton(
              onPressed:()=>sendCommand("AA 55 EQ CH1"),
              child: const Text("SEND EQ"),
            ),
            ElevatedButton(
              onPressed:()=>sendCommand("AA 55 CROSSOVER CH1"),
              child: const Text("SEND CROSSOVER"),
            ),
            Expanded(child: Text(log))
          ],
        ),
      ),
    );
  }
}
