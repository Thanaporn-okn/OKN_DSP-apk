# OKN_DSP UI Demo v1

Full installable Android UI prototype for a 7-channel DSP controller.

## Included screens
- Mixer with 7 independent channel gains
- Master output control
- 10-band EQ
- HPF/LPF crossover controls
- Preset manager
- BLE / app settings demo
- AMOLED-style Material 3 UI

## Important
This version is a visual/interaction prototype. BLE is simulated intentionally until real DSP packet formats are confirmed from logs.

## APK output
GitHub Actions will create:
`app/build/outputs/apk/debug/app-debug.apk`
