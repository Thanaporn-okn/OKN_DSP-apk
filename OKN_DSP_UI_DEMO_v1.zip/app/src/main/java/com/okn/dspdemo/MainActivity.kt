package com.okn.dspdemo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.okn.dspdemo.ui.theme.OKNDSPTheme
import kotlin.math.cos
import kotlin.math.sin

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OKNDSPTheme { OKNDspDemo() } }
    }
}

enum class DspPage(val label: String) { Mixer("MIXER"), Eq("EQ"), Xover("XOVER"), Preset("PRESET"), Setup("SETUP") }

data class DspChannel(
    val id: Int,
    val name: String,
    val role: String,
    val gain: Float = 0f,
    val muted: Boolean = false
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OKNDspDemo() {
    var page by remember { mutableStateOf(DspPage.Mixer) }
    var connected by remember { mutableStateOf(false) }
    var master by remember { mutableFloatStateOf(-8f) }
    var channels by remember {
        mutableStateOf(
            listOf(
                DspChannel(1, "CH 1", "FRONT L", -2f),
                DspChannel(2, "CH 2", "FRONT R", -2f),
                DspChannel(3, "CH 3", "REAR L", -4f),
                DspChannel(4, "CH 4", "REAR R", -4f),
                DspChannel(5, "CH 5", "CENTER", -6f),
                DspChannel(6, "CH 6", "SUB", -8f),
                DspChannel(7, "CH 7", "AUX", -10f)
            )
        )
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            CenterAlignedTopAppBar(
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = Color.Transparent),
                navigationIcon = {
                    Box(
                        modifier = Modifier.padding(start = 16.dp).size(38.dp).clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = .12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.GraphicEq, null, tint = MaterialTheme.colorScheme.primary)
                    }
                },
                title = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("OKN_DSP", fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
                        Text("7-CHANNEL DIGITAL SOUND PROCESSOR", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(.5f), letterSpacing = 1.1.sp)
                    }
                },
                actions = {
                    ConnectionPill(connected = connected, onClick = { connected = !connected })
                    Spacer(Modifier.width(12.dp))
                }
            )
        },
        bottomBar = { DspBottomBar(page) { page = it } }
    ) { pad ->
        AnimatedContent(targetState = page, label = "page") { target ->
            when (target) {
                DspPage.Mixer -> MixerPage(pad, connected, master, { master = it }, channels) { idx, ch ->
                    channels = channels.toMutableList().also { it[idx] = ch }
                }
                DspPage.Eq -> EqualizerPage(pad)
                DspPage.Xover -> XoverPage(pad)
                DspPage.Preset -> PresetPage(pad)
                DspPage.Setup -> SetupPage(pad, connected) { connected = !connected }
            }
        }
    }
}

@Composable
private fun ConnectionPill(connected: Boolean, onClick: () -> Unit) {
    val color by animateColorAsState(if (connected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline, label = "conn")
    Surface(
        modifier = Modifier.clickable { onClick() },
        shape = RoundedCornerShape(50),
        color = color.copy(alpha = .12f),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = .45f))
    ) {
        Row(Modifier.padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(7.dp).clip(CircleShape).background(color))
            Spacer(Modifier.width(6.dp))
            Text(if (connected) "DSP" else "CONNECT", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = color)
        }
    }
}

@Composable
private fun MixerPage(
    pad: PaddingValues,
    connected: Boolean,
    master: Float,
    onMaster: (Float) -> Unit,
    channels: List<DspChannel>,
    onChannel: (Int, DspChannel) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(pad).padding(horizontal = 16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Spacer(Modifier.height(4.dp))
        StatusHero(connected, master, onMaster)
        SectionLabel("OUTPUT CHANNELS", "Independent control • Demo mode")
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            channels.forEachIndexed { index, ch ->
                ChannelStrip(ch) { onChannel(index, it) }
            }
        }
        SectionLabel("SIGNAL", "Live-style visual meter")
        SignalCard()
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun StatusHero(connected: Boolean, master: Float, onMaster: (Float) -> Unit) {
    Surface(
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(.55f))
    ) {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("MASTER OUTPUT", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.55f), letterSpacing = 1.2.sp)
                    Spacer(Modifier.height(6.dp))
                    Text("${"%.1f".format(master)} dB", fontSize = 30.sp, fontWeight = FontWeight.Black)
                    Text(if (connected) "GOLO DSP • BLE LINK ACTIVE" else "DEMO MODE • TAP CONNECT", fontSize = 10.sp, color = if (connected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(.45f))
                }
                GainKnob(master, -60f, 12f)
            }
            Spacer(Modifier.height(16.dp))
            Slider(
                value = master,
                onValueChange = onMaster,
                valueRange = -60f..12f,
                colors = SliderDefaults.colors(activeTrackColor = MaterialTheme.colorScheme.primary, thumbColor = MaterialTheme.colorScheme.primary)
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("-60", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(.4f))
                Text("0 dB", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(.4f))
                Text("+12", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(.4f))
            }
        }
    }
}

@Composable
private fun GainKnob(value: Float, min: Float, max: Float) {
    val animated by animateFloatAsState(value, label = "knob")
    val p = ((animated - min) / (max - min)).coerceIn(0f, 1f)
    Canvas(Modifier.size(92.dp)) {
        val stroke = 8.dp.toPx()
        drawArc(Color(0xFF24313D), 135f, 270f, false, style = Stroke(stroke, cap = StrokeCap.Round))
        drawArc(Color(0xFF43E6C2), 135f, 270f * p, false, style = Stroke(stroke, cap = StrokeCap.Round))
        val angle = Math.toRadians((135 + 270 * p).toDouble())
        val r = size.minDimension * .32f
        val c = Offset(size.width / 2, size.height / 2)
        drawCircle(Color(0xFF121B24), size.minDimension * .28f, c)
        drawLine(Color(0xFFEAF2F7), c, Offset(c.x + cos(angle).toFloat() * r, c.y + sin(angle).toFloat() * r), 3.dp.toPx(), StrokeCap.Round)
    }
}

@Composable
private fun ChannelStrip(ch: DspChannel, onChange: (DspChannel) -> Unit) {
    Surface(
        modifier = Modifier.width(148.dp),
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, if (ch.muted) MaterialTheme.colorScheme.error.copy(.65f) else MaterialTheme.colorScheme.outline.copy(.5f))
    ) {
        Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(ch.name, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
            Text(ch.role, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(.45f))
            Spacer(Modifier.height(12.dp))
            MiniMeter(ch.gain, ch.muted)
            Spacer(Modifier.height(12.dp))
            Text(if (ch.muted) "MUTED" else "${"%.1f".format(ch.gain)} dB", fontWeight = FontWeight.Bold, color = if (ch.muted) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
            Slider(
                value = ch.gain,
                onValueChange = { onChange(ch.copy(gain = it)) },
                valueRange = -24f..12f,
                enabled = !ch.muted
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(
                    onClick = { onChange(ch.copy(muted = !ch.muted)) },
                    label = { Text("MUTE", fontSize = 9.sp) },
                    leadingIcon = { Icon(if (ch.muted) Icons.Default.VolumeOff else Icons.Default.VolumeUp, null, Modifier.size(15.dp)) }
                )
                AssistChip(onClick = {}, label = { Text("EQ", fontSize = 9.sp) })
            }
        }
    }
}

@Composable
private fun MiniMeter(gain: Float, muted: Boolean) {
    val level = if (muted) 0f else ((gain + 24f) / 36f).coerceIn(.08f, 1f)
    Canvas(Modifier.fillMaxWidth().height(74.dp)) {
        val bars = 18
        val gap = 3.dp.toPx()
        val h = (size.height - gap * (bars - 1)) / bars
        repeat(bars) { i ->
            val active = i < (bars * level).toInt()
            val y = size.height - (i + 1) * h - i * gap
            val c = when {
                !active -> Color(0xFF1D2934)
                i > 15 -> Color(0xFFFF6B6B)
                i > 12 -> Color(0xFFFFC857)
                else -> Color(0xFF43E6C2)
            }
            drawRoundRect(c, Offset(0f, y), Size(size.width, h), CornerRadius(h / 2, h / 2))
        }
    }
}

@Composable
private fun SignalCard() {
    Surface(shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surface) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Waves, null, tint = MaterialTheme.colorScheme.secondary)
                Spacer(Modifier.width(8.dp))
                Text("INPUT ANALYZER", fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Text("48 kHz / 24-bit", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(.45f))
            }
            Spacer(Modifier.height(10.dp))
            Canvas(Modifier.fillMaxWidth().height(92.dp)) {
                val mid = size.height / 2
                val step = size.width / 52
                var prev = Offset(0f, mid)
                for (i in 1..52) {
                    val x = i * step
                    val wave = (sin(i * .55) * 16 + sin(i * .17) * 11 + sin(i * 1.1) * 4).toFloat()
                    val next = Offset(x, mid + wave)
                    drawLine(Color(0xFF76B7FF), prev, next, 2.dp.toPx(), StrokeCap.Round)
                    prev = next
                }
                drawLine(Color(0xFF20303D), Offset(0f, mid), Offset(size.width, mid), 1.dp.toPx())
            }
        }
    }
}

@Composable
private fun EqualizerPage(pad: PaddingValues) {
    val freqs = listOf("31", "62", "125", "250", "500", "1K", "2K", "4K", "8K", "16K")
    var bands by remember { mutableStateOf(List(10) { 0f }) }
    Column(Modifier.fillMaxSize().padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        PageHeader("PARAMETRIC EQ", "CH 1 • FRONT LEFT", Icons.Default.Equalizer)
        Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.padding(16.dp)) {
                Text("10-BAND EQUALIZER", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.5f), letterSpacing = 1.2.sp)
                Spacer(Modifier.height(12.dp))
                freqs.forEachIndexed { index, f ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(f, Modifier.width(42.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Slider(value = bands[index], onValueChange = { v -> bands = bands.toMutableList().also { it[index] = v } }, valueRange = -12f..12f, modifier = Modifier.weight(1f))
                        Text("${if (bands[index] >= 0) "+" else ""}${"%.1f".format(bands[index])}", Modifier.width(48.dp), textAlign = TextAlign.End, fontSize = 10.sp, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FilledTonalButton(onClick = { bands = List(10) { 0f } }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.RestartAlt, null); Spacer(Modifier.width(6.dp)); Text("FLAT") }
            Button(onClick = {}, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Save, null); Spacer(Modifier.width(6.dp)); Text("SAVE EQ") }
        }
    }
}

@Composable
private fun XoverPage(pad: PaddingValues) {
    var hpf by remember { mutableFloatStateOf(80f) }
    var lpf by remember { mutableFloatStateOf(8000f) }
    Column(Modifier.fillMaxSize().padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        PageHeader("CROSSOVER", "CH 1 • FRONT LEFT", Icons.Default.FilterAlt)
        CrossoverCard("HIGH PASS FILTER", "HPF", hpf, 20f..500f) { hpf = it }
        CrossoverCard("LOW PASS FILTER", "LPF", lpf, 500f..20000f) { lpf = it }
        Surface(shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.padding(16.dp)) {
                Text("FILTER SLOPE", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.5f), letterSpacing = 1.2.sp)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("6 dB", "12 dB", "18 dB", "24 dB").forEachIndexed { i, s ->
                        FilterChip(selected = i == 3, onClick = {}, label = { Text(s, fontSize = 10.sp) })
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("Linkwitz-Riley • Phase coherent", fontSize = 10.sp, color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
private fun CrossoverCard(title: String, type: String, value: Float, range: ClosedFloatingPointRange<Float>, onValue: (Float) -> Unit) {
    Surface(shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surface) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(title, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.5f), letterSpacing = 1.2.sp)
                    Text(type, fontSize = 24.sp, fontWeight = FontWeight.Black)
                }
                Text("${value.toInt()} Hz", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
            Slider(value = value, onValueChange = onValue, valueRange = range)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${range.start.toInt()} Hz", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(.4f))
                Text("${range.endInclusive.toInt()} Hz", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(.4f))
            }
        }
    }
}

@Composable
private fun PresetPage(pad: PaddingValues) {
    var selected by remember { mutableIntStateOf(0) }
    val presets = listOf("DAILY DRIVE", "VOCAL FOCUS", "DEEP BASS", "NIGHT MODE", "USER 01")
    Column(Modifier.fillMaxSize().padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        PageHeader("PRESETS", "Instant DSP profiles", Icons.Default.Bookmarks)
        presets.forEachIndexed { index, name ->
            Surface(
                modifier = Modifier.fillMaxWidth().clickable { selected = index },
                shape = RoundedCornerShape(18.dp),
                color = if (selected == index) MaterialTheme.colorScheme.primary.copy(.12f) else MaterialTheme.colorScheme.surface,
                border = androidx.compose.foundation.BorderStroke(1.dp, if (selected == index) MaterialTheme.colorScheme.primary.copy(.55f) else MaterialTheme.colorScheme.outline.copy(.45f))
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(if (selected == index) MaterialTheme.colorScheme.primary.copy(.16f) else MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
                        Icon(if (selected == index) Icons.Default.Check else Icons.Default.Tune, null, tint = if (selected == index) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(.55f))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(name, fontWeight = FontWeight.Bold)
                        Text(if (index == 0) "Balanced • 7 channels • Active" else "Tap to recall profile", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(.45f))
                    }
                    Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurface.copy(.35f))
                }
            }
        }
        Button(onClick = {}, modifier = Modifier.fillMaxWidth().height(52.dp)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("SAVE CURRENT AS PRESET") }
    }
}

@Composable
private fun SetupPage(pad: PaddingValues, connected: Boolean, toggle: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        PageHeader("SETUP", "Device & application", Icons.Default.Settings)
        Surface(shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.primary.copy(.12f)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Bluetooth, null, tint = MaterialTheme.colorScheme.primary)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("GOLO DSP", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text("UUID AB01 • Demo transport", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(.45f))
                    }
                    Switch(checked = connected, onCheckedChange = { toggle() })
                }
            }
        }
        SettingRow(Icons.Default.Link, "Channel link", "Independent gains for UI demo", false)
        SettingRow(Icons.Default.Speed, "Realtime update", "Send parameters while dragging", true)
        SettingRow(Icons.Default.Vibration, "Haptic feedback", "Samsung-style touch response", true)
        SettingRow(Icons.Default.DarkMode, "AMOLED dark", "Optimized for OLED screens", true)
        Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(.55f)) {
            Column(Modifier.padding(16.dp)) {
                Text("OKN_DSP UI DEMO v1", fontWeight = FontWeight.Bold)
                Text("Visual prototype only. BLE controls are intentionally simulated until command packets are confirmed.", fontSize = 10.sp, lineHeight = 15.sp, color = MaterialTheme.colorScheme.onSurface.copy(.5f))
            }
        }
    }
}

@Composable
private fun SettingRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, sub: String, checked: Boolean) {
    Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surface) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.secondary)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.SemiBold); Text(sub, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(.45f)) }
            Switch(checked = checked, onCheckedChange = null)
        }
    }
}

@Composable
private fun PageHeader(title: String, sub: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.secondary.copy(.12f)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = MaterialTheme.colorScheme.secondary) }
        Spacer(Modifier.width(12.dp))
        Column { Text(title, fontSize = 22.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp); Text(sub, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(.45f)) }
    }
}

@Composable
private fun SectionLabel(title: String, sub: String) {
    Row(verticalAlignment = Alignment.Bottom) {
        Text(title, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.1.sp)
        Spacer(Modifier.weight(1f))
        Text(sub, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(.4f))
    }
}

@Composable
private fun DspBottomBar(page: DspPage, onSelect: (DspPage) -> Unit) {
    NavigationBar(containerColor = Color(0xFF0A1016), tonalElevation = 0.dp) {
        DspPage.entries.forEach { item ->
            val icon = when (item) {
                DspPage.Mixer -> Icons.Default.Tune
                DspPage.Eq -> Icons.Default.Equalizer
                DspPage.Xover -> Icons.Default.FilterAlt
                DspPage.Preset -> Icons.Default.Bookmarks
                DspPage.Setup -> Icons.Default.Settings
            }
            NavigationBarItem(
                selected = page == item,
                onClick = { onSelect(item) },
                icon = { Icon(icon, item.label) },
                label = { Text(item.label, fontSize = 8.sp, fontWeight = FontWeight.Bold) },
                colors = NavigationBarItemDefaults.colors(indicatorColor = MaterialTheme.colorScheme.primary.copy(.14f), selectedIconColor = MaterialTheme.colorScheme.primary, selectedTextColor = MaterialTheme.colorScheme.primary, unselectedIconColor = MaterialTheme.colorScheme.onSurface.copy(.42f), unselectedTextColor = MaterialTheme.colorScheme.onSurface.copy(.42f))
            )
        }
    }
}

private fun Modifier.verticalScroll(rememberScrollState()): Modifier = this.then(Modifier.verticalScroll(rememberScrollState()))
