package com.okn.dspdemo.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFF43E6C2),
    onPrimary = Color(0xFF002019),
    secondary = Color(0xFF76B7FF),
    tertiary = Color(0xFFFFC857),
    background = Color(0xFF070B10),
    surface = Color(0xFF0D131B),
    surfaceVariant = Color(0xFF131C26),
    onBackground = Color(0xFFEAF2F7),
    onSurface = Color(0xFFEAF2F7),
    outline = Color(0xFF2A3948)
)

@Composable
fun OKNDSPTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColors, content = content)
}
