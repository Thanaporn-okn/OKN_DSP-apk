# OKN DSP V89 — EQ Gain +/- Buttons (Base V41)

Base: **V40 real-hardware stable (user-tested normal)**.

V40 adds **automatic DSP readback/synchronization** without changing the V39 hardware writer. After initial connection, reconnect, or manual refresh, the authenticated fresh Device Description is treated as the authoritative snapshot. The UI is updated with current Master/Bass/BassCutoff and all 7 x 15 EQ Frequency/Q/Gain values, writable locks are rebuilt, then the synchronized state is checkpointed locally.

Safety boundary: readback callbacks do not echo values back to the DSP; no new actuator mapping or packet format is introduced; SaveParams is never automatic; V38 safe-PEQ gating and V39 Gain-only Safe Reset remain unchanged.

Version: **41.0.0** (`versionCode 1041`)


## V41 guarded persistent save
See `Sources/V41_GUARDED_SAVE_RESTORE.txt`. V41 is based only on V40 and adds a manual-only verified SaveParams transaction plus readback-only Restore.
