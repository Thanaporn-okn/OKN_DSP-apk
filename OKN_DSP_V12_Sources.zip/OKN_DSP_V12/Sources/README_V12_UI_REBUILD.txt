OKN_DSP V12 — Phase 1 Full UI Rebuild

V12 replaces the previous custom-Canvas page implementation with a local offline WebView UI written from HTML/CSS/JavaScript plus bundled decorative artwork. This was done to match the supplied four-screen reference much more literally and responsively across phones and tablets.

Implemented pages:
- Home: device card, connection/status stack, input source, quick actions, premium strip.
- Mix: Master/Bass sliders and four real-time rotary controls.
- Eq: 7 channels, editable 15-band graph, Frequency/Gain/Q, output level, local preset save/load.
- Crossover: response graph, four filter blocks, slopes, Link L/R, delay units, delay controls, reset and auto-align preview.

All controls remain live Phase-1 controls. Graphs redraw immediately. No uploaded reference screenshot is bundled or used as a background. Phase 2 hardware transport remains disabled.
