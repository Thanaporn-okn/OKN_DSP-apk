OKN_DSP Version 12 - Phase 1 UI

Purpose
- Rebuild the interface from code to visually approach the supplied four-screen reference.
- The supplied reference image is NOT embedded or copied as an app background.
- Phase 2 DSP/BLE transport remains disabled until the Phase 1 UI is accepted.

Pages
- Home
- Mix
- Eq
- Crossover

V12 focus
- Correct visual differences observed in the running V11 recording (30565.mp4).
- Use a vector OKN_DSP wordmark independent of the phone's selected display font.
- Match the supplied 432x768 reference geometry for card heights, knob sizes, EQ layout and crossover layout while keeping the app full-screen on 20:9 phones and tablets.
- Make the 15-band EQ line pass through its editable points and let Frequency/Gain/Q redraw the graph immediately.
- Match the crossover magnitude graph to the reference dB scale and preserve real-time response to filter/frequency/slope changes.
- Preserve the stable development signing identity for update-in-place builds.

Signing / update path
V3 introduced a stable DEVELOPMENT signing key. V4 through V12 preserve the same key, so V3 and later development builds can update in place.
If moving from V1/V2 and Android reports an incompatible update, uninstall the old V1/V2 app once. V3 and later use the stable key.

Build
Use OKN_DSP_AutoBuild.yml. The workflow automatically selects the highest OKN_DSP_V*_Sources.zip in the repository root, verifies Sources/SHA256SUMS.txt, verifies the signing key, builds the signed debug APK and uploads the APK artifact.
