# OKN DSP V12 — Phase 1

V12 applies the visual changes requested after the V11 device test.

- Launcher icon replaced with the supplied blue/cyan OKN equalizer icon artwork.
- Mix page removes blue from active controls.
- Master Volume uses mint/green.
- Bass Volume uses orange.
- Bass Cutoff uses amber/gold.
- Ch1–Ch7 use a non-blue mix palette: mint, orange, amber, coral, green, tangerine and gold.
- Mix bottom-navigation active state uses mint/green instead of blue.
- Home and EQ retain their existing color behavior.
- EQ color policy remains: Frequency blue, Q cyan/teal, Gain Band mint green.
- V11 WindowInsets safe-area fix is preserved.
- Preset behavior is preserved: popup naming, multiple presets, Load and Delete.

Version: **12.0.0** (`versionCode 1012`)
