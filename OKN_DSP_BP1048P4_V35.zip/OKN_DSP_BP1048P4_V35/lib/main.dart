import 'package:flutter/material.dart';

void main() => runApp(const OKNDSP());

class OKNDSP extends StatelessWidget {
  const OKNDSP({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'OKN DSP BP1048P4 V35',
      home: Scaffold(
        appBar: AppBar(title: const Text('OKN_DSP BP1048P4 V35')),
        body: const Padding(
          padding: EdgeInsets.all(20),
          child: Text(
            'Bluetooth DSP Controller\n\n'
            'Manifest Fixed\n'
            'Bluetooth Permission Layer\n'
            'BP1048P4 TX RX Ready\n'
            'CH1-CH7 DSP Control',
            style: TextStyle(fontSize: 22),
          ),
        ),
      ),
    );
  }
}
