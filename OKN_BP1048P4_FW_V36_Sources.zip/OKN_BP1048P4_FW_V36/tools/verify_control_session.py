#!/usr/bin/env python3
from pathlib import Path
import sys
root=Path(__file__).resolve().parents[1]
h=(root/'src/transport/okn_control_session.h').read_text()
c=(root/'src/transport/okn_control_session.c').read_text()
fm=(root/'firmware_manifest.json').read_text()
errors=[]
for sym in ('okn_control_session_execute','okn_control_session_reset','duplicate_replays','cached_request','cached_controller_revision','stale_cache_misses'):
    if sym not in h+c: errors.append('missing control-session symbol: '+sym)
if 'memcmp(session->cached_request, request, request_len)' not in c:
    errors.append('duplicate detection must compare exact request bytes')
if 'okn_protocol_execute_ex' not in c:
    errors.append('session must use separated protocol execution result')
if 'uint8_t encoded[OKN_CONTROL_MAX_FRAME]' not in c:
    errors.append('session must execute into full internal response buffer')

if 'session->cached_controller_revision == session->controller->revision' not in c:
    errors.append('duplicate cache must be bound to current controller revision')
if '++session->stale_cache_misses' not in c:
    errors.append('stale revision-bound cache misses must be observable')
if 'session->cached_controller_revision = session->controller->revision' not in c:
    errors.append('cache must snapshot controller revision after command evaluation')
if '"revision_bound_response_cache": true' not in fm:
    errors.append('firmware manifest must declare revision-bound response cache')
if '"single_outstanding_request": true' not in fm:
    errors.append('firmware manifest must declare serialized request contract')
if '"exact_duplicate_response_cache": true' not in fm:
    errors.append('firmware manifest must declare duplicate response cache')
if errors:
    [print('BLOCKED:',e) for e in errors]; sys.exit(1)
print('PASS: V36 control-session cache is exact-byte, revision-bound, retry-safe, and portable')
