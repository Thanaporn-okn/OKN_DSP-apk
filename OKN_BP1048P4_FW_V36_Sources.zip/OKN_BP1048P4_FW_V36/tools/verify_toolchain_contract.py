#!/usr/bin/env python3
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
errors=[]
h=(ROOT/'src/portability/okn_toolchain_contract.h').read_text()
p=(ROOT/'src/persist/okn_persistence.c').read_text()
probe=(ROOT/'tools/toolchain_probe.py').read_text()
required=['CHAR_BIT == 8','sizeof(uint32_t) == 4u','sizeof(float) == 4u','FLT_RADIX == 2','FLT_MANT_DIG == 24','FLT_MAX_EXP == 128','FLT_MIN_EXP == -125']
for x in required:
    if x not in h: errors.append('missing compile contract: '+x)
if 'portability/okn_toolchain_contract.h' not in p: errors.append('persistence must include toolchain contract')
if '(int32_t)(a - b)' in p or '(int32_t)(a-b)' in p: errors.append('generation order must not rely on uint32->int32 implementation-defined conversion')
for bad in ['-o firmware','objcopy','flash','programmer']:
    # Documentation text can mention forbidden capabilities; only catch command-like implementation tokens below.
    pass
if '"-c"' not in probe: errors.append('toolchain probe must compile-only with -c')
if 'linker_invoked": False' not in probe or 'hardware_io_performed": False' not in probe: errors.append('probe non-authorizing boundary missing')
if errors:
    for e in errors: print('BLOCKED:',e)
    sys.exit(1)
print('PASS: V36 toolchain contract is compile-only, IEEE-binary32-explicit, and non-authorizing')
