#!/usr/bin/env python3
from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'evidence_manifest.json').read_text())
errors=[]
if m.get('schema')!=4: errors.append('evidence schema must be 4')
if m.get('project_version')!=36: errors.append('project_version must be 36')
if m.get('target')!='BP1048P4' or m.get('board')!='GoloPine 7CH': errors.append('target/board mismatch')
if m.get('policy')!='FAIL_CLOSED_NO_INFERENCE': errors.append('policy mismatch')
if m.get('hardware_authorized') is not False: errors.append('hardware_authorized must be false')
req=m.get('required_exact_evidence',{})
if any(bool(v) for v in req.values()): errors.append('V36 exact evidence flags must all remain false')
prov=m.get('provenance',{})
if prov.get('previous_source_sha256')!='c2ebb1ec60f686f77cba628d8d3c0e8bbfdcf5f4b1b982ec00305e8ecbde0beb': errors.append('V35 source provenance mismatch')
if prov.get('validation_zip_sha256')!='45370986b60a55f014a51f0e2e0abe75a7bd43d0b762f8894f709b92d0bc049d': errors.append('V35 validation provenance mismatch')
if not any(o.get('id')=='v35-ci-validation' for o in m.get('observations',[])): errors.append('V35 CI observation missing')
for ob in m.get('observations',[]):
    if ob.get('authorizes') not in ([],None): errors.append('observations may not authorize hardware in V36')
if errors:
    [print('BLOCKED:',e) for e in errors]; sys.exit(1)
print('PASS: V36 evidence manifest is internally consistent and non-authorizing')
