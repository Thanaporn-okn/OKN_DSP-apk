#!/usr/bin/env python3
from pathlib import Path
import argparse,json,sys
from target_qualification_policy import CLAIM_CLASSES,evaluate
from qualification_bundle import load_and_verify
root=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser(); p.add_argument('--expect-locked',action='store_true'); a=p.parse_args()
m=json.loads((root/'target_qualification_manifest.json').read_text())
t=json.loads((root/'target_port_manifest.json').read_text())
b=load_and_verify(root/'qualification_bundle_manifest.json',root)
errors=list(b['errors'])
if m.get('schema')!=2: errors.append('qualification schema must be 2')
if m.get('project_version')!=36: errors.append('qualification project_version must be 36')
if m.get('target')!='BP1048P4' or m.get('board')!='GoloPine 7CH': errors.append('qualification target/board mismatch')
if m.get('policy')!='CONTENT_BOUND_HASHED_PROVENANCE_REVIEW_REQUIRED_NO_NAME_BASED_AUTHORIZATION': errors.append('qualification policy mismatch')
if m.get('qualification_bundle_manifest')!='qualification_bundle_manifest.json': errors.append('qualification bundle link missing')
claims=m.get('claims',{})
if set(claims)!=set(CLAIM_CLASSES): errors.append('qualification claim set mismatch')
for name,rec in claims.items():
    if rec.get('verified') is not False: errors.append(name+': verified must remain false in V36')
    if rec.get('reviewed') is not False: errors.append(name+': reviewed must remain false in V36')
    for k in ('classification','artifact_sha256','artifact_id','source','evidence_locator'):
        if rec.get(k) is not None: errors.append(name+': '+k+' must remain null in V36')
if m.get('automatic_authorization') is not False: errors.append('automatic_authorization must be false')
if m.get('hardware_authorized') is not False or m.get('mobile_flash_authorized') is not False: errors.append('V36 authorization flags must be false')
if t.get('qualification_manifest')!='target_qualification_manifest.json': errors.append('target manifest qualification link missing')
if t.get('qualification_bundle_manifest')!='qualification_bundle_manifest.json': errors.append('target manifest bundle link missing')
r=evaluate(m,b['verified_index'])
print('TARGET_QUALIFICATION='+('READY' if r['hardware_ready'] else 'LOCKED'))
print('MOBILE_QUALIFICATION='+('READY' if r['mobile_ready'] else 'LOCKED'))
for k in r['hardware_missing']: print(k+'=BLOCKED')
if errors:
    [print('BLOCKED:',e) for e in errors]; sys.exit(1)
if a.expect_locked and (r['hardware_ready'] or r['mobile_ready']):
    print('ERROR: V36 qualification unexpectedly became ready'); sys.exit(1)
print('PASS: V36 target qualification requires content-bound files + hash + provenance + review and remains fail-closed')
