#!/usr/bin/env python3
from pathlib import Path
import re, sys

ROOT = Path(__file__).resolve().parents[1]
EXPECTED = {
    'tests/golden/get_info_req.vec': 8,
    'tests/golden/get_info_rsp.vec': 18,
    'tests/golden/get_capabilities_req.vec': 8,
    'tests/golden/get_capabilities_rsp.vec': 35,
    'tests/golden/set_ch3_gain_neg3_5_req.vec': 13,
    'tests/golden/set_ch3_gain_neg3_5_ack.vec': 15,
    'tests/golden/persist_default_gen01020304.vec': 1690,
}
errors=[]
for rel,n in EXPECTED.items():
    p=ROOT/rel
    if not p.exists():
        errors.append(rel+': missing'); continue
    text=''.join(p.read_text().split())
    if not re.fullmatch(r'[0-9a-f]+', text):
        errors.append(rel+': must be lowercase hex + whitespace only'); continue
    if len(text)!=n*2:
        errors.append(rel+f': decoded length must be {n}')

proto=(ROOT/'src/core/okn_protocol.c').read_text()
persist=(ROOT/'src/persist/okn_persistence.c').read_text()
all_src='\n'.join(p.read_text(errors='ignore') for p in ROOT.joinpath('src').rglob('*.[ch]'))
for token in ('write_u16_le','write_u32_le','read_f32_le','write_f32_le'):
    if token not in proto: errors.append('protocol missing explicit byte helper '+token)
for token in ('wr16','wr32','rd16','rd32','wrf','rdf'):
    if token not in persist: errors.append('persistence missing explicit byte helper '+token)
if '#pragma pack' in all_src or '__attribute__((packed))' in all_src:
    errors.append('packed structs are forbidden for wire/persistence layout')
if 'memcpy(out, state' in persist or 'memcpy(out,state' in persist:
    errors.append('raw state struct memcpy into persistence image is forbidden')
mk=(ROOT/'Makefile').read_text()
if 'compiler-matrix' not in mk or 'test_wire_vectors' not in mk:
    errors.append('compiler matrix / wire vector test missing from Makefile')

if errors:
    for e in errors: print('BLOCKED:',e)
    sys.exit(1)
print('PASS: V36 wire/persistence byte formats are golden-vector-bound and struct-layout independent')
