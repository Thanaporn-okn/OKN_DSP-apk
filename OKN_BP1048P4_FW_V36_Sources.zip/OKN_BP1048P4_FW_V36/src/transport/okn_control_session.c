#include "okn_control_session.h"
#include <string.h>

static okn_control_session_result_t result_init(void) {
    okn_control_session_result_t r;
    memset(&r, 0, sizeof(r));
    r.protocol.transport_status = OKN_OK;
    r.protocol.command_status = OKN_OK;
    return r;
}

void okn_control_session_init(okn_control_session_t *session, okn_controller_t *controller) {
    if (!session) return;
    memset(session, 0, sizeof(*session));
    session->controller = controller;
}

void okn_control_session_reset(okn_control_session_t *session) {
    if (!session) return;
    session->cache_valid = false;
    session->cached_request_len = 0u;
    session->cached_response_len = 0u;
    session->cached_command_status = OKN_OK;
    session->cached_command_evaluated = false;
    session->cached_controller_revision = 0u;
}

static bool request_bytes_match_cache(const okn_control_session_t *session,
                                        const uint8_t *request,
                                        size_t request_len) {
    return session->cache_valid &&
           session->cached_request_len == request_len &&
           request_len <= OKN_CONTROL_MAX_FRAME &&
           memcmp(session->cached_request, request, request_len) == 0;
}

static bool cached_revision_is_current(const okn_control_session_t *session) {
    return session->controller &&
           session->cached_controller_revision == session->controller->revision;
}

static okn_control_session_result_t emit_cached(okn_control_session_t *session,
                                                uint8_t *response,
                                                size_t response_cap) {
    okn_control_session_result_t r = result_init();
    r.duplicate_replayed = true;
    r.required_response_len = session->cached_response_len;
    r.protocol.command_evaluated = session->cached_command_evaluated;
    r.protocol.command_status = session->cached_command_status;

    if (session->cached_response_len > response_cap ||
        (session->cached_response_len != 0u && !response)) {
        r.protocol.transport_status = OKN_ERR_BUFFER;
        return r;
    }

    if (session->cached_response_len != 0u)
        memcpy(response, session->cached_response, session->cached_response_len);
    r.protocol.response_len = session->cached_response_len;
    ++session->duplicate_replays;
    return r;
}

okn_control_session_result_t okn_control_session_execute(okn_control_session_t *session,
                                                         const uint8_t *request,
                                                         size_t request_len,
                                                         uint8_t *response,
                                                         size_t response_cap) {
    okn_control_session_result_t r = result_init();
    if (!session || !session->controller || !request || request_len > OKN_CONTROL_MAX_FRAME) {
        r.protocol.transport_status = OKN_ERR_ARG;
        return r;
    }

    if (request_bytes_match_cache(session, request, request_len)) {
        if (cached_revision_is_current(session))
            return emit_cached(session, response, response_cap);

        /* V36 revision-bound replay cache: exact request bytes alone are not
         * sufficient once another trusted path has changed controller state.
         * Bypass the stale cache and re-evaluate against the current state. */
        session->cache_valid = false;
        ++session->stale_cache_misses;
    }

    /* Always execute into a full local response buffer. This ensures a valid
     * mutating command cannot be applied a second time merely because the
     * caller initially provided an undersized output buffer. */
    uint8_t encoded[OKN_CONTROL_MAX_FRAME];
    const okn_protocol_result_t pr = okn_protocol_execute_ex(session->controller,
                                                              request, request_len,
                                                              encoded, sizeof(encoded));
    r.protocol = pr;
    r.required_response_len = pr.response_len;
    r.duplicate_replayed = false;

    if (pr.command_evaluated && pr.transport_status == OKN_OK) {
        memcpy(session->cached_request, request, request_len);
        session->cached_request_len = request_len;
        if (pr.response_len != 0u)
            memcpy(session->cached_response, encoded, pr.response_len);
        session->cached_response_len = pr.response_len;
        session->cached_command_status = pr.command_status;
        session->cached_command_evaluated = pr.command_evaluated;
        session->cached_controller_revision = session->controller->revision;
        session->cache_valid = true;
        ++session->executed_requests;
    }

    if (pr.transport_status != OKN_OK)
        return r;

    if (pr.response_len > response_cap || (pr.response_len != 0u && !response)) {
        r.protocol.transport_status = OKN_ERR_BUFFER;
        r.protocol.response_len = 0u;
        return r;
    }

    if (pr.response_len != 0u)
        memcpy(response, encoded, pr.response_len);
    return r;
}
