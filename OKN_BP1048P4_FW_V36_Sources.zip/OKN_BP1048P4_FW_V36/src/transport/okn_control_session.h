#ifndef OKN_CONTROL_SESSION_H
#define OKN_CONTROL_SESSION_H

#include "../core/okn_protocol.h"
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define OKN_CONTROL_MAX_FRAME (8u + OKN_PROTO_MAX_PAYLOAD)

/*
 * Portable single-outstanding-request session guard.
 *
 * BLE/GATT transports can redeliver the same application frame after a host
 * timeout/retry. Applying an identical SET twice would incorrectly advance
 * revision/dirty metadata twice. V14 therefore remembers the most recently
 * completed valid request and its encoded response. An exact byte-for-byte
 * duplicate is answered from cache without evaluating the command again,
 * but only while the controller revision still matches the revision captured
 * when the response was cached. If another trusted path changes controller
 * state/revision, the stale cache entry is bypassed and the request is
 * evaluated again against current state.
 *
 * This is intentionally NOT a general anti-replay/security mechanism. The
 * cache covers only the immediately previous request in the current transport
 * session. The Android adapter must serialize requests (one outstanding at a
 * time) and call okn_control_session_reset() on disconnect/reconnect.
 */
typedef struct {
    okn_controller_t *controller;
    bool cache_valid;
    uint8_t cached_request[OKN_CONTROL_MAX_FRAME];
    size_t cached_request_len;
    uint8_t cached_response[OKN_CONTROL_MAX_FRAME];
    size_t cached_response_len;
    okn_status_t cached_command_status;
    bool cached_command_evaluated;
    uint32_t cached_controller_revision;
    uint32_t executed_requests;
    uint32_t duplicate_replays;
    uint32_t stale_cache_misses;
} okn_control_session_t;

typedef struct {
    okn_protocol_result_t protocol;
    bool duplicate_replayed;
    size_t required_response_len;
} okn_control_session_result_t;

void okn_control_session_init(okn_control_session_t *session, okn_controller_t *controller);

/* Clear duplicate history at a transport session boundary. Statistics are
 * preserved so diagnostics can observe retry behavior across reconnects. */
void okn_control_session_reset(okn_control_session_t *session);

okn_control_session_result_t okn_control_session_execute(okn_control_session_t *session,
                                                         const uint8_t *request,
                                                         size_t request_len,
                                                         uint8_t *response,
                                                         size_t response_cap);

#endif
