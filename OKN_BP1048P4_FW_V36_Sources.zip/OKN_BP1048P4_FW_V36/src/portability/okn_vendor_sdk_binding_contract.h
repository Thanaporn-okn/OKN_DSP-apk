#ifndef OKN_VENDOR_SDK_BINDING_CONTRACT_H
#define OKN_VENDOR_SDK_BINDING_CONTRACT_H

/*
 * V36 compile-only vendor SDK binding contract.
 *
 * A reviewed exact-target shim may include vendor headers and define these
 * macros. This contract checks shape only; it never proves hardware identity,
 * board routing, linker layout, programmer transport, or flash safety.
 */
#define OKN_VENDOR_SDK_BINDING_CONTRACT_ABI 1u

#ifndef OKN_VENDOR_BINDING_ABI
#error "OKN_VENDOR_BINDING_ABI must be defined by the reviewed vendor shim"
#endif
#ifndef OKN_VENDOR_EVIDENCE_EXACT_BP1048P4
#error "OKN_VENDOR_EVIDENCE_EXACT_BP1048P4 must be defined"
#endif
#ifndef OKN_VENDOR_EVIDENCE_EXACT_GOLOPINE_BOARD
#error "OKN_VENDOR_EVIDENCE_EXACT_GOLOPINE_BOARD must be defined"
#endif
#ifndef OKN_VENDOR_BINDING_HAS_PLATFORM_INIT
#error "OKN_VENDOR_BINDING_HAS_PLATFORM_INIT must be defined"
#endif
#ifndef OKN_VENDOR_BINDING_HAS_OUTPUT_SAFETY_MUTE
#error "OKN_VENDOR_BINDING_HAS_OUTPUT_SAFETY_MUTE must be defined"
#endif
#ifndef OKN_VENDOR_BINDING_HAS_AUDIO_START
#error "OKN_VENDOR_BINDING_HAS_AUDIO_START must be defined"
#endif
#ifndef OKN_VENDOR_BINDING_HAS_AUDIO_APPLY
#error "OKN_VENDOR_BINDING_HAS_AUDIO_APPLY must be defined"
#endif
#ifndef OKN_VENDOR_BINDING_HAS_BLE_NOTIFY
#error "OKN_VENDOR_BINDING_HAS_BLE_NOTIFY must be defined"
#endif
#ifndef OKN_VENDOR_BINDING_HAS_NVM
#error "OKN_VENDOR_BINDING_HAS_NVM must be defined"
#endif

#if OKN_VENDOR_BINDING_ABI != OKN_VENDOR_SDK_BINDING_CONTRACT_ABI
#error "vendor binding ABI mismatch"
#endif

/* Exact-target acceptance is intentionally separate from basic ABI shape. */
#ifdef OKN_VENDOR_REQUIRE_EXACT_TARGET
# if OKN_VENDOR_EVIDENCE_EXACT_BP1048P4 != 1
#  error "exact BP1048P4 evidence is required"
# endif
# if OKN_VENDOR_EVIDENCE_EXACT_GOLOPINE_BOARD != 1
#  error "exact GoloPine board evidence is required"
# endif
#endif

/* The shim must explicitly state which adapter-facing groups it binds. */
#if (OKN_VENDOR_BINDING_HAS_PLATFORM_INIT != 0) && (OKN_VENDOR_BINDING_HAS_PLATFORM_INIT != 1)
#error "platform-init capability must be 0 or 1"
#endif
#if (OKN_VENDOR_BINDING_HAS_OUTPUT_SAFETY_MUTE != 0) && (OKN_VENDOR_BINDING_HAS_OUTPUT_SAFETY_MUTE != 1)
#error "safety-mute capability must be 0 or 1"
#endif
#if (OKN_VENDOR_BINDING_HAS_AUDIO_START != 0) && (OKN_VENDOR_BINDING_HAS_AUDIO_START != 1)
#error "audio-start capability must be 0 or 1"
#endif
#if (OKN_VENDOR_BINDING_HAS_AUDIO_APPLY != 0) && (OKN_VENDOR_BINDING_HAS_AUDIO_APPLY != 1)
#error "audio-apply capability must be 0 or 1"
#endif
#if (OKN_VENDOR_BINDING_HAS_BLE_NOTIFY != 0) && (OKN_VENDOR_BINDING_HAS_BLE_NOTIFY != 1)
#error "BLE capability must be 0 or 1"
#endif
#if (OKN_VENDOR_BINDING_HAS_NVM != 0) && (OKN_VENDOR_BINDING_HAS_NVM != 1)
#error "NVM capability must be 0 or 1"
#endif

#endif
