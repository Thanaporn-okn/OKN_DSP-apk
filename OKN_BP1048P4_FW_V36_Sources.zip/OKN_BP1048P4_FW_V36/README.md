# OKN_BP1048P4_FW_V36

V36 hardens the portable control-session replay cache while keeping Protocol V2 and persistence schema 2 unchanged.

## What V36 adds

- Exact duplicate requests are replayed from cache only while the controller revision still matches the revision captured when the response was cached.
- If another trusted controller path changes state/revision, an exact-byte retry bypasses the stale cache and is evaluated again against current state.
- Adds `cached_controller_revision` and `stale_cache_misses` diagnostics.
- Adds mutating `SET_CH_GAIN` regression coverage proving stale cached ACKs cannot mask a later controller mutation.
- Adds read-only capability-query regression coverage proving a changed controller revision cannot replay stale capability data.
- Preserves V35 stream consume-before-callback and same-stream reentrancy protections.
- V35 Source ZIP and uploaded GitHub validation Artifact are bound as the immediate predecessor.

## Safety status

This package is **not** a BP1048P4/GoloPine flash image. It emits no programmer packet, does not invoke a target linker, and contains no guessed BP1048P4 address, pin, boot command, memory capacity, or image format. Hardware and mobile flashing remain locked.

Run:

```sh
make host-test
```
