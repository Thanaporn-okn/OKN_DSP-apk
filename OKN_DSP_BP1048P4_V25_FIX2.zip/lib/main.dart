import 'package:flutter/material.dart';

void main() => runApp(const OKNDSP());

class OKNDSP extends StatelessWidget {
  const OKNDSP({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: const Color(0xff101018),
        body: Center(
          child: Text(
            'OKN_DSP BP1048P4 V25 FIX2\nFlutter Build Ready',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.cyan, fontSize: 24),
          ),
        ),
      ),
    );
  }
}
