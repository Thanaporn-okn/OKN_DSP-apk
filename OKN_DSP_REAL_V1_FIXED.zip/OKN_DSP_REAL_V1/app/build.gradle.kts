plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

kotlin { jvmToolchain(17) }

android {
    namespace = "com.okn.dspreal"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.okn.dspreal"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0-real-v1"
    }
}
