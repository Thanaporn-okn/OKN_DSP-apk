package com.okn.dspreal.protocol

import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Confirmed TX crypto:
 * AES/CFB8/NoPadding, key = 16-byte RandKey, IV = 01 repeated 16 times.
 * The Cipher instance MUST remain continuous for the whole session.
 */
class SessionTxCipher(randKey: ByteArray) {
    init { require(randKey.size == 16) }
    private val cipher = Cipher.getInstance("AES/CFB8/NoPadding").apply {
        init(Cipher.ENCRYPT_MODE, SecretKeySpec(randKey.copyOf(), "AES"), IvParameterSpec(ByteArray(16) { 0x01 }))
    }
    fun next(plain: ByteArray): ByteArray = cipher.update(plain) ?: byteArrayOf()
}
