package com.okn.dspreal.protocol

data class AuthHeader(val typeId: Int, val versionId: Int, val raw: ByteArray)

object AuthProtocol {
    // Observed unencrypted AB01 write at the start of every captured official-app session.
    val REQUEST = Hex.parse("631C062443FD3844558001F3EDA0CCF8")

    // First encrypted TX plaintext after successful authentication.
    val DEVICE_DESCRIPTION_PLAIN = Hex.parse("661C0624")

    fun parseResponse32(bytes: ByteArray): AuthHeader {
        require(bytes.size == 32)
        return AuthHeader(ByteCodec.readU16be(bytes, 0), ByteCodec.readU16be(bytes, 2), bytes.copyOf())
    }
}
