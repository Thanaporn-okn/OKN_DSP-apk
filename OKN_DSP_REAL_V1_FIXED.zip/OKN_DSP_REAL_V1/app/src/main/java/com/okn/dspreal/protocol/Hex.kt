package com.okn.dspreal.protocol

object Hex {
    fun parse(text: String): ByteArray {
        val s = text.filterNot { it.isWhitespace() || it == ':' || it == '-' }
        require(s.length % 2 == 0) { "HEX ต้องมีจำนวนตัวอักษรเป็นเลขคู่" }
        require(s.all { it.digitToIntOrNull(16) != null }) { "HEX ไม่ถูกต้อง" }
        return ByteArray(s.length / 2) { i -> s.substring(i * 2, i * 2 + 2).toInt(16).toByte() }
    }

    fun of(bytes: ByteArray): String = bytes.joinToString("") { "%02X".format(it.toInt() and 0xff) }
}
