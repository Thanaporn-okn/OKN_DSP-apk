package com.okn.dspreal.dsp

import com.okn.dspreal.protocol.ByteCodec
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

object EqBandCodec {
    const val PEAKING = 12
    const val FS = 44100.0

    /** Confirmed 48-byte band record: INT32 LE type + 11 FLOAT32 LE fields. */
    fun peaking(frequencyHz: Double, q: Double, boostDb: Double): ByteArray {
        require(frequencyHz > 0.0 && frequencyHz < FS / 2)
        require(q > 0.0)
        val a = 10.0.pow(boostDb / 40.0)
        val w0 = 2.0 * PI * frequencyHz / FS
        val alpha = sin(w0) / (2.0 * q)
        val a0 = 1.0 + alpha / a
        val b0 = (1.0 + alpha * a) / a0
        val b1 = (-2.0 * cos(w0)) / a0
        val b2 = (1.0 - alpha * a) / a0
        val a1 = (-2.0 * cos(w0)) / a0
        val a2 = (1.0 - alpha / a) / a0
        return ByteCodec.i32le(PEAKING) +
            ByteCodec.f32le(frequencyHz.toFloat()) + ByteCodec.f32le(0f) +
            ByteCodec.f32le(q.toFloat()) + ByteCodec.f32le(boostDb.toFloat()) +
            ByteCodec.f32le(0f) + ByteCodec.f32le(0f) +
            ByteCodec.f32le(b0.toFloat()) + ByteCodec.f32le(b1.toFloat()) +
            ByteCodec.f32le(b2.toFloat()) + ByteCodec.f32le(a1.toFloat()) + ByteCodec.f32le(a2.toFloat())
    }
}
