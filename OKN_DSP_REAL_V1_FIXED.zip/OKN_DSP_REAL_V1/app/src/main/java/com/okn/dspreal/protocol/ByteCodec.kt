package com.okn.dspreal.protocol

import java.nio.ByteBuffer
import java.nio.ByteOrder

object ByteCodec {
    fun u16be(v: Int) = byteArrayOf((v ushr 8).toByte(), v.toByte())
    fun u32be(v: Int) = byteArrayOf((v ushr 24).toByte(), (v ushr 16).toByte(), (v ushr 8).toByte(), v.toByte())
    fun i32le(v: Int): ByteArray = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(v).array()
    fun f32le(v: Float): ByteArray = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putFloat(v).array()
    fun readU16be(b: ByteArray, off: Int): Int = ((b[off].toInt() and 0xff) shl 8) or (b[off + 1].toInt() and 0xff)
}
