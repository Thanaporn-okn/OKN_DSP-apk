package com.okn.dspreal.dsp

object DspMap {
    const val MASTER_VOLUME = 2
    const val REMIND_SOUND_VOLUME = 3
    const val BASS_VOLUME = 8
    const val BASS_CUTOFF = 9
    const val BASS_BOOST = 10
    const val TREBLE_BOOST = 11
    const val MIDDLE_BOOST = 13

    private val EQ = intArrayOf(4, 5, 6, 14, 15, 16, 17)
    fun eqActuator(channel1Based: Int): Int = EQ[channel1Based - 1]
    fun eqOffset(band1Based: Int): Int = (band1Based - 1) * 48
}
