package com.okn.dspreal.protocol

/** Confirmed from decrypted official-app HCI traffic. */
object UfeCodec {
    const val WRITE_ACTUATOR = 0x57
    const val READ_SENSOR_ACTUATOR = 0x58

    fun read(actuatorId: Int, offset: Int, length: Int): ByteArray =
        byteArrayOf(READ_SENSOR_ACTUATOR.toByte()) + ByteCodec.u32be(actuatorId) + ByteCodec.u16be(offset) + ByteCodec.u16be(length)

    fun write(actuatorId: Int, offset: Int, data: ByteArray): ByteArray =
        byteArrayOf(WRITE_ACTUATOR.toByte()) + ByteCodec.u32be(actuatorId) + ByteCodec.u16be(offset) + ByteCodec.u16be(data.size) + data

    fun writeFloat(actuatorId: Int, value: Float): ByteArray = write(actuatorId, 0, ByteCodec.f32le(value))
}
