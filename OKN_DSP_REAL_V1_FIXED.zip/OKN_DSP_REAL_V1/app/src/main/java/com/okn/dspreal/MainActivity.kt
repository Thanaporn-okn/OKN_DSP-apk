package com.okn.dspreal

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.widget.*
import com.okn.dspreal.ble.BleProfile
import com.okn.dspreal.ble.GoloBleTransport
import com.okn.dspreal.dsp.DspCommandEngine
import com.okn.dspreal.dsp.DspMap
import com.okn.dspreal.dsp.ObservedCommands
import com.okn.dspreal.protocol.AuthProtocol
import com.okn.dspreal.protocol.Hex

class MainActivity : Activity(), GoloBleTransport.Listener {
    private lateinit var transport: GoloBleTransport
    private lateinit var engine: DspCommandEngine
    private lateinit var status: TextView
    private lateinit var devices: LinearLayout
    private lateinit var logView: TextView
    private lateinit var keyInput: EditText
    private var ready = false
    private var authResponse: ByteArray? = null
    private val handler = Handler(Looper.getMainLooper())
    private val found = linkedMapOf<String, BluetoothDevice>()
    private val scanner get() = getSystemService(BluetoothManager::class.java)?.adapter?.bluetoothLeScanner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        transport = GoloBleTransport(this, this)
        engine = DspCommandEngine(transport) { appendLog(it) }
        buildUi()
        requestPermissionsIfNeeded()
    }

    override fun onDestroy() {
        try { scanner?.stopScan(scanCb) } catch (_: Exception) {}
        transport.close()
        super.onDestroy()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 20, 24, 32) }
        root.addView(TextView(this).apply { text = "OKN DSP REAL V1"; textSize = 24f })
        root.addView(TextView(this).apply {
            text = "เริ่มใหม่จากหลักฐานจริง • AB00/AB01/AB02 • UFE 0x57/0x58 • AES-CFB8 continuous TX"
            textSize = 13f
        })
        status = TextView(this).apply { text = "DISCONNECTED"; textSize = 15f; setPadding(0, 12, 0, 12) }
        root.addView(status)

        root.addView(Button(this).apply { text = "1) SCAN DSP"; setOnClickListener { startScan() } })
        devices = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(devices)

        section(root, "AUTH / SESSION")
        root.addView(Button(this).apply {
            text = "2) SEND REAL AUTH REQUEST"
            setOnClickListener { runReal { requireReady(); engine.sendAuthRequest() } }
        })
        root.addView(TextView(this).apply {
            text = "AUTH RAW = 631C062443FD3844558001F3EDA0CCF8\nรอ RX 32 bytes ก่อนตั้ง RandKey"
            textSize = 12f
        })
        keyInput = EditText(this).apply {
            hint = "RandKey ของ session ปัจจุบัน: 32 hex chars"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setSingleLine(true)
        }
        root.addView(keyInput)
        root.addView(Button(this).apply {
            text = "3) SET RANDKEY + REQUEST DEVICE DESCRIPTION"
            setOnClickListener {
                runReal {
                    require(authResponse?.size == 32) { "ยังไม่ได้รับ auth response 32 bytes ของ session นี้" }
                    val key = Hex.parse(keyInput.text.toString())
                    require(key.size == 16) { "RandKey ต้องยาว 16 bytes / 32 hex" }
                    engine.setRandKeyAndRequestDescriptor(key)
                }
            }
        })
        root.addView(TextView(this).apply {
            text = "ข้อจำกัด V1: วิธีถอด RandKey จาก auth response 32B แบบอัตโนมัติยังไม่ยืนยัน จึงไม่สร้างสูตรเดา. เมื่อใส่ key ของ session นี้แล้ว เส้น TX หลังจากนี้เป็นคำสั่งจริงทั้งหมด."
            textSize = 12f
        })

        section(root, "REAL COMMAND LAB")
        root.addView(Button(this).apply { text = "READ MASTER • ID 2 • 4 bytes"; setOnClickListener { runReal { engine.readMaster() } } })

        val master = EditText(this).apply { hint = "Master float เช่น -13.76"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED }
        root.addView(master)
        root.addView(Button(this).apply {
            text = "WRITE MASTER FLOAT • ID 2"
            setOnClickListener { runReal { engine.writeMaster(master.text.toString().toFloat()) } }
        })
        root.addView(Button(this).apply {
            text = "REAL CAPTURE: MASTER -13.76 dB"
            setOnClickListener { runReal { engine.observed("MASTER -13.76", ObservedCommands.MASTER_MINUS_13_76) } }
        })

        val scalarIds = linkedMapOf(
            "Bass Volume • ID8" to DspMap.BASS_VOLUME,
            "Bass Cutoff • ID9" to DspMap.BASS_CUTOFF,
            "Bass Boost • ID10" to DspMap.BASS_BOOST,
            "Treble Boost • ID11" to DspMap.TREBLE_BOOST,
            "MiddleBoost • ID13" to DspMap.MIDDLE_BOOST,
        )
        val scalarSpinner = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, scalarIds.keys.toList()) }
        val scalarValue = EditText(this).apply { hint = "FLOAT32 value"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED }
        root.addView(scalarSpinner); root.addView(scalarValue)
        root.addView(Button(this).apply {
            text = "WRITE VERIFIED-MAPPED SCALAR"
            setOnClickListener {
                runReal {
                    val id = scalarIds.values.elementAt(scalarSpinner.selectedItemPosition)
                    engine.writeScalar(id, scalarValue.text.toString().toFloat())
                }
            }
        })

        section(root, "EQ 15-BAND • REAL WRITE")
        val ch = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, (1..7).map { "CH$it • ID${DspMap.eqActuator(it)}" }) }
        val band = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, (1..15).map { "Band $it • offset ${DspMap.eqOffset(it)}" }) }
        val f = EditText(this).apply { hint = "Frequency Hz เช่น 251.6"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL }
        val q = EditText(this).apply { hint = "Q เช่น 2.23"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL }
        val db = EditText(this).apply { hint = "Boost dB เช่น 12.48"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED }
        root.addView(ch); root.addView(band); root.addView(f); root.addView(q); root.addView(db)
        root.addView(Button(this).apply {
            text = "WRITE PEAKING EQ • 48-BYTE BAND"
            setOnClickListener {
                runReal {
                    engine.writeEqPeaking(ch.selectedItemPosition + 1, band.selectedItemPosition + 1, f.text.toString().toDouble(), q.text.toString().toDouble(), db.text.toString().toDouble())
                }
            }
        })
        root.addView(Button(this).apply { text = "REAL CAPTURE: CH1 B6 +12.48 dB"; setOnClickListener { runReal { engine.observed("CH1 B6 +12.48", ObservedCommands.CH1_B6_12_48) } } })
        root.addView(Button(this).apply { text = "REAL CAPTURE: CH2 B6 +8.16 dB"; setOnClickListener { runReal { engine.observed("CH2 B6 +8.16", ObservedCommands.CH2_B6_8_16) } } })
        root.addView(Button(this).apply { text = "REAL CAPTURE: CH1 B6 +18.72 dB"; setOnClickListener { runReal { engine.observed("CH1 B6 +18.72", ObservedCommands.CH1_B6_18_72) } } })

        section(root, "LIVE LOG")
        logView = TextView(this).apply { textSize = 11f; setTextIsSelectable(true); gravity = Gravity.START; text = "" }
        root.addView(logView)
        root.addView(Button(this).apply { text = "CLEAR LOG"; setOnClickListener { logView.text = "" } })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun section(root: LinearLayout, title: String) {
        root.addView(TextView(this).apply { text = title; textSize = 19f; setPadding(0, 22, 0, 8) })
    }

    private fun requestPermissionsIfNeeded() {
        val p = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) p += Manifest.permission.BLUETOOTH_SCAN
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) p += Manifest.permission.BLUETOOTH_CONNECT
        } else if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            p += Manifest.permission.ACCESS_FINE_LOCATION
        }
        if (p.isNotEmpty()) requestPermissions(p.toTypedArray(), 100)
    }

    private fun permitted(): Boolean = if (Build.VERSION.SDK_INT >= 31) {
        checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
    } else checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun startScan() {
        if (!permitted()) { requestPermissionsIfNeeded(); toast("อนุญาต Bluetooth/Location แล้วกด Scan อีกครั้ง"); return }
        val a = getSystemService(BluetoothManager::class.java)?.adapter
        if (a == null || !a.isEnabled) { toast("กรุณาเปิด Bluetooth"); return }
        found.clear(); devices.removeAllViews(); status.text = "SCANNING 10s"
        try { scanner?.startScan(scanCb) } catch (e: Exception) { toast(e.message ?: "scan error") }
        handler.postDelayed({ try { scanner?.stopScan(scanCb) } catch (_: Exception) {}; if (!ready) status.text = "SCAN FINISHED" }, 10_000)
    }

    private val scanCb: ScanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val d = result.device
            if (found.containsKey(d.address)) return
            val name = result.scanRecord?.deviceName ?: try { d.name } catch (_: Exception) { null }
            val serviceSeen = result.scanRecord?.serviceUuids?.any { it.uuid == BleProfile.SERVICE } == true
            if (!(serviceSeen || name?.contains("GoloPine", true) == true || name?.contains("DSP", true) == true)) return
            found[d.address] = d
            runOnUiThread {
                devices.addView(Button(this@MainActivity).apply {
                    text = "${name ?: "BLE DSP"} • ${d.address}\nCONNECT"
                    setOnClickListener {
                        stopBleScanSafely()
                        ready = false; authResponse = null; engine.resetSession(); transport.connect(d)
                    }
                })
            }
        }
    }

    private fun stopBleScanSafely() {
        try {
            scanner?.stopScan(scanCb)
        } catch (_: Exception) {
        }
    }

    override fun onState(text: String) = runOnUiThread { status.text = text; appendLog("STATE $text") }
    override fun onReady() = runOnUiThread { ready = true; appendLog("BLE READY: AB01 write-no-response / AB02 notify") }
    override fun onNotify(bytes: ByteArray) = runOnUiThread {
        appendLog("RX ${bytes.size}B ${Hex.of(bytes)}")
        if (bytes.size == 32 && authResponse == null) {
            authResponse = bytes.copyOf()
            val h = AuthProtocol.parseResponse32(bytes)
            appendLog("AUTH32 typeID=${h.typeId} versionID=${h.versionId}")
            status.text = "AUTH RESPONSE 32B • type=${h.typeId} version=${h.versionId} • WAIT RANDKEY"
        }
    }

    private fun requireReady() { require(ready) { "BLE ยังไม่ READY" } }
    private inline fun runReal(block: () -> Unit) {
        try { block() } catch (e: Exception) { toast(e.message ?: e.javaClass.simpleName); appendLog("ERROR ${e.message}") }
    }
    private fun appendLog(s: String) { if (::logView.isInitialized) logView.append(s + "\n") }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
