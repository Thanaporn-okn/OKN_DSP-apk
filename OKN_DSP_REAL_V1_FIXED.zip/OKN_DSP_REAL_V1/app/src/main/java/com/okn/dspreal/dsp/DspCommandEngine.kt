package com.okn.dspreal.dsp

import com.okn.dspreal.ble.GoloBleTransport
import com.okn.dspreal.protocol.AuthProtocol
import com.okn.dspreal.protocol.Hex
import com.okn.dspreal.protocol.SessionTxCipher
import com.okn.dspreal.protocol.UfeCodec

class DspCommandEngine(
    private val transport: GoloBleTransport,
    private val log: (String) -> Unit,
) {
    private var txCipher: SessionTxCipher? = null

    fun resetSession() { txCipher = null }

    fun sendAuthRequest(): Boolean {
        resetSession()
        val p = AuthProtocol.REQUEST
        log("TX RAW AUTH   ${Hex.of(p)}")
        return transport.writeNoResponse(p)
    }

    /** Initialize only with the RandKey belonging to the CURRENT 32-byte auth response. */
    fun setRandKeyAndRequestDescriptor(randKey: ByteArray): Boolean {
        txCipher = SessionTxCipher(randKey)
        return sendEncrypted(AuthProtocol.DEVICE_DESCRIPTION_PLAIN, "DEVICE DESCRIPTION")
    }

    fun readMaster(): Boolean = sendEncrypted(UfeCodec.read(DspMap.MASTER_VOLUME, 0, 4), "READ MASTER ID=2")
    fun writeMaster(value: Float): Boolean = sendEncrypted(UfeCodec.writeFloat(DspMap.MASTER_VOLUME, value), "WRITE MASTER ID=2 value=$value")
    fun writeScalar(id: Int, value: Float): Boolean = sendEncrypted(UfeCodec.writeFloat(id, value), "WRITE FLOAT ID=$id value=$value")

    fun writeEqPeaking(channel: Int, band: Int, frequencyHz: Double, q: Double, boostDb: Double): Boolean {
        val payload = EqBandCodec.peaking(frequencyHz, q, boostDb)
        return sendEncrypted(UfeCodec.write(DspMap.eqActuator(channel), DspMap.eqOffset(band), payload), "WRITE EQ CH$channel BAND$band")
    }

    fun observed(label: String, plain: ByteArray): Boolean = sendEncrypted(plain, "OBSERVED $label")

    private fun sendEncrypted(plain: ByteArray, label: String): Boolean {
        val cipher = txCipher ?: error("ยังไม่ได้ตั้ง RandKey ของ session นี้")
        val encrypted = cipher.next(plain)
        log("TX PLAIN [$label] ${Hex.of(plain)}")
        log("TX CIPHER[$label] ${Hex.of(encrypted)}")
        val ok = transport.writeNoResponse(encrypted)
        if (!ok) log("!! BLE WRITE FAILED")
        return ok
    }
}
