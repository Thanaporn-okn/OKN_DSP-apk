package com.okn.dspreal.ble

import java.util.UUID

object BleProfile {
    const val DEVICE_NAME = "GoloPineDSPAudioTurning"
    val SERVICE = UUID.fromString("0000ab00-0000-1000-8000-00805f9b34fb")
    val WRITE = UUID.fromString("0000ab01-0000-1000-8000-00805f9b34fb")
    val NOTIFY = UUID.fromString("0000ab02-0000-1000-8000-00805f9b34fb")
    val NOTIFY_SECONDARY = UUID.fromString("0000ab03-0000-1000-8000-00805f9b34fb")
    val CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
}
