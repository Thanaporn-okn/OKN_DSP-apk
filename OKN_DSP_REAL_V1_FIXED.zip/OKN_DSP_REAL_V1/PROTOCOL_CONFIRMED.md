# Confirmed protocol baseline

## BLE
- Service AB00
- AB01 write value handle observed as 0x0006
- AB02 notify value handle observed as 0x0008
- Android write type: NO_RESPONSE, matching ATT opcode 0x52 captures

## Authentication/session
- Fixed 16-byte raw auth request: 631C062443FD3844558001F3EDA0CCF8
- Auth response length: 32 bytes
- Response bytes 0..1 = TypeID BE; bytes 2..3 = VersionID BE
- RandKey: 16 bytes; official runtime logs print it per session
- TX crypto: AES-CFB8, no padding
- Key: current session RandKey
- IV: 01 repeated 16 bytes
- TX stream is continuous; do not reset cipher between packets
- First encrypted plaintext: 661C0624 (device-description request)

## UFE
- 0x57 WRITE_ACTUATOR
- 0x58 READ_SENSOR_ACTUATOR
- integer header fields: big endian
- scalar FLOAT32 payload: little endian

## Real decrypted writes from capture
- Master ID2 -13.76: 570000000200000004F6285CC1
- CH1 EQ ID4 band6 offset240 length48 +12.48 dB: see `ObservedCommands.kt`
- CH2 EQ ID5 band6 offset240 length48 +8.16 dB: see `ObservedCommands.kt`
- CH1 EQ ID4 band6 offset240 length48 +18.72 dB: see `ObservedCommands.kt`

## Not guessed
- Automatic RandKey extraction from the 32-byte auth response is intentionally not implemented until recovered from the reference binary.
- SAVE_PARAMS ID7 is not exposed as a write because its payload semantics are not yet proven.
