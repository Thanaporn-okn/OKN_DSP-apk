package com.okn.dspcontroller

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
