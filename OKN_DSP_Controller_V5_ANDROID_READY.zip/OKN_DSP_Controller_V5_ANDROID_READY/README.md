# OKN DSP Controller V5 Android Ready

Flutter Android structure ready for GitHub Actions APK build.

Run:
flutter pub get
flutter build apk --release
