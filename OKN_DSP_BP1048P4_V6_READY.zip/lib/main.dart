
import 'package:flutter/material.dart';

void main()=>runApp(const App());

class App extends StatelessWidget{
 const App({super.key});
 Widget build(BuildContext c)=>MaterialApp(
  theme:ThemeData.dark(),
  home:const DSP()
 );
}

class DSP extends StatefulWidget{
 const DSP({super.key});
 State<DSP> createState()=>_DSPState();
}

class _DSPState extends State<DSP>{
 int ch=1;
 double delay=0;
 final freq=['31Hz','62Hz','125Hz','250Hz','500Hz','1kHz','2kHz','4kHz','8kHz','16kHz'];
 final eq=List<double>.filled(10,0);

 Widget build(BuildContext c)=>Scaffold(
 appBar:AppBar(title:const Text('OKN_DSP BP1048P4 V6')),
 body:ListView(
 padding:const EdgeInsets.all(16),
 children:[
 Text('Channel CH$ch'),
 DropdownButton<int>(
 value:ch,
 items:List.generate(7,(i)=>DropdownMenuItem(
 value:i+1,child:Text('CH${i+1}'))),
 onChanged:(v)=>setState(()=>ch=v!)
 ),
 const Text('EQ'),
 ...List.generate(freq.length,(i)=>Column(children:[
 Text(freq[i]),
 Slider(value:eq[i],min:-12,max:12,
 onChanged:(v)=>setState(()=>eq[i]=v))
 ])),
 const Divider(),
 Text('Delay ${delay.toStringAsFixed(1)} ms'),
 Slider(value:delay,min:0,max:20,
 onChanged:(v)=>setState(()=>delay=v)),
 const Text('Crossover HPF / LPF ready'),
 ElevatedButton(onPressed:(){},child:const Text('Save Preset'))
 ])
 );
}
