package com.okn.dsp

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View

/** Small self-drawn crossover response graph matching the supplied reference style. */
class FilterCurveView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : View(context, attrs, defStyleAttr) {
    var highPass: Boolean = true
    var enabledCurve: Boolean = true
    var accentColor: Int = Color.GREEN
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private fun dp(v: Float)=v*resources.displayMetrics.density

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w=width.toFloat(); val h=height.toFloat()
        p.style=Paint.Style.STROKE; p.strokeWidth=dp(.7f); p.color=Color.rgb(30,48,57)
        for(i in 1..7){val x=w*i/8f;c.drawLine(x,0f,x,h,p)}
        for(i in 1..4){val y=h*i/5f;c.drawLine(0f,y,w,y,p)}
        val path=Path()
        if(highPass){
            path.moveTo(0f,h*.82f); path.cubicTo(w*.22f,h*.82f,w*.28f,h*.35f,w*.42f,h*.18f); path.cubicTo(w*.55f,h*.08f,w*.75f,h*.08f,w,h*.08f)
        } else {
            path.moveTo(0f,h*.08f); path.cubicTo(w*.28f,h*.08f,w*.45f,h*.08f,w*.58f,h*.18f); path.cubicTo(w*.72f,h*.35f,w*.78f,h*.82f,w,h*.82f)
        }
        p.strokeWidth=dp(1.7f); p.color=if(enabledCurve)accentColor else Color.rgb(87,92,96); c.drawPath(path,p)
        p.style=Paint.Style.FILL
    }
}
