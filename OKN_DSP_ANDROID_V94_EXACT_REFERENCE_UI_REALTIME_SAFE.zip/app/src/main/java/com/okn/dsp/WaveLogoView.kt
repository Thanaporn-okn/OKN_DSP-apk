package com.okn.dsp

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import kotlin.math.abs

class WaveLogoView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#17C9FF")
        strokeWidth = resources.displayMetrics.density * 3f
        strokeCap = Paint.Cap.ROUND
    }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val d = resources.displayMetrics.density
        val heights = floatArrayOf(8f,18f,30f,43f,55f,37f,29f,20f,12f,7f)
        val gap = 8f * d
        val start = cx - gap * (heights.size - 1) / 2f
        heights.forEachIndexed { i, h ->
            val hh = h * d * 0.48f
            val x = start + i * gap
            canvas.drawLine(x, cy - hh, x, cy + hh, paint)
        }
    }
}
