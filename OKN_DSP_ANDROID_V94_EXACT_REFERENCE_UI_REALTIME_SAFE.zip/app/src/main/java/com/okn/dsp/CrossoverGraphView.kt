package com.okn.dsp

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import kotlin.math.log10
import kotlin.math.pow

class CrossoverGraphView(context: Context) : View(context) {
    var hpfEnabled = true
    var lpfEnabled = true
    var hpfHz = 80f
    var lpfHz = 8000f
    private val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#20323D"); strokeWidth = 1f }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#B9C8D0"); textSize = 9f * resources.displayMetrics.scaledDensity }
    private val hpPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#16B9FF"); style = Paint.Style.STROKE; strokeWidth = 2.5f * resources.displayMetrics.density }
    private val midPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#21E04F"); style = Paint.Style.STROKE; strokeWidth = 2.2f * resources.displayMetrics.density }
    private val lpPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FF9B18"); style = Paint.Style.STROKE; strokeWidth = 2.5f * resources.displayMetrics.density }
    private fun xForHz(hz: Float, left: Float, right: Float): Float {
        val p = ((log10(hz.coerceIn(20f, 20000f).toDouble()) - log10(20.0)) / (log10(20000.0) - log10(20.0))).toFloat()
        return left + p * (right - left)
    }
    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val d = resources.displayMetrics.density
        val left = 34f*d; val right = width - 8f*d; val top = 10f*d; val bottom = height - 24f*d
        listOf(0,-12,-24,-36,-48).forEachIndexed { i,v ->
            val y = top + i * (bottom-top)/4f; c.drawLine(left,y,right,y,grid); c.drawText(v.toString(),2f*d,y+3f*d,textPaint)
        }
        val ticks = listOf(20f,50f,100f,200f,500f,1000f,2000f,5000f,10000f,20000f)
        ticks.forEach { hz -> val x=xForHz(hz,left,right); c.drawLine(x,top,x,bottom,grid); val label=if(hz>=1000) "${(hz/1000).toInt()}K" else hz.toInt().toString(); c.drawText(label,x-8f*d,height-5f*d,textPaint) }
        fun sigmoid(x:Float,cut:Float,high:Boolean):Float {
            val ratio = kotlin.math.ln((x/cut).coerceAtLeast(0.001f).toDouble()).toFloat()
            val t = 1f/(1f+kotlin.math.exp((-5.5f*ratio).toDouble()).toFloat())
            return if(high) t else 1f-t
        }
        if (hpfEnabled) {
            val p=Path(); var first=true
            for(i in 0..180){ val hz=(20.0 * 1000.0.pow(i/180.0)).toFloat(); val a=sigmoid(hz,hpfHz,true); val x=xForHz(hz,left,right); val y=bottom-a*(bottom-top); if(first){p.moveTo(x,y);first=false}else p.lineTo(x,y)}; c.drawPath(p,hpPaint)
        }
        if (lpfEnabled) {
            val p=Path(); var first=true
            for(i in 0..180){ val hz=(20.0 * 1000.0.pow(i/180.0)).toFloat(); val a=sigmoid(hz,lpfHz,false); val x=xForHz(hz,left,right); val y=bottom-a*(bottom-top); if(first){p.moveTo(x,y);first=false}else p.lineTo(x,y)}; c.drawPath(p,lpPaint)
        }
        val pass=Path(); var first=true
        for(i in 0..180){ val hz=(20.0 * 1000.0.pow(i/180.0)).toFloat(); val hp=if(hpfEnabled)sigmoid(hz,hpfHz,true) else 1f; val lp=if(lpfEnabled)sigmoid(hz,lpfHz,false) else 1f; val a=(hp*lp).coerceIn(0f,1f); val x=xForHz(hz,left,right); val y=bottom-a*(bottom-top); if(first){pass.moveTo(x,y);first=false}else pass.lineTo(x,y)}; c.drawPath(pass,midPaint)
    }
}
