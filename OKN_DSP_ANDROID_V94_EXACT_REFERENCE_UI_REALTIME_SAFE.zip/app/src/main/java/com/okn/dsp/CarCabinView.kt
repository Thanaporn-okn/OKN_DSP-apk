package com.okn.dsp

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

/** Self-drawn top-down cabin artwork used by the Delay page. */
class CarCabinView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : View(context, attrs, defStyleAttr) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private fun dp(v: Float) = v * resources.displayMetrics.density

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat(); val h = height.toFloat()

        // Four cyan speaker targets from the supplied DELAY reference.
        p.style = Paint.Style.STROKE
        p.strokeWidth = dp(1.2f)
        val speakers = listOf(w*.17f to h*.27f, w*.83f to h*.27f, w*.17f to h*.68f, w*.83f to h*.68f)
        speakers.forEach { (sx, sy) ->
            listOf(31f, 23f, 14f).forEachIndexed { idx, r ->
                p.color = when(idx) { 0 -> Color.rgb(5,60,98); 1 -> Color.rgb(7,102,158); else -> Color.rgb(32,177,242) }
                c.drawCircle(sx, sy, dp(r), p)
            }
            p.style = Paint.Style.FILL; p.color = Color.rgb(210,244,255); c.drawCircle(sx, sy, dp(4f), p); p.style = Paint.Style.STROKE
        }

        val body = RectF(w * .29f, h * .05f, w * .71f, h * .95f)
        p.style = Paint.Style.FILL
        p.color = Color.rgb(22, 28, 33)
        c.drawRoundRect(body, dp(34f), dp(34f), p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = dp(1.5f)
        p.color = Color.rgb(82, 93, 102)
        c.drawRoundRect(body, dp(34f), dp(34f), p)

        p.style = Paint.Style.FILL
        p.color = Color.rgb(10, 19, 25)
        c.drawRoundRect(RectF(w*.34f,h*.13f,w*.66f,h*.38f),dp(18f),dp(18f),p)
        c.drawRoundRect(RectF(w*.34f,h*.64f,w*.66f,h*.88f),dp(18f),dp(18f),p)

        fun seat(l:Float,t:Float,r:Float,b:Float){
            p.color=Color.rgb(47,52,57); c.drawRoundRect(RectF(l,t,r,b),dp(9f),dp(9f),p)
            p.style=Paint.Style.STROKE; p.strokeWidth=dp(1f); p.color=Color.rgb(92,99,105); c.drawRoundRect(RectF(l,t,r,b),dp(9f),dp(9f),p); p.style=Paint.Style.FILL
        }
        seat(w*.36f,h*.35f,w*.48f,h*.55f); seat(w*.52f,h*.35f,w*.64f,h*.55f)
        seat(w*.36f,h*.57f,w*.48f,h*.76f); seat(w*.52f,h*.57f,w*.64f,h*.76f)

        // centre console / dash accents
        p.color=Color.rgb(58,67,73)
        c.drawRoundRect(RectF(w*.47f,h*.19f,w*.53f,h*.69f),dp(4f),dp(4f),p)
        p.color=Color.rgb(21,201,255)
        c.drawCircle(w*.50f,h*.30f,dp(3.2f),p)

        // bonnet and tail contour
        val path=Path(); p.style=Paint.Style.STROKE; p.strokeWidth=dp(1f);p.color=Color.rgb(61,72,80)
        path.moveTo(w*.36f,h*.09f);path.quadTo(w*.50f,h*.01f,w*.64f,h*.09f);c.drawPath(path,p)
        path.reset();path.moveTo(w*.36f,h*.91f);path.quadTo(w*.50f,h*.99f,w*.64f,h*.91f);c.drawPath(path,p)
        p.style=Paint.Style.FILL
    }
}
