package com.okn.dsp

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.round

/** Reference-style vertical DSP fader with continuous touch tracking. */
class VerticalFaderView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : View(context, attrs, defStyleAttr) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var minValue = -60f
    private var maxValue = 6f
    private var value = -2f
    private var accent = Color.CYAN
    private var enabledForTouch = true
    var onValueChanged: ((Float) -> Unit)? = null
    var onTrackingStopped: ((Float) -> Unit)? = null

    fun configure(min: Float, max: Float, current: Float, color: Int, touchEnabled: Boolean = true) {
        minValue = min
        maxValue = max
        value = current.coerceIn(min, max)
        accent = color
        enabledForTouch = touchEnabled
        invalidate()
    }

    fun setValue(v: Float, notify: Boolean = false) {
        val next = v.coerceIn(minValue, maxValue)
        if (next == value) return
        value = next
        invalidate()
        if (notify) onValueChanged?.invoke(value)
    }

    fun getValue(): Float = value

    private fun dp(v: Float): Float = v * resources.displayMetrics.density

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width * 0.5f
        val top = dp(18f)
        val bottom = height - dp(18f)
        val trackW = dp(2f)

        paint.strokeWidth = dp(1f)
        paint.color = Color.rgb(47, 65, 75)
        for (i in 0..8) {
            val y = top + (bottom - top) * i / 8f
            canvas.drawLine(cx - dp(14f), y, cx - dp(7f), y, paint)
            canvas.drawLine(cx + dp(7f), y, cx + dp(14f), y, paint)
        }

        paint.color = Color.rgb(37, 58, 69)
        paint.strokeWidth = trackW
        canvas.drawLine(cx, top, cx, bottom, paint)

        val y = valueToY(value, top, bottom)
        paint.color = accent
        paint.strokeWidth = dp(2.4f)
        canvas.drawLine(cx, y, cx, bottom, paint)

        val thumb = RectF(cx - dp(10f), y - dp(6f), cx + dp(10f), y + dp(6f))
        paint.color = if (enabledForTouch) Color.rgb(221, 230, 236) else Color.rgb(108, 119, 126)
        canvas.drawRoundRect(thumb, dp(4f), dp(4f), paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = dp(1f)
        paint.color = if (enabledForTouch) Color.rgb(151, 164, 173) else Color.rgb(76, 86, 93)
        canvas.drawRoundRect(thumb, dp(4f), dp(4f), paint)
        paint.style = Paint.Style.FILL
    }

    private fun valueToY(v: Float, top: Float, bottom: Float): Float {
        val t = ((v - minValue) / (maxValue - minValue)).coerceIn(0f, 1f)
        return bottom - t * (bottom - top)
    }

    private fun yToValue(y: Float): Float {
        val top = dp(18f)
        val bottom = height - dp(18f)
        val t = ((bottom - y) / (bottom - top)).coerceIn(0f, 1f)
        return minValue + t * (maxValue - minValue)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!enabledForTouch || !isEnabled) return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                updateFromTouch(event.y)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                updateFromTouch(event.y)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                updateFromTouch(event.y)
                parent?.requestDisallowInterceptTouchEvent(false)
                onTrackingStopped?.invoke(value)
                performClick()
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun updateFromTouch(y: Float) {
        val raw = yToValue(y)
        val stepped = round(raw * 10f) / 10f
        if (stepped != value) {
            value = stepped.coerceIn(minValue, maxValue)
            invalidate()
            onValueChanged?.invoke(value)
        }
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
