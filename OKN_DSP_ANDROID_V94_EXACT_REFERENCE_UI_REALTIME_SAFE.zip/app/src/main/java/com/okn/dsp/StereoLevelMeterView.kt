package com.okn.dsp

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

class StereoLevelMeterView(context: Context) : View(context) {
    var leftLevel = .78f
    var rightLevel = .70f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.parseColor("#AFC0C9"); textSize=8f*resources.displayMetrics.scaledDensity }
    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val d=resources.displayMetrics.density
        val left=30f*d; val right=width-8f*d; val barW=right-left; val segs=22; val gap=2f*d; val segW=(barW-gap*(segs-1))/segs
        fun row(y:Float,level:Float,tag:String){
            c.drawText(tag,2f*d,y+9f*d,label)
            for(i in 0 until segs){
                val frac=(i+1f)/segs; p.color=when { frac<.66f->Color.parseColor("#20D63A"); frac<.88f->Color.parseColor("#E5F229"); else->Color.parseColor("#E83A28") }
                if(frac>level) p.alpha=35 else p.alpha=255
                val x=left+i*(segW+gap); c.drawRect(x,y,x+segW,y+10f*d,p)
            }; p.alpha=255
        }
        row(5f*d,leftLevel,"L"); row(22f*d,rightLevel,"R")
        listOf("-60","-40","-20","-10","-6","-3","0").forEachIndexed{i,s->c.drawText(s,left+i*(barW/6f)-7f*d,height-2f*d,label)}
    }
}
