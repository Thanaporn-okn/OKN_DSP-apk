#!/usr/bin/env python3
from pathlib import Path
import hashlib, re
root=Path(__file__).resolve().parent

def req(rel):
    p=root/rel
    assert p.is_file(), f"missing {rel}"
    return p

def txt(rel): return req(rel).read_text(encoding='utf-8', errors='replace')
def has(rel, marker): assert marker in txt(rel), f"missing marker {marker!r} in {rel}"
def sha(rel, expected):
    actual=hashlib.sha256(req(rel).read_bytes()).hexdigest()
    assert actual==expected, f"hash mismatch {rel}: {actual} != {expected}"

def balanced_kotlin(text):
    stack=[]; i=0; n=len(text); state='code'; quote=''; pairs={')':'(',']':'[','}':'{'}
    while i<n:
        c=text[i]; nxt=text[i+1] if i+1<n else ''
        if state=='line':
            if c=='\n': state='code'
        elif state=='block':
            if c=='*' and nxt=='/': state='code'; i+=1
        elif state=='string':
            if c=='\\': i+=1
            elif c==quote: state='code'
        elif state=='triple':
            if text.startswith('"""',i): state='code'; i+=2
        else:
            if c=='/' and nxt=='/': state='line'; i+=1
            elif c=='/' and nxt=='*': state='block'; i+=1
            elif text.startswith('"""',i): state='triple'; i+=2
            elif c in ('"',"'"): state='string'; quote=c
            elif c in '([{': stack.append(c)
            elif c in ')]}':
                assert stack and stack[-1]==pairs[c], f"unbalanced token at offset {i}: {c}"
                stack.pop()
        i+=1
    assert not stack, f"unclosed tokens: {stack[-10:]}"

U='app/src/main/java/com/okn/dsp/UnifiedControlActivity.kt'
G='app/build.gradle.kts'
M='app/src/main/AndroidManifest.xml'
EQ='app/src/main/java/com/okn/dsp/protocol/LiveEqPolicy.kt'
SC='app/src/main/java/com/okn/dsp/protocol/VerifiedScalarControls.kt'
WG='app/src/main/java/com/okn/dsp/protocol/WriteGate.kt'
SAVE='app/src/main/java/com/okn/dsp/protocol/SaveParamsPolicy.kt'
KEY='app/okn_dsp_stable_debug.keystore'
README='README_V93.txt'
PLAN='evidence/OKN_DSP_V93_REFERENCE_UI_PHONE_SYNC_TREBLE_SLEW.txt'
PLANJ='evidence/OKN_DSP_V93_REFERENCE_UI_PHONE_SYNC_TREBLE_SLEW.json'
REF='evidence/OKN_DSP_V93_REFERENCE_UI_MASTER.png'
for f in [U,G,M,EQ,SC,WG,SAVE,KEY,README,PLAN,PLANJ,REF]: req(f)

has(G,'applicationId = "com.okn.dsp"')
has(G,'versionCode = 93')
has(G,'versionName = "6.2.0-v93-reference-ui-phone-sync-treble-slew"')
has(M,'android:label="OKN_DSP"')
has(M,'android:screenOrientation="fullSensor"')
has(M,'android:configChanges="orientation|screenSize|smallestScreenSize"')
sha(REF,'35ba1cc797646fd2a4a317d0b368e6d39ac562042cb86be39a08dab9d6649aaa')

u=txt(U)
# Required reference UI structure.
for marker in [
    'OKN_DSP','Digital Sound Processor','7CH DSP Processor','Master Volume','Channels (7)',
    'Quick Controls','Home','Channels','Tuning','Presets','Settings',
    'EQ','Crossover','Delay','Mixer','Preset','GlowDspView','VerticalFaderView'
]: assert marker in u, marker

# Automatic connect/session path and remembered restore.
cccd=u[u.index('override fun onDescriptorWrite'):u.index('override fun onCharacteristicWrite')]
assert 'handler.postDelayed' in cccd and 'startSession()' in cccd
initial=u[u.index('            DescMode.INITIAL -> {'):u.index('            DescMode.REFRESH ->')]
assert 'runFieldSelfCheck()' in initial
assert 'restoreLocalSnapshotToConnectedDsp()' in initial
assert 'seedLocalSnapshotFromDsp()' in initial

# Realtime queue invariants.
for marker in [
    'sealed class LiveCommand','LinkedHashMap<String, LiveCommand>()','liveQueue[cmd.key] = cmd',
    'private val liveMinIntervalMs = 38L','if (liveInFlight != null || liveQueue.isEmpty()) return',
    'tx.encryptNext(plain)','writeNoResponse(g, w, enc, label, purpose = null, live = true)',
    'onLiveGattResult','2200L','V93_REALTIME_STREAM_FAIL_CLOSED'
]: assert marker in u, marker

# Android phone volume <-> verified MasterVolume bridge.
for marker in [
    'override fun dispatchKeyEvent(event: KeyEvent)','KeyEvent.KEYCODE_VOLUME_UP','KeyEvent.KEYCODE_VOLUME_DOWN',
    'AudioManager.STREAM_MUSIC','masterDbFromSystemVolume','syncSystemVolumeFromMaster',
    'queueScalarRealtime(2, mapped, "phone-volume-key")','main-master-continuous'
]: assert marker in u, marker

# Orientation keeps GATT session while only visual tree rebuilds.
for marker in ['override fun onConfigurationChanged(newConfig: Configuration)','buildUi()','V93_ORIENTATION_REBUILD','keepGatt=${gatt != null}']:
    assert marker in u, marker

# ID11 bounded safe slew: <=0.5 dB, one step after successful GATT callback.
scalar_queue=u[u.index('private fun queueScalarRealtime'):u.index('private fun queueEqRealtime')]
for marker in ['if (id == 11)','trebleSlewStepDb = 0.5f','trebleSlewIntervalMs = 48L','scheduleTrebleSafeSlew','V93_TREBLEBOOST_SAFE_SLEW_TARGET']:
    assert marker in u, marker
assert 'V92_TREBLEBOOST_ID11_STREAM_BLOCKED' not in scalar_queue
result=u[u.index('private fun onLiveGattResult'):u.index('private fun failRealtimeStream')]
assert 'cmd.id == 11' in result and 'scheduleTrebleSafeSlew(trebleSlewIntervalMs)' in result
restore=u[u.index('private fun restoreLocalSnapshotToConnectedDsp'):u.index('private fun queueScalarRealtime')]
assert 'if (c.id == 11) continue' not in restore

# Persistence and one-tap guarded manual SaveParams, never automatic.
for marker in ['okn_dsp_v90_realtime_ui','persistScalarLocal','persistEqLocal','app-reopen-restore','reference_ch_gain_','reference_delay_ms_','reference_mixer_pan_','reference_preset_index']:
    assert marker in u, marker
assert 'SaveParamsPolicy' not in restore and 'beginPermanentSavePrecheck' not in restore
savefn=u[u.index('private fun confirmPermanentSave'):u.index('private fun beginPermanentSavePrecheck')]
assert 'noConfirmationDialog=true' in savefn and 'beginPermanentSavePrecheck()' in savefn
assert 'autoSaveParams=false' in u

# Verified writer boundary unchanged; no guessed unknown write packets.
sc=txt(SC)
ids=[int(x) for x in re.findall(r'VerifiedScalarControl\((\d+),',sc)]
assert ids==[2,3,8,9,10,13,11], ids
wg=txt(WG)
assert 'const val enabled: Boolean = false' in wg
assert 'const val unifiedVerifiedScalarWritesEnabled: Boolean = true' in wg
assert 'const val unifiedVerifiedEqWritesEnabled: Boolean = true' in wg
for marker in ['b.type == EqBandCodec.PEAKING_TYPE','targetFromParameters']:
    has(EQ,marker)
has(SAVE,'570000000700000000"')
for marker in [
    'Crossover controls จำค่าและเลื่อนแบบ Real-time ใน UI',
    'Delay เลื่อนต่อเนื่องและจำค่าในเครื่อง',
    'routing/mixer write ยังไม่มี protocol ที่ยืนยัน',
    'DSP Preset write ยัง LOCKED'
]: assert marker in u, marker

# Frozen protocol/transport hashes preserved from the qualified V88/V92 baseline.
protocol_hashes={
"ConfirmedDspMap.kt":"6e68295f194dd0b0f70d0b83b9ba2324a9a2a8eaf2350b5d5a821f838ae2c66d",
"UfeCodec.kt":"b47f66afec8fd3383581c30b2dc1ad9ad41e3b7089f427f0b094e91581588c34",
"ProtocolSelfTest.kt":"8e1ea8beda03c2b90679a1af0a142a823be23e93481b124b981df768b0a9a0be",
"AuthSessionAnalyzer.kt":"63c8e8afcbc0fb5a2400a8e620932af72bec4d695463c8ed86b0c6bd5d507f7d",
"WriteGate.kt":"8aa82bb069dd64dc2d1274801f1f4420a764f52670246e9c813b0723531be472",
"ControlledCapture.kt":"0359e28b230618edfec7ed90d4f9a9cc116ce58f684ba640758ba22812e88776",
"ByteCodec.kt":"04843cec90b69886607d98a0aabf0ad81812fc8d25df913c5b1847a10fd7a3ae",
"EqBandCodec.kt":"4f033a406e363b2418af9b39fa2e42a13674b09f9de2bb7acf1eb6ff1918cd58",
"VerifiedScalarControls.kt":"4c096b001523704dcb6aa36496dd17263d6df84a0a1fee20c2fc40d60e898f6b",
"SessionCrypto.kt":"bae330efd6e9beb628b287e43e36bd98d80b3f9b4d1c014f65c63ef16efa586e",
"UfeConstants.kt":"e64de468c11d80ea052b97c9298a0a8a7f8cc49362f5bd06193d2c7c6d0108aa",
"SaveParamsPolicy.kt":"88005dba77d2b84597f5bd5e23eaaacec7d25b59dc0f38b8affbde2d2cfbeb85",
"SevenChannelEqMapPolicy.kt":"6dde7ec82e42f974fe5bde040447a6ba089a3795ed930164c2622f280fd39da4",
"FinalEqWriteRestorePolicy.kt":"41468a2f9b40511efe2e0384683eed42c60ee765222b5b4bb138b85e962180d7"
}
for name,expected in protocol_hashes.items(): sha('app/src/main/java/com/okn/dsp/protocol/'+name, expected)
transport_hashes={
"BleProfile.kt":"52f25f92e0dd5059417a894e0da7e58ea73de4505661e9b25e62e51e73d314a0",
"BleTransport.kt":"d44d661d0abe0e6dd7f3202011a97bab0de8f5e306ff70a1430ad02c9ccfc09b",
"DspTransport.kt":"1e2a2a54c2e31323da4bbc6f9efab01c2fdd2c2f2c9ebc8ee9d6f3e0ea1b6750"
}
for name,expected in transport_hashes.items(): sha('app/src/main/java/com/okn/dsp/transport/'+name, expected)
sha(KEY,'ba1c52f2607c09953c52fdd79c5f72026aaf0adb8aa44bcba277f7d9b49d9511')

# Fail-closed and writer-order invariants.
for marker in ['V88_ALL_STATUS_DISCONNECT_FAIL_CLOSED','V88_LIFECYCLE_DESTROY_FAIL_CLOSED','V88_SESSION_HEALTH_GATE_RESULT','SaveParamsPolicy.encodeTrigger()']:
    assert marker in u, marker
assert 'marginTop=' not in u
assert u.count('class UnifiedControlActivity : Activity()')==1
assert u.count('override fun onDestroy()')==1
assert u.count('override fun onConfigurationChanged(newConfig: Configuration)')==1
balanced_kotlin(u)

section=u[u.index('    private fun writeNoResponse('):u.index('    private fun record(kind: String, text: String) {')]
a=section.index('gattWriteTickets.addLast(kind)')
b=section.index('V88_UNIFIED_GATT_TICKET_PREPARED')
c=section.index('if (purpose != null) armGattActionTimeout(purpose)')
d=section.index('g.writeCharacteristic(ch, bytes, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE)')
assert a<b<c<d

print('V93 PREFLIGHT PASS')
print('versionCode=93')
print('versionName=6.2.0-v93-reference-ui-phone-sync-treble-slew')
print('referenceUI=portrait+landscape+5-bottom-nav+6-quick-controls')
print('postConnect=automatic-auth+descriptor+health-gate+remembered-restore')
print('realtime=latest-target-wins+one-inflight+38ms-pacing+gatt-timeout-fail-closed')
print('phoneVolumeSync=MasterVolume-ID2+physical-volume-keys')
print('trebleBoostId11=bounded-0.5dB-safe-slew-next-step-after-GATT-success')
print('eq=safe-PEAKING-full-48-byte-continuous')
print('unknownWriters=locked-no-guess')
print('SaveParams=one-tap-manual-guarded;autoSave=false')
print('stableSigning=PASS')
