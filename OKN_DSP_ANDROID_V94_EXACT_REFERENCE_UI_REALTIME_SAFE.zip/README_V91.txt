OKN_DSP V91 — REFERENCE REAL-TIME UI
====================================

Purpose
-------
V91 retains the Android operator UI around the supplied OKN_DSP dark/cyan reference while retaining the previously verified BLE/authentication/descriptor protocol and narrow writable DSP surface.

Interaction model
-----------------
- Scan Bluetooth and tap a discovered DSP, or reconnect the cached last DSP.
- After AB02 notification setup, authentication + Device Description load + read-only session health gate run automatically. There is no separate START/LOAD/SAFETY button in the production UI.
- Verified Global controls send in real time while the slider moves.
- Verified PEAKING EQ rows expose Frequency (20 Hz–20 kHz), Q (0.05–20), and Gain (-12..+12 dB) and send in real time.
- The writer coalesces repeated slider positions and sends one encrypted GATT command at a time. A missing/failed GATT completion fails closed and requires reconnect.
- Every Global and editable EQ change is persisted immediately to local Android SharedPreferences.
- On the next app open, after the user connects the DSP, V91 automatically compares the remembered settings against the fresh descriptor and reapplies differences to DSP RAM.

Persistence distinction
-----------------------
Local app memory is automatic. SaveParams to the DSP itself is NOT automatic. The red Save to Device button remains a manual guarded action using the verified actuator ID7 command and fresh PRE/POST descriptor checks. This protects the verified device-write scope while still meeting the reopen/reconnect restore requirement.

Verified writable scope
-----------------------
Global scalar IDs: 2,3,8,9,10,13,11.
EQ actuator IDs: CH1=4, CH2=5, CH3=6, CH4=14, CH5=15, CH6=16, CH7=17.
EQ: 15 records/channel are displayed; only actual type=12 safe PEAKING records are editable. Frequency/Q/Gain are real-time on those verified PEAKING records. Non-PEAKING rows are read-only, matching the supplied UI reference. Preset, Delay, generic and unknown writes stay locked.
Sensors remain read-only: FrontAudioJackPluggedIn, RearAudioJackPluggedIn, PowerStageVoltage, CPU Load.

Self-created UI artwork
-----------------------
GlowDspView.kt draws the DSP hardware illustration in-app with Canvas.
EqCurveView.kt draws channel EQ grids/curves/points in-app with Canvas.
The supplied reference image is not embedded into the app as a UI bitmap.

Build
-----
Use build-okn-dsp-v91.yml. The workflow verifies the V91 source ZIP SHA, runs preflight_v91.py, verifies the stable keystore/certificate, builds with Android 35 + Gradle 8.9, verifies the APK certificate, and uploads the APK artifact.

V91 is a build-fix release from V90. The exact Kotlin compile failure at UnifiedControlActivity.kt line 2389 used an invalid LayoutParams property `marginTop`; V91 changes it to the valid `topMargin` field. No BLE protocol, crypto, verified writer allow-list, EQ payload format, SaveParams semantics, or stable signing identity is changed.
