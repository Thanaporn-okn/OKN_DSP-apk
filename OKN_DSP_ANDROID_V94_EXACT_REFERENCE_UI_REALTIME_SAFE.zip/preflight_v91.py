#!/usr/bin/env python3
from pathlib import Path
import hashlib, re
root=Path(__file__).resolve().parent

def req(rel):
    p=root/rel
    assert p.is_file(), f"missing {rel}"
    return p

def txt(rel): return req(rel).read_text(encoding="utf-8", errors="replace")
def has(rel, marker): assert marker in txt(rel), f"missing marker {marker!r} in {rel}"
def sha(rel, expected):
    actual=hashlib.sha256(req(rel).read_bytes()).hexdigest()
    assert actual==expected, f"hash mismatch {rel} {actual}"

U='app/src/main/java/com/okn/dsp/UnifiedControlActivity.kt'
G='app/build.gradle.kts'
M='app/src/main/AndroidManifest.xml'
MAIN='app/src/main/java/com/okn/dsp/MainActivity.kt'
EQ='app/src/main/java/com/okn/dsp/protocol/LiveEqPolicy.kt'
SC='app/src/main/java/com/okn/dsp/protocol/VerifiedScalarControls.kt'
WG='app/src/main/java/com/okn/dsp/protocol/WriteGate.kt'
SAVE='app/src/main/java/com/okn/dsp/protocol/SaveParamsPolicy.kt'
STYLE='app/src/main/res/values/styles.xml'
GLOW='app/src/main/java/com/okn/dsp/GlowDspView.kt'
CURVE='app/src/main/java/com/okn/dsp/EqCurveView.kt'
KEY='app/okn_dsp_stable_debug.keystore'
README='README_V91.txt'
PLAN='evidence/OKN_DSP_V91_REFERENCE_REALTIME_UI_COMPILE_FIX.txt'
PLANJ='evidence/OKN_DSP_V91_REFERENCE_REALTIME_UI_COMPILE_FIX.json'
for f in [U,G,M,MAIN,EQ,SC,WG,SAVE,STYLE,GLOW,CURVE,KEY,README,PLAN,PLANJ]: req(f)

# Version / identity / dark reference UI.
has(G,'applicationId = "com.okn.dsp"')
has(G,'versionCode = 91')
has(G,'versionName = "6.0.1-v91-compile-fix"')
has(M,'android:label="OKN_DSP"')
has(STYLE,'Theme.Material3.Dark.NoActionBar')
for marker in ['OKN_DSP','Digital Sound Processor','สแกน Bluetooth','เชื่อมต่อ DSP ล่าสุด','Global Controls','Sensors & System','SaveParams (Guarded)','Home','Global','EQ','Sensors','More']:
    has(U,marker)
for marker in ['class GlowDspView','Self-drawn DSP artwork']:
    has(GLOW,marker)
for marker in ['class EqCurveView','Lightweight self-drawn EQ graph']:
    has(CURVE,marker)

# Automatic post-connect session: CCCD success must lead to startSession without a visible extra START step.
u=txt(U)
cccd=u[u.index('override fun onDescriptorWrite'):u.index('override fun onCharacteristicWrite')]
assert 'handler.postDelayed' in cccd and 'startSession()' in cccd
assert 'startSessionButton.isEnabled = false' in cccd

# Real-time writer: coalesced queue, GATT completion sequencing, timeout fail-closed.
for marker in ['sealed class LiveCommand','LinkedHashMap<String, LiveCommand>()','GattWriteKind.LIVE','queueScalarRealtime','queueEqRealtime','drainLiveQueue','onLiveGattResult','liveGattTimeoutRunnable','gatt-callback-timeout','V91_REALTIME_STREAM_FAIL_CLOSED']:
    assert marker in u, marker
live=u[u.index('private fun drainLiveQueue'):u.index('private fun renderHomeDynamic')]
assert 'tx.encryptNext(plain)' in live
assert 'writeNoResponse(g, w, enc, label, purpose = null, live = true)' in live
assert 'liveQueue[cmd.key] = cmd' in u

# Local persistence and reconnect restore, but never automatic device SaveParams.
for marker in ['okn_dsp_v90_realtime_ui','snapshot_initialized','persistScalarLocal','persistEqLocal','seedLocalSnapshotFromDsp','restoreLocalSnapshotToConnectedDsp','app-reopen-restore']:
    assert marker in u, marker
restore=u[u.index('private fun restoreLocalSnapshotToConnectedDsp'):u.index('private fun queueScalarRealtime')]
assert 'SaveParamsPolicy' not in restore and 'beginPermanentSavePrecheck' not in restore
assert 'autoSaveParams=false' in u


# V91 exact compile-fix gate: invalid MarginLayoutParams property must be gone.
assert 'marginTop=' not in u, 'invalid LayoutParams property marginTop still present'
assert 'topMargin=dp(5)' in u, 'V91 topMargin compile fix missing'
assert 'okn_dsp_v90_realtime_ui' in u, 'local preference namespace must stay stable across V90 -> V91 upgrade'

# Verified writable surface remains narrow.
sc=txt(SC)
ids=[int(x) for x in re.findall(r'VerifiedScalarControl\((\d+),',sc)]
assert ids==[2,3,8,9,10,13,11], ids
wg=txt(WG)
assert 'const val enabled: Boolean = false' in wg
assert 'const val unifiedVerifiedScalarWritesEnabled: Boolean = true' in wg
assert 'const val unifiedVerifiedEqWritesEnabled: Boolean = true' in wg
for marker in ['b.type == EqBandCodec.PEAKING_TYPE','MIN_FREQUENCY_HZ = 20.0f','MAX_FREQUENCY_HZ = 20000.0f','MIN_Q = 0.05f','MAX_Q = 20.0f','targetFromParameters']:
    has(EQ,marker)
has(SAVE,'"570000000700000000"')

# Existing protocol files except LiveEqPolicy remain byte-for-byte V89/V88 baseline.
protocol_hashes={"ConfirmedDspMap.kt": "6e68295f194dd0b0f70d0b83b9ba2324a9a2a8eaf2350b5d5a821f838ae2c66d", "UfeCodec.kt": "b47f66afec8fd3383581c30b2dc1ad9ad41e3b7089f427f0b094e91581588c34", "ProtocolSelfTest.kt": "8e1ea8beda03c2b90679a1af0a142a823be23e93481b124b981df768b0a9a0be", "AuthSessionAnalyzer.kt": "63c8e8afcbc0fb5a2400a8e620932af72bec4d695463c8ed86b0c6bd5d507f7d", "WriteGate.kt": "8aa82bb069dd64dc2d1274801f1f4420a764f52670246e9c813b0723531be472", "ControlledCapture.kt": "0359e28b230618edfec7ed90d4f9a9cc116ce58f684ba640758ba22812e88776", "ByteCodec.kt": "04843cec90b69886607d98a0aabf0ad81812fc8d25df913c5b1847a10fd7a3ae", "EqBandCodec.kt": "4f033a406e363b2418af9b39fa2e42a13674b09f9de2bb7acf1eb6ff1918cd58", "VerifiedScalarControls.kt": "4c096b001523704dcb6aa36496dd17263d6df84a0a1fee20c2fc40d60e898f6b", "SessionCrypto.kt": "bae330efd6e9beb628b287e43e36bd98d80b3f9b4d1c014f65c63ef16efa586e", "UfeConstants.kt": "e64de468c11d80ea052b97c9298a0a8a7f8cc49362f5bd06193d2c7c6d0108aa", "SaveParamsPolicy.kt": "88005dba77d2b84597f5bd5e23eaaacec7d25b59dc0f38b8affbde2d2cfbeb85", "ControlledEqBandProof.kt": "9c93d7aabc0fc7edcb4056a3077cdb23a49c1469618453c87faa47c477c34126", "ControlledMasterVolumeProof.kt": "8357e6207b1b5382e4a70a0eeec25d03c38fc374d3a21633f156f341ffa57778", "PreAuthRandKeyDecoder.kt": "58d8a287449c849fb925070ac1f61ea26ba02875f58605fd7008439da78533ac", "AuthVectorLab.kt": "16ba1e0fa076da2b5b6b1ccc0c97bee7f015895c7ebceb55a5f1e704ebfe113a", "ReferenceProfile.kt": "3cc1ad3d717f29358e04c0c5ccfff16c8f310006651fd3024fe570853c2595dc", "SevenChannelEqMapPolicy.kt": "6dde7ec82e42f974fe5bde040447a6ba089a3795ed930164c2622f280fd39da4", "FinalEqWriteRestorePolicy.kt": "41468a2f9b40511efe2e0384683eed42c60ee765222b5b4bb138b85e962180d7", "AuthResponseCodec.kt": "0cbe3174f4d0bf543edb1dfd41db71ab4970effb3743be9e6c7d5a174a5e5f90", "EqBandRecoveryPolicy.kt": "9928f69cadc2e6e172cf2eed61f7a9063374ef4c8cd73e4522a45a0b9b76b82d", "DeviceDescriptionProof.kt": "ae0cbc9d09eed29bae77f32f84bba3c8cbea7db8e8f9b04b0e3a1311ca527307", "ProtocolEvidence.kt": "c8989d2dd57299a64464f31824b86df9fd07f9ef376bc6b4cd6576d0076e5ef5", "RandKeyPreAuthLab.kt": "feb00c3513d5869b1d72a34e864ae3396570eac23f3f9036c0f40b575d79686a"}
for name,expected in protocol_hashes.items(): sha('app/src/main/java/com/okn/dsp/protocol/'+name,expected)
transport_hashes={"BleProfile.kt": "52f25f92e0dd5059417a894e0da7e58ea73de4505661e9b25e62e51e73d314a0", "BleTransport.kt": "d44d661d0abe0e6dd7f3202011a97bab0de8f5e306ff70a1430ad02c9ccfc09b", "DspTransport.kt": "1e2a2a54c2e31323da4bbc6f9efab01c2fdd2c2f2c9ebc8ee9d6f3e0ea1b6750"}
for name,expected in transport_hashes.items(): sha('app/src/main/java/com/okn/dsp/transport/'+name,expected)

# Stable signing identity unchanged.
sha(KEY,'ba1c52f2607c09953c52fdd79c5f72026aaf0adb8aa44bcba277f7d9b49d9511')

# Existing critical safety paths retained.
for marker in ['V88_ALL_STATUS_DISCONNECT_FAIL_CLOSED','V88_LIFECYCLE_DESTROY_FAIL_CLOSED','V88_SESSION_HEALTH_GATE_RESULT','SaveParamsPolicy.encodeTrigger()','UfeCodec.encodeFloat32Write(id, target)','LiveEqPolicy.encodeRestore(ch, band1, original)','private fun failClosedDisconnectedAllStatus(callbackGatt: BluetoothGatt, statusCode: Int)']:
    assert marker in u, marker
section=u[u.index('    private fun writeNoResponse('):u.index('    private fun record(kind: String, text: String) {')]
a=section.index('gattWriteTickets.addLast(kind)')
b=section.index('V88_UNIFIED_GATT_TICKET_PREPARED')
c=section.index('if (purpose != null) armGattActionTimeout(purpose)')
d=section.index('g.writeCharacteristic(ch, bytes, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE)')
assert a<b<c<d
assert u.count('class UnifiedControlActivity : Activity()')==1
assert u.count('override fun onDestroy()')==1

print('V91 PREFLIGHT PASS')
print('versionCode=91')
print('versionName=6.0.1-v91-compile-fix')
print('ui=reference-dark-neon+self-drawn-dsp+self-drawn-eq-curves')
print('postConnect=automatic-auth+descriptor+read-only-health-gate+local-restore')
print('realtime=7-scalars+verified-PEAKING-F/Q/Gain;coalesced+gatt-sequenced+timeout-fail-closed')
print('persistence=local-immediate;SaveParams=manual-guarded-only')
print('genericWrites=false;nonPeaking/preset/delay/unknown=locked')
print('keystoreSha256=ba1c52f2607c09953c52fdd79c5f72026aaf0adb8aa44bcba277f7d9b49d9511')
