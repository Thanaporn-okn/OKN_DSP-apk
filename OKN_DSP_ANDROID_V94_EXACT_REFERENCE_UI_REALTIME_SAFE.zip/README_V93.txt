OKN_DSP V93 — REFERENCE UI + PHONE VOLUME SYNC + TREBLE SAFE-SLEW
=================================================================

VERSION
versionCode: 93
versionName: 6.2.0-v93-reference-ui-phone-sync-treble-slew
applicationId: com.okn.dsp
app label: OKN_DSP

PURPOSE
- Rebuild the operator UI around the supplied OKN_DSP portrait reference.
- Preserve the frozen, hardware-qualified V88 BLE/auth/crypto/protocol and stable signing identity.
- Keep Bluetooth scan -> tap/connect -> Auth -> fresh Device Description -> Health Gate automatic.
- Keep all visible UI values persistent across app restarts.
- Keep verified MasterVolume and safe PEAKING EQ continuous/realtime with a single-inflight, paced BLE queue.
- Add Android physical volume +/- synchronization with verified MasterVolume ID2.
- Add portrait + landscape live UI rebuilding without destroying the active GATT session.
- Replace the V92 TrebleBoost write block with a bounded ID11 safe-slew mitigation.

REFERENCE UI
The exact supplied reference screenshot is embedded as:
evidence/OKN_DSP_V93_REFERENCE_UI_MASTER.png
The application itself uses self-drawn/native UI elements; no external image download is required at runtime.

REALTIME ENGINE
- Latest-target-wins queue.
- One BLE write in flight.
- Minimum live pacing: 38 ms.
- GATT callback timeout: 2200 ms -> fail closed, no blind retry.
- MasterVolume slider updates Android STREAM_MUSIC volume and verified DSP ID2 together.
- Android volume +/- keys update STREAM_MUSIC, the MasterVolume slider/label, persistent local state, and DSP ID2 when the Health Gate is valid.
- Safe PEAKING EQ Frequency/Gain/Q rebuilds and streams the full verified 48-byte record.

TREBLEBOOST ID11 MITIGATION
- V93 no longer sends one large abrupt direct jump for ID11.
- Target motion is broken into <=0.5 dB steps.
- A next step is emitted only after the prior step receives a successful GATT callback.
- Nominal inter-step delay: 48 ms.
- New user targets replace the destination while the ramp is active.
- This is an engineering mitigation based on the already verified ID11 scalar packet format; it does NOT claim the acoustic root cause of the prior "ตุ้บ/ดุบ" transient is proven.
- Real-DSP listening/runtime qualification is required before declaring the transient eliminated.

PERSISTENCE
- Every interactive UI surface persists immediately in SharedPreferences.
- Verified scalars and safe PEAKING EQ are replayed to the connected DSP after a fresh Health Gate when local remembered state differs.
- TrebleBoost replay uses the same bounded safe-slew path.
- SaveParams remains a separate one-tap guarded action; it is never sent automatically.

ORIENTATION
- AndroidManifest uses fullSensor.
- UnifiedControlActivity handles orientation/screenSize configuration changes itself.
- Visual tree is rebuilt for portrait/landscape while retaining the current BLE/GATT/auth/session objects.
- Portrait home layout follows the supplied reference hierarchy: brand/status, DSP processor card, Master, 7 channel cards (4+3), Quick Controls, five-item bottom navigation.

HARDWARE WRITE BOUNDARY
Verified DSP hardware writes in this source remain limited to:
- Scalar IDs: 2,3,8,9,10,13,11
- Safe PEAKING EQ type=12 across verified channel actuator IDs 4,5,6,14,15,16,17
- Manual guarded SaveParams ID7

No unverified packet is fabricated. Channel Gain/Mute, Crossover, Delay, Mixer routing, and DSP Preset writes remain locally interactive/persistent until their real packet/actuator mapping is separately proven. This prevents the app from sending guessed commands to the DSP.

BUILD STATUS
- V93 packaged source/preflight: intended for GitHub Actions build.
- Full APK compilation is performed by build-okn-dsp-v93.yml.
- Real-device no-stutter and TrebleBoost acoustic qualification remain hardware tests; source code cannot truthfully guarantee analog/audio behavior without that run.
