#!/usr/bin/env python3
from pathlib import Path
import hashlib, re
root=Path(__file__).resolve().parent

def req(rel):
    p=root/rel
    assert p.is_file(), f"missing {rel}"
    return p

def txt(rel): return req(rel).read_text(encoding='utf-8',errors='replace')
def sha(rel,expected):
    actual=hashlib.sha256(req(rel).read_bytes()).hexdigest()
    assert actual==expected, f"hash mismatch {rel}: {actual} != {expected}"

def balanced_kotlin(text):
    stack=[]; state='code'; quote=''; i=0; pairs={')':'(',']':'[','}':'{'}
    while i<len(text):
        c=text[i]; n=text[i+1] if i+1<len(text) else ''
        if state=='line':
            if c=='\n': state='code'
        elif state=='block':
            if c=='*' and n=='/': state='code'; i+=1
        elif state=='string':
            if c=='\\': i+=1
            elif c==quote: state='code'
        elif state=='triple':
            if text.startswith('"""',i): state='code'; i+=2
        else:
            if c=='/' and n=='/': state='line'; i+=1
            elif c=='/' and n=='*': state='block'; i+=1
            elif text.startswith('"""',i): state='triple'; i+=2
            elif c in ('"',"'"): state='string'; quote=c
            elif c in '([{': stack.append(c)
            elif c in ')]}':
                assert stack and stack[-1]==pairs[c], f"unbalanced token at {i}"
                stack.pop()
        i+=1
    assert not stack, f"unclosed tokens {stack[-10:]}"

U='app/src/main/java/com/okn/dsp/UnifiedControlActivity.kt'
G='app/build.gradle.kts'
M='app/src/main/AndroidManifest.xml'
REF='evidence/OKN_DSP_V94_UI_REFERENCE.png'
KEY='app/okn_dsp_stable_debug.keystore'
for f in [U,G,M,REF,KEY,'README_V94.txt','evidence/OKN_DSP_V94_EXACT_REFERENCE_UI_REALTIME_SAFE.txt','evidence/OKN_DSP_V94_EXACT_REFERENCE_UI_REALTIME_SAFE.json','app/src/main/java/com/okn/dsp/WaveLogoView.kt','app/src/main/java/com/okn/dsp/CrossoverGraphView.kt','app/src/main/java/com/okn/dsp/StereoLevelMeterView.kt','app/src/main/java/com/okn/dsp/CarCabinView.kt']:
    req(f)

assert 'versionCode = 94' in txt(G)
assert 'versionName = "6.3.0-v94-exact-reference-ui-realtime-safe"' in txt(G)
assert 'android:screenOrientation="fullSensor"' in txt(M)
assert 'android:configChanges="orientation|screenSize|smallestScreenSize"' in txt(M)
sha(REF,'4d57da3aa525975754155a5ca79fa34054d038340a90babe535a25b7bce0a0f9')
sha(KEY,'ba1c52f2607c09953c52fdd79c5f72026aaf0adb8aa44bcba277f7d9b49d9511')

u=txt(U)
for marker in [
    'V94_EXACT_REFERENCE_UI_START','สแกนหาอุปกรณ์','เชื่อมต่อด้วย MAC','OKN_DSP','PROFESSIONAL AUDIO DSP',
    'CROSSOVER','DELAY','OUTPUT','PRESET','SETTINGS','pageHeader("EQ")','channelTabs',
    'WaveLogoView(this)','CrossoverGraphView(this)','StereoLevelMeterView(this)','CarCabinView(this)',
    'MasterVolume','v94-master-continuous','queueScalarRealtime(2, mapped, "phone-volume-key")',
    'v94-eq-continuous','v94-eq-reset','persistPresetSnapshot','recallPresetSnapshot'
]: assert marker in u, marker

# Auto post-connect start is retained.
cccd=u[u.index('override fun onDescriptorWrite'):u.index('override fun onCharacteristicWrite')]
assert 'startSession()' in cccd and 'handler.postDelayed' in cccd

# Realtime queue + failure behavior retained.
for marker in ['sealed class LiveCommand','private val liveMinIntervalMs = 38L','liveQueue[cmd.key] = cmd','if (liveInFlight != null || liveQueue.isEmpty()) return','onLiveGattResult','V93_REALTIME_STREAM_FAIL_CLOSED']:
    assert marker in u, marker

# Phone physical buttons -> Android media volume + MasterVolume ID2.
for marker in ['override fun dispatchKeyEvent(event: KeyEvent)','KeyEvent.KEYCODE_VOLUME_UP','KeyEvent.KEYCODE_VOLUME_DOWN','AudioManager.STREAM_MUSIC','masterDbFromSystemVolume','syncSystemVolumeFromMaster']:
    assert marker in u, marker

# Rotation rebuilds the UI while retaining current session objects.
for marker in ['override fun onConfigurationChanged(newConfig: Configuration)','buildUi()','V94_ORIENTATION_REBUILD','keepGatt=${gatt != null}']:
    assert marker in u, marker

# ID11 slew remains bounded and callback-driven.
for marker in ['trebleSlewStepDb = 0.5f','trebleSlewIntervalMs = 48L','if (id == 11)','scheduleTrebleSafeSlew','scheduleTrebleSafeSlew(trebleSlewIntervalMs)']:
    assert marker in u, marker

# Persistence / reconnect replay.
for marker in ['persistScalarLocal','persistEqLocal','restoreLocalSnapshotToConnectedDsp','app-reopen-restore','reference_hpf_freq_','reference_delay_ms_','reference_ch_gain_','v94_preset_']:
    assert marker in u, marker

# Verified writer boundary is unchanged.
sc=txt('app/src/main/java/com/okn/dsp/protocol/VerifiedScalarControls.kt')
ids=[int(x) for x in re.findall(r'VerifiedScalarControl\((\d+),',sc)]
assert ids==[2,3,8,9,10,13,11], ids
wg=txt('app/src/main/java/com/okn/dsp/protocol/WriteGate.kt')
assert 'const val enabled: Boolean = false' in wg
assert 'const val unifiedVerifiedScalarWritesEnabled: Boolean = true' in wg
assert 'const val unifiedVerifiedEqWritesEnabled: Boolean = true' in wg
assert 'b.type == EqBandCodec.PEAKING_TYPE' in txt('app/src/main/java/com/okn/dsp/protocol/LiveEqPolicy.kt')
assert '570000000700000000"' in txt('app/src/main/java/com/okn/dsp/protocol/SaveParamsPolicy.kt')

# Exact frozen protocol/transport hashes from production baseline.
protocol_hashes={
"ConfirmedDspMap.kt":"6e68295f194dd0b0f70d0b83b9ba2324a9a2a8eaf2350b5d5a821f838ae2c66d",
"UfeCodec.kt":"b47f66afec8fd3383581c30b2dc1ad9ad41e3b7089f427f0b094e91581588c34",
"ProtocolSelfTest.kt":"8e1ea8beda03c2b90679a1af0a142a823be23e93481b124b981df768b0a9a0be",
"AuthSessionAnalyzer.kt":"63c8e8afcbc0fb5a2400a8e620932af72bec4d695463c8ed86b0c6bd5d507f7d",
"WriteGate.kt":"8aa82bb069dd64dc2d1274801f1f4420a764f52670246e9c813b0723531be472",
"ControlledCapture.kt":"0359e28b230618edfec7ed90d4f9a9cc116ce58f684ba640758ba22812e88776",
"ByteCodec.kt":"04843cec90b69886607d98a0aabf0ad81812fc8d25df913c5b1847a10fd7a3ae",
"EqBandCodec.kt":"4f033a406e363b2418af9b39fa2e42a13674b09f9de2bb7acf1eb6ff1918cd58",
"VerifiedScalarControls.kt":"4c096b001523704dcb6aa36496dd17263d6df84a0a1fee20c2fc40d60e898f6b",
"SessionCrypto.kt":"bae330efd6e9beb628b287e43e36bd98d80b3f9b4d1c014f65c63ef16efa586e",
"UfeConstants.kt":"e64de468c11d80ea052b97c9298a0a8a7f8cc49362f5bd06193d2c7c6d0108aa",
"SaveParamsPolicy.kt":"88005dba77d2b84597f5bd5e23eaaacec7d25b59dc0f38b8affbde2d2cfbeb85",
"SevenChannelEqMapPolicy.kt":"6dde7ec82e42f974fe5bde040447a6ba089a3795ed930164c2622f280fd39da4",
"FinalEqWriteRestorePolicy.kt":"41468a2f9b40511efe2e0384683eed42c60ee765222b5b4bb138b85e962180d7"
}
for name,h in protocol_hashes.items(): sha('app/src/main/java/com/okn/dsp/protocol/'+name,h)
transport_hashes={
"BleProfile.kt":"52f25f92e0dd5059417a894e0da7e58ea73de4505661e9b25e62e51e73d314a0",
"BleTransport.kt":"d44d661d0abe0e6dd7f3202011a97bab0de8f5e306ff70a1430ad02c9ccfc09b",
"DspTransport.kt":"1e2a2a54c2e31323da4bbc6f9efab01c2fdd2c2f2c9ebc8ee9d6f3e0ea1b6750"
}
for name,h in transport_hashes.items(): sha('app/src/main/java/com/okn/dsp/transport/'+name,h)

# No newly exposed generic write surface.
assert u.count('class UnifiedControlActivity : Activity()')==1
assert u.count('override fun onDestroy()')==1
assert u.count('override fun onConfigurationChanged(newConfig: Configuration)')==1
balanced_kotlin(u)
for rel in ['app/src/main/java/com/okn/dsp/WaveLogoView.kt','app/src/main/java/com/okn/dsp/CrossoverGraphView.kt','app/src/main/java/com/okn/dsp/StereoLevelMeterView.kt','app/src/main/java/com/okn/dsp/CarCabinView.kt']:
    balanced_kotlin(txt(rel))

print('V94 PREFLIGHT PASS')
print('versionCode=94')
print('versionName=6.3.0-v94-exact-reference-ui-realtime-safe')
print('ui=8-screen exact-reference hierarchy; no visible bottom nav')
print('bluetooth=scan+tap-connect+auto authenticated session')
print('realtime=verified scalars+15x7 PEAKING EQ; latest-target-wins; one-inflight; 38ms pacing')
print('master=app slider <-> Android STREAM_MUSIC <-> verified ID2')
print('trebleBoost=ID11 bounded 0.5dB/48ms callback-driven slew mitigation')
print('persistence=immediate local + verified replay after fresh Health Gate')
print('unknownHardwareWrites=crossover/delay/output-mute-phase/device-preset LOCKED; no guessing')
