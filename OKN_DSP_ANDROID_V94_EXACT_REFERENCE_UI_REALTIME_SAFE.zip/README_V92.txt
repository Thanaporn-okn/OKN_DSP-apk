OKN_DSP V92 — SUPPLIED REFERENCE UI / CONTINUOUS REAL-TIME CONTROL
==================================================================

VERSION
- versionCode: 92
- versionName: 6.1.0-v92-reference-ui-continuous-realtime
- orientation: sensorLandscape
- app label: OKN_DSP

UI CONTRACT
V92 rebuilds the visible operator UI around the supplied master reference image.
Visible pages are exactly:
MAIN / EQ / CROSSOVER / DELAY / MIXER / PRESET / SETTINGS

The reference artwork is included at:
evidence/OKN_DSP_V92_REFERENCE_UI_MASTER.jpg
SHA256:
52a65eee71eca8a29655c1191f11789b7bb41ab72b380324e46fdb829705e36d

CONNECTION / STARTUP CONTRACT
- SCAN discovers compatible BLE DSP devices.
- Selecting a device connects immediately.
- Successful AB02 CCCD subscription automatically starts Auth + Device Description.
- The read-only session health gate runs automatically after the fresh descriptor is loaded.
- Remembered verified settings are replayed automatically only after a fresh current-session gate passes.
- No extra START/APPLY confirmation step is required in the visible UI.

CONTINUOUS REAL-TIME ENGINE
- UI updates continuously while the finger moves.
- Verified DSP writes use a latest-value-wins LinkedHashMap queue.
- Only one BLE GATT write is in flight at a time.
- Stream pacing is 38 ms minimum between accepted writes to avoid building a BLE backlog.
- GATT timeout/status uncertainty fails closed and requires reconnect rather than blind retry.
- No automatic SaveParams is sent by slider movement.

VERIFIED HARDWARE REAL-TIME SCOPE
- MasterVolume scalar ID 2 is visible on MAIN and streams in real time.
- Existing verified scalar writer is retained for the allow-list, but TrebleBoost ID11 is explicitly stream-blocked in V92 because of the prior audible transient incident.
- 7-channel, 15-band PEAKING EQ type=12 remains the verified real-time EQ surface.
- EQ Frequency / Gain / Q sliders persist locally and stream the full verified 48-byte record when the current session is healthy.

IMPORTANT SAFETY BOUNDARY
The supplied UI also contains Master/Channel Mute, channel faders, Crossover, Delay,
Mixer and Preset controls. Their exact device write packets/actuator mappings are not
verified in the current evidence. V92 therefore makes these controls fully interactive
and persistent in the UI but intentionally DOES NOT invent hardware writes for them.
They must remain local-only until real protocol evidence proves the corresponding DSP
write format. This is deliberate, not a missing button implementation.

PERSISTENCE
- UI values are stored immediately with SharedPreferences.
- The stable preference namespace is retained across V90/V91/V92 upgrades.
- After app restart, a fresh reconnect/auth/descriptor/gate occurs first.
- Verified Master/EQ values can then be restored to the connected DSP automatically.
- Unverified controls restore their UI state locally only.
- SaveParams remains a one-tap guarded manual action; it is never automatic.

TREBLEBOOST ID11 SAFETY HOLD
- ID11 remains in the historical verified scalar map.
- V92 prevents direct or automatic ID11 live streaming.
- Its local value may be remembered, but it is not replayed to hardware.
- Do not remove this hold without runtime evidence resolving the prior transient.

BUILD / SIGNING
- JDK 17
- Android SDK 35 / Build Tools 35.0.0
- Gradle 8.9
- stable debug keystore SHA256:
  ba1c52f2607c09953c52fdd79c5f72026aaf0adb8aa44bcba277f7d9b49d9511
- expected APK signer certificate SHA256:
  c3da85af2e978dbd0ed9bb695e5c79a263189595c116ad93a1ded75a2eb98397

QUALIFICATION STATUS
- Source static/preflight/integrity verification: required before delivery.
- GitHub Actions APK compilation: authoritative build path.
- Real DSP no-stutter/audio qualification: must be confirmed on the target DSP after APK build/install.
