OKN_DSP V94 — EXACT REFERENCE UI + REALTIME SAFE CONTROL
=========================================================

Version
- versionCode: 94
- versionName: 6.3.0-v94-exact-reference-ui-realtime-safe
- Package: com.okn.dsp

UI SOURCE OF TRUTH
- evidence/OKN_DSP_V94_UI_REFERENCE.png
- SHA256: 4d57da3aa525975754155a5ca79fa34054d038340a90babe535a25b7bce0a0f9
- Visible operator shell rebuilt to the supplied eight-screen layout:
  1) Bluetooth connection
  2) main menu
  3) EQ
  4) crossover
  5) delay
  6) output
  7) preset
  8) settings
- No bottom navigation is shown in V94. Page cards/back arrows drive navigation.
- Portrait and landscape rebuild only the visual tree; the current GATT/session is retained by Android configChanges.

REALTIME / PERSISTENCE
- BLE scan, tap-to-connect, AB00/AB01/AB02 discovery and automatic authenticated session startup are retained from the verified baseline.
- All verified realtime writes are latest-target-wins, one-inflight, paced at 38 ms and fail closed on GATT uncertainty.
- MasterVolume ID2 is synchronized with Android STREAM_MUSIC in both directions:
  app slider -> phone media volume + DSP ID2
  physical phone Volume +/- -> phone media volume + app MasterVolume + DSP ID2
- Verified PEAKING EQ is editable continuously for Frequency / Q / Gain on all 15 verified bands per channel, CH1..CH7.
- App values are stored immediately in SharedPreferences and verified scalar/EQ values are replayed after a fresh read-only Health Gate on reconnect.
- Local crossover/delay/output/preset UI states are also persisted immediately.

TREBLEBOOST ID11 MITIGATION
- Retains V93 bounded safe-slew delivery: max 0.5 dB per step, 48 ms interval, next step only after matching successful GATT callback.
- This is a source-level mitigation for abrupt ID11 jumps. Real hardware/acoustic testing is still required before claiming the historic pop/thump is eliminated under every setup.

VERIFIED DSP WRITE BOUNDARY — DO NOT EXPAND WITHOUT EVIDENCE
- Scalar IDs: 2,3,8,9,10,13,11
- EQ actuator IDs: CH1=4, CH2=5, CH3=6, CH4=14, CH5=15, CH6=16, CH7=17
- EQ write: type=12 PEAKING only, 15 bands/channel, full 48-byte record
- SaveParams ID7 remains manual/guarded only and is never sent automatically.
- Preset / Delay / Crossover / channel Output-Mute-Phase hardware writes remain LOCKED because the decoded device descriptor contains no verified actuator/payload for those operations.
- V94 provides immediate UI response + persistence for those pages, but does NOT invent an unsafe DSP packet.

BUILD
- Use the separate build-okn-dsp-v94.yml workflow.
- Workflow auto-runs on push of the V94 ZIP / SHA file / workflow itself.
- JDK 17, Gradle 8.9, compileSdk 35, Android build-tools 35.0.0.
- Stable debug signing identity is preserved.

VALIDATION STATUS
- Static source preflight: run python3 preflight_v94.py
- Local Android APK compilation is not claimed by this package; GitHub Actions is the authoritative build path.
- Real DSP acoustic qualification is not claimed until the generated APK is exercised on the target hardware.
