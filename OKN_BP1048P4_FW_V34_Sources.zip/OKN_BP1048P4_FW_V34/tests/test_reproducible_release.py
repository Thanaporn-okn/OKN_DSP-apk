#!/usr/bin/env python3
from pathlib import Path
import importlib.util, os, tempfile, time, zipfile

root = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("rp", root/"tools/reproducible_package.py")
rp = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rp)

with tempfile.TemporaryDirectory(prefix="okn-v30-repro-test-") as td:
    td = Path(td)
    aroot, broot = td/"same", td/"same2"
    aroot.mkdir(); broot.mkdir()
    (aroot/"b.txt").write_bytes(b"beta\n")
    (aroot/"a.txt").write_bytes(b"alpha\n")
    (broot/"b.txt").write_bytes(b"beta\n")
    (broot/"a.txt").write_bytes(b"alpha\n")
    # root name affects archive path by design; use same name in separate parents.
    xparent, yparent = td/"x", td/"y"
    xroot, yroot = xparent/"pkg", yparent/"pkg"
    xroot.mkdir(parents=True); yroot.mkdir(parents=True)
    for dst in (xroot,yroot):
        (dst/"b.txt").write_bytes(b"beta\n")
        (dst/"a.txt").write_bytes(b"alpha\n")
    os.utime(xroot/"a.txt",(1,1)); os.utime(yroot/"a.txt",(2000000000,2000000000))
    za, zb = td/"a.zip", td/"b.zip"
    ra = rp.build_zip(xroot, za); rb = rp.build_zip(yroot, zb)
    assert za.read_bytes() == zb.read_bytes(), "mtime or creation order changed deterministic ZIP bytes"
    assert ra["tree_sha256"] == rb["tree_sha256"]
    assert rp.verify_archive(xroot, za) == []
    # Content changes must change package bytes/hash.
    (yroot/"a.txt").write_bytes(b"ALPHA CHANGED\n")
    zc = td/"c.zip"
    rc = rp.build_zip(yroot, zc)
    assert rc["zip_sha256"] != ra["zip_sha256"]
    # Symlinks are forbidden when supported by platform.
    link = xroot/"link.txt"
    try:
        link.symlink_to("a.txt")
    except (OSError, NotImplementedError):
        pass
    else:
        try:
            rp.collect_files(xroot)
        except ValueError:
            pass
        else:
            raise AssertionError("symlink was not rejected")
print("ALL V34 REPRODUCIBLE RELEASE TESTS PASS")
