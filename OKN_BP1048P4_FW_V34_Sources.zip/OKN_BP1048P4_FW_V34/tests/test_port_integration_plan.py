#!/usr/bin/env python3
from pathlib import Path
import copy,hashlib,json,sys,tempfile
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'tools'))
from target_qualification_policy import CLAIM_CLASSES
from qualification_bundle import verify_bundle
from port_integration_plan import build_plan,derive_from_files,SUBSYSTEMS
# Shipped plan is fully locked and reproducible.
plan=derive_from_files(root)
assert plan == json.loads((root/'port_integration_plan.json').read_text())
assert not plan['hardware_integration_ready'] and not plan['mobile_flash_integration_ready']
assert all(not s['ready_for_integration'] for s in plan['subsystems'].values())
# Synthetic exact evidence can complete readiness claims but still cannot authorize itself.
q=json.loads((root/'target_qualification_manifest.json').read_text())
with tempfile.TemporaryDirectory() as td:
    td=Path(td); (td/'qualification_evidence').mkdir()
    payload=b'V34 synthetic exact evidence for port-plan unit test only\n'
    f=td/'qualification_evidence'/'evidence.bin'; f.write_bytes(payload)
    sha=hashlib.sha256(payload).hexdigest(); all_classes=sorted(set().union(*CLAIM_CLASSES.values()))
    bm={'schema':1,'project_version':34,'target':'BP1048P4','board':'GoloPine 7CH','policy':'CONTENT_BOUND_HASH_VERIFIED_REVIEW_REQUIRED','state':'TEST','bundle_root':'qualification_evidence','artifacts':[{'id':'synthetic','path':'evidence.bin','sha256':sha,'source':'synthetic unit-test evidence','classifications':all_classes,'reviewed':True}]}
    vr=verify_bundle(bm,td); assert vr['ok']
    q2=copy.deepcopy(q)
    for name,classes in CLAIM_CLASSES.items():
        q2['claims'][name]={'verified':True,'reviewed':True,'classification':sorted(classes)[0],'artifact_sha256':sha,'artifact_id':'synthetic','source':'synthetic unit-test evidence','evidence_locator':'unit-test:claim/'+name}
    p=build_plan(q2,vr['verified_index'])
    assert all(s['evidence_complete'] for s in p['subsystems'].values())
    assert all(not s['ready_for_integration'] for s in p['subsystems'].values())
    q2['hardware_authorized']=True
    p=build_plan(q2,vr['verified_index'])
    assert all(s['ready_for_integration'] for k,s in p['subsystems'].items() if k!='mobile_flash')
    assert not p['subsystems']['mobile_flash']['ready_for_integration']
    q2['mobile_flash_authorized']=True
    p=build_plan(q2,vr['verified_index'])
    assert all(s['ready_for_integration'] for s in p['subsystems'].values())
# Every subsystem maps only to known claims.
for _,claims in SUBSYSTEMS.values(): assert all(c in CLAIM_CLASSES for c in claims)
print('ALL V34 PORT INTEGRATION PLAN TESTS PASS')
