#include "../src/transport/okn_stream.h"
#include "../src/core/okn_controller.h"
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

static size_t finish_pkt(uint8_t *p, uint8_t cmd, const uint8_t *payload, uint16_t plen) {
    p[0]='O'; p[1]='K'; p[2]=OKN_PROTO_VERSION; p[3]=cmd;
    p[4]=(uint8_t)plen; p[5]=(uint8_t)(plen>>8);
    if (plen) memcpy(&p[6], payload, plen);
    const uint16_t crc=okn_crc16_ccitt(p,6u+plen);
    p[6u+plen]=(uint8_t)crc; p[7u+plen]=(uint8_t)(crc>>8);
    return 8u+plen;
}

static void write_f32_le(uint8_t *p, float f) {
    uint32_t u=0u;
    memcpy(&u,&f,sizeof(u));
    p[0]=(uint8_t)u; p[1]=(uint8_t)(u>>8); p[2]=(uint8_t)(u>>16); p[3]=(uint8_t)(u>>24);
}

static size_t make_set_gain(uint8_t *p, uint8_t ch, float db) {
    uint8_t payload[5];
    payload[0]=ch; write_f32_le(&payload[1],db);
    return finish_pkt(p,OKN_CMD_SET_CH_GAIN,payload,(uint16_t)sizeof(payload));
}

typedef struct {
    okn_controller_t ctl;
    unsigned calls;
    bool fail_next_after_apply;
} fault_sink_t;

static okn_status_t on_frame_fail_after_apply(void *u, const uint8_t *f, size_t n) {
    fault_sink_t *s=(fault_sink_t*)u;
    uint8_t rsp[OKN_PROTO_MAX_PACKET];
    ++s->calls;
    const okn_protocol_result_t result=okn_protocol_execute_ex(&s->ctl,f,n,rsp,sizeof(rsp));
    if (result.transport_status!=OKN_OK) return result.transport_status;
    if (s->fail_next_after_apply) {
        s->fail_next_after_apply=false;
        return OKN_ERR_BUFFER;
    }
    return OKN_OK;
}

typedef struct {
    okn_controller_t ctl;
    unsigned calls;
    uint8_t last_cmd;
} sink_t;

static okn_status_t on_frame(void *u, const uint8_t *f, size_t n) {
    sink_t *s=(sink_t*)u;
    uint8_t rsp[160]; size_t rn=0u;
    ++s->calls; s->last_cmd=f[3];
    const okn_protocol_result_t result = okn_protocol_execute_ex(&s->ctl,f,n,rsp,sizeof(rsp));
    rn = result.response_len;
    (void)rn;
    return result.transport_status;
}

int main(void) {
    okn_stream_t st; sink_t sink;
    okn_stream_init(&st); okn_controller_init(&sink.ctl); sink.calls=0u; sink.last_cmd=0u;

    uint8_t a[32], b[32];
    size_t an=finish_pkt(a,OKN_CMD_PING,NULL,0u);
    uint8_t ch=3u; size_t bn=finish_pkt(b,OKN_CMD_GET_CHANNEL_STATE,&ch,1u);

    /* BLE-like fragmentation: 1 byte, then partial header, then remainder. */
    assert(okn_stream_feed(&st,a,1u,on_frame,&sink)==OKN_OK);
    assert(sink.calls==0u);
    assert(okn_stream_feed(&st,a+1u,4u,on_frame,&sink)==OKN_OK);
    assert(sink.calls==0u);
    assert(okn_stream_feed(&st,a+5u,an-5u,on_frame,&sink)==OKN_OK);
    assert(sink.calls==1u && sink.last_cmd==OKN_CMD_PING);

    /* Noise before frame must be discarded and resynchronized. */
    const uint8_t noise[]={0x00,0xFF,'O',0x00,0x11};
    assert(okn_stream_feed(&st,noise,sizeof(noise),on_frame,&sink)==OKN_OK);
    assert(okn_stream_feed(&st,b,bn,on_frame,&sink)==OKN_OK);
    assert(sink.calls==2u && sink.last_cmd==OKN_CMD_GET_CHANNEL_STATE);

    /* Two concatenated frames in a single transport chunk. */
    uint8_t combo[64]; memcpy(combo,a,an); memcpy(combo+an,b,bn);
    assert(okn_stream_feed(&st,combo,an+bn,on_frame,&sink)==OKN_OK);
    assert(sink.calls==4u);

    /* Corrupt frame is not delivered; following valid frame still is. */
    uint8_t bad[32]; memcpy(bad,a,an); bad[an-1u]^=1u;
    memcpy(combo,bad,an); memcpy(combo+an,a,an);
    assert(okn_stream_feed(&st,combo,an+an,on_frame,&sink)==OKN_OK);
    assert(sink.calls==5u);
    assert(st.crc_errors>=1u);
    assert(st.frames_ok==5u);

    /* Application-level rejection is encoded as an ACK and must not abort
     * subsequent valid frames in the same BLE-like chunk. */
    uint8_t unsupported[16];
    size_t un=finish_pkt(unsupported,0x66u,NULL,0u);
    memcpy(combo,unsupported,un); memcpy(combo+un,a,an);
    assert(okn_stream_feed(&st,combo,un+an,on_frame,&sink)==OKN_OK);
    assert(sink.calls==7u && st.frames_ok==7u);

    /* A fragmented frame must not remain buffered forever. Time is supplied by
     * the transport adapter; the parser owns no clock and assumes no BLE timing. */
    okn_stream_t idle; sink_t idle_sink;
    okn_stream_init(&idle); okn_controller_init(&idle_sink.ctl);
    idle_sink.calls=0u; idle_sink.last_cmd=0u;
    assert(okn_stream_feed(&idle,a,5u,on_frame,&idle_sink)==OKN_OK);
    assert(idle.len==5u && idle_sink.calls==0u);
    assert(okn_stream_note_idle(&idle,40u,50u)==OKN_OK);
    assert(idle.len==5u && idle.partial_idle_ms==40u && idle.timeout_resets==0u);
    assert(okn_stream_note_idle(&idle,9u,50u)==OKN_OK);
    assert(idle.len==5u && idle.partial_idle_ms==49u);
    assert(okn_stream_note_idle(&idle,1u,50u)==OKN_OK);
    assert(idle.len==0u && idle.partial_idle_ms==0u && idle.timeout_resets==1u);
    assert(idle.dropped_bytes>=5u);
    assert(okn_stream_feed(&idle,a,an,on_frame,&idle_sink)==OKN_OK);
    assert(idle_sink.calls==1u && idle.frames_ok==1u);

    /* Explicit session reset discards a partial frame deterministically. */
    assert(okn_stream_feed(&idle,b,3u,on_frame,&idle_sink)==OKN_OK);
    assert(idle.len==3u);
    okn_stream_reset_partial(&idle);
    assert(idle.len==0u && idle.partial_idle_ms==0u);
    assert(okn_stream_note_idle(&idle,100u,50u)==OKN_OK);
    assert(idle.timeout_resets==1u); /* no buffered data => no timeout reset */
    assert(okn_stream_note_idle(&idle,1u,0u)==OKN_ERR_ARG);

    /* V34 exactly-once dispatch regression: a CRC-valid mutating frame is
     * consumed even when the callback reports an error after applying it.
     * The following concatenated frame stays buffered and can be drained
     * later, but the mutation must never be implicitly dispatched twice. */
    {
        okn_stream_t once; fault_sink_t fs;
        okn_stream_init(&once); okn_controller_init(&fs.ctl);
        fs.calls=0u; fs.fail_next_after_apply=true;

        uint8_t setg[32], seq[64];
        const size_t gn=make_set_gain(setg,2u,-3.0f);
        memcpy(seq,setg,gn); memcpy(seq+gn,a,an);

        assert(okn_stream_feed(&once,seq,gn+an,on_frame_fail_after_apply,&fs)==OKN_ERR_BUFFER);
        assert(fs.calls==1u);
        assert(fs.ctl.revision==1u);
        assert(once.frames_ok==1u && once.callback_errors==1u);
        assert(once.len==an); /* following PING remains, failed frame does not */

        assert(okn_stream_feed(&once,NULL,0u,on_frame_fail_after_apply,&fs)==OKN_OK);
        assert(fs.calls==2u);
        assert(fs.ctl.revision==1u); /* PING is read-only; SET was not replayed */
        assert(once.frames_ok==2u && once.callback_errors==1u && once.len==0u);

        assert(okn_stream_feed(&once,NULL,0u,on_frame_fail_after_apply,&fs)==OKN_OK);
        assert(fs.calls==2u && fs.ctl.revision==1u);
    }

    puts("ALL V34 STREAM TESTS PASS");
    return 0;
}
