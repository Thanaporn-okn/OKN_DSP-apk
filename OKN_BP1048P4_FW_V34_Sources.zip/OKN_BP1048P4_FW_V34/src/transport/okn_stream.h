#ifndef OKN_STREAM_H
#define OKN_STREAM_H

#include "../core/okn_protocol.h"
#include <stddef.h>
#include <stdint.h>

#define OKN_PROTO_MAX_PACKET (8u + OKN_PROTO_MAX_PAYLOAD)
#define OKN_STREAM_BUFFER_CAP (OKN_PROTO_MAX_PACKET * 2u)

typedef okn_status_t (*okn_stream_frame_cb)(void *user, const uint8_t *frame, size_t len);

typedef struct {
    uint8_t buf[OKN_STREAM_BUFFER_CAP];
    size_t len;
    uint32_t frames_ok;
    uint32_t dropped_bytes;
    uint32_t crc_errors;
    uint32_t format_errors;
    /* Count valid frames that were consumed exactly once but whose callback
     * reported a non-OK application/delivery status. Such frames are never
     * retained for implicit redispatch. */
    uint32_t callback_errors;
    /* Transport-agnostic partial-frame idle accounting. The real BLE adapter
     * supplies elapsed milliseconds; the portable parser never reads a clock. */
    uint32_t partial_idle_ms;
    uint32_t timeout_resets;
} okn_stream_t;

void okn_stream_init(okn_stream_t *s);

/* Explicitly discard only the currently buffered partial/noise bytes. This is
 * safe to call when a BLE connection/session is reset. */
void okn_stream_reset_partial(okn_stream_t *s);

/* Report transport idle time while bytes are buffered. If the accumulated idle
 * reaches timeout_ms, the partial frame is discarded and parser resynchronizes.
 * timeout_ms is policy owned by the verified transport adapter; V13 does not
 * claim a BP1048P4/BLE timing value. */
okn_status_t okn_stream_note_idle(okn_stream_t *s,
                                  uint32_t elapsed_ms,
                                  uint32_t timeout_ms);

/* Valid CRC-checked frames are consumed exactly once before this function
 * returns a callback error. A callback failure never leaves the same valid
 * frame buffered for implicit redispatch; any following concatenated frames
 * remain buffered and may be drained by a later call. */
okn_status_t okn_stream_feed(okn_stream_t *s,
                             const uint8_t *data, size_t len,
                             okn_stream_frame_cb cb, void *user);

#endif
