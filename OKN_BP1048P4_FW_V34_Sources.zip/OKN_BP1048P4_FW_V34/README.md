# OKN_BP1048P4_FW_V34

V34 hardens the portable BLE-like byte-stream boundary so every CRC-valid frame is dispatched at most once by the parser, even when the application callback reports an error after processing it. Protocol V2 and persistence schema 2 remain unchanged.

## What V34 adds

- CRC-valid frames are consumed exactly once after callback invocation, including callback-error paths.
- A callback error can no longer leave the same mutating frame buffered for implicit redispatch.
- Later concatenated frames remain buffered and can be drained on a later transport call.
- Adds `callback_errors` telemetry without assigning any BP1048P4/BLE timing or hardware semantics.
- Adds a regression where `SET_CH_GAIN` is applied, the callback deliberately fails, and the stream is drained again; controller revision must remain incremented exactly once.
- V33 Source ZIP and uploaded GitHub validation Artifact are bound as the immediate predecessor.

## Safety status

This package is **not** a BP1048P4/GoloPine flash image. It emits no programmer packet, does not invoke a target linker, and contains no guessed BP1048P4 address, pin, boot command, memory capacity, or image format. Hardware and mobile flashing remain locked.

Run:

```sh
make host-test
```
