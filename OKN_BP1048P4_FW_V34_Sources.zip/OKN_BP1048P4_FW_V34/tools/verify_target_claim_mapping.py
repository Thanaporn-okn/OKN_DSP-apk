#!/usr/bin/env python3
import json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
m=json.loads((ROOT/'target_claim_mapping_manifest.json').read_text(encoding='utf-8'))
fw=json.loads((ROOT/'firmware_manifest.json').read_text(encoding='utf-8'))
q=json.loads((ROOT/'target_qualification_manifest.json').read_text(encoding='utf-8'))
errors=[]
if m.get('schema')!=1 or m.get('project_version')!=34: errors.append('claim mapping schema/version mismatch')
if m.get('state')!='LOCKED_NO_REVIEWED_CLAIM_MAPPING': errors.append('shipped V34 claim mapping must remain locked')
if m.get('mappings')!=[]: errors.append('shipped V34 claim mapping list must remain empty')
for k in ('mapping_requires_review_ready_document','mapping_requires_reverified_document_sha256','mapping_requires_evidence_locator','mapping_requires_reviewer','scope_allowlist_enforced'):
    if m.get(k) is not True: errors.append(k+' must be true')
for k in ('auto_promotes_target_qualification','authorizes_hardware','authorizes_mobile_flash'):
    if m.get(k) is not False: errors.append(k+' must be false')
if q.get('hardware_authorized') is not False or q.get('mobile_flash_authorized') is not False:
    errors.append('target qualification authorization must remain false')
if any(v.get('verified') or v.get('reviewed') for v in q.get('claims',{}).values()):
    errors.append('shipped V34 target qualification claims must remain unverified/unreviewed')
rh=fw.get('release_hardening',{})
if rh.get('reviewed_target_claim_mapping') is not True: errors.append('firmware manifest missing reviewed claim mapping')
if rh.get('claim_mapping_rehashes_document') is not True: errors.append('document rehash requirement missing')
if rh.get('claim_mapping_scope_allowlist') is not True: errors.append('claim scope allowlist missing')
if rh.get('claim_mapping_auto_promotes_qualification') is not False: errors.append('claim mapping auto-promotion must be false')
if errors:
    print('ERROR: V34 target claim mapping policy violation')
    for e in errors: print(' - '+e)
    sys.exit(1)
print('PASS: V34 target claim mapping binds reviewed evidence to narrow claims without auto-promotion/authorization')
