#!/usr/bin/env python3
from pathlib import Path
import json, subprocess, sys

root = Path(__file__).resolve().parents[1]
m = json.loads((root/"release_repro_manifest.json").read_text())
errors = []
if m.get("schema") != 1: errors.append("release reproducibility schema must be 1")
if m.get("project_version") != 34: errors.append("release reproducibility project_version must be 33")
if m.get("policy") != "DETERMINISTIC_SOURCE_PACKAGE_NO_HARDWARE_AUTHORIZATION":
    errors.append("release reproducibility policy mismatch")
if m.get("normalized_timestamp") != "1980-01-01T00:00:00Z":
    errors.append("normalized timestamp must remain fixed")
if m.get("regular_file_mode_octal") != "0644":
    errors.append("regular file mode must remain 0644")
for k in ("symlinks_allowed","authorizes_hardware","authorizes_mobile_flash","emits_target_firmware_image"):
    if m.get(k) is not False:
        errors.append(k+" must remain false")
for k in ("source_inventory_required","double_build_byte_identity_required","extract_roundtrip_required","source_mtime_must_not_affect_archive"):
    if m.get(k) is not True:
        errors.append(k+" must remain true")
if errors:
    for e in errors: print("BLOCKED:", e)
    raise SystemExit(1)
r = subprocess.run([sys.executable, str(root/"tools/reproducible_package.py"), "--root", str(root), "--verify"])
raise SystemExit(r.returncode)
