#!/usr/bin/env python3
from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'evidence_manifest.json').read_text())
errors=[]
if m.get('schema')!=4: errors.append('evidence schema must be 4')
if m.get('project_version')!=34: errors.append('project_version must be 33')
if m.get('target')!='BP1048P4' or m.get('board')!='GoloPine 7CH': errors.append('target/board mismatch')
if m.get('policy')!='FAIL_CLOSED_NO_INFERENCE': errors.append('policy mismatch')
if m.get('hardware_authorized') is not False: errors.append('hardware_authorized must be false')
req=m.get('required_exact_evidence',{})
if any(bool(v) for v in req.values()): errors.append('V34 exact evidence flags must all remain false')
prov=m.get('provenance',{})
if prov.get('previous_source_sha256')!='a6de1d9ebc08812e3c01517036a1e23070ef5df88b4711f1872ccb3d7e55042e': errors.append('V33 source provenance mismatch')
if prov.get('validation_zip_sha256')!='3aee30a1a1845b458098dc3dfc6363b17f2aa4270626ed7ec92974b6bf85927f': errors.append('V33 validation provenance mismatch')
if not any(o.get('id')=='v33-ci-validation' for o in m.get('observations',[])): errors.append('V33 CI observation missing')
for ob in m.get('observations',[]):
    if ob.get('authorizes') not in ([],None): errors.append('observations may not authorize hardware in V34')
if errors:
    [print('BLOCKED:',e) for e in errors]; sys.exit(1)
print('PASS: V34 evidence manifest is internally consistent and non-authorizing')
