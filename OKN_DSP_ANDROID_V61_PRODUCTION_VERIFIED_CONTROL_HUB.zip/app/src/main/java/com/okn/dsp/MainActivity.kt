package com.okn.dsp

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * V61 production verified control hub.
 *
 * Important design rule: the launcher contains NO mock/local DSP controls.
 * Every writable control exposed from this screen opens a module whose BLE write path
 * has already been runtime-proved and whose APPLY operation performs fresh descriptor
 * readback verification. Permanent SAVE remains an explicit guarded SaveParams ID7 action.
 */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
    }

    private fun buildUi(): ScrollView {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 32)
        }

        root.addView(TextView(this).apply {
            text = "OKN DSP V61 — PRODUCTION VERIFIED CONTROL HUB"
            textSize = 22f
        })

        root.addView(TextView(this).apply {
            text = "REAL DSP CONTROLS ONLY • NO MOCK EQ • NO LOCAL PRESET WRITE • GENERIC WRITES LOCKED"
            textSize = 14f
            setPadding(0, 8, 0, 12)
        })

        root.addView(TextView(this).apply {
            text = "Verified writable coverage\n" +
                "• Global FLOAT32: ID2 MasterVolume, ID8 BassVolume, ID9 BassCutoff, ID10 BassBoost, ID13 MiddleBoost, ID11 TrebleBoost\n" +
                "• EQ 7CH: CH1–CH7 actuator IDs 4,5,6,14,15,16,17 • 15 bands/channel • writable only on verified safe PEAKING bands\n" +
                "• Permanent SAVE: actuator ID7 SaveParams • exact trigger 570000000700000000 • persistence proved with two real power-cycles\n" +
                "• ID3 RemindSoundVolume is intentionally not exposed. Preset, Delay and unknown writes remain locked."
            textSize = 13f
            setPadding(0, 0, 0, 16)
        })

        root.addView(Button(this).apply {
            text = "GLOBAL CONTROLS • REAL DSP • APPLY + VERIFY + PERMANENT SAVE"
            setOnClickListener { startActivity(Intent(this@MainActivity, ScalarControlActivity::class.java)) }
        })

        root.addView(TextView(this).apply {
            text = "เปิดหน้า Global Controls ที่ใช้ WRITE 0x57 → fresh Device Description verify → rollback ถ้า verify ไม่ผ่าน และกด SaveParams แยกเมื่อพร้อม"
            textSize = 12f
            setPadding(0, 2, 0, 12)
        })

        root.addView(Button(this).apply {
            text = "LIVE EQ 7CH • REAL DSP • APPLY + VERIFY + PERMANENT SAVE"
            setOnClickListener { startActivity(Intent(this@MainActivity, LiveEqActivity::class.java)) }
        })

        root.addView(TextView(this).apply {
            text = "เปิดหน้า EQ 7CH จริงจาก Device Description • 105 bands • แก้เฉพาะ band shape ที่ policy พิสูจน์แล้ว • rollback อัตโนมัติเมื่อ readback ไม่ตรง"
            textSize = 12f
            setPadding(0, 2, 0, 12)
        })

        root.addView(Button(this).apply {
            text = "ADVANCED • EVIDENCE / CAPTURE LAB (READ-ONLY / PROOF TOOLS)"
            setOnClickListener { startActivity(Intent(this@MainActivity, EvidenceLabActivity::class.java)) }
        })

        root.addView(TextView(this).apply {
            text = "V61 removes the old launcher-side local EQ sliders and local preset controls because they were not connected to the verified live DSP write path. The two buttons above are the production entry points for the real verified modules."
            textSize = 12f
            setPadding(0, 16, 0, 0)
        })

        return ScrollView(this).apply { addView(root) }
    }
}
