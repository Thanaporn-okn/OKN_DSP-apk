OKN DSP V61 — PRODUCTION VERIFIED CONTROL HUB

Purpose
- Promote the already runtime-proved V58/V60 control paths into a clean production launcher.
- Remove launcher-side mock/local EQ sliders and local preset controls that were not wired to the verified DSP write path.
- Keep only real verified entry points: Global Controls and LIVE EQ 7CH.

Verified runtime basis
- V45/V60: six FLOAT32 global controls use WRITE 0x57 + Device Description readback verification.
- V49/V50/V51/V58: 7CH EQ actuator map and live PEAKING-band writes are verified with readback and automatic rollback on failure.
- V57: SaveParams actuator ID7 exact trigger 570000000700000000 persisted target and restored original values across two real DSP power-cycles.
- V60: recovered V59 RAM-dirty MasterVolume ID2=-59.08 from a fresh live descriptor and completed guarded permanent SaveParams with GATT status=0.

Production V61 launcher rules
- NO mock/local DSP sliders.
- NO local preset write controls.
- NO generic actuator writer.
- NO automatic SaveParams.
- ID3 RemindSoundVolume remains intentionally omitted.
- Preset, Delay and unknown writes remain locked.

Real module A — Global Controls
- IDs: 2,8,9,10,13,11 only.
- APPLY = WRITE 0x57 -> fresh Device Description -> verify.
- Verify failure = write original value back -> fresh descriptor verify.
- Permanent SAVE is a separate guarded action using only SaveParams ID7.

Real module B — LIVE EQ 7CH
- CH1..CH7 actuator IDs: 4,5,6,14,15,16,17.
- 15 bands/channel read from live Device Description.
- Only policy-safe PEAKING type=12 bands are writable.
- APPLY = full 48-byte band WRITE -> fresh descriptor verify.
- Verify failure = automatic exact previous-record rollback + verify.
- Permanent SAVE is a separate guarded action using only SaveParams ID7.

Build target
- versionCode 61
- versionName 4.3.0-v61-production-verified-control-hub
- debug APK: OKN_DSP_V61_PRODUCTION_VERIFIED_CONTROL_HUB-debug.apk
