package com.okn.dsp.core

import android.content.Context
import com.okn.dsp.logging.DspLogger
import com.okn.dsp.persistence.DspPreferences
import com.okn.dsp.repository.DeviceRepository
import com.okn.dsp.repository.DspRepository
import com.okn.dsp.repository.SensorRepository
import com.okn.dsp.state.DspStateStore

/** V2 process-scoped runtime. UI is a pure observer/command client. */
class DspRuntime(context: Context) {
    val store = DspStateStore()
    val logger = DspLogger()
    val dsp = DspRepository(context.applicationContext, store, logger, DspPreferences(context.applicationContext))
    val devices = DeviceRepository(dsp)
    val sensors = SensorRepository(store)
}
