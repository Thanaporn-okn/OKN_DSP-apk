package com.okn.dsp.protocol

/** OKN_DSP V2 confirmed mappings recovered from verified target-device descriptor/capture evidence. */
object ConfirmedDspMap {
    const val MASTER_VOLUME = 2
    const val REMIND_SOUND_VOLUME = 3
    const val SAVE_PARAMS = 7
    const val BASS_VOLUME = 8
    const val BASS_CUTOFF = 9
    const val BASS_BOOST = 10
    const val TREBLE_BOOST = 11
    const val MIDDLE_BOOST = 13

    val EQ_ACTUATOR_BY_CHANNEL = intArrayOf(4, 5, 6, 14, 15, 16, 17)

    const val EQ_BAND_COUNT = 15
    const val EQ_BAND_BYTES = 48
    const val SAMPLE_RATE_HZ = 44100

    fun eqActuator(channelIndex: Int): Int = EQ_ACTUATOR_BY_CHANNEL[channelIndex.coerceIn(0, 6)]

    /** Band number is 1-based. Example: Band 7 -> offset 288 bytes. */
    fun eqBandOffset(band: Int): Int = (band.coerceIn(1, EQ_BAND_COUNT) - 1) * EQ_BAND_BYTES
}
