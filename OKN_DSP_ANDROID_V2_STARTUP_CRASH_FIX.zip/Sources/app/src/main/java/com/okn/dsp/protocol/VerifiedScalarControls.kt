package com.okn.dsp.protocol

import kotlin.math.abs

data class VerifiedScalarControl(
    val id: Int,
    val name: String,
    val min: Float,
    val max: Float,
    val unit: String,
    val step: Float = 1.0f,
)

/**
 * OKN_DSP V2 verified scalar allow-list. These IDs come from the proven target-device
 * descriptor/write evidence. SaveParams ID=7, EQ actuator IDs and unknown IDs are
 * intentionally excluded from this scalar serializer.
 */
object VerifiedScalarControls {
    val controls = listOf(
        VerifiedScalarControl(2, "MasterVolume", -70f, 6f, "dB"),
        VerifiedScalarControl(3, "RemindSoundVolume", -70f, 6f, "dB"),
        VerifiedScalarControl(8, "BassVolume", -70f, 6f, "dB"),
        VerifiedScalarControl(9, "BassCutoff", 20f, 250f, "Hz"),
        VerifiedScalarControl(10, "BassBoost", -12f, 12f, "dB"),
        VerifiedScalarControl(13, "MiddleBoost", -12f, 12f, "dB"),
        VerifiedScalarControl(11, "TrebleBoost", -12f, 12f, "dB"),
    )

    private val byId = controls.associateBy { it.id }
    fun byId(id: Int): VerifiedScalarControl? = byId[id]
    fun allowed(id: Int): Boolean = byId.containsKey(id)

    fun sanitize(id: Int, value: Float): Float? {
        val c = byId(id) ?: return null
        if (!value.isFinite() || value < c.min || value > c.max) return null
        return value
    }

    fun matches(id: Int, actual: Float, expected: Float): Boolean {
        val c = byId(id) ?: return false
        val tolerance = if (c.unit == "Hz") 0.11f else 0.06f
        return actual.isFinite() && abs(actual - expected) <= tolerance
    }
}
