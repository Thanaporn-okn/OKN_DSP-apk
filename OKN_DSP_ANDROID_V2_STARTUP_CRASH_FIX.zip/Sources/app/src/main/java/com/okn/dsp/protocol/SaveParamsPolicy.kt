package com.okn.dsp.protocol

/**
 * OKN_DSP V2 manual permanent-save policy. The exact trigger is a verified packet and
 * is intentionally never sent by sliders, reconnect, local persistence, presets or
 * background lifecycle events.
 */
object SaveParamsPolicy {
    const val ACTUATOR_ID = 7
    const val TYPE_ID = 2100
    const val TEST_CHANNEL = 1
    const val TEST_BAND = 4
    const val TEST_ACTUATOR = 4
    const val TEST_OFFSET = 144
    const val ORIGINAL_BOOST_DB = 0.0f
    const val TEST_BOOST_DB = -0.1f
    const val V51_LIVE_BOOST_DB = -0.2f
    const val BOOST_TOL = 0.0065f

    fun encodeTrigger(): ByteArray = UfeCodec.encodeWrite(ACTUATOR_ID, 0, byteArrayOf())

    fun triggerIsExact(): Boolean = ByteCodec.run { encodeTrigger().toHex() } == "570000000700000000"

    fun safeBandShape(b: EqBand48): Boolean =
        LiveEqPolicy.isWritable(b) &&
            kotlin.math.abs(b.frequency - 100.0f) <= 0.15f &&
            kotlin.math.abs(b.q - 2.23f) <= 0.02f

    fun boostMatches(actual: Float, expected: Float): Boolean =
        kotlin.math.abs(actual - expected) <= BOOST_TOL

    fun exactOriginalFrom(current: EqBand48): EqBand48 {
        require(safeBandShape(current)) { "unexpected CH1 Band4 shape" }
        return LiveEqPolicy.targetFromCurrent(current, ORIGINAL_BOOST_DB)
    }

    fun testTargetFrom(original: EqBand48): EqBand48 {
        require(safeBandShape(original)) { "unexpected CH1 Band4 shape" }
        require(boostMatches(original.boostDb, ORIGINAL_BOOST_DB)) { "baseline must be 0.0 dB" }
        return LiveEqPolicy.targetFromCurrent(original, TEST_BOOST_DB)
    }
}
