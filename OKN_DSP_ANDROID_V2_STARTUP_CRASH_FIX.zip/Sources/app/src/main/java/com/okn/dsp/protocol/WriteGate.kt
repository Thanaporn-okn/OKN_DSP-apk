package com.okn.dsp.protocol

/**
 * OKN_DSP V2 hardware-write boundary.
 *
 * The app exposes only protocol surfaces that were already verified on the target DSP:
 * the seven scalar actuator IDs, the seven-channel safe PEAKING EQ records, and the
 * exact manual SaveParams trigger. Generic, preset, delay, crossover and unknown
 * hardware writes stay disabled until their packet maps are independently verified.
 */
object WriteGate {
    /** Generic actuator writes are deliberately impossible. */
    const val enabled: Boolean = false
    const val verifiedScalarControlsEnabled: Boolean = true
    const val verifiedEqWritesEnabled: Boolean = true
    const val manualSaveParamsEnabled: Boolean = true
    const val presetHardwareWritesEnabled: Boolean = false
    const val crossoverWritesEnabled: Boolean = false
    const val delayWritesEnabled: Boolean = false
    const val unknownOutputWritesEnabled: Boolean = false
}
