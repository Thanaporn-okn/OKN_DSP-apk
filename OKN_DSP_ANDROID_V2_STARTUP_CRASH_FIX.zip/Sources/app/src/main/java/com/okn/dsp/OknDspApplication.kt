package com.okn.dsp

import android.app.Application
import com.okn.dsp.core.DspRuntime
import com.okn.dsp.error.StartupCrashStore

/**
 * V2: application startup must never eagerly construct Bluetooth/DSP runtime.
 * Runtime is created only when MainActivity is ready to present a recoverable UI.
 */
class OknDspApplication : Application() {
    val runtime: DspRuntime by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        DspRuntime(applicationContext)
    }

    override fun onCreate() {
        super.onCreate()
        StartupCrashStore.install(this)
    }
}
