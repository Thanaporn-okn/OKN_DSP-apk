OKN_DSP V2 — STARTUP CRASH FIX
==============================

Version
- applicationId: com.okn.dsp
- versionCode: 2
- versionName: 1.0.1-v2-startup-fix

Reason for V2
- V1 installed successfully but Android showed an app-defect/closed dialog immediately when launching.
- The screenshot proves a startup crash, but without device logcat it does not identify the exact exception.
- V2 therefore removes the unguarded startup chain that could turn a system-service/runtime issue into a process crash.

V2 startup changes
1. DspRuntime is lazy. Application.onCreate no longer constructs the BLE/DSP stack eagerly.
2. MainActivity wraps main UI startup and falls back to an in-app recovery screen instead of a blind crash-loop.
3. PhoneVolumeBridge is optional at startup and cannot terminate the app if AudioManager integration fails.
4. Settings.System ContentObserver registration is guarded.
5. Automatic reconnect no longer requests Bluetooth permission before the first usable frame. It runs only when permission already exists.
6. Lifecycle, rotation and physical-volume-key paths guard uninitialized startup components.
7. StartupCrashStore records the latest uncaught stack trace locally for the next diagnostic cycle.

UI contract
- Uses only the two user-supplied Home/EQ reference images.
- Home and EQ reference image hashes remain unchanged from the uploaded masters.
- Dynamic verified controls update immediately on touch.

Verified hardware boundary preserved
- BLE service AB00; AB01 write; AB02 notify; AB03 known secondary path.
- Scalar actuator IDs: 2,3,8,9,10,13,11 only.
- EQ actuators CH1..CH7: 4,5,6,14,15,16,17.
- Only verified PEAKING type=12 full 48-byte EQ records are writable.
- Generic unknown, Crossover, Delay, unknown Output and unverified preset hardware writes remain locked.
- Manual SaveParams remains the exact guarded ID7 path only.

Build
- compileSdk/targetSdk 35
- minSdk 26
- JDK 17
- Gradle 8.9
- stable debug signer preserved
- GitHub Actions workflow auto-runs on OKN_DSP_ANDROID_V*.zip pushes.

Important
- V2 is a source-level startup hardening fix. Full Android compilation is performed by GitHub Actions.
- Physical DSP behavior still requires testing on the target DSP after APK installation.

V2 concrete source defect fixed
- V1 used AudioManager.setStreamVolume() for Master Volume <-> phone volume sync but AndroidManifest.xml did not declare android.permission.MODIFY_AUDIO_SETTINGS.
- V2 declares MODIFY_AUDIO_SETTINGS and also guards the entire phone-volume bridge so a system-volume failure cannot crash startup.
