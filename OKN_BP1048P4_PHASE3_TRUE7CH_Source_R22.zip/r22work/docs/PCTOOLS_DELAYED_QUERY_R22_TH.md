# R22 — Delayed ACP/PCTools Query Probe

R22 ปิดเส้นทาง boot-entry จาก R20/R21 ชั่วคราว แล้วตรวจ transport ของ normal firmware ให้ชัดเจนขึ้น.

## สิ่งที่ส่งได้
- `A5 5A 00 00 16` จำนวน 1 ครั้งต่อ app launch — query firmware info
- `A5 5A 11 00 16` จำนวน 1 ครั้งต่อ app launch — query PC Tools burn/version info

แต่ละ frame ถูก zero-pad เป็น HID Output report 256 bytes บน IF4. หลังส่งแล้ว R22 ทำเฉพาะ HID Input GET_REPORT ที่ +5, +20, +50, +100, +250, +500, +1000, +2000 ms.

## สิ่งที่ R22 ห้าม
- ไม่มี Feature SET_REPORT สำหรับเข้า bootloader
- ไม่มี AA / 0x55 boot-arm
- ไม่มี 0xFE / 0xFD
- ไม่มี MVA payload
- ไม่มี erase/program/commit
- ไม่มี endpoint OUT หรือ bulk transfer

## เหตุผล
R17 เคย query 0x00/0x11 แล้วไม่พบ reply แต่ polling หลังส่งสั้นมาก. R22 ส่ง query เพียงครั้งเดียวแล้วขยายหน้าต่างรับ reply ถึง 2 วินาที เพื่อแยกว่าเป็น timing issue หรือ normal firmware ไม่เปิด ACP/PCTools data transport ผ่าน USB.
