# OKN BP1048P4 R22

R22 ใช้ Samsung S25+ ต่อ USB-C เข้าบอร์ดโดยตรงเพื่อทดสอบ normal-app HID transport แบบ query-only.

หลัง R21 ยืนยันว่า 0x55 ได้ ACK แต่ไม่เกิด flashboot takeover, R22 จะไม่ส่ง 0x55/AA อีก. รุ่นนี้ส่งได้เฉพาะคำขออ่าน `0x00` และ `0x11` อย่างละหนึ่งครั้งต่อการเปิดแอป แล้ว poll HID Input GET_REPORT ถึง +2000ms.

ลำดับใช้งาน: `2 SCAN` → `3 INSPECT` → ทดสอบ `5` ก่อน. ถ้า 0x00 ไม่ตอบ ค่อยทดสอบ `6` 0x11. จากนั้น `8 COPY WHOLE LOG`.

ไม่มี firmware payload, MVA, erase, program, commit หรือ boot-entry Feature SET_REPORT.
