package com.okn.dsp.usbprobe;

import android.app.*;
import android.os.*;
import android.content.*;
import android.hardware.usb.*;
import android.widget.*;
import java.util.*;
import java.text.SimpleDateFormat;

/**
 * R22 is a narrowly-scoped normal-app transport diagnostic.
 * It NEVER requests bootloader entry and NEVER sends firmware/flash commands.
 * The only host->device writes are one-shot, documented query-only HID Output reports:
 *   A5 5A 00 00 16   firmware information query
 *   A5 5A 11 00 16   PC-Tools burn/version information query
 * Each semantic frame is zero-padded to the board's 256-byte HID Output report.
 * After one query, R22 only polls HID Input GET_REPORT at increasing delays.
 */
public final class MainActivity extends Activity {
    private static final String ACTION_USB_PERMISSION = "com.okn.dsp.usbprobe.USB_PERMISSION";

    private static final int TARGET_NORMAL_VID = 0x6324;
    private static final int TARGET_NORMAL_PID = 0x1719;
    private static final byte[] TARGET_NORMAL_DEVICE = hx(
            "12 01 10 01 00 00 00 40 24 63 19 17 00 01 01 02 03 01");
    private static final byte[] TARGET_NORMAL_IF4_REPORT = hx(
            "06 00 FF 0A AA 55 A1 01 15 00 26 FF 00 75 08 96 00 01 09 01 81 02 " +
            "96 00 01 09 01 91 02 95 08 09 01 B1 02 C0");

    private UsbManager usb;
    private TextView log;
    private UsbDevice selected;
    private volatile boolean watchStop;
    private volatile boolean query00Used;
    private volatile boolean query11Used;
    private Capture lastCapture;

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            String a = i.getAction();
            if (ACTION_USB_PERMISSION.equals(a)) {
                UsbDevice d = i.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                if (!i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false) || d == null) {
                    add("USB permission denied");
                    return;
                }
                selected = d;
                add("USB permission granted: " + sig(d));
                inspectReadOnly(d);
                return;
            }
            if (UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(a)) {
                UsbDevice d = i.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                add("USB ATTACHED: " + (d == null ? "<unknown>" : sig(d)));
                return;
            }
            if (UsbManager.ACTION_USB_DEVICE_DETACHED.equals(a)) {
                UsbDevice d = i.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                add("USB DETACHED: " + (d == null ? "<unknown>" : sig(d)));
                if (selected != null && d != null && selected.getDeviceId() == d.getDeviceId()) selected = null;
            }
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        usb = (UsbManager)getSystemService(USB_SERVICE);
        buildUi();
        IntentFilter f = new IntentFilter(ACTION_USB_PERMISSION);
        f.addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED);
        f.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, RECEIVER_NOT_EXPORTED);
        else registerReceiver(receiver, f);
        readExitHistory();
    }

    @Override protected void onDestroy() {
        watchStop = true;
        super.onDestroy();
        try { unregisterReceiver(receiver); } catch (Exception ignored) {}
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24,24,24,24);

        TextView title = new TextView(this);
        title.setText("OKN MVSilicon Direct USB-C Diagnostic R22\n" +
                "S25+ ↔ GoloPine BP1048P4\n" +
                "Delayed ACP/PCTools query polling — NO BOOT ENTRY / NO ERASE / NO PROGRAM");
        title.setTextSize(18);

        Button exits = new Button(this); exits.setText("1) READ APP EXIT HISTORY");
        Button scan = new Button(this); scan.setText("2) SCAN USB + CLASSIFY (PASSIVE)");
        Button inspect = new Button(this); inspect.setText("3) INSPECT GOLOPINE (READ-ONLY)");
        Button sole = new Button(this); sole.setText("4) INSPECT SOLE USB DEVICE (READ-ONLY)");
        Button q00 = new Button(this); q00.setText("5) ONE-SHOT 0x00 FIRMWARE-INFO QUERY + DELAYED POLL");
        Button q11 = new Button(this); q11.setText("6) ONE-SHOT 0x11 PCTOOLS VERSION QUERY + DELAYED POLL");
        Button watch = new Button(this); watch.setText("7) WATCH ENUMERATION 20s (PASSIVE)");
        Button copy = new Button(this); copy.setText("8) COPY WHOLE LOG");
        Button clear = new Button(this); clear.setText("CLEAR LOG");

        log = new TextView(this);
        log.setTextIsSelectable(true);
        ScrollView sv = new ScrollView(this);
        sv.addView(log);

        root.addView(title); root.addView(exits); root.addView(scan); root.addView(inspect);
        root.addView(sole); root.addView(q00); root.addView(q11); root.addView(watch); root.addView(copy); root.addView(clear);
        root.addView(sv, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);

        exits.setOnClickListener(v -> readExitHistory());
        scan.setOnClickListener(v -> scanPassive());
        inspect.setOnClickListener(v -> selectAndInspect(true));
        sole.setOnClickListener(v -> selectAndInspect(false));
        q00.setOnClickListener(v -> confirmDelayedQuery(0x00));
        q11.setOnClickListener(v -> confirmDelayedQuery(0x11));
        watch.setOnClickListener(v -> watchEnumeration20s());
        copy.setOnClickListener(v -> copyLog());
        clear.setOnClickListener(v -> log.setText(""));
    }

    private void readExitHistory() {
        add("=== ANDROID APP EXIT HISTORY ===");
        add("Model: " + Build.MANUFACTURER + " " + Build.MODEL + " SDK=" + Build.VERSION.SDK_INT);
        if (Build.VERSION.SDK_INT < 30) { add("ApplicationExitInfo unavailable below API 30."); return; }
        try {
            ActivityManager am = (ActivityManager)getSystemService(ACTIVITY_SERVICE);
            List<ApplicationExitInfo> infos = am.getHistoricalProcessExitReasons(getPackageName(), 0, 8);
            add("Historical exits: " + infos.size());
            SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS Z", Locale.US);
            int idx = 0;
            for (ApplicationExitInfo info : infos) {
                idx++;
                add("EXIT #" + idx + ": time=" + fmt.format(new Date(info.getTimestamp())) +
                        " reason=" + info.getReason() + " status=" + info.getStatus());
                String desc = info.getDescription();
                if (desc != null && !desc.isEmpty()) add("  description=" + desc);
            }
        } catch (Throwable t) {
            add("Exit-history read failed: " + t.getClass().getSimpleName() + ": " + safe(t.getMessage()));
        }
        add("=== END EXIT HISTORY ===");
    }

    private void scanPassive() {
        add("=== R22 PASSIVE USB SCAN ===");
        Map<String,UsbDevice> devices = usb.getDeviceList();
        add("USB devices: " + devices.size());
        selected = null;
        for (UsbDevice d : devices.values()) {
            addDeviceSummary(d);
            if (selected == null && isExactNormalId(d)) selected = d;
        }
        if (selected != null) add("Selected candidate: " + sig(selected));
        else add("No exact GoloPine 6324:1719 candidate. Button 4 is allowed only when exactly one USB device is attached.");
        add("PASSIVE means Android enumeration only; no UsbDeviceConnection opened.");
        add("=== END R22 PASSIVE USB SCAN ===");
    }

    private void selectAndInspect(boolean exactOnly) {
        Map<String,UsbDevice> devices = usb.getDeviceList();
        UsbDevice d = null;
        if (exactOnly) {
            for (UsbDevice x : devices.values()) if (isExactNormalId(x)) { d = x; break; }
            if (d == null) { add("No exact 6324:1719 device found. Run button 2 first."); return; }
        } else {
            if (devices.size() != 1) { add("BLOCKED: button 4 requires exactly one attached USB device; found " + devices.size() + "."); return; }
            d = devices.values().iterator().next();
        }
        selected = d;
        if (usb.hasPermission(d)) inspectReadOnly(d); else requestPermission(d);
    }

    private void requestPermission(UsbDevice d) {
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0);
        PendingIntent pi = PendingIntent.getBroadcast(this, 0,
                new Intent(ACTION_USB_PERMISSION).setPackage(getPackageName()), flags);
        add("Requesting Android USB permission for " + sig(d));
        usb.requestPermission(d, pi);
    }

    private boolean isExactNormalId(UsbDevice d) {
        return d != null && d.getVendorId()==TARGET_NORMAL_VID && d.getProductId()==TARGET_NORMAL_PID;
    }

    private void addDeviceSummary(UsbDevice d) {
        add(sig(d));
        add("  devClass=" + d.getDeviceClass() + " sub=" + d.getDeviceSubclass() + " proto=" + d.getDeviceProtocol());
        for (int i=0; i<d.getInterfaceCount(); i++) {
            UsbInterface x = d.getInterface(i);
            add("  IDX" + i + " IF" + x.getId() + " alt=" + x.getAlternateSetting() +
                    " class=" + x.getInterfaceClass() + " sub=" + x.getInterfaceSubclass() +
                    " proto=" + x.getInterfaceProtocol() + " ep=" + x.getEndpointCount() +
                    " name=" + safe(x.getName()));
            for (int e=0; e<x.getEndpointCount(); e++) {
                UsbEndpoint ep = x.getEndpoint(e);
                add("    EP addr=0x" + String.format(Locale.US,"%02X",ep.getAddress()) +
                        " dir=" + (ep.getDirection()==UsbConstants.USB_DIR_IN?"IN":"OUT") +
                        " type=" + ep.getType() + " max=" + ep.getMaxPacketSize() +
                        " interval=" + ep.getInterval());
            }
        }
    }

    private void inspectReadOnly(UsbDevice d) {
        new Thread(() -> {
            ui("=== R22 DIRECT USB-C READ-ONLY INSPECTION ===");
            ui("Target: " + sig(d));
            UsbDeviceConnection c = usb.openDevice(d);
            if (c == null) { ui("openDevice: FAILED"); return; }
            try {
                Capture cap = new Capture();
                cap.androidSig = sig(d);
                ui("openDevice: OK");
                ui("Android strings: manufacturer=" + safe(d.getManufacturerName()) +
                        " product=" + safe(d.getProductName()) + " serial=" + safe(d.getSerialNumber()) +
                        " version=" + safe(d.getVersion()));

                byte[] dd = new byte[18];
                int dn = c.controlTransfer(0x80, 0x06, 0x0100, 0, dd, dd.length, 1500);
                ui("GET_DESCRIPTOR DEVICE => " + dn + " bytes" + (dn>0?"\n  "+hex(dd,dn):""));
                if (dn > 0) cap.device = Arrays.copyOf(dd,dn);

                byte[] cfg9 = new byte[9];
                int c9 = c.controlTransfer(0x80,0x06,0x0200,0,cfg9,cfg9.length,1500);
                ui("GET_DESCRIPTOR CONFIG header => " + c9 + " bytes" + (c9>0?"\n  "+hex(cfg9,c9):""));
                if (c9 >= 4) {
                    int total=(cfg9[2]&0xFF)|((cfg9[3]&0xFF)<<8);
                    byte[] cfg=new byte[Math.max(9,Math.min(total,4096))];
                    int cn=c.controlTransfer(0x80,0x06,0x0200,0,cfg,cfg.length,1500);
                    ui("GET_DESCRIPTOR CONFIG full requested=" + cfg.length + " => " + cn + " bytes");
                    if (cn > 0) { cap.config=Arrays.copyOf(cfg,cn); ui("  CONFIG: " + hex(cfg,cn)); }
                }

                for (int i=0; i<d.getInterfaceCount(); i++) {
                    UsbInterface x=d.getInterface(i);
                    if (x.getInterfaceClass()==UsbConstants.USB_CLASS_HID) {
                        byte[] rd=new byte[512];
                        int rn=c.controlTransfer(0x81,0x06,0x2200,x.getId(),rd,rd.length,1500);
                        ui("IF"+x.getId()+" HID GET_DESCRIPTOR REPORT => "+rn+" bytes" + (rn>0?"\n  REPORT: "+hex(rd,rn):""));
                        if (rn > 0) cap.hidReports.put(x.getId(),Arrays.copyOf(rd,rn));
                    }
                }

                boolean devOk = eq(cap.device,TARGET_NORMAL_DEVICE);
                boolean if4Ok = eq(cap.hidReports.get(4),TARGET_NORMAL_IF4_REPORT);
                cap.exactNormal = isExactNormalId(d) && d.getInterfaceCount()==7 && devOk && if4Ok;
                lastCapture = cap;
                ui("R22 EXACT NORMAL GATE: " + (cap.exactNormal?"PASS":"FAIL"));
                ui("R22 SAFETY RESULT: descriptor-only inspection complete.");
                ui("No Output report was sent by inspection.");
            } catch (Throwable t) {
                ui("R22 inspection exception: " + t.getClass().getSimpleName() + ": " + safe(t.getMessage()));
            } finally {
                c.close();
                ui("=== END R22 READ-ONLY INSPECTION ===");
            }
        }, "okn-r22-readonly").start();
    }

    private void confirmDelayedQuery(int ctrl) {
        if (ctrl!=0x00 && ctrl!=0x11) { add("INTERNAL BLOCK: unsupported query control."); return; }
        if ((ctrl==0x00 && query00Used) || (ctrl==0x11 && query11Used)) {
            add(String.format(Locale.US,"BLOCKED: 0x%02X query is one-shot per app launch.",ctrl));
            return;
        }
        UsbDevice d = null;
        for (UsbDevice x : usb.getDeviceList().values()) if (isExactNormalId(x)) { d=x; break; }
        if (d == null) { add("BLOCKED: exact normal device 6324:1719 is not attached."); return; }
        if (!usb.hasPermission(d)) {
            add("BLOCKED: grant USB permission first with button 3. R22 will not auto-send a query after permission.");
            requestPermission(d);
            return;
        }
        final UsbDevice target=d;
        final String what = ctrl==0x00 ? "firmware information" : "PC-Tools burn/version information";
        new AlertDialog.Builder(this)
                .setTitle(String.format(Locale.US,"R22 one-shot 0x%02X query",ctrl))
                .setMessage("This sends exactly ONE documented query-only HID Output report for " + what +
                        ". Data length is zero. Then R22 performs Input GET_REPORT polls only. " +
                        "NO boot-entry Feature SET_REPORT, NO firmware payload, NO erase/program/commit. Run once?")
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("RUN ONCE", (dlg,which) -> executeDelayedQuery(target,ctrl))
                .show();
    }

    private void executeDelayedQuery(UsbDevice d, int ctrl) {
        if (ctrl==0x00) { if (query00Used) { add("BLOCKED: 0x00 already consumed."); return; } query00Used=true; }
        else { if (query11Used) { add("BLOCKED: 0x11 already consumed."); return; } query11Used=true; }

        new Thread(() -> {
            ui(String.format(Locale.US,"=== R22 ONE-SHOT QUERY CTRL 0x%02X + DELAYED INPUT POLL ===",ctrl));
            ui("Target: " + sig(d));
            ui("SAFETY: exactly one query-only HID Output SET_REPORT; then control-IN reads only.");
            UsbDeviceConnection c=usb.openDevice(d);
            if(c==null){ ui("openDevice: FAILED"); return; }
            try {
                if (!exactNormalGate(c,d)) { ui("GATE FAIL: exact normal board fingerprint not present. No query sent."); return; }

                byte[] baseline=new byte[256];
                int baseN=c.controlTransfer(0xA1,0x01,0x0100,4,baseline,baseline.length,1200);
                ui("Baseline GET_REPORT INPUT => "+baseN+" bytes"+(baseN>0?": "+hex(baseline,Math.min(baseN,64)):""));

                byte[] tx=new byte[256];
                tx[0]=(byte)0xA5; tx[1]=0x5A; tx[2]=(byte)ctrl; tx[3]=0x00; tx[4]=0x16;
                ui("TX semantic frame: "+hex(tx,5)+" (LEN=0 query; bytes 5..255 are zero padding)");
                int wn=c.controlTransfer(0x21,0x09,0x0200,4,tx,tx.length,1200);
                ui("SET_REPORT OUTPUT query => "+wn+" bytes");
                if(wn!=256){ ui("STOP: query was not accepted as a 256-byte Output report. No retry is sent."); return; }

                long t0=SystemClock.elapsedRealtime();
                int[] targetMs={5,20,50,100,250,500,1000,2000};
                boolean matched=false;
                for(int ms:targetMs){
                    long wait=t0+ms-SystemClock.elapsedRealtime();
                    if(wait>0) SystemClock.sleep(wait);
                    byte[] rx=new byte[256];
                    int rn=c.controlTransfer(0xA1,0x01,0x0100,4,rx,rx.length,1200);
                    ui(String.format(Locale.US,"POLL +%dms GET_REPORT INPUT => %d bytes%s",ms,rn,rn>0?": "+hex(rx,Math.min(rn,64)):""));
                    if(rn>0){
                        int off=findAcpFrame(rx,rn,ctrl);
                        if(off>=0){
                            int len=rx[off+3]&0xFF;
                            int total=len+5;
                            ui("MATCHED ACP/PCTOOLS FRAME @offset "+off+": "+hex(Arrays.copyOfRange(rx,off,off+total),total));
                            decodeKnownRead(ctrl,rx,off,len);
                            matched=true;
                            break;
                        }
                    }
                }
                if(!matched) ui(String.format(Locale.US,"CTRL 0x%02X RESULT: NO VALID MATCHING FRAME through +2000ms after one query.",ctrl));

                byte[] feature=new byte[8];
                int fn=c.controlTransfer(0xA1,0x01,0x0300,4,feature,feature.length,1200);
                ui("Final Feature GET_REPORT (read-only sanity) => "+fn+" bytes"+(fn>0?": "+hex(feature,fn):""));
                ui("R22 QUERY DONE. No boot-entry Feature SET_REPORT and no flash operation was sent.");
            } catch(Throwable t){
                ui(String.format(Locale.US,"CTRL 0x%02X exception: %s: %s",ctrl,t.getClass().getSimpleName(),safe(t.getMessage())));
            } finally {
                try{c.close();}catch(Throwable ignored){}
                ui(String.format(Locale.US,"=== END R22 QUERY CTRL 0x%02X ===",ctrl));
            }
        },"okn-r22-delayed-query").start();
    }

    private boolean exactNormalGate(UsbDeviceConnection c, UsbDevice d) {
        if(!isExactNormalId(d) || d.getInterfaceCount()!=7) return false;
        byte[] dd=new byte[18];
        int dn=c.controlTransfer(0x80,0x06,0x0100,0,dd,dd.length,1200);
        ui("Gate DEVICE => "+dn+" bytes: "+(dn>0?hex(dd,dn):"<none>"));
        if(dn!=18 || !eq(dd,TARGET_NORMAL_DEVICE)) return false;
        byte[] rd=new byte[128];
        int rn=c.controlTransfer(0x81,0x06,0x2200,4,rd,rd.length,1200);
        ui("Gate IF4 REPORT => "+rn+" bytes: "+(rn>0?hex(rd,rn):"<none>"));
        return rn==TARGET_NORMAL_IF4_REPORT.length && eq(Arrays.copyOf(rd,rn),TARGET_NORMAL_IF4_REPORT);
    }

    private static int findAcpFrame(byte[] b,int n,int expectedCtrl){
        if(b==null || n<5) return -1;
        int limit=Math.min(n-5,16);
        for(int off=0;off<=limit;off++){
            if((b[off]&0xFF)!=0xA5 || (b[off+1]&0xFF)!=0x5A || (b[off+2]&0xFF)!=expectedCtrl) continue;
            int len=b[off+3]&0xFF;
            int total=len+5;
            if(off+total>n || off+total>b.length || total<5) continue;
            if((b[off+total-1]&0xFF)==0x16) return off;
        }
        return -1;
    }

    private void decodeKnownRead(int ctrl,byte[] b,int off,int len){
        int p=off+4;
        if(ctrl==0x11 && len>=4){
            StringBuilder s=new StringBuilder();
            s.append(String.format(Locale.US,"0x11 PCTools version: firmwareType=0x%02X version=%d.%d.%d",
                    b[p]&0xFF,b[p+1]&0xFF,b[p+2]&0xFF,b[p+3]&0xFF));
            if(len>4) s.append(" rest="+hex(Arrays.copyOfRange(b,p+4,p+len),len-4));
            ui(s.toString());
        } else if(ctrl==0x00){
            ui("0x00 firmware-info body length="+len+" raw="+hex(Arrays.copyOfRange(b,p,p+len),len));
            if(len>=4) ui(String.format(Locale.US,"  chip/family=0x%02X firmwareVersion=%d.%d.%d",b[p]&0xFF,b[p+1]&0xFF,b[p+2]&0xFF,b[p+3]&0xFF));
        }
    }

    private void watchEnumeration20s(){
        watchStop=false;
        add("=== R22 20s PASSIVE ENUMERATION WATCH ===");
        new Thread(() -> {
            long end=SystemClock.elapsedRealtime()+20000;
            String prev=""; int change=0;
            while(!watchStop && SystemClock.elapsedRealtime()<end){
                String now=snapshotShallow();
                if(!now.equals(prev)){ change++; ui("WATCH CHANGE #"+change+" t="+SystemClock.elapsedRealtime()+"ms\n"+now); prev=now; }
                SystemClock.sleep(250);
            }
            ui("R22 WATCH DONE. changes="+change);
            ui("=== END R22 WATCH ===");
        },"okn-r22-passive-watch").start();
    }

    private String snapshotShallow(){
        List<UsbDevice> ds=new ArrayList<>(usb.getDeviceList().values());
        ds.sort(Comparator.comparingInt(UsbDevice::getVendorId).thenComparingInt(UsbDevice::getProductId).thenComparingInt(UsbDevice::getDeviceId));
        StringBuilder s=new StringBuilder(); s.append("devices=").append(ds.size());
        for(UsbDevice d:ds) s.append("\n  ").append(sig(d));
        return s.toString();
    }

    private void copyLog(){
        ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("OKN direct USB-C R22 log",log.getText()));
        Toast.makeText(this,"Log copied",Toast.LENGTH_SHORT).show();
    }

    private static String sig(UsbDevice d){
        return String.format(Locale.US,"VID:PID=%04X:%04X interfaces=%d deviceId=%d name=%s",
                d.getVendorId(),d.getProductId(),d.getInterfaceCount(),d.getDeviceId(),safe(d.getDeviceName()));
    }
    private static boolean eq(byte[] a,byte[] b){ return a!=null && b!=null && Arrays.equals(a,b); }
    private static String safe(String s){ return s==null?"<null>":s; }
    private static String hex(byte[] b,int n){
        if(b==null || n<=0) return "<none>";
        StringBuilder s=new StringBuilder();
        for(int i=0;i<n && i<b.length;i++){ if(i>0)s.append(' '); s.append(String.format(Locale.US,"%02X",b[i]&0xFF)); }
        return s.toString();
    }
    private static byte[] hx(String s){
        String[] p=s.trim().split("\\s+"); byte[] out=new byte[p.length];
        for(int i=0;i<p.length;i++) out[i]=(byte)Integer.parseInt(p[i],16);
        return out;
    }
    private void add(String s){ runOnUiThread(() -> log.append(s+"\n")); }
    private void ui(String s){ runOnUiThread(() -> log.append(s+"\n")); }

    private static final class Capture{
        String androidSig;
        byte[] device,config;
        boolean exactNormal;
        final Map<Integer,byte[]> hidReports=new LinkedHashMap<>();
    }
}
