# R22 build notes

ใช้ `OKN_BP1048P4_AUTO.yml` เดิมได้. Android: Java 17, Gradle 8.10.2, compileSdk 35.

R22 มี host safety guard ตรวจว่า source ไม่มี boot-entry path และ Output SET_REPORT ถูกใช้เฉพาะ semantic query CTRL 0x00/0x11 LEN=0.
