from pathlib import Path
s=Path('android-usb-probe/app/src/main/java/com/okn/dsp/usbprobe/MainActivity.java').read_text()
assert 'versionName' not in s
assert 'tx[0]=(byte)0xA5; tx[1]=0x5A; tx[2]=(byte)ctrl; tx[3]=0x00; tx[4]=0x16;' in s
assert 'ctrl!=0x00 && ctrl!=0x11' in s
assert 'c.controlTransfer(0x21,0x09,0x0200,4,tx,tx.length,1200)' in s
assert 'c.controlTransfer(0xA1,0x01,0x0100,4,rx,rx.length,1200)' in s
assert 'c.controlTransfer(0x21,0x09,0x0300' not in s  # no Feature SET_REPORT
assert 'bulkTransfer(' not in s
assert 'claimInterface(' not in s
assert '0xFE' not in s
assert '0xFD' not in s
assert 'erase' not in s.lower() or 'NO ERASE' in s or 'no erase' in s.lower()
assert 'program' not in s.lower() or 'NO PROGRAM' in s or 'no program' in s.lower()
print('R22 delayed query safety guard: PASS')
